/*      */ package javafx.embed.swt;
/*      */ 
/*      */ import com.sun.glass.ui.Application;
/*      */ import com.sun.glass.ui.Pixels;
/*      */ import com.sun.javafx.cursor.CursorFrame;
/*      */ import com.sun.javafx.cursor.CursorType;
/*      */ import com.sun.javafx.embed.EmbeddedSceneDSInterface;
/*      */ import com.sun.javafx.embed.EmbeddedSceneDTInterface;
/*      */ import com.sun.javafx.embed.EmbeddedSceneInterface;
/*      */ import com.sun.javafx.embed.EmbeddedStageInterface;
/*      */ import com.sun.javafx.embed.HostInterface;
/*      */ import com.sun.javafx.stage.EmbeddedWindow;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.IntBuffer;
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessController;
/*      */ import java.security.Permission;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.NamedArg;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.input.TransferMode;
/*      */ import javafx.stage.Window;
/*      */ import javafx.util.FXPermission;
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.dnd.DragSource;
/*      */ import org.eclipse.swt.dnd.DragSourceEvent;
/*      */ import org.eclipse.swt.dnd.DragSourceListener;
/*      */ import org.eclipse.swt.dnd.DropTarget;
/*      */ import org.eclipse.swt.dnd.DropTargetEvent;
/*      */ import org.eclipse.swt.dnd.DropTargetListener;
/*      */ import org.eclipse.swt.dnd.FileTransfer;
/*      */ import org.eclipse.swt.dnd.HTMLTransfer;
/*      */ import org.eclipse.swt.dnd.ImageTransfer;
/*      */ import org.eclipse.swt.dnd.RTFTransfer;
/*      */ import org.eclipse.swt.dnd.TextTransfer;
/*      */ import org.eclipse.swt.dnd.Transfer;
/*      */ import org.eclipse.swt.dnd.TransferData;
/*      */ import org.eclipse.swt.dnd.URLTransfer;
/*      */ import org.eclipse.swt.events.ControlEvent;
/*      */ import org.eclipse.swt.events.ControlListener;
/*      */ import org.eclipse.swt.events.DisposeEvent;
/*      */ import org.eclipse.swt.events.DisposeListener;
/*      */ import org.eclipse.swt.events.FocusEvent;
/*      */ import org.eclipse.swt.events.FocusListener;
/*      */ import org.eclipse.swt.events.GestureEvent;
/*      */ import org.eclipse.swt.events.KeyEvent;
/*      */ import org.eclipse.swt.events.KeyListener;
/*      */ import org.eclipse.swt.events.MenuDetectEvent;
/*      */ import org.eclipse.swt.events.MouseEvent;
/*      */ import org.eclipse.swt.events.MouseListener;
/*      */ import org.eclipse.swt.events.MouseTrackListener;
/*      */ import org.eclipse.swt.events.PaintEvent;
/*      */ import org.eclipse.swt.graphics.Cursor;
/*      */ import org.eclipse.swt.graphics.Device;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.ImageData;
/*      */ import org.eclipse.swt.graphics.PaletteData;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.RGB;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.widgets.Canvas;
/*      */ import org.eclipse.swt.widgets.Composite;
/*      */ import org.eclipse.swt.widgets.Control;
/*      */ import org.eclipse.swt.widgets.Display;
/*      */ import org.eclipse.swt.widgets.Event;
/*      */ import org.eclipse.swt.widgets.Listener;
/*      */ import org.eclipse.swt.widgets.Shell;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FXCanvas
/*      */   extends Canvas
/*      */ {
/*  144 */   private static final FXPermission FXCANVAS_PERMISSION = new FXPermission("accessFXCanvasInternals");
/*      */   
/*      */   private HostContainer hostContainer;
/*      */   
/*      */   private volatile EmbeddedWindow stage;
/*      */   
/*      */   private volatile Scene scene;
/*      */   private EmbeddedStageInterface stagePeer;
/*      */   private EmbeddedSceneInterface scenePeer;
/*  153 */   private int pWidth = 0;
/*  154 */   private int pHeight = 0;
/*      */   
/*  156 */   private volatile int pPreferredWidth = -1;
/*  157 */   private volatile int pPreferredHeight = -1;
/*      */   
/*  159 */   private IntBuffer pixelsBuf = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Listener moveFilter;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DropTarget dropTarget;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double getScaleFactor() {
/*  175 */     if (SWT.getPlatform().equals("cocoa")) {
/*  176 */       if (windowField == null || screenMethod == null || backingScaleFactorMethod == null) {
/*  177 */         return 1.0D;
/*      */       }
/*      */       try {
/*  180 */         Object object1 = windowField.get(getShell());
/*  181 */         Object object2 = screenMethod.invoke(object1, new Object[0]);
/*  182 */         Object object3 = backingScaleFactorMethod.invoke(object2, new Object[0]);
/*  183 */         return ((Double)object3).doubleValue();
/*  184 */       } catch (Exception exception) {}
/*      */     
/*      */     }
/*  187 */     else if (SWT.getPlatform().equals("win32")) {
/*  188 */       if (swtDPIUtilMethod == null) {
/*  189 */         return 1.0D;
/*      */       }
/*      */       try {
/*  192 */         Integer integer = (Integer)swtDPIUtilMethod.invoke((Object)null, new Object[0]);
/*  193 */         return integer.intValue() / 100.0D;
/*  194 */       } catch (Exception exception) {}
/*      */     } 
/*      */ 
/*      */     
/*  198 */     return 1.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  203 */   static Transfer[] StandardTransfers = new Transfer[] {
/*  204 */       (Transfer)TextTransfer.getInstance(), 
/*  205 */       (Transfer)RTFTransfer.getInstance(), 
/*  206 */       (Transfer)HTMLTransfer.getInstance(), 
/*  207 */       (Transfer)URLTransfer.getInstance(), 
/*  208 */       (Transfer)ImageTransfer.getInstance(), 
/*  209 */       (Transfer)FileTransfer.getInstance()
/*      */     };
/*  211 */   static Transfer[] CustomTransfers = new Transfer[0]; private static Field windowField; private static Method windowMethod; private static Method screenMethod; private static Method backingScaleFactorMethod; private static Method swtDPIUtilMethod;
/*      */   
/*      */   static Transfer[] getAllTransfers() {
/*  214 */     Transfer[] arrayOfTransfer = new Transfer[StandardTransfers.length + CustomTransfers.length];
/*  215 */     System.arraycopy(StandardTransfers, 0, arrayOfTransfer, 0, StandardTransfers.length);
/*  216 */     System.arraycopy(CustomTransfers, 0, arrayOfTransfer, StandardTransfers.length, CustomTransfers.length);
/*  217 */     return arrayOfTransfer;
/*      */   }
/*      */   
/*      */   static Transfer getCustomTransfer(String paramString) {
/*  221 */     for (byte b = 0; b < CustomTransfers.length; b++) {
/*  222 */       if (((CustomTransfer)CustomTransfers[b]).getMime().equals(paramString)) {
/*  223 */         return CustomTransfers[b];
/*      */       }
/*      */     } 
/*  226 */     CustomTransfer customTransfer = new CustomTransfer(paramString, paramString);
/*  227 */     Transfer[] arrayOfTransfer = new Transfer[CustomTransfers.length + 1];
/*  228 */     System.arraycopy(CustomTransfers, 0, arrayOfTransfer, 0, CustomTransfers.length);
/*  229 */     arrayOfTransfer[CustomTransfers.length] = (Transfer)customTransfer;
/*  230 */     CustomTransfers = arrayOfTransfer;
/*  231 */     return (Transfer)customTransfer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  241 */     if (SWT.getPlatform().equals("cocoa")) {
/*      */       try {
/*  243 */         windowField = Shell.class.getDeclaredField("window");
/*  244 */         windowField.setAccessible(true);
/*      */         
/*  246 */         Class<?> clazz1 = Class.forName("org.eclipse.swt.internal.cocoa.NSView");
/*  247 */         windowMethod = clazz1.getDeclaredMethod("window", new Class[0]);
/*  248 */         windowMethod.setAccessible(true);
/*      */         
/*  250 */         Class<?> clazz2 = Class.forName("org.eclipse.swt.internal.cocoa.NSWindow");
/*  251 */         screenMethod = clazz2.getDeclaredMethod("screen", new Class[0]);
/*  252 */         screenMethod.setAccessible(true);
/*      */         
/*  254 */         Class<?> clazz3 = Class.forName("org.eclipse.swt.internal.cocoa.NSScreen");
/*  255 */         backingScaleFactorMethod = clazz3.getDeclaredMethod("backingScaleFactor", new Class[0]);
/*  256 */         backingScaleFactorMethod.setAccessible(true);
/*  257 */       } catch (Exception exception) {}
/*      */     
/*      */     }
/*  260 */     else if (SWT.getPlatform().equals("win32")) {
/*      */       try {
/*  262 */         String str = AccessController.<String>doPrivileged(() -> System.getProperty("swt.autoScale"));
/*  263 */         if (str == null || !"false".equalsIgnoreCase(str)) {
/*  264 */           Class<?> clazz = Class.forName("org.eclipse.swt.internal.DPIUtil");
/*  265 */           swtDPIUtilMethod = clazz.getMethod("getDeviceZoom", new Class[0]);
/*      */         } 
/*  267 */       } catch (Exception exception) {}
/*      */     } 
/*      */ 
/*      */     
/*  271 */     initFx();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FXCanvas(@NamedArg("parent") Composite paramComposite, @NamedArg("style") int paramInt) {
/*  278 */     super(paramComposite, paramInt | 0x40000);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     this.moveFilter = (paramEvent -> {
/*      */         FXCanvas fXCanvas = this;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         while (fXCanvas != null) {
/*      */           if (fXCanvas == paramEvent.widget) {
/*      */             sendMoveEventToFX();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           Composite composite = fXCanvas.getParent();
/*      */         } 
/*      */       });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  609 */     this.lastScaleFactor = 1.0D;
/*      */     
/*  611 */     this.lastPixelsBuf = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  744 */     this.totalScrollX = 0.0D;
/*  745 */     this.totalScrollY = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  827 */     this.gestureActive = false;
/*      */     
/*  829 */     this.panGestureInertiaActive = false;
/*      */ 
/*      */ 
/*      */     
/*  833 */     this.nestedGestures = new Stack<>();
/*      */     
/*  835 */     this.inertiaTime = 0L;
/*  836 */     this.inertiaXScroll = 0.0D;
/*  837 */     this.inertiaYScroll = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  945 */     this.lastTotalZoom = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  969 */     this.lastTotalAngle = 0.0D; setApplicationName(Display.getAppName()); this.hostContainer = new HostContainer(); registerEventListeners(); Display display = paramComposite.getDisplay(); display.addFilter(10, this.moveFilter);
/*      */   } public static FXCanvas getFXCanvas(Scene paramScene) { Window window = paramScene.getWindow(); if (window != null && window instanceof EmbeddedWindow) { HostInterface hostInterface = ((EmbeddedWindow)window).getHost(); if (hostInterface instanceof HostContainer) return ((HostContainer)hostInterface).fxCanvas;  }  return null; } private static void initFx() { long l = 0L; try { Field field = Display.class.getDeclaredField("eventProc"); field.setAccessible(true); if (field.getType() == int.class) { l = field.getInt(Display.getDefault()); } else if (field.getType() == long.class) { l = field.getLong(Display.getDefault()); }  } catch (Throwable throwable) {} String str = String.valueOf(l); AccessController.doPrivileged(() -> { System.setProperty("com.sun.javafx.application.type", "FXCanvas"); System.setProperty("javafx.embed.isEventThread", "true"); if (swtDPIUtilMethod == null) { System.setProperty("glass.win.uiScale", "100%"); System.setProperty("glass.win.renderScale", "100%"); } else { Integer integer = Integer.valueOf(100); try { integer = (Integer)swtDPIUtilMethod.invoke(null, new Object[0]); } catch (Exception exception) {} System.setProperty("glass.win.uiScale", "" + integer + "%"); System.setProperty("glass.win.renderScale", "" + integer + "%"); }  System.setProperty("javafx.embed.eventProc", paramString); return null; }); CountDownLatch countDownLatch = new CountDownLatch(1); AccessController.doPrivileged(() -> { Platform.startup(()); return null; }(AccessControlContext)null, new Permission[] { (Permission)FXCANVAS_PERMISSION }); try { countDownLatch.await(); } catch (InterruptedException interruptedException) { throw new RuntimeException(interruptedException); }  } private void setApplicationName(String paramString) { Platform.runLater(() -> Application.GetApplication().setName(paramString)); } public void reskin(int paramInt) { super.reskin(paramInt); if (paramInt == 1) sendMoveEventToFX();  } static ArrayList<DropTarget> targets = new ArrayList<>(); double lastScaleFactor; int lastWidth; int lastHeight; IntBuffer lastPixelsBuf; double totalScrollX; double totalScrollY; private boolean gestureActive; private boolean panGestureInertiaActive; private GestureEvent lastGestureEvent; private Stack<Integer> nestedGestures; private long inertiaTime; private double inertiaXScroll;
/*  971 */   private void sendRotateEventToFX(int paramInt, GestureEvent paramGestureEvent) { Point point = toDisplay(paramGestureEvent.x, paramGestureEvent.y);
/*      */ 
/*      */ 
/*      */     
/*  975 */     double d1 = -paramGestureEvent.rotation;
/*      */     
/*  977 */     d1 = this.lastTotalAngle = 0.0D;
/*  978 */     if (paramInt == 2)
/*      */     {
/*  980 */       d1 = this.lastTotalAngle;
/*      */     }
/*  982 */     double d2 = (paramInt == 2) ? 0.0D : (d1 - this.lastTotalAngle);
/*  983 */     this.lastTotalAngle = d1;
/*      */     
/*  985 */     this.scenePeer.rotateEvent(paramInt, d2, d1, paramGestureEvent.x, paramGestureEvent.y, point.x, point.y, ((paramGestureEvent.stateMask & 0x20000) != 0), ((paramGestureEvent.stateMask & 0x40000) != 0), ((paramGestureEvent.stateMask & 0x10000) != 0), ((paramGestureEvent.stateMask & 0x400000) != 0), !this.gestureActive); } private double inertiaYScroll; private double lastTotalZoom; private double lastTotalAngle; DropTarget getDropTarget() { return this.dropTarget; }
/*      */   void setDropTarget(DropTarget paramDropTarget) { if (this.dropTarget != null) { targets.remove(this.dropTarget); this.dropTarget.dispose(); }  this.dropTarget = paramDropTarget; if (this.dropTarget != null)
/*      */       targets.add(this.dropTarget);  }
/*      */   static void updateDropTarget() { for (DropTarget dropTarget : targets)
/*      */       dropTarget.setTransfer(getAllTransfers());  }
/*      */   public Point computeSize(int paramInt1, int paramInt2, boolean paramBoolean) { checkWidget(); if (paramInt1 == -1 && paramInt2 == -1 && this.pPreferredWidth != -1 && this.pPreferredHeight != -1)
/*      */       return new Point(this.pPreferredWidth, this.pPreferredHeight);  return super.computeSize(paramInt1, paramInt2, paramBoolean); }
/*      */   public Scene getScene() { checkWidget(); return this.scene; }
/*      */   public void setScene(Scene paramScene) { checkWidget(); if (this.stage == null && paramScene != null) { this.stage = new EmbeddedWindow(this.hostContainer); this.stage.show(); }  this.scene = paramScene; if (this.stage != null)
/*      */       this.stage.setScene(paramScene);  if (this.stage != null && paramScene == null) { this.stage.hide(); this.stage = null; }  }
/*  995 */   private void sendSwipeEventToFX(GestureEvent paramGestureEvent) { Point point = toDisplay(paramGestureEvent.x, paramGestureEvent.y);
/*  996 */     byte b = -1;
/*  997 */     if (paramGestureEvent.yDirection > 0) {
/*  998 */       b = 0;
/*  999 */     } else if (paramGestureEvent.yDirection < 0) {
/* 1000 */       b = 1;
/* 1001 */     } else if (paramGestureEvent.xDirection > 0) {
/* 1002 */       b = 3;
/* 1003 */     } else if (paramGestureEvent.xDirection < 0) {
/* 1004 */       b = 2;
/*      */     } 
/* 1006 */     this.scenePeer.swipeEvent(b, paramGestureEvent.x, paramGestureEvent.y, point.x, point.y, ((paramGestureEvent.stateMask & 0x20000) != 0), ((paramGestureEvent.stateMask & 0x40000) != 0), ((paramGestureEvent.stateMask & 0x10000) != 0), ((paramGestureEvent.stateMask & 0x400000) != 0)); } private void registerEventListeners() { addDisposeListener(new DisposeListener() { public void widgetDisposed(DisposeEvent param1DisposeEvent) { Display display = FXCanvas.this.getDisplay(); display.removeFilter(10, FXCanvas.this.moveFilter); FXCanvas.this.widgetDisposed(param1DisposeEvent); } }
/*      */       ); addPaintListener(paramPaintEvent -> paintControl(paramPaintEvent)); addMouseListener(new MouseListener() { public void mouseDoubleClick(MouseEvent param1MouseEvent) {} public void mouseDown(MouseEvent param1MouseEvent) { if (param1MouseEvent.button > 3) return;  FXCanvas.this.sendMouseEventToFX(param1MouseEvent, 0); } public void mouseUp(MouseEvent param1MouseEvent) { if (param1MouseEvent.button > 3) return;  FXCanvas.this.sendMouseEventToFX(param1MouseEvent, 1); } }
/*      */       ); addMouseMoveListener(paramMouseEvent -> { if ((paramMouseEvent.stateMask & SWT.BUTTON_MASK) != 0) { if ((paramMouseEvent.stateMask & 0x380000) != 0) { sendMouseEventToFX(paramMouseEvent, 6); } else { sendMouseEventToFX(paramMouseEvent, 5); }  } else { sendMouseEventToFX(paramMouseEvent, 5); }  }); addListener(37, paramEvent -> { if (!this.gestureActive && (!this.panGestureInertiaActive || this.lastGestureEvent == null || paramEvent.time != this.lastGestureEvent.time)) sendScrollEventToFX(7, 0.0D, SWTEvents.getWheelRotation(paramEvent), paramEvent.x, paramEvent.y, paramEvent.stateMask, false);  }); addListener(38, paramEvent -> { if (!this.gestureActive && (!this.panGestureInertiaActive || this.lastGestureEvent == null || paramEvent.time != this.lastGestureEvent.time)) sendScrollEventToFX(8, SWTEvents.getWheelRotation(paramEvent), 0.0D, paramEvent.x, paramEvent.y, paramEvent.stateMask, false);  }); addMouseTrackListener(new MouseTrackListener() { public void mouseEnter(MouseEvent param1MouseEvent) { FXCanvas.this.sendMouseEventToFX(param1MouseEvent, 3); } public void mouseExit(MouseEvent param1MouseEvent) { FXCanvas.this.sendMouseEventToFX(param1MouseEvent, 4); } public void mouseHover(MouseEvent param1MouseEvent) {} }
/*      */       ); addControlListener(new ControlListener() { public void controlMoved(ControlEvent param1ControlEvent) { FXCanvas.this.sendMoveEventToFX(); } public void controlResized(ControlEvent param1ControlEvent) { FXCanvas.this.sendResizeEventToFX(); } }
/*      */       ); addFocusListener(new FocusListener() { public void focusGained(FocusEvent param1FocusEvent) { FXCanvas.this.sendFocusEventToFX(param1FocusEvent, true); } public void focusLost(FocusEvent param1FocusEvent) { FXCanvas.this.sendFocusEventToFX(param1FocusEvent, false); } }
/*      */       ); addKeyListener(new KeyListener() { public void keyPressed(KeyEvent param1KeyEvent) { FXCanvas.this.sendKeyEventToFX(param1KeyEvent, 1); } public void keyReleased(KeyEvent param1KeyEvent) { FXCanvas.this.sendKeyEventToFX(param1KeyEvent, 2); } }
/*      */       ); addGestureListener(paramGestureEvent -> sendGestureEventToFX(paramGestureEvent)); addMenuDetectListener(paramMenuDetectEvent -> { Runnable runnable = (); if ("cocoa".equals(SWT.getPlatform())) { getDisplay().asyncExec(runnable); } else { runnable.run(); }  }); } private void widgetDisposed(DisposeEvent paramDisposeEvent) { setDropTarget((DropTarget)null); if (this.stage != null) this.stage.hide();  } private void paintControl(PaintEvent paramPaintEvent) { if (this.scenePeer == null || this.pixelsBuf == null) return;  double d = getScaleFactor(); if (this.lastScaleFactor != d) { resizePixelBuffer(d); this.lastScaleFactor = d; this.scenePeer.setPixelScaleFactors((float)d, (float)d); }  IntBuffer intBuffer = this.pixelsBuf; int i = this.pWidth, j = this.pHeight; if (this.scenePeer.getPixels(this.pixelsBuf, this.pWidth, this.pHeight)) { i = this.lastWidth = this.pWidth; j = this.lastHeight = this.pHeight; intBuffer = this.lastPixelsBuf = this.pixelsBuf; } else { if (this.lastPixelsBuf == null) return;  i = this.lastWidth; j = this.lastHeight; intBuffer = this.lastPixelsBuf; }  i = (int)Math.round(i * d); j = (int)Math.round(j * d); ImageData imageData = null; if ("win32".equals(SWT.getPlatform())) { PaletteData paletteData = new PaletteData(65280, 16711680, -16777216); int k = i * 4; byte[] arrayOfByte = new byte[k * j]; int[] arrayOfInt = intBuffer.array(); byte b1 = 0, b2 = 0; for (byte b3 = 0; b3 < j; b3++) { for (byte b = 0; b < i; b++) { int m = arrayOfInt[b2++]; arrayOfByte[b1++] = (byte)(m & 0xFF); arrayOfByte[b1++] = (byte)(m >> 8 & 0xFF); arrayOfByte[b1++] = (byte)(m >> 16 & 0xFF); arrayOfByte[b1++] = 0; }  }  imageData = new ImageData(i, j, 32, paletteData, 4, arrayOfByte); } else { if (i * j > (intBuffer.array()).length) { System.err.println("FXCanvas.paintControl: scale mismatch!"); return; }  PaletteData paletteData = new PaletteData(16711680, 65280, 255); imageData = new ImageData(i, j, 32, paletteData); imageData.setPixels(0, 0, i * j, intBuffer.array(), 0); }  Image image = new Image((Device)Display.getDefault(), imageData); paramPaintEvent.gc.drawImage(image, 0, 0, i, j, 0, 0, this.pWidth, this.pHeight); image.dispose(); }
/*      */   private void sendMoveEventToFX() { if (this.stagePeer == null) return;  Rectangle rectangle = getClientArea(); Point point = toDisplay(rectangle.x, rectangle.y); this.stagePeer.setLocation(point.x, point.y); }
/* 1014 */   private void sendMenuEventToFX(MenuDetectEvent paramMenuDetectEvent) { if (this.scenePeer == null) {
/*      */       return;
/*      */     }
/* 1017 */     Point point = toControl(paramMenuDetectEvent.x, paramMenuDetectEvent.y);
/* 1018 */     this.scenePeer.menuEvent(point.x, point.y, paramMenuDetectEvent.x, paramMenuDetectEvent.y, false); }
/*      */   private void sendMouseEventToFX(MouseEvent paramMouseEvent, int paramInt) { if (this.scenePeer == null)
/*      */       return;  Point point = toDisplay(paramMouseEvent.x, paramMouseEvent.y); int i = ((paramMouseEvent.stateMask & 0x80000) != 0) ? 1 : 0; int j = ((paramMouseEvent.stateMask & 0x100000) != 0) ? 1 : 0; int k = ((paramMouseEvent.stateMask & 0x200000) != 0) ? 1 : 0; boolean bool1 = ((paramMouseEvent.stateMask & 0x20000) != 0) ? true : false; boolean bool2 = ((paramMouseEvent.stateMask & 0x40000) != 0) ? true : false; boolean bool3 = ((paramMouseEvent.stateMask & 0x10000) != 0) ? true : false; boolean bool4 = ((paramMouseEvent.stateMask & 0x400000) != 0) ? true : false; int m = paramMouseEvent.button; switch (paramInt) { case 0: i |= (paramMouseEvent.button == 1) ? 1 : 0; j |= (paramMouseEvent.button == 2) ? 1 : 0; k |= (paramMouseEvent.button == 3) ? 1 : 0; break;case 1: i &= (paramMouseEvent.button != 1) ? 1 : 0; j &= (paramMouseEvent.button != 2) ? 1 : 0; k &= (paramMouseEvent.button != 3) ? 1 : 0; break;case 2: return;case 3: case 4: case 5: case 6: if (m == 0) { if ((paramMouseEvent.stateMask & 0x80000) != 0) { m = 1; break; }  if ((paramMouseEvent.stateMask & 0x100000) != 0) { m = 2; break; }  if ((paramMouseEvent.stateMask & 0x200000) != 0)
/*      */             m = 3;  }  break; }  this.scenePeer.mouseEvent(paramInt, SWTEvents.mouseButtonToEmbedMouseButton(m, paramMouseEvent.stateMask), i, j, k, paramMouseEvent.x, paramMouseEvent.y, point.x, point.y, bool1, bool2, bool3, bool4, false); }
/*      */   private void sendScrollEventToFX(int paramInt1, double paramDouble1, double paramDouble2, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) { if (this.scenePeer == null)
/*      */       return;  double d = 5.0D; if (paramInt1 == 8 || paramInt1 == 7) { d = 40.0D; this.totalScrollX = paramDouble1; this.totalScrollY = paramDouble2; } else { if ("cocoa".equals(SWT.getPlatform()) && SWT.getVersion() < 4600)
/* 1024 */         d *= -1.0D;  if (paramInt1 == 0) { this.totalScrollX = 0.0D; this.totalScrollY = 0.0D; } else if (paramBoolean) { this.totalScrollX = paramDouble1; this.totalScrollY = paramDouble2; } else { this.totalScrollX += paramDouble1; this.totalScrollY += paramDouble2; }  }  Point point = toDisplay(paramInt2, paramInt3); this.scenePeer.scrollEvent(paramInt1, paramDouble1, paramDouble2, this.totalScrollX, this.totalScrollY, d, d, paramInt2, paramInt3, point.x, point.y, ((paramInt4 & 0x20000) != 0), ((paramInt4 & 0x40000) != 0), ((paramInt4 & 0x10000) != 0), ((paramInt4 & 0x400000) != 0), paramBoolean); } private void sendResizeEventToFX() { redraw();
/* 1025 */     update();
/*      */     
/* 1027 */     this.pWidth = (getClientArea()).width;
/* 1028 */     this.pHeight = (getClientArea()).height;
/*      */     
/* 1030 */     resizePixelBuffer(this.lastScaleFactor);
/*      */     
/* 1032 */     if (this.scenePeer == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1036 */     this.stagePeer.setSize(this.pWidth, this.pHeight);
/* 1037 */     this.scenePeer.setSize(this.pWidth, this.pHeight); }
/*      */   private void sendKeyEventToFX(KeyEvent paramKeyEvent, int paramInt) { if (this.scenePeer == null) return;  int i = paramKeyEvent.stateMask; if (paramInt == 1) { if (paramKeyEvent.keyCode == 131072) i |= 0x20000;  if (paramKeyEvent.keyCode == 262144) i |= 0x40000;  if (paramKeyEvent.keyCode == 65536) i |= 0x10000;  if (paramKeyEvent.keyCode == 4194304) i |= 0x400000;  } else { if (paramKeyEvent.keyCode == 131072) i &= 0xFFFDFFFF;  if (paramKeyEvent.keyCode == 262144) i &= 0xFFFBFFFF;  if (paramKeyEvent.keyCode == 65536) i &= 0xFFFEFFFF;  if (paramKeyEvent.keyCode == 4194304) i &= 0xFFBFFFFF;  }  int j = SWTEvents.keyCodeToEmbedKeyCode(paramKeyEvent.keyCode); this.scenePeer.keyEvent(SWTEvents.keyIDToEmbedKeyType(paramInt), j, new char[0], SWTEvents.keyModifiersToEmbedKeyModifiers(i)); if (paramKeyEvent.character != '\000' && paramInt == 1) { char[] arrayOfChar = { paramKeyEvent.character }; this.scenePeer.keyEvent(2, paramKeyEvent.keyCode, arrayOfChar, SWTEvents.keyModifiersToEmbedKeyModifiers(i)); }  }
/*      */   private void sendGestureEventToFX(GestureEvent paramGestureEvent) { if (this.scenePeer == null) return;  switch (paramGestureEvent.detail) { case 2: this.gestureActive = true; this.panGestureInertiaActive = false; break;case 32: if (this.gestureActive && !this.nestedGestures.contains(Integer.valueOf(32))) { sendZoomEventToFX(0, paramGestureEvent); this.nestedGestures.push(Integer.valueOf(32)); }  sendZoomEventToFX(1, paramGestureEvent); break;case 64: if (this.gestureActive && !this.nestedGestures.contains(Integer.valueOf(64))) { sendScrollEventToFX(0, paramGestureEvent.xDirection, paramGestureEvent.yDirection, paramGestureEvent.x, paramGestureEvent.y, paramGestureEvent.stateMask, false); this.nestedGestures.push(Integer.valueOf(64)); }  if (this.panGestureInertiaActive && paramGestureEvent.time > this.lastGestureEvent.time + 250) this.panGestureInertiaActive = false;  if (this.gestureActive || this.panGestureInertiaActive) { double d1 = paramGestureEvent.xDirection; double d2 = paramGestureEvent.yDirection; if (this.panGestureInertiaActive) if (d1 == 0.0D && d2 == 0.0D) { double d = Math.max(0.0D, Math.min(1.0D, (paramGestureEvent.time - this.inertiaTime) / 1500.0D)); d1 = (1.0D - d) * this.inertiaXScroll; d2 = (1.0D - d) * this.inertiaYScroll; }   sendScrollEventToFX(1, d1, d2, paramGestureEvent.x, paramGestureEvent.y, paramGestureEvent.stateMask, this.panGestureInertiaActive); }  break;case 8: if (this.gestureActive && !this.nestedGestures.contains(Integer.valueOf(8))) { sendRotateEventToFX(0, paramGestureEvent); this.nestedGestures.push(Integer.valueOf(8)); }  sendRotateEventToFX(1, paramGestureEvent); break;case 16: sendSwipeEventToFX(paramGestureEvent); break;case 4: while (!this.nestedGestures.isEmpty()) { switch (((Integer)this.nestedGestures.pop()).intValue()) { case 32: sendZoomEventToFX(2, paramGestureEvent);case 64: sendScrollEventToFX(2, paramGestureEvent.xDirection, paramGestureEvent.yDirection, paramGestureEvent.x, paramGestureEvent.y, paramGestureEvent.stateMask, false); this.inertiaXScroll = this.lastGestureEvent.xDirection; this.inertiaYScroll = this.lastGestureEvent.yDirection; this.inertiaTime = paramGestureEvent.time; this.panGestureInertiaActive = true;case 8: sendRotateEventToFX(2, paramGestureEvent); }  }  this.gestureActive = false; break; }  this.lastGestureEvent = paramGestureEvent; }
/*      */   private void sendZoomEventToFX(int paramInt, GestureEvent paramGestureEvent) { Point point = toDisplay(paramGestureEvent.x, paramGestureEvent.y); double d1 = paramGestureEvent.magnification; d1 = this.lastTotalZoom = 1.0D; if (paramInt == 2)
/* 1041 */       d1 = this.lastTotalZoom;  double d2 = (paramInt == 2) ? 1.0D : (d1 / this.lastTotalZoom); this.lastTotalZoom = d1; this.scenePeer.zoomEvent(paramInt, d2, d1, paramGestureEvent.x, paramGestureEvent.y, point.x, point.y, ((paramGestureEvent.stateMask & 0x20000) != 0), ((paramGestureEvent.stateMask & 0x40000) != 0), ((paramGestureEvent.stateMask & 0x10000) != 0), ((paramGestureEvent.stateMask & 0x400000) != 0), !this.gestureActive); } private void resizePixelBuffer(double paramDouble) { this.lastPixelsBuf = null;
/* 1042 */     if (this.pWidth <= 0 || this.pHeight <= 0) {
/* 1043 */       this.pixelsBuf = null;
/*      */     } else {
/* 1045 */       this.pixelsBuf = IntBuffer.allocate((int)Math.round(this.pWidth * paramDouble) * 
/* 1046 */           (int)Math.round(this.pHeight * paramDouble));
/*      */       
/* 1048 */       RGB rGB = getBackground().getRGB();
/* 1049 */       Arrays.fill(this.pixelsBuf.array(), rGB.red << 16 | rGB.green << 8 | rGB.blue);
/*      */     }  }
/*      */ 
/*      */   
/*      */   private void sendFocusEventToFX(FocusEvent paramFocusEvent, boolean paramBoolean) {
/* 1054 */     if (this.stage == null || this.stagePeer == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1059 */     boolean bool = paramBoolean ? false : true;
/* 1060 */     this.stagePeer.setFocused(paramBoolean, bool);
/*      */   }
/*      */   
/*      */   private class HostContainer
/*      */     implements HostInterface {
/* 1065 */     final FXCanvas fxCanvas = FXCanvas.this;
/*      */ 
/*      */     
/*      */     public void setEmbeddedStage(EmbeddedStageInterface param1EmbeddedStageInterface) {
/* 1069 */       FXCanvas.this.stagePeer = param1EmbeddedStageInterface;
/* 1070 */       if (FXCanvas.this.stagePeer == null) {
/*      */         return;
/*      */       }
/* 1073 */       if (FXCanvas.this.pWidth > 0 && FXCanvas.this.pHeight > 0) {
/* 1074 */         FXCanvas.this.stagePeer.setSize(FXCanvas.this.pWidth, FXCanvas.this.pHeight);
/*      */       }
/* 1076 */       if (FXCanvas.this.isFocusControl()) {
/* 1077 */         FXCanvas.this.stagePeer.setFocused(true, 0);
/*      */       }
/* 1079 */       FXCanvas.this.sendMoveEventToFX();
/* 1080 */       FXCanvas.this.sendResizeEventToFX();
/*      */     }
/*      */     
/*      */     TransferMode getTransferMode(int param1Int) {
/* 1084 */       switch (param1Int) {
/*      */         case 1:
/* 1086 */           return TransferMode.COPY;
/*      */         case 2:
/*      */         case 8:
/* 1089 */           return TransferMode.MOVE;
/*      */         case 4:
/* 1091 */           return TransferMode.LINK;
/*      */       } 
/* 1093 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     Set<TransferMode> getTransferModes(int param1Int) {
/* 1098 */       HashSet<TransferMode> hashSet = new HashSet();
/* 1099 */       if ((param1Int & 0x1) != 0) hashSet.add(TransferMode.COPY); 
/* 1100 */       if ((param1Int & 0x2) != 0) hashSet.add(TransferMode.MOVE); 
/* 1101 */       if ((param1Int & 0x8) != 0) hashSet.add(TransferMode.MOVE); 
/* 1102 */       if ((param1Int & 0x4) != 0) hashSet.add(TransferMode.LINK); 
/* 1103 */       return hashSet;
/*      */     }
/*      */     
/*      */     ImageData createImageData(Pixels param1Pixels) {
/* 1107 */       if (param1Pixels == null) return null; 
/* 1108 */       int i = param1Pixels.getWidth();
/* 1109 */       int j = param1Pixels.getHeight();
/* 1110 */       int k = i * 4;
/* 1111 */       int m = k * j;
/* 1112 */       byte[] arrayOfByte1 = new byte[m];
/* 1113 */       byte[] arrayOfByte2 = new byte[i * j];
/* 1114 */       if (param1Pixels.getBytesPerComponent() == 1) {
/*      */         
/* 1116 */         ByteBuffer byteBuffer = (ByteBuffer)param1Pixels.getPixels();
/* 1117 */         for (byte b1 = 0, b2 = 0, b3 = 0; b1 < j; b1++) {
/* 1118 */           for (byte b = 0; b < i; b++, b2 += 4) {
/* 1119 */             byte b4 = byteBuffer.get();
/* 1120 */             byte b5 = byteBuffer.get();
/* 1121 */             byte b6 = byteBuffer.get();
/* 1122 */             byte b7 = byteBuffer.get();
/*      */             
/* 1124 */             arrayOfByte2[b3++] = b7;
/* 1125 */             arrayOfByte1[b2] = b4;
/* 1126 */             arrayOfByte1[b2 + 1] = b5;
/* 1127 */             arrayOfByte1[b2 + 2] = b6;
/* 1128 */             arrayOfByte1[b2 + 3] = 0;
/*      */           } 
/*      */         } 
/* 1131 */       } else if (param1Pixels.getBytesPerComponent() == 4) {
/*      */         
/* 1133 */         IntBuffer intBuffer = (IntBuffer)param1Pixels.getPixels();
/* 1134 */         for (byte b1 = 0, b2 = 0, b3 = 0; b1 < j; b1++) {
/* 1135 */           for (byte b = 0; b < i; b++, b2 += 4) {
/* 1136 */             int n = intBuffer.get();
/* 1137 */             byte b4 = (byte)(n & 0xFF);
/* 1138 */             byte b5 = (byte)(n >> 8 & 0xFF);
/* 1139 */             byte b6 = (byte)(n >> 16 & 0xFF);
/* 1140 */             byte b7 = (byte)(n >> 24 & 0xFF);
/*      */             
/* 1142 */             arrayOfByte2[b3++] = b7;
/* 1143 */             arrayOfByte1[b2] = b4;
/* 1144 */             arrayOfByte1[b2 + 1] = b5;
/* 1145 */             arrayOfByte1[b2 + 2] = b6;
/* 1146 */             arrayOfByte1[b2 + 3] = 0;
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1150 */         return null;
/*      */       } 
/* 1152 */       PaletteData paletteData = new PaletteData(65280, 16711680, -16777216);
/* 1153 */       ImageData imageData = new ImageData(i, j, 32, paletteData, 4, arrayOfByte1);
/* 1154 */       imageData.alphaData = arrayOfByte2;
/* 1155 */       return imageData;
/*      */     }
/*      */ 
/*      */     
/*      */     private DragSource createDragSource(final EmbeddedSceneDSInterface fxDragSource, TransferMode param1TransferMode) {
/* 1160 */       Transfer[] arrayOfTransfer = getTransferTypes(fxDragSource.getMimeTypes());
/* 1161 */       if (arrayOfTransfer.length == 0) return null; 
/* 1162 */       int i = getDragActions(fxDragSource.getSupportedActions());
/* 1163 */       final DragSource dragSource = new DragSource((Control)FXCanvas.this, i);
/* 1164 */       dragSource.setTransfer(arrayOfTransfer);
/* 1165 */       dragSource.addDragListener(new DragSourceListener() {
/*      */             public void dragFinished(DragSourceEvent param2DragSourceEvent) {
/* 1167 */               dragSource.dispose();
/* 1168 */               fxDragSource.dragDropEnd(FXCanvas.HostContainer.this.getTransferMode(param2DragSourceEvent.detail));
/*      */             }
/*      */             public void dragSetData(DragSourceEvent param2DragSourceEvent) {
/* 1171 */               Transfer[] arrayOfTransfer = dragSource.getTransfer();
/* 1172 */               for (byte b = 0; b < arrayOfTransfer.length; b++) {
/* 1173 */                 if (arrayOfTransfer[b].isSupportedType(param2DragSourceEvent.dataType)) {
/* 1174 */                   String str = FXCanvas.HostContainer.this.getMime(arrayOfTransfer[b]);
/* 1175 */                   if (str != null) {
/* 1176 */                     param2DragSourceEvent.doit = true;
/* 1177 */                     param2DragSourceEvent.data = fxDragSource.getData(str);
/* 1178 */                     if (param2DragSourceEvent.data instanceof Pixels) {
/* 1179 */                       param2DragSourceEvent.data = FXCanvas.HostContainer.this.createImageData((Pixels)param2DragSourceEvent.data);
/*      */                     }
/*      */                     return;
/*      */                   } 
/*      */                 } 
/* 1184 */                 param2DragSourceEvent.doit = false;
/*      */               } 
/*      */             }
/*      */             
/*      */             public void dragStart(DragSourceEvent param2DragSourceEvent) {}
/*      */           });
/* 1190 */       return dragSource;
/*      */     }
/*      */     
/*      */     int getDragAction(TransferMode param1TransferMode) {
/* 1194 */       if (param1TransferMode == null) return 0; 
/* 1195 */       switch (param1TransferMode) { case COPY:
/* 1196 */           return 1;
/* 1197 */         case MOVE: return 2;
/* 1198 */         case LINK: return 4; }
/*      */       
/* 1200 */       throw new IllegalArgumentException("Invalid transfer mode");
/*      */     }
/*      */ 
/*      */     
/*      */     int getDragActions(Set<TransferMode> param1Set) {
/* 1205 */       int i = 0;
/* 1206 */       for (TransferMode transferMode : param1Set) {
/* 1207 */         i |= getDragAction(transferMode);
/*      */       }
/* 1209 */       return i;
/*      */     }
/*      */     
/*      */     Transfer getTransferType(String param1String) {
/* 1213 */       if (param1String.equals("text/plain")) return (Transfer)TextTransfer.getInstance(); 
/* 1214 */       if (param1String.equals("text/rtf")) return (Transfer)RTFTransfer.getInstance(); 
/* 1215 */       if (param1String.equals("text/html")) return (Transfer)HTMLTransfer.getInstance(); 
/* 1216 */       if (param1String.equals("text/uri-list")) return (Transfer)URLTransfer.getInstance(); 
/* 1217 */       if (param1String.equals("application/x-java-rawimage")) return (Transfer)ImageTransfer.getInstance(); 
/* 1218 */       if (param1String.equals("application/x-java-file-list") || param1String.equals("java.file-list")) {
/* 1219 */         return (Transfer)FileTransfer.getInstance();
/*      */       }
/* 1221 */       return FXCanvas.getCustomTransfer(param1String);
/*      */     }
/*      */     
/*      */     Transfer[] getTransferTypes(String[] param1ArrayOfString) {
/* 1225 */       byte b1 = 0;
/* 1226 */       Transfer[] arrayOfTransfer = new Transfer[param1ArrayOfString.length];
/* 1227 */       for (byte b2 = 0; b2 < param1ArrayOfString.length; b2++) {
/* 1228 */         Transfer transfer = getTransferType(param1ArrayOfString[b2]);
/* 1229 */         if (transfer != null) arrayOfTransfer[b1++] = transfer; 
/*      */       } 
/* 1231 */       if (b1 != param1ArrayOfString.length) {
/* 1232 */         Transfer[] arrayOfTransfer1 = new Transfer[b1];
/* 1233 */         System.arraycopy(arrayOfTransfer, 0, arrayOfTransfer1, 0, b1);
/* 1234 */         arrayOfTransfer = arrayOfTransfer1;
/*      */       } 
/* 1236 */       return arrayOfTransfer;
/*      */     }
/*      */     
/*      */     String getMime(Transfer param1Transfer) {
/* 1240 */       if (param1Transfer.equals(TextTransfer.getInstance())) return "text/plain"; 
/* 1241 */       if (param1Transfer.equals(RTFTransfer.getInstance())) return "text/rtf"; 
/* 1242 */       if (param1Transfer.equals(HTMLTransfer.getInstance())) return "text/html"; 
/* 1243 */       if (param1Transfer.equals(URLTransfer.getInstance())) return "text/uri-list"; 
/* 1244 */       if (param1Transfer.equals(ImageTransfer.getInstance())) return "application/x-java-rawimage"; 
/* 1245 */       if (param1Transfer.equals(FileTransfer.getInstance())) return "application/x-java-file-list"; 
/* 1246 */       if (param1Transfer instanceof CustomTransfer) return ((CustomTransfer)param1Transfer).getMime(); 
/* 1247 */       return null;
/*      */     }
/*      */     
/*      */     String[] getMimes(Transfer[] param1ArrayOfTransfer, TransferData param1TransferData) {
/* 1251 */       byte b1 = 0;
/* 1252 */       String[] arrayOfString = new String[param1ArrayOfTransfer.length];
/* 1253 */       for (byte b2 = 0; b2 < param1ArrayOfTransfer.length; b2++) {
/* 1254 */         if (param1ArrayOfTransfer[b2].isSupportedType(param1TransferData)) {
/* 1255 */           arrayOfString[b1++] = getMime(param1ArrayOfTransfer[b2]);
/*      */         }
/*      */       } 
/* 1258 */       if (b1 != arrayOfString.length) {
/* 1259 */         String[] arrayOfString1 = new String[b1];
/* 1260 */         System.arraycopy(arrayOfString, 0, arrayOfString1, 0, b1);
/* 1261 */         arrayOfString = arrayOfString1;
/*      */       } 
/* 1263 */       return arrayOfString;
/*      */     }
/*      */     
/*      */     DropTarget createDropTarget(EmbeddedSceneInterface param1EmbeddedSceneInterface) {
/* 1267 */       final DropTarget dropTarget = new DropTarget((Control)FXCanvas.this, 7);
/* 1268 */       final EmbeddedSceneDTInterface fxDropTarget = param1EmbeddedSceneInterface.createDropTarget();
/* 1269 */       dropTarget.setTransfer(FXCanvas.getAllTransfers());
/* 1270 */       dropTarget.addDropListener(new DropTargetListener()
/*      */           {
/*      */             Object data;
/*      */ 
/*      */             
/*      */             TransferData currentTransferData;
/*      */ 
/*      */             
/*      */             boolean ignoreLeave;
/*      */             
/* 1280 */             int detail = 0; int operations = 0;
/* 1281 */             EmbeddedSceneDSInterface fxDragSource = new EmbeddedSceneDSInterface() {
/*      */                 public Set<TransferMode> getSupportedActions() {
/* 1283 */                   return FXCanvas.HostContainer.this.getTransferModes(FXCanvas.HostContainer.null.this.operations);
/*      */                 }
/*      */                 
/*      */                 public Object getData(String param3String) {
/* 1287 */                   return FXCanvas.HostContainer.null.this.data;
/*      */                 }
/*      */                 public String[] getMimeTypes() {
/* 1290 */                   if (FXCanvas.HostContainer.null.this.currentTransferData == null) return new String[0]; 
/* 1291 */                   return FXCanvas.HostContainer.this.getMimes(FXCanvas.getAllTransfers(), FXCanvas.HostContainer.null.this.currentTransferData);
/*      */                 }
/*      */                 public boolean isMimeTypeAvailable(String param3String) {
/* 1294 */                   String[] arrayOfString = getMimeTypes();
/* 1295 */                   for (byte b = 0; b < arrayOfString.length; b++) {
/* 1296 */                     if (arrayOfString[b].equals(param3String)) return true; 
/*      */                   } 
/* 1298 */                   return false;
/*      */                 }
/*      */                 public void dragDropEnd(TransferMode param3TransferMode) {
/* 1301 */                   FXCanvas.HostContainer.null.this.data = null;
/*      */                   
/* 1303 */                   FXCanvas.HostContainer.null.this.currentTransferData = null;
/*      */                 }
/*      */               };
/*      */             public void dragEnter(DropTargetEvent param2DropTargetEvent) {
/* 1307 */               this.ignoreLeave = false;
/* 1308 */               dropTarget.setTransfer(FXCanvas.getAllTransfers());
/* 1309 */               this.detail = param2DropTargetEvent.detail;
/* 1310 */               this.operations = param2DropTargetEvent.operations;
/* 1311 */               dragOver(param2DropTargetEvent, true, this.detail);
/*      */             }
/*      */             public void dragLeave(DropTargetEvent param2DropTargetEvent) {
/* 1314 */               this.detail = this.operations = 0;
/* 1315 */               this.data = null;
/*      */               
/* 1317 */               this.currentTransferData = null;
/* 1318 */               FXCanvas.this.getDisplay().asyncExec(() -> {
/*      */                     if (this.ignoreLeave)
/*      */                       return; 
/*      */                     param2EmbeddedSceneDTInterface.handleDragLeave();
/*      */                   });
/*      */             } public void dragOperationChanged(DropTargetEvent param2DropTargetEvent) {
/* 1324 */               this.detail = param2DropTargetEvent.detail;
/* 1325 */               this.operations = param2DropTargetEvent.operations;
/* 1326 */               dragOver(param2DropTargetEvent, false, this.detail);
/*      */             }
/*      */             public void dragOver(DropTargetEvent param2DropTargetEvent) {
/* 1329 */               this.operations = param2DropTargetEvent.operations;
/* 1330 */               dragOver(param2DropTargetEvent, false, this.detail);
/*      */             }
/*      */             public void dragOver(DropTargetEvent param2DropTargetEvent, boolean param2Boolean, int param2Int) {
/*      */               TransferMode transferMode1;
/* 1334 */               this.currentTransferData = param2DropTargetEvent.currentDataType;
/* 1335 */               Point point = FXCanvas.this.toControl(param2DropTargetEvent.x, param2DropTargetEvent.y);
/* 1336 */               if (param2Int == 0) param2Int = 1; 
/* 1337 */               TransferMode transferMode2 = FXCanvas.HostContainer.this.getTransferMode(param2Int);
/* 1338 */               if (param2Boolean) {
/* 1339 */                 transferMode1 = fxDropTarget.handleDragEnter(point.x, point.y, param2DropTargetEvent.x, param2DropTargetEvent.y, transferMode2, this.fxDragSource);
/*      */               } else {
/* 1341 */                 transferMode1 = fxDropTarget.handleDragOver(point.x, point.y, param2DropTargetEvent.x, param2DropTargetEvent.y, transferMode2);
/*      */               } 
/* 1343 */               param2DropTargetEvent.detail = FXCanvas.HostContainer.this.getDragAction(transferMode1);
/*      */             }
/*      */             public void drop(DropTargetEvent param2DropTargetEvent) {
/* 1346 */               this.detail = param2DropTargetEvent.detail;
/* 1347 */               this.operations = param2DropTargetEvent.operations;
/* 1348 */               this.data = param2DropTargetEvent.data;
/*      */               
/* 1350 */               this.currentTransferData = param2DropTargetEvent.currentDataType;
/* 1351 */               Point point = FXCanvas.this.toControl(param2DropTargetEvent.x, param2DropTargetEvent.y);
/* 1352 */               TransferMode transferMode1 = FXCanvas.HostContainer.this.getTransferMode(param2DropTargetEvent.detail);
/* 1353 */               TransferMode transferMode2 = fxDropTarget.handleDragDrop(point.x, point.y, param2DropTargetEvent.x, param2DropTargetEvent.y, transferMode1);
/* 1354 */               param2DropTargetEvent.detail = FXCanvas.HostContainer.this.getDragAction(transferMode2);
/* 1355 */               this.data = null;
/*      */               
/* 1357 */               this.currentTransferData = null;
/*      */             }
/*      */             public void dropAccept(DropTargetEvent param2DropTargetEvent) {
/* 1360 */               this.ignoreLeave = true;
/*      */             }
/*      */           });
/* 1363 */       return dropTarget;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setEmbeddedScene(EmbeddedSceneInterface param1EmbeddedSceneInterface) {
/* 1368 */       FXCanvas.this.scenePeer = param1EmbeddedSceneInterface;
/* 1369 */       if (FXCanvas.this.scenePeer == null) {
/*      */         return;
/*      */       }
/* 1372 */       if (FXCanvas.this.pWidth > 0 && FXCanvas.this.pHeight > 0) {
/* 1373 */         FXCanvas.this.scenePeer.setSize(FXCanvas.this.pWidth, FXCanvas.this.pHeight);
/*      */       }
/* 1375 */       double d = FXCanvas.this.getScaleFactor();
/* 1376 */       FXCanvas.this.resizePixelBuffer(d);
/* 1377 */       FXCanvas.this.lastScaleFactor = d;
/* 1378 */       FXCanvas.this.scenePeer.setPixelScaleFactors((float)d, (float)d);
/* 1379 */       FXCanvas.this.scenePeer.setDragStartListener((param1EmbeddedSceneDSInterface, param1TransferMode) -> Platform.runLater(()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1391 */       FXCanvas.this.setDropTarget((DropTarget)null);
/* 1392 */       FXCanvas.this.setDropTarget(createDropTarget(param1EmbeddedSceneInterface));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean requestFocus() {
/* 1397 */       Display.getDefault().asyncExec(() -> {
/*      */             if (FXCanvas.this.isDisposed())
/*      */               return;  FXCanvas.this.forceFocus();
/*      */           });
/* 1401 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean traverseFocusOut(boolean param1Boolean) {
/* 1407 */       return true;
/*      */     }
/*      */     
/* 1410 */     Object lock = new Object(); boolean queued = false;
/*      */     
/*      */     public void repaint() {
/* 1413 */       synchronized (this.lock) {
/* 1414 */         if (this.queued)
/* 1415 */           return;  this.queued = true;
/* 1416 */         Display.getDefault().asyncExec(() -> {
/*      */               try {
/*      */                 if (FXCanvas.this.isDisposed())
/*      */                   return; 
/*      */                 FXCanvas.this.redraw();
/*      */               } finally {
/*      */                 synchronized (this.lock) {
/*      */                   this.queued = false;
/*      */                 } 
/*      */               } 
/*      */             });
/*      */       } 
/*      */     }
/*      */     
/*      */     public void setPreferredSize(int param1Int1, int param1Int2) {
/* 1431 */       FXCanvas.this.pPreferredWidth = param1Int1;
/* 1432 */       FXCanvas.this.pPreferredHeight = param1Int2;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void setEnabled(boolean param1Boolean) {
/* 1438 */       FXCanvas.this.setEnabled(param1Boolean);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setCursor(CursorFrame param1CursorFrame) {
/* 1443 */       FXCanvas.this.setCursor(getPlatformCursor(param1CursorFrame));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Cursor getPlatformCursor(CursorFrame param1CursorFrame) {
/* 1453 */       if (param1CursorFrame.getCursorType() == CursorType.DEFAULT) {
/* 1454 */         return null;
/*      */       }
/*      */       
/* 1457 */       Cursor cursor1 = param1CursorFrame.<Cursor>getPlatformCursor(Cursor.class);
/* 1458 */       if (cursor1 != null)
/*      */       {
/* 1460 */         return cursor1;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1465 */       Cursor cursor2 = SWTCursors.embedCursorToCursor(param1CursorFrame);
/* 1466 */       param1CursorFrame.setPlatforCursor(Cursor.class, cursor2);
/*      */       
/* 1468 */       return cursor2;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean grabFocus() {
/* 1474 */       return true;
/*      */     }
/*      */     
/*      */     public void ungrabFocus() {}
/*      */     
/*      */     private HostContainer() {}
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx-swt.jar!\javafx\embed\swt\FXCanvas.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */