/*     */ package javafx.embed.swt;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SWTEvents
/*     */ {
/*     */   static int mouseButtonToEmbedMouseButton(int paramInt1, int paramInt2) {
/*  68 */     switch (paramInt1) { case 1:
/*  69 */         return 1;
/*  70 */       case 2: return 4;
/*  71 */       case 3: return 2; }
/*     */     
/*  73 */     return 0;
/*     */   }
/*     */   
/*     */   static double getWheelRotation(Event paramEvent) {
/*  77 */     int i = 1;
/*  78 */     if ("win32".equals(SWT.getPlatform()) && paramEvent.type == 37) {
/*  79 */       int[] arrayOfInt = new int[1];
/*     */ 
/*     */       
/*  82 */       try { Class<?> clazz = Class.forName("org.eclipse.swt.internal.win32.OS");
/*  83 */         Method method = clazz.getDeclaredMethod("SystemParametersInfo", new Class[] { int.class, int.class, int[].class, int.class });
/*  84 */         method.invoke(clazz, new Object[] { Integer.valueOf(104), Integer.valueOf(0), arrayOfInt, Integer.valueOf(0) }); }
/*  85 */       catch (IllegalAccessException illegalAccessException) {  }
/*  86 */       catch (InvocationTargetException invocationTargetException) {  }
/*  87 */       catch (NoSuchMethodException noSuchMethodException) {  }
/*  88 */       catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */       
/*  91 */       if (arrayOfInt[0] != -1) {
/*  92 */         i = arrayOfInt[0];
/*     */       }
/*  94 */     } else if ("gtk".equals(SWT.getPlatform())) {
/*  95 */       i = 3;
/*     */     }
/*  97 */     else if ("cocoa".equals(SWT.getPlatform())) {
/*  98 */       i = Math.abs(paramEvent.count);
/*     */     } 
/* 100 */     return paramEvent.count / Math.max(1, i);
/*     */   }
/*     */   
/*     */   static int keyIDToEmbedKeyType(int paramInt) {
/* 104 */     switch (paramInt) {
/*     */       case 1:
/* 106 */         return 0;
/*     */       case 2:
/* 108 */         return 1;
/*     */     } 
/*     */ 
/*     */     
/* 112 */     return 0;
/*     */   }
/*     */   
/* 115 */   static final int[][] KeyTable = new int[][] { { 0, 0 }, { 10, 13 }, { 10, 10 }, { 8, 8 }, { 9, 9 }, { 27, 27 }, { 32, 32 }, { 127, 127 }, { 155, 16777225 }, { 156, 16777297 }, { 16, 131072 }, { 17, 262144 }, { 18, 65536 }, { 524, 4194304 }, { 20, 16777298 }, { 144, 16777299 }, { 145, 16777300 }, { 33, 16777221 }, { 34, 16777222 }, { 35, 16777224 }, { 36, 16777223 }, { 37, 16777219 }, { 38, 16777217 }, { 39, 16777220 }, { 40, 16777218 }, { 44, 44 }, { 45, 45 }, { 46, 46 }, { 47, 47 }, { 59, 59 }, { 61, 61 }, { 91, 91 }, { 92, 92 }, { 93, 93 }, { 106, 16777258 }, { 107, 16777259 }, { 109, 16777261 }, { 110, 16777262 }, { 111, 16777263 }, { 150, 64 }, { 151, 42 }, { 152, 34 }, { 153, 60 }, { 160, 62 }, { 161, 123 }, { 162, 125 }, { 192, 96 }, { 222, 39 }, { 512, 64 }, { 513, 58 }, { 514, 94 }, { 515, 36 }, { 517, 33 }, { 519, 40 }, { 520, 35 }, { 521, 43 }, { 522, 41 }, { 523, 95 }, { 48, 48 }, { 49, 49 }, { 50, 50 }, { 51, 51 }, { 52, 52 }, { 53, 53 }, { 54, 54 }, { 55, 55 }, { 56, 56 }, { 57, 57 }, { 65, 97 }, { 66, 98 }, { 67, 99 }, { 68, 100 }, { 69, 101 }, { 70, 102 }, { 71, 103 }, { 72, 104 }, { 73, 105 }, { 74, 106 }, { 75, 107 }, { 76, 108 }, { 77, 109 }, { 78, 110 }, { 79, 111 }, { 80, 112 }, { 81, 113 }, { 82, 114 }, { 83, 115 }, { 84, 116 }, { 85, 117 }, { 86, 118 }, { 87, 119 }, { 88, 120 }, { 89, 121 }, { 90, 122 }, { 96, 16777264 }, { 97, 16777265 }, { 98, 16777266 }, { 99, 16777267 }, { 100, 16777268 }, { 101, 16777269 }, { 102, 16777270 }, { 103, 16777271 }, { 104, 16777272 }, { 105, 16777273 }, { 112, 16777226 }, { 113, 16777227 }, { 114, 16777228 }, { 115, 16777229 }, { 116, 16777230 }, { 117, 16777231 }, { 118, 16777232 }, { 119, 16777233 }, { 120, 16777234 }, { 121, 16777235 }, { 122, 16777236 }, { 123, 16777237 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int keyCodeToEmbedKeyCode(int paramInt) {
/* 281 */     for (byte b = 0; b < KeyTable.length; b++) {
/* 282 */       if (KeyTable[b][1] == paramInt) return KeyTable[b][0]; 
/*     */     } 
/* 284 */     return 0;
/*     */   }
/*     */   
/*     */   static int keyModifiersToEmbedKeyModifiers(int paramInt) {
/* 288 */     int i = 0;
/* 289 */     if ((paramInt & 0x20000) != 0) {
/* 290 */       i |= 0x1;
/*     */     }
/* 292 */     if ((paramInt & 0x40000) != 0) {
/* 293 */       i |= 0x2;
/*     */     }
/* 295 */     if ((paramInt & 0x10000) != 0) {
/* 296 */       i |= 0x4;
/*     */     }
/*     */     
/* 299 */     if ((paramInt & 0x400000) != 0) {
/* 300 */       i |= 0x8;
/*     */     }
/* 302 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx-swt.jar!\javafx\embed\swt\SWTEvents.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */