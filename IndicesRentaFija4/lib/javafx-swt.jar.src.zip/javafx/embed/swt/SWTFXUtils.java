/*     */ package javafx.embed.swt;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.security.AccessController;
/*     */ import javafx.scene.image.Image;
/*     */ import javafx.scene.image.PixelFormat;
/*     */ import javafx.scene.image.PixelReader;
/*     */ import javafx.scene.image.PixelWriter;
/*     */ import javafx.scene.image.WritableImage;
/*     */ import javafx.scene.image.WritablePixelFormat;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SWTFXUtils
/*     */ {
/*     */   private static int blitSrc;
/*     */   private static boolean blitSrcCache;
/*     */   private static int alphaOpaque;
/*     */   private static boolean alphaOpaqueCache;
/*     */   private static int msbFirst;
/*     */   private static boolean msbFirstCache;
/*     */   private static Method blitDirect;
/*     */   private static Method blitPalette;
/*     */   private static Method getByteOrderMethod;
/*     */   
/*     */   public static WritableImage toFXImage(ImageData paramImageData, WritableImage paramWritableImage) {
/*  80 */     byte[] arrayOfByte = convertImage(paramImageData);
/*  81 */     if (arrayOfByte == null) return null; 
/*  82 */     int i = paramImageData.width;
/*  83 */     int j = paramImageData.height;
/*  84 */     if (paramWritableImage != null) {
/*  85 */       int m = (int)paramWritableImage.getWidth();
/*  86 */       int n = (int)paramWritableImage.getHeight();
/*  87 */       if (m < i || n < j) {
/*  88 */         paramWritableImage = null;
/*  89 */       } else if (i < m || j < n) {
/*  90 */         int[] arrayOfInt = new int[m];
/*  91 */         PixelWriter pixelWriter1 = paramWritableImage.getPixelWriter();
/*  92 */         WritablePixelFormat<IntBuffer> writablePixelFormat1 = PixelFormat.getIntArgbPreInstance();
/*  93 */         if (i < m) {
/*  94 */           pixelWriter1.setPixels(i, 0, m - i, j, writablePixelFormat1, arrayOfInt, 0, 0);
/*     */         }
/*  96 */         if (j < n) {
/*  97 */           pixelWriter1.setPixels(0, j, m, n - j, writablePixelFormat1, arrayOfInt, 0, 0);
/*     */         }
/*     */       } 
/*     */     } 
/* 101 */     if (paramWritableImage == null) {
/* 102 */       paramWritableImage = new WritableImage(i, j);
/*     */     }
/* 104 */     PixelWriter pixelWriter = paramWritableImage.getPixelWriter();
/* 105 */     int k = i * 4;
/* 106 */     WritablePixelFormat<ByteBuffer> writablePixelFormat = PixelFormat.getByteBgraInstance();
/* 107 */     pixelWriter.setPixels(0, 0, i, j, writablePixelFormat, arrayOfByte, 0, k);
/* 108 */     return paramWritableImage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageData fromFXImage(Image paramImage, ImageData paramImageData) {
/* 139 */     PixelReader pixelReader = paramImage.getPixelReader();
/* 140 */     if (pixelReader == null) {
/* 141 */       return null;
/*     */     }
/* 143 */     int i = (int)paramImage.getWidth();
/* 144 */     int j = (int)paramImage.getHeight();
/* 145 */     int k = i * 4;
/* 146 */     int m = k * j;
/* 147 */     byte[] arrayOfByte1 = new byte[m];
/* 148 */     WritablePixelFormat<ByteBuffer> writablePixelFormat = PixelFormat.getByteBgraInstance();
/* 149 */     pixelReader.getPixels(0, 0, i, j, writablePixelFormat, arrayOfByte1, 0, k);
/* 150 */     byte[] arrayOfByte2 = new byte[i * j];
/* 151 */     for (byte b1 = 0, b2 = 0, b3 = 0; b1 < j; b1++) {
/* 152 */       for (byte b = 0; b < i; b++, b2 += 4) {
/* 153 */         byte b4 = arrayOfByte1[b2 + 3];
/* 154 */         arrayOfByte1[b2 + 3] = 0;
/* 155 */         arrayOfByte2[b3++] = b4;
/*     */       } 
/*     */     } 
/* 158 */     PaletteData paletteData = new PaletteData(65280, 16711680, -16777216);
/* 159 */     paramImageData = new ImageData(i, j, 32, paletteData, 4, arrayOfByte1);
/* 160 */     paramImageData.alphaData = arrayOfByte2;
/* 161 */     return paramImageData;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int BLIT_SRC() throws Exception {
/* 167 */     if (!blitSrcCache) {
/* 168 */       blitSrc = readValue("BLIT_SRC");
/* 169 */       blitSrcCache = true;
/*     */     } 
/* 171 */     return blitSrc;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int ALPHA_OPAQUE() throws Exception {
/* 177 */     if (!alphaOpaqueCache) {
/* 178 */       alphaOpaque = readValue("ALPHA_OPAQUE");
/* 179 */       alphaOpaqueCache = true;
/*     */     } 
/* 181 */     return alphaOpaque;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int MSB_FIRST() throws Exception {
/* 187 */     if (!msbFirstCache) {
/* 188 */       msbFirst = readValue("MSB_FIRST");
/* 189 */       msbFirstCache = true;
/*     */     } 
/* 191 */     return msbFirst;
/*     */   }
/*     */   
/*     */   private static int readValue(String paramString) throws Exception {
/* 195 */     Class<ImageData> clazz = ImageData.class;
/* 196 */     return ((Integer)AccessController.<Integer>doPrivileged(() -> { Field field = paramClass.getDeclaredField(paramString); field.setAccessible(true); return Integer.valueOf(field.getInt(paramClass)); })).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void blit(int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, byte[] paramArrayOfbyte2, int paramInt13, int paramInt14, int paramInt15, byte[] paramArrayOfbyte3, int paramInt16, int paramInt17, int paramInt18, int paramInt19, int paramInt20, int paramInt21, int paramInt22, int paramInt23, int paramInt24, int paramInt25, boolean paramBoolean1, boolean paramBoolean2) throws Exception {
/* 215 */     Class<ImageData> clazz = ImageData.class;
/* 216 */     if (blitDirect == null) {
/* 217 */       Class<int> clazz1 = int.class; Class<boolean> clazz2 = boolean.class; Class<byte[]> clazz3 = byte[].class;
/* 218 */       Class[] arrayOfClass = { clazz1, clazz3, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz3, clazz1, clazz1, clazz1, clazz3, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz2, clazz2 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 226 */       blitDirect = AccessController.<Method>doPrivileged(() -> {
/*     */             Method method = paramClass.getDeclaredMethod("blit", paramArrayOfClass);
/*     */             
/*     */             method.setAccessible(true);
/*     */             
/*     */             return method;
/*     */           });
/*     */     } 
/* 234 */     if (blitDirect != null) {
/* 235 */       blitDirect.invoke(clazz, new Object[] { Integer.valueOf(paramInt1), paramArrayOfbyte1, 
/* 236 */             Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4), 
/* 237 */             Integer.valueOf(paramInt5), Integer.valueOf(paramInt6), Integer.valueOf(paramInt7), Integer.valueOf(paramInt8), 
/* 238 */             Integer.valueOf(paramInt9), Integer.valueOf(paramInt10), Integer.valueOf(paramInt11), 
/* 239 */             Integer.valueOf(paramInt12), paramArrayOfbyte2, Integer.valueOf(paramInt13), Integer.valueOf(paramInt14), Integer.valueOf(paramInt15), paramArrayOfbyte3, 
/* 240 */             Integer.valueOf(paramInt16), Integer.valueOf(paramInt17), Integer.valueOf(paramInt18), 
/* 241 */             Integer.valueOf(paramInt19), Integer.valueOf(paramInt20), Integer.valueOf(paramInt21), Integer.valueOf(paramInt22), 
/* 242 */             Integer.valueOf(paramInt23), Integer.valueOf(paramInt24), Integer.valueOf(paramInt25), 
/* 243 */             Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void blit(int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4, int paramInt9, byte[] paramArrayOfbyte5, int paramInt10, int paramInt11, int paramInt12, byte[] paramArrayOfbyte6, int paramInt13, int paramInt14, int paramInt15, int paramInt16, int paramInt17, int paramInt18, int paramInt19, int paramInt20, int paramInt21, int paramInt22, boolean paramBoolean1, boolean paramBoolean2) throws Exception {
/* 258 */     Class<ImageData> clazz = ImageData.class;
/* 259 */     if (blitPalette == null) {
/* 260 */       Class<int> clazz1 = int.class; Class<boolean> clazz2 = boolean.class; Class<byte[]> clazz3 = byte[].class;
/* 261 */       Class[] arrayOfClass = { clazz1, clazz3, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz3, clazz3, clazz3, clazz1, clazz3, clazz1, clazz1, clazz1, clazz3, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz1, clazz2, clazz2 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 269 */       blitPalette = AccessController.<Method>doPrivileged(() -> {
/*     */             Method method = paramClass.getDeclaredMethod("blit", paramArrayOfClass);
/*     */             
/*     */             method.setAccessible(true);
/*     */             
/*     */             return method;
/*     */           });
/*     */     } 
/* 277 */     if (blitPalette != null) {
/* 278 */       blitPalette.invoke(clazz, new Object[] { Integer.valueOf(paramInt1), paramArrayOfbyte1, 
/* 279 */             Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4), 
/* 280 */             Integer.valueOf(paramInt5), Integer.valueOf(paramInt6), Integer.valueOf(paramInt7), Integer.valueOf(paramInt8), paramArrayOfbyte2, paramArrayOfbyte3, paramArrayOfbyte4, 
/*     */             
/* 282 */             Integer.valueOf(paramInt9), paramArrayOfbyte5, Integer.valueOf(paramInt10), Integer.valueOf(paramInt11), Integer.valueOf(paramInt12), paramArrayOfbyte6, 
/* 283 */             Integer.valueOf(paramInt13), Integer.valueOf(paramInt14), Integer.valueOf(paramInt15), 
/* 284 */             Integer.valueOf(paramInt16), Integer.valueOf(paramInt17), Integer.valueOf(paramInt18), Integer.valueOf(paramInt19), 
/* 285 */             Integer.valueOf(paramInt20), Integer.valueOf(paramInt21), Integer.valueOf(paramInt22), 
/* 286 */             Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static int getByteOrder(ImageData paramImageData) throws Exception {
/* 292 */     Class<ImageData> clazz = ImageData.class;
/* 293 */     if (getByteOrderMethod != null) {
/* 294 */       getByteOrderMethod = AccessController.<Method>doPrivileged(() -> {
/*     */             Method method = paramClass.getDeclaredMethod("getByteOrder", new Class[0]);
/*     */             
/*     */             method.setAccessible(true);
/*     */             return method;
/*     */           });
/*     */     }
/* 301 */     if (getByteOrderMethod != null) {
/* 302 */       return ((Integer)getByteOrderMethod.invoke(paramImageData, new Object[0])).intValue();
/*     */     }
/* 304 */     return MSB_FIRST();
/*     */   }
/*     */   
/*     */   private static byte[] convertImage(ImageData paramImageData) {
/* 308 */     byte[] arrayOfByte = null;
/*     */     try {
/* 310 */       PaletteData paletteData = paramImageData.palette;
/* 311 */       if (((paramImageData.depth != 1 && paramImageData.depth != 2 && paramImageData.depth != 4 && paramImageData.depth != 8) || paletteData.isDirect) && paramImageData.depth != 8 && ((paramImageData.depth != 16 && paramImageData.depth != 24 && paramImageData.depth != 32) || !paletteData.isDirect))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 317 */         return null;
/*     */       }
/*     */       
/* 320 */       int i = BLIT_SRC();
/* 321 */       int j = ALPHA_OPAQUE();
/* 322 */       int k = MSB_FIRST();
/*     */       
/* 324 */       int m = paramImageData.width;
/* 325 */       int n = paramImageData.height;
/* 326 */       int i1 = getByteOrder(paramImageData);
/* 327 */       byte b = 3;
/* 328 */       char c = '＀';
/* 329 */       int i2 = 16711680;
/* 330 */       int i3 = -16777216;
/* 331 */       int i4 = m * n * 4;
/* 332 */       int i5 = m * 4;
/* 333 */       arrayOfByte = new byte[i4];
/*     */       
/* 335 */       if (paletteData.isDirect) {
/* 336 */         blit(i, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, i1, 0, 0, m, n, paletteData.redMask, paletteData.greenMask, paletteData.blueMask, j, (byte[])null, 0, 0, 0, arrayOfByte, 32, i5, k, 0, 0, m, n, c, i2, i3, false, false);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 345 */         RGB[] arrayOfRGB = paletteData.getRGBs();
/* 346 */         int i7 = arrayOfRGB.length;
/* 347 */         byte[] arrayOfByte1 = new byte[i7];
/* 348 */         byte[] arrayOfByte2 = new byte[i7];
/* 349 */         byte[] arrayOfByte3 = new byte[i7];
/* 350 */         for (byte b1 = 0; b1 < arrayOfRGB.length; b1++) {
/* 351 */           RGB rGB = arrayOfRGB[b1];
/* 352 */           if (rGB != null) {
/* 353 */             arrayOfByte1[b1] = (byte)rGB.red;
/* 354 */             arrayOfByte2[b1] = (byte)rGB.green;
/* 355 */             arrayOfByte3[b1] = (byte)rGB.blue;
/*     */           } 
/* 357 */         }  blit(i, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, i1, 0, 0, m, n, arrayOfByte1, arrayOfByte2, arrayOfByte3, j, (byte[])null, 0, 0, 0, arrayOfByte, 32, i5, k, 0, 0, m, n, c, i2, i3, false, false);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 367 */       int i6 = paramImageData.getTransparencyType();
/* 368 */       boolean bool = (i6 != 0) ? true : false;
/* 369 */       if (i6 == 2 || paramImageData.transparentPixel != -1) {
/*     */         
/* 371 */         ImageData imageData = paramImageData.getTransparencyMask();
/* 372 */         byte[] arrayOfByte1 = imageData.data;
/* 373 */         int i7 = imageData.bytesPerLine;
/* 374 */         byte b1 = 0; int i8 = 0;
/* 375 */         for (byte b2 = 0; b2 < n; b2++) {
/* 376 */           for (byte b3 = 0; b3 < m; b3++) {
/* 377 */             byte b4 = arrayOfByte1[i8 + (b3 >> 3)];
/* 378 */             int i9 = 1 << 7 - (b3 & 0x7);
/* 379 */             arrayOfByte[b1 + b] = ((b4 & i9) != 0) ? -1 : 0;
/* 380 */             b1 += 4;
/*     */           } 
/* 382 */           i8 += i7;
/*     */         }
/*     */       
/* 385 */       } else if (paramImageData.alpha != -1) {
/* 386 */         bool = true;
/* 387 */         int i7 = paramImageData.alpha;
/* 388 */         byte b1 = (byte)i7;
/* 389 */         for (byte b2 = 0; b2 < arrayOfByte.length; b2 += 4) {
/* 390 */           arrayOfByte[b2 + b] = b1;
/*     */         }
/* 392 */       } else if (paramImageData.alphaData != null) {
/* 393 */         bool = true;
/* 394 */         byte[] arrayOfByte1 = new byte[paramImageData.alphaData.length];
/* 395 */         System.arraycopy(paramImageData.alphaData, 0, arrayOfByte1, 0, arrayOfByte1.length);
/*     */         
/* 397 */         byte b1 = 0, b2 = 0;
/* 398 */         for (byte b3 = 0; b3 < n; b3++) {
/* 399 */           for (byte b4 = 0; b4 < m; b4++) {
/* 400 */             arrayOfByte[b1 + b] = arrayOfByte1[b2];
/* 401 */             b1 += 4;
/* 402 */             b2++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 407 */       if (!bool) {
/* 408 */         for (byte b1 = 0; b1 < arrayOfByte.length; b1 += 4) {
/* 409 */           arrayOfByte[b1 + b] = -1;
/*     */         }
/*     */       }
/* 412 */     } catch (Exception exception) {
/* 413 */       return null;
/*     */     } 
/* 415 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx-swt.jar!\javafx\embed\swt\SWTFXUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */