/*    */ package javafx.embed.swt;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import javafx.beans.NamedArg;
/*    */ import org.eclipse.swt.dnd.ByteArrayTransfer;
/*    */ import org.eclipse.swt.dnd.DND;
/*    */ import org.eclipse.swt.dnd.TransferData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CustomTransfer
/*    */   extends ByteArrayTransfer
/*    */ {
/*    */   private String name;
/*    */   private String mime;
/*    */   
/*    */   public CustomTransfer(@NamedArg("name") String paramString1, @NamedArg("mime") String paramString2) {
/* 39 */     this.name = paramString1;
/* 40 */     this.mime = paramString2;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 44 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getMime() {
/* 48 */     return this.mime;
/*    */   }
/*    */   
/*    */   public void javaToNative(Object paramObject, TransferData paramTransferData) {
/* 52 */     if (!checkCustom(paramObject) || !isSupportedType(paramTransferData)) {
/* 53 */       DND.error(2003);
/*    */     }
/* 55 */     byte[] arrayOfByte = null;
/* 56 */     if (paramObject instanceof ByteBuffer)
/* 57 */     { arrayOfByte = ((ByteBuffer)paramObject).array(); }
/*    */     
/* 59 */     else if (paramObject instanceof byte[]) { arrayOfByte = (byte[])paramObject; }
/*    */     
/* 61 */     if (arrayOfByte == null) DND.error(2003); 
/* 62 */     super.javaToNative(arrayOfByte, paramTransferData);
/*    */   }
/*    */   
/*    */   public Object nativeToJava(TransferData paramTransferData) {
/* 66 */     if (isSupportedType(paramTransferData)) {
/* 67 */       return super.nativeToJava(paramTransferData);
/*    */     }
/* 69 */     return null;
/*    */   }
/*    */   
/*    */   protected String[] getTypeNames() {
/* 73 */     return new String[] { this.name };
/*    */   }
/*    */   
/*    */   protected int[] getTypeIds() {
/* 77 */     return new int[] { registerType(this.name) };
/*    */   }
/*    */   
/*    */   boolean checkByteArray(Object paramObject) {
/* 81 */     return (paramObject != null && paramObject instanceof byte[] && ((byte[])paramObject).length > 0);
/*    */   }
/*    */   
/*    */   boolean checkByteBuffer(Object paramObject) {
/* 85 */     return (paramObject != null && paramObject instanceof ByteBuffer && ((ByteBuffer)paramObject).limit() > 0);
/*    */   }
/*    */   
/*    */   boolean checkCustom(Object paramObject) {
/* 89 */     return (checkByteArray(paramObject) || checkByteBuffer(paramObject));
/*    */   }
/*    */   
/*    */   protected boolean validate(Object paramObject) {
/* 93 */     return checkCustom(paramObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx-swt.jar!\javafx\embed\swt\CustomTransfer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */