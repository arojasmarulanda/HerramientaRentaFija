/*    */ package javafx.embed.swt;
/*    */ 
/*    */ import com.sun.javafx.cursor.CursorFrame;
/*    */ import com.sun.javafx.cursor.CursorType;
/*    */ import com.sun.javafx.cursor.ImageCursorFrame;
/*    */ import com.sun.javafx.tk.Toolkit;
/*    */ import javafx.scene.image.Image;
/*    */ import org.eclipse.swt.graphics.Cursor;
/*    */ import org.eclipse.swt.graphics.Device;
/*    */ import org.eclipse.swt.graphics.ImageData;
/*    */ import org.eclipse.swt.widgets.Display;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SWTCursors
/*    */ {
/*    */   private static Cursor createCustomCursor(Display paramDisplay, ImageCursorFrame paramImageCursorFrame) {
/* 47 */     Image image = Toolkit.getImageAccessor().fromPlatformImage(paramImageCursorFrame.getPlatformImage());
/* 48 */     ImageData imageData = SWTFXUtils.fromFXImage(image, null);
/* 49 */     return new Cursor((Device)paramDisplay, imageData, 
/* 50 */         (int)paramImageCursorFrame.getHotspotX(), (int)paramImageCursorFrame.getHotspotY());
/*    */   }
/*    */   
/*    */   static Cursor embedCursorToCursor(CursorFrame paramCursorFrame) {
/* 54 */     Display display = Display.getCurrent();
/*    */     
/* 56 */     if (display == null) {
/* 57 */       return null;
/*    */     }
/*    */     
/* 60 */     byte b = 0;
/* 61 */     switch (paramCursorFrame.getCursorType()) { case DEFAULT:
/* 62 */         b = 0; break;
/* 63 */       case CROSSHAIR: b = 2; break;
/* 64 */       case TEXT: b = 19; break;
/* 65 */       case WAIT: b = 1; break;
/* 66 */       case SW_RESIZE: b = 16; break;
/* 67 */       case SE_RESIZE: b = 15; break;
/* 68 */       case NW_RESIZE: b = 17; break;
/* 69 */       case NE_RESIZE: b = 14; break;
/* 70 */       case N_RESIZE: b = 10; break;
/* 71 */       case S_RESIZE: b = 11; break;
/* 72 */       case W_RESIZE: b = 13; break;
/* 73 */       case E_RESIZE: b = 12; break;
/*    */       case OPEN_HAND: case CLOSED_HAND:
/*    */       case HAND:
/* 76 */         b = 21; break;
/* 77 */       case MOVE: b = 5;
/*    */         break;
/*    */       
/*    */       case H_RESIZE:
/* 81 */         b = 9; break;
/* 82 */       case V_RESIZE: b = 7;
/*    */         break;
/*    */       case NONE:
/* 85 */         return null;
/*    */       case IMAGE:
/* 87 */         return createCustomCursor(display, (ImageCursorFrame)paramCursorFrame); }
/*    */     
/* 89 */     return display.getSystemCursor(b);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx-swt.jar!\javafx\embed\swt\SWTCursors.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */