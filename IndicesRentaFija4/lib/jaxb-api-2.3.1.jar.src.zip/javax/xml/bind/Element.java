package javax.xml.bind;

public interface Element {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\jaxb-api-2.3.1.jar!\javax\xml\bind\Element.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */