package javax.xml.bind;

import org.xml.sax.ContentHandler;

public interface UnmarshallerHandler extends ContentHandler {
  Object getResult() throws JAXBException, IllegalStateException;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\jaxb-api-2.3.1.jar!\javax\xml\bind\UnmarshallerHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */