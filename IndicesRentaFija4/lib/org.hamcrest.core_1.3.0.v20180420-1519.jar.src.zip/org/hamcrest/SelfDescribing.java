package org.hamcrest;

public interface SelfDescribing {
  void describeTo(Description paramDescription);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.hamcrest.core_1.3.0.v20180420-1519.jar!\org\hamcrest\SelfDescribing.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */