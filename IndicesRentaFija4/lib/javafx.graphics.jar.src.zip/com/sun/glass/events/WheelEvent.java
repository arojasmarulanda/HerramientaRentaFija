package com.sun.glass.events;

public class WheelEvent {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glass\events\WheelEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */