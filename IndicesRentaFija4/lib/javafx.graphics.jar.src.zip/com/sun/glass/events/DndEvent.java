package com.sun.glass.events;

public class DndEvent {
  public static final int ENTER = 611;
  
  public static final int UPDATE = 612;
  
  public static final int PERFORM = 613;
  
  public static final int EXIT = 614;
  
  public static final int END = 615;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glass\events\DndEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */