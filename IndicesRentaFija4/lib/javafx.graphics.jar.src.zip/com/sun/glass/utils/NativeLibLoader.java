/*     */ package com.sun.glass.utils;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.security.AccessController;
/*     */ import java.security.DigestInputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeLibLoader
/*     */ {
/*  45 */   private static final HashSet<String> loaded = new HashSet<>();
/*     */   
/*     */   public static synchronized void loadLibrary(String paramString) {
/*  48 */     if (!loaded.contains(paramString)) {
/*  49 */       StackWalker stackWalker = AccessController.<StackWalker>doPrivileged(() -> StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE));
/*     */       
/*  51 */       Class clazz = stackWalker.getCallerClass();
/*  52 */       loadLibraryInternal(paramString, null, clazz);
/*  53 */       loaded.add(paramString);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static synchronized void loadLibrary(String paramString, List<String> paramList) {
/*  58 */     if (!loaded.contains(paramString)) {
/*  59 */       StackWalker stackWalker = AccessController.<StackWalker>doPrivileged(() -> StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE));
/*     */       
/*  61 */       Class clazz = stackWalker.getCallerClass();
/*  62 */       loadLibraryInternal(paramString, paramList, clazz);
/*  63 */       loaded.add(paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean verbose = false;
/*     */   private static boolean usingModules = false;
/*  70 */   private static File libDir = null;
/*  71 */   private static String libPrefix = "";
/*  72 */   private static String libSuffix = "";
/*     */   
/*     */   static {
/*  75 */     AccessController.doPrivileged(() -> {
/*     */           verbose = Boolean.getBoolean("javafx.verbose");
/*     */           return null;
/*     */         });
/*     */   }
/*     */   
/*     */   private static String[] initializePath(String paramString) {
/*  82 */     String str1 = System.getProperty(paramString, "");
/*  83 */     String str2 = File.pathSeparator;
/*  84 */     int i = str1.length();
/*     */ 
/*     */     
/*  87 */     int j = str1.indexOf(str2);
/*  88 */     int m = 0;
/*  89 */     while (j >= 0) {
/*  90 */       m++;
/*  91 */       j = str1.indexOf(str2, j + 1);
/*     */     } 
/*     */ 
/*     */     
/*  95 */     String[] arrayOfString = new String[m + 1];
/*     */ 
/*     */     
/*  98 */     m = j = 0;
/*  99 */     int k = str1.indexOf(str2);
/* 100 */     while (k >= 0) {
/* 101 */       if (k - j > 0) {
/* 102 */         arrayOfString[m++] = str1.substring(j, k);
/* 103 */       } else if (k - j == 0) {
/* 104 */         arrayOfString[m++] = ".";
/*     */       } 
/* 106 */       j = k + 1;
/* 107 */       k = str1.indexOf(str2, j);
/*     */     } 
/* 109 */     arrayOfString[m] = str1.substring(j, i);
/* 110 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void loadLibraryInternal(String paramString, List<String> paramList, Class paramClass) {
/*     */     try {
/* 120 */       loadLibraryFullPath(paramString);
/* 121 */     } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/* 122 */       if (verbose && !usingModules) {
/* 123 */         System.err.println("WARNING: " + unsatisfiedLinkError);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 130 */       String[] arrayOfString = initializePath("java.library.path");
/* 131 */       for (byte b = 0; b < arrayOfString.length; b++) {
/*     */         try {
/* 133 */           String str1 = arrayOfString[b];
/* 134 */           if (!str1.endsWith(File.separator)) str1 = str1 + str1; 
/* 135 */           String str2 = System.mapLibraryName(paramString);
/* 136 */           File file = new File(str1 + str1);
/* 137 */           System.load(file.getAbsolutePath());
/* 138 */           if (verbose) {
/* 139 */             System.err.println("Loaded " + file.getAbsolutePath() + " from java.library.path");
/*     */           }
/*     */           
/*     */           return;
/* 143 */         } catch (UnsatisfiedLinkError unsatisfiedLinkError1) {}
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 150 */         System.loadLibrary(paramString);
/* 151 */         if (verbose) {
/* 152 */           System.err.println("System.loadLibrary(" + paramString + ") succeeded");
/*     */         }
/*     */       }
/* 155 */       catch (UnsatisfiedLinkError unsatisfiedLinkError1) {
/*     */         
/* 157 */         if (loadLibraryFromResource(paramString, paramList, paramClass)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 164 */         if ("iOS".equals(System.getProperty("os.name")) && paramString
/* 165 */           .contains("-")) {
/* 166 */           paramString = paramString.replace("-", "_");
/*     */           try {
/* 168 */             System.loadLibrary(paramString);
/*     */             return;
/* 170 */           } catch (UnsatisfiedLinkError unsatisfiedLinkError2) {
/* 171 */             throw unsatisfiedLinkError2;
/*     */           } 
/*     */         } 
/*     */         
/* 175 */         throw unsatisfiedLinkError1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean loadLibraryFromResource(String paramString, List<String> paramList, Class paramClass) {
/* 185 */     return installLibraryFromResource(paramString, paramList, paramClass, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean installLibraryFromResource(String paramString, List<String> paramList, Class paramClass, boolean paramBoolean) {
/*     */     try {
/* 195 */       if (paramList != null) {
/* 196 */         for (String str1 : paramList) {
/* 197 */           boolean bool = installLibraryFromResource(str1, null, paramClass, false);
/*     */         }
/*     */       }
/* 200 */       String str = "/" + System.mapLibraryName(paramString);
/* 201 */       InputStream inputStream = paramClass.getResourceAsStream(str);
/* 202 */       if (inputStream != null) {
/* 203 */         String str1 = cacheLibrary(inputStream, str, paramClass);
/* 204 */         if (paramBoolean) {
/* 205 */           System.load(str1);
/* 206 */           if (verbose) {
/* 207 */             System.err.println("Loaded library " + str + " from resource");
/*     */           }
/* 209 */         } else if (verbose) {
/* 210 */           System.err.println("Unpacked library " + str + " from resource");
/*     */         } 
/* 212 */         return true;
/*     */       } 
/* 214 */     } catch (Throwable throwable) {
/*     */ 
/*     */       
/* 217 */       System.err.println("Loading library " + paramString + " from resource failed: " + throwable);
/* 218 */       throwable.printStackTrace();
/*     */     } 
/* 220 */     return false;
/*     */   }
/*     */   
/*     */   private static String cacheLibrary(InputStream paramInputStream, String paramString, Class paramClass) throws IOException {
/* 224 */     String str1 = System.getProperty("javafx.version", "versionless");
/* 225 */     String str2 = System.getProperty("user.home") + "/.openjfx/cache/" + System.getProperty("user.home");
/* 226 */     File file1 = new File(str2);
/* 227 */     if (file1.exists()) {
/* 228 */       if (!file1.isDirectory()) {
/* 229 */         throw new IOException("Cache exists but is not a directory: " + file1);
/*     */       }
/*     */     }
/* 232 */     else if (!file1.mkdirs()) {
/* 233 */       throw new IOException("Can not create cache at " + file1);
/*     */     } 
/*     */ 
/*     */     
/* 237 */     File file2 = new File(file1, paramString);
/*     */     
/* 239 */     boolean bool = true;
/* 240 */     if (file2.exists()) {
/*     */       byte[] arrayOfByte1;
/*     */       
/*     */       try {
/* 244 */         DigestInputStream digestInputStream = new DigestInputStream(paramInputStream, MessageDigest.getInstance("MD5"));
/* 245 */         digestInputStream.getMessageDigest().reset();
/* 246 */         byte[] arrayOfByte = new byte[4096];
/* 247 */         while (digestInputStream.read(arrayOfByte) != -1);
/* 248 */         arrayOfByte1 = digestInputStream.getMessageDigest().digest();
/* 249 */         paramInputStream.close();
/* 250 */         paramInputStream = paramClass.getResourceAsStream(paramString);
/*     */       }
/* 252 */       catch (NoSuchAlgorithmException noSuchAlgorithmException) {
/* 253 */         arrayOfByte1 = new byte[1];
/*     */       } 
/* 255 */       byte[] arrayOfByte2 = calculateCheckSum(file2);
/* 256 */       if (!Arrays.equals(arrayOfByte1, arrayOfByte2)) {
/* 257 */         Files.delete(file2.toPath());
/*     */       } else {
/*     */         
/* 260 */         bool = false;
/*     */       } 
/*     */     } 
/* 263 */     if (bool) {
/* 264 */       Path path = file2.toPath();
/* 265 */       Files.copy(paramInputStream, path, new java.nio.file.CopyOption[0]);
/*     */     } 
/*     */     
/* 268 */     return file2.getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] calculateCheckSum(File paramFile) {
/*     */     try {
/* 275 */       FileInputStream fileInputStream = new FileInputStream(paramFile); 
/* 276 */       try { DigestInputStream digestInputStream = new DigestInputStream(fileInputStream, MessageDigest.getInstance("MD5")); 
/* 277 */         try { digestInputStream.getMessageDigest().reset();
/* 278 */           byte[] arrayOfByte1 = new byte[4096];
/* 279 */           while (digestInputStream.read(arrayOfByte1) != -1);
/* 280 */           byte[] arrayOfByte2 = digestInputStream.getMessageDigest().digest();
/* 281 */           digestInputStream.close(); fileInputStream.close(); return arrayOfByte2; } catch (Throwable throwable) { try { digestInputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Throwable throwable) { try { fileInputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*     */     
/* 283 */     } catch (IllegalArgumentException|NoSuchAlgorithmException|IOException|SecurityException illegalArgumentException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 289 */       return new byte[0];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void loadLibraryFullPath(String paramString) {
/*     */     try {
/* 299 */       if (usingModules) {
/* 300 */         throw new UnsatisfiedLinkError("ignored");
/*     */       }
/* 302 */       if (libDir == null) {
/*     */ 
/*     */         
/* 305 */         String str1 = "NativeLibLoader.class";
/* 306 */         Class<NativeLibLoader> clazz = NativeLibLoader.class;
/* 307 */         String str2 = clazz.getResource(str1).toString();
/* 308 */         if (str2.startsWith("jrt:")) {
/*     */           
/* 310 */           usingModules = true;
/* 311 */           throw new UnsatisfiedLinkError("ignored");
/*     */         } 
/* 313 */         if (!str2.startsWith("jar:file:") || str2.indexOf('!') == -1) {
/* 314 */           throw new UnsatisfiedLinkError("Invalid URL for class: " + str2);
/*     */         }
/*     */         
/* 317 */         String str3 = str2.substring(4, str2.lastIndexOf('!'));
/*     */         
/* 319 */         int i = Math.max(str3.lastIndexOf('/'), str3.lastIndexOf('\\'));
/*     */ 
/*     */         
/* 322 */         String str4 = System.getProperty("os.name");
/* 323 */         String str5 = null;
/* 324 */         if (str4.startsWith("Windows")) {
/* 325 */           str5 = "../bin";
/* 326 */         } else if (str4.startsWith("Mac")) {
/* 327 */           str5 = ".";
/* 328 */         } else if (str4.startsWith("Linux")) {
/* 329 */           str5 = ".";
/*     */         } 
/*     */ 
/*     */         
/* 333 */         String str6 = str3.substring(0, i) + "/" + str3.substring(0, i);
/*     */         
/* 335 */         libDir = new File((new URI(str6)).getPath());
/*     */ 
/*     */         
/* 338 */         if (str4.startsWith("Windows")) {
/* 339 */           libPrefix = "";
/* 340 */           libSuffix = ".dll";
/* 341 */         } else if (str4.startsWith("Mac")) {
/* 342 */           libPrefix = "lib";
/* 343 */           libSuffix = ".dylib";
/* 344 */         } else if (str4.startsWith("Linux")) {
/* 345 */           libPrefix = "lib";
/* 346 */           libSuffix = ".so";
/*     */         } 
/*     */       } 
/*     */       
/* 350 */       File file = new File(libDir, libPrefix + libPrefix + paramString);
/* 351 */       String str = file.getCanonicalPath();
/*     */       try {
/* 353 */         System.load(str);
/* 354 */         if (verbose) {
/* 355 */           System.err.println("Loaded " + file.getAbsolutePath() + " from relative path");
/*     */         }
/*     */       }
/* 358 */       catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/* 359 */         throw unsatisfiedLinkError;
/*     */       } 
/* 361 */     } catch (Exception exception) {
/*     */       
/* 363 */       throw (UnsatisfiedLinkError)(new UnsatisfiedLinkError()).initCause(exception);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\utils\NativeLibLoader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */