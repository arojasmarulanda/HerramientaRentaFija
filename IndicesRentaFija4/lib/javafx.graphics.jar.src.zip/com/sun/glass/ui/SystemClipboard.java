/*    */ package com.sun.glass.ui;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SystemClipboard
/*    */   extends Clipboard
/*    */ {
/*    */   protected SystemClipboard(String paramString) {
/* 31 */     super(paramString);
/* 32 */     Application.checkEventThread();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract boolean isOwner();
/*    */ 
/*    */   
/*    */   protected abstract void pushToSystem(HashMap<String, Object> paramHashMap, int paramInt);
/*    */ 
/*    */   
/*    */   protected abstract void pushTargetActionToSystem(int paramInt);
/*    */ 
/*    */   
/*    */   public void flush(ClipboardAssistance paramClipboardAssistance, HashMap<String, Object> paramHashMap, int paramInt) {
/* 47 */     Application.checkEventThread();
/*    */ 
/*    */     
/* 50 */     setSharedData(paramClipboardAssistance, paramHashMap, paramInt);
/* 51 */     pushToSystem(paramHashMap, paramInt);
/*    */   } protected abstract Object popFromSystem(String paramString); protected abstract int supportedSourceActionsFromSystem();
/*    */   protected abstract String[] mimesFromSystem();
/*    */   public int getSupportedSourceActions() {
/* 55 */     Application.checkEventThread();
/* 56 */     if (isOwner()) {
/* 57 */       return super.getSupportedSourceActions();
/*    */     }
/* 59 */     return supportedSourceActionsFromSystem();
/*    */   }
/*    */   
/*    */   public void setTargetAction(int paramInt) {
/* 63 */     Application.checkEventThread();
/* 64 */     pushTargetActionToSystem(paramInt);
/*    */   }
/*    */   
/*    */   public Object getLocalData(String paramString) {
/* 68 */     return super.getData(paramString);
/*    */   }
/*    */   
/*    */   public Object getData(String paramString) {
/* 72 */     Application.checkEventThread();
/* 73 */     if (isOwner()) {
/* 74 */       return getLocalData(paramString);
/*    */     }
/* 76 */     return popFromSystem(paramString);
/*    */   }
/*    */   
/*    */   public String[] getMimeTypes() {
/* 80 */     Application.checkEventThread();
/* 81 */     if (isOwner()) {
/* 82 */       return super.getMimeTypes();
/*    */     }
/* 84 */     return mimesFromSystem();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 88 */     Application.checkEventThread();
/* 89 */     return "System Clipboard";
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\SystemClipboard.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */