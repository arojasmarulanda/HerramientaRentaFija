/*    */ package com.sun.glass.ui;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Platform
/*    */ {
/*    */   public static final String MAC = "Mac";
/*    */   public static final String WINDOWS = "Win";
/*    */   public static final String GTK = "Gtk";
/*    */   public static final String IOS = "Ios";
/*    */   public static final String UNKNOWN = "unknown";
/* 39 */   private static String type = null;
/*    */   
/*    */   public static synchronized String determinePlatform() {
/* 42 */     if (type == null) {
/*    */ 
/*    */ 
/*    */       
/* 46 */       String str1 = AccessController.<String>doPrivileged(() -> System.getProperty("glass.platform"));
/*    */       
/* 48 */       if (str1 != null) {
/* 49 */         if (str1.equals("macosx")) {
/* 50 */           type = "Mac";
/* 51 */         } else if (str1.equals("windows")) {
/* 52 */           type = "Win";
/* 53 */         } else if (str1.equals("linux")) {
/* 54 */           type = "Gtk";
/* 55 */         } else if (str1.equals("gtk")) {
/* 56 */           type = "Gtk";
/* 57 */         } else if (str1.equals("ios")) {
/* 58 */           type = "Ios";
/*    */         } else {
/* 60 */           type = str1;
/* 61 */         }  return type;
/*    */       } 
/*    */       
/* 64 */       String str2 = System.getProperty("os.name");
/* 65 */       String str3 = str2.toLowerCase(Locale.ROOT);
/* 66 */       if (str3.startsWith("mac") || str3.startsWith("darwin")) {
/* 67 */         type = "Mac";
/* 68 */       } else if (str3.startsWith("wind")) {
/* 69 */         type = "Win";
/* 70 */       } else if (str3.startsWith("linux")) {
/* 71 */         type = "Gtk";
/*    */       } 
/*    */     } 
/*    */     
/* 75 */     return type;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\Platform.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */