/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.Objects;
/*     */ import javafx.scene.image.PixelWriter;
/*     */ import javafx.scene.image.WritableImage;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.stage.Screen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GlassRobot
/*     */ {
/*     */   public static final int MOUSE_LEFT_BTN = 1;
/*     */   public static final int MOUSE_RIGHT_BTN = 2;
/*     */   public static final int MOUSE_MIDDLE_BTN = 4;
/*     */   
/*     */   public abstract void create();
/*     */   
/*     */   public abstract void destroy();
/*     */   
/*     */   public abstract void keyPress(KeyCode paramKeyCode);
/*     */   
/*     */   public abstract void keyRelease(KeyCode paramKeyCode);
/*     */   
/*     */   public abstract double getMouseX();
/*     */   
/*     */   public abstract double getMouseY();
/*     */   
/*     */   public abstract void mouseMove(double paramDouble1, double paramDouble2);
/*     */   
/*     */   public abstract void mousePress(MouseButton... paramVarArgs);
/*     */   
/*     */   public abstract void mouseRelease(MouseButton... paramVarArgs);
/*     */   
/*     */   public abstract void mouseWheel(int paramInt);
/*     */   
/*     */   public abstract Color getPixelColor(double paramDouble1, double paramDouble2);
/*     */   
/*     */   public void getScreenCapture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, boolean paramBoolean) {
/* 154 */     throw new InternalError("not implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableImage getScreenCapture(WritableImage paramWritableImage, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) {
/*     */     int arrayOfInt[], i, j;
/* 185 */     if (paramDouble3 <= 0.0D) {
/* 186 */       throw new IllegalArgumentException("width must be > 0");
/*     */     }
/* 188 */     if (paramDouble4 <= 0.0D) {
/* 189 */       throw new IllegalArgumentException("height must be > 0");
/*     */     }
/* 191 */     Screen screen = Screen.getPrimary();
/* 192 */     Objects.requireNonNull(screen);
/* 193 */     double d1 = screen.getOutputScaleX();
/* 194 */     double d2 = screen.getOutputScaleY();
/*     */ 
/*     */     
/* 197 */     if (d1 == 1.0D && d2 == 1.0D) {
/*     */       
/* 199 */       arrayOfInt = new int[(int)(paramDouble3 * paramDouble4)];
/* 200 */       getScreenCapture((int)paramDouble1, (int)paramDouble2, (int)paramDouble3, (int)paramDouble4, arrayOfInt, paramBoolean);
/* 201 */       i = (int)paramDouble3;
/* 202 */       j = (int)paramDouble4;
/*     */     }
/*     */     else {
/*     */       
/* 206 */       int k = (int)Math.floor(paramDouble1 * d1);
/* 207 */       int m = (int)Math.floor(paramDouble2 * d2);
/* 208 */       int n = (int)Math.ceil((paramDouble1 + paramDouble3) * d1);
/* 209 */       int i1 = (int)Math.ceil((paramDouble2 + paramDouble4) * d2);
/* 210 */       int i2 = n - k;
/* 211 */       int i3 = i1 - m;
/* 212 */       int[] arrayOfInt1 = new int[i2 * i3];
/* 213 */       getScreenCapture(k, m, i2, i3, arrayOfInt1, paramBoolean);
/* 214 */       i = i2;
/* 215 */       j = i3;
/* 216 */       if (!paramBoolean) {
/* 217 */         arrayOfInt = arrayOfInt1;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 222 */         arrayOfInt = new int[(int)(paramDouble3 * paramDouble4)];
/* 223 */         byte b1 = 0;
/* 224 */         for (byte b2 = 0; b2 < paramDouble4; b2++) {
/* 225 */           double d = (paramDouble2 + b2 + 0.5D) * d2 - (m + 0.5F);
/* 226 */           int i4 = (int)Math.floor(d);
/* 227 */           int i5 = (int)((d - i4) * 256.0D);
/* 228 */           for (byte b = 0; b < paramDouble3; b++) {
/* 229 */             double d3 = (paramDouble1 + b + 0.5D) * d1 - (k + 0.5F);
/* 230 */             int i6 = (int)Math.floor(d3);
/* 231 */             int i7 = (int)((d3 - i6) * 256.0D);
/* 232 */             arrayOfInt[b1++] = interp(arrayOfInt1, i6, i4, i2, i3, i7, i5);
/*     */           } 
/*     */         } 
/* 235 */         i = (int)paramDouble3;
/* 236 */         j = (int)paramDouble4;
/*     */       } 
/*     */     } 
/*     */     
/* 240 */     return convertFromPixels(paramWritableImage, Application.GetApplication().createPixels(i, j, IntBuffer.wrap(arrayOfInt)));
/*     */   }
/*     */   
/*     */   public static int convertToRobotMouseButton(MouseButton[] paramArrayOfMouseButton) {
/* 244 */     int i = 0;
/* 245 */     for (MouseButton mouseButton : paramArrayOfMouseButton) {
/* 246 */       switch (mouseButton) { case PRIMARY:
/* 247 */           i |= 0x1; break;
/* 248 */         case SECONDARY: i |= 0x2; break;
/* 249 */         case MIDDLE: i |= 0x4; break;
/* 250 */         default: throw new IllegalArgumentException("MouseButton: " + mouseButton + " not supported by Robot"); }
/*     */     
/*     */     } 
/* 253 */     return i;
/*     */   }
/*     */   
/*     */   public static Color convertFromIntArgb(int paramInt) {
/* 257 */     int i = paramInt >> 24 & 0xFF;
/* 258 */     int j = paramInt >> 16 & 0xFF;
/* 259 */     int k = paramInt >> 8 & 0xFF;
/* 260 */     int m = paramInt & 0xFF;
/* 261 */     return new Color(j / 255.0D, k / 255.0D, m / 255.0D, i / 255.0D);
/*     */   }
/*     */   
/*     */   protected static WritableImage convertFromPixels(WritableImage paramWritableImage, Pixels paramPixels) {
/* 265 */     Objects.requireNonNull(paramPixels);
/* 266 */     int i = paramPixels.getWidth();
/* 267 */     int j = paramPixels.getHeight();
/* 268 */     if (paramWritableImage == null || paramWritableImage.getWidth() != i || paramWritableImage.getHeight() != j) {
/* 269 */       paramWritableImage = new WritableImage(i, j);
/*     */     }
/*     */     
/* 272 */     int k = paramPixels.getBytesPerComponent();
/* 273 */     if (k == 4) {
/* 274 */       IntBuffer intBuffer = (IntBuffer)paramPixels.getPixels();
/* 275 */       writeIntBufferToImage(intBuffer, paramWritableImage);
/* 276 */     } else if (k == 1) {
/* 277 */       ByteBuffer byteBuffer = (ByteBuffer)paramPixels.getPixels();
/* 278 */       writeByteBufferToImage(byteBuffer, paramWritableImage);
/*     */     } else {
/* 280 */       throw new IllegalArgumentException("bytesPerComponent must be either 4 or 1 but was: " + k);
/*     */     } 
/*     */ 
/*     */     
/* 284 */     return paramWritableImage;
/*     */   }
/*     */   
/*     */   private static void writeIntBufferToImage(IntBuffer paramIntBuffer, WritableImage paramWritableImage) {
/* 288 */     Objects.requireNonNull(paramWritableImage);
/* 289 */     PixelWriter pixelWriter = paramWritableImage.getPixelWriter();
/* 290 */     double d1 = paramWritableImage.getWidth();
/* 291 */     double d2 = paramWritableImage.getHeight();
/*     */     
/* 293 */     for (byte b = 0; b < d2; b++) {
/* 294 */       for (byte b1 = 0; b1 < d1; b1++) {
/* 295 */         int i = paramIntBuffer.get();
/* 296 */         pixelWriter.setArgb(b1, b, i);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeByteBufferToImage(ByteBuffer paramByteBuffer, WritableImage paramWritableImage) {
/* 302 */     Objects.requireNonNull(paramWritableImage);
/* 303 */     PixelWriter pixelWriter = paramWritableImage.getPixelWriter();
/* 304 */     double d1 = paramWritableImage.getWidth();
/* 305 */     double d2 = paramWritableImage.getHeight();
/*     */     
/* 307 */     int i = Pixels.getNativeFormat();
/*     */     
/* 309 */     for (byte b = 0; b < d2; b++) {
/* 310 */       for (byte b1 = 0; b1 < d1; b1++) {
/* 311 */         if (i == 1) {
/* 312 */           pixelWriter.setArgb(b1, b, PixelUtils.PretoNonPre(bgraPreToRgbaPre(paramByteBuffer.getInt())));
/* 313 */         } else if (i == 2) {
/* 314 */           pixelWriter.setArgb(b1, b, paramByteBuffer.getInt());
/*     */         } else {
/* 316 */           throw new IllegalArgumentException("format must be either BYTE_BGRA_PRE or BYTE_ARGB");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int bgraPreToRgbaPre(int paramInt) {
/* 323 */     return Integer.reverseBytes(paramInt);
/*     */   }
/*     */   
/*     */   private static int interp(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 327 */     int i = 256 - paramInt5;
/* 328 */     int j = 256 - paramInt6;
/* 329 */     int k = paramInt2 * paramInt3 + paramInt1;
/* 330 */     boolean bool1 = (paramInt1 < 0 || paramInt2 < 0 || paramInt1 >= paramInt3 || paramInt2 >= paramInt4) ? false : paramArrayOfint[k];
/* 331 */     if (paramInt6 == 0) {
/*     */       
/* 333 */       if (paramInt5 == 0)
/*     */       {
/* 335 */         return bool1;
/*     */       }
/* 337 */       boolean bool = (paramInt2 < 0 || paramInt1 + 1 >= paramInt3 || paramInt2 >= paramInt4) ? false : paramArrayOfint[k + 1];
/* 338 */       return interp(bool1, bool, i, paramInt5);
/* 339 */     }  if (paramInt5 == 0) {
/*     */       
/* 341 */       boolean bool = (paramInt1 < 0 || paramInt1 >= paramInt3 || paramInt2 + 1 >= paramInt4) ? false : paramArrayOfint[k + paramInt3];
/* 342 */       return interp(bool1, bool, j, paramInt6);
/*     */     } 
/*     */     
/* 345 */     boolean bool2 = (paramInt2 < 0 || paramInt1 + 1 >= paramInt3 || paramInt2 >= paramInt4) ? false : paramArrayOfint[k + 1];
/* 346 */     boolean bool3 = (paramInt1 < 0 || paramInt1 >= paramInt3 || paramInt2 + 1 >= paramInt4) ? false : paramArrayOfint[k + paramInt3];
/* 347 */     boolean bool4 = (paramInt1 + 1 >= paramInt3 || paramInt2 + 1 >= paramInt4) ? false : paramArrayOfint[k + paramInt3 + 1];
/* 348 */     return interp(interp(bool1, bool2, i, paramInt5), 
/* 349 */         interp(bool3, bool4, i, paramInt5), j, paramInt6);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int interp(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 355 */     int i = paramInt1 >> 24 & 0xFF;
/* 356 */     int j = paramInt1 >> 16 & 0xFF;
/* 357 */     int k = paramInt1 >> 8 & 0xFF;
/* 358 */     int m = paramInt1 & 0xFF;
/* 359 */     int n = paramInt2 >> 24 & 0xFF;
/* 360 */     int i1 = paramInt2 >> 16 & 0xFF;
/* 361 */     int i2 = paramInt2 >> 8 & 0xFF;
/* 362 */     int i3 = paramInt2 & 0xFF;
/* 363 */     int i4 = i * paramInt3 + n * paramInt4 >> 8;
/* 364 */     int i5 = j * paramInt3 + i1 * paramInt4 >> 8;
/* 365 */     int i6 = k * paramInt3 + i2 * paramInt4 >> 8;
/* 366 */     int i7 = m * paramInt3 + i3 * paramInt4 >> 8;
/* 367 */     return i4 << 24 | i5 << 16 | i6 << 8 | i7;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\GlassRobot.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */