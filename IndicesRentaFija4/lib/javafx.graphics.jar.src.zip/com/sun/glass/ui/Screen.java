/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Screen
/*     */ {
/*  37 */   private static volatile List<Screen> screens = null; private static EventHandler eventHandler;
/*     */   private volatile long ptr;
/*     */   private volatile int adapter;
/*     */   private final int depth;
/*     */   private final int x;
/*     */   private final int y;
/*  43 */   private static final int dpiOverride = ((Integer)AccessController.<Integer>doPrivileged(() -> Integer.getInteger("com.sun.javafx.screenDPI", 0))).intValue();
/*     */   
/*     */   private final int width;
/*     */   private final int height;
/*     */   private final int platformX;
/*     */   private final int platformY;
/*     */   private final int platformWidth;
/*     */   
/*     */   public static double getVideoRefreshPeriod() {
/*  52 */     Application.checkEventThread();
/*  53 */     return Application.GetApplication().staticScreen_getVideoRefreshPeriod();
/*     */   }
/*     */   
/*     */   private final int platformHeight;
/*     */   private final int visibleX;
/*     */   private final int visibleY;
/*     */   
/*     */   public static Screen getMainScreen() {
/*  61 */     return getScreens().get(0);
/*     */   }
/*     */   private final int visibleWidth; private final int visibleHeight; private final int resolutionX;
/*     */   private final int resolutionY;
/*     */   private final float platformScaleX;
/*     */   private final float platformScaleY;
/*     */   
/*     */   public static List<Screen> getScreens() {
/*  69 */     if (screens == null) {
/*  70 */       throw new RuntimeException("Internal graphics not initialized yet");
/*     */     }
/*     */     
/*  73 */     return screens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final float outputScaleX;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final float outputScaleY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class EventHandler
/*     */   {
/*     */     public void handleSettingsChanged() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Screen(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14, int paramInt15, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 133 */     this.ptr = paramLong;
/*     */     
/* 135 */     this.depth = paramInt1;
/*     */     
/* 137 */     this.x = paramInt2;
/* 138 */     this.y = paramInt3;
/* 139 */     this.width = paramInt4;
/* 140 */     this.height = paramInt5;
/*     */     
/* 142 */     this.platformX = paramInt6;
/* 143 */     this.platformY = paramInt7;
/* 144 */     this.platformWidth = paramInt8;
/* 145 */     this.platformHeight = paramInt9;
/*     */     
/* 147 */     this.visibleX = paramInt10;
/* 148 */     this.visibleY = paramInt11;
/* 149 */     this.visibleWidth = paramInt12;
/* 150 */     this.visibleHeight = paramInt13;
/*     */     
/* 152 */     if (dpiOverride > 0) {
/* 153 */       this.resolutionX = this.resolutionY = dpiOverride;
/*     */     } else {
/* 155 */       this.resolutionX = paramInt14;
/* 156 */       this.resolutionY = paramInt15;
/*     */     } 
/*     */     
/* 159 */     this.platformScaleX = paramFloat1;
/* 160 */     this.platformScaleY = paramFloat2;
/* 161 */     this.outputScaleX = paramFloat3;
/* 162 */     this.outputScaleY = paramFloat4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDepth() {
/* 169 */     return this.depth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getX() {
/* 176 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getY() {
/* 183 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 190 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 197 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPlatformX() {
/* 204 */     return this.platformX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPlatformY() {
/* 211 */     return this.platformY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPlatformWidth() {
/* 218 */     return this.platformWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPlatformHeight() {
/* 225 */     return this.platformHeight;
/*     */   }
/*     */   
/*     */   public float fromPlatformX(int paramInt) {
/* 229 */     return this.x + (paramInt - this.platformX) / this.platformScaleX;
/*     */   }
/*     */   
/*     */   public float fromPlatformY(int paramInt) {
/* 233 */     return this.y + (paramInt - this.platformY) / this.platformScaleY;
/*     */   }
/*     */   
/*     */   public int toPlatformX(float paramFloat) {
/* 237 */     return this.platformX + Math.round((paramFloat - this.x) * this.platformScaleX);
/*     */   }
/*     */   
/*     */   public int toPlatformY(float paramFloat) {
/* 241 */     return this.platformY + Math.round((paramFloat - this.y) * this.platformScaleY);
/*     */   }
/*     */   
/*     */   public float portionIntersectsPlatformRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 245 */     int i = Math.max(paramInt1, this.platformX);
/* 246 */     int j = Math.max(paramInt2, this.platformY);
/* 247 */     int k = Math.min(paramInt1 + paramInt3, this.platformX + this.platformWidth);
/* 248 */     int m = Math.min(paramInt2 + paramInt4, this.platformY + this.platformHeight);
/* 249 */     if ((k -= i) <= 0) return 0.0F; 
/* 250 */     if ((m -= j) <= 0) return 0.0F; 
/* 251 */     float f = (k * m);
/* 252 */     return f / paramInt3 / paramInt4;
/*     */   }
/*     */   
/*     */   public boolean containsPlatformRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 256 */     if (!containsPlatformCoords(paramInt1, paramInt2)) return false; 
/* 257 */     if (paramInt3 <= 0 || paramInt4 <= 0) return true; 
/* 258 */     return (paramInt1 + paramInt3 <= this.platformX + this.platformWidth && paramInt2 + paramInt4 <= this.platformY + this.platformHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsPlatformCoords(int paramInt1, int paramInt2) {
/* 263 */     paramInt1 -= this.platformX;
/* 264 */     paramInt2 -= this.platformY;
/* 265 */     return (paramInt1 >= 0 && paramInt1 < this.platformWidth && paramInt2 >= 0 && paramInt2 < this.platformHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPlatformScaleX() {
/* 276 */     return this.platformScaleX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPlatformScaleY() {
/* 286 */     return this.platformScaleY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getRecommendedOutputScaleX() {
/* 295 */     return this.outputScaleX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getRecommendedOutputScaleY() {
/* 304 */     return this.outputScaleY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVisibleX() {
/* 311 */     return this.visibleX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVisibleY() {
/* 318 */     return this.visibleY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVisibleWidth() {
/* 325 */     return this.visibleWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVisibleHeight() {
/* 332 */     return this.visibleHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getResolutionX() {
/* 339 */     return this.resolutionX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getResolutionY() {
/* 346 */     return this.resolutionY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getNativeScreen() {
/* 353 */     return this.ptr;
/*     */   }
/*     */   
/*     */   private void dispose() {
/* 357 */     this.ptr = 0L;
/*     */   }
/*     */   
/*     */   public int getAdapterOrdinal() {
/* 361 */     return this.adapter;
/*     */   }
/*     */   
/*     */   public void setAdapterOrdinal(int paramInt) {
/* 365 */     this.adapter = paramInt;
/*     */   }
/*     */   
/*     */   public static void setEventHandler(EventHandler paramEventHandler) {
/* 369 */     Application.checkEventThread();
/* 370 */     eventHandler = paramEventHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void notifySettingsChanged() {
/* 378 */     List<Screen> list = screens;
/*     */ 
/*     */     
/* 381 */     initScreens();
/*     */     
/* 383 */     if (eventHandler != null) {
/* 384 */       eventHandler.handleSettingsChanged();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 391 */     List<Window> list1 = Window.getWindows();
/* 392 */     for (Window window : list1) {
/* 393 */       Screen screen = window.getScreen();
/* 394 */       for (Screen screen1 : screens) {
/* 395 */         if (screen.getNativeScreen() == screen1.getNativeScreen()) {
/* 396 */           window.setScreen(screen1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 403 */     if (list != null) {
/* 404 */       for (Screen screen : list) {
/* 405 */         screen.dispose();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static void initScreens() {
/* 411 */     Application.checkEventThread();
/* 412 */     Screen[] arrayOfScreen = Application.GetApplication().staticScreen_getScreens();
/* 413 */     if (arrayOfScreen == null) {
/* 414 */       throw new RuntimeException("Internal graphics failed to initialize");
/*     */     }
/* 416 */     screens = Collections.unmodifiableList(Arrays.asList(arrayOfScreen));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 421 */     return "Screen:\n    ptr:" + getNativeScreen() + "\n    adapter:" + 
/* 422 */       getAdapterOrdinal() + "\n    depth:" + 
/* 423 */       getDepth() + "\n    x:" + 
/* 424 */       getX() + "\n    y:" + 
/* 425 */       getY() + "\n    width:" + 
/* 426 */       getWidth() + "\n    height:" + 
/* 427 */       getHeight() + "\n    platformX:" + 
/* 428 */       getPlatformX() + "\n    platformY:" + 
/* 429 */       getPlatformY() + "\n    platformWidth:" + 
/* 430 */       getPlatformWidth() + "\n    platformHeight:" + 
/* 431 */       getPlatformHeight() + "\n    visibleX:" + 
/* 432 */       getVisibleX() + "\n    visibleY:" + 
/* 433 */       getVisibleY() + "\n    visibleWidth:" + 
/* 434 */       getVisibleWidth() + "\n    visibleHeight:" + 
/* 435 */       getVisibleHeight() + "\n    platformScaleX:" + 
/* 436 */       getPlatformScaleX() + "\n    platformScaleY:" + 
/* 437 */       getPlatformScaleY() + "\n    outputScaleX:" + 
/* 438 */       getRecommendedOutputScaleX() + "\n    outputScaleY:" + 
/* 439 */       getRecommendedOutputScaleY() + "\n    resolutionX:" + 
/* 440 */       getResolutionX() + "\n    resolutionY:" + 
/* 441 */       getResolutionY() + "\n";
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 445 */     if (this == paramObject) return true; 
/* 446 */     if (paramObject == null || getClass() != paramObject.getClass()) return false;
/*     */     
/* 448 */     Screen screen = (Screen)paramObject;
/* 449 */     return (this.ptr == screen.ptr && this.adapter == screen.adapter && this.depth == screen.depth && this.x == screen.x && this.y == screen.y && this.width == screen.width && this.height == screen.height && this.visibleX == screen.visibleX && this.visibleY == screen.visibleY && this.visibleWidth == screen.visibleWidth && this.visibleHeight == screen.visibleHeight && this.resolutionX == screen.resolutionX && this.resolutionY == screen.resolutionY && 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 462 */       Float.compare(screen.platformScaleX, this.platformScaleX) == 0 && 
/* 463 */       Float.compare(screen.platformScaleY, this.platformScaleY) == 0 && 
/* 464 */       Float.compare(screen.outputScaleX, this.outputScaleX) == 0 && 
/* 465 */       Float.compare(screen.outputScaleY, this.outputScaleY) == 0);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 469 */     int i = 17;
/* 470 */     i = 31 * i + (int)(this.ptr ^ this.ptr >>> 32L);
/* 471 */     i = 31 * i + this.adapter;
/* 472 */     i = 31 * i + this.depth;
/* 473 */     i = 31 * i + this.x;
/* 474 */     i = 31 * i + this.y;
/* 475 */     i = 31 * i + this.width;
/* 476 */     i = 31 * i + this.height;
/* 477 */     i = 31 * i + this.visibleX;
/* 478 */     i = 31 * i + this.visibleY;
/* 479 */     i = 31 * i + this.visibleWidth;
/* 480 */     i = 31 * i + this.visibleHeight;
/* 481 */     i = 31 * i + this.resolutionX;
/* 482 */     i = 31 * i + this.resolutionY;
/* 483 */     i = 31 * i + ((this.platformScaleX != 0.0F) ? Float.floatToIntBits(this.platformScaleX) : 0);
/* 484 */     i = 31 * i + ((this.platformScaleY != 0.0F) ? Float.floatToIntBits(this.platformScaleY) : 0);
/* 485 */     i = 31 * i + ((this.outputScaleX != 0.0F) ? Float.floatToIntBits(this.outputScaleX) : 0);
/* 486 */     i = 31 * i + ((this.outputScaleY != 0.0F) ? Float.floatToIntBits(this.outputScaleY) : 0);
/* 487 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\Screen.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */