/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Timer
/*     */ {
/*     */   private static final double UNSET_PERIOD = -1.0D;
/*     */   private static final double SET_PERIOD = -2.0D;
/*     */   private final Runnable runnable;
/*     */   private long ptr;
/*  46 */   private double period = -1.0D;
/*     */ 
/*     */   
/*     */   protected abstract long _start(Runnable paramRunnable);
/*     */ 
/*     */   
/*     */   protected abstract long _start(Runnable paramRunnable, int paramInt);
/*     */ 
/*     */   
/*     */   protected abstract void _stop(long paramLong);
/*     */ 
/*     */   
/*     */   protected Timer(Runnable paramRunnable) {
/*  59 */     if (paramRunnable == null) {
/*  60 */       throw new IllegalArgumentException("runnable shouldn't be null");
/*     */     }
/*  62 */     this.runnable = paramRunnable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getMinPeriod() {
/*  69 */     return Application.GetApplication().staticTimer_getMinPeriod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getMaxPeriod() {
/*  76 */     return Application.GetApplication().staticTimer_getMaxPeriod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void start(int paramInt) {
/*  86 */     if (paramInt < getMinPeriod() || paramInt > getMaxPeriod()) {
/*  87 */       throw new IllegalArgumentException("period is out of range");
/*     */     }
/*     */     
/*  90 */     if (this.ptr != 0L) {
/*  91 */       stop();
/*     */     }
/*     */     
/*  94 */     this.ptr = _start(this.runnable, paramInt);
/*  95 */     if (this.ptr == 0L) {
/*  96 */       this.period = -1.0D;
/*  97 */       throw new RuntimeException("Failed to start the timer");
/*     */     } 
/*  99 */     this.period = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void start() {
/* 110 */     if (this.ptr != 0L) {
/* 111 */       stop();
/*     */     }
/*     */     
/* 114 */     this.ptr = _start(this.runnable);
/* 115 */     if (this.ptr == 0L) {
/* 116 */       this.period = -1.0D;
/* 117 */       throw new RuntimeException("Failed to start the timer");
/*     */     } 
/* 119 */     this.period = -2.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void stop() {
/* 128 */     if (this.ptr != 0L) {
/* 129 */       _stop(this.ptr);
/* 130 */       this.ptr = 0L;
/* 131 */       this.period = -1.0D;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isRunning() {
/* 140 */     return (this.period != -1.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\Timer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */