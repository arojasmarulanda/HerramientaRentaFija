/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GestureSupport
/*     */ {
/*     */   private static final double THRESHOLD_SCROLL = 1.0D;
/*     */   private static final double THRESHOLD_SCALE = 0.01D;
/*     */   private static final double THRESHOLD_EXPANSION = 0.01D;
/*     */   
/*     */   private static class GestureState
/*     */   {
/*     */     enum StateId
/*     */     {
/*  34 */       Idle, Running, Inertia;
/*     */     }
/*     */     
/*  37 */     private StateId id = StateId.Idle;
/*     */     
/*     */     void setIdle() {
/*  40 */       this.id = StateId.Idle;
/*     */     }
/*     */     
/*     */     boolean isIdle() {
/*  44 */       return (this.id == StateId.Idle);
/*     */     }
/*     */     
/*     */     int updateProgress(boolean param1Boolean) {
/*  48 */       byte b = 2;
/*     */       
/*  50 */       if (doesGestureStart(param1Boolean) && !param1Boolean) {
/*  51 */         b = 1;
/*     */       }
/*     */       
/*  54 */       this.id = param1Boolean ? StateId.Inertia : StateId.Running;
/*     */       
/*  56 */       return b;
/*     */     }
/*     */     
/*     */     boolean doesGestureStart(boolean param1Boolean) {
/*  60 */       switch (this.id) {
/*     */         case Running:
/*  62 */           return param1Boolean;
/*     */         case Inertia:
/*  64 */           return !param1Boolean;
/*     */       } 
/*  66 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     private GestureState() {}
/*     */   }
/*     */   
/*  73 */   private static final double THRESHOLD_ROTATE = Math.toDegrees(0.017453292519943295D);
/*     */   
/*  75 */   private final GestureState scrolling = new GestureState();
/*  76 */   private final GestureState rotating = new GestureState();
/*  77 */   private final GestureState zooming = new GestureState();
/*  78 */   private final GestureState swiping = new GestureState();
/*     */   
/*  80 */   private double totalScrollX = Double.NaN;
/*  81 */   private double totalScrollY = Double.NaN;
/*  82 */   private double totalScale = 1.0D;
/*  83 */   private double totalExpansion = Double.NaN;
/*  84 */   private double totalRotation = 0.0D;
/*  85 */   private double multiplierX = 1.0D;
/*  86 */   private double multiplierY = 1.0D;
/*     */   
/*     */   private boolean zoomWithExpansion;
/*     */   
/*     */   public GestureSupport(boolean paramBoolean) {
/*  91 */     this.zoomWithExpansion = paramBoolean;
/*     */   }
/*     */   
/*     */   private static double multiplicativeDelta(double paramDouble1, double paramDouble2) {
/*  95 */     if (paramDouble1 == 0.0D) {
/*  96 */       return Double.NaN;
/*     */     }
/*  98 */     return paramDouble2 / paramDouble1;
/*     */   }
/*     */   
/*     */   private int setScrolling(boolean paramBoolean) {
/* 102 */     return this.scrolling.updateProgress(paramBoolean);
/*     */   }
/*     */   
/*     */   private int setRotating(boolean paramBoolean) {
/* 106 */     return this.rotating.updateProgress(paramBoolean);
/*     */   }
/*     */   
/*     */   private int setZooming(boolean paramBoolean) {
/* 110 */     return this.zooming.updateProgress(paramBoolean);
/*     */   }
/*     */   
/*     */   private int setSwiping(boolean paramBoolean) {
/* 114 */     return this.swiping.updateProgress(paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean isScrolling() {
/* 118 */     return !this.scrolling.isIdle();
/*     */   }
/*     */   
/*     */   public boolean isRotating() {
/* 122 */     return !this.rotating.isIdle();
/*     */   }
/*     */   
/*     */   public boolean isZooming() {
/* 126 */     return !this.zooming.isIdle();
/*     */   }
/*     */   
/*     */   public boolean isSwiping() {
/* 130 */     return !this.swiping.isIdle();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleScrollingEnd(View paramView, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 136 */     this.scrolling.setIdle();
/* 137 */     if (paramBoolean2) {
/*     */       return;
/*     */     }
/* 140 */     paramView.notifyScrollGestureEvent(3, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, 0.0D, 0.0D, this.totalScrollX, this.totalScrollY, this.multiplierX, this.multiplierY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleRotationEnd(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 150 */     this.rotating.setIdle();
/* 151 */     if (paramBoolean2) {
/*     */       return;
/*     */     }
/* 154 */     paramView.notifyRotateGestureEvent(3, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, 0.0D, this.totalRotation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleZoomingEnd(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 162 */     this.zooming.setIdle();
/* 163 */     if (paramBoolean2) {
/*     */       return;
/*     */     }
/* 166 */     paramView.notifyZoomGestureEvent(3, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, Double.NaN, 0.0D, this.totalScale, this.totalExpansion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleSwipeEnd(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 175 */     this.swiping.setIdle();
/* 176 */     if (paramBoolean2) {
/*     */       return;
/*     */     }
/* 179 */     paramView.notifySwipeGestureEvent(3, paramInt1, paramBoolean1, paramBoolean2, 2147483647, 2147483647, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleTotalZooming(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, double paramDouble1, double paramDouble2) {
/* 188 */     double d1 = this.totalScale;
/* 189 */     double d2 = this.totalExpansion;
/* 190 */     if (this.zooming.doesGestureStart(paramBoolean2)) {
/* 191 */       d1 = 1.0D;
/* 192 */       d2 = 0.0D;
/*     */     } 
/*     */     
/* 195 */     if (Math.abs(paramDouble1 - d1) < 0.01D && (!this.zoomWithExpansion || 
/*     */       
/* 197 */       Math.abs(paramDouble2 - d2) < 0.01D)) {
/*     */       return;
/*     */     }
/*     */     
/* 201 */     double d3 = Double.NaN;
/* 202 */     if (this.zoomWithExpansion) {
/* 203 */       d3 = paramDouble2 - d2;
/*     */     } else {
/* 205 */       paramDouble2 = Double.NaN;
/*     */     } 
/*     */     
/* 208 */     this.totalScale = paramDouble1;
/* 209 */     this.totalExpansion = paramDouble2;
/* 210 */     int i = setZooming(paramBoolean2);
/*     */     
/* 212 */     paramView.notifyZoomGestureEvent(i, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, 
/*     */         
/* 214 */         multiplicativeDelta(d1, this.totalScale), d3, paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleTotalRotation(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, double paramDouble) {
/* 222 */     double d = this.totalRotation;
/* 223 */     if (this.rotating.doesGestureStart(paramBoolean2)) {
/* 224 */       d = 0.0D;
/*     */     }
/*     */     
/* 227 */     if (Math.abs(paramDouble - d) < THRESHOLD_ROTATE) {
/*     */       return;
/*     */     }
/*     */     
/* 231 */     this.totalRotation = paramDouble;
/* 232 */     int i = setRotating(paramBoolean2);
/*     */     
/* 234 */     paramView.notifyRotateGestureEvent(i, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, paramDouble - d, paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleTotalScrolling(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 244 */     this.multiplierX = paramDouble3;
/* 245 */     this.multiplierY = paramDouble4;
/*     */     
/* 247 */     double d1 = this.totalScrollX;
/* 248 */     double d2 = this.totalScrollY;
/* 249 */     if (this.scrolling.doesGestureStart(paramBoolean2)) {
/* 250 */       d1 = 0.0D;
/* 251 */       d2 = 0.0D;
/*     */     } 
/*     */     
/* 254 */     if (Math.abs(paramDouble1 - this.totalScrollX) < 1.0D && 
/* 255 */       Math.abs(paramDouble2 - this.totalScrollY) < 1.0D) {
/*     */       return;
/*     */     }
/*     */     
/* 259 */     this.totalScrollX = paramDouble1;
/* 260 */     this.totalScrollY = paramDouble2;
/* 261 */     int i = setScrolling(paramBoolean2);
/*     */     
/* 263 */     paramView.notifyScrollGestureEvent(i, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1 - d1, paramDouble2 - d2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleDeltaZooming(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, double paramDouble1, double paramDouble2) {
/* 274 */     double d1 = this.totalScale;
/* 275 */     double d2 = this.totalExpansion;
/* 276 */     if (this.zooming.doesGestureStart(paramBoolean2)) {
/* 277 */       d1 = 1.0D;
/* 278 */       d2 = 0.0D;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 287 */     this.totalScale = d1 * (1.0D + paramDouble1);
/* 288 */     if (this.zoomWithExpansion) {
/* 289 */       this.totalExpansion = d2 + paramDouble2;
/*     */     } else {
/* 291 */       this.totalExpansion = Double.NaN;
/*     */     } 
/*     */     
/* 294 */     int i = setZooming(paramBoolean2);
/*     */     
/* 296 */     paramView.notifyZoomGestureEvent(i, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, 
/*     */         
/* 298 */         multiplicativeDelta(d1, this.totalScale), paramDouble2, this.totalScale, this.totalExpansion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleDeltaRotation(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, double paramDouble) {
/* 306 */     double d = this.totalRotation;
/* 307 */     if (this.rotating.doesGestureStart(paramBoolean2)) {
/* 308 */       d = 0.0D;
/*     */     }
/*     */     
/* 311 */     this.totalRotation = d + paramDouble;
/* 312 */     int i = setRotating(paramBoolean2);
/*     */     
/* 314 */     paramView.notifyRotateGestureEvent(i, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, paramDouble, this.totalRotation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleDeltaScrolling(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 323 */     this.multiplierX = paramDouble3;
/* 324 */     this.multiplierY = paramDouble4;
/*     */     
/* 326 */     double d1 = this.totalScrollX;
/* 327 */     double d2 = this.totalScrollY;
/* 328 */     if (this.scrolling.doesGestureStart(paramBoolean2)) {
/* 329 */       d1 = 0.0D;
/* 330 */       d2 = 0.0D;
/*     */     } 
/*     */     
/* 333 */     this.totalScrollX = d1 + paramDouble1;
/* 334 */     this.totalScrollY = d2 + paramDouble2;
/*     */     
/* 336 */     int i = setScrolling(paramBoolean2);
/*     */     
/* 338 */     paramView.notifyScrollGestureEvent(i, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1, paramDouble2, this.totalScrollX, this.totalScrollY, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleSwipe(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7) {
/* 347 */     int i = setSwiping(paramBoolean2);
/* 348 */     paramView.notifySwipeGestureEvent(i, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void handleSwipePerformed(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7) {
/* 356 */     paramView.notifySwipeGestureEvent(2, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void handleScrollingPerformed(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 368 */     paramView.notifyScrollGestureEvent(2, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1, paramDouble2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TouchInputSupport.TouchCountListener createTouchCountListener() {
/* 374 */     Application.checkEventThread();
/* 375 */     return (paramTouchInputSupport, paramView, paramInt, paramBoolean) -> {
/*     */         boolean bool = false;
/*     */         if (isScrolling())
/*     */           handleScrollingEnd(paramView, paramInt, paramTouchInputSupport.getTouchCount(), paramBoolean, false, 2147483647, 2147483647, 2147483647, 2147483647); 
/*     */         if (isRotating())
/*     */           handleRotationEnd(paramView, paramInt, paramBoolean, false, 2147483647, 2147483647, 2147483647, 2147483647); 
/*     */         if (isZooming())
/*     */           handleZoomingEnd(paramView, paramInt, paramBoolean, false, 2147483647, 2147483647, 2147483647, 2147483647); 
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\GestureSupport.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */