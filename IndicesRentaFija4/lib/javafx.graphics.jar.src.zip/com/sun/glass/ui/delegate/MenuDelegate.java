package com.sun.glass.ui.delegate;

import com.sun.glass.ui.Pixels;

public interface MenuDelegate {
  boolean createMenu(String paramString, boolean paramBoolean);
  
  boolean setTitle(String paramString);
  
  boolean setEnabled(boolean paramBoolean);
  
  boolean setPixels(Pixels paramPixels);
  
  boolean insert(MenuDelegate paramMenuDelegate, int paramInt);
  
  boolean insert(MenuItemDelegate paramMenuItemDelegate, int paramInt);
  
  boolean remove(MenuDelegate paramMenuDelegate, int paramInt);
  
  boolean remove(MenuItemDelegate paramMenuItemDelegate, int paramInt);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\delegate\MenuDelegate.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */