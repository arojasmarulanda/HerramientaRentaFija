package com.sun.glass.ui.delegate;

public interface MenuBarDelegate {
  boolean createMenuBar();
  
  boolean insert(MenuDelegate paramMenuDelegate, int paramInt);
  
  boolean remove(MenuDelegate paramMenuDelegate, int paramInt);
  
  long getNativeMenu();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\delegate\MenuBarDelegate.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */