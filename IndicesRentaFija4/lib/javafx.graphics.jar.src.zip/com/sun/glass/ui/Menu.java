/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import com.sun.glass.ui.delegate.MenuDelegate;
/*     */ import com.sun.glass.ui.delegate.MenuItemDelegate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Menu
/*     */ {
/*     */   private final MenuDelegate delegate;
/*     */   private String title;
/*     */   private boolean enabled;
/*     */   
/*     */   public static class EventHandler
/*     */   {
/*     */     public void handleMenuOpening(Menu param1Menu, long param1Long) {}
/*     */     
/*     */     public void handleMenuClosed(Menu param1Menu, long param1Long) {}
/*     */   }
/*     */   
/*     */   public EventHandler getEventHandler() {
/*  48 */     Application.checkEventThread();
/*  49 */     return this.eventHandler;
/*     */   }
/*     */   
/*     */   public void setEventHandler(EventHandler paramEventHandler) {
/*  53 */     Application.checkEventThread();
/*  54 */     this.eventHandler = paramEventHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private final List<Object> items = new ArrayList();
/*     */   
/*     */   private EventHandler eventHandler;
/*     */   
/*     */   protected Menu(String paramString) {
/*  66 */     this(paramString, true);
/*     */   }
/*     */   
/*     */   protected Menu(String paramString, boolean paramBoolean) {
/*  70 */     Application.checkEventThread();
/*  71 */     this.title = paramString;
/*  72 */     this.enabled = paramBoolean;
/*  73 */     this.delegate = PlatformFactory.getPlatformFactory().createMenuDelegate(this);
/*  74 */     if (!this.delegate.createMenu(paramString, paramBoolean)) {
/*  75 */       throw new RuntimeException("Menu creation error.");
/*     */     }
/*     */   }
/*     */   
/*     */   public String getTitle() {
/*  80 */     Application.checkEventThread();
/*  81 */     return this.title;
/*     */   }
/*     */   
/*     */   public void setTitle(String paramString) {
/*  85 */     Application.checkEventThread();
/*  86 */     if (this.delegate.setTitle(paramString)) {
/*  87 */       this.title = paramString;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*  92 */     Application.checkEventThread();
/*  93 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean paramBoolean) {
/*  97 */     Application.checkEventThread();
/*  98 */     if (this.delegate.setEnabled(paramBoolean)) {
/*  99 */       this.enabled = paramBoolean;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean setPixels(Pixels paramPixels) {
/* 104 */     Application.checkEventThread();
/* 105 */     return this.delegate.setPixels(paramPixels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> getItems() {
/* 113 */     Application.checkEventThread();
/* 114 */     return Collections.unmodifiableList(this.items);
/*     */   }
/*     */   
/*     */   public void add(Menu paramMenu) {
/* 118 */     Application.checkEventThread();
/* 119 */     insert(paramMenu, this.items.size());
/*     */   }
/*     */   
/*     */   public void add(MenuItem paramMenuItem) {
/* 123 */     Application.checkEventThread();
/* 124 */     insert(paramMenuItem, this.items.size());
/*     */   }
/*     */   
/*     */   public void insert(Menu paramMenu, int paramInt) throws IndexOutOfBoundsException {
/* 128 */     Application.checkEventThread();
/* 129 */     if (paramMenu == null) {
/* 130 */       throw new IllegalArgumentException();
/*     */     }
/* 132 */     synchronized (this.items) {
/* 133 */       if (paramInt < 0 || paramInt > this.items.size()) {
/* 134 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 136 */       MenuDelegate menuDelegate = paramMenu.getDelegate();
/* 137 */       if (this.delegate.insert(menuDelegate, paramInt)) {
/* 138 */         this.items.add(paramInt, paramMenu);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void insert(MenuItem paramMenuItem, int paramInt) throws IndexOutOfBoundsException {
/* 144 */     Application.checkEventThread();
/* 145 */     synchronized (this.items) {
/* 146 */       if (paramInt < 0 || paramInt > this.items.size()) {
/* 147 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 149 */       MenuItemDelegate menuItemDelegate = (paramMenuItem != null) ? paramMenuItem.getDelegate() : null;
/* 150 */       if (this.delegate.insert(menuItemDelegate, paramInt)) {
/* 151 */         this.items.add(paramInt, paramMenuItem);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void remove(int paramInt) throws IndexOutOfBoundsException {
/* 157 */     Application.checkEventThread();
/* 158 */     synchronized (this.items) {
/* 159 */       Object object = this.items.get(paramInt);
/* 160 */       boolean bool = false;
/* 161 */       if (object == MenuItem.Separator) {
/* 162 */         bool = this.delegate.remove((MenuItemDelegate)null, paramInt);
/* 163 */       } else if (object instanceof MenuItem) {
/* 164 */         bool = this.delegate.remove(((MenuItem)object).getDelegate(), paramInt);
/*     */       } else {
/* 166 */         bool = this.delegate.remove(((Menu)object).getDelegate(), paramInt);
/*     */       } 
/* 168 */       if (bool) {
/* 169 */         this.items.remove(paramInt);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MenuDelegate getDelegate() {
/* 179 */     return this.delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyMenuOpening() {
/* 186 */     if (this.eventHandler != null) {
/* 187 */       this.eventHandler.handleMenuOpening(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyMenuClosed() {
/* 192 */     if (this.eventHandler != null)
/* 193 */       this.eventHandler.handleMenuClosed(this, System.nanoTime()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\Menu.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */