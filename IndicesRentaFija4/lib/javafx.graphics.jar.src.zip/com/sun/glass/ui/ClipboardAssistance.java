/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClipboardAssistance
/*     */ {
/*  31 */   private final HashMap<String, Object> cacheData = new HashMap<>();
/*     */   private final Clipboard clipboard;
/*  33 */   private int supportedActions = 1342177279;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClipboardAssistance(String paramString) {
/*  40 */     Application.checkEventThread();
/*  41 */     this.clipboard = Clipboard.get(paramString);
/*  42 */     this.clipboard.add(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  49 */     Application.checkEventThread();
/*  50 */     this.clipboard.remove(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/*  58 */     Application.checkEventThread();
/*  59 */     this.clipboard.flush(this, this.cacheData, this.supportedActions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void emptyCache() {
/*  66 */     Application.checkEventThread();
/*  67 */     this.cacheData.clear();
/*     */   }
/*     */   
/*     */   public boolean isCacheEmpty() {
/*  71 */     Application.checkEventThread();
/*  72 */     return this.cacheData.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(String paramString, Object paramObject) {
/*  83 */     Application.checkEventThread();
/*  84 */     this.cacheData.put(paramString, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getData(String paramString) {
/*  94 */     Application.checkEventThread();
/*  95 */     return this.clipboard.getData(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportedActions(int paramInt) {
/* 104 */     Application.checkEventThread();
/* 105 */     this.supportedActions = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSupportedSourceActions() {
/* 113 */     Application.checkEventThread();
/* 114 */     return this.clipboard.getSupportedSourceActions();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetAction(int paramInt) {
/* 122 */     Application.checkEventThread();
/* 123 */     this.clipboard.setTargetAction(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void contentChanged() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(int paramInt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getMimeTypes() {
/* 139 */     Application.checkEventThread();
/* 140 */     return this.clipboard.getMimeTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 145 */     return "ClipboardAssistance[" + this.clipboard + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\ClipboardAssistance.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */