/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import com.sun.glass.ui.GestureSupport;
/*     */ import com.sun.glass.ui.TouchInputSupport;
/*     */ import com.sun.glass.ui.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WinGestureSupport
/*     */ {
/*     */   private static final double multiplier = 1.0D;
/*     */   
/*     */   static {
/*  38 */     _initIDs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   private static final GestureSupport gestures = new GestureSupport(true);
/*  45 */   private static final TouchInputSupport touches = new TouchInputSupport(gestures
/*  46 */       .createTouchCountListener(), true);
/*     */   
/*     */   private static int modifiers;
/*     */   
/*     */   private static boolean isDirect;
/*     */   
/*     */   public static void notifyBeginTouchEvent(View paramView, int paramInt1, boolean paramBoolean, int paramInt2) {
/*  53 */     touches.notifyBeginTouchEvent(paramView, paramInt1, paramBoolean, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void notifyNextTouchEvent(View paramView, int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  58 */     touches.notifyNextTouchEvent(paramView, paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */   
/*     */   public static void notifyEndTouchEvent(View paramView) {
/*  62 */     touches.notifyEndTouchEvent(paramView);
/*  63 */     gestureFinished(paramView, touches.getTouchCount(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void gestureFinished(View paramView, int paramInt, boolean paramBoolean) {
/*  68 */     if (gestures.isScrolling() && paramInt == 0) {
/*  69 */       gestures.handleScrollingEnd(paramView, modifiers, paramInt, isDirect, paramBoolean, 2147483647, 2147483647, 2147483647, 2147483647);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     if (gestures.isRotating() && paramInt < 2) {
/*  78 */       gestures.handleRotationEnd(paramView, modifiers, isDirect, paramBoolean, 2147483647, 2147483647, 2147483647, 2147483647);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     if (gestures.isZooming() && paramInt < 2) {
/*  86 */       gestures.handleZoomingEnd(paramView, modifiers, isDirect, paramBoolean, 2147483647, 2147483647, 2147483647, 2147483647);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void inertiaGestureFinished(View paramView) {
/*  95 */     gestureFinished(paramView, 0, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void gesturePerformed(View paramView, int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
/* 105 */     modifiers = paramInt1;
/* 106 */     isDirect = paramBoolean1;
/*     */     
/* 108 */     int i = touches.getTouchCount();
/*     */     
/* 110 */     if (i >= 2) {
/* 111 */       gestures.handleTotalZooming(paramView, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, paramFloat5, paramFloat6);
/*     */ 
/*     */ 
/*     */       
/* 115 */       gestures.handleTotalRotation(paramView, paramInt1, paramBoolean1, paramBoolean2, paramInt2, paramInt3, paramInt4, paramInt5, 
/* 116 */           Math.toDegrees(paramFloat7));
/*     */     } 
/*     */ 
/*     */     
/* 120 */     gestures.handleTotalScrolling(paramView, paramInt1, paramBoolean1, paramBoolean2, i, paramInt2, paramInt3, paramInt4, paramInt5, paramFloat3, paramFloat4, 1.0D, 1.0D);
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinGestureSupport.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */