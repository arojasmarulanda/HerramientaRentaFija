/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import com.sun.glass.ui.MenuItem;
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import com.sun.glass.ui.delegate.MenuItemDelegate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WinMenuItemDelegate
/*     */   implements MenuItemDelegate
/*     */ {
/*     */   private final MenuItem owner;
/*  40 */   private WinMenuImpl parent = null;
/*     */   
/*  42 */   private int cmdID = -1;
/*     */   
/*     */   public WinMenuItemDelegate(MenuItem paramMenuItem) {
/*  45 */     this.owner = paramMenuItem;
/*     */   }
/*     */   
/*     */   public MenuItem getOwner() {
/*  49 */     return this.owner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean createMenuItem(String paramString, MenuItem.Callback paramCallback, int paramInt1, int paramInt2, Pixels paramPixels, boolean paramBoolean1, boolean paramBoolean2) {
/*  56 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setTitle(String paramString) {
/*  62 */     if (this.parent != null) {
/*  63 */       paramString = getTitle(paramString, getOwner().getShortcutKey(), 
/*  64 */           getOwner().getShortcutModifiers());
/*  65 */       return this.parent.setItemTitle(this, paramString);
/*     */     } 
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setCallback(MenuItem.Callback paramCallback) {
/*  72 */     return true;
/*     */   }
/*     */   
/*     */   public boolean setShortcut(int paramInt1, int paramInt2) {
/*  76 */     if (this.parent != null) {
/*  77 */       String str = getTitle(getOwner().getTitle(), paramInt1, paramInt2);
/*     */       
/*  79 */       return this.parent.setItemTitle(this, str);
/*     */     } 
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setPixels(Pixels paramPixels) {
/*  86 */     return false;
/*     */   }
/*     */   
/*     */   public boolean setEnabled(boolean paramBoolean) {
/*  90 */     if (this.parent != null) {
/*  91 */       return this.parent.enableItem(this, paramBoolean);
/*     */     }
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   public boolean setChecked(boolean paramBoolean) {
/*  97 */     if (this.parent != null) {
/*  98 */       return this.parent.checkItem(this, paramBoolean);
/*     */     }
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getTitle(String paramString, int paramInt1, int paramInt2) {
/* 108 */     if (paramInt1 == 0) {
/* 109 */       return paramString;
/*     */     }
/* 111 */     return paramString;
/*     */   }
/*     */   
/*     */   WinMenuImpl getParent() {
/* 115 */     return this.parent;
/*     */   }
/*     */ 
/*     */   
/*     */   void setParent(WinMenuImpl paramWinMenuImpl) {
/* 120 */     if (this.parent != null) {
/* 121 */       CommandIDManager.freeID(this.cmdID);
/* 122 */       this.cmdID = -1;
/*     */     } 
/* 124 */     if (paramWinMenuImpl != null) {
/* 125 */       this.cmdID = CommandIDManager.getID(this);
/*     */     }
/* 127 */     this.parent = paramWinMenuImpl;
/*     */   }
/*     */   
/*     */   int getCmdID() {
/* 131 */     return this.cmdID;
/*     */   }
/*     */   
/*     */   static class CommandIDManager
/*     */   {
/*     */     private static final int FIRST_ID = 1;
/*     */     private static final int LAST_ID = 65535;
/* 138 */     private static List<Integer> freeList = new ArrayList<>();
/*     */     
/* 140 */     private static final Map<Integer, WinMenuItemDelegate> map = new HashMap<>();
/*     */     
/* 142 */     private static int nextID = 1;
/*     */     
/*     */     public static synchronized int getID(WinMenuItemDelegate param1WinMenuItemDelegate) {
/*     */       Integer integer;
/* 146 */       if (freeList.isEmpty()) {
/* 147 */         if (nextID > 65535)
/*     */         {
/* 149 */           nextID = 1;
/*     */         }
/* 151 */         integer = Integer.valueOf(nextID);
/* 152 */         nextID++;
/*     */       } else {
/*     */         
/* 155 */         integer = freeList.remove(freeList.size() - 1);
/*     */       } 
/* 157 */       map.put(integer, param1WinMenuItemDelegate);
/* 158 */       return integer.intValue();
/*     */     }
/*     */     
/*     */     public static synchronized void freeID(int param1Int) {
/* 162 */       Integer integer = Integer.valueOf(param1Int);
/* 163 */       if (map.remove(integer) != null) {
/* 164 */         freeList.add(integer);
/*     */       }
/*     */     }
/*     */     
/*     */     public static WinMenuItemDelegate getHandler(int param1Int) {
/* 169 */       return map.get(Integer.valueOf(param1Int));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinMenuItemDelegate.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */