/*    */ package com.sun.glass.ui.win;
/*    */ 
/*    */ import com.sun.glass.ui.MenuBar;
/*    */ import com.sun.glass.ui.delegate.MenuBarDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WinMenuBarDelegate
/*    */   extends WinMenuImpl
/*    */   implements MenuBarDelegate
/*    */ {
/*    */   private final MenuBar owner;
/*    */   
/*    */   WinMenuBarDelegate(MenuBar paramMenuBar) {
/* 36 */     this.owner = paramMenuBar;
/*    */   }
/*    */   
/*    */   public MenuBar getOwner() {
/* 40 */     return this.owner;
/*    */   }
/*    */   
/*    */   public boolean createMenuBar() {
/* 44 */     return create();
/*    */   }
/*    */   
/*    */   public boolean insert(MenuDelegate paramMenuDelegate, int paramInt) {
/* 48 */     WinMenuDelegate winMenuDelegate = (WinMenuDelegate)paramMenuDelegate;
/* 49 */     if (winMenuDelegate.getParent() != null);
/*    */ 
/*    */     
/* 52 */     return insertSubmenu(winMenuDelegate, paramInt);
/*    */   }
/*    */   
/*    */   public boolean remove(MenuDelegate paramMenuDelegate, int paramInt) {
/* 56 */     WinMenuDelegate winMenuDelegate = (WinMenuDelegate)paramMenuDelegate;
/* 57 */     return removeMenu(winMenuDelegate, paramInt);
/*    */   }
/*    */   
/*    */   public long getNativeMenu() {
/* 61 */     return getHMENU();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinMenuBarDelegate.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */