/*    */ package com.sun.glass.ui.win;
/*    */ 
/*    */ import com.sun.glass.ui.Pixels;
/*    */ import com.sun.glass.ui.View;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WinView
/*    */   extends View
/*    */ {
/*    */   static {
/* 43 */     _initIDs();
/* 44 */   } private static final long multiClickTime = _getMultiClickTime_impl();
/* 45 */   private static final int multiClickMaxX = _getMultiClickMaxX_impl();
/* 46 */   private static final int multiClickMaxY = _getMultiClickMaxY_impl();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static long getMultiClickTime_impl() {
/* 62 */     return multiClickTime;
/*    */   }
/*    */   
/*    */   static int getMultiClickMaxX_impl() {
/* 66 */     return multiClickMaxX;
/*    */   }
/*    */   
/*    */   static int getMultiClickMaxY_impl() {
/* 70 */     return multiClickMaxY;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int _getNativeFrameBuffer(long paramLong) {
/* 75 */     return 0;
/*    */   }
/*    */   
/*    */   private static native void _initIDs();
/*    */   
/*    */   private static native long _getMultiClickTime_impl();
/*    */   
/*    */   private static native int _getMultiClickMaxX_impl();
/*    */   
/*    */   private static native int _getMultiClickMaxY_impl();
/*    */   
/*    */   protected native void _enableInputMethodEvents(long paramLong, boolean paramBoolean);
/*    */   
/*    */   protected native void _finishInputMethodComposition(long paramLong);
/*    */   
/*    */   protected native long _create(Map paramMap);
/*    */   
/*    */   protected native long _getNativeView(long paramLong);
/*    */   
/*    */   protected native int _getX(long paramLong);
/*    */   
/*    */   protected native int _getY(long paramLong);
/*    */   
/*    */   protected native void _setParent(long paramLong1, long paramLong2);
/*    */   
/*    */   protected native boolean _close(long paramLong);
/*    */   
/*    */   protected native void _scheduleRepaint(long paramLong);
/*    */   
/*    */   protected native void _begin(long paramLong);
/*    */   
/*    */   protected native void _end(long paramLong);
/*    */   
/*    */   protected native void _uploadPixels(long paramLong, Pixels paramPixels);
/*    */   
/*    */   protected native boolean _enterFullscreen(long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
/*    */   
/*    */   protected native void _exitFullscreen(long paramLong, boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */