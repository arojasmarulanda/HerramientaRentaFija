/*      */ package com.sun.glass.ui.win;
/*      */ 
/*      */ import com.sun.glass.ui.Accessible;
/*      */ import com.sun.glass.ui.View;
/*      */ import java.util.List;
/*      */ import java.util.function.Function;
/*      */ import java.util.stream.Collectors;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.geometry.Bounds;
/*      */ import javafx.geometry.Point2D;
/*      */ import javafx.scene.AccessibleAction;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.input.KeyCombination;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class WinAccessible
/*      */   extends Accessible
/*      */ {
/*      */   static {
/*   68 */     _initIDs();
/*      */   }
/*      */   
/*   71 */   private static int idCount = 1;
/*      */   
/*      */   private static final int UIA_BoundingRectanglePropertyId = 30001;
/*      */   
/*      */   private static final int UIA_ProcessIdPropertyId = 30002;
/*      */   
/*      */   private static final int UIA_ControlTypePropertyId = 30003;
/*      */   
/*      */   private static final int UIA_LocalizedControlTypePropertyId = 30004;
/*      */   
/*      */   private static final int UIA_NamePropertyId = 30005;
/*      */   
/*      */   private static final int UIA_AcceleratorKeyPropertyId = 30006;
/*      */   
/*      */   private static final int UIA_AccessKeyPropertyId = 30007;
/*      */   
/*      */   private static final int UIA_HasKeyboardFocusPropertyId = 30008;
/*      */   
/*      */   private static final int UIA_IsKeyboardFocusablePropertyId = 30009;
/*      */   
/*      */   private static final int UIA_IsEnabledPropertyId = 30010;
/*      */   
/*      */   private static final int UIA_AutomationIdPropertyId = 30011;
/*      */   
/*      */   private static final int UIA_ClassNamePropertyId = 30012;
/*      */   
/*      */   private static final int UIA_HelpTextPropertyId = 30013;
/*      */   
/*      */   private static final int UIA_ClickablePointPropertyId = 30014;
/*      */   
/*      */   private static final int UIA_CulturePropertyId = 30015;
/*      */   
/*      */   private static final int UIA_IsControlElementPropertyId = 30016;
/*      */   
/*      */   private static final int UIA_IsContentElementPropertyId = 30017;
/*      */   
/*      */   private static final int UIA_LabeledByPropertyId = 30018;
/*      */   
/*      */   private static final int UIA_IsPasswordPropertyId = 30019;
/*      */   
/*      */   private static final int UIA_NativeWindowHandlePropertyId = 30020;
/*      */   
/*      */   private static final int UIA_ItemTypePropertyId = 30021;
/*      */   
/*      */   private static final int UIA_IsOffscreenPropertyId = 30022;
/*      */   
/*      */   private static final int UIA_OrientationPropertyId = 30023;
/*      */   
/*      */   private static final int UIA_FrameworkIdPropertyId = 30024;
/*      */   
/*      */   private static final int UIA_ValueValuePropertyId = 30045;
/*      */   
/*      */   private static final int UIA_RangeValueValuePropertyId = 30047;
/*      */   
/*      */   private static final int UIA_ExpandCollapseExpandCollapseStatePropertyId = 30070;
/*      */   
/*      */   private static final int UIA_ToggleToggleStatePropertyId = 30086;
/*      */   
/*      */   private static final int UIA_AriaRolePropertyId = 30101;
/*      */   
/*      */   private static final int UIA_ProviderDescriptionPropertyId = 30107;
/*      */   
/*      */   private static final int UIA_InvokePatternId = 10000;
/*      */   
/*      */   private static final int UIA_SelectionPatternId = 10001;
/*      */   
/*      */   private static final int UIA_ValuePatternId = 10002;
/*      */   
/*      */   private static final int UIA_RangeValuePatternId = 10003;
/*      */   private static final int UIA_ScrollPatternId = 10004;
/*      */   private static final int UIA_ExpandCollapsePatternId = 10005;
/*      */   private static final int UIA_GridPatternId = 10006;
/*      */   private static final int UIA_GridItemPatternId = 10007;
/*      */   private static final int UIA_SelectionItemPatternId = 10010;
/*      */   private static final int UIA_TablePatternId = 10012;
/*      */   private static final int UIA_TableItemPatternId = 10013;
/*      */   private static final int UIA_TextPatternId = 10014;
/*      */   private static final int UIA_TogglePatternId = 10015;
/*      */   private static final int UIA_TransformPatternId = 10016;
/*      */   private static final int UIA_ScrollItemPatternId = 10017;
/*      */   private static final int UIA_ItemContainerPatternId = 10019;
/*      */   private static final int UIA_ButtonControlTypeId = 50000;
/*      */   private static final int UIA_CheckBoxControlTypeId = 50002;
/*      */   private static final int UIA_ComboBoxControlTypeId = 50003;
/*      */   private static final int UIA_EditControlTypeId = 50004;
/*      */   private static final int UIA_HyperlinkControlTypeId = 50005;
/*      */   private static final int UIA_ImageControlTypeId = 50006;
/*      */   private static final int UIA_ListItemControlTypeId = 50007;
/*      */   private static final int UIA_ListControlTypeId = 50008;
/*      */   private static final int UIA_MenuControlTypeId = 50009;
/*      */   private static final int UIA_MenuBarControlTypeId = 50010;
/*      */   private static final int UIA_MenuItemControlTypeId = 50011;
/*      */   private static final int UIA_ProgressBarControlTypeId = 50012;
/*      */   private static final int UIA_RadioButtonControlTypeId = 50013;
/*      */   private static final int UIA_ScrollBarControlTypeId = 50014;
/*      */   private static final int UIA_SliderControlTypeId = 50015;
/*      */   private static final int UIA_SpinnerControlTypeId = 50016;
/*      */   private static final int UIA_TabControlTypeId = 50018;
/*      */   private static final int UIA_TabItemControlTypeId = 50019;
/*      */   private static final int UIA_TextControlTypeId = 50020;
/*      */   private static final int UIA_ToolBarControlTypeId = 50021;
/*      */   private static final int UIA_TreeControlTypeId = 50023;
/*      */   private static final int UIA_TreeItemControlTypeId = 50024;
/*      */   private static final int UIA_GroupControlTypeId = 50026;
/*      */   private static final int UIA_ThumbControlTypeId = 50027;
/*      */   private static final int UIA_DataGridControlTypeId = 50028;
/*      */   private static final int UIA_DataItemControlTypeId = 50029;
/*      */   private static final int UIA_SplitButtonControlTypeId = 50031;
/*      */   private static final int UIA_WindowControlTypeId = 50032;
/*      */   private static final int UIA_PaneControlTypeId = 50033;
/*      */   private static final int UIA_TableControlTypeId = 50036;
/*      */   private static final int NavigateDirection_Parent = 0;
/*      */   private static final int NavigateDirection_NextSibling = 1;
/*      */   private static final int NavigateDirection_PreviousSibling = 2;
/*      */   private static final int NavigateDirection_FirstChild = 3;
/*      */   private static final int NavigateDirection_LastChild = 4;
/*      */   private static final int RowOrColumnMajor_RowMajor = 0;
/*      */   private static final int RowOrColumnMajor_ColumnMajor = 1;
/*      */   private static final int RowOrColumnMajor_Indeterminate = 2;
/*      */   private static final int UIA_MenuOpenedEventId = 20003;
/*      */   private static final int UIA_AutomationPropertyChangedEventId = 20004;
/*      */   private static final int UIA_AutomationFocusChangedEventId = 20005;
/*      */   private static final int UIA_MenuClosedEventId = 20007;
/*      */   private static final int UIA_SelectionItem_ElementRemovedFromSelectionEventId = 20011;
/*      */   private static final int UIA_SelectionItem_ElementSelectedEventId = 20012;
/*      */   private static final int UIA_Text_TextSelectionChangedEventId = 20014;
/*      */   private static final int UIA_Text_TextChangedEventId = 20015;
/*      */   private static final int UIA_MenuModeStartEventId = 20018;
/*      */   private static final int UIA_MenuModeEndEventId = 20019;
/*      */   private static final int SupportedTextSelection_None = 0;
/*      */   private static final int SupportedTextSelection_Single = 1;
/*      */   private static final int SupportedTextSelection_Multiple = 2;
/*      */   private static final int ExpandCollapseState_Collapsed = 0;
/*      */   private static final int ExpandCollapseState_Expanded = 1;
/*      */   private static final int ExpandCollapseState_PartiallyExpanded = 2;
/*      */   private static final int ExpandCollapseState_LeafNode = 3;
/*      */   private static final int ScrollAmount_LargeDecrement = 0;
/*      */   private static final int ScrollAmount_SmallDecrement = 1;
/*      */   private static final int ScrollAmount_NoAmount = 2;
/*      */   private static final int ScrollAmount_LargeIncrement = 3;
/*      */   private static final int ScrollAmount_SmallIncrement = 4;
/*      */   private static final int UIA_ScrollPatternNoScroll = -1;
/*      */   private static final int ToggleState_Off = 0;
/*      */   private static final int ToggleState_On = 1;
/*      */   private static final int ToggleState_Indeterminate = 2;
/*      */   private static final int UiaAppendRuntimeId = 3;
/*      */   private long peer;
/*      */   private int id;
/*      */   private WinTextRangeProvider documentRange;
/*      */   private WinTextRangeProvider selectionRange;
/*  221 */   private int lastIndex = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   WinAccessible() {
/*  234 */     this.peer = _createGlassAccessible();
/*  235 */     if (this.peer == 0L) {
/*  236 */       throw new RuntimeException("could not create platform accessible");
/*      */     }
/*  238 */     this.id = idCount++;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  243 */     super.dispose();
/*  244 */     if (this.selectionRange != null) {
/*  245 */       this.selectionRange.dispose();
/*  246 */       this.selectionRange = null;
/*      */     } 
/*  248 */     if (this.documentRange != null) {
/*  249 */       this.documentRange.dispose();
/*  250 */       this.documentRange = null;
/*      */     } 
/*  252 */     if (this.peer != 0L) {
/*  253 */       _destroyGlassAccessible(this.peer);
/*  254 */       this.peer = 0L;
/*      */     } 
/*      */   } public void sendNotification(AccessibleAttribute paramAccessibleAttribute) {
/*      */     Node node;
/*      */     Object object;
/*      */     long l;
/*      */     Boolean bool;
/*  261 */     if (isDisposed())
/*      */       return; 
/*  263 */     switch (paramAccessibleAttribute) {
/*      */       case TABLE_ROW:
/*  265 */         if (getView() != null) {
/*      */           
/*  267 */           long l1 = GetFocus();
/*  268 */           if (l1 != 0L) {
/*  269 */             UiaRaiseAutomationEvent(l1, 20005);
/*      */           }
/*      */         } else {
/*      */           
/*  273 */           Node node1 = (Node)getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/*  274 */           if (node1 != null) {
/*  275 */             UiaRaiseAutomationEvent(getNativeAccessible(node1), 20005);
/*      */           } else {
/*      */             
/*  278 */             Scene scene = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/*  279 */             Accessible accessible = getAccessible(scene);
/*  280 */             if (accessible != null) {
/*  281 */               accessible.sendNotification(AccessibleAttribute.FOCUS_NODE);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       
/*      */       case TABLE_CELL:
/*  287 */         node = (Node)getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/*  288 */         l = getNativeAccessible(node);
/*  289 */         if (l != 0L) {
/*  290 */           UiaRaiseAutomationEvent(l, 20005);
/*      */         }
/*      */ 
/*      */       
/*      */       case LIST_ITEM:
/*  295 */         if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.CHECK_BOX) {
/*  296 */           notifyToggleState();
/*      */         }
/*      */ 
/*      */       
/*      */       case TAB_ITEM:
/*  301 */         object = getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  302 */         if (object == AccessibleRole.CHECK_BOX || object == AccessibleRole.TOGGLE_BUTTON) {
/*  303 */           notifyToggleState();
/*      */         } else {
/*      */           
/*  306 */           Boolean bool1 = (Boolean)getAttribute(AccessibleAttribute.SELECTED, new Object[0]);
/*  307 */           if (bool1 != null) {
/*  308 */             if (bool1.booleanValue()) {
/*  309 */               UiaRaiseAutomationEvent(this.peer, 20012);
/*      */             } else {
/*  311 */               UiaRaiseAutomationEvent(this.peer, 20011);
/*      */             } 
/*      */           }
/*      */         } 
/*      */ 
/*      */       
/*      */       case PAGE_ITEM:
/*      */         return;
/*      */       
/*      */       case TREE_ITEM:
/*  321 */         object = getAttribute(AccessibleAttribute.VALUE, new Object[0]);
/*  322 */         if (object != null) {
/*  323 */           WinVariant winVariant1 = new WinVariant();
/*  324 */           winVariant1.vt = 5;
/*  325 */           winVariant1.dblVal = 0.0D;
/*  326 */           WinVariant winVariant2 = new WinVariant();
/*  327 */           winVariant2.vt = 5;
/*  328 */           winVariant2.dblVal = object.doubleValue();
/*  329 */           UiaRaiseAutomationPropertyChangedEvent(this.peer, 30047, winVariant1, winVariant2);
/*      */         } 
/*      */ 
/*      */       
/*      */       case TREE_TABLE_ROW:
/*      */       case TREE_TABLE_CELL:
/*  335 */         if (this.selectionRange != null) {
/*  336 */           object = getAttribute(AccessibleAttribute.SELECTION_START, new Object[0]);
/*  337 */           boolean bool1 = (object != null && object.intValue() != this.selectionRange.getStart()) ? true : false;
/*  338 */           Integer integer = (Integer)getAttribute(AccessibleAttribute.SELECTION_END, new Object[0]);
/*  339 */           boolean bool2 = (integer != null && integer.intValue() != this.selectionRange.getEnd()) ? true : false;
/*      */ 
/*      */ 
/*      */           
/*  343 */           if (bool1 || bool2) {
/*  344 */             UiaRaiseAutomationEvent(this.peer, 20014);
/*      */           }
/*      */         } 
/*      */       
/*      */       case CONTEXT_MENU:
/*  349 */         object = getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*  350 */         if (object != null) {
/*  351 */           WinVariant winVariant1 = new WinVariant();
/*  352 */           winVariant1.vt = 8;
/*  353 */           winVariant1.bstrVal = "";
/*  354 */           WinVariant winVariant2 = new WinVariant();
/*  355 */           winVariant2.vt = 8;
/*  356 */           winVariant2.bstrVal = (String)object;
/*  357 */           if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.SPINNER) {
/*  358 */             UiaRaiseAutomationPropertyChangedEvent(this.peer, 30005, winVariant1, winVariant2);
/*      */           } else {
/*      */             
/*  361 */             UiaRaiseAutomationPropertyChangedEvent(this.peer, 30045, winVariant1, winVariant2);
/*      */           } 
/*      */         } 
/*      */         
/*  365 */         if (this.selectionRange != null || this.documentRange != null) {
/*  366 */           UiaRaiseAutomationEvent(this.peer, 20015);
/*      */         }
/*      */       
/*      */       case RADIO_MENU_ITEM:
/*  370 */         bool = (Boolean)getAttribute(AccessibleAttribute.EXPANDED, new Object[0]);
/*  371 */         if (bool != null) {
/*  372 */           WinVariant winVariant1 = new WinVariant();
/*  373 */           winVariant1.vt = 3;
/*  374 */           winVariant1.lVal = bool.booleanValue() ? 0 : 1;
/*  375 */           WinVariant winVariant2 = new WinVariant();
/*  376 */           winVariant2.vt = 3;
/*  377 */           winVariant2.lVal = bool.booleanValue() ? 1 : 0;
/*  378 */           if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.TREE_TABLE_ROW) {
/*  379 */             Accessible accessible = getContainer();
/*  380 */             Integer integer = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/*  381 */             if (accessible != null && integer != null) {
/*  382 */               Node node1 = (Node)accessible.getAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, new Object[] { integer, Integer.valueOf(0) });
/*  383 */               if (node1 != null) {
/*  384 */                 long l1 = ((WinAccessible)getAccessible(node1)).getNativeAccessible();
/*  385 */                 UiaRaiseAutomationPropertyChangedEvent(l1, 30070, winVariant1, winVariant2);
/*      */               } 
/*      */             } 
/*      */           } else {
/*  389 */             UiaRaiseAutomationPropertyChangedEvent(this.peer, 30070, winVariant1, winVariant2);
/*      */           } 
/*      */         } 
/*      */       
/*      */       case CHECK_MENU_ITEM:
/*      */         return;
/*      */     } 
/*      */     
/*  397 */     UiaRaiseAutomationEvent(this.peer, 20004);
/*      */   }
/*      */ 
/*      */   
/*      */   private void notifyToggleState() {
/*  402 */     int i = get_ToggleState();
/*  403 */     WinVariant winVariant1 = new WinVariant();
/*  404 */     winVariant1.vt = 3;
/*  405 */     winVariant1.lVal = i;
/*  406 */     WinVariant winVariant2 = new WinVariant();
/*  407 */     winVariant2.vt = 3;
/*  408 */     winVariant2.lVal = i;
/*  409 */     UiaRaiseAutomationPropertyChangedEvent(this.peer, 30086, winVariant1, winVariant2);
/*      */   }
/*      */ 
/*      */   
/*      */   protected long getNativeAccessible() {
/*  414 */     return this.peer;
/*      */   }
/*      */   
/*      */   private Accessible getContainer() {
/*  418 */     if (isDisposed()) return null; 
/*  419 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  420 */     if (accessibleRole != null) {
/*  421 */       switch (accessibleRole) { case TABLE_ROW:
/*      */         case TABLE_CELL:
/*  423 */           return getContainerAccessible(AccessibleRole.TABLE_VIEW);
/*  424 */         case LIST_ITEM: return getContainerAccessible(AccessibleRole.LIST_VIEW);
/*  425 */         case TAB_ITEM: return getContainerAccessible(AccessibleRole.TAB_PANE);
/*  426 */         case PAGE_ITEM: return getContainerAccessible(AccessibleRole.PAGINATION);
/*  427 */         case TREE_ITEM: return getContainerAccessible(AccessibleRole.TREE_VIEW);
/*      */         case TREE_TABLE_ROW: case TREE_TABLE_CELL:
/*  429 */           return getContainerAccessible(AccessibleRole.TREE_TABLE_VIEW); }
/*      */ 
/*      */     
/*      */     }
/*  433 */     return null;
/*      */   }
/*      */   
/*      */   private int getControlType() {
/*  437 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  438 */     if (accessibleRole == null) return 50026; 
/*  439 */     switch (accessibleRole) { case CONTEXT_MENU:
/*  440 */         return 50009;
/*      */       case RADIO_MENU_ITEM: case CHECK_MENU_ITEM:
/*      */       case MENU:
/*      */       case MENU_ITEM:
/*  444 */         return 50011;
/*      */       case BUTTON: case MENU_BUTTON:
/*      */       case TOGGLE_BUTTON:
/*      */       case INCREMENT_BUTTON:
/*      */       case DECREMENT_BUTTON:
/*  449 */         return 50000;
/*  450 */       case SPLIT_MENU_BUTTON: return 50031;
/*      */       case PAGINATION: case TAB_PANE:
/*  452 */         return 50018;
/*      */       case TAB_ITEM: case PAGE_ITEM:
/*  454 */         return 50019;
/*  455 */       case SLIDER: return 50015;
/*  456 */       case PARENT: return (getView() != null) ? 50032 : 50033;
/*  457 */       case TEXT: return 50020;
/*      */       case TEXT_FIELD: case PASSWORD_FIELD:
/*      */       case TEXT_AREA:
/*  460 */         return 50004;
/*      */       case TREE_TABLE_VIEW: case TABLE_VIEW:
/*  462 */         return 50036;
/*  463 */       case LIST_VIEW: return 50008;
/*  464 */       case LIST_ITEM: return 50007;
/*      */       case TABLE_CELL: case TREE_TABLE_CELL:
/*  466 */         return 50029;
/*  467 */       case IMAGE_VIEW: return 50006;
/*  468 */       case RADIO_BUTTON: return 50013;
/*  469 */       case CHECK_BOX: return 50002;
/*  470 */       case COMBO_BOX: return 50003;
/*  471 */       case HYPERLINK: return 50005;
/*  472 */       case TREE_VIEW: return 50023;
/*  473 */       case TREE_ITEM: return 50024;
/*  474 */       case PROGRESS_INDICATOR: return 50012;
/*  475 */       case TOOL_BAR: return 50021;
/*  476 */       case TITLED_PANE: return 50026;
/*  477 */       case SCROLL_PANE: return 50033;
/*  478 */       case SCROLL_BAR: return 50014;
/*  479 */       case THUMB: return 50027;
/*  480 */       case MENU_BAR: return 50010;
/*  481 */       case DATE_PICKER: return 50033;
/*  482 */       case SPINNER: return 50016; }
/*  483 */      return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private List<Node> getUnignoredChildren(WinAccessible paramWinAccessible) {
/*  489 */     if (paramWinAccessible == null) return FXCollections.emptyObservableList();
/*      */ 
/*      */     
/*  492 */     ObservableList observableList = (ObservableList)paramWinAccessible.getAttribute(AccessibleAttribute.CHILDREN, new Object[0]);
/*  493 */     if (observableList == null) return FXCollections.emptyObservableList(); 
/*  494 */     return (List<Node>)observableList.stream()
/*  495 */       .filter(Node::isVisible)
/*  496 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */   
/*      */   private Accessible getRow() {
/*  501 */     Integer integer1 = (Integer)getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/*  502 */     if (integer1 == null) return null; 
/*  503 */     if (integer1.intValue() != 0) return null; 
/*  504 */     Integer integer2 = (Integer)getAttribute(AccessibleAttribute.ROW_INDEX, new Object[0]);
/*  505 */     if (integer2 == null) return null; 
/*  506 */     Accessible accessible = getContainer();
/*  507 */     if (accessible == null) return null; 
/*  508 */     Node node = (Node)accessible.getAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { integer2 });
/*  509 */     return getAccessible(node);
/*      */   }
/*      */   private void changeSelection(boolean paramBoolean1, boolean paramBoolean2) {
/*      */     Integer integer1, integer2;
/*  513 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  514 */     if (accessibleRole == null)
/*  515 */       return;  Accessible accessible = getContainer();
/*  516 */     if (accessible == null)
/*  517 */       return;  Node node = null;
/*  518 */     switch (accessibleRole) {
/*      */       case LIST_ITEM:
/*  520 */         integer1 = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/*  521 */         if (integer1 != null) {
/*  522 */           node = (Node)accessible.getAttribute(AccessibleAttribute.ITEM_AT_INDEX, new Object[] { integer1 });
/*      */         }
/*      */         break;
/*      */       
/*      */       case TREE_ITEM:
/*  527 */         integer1 = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/*  528 */         if (integer1 != null) {
/*  529 */           node = (Node)accessible.getAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { integer1 });
/*      */         }
/*      */         break;
/*      */       
/*      */       case TABLE_CELL:
/*      */       case TREE_TABLE_CELL:
/*  535 */         integer1 = (Integer)getAttribute(AccessibleAttribute.ROW_INDEX, new Object[0]);
/*  536 */         integer2 = (Integer)getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/*  537 */         if (integer1 != null && integer2 != null) {
/*  538 */           node = (Node)accessible.getAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, new Object[] { integer1, integer2 });
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  544 */     if (node != null) {
/*  545 */       ObservableList<?> observableList = FXCollections.observableArrayList();
/*  546 */       if (!paramBoolean2) {
/*      */         
/*  548 */         ObservableList<?> observableList1 = (ObservableList)accessible.getAttribute(AccessibleAttribute.SELECTED_ITEMS, new Object[0]);
/*  549 */         if (observableList1 != null) {
/*  550 */           observableList.addAll(observableList1);
/*      */         }
/*      */       } 
/*  553 */       if (paramBoolean1) {
/*  554 */         observableList.add(node);
/*      */       } else {
/*  556 */         observableList.remove(node);
/*      */       } 
/*  558 */       accessible.executeAction(AccessibleAction.SET_SELECTED_ITEMS, new Object[] { observableList });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long GetPatternProvider(int paramInt) {
/*  566 */     if (isDisposed()) return 0L; 
/*  567 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  568 */     boolean bool = false;
/*  569 */     switch (accessibleRole) {
/*      */       case MENU:
/*      */       case SPLIT_MENU_BUTTON:
/*  572 */         bool = (paramInt == 10000 || paramInt == 10005) ? true : false;
/*      */         break;
/*      */       
/*      */       case RADIO_MENU_ITEM:
/*      */       case CHECK_MENU_ITEM:
/*  577 */         bool = (paramInt == 10000 || paramInt == 10015) ? true : false;
/*      */         break;
/*      */       
/*      */       case MENU_ITEM:
/*      */       case BUTTON:
/*      */       case MENU_BUTTON:
/*      */       case INCREMENT_BUTTON:
/*      */       case DECREMENT_BUTTON:
/*      */       case HYPERLINK:
/*  586 */         bool = (paramInt == 10000) ? true : false;
/*      */         break;
/*      */       case TAB_ITEM:
/*      */       case PAGE_ITEM:
/*  590 */         bool = (paramInt == 10010) ? true : false;
/*      */         break;
/*      */       case PAGINATION:
/*      */       case TAB_PANE:
/*  594 */         bool = (paramInt == 10001) ? true : false;
/*      */         break;
/*      */       case SCROLL_PANE:
/*  597 */         bool = (paramInt == 10004) ? true : false;
/*      */         break;
/*      */       case TREE_TABLE_VIEW:
/*      */       case TABLE_VIEW:
/*  601 */         bool = (paramInt == 10001 || paramInt == 10006 || paramInt == 10012 || paramInt == 10004) ? true : false;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case TREE_TABLE_CELL:
/*  607 */         bool = (paramInt == 10010 || paramInt == 10007 || paramInt == 10013 || paramInt == 10005 || paramInt == 10017) ? true : false;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case TABLE_CELL:
/*  614 */         bool = (paramInt == 10010 || paramInt == 10007 || paramInt == 10013 || paramInt == 10017) ? true : false;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case TREE_VIEW:
/*  620 */         bool = (paramInt == 10001 || paramInt == 10004) ? true : false;
/*      */         break;
/*      */       
/*      */       case TREE_ITEM:
/*  624 */         bool = (paramInt == 10010 || paramInt == 10005 || paramInt == 10017) ? true : false;
/*      */         break;
/*      */ 
/*      */       
/*      */       case LIST_VIEW:
/*  629 */         bool = (paramInt == 10001 || paramInt == 10004) ? true : false;
/*      */         break;
/*      */       
/*      */       case LIST_ITEM:
/*  633 */         bool = (paramInt == 10010 || paramInt == 10017) ? true : false;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case TEXT_FIELD:
/*      */       case TEXT_AREA:
/*  649 */         bool = (paramInt == 10014 || paramInt == 10002) ? true : false;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case RADIO_BUTTON:
/*  656 */         bool = (paramInt == 10010) ? true : false;
/*      */         break;
/*      */       case TOGGLE_BUTTON:
/*      */       case CHECK_BOX:
/*  660 */         bool = (paramInt == 10015) ? true : false;
/*      */         break;
/*      */       case TOOL_BAR:
/*      */       case TITLED_PANE:
/*  664 */         bool = (paramInt == 10005) ? true : false;
/*      */         break;
/*      */       case COMBO_BOX:
/*  667 */         bool = (paramInt == 10005 || paramInt == 10002) ? true : false;
/*      */         break;
/*      */       
/*      */       case SLIDER:
/*      */       case PROGRESS_INDICATOR:
/*      */       case SCROLL_BAR:
/*  673 */         bool = (paramInt == 10003) ? true : false;
/*      */         break;
/*      */     } 
/*      */     
/*  677 */     return bool ? getNativeAccessible() : 0L;
/*      */   }
/*      */   
/*      */   private long get_HostRawElementProvider() {
/*  681 */     if (isDisposed()) return 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  686 */     View view = getView();
/*  687 */     return (view != null) ? view.getNativeView() : 0L; } private WinVariant GetPropertyValue(int paramInt) { int i; String str2; KeyCombination keyCombination;
/*      */     String str1;
/*      */     Boolean bool;
/*      */     AccessibleRole accessibleRole1, accessibleRole2;
/*  691 */     if (isDisposed()) return null; 
/*  692 */     WinVariant winVariant = null;
/*  693 */     switch (paramInt) {
/*      */       case 30003:
/*  695 */         i = getControlType();
/*  696 */         if (i != 0) {
/*  697 */           winVariant = new WinVariant();
/*  698 */           winVariant.vt = 3;
/*  699 */           winVariant.lVal = i;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 30007:
/*  704 */         str2 = (String)getAttribute(AccessibleAttribute.MNEMONIC, new Object[0]);
/*  705 */         if (str2 != null) {
/*  706 */           winVariant = new WinVariant();
/*  707 */           winVariant.vt = 8;
/*  708 */           winVariant.bstrVal = "Alt+" + str2.toLowerCase();
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 30006:
/*  713 */         keyCombination = (KeyCombination)getAttribute(AccessibleAttribute.ACCELERATOR, new Object[0]);
/*  714 */         if (keyCombination != null) {
/*  715 */           winVariant = new WinVariant();
/*  716 */           winVariant.vt = 8;
/*      */ 
/*      */ 
/*      */           
/*  720 */           winVariant.bstrVal = keyCombination.toString().replaceAll("Shortcut", "Ctrl");
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 30005:
/*  727 */         accessibleRole2 = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  728 */         if (accessibleRole2 == null) accessibleRole2 = AccessibleRole.NODE; 
/*  729 */         switch (accessibleRole2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case TEXT_FIELD:
/*      */           case TEXT_AREA:
/*      */           case COMBO_BOX:
/*  738 */             keyCombination = null;
/*      */             break;
/*      */           case INCREMENT_BUTTON:
/*      */           case DECREMENT_BUTTON:
/*  742 */             str1 = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*  743 */             if (str1 == null || str1.length() == 0) {
/*  744 */               if (accessibleRole2 == AccessibleRole.INCREMENT_BUTTON) {
/*  745 */                 str1 = "increment"; break;
/*      */               } 
/*  747 */               str1 = "decrement";
/*      */             } 
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  753 */             str1 = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*      */             break;
/*      */         } 
/*  756 */         if (str1 == null || str1.length() == 0) {
/*  757 */           Node node = (Node)getAttribute(AccessibleAttribute.LABELED_BY, new Object[0]);
/*  758 */           if (node != null) {
/*  759 */             str1 = (String)getAccessible(node).getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*      */           }
/*      */         } 
/*  762 */         if (str1 == null || str1.length() == 0) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  771 */         winVariant = new WinVariant();
/*  772 */         winVariant.vt = 8;
/*  773 */         winVariant.bstrVal = str1;
/*      */         break;
/*      */       
/*      */       case 30013:
/*  777 */         str1 = (String)getAttribute(AccessibleAttribute.HELP, new Object[0]);
/*  778 */         if (str1 != null) {
/*  779 */           winVariant = new WinVariant();
/*  780 */           winVariant.vt = 8;
/*  781 */           winVariant.bstrVal = str1;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 30004:
/*  786 */         str1 = (String)getAttribute(AccessibleAttribute.ROLE_DESCRIPTION, new Object[0]);
/*  787 */         if (str1 == null) {
/*  788 */           accessibleRole2 = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  789 */           if (accessibleRole2 == null) accessibleRole2 = AccessibleRole.NODE; 
/*  790 */           switch (accessibleRole2) { case TITLED_PANE:
/*  791 */               str1 = "title pane"; break;
/*  792 */             case PAGE_ITEM: str1 = "page";
/*      */               break; }
/*      */         
/*      */         } 
/*  796 */         if (str1 != null) {
/*  797 */           winVariant = new WinVariant();
/*  798 */           winVariant.vt = 8;
/*  799 */           winVariant.bstrVal = str1;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 30008:
/*  804 */         bool = (Boolean)getAttribute(AccessibleAttribute.FOCUSED, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  812 */         if (Boolean.FALSE.equals(bool)) {
/*  813 */           Scene scene = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/*  814 */           if (scene != null) {
/*  815 */             Accessible accessible = getAccessible(scene);
/*  816 */             if (accessible != null) {
/*  817 */               Node node = (Node)accessible.getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/*  818 */               if (node != null) {
/*  819 */                 Node node1 = (Node)getAccessible(node).getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/*  820 */                 if (getNativeAccessible(node1) == this.peer) {
/*  821 */                   bool = Boolean.valueOf(true);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*  827 */         winVariant = new WinVariant();
/*  828 */         winVariant.vt = 11;
/*  829 */         winVariant.boolVal = (bool != null) ? bool.booleanValue() : false;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 30016:
/*      */       case 30017:
/*  835 */         winVariant = new WinVariant();
/*  836 */         winVariant.vt = 11;
/*  837 */         winVariant.boolVal = (getView() != null || !isIgnored());
/*      */         break;
/*      */       
/*      */       case 30010:
/*  841 */         bool = (Boolean)getAttribute(AccessibleAttribute.DISABLED, new Object[0]);
/*  842 */         winVariant = new WinVariant();
/*  843 */         winVariant.vt = 11;
/*  844 */         winVariant.boolVal = (bool != null) ? (!bool.booleanValue()) : true;
/*      */         break;
/*      */       
/*      */       case 30009:
/*  848 */         winVariant = new WinVariant();
/*  849 */         winVariant.vt = 11;
/*  850 */         winVariant.boolVal = true;
/*      */         break;
/*      */       
/*      */       case 30019:
/*  854 */         accessibleRole1 = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  855 */         winVariant = new WinVariant();
/*  856 */         winVariant.vt = 11;
/*  857 */         winVariant.boolVal = (accessibleRole1 == AccessibleRole.PASSWORD_FIELD);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 30011:
/*  862 */         winVariant = new WinVariant();
/*  863 */         winVariant.vt = 8;
/*  864 */         winVariant.bstrVal = "JavaFX" + this.id;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 30107:
/*  869 */         winVariant = new WinVariant();
/*  870 */         winVariant.vt = 8;
/*  871 */         winVariant.bstrVal = "JavaFXProvider";
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  876 */     return winVariant; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float[] get_BoundingRectangle() {
/*  883 */     if (isDisposed()) return null;
/*      */     
/*  885 */     if (getView() != null) return null;
/*      */     
/*  887 */     Bounds bounds = (Bounds)getAttribute(AccessibleAttribute.BOUNDS, new Object[0]);
/*  888 */     if (bounds != null) {
/*  889 */       return new float[] { (float)bounds.getMinX(), (float)bounds.getMinY(), 
/*  890 */           (float)bounds.getWidth(), (float)bounds.getHeight() };
/*      */     }
/*  892 */     return null;
/*      */   }
/*      */   
/*      */   private long get_FragmentRoot() {
/*  896 */     if (isDisposed()) return 0L; 
/*  897 */     Scene scene = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/*  898 */     if (scene == null) return 0L; 
/*  899 */     WinAccessible winAccessible = (WinAccessible)getAccessible(scene);
/*  900 */     if (winAccessible == null || winAccessible.isDisposed()) return 0L; 
/*  901 */     return winAccessible.getNativeAccessible();
/*      */   }
/*      */   
/*      */   private long[] GetEmbeddedFragmentRoots() {
/*  905 */     if (isDisposed()) return null; 
/*  906 */     return null;
/*      */   }
/*      */   
/*      */   private int[] GetRuntimeId() {
/*  910 */     if (isDisposed()) return null;
/*      */ 
/*      */     
/*  913 */     if (getView() != null) return null; 
/*  914 */     return new int[] { 3, this.id };
/*      */   }
/*      */   private long NavigateListView(WinAccessible paramWinAccessible, int paramInt) {
/*      */     Integer integer3, integer4;
/*  918 */     Accessible accessible = paramWinAccessible.getContainer();
/*  919 */     if (accessible == null) return 0L; 
/*  920 */     Integer integer1 = (Integer)accessible.getAttribute(AccessibleAttribute.ITEM_COUNT, new Object[0]);
/*  921 */     if (integer1 == null || integer1.intValue() == 0) return 0L; 
/*  922 */     Integer integer2 = (Integer)paramWinAccessible.getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/*  923 */     if (integer2 == null) return 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  930 */     if (0 > integer2.intValue() || integer2.intValue() >= integer1.intValue()) return 0L; 
/*  931 */     switch (paramInt) { case 1:
/*  932 */         integer3 = integer2; integer4 = integer2 = Integer.valueOf(integer2.intValue() + 1); break;
/*  933 */       case 2: integer3 = integer2; integer4 = integer2 = Integer.valueOf(integer2.intValue() - 1); break;
/*  934 */       case 3: integer2 = Integer.valueOf(0); break;
/*  935 */       case 4: integer2 = Integer.valueOf(integer1.intValue() - 1); break; }
/*      */     
/*  937 */     if (0 > integer2.intValue() || integer2.intValue() >= integer1.intValue()) return 0L; 
/*  938 */     Node node = (Node)accessible.getAttribute(AccessibleAttribute.ITEM_AT_INDEX, new Object[] { integer2 });
/*  939 */     return getNativeAccessible(node);
/*      */   } private long Navigate(int paramInt) {
/*      */     Node node2;
/*      */     List<Node> list;
/*  943 */     if (isDisposed()) return 0L; 
/*  944 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*      */     
/*  946 */     boolean bool = (accessibleRole == AccessibleRole.TREE_ITEM) ? true : false;
/*  947 */     Node node1 = null;
/*  948 */     switch (paramInt) {
/*      */       
/*      */       case 0:
/*  951 */         if (getView() != null) return 0L;
/*      */         
/*  953 */         if (bool) {
/*  954 */           node1 = (Node)getAttribute(AccessibleAttribute.TREE_ITEM_PARENT, new Object[0]);
/*  955 */           if (node1 == null) {
/*      */             
/*  957 */             WinAccessible winAccessible = (WinAccessible)getContainer();
/*  958 */             return (winAccessible != null) ? winAccessible.getNativeAccessible() : 0L;
/*      */           }  break;
/*      */         } 
/*  961 */         node1 = (Node)getAttribute(AccessibleAttribute.PARENT, new Object[0]);
/*  962 */         if (node1 == null) {
/*      */           
/*  964 */           Scene scene = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/*  965 */           WinAccessible winAccessible = (WinAccessible)getAccessible(scene);
/*      */           
/*  967 */           if (winAccessible == null || winAccessible == this || winAccessible.isDisposed()) return 0L; 
/*  968 */           return winAccessible.getNativeAccessible();
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 2:
/*  975 */         if (accessibleRole == AccessibleRole.LIST_ITEM) {
/*  976 */           return NavigateListView(this, paramInt);
/*      */         }
/*      */         
/*  979 */         node2 = (Node)getAttribute(bool ? AccessibleAttribute.TREE_ITEM_PARENT : AccessibleAttribute.PARENT, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  984 */         if (node2 != null) {
/*  985 */           Function<Integer, Node> function; WinAccessible winAccessible = (WinAccessible)getAccessible(node2);
/*      */           
/*  987 */           int i = 0;
/*  988 */           if (bool) {
/*  989 */             Integer integer = (Integer)winAccessible.getAttribute(AccessibleAttribute.TREE_ITEM_COUNT, new Object[0]);
/*  990 */             if (integer == null) return 0L; 
/*  991 */             i = integer.intValue();
/*  992 */             function = (paramInteger -> (Node)paramWinAccessible.getAttribute(AccessibleAttribute.TREE_ITEM_AT_INDEX, new Object[] { paramInteger }));
/*      */           }
/*      */           else {
/*      */             
/*  996 */             List<Node> list1 = getUnignoredChildren(winAccessible);
/*  997 */             if (list1 == null) return 0L; 
/*  998 */             i = list1.size();
/*  999 */             function = (paramInteger -> (Node)paramList.get(paramInteger.intValue()));
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1004 */           int j = winAccessible.lastIndex;
/* 1005 */           int k = -1;
/* 1006 */           if (0 <= j && j < i && getNativeAccessible(function.apply(Integer.valueOf(j))) == this.peer) {
/* 1007 */             k = j;
/*      */           } else {
/* 1009 */             for (byte b = 0; b < i; b++) {
/* 1010 */               if (getNativeAccessible(function.apply(Integer.valueOf(b))) == this.peer) {
/* 1011 */                 k = b;
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           } 
/* 1016 */           if (k != -1) {
/* 1017 */             if (paramInt == 1) {
/* 1018 */               k++;
/*      */             } else {
/* 1020 */               k--;
/*      */             } 
/* 1022 */             if (0 <= k && k < i) {
/* 1023 */               node1 = function.apply(Integer.valueOf(k));
/* 1024 */               winAccessible.lastIndex = k;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 3:
/*      */       case 4:
/* 1032 */         this.lastIndex = -1;
/* 1033 */         if (accessibleRole == AccessibleRole.LIST_VIEW)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1040 */           getAttribute(AccessibleAttribute.ITEM_AT_INDEX, new Object[] { Integer.valueOf(0) });
/*      */         }
/* 1042 */         if (accessibleRole == AccessibleRole.TREE_VIEW) {
/*      */           
/* 1044 */           this.lastIndex = 0;
/* 1045 */           node1 = (Node)getAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { Integer.valueOf(0) }); break;
/* 1046 */         }  if (bool) {
/* 1047 */           Integer integer = (Integer)getAttribute(AccessibleAttribute.TREE_ITEM_COUNT, new Object[0]);
/* 1048 */           if (integer != null && integer.intValue() > 0) {
/* 1049 */             this.lastIndex = (paramInt == 3) ? 0 : (integer.intValue() - 1);
/* 1050 */             node1 = (Node)getAttribute(AccessibleAttribute.TREE_ITEM_AT_INDEX, new Object[] { Integer.valueOf(this.lastIndex) });
/*      */           }  break;
/*      */         } 
/* 1053 */         list = getUnignoredChildren(this);
/* 1054 */         if (list != null && list.size() > 0) {
/* 1055 */           this.lastIndex = (paramInt == 3) ? 0 : (list.size() - 1);
/* 1056 */           node1 = list.get(this.lastIndex);
/*      */         } 
/* 1058 */         if (node1 != null) {
/* 1059 */           accessibleRole = (AccessibleRole)getAccessible(node1).getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1060 */           if (accessibleRole == AccessibleRole.LIST_ITEM) {
/* 1061 */             WinAccessible winAccessible = (WinAccessible)getAccessible(node1);
/* 1062 */             return NavigateListView(winAccessible, paramInt);
/*      */           } 
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1069 */     return getNativeAccessible(node1);
/*      */   }
/*      */   
/*      */   private void SetFocus() {
/* 1073 */     if (isDisposed())
/* 1074 */       return;  executeAction(AccessibleAction.REQUEST_FOCUS, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long ElementProviderFromPoint(double paramDouble1, double paramDouble2) {
/* 1081 */     if (isDisposed()) return 0L; 
/* 1082 */     Node node = (Node)getAttribute(AccessibleAttribute.NODE_AT_POINT, new Object[] { new Point2D(paramDouble1, paramDouble2) });
/* 1083 */     return getNativeAccessible(node);
/*      */   }
/*      */   
/*      */   private long GetFocus() {
/* 1087 */     if (isDisposed()) return 0L; 
/* 1088 */     Node node1 = (Node)getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/* 1089 */     if (node1 == null) return 0L; 
/* 1090 */     Node node2 = (Node)getAccessible(node1).getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/* 1091 */     if (node2 != null) return getNativeAccessible(node2); 
/* 1092 */     return getNativeAccessible(node1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void AdviseEventAdded(int paramInt, long paramLong) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void AdviseEventRemoved(int paramInt, long paramLong) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void Invoke() {
/* 1113 */     if (isDisposed())
/* 1114 */       return;  executeAction(AccessibleAction.FIRE, new Object[0]);
/*      */   } private long[] GetSelection() {
/*      */     ObservableList observableList;
/*      */     Node node;
/*      */     Integer integer;
/*      */     byte b;
/*      */     byte b1, b2;
/* 1121 */     if (isDisposed()) return null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1127 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1128 */     if (accessibleRole == null) return null; 
/* 1129 */     switch (accessibleRole) {
/*      */       
/*      */       case TREE_TABLE_VIEW:
/*      */       case TABLE_VIEW:
/*      */       case LIST_VIEW:
/*      */       case TREE_VIEW:
/* 1135 */         observableList = (ObservableList)getAttribute(AccessibleAttribute.SELECTED_ITEMS, new Object[0]);
/* 1136 */         if (observableList != null) {
/* 1137 */           return observableList.stream().mapToLong(paramNode -> getNativeAccessible(paramNode)).toArray();
/*      */         }
/*      */         break;
/*      */       
/*      */       case PAGINATION:
/*      */       case TAB_PANE:
/* 1143 */         node = (Node)getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/* 1144 */         if (node != null) {
/* 1145 */           return new long[] { getNativeAccessible(node) };
/*      */         }
/*      */         break;
/*      */       
/*      */       case TEXT_FIELD:
/*      */       case TEXT_AREA:
/* 1151 */         if (this.selectionRange == null) {
/* 1152 */           this.selectionRange = new WinTextRangeProvider(this);
/*      */         }
/* 1154 */         integer = (Integer)getAttribute(AccessibleAttribute.SELECTION_START, new Object[0]);
/* 1155 */         b = (integer != null) ? integer.intValue() : 0;
/* 1156 */         b1 = -1;
/* 1157 */         b2 = -1;
/* 1158 */         if (b) {
/* 1159 */           integer = (Integer)getAttribute(AccessibleAttribute.SELECTION_END, new Object[0]);
/* 1160 */           b1 = (integer != null) ? integer.intValue() : 0;
/* 1161 */           if (b1 >= b) {
/* 1162 */             String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 1163 */             b2 = (str != null) ? str.length() : 0;
/*      */           } 
/*      */         } 
/* 1166 */         if (b2 != -1 && b1 <= b2) {
/* 1167 */           this.selectionRange.setRange(b, b1);
/*      */         } else {
/* 1169 */           this.selectionRange.setRange(0, 0);
/*      */         } 
/* 1171 */         return new long[] { this.selectionRange.getNativeProvider() };
/*      */     } 
/*      */ 
/*      */     
/* 1175 */     return null;
/*      */   }
/*      */   
/*      */   private boolean get_CanSelectMultiple() {
/* 1179 */     if (isDisposed()) return false; 
/* 1180 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1181 */     if (accessibleRole != null) {
/* 1182 */       switch (accessibleRole) {
/*      */         case TREE_TABLE_VIEW:
/*      */         case TABLE_VIEW:
/*      */         case LIST_VIEW:
/*      */         case TREE_VIEW:
/* 1187 */           return Boolean.TRUE.equals(getAttribute(AccessibleAttribute.MULTIPLE_SELECTION, new Object[0]));
/*      */       } 
/*      */     
/*      */     }
/* 1191 */     return false;
/*      */   }
/*      */   
/*      */   private boolean get_IsSelectionRequired() {
/* 1195 */     if (isDisposed()) return false;
/*      */     
/* 1197 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void SetValue(double paramDouble) {
/* 1204 */     if (isDisposed())
/* 1205 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1206 */     if (accessibleRole != null) {
/* 1207 */       switch (accessibleRole) {
/*      */         case SLIDER:
/*      */         case SCROLL_BAR:
/* 1210 */           executeAction(AccessibleAction.SET_VALUE, new Object[] { Double.valueOf(paramDouble) });
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private double get_Value() {
/* 1218 */     if (isDisposed()) return 0.0D; 
/* 1219 */     if (Boolean.TRUE.equals(getAttribute(AccessibleAttribute.INDETERMINATE, new Object[0]))) return 0.0D; 
/* 1220 */     Double double_ = (Double)getAttribute(AccessibleAttribute.VALUE, new Object[0]);
/* 1221 */     return (double_ != null) ? double_.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean get_IsReadOnly() {
/* 1228 */     if (isDisposed()) return false; 
/* 1229 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1230 */     if (accessibleRole != null) {
/* 1231 */       switch (accessibleRole) { case SLIDER:
/* 1232 */           return false;
/* 1233 */         case SCROLL_BAR: return true;
/*      */         case TEXT_FIELD: case TEXT_AREA:
/*      */         case COMBO_BOX:
/* 1236 */           return Boolean.FALSE.equals(getAttribute(AccessibleAttribute.EDITABLE, new Object[0])); }
/*      */ 
/*      */     
/*      */     }
/* 1240 */     return true;
/*      */   }
/*      */   
/*      */   private double get_Maximum() {
/* 1244 */     if (isDisposed()) return 0.0D; 
/* 1245 */     Double double_ = (Double)getAttribute(AccessibleAttribute.MAX_VALUE, new Object[0]);
/* 1246 */     return (double_ != null) ? double_.doubleValue() : 0.0D;
/*      */   }
/*      */   
/*      */   private double get_Minimum() {
/* 1250 */     if (isDisposed()) return 0.0D; 
/* 1251 */     Double double_ = (Double)getAttribute(AccessibleAttribute.MIN_VALUE, new Object[0]);
/* 1252 */     return (double_ != null) ? double_.doubleValue() : 0.0D;
/*      */   }
/*      */   
/*      */   private double get_LargeChange() {
/* 1256 */     if (isDisposed()) return 0.0D; 
/* 1257 */     return 10.0D;
/*      */   }
/*      */   
/*      */   private double get_SmallChange() {
/* 1261 */     if (isDisposed()) return 0.0D; 
/* 1262 */     return 3.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void SetValueString(String paramString) {
/* 1269 */     if (isDisposed())
/* 1270 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1271 */     if (accessibleRole != null) {
/* 1272 */       switch (accessibleRole) {
/*      */         case TEXT_FIELD:
/*      */         case TEXT_AREA:
/* 1275 */           executeAction(AccessibleAction.SET_TEXT, new Object[] { paramString });
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private String get_ValueString() {
/* 1283 */     if (isDisposed()) return null; 
/* 1284 */     return (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void Select() {
/* 1291 */     if (isDisposed())
/* 1292 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1293 */     if (accessibleRole != null) {
/* 1294 */       switch (accessibleRole) {
/*      */         case TAB_ITEM:
/*      */         case PAGE_ITEM:
/* 1297 */           executeAction(AccessibleAction.REQUEST_FOCUS, new Object[0]);
/*      */           break;
/*      */         case BUTTON:
/*      */         case TOGGLE_BUTTON:
/*      */         case INCREMENT_BUTTON:
/*      */         case DECREMENT_BUTTON:
/*      */         case RADIO_BUTTON:
/* 1304 */           executeAction(AccessibleAction.FIRE, new Object[0]);
/*      */           break;
/*      */         case TABLE_CELL:
/*      */         case LIST_ITEM:
/*      */         case TREE_ITEM:
/*      */         case TREE_TABLE_CELL:
/* 1310 */           changeSelection(true, true);
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void AddToSelection() {
/* 1318 */     if (isDisposed())
/* 1319 */       return;  changeSelection(true, false);
/*      */   }
/*      */   
/*      */   private void RemoveFromSelection() {
/* 1323 */     if (isDisposed())
/* 1324 */       return;  changeSelection(false, false);
/*      */   }
/*      */   
/*      */   private boolean get_IsSelected() {
/* 1328 */     if (isDisposed()) return false; 
/* 1329 */     return Boolean.TRUE.equals(getAttribute(AccessibleAttribute.SELECTED, new Object[0]));
/*      */   }
/*      */   
/*      */   private long get_SelectionContainer() {
/* 1333 */     if (isDisposed()) return 0L; 
/* 1334 */     WinAccessible winAccessible = (WinAccessible)getContainer();
/* 1335 */     return (winAccessible != null) ? winAccessible.getNativeAccessible() : 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long[] GetVisibleRanges() {
/* 1342 */     if (isDisposed()) return null; 
/* 1343 */     return new long[] { get_DocumentRange() };
/*      */   }
/*      */   
/*      */   private long RangeFromChild(long paramLong) {
/* 1347 */     if (isDisposed()) return 0L; 
/* 1348 */     return 0L;
/*      */   }
/*      */   
/*      */   private long RangeFromPoint(double paramDouble1, double paramDouble2) {
/* 1352 */     if (isDisposed()) return 0L; 
/* 1353 */     Integer integer = (Integer)getAttribute(AccessibleAttribute.OFFSET_AT_POINT, new Object[] { new Point2D(paramDouble1, paramDouble2) });
/* 1354 */     if (integer != null) {
/* 1355 */       WinTextRangeProvider winTextRangeProvider = new WinTextRangeProvider(this);
/* 1356 */       winTextRangeProvider.setRange(integer.intValue(), integer.intValue());
/* 1357 */       return winTextRangeProvider.getNativeProvider();
/*      */     } 
/* 1359 */     return 0L;
/*      */   }
/*      */   
/*      */   private long get_DocumentRange() {
/* 1363 */     if (isDisposed()) return 0L; 
/* 1364 */     if (this.documentRange == null) {
/* 1365 */       this.documentRange = new WinTextRangeProvider(this);
/*      */     }
/* 1367 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 1368 */     if (str == null) return 0L; 
/* 1369 */     this.documentRange.setRange(0, str.length());
/* 1370 */     return this.documentRange.getNativeProvider();
/*      */   }
/*      */   
/*      */   private int get_SupportedTextSelection() {
/* 1374 */     if (isDisposed()) return 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1379 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int get_ColumnCount() {
/* 1386 */     if (isDisposed()) return 0; 
/* 1387 */     Integer integer = (Integer)getAttribute(AccessibleAttribute.COLUMN_COUNT, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1393 */     return (integer != null) ? integer.intValue() : 1;
/*      */   }
/*      */   
/*      */   private int get_RowCount() {
/* 1397 */     if (isDisposed()) return 0; 
/* 1398 */     Integer integer = (Integer)getAttribute(AccessibleAttribute.ROW_COUNT, new Object[0]);
/* 1399 */     return (integer != null) ? integer.intValue() : 0;
/*      */   }
/*      */   
/*      */   private long GetItem(int paramInt1, int paramInt2) {
/* 1403 */     if (isDisposed()) return 0L; 
/* 1404 */     Node node = (Node)getAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/* 1405 */     return getNativeAccessible(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int get_Column() {
/* 1412 */     if (isDisposed()) return 0; 
/* 1413 */     Integer integer = (Integer)getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/* 1414 */     return (integer != null) ? integer.intValue() : 0;
/*      */   }
/*      */   
/*      */   private int get_ColumnSpan() {
/* 1418 */     if (isDisposed()) return 0; 
/* 1419 */     return 1;
/*      */   }
/*      */   
/*      */   private long get_ContainingGrid() {
/* 1423 */     if (isDisposed()) return 0L; 
/* 1424 */     WinAccessible winAccessible = (WinAccessible)getContainer();
/* 1425 */     return (winAccessible != null) ? winAccessible.getNativeAccessible() : 0L;
/*      */   }
/*      */   
/*      */   private int get_Row() {
/* 1429 */     if (isDisposed()) return 0; 
/* 1430 */     Integer integer = null;
/* 1431 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1432 */     if (accessibleRole != null) {
/* 1433 */       switch (accessibleRole) { case TABLE_ROW:
/*      */         case LIST_ITEM:
/*      */         case TREE_TABLE_ROW:
/* 1436 */           integer = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]); break;
/*      */         case TABLE_CELL: case TREE_TABLE_CELL:
/* 1438 */           integer = (Integer)getAttribute(AccessibleAttribute.ROW_INDEX, new Object[0]);
/*      */           break; }
/*      */     
/*      */     }
/* 1442 */     return (integer != null) ? integer.intValue() : 0;
/*      */   }
/*      */   
/*      */   private int get_RowSpan() {
/* 1446 */     if (isDisposed()) return 0; 
/* 1447 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long[] GetColumnHeaders() {
/* 1454 */     if (isDisposed()) return null;
/*      */     
/* 1456 */     return null;
/*      */   }
/*      */   
/*      */   private long[] GetRowHeaders() {
/* 1460 */     if (isDisposed()) return null;
/*      */     
/* 1462 */     return null;
/*      */   }
/*      */   
/*      */   private int get_RowOrColumnMajor() {
/* 1466 */     if (isDisposed()) return 0; 
/* 1467 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long[] GetColumnHeaderItems() {
/* 1474 */     if (isDisposed()) return null; 
/* 1475 */     Integer integer = (Integer)getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/* 1476 */     if (integer == null) return null; 
/* 1477 */     Accessible accessible = getContainer();
/* 1478 */     if (accessible == null) return null; 
/* 1479 */     Node node = (Node)accessible.getAttribute(AccessibleAttribute.COLUMN_AT_INDEX, new Object[] { integer });
/* 1480 */     if (node == null) return null; 
/* 1481 */     return new long[] { getNativeAccessible(node) };
/*      */   }
/*      */   
/*      */   private long[] GetRowHeaderItems() {
/* 1485 */     if (isDisposed()) return null;
/*      */     
/* 1487 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void Toggle() {
/* 1494 */     if (isDisposed())
/* 1495 */       return;  executeAction(AccessibleAction.FIRE, new Object[0]);
/*      */   }
/*      */   
/*      */   private int get_ToggleState() {
/* 1499 */     if (isDisposed()) return 0; 
/* 1500 */     if (Boolean.TRUE.equals(getAttribute(AccessibleAttribute.INDETERMINATE, new Object[0]))) {
/* 1501 */       return 2;
/*      */     }
/* 1503 */     boolean bool = Boolean.TRUE.equals(getAttribute(AccessibleAttribute.SELECTED, new Object[0]));
/* 1504 */     return bool ? 1 : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void Collapse() {
/* 1511 */     if (isDisposed())
/* 1512 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1513 */     if (accessibleRole == AccessibleRole.TOOL_BAR) {
/* 1514 */       Node node = (Node)getAttribute(AccessibleAttribute.OVERFLOW_BUTTON, new Object[0]);
/* 1515 */       if (node != null) {
/* 1516 */         getAccessible(node).executeAction(AccessibleAction.FIRE, new Object[0]);
/*      */       }
/*      */       return;
/*      */     } 
/* 1520 */     if (accessibleRole == AccessibleRole.TREE_TABLE_CELL) {
/* 1521 */       Accessible accessible = getRow();
/* 1522 */       if (accessible != null) accessible.executeAction(AccessibleAction.COLLAPSE, new Object[0]); 
/*      */       return;
/*      */     } 
/* 1525 */     executeAction(AccessibleAction.COLLAPSE, new Object[0]);
/*      */   }
/*      */   
/*      */   private void Expand() {
/* 1529 */     if (isDisposed())
/* 1530 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1531 */     if (accessibleRole == AccessibleRole.TOOL_BAR) {
/* 1532 */       Node node = (Node)getAttribute(AccessibleAttribute.OVERFLOW_BUTTON, new Object[0]);
/* 1533 */       if (node != null) {
/* 1534 */         getAccessible(node).executeAction(AccessibleAction.FIRE, new Object[0]);
/*      */       }
/*      */       return;
/*      */     } 
/* 1538 */     if (accessibleRole == AccessibleRole.TREE_TABLE_CELL) {
/* 1539 */       Accessible accessible = getRow();
/* 1540 */       if (accessible != null) accessible.executeAction(AccessibleAction.EXPAND, new Object[0]); 
/*      */       return;
/*      */     } 
/* 1543 */     executeAction(AccessibleAction.EXPAND, new Object[0]);
/*      */   }
/*      */   
/*      */   private int get_ExpandCollapseState() {
/* 1547 */     if (isDisposed()) return 0;
/*      */     
/* 1549 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1550 */     if (accessibleRole == AccessibleRole.TOOL_BAR) {
/* 1551 */       Node node = (Node)getAttribute(AccessibleAttribute.OVERFLOW_BUTTON, new Object[0]);
/* 1552 */       if (node != null) {
/* 1553 */         boolean bool1 = Boolean.TRUE.equals(getAccessible(node).getAttribute(AccessibleAttribute.VISIBLE, new Object[0]));
/* 1554 */         return bool1 ? 0 : 1;
/*      */       } 
/*      */     } 
/*      */     
/* 1558 */     if (accessibleRole == AccessibleRole.TREE_TABLE_CELL) {
/* 1559 */       Accessible accessible = getRow();
/* 1560 */       if (accessible == null) return 3; 
/* 1561 */       Object object1 = accessible.getAttribute(AccessibleAttribute.LEAF, new Object[0]);
/* 1562 */       if (Boolean.TRUE.equals(object1)) return 3; 
/* 1563 */       object1 = accessible.getAttribute(AccessibleAttribute.EXPANDED, new Object[0]);
/* 1564 */       boolean bool1 = Boolean.TRUE.equals(object1);
/* 1565 */       return bool1 ? 1 : 0;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1575 */     Object object = getAttribute(AccessibleAttribute.LEAF, new Object[0]);
/* 1576 */     if (Boolean.TRUE.equals(object)) return 3;
/*      */     
/* 1578 */     object = getAttribute(AccessibleAttribute.EXPANDED, new Object[0]);
/* 1579 */     boolean bool = Boolean.TRUE.equals(object);
/* 1580 */     return bool ? 1 : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean get_CanMove() {
/* 1587 */     return false;
/*      */   }
/*      */   
/*      */   private boolean get_CanResize() {
/* 1591 */     return false;
/*      */   }
/*      */   
/*      */   private boolean get_CanRotate() {
/* 1595 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void Move(double paramDouble1, double paramDouble2) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void Resize(double paramDouble1, double paramDouble2) {}
/*      */ 
/*      */   
/*      */   private void Rotate(double paramDouble) {}
/*      */ 
/*      */   
/*      */   private void Scroll(int paramInt1, int paramInt2) {
/* 1611 */     if (isDisposed()) {
/*      */       return;
/*      */     }
/* 1614 */     if (get_VerticallyScrollable()) {
/* 1615 */       Node node = (Node)getAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR, new Object[0]);
/* 1616 */       Accessible accessible = getAccessible(node);
/* 1617 */       if (accessible == null)
/* 1618 */         return;  switch (paramInt2) {
/*      */         case 3:
/* 1620 */           accessible.executeAction(AccessibleAction.BLOCK_INCREMENT, new Object[0]);
/*      */           break;
/*      */         case 4:
/* 1623 */           accessible.executeAction(AccessibleAction.INCREMENT, new Object[0]);
/*      */           break;
/*      */         case 0:
/* 1626 */           accessible.executeAction(AccessibleAction.BLOCK_DECREMENT, new Object[0]);
/*      */           break;
/*      */         case 1:
/* 1629 */           accessible.executeAction(AccessibleAction.DECREMENT, new Object[0]);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/* 1636 */     if (get_HorizontallyScrollable()) {
/* 1637 */       Node node = (Node)getAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR, new Object[0]);
/* 1638 */       Accessible accessible = getAccessible(node);
/* 1639 */       if (accessible == null)
/* 1640 */         return;  switch (paramInt1) {
/*      */         case 3:
/* 1642 */           accessible.executeAction(AccessibleAction.BLOCK_INCREMENT, new Object[0]);
/*      */           break;
/*      */         case 4:
/* 1645 */           accessible.executeAction(AccessibleAction.INCREMENT, new Object[0]);
/*      */           break;
/*      */         case 0:
/* 1648 */           accessible.executeAction(AccessibleAction.BLOCK_DECREMENT, new Object[0]);
/*      */           break;
/*      */         case 1:
/* 1651 */           accessible.executeAction(AccessibleAction.DECREMENT, new Object[0]);
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void SetScrollPercent(double paramDouble1, double paramDouble2) {
/* 1659 */     if (isDisposed()) {
/*      */       return;
/*      */     }
/* 1662 */     if (paramDouble2 != -1.0D && get_VerticallyScrollable()) {
/* 1663 */       Node node = (Node)getAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR, new Object[0]);
/* 1664 */       Accessible accessible = getAccessible(node);
/* 1665 */       if (accessible == null)
/* 1666 */         return;  Double double_1 = (Double)accessible.getAttribute(AccessibleAttribute.MIN_VALUE, new Object[0]);
/* 1667 */       Double double_2 = (Double)accessible.getAttribute(AccessibleAttribute.MAX_VALUE, new Object[0]);
/* 1668 */       if (double_1 != null && double_2 != null) {
/* 1669 */         accessible.executeAction(AccessibleAction.SET_VALUE, new Object[] { Double.valueOf((double_2.doubleValue() - double_1.doubleValue()) * paramDouble2 / 100.0D + double_1.doubleValue()) });
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1674 */     if (paramDouble1 != -1.0D && get_HorizontallyScrollable()) {
/* 1675 */       Node node = (Node)getAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR, new Object[0]);
/* 1676 */       Accessible accessible = getAccessible(node);
/* 1677 */       if (accessible == null)
/* 1678 */         return;  Double double_1 = (Double)accessible.getAttribute(AccessibleAttribute.MIN_VALUE, new Object[0]);
/* 1679 */       Double double_2 = (Double)accessible.getAttribute(AccessibleAttribute.MAX_VALUE, new Object[0]);
/* 1680 */       if (double_1 != null && double_2 != null) {
/* 1681 */         accessible.executeAction(AccessibleAction.SET_VALUE, new Object[] { Double.valueOf((double_2.doubleValue() - double_1.doubleValue()) * paramDouble1 / 100.0D + double_1.doubleValue()) });
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean get_HorizontallyScrollable() {
/* 1687 */     if (isDisposed()) return false;
/*      */     
/* 1689 */     Node node = (Node)getAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR, new Object[0]);
/* 1690 */     if (node == null) return false;
/*      */     
/* 1692 */     Boolean bool = (Boolean)getAccessible(node).getAttribute(AccessibleAttribute.VISIBLE, new Object[0]);
/* 1693 */     return Boolean.TRUE.equals(bool);
/*      */   }
/*      */   
/*      */   private double get_HorizontalScrollPercent() {
/* 1697 */     if (isDisposed()) return 0.0D;
/*      */     
/* 1699 */     if (!get_HorizontallyScrollable()) {
/* 1700 */       return -1.0D;
/*      */     }
/*      */     
/* 1703 */     Node node = (Node)getAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR, new Object[0]);
/* 1704 */     if (node != null) {
/*      */       
/* 1706 */       Accessible accessible = getAccessible(node);
/* 1707 */       Double double_1 = (Double)accessible.getAttribute(AccessibleAttribute.VALUE, new Object[0]);
/* 1708 */       if (double_1 == null) return 0.0D; 
/* 1709 */       Double double_2 = (Double)accessible.getAttribute(AccessibleAttribute.MAX_VALUE, new Object[0]);
/* 1710 */       if (double_2 == null) return 0.0D; 
/* 1711 */       Double double_3 = (Double)accessible.getAttribute(AccessibleAttribute.MIN_VALUE, new Object[0]);
/* 1712 */       if (double_3 == null) return 0.0D; 
/* 1713 */       return 100.0D * (double_1.doubleValue() - double_3.doubleValue()) / (double_2.doubleValue() - double_3.doubleValue());
/*      */     } 
/*      */     
/* 1716 */     return 0.0D;
/*      */   }
/*      */   
/*      */   private double get_HorizontalViewSize() {
/* 1720 */     if (isDisposed()) return 0.0D; 
/* 1721 */     if (!get_HorizontallyScrollable()) return 100.0D; 
/* 1722 */     Node node = (Node)getAttribute(AccessibleAttribute.CONTENTS, new Object[0]);
/* 1723 */     if (node == null) return 100.0D; 
/* 1724 */     Bounds bounds1 = (Bounds)getAccessible(node).getAttribute(AccessibleAttribute.BOUNDS, new Object[0]);
/* 1725 */     if (bounds1 == null) return 0.0D; 
/* 1726 */     Bounds bounds2 = (Bounds)getAttribute(AccessibleAttribute.BOUNDS, new Object[0]);
/* 1727 */     if (bounds2 == null) return 0.0D; 
/* 1728 */     return bounds2.getWidth() / bounds1.getWidth() * 100.0D;
/*      */   }
/*      */   
/*      */   private boolean get_VerticallyScrollable() {
/* 1732 */     if (isDisposed()) return false;
/*      */     
/* 1734 */     Node node = (Node)getAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR, new Object[0]);
/* 1735 */     if (node == null) return false;
/*      */     
/* 1737 */     Boolean bool = (Boolean)getAccessible(node).getAttribute(AccessibleAttribute.VISIBLE, new Object[0]);
/* 1738 */     return Boolean.TRUE.equals(bool);
/*      */   }
/*      */   
/*      */   private double get_VerticalScrollPercent() {
/* 1742 */     if (isDisposed()) return 0.0D;
/*      */     
/* 1744 */     if (!get_VerticallyScrollable()) {
/* 1745 */       return -1.0D;
/*      */     }
/*      */     
/* 1748 */     Node node = (Node)getAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR, new Object[0]);
/* 1749 */     if (node != null) {
/*      */       
/* 1751 */       Accessible accessible = getAccessible(node);
/* 1752 */       Double double_1 = (Double)accessible.getAttribute(AccessibleAttribute.VALUE, new Object[0]);
/* 1753 */       if (double_1 == null) return 0.0D; 
/* 1754 */       Double double_2 = (Double)accessible.getAttribute(AccessibleAttribute.MAX_VALUE, new Object[0]);
/* 1755 */       if (double_2 == null) return 0.0D; 
/* 1756 */       Double double_3 = (Double)accessible.getAttribute(AccessibleAttribute.MIN_VALUE, new Object[0]);
/* 1757 */       if (double_3 == null) return 0.0D; 
/* 1758 */       return 100.0D * (double_1.doubleValue() - double_3.doubleValue()) / (double_2.doubleValue() - double_3.doubleValue());
/*      */     } 
/*      */     
/* 1761 */     return 0.0D;
/*      */   }
/*      */   
/*      */   private double get_VerticalViewSize() {
/* 1765 */     if (isDisposed()) return 0.0D; 
/* 1766 */     if (!get_VerticallyScrollable()) return 100.0D;
/*      */     
/* 1768 */     double d1 = 0.0D;
/*      */     
/* 1770 */     Bounds bounds = (Bounds)getAttribute(AccessibleAttribute.BOUNDS, new Object[0]);
/* 1771 */     if (bounds == null) return 0.0D; 
/* 1772 */     double d2 = bounds.getHeight();
/*      */     
/* 1774 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1775 */     if (accessibleRole == null) return 0.0D; 
/* 1776 */     if (accessibleRole == AccessibleRole.SCROLL_PANE) {
/* 1777 */       Node node = (Node)getAttribute(AccessibleAttribute.CONTENTS, new Object[0]);
/* 1778 */       if (node != null) {
/* 1779 */         Bounds bounds1 = (Bounds)getAccessible(node).getAttribute(AccessibleAttribute.BOUNDS, new Object[0]);
/* 1780 */         d1 = (bounds1 == null) ? 0.0D : bounds1.getHeight();
/*      */       } 
/*      */     } else {
/* 1783 */       Integer integer = Integer.valueOf(0);
/* 1784 */       switch (accessibleRole) {
/*      */         case LIST_VIEW:
/* 1786 */           integer = (Integer)getAttribute(AccessibleAttribute.ITEM_COUNT, new Object[0]);
/*      */           break;
/*      */         case TREE_TABLE_VIEW:
/*      */         case TABLE_VIEW:
/*      */         case TREE_VIEW:
/* 1791 */           integer = (Integer)getAttribute(AccessibleAttribute.ROW_COUNT, new Object[0]);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1802 */       d1 = (integer == null) ? 0.0D : (integer.intValue() * 24);
/*      */     } 
/*      */     
/* 1805 */     return (d1 == 0.0D) ? 0.0D : (d2 / d1 * 100.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void ScrollIntoView() {
/*      */     Integer integer1, integer2;
/* 1812 */     if (isDisposed())
/* 1813 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1814 */     if (accessibleRole == null)
/* 1815 */       return;  Accessible accessible = getContainer();
/* 1816 */     if (accessible == null)
/* 1817 */       return;  Node node = null;
/* 1818 */     switch (accessibleRole) {
/*      */       case LIST_ITEM:
/* 1820 */         integer1 = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/* 1821 */         if (integer1 != null) {
/* 1822 */           node = (Node)accessible.getAttribute(AccessibleAttribute.ITEM_AT_INDEX, new Object[] { integer1 });
/*      */         }
/*      */         break;
/*      */       
/*      */       case TREE_ITEM:
/* 1827 */         integer1 = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/* 1828 */         if (integer1 != null) {
/* 1829 */           node = (Node)accessible.getAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { integer1 });
/*      */         }
/*      */         break;
/*      */       
/*      */       case TABLE_CELL:
/*      */       case TREE_TABLE_CELL:
/* 1835 */         integer1 = (Integer)getAttribute(AccessibleAttribute.ROW_INDEX, new Object[0]);
/* 1836 */         integer2 = (Integer)getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/* 1837 */         if (integer1 != null && integer2 != null) {
/* 1838 */           node = (Node)accessible.getAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, new Object[] { integer1, integer2 });
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1844 */     if (node != null)
/* 1845 */       accessible.executeAction(AccessibleAction.SHOW_ITEM, new Object[] { node }); 
/*      */   }
/*      */   
/*      */   private static native void _initIDs();
/*      */   
/*      */   private native long _createGlassAccessible();
/*      */   
/*      */   private native void _destroyGlassAccessible(long paramLong);
/*      */   
/*      */   private static native long UiaRaiseAutomationEvent(long paramLong, int paramInt);
/*      */   
/*      */   private static native long UiaRaiseAutomationPropertyChangedEvent(long paramLong, int paramInt, WinVariant paramWinVariant1, WinVariant paramWinVariant2);
/*      */   
/*      */   private static native boolean UiaClientsAreListening();
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinAccessible.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */