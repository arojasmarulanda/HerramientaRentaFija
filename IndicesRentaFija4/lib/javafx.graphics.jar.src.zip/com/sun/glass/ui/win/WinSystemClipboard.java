/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import com.sun.glass.ui.Application;
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import com.sun.glass.ui.SystemClipboard;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WinSystemClipboard
/*     */   extends SystemClipboard
/*     */ {
/*     */   static {
/*  42 */     initIDs();
/*     */   }
/*     */   
/*  45 */   private long ptr = 0L;
/*     */   
/*     */   protected WinSystemClipboard(String paramString) {
/*  48 */     super(paramString);
/*  49 */     create();
/*     */   }
/*     */   
/*     */   protected final long getPtr() {
/*  53 */     return this.ptr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   static final byte[] terminator = new byte[] { 0, 0 };
/*     */   
/*     */   static final String defaultCharset = "UTF-16LE";
/*     */   static final String RTFCharset = "US-ASCII";
/*     */   
/*     */   private byte[] fosSerialize(String paramString, long paramLong) {
/*  77 */     Object object = getLocalData(paramString);
/*  78 */     if (object instanceof ByteBuffer) {
/*  79 */       byte[] arrayOfByte = ((ByteBuffer)object).array();
/*  80 */       if ("text/html".equals(paramString)) {
/*  81 */         arrayOfByte = WinHTMLCodec.encode(arrayOfByte);
/*     */       }
/*  83 */       return arrayOfByte;
/*  84 */     }  if (object instanceof String) {
/*  85 */       String str = ((String)object).replaceAll("(\r\n|\r|\n)", "\r\n");
/*  86 */       if ("text/html".equals(paramString))
/*     */         
/*     */         try {
/*  89 */           byte[] arrayOfByte = str.getBytes("UTF-8");
/*  90 */           ByteBuffer byteBuffer1 = ByteBuffer.allocate(arrayOfByte.length + 1);
/*  91 */           byteBuffer1.put(arrayOfByte);
/*  92 */           byteBuffer1.put((byte)0);
/*     */           
/*  94 */           return WinHTMLCodec.encode(byteBuffer1.array());
/*  95 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */           
/*  97 */           return null;
/*     */         }  
/*  99 */       if ("text/rtf".equals(paramString)) {
/*     */         
/*     */         try {
/* 102 */           byte[] arrayOfByte = str.getBytes("US-ASCII");
/* 103 */           ByteBuffer byteBuffer1 = ByteBuffer.allocate(arrayOfByte.length + 1);
/* 104 */           byteBuffer1.put(arrayOfByte);
/* 105 */           byteBuffer1.put((byte)0);
/* 106 */           return byteBuffer1.array();
/* 107 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */           
/* 109 */           return null;
/*     */         } 
/*     */       }
/* 112 */       ByteBuffer byteBuffer = ByteBuffer.allocate((str.length() + 1) * 2);
/*     */       try {
/* 114 */         byteBuffer.put(str.getBytes("UTF-16LE"));
/* 115 */       } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */ 
/*     */       
/* 118 */       byteBuffer.put(terminator);
/* 119 */       return byteBuffer.array();
/*     */     } 
/* 121 */     if ("application/x-java-file-list".equals(paramString)) {
/* 122 */       String[] arrayOfString = (String[])object;
/* 123 */       if (arrayOfString != null && arrayOfString.length > 0) {
/* 124 */         int i = 0;
/* 125 */         for (String str : arrayOfString) {
/* 126 */           i += (str.length() + 1) * 2;
/*     */         }
/* 128 */         i += 2;
/*     */         try {
/* 130 */           ByteBuffer byteBuffer = ByteBuffer.allocate(i);
/* 131 */           for (String str : arrayOfString) {
/* 132 */             byteBuffer.put(str.getBytes("UTF-16LE"));
/* 133 */             byteBuffer.put(terminator);
/*     */           } 
/* 135 */           byteBuffer.put(terminator);
/* 136 */           return byteBuffer.array();
/* 137 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */       }
/*     */     
/*     */     }
/* 141 */     else if ("application/x-java-rawimage".equals(paramString)) {
/* 142 */       Pixels pixels = (Pixels)object;
/* 143 */       if (pixels != null) {
/* 144 */         ByteBuffer byteBuffer = ByteBuffer.allocate(pixels
/* 145 */             .getWidth() * pixels.getHeight() * 4 + 8);
/* 146 */         byteBuffer.putInt(pixels.getWidth());
/* 147 */         byteBuffer.putInt(pixels.getHeight());
/* 148 */         byteBuffer.put(pixels.asByteBuffer());
/* 149 */         return byteBuffer.array();
/*     */       } 
/*     */     } 
/*     */     
/* 153 */     return null;
/*     */   }
/*     */   
/*     */   private static final class MimeTypeParser {
/*     */     protected static final String externalBodyMime = "message/external-body";
/*     */     protected String mime;
/*     */     protected boolean bInMemoryFile;
/*     */     protected int index;
/*     */     
/*     */     public MimeTypeParser() {
/* 163 */       parse("");
/*     */     }
/*     */     
/*     */     public MimeTypeParser(String param1String) {
/* 167 */       parse(param1String);
/*     */     }
/*     */     
/*     */     public void parse(String param1String) {
/* 171 */       this.mime = param1String;
/* 172 */       this.bInMemoryFile = false;
/* 173 */       this.index = -1;
/*     */ 
/*     */       
/* 176 */       if (param1String.startsWith("message/external-body")) {
/* 177 */         String[] arrayOfString = param1String.split(";");
/* 178 */         String str = "";
/* 179 */         int i = -1;
/*     */         
/* 181 */         for (byte b = 1; b < arrayOfString.length; b++) {
/* 182 */           String[] arrayOfString1 = arrayOfString[b].split("=");
/* 183 */           if (arrayOfString1.length == 2) {
/* 184 */             if (arrayOfString1[0].trim().equalsIgnoreCase("index")) {
/*     */ 
/*     */               
/* 187 */               i = Integer.parseInt(arrayOfString1[1].trim());
/* 188 */             } else if (arrayOfString1[0].trim().equalsIgnoreCase("access-type")) {
/* 189 */               str = arrayOfString1[1].trim();
/*     */             } 
/*     */           }
/* 192 */           if (i != -1 && !str.isEmpty()) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 200 */         if (str.equalsIgnoreCase("clipboard")) {
/* 201 */           this.bInMemoryFile = true;
/* 202 */           this.mime = arrayOfString[0];
/* 203 */           this.index = i;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getMime() {
/* 209 */       return this.mime;
/*     */     }
/*     */     
/*     */     public int getIndex() {
/* 213 */       return this.index;
/*     */     }
/*     */     
/*     */     public boolean isInMemoryFile() {
/* 217 */       return this.bInMemoryFile;
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void pushToSystem(HashMap<String, Object> paramHashMap, int paramInt) {
/* 222 */     Set<String> set = paramHashMap.keySet();
/* 223 */     HashSet<String> hashSet = new HashSet();
/* 224 */     MimeTypeParser mimeTypeParser = new MimeTypeParser();
/* 225 */     for (String str : set) {
/* 226 */       mimeTypeParser.parse(str);
/* 227 */       if (!mimeTypeParser.isInMemoryFile())
/*     */       {
/*     */ 
/*     */         
/* 231 */         hashSet.add(str);
/*     */       }
/*     */     } 
/* 234 */     push(hashSet.toArray(), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object popFromSystem(String paramString) {
/* 243 */     if (!pop()) {
/* 244 */       return null;
/*     */     }
/*     */     
/* 247 */     MimeTypeParser mimeTypeParser = new MimeTypeParser(paramString);
/* 248 */     String str = mimeTypeParser.getMime();
/* 249 */     byte[] arrayOfByte = popBytes(str, mimeTypeParser.getIndex());
/* 250 */     if (arrayOfByte != null) {
/* 251 */       if ("text/plain".equals(str) || "text/uri-list".equals(str)) {
/*     */         
/*     */         try {
/* 254 */           return new String(arrayOfByte, 0, arrayOfByte.length - 2, "UTF-16LE");
/* 255 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */       
/*     */       }
/* 258 */       else if ("text/html".equals(str)) {
/*     */         try {
/* 260 */           arrayOfByte = WinHTMLCodec.decode(arrayOfByte);
/* 261 */           return new String(arrayOfByte, 0, arrayOfByte.length, "UTF-8");
/* 262 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */       
/*     */       }
/* 265 */       else if ("text/rtf".equals(str)) {
/*     */         try {
/* 267 */           return new String(arrayOfByte, 0, arrayOfByte.length, "US-ASCII");
/* 268 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */       
/*     */       }
/* 271 */       else if ("application/x-java-file-list".equals(str)) {
/*     */         try {
/* 273 */           String str1 = new String(arrayOfByte, 0, arrayOfByte.length, "UTF-16LE");
/* 274 */           return str1.split("\000");
/* 275 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */       } else {
/*     */         
/* 278 */         if ("application/x-java-rawimage".equals(str)) {
/* 279 */           ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte, 0, 8);
/* 280 */           return Application.GetApplication().createPixels(byteBuffer.getInt(), byteBuffer.getInt(), ByteBuffer.wrap(arrayOfByte, 8, arrayOfByte.length - 8));
/*     */         } 
/* 282 */         return ByteBuffer.wrap(arrayOfByte);
/*     */       } 
/*     */     } else {
/*     */       
/* 286 */       if ("text/uri-list".equals(str) || "text/plain".equals(str)) {
/*     */         
/* 288 */         arrayOfByte = popBytes(str + ";locale", mimeTypeParser.getIndex());
/* 289 */         if (arrayOfByte != null) {
/*     */           
/*     */           try {
/*     */ 
/*     */ 
/*     */             
/* 295 */             return new String(arrayOfByte, 0, arrayOfByte.length - 1, "UTF-8");
/* 296 */           } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 301 */       if ("text/uri-list".equals(str)) {
/*     */ 
/*     */         
/* 304 */         String[] arrayOfString = (String[])popFromSystem("application/x-java-file-list");
/* 305 */         if (arrayOfString != null) {
/* 306 */           StringBuilder stringBuilder = new StringBuilder();
/*     */           
/* 308 */           for (byte b = 0; b < arrayOfString.length; b++) {
/* 309 */             String str1 = arrayOfString[b];
/* 310 */             str1 = str1.replace("\\", "/");
/*     */             
/* 312 */             if (stringBuilder.length() > 0) {
/* 313 */               stringBuilder.append("\r\n");
/*     */             }
/* 315 */             stringBuilder.append("file:/").append(str1);
/*     */           } 
/* 317 */           return stringBuilder.toString();
/*     */         } 
/*     */       } 
/*     */     } 
/* 321 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String[] mimesFromSystem() {
/* 328 */     if (!pop()) {
/* 329 */       return null;
/*     */     }
/* 331 */     return popMimesFromSystem();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 335 */     return "Windows System Clipboard";
/*     */   }
/*     */   
/*     */   protected final void close() {
/* 339 */     dispose();
/* 340 */     this.ptr = 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int supportedSourceActionsFromSystem() {
/* 347 */     if (!pop()) {
/* 348 */       return 0;
/*     */     }
/* 350 */     return popSupportedSourceActions();
/*     */   }
/*     */   
/*     */   private static native void initIDs();
/*     */   
/*     */   protected native boolean isOwner();
/*     */   
/*     */   protected native void create();
/*     */   
/*     */   protected native void dispose();
/*     */   
/*     */   protected native void push(Object[] paramArrayOfObject, int paramInt);
/*     */   
/*     */   protected native boolean pop();
/*     */   
/*     */   private native byte[] popBytes(String paramString, long paramLong);
/*     */   
/*     */   private native String[] popMimesFromSystem();
/*     */   
/*     */   protected native void pushTargetActionToSystem(int paramInt);
/*     */   
/*     */   private native int popSupportedSourceActions();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinSystemClipboard.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */