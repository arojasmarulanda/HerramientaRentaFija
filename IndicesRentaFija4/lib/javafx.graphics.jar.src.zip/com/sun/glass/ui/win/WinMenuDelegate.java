/*    */ package com.sun.glass.ui.win;
/*    */ 
/*    */ import com.sun.glass.ui.Menu;
/*    */ import com.sun.glass.ui.Pixels;
/*    */ import com.sun.glass.ui.delegate.MenuDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuItemDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WinMenuDelegate
/*    */   extends WinMenuImpl
/*    */   implements MenuDelegate
/*    */ {
/*    */   private final Menu owner;
/* 35 */   private WinMenuImpl parent = null;
/*    */   
/*    */   public WinMenuDelegate(Menu paramMenu) {
/* 38 */     this.owner = paramMenu;
/*    */   }
/*    */ 
/*    */   
/*    */   public Menu getOwner() {
/* 43 */     return this.owner;
/*    */   }
/*    */   
/*    */   public boolean createMenu(String paramString, boolean paramBoolean) {
/* 47 */     return create();
/*    */   }
/*    */   
/*    */   public void dispose() {
/* 51 */     destroy();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean setTitle(String paramString) {
/* 57 */     if (this.parent != null) {
/* 58 */       return this.parent.setSubmenuTitle(this, paramString);
/*    */     }
/* 60 */     return true;
/*    */   }
/*    */   
/*    */   public boolean setEnabled(boolean paramBoolean) {
/* 64 */     if (this.parent != null) {
/* 65 */       return this.parent.enableSubmenu(this, paramBoolean);
/*    */     }
/* 67 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean setPixels(Pixels paramPixels) {
/* 72 */     return false;
/*    */   }
/*    */   
/*    */   public boolean insert(MenuDelegate paramMenuDelegate, int paramInt) {
/* 76 */     return insertSubmenu((WinMenuDelegate)paramMenuDelegate, paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean insert(MenuItemDelegate paramMenuItemDelegate, int paramInt) {
/* 81 */     return insertItem((WinMenuItemDelegate)paramMenuItemDelegate, paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean remove(MenuDelegate paramMenuDelegate, int paramInt) {
/* 86 */     return removeMenu((WinMenuDelegate)paramMenuDelegate, paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean remove(MenuItemDelegate paramMenuItemDelegate, int paramInt) {
/* 91 */     return removeItem((WinMenuItemDelegate)paramMenuItemDelegate, paramInt);
/*    */   }
/*    */   
/*    */   WinMenuImpl getParent() {
/* 95 */     return this.parent;
/*    */   }
/*    */   
/*    */   void setParent(WinMenuImpl paramWinMenuImpl) {
/* 99 */     this.parent = paramWinMenuImpl;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinMenuDelegate.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */