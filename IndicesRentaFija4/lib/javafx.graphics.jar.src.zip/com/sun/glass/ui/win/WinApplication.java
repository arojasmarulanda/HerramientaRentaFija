/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import com.sun.glass.ui.Accessible;
/*     */ import com.sun.glass.ui.Application;
/*     */ import com.sun.glass.ui.CommonDialogs;
/*     */ import com.sun.glass.ui.Cursor;
/*     */ import com.sun.glass.ui.GlassRobot;
/*     */ import com.sun.glass.ui.InvokeLaterDispatcher;
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import com.sun.glass.ui.Screen;
/*     */ import com.sun.glass.ui.Size;
/*     */ import com.sun.glass.ui.Timer;
/*     */ import com.sun.glass.ui.View;
/*     */ import com.sun.glass.ui.Window;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import com.sun.prism.impl.PrismSettings;
/*     */ import java.io.File;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WinApplication
/*     */   extends Application
/*     */   implements InvokeLaterDispatcher.InvokeLaterSubmitter
/*     */ {
/*     */   static float overrideUIScale;
/*     */   private final InvokeLaterDispatcher invokeLaterDispatcher;
/*     */   private static boolean verbose;
/*     */   private static final int Process_DPI_Unaware = 0;
/*     */   private static final int Process_System_DPI_Aware = 1;
/*     */   private static final int Process_Per_Monitor_DPI_Aware = 2;
/*     */   
/*     */   private static boolean getBoolean(String paramString1, boolean paramBoolean, String paramString2) {
/*  43 */     String str = System.getProperty(paramString1);
/*  44 */     if (str == null) {
/*  45 */       str = System.getenv(paramString1);
/*     */     }
/*  47 */     if (str == null) {
/*  48 */       return paramBoolean;
/*     */     }
/*  50 */     Boolean bool = Boolean.valueOf(Boolean.parseBoolean(str));
/*  51 */     if (PrismSettings.verbose) {
/*  52 */       System.out.println((bool.booleanValue() ? "" : "not ") + (bool.booleanValue() ? "" : "not "));
/*     */     }
/*  54 */     return bool.booleanValue();
/*     */   }
/*     */   private static float getFloat(String paramString1, float paramFloat, String paramString2) {
/*     */     float f;
/*  58 */     String str = System.getProperty(paramString1);
/*  59 */     if (str == null) {
/*  60 */       str = System.getenv(paramString1);
/*     */     }
/*  62 */     if (str == null) {
/*  63 */       return paramFloat;
/*     */     }
/*  65 */     str = str.trim();
/*     */     
/*  67 */     if (str.endsWith("%")) {
/*  68 */       f = Integer.parseInt(str.substring(0, str.length() - 1)) / 100.0F;
/*  69 */     } else if (str.endsWith("DPI") || str.endsWith("dpi")) {
/*  70 */       f = Integer.parseInt(str.substring(0, str.length() - 3)) / 96.0F;
/*     */     } else {
/*  72 */       f = Float.parseFloat(str);
/*     */     } 
/*  74 */     if (PrismSettings.verbose) {
/*  75 */       System.out.println(paramString2 + paramString2);
/*     */     }
/*  77 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/*  82 */     AccessController.doPrivileged(new PrivilegedAction<Void>() {
/*     */           public Void run() {
/*  84 */             WinApplication.verbose = Boolean.getBoolean("javafx.verbose");
/*  85 */             if (PrismSettings.allowHiDPIScaling) {
/*  86 */               WinApplication.overrideUIScale = WinApplication.getFloat("glass.win.uiScale", -1.0F, "Forcing UI scaling factor: ");
/*     */               
/*  88 */               if (PrismSettings.verbose) {
/*  89 */                 WinApplication.getFloat("glass.win.renderScale", -1.0F, "(No longer supported) Rendering scaling factor: ");
/*     */                 
/*  91 */                 WinApplication.getFloat("glass.win.minHiDPI", 1.5F, "(No longer supported) UI scaling threshold: ");
/*     */                 
/*  93 */                 WinApplication.getBoolean("glass.win.forceIntegerRenderScale", true, "(No longer supported) force integer rendering scale");
/*     */               } 
/*     */             } else {
/*     */               
/*  97 */               WinApplication.overrideUIScale = 1.0F;
/*     */             } 
/*     */             
/* 100 */             Toolkit.loadMSWindowsLibraries();
/* 101 */             WinApplication.loadNativeLibrary();
/* 102 */             return null;
/*     */           }
/*     */         });
/* 105 */     initIDs(overrideUIScale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WinApplication() {
/* 112 */     boolean bool = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.embed.isEventThread")))).booleanValue();
/* 113 */     if (!bool) {
/* 114 */       this.invokeLaterDispatcher = new InvokeLaterDispatcher(this);
/* 115 */       this.invokeLaterDispatcher.start();
/*     */     } else {
/* 117 */       this.invokeLaterDispatcher = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getDesiredAwarenesslevel() {
/* 134 */     if (!PrismSettings.allowHiDPIScaling) {
/* 135 */       return 0;
/*     */     }
/*     */     
/* 138 */     String str = AccessController.<String>doPrivileged(() -> System.getProperty("javafx.glass.winDPIawareness"));
/*     */     
/* 140 */     if (str != null) {
/* 141 */       str = str.toLowerCase();
/* 142 */       if (str.equals("aware"))
/* 143 */         return 1; 
/* 144 */       if (str.equals("permonitor")) {
/* 145 */         return 2;
/*     */       }
/* 147 */       if (!str.equals("unaware")) {
/* 148 */         System.err.println("unrecognized DPI awareness request, defaulting to unaware: " + str);
/*     */       }
/* 150 */       return 0;
/*     */     } 
/*     */     
/* 153 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void runLoop(Runnable paramRunnable) {
/* 159 */     boolean bool = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.embed.isEventThread")))).booleanValue();
/* 160 */     int i = getDesiredAwarenesslevel();
/*     */     
/* 162 */     ClassLoader classLoader = WinApplication.class.getClassLoader();
/* 163 */     _setClassLoader(classLoader);
/*     */     
/* 165 */     if (bool) {
/* 166 */       _init(i);
/* 167 */       setEventThread(Thread.currentThread());
/* 168 */       paramRunnable.run();
/*     */       
/*     */       return;
/*     */     } 
/* 172 */     Thread thread = AccessController.<Thread>doPrivileged(() -> new Thread((), "WindowsNativeRunloopThread"));
/*     */ 
/*     */ 
/*     */     
/* 176 */     setEventThread(thread);
/* 177 */     thread.start();
/*     */   }
/*     */   
/*     */   protected void finishTerminating() {
/* 181 */     Thread thread = getEventThread();
/* 182 */     if (thread != null) {
/* 183 */       _terminateLoop();
/* 184 */       setEventThread(null);
/*     */     } 
/* 186 */     super.finishTerminating();
/*     */   }
/*     */   
/*     */   public boolean shouldUpdateWindow() {
/* 190 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _enterNestedEventLoop() {
/* 197 */     if (this.invokeLaterDispatcher != null) {
/* 198 */       this.invokeLaterDispatcher.notifyEnteringNestedEventLoop();
/*     */     }
/*     */     try {
/* 201 */       return _enterNestedEventLoopImpl();
/*     */     } finally {
/* 203 */       if (this.invokeLaterDispatcher != null) {
/* 204 */         this.invokeLaterDispatcher.notifyLeftNestedEventLoop();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void _leaveNestedEventLoop(Object paramObject) {
/* 210 */     if (this.invokeLaterDispatcher != null) {
/* 211 */       this.invokeLaterDispatcher.notifyLeavingNestedEventLoop();
/*     */     }
/* 213 */     _leaveNestedEventLoopImpl(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Window createWindow(Window paramWindow, Screen paramScreen, int paramInt) {
/* 219 */     return new WinWindow(paramWindow, paramScreen, paramInt);
/*     */   }
/*     */   
/*     */   public Window createWindow(long paramLong) {
/* 223 */     return new WinChildWindow(paramLong);
/*     */   }
/*     */   
/*     */   public View createView() {
/* 227 */     return new WinView();
/*     */   }
/*     */   
/*     */   public Cursor createCursor(int paramInt) {
/* 231 */     return new WinCursor(paramInt);
/*     */   }
/*     */   
/*     */   public Cursor createCursor(int paramInt1, int paramInt2, Pixels paramPixels) {
/* 235 */     return new WinCursor(paramInt1, paramInt2, paramPixels);
/*     */   }
/*     */   
/*     */   protected void staticCursor_setVisible(boolean paramBoolean) {
/* 239 */     WinCursor.setVisible_impl(paramBoolean);
/*     */   }
/*     */   
/*     */   protected Size staticCursor_getBestSize(int paramInt1, int paramInt2) {
/* 243 */     return WinCursor.getBestSize_impl(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public Pixels createPixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer) {
/* 247 */     return new WinPixels(paramInt1, paramInt2, paramByteBuffer);
/*     */   }
/*     */   
/*     */   public Pixels createPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer) {
/* 251 */     return new WinPixels(paramInt1, paramInt2, paramIntBuffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public Pixels createPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer, float paramFloat1, float paramFloat2) {
/* 256 */     return new WinPixels(paramInt1, paramInt2, paramIntBuffer, paramFloat1, paramFloat2);
/*     */   }
/*     */   
/*     */   protected int staticPixels_getNativeFormat() {
/* 260 */     return WinPixels.getNativeFormat_impl();
/*     */   }
/*     */   
/*     */   public GlassRobot createRobot() {
/* 264 */     return new WinRobot();
/*     */   }
/*     */   
/*     */   protected double staticScreen_getVideoRefreshPeriod() {
/* 268 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Timer createTimer(Runnable paramRunnable) {
/* 274 */     return new WinTimer(paramRunnable);
/*     */   }
/*     */   
/*     */   protected int staticTimer_getMinPeriod() {
/* 278 */     return WinTimer.getMinPeriod_impl();
/*     */   }
/*     */   
/*     */   protected int staticTimer_getMaxPeriod() {
/* 282 */     return WinTimer.getMaxPeriod_impl();
/*     */   }
/*     */   
/*     */   public Accessible createAccessible() {
/* 286 */     return new WinAccessible();
/*     */   }
/*     */ 
/*     */   
/*     */   protected CommonDialogs.FileChooserResult staticCommonDialogs_showFileChooser(Window paramWindow, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt2) {
/* 291 */     if (this.invokeLaterDispatcher != null) {
/* 292 */       this.invokeLaterDispatcher.notifyEnteringNestedEventLoop();
/*     */     }
/* 294 */     return WinCommonDialogs.showFileChooser_impl(paramWindow, paramString1, paramString2, paramString3, paramInt1, paramBoolean, paramArrayOfExtensionFilter, paramInt2);
/*     */   }
/*     */   
/*     */   protected File staticCommonDialogs_showFolderChooser(Window paramWindow, String paramString1, String paramString2) {
/* 298 */     if (this.invokeLaterDispatcher != null) {
/* 299 */       this.invokeLaterDispatcher.notifyEnteringNestedEventLoop();
/*     */     }
/* 301 */     return WinCommonDialogs.showFolderChooser_impl(paramWindow, paramString1, paramString2);
/*     */   }
/*     */   
/*     */   protected long staticView_getMultiClickTime() {
/* 305 */     return WinView.getMultiClickTime_impl();
/*     */   }
/*     */   
/*     */   protected int staticView_getMultiClickMaxX() {
/* 309 */     return WinView.getMultiClickMaxX_impl();
/*     */   }
/*     */   
/*     */   protected int staticView_getMultiClickMaxY() {
/* 313 */     return WinView.getMultiClickMaxY_impl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void submitForLaterInvocation(Runnable paramRunnable) {
/* 321 */     _submitForLaterInvocation(paramRunnable);
/*     */   }
/*     */   
/*     */   protected void _invokeLater(Runnable paramRunnable) {
/* 325 */     if (this.invokeLaterDispatcher != null) {
/* 326 */       this.invokeLaterDispatcher.invokeLater(paramRunnable);
/*     */     } else {
/* 328 */       submitForLaterInvocation(paramRunnable);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHighContrastTheme() {
/* 334 */     checkEventThread();
/* 335 */     return _getHighContrastTheme();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _supportsInputMethods() {
/* 340 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _supportsTransparentWindows() {
/* 345 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataDirectory() {
/* 351 */     checkEventThread();
/* 352 */     String str = AccessController.<String>doPrivileged(() -> System.getenv("APPDATA"));
/* 353 */     if (str == null || str.length() == 0) {
/* 354 */       return super.getDataDirectory();
/*     */     }
/* 356 */     return str + str + File.separator + this.name;
/*     */   }
/*     */   
/*     */   private static native void initIDs(float paramFloat);
/*     */   
/*     */   private native long _init(int paramInt);
/*     */   
/*     */   private native void _setClassLoader(ClassLoader paramClassLoader);
/*     */   
/*     */   private native void _runLoop(Runnable paramRunnable);
/*     */   
/*     */   private native void _terminateLoop();
/*     */   
/*     */   private native Object _enterNestedEventLoopImpl();
/*     */   
/*     */   private native void _leaveNestedEventLoopImpl(Object paramObject);
/*     */   
/*     */   protected native Screen[] staticScreen_getScreens();
/*     */   
/*     */   protected native void _invokeAndWait(Runnable paramRunnable);
/*     */   
/*     */   private native void _submitForLaterInvocation(Runnable paramRunnable);
/*     */   
/*     */   private native String _getHighContrastTheme();
/*     */   
/*     */   protected native boolean _supportsUnifiedWindows();
/*     */   
/*     */   protected native int _getKeyCodeForChar(char paramChar);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinApplication.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */