/*    */ package com.sun.glass.ui.win;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WinHTMLCodec
/*    */ {
/*    */   public static final String defaultCharset = "UTF-8";
/*    */   
/*    */   public static byte[] encode(byte[] paramArrayOfbyte) {
/* 50 */     return HTMLCodec.convertToHTMLFormat(paramArrayOfbyte);
/*    */   }
/*    */   
/*    */   public static byte[] decode(byte[] paramArrayOfbyte) {
/*    */     try {
/* 55 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
/* 56 */       HTMLCodec hTMLCodec = new HTMLCodec(byteArrayInputStream, EHTMLReadMode.HTML_READ_SELECTION);
/*    */ 
/*    */       
/* 59 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(paramArrayOfbyte.length);
/*    */ 
/*    */       
/*    */       int i;
/*    */       
/* 64 */       while ((i = hTMLCodec.read()) != -1) {
/* 65 */         byteArrayOutputStream.write(i);
/*    */       }
/*    */       
/* 68 */       return byteArrayOutputStream.toByteArray();
/* 69 */     } catch (IOException iOException) {
/* 70 */       throw new RuntimeException("Unexpected IOException caught", iOException);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinHTMLCodec.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */