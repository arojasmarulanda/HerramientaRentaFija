/*    */ package com.sun.glass.ui.win;
/*    */ 
/*    */ import com.sun.glass.ui.CommonDialogs;
/*    */ import com.sun.glass.ui.Window;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WinCommonDialogs
/*    */ {
/*    */   static {
/* 42 */     _initIDs();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static CommonDialogs.FileChooserResult showFileChooser_impl(Window paramWindow, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt2) {
/* 52 */     if (paramWindow != null) {
/* 53 */       ((WinWindow)paramWindow).setDeferredClosing(true);
/*    */     }
/*    */     try {
/* 56 */       return _showFileChooser((paramWindow != null) ? paramWindow.getNativeWindow() : 0L, paramString1, paramString2, paramString3, paramInt1, paramBoolean, paramArrayOfExtensionFilter, paramInt2);
/*    */     } finally {
/*    */       
/* 59 */       if (paramWindow != null) {
/* 60 */         ((WinWindow)paramWindow).setDeferredClosing(false);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   static File showFolderChooser_impl(Window paramWindow, String paramString1, String paramString2) {
/* 66 */     if (paramWindow != null) {
/* 67 */       ((WinWindow)paramWindow).setDeferredClosing(true);
/*    */     }
/*    */     try {
/* 70 */       String str = _showFolderChooser((paramWindow != null) ? paramWindow.getNativeWindow() : 0L, paramString1, paramString2);
/* 71 */       return (str != null) ? new File(str) : null;
/*    */     } finally {
/* 73 */       if (paramWindow != null)
/* 74 */         ((WinWindow)paramWindow).setDeferredClosing(false); 
/*    */     } 
/*    */   }
/*    */   
/*    */   private static native void _initIDs();
/*    */   
/*    */   private static native CommonDialogs.FileChooserResult _showFileChooser(long paramLong, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt2);
/*    */   
/*    */   private static native String _showFolderChooser(long paramLong, String paramString1, String paramString2);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinCommonDialogs.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */