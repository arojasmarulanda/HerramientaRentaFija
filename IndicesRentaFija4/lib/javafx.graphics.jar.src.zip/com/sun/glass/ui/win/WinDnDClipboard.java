/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WinDnDClipboard
/*     */   extends WinSystemClipboard
/*     */ {
/*     */   protected void create() {}
/*     */   
/*     */   protected native void dispose();
/*     */   
/*     */   protected boolean isOwner() {
/*     */     return (getDragButton() != 0);
/*     */   }
/*     */   
/*     */   protected void pushTargetActionToSystem(int paramInt) {
/*     */     throw new UnsupportedOperationException("[Target Action] not supported! Override View.handleDragDrop instead.");
/*     */   }
/*     */   
/*     */   protected native void push(Object[] paramArrayOfObject, int paramInt);
/*     */   
/*     */   public WinDnDClipboard(String paramString) {
/*  29 */     super(paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     this.sourceSupportedActions = 0;
/*     */   }
/*     */   protected final int supportedSourceActionsFromSystem() {
/*  96 */     return (this.sourceSupportedActions != 0) ? 
/*  97 */       this.sourceSupportedActions : 
/*  98 */       super.supportedSourceActionsFromSystem();
/*     */   } protected boolean pop() {
/*     */     return (getPtr() != 0L);
/*     */   } private static WinDnDClipboard getInstance() {
/*     */     return (WinDnDClipboard)get("DND");
/*     */   }
/*     */   private void setSourceSupportedActions(int paramInt) {
/* 105 */     this.sourceSupportedActions = paramInt;
/*     */   }
/*     */   
/*     */   public String toString() {
/*     */     return "Windows DnD Clipboard";
/*     */   }
/*     */   
/*     */   private static int dragButton = 0;
/*     */   private int sourceSupportedActions;
/*     */   
/*     */   public int getDragButton() {
/*     */     return dragButton;
/*     */   }
/*     */   
/*     */   private void setDragButton(int paramInt) {
/*     */     this;
/*     */     dragButton = paramInt;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinDnDClipboard.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */