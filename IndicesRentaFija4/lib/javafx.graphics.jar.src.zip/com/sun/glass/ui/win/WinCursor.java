/*    */ package com.sun.glass.ui.win;
/*    */ 
/*    */ import com.sun.glass.ui.Cursor;
/*    */ import com.sun.glass.ui.Pixels;
/*    */ import com.sun.glass.ui.Size;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WinCursor
/*    */   extends Cursor
/*    */ {
/*    */   static {
/* 38 */     _initIDs();
/*    */   }
/*    */   
/*    */   protected WinCursor(int paramInt) {
/* 42 */     super(paramInt);
/*    */   }
/*    */   
/*    */   protected WinCursor(int paramInt1, int paramInt2, Pixels paramPixels) {
/* 46 */     super(paramInt1, paramInt2, paramPixels);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void setVisible_impl(boolean paramBoolean) {
/* 55 */     _setVisible(paramBoolean);
/*    */   }
/*    */   
/*    */   static Size getBestSize_impl(int paramInt1, int paramInt2) {
/* 59 */     return _getBestSize(paramInt1, paramInt2);
/*    */   }
/*    */   
/*    */   private static native void _initIDs();
/*    */   
/*    */   protected native long _createCursor(int paramInt1, int paramInt2, Pixels paramPixels);
/*    */   
/*    */   private static native void _setVisible(boolean paramBoolean);
/*    */   
/*    */   private static native Size _getBestSize(int paramInt1, int paramInt2);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinCursor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */