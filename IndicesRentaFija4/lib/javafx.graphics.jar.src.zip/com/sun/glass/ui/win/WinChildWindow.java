/*    */ package com.sun.glass.ui.win;
/*    */ 
/*    */ import com.sun.glass.ui.Pixels;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WinChildWindow
/*    */   extends WinWindow
/*    */ {
/*    */   protected WinChildWindow(long paramLong) {
/* 37 */     super(paramLong);
/*    */   }
/*    */   
/*    */   protected long _createWindow(long paramLong1, long paramLong2, int paramInt) {
/* 41 */     return 0L;
/* 42 */   } protected boolean _setMenubar(long paramLong1, long paramLong2) { return false; }
/* 43 */   protected boolean _minimize(long paramLong, boolean paramBoolean) { return false; }
/* 44 */   protected boolean _maximize(long paramLong, boolean paramBoolean1, boolean paramBoolean2) { return false; }
/* 45 */   protected boolean _setResizable(long paramLong, boolean paramBoolean) { return false; } protected boolean _setTitle(long paramLong, String paramString) {
/* 46 */     return false;
/*    */   }
/*    */   protected void _setLevel(long paramLong, int paramInt) {}
/* 49 */   protected boolean _setMinimumSize(long paramLong, int paramInt1, int paramInt2) { return false; } protected void _setAlpha(long paramLong, float paramFloat) {} protected boolean _setMaximumSize(long paramLong, int paramInt1, int paramInt2) {
/* 50 */     return false;
/*    */   }
/*    */   
/*    */   protected void _setIcon(long paramLong, Pixels paramPixels) {}
/*    */   
/*    */   protected void _enterModal(long paramLong) {}
/*    */   
/*    */   protected void _enterModalWithWindow(long paramLong1, long paramLong2) {}
/*    */   
/*    */   protected void _exitModal(long paramLong) {}
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinChildWindow.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */