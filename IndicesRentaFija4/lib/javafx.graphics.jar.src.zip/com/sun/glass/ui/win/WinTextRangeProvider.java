/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import java.text.BreakIterator;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.text.Font;
/*     */ import javafx.scene.text.FontWeight;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WinTextRangeProvider
/*     */ {
/*     */   private static final int TextPatternRangeEndpoint_Start = 0;
/*     */   private static final int TextPatternRangeEndpoint_End = 1;
/*     */   private static final int TextUnit_Character = 0;
/*     */   private static final int TextUnit_Format = 1;
/*     */   private static final int TextUnit_Word = 2;
/*     */   private static final int TextUnit_Line = 3;
/*     */   private static final int TextUnit_Paragraph = 4;
/*     */   private static final int TextUnit_Page = 5;
/*     */   private static final int TextUnit_Document = 6;
/*     */   private static final int UIA_FontNameAttributeId = 40005;
/*     */   private static final int UIA_FontSizeAttributeId = 40006;
/*     */   private static final int UIA_FontWeightAttributeId = 40007;
/*     */   private static final int UIA_IsHiddenAttributeId = 40013;
/*     */   private static final int UIA_IsItalicAttributeId = 40014;
/*     */   private static final int UIA_IsReadOnlyAttributeId = 40015;
/*     */   
/*     */   static {
/*  44 */     _initIDs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private static int idCount = 1;
/*     */   
/*     */   private int id;
/*     */   
/*     */   private int start;
/*     */   
/*     */   private int end;
/*     */   
/*     */   private WinAccessible accessible;
/*     */   private long peer;
/*     */   
/*     */   WinTextRangeProvider(WinAccessible paramWinAccessible) {
/*  80 */     this.accessible = paramWinAccessible;
/*  81 */     this.peer = _createTextRangeProvider(paramWinAccessible.getNativeAccessible());
/*  82 */     this.id = idCount++;
/*     */   }
/*     */   
/*     */   long getNativeProvider() {
/*  86 */     return this.peer;
/*     */   }
/*     */   
/*     */   void dispose() {
/*  90 */     _destroyTextRangeProvider(this.peer);
/*  91 */     this.peer = 0L;
/*     */   }
/*     */   
/*     */   void setRange(int paramInt1, int paramInt2) {
/*  95 */     this.start = paramInt1;
/*  96 */     this.end = paramInt2;
/*     */   }
/*     */   
/*     */   int getStart() {
/* 100 */     return this.start;
/*     */   }
/*     */   
/*     */   int getEnd() {
/* 104 */     return this.end;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 108 */     return "Range(start: " + this.start + ", end: " + this.end + ", id: " + this.id + ")";
/*     */   }
/*     */   
/*     */   private Object getAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 112 */     return this.accessible.getAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */   
/*     */   private boolean isWordStart(BreakIterator paramBreakIterator, String paramString, int paramInt) {
/* 116 */     if (paramInt == 0) return true; 
/* 117 */     if (paramInt == paramString.length()) return true; 
/* 118 */     if (paramInt == -1) return true; 
/* 119 */     return (paramBreakIterator.isBoundary(paramInt) && Character.isLetterOrDigit(paramString.charAt(paramInt)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long Clone() {
/* 126 */     WinTextRangeProvider winTextRangeProvider = new WinTextRangeProvider(this.accessible);
/* 127 */     winTextRangeProvider.setRange(this.start, this.end);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     return winTextRangeProvider.getNativeProvider();
/*     */   }
/*     */   
/*     */   private boolean Compare(WinTextRangeProvider paramWinTextRangeProvider) {
/* 137 */     if (paramWinTextRangeProvider == null) return false; 
/* 138 */     return (this.accessible == paramWinTextRangeProvider.accessible && this.start == paramWinTextRangeProvider.start && this.end == paramWinTextRangeProvider.end);
/*     */   }
/*     */   
/*     */   private int CompareEndpoints(int paramInt1, WinTextRangeProvider paramWinTextRangeProvider, int paramInt2) {
/* 142 */     int i = (paramInt1 == 0) ? this.start : this.end;
/* 143 */     int j = (paramInt2 == 0) ? paramWinTextRangeProvider.start : paramWinTextRangeProvider.end;
/* 144 */     return i - j; } private void ExpandToEnclosingUnit(int paramInt) { BreakIterator breakIterator1; Integer integer1, integer2;
/*     */     BreakIterator breakIterator2;
/*     */     Integer integer3;
/*     */     int j;
/* 148 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 149 */     if (str == null)
/* 150 */       return;  int i = str.length();
/* 151 */     if (i == 0)
/*     */       return; 
/* 153 */     switch (paramInt) {
/*     */       case 0:
/* 155 */         if (this.start == i) this.start--; 
/* 156 */         this.end = this.start + 1;
/*     */         break;
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 161 */         breakIterator1 = BreakIterator.getWordInstance();
/* 162 */         breakIterator1.setText(str);
/* 163 */         if (!isWordStart(breakIterator1, str, this.start)) {
/* 164 */           int k = breakIterator1.preceding(this.start);
/* 165 */           while (!isWordStart(breakIterator1, str, k)) {
/* 166 */             k = breakIterator1.previous();
/*     */           }
/* 168 */           this.start = (k != -1) ? k : 0;
/*     */         } 
/* 170 */         if (!isWordStart(breakIterator1, str, this.end)) {
/* 171 */           int k = breakIterator1.following(this.end);
/* 172 */           while (!isWordStart(breakIterator1, str, k)) {
/* 173 */             k = breakIterator1.next();
/*     */           }
/* 175 */           this.end = (k != -1) ? k : i;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 3:
/* 180 */         integer1 = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(this.start) });
/* 181 */         integer2 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { integer1 });
/* 182 */         integer3 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { integer1 });
/* 183 */         if (integer1 == null || integer3 == null || integer2 == null) {
/*     */           
/* 185 */           this.start = 0;
/* 186 */           this.end = i;
/*     */           break;
/*     */         } 
/* 189 */         this.start = integer2.intValue();
/* 190 */         this.end = integer3.intValue();
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 196 */         integer1 = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(this.start) });
/* 197 */         if (integer1 == null) {
/*     */           
/* 199 */           this.start = 0;
/* 200 */           this.end = i;
/*     */           break;
/*     */         } 
/* 203 */         breakIterator2 = BreakIterator.getSentenceInstance();
/* 204 */         breakIterator2.setText(str);
/* 205 */         if (!breakIterator2.isBoundary(this.start)) {
/* 206 */           int k = breakIterator2.preceding(this.start);
/* 207 */           this.start = (k != -1) ? k : 0;
/*     */         } 
/* 209 */         j = breakIterator2.following(this.start);
/* 210 */         this.end = (j != -1) ? j : i;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/*     */       case 6:
/* 216 */         this.start = 0;
/* 217 */         this.end = i;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 223 */     this.start = Math.max(0, Math.min(this.start, i));
/* 224 */     this.end = Math.max(this.start, Math.min(this.end, i)); }
/*     */ 
/*     */   
/*     */   private long FindAttribute(int paramInt, WinVariant paramWinVariant, boolean paramBoolean) {
/* 228 */     System.err.println("FindAttribute NOT IMPLEMENTED");
/* 229 */     return 0L;
/*     */   }
/*     */   
/*     */   private long FindText(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 233 */     if (paramString == null) return 0L; 
/* 234 */     String str1 = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 235 */     if (str1 == null) return 0L; 
/* 236 */     String str2 = str1.substring(this.start, this.end);
/* 237 */     if (paramBoolean2) {
/* 238 */       str2 = str2.toLowerCase();
/* 239 */       paramString = paramString.toLowerCase();
/*     */     } 
/* 241 */     int i = -1;
/* 242 */     if (paramBoolean1) {
/* 243 */       i = str2.lastIndexOf(paramString);
/*     */     } else {
/* 245 */       i = str2.indexOf(paramString);
/*     */     } 
/* 247 */     if (i == -1) return 0L; 
/* 248 */     WinTextRangeProvider winTextRangeProvider = new WinTextRangeProvider(this.accessible);
/* 249 */     winTextRangeProvider.setRange(this.start + i, this.start + i + paramString.length());
/* 250 */     return winTextRangeProvider.getNativeProvider();
/*     */   }
/*     */   private WinVariant GetAttributeValue(int paramInt) {
/*     */     Font font;
/* 254 */     WinVariant winVariant = null;
/* 255 */     switch (paramInt) {
/*     */       case 40005:
/* 257 */         font = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
/* 258 */         if (font != null) {
/* 259 */           winVariant = new WinVariant();
/* 260 */           winVariant.vt = 8;
/* 261 */           winVariant.bstrVal = font.getName();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 40006:
/* 266 */         font = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
/* 267 */         if (font != null) {
/* 268 */           winVariant = new WinVariant();
/* 269 */           winVariant.vt = 5;
/* 270 */           winVariant.dblVal = font.getSize();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 40007:
/* 275 */         font = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
/* 276 */         if (font != null) {
/* 277 */           boolean bool = font.getStyle().toLowerCase().contains("bold");
/* 278 */           winVariant = new WinVariant();
/* 279 */           winVariant.vt = 3;
/* 280 */           winVariant.lVal = bool ? FontWeight.BOLD.getWeight() : FontWeight.NORMAL.getWeight();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 40013:
/*     */       case 40015:
/* 286 */         winVariant = new WinVariant();
/* 287 */         winVariant.vt = 11;
/* 288 */         winVariant.boolVal = false;
/*     */         break;
/*     */       case 40014:
/* 291 */         font = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
/* 292 */         if (font != null) {
/* 293 */           boolean bool = font.getStyle().toLowerCase().contains("italic");
/* 294 */           winVariant = new WinVariant();
/* 295 */           winVariant.vt = 11;
/* 296 */           winVariant.boolVal = bool;
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 303 */     return winVariant;
/*     */   }
/*     */   
/*     */   private double[] GetBoundingRectangles() {
/* 307 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 308 */     if (str == null) return null; 
/* 309 */     int i = str.length();
/*     */ 
/*     */     
/* 312 */     if (i == 0) return new double[0]; 
/* 313 */     int j = this.end;
/* 314 */     if (j > 0 && j > this.start && str.charAt(j - 1) == '\n') {
/* 315 */       j--;
/*     */     }
/* 317 */     if (j > 0 && j > this.start && str.charAt(j - 1) == '\r') {
/* 318 */       j--;
/*     */     }
/* 320 */     if (j > 0 && j > this.start && j == i) {
/* 321 */       j--;
/*     */     }
/* 323 */     Bounds[] arrayOfBounds = (Bounds[])getAttribute(AccessibleAttribute.BOUNDS_FOR_RANGE, new Object[] { Integer.valueOf(this.start), Integer.valueOf(j) });
/* 324 */     if (arrayOfBounds != null) {
/* 325 */       double[] arrayOfDouble = new double[arrayOfBounds.length * 4];
/* 326 */       byte b1 = 0;
/* 327 */       for (byte b2 = 0; b2 < arrayOfBounds.length; b2++) {
/* 328 */         Bounds bounds = arrayOfBounds[b2];
/* 329 */         arrayOfDouble[b1++] = bounds.getMinX();
/* 330 */         arrayOfDouble[b1++] = bounds.getMinY();
/* 331 */         arrayOfDouble[b1++] = bounds.getWidth();
/* 332 */         arrayOfDouble[b1++] = bounds.getHeight();
/*     */       } 
/* 334 */       return arrayOfDouble;
/*     */     } 
/* 336 */     return null;
/*     */   }
/*     */   
/*     */   private long GetEnclosingElement() {
/* 340 */     return this.accessible.getNativeAccessible();
/*     */   }
/*     */   
/*     */   private String GetText(int paramInt) {
/* 344 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 345 */     if (str == null) return null; 
/* 346 */     int i = (paramInt != -1) ? Math.min(this.end, this.start + paramInt) : this.end;
/*     */     
/* 348 */     return str.substring(this.start, i); } private int Move(int paramInt1, int paramInt2) { int k; BreakIterator breakIterator2;
/*     */     Integer integer;
/*     */     BreakIterator breakIterator1;
/*     */     int m;
/* 352 */     if (paramInt2 == 0) return 0; 
/* 353 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 354 */     if (str == null) return 0; 
/* 355 */     int i = str.length();
/* 356 */     if (i == 0) return 0;
/*     */     
/* 358 */     int j = 0;
/* 359 */     switch (paramInt1) {
/*     */       case 0:
/* 361 */         k = this.start;
/* 362 */         this.start = Math.max(0, Math.min(this.start + paramInt2, i - 1));
/* 363 */         this.end = this.start + 1;
/* 364 */         j = this.start - k;
/*     */         break;
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 369 */         breakIterator2 = BreakIterator.getWordInstance();
/* 370 */         breakIterator2.setText(str);
/* 371 */         m = this.start;
/* 372 */         while (!isWordStart(breakIterator2, str, m)) {
/* 373 */           m = breakIterator2.preceding(this.start);
/*     */         }
/* 375 */         while (m != -1 && j != paramInt2) {
/* 376 */           if (paramInt2 > 0) {
/* 377 */             m = breakIterator2.following(m);
/* 378 */             while (!isWordStart(breakIterator2, str, m)) {
/* 379 */               m = breakIterator2.next();
/*     */             }
/* 381 */             j++; continue;
/*     */           } 
/* 383 */           m = breakIterator2.preceding(m);
/* 384 */           while (!isWordStart(breakIterator2, str, m)) {
/* 385 */             m = breakIterator2.previous();
/*     */           }
/* 387 */           j--;
/*     */         } 
/*     */         
/* 390 */         if (j != 0) {
/* 391 */           if (m != -1) {
/* 392 */             this.start = m;
/*     */           } else {
/* 394 */             this.start = (paramInt2 > 0) ? i : 0;
/*     */           } 
/* 396 */           m = breakIterator2.following(this.start);
/* 397 */           while (!isWordStart(breakIterator2, str, m)) {
/* 398 */             m = breakIterator2.next();
/*     */           }
/* 400 */           this.end = (m != -1) ? m : i;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 3:
/* 405 */         integer = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(this.start) });
/* 406 */         if (integer == null) return 0; 
/* 407 */         m = (paramInt2 > 0) ? 1 : -1;
/* 408 */         while (paramInt2 != j && 
/* 409 */           getAttribute(AccessibleAttribute.LINE_START, new Object[] { Integer.valueOf(integer.intValue() + m) }) != null) {
/* 410 */           integer = Integer.valueOf(integer.intValue() + m);
/* 411 */           j += m;
/*     */         } 
/* 413 */         if (j != 0) {
/* 414 */           Integer integer1 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { integer });
/* 415 */           Integer integer2 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { integer });
/* 416 */           if (integer1 == null || integer2 == null) return 0; 
/* 417 */           this.start = integer1.intValue();
/* 418 */           this.end = integer2.intValue();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 4:
/* 423 */         breakIterator1 = BreakIterator.getSentenceInstance();
/* 424 */         breakIterator1.setText(str);
/* 425 */         m = breakIterator1.isBoundary(this.start) ? this.start : breakIterator1.preceding(this.start);
/* 426 */         while (m != -1 && j != paramInt2) {
/* 427 */           if (paramInt2 > 0) {
/* 428 */             m = breakIterator1.following(m);
/* 429 */             j++; continue;
/*     */           } 
/* 431 */           m = breakIterator1.preceding(m);
/* 432 */           j--;
/*     */         } 
/*     */         
/* 435 */         if (j != 0) {
/* 436 */           this.start = (m != -1) ? m : 0;
/* 437 */           m = breakIterator1.following(this.start);
/* 438 */           this.end = (m != -1) ? m : i;
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/*     */       case 6:
/* 445 */         return 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 450 */     this.start = Math.max(0, Math.min(this.start, i));
/* 451 */     this.end = Math.max(this.start, Math.min(this.end, i));
/* 452 */     return j; } private int MoveEndpointByUnit(int paramInt1, int paramInt2, int paramInt3) { int m; BreakIterator breakIterator2; Integer integer1; BreakIterator breakIterator1;
/*     */     Integer integer2, integer3;
/*     */     byte b;
/*     */     int n;
/* 456 */     if (paramInt3 == 0) return 0; 
/* 457 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 458 */     if (str == null) return 0; 
/* 459 */     int i = str.length();
/*     */     
/* 461 */     int j = 0;
/* 462 */     int k = (paramInt1 == 0) ? this.start : this.end;
/* 463 */     switch (paramInt2) {
/*     */       case 0:
/* 465 */         m = k;
/* 466 */         k = Math.max(0, Math.min(k + paramInt3, i));
/* 467 */         j = k - m;
/*     */         break;
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 472 */         breakIterator2 = BreakIterator.getWordInstance();
/* 473 */         breakIterator2.setText(str);
/* 474 */         while (k != -1 && j != paramInt3) {
/* 475 */           if (paramInt3 > 0) {
/* 476 */             k = breakIterator2.following(k);
/* 477 */             while (!isWordStart(breakIterator2, str, k)) {
/* 478 */               k = breakIterator2.next();
/*     */             }
/* 480 */             j++; continue;
/*     */           } 
/* 482 */           k = breakIterator2.preceding(k);
/* 483 */           while (!isWordStart(breakIterator2, str, k)) {
/* 484 */             k = breakIterator2.previous();
/*     */           }
/* 486 */           j--;
/*     */         } 
/*     */         
/* 489 */         if (k == -1) {
/* 490 */           k = (paramInt3 > 0) ? i : 0;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 3:
/* 495 */         integer1 = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(k) });
/* 496 */         integer2 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { integer1 });
/* 497 */         integer3 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { integer1 });
/* 498 */         if (integer1 == null || integer2 == null || integer3 == null) {
/*     */           
/* 500 */           k = (paramInt3 > 0) ? i : 0;
/*     */           break;
/*     */         } 
/* 503 */         b = (paramInt3 > 0) ? 1 : -1;
/* 504 */         n = ((paramInt3 > 0) ? integer3 : integer2).intValue();
/* 505 */         if (k != n)
/*     */         {
/* 507 */           j += b;
/*     */         }
/* 509 */         while (paramInt3 != j && 
/* 510 */           getAttribute(AccessibleAttribute.LINE_START, new Object[] { Integer.valueOf(integer1.intValue() + b) }) != null) {
/* 511 */           integer1 = Integer.valueOf(integer1.intValue() + b);
/* 512 */           j += b;
/*     */         } 
/* 514 */         if (j != 0) {
/* 515 */           integer2 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { integer1 });
/* 516 */           integer3 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { integer1 });
/* 517 */           if (integer2 == null || integer3 == null) return 0; 
/* 518 */           k = ((paramInt3 > 0) ? integer3 : integer2).intValue();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 4:
/* 523 */         breakIterator1 = BreakIterator.getSentenceInstance();
/* 524 */         breakIterator1.setText(str);
/* 525 */         while (k != -1 && j != paramInt3) {
/* 526 */           if (paramInt3 > 0) {
/* 527 */             k = breakIterator1.following(k);
/* 528 */             j++; continue;
/*     */           } 
/* 530 */           k = breakIterator1.preceding(k);
/* 531 */           j--;
/*     */         } 
/*     */         
/* 534 */         if (k == -1) {
/* 535 */           k = (paramInt3 > 0) ? i : 0;
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/*     */       case 6:
/* 542 */         return 0;
/*     */     } 
/*     */     
/* 545 */     if (paramInt1 == 0) {
/* 546 */       this.start = k;
/*     */     } else {
/* 548 */       this.end = k;
/*     */     } 
/* 550 */     if (this.start > this.end) {
/* 551 */       this.start = this.end = k;
/*     */     }
/*     */ 
/*     */     
/* 555 */     this.start = Math.max(0, Math.min(this.start, i));
/* 556 */     this.end = Math.max(this.start, Math.min(this.end, i));
/* 557 */     return j; }
/*     */ 
/*     */   
/*     */   private void MoveEndpointByRange(int paramInt1, WinTextRangeProvider paramWinTextRangeProvider, int paramInt2) {
/* 561 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 562 */     if (str == null)
/* 563 */       return;  int i = str.length();
/*     */     
/* 565 */     int j = (paramInt2 == 0) ? paramWinTextRangeProvider.start : paramWinTextRangeProvider.end;
/* 566 */     if (paramInt1 == 0) {
/* 567 */       this.start = j;
/*     */     } else {
/* 569 */       this.end = j;
/*     */     } 
/* 571 */     if (this.start > this.end) {
/* 572 */       this.start = this.end = j;
/*     */     }
/*     */ 
/*     */     
/* 576 */     this.start = Math.max(0, Math.min(this.start, i));
/* 577 */     this.end = Math.max(this.start, Math.min(this.end, i));
/*     */   }
/*     */   
/*     */   private void Select() {
/* 581 */     this.accessible.executeAction(AccessibleAction.SET_TEXT_SELECTION, new Object[] { Integer.valueOf(this.start), Integer.valueOf(this.end) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void AddToSelection() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void RemoveFromSelection() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void ScrollIntoView(boolean paramBoolean) {
/* 595 */     this.accessible.executeAction(AccessibleAction.SHOW_TEXT_RANGE, new Object[] { Integer.valueOf(this.start), Integer.valueOf(this.end) });
/*     */   }
/*     */ 
/*     */   
/*     */   private long[] GetChildren() {
/* 600 */     return new long[0];
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */   
/*     */   private native long _createTextRangeProvider(long paramLong);
/*     */   
/*     */   private native void _destroyTextRangeProvider(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\win\WinTextRangeProvider.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */