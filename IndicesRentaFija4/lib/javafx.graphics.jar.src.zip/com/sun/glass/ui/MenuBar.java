/*    */ package com.sun.glass.ui;
/*    */ 
/*    */ import com.sun.glass.ui.delegate.MenuBarDelegate;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MenuBar
/*    */ {
/*    */   private final MenuBarDelegate delegate;
/* 36 */   private final List<Menu> menus = new ArrayList<>();
/*    */   
/*    */   protected MenuBar() {
/* 39 */     Application.checkEventThread();
/* 40 */     this.delegate = PlatformFactory.getPlatformFactory().createMenuBarDelegate(this);
/* 41 */     if (!this.delegate.createMenuBar()) {
/* 42 */       throw new RuntimeException("MenuBar creation error.");
/*    */     }
/*    */   }
/*    */   
/*    */   long getNativeMenu() {
/* 47 */     return this.delegate.getNativeMenu();
/*    */   }
/*    */   
/*    */   public void add(Menu paramMenu) {
/* 51 */     Application.checkEventThread();
/* 52 */     insert(paramMenu, this.menus.size());
/*    */   }
/*    */   
/*    */   public void insert(Menu paramMenu, int paramInt) {
/* 56 */     Application.checkEventThread();
/* 57 */     synchronized (this.menus) {
/* 58 */       if (this.delegate.insert(paramMenu.getDelegate(), paramInt)) {
/* 59 */         this.menus.add(paramInt, paramMenu);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public void remove(int paramInt) {
/* 65 */     Application.checkEventThread();
/* 66 */     synchronized (this.menus) {
/* 67 */       Menu menu = this.menus.get(paramInt);
/* 68 */       if (this.delegate.remove(menu.getDelegate(), paramInt)) {
/* 69 */         this.menus.remove(paramInt);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public void remove(Menu paramMenu) {
/* 75 */     Application.checkEventThread();
/* 76 */     synchronized (this.menus) {
/* 77 */       int i = this.menus.indexOf(paramMenu);
/* 78 */       if (i >= 0 && 
/* 79 */         this.delegate.remove(paramMenu.getDelegate(), i)) {
/* 80 */         this.menus.remove(i);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Menu> getMenus() {
/* 89 */     Application.checkEventThread();
/* 90 */     return Collections.unmodifiableList(this.menus);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\MenuBar.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */