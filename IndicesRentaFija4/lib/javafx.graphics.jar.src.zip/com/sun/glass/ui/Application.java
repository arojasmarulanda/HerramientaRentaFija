/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import java.io.File;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.security.AccessController;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Application
/*     */ {
/*     */   private static final String DEFAULT_NAME = "java";
/*  43 */   protected String name = "java";
/*     */   
/*     */   private EventHandler eventHandler;
/*     */ 
/*     */   
/*     */   public static class EventHandler
/*     */   {
/*     */     public void handleWillFinishLaunchingAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidFinishLaunchingAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleWillBecomeActiveAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidBecomeActiveAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleWillResignActiveAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidResignActiveAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidReceiveMemoryWarning(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleWillHideAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidHideAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleWillUnhideAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidUnhideAction(Application param1Application, long param1Long) {}
/*     */     
/*     */     public void handleOpenFilesAction(Application param1Application, long param1Long, String[] param1ArrayOfString) {}
/*     */     
/*     */     public void handleQuitAction(Application param1Application, long param1Long) {}
/*     */     
/*     */     public boolean handleThemeChanged(String param1String) {
/*  87 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean initialActiveEventReceived = false;
/*  93 */   private String[] initialOpenedFiles = null; private static boolean loaded = false;
/*     */   private static Application application;
/*     */   private static Thread eventThread;
/*     */   private static final boolean disableThreadChecks;
/*     */   
/*     */   static {
/*  99 */     disableThreadChecks = ((Boolean)AccessController.<Boolean>doPrivileged(() -> { String str = System.getProperty("glass.disableThreadChecks", "false"); return Boolean.valueOf("true".equalsIgnoreCase(str)); })).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static synchronized void loadNativeLibrary(String paramString) {
/* 109 */     if (!loaded) {
/* 110 */       NativeLibLoader.loadLibrary(paramString);
/* 111 */       loaded = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static synchronized void loadNativeLibrary() {
/* 118 */     loadNativeLibrary("glass");
/*     */   }
/*     */   
/* 121 */   private static volatile Map deviceDetails = null;
/*     */ 
/*     */   
/*     */   private boolean terminateWhenLastWindowClosed;
/*     */ 
/*     */   
/*     */   public static void setDeviceDetails(Map paramMap) {
/* 128 */     deviceDetails = paramMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map getDeviceDetails() {
/* 133 */     return deviceDetails;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void run(Runnable paramRunnable) {
/* 141 */     if (application != null) {
/* 142 */       throw new IllegalStateException("Application is already running");
/*     */     }
/* 144 */     application = PlatformFactory.getPlatformFactory().createApplication();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 151 */       application.runLoop(() -> {
/*     */             Screen.initScreens();
/*     */             paramRunnable.run();
/*     */           });
/* 155 */     } catch (Throwable throwable) {
/* 156 */       throwable.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finishTerminating() {
/* 166 */     application = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 181 */     checkEventThread();
/* 182 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/* 198 */     checkEventThread();
/* 199 */     if (paramString != null && "java".equals(this.name)) {
/* 200 */       this.name = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataDirectory() {
/* 215 */     checkEventThread();
/* 216 */     String str = AccessController.<String>doPrivileged(() -> System.getProperty("user.home"));
/* 217 */     return str + str + "." + File.separator + this.name;
/*     */   }
/*     */   
/*     */   private void notifyWillFinishLaunching() {
/* 221 */     EventHandler eventHandler = getEventHandler();
/* 222 */     if (eventHandler != null) {
/* 223 */       eventHandler.handleWillFinishLaunchingAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyDidFinishLaunching() {
/* 228 */     EventHandler eventHandler = getEventHandler();
/* 229 */     if (eventHandler != null) {
/* 230 */       eventHandler.handleDidFinishLaunchingAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyWillBecomeActive() {
/* 235 */     EventHandler eventHandler = getEventHandler();
/* 236 */     if (eventHandler != null) {
/* 237 */       eventHandler.handleWillBecomeActiveAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyDidBecomeActive() {
/* 242 */     this.initialActiveEventReceived = true;
/* 243 */     EventHandler eventHandler = getEventHandler();
/* 244 */     if (eventHandler != null) {
/* 245 */       eventHandler.handleDidBecomeActiveAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyWillResignActive() {
/* 250 */     EventHandler eventHandler = getEventHandler();
/* 251 */     if (eventHandler != null) {
/* 252 */       eventHandler.handleWillResignActiveAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean notifyThemeChanged(String paramString) {
/* 257 */     EventHandler eventHandler = getEventHandler();
/* 258 */     if (eventHandler != null) {
/* 259 */       return eventHandler.handleThemeChanged(paramString);
/*     */     }
/* 261 */     return false;
/*     */   }
/*     */   
/*     */   private void notifyDidResignActive() {
/* 265 */     EventHandler eventHandler = getEventHandler();
/* 266 */     if (eventHandler != null) {
/* 267 */       eventHandler.handleDidResignActiveAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyDidReceiveMemoryWarning() {
/* 272 */     EventHandler eventHandler = getEventHandler();
/* 273 */     if (eventHandler != null) {
/* 274 */       eventHandler.handleDidReceiveMemoryWarning(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyWillHide() {
/* 279 */     EventHandler eventHandler = getEventHandler();
/* 280 */     if (eventHandler != null) {
/* 281 */       eventHandler.handleWillHideAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyDidHide() {
/* 286 */     EventHandler eventHandler = getEventHandler();
/* 287 */     if (eventHandler != null) {
/* 288 */       eventHandler.handleDidHideAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyWillUnhide() {
/* 293 */     EventHandler eventHandler = getEventHandler();
/* 294 */     if (eventHandler != null) {
/* 295 */       eventHandler.handleWillUnhideAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyDidUnhide() {
/* 300 */     EventHandler eventHandler = getEventHandler();
/* 301 */     if (eventHandler != null) {
/* 302 */       eventHandler.handleDidUnhideAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void notifyOpenFiles(String[] paramArrayOfString) {
/* 308 */     if (!this.initialActiveEventReceived && this.initialOpenedFiles == null)
/*     */     {
/* 310 */       this.initialOpenedFiles = paramArrayOfString;
/*     */     }
/* 312 */     EventHandler eventHandler = getEventHandler();
/* 313 */     if (eventHandler != null && paramArrayOfString != null) {
/* 314 */       eventHandler.handleOpenFilesAction(this, System.nanoTime(), paramArrayOfString);
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyWillQuit() {
/* 319 */     EventHandler eventHandler = getEventHandler();
/* 320 */     if (eventHandler != null) {
/* 321 */       eventHandler.handleQuitAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void installDefaultMenus(MenuBar paramMenuBar) {
/* 332 */     checkEventThread();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventHandler getEventHandler() {
/* 340 */     return this.eventHandler;
/*     */   }
/*     */   
/*     */   public void setEventHandler(EventHandler paramEventHandler) {
/* 344 */     checkEventThread();
/* 345 */     boolean bool = (this.eventHandler != null && this.initialOpenedFiles != null) ? true : false;
/* 346 */     this.eventHandler = paramEventHandler;
/* 347 */     if (bool == true)
/*     */     {
/* 349 */       notifyOpenFiles(this.initialOpenedFiles); } 
/*     */   }
/*     */   
/*     */   protected Application() {
/* 353 */     this.terminateWhenLastWindowClosed = true;
/*     */   } public final boolean shouldTerminateWhenLastWindowClosed() {
/* 355 */     checkEventThread();
/* 356 */     return this.terminateWhenLastWindowClosed;
/*     */   }
/*     */   public final void setTerminateWhenLastWindowClosed(boolean paramBoolean) {
/* 359 */     checkEventThread();
/* 360 */     this.terminateWhenLastWindowClosed = paramBoolean;
/*     */   }
/*     */   
/*     */   public boolean shouldUpdateWindow() {
/* 364 */     checkEventThread();
/* 365 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasWindowManager() {
/* 370 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyRenderingFinished() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void terminate() {
/* 382 */     checkEventThread();
/*     */     try {
/* 384 */       LinkedList<Window> linkedList = new LinkedList<>(Window.getWindows());
/* 385 */       for (Window window : linkedList)
/*     */       {
/* 387 */         window.setVisible(false);
/*     */       }
/* 389 */       for (Window window : linkedList)
/*     */       {
/* 391 */         window.close();
/*     */       }
/* 393 */     } catch (Throwable throwable) {
/* 394 */       throwable.printStackTrace();
/*     */     } finally {
/* 396 */       finishTerminating();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Application GetApplication() {
/* 402 */     return application;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void setEventThread(Thread paramThread) {
/* 407 */     eventThread = paramThread;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Thread getEventThread() {
/* 412 */     return eventThread;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEventThread() {
/* 419 */     return (Thread.currentThread() == eventThread);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkEventThread() {
/* 436 */     if (!disableThreadChecks && 
/* 437 */       Thread.currentThread() != eventThread)
/*     */     {
/* 439 */       throw new IllegalStateException("This operation is permitted on the event thread only; currentThread = " + 
/*     */           
/* 441 */           Thread.currentThread().getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void reportException(Throwable paramThrowable) {
/* 448 */     Thread thread = Thread.currentThread();
/*     */     
/* 450 */     Thread.UncaughtExceptionHandler uncaughtExceptionHandler = thread.getUncaughtExceptionHandler();
/* 451 */     uncaughtExceptionHandler.uncaughtException(thread, paramThrowable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokeAndWait(Runnable paramRunnable) {
/* 460 */     if (paramRunnable == null) {
/*     */       return;
/*     */     }
/* 463 */     if (isEventThread()) {
/* 464 */       paramRunnable.run();
/*     */     } else {
/* 466 */       GetApplication()._invokeAndWait(paramRunnable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokeLater(Runnable paramRunnable) {
/* 476 */     if (paramRunnable == null) {
/*     */       return;
/*     */     }
/* 479 */     GetApplication()._invokeLater(paramRunnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 485 */   private static int nestedEventLoopCounter = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object enterNestedEventLoop() {
/* 505 */     checkEventThread();
/*     */     
/* 507 */     nestedEventLoopCounter++;
/*     */     try {
/* 509 */       return GetApplication()._enterNestedEventLoop();
/*     */     } finally {
/* 511 */       nestedEventLoopCounter--;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void leaveNestedEventLoop(Object paramObject) {
/* 532 */     checkEventThread();
/*     */     
/* 534 */     if (nestedEventLoopCounter == 0) {
/* 535 */       throw new IllegalStateException("Not in a nested event loop");
/*     */     }
/*     */     
/* 538 */     GetApplication()._leaveNestedEventLoop(paramObject);
/*     */   }
/*     */   
/*     */   public static boolean isNestedLoopRunning() {
/* 542 */     checkEventThread();
/* 543 */     return (nestedEventLoopCounter > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void menuAboutAction() {
/* 548 */     System.err.println("about");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Window createWindow(Screen paramScreen, int paramInt) {
/* 577 */     return createWindow(null, paramScreen, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Menu createMenu(String paramString) {
/* 591 */     return new Menu(paramString);
/*     */   }
/*     */   
/*     */   public final Menu createMenu(String paramString, boolean paramBoolean) {
/* 595 */     return new Menu(paramString, paramBoolean);
/*     */   }
/*     */   
/*     */   public final MenuBar createMenuBar() {
/* 599 */     return new MenuBar();
/*     */   }
/*     */   
/*     */   public final MenuItem createMenuItem(String paramString) {
/* 603 */     return createMenuItem(paramString, null);
/*     */   }
/*     */   
/*     */   public final MenuItem createMenuItem(String paramString, MenuItem.Callback paramCallback) {
/* 607 */     return createMenuItem(paramString, paramCallback, 0, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public final MenuItem createMenuItem(String paramString, MenuItem.Callback paramCallback, int paramInt1, int paramInt2) {
/* 612 */     return createMenuItem(paramString, paramCallback, paramInt1, paramInt2, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public final MenuItem createMenuItem(String paramString, MenuItem.Callback paramCallback, int paramInt1, int paramInt2, Pixels paramPixels) {
/* 617 */     return new MenuItem(paramString, paramCallback, paramInt1, paramInt2, paramPixels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Pixels createPixels(int paramInt1, int paramInt2, int[] paramArrayOfint, float paramFloat1, float paramFloat2) {
/* 627 */     return GetApplication().createPixels(paramInt1, paramInt2, IntBuffer.wrap(paramArrayOfint), paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */   
/*     */   static float getScaleFactor(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 632 */     float f = 0.0F;
/*     */     
/* 634 */     for (Screen screen : Screen.getScreens()) {
/* 635 */       int i = screen.getX(), j = screen.getY(), k = screen.getWidth(), m = screen.getHeight();
/* 636 */       if (paramInt1 < i + k && paramInt1 + paramInt3 > i && paramInt2 < j + m && paramInt2 + paramInt4 > j) {
/* 637 */         if (f < screen.getRecommendedOutputScaleX()) {
/* 638 */           f = screen.getRecommendedOutputScaleX();
/*     */         }
/* 640 */         if (f < screen.getRecommendedOutputScaleY()) {
/* 641 */           f = screen.getRecommendedOutputScaleY();
/*     */         }
/*     */       } 
/*     */     } 
/* 645 */     return (f == 0.0F) ? 1.0F : f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final EventLoop createEventLoop() {
/* 659 */     return new EventLoop();
/*     */   }
/*     */   public Accessible createAccessible() {
/* 662 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHighContrastTheme() {
/* 678 */     checkEventThread();
/* 679 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _supportsInputMethods() {
/* 684 */     return false;
/*     */   }
/*     */   public final boolean supportsInputMethods() {
/* 687 */     checkEventThread();
/* 688 */     return _supportsInputMethods();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean supportsTransparentWindows() {
/* 693 */     checkEventThread();
/* 694 */     return _supportsTransparentWindows();
/*     */   }
/*     */   
/*     */   public boolean hasTwoLevelFocus() {
/* 698 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasVirtualKeyboard() {
/* 702 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasTouch() {
/* 706 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasMultiTouch() {
/* 710 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasPointer() {
/* 714 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean supportsUnifiedWindows() {
/* 719 */     checkEventThread();
/* 720 */     return _supportsUnifiedWindows();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _supportsSystemMenu() {
/* 725 */     return false;
/*     */   }
/*     */   public final boolean supportsSystemMenu() {
/* 728 */     checkEventThread();
/* 729 */     return _supportsSystemMenu();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getKeyCodeForChar(char paramChar) {
/* 742 */     return application._getKeyCodeForChar(paramChar);
/*     */   }
/*     */   
/*     */   protected abstract void runLoop(Runnable paramRunnable);
/*     */   
/*     */   protected abstract void _invokeAndWait(Runnable paramRunnable);
/*     */   
/*     */   protected abstract void _invokeLater(Runnable paramRunnable);
/*     */   
/*     */   protected abstract Object _enterNestedEventLoop();
/*     */   
/*     */   protected abstract void _leaveNestedEventLoop(Object paramObject);
/*     */   
/*     */   public abstract Window createWindow(Window paramWindow, Screen paramScreen, int paramInt);
/*     */   
/*     */   public abstract Window createWindow(long paramLong);
/*     */   
/*     */   public abstract View createView();
/*     */   
/*     */   public abstract Cursor createCursor(int paramInt);
/*     */   
/*     */   public abstract Cursor createCursor(int paramInt1, int paramInt2, Pixels paramPixels);
/*     */   
/*     */   protected abstract void staticCursor_setVisible(boolean paramBoolean);
/*     */   
/*     */   protected abstract Size staticCursor_getBestSize(int paramInt1, int paramInt2);
/*     */   
/*     */   public abstract Pixels createPixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer);
/*     */   
/*     */   public abstract Pixels createPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer);
/*     */   
/*     */   public abstract Pixels createPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer, float paramFloat1, float paramFloat2);
/*     */   
/*     */   protected abstract int staticPixels_getNativeFormat();
/*     */   
/*     */   public abstract GlassRobot createRobot();
/*     */   
/*     */   protected abstract double staticScreen_getVideoRefreshPeriod();
/*     */   
/*     */   protected abstract Screen[] staticScreen_getScreens();
/*     */   
/*     */   public abstract Timer createTimer(Runnable paramRunnable);
/*     */   
/*     */   protected abstract int staticTimer_getMinPeriod();
/*     */   
/*     */   protected abstract int staticTimer_getMaxPeriod();
/*     */   
/*     */   protected abstract CommonDialogs.FileChooserResult staticCommonDialogs_showFileChooser(Window paramWindow, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt2);
/*     */   
/*     */   protected abstract File staticCommonDialogs_showFolderChooser(Window paramWindow, String paramString1, String paramString2);
/*     */   
/*     */   protected abstract long staticView_getMultiClickTime();
/*     */   
/*     */   protected abstract int staticView_getMultiClickMaxX();
/*     */   
/*     */   protected abstract int staticView_getMultiClickMaxY();
/*     */   
/*     */   protected abstract boolean _supportsTransparentWindows();
/*     */   
/*     */   protected abstract boolean _supportsUnifiedWindows();
/*     */   
/*     */   protected abstract int _getKeyCodeForChar(char paramChar);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\Application.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */