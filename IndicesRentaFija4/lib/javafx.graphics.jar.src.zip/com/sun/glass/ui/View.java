/*      */ package com.sun.glass.ui;
/*      */ 
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.security.AccessController;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class View
/*      */ {
/*      */   public static final int GESTURE_NO_VALUE = 2147483647;
/*      */   public static final double GESTURE_NO_DOUBLE_VALUE = NaND;
/*      */   public static final byte IME_ATTR_INPUT = 0;
/*      */   public static final byte IME_ATTR_TARGET_CONVERTED = 1;
/*      */   public static final byte IME_ATTR_CONVERTED = 2;
/*      */   public static final byte IME_ATTR_TARGET_NOTCONVERTED = 3;
/*      */   public static final byte IME_ATTR_INPUT_ERROR = 4;
/*      */   static final boolean accessible;
/*      */   private volatile long ptr;
/*      */   private Window window;
/*      */   private EventHandler eventHandler;
/*      */   
/*      */   static {
/*   47 */     accessible = ((Boolean)AccessController.<Boolean>doPrivileged(() -> {
/*      */           String str = System.getProperty("glass.accessible.force");
/*      */           if (str != null) {
/*      */             return Boolean.valueOf(Boolean.parseBoolean(str));
/*      */           }
/*      */           try {
/*      */             String str1 = Platform.determinePlatform();
/*      */             String str2 = System.getProperty("os.version").replaceFirst("(\\d+)\\.\\d+.*", "$1");
/*      */             String str3 = System.getProperty("os.version").replaceFirst("\\d+\\.(\\d+).*", "$1");
/*      */             int i = Integer.parseInt(str2) * 100 + Integer.parseInt(str3);
/*   57 */             return Boolean.valueOf(((str1.equals("Mac") && i >= 1009) || (str1.equals("Win") && i >= 601)));
/*      */           }
/*   59 */           catch (Exception exception) {
/*      */             return Boolean.valueOf(false);
/*      */           } 
/*      */         })).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EventHandler
/*      */   {
/*      */     public void handleViewEvent(View param1View, long param1Long, int param1Int) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleKeyEvent(View param1View, long param1Long, int param1Int1, int param1Int2, char[] param1ArrayOfchar, int param1Int3) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleMenuEvent(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, boolean param1Boolean) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleMouseEvent(View param1View, long param1Long, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, boolean param1Boolean1, boolean param1Boolean2) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleScrollEvent(View param1View, long param1Long, int param1Int1, int param1Int2, int param1Int3, int param1Int4, double param1Double1, double param1Double2, int param1Int5, int param1Int6, int param1Int7, int param1Int8, int param1Int9, double param1Double3, double param1Double4) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleInputMethodEvent(long param1Long, String param1String, int[] param1ArrayOfint1, int[] param1ArrayOfint2, byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double[] getInputMethodCandidatePos(int param1Int) {
/*  118 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleDragStart(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, ClipboardAssistance param1ClipboardAssistance) {}
/*      */ 
/*      */     
/*      */     public void handleDragEnd(View param1View, int param1Int) {}
/*      */ 
/*      */     
/*      */     public int handleDragEnter(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, ClipboardAssistance param1ClipboardAssistance) {
/*  130 */       return param1Int5;
/*      */     }
/*      */ 
/*      */     
/*      */     public int handleDragOver(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, ClipboardAssistance param1ClipboardAssistance) {
/*  135 */       return param1Int5;
/*      */     }
/*      */ 
/*      */     
/*      */     public void handleDragLeave(View param1View, ClipboardAssistance param1ClipboardAssistance) {}
/*      */ 
/*      */     
/*      */     public int handleDragDrop(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, ClipboardAssistance param1ClipboardAssistance) {
/*  143 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleBeginTouchEvent(View param1View, long param1Long, int param1Int1, boolean param1Boolean, int param1Int2) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleNextTouchEvent(View param1View, long param1Long1, int param1Int1, long param1Long2, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleEndTouchEvent(View param1View, long param1Long) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleScrollGestureEvent(View param1View, long param1Long, int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleZoomGestureEvent(View param1View, long param1Long, int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, double param1Double1, double param1Double2, double param1Double3, double param1Double4) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleRotateGestureEvent(View param1View, long param1Long, int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, double param1Double1, double param1Double2) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleSwipeGestureEvent(View param1View, long param1Long, int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Accessible getSceneAccessible() {
/*  367 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   public static long getMultiClickTime() {
/*  372 */     Application.checkEventThread();
/*  373 */     return Application.GetApplication().staticView_getMultiClickTime();
/*      */   }
/*      */   
/*      */   public static int getMultiClickMaxX() {
/*  377 */     Application.checkEventThread();
/*  378 */     return Application.GetApplication().staticView_getMultiClickMaxX();
/*      */   }
/*      */   
/*      */   public static int getMultiClickMaxY() {
/*  382 */     Application.checkEventThread();
/*  383 */     return Application.GetApplication().staticView_getMultiClickMaxY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _finishInputMethodComposition(long paramLong) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  398 */   private int width = -1;
/*  399 */   private int height = -1;
/*      */   
/*      */   private boolean isValid = false;
/*      */   
/*      */   private boolean isVisible = false;
/*      */   private boolean inFullscreen = false;
/*      */   
/*      */   public static final class Capability
/*      */   {
/*      */     public static final int k3dKeyValue = 0;
/*      */     public static final int kSyncKeyValue = 1;
/*      */     public static final int k3dProjectionKeyValue = 2;
/*      */     public static final int k3dProjectionAngleKeyValue = 3;
/*      */     public static final int k3dDepthKeyValue = 4;
/*      */     public static final int kHiDPIAwareKeyValue = 5;
/*  414 */     public static final Object k3dKey = Integer.valueOf(0);
/*  415 */     public static final Object kSyncKey = Integer.valueOf(1);
/*  416 */     public static final Object k3dProjectionKey = Integer.valueOf(2);
/*  417 */     public static final Object k3dProjectionAngleKey = Integer.valueOf(3);
/*  418 */     public static final Object k3dDepthKey = Integer.valueOf(4);
/*  419 */     public static final Object kHiDPIAwareKey = Integer.valueOf(5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected View() {
/*  425 */     Application.checkEventThread();
/*  426 */     Application.GetApplication(); this.ptr = _create(Application.getDeviceDetails());
/*  427 */     if (this.ptr == 0L) {
/*  428 */       throw new RuntimeException("could not create platform view");
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkNotClosed() {
/*  433 */     if (this.ptr == 0L) {
/*  434 */       throw new IllegalStateException("The view has already been closed");
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isClosed() {
/*  439 */     Application.checkEventThread();
/*  440 */     return (this.ptr == 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getNativeView() {
/*  450 */     Application.checkEventThread();
/*  451 */     checkNotClosed();
/*  452 */     return _getNativeView(this.ptr);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNativeRemoteLayerId(String paramString) {
/*  457 */     Application.checkEventThread();
/*  458 */     throw new RuntimeException("This operation is not supported on this platform");
/*      */   }
/*      */   
/*      */   public Window getWindow() {
/*  462 */     Application.checkEventThread();
/*  463 */     return this.window;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getX() {
/*  469 */     Application.checkEventThread();
/*  470 */     checkNotClosed();
/*  471 */     return _getX(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getY() {
/*  477 */     Application.checkEventThread();
/*  478 */     checkNotClosed();
/*  479 */     return _getY(this.ptr);
/*      */   }
/*      */   
/*      */   public int getWidth() {
/*  483 */     Application.checkEventThread();
/*  484 */     return this.width;
/*      */   }
/*      */   
/*      */   public int getHeight() {
/*  488 */     Application.checkEventThread();
/*  489 */     return this.height;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setWindow(Window paramWindow) {
/*  496 */     Application.checkEventThread();
/*  497 */     checkNotClosed();
/*  498 */     this.window = paramWindow;
/*  499 */     _setParent(this.ptr, (paramWindow == null) ? 0L : paramWindow.getNativeHandle());
/*  500 */     this.isValid = (this.ptr != 0L && paramWindow != null);
/*      */   }
/*      */ 
/*      */   
/*      */   void setVisible(boolean paramBoolean) {
/*  505 */     this.isVisible = paramBoolean;
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() {
/*  510 */     Application.checkEventThread();
/*  511 */     if (this.ptr == 0L) {
/*      */       return;
/*      */     }
/*  514 */     if (isInFullscreen()) {
/*  515 */       _exitFullscreen(this.ptr, false);
/*      */     }
/*  517 */     Window window = getWindow();
/*  518 */     if (window != null) {
/*  519 */       window.setView(null);
/*      */     }
/*  521 */     this.isValid = false;
/*  522 */     _close(this.ptr);
/*  523 */     this.ptr = 0L;
/*      */   }
/*      */   
/*      */   public EventHandler getEventHandler() {
/*  527 */     Application.checkEventThread();
/*  528 */     return this.eventHandler;
/*      */   }
/*      */   
/*      */   public void setEventHandler(EventHandler paramEventHandler) {
/*  532 */     Application.checkEventThread();
/*  533 */     this.eventHandler = paramEventHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleViewEvent(long paramLong, int paramInt) {
/*  539 */     if (this.eventHandler != null) {
/*  540 */       this.eventHandler.handleViewEvent(this, paramLong, paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void handleKeyEvent(long paramLong, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3) {
/*  546 */     if (this.eventHandler != null) {
/*  547 */       this.eventHandler.handleKeyEvent(this, paramLong, paramInt1, paramInt2, paramArrayOfchar, paramInt3);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleMouseEvent(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean1, boolean paramBoolean2) {
/*  555 */     if (this.eventHandler != null) {
/*  556 */       this.eventHandler.handleMouseEvent(this, paramLong, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean1, paramBoolean2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleMenuEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
/*  563 */     if (this.eventHandler != null) {
/*  564 */       this.eventHandler.handleMenuEvent(this, paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void handleBeginTouchEvent(View paramView, long paramLong, int paramInt1, boolean paramBoolean, int paramInt2) {
/*  570 */     if (this.eventHandler != null) {
/*  571 */       this.eventHandler.handleBeginTouchEvent(paramView, paramLong, paramInt1, paramBoolean, paramInt2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleNextTouchEvent(View paramView, long paramLong1, int paramInt1, long paramLong2, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  579 */     if (this.eventHandler != null) {
/*  580 */       this.eventHandler.handleNextTouchEvent(paramView, paramLong1, paramInt1, paramLong2, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */     }
/*      */   }
/*      */   
/*      */   public void handleEndTouchEvent(View paramView, long paramLong) {
/*  585 */     if (this.eventHandler != null) {
/*  586 */       this.eventHandler.handleEndTouchEvent(paramView, paramLong);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleScrollGestureEvent(View paramView, long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*  597 */     if (this.eventHandler != null) {
/*  598 */       this.eventHandler.handleScrollGestureEvent(paramView, paramLong, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleZoomGestureEvent(View paramView, long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  611 */     if (this.eventHandler != null) {
/*  612 */       this.eventHandler.handleZoomGestureEvent(paramView, paramLong, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleRotateGestureEvent(View paramView, long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2) {
/*  625 */     if (this.eventHandler != null) {
/*  626 */       this.eventHandler.handleRotateGestureEvent(paramView, paramLong, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1, paramDouble2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleSwipeGestureEvent(View paramView, long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
/*  637 */     if (this.eventHandler != null) {
/*  638 */       this.eventHandler.handleSwipeGestureEvent(paramView, paramLong, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleInputMethodEvent(long paramLong, String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  647 */     if (this.eventHandler != null) {
/*  648 */       this.eventHandler.handleInputMethodEvent(paramLong, paramString, paramArrayOfint1, paramArrayOfint2, paramArrayOfbyte, paramInt1, paramInt2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void enableInputMethodEvents(boolean paramBoolean) {
/*  655 */     Application.checkEventThread();
/*  656 */     checkNotClosed();
/*  657 */     _enableInputMethodEvents(this.ptr, paramBoolean);
/*      */   }
/*      */   
/*      */   public void finishInputMethodComposition() {
/*  661 */     Application.checkEventThread();
/*  662 */     checkNotClosed();
/*  663 */     _finishInputMethodComposition(this.ptr);
/*      */   }
/*      */   
/*      */   private double[] getInputMethodCandidatePos(int paramInt) {
/*  667 */     if (this.eventHandler != null) {
/*  668 */       return this.eventHandler.getInputMethodCandidatePos(paramInt);
/*      */     }
/*  670 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private void handleDragStart(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, ClipboardAssistance paramClipboardAssistance) {
/*  675 */     if (this.eventHandler != null) {
/*  676 */       this.eventHandler.handleDragStart(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramClipboardAssistance);
/*      */     }
/*      */   }
/*      */   
/*      */   private void handleDragEnd(int paramInt) {
/*  681 */     if (this.eventHandler != null) {
/*  682 */       this.eventHandler.handleDragEnd(this, paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private int handleDragEnter(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, ClipboardAssistance paramClipboardAssistance) {
/*  688 */     if (this.eventHandler != null) {
/*  689 */       return this.eventHandler.handleDragEnter(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramClipboardAssistance);
/*      */     }
/*  691 */     return paramInt5;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int handleDragOver(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, ClipboardAssistance paramClipboardAssistance) {
/*  697 */     if (this.eventHandler != null) {
/*  698 */       return this.eventHandler.handleDragOver(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramClipboardAssistance);
/*      */     }
/*  700 */     return paramInt5;
/*      */   }
/*      */ 
/*      */   
/*      */   private void handleDragLeave(ClipboardAssistance paramClipboardAssistance) {
/*  705 */     if (this.eventHandler != null) {
/*  706 */       this.eventHandler.handleDragLeave(this, paramClipboardAssistance);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private int handleDragDrop(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, ClipboardAssistance paramClipboardAssistance) {
/*  712 */     if (this.eventHandler != null) {
/*  713 */       return this.eventHandler.handleDragDrop(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramClipboardAssistance);
/*      */     }
/*  715 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void scheduleRepaint() {
/*  724 */     Application.checkEventThread();
/*  725 */     checkNotClosed();
/*  726 */     _scheduleRepaint(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void lock() {
/*  735 */     checkNotClosed();
/*  736 */     _begin(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unlock() {
/*  746 */     checkNotClosed();
/*  747 */     _end(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNativeFrameBuffer() {
/*  756 */     return _getNativeFrameBuffer(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void uploadPixels(Pixels paramPixels) {
/*  768 */     Application.checkEventThread();
/*  769 */     checkNotClosed();
/*  770 */     lock();
/*      */     try {
/*  772 */       _uploadPixels(this.ptr, paramPixels);
/*      */     } finally {
/*  774 */       unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean enterFullscreen(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*  783 */     Application.checkEventThread();
/*  784 */     checkNotClosed();
/*  785 */     return _enterFullscreen(this.ptr, paramBoolean1, paramBoolean2, paramBoolean3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void exitFullscreen(boolean paramBoolean) {
/*  790 */     Application.checkEventThread();
/*  791 */     checkNotClosed();
/*  792 */     _exitFullscreen(this.ptr, paramBoolean);
/*      */   }
/*      */   
/*      */   public boolean isInFullscreen() {
/*  796 */     Application.checkEventThread();
/*  797 */     return this.inFullscreen;
/*      */   }
/*      */   
/*      */   public boolean toggleFullscreen(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*  801 */     Application.checkEventThread();
/*  802 */     checkNotClosed();
/*  803 */     if (!this.inFullscreen) {
/*  804 */       enterFullscreen(paramBoolean1, paramBoolean2, paramBoolean3);
/*      */     } else {
/*  806 */       exitFullscreen(paramBoolean1);
/*      */     } 
/*      */     
/*  809 */     _scheduleRepaint(this.ptr);
/*      */     
/*  811 */     return this.inFullscreen;
/*      */   }
/*      */   
/*      */   public void updateLocation() {
/*  815 */     notifyView(423);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyView(int paramInt) {
/*  823 */     if (paramInt == 421) {
/*  824 */       if (this.isValid) {
/*  825 */         handleViewEvent(System.nanoTime(), paramInt);
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  830 */       boolean bool = false;
/*      */       
/*  832 */       switch (paramInt) {
/*      */         case 412:
/*  834 */           this.isValid = false;
/*  835 */           bool = true;
/*      */           break;
/*      */         case 411:
/*  838 */           this.isValid = true;
/*  839 */           bool = true;
/*      */           break;
/*      */         case 431:
/*  842 */           this.inFullscreen = true;
/*  843 */           bool = true;
/*  844 */           if (getWindow() != null) {
/*  845 */             getWindow().notifyFullscreen(true);
/*      */           }
/*      */           break;
/*      */         case 432:
/*  849 */           this.inFullscreen = false;
/*  850 */           bool = true;
/*  851 */           if (getWindow() != null) {
/*  852 */             getWindow().notifyFullscreen(false);
/*      */           }
/*      */           break;
/*      */         case 422:
/*      */         case 423:
/*      */           break;
/*      */         default:
/*  859 */           System.err.println("Unknown view event type: " + paramInt);
/*      */           return;
/*      */       } 
/*      */       
/*  863 */       handleViewEvent(System.nanoTime(), paramInt);
/*      */       
/*  865 */       if (bool)
/*      */       {
/*      */         
/*  868 */         handleViewEvent(System.nanoTime(), 423);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void notifyResize(int paramInt1, int paramInt2) {
/*  874 */     if (this.width == paramInt1 && this.height == paramInt2) {
/*      */       return;
/*      */     }
/*      */     
/*  878 */     this.width = paramInt1;
/*  879 */     this.height = paramInt2;
/*  880 */     handleViewEvent(System.nanoTime(), 422);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyRepaint(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  887 */     notifyView(421);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyMenu(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
/*  894 */     handleMenuEvent(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  900 */   private static WeakReference<View> lastClickedView = null;
/*      */   private static int lastClickedButton;
/*      */   private static long lastClickedTime;
/*      */   private static int lastClickedX;
/*      */   private static int lastClickedY;
/*      */   private static int clickCount;
/*      */   private static boolean dragProcessed = false;
/*      */   private ClipboardAssistance dropSourceAssistant;
/*      */   ClipboardAssistance dropTargetAssistant;
/*      */   
/*      */   protected void notifyMouse(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean1, boolean paramBoolean2) {
/*  911 */     if (this.window != null)
/*      */     {
/*  913 */       if (this.window.handleMouseEvent(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6)) {
/*      */         return;
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  919 */     long l = System.nanoTime();
/*  920 */     if (paramInt1 == 221) {
/*  921 */       View view = (lastClickedView == null) ? null : lastClickedView.get();
/*      */       
/*  923 */       if (view == this && lastClickedButton == paramInt2 && l - lastClickedTime <= 1000000L * 
/*      */         
/*  925 */         getMultiClickTime() && 
/*  926 */         Math.abs(paramInt3 - lastClickedX) <= getMultiClickMaxX() && 
/*  927 */         Math.abs(paramInt4 - lastClickedY) <= getMultiClickMaxY()) {
/*      */         
/*  929 */         clickCount++;
/*      */       } else {
/*  931 */         clickCount = 1;
/*      */         
/*  933 */         lastClickedView = new WeakReference<>(this);
/*  934 */         lastClickedButton = paramInt2;
/*  935 */         lastClickedX = paramInt3;
/*  936 */         lastClickedY = paramInt4;
/*      */       } 
/*      */       
/*  939 */       lastClickedTime = l;
/*      */     } 
/*      */     
/*  942 */     handleMouseEvent(l, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean1, paramBoolean2);
/*      */ 
/*      */     
/*  945 */     if (paramInt1 == 223) {
/*      */       
/*  947 */       if (!dragProcessed) {
/*  948 */         notifyDragStart(paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
/*  949 */         dragProcessed = true;
/*      */       } 
/*      */     } else {
/*  952 */       dragProcessed = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, double paramDouble1, double paramDouble2, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, double paramDouble3, double paramDouble4) {
/*  963 */     if (this.eventHandler != null) {
/*  964 */       this.eventHandler.handleScrollEvent(this, System.nanoTime(), paramInt1, paramInt2, paramInt3, paramInt4, paramDouble1, paramDouble2, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramDouble3, paramDouble4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyKey(int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3) {
/*  971 */     handleKeyEvent(System.nanoTime(), paramInt1, paramInt2, paramArrayOfchar, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyInputMethod(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) {
/*  977 */     handleInputMethodEvent(System.nanoTime(), paramString, paramArrayOfint1, paramArrayOfint2, paramArrayOfbyte, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   
/*      */   protected double[] notifyInputMethodCandidatePosRequest(int paramInt) {
/*  982 */     double[] arrayOfDouble = getInputMethodCandidatePos(paramInt);
/*  983 */     if (arrayOfDouble == null) {
/*  984 */       arrayOfDouble = new double[2];
/*  985 */       arrayOfDouble[0] = 0.0D;
/*  986 */       arrayOfDouble[1] = 0.0D;
/*      */     } 
/*  988 */     return arrayOfDouble;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void notifyDragStart(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  993 */     this.dropSourceAssistant = new ClipboardAssistance("DND")
/*      */       {
/*      */         public void actionPerformed(int param1Int)
/*      */         {
/*  997 */           View.this.notifyDragEnd(param1Int);
/*      */         }
/*      */       };
/*      */     
/* 1001 */     handleDragStart(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, this.dropSourceAssistant);
/*      */     
/* 1003 */     if (this.dropSourceAssistant != null) {
/* 1004 */       this.dropSourceAssistant.close();
/* 1005 */       this.dropSourceAssistant = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void notifyDragEnd(int paramInt) {
/* 1010 */     handleDragEnd(paramInt);
/* 1011 */     if (this.dropSourceAssistant != null) {
/* 1012 */       this.dropSourceAssistant.close();
/* 1013 */       this.dropSourceAssistant = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int notifyDragEnter(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 1020 */     this.dropTargetAssistant = new ClipboardAssistance("DND") {
/*      */         public void flush() {
/* 1022 */           throw new UnsupportedOperationException("Flush is forbidden from target!");
/*      */         }
/*      */       };
/* 1025 */     return handleDragEnter(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, this.dropTargetAssistant);
/*      */   }
/*      */ 
/*      */   
/*      */   protected int notifyDragOver(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 1030 */     return handleDragOver(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, this.dropTargetAssistant);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void notifyDragLeave() {
/* 1035 */     handleDragLeave(this.dropTargetAssistant);
/* 1036 */     this.dropTargetAssistant.close();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int notifyDragDrop(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 1042 */     int i = handleDragDrop(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, this.dropTargetAssistant);
/* 1043 */     this.dropTargetAssistant.close();
/* 1044 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public void notifyBeginTouchEvent(int paramInt1, boolean paramBoolean, int paramInt2) {
/* 1049 */     handleBeginTouchEvent(this, System.nanoTime(), paramInt1, paramBoolean, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyNextTouchEvent(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 1055 */     handleNextTouchEvent(this, System.nanoTime(), paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */   }
/*      */ 
/*      */   
/*      */   public void notifyEndTouchEvent() {
/* 1060 */     handleEndTouchEvent(this, System.nanoTime());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyScrollGestureEvent(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 1069 */     handleScrollGestureEvent(this, System.nanoTime(), paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyZoomGestureEvent(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 1080 */     handleZoomGestureEvent(this, System.nanoTime(), paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyRotateGestureEvent(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2) {
/* 1091 */     handleRotateGestureEvent(this, System.nanoTime(), paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1, paramDouble2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifySwipeGestureEvent(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
/* 1101 */     handleSwipeGestureEvent(this, System.nanoTime(), paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long getAccessible() {
/* 1114 */     Application.checkEventThread();
/* 1115 */     checkNotClosed();
/* 1116 */     if (accessible) {
/* 1117 */       Accessible accessible = this.eventHandler.getSceneAccessible();
/* 1118 */       if (accessible != null) {
/* 1119 */         accessible.setView(this);
/* 1120 */         return accessible.getNativeAccessible();
/*      */       } 
/*      */     } 
/* 1123 */     return 0L;
/*      */   }
/*      */   
/*      */   protected abstract void _enableInputMethodEvents(long paramLong, boolean paramBoolean);
/*      */   
/*      */   protected abstract long _create(Map paramMap);
/*      */   
/*      */   protected abstract long _getNativeView(long paramLong);
/*      */   
/*      */   protected abstract int _getX(long paramLong);
/*      */   
/*      */   protected abstract int _getY(long paramLong);
/*      */   
/*      */   protected abstract void _setParent(long paramLong1, long paramLong2);
/*      */   
/*      */   protected abstract boolean _close(long paramLong);
/*      */   
/*      */   protected abstract void _scheduleRepaint(long paramLong);
/*      */   
/*      */   protected abstract void _begin(long paramLong);
/*      */   
/*      */   protected abstract void _end(long paramLong);
/*      */   
/*      */   protected abstract int _getNativeFrameBuffer(long paramLong);
/*      */   
/*      */   protected abstract void _uploadPixels(long paramLong, Pixels paramPixels);
/*      */   
/*      */   protected abstract boolean _enterFullscreen(long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
/*      */   
/*      */   protected abstract void _exitFullscreen(long paramLong, boolean paramBoolean);
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\glas\\ui\View.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */