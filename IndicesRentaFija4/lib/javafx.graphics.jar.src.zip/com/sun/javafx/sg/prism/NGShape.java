/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.prism.BasicStroke;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.RTTexture;
/*     */ import com.sun.prism.Texture;
/*     */ import com.sun.prism.impl.PrismSettings;
/*     */ import com.sun.prism.paint.Paint;
/*     */ import com.sun.prism.shape.ShapeRep;
/*     */ import javafx.scene.shape.StrokeLineCap;
/*     */ import javafx.scene.shape.StrokeLineJoin;
/*     */ import javafx.scene.shape.StrokeType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NGShape
/*     */   extends NGNode
/*     */ {
/*     */   private RTTexture cached3D;
/*     */   private double cachedW;
/*     */   private double cachedH;
/*     */   protected Paint fillPaint;
/*     */   protected Paint drawPaint;
/*     */   protected BasicStroke drawStroke;
/*     */   
/*     */   public enum Mode
/*     */   {
/*  46 */     EMPTY, FILL, STROKE, STROKE_FILL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   protected Mode mode = Mode.FILL;
/*     */   
/*     */   protected ShapeRep shapeRep;
/*     */   
/*     */   public void setMode(Mode paramMode) {
/*  64 */     if (paramMode != this.mode) {
/*  65 */       this.mode = paramMode;
/*  66 */       geometryChanged();
/*     */     } 
/*     */   }
/*     */   private boolean smooth; static final double THRESHOLD = 0.00390625D;
/*     */   public Mode getMode() {
/*  71 */     return this.mode;
/*     */   }
/*     */   
/*     */   public void setSmooth(boolean paramBoolean) {
/*  75 */     paramBoolean = (!PrismSettings.forceNonAntialiasedShape && paramBoolean);
/*  76 */     if (paramBoolean != this.smooth) {
/*  77 */       this.smooth = paramBoolean;
/*  78 */       visualsChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isSmooth() {
/*  83 */     return this.smooth;
/*     */   }
/*     */   
/*     */   public void setFillPaint(Object paramObject) {
/*  87 */     if (paramObject != this.fillPaint || (this.fillPaint != null && this.fillPaint
/*  88 */       .isMutable())) {
/*     */       
/*  90 */       this.fillPaint = (Paint)paramObject;
/*  91 */       visualsChanged();
/*  92 */       invalidateOpaqueRegion();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Paint getFillPaint() {
/*  97 */     return this.fillPaint;
/*     */   }
/*     */   
/*     */   public void setDrawPaint(Object paramObject) {
/* 101 */     if (paramObject != this.drawPaint || (this.drawPaint != null && this.drawPaint
/* 102 */       .isMutable())) {
/*     */       
/* 104 */       this.drawPaint = (Paint)paramObject;
/* 105 */       visualsChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setDrawStroke(BasicStroke paramBasicStroke) {
/* 110 */     if (this.drawStroke != paramBasicStroke) {
/* 111 */       this.drawStroke = paramBasicStroke;
/* 112 */       geometryChanged();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawStroke(float paramFloat1, StrokeType paramStrokeType, StrokeLineCap paramStrokeLineCap, StrokeLineJoin paramStrokeLineJoin, float paramFloat2, float[] paramArrayOffloat, float paramFloat3) {
/*     */     byte b;
/*     */     boolean bool1, bool2;
/* 123 */     if (paramStrokeType == StrokeType.CENTERED) {
/* 124 */       b = 0;
/* 125 */     } else if (paramStrokeType == StrokeType.INSIDE) {
/* 126 */       b = 1;
/*     */     } else {
/* 128 */       b = 2;
/*     */     } 
/*     */ 
/*     */     
/* 132 */     if (paramStrokeLineCap == StrokeLineCap.BUTT) {
/* 133 */       bool1 = false;
/* 134 */     } else if (paramStrokeLineCap == StrokeLineCap.SQUARE) {
/* 135 */       bool1 = true;
/*     */     } else {
/* 137 */       bool1 = true;
/*     */     } 
/*     */ 
/*     */     
/* 141 */     if (paramStrokeLineJoin == StrokeLineJoin.BEVEL) {
/* 142 */       bool2 = true;
/* 143 */     } else if (paramStrokeLineJoin == StrokeLineJoin.MITER) {
/* 144 */       bool2 = false;
/*     */     } else {
/* 146 */       bool2 = true;
/*     */     } 
/*     */     
/* 149 */     if (this.drawStroke == null) {
/* 150 */       this.drawStroke = new BasicStroke(b, paramFloat1, bool1, bool2, paramFloat2);
/*     */     } else {
/* 152 */       this.drawStroke.set(b, paramFloat1, bool1, bool2, paramFloat2);
/*     */     } 
/* 154 */     if (paramArrayOffloat.length > 0) {
/* 155 */       this.drawStroke.set(paramArrayOffloat, paramFloat3);
/*     */     } else {
/* 157 */       this.drawStroke.set((float[])null, 0.0F);
/*     */     } 
/*     */     
/* 160 */     geometryChanged();
/*     */   }
/*     */   
/*     */   public abstract Shape getShape();
/*     */   
/*     */   protected ShapeRep createShapeRep(Graphics paramGraphics) {
/* 166 */     return paramGraphics.getResourceFactory().createPathRep();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void visualsChanged() {
/* 171 */     super.visualsChanged();
/*     */ 
/*     */     
/* 174 */     if (this.cached3D != null) {
/* 175 */       this.cached3D.dispose();
/* 176 */       this.cached3D = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static double hypot(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 181 */     return Math.sqrt(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2 + paramDouble3 * paramDouble3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderContent(Graphics paramGraphics) {
/* 191 */     if (this.mode == Mode.EMPTY) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 196 */     boolean bool = paramGraphics instanceof com.sun.prism.PrinterGraphics;
/*     */ 
/*     */ 
/*     */     
/* 200 */     BaseTransform baseTransform = paramGraphics.getTransformNoClone();
/* 201 */     boolean bool1 = !baseTransform.is2D() ? true : false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     if (bool1) {
/* 208 */       double d1 = hypot(baseTransform.getMxx(), baseTransform.getMyx(), baseTransform.getMzx());
/* 209 */       double d2 = hypot(baseTransform.getMxy(), baseTransform.getMyy(), baseTransform.getMzy());
/* 210 */       double d3 = d1 * this.contentBounds.getWidth();
/* 211 */       double d4 = d2 * this.contentBounds.getHeight();
/* 212 */       if (this.cached3D != null) {
/* 213 */         this.cached3D.lock();
/* 214 */         if (this.cached3D.isSurfaceLost() || 
/* 215 */           Math.max(Math.abs(d3 - this.cachedW), Math.abs(d4 - this.cachedH)) > 0.00390625D) {
/*     */           
/* 217 */           this.cached3D.unlock();
/* 218 */           this.cached3D.dispose();
/* 219 */           this.cached3D = null;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 224 */       if (this.cached3D == null) {
/* 225 */         int k = (int)Math.ceil(d3);
/* 226 */         int m = (int)Math.ceil(d4);
/* 227 */         this.cachedW = d3;
/* 228 */         this.cachedH = d4;
/*     */ 
/*     */         
/* 231 */         if (k <= 0 || m <= 0) {
/*     */           return;
/*     */         }
/* 234 */         this.cached3D = paramGraphics.getResourceFactory().createRTTexture(k, m, Texture.WrapMode.CLAMP_TO_ZERO, false);
/*     */ 
/*     */         
/* 237 */         this.cached3D.setLinearFiltering(isSmooth());
/* 238 */         this.cached3D.contentsUseful();
/* 239 */         Graphics graphics = this.cached3D.createGraphics();
/*     */ 
/*     */         
/* 242 */         graphics.scale((float)d1, (float)d2);
/* 243 */         graphics.translate(-this.contentBounds.getMinX(), -this.contentBounds.getMinY());
/* 244 */         renderContent2D(graphics, bool);
/*     */       } 
/*     */       
/* 247 */       int i = this.cached3D.getContentWidth();
/* 248 */       int j = this.cached3D.getContentHeight();
/* 249 */       float f1 = this.contentBounds.getMinX();
/* 250 */       float f2 = this.contentBounds.getMinY();
/* 251 */       float f3 = f1 + (float)(i / d1);
/* 252 */       float f4 = f2 + (float)(j / d2);
/* 253 */       paramGraphics.drawTexture(this.cached3D, f1, f2, f3, f4, 0.0F, 0.0F, i, j);
/* 254 */       this.cached3D.unlock();
/*     */     } else {
/* 256 */       if (this.cached3D != null) {
/* 257 */         this.cached3D.dispose();
/* 258 */         this.cached3D = null;
/*     */       } 
/*     */       
/* 261 */       renderContent2D(paramGraphics, bool);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderContent2D(Graphics paramGraphics, boolean paramBoolean) {
/* 275 */     boolean bool1 = paramGraphics.isAntialiasedShape();
/* 276 */     boolean bool2 = isSmooth();
/* 277 */     if (bool2 != bool1) {
/* 278 */       paramGraphics.setAntialiasedShape(bool2);
/*     */     }
/*     */     
/* 281 */     ShapeRep shapeRep = paramBoolean ? null : this.shapeRep;
/* 282 */     if (shapeRep == null) {
/* 283 */       shapeRep = createShapeRep(paramGraphics);
/*     */     }
/* 285 */     Shape shape = getShape();
/* 286 */     if (this.mode != Mode.STROKE) {
/* 287 */       paramGraphics.setPaint(this.fillPaint);
/* 288 */       shapeRep.fill(paramGraphics, shape, this.contentBounds);
/*     */     } 
/* 290 */     if (this.mode != Mode.FILL && this.drawStroke.getLineWidth() > 0.0F) {
/* 291 */       paramGraphics.setPaint(this.drawPaint);
/* 292 */       paramGraphics.setStroke(this.drawStroke);
/* 293 */       shapeRep.draw(paramGraphics, shape, this.contentBounds);
/*     */     } 
/*     */     
/* 296 */     if (bool2 != bool1) {
/* 297 */       paramGraphics.setAntialiasedShape(bool1);
/*     */     }
/* 299 */     if (!paramBoolean) {
/* 300 */       this.shapeRep = shapeRep;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasOverlappingContents() {
/* 306 */     return (this.mode == Mode.STROKE_FILL);
/*     */   }
/*     */   
/*     */   protected Shape getStrokeShape() {
/* 310 */     return this.drawStroke.createStrokedShape(getShape());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void geometryChanged() {
/* 316 */     super.geometryChanged();
/* 317 */     if (this.shapeRep != null) {
/* 318 */       this.shapeRep.invalidate(ShapeRep.InvalidationType.LOCATION_AND_GEOMETRY);
/*     */     }
/*     */ 
/*     */     
/* 322 */     if (this.cached3D != null) {
/* 323 */       this.cached3D.dispose();
/* 324 */       this.cached3D = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasOpaqueRegion() {
/* 330 */     Mode mode = getMode();
/* 331 */     Paint paint = getFillPaint();
/* 332 */     return (super.hasOpaqueRegion() && (mode == Mode.FILL || mode == Mode.STROKE_FILL) && paint != null && paint
/*     */       
/* 334 */       .isOpaque());
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGShape.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */