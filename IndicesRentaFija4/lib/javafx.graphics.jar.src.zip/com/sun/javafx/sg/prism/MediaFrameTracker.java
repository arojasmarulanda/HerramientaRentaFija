package com.sun.javafx.sg.prism;

public interface MediaFrameTracker {
  void incrementDecodedFrameCount(int paramInt);
  
  void incrementRenderedFrameCount(int paramInt);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\MediaFrameTracker.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */