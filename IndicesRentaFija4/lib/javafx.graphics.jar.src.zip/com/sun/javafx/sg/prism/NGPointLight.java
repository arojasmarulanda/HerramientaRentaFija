package com.sun.javafx.sg.prism;

public class NGPointLight extends NGLightBase {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGPointLight.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */