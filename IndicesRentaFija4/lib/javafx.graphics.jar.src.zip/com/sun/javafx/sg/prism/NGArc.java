/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.Arc2D;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.prism.Graphics;
/*    */ import com.sun.prism.shape.ShapeRep;
/*    */ import javafx.scene.shape.ArcType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGArc
/*    */   extends NGShape
/*    */ {
/* 38 */   private Arc2D arc = new Arc2D();
/*    */ 
/*    */   
/*    */   public void updateArc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, ArcType paramArcType) {
/* 42 */     this.arc.x = paramFloat1 - paramFloat3;
/* 43 */     this.arc.width = paramFloat3 * 2.0F;
/* 44 */     this.arc.y = paramFloat2 - paramFloat4;
/* 45 */     this.arc.height = paramFloat4 * 2.0F;
/* 46 */     this.arc.start = paramFloat5;
/* 47 */     this.arc.extent = paramFloat6;
/*    */     
/* 49 */     if (paramArcType == ArcType.CHORD) {
/* 50 */       this.arc.setArcType(1);
/* 51 */     } else if (paramArcType == ArcType.OPEN) {
/* 52 */       this.arc.setArcType(0);
/* 53 */     } else if (paramArcType == ArcType.ROUND) {
/* 54 */       this.arc.setArcType(2);
/*    */     } else {
/* 56 */       throw new AssertionError("Unknown arc type specified");
/*    */     } 
/* 58 */     geometryChanged();
/*    */   }
/*    */   public Shape getShape() {
/* 61 */     return this.arc;
/*    */   } protected ShapeRep createShapeRep(Graphics paramGraphics) {
/* 63 */     return paramGraphics.getResourceFactory().createArcRep();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGArc.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */