/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.PixelFormat;
/*     */ import com.sun.prism.ResourceFactory;
/*     */ import com.sun.prism.Texture;
/*     */ import java.nio.Buffer;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NGExternalNode
/*     */   extends NGNode
/*     */ {
/*     */   private Texture dsttexture;
/*     */   private BufferData bufferData;
/*  42 */   private final AtomicReference<RenderData> renderData = new AtomicReference<>(null);
/*     */   
/*     */   private RenderData rd;
/*     */   
/*     */   private volatile ReentrantLock bufferLock;
/*     */ 
/*     */   
/*     */   protected void renderContent(Graphics paramGraphics) {
/*  50 */     RenderData renderData = this.renderData.getAndSet(null);
/*     */     
/*  52 */     if (renderData != null) {
/*  53 */       this.rd = renderData;
/*     */     }
/*  55 */     if (this.rd == null)
/*     */       return; 
/*  57 */     int i = this.rd.bdata.srcbounds.x;
/*  58 */     int j = this.rd.bdata.srcbounds.y;
/*  59 */     int k = this.rd.bdata.srcbounds.width;
/*  60 */     int m = this.rd.bdata.srcbounds.height;
/*     */     
/*  62 */     if (this.dsttexture != null) {
/*     */       
/*  64 */       this.dsttexture.lock();
/*     */       
/*  66 */       if (this.dsttexture.isSurfaceLost() || this.dsttexture
/*  67 */         .getContentWidth() != k || this.dsttexture
/*  68 */         .getContentHeight() != m) {
/*     */         
/*  70 */         this.dsttexture.unlock();
/*  71 */         this.dsttexture.dispose();
/*  72 */         this.rd = this.rd.copyAddDirtyRect(0, 0, k, m);
/*  73 */         this.dsttexture = createTexture(paramGraphics, this.rd);
/*     */       } 
/*     */     } else {
/*  76 */       this.dsttexture = createTexture(paramGraphics, this.rd);
/*     */     } 
/*  78 */     if (this.dsttexture == null) {
/*     */       return;
/*     */     }
/*     */     try {
/*  82 */       if (renderData != null) {
/*  83 */         this.bufferLock.lock();
/*     */         try {
/*  85 */           this.dsttexture.update(this.rd.bdata.srcbuffer, PixelFormat.INT_ARGB_PRE, this.rd.dirtyRect.x, this.rd.dirtyRect.y, i + this.rd.dirtyRect.x, j + this.rd.dirtyRect.y, this.rd.dirtyRect.width, this.rd.dirtyRect.height, this.rd.bdata.linestride * 4, false);
/*     */ 
/*     */         
/*     */         }
/*     */         finally {
/*     */ 
/*     */ 
/*     */           
/*  93 */           this.bufferLock.unlock();
/*     */         } 
/*  95 */         if (this.rd.clearTarget) {
/*  96 */           paramGraphics.clearQuad(0.0F, 0.0F, this.rd.bdata.usrwidth, this.rd.bdata.usrheight);
/*     */         }
/*     */       } 
/*     */       
/* 100 */       paramGraphics.drawTexture(this.dsttexture, 0.0F, 0.0F, this.rd.bdata.usrwidth, this.rd.bdata.usrheight, 0.0F, 0.0F, k, m);
/*     */     }
/*     */     finally {
/*     */       
/* 104 */       this.dsttexture.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Texture createTexture(Graphics paramGraphics, RenderData paramRenderData) {
/* 109 */     ResourceFactory resourceFactory = paramGraphics.getResourceFactory();
/* 110 */     if (!resourceFactory.isDeviceReady()) {
/* 111 */       return null;
/*     */     }
/* 113 */     Texture texture = resourceFactory.createTexture(PixelFormat.INT_ARGB_PRE, Texture.Usage.DYNAMIC, Texture.WrapMode.CLAMP_NOT_NEEDED, paramRenderData.bdata.srcbounds.width, paramRenderData.bdata.srcbounds.height);
/*     */ 
/*     */ 
/*     */     
/* 117 */     if (texture != null) {
/* 118 */       texture.contentsUseful();
/*     */     } else {
/* 120 */       System.err.println("NGExternalNode: failed to create a texture");
/*     */     } 
/* 122 */     return texture;
/*     */   }
/*     */   
/*     */   public void setLock(ReentrantLock paramReentrantLock) {
/* 126 */     this.bufferLock = paramReentrantLock;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BufferData
/*     */   {
/*     */     final Buffer srcbuffer;
/*     */ 
/*     */     
/*     */     final int linestride;
/*     */ 
/*     */     
/*     */     final Rectangle srcbounds;
/*     */ 
/*     */     
/*     */     final float usrwidth;
/*     */     
/*     */     final float usrheight;
/*     */     
/*     */     final double scaleX;
/*     */     
/*     */     final double scaleY;
/*     */ 
/*     */     
/*     */     BufferData(Buffer param1Buffer, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, float param1Float1, float param1Float2, double param1Double1, double param1Double2) {
/* 152 */       this.srcbuffer = param1Buffer;
/* 153 */       this.scaleX = param1Double1;
/* 154 */       this.scaleY = param1Double2;
/* 155 */       this.linestride = param1Int1;
/* 156 */       this.srcbounds = scale(new Rectangle(param1Int2, param1Int3, param1Int4, param1Int5));
/* 157 */       this.usrwidth = param1Float1;
/* 158 */       this.usrheight = param1Float2;
/*     */     }
/*     */     
/*     */     Rectangle scale(Rectangle param1Rectangle) {
/* 162 */       int i = param1Rectangle.x;
/* 163 */       param1Rectangle.x = (int)Math.round(i * this.scaleX);
/* 164 */       int j = param1Rectangle.y;
/* 165 */       param1Rectangle.y = (int)Math.round(j * this.scaleY);
/* 166 */       param1Rectangle.width = (int)Math.round(param1Rectangle.width * this.scaleX);
/* 167 */       param1Rectangle.height = (int)Math.round(param1Rectangle.height * this.scaleY);
/* 168 */       return param1Rectangle;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     BufferData copyWithBounds(int param1Int1, int param1Int2, int param1Int3, int param1Int4, float param1Float1, float param1Float2) {
/* 174 */       return new BufferData(this.srcbuffer, this.linestride, param1Int1, param1Int2, param1Int3, param1Int4, param1Float1, param1Float2, this.scaleX, this.scaleY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class RenderData
/*     */   {
/*     */     final NGExternalNode.BufferData bdata;
/*     */     
/*     */     final Rectangle dirtyRect;
/*     */     
/*     */     final boolean clearTarget;
/*     */ 
/*     */     
/*     */     RenderData(NGExternalNode.BufferData param1BufferData, int param1Int1, int param1Int2, int param1Int3, int param1Int4, boolean param1Boolean) {
/* 189 */       this(param1BufferData, param1Int1, param1Int2, param1Int3, param1Int4, param1Boolean, true);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     RenderData(NGExternalNode.BufferData param1BufferData, int param1Int1, int param1Int2, int param1Int3, int param1Int4, boolean param1Boolean1, boolean param1Boolean2) {
/* 196 */       this.bdata = param1BufferData;
/* 197 */       Rectangle rectangle = new Rectangle(param1Int1, param1Int2, param1Int3, param1Int4);
/* 198 */       this.dirtyRect = param1Boolean2 ? param1BufferData.scale(rectangle) : rectangle;
/* 199 */       this.dirtyRect.intersectWith(param1BufferData.srcbounds);
/* 200 */       this.clearTarget = param1Boolean1;
/*     */     }
/*     */ 
/*     */     
/*     */     RenderData copyAddDirtyRect(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 205 */       Rectangle rectangle = this.bdata.scale(new Rectangle(param1Int1, param1Int2, param1Int3, param1Int4));
/* 206 */       rectangle.add(this.dirtyRect);
/* 207 */       return new RenderData(this.bdata, rectangle.x, rectangle.y, rectangle.width, rectangle.height, this.clearTarget, false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImageBuffer(Buffer paramBuffer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, int paramInt5, double paramDouble1, double paramDouble2) {
/* 218 */     this.bufferData = new BufferData(paramBuffer, paramInt5, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat1, paramFloat2, paramDouble1, paramDouble2);
/*     */     
/* 220 */     this.renderData.set(new RenderData(this.bufferData, paramInt1, paramInt2, paramInt3, paramInt4, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImageBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2) {
/* 227 */     boolean bool = (paramInt3 < this.bufferData.usrwidth || paramInt4 < this.bufferData.usrheight) ? true : false;
/*     */     
/* 229 */     this.bufferData = this.bufferData.copyWithBounds(paramInt1, paramInt2, paramInt3, paramInt4, paramFloat1, paramFloat2);
/* 230 */     this.renderData.updateAndGet(paramRenderData -> {
/*     */           boolean bool = (paramRenderData != null) ? paramRenderData.clearTarget : false;
/*     */           return new RenderData(this.bufferData, paramInt1, paramInt2, paramInt3, paramInt4, bool | paramBoolean);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void repaintDirtyRegion(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 239 */     this.renderData.updateAndGet(paramRenderData -> (paramRenderData != null) ? paramRenderData.copyAddDirtyRect(paramInt1, paramInt2, paramInt3, paramInt4) : new RenderData(this.bufferData, paramInt1, paramInt2, paramInt3, paramInt4, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markContentDirty() {
/* 249 */     visualsChanged();
/*     */   }
/*     */   
/*     */   protected boolean hasOverlappingContents() {
/* 253 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGExternalNode.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */