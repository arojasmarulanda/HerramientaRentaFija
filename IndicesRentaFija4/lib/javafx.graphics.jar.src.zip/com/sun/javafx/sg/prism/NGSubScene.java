/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.prism.CompositeMode;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.RTTexture;
/*     */ import com.sun.prism.RenderTarget;
/*     */ import com.sun.prism.ResourceFactory;
/*     */ import com.sun.prism.Texture;
/*     */ import com.sun.prism.paint.Color;
/*     */ import com.sun.prism.paint.Paint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NGSubScene
/*     */   extends NGNode
/*     */ {
/*     */   private float slWidth;
/*     */   private float slHeight;
/*     */   private double lastScaledW;
/*     */   private double lastScaledH;
/*     */   private RTTexture rtt;
/*  50 */   private RTTexture resolveRTT = null;
/*  51 */   private NGNode root = null;
/*     */   
/*     */   private boolean renderSG = true;
/*     */   private final boolean depthBuffer;
/*     */   private final boolean msaa;
/*     */   private Paint fillPaint;
/*     */   private NGCamera camera;
/*     */   private NGLightBase[] lights;
/*     */   private boolean isOpaque;
/*     */   static final double THRESHOLD = 0.00390625D;
/*     */   
/*     */   private NGSubScene() {
/*  63 */     this(false, false);
/*     */   }
/*     */   
/*     */   public void setRoot(NGNode paramNGNode) {
/*  67 */     this.root = paramNGNode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFillPaint(Object paramObject) {
/*  72 */     this.fillPaint = (Paint)paramObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCamera(NGCamera paramNGCamera) {
/*  77 */     this.camera = (paramNGCamera == null) ? NGCamera.INSTANCE : paramNGCamera;
/*     */   }
/*     */   
/*     */   public void setWidth(float paramFloat) {
/*  81 */     if (this.slWidth != paramFloat) {
/*  82 */       this.slWidth = paramFloat;
/*  83 */       geometryChanged();
/*  84 */       invalidateRTT();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setHeight(float paramFloat) {
/*  89 */     if (this.slHeight != paramFloat) {
/*  90 */       this.slHeight = paramFloat;
/*  91 */       geometryChanged();
/*  92 */       invalidateRTT();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public NGLightBase[] getLights() {
/*  98 */     return this.lights;
/*     */   }
/*     */   public void setLights(NGLightBase[] paramArrayOfNGLightBase) {
/* 101 */     this.lights = paramArrayOfNGLightBase;
/*     */   }
/*     */   
/*     */   public void markContentDirty() {
/* 105 */     visualsChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void visualsChanged() {
/* 110 */     this.renderSG = true;
/* 111 */     super.visualsChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void geometryChanged() {
/* 116 */     this.renderSG = true;
/* 117 */     super.geometryChanged();
/*     */   }
/*     */   
/*     */   private void invalidateRTT() {
/* 121 */     if (this.rtt != null) {
/*     */ 
/*     */       
/* 124 */       this.rtt.dispose();
/* 125 */       this.rtt = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasOverlappingContents() {
/* 132 */     return false;
/*     */   }
/*     */   
/* 135 */   public NGSubScene(boolean paramBoolean1, boolean paramBoolean2) { this.isOpaque = false;
/*     */     this.depthBuffer = paramBoolean1;
/* 137 */     this.msaa = paramBoolean2; } private void applyBackgroundFillPaint(Graphics paramGraphics) { this.isOpaque = true;
/* 138 */     if (this.fillPaint != null) {
/* 139 */       if (this.fillPaint instanceof Color) {
/* 140 */         Color color = (Color)this.fillPaint;
/* 141 */         this.isOpaque = (color.getAlpha() >= 1.0D);
/* 142 */         paramGraphics.clear(color);
/*     */       } else {
/* 144 */         if (!this.fillPaint.isOpaque()) {
/* 145 */           paramGraphics.clear();
/* 146 */           this.isOpaque = false;
/*     */         } 
/* 148 */         paramGraphics.setPaint(this.fillPaint);
/* 149 */         paramGraphics.fillRect(0.0F, 0.0F, this.rtt.getContentWidth(), this.rtt.getContentHeight());
/*     */       } 
/*     */     } else {
/* 152 */       this.isOpaque = false;
/*     */       
/* 154 */       paramGraphics.clear();
/*     */     }  }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderForcedContent(Graphics paramGraphics) {
/* 160 */     this.root.renderForcedContent(paramGraphics);
/*     */   }
/*     */   
/*     */   private static double hypot(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 164 */     return Math.sqrt(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2 + paramDouble3 * paramDouble3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderContent(Graphics paramGraphics) {
/* 174 */     if (this.slWidth <= 0.0D || this.slHeight <= 0.0D)
/* 175 */       return;  BaseTransform baseTransform = paramGraphics.getTransformNoClone();
/* 176 */     double d1 = hypot(baseTransform.getMxx(), baseTransform.getMyx(), baseTransform.getMzx());
/* 177 */     double d2 = hypot(baseTransform.getMxy(), baseTransform.getMyy(), baseTransform.getMzy());
/* 178 */     double d3 = this.slWidth * d1;
/* 179 */     double d4 = this.slHeight * d2;
/* 180 */     int i = (int)Math.ceil(d3 - 0.00390625D);
/* 181 */     int j = (int)Math.ceil(d4 - 0.00390625D);
/* 182 */     if (Math.max(Math.abs(d3 - this.lastScaledW), Math.abs(d4 - this.lastScaledH)) > 0.00390625D) {
/* 183 */       if (this.rtt != null && (i != this.rtt
/* 184 */         .getContentWidth() || j != this.rtt
/* 185 */         .getContentHeight()))
/*     */       {
/* 187 */         invalidateRTT();
/*     */       }
/* 189 */       this.renderSG = true;
/* 190 */       this.lastScaledW = d3;
/* 191 */       this.lastScaledH = d4;
/*     */     } 
/* 193 */     if (this.rtt != null) {
/* 194 */       this.rtt.lock();
/* 195 */       if (this.rtt.isSurfaceLost()) {
/* 196 */         this.renderSG = true;
/* 197 */         this.rtt = null;
/*     */       } 
/*     */     } 
/*     */     
/* 201 */     if (this.renderSG || !this.root.isClean()) {
/* 202 */       if (this.rtt == null) {
/* 203 */         ResourceFactory resourceFactory = paramGraphics.getResourceFactory();
/* 204 */         this.rtt = resourceFactory.createRTTexture(i, j, Texture.WrapMode.CLAMP_TO_ZERO, this.msaa);
/*     */       } 
/*     */ 
/*     */       
/* 208 */       Graphics graphics = this.rtt.createGraphics();
/* 209 */       graphics.scale((float)d1, (float)d2);
/* 210 */       graphics.setLights(this.lights);
/*     */       
/* 212 */       graphics.setDepthBuffer(this.depthBuffer);
/* 213 */       if (this.camera != null) {
/* 214 */         graphics.setCamera(this.camera);
/*     */       }
/* 216 */       applyBackgroundFillPaint(graphics);
/*     */       
/* 218 */       this.root.render(graphics);
/* 219 */       this.root.clearDirtyTree();
/* 220 */       this.renderSG = false;
/*     */     } 
/* 222 */     if (this.msaa) {
/* 223 */       int k = this.rtt.getContentX();
/* 224 */       int m = this.rtt.getContentY();
/* 225 */       int n = k + i;
/* 226 */       int i1 = m + j;
/* 227 */       if ((this.isOpaque || paramGraphics.getCompositeMode() == CompositeMode.SRC) && 
/* 228 */         isDirectBlitTransform(baseTransform, d1, d2) && 
/* 229 */         !paramGraphics.isDepthTest()) {
/*     */ 
/*     */         
/* 232 */         int i2 = (int)(baseTransform.getMxt() + 0.5D);
/* 233 */         int i3 = (int)(baseTransform.getMyt() + 0.5D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 239 */         RenderTarget renderTarget = paramGraphics.getRenderTarget();
/* 240 */         int i4 = renderTarget.getContentX() + i2;
/* 241 */         int i5 = renderTarget.getContentY() + i3;
/* 242 */         int i6 = i4 + i;
/* 243 */         int i7 = i5 + j;
/* 244 */         int i8 = renderTarget.getContentWidth();
/* 245 */         int i9 = renderTarget.getContentHeight();
/* 246 */         byte b1 = (i6 > i8) ? (i8 - i6) : 0;
/* 247 */         byte b2 = (i7 > i9) ? (i9 - i7) : 0;
/* 248 */         paramGraphics.blit(this.rtt, null, k, m, n + b1, i1 + b2, i4, i5, i6 + b1, i7 + b2);
/*     */       } else {
/*     */         
/* 251 */         if (this.resolveRTT != null && (this.resolveRTT
/* 252 */           .getContentWidth() < i || this.resolveRTT
/* 253 */           .getContentHeight() < j)) {
/*     */ 
/*     */           
/* 256 */           this.resolveRTT.dispose();
/* 257 */           this.resolveRTT = null;
/*     */         } 
/* 259 */         if (this.resolveRTT != null) {
/* 260 */           this.resolveRTT.lock();
/* 261 */           if (this.resolveRTT.isSurfaceLost()) {
/* 262 */             this.resolveRTT = null;
/*     */           }
/*     */         } 
/* 265 */         if (this.resolveRTT == null) {
/* 266 */           this.resolveRTT = paramGraphics.getResourceFactory().createRTTexture(i, j, Texture.WrapMode.CLAMP_TO_ZERO, false);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 271 */         this.resolveRTT.createGraphics().blit(this.rtt, this.resolveRTT, k, m, n, i1, k, m, n, i1);
/*     */         
/* 273 */         paramGraphics.drawTexture(this.resolveRTT, 0.0F, 0.0F, (float)(i / d1), (float)(j / d2), 0.0F, 0.0F, i, j);
/*     */         
/* 275 */         this.resolveRTT.unlock();
/*     */       } 
/*     */     } else {
/* 278 */       paramGraphics.drawTexture(this.rtt, 0.0F, 0.0F, (float)(i / d1), (float)(j / d2), 0.0F, 0.0F, i, j);
/*     */     } 
/*     */     
/* 281 */     this.rtt.unlock();
/*     */   }
/*     */   
/*     */   private static boolean isDirectBlitTransform(BaseTransform paramBaseTransform, double paramDouble1, double paramDouble2) {
/* 285 */     if (paramDouble1 == 1.0D && paramDouble2 == 1.0D) return paramBaseTransform.isTranslateOrIdentity(); 
/* 286 */     if (!paramBaseTransform.is2D()) return false; 
/* 287 */     return (paramBaseTransform.getMxx() == paramDouble1 && paramBaseTransform
/* 288 */       .getMxy() == 0.0D && paramBaseTransform
/* 289 */       .getMyx() == 0.0D && paramBaseTransform
/* 290 */       .getMyy() == paramDouble2);
/*     */   }
/*     */   
/*     */   public NGCamera getCamera() {
/* 294 */     return this.camera;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGSubScene.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */