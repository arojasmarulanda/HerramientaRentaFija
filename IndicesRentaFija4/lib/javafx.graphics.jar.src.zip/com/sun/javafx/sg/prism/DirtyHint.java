package com.sun.javafx.sg.prism;

public final class DirtyHint {
  double translateXDelta;
  
  double translateYDelta;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\DirtyHint.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */