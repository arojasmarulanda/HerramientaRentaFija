/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.CubicCurve2D;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGCubicCurve
/*    */   extends NGShape
/*    */ {
/* 35 */   private CubicCurve2D curve = new CubicCurve2D();
/*    */   public final Shape getShape() {
/* 37 */     return this.curve;
/*    */   }
/*    */   
/*    */   public void updateCubicCurve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/* 41 */     this.curve.x1 = paramFloat1;
/* 42 */     this.curve.y1 = paramFloat2;
/* 43 */     this.curve.x2 = paramFloat3;
/* 44 */     this.curve.y2 = paramFloat4;
/* 45 */     this.curve.ctrlx1 = paramFloat5;
/* 46 */     this.curve.ctrly1 = paramFloat6;
/* 47 */     this.curve.ctrlx2 = paramFloat7;
/* 48 */     this.curve.ctrly2 = paramFloat8;
/* 49 */     geometryChanged();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGCubicCurve.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */