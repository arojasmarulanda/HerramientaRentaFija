/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.FlatteningPathIterator;
/*     */ import com.sun.javafx.geom.IllegalPathStateException;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.PathIterator;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ShapeEvaluator
/*     */ {
/*     */   private Shape savedv0;
/*     */   private Shape savedv1;
/*     */   private Geometry geom0;
/*     */   private Geometry geom1;
/*     */   
/*     */   public Shape evaluate(Shape paramShape1, Shape paramShape2, float paramFloat) {
/*  86 */     if (this.savedv0 != paramShape1 || this.savedv1 != paramShape2) {
/*  87 */       if (this.savedv0 == paramShape2 && this.savedv1 == paramShape1) {
/*     */         
/*  89 */         Geometry geometry = this.geom0;
/*  90 */         this.geom0 = this.geom1;
/*  91 */         this.geom1 = geometry;
/*     */       } else {
/*  93 */         recalculate(paramShape1, paramShape2);
/*     */       } 
/*  95 */       this.savedv0 = paramShape1;
/*  96 */       this.savedv1 = paramShape2;
/*     */     } 
/*  98 */     return getShape(paramFloat);
/*     */   }
/*     */   
/*     */   private void recalculate(Shape paramShape1, Shape paramShape2) {
/* 102 */     this.geom0 = new Geometry(paramShape1);
/* 103 */     this.geom1 = new Geometry(paramShape2);
/* 104 */     float[] arrayOfFloat1 = this.geom0.getTvals();
/* 105 */     float[] arrayOfFloat2 = this.geom1.getTvals();
/* 106 */     float[] arrayOfFloat3 = mergeTvals(arrayOfFloat1, arrayOfFloat2);
/* 107 */     this.geom0.setTvals(arrayOfFloat3);
/* 108 */     this.geom1.setTvals(arrayOfFloat3);
/*     */   }
/*     */   
/*     */   private Shape getShape(float paramFloat) {
/* 112 */     return new MorphedShape(this.geom0, this.geom1, paramFloat);
/*     */   }
/*     */   
/*     */   private static float[] mergeTvals(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/* 116 */     int i = sortTvals(paramArrayOffloat1, paramArrayOffloat2, null);
/* 117 */     float[] arrayOfFloat = new float[i];
/* 118 */     sortTvals(paramArrayOffloat1, paramArrayOffloat2, arrayOfFloat);
/* 119 */     return arrayOfFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int sortTvals(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float[] paramArrayOffloat3) {
/* 126 */     byte b1 = 0;
/* 127 */     byte b2 = 0;
/* 128 */     byte b3 = 0;
/* 129 */     while (b1 < paramArrayOffloat1.length && b2 < paramArrayOffloat2.length) {
/* 130 */       float f1 = paramArrayOffloat1[b1];
/* 131 */       float f2 = paramArrayOffloat2[b2];
/* 132 */       if (f1 <= f2) {
/* 133 */         if (paramArrayOffloat3 != null) paramArrayOffloat3[b3] = f1; 
/* 134 */         b1++;
/*     */       } 
/* 136 */       if (f2 <= f1) {
/* 137 */         if (paramArrayOffloat3 != null) paramArrayOffloat3[b3] = f2; 
/* 138 */         b2++;
/*     */       } 
/* 140 */       b3++;
/*     */     } 
/* 142 */     return b3;
/*     */   }
/*     */   
/*     */   private static float interp(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 146 */     return paramFloat1 + (paramFloat2 - paramFloat1) * paramFloat3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Geometry
/*     */   {
/*     */     static final float THIRD = 0.33333334F;
/*     */     
/*     */     static final float MIN_LEN = 0.001F;
/*     */     
/*     */     int numCoords;
/*     */     
/* 159 */     float[] bezierCoords = new float[20]; public Geometry(Shape param1Shape) {
/* 160 */       PathIterator pathIterator = param1Shape.getPathIterator(null);
/* 161 */       this.windingrule = pathIterator.getWindingRule();
/* 162 */       if (pathIterator.isDone())
/*     */       {
/*     */         
/* 165 */         this.numCoords = 8;
/*     */       }
/* 167 */       float[] arrayOfFloat = new float[6];
/* 168 */       int i = pathIterator.currentSegment(arrayOfFloat);
/* 169 */       pathIterator.next();
/* 170 */       if (i != 0) {
/* 171 */         throw new IllegalPathStateException("missing initial moveto");
/*     */       }
/*     */       
/* 174 */       float f3 = arrayOfFloat[0], f1 = f3;
/* 175 */       float f4 = arrayOfFloat[1], f2 = f4;
/*     */       
/* 177 */       Vector<Point2D> vector = new Vector();
/* 178 */       this.numCoords = 2;
/* 179 */       while (!pathIterator.isDone()) {
/* 180 */         float f8, f9, f10, f11; switch (pathIterator.currentSegment(arrayOfFloat)) {
/*     */           case 0:
/* 182 */             if (f1 != f3 || f2 != f4) {
/* 183 */               appendLineTo(f1, f2, f3, f4);
/* 184 */               f1 = f3;
/* 185 */               f2 = f4;
/*     */             } 
/* 187 */             f8 = arrayOfFloat[0];
/* 188 */             f9 = arrayOfFloat[1];
/* 189 */             if (f1 != f8 || f2 != f9) {
/* 190 */               vector.add(new Point2D(f3, f4));
/* 191 */               appendLineTo(f1, f2, f8, f9);
/* 192 */               f1 = f3 = f8;
/* 193 */               f2 = f4 = f9;
/*     */             } 
/*     */             break;
/*     */           case 4:
/* 197 */             if (f1 != f3 || f2 != f4) {
/* 198 */               appendLineTo(f1, f2, f3, f4);
/* 199 */               f1 = f3;
/* 200 */               f2 = f4;
/*     */             } 
/*     */             break;
/*     */           case 1:
/* 204 */             f8 = arrayOfFloat[0];
/* 205 */             f9 = arrayOfFloat[1];
/* 206 */             appendLineTo(f1, f2, f8, f9);
/* 207 */             f1 = f8;
/* 208 */             f2 = f9;
/*     */             break;
/*     */           case 2:
/* 211 */             f10 = arrayOfFloat[0];
/* 212 */             f11 = arrayOfFloat[1];
/* 213 */             f8 = arrayOfFloat[2];
/* 214 */             f9 = arrayOfFloat[3];
/* 215 */             appendQuadTo(f1, f2, f10, f11, f8, f9);
/* 216 */             f1 = f8;
/* 217 */             f2 = f9;
/*     */             break;
/*     */           case 3:
/* 220 */             appendCubicTo(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3], f1 = arrayOfFloat[4], f2 = arrayOfFloat[5]);
/*     */             break;
/*     */         } 
/*     */ 
/*     */         
/* 225 */         pathIterator.next();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 230 */       if (this.numCoords < 8 || f1 != f3 || f2 != f4) {
/* 231 */         appendLineTo(f1, f2, f3, f4);
/* 232 */         f1 = f3;
/* 233 */         f2 = f4;
/*     */       } 
/*     */       
/*     */       int j;
/* 237 */       for (j = vector.size() - 1; j >= 0; j--) {
/* 238 */         Point2D point2D = vector.get(j);
/* 239 */         float f8 = point2D.x;
/* 240 */         float f9 = point2D.y;
/* 241 */         if (f1 != f8 || f2 != f9) {
/* 242 */           appendLineTo(f1, f2, f8, f9);
/* 243 */           f1 = f8;
/* 244 */           f2 = f9;
/*     */         } 
/*     */       } 
/*     */       
/* 248 */       j = 0;
/* 249 */       float f5 = this.bezierCoords[0];
/* 250 */       float f6 = this.bezierCoords[1];
/* 251 */       for (byte b1 = 6; b1 < this.numCoords; b1 += 6) {
/* 252 */         float f8 = this.bezierCoords[b1];
/* 253 */         float f9 = this.bezierCoords[b1 + 1];
/* 254 */         if (f9 < f6 || (f9 == f6 && f8 < f5)) {
/* 255 */           j = b1;
/* 256 */           f5 = f8;
/* 257 */           f6 = f9;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 262 */       if (j > 0) {
/*     */         
/* 264 */         float[] arrayOfFloat1 = new float[this.numCoords];
/*     */ 
/*     */         
/* 267 */         System.arraycopy(this.bezierCoords, j, arrayOfFloat1, 0, this.numCoords - j);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 277 */         System.arraycopy(this.bezierCoords, 2, arrayOfFloat1, this.numCoords - j, j);
/*     */ 
/*     */         
/* 280 */         this.bezierCoords = arrayOfFloat1;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 310 */       float f7 = 0.0F;
/*     */ 
/*     */       
/* 313 */       f1 = this.bezierCoords[0];
/* 314 */       f2 = this.bezierCoords[1]; byte b2;
/* 315 */       for (b2 = 2; b2 < this.numCoords; b2 += 2) {
/* 316 */         float f8 = this.bezierCoords[b2];
/* 317 */         float f9 = this.bezierCoords[b2 + 1];
/* 318 */         f7 += f1 * f9 - f8 * f2;
/* 319 */         f1 = f8;
/* 320 */         f2 = f9;
/*     */       } 
/* 322 */       if (f7 < 0.0F) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 337 */         b2 = 2;
/* 338 */         int k = this.numCoords - 4;
/* 339 */         while (b2 < k) {
/* 340 */           f1 = this.bezierCoords[b2];
/* 341 */           f2 = this.bezierCoords[b2 + 1];
/* 342 */           this.bezierCoords[b2] = this.bezierCoords[k];
/* 343 */           this.bezierCoords[b2 + 1] = this.bezierCoords[k + 1];
/* 344 */           this.bezierCoords[k] = f1;
/* 345 */           this.bezierCoords[k + 1] = f2;
/* 346 */           b2 += 2;
/* 347 */           k -= 2;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     int windingrule;
/*     */     float[] myTvals;
/*     */     
/*     */     private void appendLineTo(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
/* 355 */       appendCubicTo(ShapeEvaluator
/* 356 */           .interp(param1Float1, param1Float3, 0.33333334F), ShapeEvaluator
/* 357 */           .interp(param1Float2, param1Float4, 0.33333334F), ShapeEvaluator
/*     */           
/* 359 */           .interp(param1Float3, param1Float1, 0.33333334F), ShapeEvaluator
/* 360 */           .interp(param1Float4, param1Float2, 0.33333334F), param1Float3, param1Float4);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void appendQuadTo(float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
/* 368 */       appendCubicTo(ShapeEvaluator
/* 369 */           .interp(param1Float3, param1Float1, 0.33333334F), ShapeEvaluator
/* 370 */           .interp(param1Float4, param1Float2, 0.33333334F), ShapeEvaluator
/*     */           
/* 372 */           .interp(param1Float3, param1Float5, 0.33333334F), ShapeEvaluator
/* 373 */           .interp(param1Float4, param1Float6, 0.33333334F), param1Float5, param1Float6);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void appendCubicTo(float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6) {
/* 381 */       if (this.numCoords + 6 > this.bezierCoords.length) {
/*     */         
/* 383 */         int i = (this.numCoords - 2) * 2 + 2;
/* 384 */         float[] arrayOfFloat = new float[i];
/* 385 */         System.arraycopy(this.bezierCoords, 0, arrayOfFloat, 0, this.numCoords);
/* 386 */         this.bezierCoords = arrayOfFloat;
/*     */       } 
/* 388 */       this.bezierCoords[this.numCoords++] = param1Float1;
/* 389 */       this.bezierCoords[this.numCoords++] = param1Float2;
/* 390 */       this.bezierCoords[this.numCoords++] = param1Float3;
/* 391 */       this.bezierCoords[this.numCoords++] = param1Float4;
/* 392 */       this.bezierCoords[this.numCoords++] = param1Float5;
/* 393 */       this.bezierCoords[this.numCoords++] = param1Float6;
/*     */     }
/*     */     
/*     */     public int getWindingRule() {
/* 397 */       return this.windingrule;
/*     */     }
/*     */     
/*     */     public int getNumCoords() {
/* 401 */       return this.numCoords;
/*     */     }
/*     */     
/*     */     public float getCoord(int param1Int) {
/* 405 */       return this.bezierCoords[param1Int];
/*     */     }
/*     */     
/*     */     public float[] getTvals() {
/* 409 */       if (this.myTvals != null) {
/* 410 */         return this.myTvals;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 415 */       float[] arrayOfFloat = new float[(this.numCoords - 2) / 6 + 1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 421 */       float f1 = this.bezierCoords[0];
/* 422 */       float f2 = this.bezierCoords[1];
/* 423 */       float f3 = 0.0F;
/* 424 */       byte b1 = 2;
/* 425 */       byte b2 = 0;
/* 426 */       while (b1 < this.numCoords) {
/*     */         
/* 428 */         float f5 = f1;
/* 429 */         float f6 = f2;
/* 430 */         float f7 = this.bezierCoords[b1++];
/* 431 */         float f8 = this.bezierCoords[b1++];
/* 432 */         f5 -= f7;
/* 433 */         f6 -= f8;
/* 434 */         float f9 = (float)Math.sqrt((f5 * f5 + f6 * f6));
/* 435 */         f5 = f7;
/* 436 */         f6 = f8;
/* 437 */         f7 = this.bezierCoords[b1++];
/* 438 */         f8 = this.bezierCoords[b1++];
/* 439 */         f5 -= f7;
/* 440 */         f6 -= f8;
/* 441 */         f9 += (float)Math.sqrt((f5 * f5 + f6 * f6));
/* 442 */         f5 = f7;
/* 443 */         f6 = f8;
/* 444 */         f7 = this.bezierCoords[b1++];
/* 445 */         f8 = this.bezierCoords[b1++];
/* 446 */         f5 -= f7;
/* 447 */         f6 -= f8;
/* 448 */         f9 += (float)Math.sqrt((f5 * f5 + f6 * f6));
/*     */         
/* 450 */         f1 -= f7;
/* 451 */         f2 -= f8;
/* 452 */         f9 += (float)Math.sqrt((f1 * f1 + f2 * f2));
/*     */         
/* 454 */         f9 /= 2.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 467 */         if (f9 < 0.001F) {
/* 468 */           f9 = 0.001F;
/*     */         }
/* 470 */         f3 += f9;
/* 471 */         arrayOfFloat[b2++] = f3;
/* 472 */         f1 = f7;
/* 473 */         f2 = f8;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 478 */       float f4 = arrayOfFloat[0];
/* 479 */       arrayOfFloat[0] = 0.0F;
/* 480 */       for (b2 = 1; b2 < arrayOfFloat.length - 1; b2++) {
/* 481 */         float f = arrayOfFloat[b2];
/* 482 */         arrayOfFloat[b2] = f4 / f3;
/* 483 */         f4 = f;
/*     */       } 
/* 485 */       arrayOfFloat[b2] = 1.0F;
/* 486 */       return this.myTvals = arrayOfFloat;
/*     */     }
/*     */     
/*     */     public void setTvals(float[] param1ArrayOffloat) {
/* 490 */       float[] arrayOfFloat1 = this.bezierCoords;
/* 491 */       float[] arrayOfFloat2 = new float[2 + (param1ArrayOffloat.length - 1) * 6];
/* 492 */       float[] arrayOfFloat3 = getTvals();
/* 493 */       byte b1 = 0;
/*     */ 
/*     */       
/* 496 */       float f4 = arrayOfFloat1[b1++], f3 = f4, f2 = f3, f1 = f2;
/* 497 */       float f8 = arrayOfFloat1[b1++], f7 = f8, f6 = f7, f5 = f6;
/* 498 */       byte b2 = 0;
/* 499 */       arrayOfFloat2[b2++] = f1;
/* 500 */       arrayOfFloat2[b2++] = f5;
/* 501 */       float f9 = 0.0F;
/* 502 */       float f10 = 0.0F;
/* 503 */       byte b3 = 1;
/* 504 */       byte b4 = 1;
/* 505 */       while (b4 < param1ArrayOffloat.length) {
/* 506 */         if (f9 >= f10) {
/* 507 */           f1 = f4;
/* 508 */           f5 = f8;
/* 509 */           f2 = arrayOfFloat1[b1++];
/* 510 */           f6 = arrayOfFloat1[b1++];
/* 511 */           f3 = arrayOfFloat1[b1++];
/* 512 */           f7 = arrayOfFloat1[b1++];
/* 513 */           f4 = arrayOfFloat1[b1++];
/* 514 */           f8 = arrayOfFloat1[b1++];
/* 515 */           f10 = arrayOfFloat3[b3++];
/*     */         } 
/* 517 */         float f = param1ArrayOffloat[b4++];
/*     */         
/* 519 */         if (f < f10) {
/*     */           
/* 521 */           float f11 = (f - f9) / (f10 - f9);
/* 522 */           arrayOfFloat2[b2++] = f1 = ShapeEvaluator.interp(f1, f2, f11);
/* 523 */           arrayOfFloat2[b2++] = f5 = ShapeEvaluator.interp(f5, f6, f11);
/* 524 */           f2 = ShapeEvaluator.interp(f2, f3, f11);
/* 525 */           f6 = ShapeEvaluator.interp(f6, f7, f11);
/* 526 */           f3 = ShapeEvaluator.interp(f3, f4, f11);
/* 527 */           f7 = ShapeEvaluator.interp(f7, f8, f11);
/* 528 */           arrayOfFloat2[b2++] = f1 = ShapeEvaluator.interp(f1, f2, f11);
/* 529 */           arrayOfFloat2[b2++] = f5 = ShapeEvaluator.interp(f5, f6, f11);
/* 530 */           f2 = ShapeEvaluator.interp(f2, f3, f11);
/* 531 */           f6 = ShapeEvaluator.interp(f6, f7, f11);
/* 532 */           arrayOfFloat2[b2++] = f1 = ShapeEvaluator.interp(f1, f2, f11);
/* 533 */           arrayOfFloat2[b2++] = f5 = ShapeEvaluator.interp(f5, f6, f11);
/*     */         } else {
/* 535 */           arrayOfFloat2[b2++] = f2;
/* 536 */           arrayOfFloat2[b2++] = f6;
/* 537 */           arrayOfFloat2[b2++] = f3;
/* 538 */           arrayOfFloat2[b2++] = f7;
/* 539 */           arrayOfFloat2[b2++] = f4;
/* 540 */           arrayOfFloat2[b2++] = f8;
/*     */         } 
/* 542 */         f9 = f;
/*     */       } 
/* 544 */       this.bezierCoords = arrayOfFloat2;
/* 545 */       this.numCoords = arrayOfFloat2.length;
/* 546 */       this.myTvals = param1ArrayOffloat;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class MorphedShape extends Shape {
/*     */     ShapeEvaluator.Geometry geom0;
/*     */     ShapeEvaluator.Geometry geom1;
/*     */     float t;
/*     */     
/*     */     MorphedShape(ShapeEvaluator.Geometry param1Geometry1, ShapeEvaluator.Geometry param1Geometry2, float param1Float) {
/* 556 */       this.geom0 = param1Geometry1;
/* 557 */       this.geom1 = param1Geometry2;
/* 558 */       this.t = param1Float;
/*     */     }
/*     */     
/*     */     public Rectangle getRectangle() {
/* 562 */       return new Rectangle(getBounds());
/*     */     }
/*     */     
/*     */     public RectBounds getBounds() {
/* 566 */       int i = this.geom0.getNumCoords();
/*     */       
/* 568 */       float f3 = ShapeEvaluator.interp(this.geom0.getCoord(0), this.geom1.getCoord(0), this.t), f1 = f3;
/* 569 */       float f4 = ShapeEvaluator.interp(this.geom0.getCoord(1), this.geom1.getCoord(1), this.t), f2 = f4;
/* 570 */       for (byte b = 2; b < i; b += 2) {
/* 571 */         float f5 = ShapeEvaluator.interp(this.geom0.getCoord(b), this.geom1.getCoord(b), this.t);
/* 572 */         float f6 = ShapeEvaluator.interp(this.geom0.getCoord(b + 1), this.geom1.getCoord(b + 1), this.t);
/* 573 */         if (f1 > f5) {
/* 574 */           f1 = f5;
/*     */         }
/* 576 */         if (f2 > f6) {
/* 577 */           f2 = f6;
/*     */         }
/* 579 */         if (f3 < f5) {
/* 580 */           f3 = f5;
/*     */         }
/* 582 */         if (f4 < f6) {
/* 583 */           f4 = f6;
/*     */         }
/*     */       } 
/* 586 */       return new RectBounds(f1, f2, f3, f4);
/*     */     }
/*     */     
/*     */     public boolean contains(float param1Float1, float param1Float2) {
/* 590 */       return Path2D.contains(getPathIterator(null), param1Float1, param1Float2);
/*     */     }
/*     */     
/*     */     public boolean intersects(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
/* 594 */       return Path2D.intersects(getPathIterator(null), param1Float1, param1Float2, param1Float3, param1Float4);
/*     */     }
/*     */     
/*     */     public boolean contains(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
/* 598 */       return Path2D.contains(getPathIterator(null), param1Float1, param1Float2, param1Float3, param1Float4);
/*     */     }
/*     */     
/*     */     public PathIterator getPathIterator(BaseTransform param1BaseTransform) {
/* 602 */       return new ShapeEvaluator.Iterator(param1BaseTransform, this.geom0, this.geom1, this.t);
/*     */     }
/*     */     
/*     */     public PathIterator getPathIterator(BaseTransform param1BaseTransform, float param1Float) {
/* 606 */       return new FlatteningPathIterator(getPathIterator(param1BaseTransform), param1Float);
/*     */     }
/*     */     
/*     */     public Shape copy() {
/* 610 */       return new Path2D(this);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Iterator
/*     */     implements PathIterator
/*     */   {
/*     */     BaseTransform at;
/*     */     ShapeEvaluator.Geometry g0;
/*     */     ShapeEvaluator.Geometry g1;
/*     */     float t;
/*     */     int cindex;
/*     */     
/*     */     public Iterator(BaseTransform param1BaseTransform, ShapeEvaluator.Geometry param1Geometry1, ShapeEvaluator.Geometry param1Geometry2, float param1Float) {
/* 624 */       this.at = param1BaseTransform;
/* 625 */       this.g0 = param1Geometry1;
/* 626 */       this.g1 = param1Geometry2;
/* 627 */       this.t = param1Float;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getWindingRule() {
/* 634 */       return (this.t < 0.5D) ? this.g0.getWindingRule() : this.g1.getWindingRule();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDone() {
/* 641 */       return (this.cindex > this.g0.getNumCoords());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void next() {
/* 648 */       if (this.cindex == 0) {
/* 649 */         this.cindex = 2;
/*     */       } else {
/* 651 */         this.cindex += 6;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int currentSegment(float[] param1ArrayOffloat) {
/*     */       byte b1;
/*     */       byte b2;
/* 661 */       if (this.cindex == 0) {
/* 662 */         b1 = 0;
/* 663 */         b2 = 2;
/* 664 */       } else if (this.cindex >= this.g0.getNumCoords()) {
/* 665 */         b1 = 4;
/* 666 */         b2 = 0;
/*     */       } else {
/* 668 */         b1 = 3;
/* 669 */         b2 = 6;
/*     */       } 
/* 671 */       if (b2 > 0) {
/* 672 */         for (byte b = 0; b < b2; b++) {
/* 673 */           param1ArrayOffloat[b] = ShapeEvaluator.interp(this.g0.getCoord(this.cindex + b), this.g1
/* 674 */               .getCoord(this.cindex + b), this.t);
/*     */         }
/*     */         
/* 677 */         if (this.at != null) {
/* 678 */           this.at.transform(param1ArrayOffloat, 0, param1ArrayOffloat, 0, b2 / 2);
/*     */         }
/*     */       } 
/* 681 */       return b1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\ShapeEvaluator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */