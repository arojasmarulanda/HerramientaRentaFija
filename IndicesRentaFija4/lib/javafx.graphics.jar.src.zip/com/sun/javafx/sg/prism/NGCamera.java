/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.PickRay;
/*     */ import com.sun.javafx.geom.Vec3d;
/*     */ import com.sun.javafx.geom.transform.Affine3D;
/*     */ import com.sun.javafx.geom.transform.GeneralTransform3D;
/*     */ import com.sun.prism.Graphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NGCamera
/*     */   extends NGNode
/*     */ {
/*  38 */   public static final NGCamera INSTANCE = new NGDefaultCamera();
/*     */   
/*  40 */   protected Affine3D worldTransform = new Affine3D();
/*     */ 
/*     */ 
/*     */   
/*  44 */   protected double viewWidth = 1.0D;
/*  45 */   protected double viewHeight = 1.0D;
/*     */   
/*  47 */   protected double zNear = 0.1D;
/*  48 */   protected double zFar = 100.0D;
/*     */ 
/*     */   
/*  51 */   private Vec3d worldPosition = new Vec3d();
/*     */   
/*  53 */   protected GeneralTransform3D projViewTx = new GeneralTransform3D();
/*     */ 
/*     */   
/*     */   protected void doRender(Graphics paramGraphics) {}
/*     */ 
/*     */   
/*     */   protected void renderContent(Graphics paramGraphics) {}
/*     */   
/*     */   protected boolean hasOverlappingContents() {
/*  62 */     return false;
/*     */   }
/*     */   
/*     */   public void setNearClip(float paramFloat) {
/*  66 */     this.zNear = paramFloat;
/*     */   }
/*     */   
/*     */   public double getNearClip() {
/*  70 */     return this.zNear;
/*     */   }
/*     */   
/*     */   public void setFarClip(float paramFloat) {
/*  74 */     this.zFar = paramFloat;
/*     */   }
/*     */   
/*     */   public double getFarClip() {
/*  78 */     return this.zFar;
/*     */   }
/*     */   
/*     */   public void setViewWidth(double paramDouble) {
/*  82 */     this.viewWidth = paramDouble;
/*     */   }
/*     */   
/*     */   public double getViewWidth() {
/*  86 */     return this.viewWidth;
/*     */   }
/*     */   
/*     */   public void setViewHeight(double paramDouble) {
/*  90 */     this.viewHeight = paramDouble;
/*     */   }
/*     */   
/*     */   public double getViewHeight() {
/*  94 */     return this.viewHeight;
/*     */   }
/*     */   
/*     */   public void setProjViewTransform(GeneralTransform3D paramGeneralTransform3D) {
/*  98 */     this.projViewTx.set(paramGeneralTransform3D);
/*     */   }
/*     */   
/*     */   public void setPosition(Vec3d paramVec3d) {
/* 102 */     this.worldPosition.set(paramVec3d);
/*     */   }
/*     */   
/*     */   public void setWorldTransform(Affine3D paramAffine3D) {
/* 106 */     this.worldTransform.setTransform(paramAffine3D);
/*     */   }
/*     */   
/*     */   public GeneralTransform3D getProjViewTx(GeneralTransform3D paramGeneralTransform3D) {
/* 110 */     if (paramGeneralTransform3D == null) {
/* 111 */       paramGeneralTransform3D = new GeneralTransform3D();
/*     */     }
/* 113 */     return paramGeneralTransform3D.set(this.projViewTx);
/*     */   }
/*     */   
/*     */   public Vec3d getPositionInWorld(Vec3d paramVec3d) {
/* 117 */     if (paramVec3d == null) {
/* 118 */       paramVec3d = new Vec3d();
/*     */     }
/* 120 */     paramVec3d.set(this.worldPosition);
/* 121 */     return paramVec3d;
/*     */   }
/*     */   
/*     */   public void release() {}
/*     */   
/*     */   public abstract PickRay computePickRay(float paramFloat1, float paramFloat2, PickRay paramPickRay);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGCamera.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */