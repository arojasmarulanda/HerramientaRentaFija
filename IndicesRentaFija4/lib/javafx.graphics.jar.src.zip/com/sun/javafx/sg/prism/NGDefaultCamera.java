/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGDefaultCamera
/*    */   extends NGParallelCamera
/*    */ {
/*    */   public void validate(int paramInt1, int paramInt2) {
/* 32 */     if (paramInt1 != this.viewWidth || paramInt2 != this.viewHeight) {
/* 33 */       setViewWidth(paramInt1);
/* 34 */       setViewHeight(paramInt2);
/*    */       
/* 36 */       double d = (paramInt1 > paramInt2) ? (paramInt1 / 2.0D) : (paramInt2 / 2.0D);
/* 37 */       this.projViewTx.ortho(0.0D, paramInt1, paramInt2, 0.0D, -d, d);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGDefaultCamera.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */