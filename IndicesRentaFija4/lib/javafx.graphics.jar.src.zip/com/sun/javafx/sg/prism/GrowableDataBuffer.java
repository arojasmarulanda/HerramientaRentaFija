/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.nio.BufferOverflowException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GrowableDataBuffer
/*     */ {
/*     */   static final int VAL_GROW_QUANTUM = 1024;
/*     */   static final int MAX_VAL_GROW = 1048576;
/*     */   static final int MIN_OBJ_GROW = 32;
/*     */   
/*     */   static class WeakLink
/*     */   {
/*     */     WeakReference<GrowableDataBuffer> bufref;
/*     */     WeakLink next;
/*     */   }
/*  60 */   static WeakLink buflist = new WeakLink();
/*     */   byte[] vals;
/*     */   int writevalpos;
/*     */   int readvalpos;
/*     */   int savevalpos;
/*     */   Object[] objs;
/*     */   int writeobjpos;
/*     */   int readobjpos;
/*     */   int saveobjpos;
/*     */   
/*     */   public static GrowableDataBuffer getBuffer(int paramInt) {
/*  71 */     return getBuffer(paramInt, 32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized GrowableDataBuffer getBuffer(int paramInt1, int paramInt2) {
/*  84 */     WeakLink weakLink1 = buflist;
/*  85 */     WeakLink weakLink2 = buflist.next;
/*  86 */     while (weakLink2 != null) {
/*  87 */       GrowableDataBuffer growableDataBuffer = weakLink2.bufref.get();
/*  88 */       WeakLink weakLink = weakLink2.next;
/*  89 */       if (growableDataBuffer == null) {
/*  90 */         weakLink1.next = weakLink2 = weakLink;
/*     */         continue;
/*     */       } 
/*  93 */       if (growableDataBuffer.valueCapacity() >= paramInt1 && growableDataBuffer.objectCapacity() >= paramInt2) {
/*  94 */         weakLink1.next = weakLink;
/*  95 */         return growableDataBuffer;
/*     */       } 
/*  97 */       weakLink1 = weakLink2;
/*  98 */       weakLink2 = weakLink;
/*     */     } 
/* 100 */     return new GrowableDataBuffer(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void returnBuffer(GrowableDataBuffer paramGrowableDataBuffer) {
/* 112 */     int i = paramGrowableDataBuffer.valueCapacity();
/* 113 */     int j = paramGrowableDataBuffer.objectCapacity();
/* 114 */     paramGrowableDataBuffer.reset();
/*     */     
/* 116 */     WeakLink weakLink1 = buflist;
/* 117 */     WeakLink weakLink2 = buflist.next;
/* 118 */     while (weakLink2 != null) {
/* 119 */       GrowableDataBuffer growableDataBuffer = weakLink2.bufref.get();
/* 120 */       WeakLink weakLink = weakLink2.next;
/* 121 */       if (growableDataBuffer == null) {
/* 122 */         weakLink1.next = weakLink2 = weakLink;
/*     */         continue;
/*     */       } 
/* 125 */       int k = growableDataBuffer.valueCapacity();
/* 126 */       int m = growableDataBuffer.objectCapacity();
/* 127 */       if (k > i || (k == i && m >= j)) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/* 132 */       weakLink1 = weakLink2;
/* 133 */       weakLink2 = weakLink;
/*     */     } 
/* 135 */     WeakLink weakLink3 = new WeakLink();
/* 136 */     weakLink3.bufref = new WeakReference<>(paramGrowableDataBuffer);
/* 137 */     weakLink1.next = weakLink3;
/* 138 */     weakLink3.next = weakLink2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GrowableDataBuffer(int paramInt1, int paramInt2) {
/* 152 */     this.vals = new byte[paramInt1];
/* 153 */     this.objs = new Object[paramInt2];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readValuePosition() {
/* 165 */     return this.readvalpos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int writeValuePosition() {
/* 175 */     return this.writevalpos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readObjectPosition() {
/* 186 */     return this.readobjpos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int writeObjectPosition() {
/* 195 */     return this.writeobjpos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int valueCapacity() {
/* 204 */     return this.vals.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int objectCapacity() {
/* 213 */     return this.objs.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() {
/* 222 */     this.savevalpos = this.readvalpos;
/* 223 */     this.saveobjpos = this.readobjpos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restore() {
/* 231 */     this.readvalpos = this.savevalpos;
/* 232 */     this.readobjpos = this.saveobjpos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasValues() {
/* 242 */     return (this.readvalpos < this.writevalpos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasObjects() {
/* 252 */     return (this.readobjpos < this.writeobjpos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 264 */     return (this.writevalpos == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 275 */     this.readvalpos = this.savevalpos = this.writevalpos = 0;
/* 276 */     this.readobjpos = this.saveobjpos = 0;
/* 277 */     if (this.writeobjpos > 0) {
/* 278 */       Arrays.fill(this.objs, 0, this.writeobjpos, (Object)null);
/* 279 */       this.writeobjpos = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void append(GrowableDataBuffer paramGrowableDataBuffer) {
/* 292 */     ensureWriteCapacity(paramGrowableDataBuffer.writevalpos);
/* 293 */     System.arraycopy(paramGrowableDataBuffer.vals, 0, this.vals, this.writevalpos, paramGrowableDataBuffer.writevalpos);
/* 294 */     this.writevalpos += paramGrowableDataBuffer.writevalpos;
/* 295 */     if (this.writeobjpos + paramGrowableDataBuffer.writeobjpos > this.objs.length) {
/* 296 */       this.objs = Arrays.copyOf(this.objs, this.writeobjpos + paramGrowableDataBuffer.writeobjpos);
/*     */     }
/* 298 */     System.arraycopy(paramGrowableDataBuffer.objs, 0, this.objs, this.writeobjpos, paramGrowableDataBuffer.writeobjpos);
/* 299 */     this.writeobjpos += paramGrowableDataBuffer.writeobjpos;
/*     */   }
/*     */   
/*     */   private void ensureWriteCapacity(int paramInt) {
/* 303 */     if (paramInt > this.vals.length - this.writevalpos) {
/* 304 */       paramInt = this.writevalpos + paramInt - this.vals.length;
/*     */       
/* 306 */       int i = Math.min(this.vals.length, 1048576);
/*     */       
/* 308 */       if (i < paramInt) i = paramInt; 
/* 309 */       int j = this.vals.length + i;
/* 310 */       j = j + 1023 & 0xFFFFFC00;
/* 311 */       this.vals = Arrays.copyOf(this.vals, j);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void ensureReadCapacity(int paramInt) {
/* 316 */     if (this.readvalpos + paramInt > this.writevalpos) {
/* 317 */       throw new BufferOverflowException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putBoolean(boolean paramBoolean) {
/* 327 */     putByte(paramBoolean ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putByte(byte paramByte) {
/* 336 */     ensureWriteCapacity(1);
/* 337 */     this.vals[this.writevalpos++] = paramByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putChar(char paramChar) {
/* 346 */     ensureWriteCapacity(2);
/* 347 */     this.vals[this.writevalpos++] = (byte)(paramChar >> 8);
/* 348 */     this.vals[this.writevalpos++] = (byte)paramChar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putShort(short paramShort) {
/* 357 */     ensureWriteCapacity(2);
/* 358 */     this.vals[this.writevalpos++] = (byte)(paramShort >> 8);
/* 359 */     this.vals[this.writevalpos++] = (byte)paramShort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putInt(int paramInt) {
/* 368 */     ensureWriteCapacity(4);
/* 369 */     this.vals[this.writevalpos++] = (byte)(paramInt >> 24);
/* 370 */     this.vals[this.writevalpos++] = (byte)(paramInt >> 16);
/* 371 */     this.vals[this.writevalpos++] = (byte)(paramInt >> 8);
/* 372 */     this.vals[this.writevalpos++] = (byte)paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putLong(long paramLong) {
/* 381 */     ensureWriteCapacity(8);
/* 382 */     this.vals[this.writevalpos++] = (byte)(int)(paramLong >> 56L);
/* 383 */     this.vals[this.writevalpos++] = (byte)(int)(paramLong >> 48L);
/* 384 */     this.vals[this.writevalpos++] = (byte)(int)(paramLong >> 40L);
/* 385 */     this.vals[this.writevalpos++] = (byte)(int)(paramLong >> 32L);
/* 386 */     this.vals[this.writevalpos++] = (byte)(int)(paramLong >> 24L);
/* 387 */     this.vals[this.writevalpos++] = (byte)(int)(paramLong >> 16L);
/* 388 */     this.vals[this.writevalpos++] = (byte)(int)(paramLong >> 8L);
/* 389 */     this.vals[this.writevalpos++] = (byte)(int)paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putFloat(float paramFloat) {
/* 398 */     putInt(Float.floatToIntBits(paramFloat));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putDouble(double paramDouble) {
/* 407 */     putLong(Double.doubleToLongBits(paramDouble));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putObject(Object paramObject) {
/* 416 */     if (this.writeobjpos >= this.objs.length) {
/* 417 */       this.objs = Arrays.copyOf(this.objs, this.writeobjpos + 32);
/*     */     }
/* 419 */     this.objs[this.writeobjpos++] = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte peekByte(int paramInt) {
/* 432 */     if (paramInt >= this.writevalpos) {
/* 433 */       throw new BufferOverflowException();
/*     */     }
/* 435 */     return this.vals[paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object peekObject(int paramInt) {
/* 448 */     if (paramInt >= this.writeobjpos) {
/* 449 */       throw new BufferOverflowException();
/*     */     }
/* 451 */     return this.objs[paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBoolean() {
/* 462 */     ensureReadCapacity(1); return 
/* 463 */       (this.vals[this.readvalpos++] != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getByte() {
/* 474 */     ensureReadCapacity(1);
/* 475 */     return this.vals[this.readvalpos++];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUByte() {
/* 487 */     ensureReadCapacity(1);
/* 488 */     return this.vals[this.readvalpos++] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getChar() {
/* 499 */     ensureReadCapacity(2);
/* 500 */     byte b = this.vals[this.readvalpos++];
/* 501 */     int i = b << 8 | this.vals[this.readvalpos++] & 0xFF;
/* 502 */     return (char)i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getShort() {
/* 513 */     ensureReadCapacity(2);
/* 514 */     byte b = this.vals[this.readvalpos++];
/* 515 */     int i = b << 8 | this.vals[this.readvalpos++] & 0xFF;
/* 516 */     return (short)i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInt() {
/* 527 */     ensureReadCapacity(4);
/* 528 */     byte b = this.vals[this.readvalpos++];
/* 529 */     int i = b << 8 | this.vals[this.readvalpos++] & 0xFF;
/* 530 */     i = i << 8 | this.vals[this.readvalpos++] & 0xFF;
/* 531 */     i = i << 8 | this.vals[this.readvalpos++] & 0xFF;
/* 532 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLong() {
/* 543 */     ensureReadCapacity(8);
/* 544 */     long l = this.vals[this.readvalpos++];
/* 545 */     l = l << 8L | (this.vals[this.readvalpos++] & 0xFF);
/* 546 */     l = l << 8L | (this.vals[this.readvalpos++] & 0xFF);
/* 547 */     l = l << 8L | (this.vals[this.readvalpos++] & 0xFF);
/* 548 */     l = l << 8L | (this.vals[this.readvalpos++] & 0xFF);
/* 549 */     l = l << 8L | (this.vals[this.readvalpos++] & 0xFF);
/* 550 */     l = l << 8L | (this.vals[this.readvalpos++] & 0xFF);
/* 551 */     l = l << 8L | (this.vals[this.readvalpos++] & 0xFF);
/* 552 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFloat() {
/* 563 */     return Float.intBitsToFloat(getInt());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDouble() {
/* 574 */     return Double.longBitsToDouble(getLong());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject() {
/* 585 */     if (this.readobjpos >= this.objs.length) {
/* 586 */       throw new BufferOverflowException();
/*     */     }
/* 588 */     return this.objs[this.readobjpos++];
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\GrowableDataBuffer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */