/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.Ellipse2D;
/*    */ import com.sun.javafx.geom.RectBounds;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.prism.Graphics;
/*    */ import com.sun.prism.shape.ShapeRep;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGEllipse
/*    */   extends NGShape
/*    */ {
/* 38 */   private Ellipse2D ellipse = new Ellipse2D();
/*    */   private float cx;
/*    */   
/*    */   public void updateEllipse(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 42 */     this.ellipse.x = paramFloat1 - paramFloat3;
/* 43 */     this.ellipse.width = paramFloat3 * 2.0F;
/* 44 */     this.ellipse.y = paramFloat2 - paramFloat4;
/* 45 */     this.ellipse.height = paramFloat4 * 2.0F;
/* 46 */     this.cx = paramFloat1;
/* 47 */     this.cy = paramFloat2;
/* 48 */     geometryChanged();
/*    */   }
/*    */   private float cy;
/*    */   
/*    */   public final Shape getShape() {
/* 53 */     return this.ellipse;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ShapeRep createShapeRep(Graphics paramGraphics) {
/* 58 */     return paramGraphics.getResourceFactory().createEllipseRep();
/*    */   }
/*    */   
/*    */   protected boolean supportsOpaqueRegions() {
/* 62 */     return true;
/*    */   }
/*    */   
/*    */   protected boolean hasOpaqueRegion() {
/* 66 */     return (super.hasOpaqueRegion() && this.ellipse.width > 0.0F && this.ellipse.height > 0.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected RectBounds computeOpaqueRegion(RectBounds paramRectBounds) {
/* 79 */     float f1 = this.ellipse.width * 0.353F;
/* 80 */     float f2 = this.ellipse.height * 0.353F;
/* 81 */     return (RectBounds)paramRectBounds.deriveWithNewBounds(this.cx - f1, this.cy - f2, 0.0F, this.cx + f1, this.cy + f2, 0.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGEllipse.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */