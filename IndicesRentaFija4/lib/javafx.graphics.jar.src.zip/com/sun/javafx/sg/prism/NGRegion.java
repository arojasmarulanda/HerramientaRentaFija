/*      */ package com.sun.javafx.sg.prism;
/*      */ 
/*      */ import com.sun.glass.ui.Screen;
/*      */ import com.sun.javafx.PlatformUtil;
/*      */ import com.sun.javafx.application.PlatformImpl;
/*      */ import com.sun.javafx.geom.Path2D;
/*      */ import com.sun.javafx.geom.RectBounds;
/*      */ import com.sun.javafx.geom.Rectangle;
/*      */ import com.sun.javafx.geom.Shape;
/*      */ import com.sun.javafx.geom.transform.Affine2D;
/*      */ import com.sun.javafx.geom.transform.BaseTransform;
/*      */ import com.sun.javafx.geom.transform.GeneralTransform3D;
/*      */ import com.sun.javafx.logging.PulseLogger;
/*      */ import com.sun.javafx.scene.NodeHelper;
/*      */ import com.sun.javafx.tk.Toolkit;
/*      */ import com.sun.prism.BasicStroke;
/*      */ import com.sun.prism.Graphics;
/*      */ import com.sun.prism.Image;
/*      */ import com.sun.prism.RTTexture;
/*      */ import com.sun.prism.Texture;
/*      */ import com.sun.prism.impl.PrismSettings;
/*      */ import com.sun.prism.paint.ImagePattern;
/*      */ import com.sun.prism.paint.Paint;
/*      */ import com.sun.scenario.effect.Offset;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.WeakHashMap;
/*      */ import javafx.geometry.Insets;
/*      */ import javafx.geometry.Side;
/*      */ import javafx.scene.layout.Background;
/*      */ import javafx.scene.layout.BackgroundFill;
/*      */ import javafx.scene.layout.BackgroundImage;
/*      */ import javafx.scene.layout.BackgroundPosition;
/*      */ import javafx.scene.layout.BackgroundRepeat;
/*      */ import javafx.scene.layout.BackgroundSize;
/*      */ import javafx.scene.layout.Border;
/*      */ import javafx.scene.layout.BorderImage;
/*      */ import javafx.scene.layout.BorderRepeat;
/*      */ import javafx.scene.layout.BorderStroke;
/*      */ import javafx.scene.layout.BorderStrokeStyle;
/*      */ import javafx.scene.layout.BorderWidths;
/*      */ import javafx.scene.layout.CornerRadii;
/*      */ import javafx.scene.paint.Color;
/*      */ import javafx.scene.paint.LinearGradient;
/*      */ import javafx.scene.paint.Paint;
/*      */ import javafx.scene.shape.Shape;
/*      */ import javafx.scene.shape.StrokeLineCap;
/*      */ import javafx.scene.shape.StrokeLineJoin;
/*      */ import javafx.scene.shape.StrokeType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NGRegion
/*      */   extends NGGroup
/*      */ {
/*   88 */   private static final Affine2D SCRATCH_AFFINE = new Affine2D();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   95 */   private static final Rectangle TEMP_RECT = new Rectangle();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  102 */   private static WeakHashMap<Screen, RegionImageCache> imageCacheMap = new WeakHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CACHE_SLICE_V = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int CACHE_SLICE_H = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  119 */   private Background background = Background.EMPTY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   private Insets backgroundInsets = Insets.EMPTY;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   private Border border = Border.EMPTY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<CornerRadii> normalizedFillCorners;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<CornerRadii> normalizedStrokeCorners;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Shape shape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private NGShape ngShape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean scaleShape = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean centerShape = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean cacheShape = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  176 */   private float opaqueTop = Float.NaN; private float opaqueRight = Float.NaN; private float opaqueBottom = Float.NaN; private float opaqueLeft = Float.NaN;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float width;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float height;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int cacheMode;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Integer cacheKey;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Paint getPlatformPaint(Paint paramPaint) {
/*  203 */     return (Paint)Toolkit.getPaintAccessor().getPlatformPaint(paramPaint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  209 */   private static final Offset nopEffect = new Offset(0, 0, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private EffectFilter nopEffectFilter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShape(Object paramObject, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*  229 */     this.ngShape = (paramObject == null) ? null : (NGShape)NodeHelper.getPeer((Shape)paramObject);
/*  230 */     this.shape = (paramObject == null) ? null : this.ngShape.getShape();
/*  231 */     this.scaleShape = paramBoolean1;
/*  232 */     this.centerShape = paramBoolean2;
/*  233 */     this.cacheShape = paramBoolean3;
/*      */ 
/*      */     
/*  236 */     invalidateOpaqueRegion();
/*  237 */     this.cacheKey = null;
/*  238 */     visualsChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSize(float paramFloat1, float paramFloat2) {
/*  249 */     this.width = paramFloat1;
/*  250 */     this.height = paramFloat2;
/*  251 */     invalidateOpaqueRegion();
/*  252 */     this.cacheKey = null;
/*  253 */     visualsChanged();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  258 */     if (this.background != null && this.background.isFillPercentageBased()) {
/*  259 */       this.backgroundInsets = null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void imagesUpdated() {
/*  269 */     visualsChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBorder(Border paramBorder) {
/*  280 */     Border border = this.border;
/*  281 */     this.border = (paramBorder == null) ? Border.EMPTY : paramBorder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  288 */     if (!this.border.getOutsets().equals(border.getOutsets())) {
/*  289 */       geometryChanged();
/*      */     } else {
/*  291 */       visualsChanged();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateStrokeCorners(List<CornerRadii> paramList) {
/*  308 */     this.normalizedStrokeCorners = paramList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CornerRadii getNormalizedStrokeRadii(int paramInt) {
/*  322 */     return (this.normalizedStrokeCorners == null) ? (
/*  323 */       (BorderStroke)this.border.getStrokes().get(paramInt)).getRadii() : 
/*  324 */       this.normalizedStrokeCorners.get(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBackground(Background paramBackground) {
/*  342 */     Background background = this.background;
/*  343 */     this.background = (paramBackground == null) ? Background.EMPTY : paramBackground;
/*      */     
/*  345 */     List<BackgroundFill> list = this.background.getFills();
/*  346 */     this.cacheMode = 0;
/*  347 */     if (!PrismSettings.disableRegionCaching && !list.isEmpty() && (this.shape == null || this.cacheShape)) {
/*  348 */       this.cacheMode = 3; byte b; int i;
/*  349 */       for (b = 0, i = list.size(); b < i && this.cacheMode != 0; b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  354 */         BackgroundFill backgroundFill = list.get(b);
/*  355 */         Paint paint = backgroundFill.getFill();
/*  356 */         if (this.shape == null) {
/*  357 */           if (paint instanceof LinearGradient) {
/*  358 */             LinearGradient linearGradient = (LinearGradient)paint;
/*  359 */             if (linearGradient.getStartX() != linearGradient.getEndX()) {
/*  360 */               this.cacheMode &= 0xFFFFFFFD;
/*      */             }
/*  362 */             if (linearGradient.getStartY() != linearGradient.getEndY()) {
/*  363 */               this.cacheMode &= 0xFFFFFFFE;
/*      */             }
/*  365 */           } else if (!(paint instanceof Color)) {
/*      */             
/*  367 */             this.cacheMode = 0;
/*      */           } 
/*  369 */         } else if (paint instanceof javafx.scene.paint.ImagePattern) {
/*  370 */           this.cacheMode = 0;
/*      */         } 
/*      */       } 
/*      */     } 
/*  374 */     this.backgroundInsets = null;
/*  375 */     this.cacheKey = null;
/*      */ 
/*      */     
/*  378 */     if (!this.background.getOutsets().equals(background.getOutsets())) {
/*  379 */       geometryChanged();
/*      */     } else {
/*  381 */       visualsChanged();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFillCorners(List<CornerRadii> paramList) {
/*  398 */     this.normalizedFillCorners = paramList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CornerRadii getNormalizedFillRadii(int paramInt) {
/*  412 */     return (this.normalizedFillCorners == null) ? (
/*  413 */       (BackgroundFill)this.background.getFills().get(paramInt)).getRadii() : 
/*  414 */       this.normalizedFillCorners.get(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOpaqueInsets(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  433 */     this.opaqueTop = paramFloat1;
/*  434 */     this.opaqueRight = paramFloat2;
/*  435 */     this.opaqueBottom = paramFloat3;
/*  436 */     this.opaqueLeft = paramFloat4;
/*  437 */     invalidateOpaqueRegion();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDirtyTree() {
/*  445 */     super.clearDirtyTree();
/*  446 */     if (this.ngShape != null) {
/*  447 */       this.ngShape.clearDirtyTree();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RegionImageCache getImageCache(Graphics paramGraphics) {
/*  459 */     Screen screen = paramGraphics.getAssociatedScreen();
/*  460 */     RegionImageCache regionImageCache = imageCacheMap.get(screen);
/*  461 */     if (regionImageCache != null) {
/*  462 */       RTTexture rTTexture = regionImageCache.getBackingStore();
/*  463 */       if (rTTexture.isSurfaceLost()) {
/*  464 */         imageCacheMap.remove(screen);
/*  465 */         regionImageCache = null;
/*      */       } 
/*      */     } 
/*  468 */     if (regionImageCache == null) {
/*  469 */       regionImageCache = new RegionImageCache(paramGraphics.getResourceFactory());
/*  470 */       imageCacheMap.put(screen, regionImageCache);
/*      */     } 
/*  472 */     return regionImageCache;
/*      */   }
/*      */   
/*      */   private Integer getCacheKey(int paramInt1, int paramInt2) {
/*  476 */     if (this.cacheKey == null) {
/*  477 */       int i = 31 * paramInt1;
/*  478 */       i = i * 37 + paramInt2;
/*  479 */       i = i * 47 + this.background.hashCode();
/*  480 */       if (this.shape != null) {
/*  481 */         i = i * 73 + this.shape.hashCode();
/*      */       }
/*  483 */       this.cacheKey = Integer.valueOf(i);
/*      */     } 
/*  485 */     return this.cacheKey;
/*      */   }
/*      */   protected boolean supportsOpaqueRegions() {
/*  488 */     return true;
/*      */   }
/*      */   
/*      */   protected boolean hasOpaqueRegion() {
/*  492 */     return (super.hasOpaqueRegion() && 
/*  493 */       !Float.isNaN(this.opaqueTop) && !Float.isNaN(this.opaqueRight) && 
/*  494 */       !Float.isNaN(this.opaqueBottom) && !Float.isNaN(this.opaqueLeft));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RectBounds computeOpaqueRegion(RectBounds paramRectBounds) {
/*  507 */     return (RectBounds)paramRectBounds.deriveWithNewBounds(this.opaqueLeft, this.opaqueTop, 0.0F, this.width - this.opaqueRight, this.height - this.opaqueBottom, 0.0F);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NGNode.RenderRootResult computeRenderRoot(NodePath paramNodePath, RectBounds paramRectBounds, int paramInt, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/*  514 */     NGNode.RenderRootResult renderRootResult = super.computeRenderRoot(paramNodePath, paramRectBounds, paramInt, paramBaseTransform, paramGeneralTransform3D);
/*  515 */     if (renderRootResult == NGNode.RenderRootResult.NO_RENDER_ROOT) {
/*  516 */       renderRootResult = computeNodeRenderRoot(paramNodePath, paramRectBounds, paramInt, paramBaseTransform, paramGeneralTransform3D);
/*      */     }
/*  518 */     return renderRootResult;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasVisuals() {
/*  526 */     return (!this.border.isEmpty() || !this.background.isEmpty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasOverlappingContents() {
/*  536 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void renderContent(Graphics paramGraphics) {
/*  554 */     if (!paramGraphics.getTransformNoClone().is2D() && isContentBounds2D()) {
/*  555 */       assert getEffectFilter() == null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  560 */       if (this.nopEffectFilter == null) {
/*  561 */         this.nopEffectFilter = new EffectFilter(nopEffect, this);
/*      */       }
/*  563 */       this.nopEffectFilter.render(paramGraphics);
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  571 */     if (this.shape != null) {
/*  572 */       renderAsShape(paramGraphics);
/*  573 */     } else if (this.width > 0.0F && this.height > 0.0F) {
/*  574 */       renderAsRectangle(paramGraphics);
/*      */     } 
/*      */ 
/*      */     
/*  578 */     super.renderContent(paramGraphics);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderAsShape(Graphics paramGraphics) {
/*  593 */     if (!this.background.isEmpty()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  598 */       Insets insets = this.background.getOutsets();
/*  599 */       Shape shape = resizeShape((float)-insets.getTop(), (float)-insets.getRight(), 
/*  600 */           (float)-insets.getBottom(), (float)-insets.getLeft());
/*  601 */       RectBounds rectBounds = shape.getBounds();
/*  602 */       int i = Math.round(rectBounds.getWidth());
/*  603 */       int j = Math.round(rectBounds.getHeight());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  611 */       RTTexture rTTexture = null;
/*  612 */       Rectangle rectangle = null;
/*      */ 
/*      */       
/*  615 */       if (this.cacheMode != 0 && paramGraphics.getTransformNoClone().isTranslateOrIdentity()) {
/*  616 */         RegionImageCache regionImageCache = getImageCache(paramGraphics);
/*  617 */         if (regionImageCache.isImageCachable(i, j)) {
/*  618 */           Integer integer = getCacheKey(i, j);
/*  619 */           rectangle = TEMP_RECT;
/*  620 */           rectangle.setBounds(0, 0, i + 1, j + 1);
/*  621 */           boolean bool = regionImageCache.getImageLocation(integer, rectangle, this.background, this.shape, paramGraphics);
/*  622 */           if (!rectangle.isEmpty())
/*      */           {
/*  624 */             rTTexture = regionImageCache.getBackingStore();
/*      */           }
/*  626 */           if (rTTexture != null && bool) {
/*  627 */             Graphics graphics = rTTexture.createGraphics();
/*      */ 
/*      */ 
/*      */             
/*  631 */             graphics.translate(rectangle.x - rectBounds.getMinX(), rectangle.y - rectBounds
/*  632 */                 .getMinY());
/*  633 */             renderBackgroundShape(graphics);
/*  634 */             if (PulseLogger.PULSE_LOGGING_ENABLED) {
/*  635 */               PulseLogger.incrementCounter("Rendering region shape image to cache");
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  643 */       if (rTTexture != null) {
/*      */         
/*  645 */         float f1 = rectBounds.getMinX();
/*  646 */         float f2 = rectBounds.getMinY();
/*  647 */         float f3 = rectBounds.getMaxX();
/*  648 */         float f4 = rectBounds.getMaxY();
/*      */         
/*  650 */         float f5 = rectangle.x;
/*  651 */         float f6 = rectangle.y;
/*  652 */         float f7 = f5 + i;
/*  653 */         float f8 = f6 + j;
/*      */         
/*  655 */         paramGraphics.drawTexture(rTTexture, f1, f2, f3, f4, f5, f6, f7, f8);
/*  656 */         if (PulseLogger.PULSE_LOGGING_ENABLED) {
/*  657 */           PulseLogger.incrementCounter("Cached region shape image used");
/*      */         }
/*      */       } else {
/*      */         
/*  661 */         renderBackgroundShape(paramGraphics);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  669 */     if (!this.border.isEmpty()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  674 */       List<BorderStroke> list = this.border.getStrokes(); byte b; int i;
/*  675 */       for (b = 0, i = list.size(); b < i; b++) {
/*      */ 
/*      */         
/*  678 */         BorderStroke borderStroke = list.get(b);
/*      */ 
/*      */         
/*  681 */         setBorderStyle(paramGraphics, borderStroke, -1.0D, false);
/*  682 */         Insets insets = borderStroke.getInsets();
/*  683 */         paramGraphics.draw(resizeShape((float)insets.getTop(), (float)insets.getRight(), 
/*  684 */               (float)insets.getBottom(), (float)insets.getLeft()));
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void renderBackgroundShape(Graphics paramGraphics) {
/*  690 */     if (PulseLogger.PULSE_LOGGING_ENABLED) {
/*  691 */       PulseLogger.incrementCounter("NGRegion renderBackgroundShape slow path");
/*  692 */       PulseLogger.addMessage("Slow shape path for " + getName());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  698 */     List<BackgroundFill> list = this.background.getFills(); int i;
/*  699 */     for (byte b = 0; b < i; b++) {
/*  700 */       BackgroundFill backgroundFill = list.get(b);
/*      */ 
/*      */       
/*  703 */       Paint paint = getPlatformPaint(backgroundFill.getFill());
/*  704 */       assert paint != null;
/*  705 */       paramGraphics.setPaint(paint);
/*      */ 
/*      */       
/*  708 */       Insets insets = backgroundFill.getInsets();
/*  709 */       paramGraphics.fill(resizeShape((float)insets.getTop(), (float)insets.getRight(), 
/*  710 */             (float)insets.getBottom(), (float)insets.getLeft()));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  716 */     List<BackgroundImage> list1 = this.background.getImages(); int j;
/*  717 */     for (i = 0, j = list1.size(); i < j; i++) {
/*  718 */       BackgroundImage backgroundImage = list1.get(i);
/*  719 */       Image image = (Image)Toolkit.getImageAccessor().getPlatformImage(backgroundImage.getImage());
/*  720 */       if (image != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  728 */         Shape shape = resizeShape(0.0F, 0.0F, 0.0F, 0.0F);
/*      */ 
/*      */         
/*  731 */         RectBounds rectBounds = shape.getBounds();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  736 */         ImagePattern imagePattern = backgroundImage.getSize().isCover() ? new ImagePattern(image, rectBounds.getMinX(), rectBounds.getMinY(), rectBounds.getWidth(), rectBounds.getHeight(), false, false) : new ImagePattern(image, rectBounds.getMinX(), rectBounds.getMinY(), image.getWidth(), image.getHeight(), false, false);
/*  737 */         paramGraphics.setPaint(imagePattern);
/*      */         
/*  739 */         paramGraphics.fill(shape);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderAsRectangle(Graphics paramGraphics) {
/*  752 */     if (!this.background.isEmpty()) {
/*  753 */       renderBackgroundRectangle(paramGraphics);
/*      */     }
/*      */     
/*  756 */     if (!this.border.isEmpty()) {
/*  757 */       renderBorderRectangle(paramGraphics);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderBackgroundRectangle(Graphics paramGraphics) {
/*  772 */     if (this.backgroundInsets == null) updateBackgroundInsets(); 
/*  773 */     double d1 = this.backgroundInsets.getLeft() + 1.0D;
/*  774 */     double d2 = this.backgroundInsets.getRight() + 1.0D;
/*  775 */     double d3 = this.backgroundInsets.getTop() + 1.0D;
/*  776 */     double d4 = this.backgroundInsets.getBottom() + 1.0D;
/*      */ 
/*      */ 
/*      */     
/*  780 */     int i = roundUp(this.width);
/*  781 */     if ((this.cacheMode & 0x2) != 0) {
/*  782 */       i = Math.min(i, (int)(d1 + d2));
/*      */     }
/*  784 */     int j = roundUp(this.height);
/*  785 */     if ((this.cacheMode & 0x1) != 0) {
/*  786 */       j = Math.min(j, (int)(d3 + d4));
/*      */     }
/*      */     
/*  789 */     Insets insets = this.background.getOutsets();
/*  790 */     int k = roundUp(insets.getTop());
/*  791 */     int m = roundUp(insets.getRight());
/*  792 */     int n = roundUp(insets.getBottom());
/*  793 */     int i1 = roundUp(insets.getLeft());
/*      */ 
/*      */ 
/*      */     
/*  797 */     int i2 = i1 + i + m;
/*  798 */     int i3 = k + j + n;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  808 */     boolean bool = (this.background.getFills().size() > 1 && this.cacheMode != 0 && paramGraphics.getTransformNoClone().isTranslateOrIdentity()) ? true : false;
/*      */     
/*  810 */     RTTexture rTTexture = null;
/*  811 */     Rectangle rectangle = null;
/*  812 */     if (bool) {
/*  813 */       RegionImageCache regionImageCache = getImageCache(paramGraphics);
/*  814 */       if (regionImageCache.isImageCachable(i2, i3)) {
/*  815 */         Integer integer = getCacheKey(i2, i3);
/*  816 */         rectangle = TEMP_RECT;
/*  817 */         rectangle.setBounds(0, 0, i2 + 1, i3 + 1);
/*  818 */         boolean bool1 = regionImageCache.getImageLocation(integer, rectangle, this.background, this.shape, paramGraphics);
/*  819 */         if (!rectangle.isEmpty())
/*      */         {
/*  821 */           rTTexture = regionImageCache.getBackingStore();
/*      */         }
/*  823 */         if (rTTexture != null && bool1) {
/*  824 */           Graphics graphics = rTTexture.createGraphics();
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  829 */           graphics.translate((rectangle.x + i1), (rectangle.y + k));
/*      */ 
/*      */           
/*  832 */           renderBackgroundRectanglesDirectly(graphics, i, j);
/*      */           
/*  834 */           if (PulseLogger.PULSE_LOGGING_ENABLED) {
/*  835 */             PulseLogger.incrementCounter("Rendering region background image to cache");
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  843 */     if (rTTexture != null) {
/*  844 */       renderBackgroundRectangleFromCache(paramGraphics, rTTexture, rectangle, i2, i3, d3, d2, d4, d1, k, m, n, i1);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  850 */       renderBackgroundRectanglesDirectly(paramGraphics, this.width, this.height);
/*      */     } 
/*      */     
/*  853 */     List<BackgroundImage> list = this.background.getImages(); byte b; int i4;
/*  854 */     for (b = 0, i4 = list.size(); b < i4; b++) {
/*  855 */       BackgroundImage backgroundImage = list.get(b);
/*  856 */       Image image = (Image)Toolkit.getImageAccessor().getPlatformImage(backgroundImage.getImage());
/*  857 */       if (image != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  864 */         int i5 = (int)backgroundImage.getImage().getWidth();
/*  865 */         int i6 = (int)backgroundImage.getImage().getHeight();
/*  866 */         int i7 = image.getWidth();
/*  867 */         int i8 = image.getHeight();
/*      */         
/*  869 */         if (i7 != 0 && i8 != 0) {
/*  870 */           BackgroundSize backgroundSize = backgroundImage.getSize();
/*  871 */           if (backgroundSize.isCover()) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  876 */             float f = Math.max(this.width / i7, this.height / i8);
/*      */             
/*  878 */             Texture texture = paramGraphics.getResourceFactory().getCachedTexture(image, Texture.WrapMode.CLAMP_TO_EDGE);
/*  879 */             paramGraphics.drawTexture(texture, 0.0F, 0.0F, this.width, this.height, 0.0F, 0.0F, this.width / f, this.height / f);
/*      */ 
/*      */ 
/*      */             
/*  883 */             texture.unlock();
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/*  890 */             double d7, d8, d9, d10, d5 = backgroundSize.isWidthAsPercentage() ? (backgroundSize.getWidth() * this.width) : backgroundSize.getWidth();
/*  891 */             double d6 = backgroundSize.isHeightAsPercentage() ? (backgroundSize.getHeight() * this.height) : backgroundSize.getHeight();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  897 */             if (backgroundSize.isContain()) {
/*      */ 
/*      */ 
/*      */               
/*  901 */               float f1 = this.width / i5;
/*  902 */               float f2 = this.height / i6;
/*  903 */               float f3 = Math.min(f1, f2);
/*  904 */               d7 = Math.ceil((f3 * i5));
/*  905 */               d8 = Math.ceil((f3 * i6));
/*  906 */             } else if (backgroundSize.getWidth() >= 0.0D && backgroundSize.getHeight() >= 0.0D) {
/*      */ 
/*      */ 
/*      */               
/*  910 */               d7 = d5;
/*  911 */               d8 = d6;
/*  912 */             } else if (d5 >= 0.0D) {
/*      */               
/*  914 */               d7 = d5;
/*  915 */               double d = d7 / i5;
/*  916 */               d8 = i6 * d;
/*  917 */             } else if (d6 >= 0.0D) {
/*      */               
/*  919 */               d8 = d6;
/*  920 */               double d = d8 / i6;
/*  921 */               d7 = i5 * d;
/*      */             } else {
/*      */               
/*  924 */               d7 = i5;
/*  925 */               d8 = i6;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  932 */             BackgroundPosition backgroundPosition = backgroundImage.getPosition();
/*      */ 
/*      */             
/*  935 */             if (backgroundPosition.getHorizontalSide() == Side.LEFT) {
/*  936 */               double d = backgroundPosition.getHorizontalPosition();
/*  937 */               if (backgroundPosition.isHorizontalAsPercentage()) {
/*  938 */                 d9 = d * this.width - d * d7;
/*      */               } else {
/*  940 */                 d9 = d;
/*      */               }
/*      */             
/*  943 */             } else if (backgroundPosition.isHorizontalAsPercentage()) {
/*  944 */               double d = 1.0D - backgroundPosition.getHorizontalPosition();
/*  945 */               d9 = d * this.width - d * d7;
/*      */             } else {
/*  947 */               d9 = this.width - d7 - backgroundPosition.getHorizontalPosition();
/*      */             } 
/*      */ 
/*      */             
/*  951 */             if (backgroundPosition.getVerticalSide() == Side.TOP) {
/*  952 */               double d = backgroundPosition.getVerticalPosition();
/*  953 */               if (backgroundPosition.isVerticalAsPercentage()) {
/*  954 */                 d10 = d * this.height - d * d8;
/*      */               } else {
/*  956 */                 d10 = d;
/*      */               }
/*      */             
/*  959 */             } else if (backgroundPosition.isVerticalAsPercentage()) {
/*  960 */               double d = 1.0D - backgroundPosition.getVerticalPosition();
/*  961 */               d10 = d * this.height - d * d8;
/*      */             } else {
/*  963 */               d10 = this.height - d8 - backgroundPosition.getVerticalPosition();
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  969 */             paintTiles(paramGraphics, image, backgroundImage.getRepeatX(), backgroundImage.getRepeatY(), backgroundPosition
/*  970 */                 .getHorizontalSide(), backgroundPosition.getVerticalSide(), 0.0F, 0.0F, this.width, this.height, 0, 0, i7, i8, (float)d9, (float)d10, (float)d7, (float)d8);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderBackgroundRectangleFromCache(Graphics paramGraphics, RTTexture paramRTTexture, Rectangle paramRectangle, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  992 */     float f1 = paramInt6 + this.width + paramInt4;
/*  993 */     float f2 = paramInt3 + this.height + paramInt5;
/*  994 */     boolean bool1 = (paramInt1 == f1) ? true : false;
/*  995 */     boolean bool2 = (paramInt2 == f2) ? true : false;
/*  996 */     float f3 = -paramInt6 - 0.49609375F;
/*  997 */     float f4 = -paramInt3 - 0.49609375F;
/*  998 */     float f5 = this.width + paramInt4 + 0.49609375F;
/*  999 */     float f6 = this.height + paramInt5 + 0.49609375F;
/* 1000 */     float f7 = paramRectangle.x - 0.49609375F;
/* 1001 */     float f8 = paramRectangle.y - 0.49609375F;
/* 1002 */     float f9 = (paramRectangle.x + paramInt1) + 0.49609375F;
/* 1003 */     float f10 = (paramRectangle.y + paramInt2) + 0.49609375F;
/*      */ 
/*      */ 
/*      */     
/* 1007 */     double d1 = paramDouble4;
/* 1008 */     double d2 = paramDouble2;
/* 1009 */     double d3 = paramDouble1;
/* 1010 */     double d4 = paramDouble3;
/* 1011 */     if (paramDouble4 + paramDouble2 > this.width) {
/* 1012 */       double d = this.width / (paramDouble4 + paramDouble2);
/* 1013 */       d1 *= d;
/* 1014 */       d2 *= d;
/*      */     } 
/* 1016 */     if (paramDouble1 + paramDouble3 > this.height) {
/* 1017 */       double d = this.height / (paramDouble1 + paramDouble3);
/* 1018 */       d3 *= d;
/* 1019 */       d4 *= d;
/*      */     } 
/*      */     
/* 1022 */     if (bool1 && bool2) {
/* 1023 */       paramGraphics.drawTexture(paramRTTexture, f3, f4, f5, f6, f7, f8, f9, f10);
/* 1024 */     } else if (bool2) {
/*      */       
/* 1026 */       float f11 = 0.49609375F + (float)(d1 + paramInt6);
/* 1027 */       float f12 = 0.49609375F + (float)(d2 + paramInt4);
/*      */       
/* 1029 */       float f13 = f3 + f11;
/* 1030 */       float f14 = f5 - f12;
/* 1031 */       float f15 = f7 + f11;
/* 1032 */       float f16 = f9 - f12;
/*      */       
/* 1034 */       paramGraphics.drawTexture3SliceH(paramRTTexture, f3, f4, f5, f6, f7, f8, f9, f10, f13, f14, f15, f16);
/*      */ 
/*      */     
/*      */     }
/* 1038 */     else if (bool1) {
/*      */       
/* 1040 */       float f11 = 0.49609375F + (float)(d3 + paramInt3);
/* 1041 */       float f12 = 0.49609375F + (float)(d4 + paramInt5);
/*      */       
/* 1043 */       float f13 = f4 + f11;
/* 1044 */       float f14 = f6 - f12;
/* 1045 */       float f15 = f8 + f11;
/* 1046 */       float f16 = f10 - f12;
/*      */       
/* 1048 */       paramGraphics.drawTexture3SliceV(paramRTTexture, f3, f4, f5, f6, f7, f8, f9, f10, f13, f14, f15, f16);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1054 */       float f11 = 0.49609375F + (float)(d1 + paramInt6);
/* 1055 */       float f12 = 0.49609375F + (float)(d3 + paramInt3);
/* 1056 */       float f13 = 0.49609375F + (float)(d2 + paramInt4);
/* 1057 */       float f14 = 0.49609375F + (float)(d4 + paramInt5);
/*      */       
/* 1059 */       float f15 = f3 + f11;
/* 1060 */       float f16 = f5 - f13;
/* 1061 */       float f17 = f7 + f11;
/* 1062 */       float f18 = f9 - f13;
/* 1063 */       float f19 = f4 + f12;
/* 1064 */       float f20 = f6 - f14;
/* 1065 */       float f21 = f8 + f12;
/* 1066 */       float f22 = f10 - f14;
/*      */       
/* 1068 */       paramGraphics.drawTexture9Slice(paramRTTexture, f3, f4, f5, f6, f7, f8, f9, f10, f15, f19, f16, f20, f17, f21, f18, f22);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1075 */     if (PulseLogger.PULSE_LOGGING_ENABLED) {
/* 1076 */       PulseLogger.incrementCounter("Cached region background image used");
/*      */     }
/*      */   }
/*      */   
/*      */   private void renderBackgroundRectanglesDirectly(Graphics paramGraphics, float paramFloat1, float paramFloat2) {
/* 1081 */     List<BackgroundFill> list = this.background.getFills(); byte b; int i;
/* 1082 */     for (b = 0, i = list.size(); b < i; b++) {
/* 1083 */       BackgroundFill backgroundFill = list.get(b);
/* 1084 */       Insets insets = backgroundFill.getInsets();
/* 1085 */       float f1 = (float)insets.getTop();
/* 1086 */       float f2 = (float)insets.getLeft();
/* 1087 */       float f3 = (float)insets.getBottom();
/* 1088 */       float f4 = (float)insets.getRight();
/*      */       
/* 1090 */       float f5 = paramFloat1 - f2 - f4;
/* 1091 */       float f6 = paramFloat2 - f1 - f3;
/*      */ 
/*      */ 
/*      */       
/* 1095 */       if (f5 > 0.0F && f6 > 0.0F) {
/*      */         
/* 1097 */         Paint paint = getPlatformPaint(backgroundFill.getFill());
/* 1098 */         paramGraphics.setPaint(paint);
/* 1099 */         CornerRadii cornerRadii = getNormalizedFillRadii(b);
/*      */ 
/*      */         
/* 1102 */         if (cornerRadii.isUniform() && (
/* 1103 */           PlatformImpl.isCaspian() || PlatformUtil.isEmbedded() || PlatformUtil.isIOS() || cornerRadii.getTopLeftHorizontalRadius() <= 0.0D || cornerRadii.getTopLeftHorizontalRadius() > 4.0D)) {
/*      */ 
/*      */           
/* 1106 */           float f7 = (float)cornerRadii.getTopLeftHorizontalRadius();
/* 1107 */           float f8 = (float)cornerRadii.getTopLeftVerticalRadius();
/* 1108 */           if (f7 == 0.0F && f8 == 0.0F) {
/*      */             
/* 1110 */             paramGraphics.fillRect(f2, f1, f5, f6);
/*      */           }
/*      */           else {
/*      */             
/* 1114 */             float f9 = f7 + f7;
/* 1115 */             float f10 = f8 + f8;
/*      */ 
/*      */ 
/*      */             
/* 1119 */             if (f9 > f5) f9 = f5; 
/* 1120 */             if (f10 > f6) f10 = f6; 
/* 1121 */             paramGraphics.fillRoundRect(f2, f1, f5, f6, f9, f10);
/*      */           } 
/*      */         } else {
/* 1124 */           if (PulseLogger.PULSE_LOGGING_ENABLED) {
/* 1125 */             PulseLogger.incrementCounter("NGRegion renderBackgrounds slow path");
/* 1126 */             PulseLogger.addMessage("Slow background path for " + getName());
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1132 */           paramGraphics.fill(createPath(paramFloat1, paramFloat2, f1, f2, f3, f4, cornerRadii));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void renderBorderRectangle(Graphics paramGraphics) {
/* 1139 */     List<BorderImage> list = this.border.getImages();
/* 1140 */     List<BorderStroke> list1 = (List<BorderStroke>)(list.isEmpty() ? this.border.getStrokes() : Collections.emptyList()); byte b; int i;
/* 1141 */     for (b = 0, i = list1.size(); b < i; b++) {
/* 1142 */       BorderStroke borderStroke = list1.get(b);
/* 1143 */       BorderWidths borderWidths = borderStroke.getWidths();
/* 1144 */       CornerRadii cornerRadii = getNormalizedStrokeRadii(b);
/* 1145 */       Insets insets = borderStroke.getInsets();
/*      */       
/* 1147 */       Paint paint1 = borderStroke.getTopStroke();
/* 1148 */       Paint paint2 = borderStroke.getRightStroke();
/* 1149 */       Paint paint3 = borderStroke.getBottomStroke();
/* 1150 */       Paint paint4 = borderStroke.getLeftStroke();
/*      */       
/* 1152 */       float f1 = (float)insets.getTop();
/* 1153 */       float f2 = (float)insets.getRight();
/* 1154 */       float f3 = (float)insets.getBottom();
/* 1155 */       float f4 = (float)insets.getLeft();
/*      */       
/* 1157 */       float f5 = (float)(borderWidths.isTopAsPercentage() ? (this.height * borderWidths.getTop()) : borderWidths.getTop());
/* 1158 */       float f6 = (float)(borderWidths.isRightAsPercentage() ? (this.width * borderWidths.getRight()) : borderWidths.getRight());
/* 1159 */       float f7 = (float)(borderWidths.isBottomAsPercentage() ? (this.height * borderWidths.getBottom()) : borderWidths.getBottom());
/* 1160 */       float f8 = (float)(borderWidths.isLeftAsPercentage() ? (this.width * borderWidths.getLeft()) : borderWidths.getLeft());
/*      */       
/* 1162 */       BorderStrokeStyle borderStrokeStyle1 = borderStroke.getTopStyle();
/* 1163 */       BorderStrokeStyle borderStrokeStyle2 = borderStroke.getRightStyle();
/* 1164 */       BorderStrokeStyle borderStrokeStyle3 = borderStroke.getBottomStyle();
/* 1165 */       BorderStrokeStyle borderStrokeStyle4 = borderStroke.getLeftStyle();
/*      */       
/* 1167 */       StrokeType strokeType1 = borderStrokeStyle1.getType();
/* 1168 */       StrokeType strokeType2 = borderStrokeStyle2.getType();
/* 1169 */       StrokeType strokeType3 = borderStrokeStyle3.getType();
/* 1170 */       StrokeType strokeType4 = borderStrokeStyle4.getType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1179 */       float f9 = f1 + ((strokeType1 == StrokeType.OUTSIDE) ? (-f5 / 2.0F) : ((strokeType1 == StrokeType.INSIDE) ? (f5 / 2.0F) : 0.0F));
/*      */ 
/*      */       
/* 1182 */       float f10 = f4 + ((strokeType4 == StrokeType.OUTSIDE) ? (-f8 / 2.0F) : ((strokeType4 == StrokeType.INSIDE) ? (f8 / 2.0F) : 0.0F));
/*      */ 
/*      */       
/* 1185 */       float f11 = f3 + ((strokeType3 == StrokeType.OUTSIDE) ? (-f7 / 2.0F) : ((strokeType3 == StrokeType.INSIDE) ? (f7 / 2.0F) : 0.0F));
/*      */ 
/*      */       
/* 1188 */       float f12 = f2 + ((strokeType2 == StrokeType.OUTSIDE) ? (-f6 / 2.0F) : ((strokeType2 == StrokeType.INSIDE) ? (f6 / 2.0F) : 0.0F));
/*      */ 
/*      */ 
/*      */       
/* 1192 */       float f13 = (float)cornerRadii.getTopLeftHorizontalRadius();
/* 1193 */       if (borderStroke.isStrokeUniform()) {
/*      */ 
/*      */         
/* 1196 */         if ((!(paint1 instanceof Color) || ((Color)paint1).getOpacity() != 0.0D) && borderStrokeStyle1 != BorderStrokeStyle.NONE) {
/* 1197 */           float f14 = this.width - f10 - f12;
/* 1198 */           float f15 = this.height - f9 - f11;
/*      */           
/* 1200 */           double d1 = 2.0D * cornerRadii.getTopLeftHorizontalRadius();
/* 1201 */           double d2 = d1 * Math.PI;
/* 1202 */           double d3 = d2 + 2.0D * (f14 - d1) + 2.0D * (f15 - d1);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1207 */           if (f14 >= 0.0F && f15 >= 0.0F) {
/* 1208 */             setBorderStyle(paramGraphics, borderStroke, d3, true);
/* 1209 */             if (cornerRadii.isUniform() && f13 == 0.0F) {
/*      */ 
/*      */               
/* 1212 */               paramGraphics.drawRect(f10, f9, f14, f15);
/* 1213 */             } else if (cornerRadii.isUniform()) {
/*      */ 
/*      */               
/* 1216 */               float f = f13 + f13;
/* 1217 */               if (f > f14) f = f14; 
/* 1218 */               if (f > f15) f = f15; 
/* 1219 */               paramGraphics.drawRoundRect(f10, f9, f14, f15, f, f);
/*      */             }
/*      */             else {
/*      */               
/* 1223 */               paramGraphics.draw(createPath(this.width, this.height, f9, f10, f11, f12, cornerRadii));
/*      */             } 
/*      */           } 
/*      */         } 
/* 1227 */       } else if (cornerRadii.isUniform() && f13 == 0.0F) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1239 */         if ((!(paint1 instanceof Color) || ((Color)paint1).getOpacity() != 0.0D) && borderStrokeStyle1 != BorderStrokeStyle.NONE) {
/* 1240 */           paramGraphics.setPaint(getPlatformPaint(paint1));
/* 1241 */           if (BorderStrokeStyle.SOLID == borderStrokeStyle1) {
/* 1242 */             paramGraphics.fillRect(f4, f1, this.width - f4 - f2, f5);
/*      */           } else {
/* 1244 */             paramGraphics.setStroke(createStroke(borderStrokeStyle1, f5, this.width, true));
/* 1245 */             paramGraphics.drawLine(f10, f9, this.width - f12, f9);
/*      */           } 
/*      */         } 
/*      */         
/* 1249 */         if ((!(paint2 instanceof Color) || ((Color)paint2).getOpacity() != 0.0D) && borderStrokeStyle2 != BorderStrokeStyle.NONE) {
/* 1250 */           paramGraphics.setPaint(getPlatformPaint(paint2));
/* 1251 */           if (BorderStrokeStyle.SOLID == borderStrokeStyle2) {
/* 1252 */             paramGraphics.fillRect(this.width - f2 - f6, f1, f6, this.height - f1 - f3);
/*      */           } else {
/*      */             
/* 1255 */             paramGraphics.setStroke(createStroke(borderStrokeStyle2, f6, this.height, true));
/* 1256 */             paramGraphics.drawLine(this.width - f12, f9, this.width - f12, this.height - f11);
/*      */           } 
/*      */         } 
/*      */         
/* 1260 */         if ((!(paint3 instanceof Color) || ((Color)paint3).getOpacity() != 0.0D) && borderStrokeStyle3 != BorderStrokeStyle.NONE) {
/* 1261 */           paramGraphics.setPaint(getPlatformPaint(paint3));
/* 1262 */           if (BorderStrokeStyle.SOLID == borderStrokeStyle3) {
/* 1263 */             paramGraphics.fillRect(f4, this.height - f3 - f7, this.width - f4 - f2, f7);
/*      */           } else {
/*      */             
/* 1266 */             paramGraphics.setStroke(createStroke(borderStrokeStyle3, f7, this.width, true));
/* 1267 */             paramGraphics.drawLine(f10, this.height - f11, this.width - f12, this.height - f11);
/*      */           } 
/*      */         } 
/*      */         
/* 1271 */         if ((!(paint4 instanceof Color) || ((Color)paint4).getOpacity() != 0.0D) && borderStrokeStyle4 != BorderStrokeStyle.NONE) {
/* 1272 */           paramGraphics.setPaint(getPlatformPaint(paint4));
/* 1273 */           if (BorderStrokeStyle.SOLID == borderStrokeStyle4) {
/* 1274 */             paramGraphics.fillRect(f4, f1, f8, this.height - f1 - f3);
/*      */           } else {
/* 1276 */             paramGraphics.setStroke(createStroke(borderStrokeStyle4, f8, this.height, true));
/* 1277 */             paramGraphics.drawLine(f10, f9, f10, this.height - f11);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1285 */         Path2D[] arrayOfPath2D = createPaths(f9, f10, f11, f12, cornerRadii);
/* 1286 */         if (borderStrokeStyle1 != BorderStrokeStyle.NONE) {
/* 1287 */           double d1 = cornerRadii.getTopLeftHorizontalRadius() + cornerRadii.getTopRightHorizontalRadius();
/* 1288 */           double d2 = this.width + d1 * -0.21460183660255172D;
/* 1289 */           paramGraphics.setStroke(createStroke(borderStrokeStyle1, f5, d2, true));
/* 1290 */           paramGraphics.setPaint(getPlatformPaint(paint1));
/* 1291 */           paramGraphics.draw(arrayOfPath2D[0]);
/*      */         } 
/* 1293 */         if (borderStrokeStyle2 != BorderStrokeStyle.NONE) {
/* 1294 */           double d1 = cornerRadii.getTopRightVerticalRadius() + cornerRadii.getBottomRightVerticalRadius();
/* 1295 */           double d2 = this.height + d1 * -0.21460183660255172D;
/* 1296 */           paramGraphics.setStroke(createStroke(borderStrokeStyle2, f6, d2, true));
/* 1297 */           paramGraphics.setPaint(getPlatformPaint(paint2));
/* 1298 */           paramGraphics.draw(arrayOfPath2D[1]);
/*      */         } 
/* 1300 */         if (borderStrokeStyle3 != BorderStrokeStyle.NONE) {
/* 1301 */           double d1 = cornerRadii.getBottomLeftHorizontalRadius() + cornerRadii.getBottomRightHorizontalRadius();
/* 1302 */           double d2 = this.width + d1 * -0.21460183660255172D;
/* 1303 */           paramGraphics.setStroke(createStroke(borderStrokeStyle3, f7, d2, true));
/* 1304 */           paramGraphics.setPaint(getPlatformPaint(paint3));
/* 1305 */           paramGraphics.draw(arrayOfPath2D[2]);
/*      */         } 
/* 1307 */         if (borderStrokeStyle4 != BorderStrokeStyle.NONE) {
/* 1308 */           double d1 = cornerRadii.getTopLeftVerticalRadius() + cornerRadii.getBottomLeftVerticalRadius();
/* 1309 */           double d2 = this.height + d1 * -0.21460183660255172D;
/* 1310 */           paramGraphics.setStroke(createStroke(borderStrokeStyle4, f8, d2, true));
/* 1311 */           paramGraphics.setPaint(getPlatformPaint(paint4));
/* 1312 */           paramGraphics.draw(arrayOfPath2D[3]);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1317 */     for (b = 0, i = list.size(); b < i; b++) {
/* 1318 */       BorderImage borderImage = list.get(b);
/* 1319 */       Image image = (Image)Toolkit.getImageAccessor().getPlatformImage(borderImage.getImage());
/* 1320 */       if (image != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1326 */         int j = image.getWidth();
/* 1327 */         int k = image.getHeight();
/* 1328 */         float f = image.getPixelScale();
/* 1329 */         BorderWidths borderWidths1 = borderImage.getWidths();
/* 1330 */         Insets insets = borderImage.getInsets();
/* 1331 */         BorderWidths borderWidths2 = borderImage.getSlices();
/*      */ 
/*      */         
/* 1334 */         int m = (int)Math.round(insets.getTop());
/* 1335 */         int n = (int)Math.round(insets.getRight());
/* 1336 */         int i1 = (int)Math.round(insets.getBottom());
/* 1337 */         int i2 = (int)Math.round(insets.getLeft());
/*      */         
/* 1339 */         int i3 = widthSize(borderWidths1.isTopAsPercentage(), borderWidths1.getTop(), this.height);
/* 1340 */         int i4 = widthSize(borderWidths1.isRightAsPercentage(), borderWidths1.getRight(), this.width);
/* 1341 */         int i5 = widthSize(borderWidths1.isBottomAsPercentage(), borderWidths1.getBottom(), this.height);
/* 1342 */         int i6 = widthSize(borderWidths1.isLeftAsPercentage(), borderWidths1.getLeft(), this.width);
/*      */         
/* 1344 */         int i7 = sliceSize(borderWidths2.isTopAsPercentage(), borderWidths2.getTop(), k, f);
/* 1345 */         int i8 = sliceSize(borderWidths2.isRightAsPercentage(), borderWidths2.getRight(), j, f);
/* 1346 */         int i9 = sliceSize(borderWidths2.isBottomAsPercentage(), borderWidths2.getBottom(), k, f);
/* 1347 */         int i10 = sliceSize(borderWidths2.isLeftAsPercentage(), borderWidths2.getLeft(), j, f);
/*      */ 
/*      */         
/* 1350 */         if ((i2 + i6 + n + i4) <= this.width && (m + i3 + i1 + i5) <= this.height) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1356 */           int i11 = i2 + i6;
/* 1357 */           int i12 = m + i3;
/* 1358 */           int i13 = Math.round(this.width) - n - i4 - i11;
/* 1359 */           int i14 = Math.round(this.height) - i1 - i5 - i12;
/* 1360 */           int i15 = i13 + i11;
/* 1361 */           int i16 = i14 + i12;
/* 1362 */           int i17 = j - i10 - i8;
/* 1363 */           int i18 = k - i7 - i9;
/*      */           
/* 1365 */           paintTiles(paramGraphics, image, BorderRepeat.STRETCH, BorderRepeat.STRETCH, Side.LEFT, Side.TOP, i2, m, i6, i3, 0, 0, i10, i7, 0.0F, 0.0F, i6, i3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1371 */           float f1 = (borderImage.getRepeatX() == BorderRepeat.STRETCH) ? i13 : ((i7 > 0) ? (i17 * i3 / i7) : false);
/* 1372 */           float f2 = i3;
/* 1373 */           paintTiles(paramGraphics, image, borderImage
/* 1374 */               .getRepeatX(), BorderRepeat.STRETCH, Side.LEFT, Side.TOP, i11, m, i13, i3, i10, 0, i17, i7, (i13 - f1) / 2.0F, 0.0F, f1, f2);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1379 */           paintTiles(paramGraphics, image, BorderRepeat.STRETCH, BorderRepeat.STRETCH, Side.LEFT, Side.TOP, i15, m, i4, i3, j - i8, 0, i8, i7, 0.0F, 0.0F, i4, i3);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1384 */           f1 = i6;
/*      */           
/* 1386 */           f2 = (borderImage.getRepeatY() == BorderRepeat.STRETCH) ? i14 : ((i10 > 0) ? (i6 * i18 / i10) : false);
/* 1387 */           paintTiles(paramGraphics, image, BorderRepeat.STRETCH, borderImage.getRepeatY(), Side.LEFT, Side.TOP, i2, i12, i6, i14, 0, i7, i10, i18, 0.0F, (i14 - f2) / 2.0F, f1, f2);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1392 */           f1 = i4;
/*      */           
/* 1394 */           f2 = (borderImage.getRepeatY() == BorderRepeat.STRETCH) ? i14 : ((i8 > 0) ? (i4 * i18 / i8) : false);
/* 1395 */           paintTiles(paramGraphics, image, BorderRepeat.STRETCH, borderImage.getRepeatY(), Side.LEFT, Side.TOP, i15, i12, i4, i14, j - i8, i7, i8, i18, 0.0F, (i14 - f2) / 2.0F, f1, f2);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1400 */           paintTiles(paramGraphics, image, BorderRepeat.STRETCH, BorderRepeat.STRETCH, Side.LEFT, Side.TOP, i2, i16, i6, i5, 0, k - i9, i10, i9, 0.0F, 0.0F, i6, i5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1406 */           f1 = (borderImage.getRepeatX() == BorderRepeat.STRETCH) ? i13 : ((i9 > 0) ? (i17 * i5 / i9) : false);
/* 1407 */           f2 = i5;
/* 1408 */           paintTiles(paramGraphics, image, borderImage.getRepeatX(), BorderRepeat.STRETCH, Side.LEFT, Side.TOP, i11, i16, i13, i5, i10, k - i9, i17, i9, (i13 - f1) / 2.0F, 0.0F, f1, f2);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1413 */           paintTiles(paramGraphics, image, BorderRepeat.STRETCH, BorderRepeat.STRETCH, Side.LEFT, Side.TOP, i15, i16, i4, i5, j - i8, k - i9, i8, i9, 0.0F, 0.0F, i4, i5);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1418 */           if (borderImage.isFilled()) {
/*      */             
/* 1420 */             float f3 = (borderImage.getRepeatX() == BorderRepeat.STRETCH) ? i13 : i17;
/* 1421 */             float f4 = (borderImage.getRepeatY() == BorderRepeat.STRETCH) ? i14 : i18;
/* 1422 */             paintTiles(paramGraphics, image, borderImage.getRepeatX(), borderImage.getRepeatY(), Side.LEFT, Side.TOP, i11, i12, i13, i14, i10, i7, i17, i18, 0.0F, 0.0F, f3, f4);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateBackgroundInsets() {
/* 1437 */     float f1 = 0.0F, f2 = 0.0F, f3 = 0.0F, f4 = 0.0F;
/* 1438 */     List<BackgroundFill> list = this.background.getFills(); byte b; int i;
/* 1439 */     for (b = 0, i = list.size(); b < i; b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1444 */       BackgroundFill backgroundFill = list.get(b);
/* 1445 */       Insets insets = backgroundFill.getInsets();
/* 1446 */       CornerRadii cornerRadii = getNormalizedFillRadii(b);
/* 1447 */       f1 = (float)Math.max(f1, insets.getTop() + Math.max(cornerRadii.getTopLeftVerticalRadius(), cornerRadii.getTopRightVerticalRadius()));
/* 1448 */       f2 = (float)Math.max(f2, insets.getRight() + Math.max(cornerRadii.getTopRightHorizontalRadius(), cornerRadii.getBottomRightHorizontalRadius()));
/* 1449 */       f3 = (float)Math.max(f3, insets.getBottom() + Math.max(cornerRadii.getBottomRightVerticalRadius(), cornerRadii.getBottomLeftVerticalRadius()));
/* 1450 */       f4 = (float)Math.max(f4, insets.getLeft() + Math.max(cornerRadii.getTopLeftHorizontalRadius(), cornerRadii.getBottomLeftHorizontalRadius()));
/*      */     } 
/* 1452 */     this.backgroundInsets = new Insets(roundUp(f1), roundUp(f2), roundUp(f3), roundUp(f4));
/*      */   }
/*      */ 
/*      */   
/*      */   private int widthSize(boolean paramBoolean, double paramDouble, float paramFloat) {
/* 1457 */     return (int)Math.round(paramBoolean ? (paramDouble * paramFloat) : paramDouble);
/*      */   }
/*      */   
/*      */   private int sliceSize(boolean paramBoolean, double paramDouble, float paramFloat1, float paramFloat2) {
/* 1461 */     if (paramBoolean) paramDouble *= paramFloat1; 
/* 1462 */     if (paramDouble > paramFloat1) paramDouble = paramFloat1; 
/* 1463 */     return (int)Math.round(paramDouble * paramFloat2);
/*      */   }
/*      */   
/*      */   private int roundUp(double paramDouble) {
/* 1467 */     return (paramDouble - (int)paramDouble == 0.0D) ? (int)paramDouble : (int)(paramDouble + 1.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BasicStroke createStroke(BorderStrokeStyle paramBorderStrokeStyle, double paramDouble1, double paramDouble2, boolean paramBoolean) {
/*      */     boolean bool1;
/*      */     boolean bool2;
/*      */     byte b;
/*      */     BasicStroke basicStroke;
/* 1487 */     if (paramBorderStrokeStyle.getLineCap() == StrokeLineCap.BUTT) {
/* 1488 */       bool1 = false;
/* 1489 */     } else if (paramBorderStrokeStyle.getLineCap() == StrokeLineCap.SQUARE) {
/* 1490 */       bool1 = true;
/*      */     } else {
/* 1492 */       bool1 = true;
/*      */     } 
/*      */ 
/*      */     
/* 1496 */     if (paramBorderStrokeStyle.getLineJoin() == StrokeLineJoin.BEVEL) {
/* 1497 */       bool2 = true;
/* 1498 */     } else if (paramBorderStrokeStyle.getLineJoin() == StrokeLineJoin.MITER) {
/* 1499 */       bool2 = false;
/*      */     } else {
/* 1501 */       bool2 = true;
/*      */     } 
/*      */ 
/*      */     
/* 1505 */     if (paramBoolean) {
/* 1506 */       b = 0;
/* 1507 */     } else if (this.scaleShape) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1512 */       b = 1;
/*      */     } else {
/* 1514 */       switch (paramBorderStrokeStyle.getType()) {
/*      */         case REPEAT:
/* 1516 */           b = 1;
/*      */           break;
/*      */         case STRETCH:
/* 1519 */           b = 2;
/*      */           break;
/*      */         
/*      */         default:
/* 1523 */           b = 0;
/*      */           break;
/*      */       } 
/*      */ 
/*      */     
/*      */     } 
/* 1529 */     if (paramBorderStrokeStyle == BorderStrokeStyle.NONE)
/* 1530 */       throw new AssertionError("Should never have been asked to draw a border with NONE"); 
/* 1531 */     if (paramDouble1 <= 0.0D) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1543 */       basicStroke = new BasicStroke((float)paramDouble1, bool1, bool2, (float)paramBorderStrokeStyle.getMiterLimit());
/* 1544 */     } else if (paramBorderStrokeStyle.getDashArray().size() > 0) {
/* 1545 */       double[] arrayOfDouble; float f; List<Double> list = paramBorderStrokeStyle.getDashArray();
/*      */ 
/*      */       
/* 1548 */       if (list == BorderStrokeStyle.DOTTED.getDashArray()) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1553 */         if (paramDouble2 > 0.0D) {
/*      */ 
/*      */ 
/*      */           
/* 1557 */           double d1 = paramDouble2 % paramDouble1 * 2.0D;
/* 1558 */           double d2 = paramDouble2 / paramDouble1 * 2.0D;
/* 1559 */           double d3 = paramDouble1 * 2.0D + d1 / d2;
/* 1560 */           arrayOfDouble = new double[] { 0.0D, d3 };
/* 1561 */           f = 0.0F;
/*      */         } else {
/* 1563 */           arrayOfDouble = new double[] { 0.0D, paramDouble1 * 2.0D };
/* 1564 */           f = 0.0F;
/*      */         } 
/* 1566 */       } else if (list == BorderStrokeStyle.DASHED.getDashArray()) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1571 */         if (paramDouble2 > 0.0D) {
/*      */ 
/*      */ 
/*      */           
/* 1575 */           double d1 = paramDouble1 * 2.0D;
/* 1576 */           double d2 = paramDouble1 * 1.4D;
/* 1577 */           double d3 = d1 + d2;
/* 1578 */           double d4 = paramDouble2 / d3;
/* 1579 */           double d5 = (int)d4;
/* 1580 */           if (d5 > 0.0D) {
/* 1581 */             double d = d5 * d1;
/* 1582 */             d2 = (paramDouble2 - d) / d5;
/*      */           } 
/* 1584 */           arrayOfDouble = new double[] { d1, d2 };
/* 1585 */           f = (float)(d1 * 0.6D);
/*      */         } else {
/* 1587 */           arrayOfDouble = new double[] { 2.0D * paramDouble1, 1.4D * paramDouble1 };
/* 1588 */           f = 0.0F;
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1593 */         arrayOfDouble = new double[list.size()];
/* 1594 */         for (byte b1 = 0; b1 < arrayOfDouble.length; b1++) {
/* 1595 */           arrayOfDouble[b1] = ((Double)list.get(b1)).doubleValue();
/*      */         }
/* 1597 */         f = (float)paramBorderStrokeStyle.getDashOffset();
/*      */       } 
/*      */ 
/*      */       
/* 1601 */       basicStroke = new BasicStroke(b, (float)paramDouble1, bool1, bool2, (float)paramBorderStrokeStyle.getMiterLimit(), arrayOfDouble, f);
/*      */     }
/*      */     else {
/*      */       
/* 1605 */       basicStroke = new BasicStroke(b, (float)paramDouble1, bool1, bool2, (float)paramBorderStrokeStyle.getMiterLimit());
/*      */     } 
/*      */     
/* 1608 */     return basicStroke;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void setBorderStyle(Graphics paramGraphics, BorderStroke paramBorderStroke, double paramDouble, boolean paramBoolean) {
/* 1614 */     BorderWidths borderWidths = paramBorderStroke.getWidths();
/* 1615 */     BorderStrokeStyle borderStrokeStyle = paramBorderStroke.getTopStyle();
/* 1616 */     double d = borderWidths.isTopAsPercentage() ? (this.height * borderWidths.getTop()) : borderWidths.getTop();
/* 1617 */     Paint paint = getPlatformPaint(paramBorderStroke.getTopStroke());
/* 1618 */     if (borderStrokeStyle == null) {
/* 1619 */       borderStrokeStyle = paramBorderStroke.getLeftStyle();
/* 1620 */       d = borderWidths.isLeftAsPercentage() ? (this.width * borderWidths.getLeft()) : borderWidths.getLeft();
/* 1621 */       paint = getPlatformPaint(paramBorderStroke.getLeftStroke());
/* 1622 */       if (borderStrokeStyle == null) {
/* 1623 */         borderStrokeStyle = paramBorderStroke.getBottomStyle();
/* 1624 */         d = borderWidths.isBottomAsPercentage() ? (this.height * borderWidths.getBottom()) : borderWidths.getBottom();
/* 1625 */         paint = getPlatformPaint(paramBorderStroke.getBottomStroke());
/* 1626 */         if (borderStrokeStyle == null) {
/* 1627 */           borderStrokeStyle = paramBorderStroke.getRightStyle();
/* 1628 */           d = borderWidths.isRightAsPercentage() ? (this.width * borderWidths.getRight()) : borderWidths.getRight();
/* 1629 */           paint = getPlatformPaint(paramBorderStroke.getRightStroke());
/*      */         } 
/*      */       } 
/*      */     } 
/* 1633 */     if (borderStrokeStyle == null || borderStrokeStyle == BorderStrokeStyle.NONE) {
/*      */       return;
/*      */     }
/*      */     
/* 1637 */     paramGraphics.setStroke(createStroke(borderStrokeStyle, d, paramDouble, paramBoolean));
/* 1638 */     paramGraphics.setPaint(paint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doCorner(Path2D paramPath2D, CornerRadii paramCornerRadii, float paramFloat1, float paramFloat2, int paramInt, float paramFloat3, float paramFloat4, boolean paramBoolean) {
/*      */     float f1;
/*      */     float f2;
/*      */     float f3;
/*      */     float f4;
/*      */     float f5;
/*      */     float f6;
/* 1681 */     switch (paramInt & 0x3) {
/*      */       case 0:
/* 1683 */         f5 = (float)paramCornerRadii.getTopLeftHorizontalRadius();
/* 1684 */         f6 = (float)paramCornerRadii.getTopLeftVerticalRadius();
/*      */         
/* 1686 */         f1 = 0.0F; f2 = f6; f3 = f5; f4 = 0.0F;
/*      */         break;
/*      */       case 1:
/* 1689 */         f5 = (float)paramCornerRadii.getTopRightHorizontalRadius();
/* 1690 */         f6 = (float)paramCornerRadii.getTopRightVerticalRadius();
/*      */         
/* 1692 */         f1 = -f5; f2 = 0.0F; f3 = 0.0F; f4 = f6;
/*      */         break;
/*      */       case 2:
/* 1695 */         f5 = (float)paramCornerRadii.getBottomRightHorizontalRadius();
/* 1696 */         f6 = (float)paramCornerRadii.getBottomRightVerticalRadius();
/*      */         
/* 1698 */         f1 = 0.0F; f2 = -f6; f3 = -f5; f4 = 0.0F;
/*      */         break;
/*      */       case 3:
/* 1701 */         f5 = (float)paramCornerRadii.getBottomLeftHorizontalRadius();
/* 1702 */         f6 = (float)paramCornerRadii.getBottomLeftVerticalRadius();
/*      */         
/* 1704 */         f1 = f5; f2 = 0.0F; f3 = 0.0F; f4 = -f6; break;
/*      */       default:
/*      */         return;
/*      */     } 
/* 1708 */     if (f5 > 0.0F && f6 > 0.0F) {
/* 1709 */       paramPath2D.appendOvalQuadrant(paramFloat1 + f1, paramFloat2 + f2, paramFloat1, paramFloat2, paramFloat1 + f3, paramFloat2 + f4, paramFloat3, paramFloat4, 
/* 1710 */           paramBoolean ? 
/* 1711 */           Path2D.CornerPrefix.MOVE_THEN_CORNER : 
/* 1712 */           Path2D.CornerPrefix.LINE_THEN_CORNER);
/* 1713 */     } else if (paramBoolean) {
/* 1714 */       paramPath2D.moveTo(paramFloat1, paramFloat2);
/*      */     } else {
/* 1716 */       paramPath2D.lineTo(paramFloat1, paramFloat2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Path2D createPath(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, CornerRadii paramCornerRadii) {
/* 1725 */     float f1 = paramFloat1 - paramFloat6;
/* 1726 */     float f2 = paramFloat2 - paramFloat5;
/* 1727 */     Path2D path2D = new Path2D();
/* 1728 */     doCorner(path2D, paramCornerRadii, paramFloat4, paramFloat3, 0, 0.0F, 1.0F, true);
/* 1729 */     doCorner(path2D, paramCornerRadii, f1, paramFloat3, 1, 0.0F, 1.0F, false);
/* 1730 */     doCorner(path2D, paramCornerRadii, f1, f2, 2, 0.0F, 1.0F, false);
/* 1731 */     doCorner(path2D, paramCornerRadii, paramFloat4, f2, 3, 0.0F, 1.0F, false);
/* 1732 */     path2D.closePath();
/* 1733 */     return path2D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Path2D makeRoundedEdge(CornerRadii paramCornerRadii, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt) {
/* 1740 */     Path2D path2D = new Path2D();
/* 1741 */     doCorner(path2D, paramCornerRadii, paramFloat1, paramFloat2, paramInt, 0.5F, 1.0F, true);
/* 1742 */     doCorner(path2D, paramCornerRadii, paramFloat3, paramFloat4, paramInt + 1, 0.0F, 0.5F, false);
/* 1743 */     return path2D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Path2D[] createPaths(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, CornerRadii paramCornerRadii) {
/* 1753 */     float f1 = this.width - paramFloat4;
/* 1754 */     float f2 = this.height - paramFloat3;
/* 1755 */     return new Path2D[] {
/* 1756 */         makeRoundedEdge(paramCornerRadii, paramFloat2, paramFloat1, f1, paramFloat1, 0), 
/* 1757 */         makeRoundedEdge(paramCornerRadii, f1, paramFloat1, f1, f2, 1), 
/* 1758 */         makeRoundedEdge(paramCornerRadii, f1, f2, paramFloat2, f2, 2), 
/* 1759 */         makeRoundedEdge(paramCornerRadii, paramFloat2, f2, paramFloat2, paramFloat1, 3)
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Shape resizeShape(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 1772 */     RectBounds rectBounds = this.shape.getBounds();
/* 1773 */     if (this.scaleShape) {
/*      */ 
/*      */       
/* 1776 */       SCRATCH_AFFINE.setToIdentity();
/* 1777 */       SCRATCH_AFFINE.translate(paramFloat4, paramFloat1);
/*      */ 
/*      */       
/* 1780 */       float f1 = this.width - paramFloat4 - paramFloat2;
/* 1781 */       float f2 = this.height - paramFloat1 - paramFloat3;
/* 1782 */       SCRATCH_AFFINE.scale((f1 / rectBounds.getWidth()), (f2 / rectBounds.getHeight()));
/*      */ 
/*      */       
/* 1785 */       if (this.centerShape) {
/* 1786 */         SCRATCH_AFFINE.translate(-rectBounds.getMinX(), -rectBounds.getMinY());
/*      */       }
/* 1788 */       return SCRATCH_AFFINE.createTransformedShape(this.shape);
/* 1789 */     }  if (this.centerShape) {
/*      */ 
/*      */ 
/*      */       
/* 1793 */       float f1 = rectBounds.getWidth();
/* 1794 */       float f2 = rectBounds.getHeight();
/* 1795 */       float f3 = f1 - paramFloat4 - paramFloat2;
/* 1796 */       float f4 = f2 - paramFloat1 - paramFloat3;
/* 1797 */       SCRATCH_AFFINE.setToIdentity();
/* 1798 */       SCRATCH_AFFINE.translate((paramFloat4 + (this.width - f1) / 2.0F - rectBounds.getMinX()), (paramFloat1 + (this.height - f2) / 2.0F - rectBounds
/* 1799 */           .getMinY()));
/* 1800 */       if (f4 != f2 || f3 != f1) {
/* 1801 */         SCRATCH_AFFINE.translate(rectBounds.getMinX(), rectBounds.getMinY());
/* 1802 */         SCRATCH_AFFINE.scale((f3 / f1), (f4 / f2));
/* 1803 */         SCRATCH_AFFINE.translate(-rectBounds.getMinX(), -rectBounds.getMinY());
/*      */       } 
/* 1805 */       return SCRATCH_AFFINE.createTransformedShape(this.shape);
/* 1806 */     }  if (paramFloat1 != 0.0F || paramFloat2 != 0.0F || paramFloat3 != 0.0F || paramFloat4 != 0.0F) {
/*      */ 
/*      */       
/* 1809 */       float f1 = rectBounds.getWidth() - paramFloat4 - paramFloat2;
/* 1810 */       float f2 = rectBounds.getHeight() - paramFloat1 - paramFloat3;
/* 1811 */       SCRATCH_AFFINE.setToIdentity();
/* 1812 */       SCRATCH_AFFINE.translate(paramFloat4, paramFloat1);
/* 1813 */       SCRATCH_AFFINE.translate(rectBounds.getMinX(), rectBounds.getMinY());
/* 1814 */       SCRATCH_AFFINE.scale((f1 / rectBounds.getWidth()), (f2 / rectBounds.getHeight()));
/* 1815 */       SCRATCH_AFFINE.translate(-rectBounds.getMinX(), -rectBounds.getMinY());
/* 1816 */       return SCRATCH_AFFINE.createTransformedShape(this.shape);
/*      */     } 
/*      */     
/* 1819 */     return this.shape;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void paintTiles(Graphics paramGraphics, Image paramImage, BorderRepeat paramBorderRepeat1, BorderRepeat paramBorderRepeat2, Side paramSide1, Side paramSide2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/* 1828 */     BackgroundRepeat backgroundRepeat1 = null;
/* 1829 */     BackgroundRepeat backgroundRepeat2 = null;
/*      */     
/* 1831 */     switch (paramBorderRepeat1) { case REPEAT:
/* 1832 */         backgroundRepeat1 = BackgroundRepeat.REPEAT; break;
/* 1833 */       case STRETCH: backgroundRepeat1 = BackgroundRepeat.NO_REPEAT; break;
/* 1834 */       case ROUND: backgroundRepeat1 = BackgroundRepeat.ROUND; break;
/* 1835 */       case SPACE: backgroundRepeat1 = BackgroundRepeat.SPACE;
/*      */         break; }
/*      */     
/* 1838 */     switch (paramBorderRepeat2) { case REPEAT:
/* 1839 */         backgroundRepeat2 = BackgroundRepeat.REPEAT; break;
/* 1840 */       case STRETCH: backgroundRepeat2 = BackgroundRepeat.NO_REPEAT; break;
/* 1841 */       case ROUND: backgroundRepeat2 = BackgroundRepeat.ROUND; break;
/* 1842 */       case SPACE: backgroundRepeat2 = BackgroundRepeat.SPACE;
/*      */         break; }
/*      */     
/* 1845 */     paintTiles(paramGraphics, paramImage, backgroundRepeat1, backgroundRepeat2, paramSide1, paramSide2, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void paintTiles(Graphics paramGraphics, Image paramImage, BackgroundRepeat paramBackgroundRepeat1, BackgroundRepeat paramBackgroundRepeat2, Side paramSide1, Side paramSide2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/* 1885 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F || paramInt3 <= 0 || paramInt4 <= 0) {
/*      */       return;
/*      */     }
/* 1888 */     assert paramInt1 >= 0 && paramInt2 >= 0 && paramInt3 > 0 && paramInt4 > 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1895 */     if (paramFloat5 == 0.0F && paramFloat6 == 0.0F && paramBackgroundRepeat1 == BackgroundRepeat.REPEAT && paramBackgroundRepeat2 == BackgroundRepeat.REPEAT) {
/* 1896 */       if (paramInt1 != 0 || paramInt2 != 0 || paramInt3 != paramImage.getWidth() || paramInt4 != paramImage.getHeight()) {
/* 1897 */         paramImage = paramImage.createSubImage(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */       }
/* 1899 */       paramGraphics.setPaint(new ImagePattern(paramImage, 0.0F, 0.0F, paramFloat7, paramFloat8, false, false));
/* 1900 */       paramGraphics.fillRect(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */     } else {
/*      */       byte b1, b2;
/*      */       
/*      */       float f1, f2;
/* 1905 */       if (paramBackgroundRepeat1 == BackgroundRepeat.SPACE && paramFloat3 < paramFloat7 * 2.0F) {
/* 1906 */         paramBackgroundRepeat1 = BackgroundRepeat.NO_REPEAT;
/*      */       }
/*      */       
/* 1909 */       if (paramBackgroundRepeat2 == BackgroundRepeat.SPACE && paramFloat4 < paramFloat8 * 2.0F) {
/* 1910 */         paramBackgroundRepeat2 = BackgroundRepeat.NO_REPEAT;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1921 */       if (paramBackgroundRepeat1 == BackgroundRepeat.REPEAT) {
/*      */ 
/*      */ 
/*      */         
/* 1925 */         float f = 0.0F;
/* 1926 */         if (paramFloat5 != 0.0F) {
/* 1927 */           float f6 = paramFloat5 % paramFloat7;
/* 1928 */           paramFloat5 = (f6 == 0.0F) ? 0.0F : ((paramFloat5 < 0.0F) ? f6 : (f6 - paramFloat7));
/* 1929 */           f = paramFloat5;
/*      */         } 
/* 1931 */         b1 = (int)Math.max(1.0D, Math.ceil(((paramFloat3 - f) / paramFloat7)));
/* 1932 */         f1 = (paramSide1 == Side.RIGHT) ? -paramFloat7 : paramFloat7;
/* 1933 */       } else if (paramBackgroundRepeat1 == BackgroundRepeat.SPACE) {
/* 1934 */         paramFloat5 = 0.0F;
/* 1935 */         b1 = (int)(paramFloat3 / paramFloat7);
/* 1936 */         float f = paramFloat3 % paramFloat7;
/* 1937 */         f1 = paramFloat7 + f / (b1 - 1);
/* 1938 */       } else if (paramBackgroundRepeat1 == BackgroundRepeat.ROUND) {
/* 1939 */         paramFloat5 = 0.0F;
/* 1940 */         b1 = (int)(paramFloat3 / paramFloat7);
/* 1941 */         paramFloat7 = paramFloat3 / (int)(paramFloat3 / paramFloat7);
/* 1942 */         f1 = paramFloat7;
/*      */       } else {
/* 1944 */         b1 = 1;
/* 1945 */         f1 = (paramSide1 == Side.RIGHT) ? -paramFloat7 : paramFloat7;
/*      */       } 
/*      */       
/* 1948 */       if (paramBackgroundRepeat2 == BackgroundRepeat.REPEAT) {
/* 1949 */         float f = 0.0F;
/* 1950 */         if (paramFloat6 != 0.0F) {
/* 1951 */           float f6 = paramFloat6 % paramFloat8;
/* 1952 */           paramFloat6 = (f6 == 0.0F) ? 0.0F : ((paramFloat6 < 0.0F) ? f6 : (f6 - paramFloat8));
/* 1953 */           f = paramFloat6;
/*      */         } 
/* 1955 */         b2 = (int)Math.max(1.0D, Math.ceil(((paramFloat4 - f) / paramFloat8)));
/* 1956 */         f2 = (paramSide2 == Side.BOTTOM) ? -paramFloat8 : paramFloat8;
/* 1957 */       } else if (paramBackgroundRepeat2 == BackgroundRepeat.SPACE) {
/* 1958 */         paramFloat6 = 0.0F;
/* 1959 */         b2 = (int)(paramFloat4 / paramFloat8);
/* 1960 */         float f = paramFloat4 % paramFloat8;
/* 1961 */         f2 = paramFloat8 + f / (b2 - 1);
/* 1962 */       } else if (paramBackgroundRepeat2 == BackgroundRepeat.ROUND) {
/* 1963 */         paramFloat6 = 0.0F;
/* 1964 */         b2 = (int)(paramFloat4 / paramFloat8);
/* 1965 */         paramFloat8 = paramFloat4 / (int)(paramFloat4 / paramFloat8);
/* 1966 */         f2 = paramFloat8;
/*      */       } else {
/* 1968 */         b2 = 1;
/* 1969 */         f2 = (paramSide2 == Side.BOTTOM) ? -paramFloat8 : paramFloat8;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1974 */       Texture texture = paramGraphics.getResourceFactory().getCachedTexture(paramImage, Texture.WrapMode.CLAMP_TO_EDGE);
/* 1975 */       int i = paramInt1 + paramInt3;
/* 1976 */       int j = paramInt2 + paramInt4;
/* 1977 */       float f3 = paramFloat1 + paramFloat3;
/* 1978 */       float f4 = paramFloat2 + paramFloat4;
/*      */       
/* 1980 */       float f5 = paramFloat2 + paramFloat6;
/* 1981 */       for (byte b3 = 0; b3 < b2; b3++) {
/* 1982 */         float f6 = f5 + paramFloat8;
/* 1983 */         float f7 = paramFloat1 + paramFloat5;
/* 1984 */         for (byte b = 0; b < b1; b++) {
/* 1985 */           float f8 = f7 + paramFloat7;
/*      */ 
/*      */           
/* 1988 */           boolean bool = false;
/* 1989 */           float f9 = (f7 < paramFloat1) ? paramFloat1 : f7;
/* 1990 */           float f10 = (f5 < paramFloat2) ? paramFloat2 : f5;
/* 1991 */           if (f9 > f3 || f10 > f4) bool = true;
/*      */           
/* 1993 */           float f11 = (f8 > f3) ? f3 : f8;
/* 1994 */           float f12 = (f6 > f4) ? f4 : f6;
/* 1995 */           if (f11 < paramFloat1 || f12 < paramFloat2) bool = true;
/*      */           
/* 1997 */           if (!bool) {
/*      */ 
/*      */             
/* 2000 */             float f13 = (f7 < paramFloat1) ? (paramInt1 + paramInt3 * -paramFloat5 / paramFloat7) : paramInt1;
/* 2001 */             float f14 = (f5 < paramFloat2) ? (paramInt2 + paramInt4 * -paramFloat6 / paramFloat8) : paramInt2;
/* 2002 */             float f15 = (f8 > f3) ? (i - paramInt3 * (f8 - f3) / paramFloat7) : i;
/* 2003 */             float f16 = (f6 > f4) ? (j - paramInt4 * (f6 - f4) / paramFloat8) : j;
/*      */             
/* 2005 */             paramGraphics.drawTexture(texture, f9, f10, f11, f12, f13, f14, f15, f16);
/*      */           } 
/* 2007 */           f7 += f1;
/*      */         } 
/* 2009 */         f5 += f2;
/*      */       } 
/* 2011 */       texture.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   final Border getBorder() {
/* 2016 */     return this.border;
/*      */   }
/*      */   
/*      */   final Background getBackground() {
/* 2020 */     return this.background;
/*      */   }
/*      */   
/*      */   final float getWidth() {
/* 2024 */     return this.width;
/*      */   }
/*      */   
/*      */   final float getHeight() {
/* 2028 */     return this.height;
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGRegion.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */