/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.Affine3D;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.paint.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NGLightBase
/*     */   extends NGNode
/*     */ {
/*  39 */   private Color color = Color.WHITE;
/*     */   
/*     */   private boolean lightOn = true;
/*     */   
/*     */   private Affine3D worldTransform;
/*     */   
/*     */   Object[] scopedNodes;
/*     */   
/*     */   public void setTransformMatrix(BaseTransform paramBaseTransform) {
/*  48 */     super.setTransformMatrix(paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doRender(Graphics paramGraphics) {}
/*     */   
/*     */   protected void renderContent(Graphics paramGraphics) {}
/*     */   
/*     */   protected boolean hasOverlappingContents() {
/*  57 */     return false;
/*     */   }
/*     */   
/*     */   public Color getColor() {
/*  61 */     return this.color;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColor(Object paramObject) {
/*  67 */     if (!this.color.equals(paramObject)) {
/*  68 */       this.color = (Color)paramObject;
/*  69 */       visualsChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isLightOn() {
/*  74 */     return this.lightOn;
/*     */   }
/*     */   
/*     */   public void setLightOn(boolean paramBoolean) {
/*  78 */     if (this.lightOn != paramBoolean) {
/*  79 */       visualsChanged();
/*  80 */       this.lightOn = paramBoolean;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Affine3D getWorldTransform() {
/*  85 */     return this.worldTransform;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorldTransform(Affine3D paramAffine3D) {
/*  97 */     this.worldTransform = paramAffine3D;
/*     */   }
/*     */   protected NGLightBase() {
/* 100 */     this.scopedNodes = null;
/*     */   }
/*     */   public void setScope(Object[] paramArrayOfObject) {
/* 103 */     if (this.scopedNodes != paramArrayOfObject) {
/* 104 */       this.scopedNodes = paramArrayOfObject;
/* 105 */       visualsChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   final boolean affects(NGShape3D paramNGShape3D) {
/* 110 */     if (!this.lightOn)
/* 111 */       return false; 
/* 112 */     if (this.scopedNodes == null) {
/* 113 */       return true;
/*     */     }
/* 115 */     for (byte b = 0; b < this.scopedNodes.length; b++) {
/* 116 */       Object object = this.scopedNodes[b];
/* 117 */       if (object instanceof NGGroup) {
/* 118 */         NGNode nGNode = paramNGShape3D.getParent();
/* 119 */         while (nGNode != null) {
/* 120 */           if (object == nGNode) {
/* 121 */             return true;
/*     */           }
/* 123 */           nGNode = nGNode.getParent();
/*     */         } 
/* 125 */       } else if (object == paramNGShape3D) {
/* 126 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 130 */     return false;
/*     */   }
/*     */   
/*     */   public void release() {}
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGLightBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */