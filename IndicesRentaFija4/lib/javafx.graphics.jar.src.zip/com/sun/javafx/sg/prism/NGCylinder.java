/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGCylinder
/*    */   extends NGShape3D
/*    */ {
/*    */   public void updateMesh(NGTriangleMesh paramNGTriangleMesh) {
/* 34 */     this.mesh = paramNGTriangleMesh;
/* 35 */     invalidate();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGCylinder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */