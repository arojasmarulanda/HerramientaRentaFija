/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.font.FontStrike;
/*     */ import com.sun.javafx.font.Metrics;
/*     */ import com.sun.javafx.font.PGFont;
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.RoundRectangle2D;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.scene.text.GlyphList;
/*     */ import com.sun.javafx.text.TextRun;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.paint.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NGText
/*     */   extends NGShape
/*     */ {
/*  46 */   static final BaseTransform IDENT = BaseTransform.IDENTITY_TRANSFORM; private GlyphList[] runs;
/*     */   private float layoutX;
/*     */   private float layoutY;
/*     */   private PGFont font;
/*     */   private int fontSmoothingType;
/*     */   
/*     */   public void setGlyphs(Object[] paramArrayOfObject) {
/*  53 */     this.runs = (GlyphList[])paramArrayOfObject;
/*  54 */     geometryChanged();
/*     */   }
/*     */   private boolean underline; private boolean strikethrough; private Object selectionPaint; private int selectionStart; private int selectionEnd;
/*     */   
/*     */   public void setLayoutLocation(float paramFloat1, float paramFloat2) {
/*  59 */     this.layoutX = paramFloat1;
/*  60 */     this.layoutY = paramFloat2;
/*  61 */     geometryChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFont(Object paramObject) {
/*  66 */     if (paramObject != null && paramObject.equals(this.font)) {
/*     */       return;
/*     */     }
/*  69 */     this.font = (PGFont)paramObject;
/*  70 */     this.fontStrike = null;
/*  71 */     this.identityStrike = null;
/*  72 */     geometryChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFontSmoothingType(int paramInt) {
/*  77 */     this.fontSmoothingType = paramInt;
/*  78 */     geometryChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUnderline(boolean paramBoolean) {
/*  83 */     this.underline = paramBoolean;
/*  84 */     geometryChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStrikethrough(boolean paramBoolean) {
/*  89 */     this.strikethrough = paramBoolean;
/*  90 */     geometryChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelection(int paramInt1, int paramInt2, Object paramObject) {
/*  97 */     this.selectionPaint = paramObject;
/*  98 */     this.selectionStart = paramInt1;
/*  99 */     this.selectionEnd = paramInt2;
/* 100 */     geometryChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseBounds computePadding(BaseBounds paramBaseBounds) {
/* 109 */     float f = (this.fontSmoothingType == 1) ? 2.0F : 1.0F;
/* 110 */     return paramBaseBounds.deriveWithNewBounds(paramBaseBounds.getMinX() - f, paramBaseBounds
/* 111 */         .getMinY() - f, paramBaseBounds
/* 112 */         .getMinZ(), paramBaseBounds
/* 113 */         .getMaxX() + f, paramBaseBounds
/* 114 */         .getMaxY() + f, paramBaseBounds
/* 115 */         .getMaxZ());
/*     */   }
/*     */   
/* 118 */   private static double EPSILON = 0.01D;
/* 119 */   private FontStrike fontStrike = null;
/* 120 */   private FontStrike identityStrike = null;
/* 121 */   private double[] strikeMat = new double[4];
/*     */   private FontStrike getStrike(BaseTransform paramBaseTransform) {
/* 123 */     int i = this.fontSmoothingType;
/* 124 */     if (getMode() == NGShape.Mode.STROKE_FILL)
/*     */     {
/*     */       
/* 127 */       i = 0;
/*     */     }
/* 129 */     if (paramBaseTransform.isIdentity()) {
/* 130 */       if (this.identityStrike == null || i != this.identityStrike
/* 131 */         .getAAMode()) {
/* 132 */         this.identityStrike = this.font.getStrike(IDENT, i);
/*     */       }
/* 134 */       return this.identityStrike;
/*     */     } 
/*     */     
/* 137 */     if (this.fontStrike == null || this.fontStrike
/* 138 */       .getSize() != this.font.getSize() || (paramBaseTransform
/* 139 */       .getMxy() == 0.0D && this.strikeMat[1] != 0.0D) || (paramBaseTransform
/* 140 */       .getMyx() == 0.0D && this.strikeMat[2] != 0.0D) || 
/* 141 */       Math.abs(this.strikeMat[0] - paramBaseTransform.getMxx()) > EPSILON || 
/* 142 */       Math.abs(this.strikeMat[1] - paramBaseTransform.getMxy()) > EPSILON || 
/* 143 */       Math.abs(this.strikeMat[2] - paramBaseTransform.getMyx()) > EPSILON || 
/* 144 */       Math.abs(this.strikeMat[3] - paramBaseTransform.getMyy()) > EPSILON || i != this.fontStrike
/* 145 */       .getAAMode()) {
/*     */       
/* 147 */       this.fontStrike = this.font.getStrike(paramBaseTransform, i);
/* 148 */       this.strikeMat[0] = paramBaseTransform.getMxx();
/* 149 */       this.strikeMat[1] = paramBaseTransform.getMxy();
/* 150 */       this.strikeMat[2] = paramBaseTransform.getMyx();
/* 151 */       this.strikeMat[3] = paramBaseTransform.getMyy();
/*     */     } 
/* 153 */     return this.fontStrike;
/*     */   }
/*     */   
/*     */   public Shape getShape() {
/* 157 */     if (this.runs == null) {
/* 158 */       return new Path2D();
/*     */     }
/* 160 */     FontStrike fontStrike = getStrike(IDENT);
/* 161 */     Path2D path2D = new Path2D();
/* 162 */     for (byte b = 0; b < this.runs.length; b++) {
/* 163 */       GlyphList glyphList = this.runs[b];
/* 164 */       Point2D point2D = glyphList.getLocation();
/* 165 */       float f1 = point2D.x - this.layoutX;
/* 166 */       float f2 = point2D.y - this.layoutY;
/* 167 */       BaseTransform baseTransform = BaseTransform.getTranslateInstance(f1, f2);
/* 168 */       path2D.append(fontStrike.getOutline(glyphList, baseTransform), false);
/* 169 */       Metrics metrics = null;
/* 170 */       if (this.underline) {
/* 171 */         metrics = fontStrike.getMetrics();
/* 172 */         RoundRectangle2D roundRectangle2D = new RoundRectangle2D();
/* 173 */         roundRectangle2D.x = f1;
/* 174 */         roundRectangle2D.y = f2 + metrics.getUnderLineOffset();
/* 175 */         roundRectangle2D.width = glyphList.getWidth();
/* 176 */         roundRectangle2D.height = metrics.getUnderLineThickness();
/* 177 */         path2D.append(roundRectangle2D, false);
/*     */       } 
/* 179 */       if (this.strikethrough) {
/* 180 */         if (metrics == null) {
/* 181 */           metrics = fontStrike.getMetrics();
/*     */         }
/* 183 */         RoundRectangle2D roundRectangle2D = new RoundRectangle2D();
/* 184 */         roundRectangle2D.x = f1;
/* 185 */         roundRectangle2D.y = f2 + metrics.getStrikethroughOffset();
/* 186 */         roundRectangle2D.width = glyphList.getWidth();
/* 187 */         roundRectangle2D.height = metrics.getStrikethroughThickness();
/* 188 */         path2D.append(roundRectangle2D, false);
/*     */       } 
/*     */     } 
/* 191 */     return path2D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean drawingEffect = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderEffect(Graphics paramGraphics) {
/* 217 */     if (!paramGraphics.getTransformNoClone().isTranslateOrIdentity()) {
/* 218 */       this.drawingEffect = true;
/*     */     }
/*     */     try {
/* 221 */       super.renderEffect(paramGraphics);
/*     */     } finally {
/* 223 */       this.drawingEffect = false;
/*     */     } 
/*     */   }
/*     */   
/* 227 */   private static int FILL = 2;
/* 228 */   private static int SHAPE_FILL = 4;
/* 229 */   private static int TEXT = 8;
/* 230 */   private static int DECORATION = 16;
/*     */   protected void renderContent2D(Graphics paramGraphics, boolean paramBoolean) {
/* 232 */     if (this.mode == NGShape.Mode.EMPTY)
/* 233 */       return;  if (this.runs == null || this.runs.length == 0)
/*     */       return; 
/* 235 */     BaseTransform baseTransform = paramGraphics.getTransformNoClone();
/* 236 */     FontStrike fontStrike = getStrike(baseTransform);
/*     */     
/* 238 */     if (fontStrike.getAAMode() == 1 || (this.fillPaint != null && this.fillPaint
/* 239 */       .isProportional()) || (this.drawPaint != null && this.drawPaint
/* 240 */       .isProportional())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 250 */       BaseBounds baseBounds1 = getContentBounds(new RectBounds(), IDENT);
/* 251 */       paramGraphics.setNodeBounds((RectBounds)baseBounds1);
/*     */     } 
/*     */     
/* 254 */     Color color = null;
/* 255 */     if (this.selectionStart != this.selectionEnd && this.selectionPaint instanceof Color) {
/* 256 */       color = (Color)this.selectionPaint;
/*     */     }
/*     */     
/* 259 */     BaseBounds baseBounds = null;
/* 260 */     if (getClipNode() != null)
/*     */     {
/* 262 */       baseBounds = getClippedBounds(new RectBounds(), IDENT);
/*     */     }
/*     */ 
/*     */     
/* 266 */     if (this.mode != NGShape.Mode.STROKE) {
/* 267 */       paramGraphics.setPaint(this.fillPaint);
/* 268 */       int i = TEXT;
/* 269 */       i |= (fontStrike.drawAsShapes() || this.drawingEffect) ? SHAPE_FILL : FILL;
/* 270 */       renderText(paramGraphics, fontStrike, baseBounds, color, i);
/*     */ 
/*     */ 
/*     */       
/* 274 */       if (this.underline || this.strikethrough) {
/* 275 */         i = DECORATION | SHAPE_FILL;
/* 276 */         renderText(paramGraphics, fontStrike, baseBounds, color, i);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 281 */     if (this.mode != NGShape.Mode.FILL) {
/* 282 */       paramGraphics.setPaint(this.drawPaint);
/* 283 */       paramGraphics.setStroke(this.drawStroke);
/* 284 */       int i = TEXT;
/* 285 */       if (this.underline || this.strikethrough) {
/* 286 */         i |= DECORATION;
/*     */       }
/* 288 */       renderText(paramGraphics, fontStrike, baseBounds, color, i);
/*     */     } 
/* 290 */     paramGraphics.setNodeBounds(null);
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderText(Graphics paramGraphics, FontStrike paramFontStrike, BaseBounds paramBaseBounds, Color paramColor, int paramInt) {
/* 295 */     for (byte b = 0; b < this.runs.length; b++) {
/* 296 */       TextRun textRun = (TextRun)this.runs[b];
/* 297 */       RectBounds rectBounds = textRun.getLineBounds();
/* 298 */       Point2D point2D = textRun.getLocation();
/* 299 */       float f1 = point2D.x - this.layoutX;
/* 300 */       float f2 = point2D.y - this.layoutY;
/* 301 */       if (paramBaseBounds != null) {
/* 302 */         if (f2 > paramBaseBounds.getMaxY())
/* 303 */           break;  if (f2 + rectBounds.getHeight() < paramBaseBounds.getMinY() || 
/* 304 */           f1 > paramBaseBounds.getMaxX() || 
/* 305 */           f1 + textRun.getWidth() < paramBaseBounds.getMinX())
/*     */           continue; 
/* 307 */       }  f2 -= rectBounds.getMinY();
/*     */       
/* 309 */       if ((paramInt & TEXT) != 0 && textRun.getGlyphCount() > 0) {
/* 310 */         if ((paramInt & FILL) != 0) {
/* 311 */           int i = textRun.getStart();
/* 312 */           paramGraphics.drawString(textRun, paramFontStrike, f1, f2, paramColor, this.selectionStart - i, this.selectionEnd - i);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 317 */           BaseTransform baseTransform = BaseTransform.getTranslateInstance(f1, f2);
/* 318 */           if ((paramInt & SHAPE_FILL) != 0) {
/* 319 */             paramGraphics.fill(paramFontStrike.getOutline(textRun, baseTransform));
/*     */           } else {
/* 321 */             paramGraphics.draw(paramFontStrike.getOutline(textRun, baseTransform));
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 326 */       if ((paramInt & DECORATION) != 0) {
/* 327 */         Metrics metrics = paramFontStrike.getMetrics();
/* 328 */         if (this.underline) {
/* 329 */           float f3 = f2 + metrics.getUnderLineOffset();
/* 330 */           float f4 = metrics.getUnderLineThickness();
/* 331 */           if ((paramInt & SHAPE_FILL) != 0) {
/* 332 */             if (f4 <= 1.0F && paramGraphics.getTransformNoClone().isTranslateOrIdentity()) {
/* 333 */               float f = (float)paramGraphics.getTransformNoClone().getMyt();
/* 334 */               f3 = Math.round(f3 + f) - f;
/*     */             } 
/* 336 */             paramGraphics.fillRect(f1, f3, textRun.getWidth(), f4);
/*     */           } else {
/* 338 */             paramGraphics.drawRect(f1, f3, textRun.getWidth(), f4);
/*     */           } 
/*     */         } 
/* 341 */         if (this.strikethrough) {
/* 342 */           float f3 = f2 + metrics.getStrikethroughOffset();
/* 343 */           float f4 = metrics.getStrikethroughThickness();
/* 344 */           if ((paramInt & SHAPE_FILL) != 0) {
/* 345 */             if (f4 <= 1.0F && paramGraphics.getTransformNoClone().isTranslateOrIdentity()) {
/* 346 */               float f = (float)paramGraphics.getTransformNoClone().getMyt();
/* 347 */               f3 = Math.round(f3 + f) - f;
/*     */             } 
/* 349 */             paramGraphics.fillRect(f1, f3, textRun.getWidth(), f4);
/*     */           } else {
/* 351 */             paramGraphics.drawRect(f1, f3, textRun.getWidth(), f4);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       continue;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGText.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */