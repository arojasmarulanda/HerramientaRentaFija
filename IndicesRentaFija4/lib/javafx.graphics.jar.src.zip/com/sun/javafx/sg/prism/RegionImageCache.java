/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.logging.PulseLogger;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.RTTexture;
/*     */ import com.sun.prism.ResourceFactory;
/*     */ import com.sun.prism.Texture;
/*     */ import com.sun.prism.impl.packrect.RectanglePacker;
/*     */ import java.util.HashMap;
/*     */ import javafx.scene.layout.Background;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RegionImageCache
/*     */ {
/*     */   private static final int MAX_SIZE = 90000;
/*     */   private static final int WIDTH = 1024;
/*     */   private static final int HEIGHT = 1024;
/*     */   private HashMap<Integer, CachedImage> imageMap;
/*     */   private RTTexture backingStore;
/*     */   private RectanglePacker hPacker;
/*     */   private RectanglePacker vPacker;
/*     */   
/*     */   RegionImageCache(ResourceFactory paramResourceFactory) {
/*     */     Texture.WrapMode wrapMode;
/*     */     byte b;
/*  60 */     this.imageMap = new HashMap<>();
/*     */ 
/*     */     
/*  63 */     if (paramResourceFactory.isWrapModeSupported(Texture.WrapMode.CLAMP_TO_ZERO)) {
/*  64 */       wrapMode = Texture.WrapMode.CLAMP_TO_ZERO;
/*  65 */       b = 0;
/*     */     } else {
/*  67 */       wrapMode = Texture.WrapMode.CLAMP_NOT_NEEDED;
/*  68 */       b = 1;
/*     */     } 
/*  70 */     this.backingStore = paramResourceFactory.createRTTexture(2048, 1024, wrapMode);
/*  71 */     this.backingStore.contentsUseful();
/*  72 */     this.backingStore.makePermanent();
/*  73 */     paramResourceFactory.setRegionTexture(this.backingStore);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     this.hPacker = new RectanglePacker(this.backingStore, b, b, 1024 - b, 1024 - b, false);
/*  82 */     this.vPacker = new RectanglePacker(this.backingStore, 1024, b, 1024, 1024 - b, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isImageCachable(int paramInt1, int paramInt2) {
/*  93 */     return (0 < paramInt1 && paramInt1 < 1024 && 0 < paramInt2 && paramInt2 < 1024 && paramInt1 * paramInt2 < 90000);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   RTTexture getBackingStore() {
/*  99 */     return this.backingStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean getImageLocation(Integer paramInteger, Rectangle paramRectangle, Background paramBackground, Shape paramShape, Graphics paramGraphics) {
/* 119 */     CachedImage cachedImage = this.imageMap.get(paramInteger);
/* 120 */     if (cachedImage != null) {
/* 121 */       if (cachedImage.equals(paramRectangle.width, paramRectangle.height, paramBackground, paramShape)) {
/* 122 */         paramRectangle.x = cachedImage.x;
/* 123 */         paramRectangle.y = cachedImage.y;
/* 124 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 128 */       paramRectangle.width = paramRectangle.height = -1;
/* 129 */       return false;
/*     */     } 
/* 131 */     boolean bool = (paramRectangle.height > 64) ? true : false;
/* 132 */     RectanglePacker rectanglePacker = bool ? this.vPacker : this.hPacker;
/*     */     
/* 134 */     if (!rectanglePacker.add(paramRectangle)) {
/* 135 */       paramGraphics.sync();
/*     */       
/* 137 */       this.vPacker.clear();
/* 138 */       this.hPacker.clear();
/* 139 */       this.imageMap.clear();
/* 140 */       rectanglePacker.add(paramRectangle);
/* 141 */       this.backingStore.createGraphics().clear();
/* 142 */       if (PulseLogger.PULSE_LOGGING_ENABLED) {
/* 143 */         PulseLogger.incrementCounter("Region image cache flushed");
/*     */       }
/*     */     } 
/* 146 */     this.imageMap.put(paramInteger, new CachedImage(paramRectangle, paramBackground, paramShape));
/* 147 */     return true;
/*     */   }
/*     */   
/*     */   static class CachedImage {
/*     */     Background background;
/*     */     Shape shape;
/*     */     int x;
/*     */     
/*     */     CachedImage(Rectangle param1Rectangle, Background param1Background, Shape param1Shape) {
/* 156 */       this.x = param1Rectangle.x;
/* 157 */       this.y = param1Rectangle.y;
/* 158 */       this.width = param1Rectangle.width;
/* 159 */       this.height = param1Rectangle.height;
/* 160 */       this.background = param1Background;
/* 161 */       this.shape = param1Shape;
/*     */     }
/*     */     int y; int width; int height;
/*     */     public boolean equals(int param1Int1, int param1Int2, Background param1Background, Shape param1Shape) {
/* 165 */       if (this.width == param1Int1 && this.height == param1Int2 && ((this.background == null) ? (param1Background == null) : this.background
/*     */         
/* 167 */         .equals(param1Background))) if ((this.shape == null) ? (param1Shape == null) : this.shape
/* 168 */           .equals(param1Shape)); 
/*     */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\RegionImageCache.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */