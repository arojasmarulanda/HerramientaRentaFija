/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.DirtyRegionContainer;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.javafx.geom.transform.Affine2D;
/*     */ import com.sun.javafx.geom.transform.Affine3D;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.geom.transform.GeneralTransform3D;
/*     */ import com.sun.javafx.logging.PulseLogger;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.RTTexture;
/*     */ import com.sun.prism.Texture;
/*     */ import com.sun.scenario.effect.Effect;
/*     */ import com.sun.scenario.effect.FilterContext;
/*     */ import com.sun.scenario.effect.Filterable;
/*     */ import com.sun.scenario.effect.ImageData;
/*     */ import com.sun.scenario.effect.impl.prism.PrDrawable;
/*     */ import com.sun.scenario.effect.impl.prism.PrFilterContext;
/*     */ import java.util.List;
/*     */ import javafx.geometry.Insets;
/*     */ import javafx.scene.CacheHint;
/*     */ import javafx.scene.layout.Background;
/*     */ import javafx.scene.layout.BackgroundFill;
/*     */ import javafx.scene.paint.Paint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheFilter
/*     */ {
/*     */   private enum ScrollCacheState
/*     */   {
/*  82 */     CHECKING_PRECONDITIONS,
/*  83 */     ENABLED,
/*  84 */     DISABLED;
/*     */   }
/*     */ 
/*     */   
/*  88 */   private static final Rectangle TEMP_RECT = new Rectangle();
/*  89 */   private static final DirtyRegionContainer TEMP_CONTAINER = new DirtyRegionContainer(1);
/*  90 */   private static final Affine3D TEMP_CACHEFILTER_TRANSFORM = new Affine3D();
/*  91 */   private static final RectBounds TEMP_BOUNDS = new RectBounds();
/*     */   
/*     */   private static final double EPSILON = 1.0E-7D;
/*     */   
/*     */   private RTTexture tempTexture;
/*     */   private double lastXDelta;
/*     */   private double lastYDelta;
/*  98 */   private ScrollCacheState scrollCacheState = ScrollCacheState.CHECKING_PRECONDITIONS;
/*     */   
/*     */   private ImageData cachedImageData;
/* 101 */   private Rectangle cacheBounds = new Rectangle();
/*     */   
/* 103 */   private final Affine2D cachedXform = new Affine2D();
/*     */   
/*     */   private double cachedScaleX;
/*     */   
/*     */   private double cachedScaleY;
/*     */   
/*     */   private double cachedRotate;
/*     */   
/*     */   private double cachedX;
/*     */   
/*     */   private double cachedY;
/*     */   private NGNode node;
/* 115 */   private final Affine2D screenXform = new Affine2D();
/*     */ 
/*     */   
/*     */   private boolean scaleHint;
/*     */ 
/*     */   
/*     */   private boolean rotateHint;
/*     */ 
/*     */   
/*     */   private CacheHint cacheHint;
/*     */ 
/*     */   
/*     */   private boolean wasUnsupported = false;
/*     */ 
/*     */   
/*     */   private Rectangle computeDirtyRegionForTranslate() {
/* 131 */     if (this.lastXDelta != 0.0D) {
/* 132 */       if (this.lastXDelta > 0.0D) {
/* 133 */         TEMP_RECT.setBounds(0, 0, (int)this.lastXDelta, this.cacheBounds.height);
/*     */       } else {
/* 135 */         TEMP_RECT.setBounds(this.cacheBounds.width + (int)this.lastXDelta, 0, -((int)this.lastXDelta), this.cacheBounds.height);
/*     */       }
/*     */     
/* 138 */     } else if (this.lastYDelta > 0.0D) {
/* 139 */       TEMP_RECT.setBounds(0, 0, this.cacheBounds.width, (int)this.lastYDelta);
/*     */     } else {
/* 141 */       TEMP_RECT.setBounds(0, this.cacheBounds.height + (int)this.lastYDelta, this.cacheBounds.width, -((int)this.lastYDelta));
/*     */     } 
/*     */     
/* 144 */     return TEMP_RECT;
/*     */   }
/*     */   
/*     */   protected CacheFilter(NGNode paramNGNode, CacheHint paramCacheHint) {
/* 148 */     this.node = paramNGNode;
/* 149 */     this.scrollCacheState = ScrollCacheState.CHECKING_PRECONDITIONS;
/* 150 */     setHint(paramCacheHint);
/*     */   }
/*     */   
/*     */   public void setHint(CacheHint paramCacheHint) {
/* 154 */     this.cacheHint = paramCacheHint;
/* 155 */     this.scaleHint = (paramCacheHint == CacheHint.SPEED || paramCacheHint == CacheHint.SCALE || paramCacheHint == CacheHint.SCALE_AND_ROTATE);
/*     */ 
/*     */     
/* 158 */     this.rotateHint = (paramCacheHint == CacheHint.SPEED || paramCacheHint == CacheHint.ROTATE || paramCacheHint == CacheHint.SCALE_AND_ROTATE);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isScaleHint() {
/* 164 */     return this.scaleHint; } final boolean isRotateHint() {
/* 165 */     return this.rotateHint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean matchesHint(CacheHint paramCacheHint) {
/* 172 */     return (this.cacheHint == paramCacheHint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unsupported(double[] paramArrayOfdouble) {
/* 181 */     double d1 = paramArrayOfdouble[0];
/* 182 */     double d2 = paramArrayOfdouble[1];
/* 183 */     double d3 = paramArrayOfdouble[2];
/*     */ 
/*     */     
/* 186 */     if (d3 > 1.0E-7D || d3 < -1.0E-7D)
/*     */     {
/*     */       
/* 189 */       if (d1 > d2 + 1.0E-7D || d2 > d1 + 1.0E-7D || d1 < d2 - 1.0E-7D || d2 < d1 - 1.0E-7D || this.cachedScaleX > this.cachedScaleY + 1.0E-7D || this.cachedScaleY > this.cachedScaleX + 1.0E-7D || this.cachedScaleX < this.cachedScaleY - 1.0E-7D || this.cachedScaleY < this.cachedScaleX - 1.0E-7D)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 195 */         return true;
/*     */       }
/*     */     }
/* 198 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isXformScrollCacheCapable(double[] paramArrayOfdouble) {
/* 202 */     if (unsupported(paramArrayOfdouble)) {
/* 203 */       return false;
/*     */     }
/* 205 */     double d = paramArrayOfdouble[2];
/* 206 */     return (this.rotateHint || d == 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean needToRenderCache(BaseTransform paramBaseTransform, double[] paramArrayOfdouble, float paramFloat1, float paramFloat2) {
/* 217 */     if (this.cachedImageData == null) {
/* 218 */       return true;
/*     */     }
/*     */     
/* 221 */     if (this.lastXDelta != 0.0D || this.lastYDelta != 0.0D) {
/* 222 */       if (Math.abs(this.lastXDelta) >= this.cacheBounds.width || Math.abs(this.lastYDelta) >= this.cacheBounds.height || 
/* 223 */         Math.rint(this.lastXDelta) != this.lastXDelta || Math.rint(this.lastYDelta) != this.lastYDelta) {
/* 224 */         this.node.clearDirtyTree();
/* 225 */         this.lastXDelta = this.lastYDelta = 0.0D;
/* 226 */         return true;
/*     */       } 
/* 228 */       if (this.scrollCacheState == ScrollCacheState.CHECKING_PRECONDITIONS) {
/* 229 */         if (scrollCacheCapable() && isXformScrollCacheCapable(paramArrayOfdouble)) {
/* 230 */           this.scrollCacheState = ScrollCacheState.ENABLED;
/*     */         } else {
/* 232 */           this.scrollCacheState = ScrollCacheState.DISABLED;
/* 233 */           return true;
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 239 */     if (this.cachedXform.getMxx() == paramBaseTransform.getMxx() && this.cachedXform
/* 240 */       .getMyy() == paramBaseTransform.getMyy() && this.cachedXform
/* 241 */       .getMxy() == paramBaseTransform.getMxy() && this.cachedXform
/* 242 */       .getMyx() == paramBaseTransform.getMyx())
/*     */     {
/* 244 */       return false;
/*     */     }
/*     */     
/* 247 */     if (this.wasUnsupported || unsupported(paramArrayOfdouble)) {
/* 248 */       return true;
/*     */     }
/*     */     
/* 251 */     double d1 = paramArrayOfdouble[0];
/* 252 */     double d2 = paramArrayOfdouble[1];
/* 253 */     double d3 = paramArrayOfdouble[2];
/* 254 */     if (this.scaleHint) {
/* 255 */       if (this.cachedScaleX < paramFloat1 || this.cachedScaleY < paramFloat2)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 260 */         return true;
/*     */       }
/* 262 */       if (this.rotateHint) {
/* 263 */         return false;
/*     */       }
/*     */       
/* 266 */       if (this.cachedRotate - 1.0E-7D < d3 && d3 < this.cachedRotate + 1.0E-7D) {
/* 267 */         return false;
/*     */       }
/* 269 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 273 */     if (this.rotateHint) {
/*     */       
/* 275 */       if (this.cachedScaleX - 1.0E-7D < d1 && d1 < this.cachedScaleX + 1.0E-7D && this.cachedScaleY - 1.0E-7D < d2 && d2 < this.cachedScaleY + 1.0E-7D)
/*     */       {
/* 277 */         return false;
/*     */       }
/* 279 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 283 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateScreenXform(double[] paramArrayOfdouble) {
/* 296 */     if (this.scaleHint) {
/* 297 */       if (this.rotateHint) {
/* 298 */         double d1 = paramArrayOfdouble[0] / this.cachedScaleX;
/* 299 */         double d2 = paramArrayOfdouble[1] / this.cachedScaleY;
/* 300 */         double d3 = paramArrayOfdouble[2] - this.cachedRotate;
/*     */         
/* 302 */         this.screenXform.setToScale(d1, d2);
/* 303 */         this.screenXform.rotate(d3);
/*     */       } else {
/* 305 */         double d1 = paramArrayOfdouble[0] / this.cachedScaleX;
/* 306 */         double d2 = paramArrayOfdouble[1] / this.cachedScaleY;
/* 307 */         this.screenXform.setToScale(d1, d2);
/*     */       }
/*     */     
/* 310 */     } else if (this.rotateHint) {
/* 311 */       double d = paramArrayOfdouble[2] - this.cachedRotate;
/* 312 */       this.screenXform.setToRotation(d, 0.0D, 0.0D);
/*     */     } else {
/*     */       
/* 315 */       this.screenXform.setTransform(BaseTransform.IDENTITY_TRANSFORM);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void invalidate() {
/* 321 */     if (this.scrollCacheState == ScrollCacheState.ENABLED) {
/* 322 */       this.scrollCacheState = ScrollCacheState.CHECKING_PRECONDITIONS;
/*     */     }
/* 324 */     imageDataUnref();
/* 325 */     this.lastXDelta = this.lastYDelta = 0.0D;
/*     */   }
/*     */   
/*     */   void imageDataUnref() {
/* 329 */     if (this.tempTexture != null) {
/* 330 */       this.tempTexture.dispose();
/* 331 */       this.tempTexture = null;
/*     */     } 
/* 333 */     if (this.cachedImageData != null) {
/*     */ 
/*     */ 
/*     */       
/* 337 */       Filterable filterable = this.cachedImageData.getUntransformedImage();
/* 338 */       if (filterable != null) {
/* 339 */         filterable.lock();
/*     */       }
/* 341 */       this.cachedImageData.unref();
/* 342 */       this.cachedImageData = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   void invalidateByTranslation(double paramDouble1, double paramDouble2) {
/* 347 */     if (this.cachedImageData == null) {
/*     */       return;
/*     */     }
/*     */     
/* 351 */     if (this.scrollCacheState == ScrollCacheState.DISABLED) {
/* 352 */       imageDataUnref();
/*     */     
/*     */     }
/* 355 */     else if (paramDouble1 != 0.0D && paramDouble2 != 0.0D) {
/* 356 */       imageDataUnref();
/*     */     } else {
/* 358 */       this.lastYDelta = paramDouble2;
/* 359 */       this.lastXDelta = paramDouble1;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 365 */     invalidate();
/* 366 */     this.node = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double[] unmatrix(BaseTransform paramBaseTransform) {
/* 393 */     double[] arrayOfDouble = new double[3];
/*     */ 
/*     */     
/* 396 */     double[][] arrayOfDouble1 = { { paramBaseTransform.getMxx(), paramBaseTransform.getMxy() }, { paramBaseTransform.getMyx(), paramBaseTransform.getMyy() } };
/* 397 */     double d1 = unitDir(arrayOfDouble1[0][0]);
/* 398 */     double d2 = unitDir(arrayOfDouble1[1][1]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 404 */     double d3 = d1 * v2length(arrayOfDouble1[0]);
/* 405 */     v2scale(arrayOfDouble1[0], d1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 412 */     double d4 = v2dot(arrayOfDouble1[0], arrayOfDouble1[1]);
/*     */ 
/*     */     
/* 415 */     v2combine(arrayOfDouble1[1], arrayOfDouble1[0], arrayOfDouble1[1], 1.0D, -d4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 422 */     double d5 = d2 * v2length(arrayOfDouble1[1]);
/* 423 */     v2scale(arrayOfDouble1[1], d2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 433 */     double d6 = arrayOfDouble1[1][0];
/* 434 */     double d7 = arrayOfDouble1[0][0];
/* 435 */     double d8 = 0.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 440 */     if (d6 >= 0.0D) {
/*     */       
/* 442 */       d8 = Math.acos(d7);
/*     */     }
/* 444 */     else if (d7 > 0.0D) {
/*     */ 
/*     */       
/* 447 */       d8 = 6.283185307179586D + Math.asin(d6);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 452 */       d8 = Math.PI + Math.acos(-d7);
/*     */     } 
/*     */ 
/*     */     
/* 456 */     arrayOfDouble[0] = d3;
/* 457 */     arrayOfDouble[1] = d5;
/* 458 */     arrayOfDouble[2] = d8;
/*     */     
/* 460 */     return arrayOfDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double unitDir(double paramDouble) {
/* 469 */     return (paramDouble < 0.0D) ? -1.0D : 1.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void v2combine(double[] paramArrayOfdouble1, double[] paramArrayOfdouble2, double[] paramArrayOfdouble3, double paramDouble1, double paramDouble2) {
/* 492 */     paramArrayOfdouble3[0] = paramDouble1 * paramArrayOfdouble1[0] + paramDouble2 * paramArrayOfdouble2[0];
/* 493 */     paramArrayOfdouble3[1] = paramDouble1 * paramArrayOfdouble1[1] + paramDouble2 * paramArrayOfdouble2[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double v2dot(double[] paramArrayOfdouble1, double[] paramArrayOfdouble2) {
/* 500 */     return paramArrayOfdouble1[0] * paramArrayOfdouble2[0] + paramArrayOfdouble1[1] * paramArrayOfdouble2[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void v2scale(double[] paramArrayOfdouble, double paramDouble) {
/* 509 */     double d = v2length(paramArrayOfdouble);
/* 510 */     if (d != 0.0D) {
/* 511 */       paramArrayOfdouble[0] = paramArrayOfdouble[0] * paramDouble / d;
/* 512 */       paramArrayOfdouble[1] = paramArrayOfdouble[1] * paramDouble / d;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double v2length(double[] paramArrayOfdouble) {
/* 522 */     return Math.sqrt(paramArrayOfdouble[0] * paramArrayOfdouble[0] + paramArrayOfdouble[1] * paramArrayOfdouble[1]);
/*     */   }
/*     */ 
/*     */   
/*     */   void render(Graphics paramGraphics) {
/* 527 */     BaseTransform baseTransform = paramGraphics.getTransformNoClone();
/* 528 */     PrFilterContext prFilterContext = PrFilterContext.getInstance(paramGraphics.getAssociatedScreen());
/*     */     
/* 530 */     double[] arrayOfDouble = unmatrix(baseTransform);
/* 531 */     boolean bool = unsupported(arrayOfDouble);
/*     */     
/* 533 */     this.lastXDelta *= arrayOfDouble[0];
/* 534 */     this.lastYDelta *= arrayOfDouble[1];
/*     */     
/* 536 */     if (this.cachedImageData != null) {
/* 537 */       Filterable filterable1 = this.cachedImageData.getUntransformedImage();
/* 538 */       if (filterable1 != null) {
/* 539 */         filterable1.lock();
/* 540 */         if (!this.cachedImageData.validate(prFilterContext)) {
/* 541 */           filterable1.unlock();
/* 542 */           invalidate();
/*     */         } 
/*     */       } 
/*     */     } 
/* 546 */     float f1 = paramGraphics.getPixelScaleFactorX();
/* 547 */     float f2 = paramGraphics.getPixelScaleFactorY();
/* 548 */     if (needToRenderCache(baseTransform, arrayOfDouble, f1, f2)) {
/* 549 */       if (PulseLogger.PULSE_LOGGING_ENABLED) {
/* 550 */         PulseLogger.incrementCounter("CacheFilter rebuilding");
/*     */       }
/* 552 */       if (this.cachedImageData != null) {
/* 553 */         Filterable filterable1 = this.cachedImageData.getUntransformedImage();
/* 554 */         if (filterable1 != null) {
/* 555 */           filterable1.unlock();
/*     */         }
/* 557 */         invalidate();
/*     */       } 
/* 559 */       if (this.scaleHint) {
/*     */ 
/*     */ 
/*     */         
/* 563 */         this.cachedScaleX = Math.max(f1, arrayOfDouble[0]);
/* 564 */         this.cachedScaleY = Math.max(f2, arrayOfDouble[1]);
/* 565 */         this.cachedRotate = 0.0D;
/* 566 */         this.cachedXform.setTransform(this.cachedScaleX, 0.0D, 0.0D, this.cachedScaleX, 0.0D, 0.0D);
/*     */ 
/*     */         
/* 569 */         updateScreenXform(arrayOfDouble);
/*     */       } else {
/* 571 */         this.cachedScaleX = arrayOfDouble[0];
/* 572 */         this.cachedScaleY = arrayOfDouble[1];
/* 573 */         this.cachedRotate = arrayOfDouble[2];
/*     */ 
/*     */         
/* 576 */         this.cachedXform.setTransform(baseTransform.getMxx(), baseTransform.getMyx(), baseTransform
/* 577 */             .getMxy(), baseTransform.getMyy(), 0.0D, 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 582 */         this.screenXform.setTransform(BaseTransform.IDENTITY_TRANSFORM);
/*     */       } 
/*     */       
/* 585 */       this.cacheBounds = getCacheBounds(this.cacheBounds, this.cachedXform);
/* 586 */       this.cachedImageData = createImageData(prFilterContext, this.cacheBounds);
/* 587 */       renderNodeToCache(this.cachedImageData, this.cacheBounds, this.cachedXform, null);
/*     */ 
/*     */       
/* 590 */       Rectangle rectangle = this.cachedImageData.getUntransformedBounds();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 595 */       this.cachedX = rectangle.x;
/* 596 */       this.cachedY = rectangle.y;
/*     */     } else {
/*     */       
/* 599 */       if (this.scrollCacheState == ScrollCacheState.ENABLED && (this.lastXDelta != 0.0D || this.lastYDelta != 0.0D)) {
/*     */         
/* 601 */         moveCacheBy(this.cachedImageData, this.lastXDelta, this.lastYDelta);
/* 602 */         renderNodeToCache(this.cachedImageData, this.cacheBounds, this.cachedXform, computeDirtyRegionForTranslate());
/* 603 */         this.lastXDelta = this.lastYDelta = 0.0D;
/*     */       } 
/*     */       
/* 606 */       if (bool) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 613 */         this.screenXform.setTransform(BaseTransform.IDENTITY_TRANSFORM);
/*     */       } else {
/* 615 */         updateScreenXform(arrayOfDouble);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 620 */     this.wasUnsupported = bool;
/*     */     
/* 622 */     Filterable filterable = this.cachedImageData.getUntransformedImage();
/* 623 */     if (filterable == null) {
/* 624 */       if (PulseLogger.PULSE_LOGGING_ENABLED) {
/* 625 */         PulseLogger.incrementCounter("CacheFilter not used");
/*     */       }
/* 627 */       renderNodeToScreen(paramGraphics);
/*     */     } else {
/* 629 */       double d1 = baseTransform.getMxt();
/* 630 */       double d2 = baseTransform.getMyt();
/* 631 */       renderCacheToScreen(paramGraphics, filterable, d1, d2);
/* 632 */       filterable.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImageData createImageData(FilterContext paramFilterContext, Rectangle paramRectangle) {
/*     */     Filterable filterable;
/*     */     try {
/* 642 */       filterable = Effect.getCompatibleImage(paramFilterContext, paramRectangle.width, paramRectangle.height);
/*     */       
/* 644 */       RTTexture rTTexture = ((PrDrawable)filterable).getTextureObject();
/* 645 */       rTTexture.contentsUseful();
/* 646 */     } catch (Throwable throwable) {
/* 647 */       filterable = null;
/*     */     } 
/*     */     
/* 650 */     return new ImageData(paramFilterContext, filterable, paramRectangle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void renderNodeToCache(ImageData paramImageData, Rectangle paramRectangle1, BaseTransform paramBaseTransform, Rectangle paramRectangle2) {
/* 664 */     PrDrawable prDrawable = (PrDrawable)paramImageData.getUntransformedImage();
/*     */     
/* 666 */     if (prDrawable != null) {
/* 667 */       Graphics graphics = prDrawable.createGraphics();
/* 668 */       TEMP_CACHEFILTER_TRANSFORM.setToIdentity();
/* 669 */       TEMP_CACHEFILTER_TRANSFORM.translate(-paramRectangle1.x, -paramRectangle1.y);
/* 670 */       if (paramBaseTransform != null) {
/* 671 */         TEMP_CACHEFILTER_TRANSFORM.concatenate(paramBaseTransform);
/*     */       }
/* 673 */       if (paramRectangle2 != null) {
/* 674 */         TEMP_CONTAINER.deriveWithNewRegion((RectBounds)TEMP_BOUNDS.deriveWithNewBounds(paramRectangle2));
/*     */         
/* 676 */         this.node.doPreCulling(TEMP_CONTAINER, TEMP_CACHEFILTER_TRANSFORM, new GeneralTransform3D());
/* 677 */         graphics.setHasPreCullingBits(true);
/* 678 */         graphics.setClipRectIndex(0);
/* 679 */         graphics.setClipRect(paramRectangle2);
/*     */       } 
/* 681 */       graphics.transform(TEMP_CACHEFILTER_TRANSFORM);
/* 682 */       if (this.node.getClipNode() != null) {
/* 683 */         this.node.renderClip(graphics);
/* 684 */       } else if (this.node.getEffectFilter() != null) {
/* 685 */         this.node.renderEffect(graphics);
/*     */       } else {
/* 687 */         this.node.renderContent(graphics);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void renderNodeToScreen(Object paramObject) {
/* 697 */     Graphics graphics = (Graphics)paramObject;
/* 698 */     if (this.node.getEffectFilter() != null) {
/* 699 */       this.node.renderEffect(graphics);
/*     */     } else {
/* 701 */       this.node.renderContent(graphics);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void renderCacheToScreen(Object paramObject, Filterable paramFilterable, double paramDouble1, double paramDouble2) {
/* 711 */     Graphics graphics = (Graphics)paramObject;
/*     */     
/* 713 */     graphics.setTransform(this.screenXform.getMxx(), this.screenXform
/* 714 */         .getMyx(), this.screenXform
/* 715 */         .getMxy(), this.screenXform
/* 716 */         .getMyy(), paramDouble1, paramDouble2);
/*     */     
/* 718 */     graphics.translate((float)this.cachedX, (float)this.cachedY);
/* 719 */     RTTexture rTTexture = ((PrDrawable)paramFilterable).getTextureObject();
/* 720 */     Rectangle rectangle = this.cachedImageData.getUntransformedBounds();
/* 721 */     graphics.drawTexture(rTTexture, 0.0F, 0.0F, rectangle.width, rectangle.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean scrollCacheCapable() {
/* 730 */     if (!(this.node instanceof NGGroup)) {
/* 731 */       return false;
/*     */     }
/* 733 */     List<NGNode> list = ((NGGroup)this.node).getChildren();
/* 734 */     if (list.size() != 1) {
/* 735 */       return false;
/*     */     }
/* 737 */     NGNode nGNode1 = list.get(0);
/* 738 */     if (!nGNode1.getTransform().is2D()) {
/* 739 */       return false;
/*     */     }
/*     */     
/* 742 */     NGNode nGNode2 = this.node.getClipNode();
/* 743 */     if (nGNode2 == null || !nGNode2.isRectClip(BaseTransform.IDENTITY_TRANSFORM, false)) {
/* 744 */       return false;
/*     */     }
/*     */     
/* 747 */     if (this.node instanceof NGRegion) {
/* 748 */       NGRegion nGRegion = (NGRegion)this.node;
/* 749 */       if (!nGRegion.getBorder().isEmpty()) {
/* 750 */         return false;
/*     */       }
/* 752 */       Background background = nGRegion.getBackground();
/*     */       
/* 754 */       if (!background.isEmpty()) {
/* 755 */         if (!background.getImages().isEmpty() || background
/* 756 */           .getFills().size() != 1) {
/* 757 */           return false;
/*     */         }
/* 759 */         BackgroundFill backgroundFill = background.getFills().get(0);
/* 760 */         Paint paint = backgroundFill.getFill();
/* 761 */         BaseBounds baseBounds = nGNode2.getCompleteBounds(TEMP_BOUNDS, BaseTransform.IDENTITY_TRANSFORM);
/*     */         
/* 763 */         return (paint.isOpaque() && paint instanceof javafx.scene.paint.Color && backgroundFill.getInsets().equals(Insets.EMPTY) && baseBounds
/* 764 */           .getMinX() == 0.0F && baseBounds.getMinY() == 0.0F && baseBounds
/* 765 */           .getMaxX() == nGRegion.getWidth() && baseBounds.getMaxY() == nGRegion.getHeight());
/*     */       } 
/*     */     } 
/*     */     
/* 769 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void moveCacheBy(ImageData paramImageData, double paramDouble1, double paramDouble2) {
/* 780 */     PrDrawable prDrawable = (PrDrawable)paramImageData.getUntransformedImage();
/* 781 */     Rectangle rectangle = paramImageData.getUntransformedBounds();
/* 782 */     int i = (int)Math.max(0.0D, -paramDouble1);
/* 783 */     int j = (int)Math.max(0.0D, -paramDouble2);
/* 784 */     int k = (int)Math.max(0.0D, paramDouble1);
/* 785 */     int m = (int)Math.max(0.0D, paramDouble2);
/* 786 */     int n = rectangle.width - (int)Math.abs(paramDouble1);
/* 787 */     int i1 = rectangle.height - (int)Math.abs(paramDouble2);
/*     */     
/* 789 */     Graphics graphics1 = prDrawable.createGraphics();
/* 790 */     if (this.tempTexture != null) {
/* 791 */       this.tempTexture.lock();
/* 792 */       if (this.tempTexture.isSurfaceLost()) {
/* 793 */         this.tempTexture = null;
/*     */       }
/*     */     } 
/* 796 */     if (this.tempTexture == null) {
/* 797 */       this
/* 798 */         .tempTexture = graphics1.getResourceFactory().createRTTexture(prDrawable.getPhysicalWidth(), prDrawable.getPhysicalHeight(), Texture.WrapMode.CLAMP_NOT_NEEDED);
/*     */     }
/*     */     
/* 801 */     Graphics graphics2 = this.tempTexture.createGraphics();
/* 802 */     graphics2.clear();
/* 803 */     graphics2.drawTexture(prDrawable.getTextureObject(), 0.0F, 0.0F, n, i1, i, j, (i + n), (j + i1));
/* 804 */     graphics2.sync();
/*     */     
/* 806 */     graphics1.clear();
/* 807 */     graphics1.drawTexture(this.tempTexture, k, m, (k + n), (m + i1), 0.0F, 0.0F, n, i1);
/* 808 */     this.tempTexture.unlock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Rectangle getCacheBounds(Rectangle paramRectangle, BaseTransform paramBaseTransform) {
/* 817 */     BaseBounds baseBounds = this.node.getClippedBounds(TEMP_BOUNDS, paramBaseTransform);
/* 818 */     paramRectangle.setBounds(baseBounds);
/* 819 */     return paramRectangle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BaseBounds computeDirtyBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 828 */     if (!this.node.dirtyBounds.isEmpty()) {
/* 829 */       paramBaseBounds = paramBaseBounds.deriveWithNewBounds(this.node.dirtyBounds);
/*     */     } else {
/* 831 */       paramBaseBounds = paramBaseBounds.deriveWithNewBounds(this.node.transformedBounds);
/*     */     } 
/*     */     
/* 834 */     if (!paramBaseBounds.isEmpty()) {
/* 835 */       paramBaseBounds.roundOut();
/* 836 */       paramBaseBounds = this.node.computePadding(paramBaseBounds);
/* 837 */       paramBaseBounds = paramBaseTransform.transform(paramBaseBounds, paramBaseBounds);
/* 838 */       paramBaseBounds = paramGeneralTransform3D.transform(paramBaseBounds, paramBaseBounds);
/*     */     } 
/* 840 */     return paramBaseBounds;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\CacheFilter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */