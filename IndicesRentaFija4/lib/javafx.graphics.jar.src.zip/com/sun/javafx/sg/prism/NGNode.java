/*      */ package com.sun.javafx.sg.prism;
/*      */ 
/*      */ import com.sun.glass.ui.Screen;
/*      */ import com.sun.javafx.geom.BaseBounds;
/*      */ import com.sun.javafx.geom.BoxBounds;
/*      */ import com.sun.javafx.geom.DirtyRegionContainer;
/*      */ import com.sun.javafx.geom.DirtyRegionPool;
/*      */ import com.sun.javafx.geom.Point2D;
/*      */ import com.sun.javafx.geom.RectBounds;
/*      */ import com.sun.javafx.geom.Rectangle;
/*      */ import com.sun.javafx.geom.transform.Affine3D;
/*      */ import com.sun.javafx.geom.transform.BaseTransform;
/*      */ import com.sun.javafx.geom.transform.GeneralTransform3D;
/*      */ import com.sun.javafx.geom.transform.NoninvertibleTransformException;
/*      */ import com.sun.javafx.logging.PulseLogger;
/*      */ import com.sun.prism.CompositeMode;
/*      */ import com.sun.prism.Graphics;
/*      */ import com.sun.prism.GraphicsPipeline;
/*      */ import com.sun.prism.RTTexture;
/*      */ import com.sun.prism.ReadbackGraphics;
/*      */ import com.sun.prism.impl.PrismSettings;
/*      */ import com.sun.scenario.effect.Blend;
/*      */ import com.sun.scenario.effect.Effect;
/*      */ import com.sun.scenario.effect.FilterContext;
/*      */ import com.sun.scenario.effect.ImageData;
/*      */ import com.sun.scenario.effect.impl.prism.PrDrawable;
/*      */ import com.sun.scenario.effect.impl.prism.PrEffectHelper;
/*      */ import com.sun.scenario.effect.impl.prism.PrFilterContext;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javafx.scene.CacheHint;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class NGNode
/*      */ {
/*   84 */   private static final GraphicsPipeline pipeline = GraphicsPipeline.getPipeline();
/*      */ 
/*      */   
/*   87 */   private static final Boolean effectsSupported = Boolean.valueOf((pipeline == null) ? false : pipeline.isEffectSupported());
/*      */   private String name;
/*      */   
/*   90 */   public enum DirtyFlag { CLEAN,
/*      */     
/*   92 */     DIRTY_BY_TRANSLATION,
/*   93 */     DIRTY; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  107 */   private static final BoxBounds TEMP_BOUNDS = new BoxBounds();
/*  108 */   private static final RectBounds TEMP_RECT_BOUNDS = new RectBounds();
/*  109 */   protected static final Affine3D TEMP_TRANSFORM = new Affine3D();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int DIRTY_REGION_INTERSECTS_NODE_BOUNDS = 1;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int DIRTY_REGION_CONTAINS_NODE_BOUNDS = 2;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int DIRTY_REGION_CONTAINS_OR_INTERSECTS_NODE_BOUNDS = 3;
/*      */ 
/*      */ 
/*      */   
/*  126 */   private BaseTransform transform = BaseTransform.IDENTITY_TRANSFORM;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  134 */   protected BaseBounds transformedBounds = new RectBounds();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  141 */   protected BaseBounds contentBounds = new RectBounds();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  150 */   BaseBounds dirtyBounds = new RectBounds();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean visible = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   protected DirtyFlag dirty = DirtyFlag.DIRTY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private NGNode parent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isClip;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private NGNode clipNode;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  189 */   private float opacity = 1.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  194 */   private double viewOrder = 0.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Blend.Mode nodeBlendMode;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean depthTest = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CacheFilter cacheFilter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private EffectFilter effectFilter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean childDirty = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  235 */   protected int dirtyChildrenAccumulated = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final int DIRTY_CHILDREN_ACCUMULATED_THRESHOLD = 12;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  246 */   protected int cullingBits = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   private DirtyHint hint;
/*      */ 
/*      */ 
/*      */   
/*  254 */   private RectBounds opaqueRegion = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean opaqueRegionInvalid = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  270 */   private int painted = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVisible(boolean paramBoolean) {
/*  292 */     if (this.visible != paramBoolean) {
/*  293 */       this.visible = paramBoolean;
/*  294 */       markDirty();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setContentBounds(BaseBounds paramBaseBounds) {
/*  306 */     this.contentBounds = this.contentBounds.deriveWithNewBounds(paramBaseBounds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransformedBounds(BaseBounds paramBaseBounds, boolean paramBoolean) {
/*  314 */     if (this.transformedBounds.equals(paramBaseBounds)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  331 */     if (this.dirtyBounds.isEmpty()) {
/*  332 */       this.dirtyBounds = this.dirtyBounds.deriveWithNewBounds(this.transformedBounds);
/*  333 */       this.dirtyBounds = this.dirtyBounds.deriveWithUnion(paramBaseBounds);
/*      */     }
/*      */     else {
/*      */       
/*  337 */       this.dirtyBounds = this.dirtyBounds.deriveWithUnion(this.transformedBounds);
/*      */     } 
/*  339 */     this.transformedBounds = this.transformedBounds.deriveWithNewBounds(paramBaseBounds);
/*  340 */     if (hasVisuals() && !paramBoolean) {
/*  341 */       markDirty();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransformMatrix(BaseTransform paramBaseTransform) {
/*  350 */     if (this.transform.equals(paramBaseTransform)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  362 */     boolean bool = false;
/*      */ 
/*      */     
/*  365 */     if (this.parent != null && this.parent.cacheFilter != null && PrismSettings.scrollCacheOpt) {
/*  366 */       if (this.hint == null) {
/*      */ 
/*      */         
/*  369 */         this.hint = new DirtyHint();
/*      */       }
/*  371 */       else if (this.transform.getMxx() == paramBaseTransform.getMxx() && this.transform
/*  372 */         .getMxy() == paramBaseTransform.getMxy() && this.transform
/*  373 */         .getMyy() == paramBaseTransform.getMyy() && this.transform
/*  374 */         .getMyx() == paramBaseTransform.getMyx() && this.transform
/*  375 */         .getMxz() == paramBaseTransform.getMxz() && this.transform
/*  376 */         .getMyz() == paramBaseTransform.getMyz() && this.transform
/*  377 */         .getMzx() == paramBaseTransform.getMzx() && this.transform
/*  378 */         .getMzy() == paramBaseTransform.getMzy() && this.transform
/*  379 */         .getMzz() == paramBaseTransform.getMzz() && this.transform
/*  380 */         .getMzt() == paramBaseTransform.getMzt()) {
/*  381 */         bool = true;
/*  382 */         this.hint.translateXDelta = paramBaseTransform.getMxt() - this.transform.getMxt();
/*  383 */         this.hint.translateYDelta = paramBaseTransform.getMyt() - this.transform.getMyt();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  388 */     this.transform = this.transform.deriveWithNewTransform(paramBaseTransform);
/*  389 */     if (bool) {
/*  390 */       markDirtyByTranslation();
/*      */     } else {
/*  392 */       markDirty();
/*      */     } 
/*  394 */     invalidateOpaqueRegion();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClipNode(NGNode paramNGNode) {
/*  405 */     if (paramNGNode != this.clipNode) {
/*      */       
/*  407 */       if (this.clipNode != null) this.clipNode.setParent(null);
/*      */       
/*  409 */       if (paramNGNode != null) paramNGNode.setParent(this, true);
/*      */       
/*  411 */       this.clipNode = paramNGNode;
/*      */       
/*  413 */       visualsChanged();
/*  414 */       invalidateOpaqueRegion();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOpacity(float paramFloat) {
/*  425 */     if (paramFloat < 0.0F || paramFloat > 1.0F) {
/*  426 */       throw new IllegalArgumentException("Internal Error: The opacity must be between 0 and 1");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  431 */     if (paramFloat != this.opacity) {
/*  432 */       float f = this.opacity;
/*  433 */       this.opacity = paramFloat;
/*  434 */       markDirty();
/*      */ 
/*      */ 
/*      */       
/*  438 */       if ((f < 1.0F && (paramFloat == 1.0F || paramFloat == 0.0F)) || (paramFloat < 1.0F && (f == 1.0F || f == 0.0F))) {
/*  439 */         invalidateOpaqueRegion();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setViewOrder(double paramDouble) {
/*  453 */     if (paramDouble != this.viewOrder) {
/*  454 */       this.viewOrder = paramDouble;
/*      */       
/*  456 */       visualsChanged();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNodeBlendMode(Blend.Mode paramMode) {
/*  481 */     if (this.nodeBlendMode != paramMode) {
/*  482 */       this.nodeBlendMode = paramMode;
/*  483 */       markDirty();
/*  484 */       invalidateOpaqueRegion();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDepthTest(boolean paramBoolean) {
/*  496 */     if (paramBoolean != this.depthTest) {
/*  497 */       this.depthTest = paramBoolean;
/*      */       
/*  499 */       visualsChanged();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCachedAsBitmap(boolean paramBoolean, CacheHint paramCacheHint) {
/*  513 */     if (paramCacheHint == null) {
/*  514 */       throw new IllegalArgumentException("Internal Error: cacheHint must not be null");
/*      */     }
/*      */     
/*  517 */     if (paramBoolean) {
/*  518 */       if (this.cacheFilter == null) {
/*  519 */         this.cacheFilter = new CacheFilter(this, paramCacheHint);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  527 */         markDirty();
/*      */       }
/*  529 */       else if (!this.cacheFilter.matchesHint(paramCacheHint)) {
/*  530 */         this.cacheFilter.setHint(paramCacheHint);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  539 */         markDirty();
/*      */       }
/*      */     
/*      */     }
/*  543 */     else if (this.cacheFilter != null) {
/*  544 */       this.cacheFilter.dispose();
/*  545 */       this.cacheFilter = null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  550 */       markDirty();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEffect(Effect paramEffect) {
/*  560 */     Effect effect = getEffect();
/*      */     
/*  562 */     if (PrismSettings.disableEffects) {
/*  563 */       paramEffect = null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  575 */     if (this.effectFilter == null && paramEffect != null) {
/*  576 */       this.effectFilter = new EffectFilter(paramEffect, this);
/*  577 */       visualsChanged();
/*  578 */     } else if (this.effectFilter != null && this.effectFilter.getEffect() != paramEffect) {
/*  579 */       this.effectFilter.dispose();
/*  580 */       this.effectFilter = null;
/*  581 */       if (paramEffect != null) {
/*  582 */         this.effectFilter = new EffectFilter(paramEffect, this);
/*      */       }
/*  584 */       visualsChanged();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  590 */     if (effect != paramEffect && (
/*  591 */       effect == null || paramEffect == null)) {
/*  592 */       invalidateOpaqueRegion();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void effectChanged() {
/*  602 */     visualsChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isContentBounds2D() {
/*  610 */     return this.contentBounds.is2D();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NGNode getParent() {
/*  625 */     return this.parent;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParent(NGNode paramNGNode) {
/*  631 */     setParent(paramNGNode, false);
/*      */   }
/*      */   
/*      */   private void setParent(NGNode paramNGNode, boolean paramBoolean) {
/*  635 */     this.parent = paramNGNode;
/*  636 */     this.isClip = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String paramString) {
/*  643 */     this.name = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getName() {
/*  650 */     return this.name;
/*      */   }
/*      */   protected final Effect getEffect() {
/*  653 */     return (this.effectFilter == null) ? null : this.effectFilter.getEffect();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isVisible() {
/*  658 */     return this.visible;
/*      */   }
/*  660 */   public final BaseTransform getTransform() { return this.transform; }
/*  661 */   public final float getOpacity() { return this.opacity; }
/*  662 */   public final Blend.Mode getNodeBlendMode() { return this.nodeBlendMode; }
/*  663 */   public final boolean isDepthTest() { return this.depthTest; }
/*  664 */   public final CacheFilter getCacheFilter() { return this.cacheFilter; }
/*  665 */   public final EffectFilter getEffectFilter() { return this.effectFilter; } public final NGNode getClipNode() {
/*  666 */     return this.clipNode;
/*      */   }
/*      */   public BaseBounds getContentBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  669 */     if (paramBaseTransform.isTranslateOrIdentity()) {
/*  670 */       paramBaseBounds = paramBaseBounds.deriveWithNewBounds(this.contentBounds);
/*  671 */       if (!paramBaseTransform.isIdentity()) {
/*  672 */         float f1 = (float)paramBaseTransform.getMxt();
/*  673 */         float f2 = (float)paramBaseTransform.getMyt();
/*  674 */         float f3 = (float)paramBaseTransform.getMzt();
/*  675 */         paramBaseBounds = paramBaseBounds.deriveWithNewBounds(paramBaseBounds
/*  676 */             .getMinX() + f1, paramBaseBounds
/*  677 */             .getMinY() + f2, paramBaseBounds
/*  678 */             .getMinZ() + f3, paramBaseBounds
/*  679 */             .getMaxX() + f1, paramBaseBounds
/*  680 */             .getMaxY() + f2, paramBaseBounds
/*  681 */             .getMaxZ() + f3);
/*      */       } 
/*  683 */       return paramBaseBounds;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  688 */     return computeBounds(paramBaseBounds, paramBaseTransform);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BaseBounds computeBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  715 */     paramBaseBounds = paramBaseBounds.deriveWithNewBounds(this.contentBounds);
/*  716 */     return paramBaseTransform.transform(this.contentBounds, paramBaseBounds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final BaseBounds getClippedBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  723 */     BaseBounds baseBounds = getEffectBounds(paramBaseBounds, paramBaseTransform);
/*  724 */     if (this.clipNode != null) {
/*      */ 
/*      */ 
/*      */       
/*  728 */       float f1 = baseBounds.getMinX();
/*  729 */       float f2 = baseBounds.getMinY();
/*  730 */       float f3 = baseBounds.getMinZ();
/*  731 */       float f4 = baseBounds.getMaxX();
/*  732 */       float f5 = baseBounds.getMaxY();
/*  733 */       float f6 = baseBounds.getMaxZ();
/*  734 */       baseBounds = this.clipNode.getCompleteBounds(baseBounds, paramBaseTransform);
/*  735 */       baseBounds.intersectWith(f1, f2, f3, f4, f5, f6);
/*      */     } 
/*  737 */     return baseBounds;
/*      */   }
/*      */   
/*      */   public final BaseBounds getEffectBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  741 */     if (this.effectFilter != null) {
/*  742 */       return this.effectFilter.getBounds(paramBaseBounds, paramBaseTransform);
/*      */     }
/*  744 */     return getContentBounds(paramBaseBounds, paramBaseTransform);
/*      */   }
/*      */ 
/*      */   
/*      */   public final BaseBounds getCompleteBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  749 */     if (paramBaseTransform.isIdentity()) {
/*  750 */       paramBaseBounds = paramBaseBounds.deriveWithNewBounds(this.transformedBounds);
/*  751 */       return paramBaseBounds;
/*  752 */     }  if (this.transform.isIdentity()) {
/*  753 */       return getClippedBounds(paramBaseBounds, paramBaseTransform);
/*      */     }
/*  755 */     double d1 = paramBaseTransform.getMxx();
/*  756 */     double d2 = paramBaseTransform.getMxy();
/*  757 */     double d3 = paramBaseTransform.getMxz();
/*  758 */     double d4 = paramBaseTransform.getMxt();
/*  759 */     double d5 = paramBaseTransform.getMyx();
/*  760 */     double d6 = paramBaseTransform.getMyy();
/*  761 */     double d7 = paramBaseTransform.getMyz();
/*  762 */     double d8 = paramBaseTransform.getMyt();
/*  763 */     double d9 = paramBaseTransform.getMzx();
/*  764 */     double d10 = paramBaseTransform.getMzy();
/*  765 */     double d11 = paramBaseTransform.getMzz();
/*  766 */     double d12 = paramBaseTransform.getMzt();
/*  767 */     BaseTransform baseTransform = paramBaseTransform.deriveWithConcatenation(this.transform);
/*  768 */     paramBaseBounds = getClippedBounds(paramBaseBounds, paramBaseTransform);
/*  769 */     if (baseTransform == paramBaseTransform) {
/*  770 */       paramBaseTransform.restoreTransform(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12);
/*      */     }
/*      */ 
/*      */     
/*  774 */     return paramBaseBounds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void visualsChanged() {
/*  789 */     invalidateCache();
/*  790 */     markDirty();
/*      */   }
/*      */   
/*      */   protected void geometryChanged() {
/*  794 */     invalidateCache();
/*  795 */     invalidateOpaqueRegion();
/*  796 */     if (hasVisuals()) {
/*  797 */       markDirty();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void markDirty() {
/*  812 */     if (this.dirty != DirtyFlag.DIRTY) {
/*  813 */       this.dirty = DirtyFlag.DIRTY;
/*  814 */       markTreeDirty();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void markDirtyByTranslation() {
/*  822 */     if (this.dirty == DirtyFlag.CLEAN) {
/*  823 */       if (this.parent != null && this.parent.dirty == DirtyFlag.CLEAN && !this.parent.childDirty) {
/*  824 */         this.dirty = DirtyFlag.DIRTY_BY_TRANSLATION;
/*  825 */         this.parent.childDirty = true;
/*  826 */         this.parent.dirtyChildrenAccumulated++;
/*  827 */         this.parent.invalidateCacheByTranslation(this.hint);
/*  828 */         this.parent.markTreeDirty();
/*      */       } else {
/*  830 */         markDirty();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void markTreeDirtyNoIncrement() {
/*  841 */     if (this.parent != null && (!this.parent.childDirty || this.dirty == DirtyFlag.DIRTY_BY_TRANSLATION)) {
/*  842 */       markTreeDirty();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void markTreeDirty() {
/*  862 */     NGNode nGNode = this.parent;
/*  863 */     boolean bool = this.isClip;
/*  864 */     boolean bool1 = (this.dirty == DirtyFlag.DIRTY_BY_TRANSLATION) ? true : false;
/*  865 */     while (nGNode != null && nGNode.dirty != DirtyFlag.DIRTY && (!nGNode.childDirty || bool || bool1)) {
/*  866 */       if (bool) {
/*  867 */         nGNode.dirty = DirtyFlag.DIRTY;
/*  868 */       } else if (!bool1) {
/*  869 */         nGNode.childDirty = true;
/*  870 */         nGNode.dirtyChildrenAccumulated++;
/*      */       } 
/*  872 */       nGNode.invalidateCache();
/*  873 */       bool = nGNode.isClip;
/*  874 */       bool1 = (nGNode.dirty == DirtyFlag.DIRTY_BY_TRANSLATION) ? true : false;
/*  875 */       nGNode = nGNode.parent;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  880 */     if (nGNode != null && nGNode.dirty == DirtyFlag.CLEAN && !bool && !bool1) {
/*  881 */       nGNode.dirtyChildrenAccumulated++;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  887 */     if (nGNode != null) nGNode.invalidateCache();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isClean() {
/*  895 */     return (this.dirty == DirtyFlag.CLEAN && !this.childDirty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clearDirty() {
/*  902 */     this.dirty = DirtyFlag.CLEAN;
/*  903 */     this.childDirty = false;
/*  904 */     this.dirtyBounds.makeEmpty();
/*  905 */     this.dirtyChildrenAccumulated = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearPainted() {
/*  913 */     this.painted = 0;
/*  914 */     if (this instanceof NGGroup) {
/*  915 */       List<NGNode> list = ((NGGroup)this).getChildren();
/*  916 */       for (byte b = 0; b < list.size(); b++) {
/*  917 */         ((NGNode)list.get(b)).clearPainted();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public void clearDirtyTree() {
/*  923 */     clearDirty();
/*  924 */     if (getClipNode() != null) {
/*  925 */       getClipNode().clearDirtyTree();
/*      */     }
/*  927 */     if (this instanceof NGGroup) {
/*  928 */       List<NGNode> list = ((NGGroup)this).getChildren();
/*  929 */       for (byte b = 0; b < list.size(); b++) {
/*  930 */         NGNode nGNode = list.get(b);
/*  931 */         if (nGNode.dirty != DirtyFlag.CLEAN || nGNode.childDirty) {
/*  932 */           nGNode.clearDirtyTree();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void invalidateCache() {
/*  945 */     if (this.cacheFilter != null) {
/*  946 */       this.cacheFilter.invalidate();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void invalidateCacheByTranslation(DirtyHint paramDirtyHint) {
/*  955 */     if (this.cacheFilter != null) {
/*  956 */       this.cacheFilter.invalidateByTranslation(paramDirtyHint.translateXDelta, paramDirtyHint.translateYDelta);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int accumulateDirtyRegions(RectBounds paramRectBounds1, RectBounds paramRectBounds2, DirtyRegionPool paramDirtyRegionPool, DirtyRegionContainer paramDirtyRegionContainer, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 1014 */     if (paramRectBounds1 == null || paramRectBounds2 == null || paramDirtyRegionPool == null || paramDirtyRegionContainer == null || paramBaseTransform == null || paramGeneralTransform3D == null) {
/* 1015 */       throw new NullPointerException();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1029 */     if (this.dirty == DirtyFlag.CLEAN && !this.childDirty) {
/* 1030 */       return 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1037 */     if (this.dirty != DirtyFlag.CLEAN) {
/* 1038 */       return accumulateNodeDirtyRegion(paramRectBounds1, paramRectBounds2, paramDirtyRegionContainer, paramBaseTransform, paramGeneralTransform3D);
/*      */     }
/* 1040 */     assert this.childDirty;
/* 1041 */     return accumulateGroupDirtyRegion(paramRectBounds1, paramRectBounds2, paramDirtyRegionPool, paramDirtyRegionContainer, paramBaseTransform, paramGeneralTransform3D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int accumulateNodeDirtyRegion(RectBounds paramRectBounds1, RectBounds paramRectBounds2, DirtyRegionContainer paramDirtyRegionContainer, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 1057 */     BaseBounds baseBounds = computeDirtyRegion(paramRectBounds2, paramBaseTransform, paramGeneralTransform3D);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1064 */     if (baseBounds != paramRectBounds2) {
/* 1065 */       baseBounds.flattenInto(paramRectBounds2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1071 */     if (paramRectBounds2.isEmpty() || paramRectBounds1.disjoint(paramRectBounds2)) {
/* 1072 */       return 1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1077 */     if (paramRectBounds2.contains(paramRectBounds1)) {
/* 1078 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1083 */     paramRectBounds2.intersectWith(paramRectBounds1);
/*      */ 
/*      */     
/* 1086 */     paramDirtyRegionContainer.addDirtyRegion(paramRectBounds2);
/*      */     
/* 1088 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int accumulateGroupDirtyRegion(RectBounds paramRectBounds1, RectBounds paramRectBounds2, DirtyRegionPool paramDirtyRegionPool, DirtyRegionContainer paramDirtyRegionContainer, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 1109 */     assert this.childDirty;
/* 1110 */     assert this.dirty == DirtyFlag.CLEAN;
/*      */     
/* 1112 */     int i = 1;
/*      */     
/* 1114 */     if (this.dirtyChildrenAccumulated > 12) {
/* 1115 */       i = accumulateNodeDirtyRegion(paramRectBounds1, paramRectBounds2, paramDirtyRegionContainer, paramBaseTransform, paramGeneralTransform3D);
/* 1116 */       return i;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1124 */     double d1 = paramBaseTransform.getMxx();
/* 1125 */     double d2 = paramBaseTransform.getMxy();
/* 1126 */     double d3 = paramBaseTransform.getMxz();
/* 1127 */     double d4 = paramBaseTransform.getMxt();
/*      */     
/* 1129 */     double d5 = paramBaseTransform.getMyx();
/* 1130 */     double d6 = paramBaseTransform.getMyy();
/* 1131 */     double d7 = paramBaseTransform.getMyz();
/* 1132 */     double d8 = paramBaseTransform.getMyt();
/*      */     
/* 1134 */     double d9 = paramBaseTransform.getMzx();
/* 1135 */     double d10 = paramBaseTransform.getMzy();
/* 1136 */     double d11 = paramBaseTransform.getMzz();
/* 1137 */     double d12 = paramBaseTransform.getMzt();
/* 1138 */     BaseTransform baseTransform1 = paramBaseTransform;
/* 1139 */     if (this.transform != null) baseTransform1 = baseTransform1.deriveWithConcatenation(this.transform);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1155 */     RectBounds rectBounds = paramRectBounds1;
/*      */ 
/*      */ 
/*      */     
/* 1159 */     DirtyRegionContainer dirtyRegionContainer = null;
/* 1160 */     BaseTransform baseTransform2 = null;
/* 1161 */     if (this.effectFilter != null) {
/*      */       try {
/* 1163 */         rectBounds = new RectBounds();
/* 1164 */         BaseBounds baseBounds = baseTransform1.inverseTransform(paramRectBounds1, TEMP_BOUNDS);
/* 1165 */         baseBounds.flattenInto(rectBounds);
/* 1166 */       } catch (NoninvertibleTransformException noninvertibleTransformException) {
/* 1167 */         return 1;
/*      */       } 
/*      */       
/* 1170 */       baseTransform2 = baseTransform1;
/* 1171 */       baseTransform1 = BaseTransform.IDENTITY_TRANSFORM;
/* 1172 */       dirtyRegionContainer = paramDirtyRegionContainer;
/* 1173 */       paramDirtyRegionContainer = paramDirtyRegionPool.checkOut();
/* 1174 */     } else if (this.clipNode != null) {
/* 1175 */       dirtyRegionContainer = paramDirtyRegionContainer;
/* 1176 */       rectBounds = new RectBounds();
/* 1177 */       BaseBounds baseBounds = this.clipNode.getCompleteBounds(rectBounds, baseTransform1);
/* 1178 */       paramGeneralTransform3D.transform(baseBounds, baseBounds);
/* 1179 */       baseBounds.flattenInto(rectBounds);
/* 1180 */       rectBounds.intersectWith(paramRectBounds1);
/* 1181 */       paramDirtyRegionContainer = paramDirtyRegionPool.checkOut();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1186 */     List<NGNode> list1 = ((NGGroup)this).getRemovedChildren();
/* 1187 */     if (list1 != null)
/*      */     {
/* 1189 */       for (int k = list1.size() - 1; k >= 0; k--) {
/* 1190 */         NGNode nGNode = list1.get(k);
/* 1191 */         nGNode.dirty = DirtyFlag.DIRTY;
/* 1192 */         i = nGNode.accumulateDirtyRegions(rectBounds, paramRectBounds2, paramDirtyRegionPool, paramDirtyRegionContainer, baseTransform1, paramGeneralTransform3D);
/*      */         
/* 1194 */         if (i == 0) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 1200 */     List<NGNode> list2 = ((NGGroup)this).getChildren();
/* 1201 */     int j = list2.size();
/* 1202 */     for (byte b = 0; b < j && i == 1; b++) {
/* 1203 */       NGNode nGNode = list2.get(b);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1208 */       i = nGNode.accumulateDirtyRegions(rectBounds, paramRectBounds2, paramDirtyRegionPool, paramDirtyRegionContainer, baseTransform1, paramGeneralTransform3D);
/*      */       
/* 1210 */       if (i == 0) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/* 1215 */     if (this.effectFilter != null && i == 1) {
/*      */       
/* 1217 */       applyEffect(this.effectFilter, paramDirtyRegionContainer, paramDirtyRegionPool);
/*      */       
/* 1219 */       if (this.clipNode != null) {
/* 1220 */         rectBounds = new RectBounds();
/* 1221 */         BaseBounds baseBounds = this.clipNode.getCompleteBounds(rectBounds, baseTransform1);
/* 1222 */         applyClip(baseBounds, paramDirtyRegionContainer);
/*      */       } 
/*      */ 
/*      */       
/* 1226 */       applyTransform(baseTransform2, paramDirtyRegionContainer);
/* 1227 */       baseTransform1 = baseTransform2;
/*      */       
/* 1229 */       dirtyRegionContainer.merge(paramDirtyRegionContainer);
/* 1230 */       paramDirtyRegionPool.checkIn(paramDirtyRegionContainer);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1236 */     if (baseTransform1 == paramBaseTransform) {
/* 1237 */       paramBaseTransform.restoreTransform(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1246 */     if (this.clipNode != null && this.effectFilter == null) {
/* 1247 */       if (i == 0) {
/* 1248 */         i = accumulateNodeDirtyRegion(paramRectBounds1, paramRectBounds2, dirtyRegionContainer, paramBaseTransform, paramGeneralTransform3D);
/*      */       } else {
/* 1250 */         dirtyRegionContainer.merge(paramDirtyRegionContainer);
/*      */       } 
/* 1252 */       paramDirtyRegionPool.checkIn(paramDirtyRegionContainer);
/*      */     } 
/* 1254 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BaseBounds computeDirtyRegion(RectBounds paramRectBounds, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 1274 */     if (this.cacheFilter != null) {
/* 1275 */       return this.cacheFilter.computeDirtyBounds(paramRectBounds, paramBaseTransform, paramGeneralTransform3D);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1283 */     BaseBounds baseBounds = paramRectBounds;
/* 1284 */     if (!this.dirtyBounds.isEmpty()) {
/* 1285 */       baseBounds = baseBounds.deriveWithNewBounds(this.dirtyBounds);
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 1293 */       baseBounds = baseBounds.deriveWithNewBounds(this.transformedBounds);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1298 */     if (!baseBounds.isEmpty()) {
/*      */ 
/*      */ 
/*      */       
/* 1302 */       baseBounds = computePadding(baseBounds);
/* 1303 */       baseBounds = paramBaseTransform.transform(baseBounds, baseBounds);
/* 1304 */       baseBounds = paramGeneralTransform3D.transform(baseBounds, baseBounds);
/*      */     } 
/* 1306 */     return baseBounds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BaseBounds computePadding(BaseBounds paramBaseBounds) {
/* 1315 */     return paramBaseBounds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasVisuals() {
/* 1325 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void doPreCulling(DirtyRegionContainer paramDirtyRegionContainer, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 1342 */     if (paramDirtyRegionContainer == null || paramBaseTransform == null || paramGeneralTransform3D == null) throw new NullPointerException(); 
/* 1343 */     markCullRegions(paramDirtyRegionContainer, -1, paramBaseTransform, paramGeneralTransform3D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void markCullRegions(DirtyRegionContainer paramDirtyRegionContainer, int paramInt, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 1372 */     if (paramBaseTransform.isIdentity()) {
/* 1373 */       TEMP_BOUNDS.deriveWithNewBounds(this.transformedBounds);
/*      */     } else {
/* 1375 */       paramBaseTransform.transform(this.transformedBounds, TEMP_BOUNDS);
/*      */     } 
/*      */     
/* 1378 */     if (!paramGeneralTransform3D.isIdentity()) {
/* 1379 */       paramGeneralTransform3D.transform(TEMP_BOUNDS, TEMP_BOUNDS);
/*      */     }
/*      */     
/* 1382 */     TEMP_BOUNDS.flattenInto(TEMP_RECT_BOUNDS);
/*      */     
/* 1384 */     this.cullingBits = 0;
/*      */     
/* 1386 */     int i = 1;
/* 1387 */     for (byte b = 0; b < paramDirtyRegionContainer.size(); b++) {
/* 1388 */       RectBounds rectBounds = paramDirtyRegionContainer.getDirtyRegion(b);
/* 1389 */       if (rectBounds == null || rectBounds.isEmpty()) {
/*      */         break;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1398 */       if ((paramInt == -1 || (paramInt & i) != 0) && rectBounds
/* 1399 */         .intersects(TEMP_RECT_BOUNDS)) {
/* 1400 */         byte b1 = 1;
/* 1401 */         if (rectBounds.contains(TEMP_RECT_BOUNDS)) {
/* 1402 */           b1 = 2;
/*      */         }
/* 1404 */         this.cullingBits |= b1 << 2 * b;
/*      */       } 
/* 1406 */       i <<= 2;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1411 */     if (this.cullingBits == 0 && (this.dirty != DirtyFlag.CLEAN || this.childDirty)) {
/* 1412 */       clearDirtyTree();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void printDirtyOpts(StringBuilder paramStringBuilder, List<NGNode> paramList) {
/* 1429 */     paramStringBuilder.append("\n*=Render Root\n");
/* 1430 */     paramStringBuilder.append("d=Dirty\n");
/* 1431 */     paramStringBuilder.append("dt=Dirty By Translation\n");
/* 1432 */     paramStringBuilder.append("i=Dirty Region Intersects the NGNode\n");
/* 1433 */     paramStringBuilder.append("c=Dirty Region Contains the NGNode\n");
/* 1434 */     paramStringBuilder.append("ef=Effect Filter\n");
/* 1435 */     paramStringBuilder.append("cf=Cache Filter\n");
/* 1436 */     paramStringBuilder.append("cl=This node is a clip node\n");
/* 1437 */     paramStringBuilder.append("b=Blend mode is set\n");
/* 1438 */     paramStringBuilder.append("or=Opaque Region\n");
/* 1439 */     printDirtyOpts(paramStringBuilder, this, BaseTransform.IDENTITY_TRANSFORM, "", paramList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void printDirtyOpts(StringBuilder paramStringBuilder, NGNode paramNGNode, BaseTransform paramBaseTransform, String paramString, List<NGNode> paramList) {
/* 1453 */     if (!paramNGNode.isVisible() || paramNGNode.getOpacity() == 0.0F)
/*      */       return; 
/* 1455 */     BaseTransform baseTransform = paramBaseTransform.copy();
/* 1456 */     baseTransform = baseTransform.deriveWithConcatenation(paramNGNode.getTransform());
/* 1457 */     ArrayList<String> arrayList = new ArrayList(); int i;
/* 1458 */     for (i = 0; i < paramList.size(); i++) {
/* 1459 */       NGNode nGNode = paramList.get(i);
/* 1460 */       if (paramNGNode == nGNode) arrayList.add("*" + i);
/*      */     
/*      */     } 
/* 1463 */     if (paramNGNode.dirty != DirtyFlag.CLEAN) {
/* 1464 */       arrayList.add((paramNGNode.dirty == DirtyFlag.DIRTY) ? "d" : "dt");
/*      */     }
/*      */     
/* 1467 */     if (paramNGNode.cullingBits != 0) {
/* 1468 */       i = 17;
/* 1469 */       for (byte b = 0; b < 15; b++) {
/* 1470 */         int j = paramNGNode.cullingBits & i;
/* 1471 */         if (j != 0) {
/* 1472 */           arrayList.add((j == 1) ? ("i" + b) : ((j == 0) ? ("c" + b) : ("ci" + b)));
/*      */         }
/* 1474 */         i <<= 2;
/*      */       } 
/*      */     } 
/*      */     
/* 1478 */     if (paramNGNode.effectFilter != null) arrayList.add("ef"); 
/* 1479 */     if (paramNGNode.cacheFilter != null) arrayList.add("cf"); 
/* 1480 */     if (paramNGNode.nodeBlendMode != null) arrayList.add("b");
/*      */     
/* 1482 */     RectBounds rectBounds = paramNGNode.getOpaqueRegion();
/* 1483 */     if (rectBounds != null) {
/* 1484 */       RectBounds rectBounds1 = new RectBounds();
/* 1485 */       baseTransform.transform(rectBounds, rectBounds1);
/* 1486 */       arrayList.add("or=" + rectBounds1.getMinX() + ", " + rectBounds1.getMinY() + ", " + rectBounds1.getWidth() + ", " + rectBounds1.getHeight());
/*      */     } 
/*      */     
/* 1489 */     if (arrayList.isEmpty()) {
/* 1490 */       paramStringBuilder.append(paramString + paramString + "\n");
/*      */     } else {
/* 1492 */       String str = " [";
/* 1493 */       for (byte b = 0; b < arrayList.size(); b++) {
/* 1494 */         str = str + str;
/* 1495 */         if (b < arrayList.size() - 1) str = str + " "; 
/*      */       } 
/* 1497 */       paramStringBuilder.append(paramString + paramString + paramNGNode.name + "]\n");
/*      */     } 
/*      */     
/* 1500 */     if (paramNGNode.getClipNode() != null) {
/* 1501 */       printDirtyOpts(paramStringBuilder, paramNGNode.getClipNode(), baseTransform, paramString + "  cl ", paramList);
/*      */     }
/*      */     
/* 1504 */     if (paramNGNode instanceof NGGroup) {
/* 1505 */       NGGroup nGGroup = (NGGroup)paramNGNode;
/* 1506 */       for (byte b = 0; b < nGGroup.getChildren().size(); b++) {
/* 1507 */         printDirtyOpts(paramStringBuilder, nGGroup.getChildren().get(b), baseTransform, paramString + "  ", paramList);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawDirtyOpts(BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D, Rectangle paramRectangle, int[] paramArrayOfint, int paramInt) {
/* 1526 */     if ((this.painted & 1 << paramInt * 2) != 0) {
/*      */       
/* 1528 */       paramBaseTransform.copy().deriveWithConcatenation(getTransform()).transform(this.contentBounds, TEMP_BOUNDS);
/* 1529 */       if (paramGeneralTransform3D != null) paramGeneralTransform3D.transform(TEMP_BOUNDS, TEMP_BOUNDS); 
/* 1530 */       RectBounds rectBounds = new RectBounds();
/* 1531 */       TEMP_BOUNDS.flattenInto(rectBounds);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1537 */       assert paramRectangle.width * paramRectangle.height == paramArrayOfint.length;
/* 1538 */       rectBounds.intersectWith(paramRectangle);
/* 1539 */       int i = (int)rectBounds.getMinX() - paramRectangle.x;
/* 1540 */       int j = (int)rectBounds.getMinY() - paramRectangle.y;
/* 1541 */       int k = (int)(rectBounds.getWidth() + 0.5D);
/* 1542 */       int m = (int)(rectBounds.getHeight() + 0.5D);
/*      */       
/* 1544 */       if (k == 0 || m == 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1552 */       for (int n = j; n < j + m; n++) {
/* 1553 */         for (int i1 = i; i1 < i + k; i1++) {
/* 1554 */           int i2 = n * paramRectangle.width + i1;
/* 1555 */           int i3 = paramArrayOfint[i2];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1564 */           if (i3 == 0) {
/* 1565 */             i3 = 134250240;
/* 1566 */           } else if ((this.painted & 3 << paramInt * 2) == 3) {
/* 1567 */             switch (i3) {
/*      */               case -2147451136:
/* 1569 */                 i3 = -2147450880;
/*      */                 break;
/*      */               case -2147450880:
/* 1572 */                 i3 = -2139128064;
/*      */                 break;
/*      */               case -2139128064:
/* 1575 */                 i3 = -2139062272;
/*      */                 break;
/*      */               case -2139062272:
/* 1578 */                 i3 = -2139160576;
/*      */                 break;
/*      */               default:
/* 1581 */                 i3 = -2139095040; break;
/*      */             } 
/*      */           } 
/* 1584 */           paramArrayOfint[i2] = i3;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected enum RenderRootResult
/*      */   {
/* 1604 */     NO_RENDER_ROOT,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1610 */     HAS_RENDER_ROOT,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1622 */     HAS_RENDER_ROOT_AND_IS_CLEAN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void getRenderRoot(NodePath paramNodePath, RectBounds paramRectBounds, int paramInt, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 1639 */     if (paramNodePath == null || paramRectBounds == null || paramBaseTransform == null || paramGeneralTransform3D == null) {
/* 1640 */       throw new NullPointerException();
/*      */     }
/* 1642 */     if (paramInt < -1 || paramInt > 15) {
/* 1643 */       throw new IllegalArgumentException("cullingIndex cannot be < -1 or > 15");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1649 */     RenderRootResult renderRootResult = computeRenderRoot(paramNodePath, paramRectBounds, paramInt, paramBaseTransform, paramGeneralTransform3D);
/* 1650 */     if (renderRootResult == RenderRootResult.NO_RENDER_ROOT) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1655 */       paramNodePath.add(this);
/* 1656 */     } else if (renderRootResult == RenderRootResult.HAS_RENDER_ROOT_AND_IS_CLEAN) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1661 */       paramNodePath.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RenderRootResult computeRenderRoot(NodePath paramNodePath, RectBounds paramRectBounds, int paramInt, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 1679 */     return computeNodeRenderRoot(paramNodePath, paramRectBounds, paramInt, paramBaseTransform, paramGeneralTransform3D);
/*      */   }
/*      */   
/* 1682 */   private static Point2D[] TEMP_POINTS2D_4 = new Point2D[] { new Point2D(), new Point2D(), new Point2D(), new Point2D() };
/*      */ 
/*      */ 
/*      */   
/*      */   private static int ccw(double paramDouble1, double paramDouble2, Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 1687 */     return (int)Math.signum((paramPoint2D2.x - paramPoint2D1.x) * (paramDouble2 - paramPoint2D1.y) - (paramPoint2D2.y - paramPoint2D1.y) * (paramDouble1 - paramPoint2D1.x));
/*      */   }
/*      */   
/*      */   private static boolean pointInConvexQuad(double paramDouble1, double paramDouble2, Point2D[] paramArrayOfPoint2D) {
/* 1691 */     int i = ccw(paramDouble1, paramDouble2, paramArrayOfPoint2D[0], paramArrayOfPoint2D[1]);
/* 1692 */     int j = ccw(paramDouble1, paramDouble2, paramArrayOfPoint2D[1], paramArrayOfPoint2D[2]);
/* 1693 */     int k = ccw(paramDouble1, paramDouble2, paramArrayOfPoint2D[2], paramArrayOfPoint2D[3]);
/* 1694 */     int m = ccw(paramDouble1, paramDouble2, paramArrayOfPoint2D[3], paramArrayOfPoint2D[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1700 */     i ^= i >>> 1;
/* 1701 */     j ^= j >>> 1;
/* 1702 */     k ^= k >>> 1;
/* 1703 */     m ^= m >>> 1;
/*      */     
/* 1705 */     int n = i | j | k | m;
/*      */     
/* 1707 */     return (n == Integer.MIN_VALUE || n == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final RenderRootResult computeNodeRenderRoot(NodePath paramNodePath, RectBounds paramRectBounds, int paramInt, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 1729 */     if (paramInt != -1) {
/* 1730 */       int i = this.cullingBits >> paramInt * 2;
/* 1731 */       if ((i & 0x3) == 0) {
/* 1732 */         return RenderRootResult.NO_RENDER_ROOT;
/*      */       }
/*      */     } 
/*      */     
/* 1736 */     if (!isVisible()) {
/* 1737 */       return RenderRootResult.NO_RENDER_ROOT;
/*      */     }
/*      */     
/* 1740 */     RectBounds rectBounds = getOpaqueRegion();
/* 1741 */     if (rectBounds == null) return RenderRootResult.NO_RENDER_ROOT;
/*      */     
/* 1743 */     BaseTransform baseTransform = getTransform();
/*      */     
/* 1745 */     Affine3D affine3D = TEMP_TRANSFORM.deriveWithNewTransform(paramBaseTransform).deriveWithConcatenation(baseTransform);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1752 */     if (checkBoundsInQuad(rectBounds, paramRectBounds, affine3D, paramGeneralTransform3D)) {
/*      */       
/* 1754 */       paramNodePath.add(this);
/* 1755 */       return isClean() ? RenderRootResult.HAS_RENDER_ROOT_AND_IS_CLEAN : RenderRootResult.HAS_RENDER_ROOT;
/*      */     } 
/*      */     
/* 1758 */     return RenderRootResult.NO_RENDER_ROOT;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean checkBoundsInQuad(RectBounds paramRectBounds1, RectBounds paramRectBounds2, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 1764 */     if (paramGeneralTransform3D.isIdentity() && (paramBaseTransform.getType() & 0xFFFFFFF0) == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1769 */       if (paramBaseTransform.isIdentity()) {
/* 1770 */         TEMP_BOUNDS.deriveWithNewBounds(paramRectBounds1);
/*      */       } else {
/* 1772 */         paramBaseTransform.transform(paramRectBounds1, TEMP_BOUNDS);
/*      */       } 
/*      */       
/* 1775 */       TEMP_BOUNDS.flattenInto(TEMP_RECT_BOUNDS);
/*      */       
/* 1777 */       return TEMP_RECT_BOUNDS.contains(paramRectBounds2);
/*      */     } 
/* 1779 */     TEMP_POINTS2D_4[0].setLocation(paramRectBounds1.getMinX(), paramRectBounds1.getMinY());
/* 1780 */     TEMP_POINTS2D_4[1].setLocation(paramRectBounds1.getMaxX(), paramRectBounds1.getMinY());
/* 1781 */     TEMP_POINTS2D_4[2].setLocation(paramRectBounds1.getMaxX(), paramRectBounds1.getMaxY());
/* 1782 */     TEMP_POINTS2D_4[3].setLocation(paramRectBounds1.getMinX(), paramRectBounds1.getMaxY());
/*      */     
/* 1784 */     for (Point2D point2D : TEMP_POINTS2D_4) {
/* 1785 */       paramBaseTransform.transform(point2D, point2D);
/* 1786 */       if (!paramGeneralTransform3D.isIdentity()) {
/* 1787 */         paramGeneralTransform3D.transform(point2D, point2D);
/*      */       }
/*      */     } 
/*      */     
/* 1791 */     return (pointInConvexQuad(paramRectBounds2.getMinX(), paramRectBounds2.getMinY(), TEMP_POINTS2D_4) && 
/* 1792 */       pointInConvexQuad(paramRectBounds2.getMaxX(), paramRectBounds2.getMinY(), TEMP_POINTS2D_4) && 
/* 1793 */       pointInConvexQuad(paramRectBounds2.getMaxX(), paramRectBounds2.getMaxY(), TEMP_POINTS2D_4) && 
/* 1794 */       pointInConvexQuad(paramRectBounds2.getMinX(), paramRectBounds2.getMaxY(), TEMP_POINTS2D_4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void invalidateOpaqueRegion() {
/* 1805 */     this.opaqueRegionInvalid = true;
/* 1806 */     if (this.isClip) this.parent.invalidateOpaqueRegion();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isOpaqueRegionInvalid() {
/* 1814 */     return this.opaqueRegionInvalid;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final RectBounds getOpaqueRegion() {
/* 1836 */     if (this.opaqueRegionInvalid || getEffect() != null) {
/* 1837 */       this.opaqueRegionInvalid = false;
/* 1838 */       if (supportsOpaqueRegions() && hasOpaqueRegion()) {
/* 1839 */         this.opaqueRegion = computeOpaqueRegion((this.opaqueRegion == null) ? new RectBounds() : this.opaqueRegion);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1845 */         assert this.opaqueRegion != null;
/* 1846 */         if (this.opaqueRegion == null) {
/* 1847 */           return null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1853 */         NGNode nGNode = getClipNode();
/* 1854 */         if (nGNode != null) {
/* 1855 */           RectBounds rectBounds = nGNode.getOpaqueRegion();
/*      */ 
/*      */           
/* 1858 */           if (rectBounds == null || (nGNode.getTransform().getType() & 0xFFFFFFF8) != 0)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/* 1863 */             return this.opaqueRegion = null;
/*      */           }
/*      */ 
/*      */           
/* 1867 */           BaseBounds baseBounds = nGNode.getTransform().transform(rectBounds, TEMP_BOUNDS);
/* 1868 */           baseBounds.flattenInto(TEMP_RECT_BOUNDS);
/* 1869 */           this.opaqueRegion.intersectWith(TEMP_RECT_BOUNDS);
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1875 */         this.opaqueRegion = null;
/*      */       } 
/*      */     } 
/*      */     
/* 1879 */     return this.opaqueRegion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean supportsOpaqueRegions() {
/* 1893 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasOpaqueRegion() {
/* 1906 */     NGNode nGNode = getClipNode();
/* 1907 */     Effect effect = getEffect();
/* 1908 */     return ((effect == null || !effect.reducesOpaquePixels()) && 
/* 1909 */       getOpacity() == 1.0F && (this.nodeBlendMode == null || this.nodeBlendMode == Blend.Mode.SRC_OVER) && (nGNode == null || (nGNode
/*      */ 
/*      */       
/* 1912 */       .supportsOpaqueRegions() && nGNode.hasOpaqueRegion())));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RectBounds computeOpaqueRegion(RectBounds paramRectBounds) {
/* 1921 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isRectClip(BaseTransform paramBaseTransform, boolean paramBoolean) {
/* 1933 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void render(Graphics paramGraphics) {
/* 1953 */     if (PulseLogger.PULSE_LOGGING_ENABLED) {
/* 1954 */       PulseLogger.incrementCounter("Nodes visited during render");
/*      */     }
/*      */     
/* 1957 */     clearDirty();
/*      */     
/* 1959 */     if (!this.visible || this.opacity == 0.0F) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1964 */     doRender(paramGraphics);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void renderForcedContent(Graphics paramGraphics) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isShape3D() {
/* 1985 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRender(Graphics paramGraphics) {
/* 1994 */     paramGraphics.setState3D(isShape3D());
/*      */     
/* 1996 */     boolean bool1 = false;
/* 1997 */     if (PrismSettings.dirtyOptsEnabled && 
/* 1998 */       paramGraphics.hasPreCullingBits()) {
/*      */       
/* 2000 */       int i = this.cullingBits >> paramGraphics.getClipRectIndex() * 2;
/* 2001 */       if ((i & 0x3) == 0) {
/*      */         return;
/*      */       }
/*      */       
/* 2005 */       if ((i & 0x2) != 0) {
/*      */ 
/*      */ 
/*      */         
/* 2009 */         paramGraphics.setHasPreCullingBits(false);
/* 2010 */         bool1 = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2016 */     boolean bool = paramGraphics.isDepthTest();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2021 */     paramGraphics.setDepthTest(isDepthTest());
/*      */ 
/*      */     
/* 2024 */     BaseTransform baseTransform = paramGraphics.getTransformNoClone();
/*      */     
/* 2026 */     double d1 = baseTransform.getMxx();
/* 2027 */     double d2 = baseTransform.getMxy();
/* 2028 */     double d3 = baseTransform.getMxz();
/* 2029 */     double d4 = baseTransform.getMxt();
/*      */     
/* 2031 */     double d5 = baseTransform.getMyx();
/* 2032 */     double d6 = baseTransform.getMyy();
/* 2033 */     double d7 = baseTransform.getMyz();
/* 2034 */     double d8 = baseTransform.getMyt();
/*      */     
/* 2036 */     double d9 = baseTransform.getMzx();
/* 2037 */     double d10 = baseTransform.getMzy();
/* 2038 */     double d11 = baseTransform.getMzz();
/* 2039 */     double d12 = baseTransform.getMzt();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2050 */     paramGraphics.transform(getTransform());
/*      */ 
/*      */ 
/*      */     
/* 2054 */     boolean bool2 = false;
/*      */     
/* 2056 */     if (!isShape3D() && paramGraphics instanceof ReadbackGraphics && needsBlending()) {
/* 2057 */       renderNodeBlendMode(paramGraphics);
/* 2058 */       bool2 = true;
/* 2059 */     } else if (!isShape3D() && getOpacity() < 1.0F) {
/* 2060 */       renderOpacity(paramGraphics);
/* 2061 */       bool2 = true;
/* 2062 */     } else if (!isShape3D() && getCacheFilter() != null) {
/* 2063 */       renderCached(paramGraphics);
/* 2064 */       bool2 = true;
/* 2065 */     } else if (!isShape3D() && getClipNode() != null) {
/* 2066 */       renderClip(paramGraphics);
/* 2067 */       bool2 = true;
/* 2068 */     } else if (!isShape3D() && getEffectFilter() != null && effectsSupported.booleanValue()) {
/* 2069 */       renderEffect(paramGraphics);
/* 2070 */       bool2 = true;
/*      */     } else {
/* 2072 */       renderContent(paramGraphics);
/* 2073 */       if (PrismSettings.showOverdraw) {
/* 2074 */         bool2 = (this instanceof NGRegion || !(this instanceof NGGroup)) ? true : false;
/*      */       }
/*      */     } 
/*      */     
/* 2078 */     if (bool1) {
/* 2079 */       paramGraphics.setHasPreCullingBits(true);
/*      */     }
/*      */ 
/*      */     
/* 2083 */     paramGraphics.setTransform3D(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2088 */     paramGraphics.setDepthTest(bool);
/*      */     
/* 2090 */     if (PulseLogger.PULSE_LOGGING_ENABLED) {
/* 2091 */       PulseLogger.incrementCounter("Nodes rendered");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2098 */     if (PrismSettings.showOverdraw) {
/* 2099 */       if (bool2) {
/* 2100 */         this.painted |= 3 << paramGraphics.getClipRectIndex() * 2;
/*      */       } else {
/* 2102 */         this.painted |= 1 << paramGraphics.getClipRectIndex() * 2;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean needsBlending() {
/* 2117 */     Blend.Mode mode = getNodeBlendMode();
/* 2118 */     return (mode != null && mode != Blend.Mode.SRC_OVER);
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderNodeBlendMode(Graphics paramGraphics) {
/* 2123 */     BaseTransform baseTransform = paramGraphics.getTransformNoClone();
/*      */     
/* 2125 */     BaseBounds baseBounds = getClippedBounds(new RectBounds(), baseTransform);
/* 2126 */     if (baseBounds.isEmpty()) {
/* 2127 */       clearDirtyTree();
/*      */       
/*      */       return;
/*      */     } 
/* 2131 */     if (!isReadbackSupported(paramGraphics)) {
/* 2132 */       if (getOpacity() < 1.0F) {
/* 2133 */         renderOpacity(paramGraphics);
/* 2134 */       } else if (getClipNode() != null) {
/* 2135 */         renderClip(paramGraphics);
/*      */       } else {
/* 2137 */         renderContent(paramGraphics);
/*      */       } 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2144 */     Rectangle rectangle = new Rectangle(baseBounds);
/* 2145 */     rectangle.intersectWith(PrEffectHelper.getGraphicsClipNoClone(paramGraphics));
/*      */ 
/*      */     
/* 2148 */     FilterContext filterContext = getFilterContext(paramGraphics);
/*      */     
/* 2150 */     PrDrawable prDrawable1 = (PrDrawable)Effect.getCompatibleImage(filterContext, rectangle.width, rectangle.height);
/* 2151 */     if (prDrawable1 == null) {
/* 2152 */       clearDirtyTree();
/*      */       return;
/*      */     } 
/* 2155 */     Graphics graphics = prDrawable1.createGraphics();
/* 2156 */     graphics.setHasPreCullingBits(paramGraphics.hasPreCullingBits());
/* 2157 */     graphics.setClipRectIndex(paramGraphics.getClipRectIndex());
/* 2158 */     graphics.translate(-rectangle.x, -rectangle.y);
/* 2159 */     graphics.transform(baseTransform);
/* 2160 */     if (getOpacity() < 1.0F) {
/* 2161 */       renderOpacity(graphics);
/* 2162 */     } else if (getCacheFilter() != null) {
/* 2163 */       renderCached(graphics);
/* 2164 */     } else if (getClipNode() != null) {
/* 2165 */       renderClip(paramGraphics);
/* 2166 */     } else if (getEffectFilter() != null) {
/* 2167 */       renderEffect(graphics);
/*      */     } else {
/* 2169 */       renderContent(graphics);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2174 */     RTTexture rTTexture = ((ReadbackGraphics)paramGraphics).readBack(rectangle);
/* 2175 */     PrDrawable prDrawable2 = PrDrawable.create(filterContext, rTTexture);
/* 2176 */     Blend blend = new Blend(getNodeBlendMode(), new PassThrough(prDrawable2, rectangle), new PassThrough(prDrawable1, rectangle));
/*      */ 
/*      */     
/* 2179 */     CompositeMode compositeMode = paramGraphics.getCompositeMode();
/* 2180 */     paramGraphics.setTransform(null);
/* 2181 */     paramGraphics.setCompositeMode(CompositeMode.SRC);
/* 2182 */     PrEffectHelper.render(blend, paramGraphics, 0.0F, 0.0F, null);
/* 2183 */     paramGraphics.setCompositeMode(compositeMode);
/*      */ 
/*      */     
/* 2186 */     Effect.releaseCompatibleImage(filterContext, prDrawable1);
/* 2187 */     ((ReadbackGraphics)paramGraphics).releaseReadBackBuffer(rTTexture);
/*      */   }
/*      */   
/*      */   private void renderRectClip(Graphics paramGraphics, NGRectangle paramNGRectangle) {
/* 2191 */     BaseBounds baseBounds = paramNGRectangle.getShape().getBounds();
/* 2192 */     if (!paramNGRectangle.getTransform().isIdentity()) {
/* 2193 */       baseBounds = paramNGRectangle.getTransform().transform(baseBounds, baseBounds);
/*      */     }
/* 2195 */     BaseTransform baseTransform = paramGraphics.getTransformNoClone();
/* 2196 */     Rectangle rectangle = paramGraphics.getClipRectNoClone();
/* 2197 */     baseBounds = baseTransform.transform(baseBounds, baseBounds);
/* 2198 */     baseBounds.intersectWith(PrEffectHelper.getGraphicsClipNoClone(paramGraphics));
/* 2199 */     if (baseBounds.isEmpty() || baseBounds
/* 2200 */       .getWidth() == 0.0F || baseBounds
/* 2201 */       .getHeight() == 0.0F) {
/* 2202 */       clearDirtyTree();
/*      */       
/*      */       return;
/*      */     } 
/* 2206 */     paramGraphics.setClipRect(new Rectangle(baseBounds));
/* 2207 */     renderForClip(paramGraphics);
/* 2208 */     paramGraphics.setClipRect(rectangle);
/* 2209 */     paramNGRectangle.clearDirty();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void renderClip(Graphics paramGraphics) {
/* 2215 */     if (getClipNode().getOpacity() == 0.0D) {
/* 2216 */       clearDirtyTree();
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2221 */     BaseTransform baseTransform = paramGraphics.getTransformNoClone();
/*      */     
/* 2223 */     BaseBounds baseBounds = getClippedBounds(new RectBounds(), baseTransform);
/* 2224 */     if (baseBounds.isEmpty()) {
/* 2225 */       clearDirtyTree();
/*      */       
/*      */       return;
/*      */     } 
/* 2229 */     if (getClipNode() instanceof NGRectangle) {
/*      */       
/* 2231 */       NGRectangle nGRectangle = (NGRectangle)getClipNode();
/* 2232 */       if (nGRectangle.isRectClip(baseTransform, false)) {
/* 2233 */         renderRectClip(paramGraphics, nGRectangle);
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/* 2240 */     Rectangle rectangle = new Rectangle(baseBounds);
/* 2241 */     rectangle.intersectWith(PrEffectHelper.getGraphicsClipNoClone(paramGraphics));
/*      */     
/* 2243 */     if (!baseTransform.is2D()) {
/* 2244 */       Rectangle rectangle1 = paramGraphics.getClipRect();
/* 2245 */       paramGraphics.setClipRect(rectangle);
/*      */       
/* 2247 */       NodeEffectInput nodeEffectInput1 = new NodeEffectInput(getClipNode(), NodeEffectInput.RenderType.FULL_CONTENT);
/*      */       
/* 2249 */       NodeEffectInput nodeEffectInput2 = new NodeEffectInput(this, NodeEffectInput.RenderType.CLIPPED_CONTENT);
/*      */ 
/*      */       
/* 2252 */       Blend blend1 = new Blend(Blend.Mode.SRC_IN, nodeEffectInput1, nodeEffectInput2);
/* 2253 */       PrEffectHelper.render(blend1, paramGraphics, 0.0F, 0.0F, null);
/* 2254 */       nodeEffectInput1.flush();
/* 2255 */       nodeEffectInput2.flush();
/* 2256 */       paramGraphics.setClipRect(rectangle1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2263 */       clearDirtyTree();
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2268 */     FilterContext filterContext = getFilterContext(paramGraphics);
/*      */     
/* 2270 */     PrDrawable prDrawable1 = (PrDrawable)Effect.getCompatibleImage(filterContext, rectangle.width, rectangle.height);
/* 2271 */     if (prDrawable1 == null) {
/* 2272 */       clearDirtyTree();
/*      */       return;
/*      */     } 
/* 2275 */     Graphics graphics1 = prDrawable1.createGraphics();
/* 2276 */     graphics1.setExtraAlpha(paramGraphics.getExtraAlpha());
/* 2277 */     graphics1.setHasPreCullingBits(paramGraphics.hasPreCullingBits());
/* 2278 */     graphics1.setClipRectIndex(paramGraphics.getClipRectIndex());
/* 2279 */     graphics1.translate(-rectangle.x, -rectangle.y);
/* 2280 */     graphics1.transform(baseTransform);
/* 2281 */     renderForClip(graphics1);
/*      */ 
/*      */ 
/*      */     
/* 2285 */     PrDrawable prDrawable2 = (PrDrawable)Effect.getCompatibleImage(filterContext, rectangle.width, rectangle.height);
/* 2286 */     if (prDrawable2 == null) {
/* 2287 */       getClipNode().clearDirtyTree();
/* 2288 */       Effect.releaseCompatibleImage(filterContext, prDrawable1);
/*      */       return;
/*      */     } 
/* 2291 */     Graphics graphics2 = prDrawable2.createGraphics();
/* 2292 */     graphics2.translate(-rectangle.x, -rectangle.y);
/* 2293 */     graphics2.transform(baseTransform);
/* 2294 */     getClipNode().render(graphics2);
/*      */ 
/*      */ 
/*      */     
/* 2298 */     paramGraphics.setTransform(null);
/* 2299 */     Blend blend = new Blend(Blend.Mode.SRC_IN, new PassThrough(prDrawable2, rectangle), new PassThrough(prDrawable1, rectangle));
/*      */ 
/*      */     
/* 2302 */     PrEffectHelper.render(blend, paramGraphics, 0.0F, 0.0F, null);
/*      */ 
/*      */     
/* 2305 */     Effect.releaseCompatibleImage(filterContext, prDrawable1);
/* 2306 */     Effect.releaseCompatibleImage(filterContext, prDrawable2);
/*      */   }
/*      */   
/*      */   void renderForClip(Graphics paramGraphics) {
/* 2310 */     if (getEffectFilter() != null) {
/* 2311 */       renderEffect(paramGraphics);
/*      */     } else {
/* 2313 */       renderContent(paramGraphics);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void renderOpacity(Graphics paramGraphics) {
/* 2318 */     if (getEffectFilter() != null || 
/* 2319 */       getCacheFilter() != null || 
/* 2320 */       getClipNode() != null || 
/* 2321 */       !hasOverlappingContents()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2327 */       float f1 = paramGraphics.getExtraAlpha();
/* 2328 */       paramGraphics.setExtraAlpha(f1 * getOpacity());
/* 2329 */       if (getCacheFilter() != null) {
/* 2330 */         renderCached(paramGraphics);
/* 2331 */       } else if (getClipNode() != null) {
/* 2332 */         renderClip(paramGraphics);
/* 2333 */       } else if (getEffectFilter() != null) {
/* 2334 */         renderEffect(paramGraphics);
/*      */       } else {
/* 2336 */         renderContent(paramGraphics);
/*      */       } 
/* 2338 */       paramGraphics.setExtraAlpha(f1);
/*      */       
/*      */       return;
/*      */     } 
/* 2342 */     FilterContext filterContext = getFilterContext(paramGraphics);
/* 2343 */     BaseTransform baseTransform = paramGraphics.getTransformNoClone();
/* 2344 */     BaseBounds baseBounds = getContentBounds(new RectBounds(), baseTransform);
/* 2345 */     Rectangle rectangle = new Rectangle(baseBounds);
/* 2346 */     rectangle.intersectWith(PrEffectHelper.getGraphicsClipNoClone(paramGraphics));
/*      */     
/* 2348 */     PrDrawable prDrawable = (PrDrawable)Effect.getCompatibleImage(filterContext, rectangle.width, rectangle.height);
/* 2349 */     if (prDrawable == null) {
/*      */       return;
/*      */     }
/* 2352 */     Graphics graphics = prDrawable.createGraphics();
/* 2353 */     graphics.setHasPreCullingBits(paramGraphics.hasPreCullingBits());
/* 2354 */     graphics.setClipRectIndex(paramGraphics.getClipRectIndex());
/* 2355 */     graphics.translate(-rectangle.x, -rectangle.y);
/* 2356 */     graphics.transform(baseTransform);
/* 2357 */     renderContent(graphics);
/*      */ 
/*      */     
/* 2360 */     paramGraphics.setTransform(null);
/* 2361 */     float f = paramGraphics.getExtraAlpha();
/* 2362 */     paramGraphics.setExtraAlpha(getOpacity() * f);
/* 2363 */     paramGraphics.drawTexture(prDrawable.getTextureObject(), rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/* 2364 */     paramGraphics.setExtraAlpha(f);
/*      */     
/* 2366 */     Effect.releaseCompatibleImage(filterContext, prDrawable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderCached(Graphics paramGraphics) {
/* 2375 */     if (isContentBounds2D() && paramGraphics.getTransformNoClone().is2D() && !(paramGraphics instanceof com.sun.prism.PrinterGraphics)) {
/*      */       
/* 2377 */       getCacheFilter().render(paramGraphics);
/*      */     } else {
/* 2379 */       renderContent(paramGraphics);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void renderEffect(Graphics paramGraphics) {
/* 2384 */     getEffectFilter().render(paramGraphics);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void renderContent(Graphics paramGraphics);
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract boolean hasOverlappingContents();
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isReadbackSupported(Graphics paramGraphics) {
/* 2398 */     return (paramGraphics instanceof ReadbackGraphics && ((ReadbackGraphics)paramGraphics)
/* 2399 */       .canReadBack());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static FilterContext getFilterContext(Graphics paramGraphics) {
/* 2409 */     Screen screen = paramGraphics.getAssociatedScreen();
/* 2410 */     if (screen == null) {
/* 2411 */       return PrFilterContext.getPrinterContext(paramGraphics.getResourceFactory());
/*      */     }
/* 2413 */     return PrFilterContext.getInstance(screen);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class PassThrough
/*      */     extends Effect
/*      */   {
/*      */     private PrDrawable img;
/*      */ 
/*      */     
/*      */     private Rectangle bounds;
/*      */ 
/*      */ 
/*      */     
/*      */     PassThrough(PrDrawable param1PrDrawable, Rectangle param1Rectangle) {
/* 2429 */       this.img = param1PrDrawable;
/* 2430 */       this.bounds = param1Rectangle;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImageData filter(FilterContext param1FilterContext, BaseTransform param1BaseTransform, Rectangle param1Rectangle, Object param1Object, Effect param1Effect) {
/* 2440 */       this.img.lock();
/* 2441 */       ImageData imageData = new ImageData(param1FilterContext, this.img, new Rectangle(this.bounds));
/* 2442 */       imageData.setReusable(true);
/* 2443 */       return imageData;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public RectBounds getBounds(BaseTransform param1BaseTransform, Effect param1Effect) {
/* 2450 */       return new RectBounds(this.bounds);
/*      */     }
/*      */ 
/*      */     
/*      */     public Effect.AccelType getAccelType(FilterContext param1FilterContext) {
/* 2455 */       return Effect.AccelType.INTRINSIC;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean reducesOpaquePixels() {
/* 2460 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public DirtyRegionContainer getDirtyRegions(Effect param1Effect, DirtyRegionPool param1DirtyRegionPool) {
/* 2465 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void release() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2479 */     return (this.name == null) ? super.toString() : this.name;
/*      */   }
/*      */   
/*      */   public void applyTransform(BaseTransform paramBaseTransform, DirtyRegionContainer paramDirtyRegionContainer) {
/* 2483 */     for (byte b = 0; b < paramDirtyRegionContainer.size(); b++) {
/* 2484 */       paramDirtyRegionContainer.setDirtyRegion(b, (RectBounds)paramBaseTransform.transform(paramDirtyRegionContainer.getDirtyRegion(b), paramDirtyRegionContainer.getDirtyRegion(b)));
/* 2485 */       if (paramDirtyRegionContainer.checkAndClearRegion(b)) {
/* 2486 */         b--;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public void applyClip(BaseBounds paramBaseBounds, DirtyRegionContainer paramDirtyRegionContainer) {
/* 2492 */     for (byte b = 0; b < paramDirtyRegionContainer.size(); b++) {
/* 2493 */       paramDirtyRegionContainer.getDirtyRegion(b).intersectWith(paramBaseBounds);
/* 2494 */       if (paramDirtyRegionContainer.checkAndClearRegion(b)) {
/* 2495 */         b--;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public void applyEffect(EffectFilter paramEffectFilter, DirtyRegionContainer paramDirtyRegionContainer, DirtyRegionPool paramDirtyRegionPool) {
/* 2501 */     Effect effect = paramEffectFilter.getEffect();
/* 2502 */     EffectDirtyBoundsHelper effectDirtyBoundsHelper = EffectDirtyBoundsHelper.getInstance();
/* 2503 */     effectDirtyBoundsHelper.setInputBounds(this.contentBounds);
/* 2504 */     effectDirtyBoundsHelper.setDirtyRegions(paramDirtyRegionContainer);
/* 2505 */     DirtyRegionContainer dirtyRegionContainer = effect.getDirtyRegions(effectDirtyBoundsHelper, paramDirtyRegionPool);
/* 2506 */     paramDirtyRegionContainer.deriveWithNewContainer(dirtyRegionContainer);
/* 2507 */     paramDirtyRegionPool.checkIn(dirtyRegionContainer);
/*      */   }
/*      */   
/*      */   private static class EffectDirtyBoundsHelper extends Effect {
/*      */     private BaseBounds bounds;
/* 2512 */     private static EffectDirtyBoundsHelper instance = null;
/*      */     private DirtyRegionContainer drc;
/*      */     
/*      */     public void setInputBounds(BaseBounds param1BaseBounds) {
/* 2516 */       this.bounds = param1BaseBounds;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImageData filter(FilterContext param1FilterContext, BaseTransform param1BaseTransform, Rectangle param1Rectangle, Object param1Object, Effect param1Effect) {
/* 2525 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public BaseBounds getBounds(BaseTransform param1BaseTransform, Effect param1Effect) {
/* 2530 */       if (this.bounds.getBoundsType() == BaseBounds.BoundsType.RECTANGLE) {
/* 2531 */         return this.bounds;
/*      */       }
/*      */       
/* 2534 */       return new RectBounds(this.bounds.getMinX(), this.bounds.getMinY(), this.bounds.getMaxX(), this.bounds.getMaxY());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Effect.AccelType getAccelType(FilterContext param1FilterContext) {
/* 2540 */       return null;
/*      */     }
/*      */     
/*      */     public static EffectDirtyBoundsHelper getInstance() {
/* 2544 */       if (instance == null) {
/* 2545 */         instance = new EffectDirtyBoundsHelper();
/*      */       }
/* 2547 */       return instance;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean reducesOpaquePixels() {
/* 2552 */       return true;
/*      */     }
/*      */     
/*      */     private void setDirtyRegions(DirtyRegionContainer param1DirtyRegionContainer) {
/* 2556 */       this.drc = param1DirtyRegionContainer;
/*      */     }
/*      */ 
/*      */     
/*      */     public DirtyRegionContainer getDirtyRegions(Effect param1Effect, DirtyRegionPool param1DirtyRegionPool) {
/* 2561 */       DirtyRegionContainer dirtyRegionContainer = param1DirtyRegionPool.checkOut();
/* 2562 */       dirtyRegionContainer.deriveWithNewContainer(this.drc);
/*      */       
/* 2564 */       return dirtyRegionContainer;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGNode.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */