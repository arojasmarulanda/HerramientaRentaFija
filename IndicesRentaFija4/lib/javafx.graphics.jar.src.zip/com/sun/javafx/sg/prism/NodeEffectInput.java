/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.DirtyRegionContainer;
/*     */ import com.sun.javafx.geom.DirtyRegionPool;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.scenario.effect.Effect;
/*     */ import com.sun.scenario.effect.FilterContext;
/*     */ import com.sun.scenario.effect.ImageData;
/*     */ import com.sun.scenario.effect.impl.prism.PrDrawable;
/*     */ import com.sun.scenario.effect.impl.prism.PrRenderInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NodeEffectInput
/*     */   extends Effect
/*     */ {
/*     */   private NGNode node;
/*     */   private RenderType renderType;
/*     */   
/*     */   public enum RenderType
/*     */   {
/*  45 */     EFFECT_CONTENT,
/*  46 */     CLIPPED_CONTENT,
/*  47 */     FULL_CONTENT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  52 */   private BaseBounds tempBounds = new RectBounds();
/*     */   
/*     */   private ImageData cachedIdentityImageData;
/*     */   private ImageData cachedTransformedImageData;
/*     */   private BaseTransform cachedTransform;
/*     */   
/*     */   public NodeEffectInput(NGNode paramNGNode) {
/*  59 */     this(paramNGNode, RenderType.EFFECT_CONTENT);
/*     */   }
/*     */   
/*     */   public NodeEffectInput(NGNode paramNGNode, RenderType paramRenderType) {
/*  63 */     this.node = paramNGNode;
/*  64 */     this.renderType = paramRenderType;
/*     */   }
/*     */   
/*     */   public NGNode getNode() {
/*  68 */     return this.node;
/*     */   }
/*     */   
/*     */   public void setNode(NGNode paramNGNode) {
/*  72 */     if (this.node != paramNGNode) {
/*  73 */       this.node = paramNGNode;
/*  74 */       flush();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean contains(ImageData paramImageData, Rectangle paramRectangle) {
/*  80 */     Rectangle rectangle = paramImageData.getUntransformedBounds();
/*  81 */     return rectangle.contains(paramRectangle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseBounds getBounds(BaseTransform paramBaseTransform, Effect paramEffect) {
/*  91 */     BaseTransform baseTransform = (paramBaseTransform == null) ? BaseTransform.IDENTITY_TRANSFORM : paramBaseTransform;
/*  92 */     this.tempBounds = this.node.getContentBounds(this.tempBounds, baseTransform);
/*  93 */     return this.tempBounds.copy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageData filter(FilterContext paramFilterContext, BaseTransform paramBaseTransform, Rectangle paramRectangle, Object paramObject, Effect paramEffect) {
/* 103 */     if (paramObject instanceof PrRenderInfo) {
/* 104 */       Graphics graphics = ((PrRenderInfo)paramObject).getGraphics();
/* 105 */       if (graphics != null) {
/* 106 */         render(graphics, paramBaseTransform);
/* 107 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 111 */     Rectangle rectangle = getImageBoundsForNode(this.node, this.renderType, paramBaseTransform, paramRectangle);
/* 112 */     if (paramBaseTransform.isIdentity()) {
/* 113 */       if (this.cachedIdentityImageData != null && 
/* 114 */         contains(this.cachedIdentityImageData, rectangle) && this.cachedIdentityImageData
/* 115 */         .validate(paramFilterContext)) {
/*     */         
/* 117 */         this.cachedIdentityImageData.addref();
/* 118 */         return this.cachedIdentityImageData;
/*     */       } 
/* 120 */     } else if (this.cachedTransformedImageData != null && 
/* 121 */       contains(this.cachedTransformedImageData, rectangle) && this.cachedTransformedImageData
/* 122 */       .validate(paramFilterContext) && this.cachedTransform
/* 123 */       .equals(paramBaseTransform)) {
/*     */       
/* 125 */       this.cachedTransformedImageData.addref();
/* 126 */       return this.cachedTransformedImageData;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 131 */     ImageData imageData = getImageDataForBoundedNode(paramFilterContext, this.node, this.renderType, paramBaseTransform, rectangle);
/* 132 */     if (paramBaseTransform.isIdentity()) {
/* 133 */       flushIdentityImage();
/* 134 */       this.cachedIdentityImageData = imageData;
/* 135 */       this.cachedIdentityImageData.addref();
/*     */     } else {
/* 137 */       flushTransformedImage();
/* 138 */       this.cachedTransform = paramBaseTransform.copy();
/* 139 */       this.cachedTransformedImageData = imageData;
/* 140 */       this.cachedTransformedImageData.addref();
/*     */     } 
/* 142 */     return imageData;
/*     */   }
/*     */ 
/*     */   
/*     */   public Effect.AccelType getAccelType(FilterContext paramFilterContext) {
/* 147 */     return Effect.AccelType.INTRINSIC;
/*     */   }
/*     */   
/*     */   public void flushIdentityImage() {
/* 151 */     if (this.cachedIdentityImageData != null) {
/* 152 */       this.cachedIdentityImageData.unref();
/* 153 */       this.cachedIdentityImageData = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void flushTransformedImage() {
/* 158 */     if (this.cachedTransformedImageData != null) {
/* 159 */       this.cachedTransformedImageData.unref();
/* 160 */       this.cachedTransformedImageData = null;
/*     */     } 
/* 162 */     this.cachedTransform = null;
/*     */   }
/*     */   
/*     */   public void flush() {
/* 166 */     flushIdentityImage();
/* 167 */     flushTransformedImage();
/*     */   }
/*     */   
/*     */   public void render(Graphics paramGraphics, BaseTransform paramBaseTransform) {
/* 171 */     BaseTransform baseTransform = null;
/* 172 */     if (!paramBaseTransform.isIdentity()) {
/* 173 */       baseTransform = paramGraphics.getTransformNoClone().copy();
/* 174 */       paramGraphics.transform(paramBaseTransform);
/*     */     } 
/* 176 */     this.node.renderContent(paramGraphics);
/* 177 */     if (baseTransform != null) {
/* 178 */       paramGraphics.setTransform(baseTransform);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ImageData getImageDataForNode(FilterContext paramFilterContext, NGNode paramNGNode, boolean paramBoolean, BaseTransform paramBaseTransform, Rectangle paramRectangle) {
/* 189 */     RenderType renderType = paramBoolean ? RenderType.EFFECT_CONTENT : RenderType.FULL_CONTENT;
/* 190 */     Rectangle rectangle = getImageBoundsForNode(paramNGNode, renderType, paramBaseTransform, paramRectangle);
/* 191 */     return getImageDataForBoundedNode(paramFilterContext, paramNGNode, renderType, paramBaseTransform, rectangle);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Rectangle getImageBoundsForNode(NGNode paramNGNode, RenderType paramRenderType, BaseTransform paramBaseTransform, Rectangle paramRectangle) {
/*     */     BaseBounds baseBounds;
/* 198 */     RectBounds rectBounds = new RectBounds();
/* 199 */     switch (paramRenderType) {
/*     */       case EFFECT_CONTENT:
/* 201 */         baseBounds = paramNGNode.getContentBounds(rectBounds, paramBaseTransform);
/*     */         break;
/*     */       case FULL_CONTENT:
/* 204 */         baseBounds = paramNGNode.getCompleteBounds(baseBounds, paramBaseTransform);
/*     */         break;
/*     */       case CLIPPED_CONTENT:
/* 207 */         baseBounds = paramNGNode.getClippedBounds(baseBounds, paramBaseTransform);
/*     */         break;
/*     */     } 
/* 210 */     Rectangle rectangle = new Rectangle(baseBounds);
/* 211 */     if (paramRectangle != null) {
/* 212 */       rectangle.intersectWith(paramRectangle);
/*     */     }
/* 214 */     return rectangle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ImageData getImageDataForBoundedNode(FilterContext paramFilterContext, NGNode paramNGNode, RenderType paramRenderType, BaseTransform paramBaseTransform, Rectangle paramRectangle) {
/* 228 */     PrDrawable prDrawable = (PrDrawable)Effect.getCompatibleImage(paramFilterContext, paramRectangle.width, paramRectangle.height);
/* 229 */     if (prDrawable != null) {
/* 230 */       Graphics graphics = prDrawable.createGraphics();
/* 231 */       graphics.translate(-paramRectangle.x, -paramRectangle.y);
/* 232 */       if (paramBaseTransform != null) {
/* 233 */         graphics.transform(paramBaseTransform);
/*     */       }
/* 235 */       switch (paramRenderType) {
/*     */         case EFFECT_CONTENT:
/* 237 */           paramNGNode.renderContent(graphics);
/*     */           break;
/*     */         case FULL_CONTENT:
/* 240 */           paramNGNode.render(graphics);
/*     */           break;
/*     */         case CLIPPED_CONTENT:
/* 243 */           paramNGNode.renderForClip(graphics);
/*     */           break;
/*     */       } 
/*     */     } 
/* 247 */     return new ImageData(paramFilterContext, prDrawable, paramRectangle);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reducesOpaquePixels() {
/* 252 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public DirtyRegionContainer getDirtyRegions(Effect paramEffect, DirtyRegionPool paramDirtyRegionPool) {
/* 257 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NodeEffectInput.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */