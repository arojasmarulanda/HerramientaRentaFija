/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.collections.FloatArraySyncer;
/*     */ import com.sun.javafx.collections.IntegerArraySyncer;
/*     */ import com.sun.prism.Mesh;
/*     */ import com.sun.prism.ResourceFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NGTriangleMesh
/*     */ {
/*     */   private boolean meshDirty = true;
/*     */   private Mesh mesh;
/*     */   private boolean userDefinedNormals = false;
/*     */   private float[] points;
/*  43 */   private int[] pointsFromAndLengthIndices = new int[2];
/*     */   
/*     */   private float[] normals;
/*     */   
/*  47 */   private int[] normalsFromAndLengthIndices = new int[2];
/*     */   
/*     */   private float[] texCoords;
/*     */   
/*  51 */   private int[] texCoordsFromAndLengthIndices = new int[2];
/*     */   
/*     */   private int[] faces;
/*     */   
/*  55 */   private int[] facesFromAndLengthIndices = new int[2];
/*     */   
/*     */   private int[] faceSmoothingGroups;
/*     */   
/*  59 */   private int[] faceSmoothingGroupsFromAndLengthIndices = new int[2];
/*     */   
/*     */   Mesh createMesh(ResourceFactory paramResourceFactory) {
/*  62 */     if (this.mesh == null) {
/*  63 */       this.mesh = paramResourceFactory.createMesh();
/*  64 */       this.meshDirty = true;
/*     */     } 
/*  66 */     return this.mesh;
/*     */   }
/*     */   
/*     */   boolean validate() {
/*  70 */     if (this.points == null || this.texCoords == null || this.faces == null || this.faceSmoothingGroups == null || (this.userDefinedNormals && this.normals == null))
/*     */     {
/*  72 */       return false;
/*     */     }
/*  74 */     if (this.meshDirty) {
/*  75 */       if (!this.mesh.buildGeometry(this.userDefinedNormals, this.points, this.pointsFromAndLengthIndices, this.normals, this.normalsFromAndLengthIndices, this.texCoords, this.texCoordsFromAndLengthIndices, this.faces, this.facesFromAndLengthIndices, this.faceSmoothingGroups, this.faceSmoothingGroupsFromAndLengthIndices))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  81 */         throw new RuntimeException("NGTriangleMesh: buildGeometry failed");
/*     */       }
/*  83 */       this.meshDirty = false;
/*     */     } 
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPointsByRef(float[] paramArrayOffloat) {
/*  92 */     this.meshDirty = true;
/*  93 */     this.points = paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setNormalsByRef(float[] paramArrayOffloat) {
/* 100 */     this.meshDirty = true;
/* 101 */     this.normals = paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTexCoordsByRef(float[] paramArrayOffloat) {
/* 108 */     this.meshDirty = true;
/* 109 */     this.texCoords = paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setFacesByRef(int[] paramArrayOfint) {
/* 116 */     this.meshDirty = true;
/* 117 */     this.faces = paramArrayOfint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setFaceSmoothingGroupsByRef(int[] paramArrayOfint) {
/* 124 */     this.meshDirty = true;
/* 125 */     this.faceSmoothingGroups = paramArrayOfint;
/*     */   }
/*     */   
/*     */   public void setUserDefinedNormals(boolean paramBoolean) {
/* 129 */     this.userDefinedNormals = paramBoolean;
/*     */   }
/*     */   
/*     */   public boolean isUserDefinedNormals() {
/* 133 */     return this.userDefinedNormals;
/*     */   }
/*     */   
/*     */   public void syncPoints(FloatArraySyncer paramFloatArraySyncer) {
/* 137 */     this.meshDirty = true;
/* 138 */     this.points = (paramFloatArraySyncer != null) ? paramFloatArraySyncer.syncTo(this.points, this.pointsFromAndLengthIndices) : null;
/*     */   }
/*     */   
/*     */   public void syncNormals(FloatArraySyncer paramFloatArraySyncer) {
/* 142 */     this.meshDirty = true;
/* 143 */     this.normals = (paramFloatArraySyncer != null) ? paramFloatArraySyncer.syncTo(this.normals, this.normalsFromAndLengthIndices) : null;
/*     */   }
/*     */   
/*     */   public void syncTexCoords(FloatArraySyncer paramFloatArraySyncer) {
/* 147 */     this.meshDirty = true;
/* 148 */     this.texCoords = (paramFloatArraySyncer != null) ? paramFloatArraySyncer.syncTo(this.texCoords, this.texCoordsFromAndLengthIndices) : null;
/*     */   }
/*     */   
/*     */   public void syncFaces(IntegerArraySyncer paramIntegerArraySyncer) {
/* 152 */     this.meshDirty = true;
/* 153 */     this.faces = (paramIntegerArraySyncer != null) ? paramIntegerArraySyncer.syncTo(this.faces, this.facesFromAndLengthIndices) : null;
/*     */   }
/*     */   
/*     */   public void syncFaceSmoothingGroups(IntegerArraySyncer paramIntegerArraySyncer) {
/* 157 */     this.meshDirty = true;
/* 158 */     this.faceSmoothingGroups = (paramIntegerArraySyncer != null) ? paramIntegerArraySyncer.syncTo(this.faceSmoothingGroups, this.faceSmoothingGroupsFromAndLengthIndices) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   int[] test_getFaceSmoothingGroups() {
/* 163 */     return this.faceSmoothingGroups;
/*     */   }
/*     */   
/*     */   int[] test_getFaces() {
/* 167 */     return this.faces;
/*     */   }
/*     */   
/*     */   float[] test_getPoints() {
/* 171 */     return this.points;
/*     */   }
/*     */   
/*     */   float[] test_getNormals() {
/* 175 */     return this.normals;
/*     */   }
/*     */   
/*     */   float[] test_getTexCoords() {
/* 179 */     return this.texCoords;
/*     */   }
/*     */   
/*     */   Mesh test_getMesh() {
/* 183 */     return this.mesh;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGTriangleMesh.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */