/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.prism.Graphics;
/*    */ import com.sun.scenario.effect.Effect;
/*    */ import com.sun.scenario.effect.impl.prism.PrEffectHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EffectFilter
/*    */ {
/*    */   private Effect effect;
/*    */   private NodeEffectInput nodeInput;
/*    */   
/*    */   EffectFilter(Effect paramEffect, NGNode paramNGNode) {
/* 41 */     this.effect = paramEffect;
/* 42 */     this.nodeInput = new NodeEffectInput(paramNGNode);
/*    */   }
/*    */   
/* 45 */   Effect getEffect() { return this.effect; } NodeEffectInput getNodeInput() {
/* 46 */     return this.nodeInput;
/*    */   }
/*    */   void dispose() {
/* 49 */     this.effect = null;
/* 50 */     this.nodeInput.setNode(null);
/* 51 */     this.nodeInput = null;
/*    */   }
/*    */   
/*    */   BaseBounds getBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 55 */     BaseBounds baseBounds = getEffect().getBounds(paramBaseTransform, this.nodeInput);
/* 56 */     return paramBaseBounds.deriveWithNewBounds(baseBounds);
/*    */   }
/*    */   
/*    */   void render(Graphics paramGraphics) {
/* 60 */     NodeEffectInput nodeEffectInput = getNodeInput();
/* 61 */     PrEffectHelper.render(getEffect(), paramGraphics, 0.0F, 0.0F, nodeEffectInput);
/* 62 */     nodeEffectInput.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\EffectFilter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */