/*     */ package com.sun.javafx.application;
/*     */ 
/*     */ import java.lang.module.ModuleDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModuleAccess
/*     */ {
/*     */   private final Object module;
/*     */   private static final Method bootLayerMethod;
/*     */   private static final Method getModuleNameMethod;
/*     */   private static final Method findModuleMethod;
/*     */   private static final Method getDescriptorMethod;
/*     */   private static final Method classForNameMethod;
/*     */   
/*     */   private ModuleAccess(Object paramObject) {
/*  37 */     this.module = paramObject;
/*     */   }
/*     */   
/*     */   ModuleDescriptor getDescriptor() {
/*     */     try {
/*  42 */       return (ModuleDescriptor)getDescriptorMethod.invoke(this.module, new Object[0]);
/*  43 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/*  44 */       throw new InternalError(illegalAccessException);
/*     */     } 
/*     */   }
/*     */   
/*     */   String getName() {
/*     */     try {
/*  50 */       return (String)getModuleNameMethod.invoke(this.module, new Object[0]);
/*  51 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/*  52 */       throw new InternalError(illegalAccessException);
/*     */     } 
/*     */   }
/*     */   
/*     */   Class<?> classForName(String paramString) {
/*     */     try {
/*  58 */       return (Class)classForNameMethod.invoke(null, new Object[] { this.module, paramString });
/*  59 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/*  60 */       throw new InternalError(illegalAccessException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static ModuleAccess load(String paramString) {
/*     */     try {
/*  67 */       Object object = bootLayerMethod.invoke(null, new Object[0]);
/*     */ 
/*     */       
/*  70 */       Optional optional = (Optional)findModuleMethod.invoke(object, new Object[] { paramString });
/*  71 */       if (!optional.isPresent())
/*     */       {
/*  73 */         throw new InternalError("Module " + paramString + " not in boot Layer");
/*     */       }
/*     */       
/*  76 */       return new ModuleAccess(optional.get());
/*  77 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/*  78 */       throw new InternalError(illegalAccessException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  89 */     Class<?> clazz = null;
/*  90 */     Method method1 = null;
/*  91 */     Method method2 = null;
/*  92 */     Method method3 = null;
/*  93 */     Method method4 = null;
/*  94 */     Method method5 = null;
/*  95 */     Method method6 = null;
/*  96 */     Method method7 = null;
/*     */     
/*     */     try {
/*  99 */       method1 = Class.class.getMethod("getModule", new Class[0]);
/* 100 */       clazz = method1.getReturnType();
/* 101 */       method2 = clazz.getMethod("getLayer", new Class[0]);
/* 102 */       method3 = clazz.getMethod("getDescriptor", new Class[0]);
/* 103 */       method4 = clazz.getMethod("getName", new Class[0]);
/*     */       
/* 105 */       Class<?> clazz1 = method2.getReturnType();
/* 106 */       method5 = clazz1.getMethod("boot", new Class[0]);
/* 107 */       method6 = clazz1.getMethod("findModule", new Class[] { String.class });
/*     */ 
/*     */       
/* 110 */       method7 = Class.class.getMethod("forName", new Class[] { clazz, String.class });
/*     */     }
/* 112 */     catch (NoSuchMethodException noSuchMethodException) {
/* 113 */       throw new InternalError("Module reflection failed", noSuchMethodException);
/*     */     } 
/*     */     
/* 116 */     bootLayerMethod = method5;
/* 117 */     getModuleNameMethod = method4;
/* 118 */     getDescriptorMethod = method3;
/* 119 */     findModuleMethod = method6;
/* 120 */     classForNameMethod = method7;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\application\ModuleAccess.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */