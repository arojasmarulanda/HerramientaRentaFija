/*     */ package com.sun.javafx.application;
/*     */ 
/*     */ import com.sun.glass.ui.Application;
/*     */ import com.sun.javafx.FXPermissions;
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.css.StyleManager;
/*     */ import com.sun.javafx.tk.TKListener;
/*     */ import com.sun.javafx.tk.TKStage;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import com.sun.javafx.util.ModuleHelper;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CopyOnWriteArraySet;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import javafx.application.ConditionalFeature;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.util.FXPermission;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlatformImpl
/*     */ {
/*  62 */   private static AtomicBoolean initialized = new AtomicBoolean(false);
/*  63 */   private static AtomicBoolean platformExit = new AtomicBoolean(false);
/*  64 */   private static AtomicBoolean toolkitExit = new AtomicBoolean(false);
/*  65 */   private static CountDownLatch startupLatch = new CountDownLatch(1);
/*  66 */   private static AtomicBoolean listenersRegistered = new AtomicBoolean(false);
/*  67 */   private static TKListener toolkitListener = null;
/*     */   private static volatile boolean implicitExit = true;
/*     */   private static boolean taskbarApplication = true;
/*     */   private static boolean contextual2DNavigation;
/*  71 */   private static AtomicInteger pendingRunnables = new AtomicInteger(0);
/*  72 */   private static AtomicInteger numWindows = new AtomicInteger(0);
/*     */   private static volatile boolean firstWindowShown = false;
/*     */   private static volatile boolean lastWindowClosed = false;
/*  75 */   private static AtomicBoolean reallyIdle = new AtomicBoolean(false);
/*  76 */   private static Set<FinishListener> finishListeners = new CopyOnWriteArraySet<>();
/*     */   
/*  78 */   private static final Object runLaterLock = new Object();
/*     */   private static Boolean isGraphicsSupported;
/*     */   private static Boolean isControlsSupported;
/*     */   private static Boolean isMediaSupported;
/*     */   private static Boolean isWebSupported;
/*     */   private static Boolean isSWTSupported;
/*     */   private static Boolean isSwingSupported;
/*     */   private static Boolean isFXMLSupported;
/*     */   private static Boolean hasTwoLevelFocus;
/*     */   private static Boolean hasVirtualKeyboard;
/*     */   private static Boolean hasTouch;
/*     */   private static Boolean hasMultiTouch;
/*     */   private static Boolean hasPointer;
/*     */   private static boolean isThreadMerged = false;
/*  92 */   private static String applicationType = "";
/*  93 */   private static BooleanProperty accessibilityActive = new SimpleBooleanProperty();
/*  94 */   private static CountDownLatch allNestedLoopsExitedLatch = new CountDownLatch(1);
/*     */ 
/*     */   
/*  97 */   private static final boolean verbose = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.verbose")))).booleanValue();
/*     */ 
/*     */ 
/*     */   
/* 101 */   private static final boolean DEBUG = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("com.sun.javafx.application.debug")))).booleanValue();
/*     */ 
/*     */ 
/*     */   
/* 105 */   private static final FXPermission FXCANVAS_PERMISSION = new FXPermission("accessFXCanvasInternals");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setTaskbarApplication(boolean paramBoolean) {
/* 115 */     taskbarApplication = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTaskbarApplication() {
/* 124 */     return taskbarApplication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setApplicationName(Class paramClass) {
/* 137 */     runLater(() -> Application.GetApplication().setName(paramClass.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isContextual2DNavigation() {
/* 147 */     return contextual2DNavigation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void startup(Runnable paramRunnable) {
/* 158 */     startup(paramRunnable, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void startup(Runnable paramRunnable, boolean paramBoolean) {
/* 176 */     if (platformExit.get()) {
/* 177 */       throw new IllegalStateException("Platform.exit has been called");
/*     */     }
/*     */     
/* 180 */     if (initialized.getAndSet(true)) {
/* 181 */       if (paramBoolean) {
/* 182 */         throw new IllegalStateException("Toolkit already initialized");
/*     */       }
/*     */ 
/*     */       
/* 186 */       runLater(paramRunnable);
/*     */       
/*     */       return;
/*     */     } 
/* 190 */     AccessController.doPrivileged(() -> {
/*     */           applicationType = System.getProperty("com.sun.javafx.application.type");
/*     */           
/*     */           if (applicationType == null) {
/*     */             applicationType = "";
/*     */           }
/*     */           
/*     */           contextual2DNavigation = Boolean.getBoolean("com.sun.javafx.isContextual2DNavigation");
/*     */           String str = System.getProperty("com.sun.javafx.twoLevelFocus");
/*     */           if (str != null) {
/*     */             hasTwoLevelFocus = Boolean.valueOf(str);
/*     */           }
/*     */           str = System.getProperty("com.sun.javafx.virtualKeyboard");
/*     */           if (str != null) {
/*     */             if (str.equalsIgnoreCase("none")) {
/*     */               hasVirtualKeyboard = Boolean.valueOf(false);
/*     */             } else if (str.equalsIgnoreCase("javafx")) {
/*     */               hasVirtualKeyboard = Boolean.valueOf(true);
/*     */             } else if (str.equalsIgnoreCase("native")) {
/*     */               hasVirtualKeyboard = Boolean.valueOf(true);
/*     */             } 
/*     */           }
/*     */           str = System.getProperty("com.sun.javafx.touch");
/*     */           if (str != null) {
/*     */             hasTouch = Boolean.valueOf(str);
/*     */           }
/*     */           str = System.getProperty("com.sun.javafx.multiTouch");
/*     */           if (str != null) {
/*     */             hasMultiTouch = Boolean.valueOf(str);
/*     */           }
/*     */           str = System.getProperty("com.sun.javafx.pointer");
/*     */           if (str != null) {
/*     */             hasPointer = Boolean.valueOf(str);
/*     */           }
/*     */           str = System.getProperty("javafx.embed.singleThread");
/*     */           if (str != null) {
/*     */             isThreadMerged = Boolean.valueOf(str).booleanValue();
/*     */             if (isThreadMerged && !isSupported(ConditionalFeature.SWING)) {
/*     */               isThreadMerged = false;
/*     */               if (verbose) {
/*     */                 System.err.println("WARNING: javafx.embed.singleThread ignored (javafx.swing module not found)");
/*     */               }
/*     */             } 
/*     */           } 
/*     */           return null;
/*     */         });
/* 236 */     if (DEBUG) {
/* 237 */       System.err.println("PlatformImpl::startup : applicationType = " + applicationType);
/*     */     }
/*     */     
/* 240 */     if ("FXCanvas".equals(applicationType)) {
/* 241 */       initFXCanvas();
/*     */     }
/*     */     
/* 244 */     if (!taskbarApplication) {
/* 245 */       AccessController.doPrivileged(() -> {
/*     */             System.setProperty("glass.taskbarApplication", "false");
/*     */ 
/*     */             
/*     */             return null;
/*     */           });
/*     */     }
/*     */     
/* 253 */     toolkitListener = new TKListener() {
/*     */         public void changedTopLevelWindows(List<TKStage> param1List) {
/* 255 */           PlatformImpl.numWindows.set(param1List.size());
/* 256 */           PlatformImpl.checkIdle();
/*     */         }
/*     */ 
/*     */         
/*     */         public void exitedLastNestedLoop() {
/* 261 */           if (PlatformImpl.platformExit.get()) {
/* 262 */             PlatformImpl.allNestedLoopsExitedLatch.countDown();
/*     */           }
/* 264 */           PlatformImpl.checkIdle();
/*     */         }
/*     */       };
/* 267 */     Toolkit.getToolkit().addTkListener(toolkitListener);
/*     */     
/* 269 */     Toolkit.getToolkit().startup(() -> {
/*     */           startupLatch.countDown();
/*     */           
/*     */           paramRunnable.run();
/*     */         });
/*     */     
/* 275 */     if (isThreadMerged) {
/* 276 */       installFwEventQueue();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initDeviceDetailsFXCanvas() {
/* 285 */     long l = ((Long)AccessController.<Long>doPrivileged(() -> Long.getLong("javafx.embed.eventProc", 0L))).longValue();
/*     */     
/* 287 */     if (l != 0L) {
/*     */ 
/*     */       
/* 290 */       Map<Object, Object> map = Application.getDeviceDetails();
/* 291 */       if (map == null) {
/* 292 */         map = new HashMap<>();
/* 293 */         Application.setDeviceDetails(map);
/*     */       } 
/* 295 */       if (map.get("javafx.embed.eventProc") == null) {
/* 296 */         map.put("javafx.embed.eventProc", Long.valueOf(l));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addExportsToFXCanvas(Class<?> paramClass) {
/* 303 */     String[] arrayOfString = { "com.sun.glass.ui", "com.sun.javafx.cursor", "com.sun.javafx.embed", "com.sun.javafx.stage", "com.sun.javafx.tk" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 311 */     if (DEBUG) {
/* 312 */       System.err.println("addExportsToFXCanvas: class = " + paramClass);
/*     */     }
/* 314 */     Object object1 = ModuleHelper.getModule(PlatformImpl.class);
/* 315 */     Object object2 = ModuleHelper.getModule(paramClass);
/* 316 */     for (String str : arrayOfString) {
/* 317 */       if (DEBUG) {
/* 318 */         System.err.println("add export of " + str + " from " + object1 + " to " + object2);
/*     */       }
/*     */       
/* 321 */       ModuleHelper.addExports(object1, str, object2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initFXCanvas() {
/* 328 */     SecurityManager securityManager = System.getSecurityManager();
/* 329 */     if (securityManager != null) {
/*     */       try {
/* 331 */         securityManager.checkPermission((Permission)FXCANVAS_PERMISSION);
/* 332 */       } catch (SecurityException securityException) {
/* 333 */         System.err.println("FXCanvas: no permission to access JavaFX internals");
/* 334 */         securityException.printStackTrace();
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/*     */     
/* 340 */     Predicate predicate = paramStackFrame -> 
/* 341 */       (!paramStackFrame.getClassName().startsWith("javafx.application.") && !paramStackFrame.getClassName().startsWith("com.sun.javafx.application."));
/*     */ 
/*     */     
/* 344 */     StackWalker stackWalker = AccessController.<StackWalker>doPrivileged(() -> StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE));
/*     */     
/* 346 */     Optional<StackWalker.StackFrame> optional = (Optional)stackWalker.walk(paramStream -> paramStream.filter(paramPredicate).findFirst());
/*     */ 
/*     */     
/* 349 */     if (optional.isPresent()) {
/* 350 */       Class<?> clazz = ((StackWalker.StackFrame)optional.get()).getDeclaringClass();
/* 351 */       if (DEBUG) {
/* 352 */         System.err.println("callerClassName = " + clazz);
/*     */       }
/*     */ 
/*     */       
/* 356 */       if ("javafx.embed.swt.FXCanvas".equals(clazz.getName())) {
/* 357 */         initDeviceDetailsFXCanvas();
/* 358 */         addExportsToFXCanvas(clazz);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void installFwEventQueue() {
/* 364 */     invokeSwingFXUtilsMethod("installFwEventQueue");
/*     */   }
/*     */   
/*     */   private static void removeFwEventQueue() {
/* 368 */     invokeSwingFXUtilsMethod("removeFwEventQueue");
/*     */   }
/*     */ 
/*     */   
/*     */   private static void invokeSwingFXUtilsMethod(String paramString) {
/*     */     try {
/* 374 */       Class<?> clazz = Class.forName("com.sun.javafx.embed.swing.SwingFXUtilsImpl");
/* 375 */       Method method = clazz.getDeclaredMethod(paramString, new Class[0]);
/*     */       
/* 377 */       waitForStart();
/* 378 */       method.invoke(null, new Object[0]);
/*     */     }
/* 380 */     catch (ClassNotFoundException|NoSuchMethodException|IllegalAccessException classNotFoundException) {
/* 381 */       throw new RuntimeException("Property javafx.embed.singleThread is not supported");
/* 382 */     } catch (InvocationTargetException invocationTargetException) {
/* 383 */       throw new RuntimeException(invocationTargetException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void waitForStart() {
/* 391 */     if (startupLatch.getCount() > 0L) {
/*     */       try {
/* 393 */         startupLatch.await();
/* 394 */       } catch (InterruptedException interruptedException) {
/* 395 */         interruptedException.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean isFxApplicationThread() {
/* 401 */     return Toolkit.getToolkit().isFxUserThread();
/*     */   }
/*     */   
/*     */   public static void runLater(Runnable paramRunnable) {
/* 405 */     runLater(paramRunnable, false);
/*     */   }
/*     */   
/*     */   private static void runLater(Runnable paramRunnable, boolean paramBoolean) {
/* 409 */     if (!initialized.get()) {
/* 410 */       throw new IllegalStateException("Toolkit not initialized");
/*     */     }
/*     */     
/* 413 */     pendingRunnables.incrementAndGet();
/* 414 */     waitForStart();
/*     */     
/* 416 */     synchronized (runLaterLock) {
/* 417 */       if (!paramBoolean && toolkitExit.get()) {
/*     */         
/* 419 */         pendingRunnables.decrementAndGet();
/*     */         
/*     */         return;
/*     */       } 
/* 423 */       AccessControlContext accessControlContext = AccessController.getContext();
/*     */       
/* 425 */       Toolkit.getToolkit().defer(() -> {
/*     */             try {
/*     */               AccessController.doPrivileged((), paramAccessControlContext);
/*     */             } finally {
/*     */               pendingRunnables.decrementAndGet();
/*     */               checkIdle();
/*     */             } 
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runAndWait(Runnable paramRunnable) {
/* 440 */     runAndWait(paramRunnable, false);
/*     */   }
/*     */   
/*     */   private static void runAndWait(Runnable paramRunnable, boolean paramBoolean) {
/* 444 */     if (isFxApplicationThread()) {
/*     */       try {
/* 446 */         paramRunnable.run();
/* 447 */       } catch (Throwable throwable) {
/* 448 */         System.err.println("Exception in runnable");
/* 449 */         throwable.printStackTrace();
/*     */       } 
/*     */     } else {
/* 452 */       CountDownLatch countDownLatch = new CountDownLatch(1);
/* 453 */       runLater(() -> { try { paramRunnable.run(); } finally { paramCountDownLatch.countDown(); }  }paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 461 */       if (!paramBoolean && toolkitExit.get()) {
/* 462 */         throw new IllegalStateException("Toolkit has exited");
/*     */       }
/*     */       
/*     */       try {
/* 466 */         countDownLatch.await();
/* 467 */       } catch (InterruptedException interruptedException) {
/* 468 */         interruptedException.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setImplicitExit(boolean paramBoolean) {
/* 474 */     implicitExit = paramBoolean;
/* 475 */     checkIdle();
/*     */   }
/*     */   
/*     */   public static boolean isImplicitExit() {
/* 479 */     return implicitExit;
/*     */   }
/*     */   
/*     */   public static void addListener(FinishListener paramFinishListener) {
/* 483 */     listenersRegistered.set(true);
/* 484 */     finishListeners.add(paramFinishListener);
/*     */   }
/*     */   
/*     */   public static void removeListener(FinishListener paramFinishListener) {
/* 488 */     finishListeners.remove(paramFinishListener);
/* 489 */     listenersRegistered.set(!finishListeners.isEmpty());
/* 490 */     if (!listenersRegistered.get()) {
/* 491 */       checkIdle();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void notifyFinishListeners(boolean paramBoolean) {
/* 497 */     if (listenersRegistered.get()) {
/* 498 */       for (FinishListener finishListener : finishListeners) {
/* 499 */         if (paramBoolean) {
/* 500 */           finishListener.exitCalled(); continue;
/*     */         } 
/* 502 */         finishListener.idle(implicitExit);
/*     */       }
/*     */     
/* 505 */     } else if (implicitExit || platformExit.get()) {
/* 506 */       tkExit();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkIdle() {
/* 514 */     if (!initialized.get()) {
/*     */       return;
/*     */     }
/*     */     
/* 518 */     if (!isFxApplicationThread()) {
/*     */ 
/*     */       
/* 521 */       runLater(() -> {
/*     */           
/*     */           });
/*     */       return;
/*     */     } 
/* 526 */     boolean bool = false;
/*     */     
/* 528 */     synchronized (PlatformImpl.class) {
/* 529 */       int i = numWindows.get();
/* 530 */       if (i > 0) {
/* 531 */         firstWindowShown = true;
/* 532 */         lastWindowClosed = false;
/* 533 */         reallyIdle.set(false);
/* 534 */       } else if (i == 0 && firstWindowShown) {
/* 535 */         lastWindowClosed = true;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 542 */       if (lastWindowClosed && pendingRunnables.get() == 0 && (toolkitExit
/* 543 */         .get() || !Toolkit.getToolkit().isNestedLoopRunning()))
/*     */       {
/* 545 */         if (reallyIdle.getAndSet(true)) {
/*     */           
/* 547 */           bool = true;
/* 548 */           lastWindowClosed = false;
/*     */         } else {
/*     */           
/* 551 */           runLater(() -> {
/*     */               
/*     */               });
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 558 */     if (bool) {
/* 559 */       notifyFinishListeners(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 564 */   private static final CountDownLatch platformExitLatch = new CountDownLatch(1);
/*     */   static CountDownLatch test_getPlatformExitLatch() {
/* 566 */     return platformExitLatch;
/*     */   }
/*     */   
/*     */   public static void tkExit() {
/* 570 */     if (toolkitExit.getAndSet(true)) {
/*     */       return;
/*     */     }
/*     */     
/* 574 */     if (initialized.get()) {
/* 575 */       if (platformExit.get()) {
/* 576 */         runAndWait(() -> { if (Toolkit.getToolkit().isNestedLoopRunning()) { Toolkit.getToolkit().exitAllNestedEventLoops(); } else { allNestedLoopsExitedLatch.countDown(); }  }true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 585 */           allNestedLoopsExitedLatch.await();
/* 586 */         } catch (InterruptedException interruptedException) {
/* 587 */           throw new RuntimeException("Could not exit all nested event loops");
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 593 */       runAndWait(() -> Toolkit.getToolkit().exit(), true);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 598 */       if (isThreadMerged) {
/* 599 */         removeFwEventQueue();
/*     */       }
/*     */       
/* 602 */       Toolkit.getToolkit().removeTkListener(toolkitListener);
/* 603 */       toolkitListener = null;
/* 604 */       platformExitLatch.countDown();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static BooleanProperty accessibilityActiveProperty() {
/* 609 */     return accessibilityActive;
/*     */   }
/*     */   
/*     */   public static void exit() {
/* 613 */     platformExit.set(true);
/* 614 */     notifyFinishListeners(true);
/*     */   }
/*     */   
/*     */   private static Boolean checkForClass(String paramString) {
/*     */     try {
/* 619 */       Class.forName(paramString, false, PlatformImpl.class.getClassLoader());
/* 620 */       return Boolean.TRUE;
/* 621 */     } catch (ClassNotFoundException classNotFoundException) {
/* 622 */       return Boolean.FALSE;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isSupported(ConditionalFeature paramConditionalFeature) {
/* 627 */     boolean bool = isSupportedImpl(paramConditionalFeature);
/* 628 */     if (bool && paramConditionalFeature == ConditionalFeature.TRANSPARENT_WINDOW) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 633 */       SecurityManager securityManager = System.getSecurityManager();
/* 634 */       if (securityManager != null) {
/*     */         try {
/* 636 */           securityManager.checkPermission((Permission)FXPermissions.CREATE_TRANSPARENT_WINDOW_PERMISSION);
/* 637 */         } catch (SecurityException securityException) {
/* 638 */           return false;
/*     */         } 
/*     */       }
/*     */       
/* 642 */       return true;
/*     */     } 
/*     */     
/* 645 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDefaultPlatformUserAgentStylesheet() {
/* 657 */     setPlatformUserAgentStylesheet("MODENA");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isModena = false;
/*     */ 
/*     */   
/*     */   private static boolean isCaspian = false;
/*     */ 
/*     */   
/*     */   private static String accessibilityTheme;
/*     */ 
/*     */   
/*     */   public static boolean isModena() {
/* 672 */     return isModena;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCaspian() {
/* 684 */     return isCaspian;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setPlatformUserAgentStylesheet(String paramString) {
/* 692 */     if (isFxApplicationThread()) {
/* 693 */       _setPlatformUserAgentStylesheet(paramString);
/*     */     } else {
/* 695 */       runLater(() -> _setPlatformUserAgentStylesheet(paramString));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean setAccessibilityTheme(String paramString) {
/* 702 */     if (accessibilityTheme != null) {
/* 703 */       StyleManager.getInstance().removeUserAgentStylesheet(accessibilityTheme);
/* 704 */       accessibilityTheme = null;
/*     */     } 
/*     */     
/* 707 */     _setAccessibilityTheme(paramString);
/*     */     
/* 709 */     if (accessibilityTheme != null) {
/* 710 */       StyleManager.getInstance().addUserAgentStylesheet(accessibilityTheme);
/* 711 */       return true;
/*     */     } 
/* 713 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void _setAccessibilityTheme(String paramString) {
/* 720 */     String str = AccessController.<String>doPrivileged(() -> System.getProperty("com.sun.javafx.highContrastTheme"));
/*     */ 
/*     */     
/* 723 */     if (isCaspian()) {
/* 724 */       if (paramString != null || str != null)
/*     */       {
/* 726 */         accessibilityTheme = "com/sun/javafx/scene/control/skin/caspian/highcontrast.css";
/*     */       }
/* 728 */     } else if (isModena()) {
/*     */       
/* 730 */       if (str != null) {
/* 731 */         switch (str.toUpperCase()) {
/*     */           case "BLACKONWHITE":
/* 733 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/blackOnWhite.css";
/*     */             break;
/*     */           case "WHITEONBLACK":
/* 736 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/whiteOnBlack.css";
/*     */             break;
/*     */           case "YELLOWONBLACK":
/* 739 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/yellowOnBlack.css";
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/* 744 */       } else if (paramString != null) {
/*     */         
/* 746 */         switch (paramString) {
/*     */           case "High Contrast White":
/* 748 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/blackOnWhite.css";
/*     */             break;
/*     */           case "High Contrast Black":
/* 751 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/whiteOnBlack.css";
/*     */             break;
/*     */           case "High Contrast #1":
/*     */           case "High Contrast #2":
/* 755 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/yellowOnBlack.css";
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void _setPlatformUserAgentStylesheet(String paramString) {
/* 765 */     isModena = isCaspian = false;
/*     */     
/* 767 */     String str = AccessController.<String>doPrivileged(() -> System.getProperty("javafx.userAgentStylesheetUrl"));
/*     */ 
/*     */     
/* 770 */     if (str != null) {
/* 771 */       paramString = str;
/*     */     }
/*     */     
/* 774 */     ArrayList<String> arrayList = new ArrayList();
/*     */ 
/*     */     
/* 777 */     if ("CASPIAN".equalsIgnoreCase(paramString)) {
/* 778 */       isCaspian = true;
/*     */       
/* 780 */       arrayList.add("com/sun/javafx/scene/control/skin/caspian/caspian.css");
/*     */       
/* 782 */       if (isSupported(ConditionalFeature.INPUT_TOUCH)) {
/* 783 */         arrayList.add("com/sun/javafx/scene/control/skin/caspian/embedded.css");
/* 784 */         if (Utils.isQVGAScreen()) {
/* 785 */           arrayList.add("com/sun/javafx/scene/control/skin/caspian/embedded-qvga.css");
/*     */         }
/* 787 */         if (PlatformUtil.isAndroid()) {
/* 788 */           arrayList.add("com/sun/javafx/scene/control/skin/caspian/android.css");
/*     */         }
/*     */       } 
/*     */       
/* 792 */       if (isSupported(ConditionalFeature.TWO_LEVEL_FOCUS)) {
/* 793 */         arrayList.add("com/sun/javafx/scene/control/skin/caspian/two-level-focus.css");
/*     */       }
/*     */       
/* 796 */       if (isSupported(ConditionalFeature.VIRTUAL_KEYBOARD)) {
/* 797 */         arrayList.add("com/sun/javafx/scene/control/skin/caspian/fxvk.css");
/*     */       }
/*     */       
/* 800 */       if (!isSupported(ConditionalFeature.TRANSPARENT_WINDOW)) {
/* 801 */         arrayList.add("com/sun/javafx/scene/control/skin/caspian/caspian-no-transparency.css");
/*     */       }
/*     */     }
/* 804 */     else if ("MODENA".equalsIgnoreCase(paramString)) {
/* 805 */       isModena = true;
/*     */       
/* 807 */       arrayList.add("com/sun/javafx/scene/control/skin/modena/modena.css");
/*     */       
/* 809 */       if (isSupported(ConditionalFeature.INPUT_TOUCH)) {
/* 810 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/touch.css");
/*     */       }
/*     */       
/* 813 */       if (PlatformUtil.isEmbedded()) {
/* 814 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/modena-embedded-performance.css");
/*     */       }
/* 816 */       if (PlatformUtil.isAndroid()) {
/* 817 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/android.css");
/*     */       }
/*     */       
/* 820 */       if (isSupported(ConditionalFeature.TWO_LEVEL_FOCUS)) {
/* 821 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/two-level-focus.css");
/*     */       }
/*     */       
/* 824 */       if (isSupported(ConditionalFeature.VIRTUAL_KEYBOARD)) {
/* 825 */         arrayList.add("com/sun/javafx/scene/control/skin/caspian/fxvk.css");
/*     */       }
/*     */       
/* 828 */       if (!isSupported(ConditionalFeature.TRANSPARENT_WINDOW)) {
/* 829 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/modena-no-transparency.css");
/*     */       }
/*     */     } else {
/*     */       
/* 833 */       arrayList.add(paramString);
/*     */     } 
/*     */ 
/*     */     
/* 837 */     _setAccessibilityTheme(Toolkit.getToolkit().getThemeName());
/* 838 */     if (accessibilityTheme != null) {
/* 839 */       arrayList.add(accessibilityTheme);
/*     */     }
/*     */     
/* 842 */     AccessController.doPrivileged(() -> {
/*     */           StyleManager.getInstance().setUserAgentStylesheets(paramList);
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addNoTransparencyStylesheetToScene(Scene paramScene) {
/* 850 */     if (isCaspian()) {
/* 851 */       AccessController.doPrivileged(() -> {
/*     */             StyleManager.getInstance().addUserAgentStylesheet(paramScene, "com/sun/javafx/scene/control/skin/caspian/caspian-no-transparency.css");
/*     */             
/*     */             return null;
/*     */           });
/* 856 */     } else if (isModena()) {
/* 857 */       AccessController.doPrivileged(() -> {
/*     */             StyleManager.getInstance().addUserAgentStylesheet(paramScene, "com/sun/javafx/scene/control/skin/modena/modena-no-transparency.css");
/*     */             return null;
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isSupportedImpl(ConditionalFeature paramConditionalFeature) {
/* 866 */     switch (paramConditionalFeature) {
/*     */       case GRAPHICS:
/* 868 */         if (isGraphicsSupported == null) {
/* 869 */           isGraphicsSupported = checkForClass("javafx.stage.Stage");
/*     */         }
/* 871 */         return isGraphicsSupported.booleanValue();
/*     */       case CONTROLS:
/* 873 */         if (isControlsSupported == null) {
/* 874 */           isControlsSupported = checkForClass("javafx.scene.control.Control");
/*     */         }
/*     */         
/* 877 */         return isControlsSupported.booleanValue();
/*     */       case MEDIA:
/* 879 */         if (isMediaSupported == null) {
/* 880 */           isMediaSupported = checkForClass("javafx.scene.media.MediaView");
/*     */           
/* 882 */           if (isMediaSupported.booleanValue() && PlatformUtil.isEmbedded()) {
/* 883 */             AccessController.doPrivileged(() -> {
/*     */                   String str = System.getProperty("com.sun.javafx.experimental.embedded.media", "false");
/*     */                   
/*     */                   isMediaSupported = Boolean.valueOf(str);
/*     */                   
/*     */                   return null;
/*     */                 });
/*     */           }
/*     */         } 
/*     */         
/* 893 */         return isMediaSupported.booleanValue();
/*     */       case WEB:
/* 895 */         if (isWebSupported == null) {
/* 896 */           isWebSupported = checkForClass("javafx.scene.web.WebView");
/* 897 */           if (isWebSupported.booleanValue() && PlatformUtil.isEmbedded()) {
/* 898 */             AccessController.doPrivileged(() -> {
/*     */                   String str = System.getProperty("com.sun.javafx.experimental.embedded.web", "false");
/*     */                   
/*     */                   isWebSupported = Boolean.valueOf(str);
/*     */                   
/*     */                   return null;
/*     */                 });
/*     */           }
/*     */         } 
/*     */         
/* 908 */         return isWebSupported.booleanValue();
/*     */       case SWT:
/* 910 */         if (isSWTSupported == null) {
/* 911 */           isSWTSupported = checkForClass("javafx.embed.swt.FXCanvas");
/*     */         }
/* 913 */         return isSWTSupported.booleanValue();
/*     */       case SWING:
/* 915 */         if (isSwingSupported == null)
/*     */         {
/*     */           
/* 918 */           isSwingSupported = Boolean.valueOf((checkForClass("javax.swing.JComponent").booleanValue() && 
/* 919 */               checkForClass("javafx.embed.swing.JFXPanel").booleanValue()));
/*     */         }
/* 921 */         return isSwingSupported.booleanValue();
/*     */       case FXML:
/* 923 */         if (isFXMLSupported == null) {
/* 924 */           isFXMLSupported = Boolean.valueOf((checkForClass("javafx.fxml.FXMLLoader").booleanValue() && 
/* 925 */               checkForClass("javax.xml.stream.XMLInputFactory").booleanValue()));
/*     */         }
/* 927 */         return isFXMLSupported.booleanValue();
/*     */       case TWO_LEVEL_FOCUS:
/* 929 */         if (hasTwoLevelFocus == null) {
/* 930 */           return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*     */         }
/* 932 */         return hasTwoLevelFocus.booleanValue();
/*     */       case VIRTUAL_KEYBOARD:
/* 934 */         if (hasVirtualKeyboard == null) {
/* 935 */           return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*     */         }
/* 937 */         return hasVirtualKeyboard.booleanValue();
/*     */       case INPUT_TOUCH:
/* 939 */         if (hasTouch == null) {
/* 940 */           return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*     */         }
/* 942 */         return hasTouch.booleanValue();
/*     */       case INPUT_MULTITOUCH:
/* 944 */         if (hasMultiTouch == null) {
/* 945 */           return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*     */         }
/* 947 */         return hasMultiTouch.booleanValue();
/*     */       case INPUT_POINTER:
/* 949 */         if (hasPointer == null) {
/* 950 */           return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*     */         }
/* 952 */         return hasPointer.booleanValue();
/*     */     } 
/* 954 */     return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*     */   }
/*     */   
/*     */   public static interface FinishListener {
/*     */     void idle(boolean param1Boolean);
/*     */     
/*     */     void exitCalled();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\application\PlatformImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */