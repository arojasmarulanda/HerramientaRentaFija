/*     */ package com.sun.javafx.css;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.collections.SetChangeListener;
/*     */ import javafx.css.PseudoClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PseudoClassState
/*     */   extends BitSet<PseudoClass>
/*     */ {
/*     */   public PseudoClassState() {}
/*     */   
/*     */   PseudoClassState(List<String> paramList) {
/*  50 */     byte b1 = (paramList != null) ? paramList.size() : 0;
/*  51 */     for (byte b2 = 0; b2 < b1; b2++) {
/*  52 */       PseudoClass pseudoClass = getPseudoClass(paramList.get(b2));
/*  53 */       add(pseudoClass);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/*  60 */     return toArray((Object[])new PseudoClass[size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] paramArrayOfT) {
/*  66 */     if (paramArrayOfT.length < size()) {
/*  67 */       paramArrayOfT = (T[])new PseudoClass[size()];
/*     */     }
/*  69 */     byte b = 0;
/*  70 */     while (b < (getBits()).length) {
/*  71 */       long l = getBits()[b];
/*  72 */       for (byte b1 = 0; b1 < 64; b1++) {
/*  73 */         long l1 = 1L << b1;
/*  74 */         if ((l & l1) == l1) {
/*  75 */           int i = b * 64 + b1;
/*  76 */           PseudoClass pseudoClass = getPseudoClass(i);
/*  77 */           paramArrayOfT[b++] = (T)pseudoClass;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  82 */     return paramArrayOfT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  88 */     ArrayList<String> arrayList = new ArrayList();
/*  89 */     Iterator<PseudoClass> iterator = iterator();
/*  90 */     while (iterator.hasNext()) {
/*  91 */       arrayList.add(((PseudoClass)iterator.next()).getPseudoClassName());
/*     */     }
/*  93 */     return arrayList.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected PseudoClass cast(Object paramObject) {
/*  98 */     if (paramObject == null) {
/*  99 */       throw new NullPointerException("null arg");
/*     */     }
/* 101 */     return (PseudoClass)paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected PseudoClass getT(int paramInt) {
/* 107 */     return getPseudoClass(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getIndex(PseudoClass paramPseudoClass) {
/* 113 */     if (paramPseudoClass instanceof PseudoClassImpl) {
/* 114 */       return ((PseudoClassImpl)paramPseudoClass).getIndex();
/*     */     }
/*     */     
/* 117 */     String str = paramPseudoClass.getPseudoClassName();
/* 118 */     Integer integer = pseudoClassMap.get(str);
/*     */     
/* 120 */     if (integer == null) {
/* 121 */       integer = Integer.valueOf(pseudoClasses.size());
/* 122 */       pseudoClasses.add(new PseudoClassImpl(str, integer.intValue()));
/* 123 */       pseudoClassMap.put(str, integer);
/*     */     } 
/* 125 */     return integer.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PseudoClass getPseudoClass(String paramString) {
/* 135 */     if (paramString == null || paramString.trim().isEmpty()) {
/* 136 */       throw new IllegalArgumentException("pseudoClass cannot be null or empty String");
/*     */     }
/*     */     
/* 139 */     PseudoClass pseudoClass = null;
/*     */     
/* 141 */     Integer integer = pseudoClassMap.get(paramString);
/* 142 */     byte b = (integer != null) ? integer.intValue() : -1;
/*     */     
/* 144 */     int i = pseudoClasses.size();
/* 145 */     assert b < i;
/*     */     
/* 147 */     if (b != -1 && b < i) {
/* 148 */       pseudoClass = pseudoClasses.get(b);
/*     */     }
/*     */     
/* 151 */     if (pseudoClass == null) {
/* 152 */       pseudoClass = new PseudoClassImpl(paramString, i);
/* 153 */       pseudoClasses.add(pseudoClass);
/* 154 */       pseudoClassMap.put(paramString, Integer.valueOf(i));
/*     */     } 
/*     */     
/* 157 */     return pseudoClass;
/*     */   }
/*     */   
/*     */   static PseudoClass getPseudoClass(int paramInt) {
/* 161 */     if (0 <= paramInt && paramInt < pseudoClasses.size()) {
/* 162 */       return pseudoClasses.get(paramInt);
/*     */     }
/* 164 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 168 */   static final Map<String, Integer> pseudoClassMap = new HashMap<>(64);
/*     */ 
/*     */   
/* 171 */   static final List<PseudoClass> pseudoClasses = new ArrayList<>();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\css\PseudoClassState.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */