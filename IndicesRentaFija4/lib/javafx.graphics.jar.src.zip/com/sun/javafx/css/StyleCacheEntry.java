/*     */ package com.sun.javafx.css;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.scene.text.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StyleCacheEntry
/*     */ {
/*     */   private Map<String, CalculatedValue> calculatedValues;
/*     */   
/*     */   public CalculatedValue get(String paramString) {
/*  45 */     CalculatedValue calculatedValue = null;
/*  46 */     if (this.calculatedValues != null && !this.calculatedValues.isEmpty()) {
/*  47 */       calculatedValue = this.calculatedValues.get(paramString);
/*     */     }
/*  49 */     return calculatedValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void put(String paramString, CalculatedValue paramCalculatedValue) {
/*  54 */     if (this.calculatedValues == null) {
/*  55 */       this.calculatedValues = new HashMap<>(5);
/*     */     }
/*     */     
/*  58 */     this.calculatedValues.put(paramString, paramCalculatedValue);
/*     */   }
/*     */   
/*     */   public static final class Key
/*     */   {
/*     */     private final Set<PseudoClass>[] pseudoClassStates;
/*     */     private final double fontSize;
/*  65 */     private int hash = Integer.MIN_VALUE;
/*     */ 
/*     */     
/*     */     public Key(Set<PseudoClass>[] param1ArrayOfSet, Font param1Font) {
/*  69 */       this.pseudoClassStates = (Set<PseudoClass>[])new Set[param1ArrayOfSet.length];
/*  70 */       for (byte b = 0; b < param1ArrayOfSet.length; b++) {
/*  71 */         this.pseudoClassStates[b] = new PseudoClassState();
/*  72 */         this.pseudoClassStates[b].addAll(param1ArrayOfSet[b]);
/*     */       } 
/*  74 */       this.fontSize = (param1Font != null) ? param1Font.getSize() : Font.getDefault().getSize();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  79 */       return Arrays.toString((Object[])this.pseudoClassStates) + ", " + Arrays.toString((Object[])this.pseudoClassStates);
/*     */     }
/*     */     
/*     */     public static int hashCode(double param1Double) {
/*  83 */       long l = Double.doubleToLongBits(param1Double);
/*  84 */       return (int)(l ^ l >>> 32L);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  89 */       if (this.hash == Integer.MIN_VALUE) {
/*     */         
/*  91 */         this.hash = hashCode(this.fontSize);
/*     */         
/*  93 */         byte b1 = (this.pseudoClassStates != null) ? this.pseudoClassStates.length : 0;
/*     */         
/*  95 */         for (byte b2 = 0; b2 < b1; b2++) {
/*     */           
/*  97 */           Set<PseudoClass> set = this.pseudoClassStates[b2];
/*  98 */           if (set != null) {
/*  99 */             this.hash = 67 * (this.hash + set.hashCode());
/*     */           }
/*     */         } 
/*     */       } 
/* 103 */       return this.hash;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 109 */       if (param1Object == this) return true;
/*     */       
/* 111 */       if (param1Object == null || param1Object.getClass() != getClass()) return false;
/*     */       
/* 113 */       Key key = (Key)param1Object;
/*     */       
/* 115 */       if (this.hash != key.hash) return false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 126 */       double d = this.fontSize - key.fontSize;
/*     */       
/* 128 */       if (d < -1.0E-6D || 1.0E-6D < d) {
/* 129 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 133 */       if ((((this.pseudoClassStates == null) ? 1 : 0) ^ ((key.pseudoClassStates == null) ? 1 : 0)) != 0) {
/* 134 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 138 */       if (this.pseudoClassStates == null) {
/* 139 */         return true;
/*     */       }
/*     */       
/* 142 */       if (this.pseudoClassStates.length != key.pseudoClassStates.length) {
/* 143 */         return false;
/*     */       }
/*     */       
/* 146 */       for (byte b = 0; b < this.pseudoClassStates.length; b++) {
/*     */         
/* 148 */         Set<PseudoClass> set1 = this.pseudoClassStates[b];
/* 149 */         Set<PseudoClass> set2 = key.pseudoClassStates[b];
/*     */ 
/*     */         
/* 152 */         if ((set1 == null) ? (set2 != null) : !set1.equals(set2)) {
/* 153 */           return false;
/*     */         }
/*     */       } 
/*     */       
/* 157 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\css\StyleCacheEntry.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */