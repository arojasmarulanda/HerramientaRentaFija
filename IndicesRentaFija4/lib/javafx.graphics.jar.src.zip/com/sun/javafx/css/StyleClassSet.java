/*     */ package com.sun.javafx.css;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.collections.SetChangeListener;
/*     */ import javafx.css.StyleClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StyleClassSet
/*     */   extends BitSet<StyleClass>
/*     */ {
/*     */   public StyleClassSet() {}
/*     */   
/*     */   StyleClassSet(List<String> paramList) {
/*  50 */     byte b1 = (paramList != null) ? paramList.size() : 0;
/*  51 */     for (byte b2 = 0; b2 < b1; b2++) {
/*  52 */       String str = paramList.get(b2);
/*  53 */       if (str != null && !str.isEmpty()) {
/*     */         
/*  55 */         StyleClass styleClass = getStyleClass(str);
/*  56 */         add(styleClass);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/*  64 */     return toArray((Object[])new StyleClass[size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] paramArrayOfT) {
/*  70 */     if (paramArrayOfT.length < size()) {
/*  71 */       paramArrayOfT = (T[])new StyleClass[size()];
/*     */     }
/*  73 */     byte b = 0;
/*  74 */     while (b < (getBits()).length) {
/*  75 */       long l = getBits()[b];
/*  76 */       for (byte b1 = 0; b1 < 64; b1++) {
/*  77 */         long l1 = 1L << b1;
/*  78 */         if ((l & l1) == l1) {
/*  79 */           int i = b * 64 + b1;
/*  80 */           StyleClass styleClass = getStyleClass(i);
/*  81 */           paramArrayOfT[b++] = (T)styleClass;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  86 */     return paramArrayOfT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  92 */     StringBuilder stringBuilder = new StringBuilder("style-classes: [");
/*  93 */     Iterator<StyleClass> iterator = iterator();
/*  94 */     while (iterator.hasNext()) {
/*  95 */       stringBuilder.append(((StyleClass)iterator.next()).getStyleClassName());
/*  96 */       if (iterator.hasNext()) {
/*  97 */         stringBuilder.append(", ");
/*     */       }
/*     */     } 
/* 100 */     stringBuilder.append(']');
/* 101 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected StyleClass cast(Object paramObject) {
/* 106 */     if (paramObject == null) {
/* 107 */       throw new NullPointerException("null arg");
/*     */     }
/* 109 */     return (StyleClass)paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected StyleClass getT(int paramInt) {
/* 115 */     return getStyleClass(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getIndex(StyleClass paramStyleClass) {
/* 120 */     return paramStyleClass.getIndex();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StyleClass getStyleClass(String paramString) {
/* 128 */     if (paramString == null || paramString.trim().isEmpty()) {
/* 129 */       throw new IllegalArgumentException("styleClass cannot be null or empty String");
/*     */     }
/*     */     
/* 132 */     StyleClass styleClass = null;
/*     */     
/* 134 */     Integer integer = styleClassMap.get(paramString);
/* 135 */     byte b = (integer != null) ? integer.intValue() : -1;
/*     */     
/* 137 */     int i = styleClasses.size();
/* 138 */     assert b < i;
/*     */     
/* 140 */     if (b != -1 && b < i) {
/* 141 */       styleClass = styleClasses.get(b);
/*     */     }
/*     */     
/* 144 */     if (styleClass == null) {
/* 145 */       styleClass = new StyleClass(paramString, i);
/* 146 */       styleClasses.add(styleClass);
/* 147 */       styleClassMap.put(paramString, Integer.valueOf(i));
/*     */     } 
/*     */     
/* 150 */     return styleClass;
/*     */   }
/*     */   
/*     */   static StyleClass getStyleClass(int paramInt) {
/* 154 */     if (0 <= paramInt && paramInt < styleClasses.size()) {
/* 155 */       return styleClasses.get(paramInt);
/*     */     }
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 161 */   static final Map<String, Integer> styleClassMap = new HashMap<>(64);
/*     */ 
/*     */   
/* 164 */   static final List<StyleClass> styleClasses = new ArrayList<>();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\css\StyleClassSet.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */