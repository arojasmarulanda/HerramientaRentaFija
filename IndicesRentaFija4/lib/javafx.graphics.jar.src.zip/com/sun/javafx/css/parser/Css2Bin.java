/*    */ package com.sun.javafx.css.parser;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import javafx.css.Stylesheet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Css2Bin
/*    */ {
/*    */   public static void main(String[] paramArrayOfString) throws Exception {
/* 40 */     if (paramArrayOfString.length < 1) throw new IllegalArgumentException("expected file name as argument");
/*    */     
/*    */     try {
/* 43 */       String str1 = paramArrayOfString[0];
/*    */       
/* 45 */       String str2 = (paramArrayOfString.length > 1) ? paramArrayOfString[1] : str1.substring(0, str1.lastIndexOf('.') + 1).concat("bss");
/*    */       
/* 47 */       convertToBinary(str1, str2);
/*    */     }
/* 49 */     catch (Exception exception) {
/* 50 */       System.err.println(exception.toString());
/* 51 */       exception.printStackTrace(System.err);
/* 52 */       System.exit(-1);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void convertToBinary(String paramString1, String paramString2) throws IOException {
/* 58 */     if (paramString1 == null || paramString2 == null) {
/* 59 */       throw new IllegalArgumentException("parameters cannot be null");
/*    */     }
/*    */     
/* 62 */     if (paramString1.equals(paramString2)) {
/* 63 */       throw new IllegalArgumentException("input file and output file cannot be the same");
/*    */     }
/*    */     
/* 66 */     File file1 = new File(paramString1);
/* 67 */     File file2 = new File(paramString2);
/* 68 */     Stylesheet.convertToBinary(file1, file2);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\css\parser\Css2Bin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */