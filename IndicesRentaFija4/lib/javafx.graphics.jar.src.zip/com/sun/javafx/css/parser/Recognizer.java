package com.sun.javafx.css.parser;

@FunctionalInterface
public interface Recognizer {
  boolean recognize(int paramInt);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\css\parser\Recognizer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */