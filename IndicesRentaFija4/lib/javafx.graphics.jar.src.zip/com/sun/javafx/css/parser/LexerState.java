/*    */ package com.sun.javafx.css.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LexerState
/*    */ {
/*    */   private final int type;
/*    */   private final String name;
/*    */   private final Recognizer[] recognizers;
/*    */   
/*    */   public boolean accepts(int paramInt) {
/* 38 */     byte b1 = (this.recognizers != null) ? this.recognizers.length : 0;
/* 39 */     for (byte b2 = 0; b2 < b1; b2++) {
/* 40 */       if (this.recognizers[b2].recognize(paramInt)) return true; 
/*    */     } 
/* 42 */     return false;
/*    */   }
/*    */   
/*    */   public int getType() {
/* 46 */     return this.type;
/*    */   }
/*    */   
/*    */   public LexerState(int paramInt, String paramString, Recognizer paramRecognizer, Recognizer... paramVarArgs) {
/* 50 */     assert paramString != null;
/* 51 */     this.type = paramInt;
/* 52 */     this.name = paramString;
/* 53 */     if (paramRecognizer != null) {
/* 54 */       int i = 1 + ((paramVarArgs != null) ? paramVarArgs.length : 0);
/* 55 */       this.recognizers = new Recognizer[i];
/* 56 */       this.recognizers[0] = paramRecognizer;
/* 57 */       for (byte b = 1; b < this.recognizers.length; b++) {
/* 58 */         this.recognizers[b] = paramVarArgs[b - 1];
/*    */       }
/*    */     } else {
/* 61 */       this.recognizers = null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public LexerState(String paramString, Recognizer paramRecognizer, Recognizer... paramVarArgs) {
/* 66 */     this(0, paramString, paramRecognizer, paramVarArgs);
/*    */   }
/*    */   
/*    */   private LexerState() {
/* 70 */     this(0, "invalid", null, new Recognizer[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 78 */     return this.name;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 82 */     if (this == paramObject) return true; 
/* 83 */     return (paramObject instanceof LexerState) ? 
/* 84 */       this.name.equals(((LexerState)paramObject).name) : false;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 88 */     return this.name.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\css\parser\LexerState.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */