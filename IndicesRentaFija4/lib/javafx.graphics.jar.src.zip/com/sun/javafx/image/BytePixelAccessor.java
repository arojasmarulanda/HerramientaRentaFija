package com.sun.javafx.image;

public interface BytePixelAccessor extends BytePixelGetter, BytePixelSetter {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\BytePixelAccessor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */