package com.sun.javafx.image;

import java.nio.IntBuffer;

public interface IntPixelSetter extends PixelSetter<IntBuffer> {
  void setArgb(int[] paramArrayOfint, int paramInt1, int paramInt2);
  
  void setArgbPre(int[] paramArrayOfint, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\IntPixelSetter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */