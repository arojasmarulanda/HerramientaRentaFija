/*     */ package com.sun.javafx.image;
/*     */ 
/*     */ import com.sun.javafx.image.impl.ByteBgr;
/*     */ import com.sun.javafx.image.impl.ByteBgra;
/*     */ import com.sun.javafx.image.impl.ByteBgraPre;
/*     */ import com.sun.javafx.image.impl.ByteGray;
/*     */ import com.sun.javafx.image.impl.ByteIndexed;
/*     */ import com.sun.javafx.image.impl.ByteRgb;
/*     */ import com.sun.javafx.image.impl.General;
/*     */ import com.sun.javafx.image.impl.IntArgb;
/*     */ import com.sun.javafx.image.impl.IntArgbPre;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import javafx.scene.image.PixelFormat;
/*     */ import javafx.scene.image.WritablePixelFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PixelUtils
/*     */ {
/*     */   public static int RgbToGray(int paramInt1, int paramInt2, int paramInt3) {
/*  47 */     return (int)(paramInt1 * 0.3D + paramInt2 * 0.59D + paramInt3 * 0.11D);
/*     */   }
/*     */   
/*     */   public static int RgbToGray(int paramInt) {
/*  51 */     return RgbToGray(paramInt >> 16 & 0xFF, paramInt >> 8 & 0xFF, paramInt & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int NonPretoPre(int paramInt1, int paramInt2) {
/*  57 */     if (paramInt2 == 255) return paramInt1; 
/*  58 */     if (paramInt2 == 0) return 0; 
/*  59 */     return (paramInt1 * paramInt2 + 127) / 255;
/*     */   }
/*     */   
/*     */   public static int PreToNonPre(int paramInt1, int paramInt2) {
/*  63 */     if (paramInt2 == 255 || paramInt2 == 0) return paramInt1; 
/*  64 */     return (paramInt1 >= paramInt2) ? 255 : ((paramInt1 * 255 + (paramInt2 >> 1)) / paramInt2);
/*     */   }
/*     */   
/*     */   public static int NonPretoPre(int paramInt) {
/*  68 */     int i = paramInt >>> 24;
/*  69 */     if (i == 255) return paramInt; 
/*  70 */     if (i == 0) return 0; 
/*  71 */     int j = paramInt >> 16 & 0xFF;
/*  72 */     int k = paramInt >> 8 & 0xFF;
/*  73 */     int m = paramInt & 0xFF;
/*  74 */     j = (j * i + 127) / 255;
/*  75 */     k = (k * i + 127) / 255;
/*  76 */     m = (m * i + 127) / 255;
/*  77 */     return i << 24 | j << 16 | k << 8 | m;
/*     */   }
/*     */   
/*     */   public static int PretoNonPre(int paramInt) {
/*  81 */     int i = paramInt >>> 24;
/*  82 */     if (i == 255 || i == 0) return paramInt; 
/*  83 */     int j = paramInt >> 16 & 0xFF;
/*  84 */     int k = paramInt >> 8 & 0xFF;
/*  85 */     int m = paramInt & 0xFF;
/*  86 */     int n = i >> 1;
/*  87 */     j = (j >= i) ? 255 : ((j * 255 + n) / i);
/*  88 */     k = (k >= i) ? 255 : ((k * 255 + n) / i);
/*  89 */     m = (m >= i) ? 255 : ((m * 255 + n) / i);
/*  90 */     return i << 24 | j << 16 | k << 8 | m;
/*     */   }
/*     */   
/*     */   public static BytePixelGetter getByteGetter(PixelFormat<ByteBuffer> paramPixelFormat) {
/*  94 */     switch (paramPixelFormat.getType()) {
/*     */       case BYTE_BGRA:
/*  96 */         return ByteBgra.getter;
/*     */       case BYTE_BGRA_PRE:
/*  98 */         return ByteBgraPre.getter;
/*     */       case BYTE_RGB:
/* 100 */         return ByteRgb.getter;
/*     */       case BYTE_INDEXED:
/* 102 */         return ByteIndexed.createGetter(paramPixelFormat);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 107 */     return null;
/*     */   }
/*     */   
/*     */   public static IntPixelGetter getIntGetter(PixelFormat<IntBuffer> paramPixelFormat) {
/* 111 */     switch (paramPixelFormat.getType()) {
/*     */       case INT_ARGB:
/* 113 */         return IntArgb.getter;
/*     */       case INT_ARGB_PRE:
/* 115 */         return IntArgbPre.getter;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     return null;
/*     */   }
/*     */   
/*     */   public static <T extends java.nio.Buffer> PixelGetter<T> getGetter(PixelFormat<T> paramPixelFormat) {
/* 126 */     switch (paramPixelFormat.getType()) {
/*     */       case BYTE_BGRA:
/*     */       case BYTE_BGRA_PRE:
/*     */       case BYTE_RGB:
/*     */       case BYTE_INDEXED:
/* 131 */         return getByteGetter((PixelFormat)paramPixelFormat);
/*     */       case INT_ARGB:
/*     */       case INT_ARGB_PRE:
/* 134 */         return getIntGetter((PixelFormat)paramPixelFormat);
/*     */     } 
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   public static BytePixelSetter getByteSetter(WritablePixelFormat<ByteBuffer> paramWritablePixelFormat) {
/* 140 */     switch (paramWritablePixelFormat.getType()) {
/*     */       case BYTE_BGRA:
/* 142 */         return ByteBgra.setter;
/*     */       case BYTE_BGRA_PRE:
/* 144 */         return ByteBgraPre.setter;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     return null;
/*     */   }
/*     */   
/*     */   public static IntPixelSetter getIntSetter(WritablePixelFormat<IntBuffer> paramWritablePixelFormat) {
/* 156 */     switch (paramWritablePixelFormat.getType()) {
/*     */       case INT_ARGB:
/* 158 */         return IntArgb.setter;
/*     */       case INT_ARGB_PRE:
/* 160 */         return IntArgbPre.setter;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     return null;
/*     */   }
/*     */   
/*     */   public static <T extends java.nio.Buffer> PixelSetter<T> getSetter(WritablePixelFormat<T> paramWritablePixelFormat) {
/* 171 */     switch (paramWritablePixelFormat.getType()) {
/*     */       case BYTE_BGRA:
/*     */       case BYTE_BGRA_PRE:
/* 174 */         return getByteSetter((WritablePixelFormat)paramWritablePixelFormat);
/*     */       case INT_ARGB:
/*     */       case INT_ARGB_PRE:
/* 177 */         return getIntSetter((WritablePixelFormat)paramWritablePixelFormat);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends java.nio.Buffer, U extends java.nio.Buffer> PixelConverter<T, U> getConverter(PixelGetter<T> paramPixelGetter, PixelSetter<U> paramPixelSetter) {
/* 188 */     if (paramPixelGetter instanceof BytePixelGetter) {
/* 189 */       if (paramPixelSetter instanceof BytePixelSetter) {
/* 190 */         return 
/* 191 */           getB2BConverter((BytePixelGetter)paramPixelGetter, (BytePixelSetter)paramPixelSetter);
/*     */       }
/* 193 */       return 
/* 194 */         getB2IConverter((BytePixelGetter)paramPixelGetter, (IntPixelSetter)paramPixelSetter);
/*     */     } 
/*     */     
/* 197 */     if (paramPixelSetter instanceof BytePixelSetter) {
/* 198 */       return 
/* 199 */         getI2BConverter((IntPixelGetter)paramPixelGetter, (BytePixelSetter)paramPixelSetter);
/*     */     }
/* 201 */     return 
/* 202 */       getI2IConverter((IntPixelGetter)paramPixelGetter, (IntPixelSetter)paramPixelSetter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteToBytePixelConverter getB2BConverter(PixelGetter<ByteBuffer> paramPixelGetter, PixelSetter<ByteBuffer> paramPixelSetter) {
/* 210 */     if (paramPixelGetter == ByteBgra.getter) {
/* 211 */       if (paramPixelSetter == ByteBgra.setter)
/* 212 */         return ByteBgra.ToByteBgraConverter(); 
/* 213 */       if (paramPixelSetter == ByteBgraPre.setter) {
/* 214 */         return ByteBgra.ToByteBgraPreConverter();
/*     */       }
/* 216 */     } else if (paramPixelGetter == ByteBgraPre.getter) {
/* 217 */       if (paramPixelSetter == ByteBgra.setter)
/* 218 */         return ByteBgraPre.ToByteBgraConverter(); 
/* 219 */       if (paramPixelSetter == ByteBgraPre.setter) {
/* 220 */         return ByteBgraPre.ToByteBgraPreConverter();
/*     */       }
/* 222 */     } else if (paramPixelGetter == ByteRgb.getter) {
/* 223 */       if (paramPixelSetter == ByteBgra.setter)
/* 224 */         return ByteRgb.ToByteBgraConverter(); 
/* 225 */       if (paramPixelSetter == ByteBgraPre.setter)
/* 226 */         return ByteRgb.ToByteBgraPreConverter(); 
/* 227 */       if (paramPixelSetter == ByteBgr.setter) {
/* 228 */         return ByteRgb.ToByteBgrConverter();
/*     */       }
/* 230 */     } else if (paramPixelGetter == ByteBgr.getter) {
/* 231 */       if (paramPixelSetter == ByteBgr.setter)
/* 232 */         return ByteBgr.ToByteBgrConverter(); 
/* 233 */       if (paramPixelSetter == ByteBgra.setter)
/* 234 */         return ByteBgr.ToByteBgraConverter(); 
/* 235 */       if (paramPixelSetter == ByteBgraPre.setter) {
/* 236 */         return ByteBgr.ToByteBgraPreConverter();
/*     */       }
/* 238 */     } else if (paramPixelGetter == ByteGray.getter) {
/* 239 */       if (paramPixelSetter == ByteGray.setter)
/* 240 */         return ByteGray.ToByteGrayConverter(); 
/* 241 */       if (paramPixelSetter == ByteBgr.setter)
/* 242 */         return ByteGray.ToByteBgrConverter(); 
/* 243 */       if (paramPixelSetter == ByteBgra.setter)
/* 244 */         return ByteGray.ToByteBgraConverter(); 
/* 245 */       if (paramPixelSetter == ByteBgraPre.setter) {
/* 246 */         return ByteGray.ToByteBgraPreConverter();
/*     */       }
/* 248 */     } else if (paramPixelGetter instanceof ByteIndexed.Getter && (
/* 249 */       paramPixelSetter == ByteBgra.setter || paramPixelSetter == ByteBgraPre.setter)) {
/* 250 */       return ByteIndexed.createToByteBgraAny((BytePixelGetter)paramPixelGetter, (BytePixelSetter)paramPixelSetter);
/*     */     } 
/*     */ 
/*     */     
/* 254 */     if (paramPixelSetter == ByteGray.setter) {
/* 255 */       return null;
/*     */     }
/* 257 */     if (paramPixelGetter.getAlphaType() != AlphaType.OPAQUE && paramPixelSetter
/* 258 */       .getAlphaType() == AlphaType.OPAQUE)
/*     */     {
/* 260 */       return null;
/*     */     }
/* 262 */     return General.create((BytePixelGetter)paramPixelGetter, (BytePixelSetter)paramPixelSetter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteToIntPixelConverter getB2IConverter(PixelGetter<ByteBuffer> paramPixelGetter, PixelSetter<IntBuffer> paramPixelSetter) {
/* 268 */     if (paramPixelGetter == ByteBgra.getter) {
/* 269 */       if (paramPixelSetter == IntArgb.setter)
/* 270 */         return ByteBgra.ToIntArgbConverter(); 
/* 271 */       if (paramPixelSetter == IntArgbPre.setter) {
/* 272 */         return ByteBgra.ToIntArgbPreConverter();
/*     */       }
/* 274 */     } else if (paramPixelGetter == ByteBgraPre.getter) {
/* 275 */       if (paramPixelSetter == IntArgb.setter)
/* 276 */         return ByteBgraPre.ToIntArgbConverter(); 
/* 277 */       if (paramPixelSetter == IntArgbPre.setter) {
/* 278 */         return ByteBgraPre.ToIntArgbPreConverter();
/*     */       }
/* 280 */     } else if (paramPixelGetter == ByteRgb.getter) {
/* 281 */       if (paramPixelSetter == IntArgb.setter)
/* 282 */         return ByteRgb.ToIntArgbConverter(); 
/* 283 */       if (paramPixelSetter == IntArgbPre.setter) {
/* 284 */         return ByteRgb.ToIntArgbPreConverter();
/*     */       }
/* 286 */     } else if (paramPixelGetter == ByteBgr.getter) {
/* 287 */       if (paramPixelSetter == IntArgb.setter)
/* 288 */         return ByteBgr.ToIntArgbConverter(); 
/* 289 */       if (paramPixelSetter == IntArgbPre.setter) {
/* 290 */         return ByteBgr.ToIntArgbPreConverter();
/*     */       }
/* 292 */     } else if (paramPixelGetter == ByteGray.getter) {
/* 293 */       if (paramPixelSetter == IntArgbPre.setter)
/* 294 */         return ByteGray.ToIntArgbPreConverter(); 
/* 295 */       if (paramPixelSetter == IntArgb.setter) {
/* 296 */         return ByteGray.ToIntArgbConverter();
/*     */       }
/* 298 */     } else if (paramPixelGetter instanceof ByteIndexed.Getter && (
/* 299 */       paramPixelSetter == IntArgb.setter || paramPixelSetter == IntArgbPre.setter)) {
/* 300 */       return ByteIndexed.createToIntArgbAny((BytePixelGetter)paramPixelGetter, (IntPixelSetter)paramPixelSetter);
/*     */     } 
/*     */ 
/*     */     
/* 304 */     if (paramPixelGetter.getAlphaType() != AlphaType.OPAQUE && paramPixelSetter
/* 305 */       .getAlphaType() == AlphaType.OPAQUE)
/*     */     {
/* 307 */       return null;
/*     */     }
/* 309 */     return General.create((BytePixelGetter)paramPixelGetter, (IntPixelSetter)paramPixelSetter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntToBytePixelConverter getI2BConverter(PixelGetter<IntBuffer> paramPixelGetter, PixelSetter<ByteBuffer> paramPixelSetter) {
/* 315 */     if (paramPixelGetter == IntArgb.getter) {
/* 316 */       if (paramPixelSetter == ByteBgra.setter)
/* 317 */         return IntArgb.ToByteBgraConverter(); 
/* 318 */       if (paramPixelSetter == ByteBgraPre.setter) {
/* 319 */         return IntArgb.ToByteBgraPreConverter();
/*     */       }
/* 321 */     } else if (paramPixelGetter == IntArgbPre.getter) {
/* 322 */       if (paramPixelSetter == ByteBgra.setter)
/* 323 */         return IntArgbPre.ToByteBgraConverter(); 
/* 324 */       if (paramPixelSetter == ByteBgraPre.setter) {
/* 325 */         return IntArgbPre.ToByteBgraPreConverter();
/*     */       }
/*     */     } 
/* 328 */     if (paramPixelSetter == ByteGray.setter) {
/* 329 */       return null;
/*     */     }
/* 331 */     if (paramPixelGetter.getAlphaType() != AlphaType.OPAQUE && paramPixelSetter
/* 332 */       .getAlphaType() == AlphaType.OPAQUE)
/*     */     {
/* 334 */       return null;
/*     */     }
/* 336 */     return General.create((IntPixelGetter)paramPixelGetter, (BytePixelSetter)paramPixelSetter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntToIntPixelConverter getI2IConverter(PixelGetter<IntBuffer> paramPixelGetter, PixelSetter<IntBuffer> paramPixelSetter) {
/* 342 */     if (paramPixelGetter == IntArgb.getter) {
/* 343 */       if (paramPixelSetter == IntArgb.setter)
/* 344 */         return IntArgb.ToIntArgbConverter(); 
/* 345 */       if (paramPixelSetter == IntArgbPre.setter) {
/* 346 */         return IntArgb.ToIntArgbPreConverter();
/*     */       }
/* 348 */     } else if (paramPixelGetter == IntArgbPre.getter) {
/* 349 */       if (paramPixelSetter == IntArgb.setter)
/* 350 */         return IntArgbPre.ToIntArgbConverter(); 
/* 351 */       if (paramPixelSetter == IntArgbPre.setter) {
/* 352 */         return IntArgbPre.ToIntArgbPreConverter();
/*     */       }
/*     */     } 
/* 355 */     if (paramPixelGetter.getAlphaType() != AlphaType.OPAQUE && paramPixelSetter
/* 356 */       .getAlphaType() == AlphaType.OPAQUE)
/*     */     {
/* 358 */       return null;
/*     */     }
/* 360 */     return General.create((IntPixelGetter)paramPixelGetter, (IntPixelSetter)paramPixelSetter);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\PixelUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */