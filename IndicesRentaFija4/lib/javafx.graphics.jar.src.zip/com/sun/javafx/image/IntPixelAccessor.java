package com.sun.javafx.image;

public interface IntPixelAccessor extends IntPixelGetter, IntPixelSetter {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\IntPixelAccessor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */