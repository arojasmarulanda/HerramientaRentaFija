package com.sun.javafx.image;

import java.nio.ByteBuffer;

public interface ByteToBytePixelConverter extends PixelConverter<ByteBuffer, ByteBuffer> {
  void convert(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  void convert(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  void convert(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\ByteToBytePixelConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */