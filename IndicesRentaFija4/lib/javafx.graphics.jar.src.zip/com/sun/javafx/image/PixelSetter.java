package com.sun.javafx.image;

public interface PixelSetter<T extends java.nio.Buffer> {
  AlphaType getAlphaType();
  
  int getNumElements();
  
  void setArgb(T paramT, int paramInt1, int paramInt2);
  
  void setArgbPre(T paramT, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\PixelSetter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */