package com.sun.javafx.image;

public interface PixelAccessor<T extends java.nio.Buffer> extends PixelGetter<T>, PixelSetter<T> {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\PixelAccessor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */