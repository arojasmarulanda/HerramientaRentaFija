package com.sun.javafx.image;

public interface PixelGetter<T extends java.nio.Buffer> {
  AlphaType getAlphaType();
  
  int getNumElements();
  
  int getArgb(T paramT, int paramInt);
  
  int getArgbPre(T paramT, int paramInt);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\PixelGetter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */