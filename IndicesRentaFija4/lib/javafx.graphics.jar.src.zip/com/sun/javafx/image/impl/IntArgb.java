/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.IntPixelAccessor;
/*     */ import com.sun.javafx.image.IntPixelGetter;
/*     */ import com.sun.javafx.image.IntPixelSetter;
/*     */ import com.sun.javafx.image.IntToBytePixelConverter;
/*     */ import com.sun.javafx.image.IntToIntPixelConverter;
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntArgb
/*     */ {
/*  39 */   public static final IntPixelGetter getter = Accessor.instance;
/*  40 */   public static final IntPixelSetter setter = Accessor.instance;
/*  41 */   public static final IntPixelAccessor accessor = Accessor.instance;
/*     */   private static IntToBytePixelConverter ToByteBgraObj;
/*     */   
/*     */   public static IntToBytePixelConverter ToByteBgraConverter() {
/*  45 */     if (ToByteBgraObj == null) {
/*  46 */       ToByteBgraObj = new IntTo4ByteSameConverter(getter, ByteBgra.setter);
/*     */     }
/*  48 */     return ToByteBgraObj;
/*     */   }
/*     */   private static IntToIntPixelConverter ToIntArgbObj;
/*     */   public static IntToBytePixelConverter ToByteBgraPreConverter() {
/*  52 */     return ToByteBgraPreConv.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public static IntToIntPixelConverter ToIntArgbConverter() {
/*  57 */     if (ToIntArgbObj == null) {
/*  58 */       ToIntArgbObj = BaseIntToIntConverter.create(accessor);
/*     */     }
/*  60 */     return ToIntArgbObj;
/*     */   }
/*     */   
/*     */   public static IntToIntPixelConverter ToIntArgbPreConverter() {
/*  64 */     return ToIntArgbPreConv.instance;
/*     */   }
/*     */   
/*     */   static class Accessor implements IntPixelAccessor {
/*  68 */     static final IntPixelAccessor instance = new Accessor();
/*     */ 
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  73 */       return AlphaType.NONPREMULTIPLIED;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  78 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(int[] param1ArrayOfint, int param1Int) {
/*  83 */       return param1ArrayOfint[param1Int];
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(int[] param1ArrayOfint, int param1Int) {
/*  88 */       return PixelUtils.NonPretoPre(param1ArrayOfint[param1Int]);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(IntBuffer param1IntBuffer, int param1Int) {
/*  93 */       return param1IntBuffer.get(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(IntBuffer param1IntBuffer, int param1Int) {
/*  98 */       return PixelUtils.NonPretoPre(param1IntBuffer.get(param1Int));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(int[] param1ArrayOfint, int param1Int1, int param1Int2) {
/* 103 */       param1ArrayOfint[param1Int1] = param1Int2;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(int[] param1ArrayOfint, int param1Int1, int param1Int2) {
/* 108 */       param1ArrayOfint[param1Int1] = PixelUtils.PretoNonPre(param1Int2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(IntBuffer param1IntBuffer, int param1Int1, int param1Int2) {
/* 113 */       param1IntBuffer.put(param1Int1, param1Int2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(IntBuffer param1IntBuffer, int param1Int1, int param1Int2) {
/* 118 */       param1IntBuffer.put(param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ToIntArgbPreConv extends BaseIntToIntConverter {
/* 123 */     public static final IntToIntPixelConverter instance = new ToIntArgbPreConv();
/*     */ 
/*     */     
/*     */     private ToIntArgbPreConv() {
/* 127 */       super(IntArgb.getter, IntArgbPre.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(int[] param1ArrayOfint1, int param1Int1, int param1Int2, int[] param1ArrayOfint2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 135 */       param1Int2 -= param1Int5;
/* 136 */       param1Int4 -= param1Int5;
/* 137 */       while (--param1Int6 >= 0) {
/* 138 */         for (byte b = 0; b < param1Int5; b++) {
/* 139 */           int i = param1ArrayOfint1[param1Int1++];
/* 140 */           int j = i >>> 24;
/* 141 */           if (j < 255) {
/* 142 */             if (j == 0) {
/* 143 */               i = 0;
/*     */             } else {
/* 145 */               int k = ((i >> 16 & 0xFF) * j + 127) / 255;
/* 146 */               int m = ((i >> 8 & 0xFF) * j + 127) / 255;
/* 147 */               int n = ((i & 0xFF) * j + 127) / 255;
/* 148 */               i = j << 24 | k << 16 | m << 8 | n;
/*     */             } 
/*     */           }
/* 151 */           param1ArrayOfint2[param1Int3++] = i;
/*     */         } 
/* 153 */         param1Int1 += param1Int2;
/* 154 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(IntBuffer param1IntBuffer1, int param1Int1, int param1Int2, IntBuffer param1IntBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 163 */       while (--param1Int6 >= 0) {
/* 164 */         for (byte b = 0; b < param1Int5; b++) {
/* 165 */           int i = param1IntBuffer1.get(param1Int1 + b);
/* 166 */           int j = i >>> 24;
/* 167 */           if (j < 255) {
/* 168 */             if (j == 0) {
/* 169 */               i = 0;
/*     */             } else {
/* 171 */               int k = ((i >> 16 & 0xFF) * j + 127) / 255;
/* 172 */               int m = ((i >> 8 & 0xFF) * j + 127) / 255;
/* 173 */               int n = ((i & 0xFF) * j + 127) / 255;
/* 174 */               i = j << 24 | k << 16 | m << 8 | n;
/*     */             } 
/*     */           }
/* 177 */           param1IntBuffer2.put(param1Int3 + b, i);
/*     */         } 
/* 179 */         param1Int1 += param1Int2;
/* 180 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteBgraPreConv extends BaseIntToByteConverter {
/* 186 */     public static final IntToBytePixelConverter instance = new ToByteBgraPreConv();
/*     */ 
/*     */     
/*     */     private ToByteBgraPreConv() {
/* 190 */       super(IntArgb.getter, ByteBgraPre.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(int[] param1ArrayOfint, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 198 */       param1Int2 -= param1Int5;
/* 199 */       param1Int4 -= param1Int5 * 4;
/* 200 */       while (--param1Int6 >= 0) {
/* 201 */         for (byte b = 0; b < param1Int5; b++) {
/* 202 */           int i = param1ArrayOfint[param1Int1++];
/* 203 */           int j = i >>> 24;
/* 204 */           int k = i >> 16;
/* 205 */           int m = i >> 8;
/* 206 */           int n = i;
/* 207 */           if (j < 255) {
/* 208 */             if (j == 0) {
/* 209 */               n = m = k = 0;
/*     */             } else {
/* 211 */               n = ((n & 0xFF) * j + 127) / 255;
/* 212 */               m = ((m & 0xFF) * j + 127) / 255;
/* 213 */               k = ((k & 0xFF) * j + 127) / 255;
/*     */             } 
/*     */           }
/* 216 */           param1ArrayOfbyte[param1Int3++] = (byte)n;
/* 217 */           param1ArrayOfbyte[param1Int3++] = (byte)m;
/* 218 */           param1ArrayOfbyte[param1Int3++] = (byte)k;
/* 219 */           param1ArrayOfbyte[param1Int3++] = (byte)j;
/*     */         } 
/* 221 */         param1Int1 += param1Int2;
/* 222 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(IntBuffer param1IntBuffer, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 231 */       param1Int4 -= param1Int5 * 4;
/* 232 */       while (--param1Int6 >= 0) {
/* 233 */         for (byte b = 0; b < param1Int5; b++) {
/* 234 */           int i = param1IntBuffer.get(param1Int1 + b);
/* 235 */           int j = i >>> 24;
/* 236 */           int k = i >> 16;
/* 237 */           int m = i >> 8;
/* 238 */           int n = i;
/* 239 */           if (j < 255) {
/* 240 */             if (j == 0) {
/* 241 */               n = m = k = 0;
/*     */             } else {
/* 243 */               n = ((n & 0xFF) * j + 127) / 255;
/* 244 */               m = ((m & 0xFF) * j + 127) / 255;
/* 245 */               k = ((k & 0xFF) * j + 127) / 255;
/*     */             } 
/*     */           }
/* 248 */           param1ByteBuffer.put(param1Int3, (byte)n);
/* 249 */           param1ByteBuffer.put(param1Int3 + 1, (byte)m);
/* 250 */           param1ByteBuffer.put(param1Int3 + 2, (byte)k);
/* 251 */           param1ByteBuffer.put(param1Int3 + 3, (byte)j);
/* 252 */           param1Int3 += 4;
/*     */         } 
/* 254 */         param1Int1 += param1Int2;
/* 255 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\IntArgb.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */