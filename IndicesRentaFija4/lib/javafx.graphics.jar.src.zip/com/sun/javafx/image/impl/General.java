/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*     */ import com.sun.javafx.image.ByteToIntPixelConverter;
/*     */ import com.sun.javafx.image.IntPixelGetter;
/*     */ import com.sun.javafx.image.IntPixelSetter;
/*     */ import com.sun.javafx.image.IntToBytePixelConverter;
/*     */ import com.sun.javafx.image.IntToIntPixelConverter;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class General
/*     */ {
/*     */   public static ByteToBytePixelConverter create(BytePixelGetter paramBytePixelGetter, BytePixelSetter paramBytePixelSetter) {
/*  44 */     return new ByteToByteGeneralConverter(paramBytePixelGetter, paramBytePixelSetter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteToIntPixelConverter create(BytePixelGetter paramBytePixelGetter, IntPixelSetter paramIntPixelSetter) {
/*  50 */     return new ByteToIntGeneralConverter(paramBytePixelGetter, paramIntPixelSetter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntToBytePixelConverter create(IntPixelGetter paramIntPixelGetter, BytePixelSetter paramBytePixelSetter) {
/*  56 */     return new IntToByteGeneralConverter(paramIntPixelGetter, paramBytePixelSetter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntToIntPixelConverter create(IntPixelGetter paramIntPixelGetter, IntPixelSetter paramIntPixelSetter) {
/*  62 */     return new IntToIntGeneralConverter(paramIntPixelGetter, paramIntPixelSetter);
/*     */   }
/*     */   
/*     */   static class ByteToByteGeneralConverter extends BaseByteToByteConverter {
/*     */     boolean usePremult;
/*     */     
/*     */     ByteToByteGeneralConverter(BytePixelGetter param1BytePixelGetter, BytePixelSetter param1BytePixelSetter) {
/*  69 */       super(param1BytePixelGetter, param1BytePixelSetter);
/*  70 */       this
/*  71 */         .usePremult = (param1BytePixelGetter.getAlphaType() != AlphaType.NONPREMULTIPLIED && param1BytePixelSetter.getAlphaType() != AlphaType.NONPREMULTIPLIED);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/*  79 */       param1Int2 -= this.nSrcElems * param1Int5;
/*  80 */       param1Int4 -= this.nDstElems * param1Int5;
/*  81 */       while (--param1Int6 >= 0) {
/*  82 */         for (byte b = 0; b < param1Int5; b++) {
/*  83 */           if (this.usePremult) {
/*  84 */             this.setter.setArgbPre(param1ArrayOfbyte2, param1Int3, this.getter.getArgbPre(param1ArrayOfbyte1, param1Int1));
/*     */           } else {
/*  86 */             this.setter.setArgb(param1ArrayOfbyte2, param1Int3, this.getter.getArgb(param1ArrayOfbyte1, param1Int1));
/*     */           } 
/*  88 */           param1Int1 += this.nSrcElems;
/*  89 */           param1Int3 += this.nDstElems;
/*     */         } 
/*  91 */         param1Int1 += param1Int2;
/*  92 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 101 */       param1Int2 -= this.nSrcElems * param1Int5;
/* 102 */       param1Int4 -= this.nDstElems * param1Int5;
/* 103 */       while (--param1Int6 >= 0) {
/* 104 */         for (byte b = 0; b < param1Int5; b++) {
/* 105 */           if (this.usePremult) {
/* 106 */             this.setter.setArgbPre(param1ByteBuffer2, param1Int3, this.getter.getArgbPre(param1ByteBuffer1, param1Int1));
/*     */           } else {
/* 108 */             this.setter.setArgb(param1ByteBuffer2, param1Int3, this.getter.getArgb(param1ByteBuffer1, param1Int1));
/*     */           } 
/* 110 */           param1Int1 += this.nSrcElems;
/* 111 */           param1Int3 += this.nDstElems;
/*     */         } 
/* 113 */         param1Int1 += param1Int2;
/* 114 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ByteToIntGeneralConverter extends BaseByteToIntConverter {
/*     */     boolean usePremult;
/*     */     
/*     */     ByteToIntGeneralConverter(BytePixelGetter param1BytePixelGetter, IntPixelSetter param1IntPixelSetter) {
/* 123 */       super(param1BytePixelGetter, param1IntPixelSetter);
/* 124 */       this
/* 125 */         .usePremult = (param1BytePixelGetter.getAlphaType() != AlphaType.NONPREMULTIPLIED && param1IntPixelSetter.getAlphaType() != AlphaType.NONPREMULTIPLIED);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 133 */       param1Int2 -= this.nSrcElems * param1Int5;
/* 134 */       param1Int4 -= param1Int5;
/* 135 */       while (--param1Int6 >= 0) {
/* 136 */         for (byte b = 0; b < param1Int5; b++) {
/* 137 */           if (this.usePremult) {
/* 138 */             this.setter.setArgbPre(param1ArrayOfint, param1Int3, this.getter.getArgbPre(param1ArrayOfbyte, param1Int1));
/*     */           } else {
/* 140 */             this.setter.setArgb(param1ArrayOfint, param1Int3, this.getter.getArgb(param1ArrayOfbyte, param1Int1));
/*     */           } 
/* 142 */           param1Int1 += this.nSrcElems;
/* 143 */           param1Int3++;
/*     */         } 
/* 145 */         param1Int1 += param1Int2;
/* 146 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2, IntBuffer param1IntBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 155 */       param1Int2 -= this.nSrcElems * param1Int5;
/* 156 */       param1Int4 -= param1Int5;
/* 157 */       while (--param1Int6 >= 0) {
/* 158 */         for (byte b = 0; b < param1Int5; b++) {
/* 159 */           if (this.usePremult) {
/* 160 */             this.setter.setArgbPre(param1IntBuffer, param1Int3, this.getter.getArgbPre(param1ByteBuffer, param1Int1));
/*     */           } else {
/* 162 */             this.setter.setArgb(param1IntBuffer, param1Int3, this.getter.getArgb(param1ByteBuffer, param1Int1));
/*     */           } 
/* 164 */           param1Int1 += this.nSrcElems;
/* 165 */           param1Int3++;
/*     */         } 
/* 167 */         param1Int1 += param1Int2;
/* 168 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class IntToByteGeneralConverter
/*     */     extends BaseIntToByteConverter {
/*     */     public IntToByteGeneralConverter(IntPixelGetter param1IntPixelGetter, BytePixelSetter param1BytePixelSetter) {
/* 176 */       super(param1IntPixelGetter, param1BytePixelSetter);
/* 177 */       this
/* 178 */         .usePremult = (param1IntPixelGetter.getAlphaType() != AlphaType.NONPREMULTIPLIED && param1BytePixelSetter.getAlphaType() != AlphaType.NONPREMULTIPLIED);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean usePremult;
/*     */ 
/*     */     
/*     */     void doConvert(int[] param1ArrayOfint, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 186 */       param1Int2 -= param1Int5;
/* 187 */       param1Int4 -= this.nDstElems * param1Int5;
/* 188 */       while (--param1Int6 >= 0) {
/* 189 */         for (byte b = 0; b < param1Int5; b++) {
/* 190 */           if (this.usePremult) {
/* 191 */             this.setter.setArgbPre(param1ArrayOfbyte, param1Int3, this.getter.getArgbPre(param1ArrayOfint, param1Int1));
/*     */           } else {
/* 193 */             this.setter.setArgb(param1ArrayOfbyte, param1Int3, this.getter.getArgb(param1ArrayOfint, param1Int1));
/*     */           } 
/* 195 */           param1Int1++;
/* 196 */           param1Int3 += this.nDstElems;
/*     */         } 
/* 198 */         param1Int1 += param1Int2;
/* 199 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(IntBuffer param1IntBuffer, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 208 */       param1Int2 -= param1Int5;
/* 209 */       param1Int4 -= this.nDstElems * param1Int5;
/* 210 */       while (--param1Int6 >= 0) {
/* 211 */         for (byte b = 0; b < param1Int5; b++) {
/* 212 */           if (this.usePremult) {
/* 213 */             this.setter.setArgbPre(param1ByteBuffer, param1Int3, this.getter.getArgbPre(param1IntBuffer, param1Int1));
/*     */           } else {
/* 215 */             this.setter.setArgb(param1ByteBuffer, param1Int3, this.getter.getArgb(param1IntBuffer, param1Int1));
/*     */           } 
/* 217 */           param1Int1++;
/* 218 */           param1Int3 += this.nDstElems;
/*     */         } 
/* 220 */         param1Int1 += param1Int2;
/* 221 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class IntToIntGeneralConverter
/*     */     extends BaseIntToIntConverter {
/*     */     public IntToIntGeneralConverter(IntPixelGetter param1IntPixelGetter, IntPixelSetter param1IntPixelSetter) {
/* 229 */       super(param1IntPixelGetter, param1IntPixelSetter);
/* 230 */       this
/* 231 */         .usePremult = (param1IntPixelGetter.getAlphaType() != AlphaType.NONPREMULTIPLIED && param1IntPixelSetter.getAlphaType() != AlphaType.NONPREMULTIPLIED);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean usePremult;
/*     */ 
/*     */     
/*     */     void doConvert(int[] param1ArrayOfint1, int param1Int1, int param1Int2, int[] param1ArrayOfint2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 239 */       param1Int2 -= param1Int5;
/* 240 */       param1Int4 -= param1Int5;
/* 241 */       while (--param1Int6 >= 0) {
/* 242 */         for (byte b = 0; b < param1Int5; b++) {
/* 243 */           if (this.usePremult) {
/* 244 */             this.setter.setArgbPre(param1ArrayOfint2, param1Int3, this.getter.getArgbPre(param1ArrayOfint1, param1Int1));
/*     */           } else {
/* 246 */             this.setter.setArgb(param1ArrayOfint2, param1Int3, this.getter.getArgb(param1ArrayOfint1, param1Int1));
/*     */           } 
/* 248 */           param1Int1++;
/* 249 */           param1Int3++;
/*     */         } 
/* 251 */         param1Int1 += param1Int2;
/* 252 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(IntBuffer param1IntBuffer1, int param1Int1, int param1Int2, IntBuffer param1IntBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 261 */       param1Int2 -= param1Int5;
/* 262 */       param1Int4 -= param1Int5;
/* 263 */       while (--param1Int6 >= 0) {
/* 264 */         for (byte b = 0; b < param1Int5; b++) {
/* 265 */           if (this.usePremult) {
/* 266 */             this.setter.setArgbPre(param1IntBuffer2, param1Int3, this.getter.getArgbPre(param1IntBuffer1, param1Int1));
/*     */           } else {
/* 268 */             this.setter.setArgb(param1IntBuffer2, param1Int3, this.getter.getArgb(param1IntBuffer1, param1Int1));
/*     */           } 
/* 270 */           param1Int1++;
/* 271 */           param1Int3++;
/*     */         } 
/* 273 */         param1Int1 += param1Int2;
/* 274 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\General.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */