/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.IntPixelAccessor;
/*     */ import com.sun.javafx.image.IntPixelGetter;
/*     */ import com.sun.javafx.image.IntPixelSetter;
/*     */ import com.sun.javafx.image.IntToBytePixelConverter;
/*     */ import com.sun.javafx.image.IntToIntPixelConverter;
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntArgbPre
/*     */ {
/*  39 */   public static final IntPixelGetter getter = Accessor.instance;
/*  40 */   public static final IntPixelSetter setter = Accessor.instance;
/*  41 */   public static final IntPixelAccessor accessor = Accessor.instance; private static IntToBytePixelConverter ToByteBgraPreObj;
/*     */   
/*     */   public static IntToBytePixelConverter ToByteBgraConverter() {
/*  44 */     return ToByteBgraConv.instance;
/*     */   }
/*     */   private static IntToIntPixelConverter ToIntArgbPreObj;
/*     */   
/*     */   public static IntToBytePixelConverter ToByteBgraPreConverter() {
/*  49 */     if (ToByteBgraPreObj == null) {
/*  50 */       ToByteBgraPreObj = new IntTo4ByteSameConverter(getter, ByteBgraPre.setter);
/*     */     }
/*     */     
/*  53 */     return ToByteBgraPreObj;
/*     */   }
/*     */   
/*     */   public static IntToIntPixelConverter ToIntArgbConverter() {
/*  57 */     return ToIntArgbConv.instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public static IntToIntPixelConverter ToIntArgbPreConverter() {
/*  62 */     if (ToIntArgbPreObj == null) {
/*  63 */       ToIntArgbPreObj = BaseIntToIntConverter.create(accessor);
/*     */     }
/*  65 */     return ToIntArgbPreObj;
/*     */   }
/*     */   
/*     */   static class Accessor implements IntPixelAccessor {
/*  69 */     static final IntPixelAccessor instance = new Accessor();
/*     */ 
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  74 */       return AlphaType.PREMULTIPLIED;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  79 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(int[] param1ArrayOfint, int param1Int) {
/*  84 */       return PixelUtils.PretoNonPre(param1ArrayOfint[param1Int]);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(int[] param1ArrayOfint, int param1Int) {
/*  89 */       return param1ArrayOfint[param1Int];
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(IntBuffer param1IntBuffer, int param1Int) {
/*  94 */       return PixelUtils.PretoNonPre(param1IntBuffer.get(param1Int));
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(IntBuffer param1IntBuffer, int param1Int) {
/*  99 */       return param1IntBuffer.get(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(int[] param1ArrayOfint, int param1Int1, int param1Int2) {
/* 104 */       param1ArrayOfint[param1Int1] = PixelUtils.NonPretoPre(param1Int2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(int[] param1ArrayOfint, int param1Int1, int param1Int2) {
/* 109 */       param1ArrayOfint[param1Int1] = param1Int2;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(IntBuffer param1IntBuffer, int param1Int1, int param1Int2) {
/* 114 */       param1IntBuffer.put(param1Int1, PixelUtils.NonPretoPre(param1Int2));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(IntBuffer param1IntBuffer, int param1Int1, int param1Int2) {
/* 119 */       param1IntBuffer.put(param1Int1, param1Int2);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ToIntArgbConv extends BaseIntToIntConverter {
/* 124 */     public static final IntToIntPixelConverter instance = new ToIntArgbConv();
/*     */ 
/*     */     
/*     */     private ToIntArgbConv() {
/* 128 */       super(IntArgbPre.getter, IntArgb.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(int[] param1ArrayOfint1, int param1Int1, int param1Int2, int[] param1ArrayOfint2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 136 */       param1Int2 -= param1Int5;
/* 137 */       param1Int4 -= param1Int5;
/* 138 */       while (--param1Int6 >= 0) {
/* 139 */         for (byte b = 0; b < param1Int5; b++) {
/* 140 */           int i = param1ArrayOfint1[param1Int1++];
/* 141 */           int j = i >>> 24;
/* 142 */           if (j > 0 && j < 255) {
/* 143 */             int k = j >> 1;
/* 144 */             int m = ((i >> 16 & 0xFF) * 255 + k) / j;
/* 145 */             int n = ((i >> 8 & 0xFF) * 255 + k) / j;
/* 146 */             int i1 = ((i & 0xFF) * 255 + k) / j;
/* 147 */             i = j << 24 | m << 16 | n << 8 | i1;
/*     */           } 
/* 149 */           param1ArrayOfint2[param1Int3++] = i;
/*     */         } 
/* 151 */         param1Int1 += param1Int2;
/* 152 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(IntBuffer param1IntBuffer1, int param1Int1, int param1Int2, IntBuffer param1IntBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 161 */       while (--param1Int6 >= 0) {
/* 162 */         for (byte b = 0; b < param1Int5; b++) {
/* 163 */           int i = param1IntBuffer1.get(param1Int1 + b);
/* 164 */           int j = i >>> 24;
/* 165 */           if (j > 0 && j < 255) {
/* 166 */             int k = j >> 1;
/* 167 */             int m = ((i >> 16 & 0xFF) * 255 + k) / j;
/* 168 */             int n = ((i >> 8 & 0xFF) * 255 + k) / j;
/* 169 */             int i1 = ((i & 0xFF) * 255 + k) / j;
/* 170 */             i = j << 24 | m << 16 | n << 8 | i1;
/*     */           } 
/* 172 */           param1IntBuffer2.put(param1Int3 + b, i);
/*     */         } 
/* 174 */         param1Int1 += param1Int2;
/* 175 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteBgraConv extends BaseIntToByteConverter {
/* 181 */     public static final IntToBytePixelConverter instance = new ToByteBgraConv();
/*     */ 
/*     */     
/*     */     private ToByteBgraConv() {
/* 185 */       super(IntArgbPre.getter, ByteBgra.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(int[] param1ArrayOfint, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 193 */       param1Int2 -= param1Int5;
/* 194 */       param1Int4 -= param1Int5 * 4;
/* 195 */       while (--param1Int6 >= 0) {
/* 196 */         for (byte b = 0; b < param1Int5; b++) {
/* 197 */           int i = param1ArrayOfint[param1Int1++];
/* 198 */           int j = i >>> 24;
/* 199 */           int k = i >> 16 & 0xFF;
/* 200 */           int m = i >> 8 & 0xFF;
/* 201 */           int n = i & 0xFF;
/* 202 */           if (j > 0 && j < 255) {
/* 203 */             int i1 = j >> 1;
/* 204 */             k = (k * 255 + i1) / j;
/* 205 */             m = (m * 255 + i1) / j;
/* 206 */             n = (n * 255 + i1) / j;
/*     */           } 
/* 208 */           param1ArrayOfbyte[param1Int3++] = (byte)n;
/* 209 */           param1ArrayOfbyte[param1Int3++] = (byte)m;
/* 210 */           param1ArrayOfbyte[param1Int3++] = (byte)k;
/* 211 */           param1ArrayOfbyte[param1Int3++] = (byte)j;
/*     */         } 
/* 213 */         param1Int1 += param1Int2;
/* 214 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(IntBuffer param1IntBuffer, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 223 */       param1Int4 -= param1Int5 * 4;
/* 224 */       while (--param1Int6 >= 0) {
/* 225 */         for (byte b = 0; b < param1Int5; b++) {
/* 226 */           int i = param1IntBuffer.get(param1Int1 + b);
/* 227 */           int j = i >>> 24;
/* 228 */           int k = i >> 16 & 0xFF;
/* 229 */           int m = i >> 8 & 0xFF;
/* 230 */           int n = i & 0xFF;
/* 231 */           if (j > 0 && j < 255) {
/* 232 */             int i1 = j >> 1;
/* 233 */             k = (k * 255 + i1) / j;
/* 234 */             m = (m * 255 + i1) / j;
/* 235 */             n = (n * 255 + i1) / j;
/*     */           } 
/* 237 */           param1ByteBuffer.put(param1Int3, (byte)n);
/* 238 */           param1ByteBuffer.put(param1Int3 + 1, (byte)m);
/* 239 */           param1ByteBuffer.put(param1Int3 + 2, (byte)k);
/* 240 */           param1ByteBuffer.put(param1Int3 + 3, (byte)j);
/* 241 */           param1Int3 += 4;
/*     */         } 
/* 243 */         param1Int1 += param1Int2;
/* 244 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\IntArgbPre.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */