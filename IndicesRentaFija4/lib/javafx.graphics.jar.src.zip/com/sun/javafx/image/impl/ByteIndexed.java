/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*     */ import com.sun.javafx.image.ByteToIntPixelConverter;
/*     */ import com.sun.javafx.image.IntPixelSetter;
/*     */ import com.sun.javafx.image.PixelSetter;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import javafx.scene.image.PixelFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteIndexed
/*     */ {
/*     */   public static BytePixelGetter createGetter(PixelFormat<ByteBuffer> paramPixelFormat) {
/*  42 */     return new Getter(paramPixelFormat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteToBytePixelConverter createToByteBgraAny(BytePixelGetter paramBytePixelGetter, BytePixelSetter paramBytePixelSetter) {
/*  49 */     return new ToByteBgraAnyConverter(paramBytePixelGetter, paramBytePixelSetter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteToIntPixelConverter createToIntArgbAny(BytePixelGetter paramBytePixelGetter, IntPixelSetter paramIntPixelSetter) {
/*  56 */     return new ToIntArgbAnyConverter(paramBytePixelGetter, paramIntPixelSetter);
/*     */   }
/*     */   
/*     */   public static class Getter implements BytePixelGetter {
/*     */     PixelFormat<ByteBuffer> theFormat;
/*     */     private int[] precolors;
/*     */     private int[] nonprecolors;
/*     */     
/*     */     Getter(PixelFormat<ByteBuffer> param1PixelFormat) {
/*  65 */       this.theFormat = param1PixelFormat;
/*     */     }
/*     */     
/*     */     int[] getPreColors() {
/*  69 */       if (this.precolors == null) {
/*  70 */         this.precolors = Toolkit.getImageAccessor().getPreColors(this.theFormat);
/*     */       }
/*  72 */       return this.precolors;
/*     */     }
/*     */     
/*     */     int[] getNonPreColors() {
/*  76 */       if (this.nonprecolors == null) {
/*  77 */         this.nonprecolors = Toolkit.getImageAccessor().getNonPreColors(this.theFormat);
/*     */       }
/*  79 */       return this.nonprecolors;
/*     */     }
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  84 */       return this.theFormat.isPremultiplied() ? 
/*  85 */         AlphaType.PREMULTIPLIED : 
/*  86 */         AlphaType.NONPREMULTIPLIED;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  91 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(byte[] param1ArrayOfbyte, int param1Int) {
/*  96 */       return getNonPreColors()[param1ArrayOfbyte[param1Int] & 0xFF];
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(byte[] param1ArrayOfbyte, int param1Int) {
/* 101 */       return getPreColors()[param1ArrayOfbyte[param1Int] & 0xFF];
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(ByteBuffer param1ByteBuffer, int param1Int) {
/* 106 */       return getNonPreColors()[param1ByteBuffer.get(param1Int) & 0xFF];
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(ByteBuffer param1ByteBuffer, int param1Int) {
/* 111 */       return getPreColors()[param1ByteBuffer.get(param1Int) & 0xFF];
/*     */     }
/*     */   }
/*     */   
/*     */   static int[] getColors(BytePixelGetter paramBytePixelGetter, PixelSetter paramPixelSetter) {
/* 116 */     Getter getter = (Getter)paramBytePixelGetter;
/* 117 */     return (paramPixelSetter.getAlphaType() == AlphaType.PREMULTIPLIED) ? 
/* 118 */       getter.getPreColors() : 
/* 119 */       getter.getNonPreColors();
/*     */   }
/*     */   
/*     */   public static class ToByteBgraAnyConverter extends BaseByteToByteConverter {
/*     */     public ToByteBgraAnyConverter(BytePixelGetter param1BytePixelGetter, BytePixelSetter param1BytePixelSetter) {
/* 124 */       super(param1BytePixelGetter, param1BytePixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 132 */       int[] arrayOfInt = ByteIndexed.getColors(getGetter(), getSetter());
/*     */       
/* 134 */       param1Int4 -= param1Int5 * 4;
/* 135 */       while (--param1Int6 >= 0) {
/* 136 */         for (byte b = 0; b < param1Int5; b++) {
/* 137 */           int i = arrayOfInt[param1ArrayOfbyte1[param1Int1 + b] & 0xFF];
/* 138 */           param1ArrayOfbyte2[param1Int3++] = (byte)i;
/* 139 */           param1ArrayOfbyte2[param1Int3++] = (byte)(i >> 8);
/* 140 */           param1ArrayOfbyte2[param1Int3++] = (byte)(i >> 16);
/* 141 */           param1ArrayOfbyte2[param1Int3++] = (byte)(i >> 24);
/*     */         } 
/* 143 */         param1Int1 += param1Int2;
/* 144 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 153 */       int[] arrayOfInt = ByteIndexed.getColors(getGetter(), getSetter());
/*     */       
/* 155 */       param1Int4 -= param1Int5 * 4;
/* 156 */       while (--param1Int6 >= 0) {
/* 157 */         for (byte b = 0; b < param1Int5; b++) {
/* 158 */           int i = arrayOfInt[param1ByteBuffer1.get(param1Int1 + b) & 0xFF];
/* 159 */           param1ByteBuffer2.put(param1Int3, (byte)i);
/* 160 */           param1ByteBuffer2.put(param1Int3 + 1, (byte)(i >> 8));
/* 161 */           param1ByteBuffer2.put(param1Int3 + 2, (byte)(i >> 16));
/* 162 */           param1ByteBuffer2.put(param1Int3 + 3, (byte)(i >> 24));
/* 163 */           param1Int3 += 4;
/*     */         } 
/* 165 */         param1Int1 += param1Int2;
/* 166 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ToIntArgbAnyConverter extends BaseByteToIntConverter {
/*     */     public ToIntArgbAnyConverter(BytePixelGetter param1BytePixelGetter, IntPixelSetter param1IntPixelSetter) {
/* 173 */       super(param1BytePixelGetter, param1IntPixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 181 */       int[] arrayOfInt = ByteIndexed.getColors(getGetter(), getSetter());
/*     */       
/* 183 */       while (--param1Int6 >= 0) {
/* 184 */         for (byte b = 0; b < param1Int5; b++) {
/* 185 */           param1ArrayOfint[param1Int3 + b] = arrayOfInt[param1ArrayOfbyte[param1Int1 + b] & 0xFF];
/*     */         }
/* 187 */         param1Int1 += param1Int2;
/* 188 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2, IntBuffer param1IntBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 197 */       int[] arrayOfInt = ByteIndexed.getColors(getGetter(), getSetter());
/*     */       
/* 199 */       while (--param1Int6 >= 0) {
/* 200 */         for (byte b = 0; b < param1Int5; b++) {
/* 201 */           param1IntBuffer.put(param1Int3 + b, arrayOfInt[param1ByteBuffer.get(param1Int1 + b) & 0xFF]);
/*     */         }
/* 203 */         param1Int1 += param1Int2;
/* 204 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\ByteIndexed.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */