/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.BytePixelAccessor;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteArgb
/*     */ {
/*  36 */   public static final BytePixelGetter getter = Accessor.instance;
/*  37 */   public static final BytePixelSetter setter = Accessor.instance;
/*  38 */   public static final BytePixelAccessor accessor = Accessor.instance;
/*     */   
/*     */   static class Accessor implements BytePixelAccessor {
/*  41 */     static final BytePixelAccessor instance = new Accessor();
/*     */ 
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  46 */       return AlphaType.NONPREMULTIPLIED;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  51 */       return 4;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(byte[] param1ArrayOfbyte, int param1Int) {
/*  56 */       return param1ArrayOfbyte[param1Int] << 24 | (param1ArrayOfbyte[param1Int + 1] & 0xFF) << 16 | (param1ArrayOfbyte[param1Int + 2] & 0xFF) << 8 | param1ArrayOfbyte[param1Int + 3] & 0xFF;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getArgbPre(byte[] param1ArrayOfbyte, int param1Int) {
/*  64 */       return PixelUtils.NonPretoPre(getArgb(param1ArrayOfbyte, param1Int));
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(ByteBuffer param1ByteBuffer, int param1Int) {
/*  69 */       return param1ByteBuffer.get(param1Int) << 24 | (param1ByteBuffer
/*  70 */         .get(param1Int + 1) & 0xFF) << 16 | (param1ByteBuffer
/*  71 */         .get(param1Int + 2) & 0xFF) << 8 | param1ByteBuffer
/*  72 */         .get(param1Int + 3) & 0xFF;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(ByteBuffer param1ByteBuffer, int param1Int) {
/*  77 */       return PixelUtils.NonPretoPre(getArgb(param1ByteBuffer, param1Int));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/*  82 */       param1ArrayOfbyte[param1Int1] = (byte)(param1Int2 >> 24);
/*  83 */       param1ArrayOfbyte[param1Int1 + 1] = (byte)(param1Int2 >> 16);
/*  84 */       param1ArrayOfbyte[param1Int1 + 2] = (byte)(param1Int2 >> 8);
/*  85 */       param1ArrayOfbyte[param1Int1 + 3] = (byte)param1Int2;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/*  90 */       setArgb(param1ArrayOfbyte, param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/*  95 */       param1ByteBuffer.put(param1Int1, (byte)(param1Int2 >> 24));
/*  96 */       param1ByteBuffer.put(param1Int1 + 1, (byte)(param1Int2 >> 16));
/*  97 */       param1ByteBuffer.put(param1Int1 + 2, (byte)(param1Int2 >> 8));
/*  98 */       param1ByteBuffer.put(param1Int1 + 3, (byte)param1Int2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 103 */       setArgb(param1ByteBuffer, param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\ByteArgb.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */