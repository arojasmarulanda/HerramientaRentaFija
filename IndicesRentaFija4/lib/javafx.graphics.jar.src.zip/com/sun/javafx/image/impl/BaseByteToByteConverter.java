/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.BytePixelAccessor;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*     */ import com.sun.javafx.image.PixelGetter;
/*     */ import com.sun.javafx.image.PixelSetter;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BaseByteToByteConverter
/*     */   implements ByteToBytePixelConverter
/*     */ {
/*     */   protected final BytePixelGetter getter;
/*     */   protected final BytePixelSetter setter;
/*     */   protected final int nSrcElems;
/*     */   protected final int nDstElems;
/*     */   
/*     */   BaseByteToByteConverter(BytePixelGetter paramBytePixelGetter, BytePixelSetter paramBytePixelSetter) {
/*  43 */     this.getter = paramBytePixelGetter;
/*  44 */     this.setter = paramBytePixelSetter;
/*  45 */     this.nSrcElems = paramBytePixelGetter.getNumElements();
/*  46 */     this.nDstElems = paramBytePixelSetter.getNumElements();
/*     */   }
/*     */ 
/*     */   
/*     */   public final BytePixelGetter getGetter() {
/*  51 */     return this.getter;
/*     */   }
/*     */ 
/*     */   
/*     */   public final BytePixelSetter getSetter() {
/*  56 */     return this.setter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  72 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/*  73 */       return;  if (paramInt2 == paramInt5 * this.nSrcElems && paramInt4 == paramInt5 * this.nDstElems) {
/*     */ 
/*     */       
/*  76 */       paramInt5 *= paramInt6;
/*  77 */       paramInt6 = 1;
/*     */     } 
/*  79 */     doConvert(paramArrayOfbyte1, paramInt1, paramInt2, paramArrayOfbyte2, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(ByteBuffer paramByteBuffer1, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  89 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/*  90 */       return;  if (paramInt2 == paramInt5 * this.nSrcElems && paramInt4 == paramInt5 * this.nDstElems) {
/*     */ 
/*     */       
/*  93 */       paramInt5 *= paramInt6;
/*  94 */       paramInt6 = 1;
/*     */     } 
/*  96 */     if (paramByteBuffer1.hasArray() && paramByteBuffer2.hasArray()) {
/*  97 */       paramInt1 += paramByteBuffer1.arrayOffset();
/*  98 */       paramInt3 += paramByteBuffer2.arrayOffset();
/*  99 */       doConvert(paramByteBuffer1.array(), paramInt1, paramInt2, paramByteBuffer2
/* 100 */           .array(), paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } else {
/*     */       
/* 103 */       doConvert(paramByteBuffer1, paramInt1, paramInt2, paramByteBuffer2, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 114 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/* 115 */       return;  if (paramInt2 == paramInt5 * this.nSrcElems && paramInt4 == paramInt5 * this.nDstElems) {
/*     */ 
/*     */       
/* 118 */       paramInt5 *= paramInt6;
/* 119 */       paramInt6 = 1;
/*     */     } 
/* 121 */     if (paramByteBuffer.hasArray()) {
/* 122 */       byte[] arrayOfByte = paramByteBuffer.array();
/* 123 */       paramInt1 += paramByteBuffer.arrayOffset();
/* 124 */       doConvert(arrayOfByte, paramInt1, paramInt2, paramArrayOfbyte, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     }
/*     */     else {
/*     */       
/* 128 */       ByteBuffer byteBuffer = ByteBuffer.wrap(paramArrayOfbyte);
/* 129 */       doConvert(paramByteBuffer, paramInt1, paramInt2, byteBuffer, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 140 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/* 141 */       return;  if (paramInt2 == paramInt5 * this.nSrcElems && paramInt4 == paramInt5 * this.nDstElems) {
/*     */ 
/*     */       
/* 144 */       paramInt5 *= paramInt6;
/* 145 */       paramInt6 = 1;
/*     */     } 
/* 147 */     if (paramByteBuffer.hasArray()) {
/* 148 */       byte[] arrayOfByte = paramByteBuffer.array();
/* 149 */       paramInt3 += paramByteBuffer.arrayOffset();
/* 150 */       doConvert(paramArrayOfbyte, paramInt1, paramInt2, arrayOfByte, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     }
/*     */     else {
/*     */       
/* 154 */       ByteBuffer byteBuffer = ByteBuffer.wrap(paramArrayOfbyte);
/* 155 */       doConvert(byteBuffer, paramInt1, paramInt2, paramByteBuffer, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static ByteToBytePixelConverter create(BytePixelAccessor paramBytePixelAccessor) {
/* 162 */     return new ByteAnyToSameConverter(paramBytePixelAccessor);
/*     */   }
/*     */   
/*     */   static class ByteAnyToSameConverter extends BaseByteToByteConverter {
/*     */     ByteAnyToSameConverter(BytePixelAccessor param1BytePixelAccessor) {
/* 167 */       super(param1BytePixelAccessor, param1BytePixelAccessor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 175 */       while (--param1Int6 >= 0) {
/* 176 */         System.arraycopy(param1ArrayOfbyte1, param1Int1, param1ArrayOfbyte2, param1Int3, param1Int5 * this.nSrcElems);
/* 177 */         param1Int1 += param1Int2;
/* 178 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 187 */       int i = param1ByteBuffer1.limit();
/* 188 */       int j = param1ByteBuffer1.position();
/* 189 */       int k = param1ByteBuffer2.position();
/*     */       try {
/* 191 */         while (--param1Int6 >= 0) {
/* 192 */           int m = param1Int1 + param1Int5 * this.nSrcElems;
/* 193 */           if (m > i) {
/* 194 */             throw new IndexOutOfBoundsException("" + i);
/*     */           }
/* 196 */           param1ByteBuffer1.limit(m);
/* 197 */           param1ByteBuffer1.position(param1Int1);
/* 198 */           param1ByteBuffer2.position(param1Int3);
/* 199 */           param1ByteBuffer2.put(param1ByteBuffer1);
/* 200 */           param1Int1 += param1Int2;
/* 201 */           param1Int3 += param1Int4;
/*     */         } 
/*     */       } finally {
/* 204 */         param1ByteBuffer1.limit(i);
/* 205 */         param1ByteBuffer1.position(j);
/* 206 */         param1ByteBuffer2.position(k);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteToBytePixelConverter createReorderer(BytePixelGetter paramBytePixelGetter, BytePixelSetter paramBytePixelSetter, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 215 */     return new FourByteReorderer(paramBytePixelGetter, paramBytePixelSetter, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   abstract void doConvert(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*     */   
/*     */   abstract void doConvert(ByteBuffer paramByteBuffer1, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*     */   
/*     */   static class FourByteReorderer extends BaseByteToByteConverter {
/*     */     FourByteReorderer(BytePixelGetter param1BytePixelGetter, BytePixelSetter param1BytePixelSetter, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 224 */       super(param1BytePixelGetter, param1BytePixelSetter);
/* 225 */       this.c0 = param1Int1;
/* 226 */       this.c1 = param1Int2;
/* 227 */       this.c2 = param1Int3;
/* 228 */       this.c3 = param1Int4;
/*     */     }
/*     */     private final int c0;
/*     */     private final int c1;
/*     */     private final int c2;
/*     */     private final int c3;
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 236 */       param1Int2 -= param1Int5 * 4;
/* 237 */       param1Int4 -= param1Int5 * 4;
/* 238 */       while (--param1Int6 >= 0) {
/* 239 */         for (byte b = 0; b < param1Int5; b++) {
/*     */ 
/*     */           
/* 242 */           byte b1 = param1ArrayOfbyte1[param1Int1 + this.c0];
/* 243 */           byte b2 = param1ArrayOfbyte1[param1Int1 + this.c1];
/* 244 */           byte b3 = param1ArrayOfbyte1[param1Int1 + this.c2];
/* 245 */           byte b4 = param1ArrayOfbyte1[param1Int1 + this.c3];
/* 246 */           param1ArrayOfbyte2[param1Int3++] = b1;
/* 247 */           param1ArrayOfbyte2[param1Int3++] = b2;
/* 248 */           param1ArrayOfbyte2[param1Int3++] = b3;
/* 249 */           param1ArrayOfbyte2[param1Int3++] = b4;
/* 250 */           param1Int1 += 4;
/*     */         } 
/* 252 */         param1Int1 += param1Int2;
/* 253 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 262 */       param1Int2 -= param1Int5 * 4;
/* 263 */       param1Int4 -= param1Int5 * 4;
/* 264 */       while (--param1Int6 >= 0) {
/* 265 */         for (byte b = 0; b < param1Int5; b++) {
/*     */ 
/*     */           
/* 268 */           byte b1 = param1ByteBuffer1.get(param1Int1 + this.c0);
/* 269 */           byte b2 = param1ByteBuffer1.get(param1Int1 + this.c1);
/* 270 */           byte b3 = param1ByteBuffer1.get(param1Int1 + this.c2);
/* 271 */           byte b4 = param1ByteBuffer1.get(param1Int1 + this.c3);
/* 272 */           param1ByteBuffer2.put(param1Int3, b1);
/* 273 */           param1ByteBuffer2.put(param1Int3 + 1, b2);
/* 274 */           param1ByteBuffer2.put(param1Int3 + 2, b3);
/* 275 */           param1ByteBuffer2.put(param1Int3 + 3, b4);
/* 276 */           param1Int1 += 4;
/* 277 */           param1Int3 += 4;
/*     */         } 
/* 279 */         param1Int1 += param1Int2;
/* 280 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\BaseByteToByteConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */