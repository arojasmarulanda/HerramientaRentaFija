/*     */ package com.sun.javafx.embed;
/*     */ 
/*     */ import com.sun.javafx.tk.FocusCause;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.input.RotateEvent;
/*     */ import javafx.scene.input.ScrollEvent;
/*     */ import javafx.scene.input.SwipeEvent;
/*     */ import javafx.scene.input.ZoomEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractEvents
/*     */ {
/*     */   public static final int MOUSEEVENT_PRESSED = 0;
/*     */   public static final int MOUSEEVENT_RELEASED = 1;
/*     */   public static final int MOUSEEVENT_CLICKED = 2;
/*     */   public static final int MOUSEEVENT_ENTERED = 3;
/*     */   public static final int MOUSEEVENT_EXITED = 4;
/*     */   public static final int MOUSEEVENT_MOVED = 5;
/*     */   public static final int MOUSEEVENT_DRAGGED = 6;
/*     */   public static final int MOUSEEVENT_VERTICAL_WHEEL = 7;
/*     */   public static final int MOUSEEVENT_HORIZONTAL_WHEEL = 8;
/*     */   public static final int MOUSEEVENT_NONE_BUTTON = 0;
/*     */   public static final int MOUSEEVENT_PRIMARY_BUTTON = 1;
/*     */   public static final int MOUSEEVENT_SECONDARY_BUTTON = 2;
/*     */   public static final int MOUSEEVENT_MIDDLE_BUTTON = 4;
/*     */   public static final int KEYEVENT_PRESSED = 0;
/*     */   public static final int KEYEVENT_RELEASED = 1;
/*     */   public static final int KEYEVENT_TYPED = 2;
/*     */   public static final int ZOOMEVENT_STARTED = 0;
/*     */   public static final int ZOOMEVENT_ZOOM = 1;
/*     */   public static final int ZOOMEVENT_FINISHED = 2;
/*     */   public static final int ROTATEEVENT_STARTED = 0;
/*     */   public static final int ROTATEEVENT_ROTATE = 1;
/*     */   public static final int ROTATEEVENT_FINISHED = 2;
/*     */   public static final int SCROLLEVENT_STARTED = 0;
/*     */   public static final int SCROLLEVENT_SCROLL = 1;
/*     */   public static final int SCROLLEVENT_FINISHED = 2;
/*     */   public static final int SWIPEEVENT_DOWN = 0;
/*     */   public static final int SWIPEEVENT_UP = 1;
/*     */   public static final int SWIPEEVENT_LEFT = 2;
/*     */   public static final int SWIPEEVENT_RIGHT = 3;
/*     */   public static final int FOCUSEVENT_ACTIVATED = 0;
/*     */   public static final int FOCUSEVENT_TRAVERSED_FORWARD = 1;
/*     */   public static final int FOCUSEVENT_TRAVERSED_BACKWARD = 2;
/*     */   public static final int FOCUSEVENT_DEACTIVATED = 3;
/*     */   public static final int MODIFIER_SHIFT = 1;
/*     */   public static final int MODIFIER_CONTROL = 2;
/*     */   public static final int MODIFIER_ALT = 4;
/*     */   public static final int MODIFIER_META = 8;
/*     */   
/*     */   public static EventType<MouseEvent> mouseIDToFXEventID(int paramInt) {
/*  93 */     switch (paramInt) {
/*     */       case 0:
/*  95 */         return MouseEvent.MOUSE_PRESSED;
/*     */       case 1:
/*  97 */         return MouseEvent.MOUSE_RELEASED;
/*     */       case 2:
/*  99 */         return MouseEvent.MOUSE_CLICKED;
/*     */       case 3:
/* 101 */         return MouseEvent.MOUSE_ENTERED;
/*     */       case 4:
/* 103 */         return MouseEvent.MOUSE_EXITED;
/*     */       case 5:
/* 105 */         return MouseEvent.MOUSE_MOVED;
/*     */       case 6:
/* 107 */         return MouseEvent.MOUSE_DRAGGED;
/*     */     } 
/*     */     
/* 110 */     return MouseEvent.MOUSE_MOVED;
/*     */   }
/*     */   
/*     */   public static MouseButton mouseButtonToFXMouseButton(int paramInt) {
/* 114 */     switch (paramInt) {
/*     */       case 1:
/* 116 */         return MouseButton.PRIMARY;
/*     */       case 2:
/* 118 */         return MouseButton.SECONDARY;
/*     */       case 4:
/* 120 */         return MouseButton.MIDDLE;
/*     */     } 
/*     */     
/* 123 */     return MouseButton.NONE;
/*     */   }
/*     */   
/*     */   public static EventType<KeyEvent> keyIDToFXEventType(int paramInt) {
/* 127 */     switch (paramInt) {
/*     */       case 0:
/* 129 */         return KeyEvent.KEY_PRESSED;
/*     */       case 1:
/* 131 */         return KeyEvent.KEY_RELEASED;
/*     */       case 2:
/* 133 */         return KeyEvent.KEY_TYPED;
/*     */     } 
/*     */     
/* 136 */     return KeyEvent.KEY_TYPED;
/*     */   }
/*     */   
/*     */   public static EventType<ZoomEvent> zoomIDToFXEventType(int paramInt) {
/* 140 */     switch (paramInt) {
/*     */       case 0:
/* 142 */         return ZoomEvent.ZOOM_STARTED;
/*     */       case 1:
/* 144 */         return ZoomEvent.ZOOM;
/*     */       case 2:
/* 146 */         return ZoomEvent.ZOOM_FINISHED;
/*     */     } 
/*     */     
/* 149 */     return ZoomEvent.ZOOM;
/*     */   }
/*     */   
/*     */   public static EventType<RotateEvent> rotateIDToFXEventType(int paramInt) {
/* 153 */     switch (paramInt) {
/*     */       case 0:
/* 155 */         return RotateEvent.ROTATION_STARTED;
/*     */       case 1:
/* 157 */         return RotateEvent.ROTATE;
/*     */       case 2:
/* 159 */         return RotateEvent.ROTATION_FINISHED;
/*     */     } 
/*     */     
/* 162 */     return RotateEvent.ROTATE;
/*     */   }
/*     */   
/*     */   public static EventType<SwipeEvent> swipeIDToFXEventType(int paramInt) {
/* 166 */     switch (paramInt) {
/*     */       case 1:
/* 168 */         return SwipeEvent.SWIPE_UP;
/*     */       case 0:
/* 170 */         return SwipeEvent.SWIPE_DOWN;
/*     */       case 2:
/* 172 */         return SwipeEvent.SWIPE_LEFT;
/*     */       case 3:
/* 174 */         return SwipeEvent.SWIPE_RIGHT;
/*     */     } 
/*     */     
/* 177 */     return SwipeEvent.SWIPE_DOWN;
/*     */   }
/*     */   
/*     */   public static EventType<ScrollEvent> scrollIDToFXEventType(int paramInt) {
/* 181 */     switch (paramInt) {
/*     */       case 0:
/* 183 */         return ScrollEvent.SCROLL_STARTED;
/*     */       case 2:
/* 185 */         return ScrollEvent.SCROLL_FINISHED;
/*     */       case 1:
/*     */       case 7:
/*     */       case 8:
/* 189 */         return ScrollEvent.SCROLL;
/*     */     } 
/*     */     
/* 192 */     return ScrollEvent.SCROLL;
/*     */   }
/*     */   
/*     */   public static FocusCause focusCauseToPeerFocusCause(int paramInt) {
/* 196 */     switch (paramInt) {
/*     */       case 0:
/* 198 */         return FocusCause.ACTIVATED;
/*     */       case 1:
/* 200 */         return FocusCause.TRAVERSED_FORWARD;
/*     */       case 2:
/* 202 */         return FocusCause.TRAVERSED_BACKWARD;
/*     */       case 3:
/* 204 */         return FocusCause.DEACTIVATED;
/*     */     } 
/*     */     
/* 207 */     return FocusCause.ACTIVATED;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\embed\AbstractEvents.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */