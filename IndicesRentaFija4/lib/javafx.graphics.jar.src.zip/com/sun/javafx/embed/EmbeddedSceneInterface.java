package com.sun.javafx.embed;

import com.sun.javafx.scene.traversal.Direction;
import java.nio.IntBuffer;
import javafx.collections.ObservableList;
import javafx.event.EventType;
import javafx.scene.image.PixelFormat;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.InputMethodRequests;
import javafx.scene.input.InputMethodTextRun;

public interface EmbeddedSceneInterface {
  void setSize(int paramInt1, int paramInt2);
  
  void setPixelScaleFactors(float paramFloat1, float paramFloat2);
  
  boolean getPixels(IntBuffer paramIntBuffer, int paramInt1, int paramInt2);
  
  PixelFormat<?> getPixelFormat();
  
  void mouseEvent(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7, boolean paramBoolean8);
  
  void scrollEvent(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5);
  
  void keyEvent(int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3);
  
  void zoomEvent(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5);
  
  void rotateEvent(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5);
  
  void swipeEvent(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4);
  
  void menuEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean);
  
  boolean traverseOut(Direction paramDirection);
  
  void setDragStartListener(HostDragStartListener paramHostDragStartListener);
  
  EmbeddedSceneDTInterface createDropTarget();
  
  void inputMethodEvent(EventType<InputMethodEvent> paramEventType, ObservableList<InputMethodTextRun> paramObservableList, String paramString, int paramInt);
  
  InputMethodRequests getInputMethodRequests();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\embed\EmbeddedSceneInterface.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */