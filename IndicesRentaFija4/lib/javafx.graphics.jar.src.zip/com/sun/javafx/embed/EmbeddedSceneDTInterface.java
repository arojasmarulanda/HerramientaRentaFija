package com.sun.javafx.embed;

import javafx.scene.input.TransferMode;

public interface EmbeddedSceneDTInterface {
  TransferMode handleDragEnter(int paramInt1, int paramInt2, int paramInt3, int paramInt4, TransferMode paramTransferMode, EmbeddedSceneDSInterface paramEmbeddedSceneDSInterface);
  
  void handleDragLeave();
  
  TransferMode handleDragDrop(int paramInt1, int paramInt2, int paramInt3, int paramInt4, TransferMode paramTransferMode);
  
  TransferMode handleDragOver(int paramInt1, int paramInt2, int paramInt3, int paramInt4, TransferMode paramTransferMode);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\embed\EmbeddedSceneDTInterface.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */