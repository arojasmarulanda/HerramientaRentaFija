package com.sun.javafx.embed;

public interface EmbeddedStageInterface {
  void setLocation(int paramInt1, int paramInt2);
  
  void setSize(int paramInt1, int paramInt2);
  
  void setFocused(boolean paramBoolean, int paramInt);
  
  void focusUngrab();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\embed\EmbeddedStageInterface.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */