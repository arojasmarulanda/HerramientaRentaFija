package com.sun.javafx.embed;

import java.util.Set;
import javafx.scene.input.TransferMode;

public interface EmbeddedSceneDSInterface {
  Set<TransferMode> getSupportedActions();
  
  Object getData(String paramString);
  
  String[] getMimeTypes();
  
  boolean isMimeTypeAvailable(String paramString);
  
  void dragDropEnd(TransferMode paramTransferMode);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\embed\EmbeddedSceneDSInterface.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */