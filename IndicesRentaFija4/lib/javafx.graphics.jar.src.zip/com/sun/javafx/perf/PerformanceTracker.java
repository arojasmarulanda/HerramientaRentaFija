/*     */ package com.sun.javafx.perf;
/*     */ 
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import javafx.scene.Scene;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PerformanceTracker
/*     */ {
/*     */   private static SceneAccessor sceneAccessor;
/*     */   private boolean perfLoggingEnabled;
/*     */   
/*     */   public static boolean isLoggingEnabled() {
/*  49 */     return (Toolkit.getToolkit().getPerformanceTracker()).perfLoggingEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class SceneAccessor
/*     */   {
/*     */     public abstract void setPerfTracker(Scene param1Scene, PerformanceTracker param1PerformanceTracker);
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract PerformanceTracker getPerfTracker(Scene param1Scene);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static PerformanceTracker getSceneTracker(Scene paramScene) {
/*  67 */     PerformanceTracker performanceTracker = null;
/*  68 */     if (sceneAccessor != null) {
/*  69 */       performanceTracker = sceneAccessor.getPerfTracker(paramScene);
/*  70 */       if (performanceTracker == null) {
/*  71 */         performanceTracker = Toolkit.getToolkit().createPerformanceTracker();
/*     */       }
/*  73 */       sceneAccessor.setPerfTracker(paramScene, performanceTracker);
/*     */     } 
/*  75 */     return performanceTracker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void releaseSceneTracker(Scene paramScene) {
/*  82 */     if (sceneAccessor != null) {
/*  83 */       sceneAccessor.setPerfTracker(paramScene, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setSceneAccessor(SceneAccessor paramSceneAccessor) {
/*  88 */     sceneAccessor = paramSceneAccessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void logEvent(String paramString) {
/* 100 */     Toolkit.getToolkit().getPerformanceTracker().doLogEvent(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void outputLog() {
/* 107 */     Toolkit.getToolkit().getPerformanceTracker().doOutputLog();
/*     */   }
/*     */   
/*     */   protected boolean isPerfLoggingEnabled() {
/* 111 */     return this.perfLoggingEnabled; } protected void setPerfLoggingEnabled(boolean paramBoolean) {
/* 112 */     this.perfLoggingEnabled = paramBoolean;
/*     */   }
/*     */   private boolean firstPulse = true; private float instantFPS;
/*     */   private int instantFPSFrames;
/*     */   private long instantFPSStartTime;
/*     */   private long avgStartTime;
/*     */   private int avgFramesTotal;
/*     */   private float instantPulses;
/*     */   private int instantPulsesFrames;
/*     */   private long instantPulsesStartTime;
/*     */   private long avgPulsesStartTime;
/*     */   private int avgPulsesTotal;
/*     */   private Runnable onPulse;
/*     */   private Runnable onFirstPulse;
/*     */   private Runnable onRenderedFrameTask;
/*     */   
/*     */   protected abstract long nanoTime();
/*     */   
/*     */   public abstract void doOutputLog();
/*     */   
/*     */   public abstract void doLogEvent(String paramString);
/*     */   
/*     */   public synchronized float getInstantFPS() {
/* 135 */     return this.instantFPS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized float getAverageFPS() {
/* 142 */     long l = nanoTime() - this.avgStartTime;
/* 143 */     if (l > 0L) {
/* 144 */       return this.avgFramesTotal * 1.0E9F / (float)l;
/*     */     }
/* 146 */     return getInstantFPS();
/*     */   }
/*     */   
/*     */   public synchronized void resetAverageFPS() {
/* 150 */     this.avgStartTime = nanoTime();
/* 151 */     this.avgFramesTotal = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getInstantPulses() {
/* 157 */     return this.instantPulses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getAveragePulses() {
/* 164 */     long l = nanoTime() - this.avgPulsesStartTime;
/* 165 */     if (l > 0L) {
/* 166 */       return this.avgPulsesTotal * 1.0E9F / (float)l;
/*     */     }
/* 168 */     return getInstantPulses();
/*     */   }
/*     */   
/*     */   public void resetAveragePulses() {
/* 172 */     this.avgPulsesStartTime = nanoTime();
/* 173 */     this.avgPulsesTotal = 0;
/*     */   }
/*     */   
/*     */   public void pulse() {
/* 177 */     calcPulses();
/* 178 */     updateInstantFps();
/* 179 */     if (this.firstPulse) {
/* 180 */       doLogEvent("first repaint");
/* 181 */       this.firstPulse = false;
/* 182 */       resetAverageFPS();
/* 183 */       resetAveragePulses();
/* 184 */       if (this.onFirstPulse != null) {
/* 185 */         this.onFirstPulse.run();
/*     */       }
/*     */     } 
/*     */     
/* 189 */     if (this.onPulse != null) this.onPulse.run(); 
/*     */   }
/*     */   
/*     */   public void frameRendered() {
/* 193 */     calcFPS();
/* 194 */     if (this.onRenderedFrameTask != null) {
/* 195 */       this.onRenderedFrameTask.run();
/*     */     }
/*     */   }
/*     */   
/*     */   private void calcPulses() {
/* 200 */     this.avgPulsesTotal++;
/* 201 */     this.instantPulsesFrames++;
/* 202 */     updateInstantPulses();
/*     */   }
/*     */   
/*     */   private synchronized void calcFPS() {
/* 206 */     this.avgFramesTotal++;
/* 207 */     this.instantFPSFrames++;
/* 208 */     updateInstantFps();
/*     */   }
/*     */   
/*     */   private synchronized void updateInstantFps() {
/* 212 */     long l = nanoTime() - this.instantFPSStartTime;
/* 213 */     if (l > 1000000000L) {
/* 214 */       this.instantFPS = 1.0E9F * this.instantFPSFrames / (float)l;
/* 215 */       this.instantFPSFrames = 0;
/* 216 */       this.instantFPSStartTime = nanoTime();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateInstantPulses() {
/* 221 */     long l = nanoTime() - this.instantPulsesStartTime;
/* 222 */     if (l > 1000000000L) {
/* 223 */       this.instantPulses = 1.0E9F * this.instantPulsesFrames / (float)l;
/* 224 */       this.instantPulsesFrames = 0;
/* 225 */       this.instantPulsesStartTime = nanoTime();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOnPulse(Runnable paramRunnable) {
/* 233 */     this.onPulse = paramRunnable; } public Runnable getOnPulse() {
/* 234 */     return this.onPulse;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOnFirstPulse(Runnable paramRunnable) {
/* 240 */     this.onFirstPulse = paramRunnable; } public Runnable getOnFirstPulse() {
/* 241 */     return this.onFirstPulse;
/*     */   }
/*     */   
/* 244 */   public void setOnRenderedFrameTask(Runnable paramRunnable) { this.onRenderedFrameTask = paramRunnable; } public Runnable getOnRenderedFrameTask() {
/* 245 */     return this.onRenderedFrameTask;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\perf\PerformanceTracker.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */