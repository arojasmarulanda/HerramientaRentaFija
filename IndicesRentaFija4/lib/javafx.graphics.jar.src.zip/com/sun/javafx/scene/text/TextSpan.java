package com.sun.javafx.scene.text;

import com.sun.javafx.geom.RectBounds;

public interface TextSpan {
  String getText();
  
  Object getFont();
  
  RectBounds getBounds();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\text\TextSpan.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */