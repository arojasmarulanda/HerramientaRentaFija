package com.sun.javafx.scene.text;

import com.sun.javafx.geom.Point2D;
import com.sun.javafx.geom.RectBounds;

public interface GlyphList {
  int getGlyphCount();
  
  int getGlyphCode(int paramInt);
  
  float getPosX(int paramInt);
  
  float getPosY(int paramInt);
  
  float getWidth();
  
  float getHeight();
  
  RectBounds getLineBounds();
  
  Point2D getLocation();
  
  int getCharOffset(int paramInt);
  
  boolean isComplex();
  
  TextSpan getTextSpan();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\text\GlyphList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */