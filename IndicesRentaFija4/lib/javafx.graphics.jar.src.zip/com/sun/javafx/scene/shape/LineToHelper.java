/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.shape.LineTo;
/*    */ import javafx.scene.shape.PathElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineToHelper
/*    */   extends PathElementHelper
/*    */ {
/* 42 */   private static final LineToHelper theInstance = new LineToHelper(); static {
/* 43 */     Utils.forceInit(LineTo.class);
/*    */   }
/*    */   private static LineToAccessor lineToAccessor;
/*    */   private static LineToHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(LineTo paramLineTo) {
/* 51 */     setHelper(paramLineTo, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void addToImpl(PathElement paramPathElement, Path2D paramPath2D) {
/* 56 */     lineToAccessor.doAddTo(paramPathElement, paramPath2D);
/*    */   }
/*    */   
/*    */   public static void setLineToAccessor(LineToAccessor paramLineToAccessor) {
/* 60 */     if (lineToAccessor != null) {
/* 61 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 64 */     lineToAccessor = paramLineToAccessor;
/*    */   }
/*    */   
/*    */   public static interface LineToAccessor {
/*    */     void doAddTo(PathElement param1PathElement, Path2D param1Path2D);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\LineToHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */