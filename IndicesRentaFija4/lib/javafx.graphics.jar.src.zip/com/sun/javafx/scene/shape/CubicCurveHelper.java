/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.CubicCurve;
/*    */ import javafx.scene.shape.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CubicCurveHelper
/*    */   extends ShapeHelper
/*    */ {
/* 43 */   private static final CubicCurveHelper theInstance = new CubicCurveHelper(); static {
/* 44 */     Utils.forceInit(CubicCurve.class);
/*    */   }
/*    */   private static CubicCurveAccessor cubicCurveAccessor;
/*    */   private static CubicCurveHelper getInstance() {
/* 48 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(CubicCurve paramCubicCurve) {
/* 52 */     setHelper(paramCubicCurve, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 57 */     return cubicCurveAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 62 */     super.updatePeerImpl(paramNode);
/* 63 */     cubicCurveAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Shape configShapeImpl(Shape paramShape) {
/* 68 */     return cubicCurveAccessor.doConfigShape(paramShape);
/*    */   }
/*    */   
/*    */   public static void setCubicCurveAccessor(CubicCurveAccessor paramCubicCurveAccessor) {
/* 72 */     if (cubicCurveAccessor != null) {
/* 73 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 76 */     cubicCurveAccessor = paramCubicCurveAccessor;
/*    */   }
/*    */   
/*    */   public static interface CubicCurveAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     Shape doConfigShape(Shape param1Shape);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\CubicCurveHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */