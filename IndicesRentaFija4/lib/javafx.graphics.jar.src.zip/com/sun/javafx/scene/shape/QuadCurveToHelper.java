/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.shape.PathElement;
/*    */ import javafx.scene.shape.QuadCurveTo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuadCurveToHelper
/*    */   extends PathElementHelper
/*    */ {
/* 42 */   private static final QuadCurveToHelper theInstance = new QuadCurveToHelper(); static {
/* 43 */     Utils.forceInit(QuadCurveTo.class);
/*    */   }
/*    */   private static QuadCurveToAccessor quadCurveToAccessor;
/*    */   private static QuadCurveToHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(QuadCurveTo paramQuadCurveTo) {
/* 51 */     setHelper(paramQuadCurveTo, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void addToImpl(PathElement paramPathElement, Path2D paramPath2D) {
/* 56 */     quadCurveToAccessor.doAddTo(paramPathElement, paramPath2D);
/*    */   }
/*    */   
/*    */   public static void setQuadCurveToAccessor(QuadCurveToAccessor paramQuadCurveToAccessor) {
/* 60 */     if (quadCurveToAccessor != null) {
/* 61 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 64 */     quadCurveToAccessor = paramQuadCurveToAccessor;
/*    */   }
/*    */   
/*    */   public static interface QuadCurveToAccessor {
/*    */     void doAddTo(PathElement param1PathElement, Path2D param1Path2D);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\QuadCurveToHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */