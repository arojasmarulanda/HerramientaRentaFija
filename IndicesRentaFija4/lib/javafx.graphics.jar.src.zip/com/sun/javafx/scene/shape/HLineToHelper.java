/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.shape.HLineTo;
/*    */ import javafx.scene.shape.PathElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HLineToHelper
/*    */   extends PathElementHelper
/*    */ {
/* 42 */   private static final HLineToHelper theInstance = new HLineToHelper(); static {
/* 43 */     Utils.forceInit(HLineTo.class);
/*    */   }
/*    */   private static HLineToAccessor hLineToAccessor;
/*    */   private static HLineToHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(HLineTo paramHLineTo) {
/* 51 */     setHelper(paramHLineTo, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void addToImpl(PathElement paramPathElement, Path2D paramPath2D) {
/* 56 */     hLineToAccessor.doAddTo(paramPathElement, paramPath2D);
/*    */   }
/*    */   
/*    */   public static void setHLineToAccessor(HLineToAccessor paramHLineToAccessor) {
/* 60 */     if (hLineToAccessor != null) {
/* 61 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 64 */     hLineToAccessor = paramHLineToAccessor;
/*    */   }
/*    */   
/*    */   public static interface HLineToAccessor {
/*    */     void doAddTo(PathElement param1PathElement, Path2D param1Path2D);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\HLineToHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */