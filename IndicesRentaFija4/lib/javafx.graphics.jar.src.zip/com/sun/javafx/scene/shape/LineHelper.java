/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.paint.Paint;
/*    */ import javafx.scene.shape.Line;
/*    */ import javafx.scene.shape.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineHelper
/*    */   extends ShapeHelper
/*    */ {
/* 46 */   private static final LineHelper theInstance = new LineHelper(); static {
/* 47 */     Utils.forceInit(Line.class);
/*    */   }
/*    */   private static LineAccessor lineAccessor;
/*    */   private static LineHelper getInstance() {
/* 51 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Line paramLine) {
/* 55 */     setHelper(paramLine, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 60 */     return lineAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 65 */     super.updatePeerImpl(paramNode);
/* 66 */     lineAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 72 */     return lineAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Paint cssGetFillInitialValueImpl(Shape paramShape) {
/* 77 */     return lineAccessor.doCssGetFillInitialValue(paramShape);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Paint cssGetStrokeInitialValueImpl(Shape paramShape) {
/* 82 */     return lineAccessor.doCssGetStrokeInitialValue(paramShape);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Shape configShapeImpl(Shape paramShape) {
/* 87 */     return lineAccessor.doConfigShape(paramShape);
/*    */   }
/*    */   
/*    */   public static void setLineAccessor(LineAccessor paramLineAccessor) {
/* 91 */     if (lineAccessor != null) {
/* 92 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 95 */     lineAccessor = paramLineAccessor;
/*    */   }
/*    */   
/*    */   public static interface LineAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     Paint doCssGetFillInitialValue(Shape param1Shape);
/*    */     
/*    */     Paint doCssGetStrokeInitialValue(Shape param1Shape);
/*    */     
/*    */     Shape doConfigShape(Shape param1Shape);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\LineHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */