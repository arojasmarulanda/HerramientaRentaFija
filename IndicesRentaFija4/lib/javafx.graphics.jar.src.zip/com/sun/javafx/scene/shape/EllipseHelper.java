/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.Ellipse;
/*    */ import javafx.scene.shape.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EllipseHelper
/*    */   extends ShapeHelper
/*    */ {
/* 45 */   private static final EllipseHelper theInstance = new EllipseHelper(); static {
/* 46 */     Utils.forceInit(Ellipse.class);
/*    */   }
/*    */   private static EllipseAccessor ellipseAccessor;
/*    */   private static EllipseHelper getInstance() {
/* 50 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Ellipse paramEllipse) {
/* 54 */     setHelper(paramEllipse, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 59 */     return ellipseAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 64 */     super.updatePeerImpl(paramNode);
/* 65 */     ellipseAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 71 */     return ellipseAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Shape configShapeImpl(Shape paramShape) {
/* 76 */     return ellipseAccessor.doConfigShape(paramShape);
/*    */   }
/*    */   
/*    */   public static void setEllipseAccessor(EllipseAccessor paramEllipseAccessor) {
/* 80 */     if (ellipseAccessor != null) {
/* 81 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 84 */     ellipseAccessor = paramEllipseAccessor;
/*    */   }
/*    */   
/*    */   public static interface EllipseAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     Shape doConfigShape(Shape param1Shape);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\EllipseHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */