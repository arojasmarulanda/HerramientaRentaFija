/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.QuadCurve;
/*    */ import javafx.scene.shape.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QuadCurveHelper
/*    */   extends ShapeHelper
/*    */ {
/* 43 */   private static final QuadCurveHelper theInstance = new QuadCurveHelper(); static {
/* 44 */     Utils.forceInit(QuadCurve.class);
/*    */   }
/*    */   private static QuadCurveAccessor quadCurveAccessor;
/*    */   private static QuadCurveHelper getInstance() {
/* 48 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(QuadCurve paramQuadCurve) {
/* 52 */     setHelper(paramQuadCurve, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 57 */     return quadCurveAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 62 */     super.updatePeerImpl(paramNode);
/* 63 */     quadCurveAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Shape configShapeImpl(Shape paramShape) {
/* 68 */     return quadCurveAccessor.doConfigShape(paramShape);
/*    */   }
/*    */   
/*    */   public static void setQuadCurveAccessor(QuadCurveAccessor paramQuadCurveAccessor) {
/* 72 */     if (quadCurveAccessor != null) {
/* 73 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 76 */     quadCurveAccessor = paramQuadCurveAccessor;
/*    */   }
/*    */   
/*    */   public static interface QuadCurveAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     Shape doConfigShape(Shape param1Shape);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\QuadCurveHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */