/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.PickRay;
/*    */ import com.sun.javafx.scene.input.PickResultChooser;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.CullFace;
/*    */ import javafx.scene.shape.Mesh;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MeshHelper
/*    */ {
/*    */   private static MeshAccessor meshAccessor;
/*    */   
/*    */   static {
/* 42 */     Utils.forceInit(Mesh.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static MeshHelper getHelper(Mesh paramMesh) {
/* 49 */     return meshAccessor.getHelper(paramMesh);
/*    */   }
/*    */   
/*    */   protected static void setHelper(Mesh paramMesh, MeshHelper paramMeshHelper) {
/* 53 */     meshAccessor.setHelper(paramMesh, paramMeshHelper);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean computeIntersects(Mesh paramMesh, PickRay paramPickRay, PickResultChooser paramPickResultChooser, Node paramNode, CullFace paramCullFace, boolean paramBoolean) {
/* 76 */     return getHelper(paramMesh).computeIntersectsImpl(paramMesh, paramPickRay, paramPickResultChooser, paramNode, paramCullFace, paramBoolean);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setMeshAccessor(MeshAccessor paramMeshAccessor) {
/* 93 */     if (meshAccessor != null) {
/* 94 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 97 */     meshAccessor = paramMeshAccessor;
/*    */   }
/*    */   
/*    */   protected abstract boolean computeIntersectsImpl(Mesh paramMesh, PickRay paramPickRay, PickResultChooser paramPickResultChooser, Node paramNode, CullFace paramCullFace, boolean paramBoolean);
/*    */   
/*    */   public static interface MeshAccessor {
/*    */     MeshHelper getHelper(Mesh param1Mesh);
/*    */     
/*    */     void setHelper(Mesh param1Mesh, MeshHelper param1MeshHelper);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\MeshHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */