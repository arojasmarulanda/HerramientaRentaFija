/*     */ package com.sun.javafx.scene.shape;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.scene.DirtyBits;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.sg.prism.NGShape;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.paint.Paint;
/*     */ import javafx.scene.shape.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ShapeHelper
/*     */   extends NodeHelper
/*     */ {
/*     */   private static ShapeAccessor shapeAccessor;
/*     */   
/*     */   static {
/*  46 */     Utils.forceInit(Shape.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Paint cssGetFillInitialValue(Shape paramShape) {
/*  56 */     return ((ShapeHelper)getHelper(paramShape)).cssGetFillInitialValueImpl(paramShape);
/*     */   }
/*     */   
/*     */   public static Paint cssGetStrokeInitialValue(Shape paramShape) {
/*  60 */     return ((ShapeHelper)getHelper(paramShape)).cssGetStrokeInitialValueImpl(paramShape);
/*     */   }
/*     */   
/*     */   public static Shape configShape(Shape paramShape) {
/*  64 */     return ((ShapeHelper)getHelper(paramShape)).configShapeImpl(paramShape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updatePeerImpl(Node paramNode) {
/*  73 */     super.updatePeerImpl(paramNode);
/*  74 */     shapeAccessor.doUpdatePeer(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void markDirtyImpl(Node paramNode, DirtyBits paramDirtyBits) {
/*  79 */     shapeAccessor.doMarkDirty(paramNode, paramDirtyBits);
/*  80 */     super.markDirtyImpl(paramNode, paramDirtyBits);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  86 */     return shapeAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/*  91 */     return shapeAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*     */   }
/*     */   
/*     */   protected Paint cssGetFillInitialValueImpl(Shape paramShape) {
/*  95 */     return shapeAccessor.doCssGetFillInitialValue(paramShape);
/*     */   }
/*     */   
/*     */   protected Paint cssGetStrokeInitialValueImpl(Shape paramShape) {
/*  99 */     return shapeAccessor.doCssGetStrokeInitialValue(paramShape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NGShape.Mode getMode(Shape paramShape) {
/* 109 */     return shapeAccessor.getMode(paramShape);
/*     */   }
/*     */   
/*     */   public static void setMode(Shape paramShape, NGShape.Mode paramMode) {
/* 113 */     shapeAccessor.setMode(paramShape, paramMode);
/*     */   }
/*     */   
/*     */   public static void setShapeChangeListener(Shape paramShape, Runnable paramRunnable) {
/* 117 */     shapeAccessor.setShapeChangeListener(paramShape, paramRunnable);
/*     */   }
/*     */   
/*     */   public static void setShapeAccessor(ShapeAccessor paramShapeAccessor) {
/* 121 */     if (shapeAccessor != null) {
/* 122 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 125 */     shapeAccessor = paramShapeAccessor;
/*     */   }
/*     */   
/*     */   protected abstract Shape configShapeImpl(Shape paramShape);
/*     */   
/*     */   public static interface ShapeAccessor {
/*     */     void doUpdatePeer(Node param1Node);
/*     */     
/*     */     void doMarkDirty(Node param1Node, DirtyBits param1DirtyBits);
/*     */     
/*     */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*     */     
/*     */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*     */     
/*     */     Paint doCssGetFillInitialValue(Shape param1Shape);
/*     */     
/*     */     Paint doCssGetStrokeInitialValue(Shape param1Shape);
/*     */     
/*     */     NGShape.Mode getMode(Shape param1Shape);
/*     */     
/*     */     void setMode(Shape param1Shape, NGShape.Mode param1Mode);
/*     */     
/*     */     void setShapeChangeListener(Shape param1Shape, Runnable param1Runnable);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\ShapeHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */