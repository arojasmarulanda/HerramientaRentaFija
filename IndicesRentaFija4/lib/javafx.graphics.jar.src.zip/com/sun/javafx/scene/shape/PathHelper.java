/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.geometry.Bounds;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.paint.Paint;
/*    */ import javafx.scene.shape.Path;
/*    */ import javafx.scene.shape.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathHelper
/*    */   extends ShapeHelper
/*    */ {
/* 45 */   private static final PathHelper theInstance = new PathHelper(); static {
/* 46 */     Utils.forceInit(Path.class);
/*    */   }
/*    */   private static PathAccessor pathAccessor;
/*    */   private static PathHelper getInstance() {
/* 50 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Path paramPath) {
/* 54 */     setHelper(paramPath, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 59 */     return pathAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 64 */     super.updatePeerImpl(paramNode);
/* 65 */     pathAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Bounds computeLayoutBoundsImpl(Node paramNode) {
/* 70 */     Bounds bounds = pathAccessor.doComputeLayoutBounds(paramNode);
/* 71 */     if (bounds != null) {
/* 72 */       return bounds;
/*    */     }
/* 74 */     return super.computeLayoutBoundsImpl(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Paint cssGetFillInitialValueImpl(Shape paramShape) {
/* 79 */     return pathAccessor.doCssGetFillInitialValue(paramShape);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Paint cssGetStrokeInitialValueImpl(Shape paramShape) {
/* 84 */     return pathAccessor.doCssGetStrokeInitialValue(paramShape);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Shape configShapeImpl(Shape paramShape) {
/* 89 */     return pathAccessor.doConfigShape(paramShape);
/*    */   }
/*    */   
/*    */   public static void setPathAccessor(PathAccessor paramPathAccessor) {
/* 93 */     if (pathAccessor != null) {
/* 94 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 97 */     pathAccessor = paramPathAccessor;
/*    */   }
/*    */   
/*    */   public static interface PathAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     Bounds doComputeLayoutBounds(Node param1Node);
/*    */     
/*    */     Paint doCssGetFillInitialValue(Shape param1Shape);
/*    */     
/*    */     Paint doCssGetStrokeInitialValue(Shape param1Shape);
/*    */     
/*    */     Shape doConfigShape(Shape param1Shape);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\PathHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */