/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.PickRay;
/*    */ import com.sun.javafx.scene.input.PickResultChooser;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.CullFace;
/*    */ import javafx.scene.shape.Mesh;
/*    */ import javafx.scene.shape.TriangleMesh;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TriangleMeshHelper
/*    */   extends MeshHelper
/*    */ {
/* 46 */   private static final TriangleMeshHelper theInstance = new TriangleMeshHelper(); static {
/* 47 */     Utils.forceInit(TriangleMesh.class);
/*    */   }
/*    */   private static TriangleMeshAccessor triangleMeshAccessor;
/*    */   private static TriangleMeshHelper getInstance() {
/* 51 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(TriangleMesh paramTriangleMesh) {
/* 55 */     setHelper(paramTriangleMesh, getInstance());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean computeIntersectsImpl(Mesh paramMesh, PickRay paramPickRay, PickResultChooser paramPickResultChooser, Node paramNode, CullFace paramCullFace, boolean paramBoolean) {
/* 62 */     return triangleMeshAccessor.doComputeIntersects(paramMesh, paramPickRay, paramPickResultChooser, paramNode, paramCullFace, paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void setTriangleMeshAccessor(TriangleMeshAccessor paramTriangleMeshAccessor) {
/* 67 */     if (triangleMeshAccessor != null) {
/* 68 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 71 */     triangleMeshAccessor = paramTriangleMeshAccessor;
/*    */   }
/*    */   
/*    */   public static interface TriangleMeshAccessor {
/*    */     boolean doComputeIntersects(Mesh param1Mesh, PickRay param1PickRay, PickResultChooser param1PickResultChooser, Node param1Node, CullFace param1CullFace, boolean param1Boolean);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\TriangleMeshHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */