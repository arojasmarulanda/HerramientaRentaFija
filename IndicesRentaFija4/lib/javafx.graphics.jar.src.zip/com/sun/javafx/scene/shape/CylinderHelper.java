/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.PickRay;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.scene.input.PickResultChooser;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.Cylinder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CylinderHelper
/*    */   extends Shape3DHelper
/*    */ {
/* 46 */   private static final CylinderHelper theInstance = new CylinderHelper(); static {
/* 47 */     Utils.forceInit(Cylinder.class);
/*    */   }
/*    */   private static CylinderAccessor cylinderAccessor;
/*    */   private static CylinderHelper getInstance() {
/* 51 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Cylinder paramCylinder) {
/* 55 */     setHelper(paramCylinder, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 60 */     return cylinderAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 65 */     super.updatePeerImpl(paramNode);
/* 66 */     cylinderAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 72 */     return cylinderAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/* 77 */     return cylinderAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean computeIntersectsImpl(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 82 */     return cylinderAccessor.doComputeIntersects(paramNode, paramPickRay, paramPickResultChooser);
/*    */   }
/*    */   
/*    */   public static void setCylinderAccessor(CylinderAccessor paramCylinderAccessor) {
/* 86 */     if (cylinderAccessor != null) {
/* 87 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 90 */     cylinderAccessor = paramCylinderAccessor;
/*    */   }
/*    */   
/*    */   public static interface CylinderAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*    */     
/*    */     boolean doComputeIntersects(Node param1Node, PickRay param1PickRay, PickResultChooser param1PickResultChooser);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\CylinderHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */