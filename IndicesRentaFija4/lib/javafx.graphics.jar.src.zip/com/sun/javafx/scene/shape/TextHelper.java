/*     */ package com.sun.javafx.scene.shape;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.sg.prism.NGNode;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.shape.Shape;
/*     */ import javafx.scene.text.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextHelper
/*     */   extends ShapeHelper
/*     */ {
/*  46 */   private static final TextHelper theInstance = new TextHelper(); static {
/*  47 */     Utils.forceInit(Text.class);
/*     */   }
/*     */   private static TextAccessor textAccessor;
/*     */   private static TextHelper getInstance() {
/*  51 */     return theInstance;
/*     */   }
/*     */   
/*     */   public static void initHelper(Text paramText) {
/*  55 */     setHelper(paramText, getInstance());
/*     */   }
/*     */ 
/*     */   
/*     */   public static BaseBounds superComputeGeomBounds(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  60 */     return ((TextHelper)getHelper(paramNode)).superComputeGeomBoundsImpl(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */   
/*     */   public static Bounds superComputeLayoutBounds(Node paramNode) {
/*  64 */     return ((TextHelper)getHelper(paramNode)).superComputeLayoutBoundsImpl(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected NGNode createPeerImpl(Node paramNode) {
/*  69 */     return textAccessor.doCreatePeer(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updatePeerImpl(Node paramNode) {
/*  74 */     super.updatePeerImpl(paramNode);
/*  75 */     textAccessor.doUpdatePeer(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   BaseBounds superComputeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  80 */     return super.computeGeomBoundsImpl(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */   
/*     */   Bounds superComputeLayoutBoundsImpl(Node paramNode) {
/*  84 */     return super.computeLayoutBoundsImpl(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  90 */     return textAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Bounds computeLayoutBoundsImpl(Node paramNode) {
/*  95 */     return textAccessor.doComputeLayoutBounds(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/* 100 */     return textAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void geomChangedImpl(Node paramNode) {
/* 105 */     super.geomChangedImpl(paramNode);
/* 106 */     textAccessor.doGeomChanged(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Shape configShapeImpl(Shape paramShape) {
/* 111 */     return textAccessor.doConfigShape(paramShape);
/*     */   }
/*     */   
/*     */   public static void setTextAccessor(TextAccessor paramTextAccessor) {
/* 115 */     if (textAccessor != null) {
/* 116 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 119 */     textAccessor = paramTextAccessor;
/*     */   }
/*     */   
/*     */   public static interface TextAccessor {
/*     */     NGNode doCreatePeer(Node param1Node);
/*     */     
/*     */     void doUpdatePeer(Node param1Node);
/*     */     
/*     */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*     */     
/*     */     Bounds doComputeLayoutBounds(Node param1Node);
/*     */     
/*     */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*     */     
/*     */     void doGeomChanged(Node param1Node);
/*     */     
/*     */     Shape doConfigShape(Shape param1Shape);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\TextHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */