/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.shape.MoveTo;
/*    */ import javafx.scene.shape.PathElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MoveToHelper
/*    */   extends PathElementHelper
/*    */ {
/* 42 */   private static final MoveToHelper theInstance = new MoveToHelper(); static {
/* 43 */     Utils.forceInit(MoveTo.class);
/*    */   }
/*    */   private static MoveToAccessor moveToAccessor;
/*    */   private static MoveToHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(MoveTo paramMoveTo) {
/* 51 */     setHelper(paramMoveTo, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void addToImpl(PathElement paramPathElement, Path2D paramPath2D) {
/* 56 */     moveToAccessor.doAddTo(paramPathElement, paramPath2D);
/*    */   }
/*    */   
/*    */   public static void setMoveToAccessor(MoveToAccessor paramMoveToAccessor) {
/* 60 */     if (moveToAccessor != null) {
/* 61 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 64 */     moveToAccessor = paramMoveToAccessor;
/*    */   }
/*    */   
/*    */   public static interface MoveToAccessor {
/*    */     void doAddTo(PathElement param1PathElement, Path2D param1Path2D);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\MoveToHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */