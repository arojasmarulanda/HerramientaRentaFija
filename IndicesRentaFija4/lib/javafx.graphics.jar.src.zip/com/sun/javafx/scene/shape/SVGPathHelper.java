/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.SVGPath;
/*    */ import javafx.scene.shape.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SVGPathHelper
/*    */   extends ShapeHelper
/*    */ {
/* 43 */   private static final SVGPathHelper theInstance = new SVGPathHelper(); static {
/* 44 */     Utils.forceInit(SVGPath.class);
/*    */   }
/*    */   private static SVGPathAccessor svgPathAccessor;
/*    */   private static SVGPathHelper getInstance() {
/* 48 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(SVGPath paramSVGPath) {
/* 52 */     setHelper(paramSVGPath, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 57 */     return svgPathAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 62 */     super.updatePeerImpl(paramNode);
/* 63 */     svgPathAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Shape configShapeImpl(Shape paramShape) {
/* 68 */     return svgPathAccessor.doConfigShape(paramShape);
/*    */   }
/*    */   
/*    */   public static void setSVGPathAccessor(SVGPathAccessor paramSVGPathAccessor) {
/* 72 */     if (svgPathAccessor != null) {
/* 73 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 76 */     svgPathAccessor = paramSVGPathAccessor;
/*    */   }
/*    */   
/*    */   public static interface SVGPathAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     Shape doConfigShape(Shape param1Shape);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\SVGPathHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */