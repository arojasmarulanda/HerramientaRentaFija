/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.shape.PathElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PathElementHelper
/*    */ {
/*    */   private static PathElementAccessor pathElementAccessor;
/*    */   
/*    */   static {
/* 39 */     Utils.forceInit(PathElement.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static PathElementHelper getHelper(PathElement paramPathElement) {
/* 46 */     return pathElementAccessor.getHelper(paramPathElement);
/*    */   }
/*    */   
/*    */   protected static void setHelper(PathElement paramPathElement, PathElementHelper paramPathElementHelper) {
/* 50 */     pathElementAccessor.setHelper(paramPathElement, paramPathElementHelper);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void addTo(PathElement paramPathElement, Path2D paramPath2D) {
/* 60 */     getHelper(paramPathElement).addToImpl(paramPathElement, paramPath2D);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setPathElementAccessor(PathElementAccessor paramPathElementAccessor) {
/* 74 */     if (pathElementAccessor != null) {
/* 75 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 78 */     pathElementAccessor = paramPathElementAccessor;
/*    */   }
/*    */   
/*    */   protected abstract void addToImpl(PathElement paramPathElement, Path2D paramPath2D);
/*    */   
/*    */   public static interface PathElementAccessor {
/*    */     PathElementHelper getHelper(PathElement param1PathElement);
/*    */     
/*    */     void setHelper(PathElement param1PathElement, PathElementHelper param1PathElementHelper);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\PathElementHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */