/*    */ package com.sun.javafx.scene;
/*    */ 
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.PerspectiveCamera;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PerspectiveCameraHelper
/*    */   extends CameraHelper
/*    */ {
/* 42 */   private static final PerspectiveCameraHelper theInstance = new PerspectiveCameraHelper(); static {
/* 43 */     Utils.forceInit(PerspectiveCamera.class);
/*    */   }
/*    */   private static PerspectiveCameraAccessor perspectiveCameraAccessor;
/*    */   private static PerspectiveCameraHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(PerspectiveCamera paramPerspectiveCamera) {
/* 51 */     setHelper(paramPerspectiveCamera, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 56 */     return perspectiveCameraAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 61 */     super.updatePeerImpl(paramNode);
/* 62 */     perspectiveCameraAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */   
/*    */   public static void setPerspectiveCameraAccessor(PerspectiveCameraAccessor paramPerspectiveCameraAccessor) {
/* 66 */     if (perspectiveCameraAccessor != null) {
/* 67 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 70 */     perspectiveCameraAccessor = paramPerspectiveCameraAccessor;
/*    */   }
/*    */   
/*    */   public static interface PerspectiveCameraAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\PerspectiveCameraHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */