/*    */ package com.sun.javafx.scene.paint;
/*    */ 
/*    */ import com.sun.javafx.sg.prism.NGPhongMaterial;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.beans.property.BooleanProperty;
/*    */ import javafx.scene.paint.Material;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaterialHelper
/*    */ {
/*    */   private static MaterialAccessor materialAccessor;
/*    */   
/*    */   static {
/* 42 */     Utils.forceInit(Material.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static BooleanProperty dirtyProperty(Material paramMaterial) {
/* 49 */     return materialAccessor.dirtyProperty(paramMaterial);
/*    */   }
/*    */   
/*    */   public static void updatePG(Material paramMaterial) {
/* 53 */     materialAccessor.updatePG(paramMaterial);
/*    */   }
/*    */   
/*    */   public static NGPhongMaterial getNGMaterial(Material paramMaterial) {
/* 57 */     return materialAccessor.getNGMaterial(paramMaterial);
/*    */   }
/*    */   
/*    */   public static void setMaterialAccessor(MaterialAccessor paramMaterialAccessor) {
/* 61 */     if (materialAccessor != null) {
/* 62 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 65 */     materialAccessor = paramMaterialAccessor;
/*    */   }
/*    */   
/*    */   public static interface MaterialAccessor {
/*    */     BooleanProperty dirtyProperty(Material param1Material);
/*    */     
/*    */     void updatePG(Material param1Material);
/*    */     
/*    */     NGPhongMaterial getNGMaterial(Material param1Material);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\paint\MaterialHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */