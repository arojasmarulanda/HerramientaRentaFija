/*    */ package com.sun.javafx.scene;
/*    */ 
/*    */ import javafx.geometry.Point2D;
/*    */ import javafx.geometry.Point3D;
/*    */ import javafx.scene.SubScene;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SceneUtils
/*    */ {
/*    */   public static Point3D subSceneToScene(SubScene paramSubScene, Point3D paramPoint3D) {
/* 43 */     SubScene subScene = paramSubScene;
/* 44 */     while (subScene != null) {
/*    */       
/* 46 */       Point2D point2D = CameraHelper.project(
/* 47 */           SubSceneHelper.getEffectiveCamera(paramSubScene), paramPoint3D);
/*    */       
/* 49 */       paramPoint3D = subScene.localToScene(point2D.getX(), point2D.getY(), 0.0D);
/* 50 */       subScene = NodeHelper.getSubScene(subScene);
/*    */     } 
/*    */     
/* 53 */     return paramPoint3D;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Point2D sceneToSubScenePlane(SubScene paramSubScene, Point2D paramPoint2D) {
/* 63 */     paramPoint2D = computeSubSceneCoordinates(paramPoint2D.getX(), paramPoint2D.getY(), paramSubScene);
/*    */     
/* 65 */     return paramPoint2D;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static Point2D computeSubSceneCoordinates(double paramDouble1, double paramDouble2, SubScene paramSubScene) {
/* 74 */     SubScene subScene = NodeHelper.getSubScene(paramSubScene);
/*    */     
/* 76 */     if (subScene == null) {
/* 77 */       return CameraHelper.pickNodeXYPlane(
/* 78 */           SceneHelper.getEffectiveCamera(paramSubScene.getScene()), paramSubScene, paramDouble1, paramDouble2);
/*    */     }
/*    */     
/* 81 */     Point2D point2D = computeSubSceneCoordinates(paramDouble1, paramDouble2, subScene);
/* 82 */     if (point2D != null) {
/* 83 */       point2D = CameraHelper.pickNodeXYPlane(
/* 84 */           SubSceneHelper.getEffectiveCamera(subScene), paramSubScene, point2D
/* 85 */           .getX(), point2D.getY());
/*    */     }
/* 87 */     return point2D;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\SceneUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */