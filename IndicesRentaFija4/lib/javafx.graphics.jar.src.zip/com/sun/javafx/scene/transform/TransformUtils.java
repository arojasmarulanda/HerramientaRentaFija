/*     */ package com.sun.javafx.scene.transform;
/*     */ 
/*     */ import javafx.scene.transform.Transform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformUtils
/*     */ {
/*     */   public static Transform immutableTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/*  44 */     return TransformHelper.createImmutableTransform(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramDouble9, paramDouble10, paramDouble11, paramDouble12);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Transform immutableTransform(Transform paramTransform) {
/*  57 */     return TransformHelper.createImmutableTransform(paramTransform
/*  58 */         .getMxx(), paramTransform.getMxy(), paramTransform.getMxz(), paramTransform.getTx(), paramTransform
/*  59 */         .getMyx(), paramTransform.getMyy(), paramTransform.getMyz(), paramTransform.getTy(), paramTransform
/*  60 */         .getMzx(), paramTransform.getMzy(), paramTransform.getMzz(), paramTransform.getTz());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Transform immutableTransform(Transform paramTransform, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/*  76 */     return TransformHelper.createImmutableTransform(paramTransform, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramDouble9, paramDouble10, paramDouble11, paramDouble12);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Transform immutableTransform(Transform paramTransform1, Transform paramTransform2) {
/*  93 */     return TransformHelper.createImmutableTransform(paramTransform1, paramTransform2
/*  94 */         .getMxx(), paramTransform2.getMxy(), paramTransform2.getMxz(), paramTransform2.getTx(), paramTransform2
/*  95 */         .getMyx(), paramTransform2.getMyy(), paramTransform2.getMyz(), paramTransform2.getTy(), paramTransform2
/*  96 */         .getMzx(), paramTransform2.getMzy(), paramTransform2.getMzz(), paramTransform2.getTz());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Transform immutableTransform(Transform paramTransform1, Transform paramTransform2, Transform paramTransform3) {
/* 111 */     return TransformHelper.createImmutableTransform(paramTransform1, paramTransform2, paramTransform3);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\transform\TransformUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */