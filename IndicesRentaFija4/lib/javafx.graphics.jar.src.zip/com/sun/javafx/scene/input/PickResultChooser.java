/*     */ package com.sun.javafx.scene.input;
/*     */ 
/*     */ import com.sun.javafx.geom.PickRay;
/*     */ import com.sun.javafx.geom.Vec3d;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.SubSceneHelper;
/*     */ import javafx.application.ConditionalFeature;
/*     */ import javafx.application.Platform;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.Point3D;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.SubScene;
/*     */ import javafx.scene.input.PickResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PickResultChooser
/*     */ {
/*  45 */   private double distance = Double.POSITIVE_INFINITY;
/*     */   private Node node;
/*  47 */   private int face = -1;
/*     */ 
/*     */   
/*     */   private Point3D point;
/*     */ 
/*     */   
/*     */   private Point3D normal;
/*     */ 
/*     */   
/*     */   private Point2D texCoord;
/*     */   
/*     */   private boolean empty = true;
/*     */   
/*     */   private boolean closed = false;
/*     */ 
/*     */   
/*     */   public static Point3D computePoint(PickRay paramPickRay, double paramDouble) {
/*  64 */     Vec3d vec3d1 = paramPickRay.getOriginNoClone();
/*  65 */     Vec3d vec3d2 = paramPickRay.getDirectionNoClone();
/*     */     
/*  67 */     return new Point3D(vec3d1.x + vec3d2.x * paramDouble, vec3d1.y + vec3d2.y * paramDouble, vec3d1.z + vec3d2.z * paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PickResult toPickResult() {
/*  79 */     if (this.empty) {
/*  80 */       return null;
/*     */     }
/*  82 */     return new PickResult(this.node, this.point, this.distance, this.face, this.normal, this.texCoord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCloser(double paramDouble) {
/*  92 */     return (paramDouble < this.distance || this.empty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 100 */     return this.empty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 111 */     return this.closed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean offer(Node paramNode, double paramDouble, int paramInt, Point3D paramPoint3D, Point2D paramPoint2D) {
/* 126 */     return processOffer(paramNode, paramNode, paramDouble, paramPoint3D, paramInt, this.normal, paramPoint2D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean offer(Node paramNode, double paramDouble, Point3D paramPoint3D) {
/* 143 */     return processOffer(paramNode, paramNode, paramDouble, paramPoint3D, -1, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean offerSubScenePickResult(SubScene paramSubScene, PickResult paramPickResult, double paramDouble) {
/* 155 */     if (paramPickResult == null) {
/* 156 */       return false;
/*     */     }
/* 158 */     return processOffer(paramPickResult.getIntersectedNode(), paramSubScene, paramDouble, paramPickResult
/* 159 */         .getIntersectedPoint(), paramPickResult.getIntersectedFace(), paramPickResult
/* 160 */         .getIntersectedNormal(), paramPickResult.getIntersectedTexCoord());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean processOffer(Node paramNode1, Node paramNode2, double paramDouble, Point3D paramPoint3D1, int paramInt, Point3D paramPoint3D2, Point2D paramPoint2D) {
/* 181 */     SubScene subScene = NodeHelper.getSubScene(paramNode2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     boolean bool1 = Platform.isSupported(ConditionalFeature.SCENE3D) ? ((subScene != null) ? SubSceneHelper.isDepthBuffer(subScene) : paramNode2.getScene().isDepthBuffer()) : false;
/*     */     
/* 188 */     boolean bool2 = (bool1 && NodeHelper.isDerivedDepthTest(paramNode2)) ? true : false;
/*     */     
/* 190 */     boolean bool3 = false;
/* 191 */     if ((this.empty || (bool2 && paramDouble < this.distance)) && !this.closed) {
/* 192 */       this.node = paramNode1;
/* 193 */       this.distance = paramDouble;
/* 194 */       this.face = paramInt;
/* 195 */       this.point = paramPoint3D1;
/* 196 */       this.normal = paramPoint3D2;
/* 197 */       this.texCoord = paramPoint2D;
/* 198 */       this.empty = false;
/* 199 */       bool3 = true;
/*     */     } 
/*     */     
/* 202 */     if (!bool2) {
/* 203 */       this.closed = true;
/*     */     }
/*     */     
/* 206 */     return bool3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Node getIntersectedNode() {
/* 215 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getIntersectedDistance() {
/* 224 */     return this.distance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getIntersectedFace() {
/* 233 */     return this.face;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point3D getIntersectedPoint() {
/* 242 */     return this.point;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point3D getIntersectedNormal() {
/* 252 */     return this.normal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Point2D getIntersectedTexCoord() {
/* 261 */     return this.texCoord;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\input\PickResultChooser.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */