/*     */ package com.sun.javafx.scene.input;
/*     */ 
/*     */ import com.sun.javafx.scene.CameraHelper;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.SceneHelper;
/*     */ import com.sun.javafx.scene.SceneUtils;
/*     */ import com.sun.javafx.scene.SubSceneHelper;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.Point3D;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.SubScene;
/*     */ import javafx.scene.input.PickResult;
/*     */ import javafx.scene.input.TransferMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputEventUtils
/*     */ {
/*     */   public static Point3D recomputeCoordinates(PickResult paramPickResult, Object paramObject) {
/*  58 */     Point3D point3D = paramPickResult.getIntersectedPoint();
/*  59 */     if (point3D == null) {
/*  60 */       return new Point3D(Double.NaN, Double.NaN, Double.NaN);
/*     */     }
/*     */     
/*  63 */     Node node1 = paramPickResult.getIntersectedNode();
/*     */ 
/*     */     
/*  66 */     Node node2 = (paramObject instanceof Node) ? (Node)paramObject : null;
/*     */ 
/*     */     
/*  69 */     SubScene subScene1 = (node1 == null) ? null : NodeHelper.getSubScene(node1);
/*     */     
/*  71 */     SubScene subScene2 = (node2 == null) ? null : NodeHelper.getSubScene(node2);
/*  72 */     boolean bool = (subScene1 != subScene2) ? true : false;
/*     */     
/*  74 */     if (node1 != null) {
/*     */       
/*  76 */       point3D = node1.localToScene(point3D);
/*  77 */       if (bool && subScene1 != null)
/*     */       {
/*  79 */         point3D = SceneUtils.subSceneToScene(subScene1, point3D);
/*     */       }
/*     */     } 
/*     */     
/*  83 */     if (node2 != null) {
/*  84 */       if (bool && subScene2 != null) {
/*     */ 
/*     */         
/*  87 */         Point2D point2D = CameraHelper.project(
/*  88 */             SceneHelper.getEffectiveCamera(node2.getScene()), point3D);
/*     */ 
/*     */         
/*  91 */         point2D = SceneUtils.sceneToSubScenePlane(subScene2, point2D);
/*     */ 
/*     */         
/*  94 */         if (point2D == null) {
/*  95 */           point3D = null;
/*     */         } else {
/*  97 */           point3D = CameraHelper.pickProjectPlane(
/*  98 */               SubSceneHelper.getEffectiveCamera(subScene2), point2D
/*  99 */               .getX(), point2D.getY());
/*     */         } 
/*     */       } 
/*     */       
/* 103 */       if (point3D != null) {
/* 104 */         point3D = node2.sceneToLocal(point3D);
/*     */       }
/* 106 */       if (point3D == null) {
/* 107 */         point3D = new Point3D(Double.NaN, Double.NaN, Double.NaN);
/*     */       }
/*     */     } 
/*     */     
/* 111 */     return point3D;
/*     */   }
/*     */ 
/*     */   
/* 115 */   private static final List<TransferMode> TM_ANY = Collections.unmodifiableList(Arrays.asList(new TransferMode[] { TransferMode.COPY, TransferMode.MOVE, TransferMode.LINK }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   private static final List<TransferMode> TM_COPY_OR_MOVE = Collections.unmodifiableList(Arrays.asList(new TransferMode[] { TransferMode.COPY, TransferMode.MOVE }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<TransferMode> safeTransferModes(TransferMode[] paramArrayOfTransferMode) {
/* 136 */     if (paramArrayOfTransferMode == TransferMode.ANY)
/* 137 */       return TM_ANY; 
/* 138 */     if (paramArrayOfTransferMode == TransferMode.COPY_OR_MOVE) {
/* 139 */       return TM_COPY_OR_MOVE;
/*     */     }
/* 141 */     return Arrays.asList(paramArrayOfTransferMode);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\input\InputEventUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */