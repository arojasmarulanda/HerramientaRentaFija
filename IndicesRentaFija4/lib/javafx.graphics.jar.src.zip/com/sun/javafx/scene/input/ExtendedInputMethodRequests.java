package com.sun.javafx.scene.input;

import javafx.scene.input.InputMethodRequests;

public interface ExtendedInputMethodRequests extends InputMethodRequests {
  int getInsertPositionOffset();
  
  String getCommittedText(int paramInt1, int paramInt2);
  
  int getCommittedTextLength();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\input\ExtendedInputMethodRequests.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */