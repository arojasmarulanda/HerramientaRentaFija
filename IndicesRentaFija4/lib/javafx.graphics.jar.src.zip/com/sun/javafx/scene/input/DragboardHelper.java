/*    */ package com.sun.javafx.scene.input;
/*    */ 
/*    */ import com.sun.javafx.tk.TKClipboard;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.input.Dragboard;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DragboardHelper
/*    */ {
/*    */   private static DragboardAccessor dragboardAccessor;
/*    */   
/*    */   static {
/* 39 */     Utils.forceInit(Dragboard.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setDataAccessRestriction(Dragboard paramDragboard, boolean paramBoolean) {
/* 47 */     dragboardAccessor.setDataAccessRestriction(paramDragboard, paramBoolean);
/*    */   }
/*    */   
/*    */   public static TKClipboard getPeer(Dragboard paramDragboard) {
/* 51 */     return dragboardAccessor.getPeer(paramDragboard);
/*    */   }
/*    */   
/*    */   public static Dragboard createDragboard(TKClipboard paramTKClipboard) {
/* 55 */     return dragboardAccessor.createDragboard(paramTKClipboard);
/*    */   }
/*    */   
/*    */   public static void setDragboardAccessor(DragboardAccessor paramDragboardAccessor) {
/* 59 */     if (dragboardAccessor != null) {
/* 60 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 63 */     dragboardAccessor = paramDragboardAccessor;
/*    */   }
/*    */   
/*    */   public static interface DragboardAccessor {
/*    */     void setDataAccessRestriction(Dragboard param1Dragboard, boolean param1Boolean);
/*    */     
/*    */     TKClipboard getPeer(Dragboard param1Dragboard);
/*    */     
/*    */     Dragboard createDragboard(TKClipboard param1TKClipboard);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\input\DragboardHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */