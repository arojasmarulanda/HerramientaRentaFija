/*    */ package com.sun.javafx.scene.input;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javafx.scene.input.KeyCode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class KeyCodeMap
/*    */ {
/* 44 */   private static final Map<Integer, KeyCode> charMap = new HashMap<>((KeyCode.values()).length);
/*    */   static {
/* 46 */     for (KeyCode keyCode : KeyCode.values()) {
/* 47 */       charMap.put(Integer.valueOf(keyCode.getCode()), keyCode);
/*    */     }
/*    */   }
/*    */   
/*    */   public static KeyCode valueOf(int paramInt) {
/* 52 */     return charMap.get(Integer.valueOf(paramInt));
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\input\KeyCodeMap.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */