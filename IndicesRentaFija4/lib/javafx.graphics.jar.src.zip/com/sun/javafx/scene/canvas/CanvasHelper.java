/*    */ package com.sun.javafx.scene.canvas;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.scene.NodeHelper;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.canvas.Canvas;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CanvasHelper
/*    */   extends NodeHelper
/*    */ {
/* 44 */   private static final CanvasHelper theInstance = new CanvasHelper(); static {
/* 45 */     Utils.forceInit(Canvas.class);
/*    */   }
/*    */   private static CanvasAccessor canvasAccessor;
/*    */   private static CanvasHelper getInstance() {
/* 49 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Canvas paramCanvas) {
/* 53 */     setHelper(paramCanvas, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 58 */     return canvasAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 63 */     super.updatePeerImpl(paramNode);
/* 64 */     canvasAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 70 */     return canvasAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/* 75 */     return canvasAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*    */   }
/*    */   
/*    */   public static void setCanvasAccessor(CanvasAccessor paramCanvasAccessor) {
/* 79 */     if (canvasAccessor != null) {
/* 80 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 83 */     canvasAccessor = paramCanvasAccessor;
/*    */   }
/*    */   
/*    */   public static interface CanvasAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\canvas\CanvasHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */