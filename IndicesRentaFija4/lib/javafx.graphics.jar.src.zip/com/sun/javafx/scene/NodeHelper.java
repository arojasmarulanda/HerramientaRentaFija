/*     */ package com.sun.javafx.scene;
/*     */ 
/*     */ import com.sun.glass.ui.Accessible;
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.PickRay;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.scene.input.PickResultChooser;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import com.sun.javafx.sg.prism.NGNode;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.beans.binding.BooleanExpression;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.Style;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.SubScene;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NodeHelper
/*     */ {
/*     */   private static NodeAccessor nodeAccessor;
/*     */   
/*     */   static {
/*  57 */     Utils.forceInit(Node.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static NodeHelper getHelper(Node paramNode) {
/*  65 */     NodeHelper nodeHelper = nodeAccessor.getHelper(paramNode);
/*  66 */     if (nodeHelper == null) {
/*     */       String str;
/*  68 */       if (paramNode instanceof javafx.scene.shape.Shape) {
/*  69 */         str = "Shape";
/*  70 */       } else if (paramNode instanceof javafx.scene.shape.Shape3D) {
/*  71 */         str = "Shape3D";
/*     */       } else {
/*  73 */         str = "Node";
/*     */       } 
/*     */       
/*  76 */       throw new UnsupportedOperationException("Applications should not extend the " + str + " class directly.");
/*     */     } 
/*     */ 
/*     */     
/*  80 */     return nodeHelper;
/*     */   }
/*     */   
/*     */   protected static void setHelper(Node paramNode, NodeHelper paramNodeHelper) {
/*  84 */     nodeAccessor.setHelper(paramNode, paramNodeHelper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NGNode createPeer(Node paramNode) {
/*  94 */     return getHelper(paramNode).createPeerImpl(paramNode);
/*     */   }
/*     */   
/*     */   public static void markDirty(Node paramNode, DirtyBits paramDirtyBits) {
/*  98 */     getHelper(paramNode).markDirtyImpl(paramNode, paramDirtyBits);
/*     */   }
/*     */   
/*     */   public static void updatePeer(Node paramNode) {
/* 102 */     getHelper(paramNode).updatePeerImpl(paramNode);
/*     */   }
/*     */   
/*     */   public static Bounds computeLayoutBounds(Node paramNode) {
/* 106 */     return getHelper(paramNode).computeLayoutBoundsImpl(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BaseBounds computeGeomBounds(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 115 */     return getHelper(paramNode).computeGeomBoundsImpl(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */   
/*     */   public static void transformsChanged(Node paramNode) {
/* 119 */     getHelper(paramNode).transformsChangedImpl(paramNode);
/*     */   }
/*     */   
/*     */   public static boolean computeContains(Node paramNode, double paramDouble1, double paramDouble2) {
/* 123 */     return getHelper(paramNode).computeContainsImpl(paramNode, paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void pickNodeLocal(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 128 */     getHelper(paramNode).pickNodeLocalImpl(paramNode, paramPickRay, paramPickResultChooser);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean computeIntersects(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 133 */     return getHelper(paramNode).computeIntersectsImpl(paramNode, paramPickRay, paramPickResultChooser);
/*     */   }
/*     */   
/*     */   public static void geomChanged(Node paramNode) {
/* 137 */     getHelper(paramNode).geomChangedImpl(paramNode);
/*     */   }
/*     */   
/*     */   public static void notifyLayoutBoundsChanged(Node paramNode) {
/* 141 */     getHelper(paramNode).notifyLayoutBoundsChangedImpl(paramNode);
/*     */   }
/*     */   
/*     */   public static void processCSS(Node paramNode) {
/* 145 */     getHelper(paramNode).processCSSImpl(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void markDirtyImpl(Node paramNode, DirtyBits paramDirtyBits) {
/* 158 */     nodeAccessor.doMarkDirty(paramNode, paramDirtyBits);
/*     */   }
/*     */   
/*     */   protected void updatePeerImpl(Node paramNode) {
/* 162 */     nodeAccessor.doUpdatePeer(paramNode);
/*     */   }
/*     */   
/*     */   protected Bounds computeLayoutBoundsImpl(Node paramNode) {
/* 166 */     return nodeAccessor.doComputeLayoutBounds(paramNode);
/*     */   }
/*     */   
/*     */   protected void transformsChangedImpl(Node paramNode) {
/* 170 */     nodeAccessor.doTransformsChanged(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void pickNodeLocalImpl(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 175 */     nodeAccessor.doPickNodeLocal(paramNode, paramPickRay, paramPickResultChooser);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean computeIntersectsImpl(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 180 */     return nodeAccessor.doComputeIntersects(paramNode, paramPickRay, paramPickResultChooser);
/*     */   }
/*     */   
/*     */   protected void geomChangedImpl(Node paramNode) {
/* 184 */     nodeAccessor.doGeomChanged(paramNode);
/*     */   }
/*     */   
/*     */   protected void notifyLayoutBoundsChangedImpl(Node paramNode) {
/* 188 */     nodeAccessor.doNotifyLayoutBoundsChanged(paramNode);
/*     */   }
/*     */   
/*     */   protected void processCSSImpl(Node paramNode) {
/* 192 */     nodeAccessor.doProcessCSS(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDirty(Node paramNode, DirtyBits paramDirtyBits) {
/* 200 */     return nodeAccessor.isDirty(paramNode, paramDirtyBits);
/*     */   }
/*     */   
/*     */   public static boolean isDirtyEmpty(Node paramNode) {
/* 204 */     return nodeAccessor.isDirtyEmpty(paramNode);
/*     */   }
/*     */   
/*     */   public static void syncPeer(Node paramNode) {
/* 208 */     nodeAccessor.syncPeer(paramNode);
/*     */   }
/*     */   
/*     */   public static <P extends NGNode> P getPeer(Node paramNode) {
/* 212 */     return nodeAccessor.getPeer(paramNode);
/*     */   }
/*     */   
/*     */   public static BaseTransform getLeafTransform(Node paramNode) {
/* 216 */     return nodeAccessor.getLeafTransform(paramNode);
/*     */   }
/*     */   
/*     */   public static void layoutBoundsChanged(Node paramNode) {
/* 220 */     nodeAccessor.layoutBoundsChanged(paramNode);
/*     */   }
/*     */   
/*     */   public static void setShowMnemonics(Node paramNode, boolean paramBoolean) {
/* 224 */     nodeAccessor.setShowMnemonics(paramNode, paramBoolean);
/*     */   }
/*     */   
/*     */   public static boolean isShowMnemonics(Node paramNode) {
/* 228 */     return nodeAccessor.isShowMnemonics(paramNode);
/*     */   }
/*     */   
/*     */   public static BooleanProperty showMnemonicsProperty(Node paramNode) {
/* 232 */     return nodeAccessor.showMnemonicsProperty(paramNode);
/*     */   }
/*     */   
/*     */   public static boolean traverse(Node paramNode, Direction paramDirection) {
/* 236 */     return nodeAccessor.traverse(paramNode, paramDirection);
/*     */   }
/*     */   
/*     */   public static double getPivotX(Node paramNode) {
/* 240 */     return nodeAccessor.getPivotX(paramNode);
/*     */   }
/*     */   
/*     */   public static double getPivotY(Node paramNode) {
/* 244 */     return nodeAccessor.getPivotY(paramNode);
/*     */   }
/*     */   
/*     */   public static double getPivotZ(Node paramNode) {
/* 248 */     return nodeAccessor.getPivotZ(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void pickNode(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 253 */     nodeAccessor.pickNode(paramNode, paramPickRay, paramPickResultChooser);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean intersects(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 258 */     return nodeAccessor.intersects(paramNode, paramPickRay, paramPickResultChooser);
/*     */   }
/*     */   
/*     */   public static double intersectsBounds(Node paramNode, PickRay paramPickRay) {
/* 262 */     return nodeAccessor.intersectsBounds(paramNode, paramPickRay);
/*     */   }
/*     */   
/*     */   public static void layoutNodeForPrinting(Node paramNode) {
/* 266 */     nodeAccessor.layoutNodeForPrinting(paramNode);
/*     */   }
/*     */   
/*     */   public static boolean isDerivedDepthTest(Node paramNode) {
/* 270 */     return nodeAccessor.isDerivedDepthTest(paramNode);
/*     */   }
/*     */   
/*     */   public static SubScene getSubScene(Node paramNode) {
/* 274 */     return nodeAccessor.getSubScene(paramNode);
/*     */   }
/*     */   
/*     */   public static Accessible getAccessible(Node paramNode) {
/* 278 */     return nodeAccessor.getAccessible(paramNode);
/*     */   }
/*     */   
/*     */   public static void reapplyCSS(Node paramNode) {
/* 282 */     nodeAccessor.reapplyCSS(paramNode);
/*     */   }
/*     */   
/*     */   public static boolean isTreeVisible(Node paramNode) {
/* 286 */     return nodeAccessor.isTreeVisible(paramNode);
/*     */   }
/*     */   
/*     */   public static BooleanExpression treeVisibleProperty(Node paramNode) {
/* 290 */     return nodeAccessor.treeVisibleProperty(paramNode);
/*     */   }
/*     */   
/*     */   public static boolean isTreeShowing(Node paramNode) {
/* 294 */     return nodeAccessor.isTreeShowing(paramNode);
/*     */   }
/*     */   
/*     */   public static BooleanExpression treeShowingProperty(Node paramNode) {
/* 298 */     return nodeAccessor.treeShowingProperty(paramNode);
/*     */   }
/*     */   
/*     */   public static List<Style> getMatchingStyles(CssMetaData paramCssMetaData, Styleable paramStyleable) {
/* 302 */     return nodeAccessor.getMatchingStyles(paramCssMetaData, paramStyleable);
/*     */   }
/*     */   
/*     */   public static Map<StyleableProperty<?>, List<Style>> findStyles(Node paramNode, Map<StyleableProperty<?>, List<Style>> paramMap) {
/* 306 */     return nodeAccessor.findStyles(paramNode, paramMap);
/*     */   }
/*     */   
/*     */   public static void setNodeAccessor(NodeAccessor paramNodeAccessor) {
/* 310 */     if (nodeAccessor != null) {
/* 311 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 314 */     nodeAccessor = paramNodeAccessor;
/*     */   }
/*     */   
/*     */   public static NodeAccessor getNodeAccessor() {
/* 318 */     if (nodeAccessor == null) {
/* 319 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 322 */     return nodeAccessor;
/*     */   }
/*     */   
/*     */   protected abstract NGNode createPeerImpl(Node paramNode);
/*     */   
/*     */   protected abstract boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2);
/*     */   
/*     */   protected abstract BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform);
/*     */   
/*     */   public static interface NodeAccessor {
/*     */     NodeHelper getHelper(Node param1Node);
/*     */     
/*     */     void setHelper(Node param1Node, NodeHelper param1NodeHelper);
/*     */     
/*     */     void doMarkDirty(Node param1Node, DirtyBits param1DirtyBits);
/*     */     
/*     */     void doUpdatePeer(Node param1Node);
/*     */     
/*     */     BaseTransform getLeafTransform(Node param1Node);
/*     */     
/*     */     Bounds doComputeLayoutBounds(Node param1Node);
/*     */     
/*     */     void doTransformsChanged(Node param1Node);
/*     */     
/*     */     void doPickNodeLocal(Node param1Node, PickRay param1PickRay, PickResultChooser param1PickResultChooser);
/*     */     
/*     */     boolean doComputeIntersects(Node param1Node, PickRay param1PickRay, PickResultChooser param1PickResultChooser);
/*     */     
/*     */     void doGeomChanged(Node param1Node);
/*     */     
/*     */     void doNotifyLayoutBoundsChanged(Node param1Node);
/*     */     
/*     */     void doProcessCSS(Node param1Node);
/*     */     
/*     */     boolean isDirty(Node param1Node, DirtyBits param1DirtyBits);
/*     */     
/*     */     boolean isDirtyEmpty(Node param1Node);
/*     */     
/*     */     void syncPeer(Node param1Node);
/*     */     
/*     */     <P extends NGNode> P getPeer(Node param1Node);
/*     */     
/*     */     void layoutBoundsChanged(Node param1Node);
/*     */     
/*     */     void setShowMnemonics(Node param1Node, boolean param1Boolean);
/*     */     
/*     */     boolean isShowMnemonics(Node param1Node);
/*     */     
/*     */     BooleanProperty showMnemonicsProperty(Node param1Node);
/*     */     
/*     */     boolean traverse(Node param1Node, Direction param1Direction);
/*     */     
/*     */     double getPivotX(Node param1Node);
/*     */     
/*     */     double getPivotY(Node param1Node);
/*     */     
/*     */     double getPivotZ(Node param1Node);
/*     */     
/*     */     void pickNode(Node param1Node, PickRay param1PickRay, PickResultChooser param1PickResultChooser);
/*     */     
/*     */     boolean intersects(Node param1Node, PickRay param1PickRay, PickResultChooser param1PickResultChooser);
/*     */     
/*     */     double intersectsBounds(Node param1Node, PickRay param1PickRay);
/*     */     
/*     */     void layoutNodeForPrinting(Node param1Node);
/*     */     
/*     */     boolean isDerivedDepthTest(Node param1Node);
/*     */     
/*     */     SubScene getSubScene(Node param1Node);
/*     */     
/*     */     void setLabeledBy(Node param1Node1, Node param1Node2);
/*     */     
/*     */     Accessible getAccessible(Node param1Node);
/*     */     
/*     */     void reapplyCSS(Node param1Node);
/*     */     
/*     */     boolean isTreeVisible(Node param1Node);
/*     */     
/*     */     BooleanExpression treeVisibleProperty(Node param1Node);
/*     */     
/*     */     boolean isTreeShowing(Node param1Node);
/*     */     
/*     */     BooleanExpression treeShowingProperty(Node param1Node);
/*     */     
/*     */     List<Style> getMatchingStyles(CssMetaData param1CssMetaData, Styleable param1Styleable);
/*     */     
/*     */     Map<StyleableProperty<?>, List<Style>> findStyles(Node param1Node, Map<StyleableProperty<?>, List<Style>> param1Map);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\NodeHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */