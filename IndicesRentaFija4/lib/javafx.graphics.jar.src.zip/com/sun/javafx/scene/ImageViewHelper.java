/*    */ package com.sun.javafx.scene;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.image.ImageView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageViewHelper
/*    */   extends NodeHelper
/*    */ {
/* 45 */   private static final ImageViewHelper theInstance = new ImageViewHelper(); static {
/* 46 */     Utils.forceInit(ImageView.class);
/*    */   }
/*    */   private static ImageViewAccessor imageViewAccessor;
/*    */   private static ImageViewHelper getInstance() {
/* 50 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(ImageView paramImageView) {
/* 54 */     setHelper(paramImageView, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 59 */     return imageViewAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 64 */     super.updatePeerImpl(paramNode);
/* 65 */     imageViewAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 71 */     return imageViewAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/* 76 */     return imageViewAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*    */   }
/*    */   
/*    */   public static void setImageViewAccessor(ImageViewAccessor paramImageViewAccessor) {
/* 80 */     if (imageViewAccessor != null) {
/* 81 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 84 */     imageViewAccessor = paramImageViewAccessor;
/*    */   }
/*    */   
/*    */   public static interface ImageViewAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\ImageViewHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */