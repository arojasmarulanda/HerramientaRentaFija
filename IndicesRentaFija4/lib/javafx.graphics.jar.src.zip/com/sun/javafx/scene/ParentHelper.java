/*     */ package com.sun.javafx.scene;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.PickRay;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.scene.input.PickResultChooser;
/*     */ import com.sun.javafx.scene.traversal.ParentTraversalEngine;
/*     */ import com.sun.javafx.sg.prism.NGNode;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.util.List;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParentHelper
/*     */   extends NodeHelper
/*     */ {
/*  50 */   private static final ParentHelper theInstance = new ParentHelper(); static {
/*  51 */     Utils.forceInit(Parent.class);
/*     */   }
/*     */   private static ParentAccessor parentAccessor;
/*     */   private static ParentHelper getInstance() {
/*  55 */     return theInstance;
/*     */   }
/*     */   
/*     */   public static void initHelper(Parent paramParent) {
/*  59 */     setHelper(paramParent, getInstance());
/*     */   }
/*     */   
/*     */   public static void superProcessCSS(Node paramNode) {
/*  63 */     ((ParentHelper)getHelper(paramNode)).superProcessCSSImpl(paramNode);
/*     */   }
/*     */   
/*     */   public static List<String> getAllParentStylesheets(Parent paramParent) {
/*  67 */     return ((ParentHelper)getHelper(paramParent)).getAllParentStylesheetsImpl(paramParent);
/*     */   }
/*     */ 
/*     */   
/*     */   protected NGNode createPeerImpl(Node paramNode) {
/*  72 */     return parentAccessor.doCreatePeer(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updatePeerImpl(Node paramNode) {
/*  77 */     super.updatePeerImpl(paramNode);
/*  78 */     parentAccessor.doUpdatePeer(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  84 */     return parentAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/*  89 */     return parentAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*     */   }
/*     */   
/*     */   void superProcessCSSImpl(Node paramNode) {
/*  93 */     super.processCSSImpl(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processCSSImpl(Node paramNode) {
/*  98 */     parentAccessor.doProcessCSS(paramNode);
/*     */   }
/*     */   
/*     */   protected List<String> getAllParentStylesheetsImpl(Parent paramParent) {
/* 102 */     return parentAccessor.doGetAllParentStylesheets(paramParent);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pickNodeLocalImpl(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 108 */     parentAccessor.doPickNodeLocal(paramNode, paramPickRay, paramPickResultChooser);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean pickChildrenNode(Parent paramParent, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 113 */     return parentAccessor.pickChildrenNode(paramParent, paramPickRay, paramPickResultChooser);
/*     */   }
/*     */   
/*     */   public static void setTraversalEngine(Parent paramParent, ParentTraversalEngine paramParentTraversalEngine) {
/* 117 */     parentAccessor.setTraversalEngine(paramParent, paramParentTraversalEngine);
/*     */   }
/*     */   
/*     */   public static ParentTraversalEngine getTraversalEngine(Parent paramParent) {
/* 121 */     return parentAccessor.getTraversalEngine(paramParent);
/*     */   }
/*     */   
/*     */   public static void setParentAccessor(ParentAccessor paramParentAccessor) {
/* 125 */     if (parentAccessor != null) {
/* 126 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 129 */     parentAccessor = paramParentAccessor;
/*     */   }
/*     */   
/*     */   public static interface ParentAccessor {
/*     */     NGNode doCreatePeer(Node param1Node);
/*     */     
/*     */     void doUpdatePeer(Node param1Node);
/*     */     
/*     */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*     */     
/*     */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*     */     
/*     */     void doProcessCSS(Node param1Node);
/*     */     
/*     */     void doPickNodeLocal(Node param1Node, PickRay param1PickRay, PickResultChooser param1PickResultChooser);
/*     */     
/*     */     boolean pickChildrenNode(Parent param1Parent, PickRay param1PickRay, PickResultChooser param1PickResultChooser);
/*     */     
/*     */     void setTraversalEngine(Parent param1Parent, ParentTraversalEngine param1ParentTraversalEngine);
/*     */     
/*     */     ParentTraversalEngine getTraversalEngine(Parent param1Parent);
/*     */     
/*     */     List<String> doGetAllParentStylesheets(Parent param1Parent);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\ParentHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */