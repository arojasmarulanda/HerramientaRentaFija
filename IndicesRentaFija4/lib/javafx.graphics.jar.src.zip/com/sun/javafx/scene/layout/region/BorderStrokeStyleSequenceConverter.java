/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.layout.BorderStrokeStyle;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BorderStrokeStyleSequenceConverter
/*    */   extends StyleConverter<ParsedValue<ParsedValue[], BorderStrokeStyle>[], BorderStrokeStyle[]>
/*    */ {
/* 43 */   private static final BorderStrokeStyleSequenceConverter BORDER_STYLE_SEQUENCE_CONVERTER = new BorderStrokeStyleSequenceConverter();
/*    */ 
/*    */   
/*    */   public static BorderStrokeStyleSequenceConverter getInstance() {
/* 47 */     return BORDER_STYLE_SEQUENCE_CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BorderStrokeStyle[] convert(ParsedValue<ParsedValue<ParsedValue[], BorderStrokeStyle>[], BorderStrokeStyle[]> paramParsedValue, Font paramFont) {
/* 57 */     ParsedValue[] arrayOfParsedValue = (ParsedValue[])paramParsedValue.getValue();
/* 58 */     BorderStrokeStyle[] arrayOfBorderStrokeStyle = new BorderStrokeStyle[4];
/*    */     
/* 60 */     arrayOfBorderStrokeStyle[0] = (arrayOfParsedValue.length > 0) ? 
/* 61 */       arrayOfParsedValue[0].convert(paramFont) : BorderStrokeStyle.SOLID;
/*    */     
/* 63 */     arrayOfBorderStrokeStyle[1] = (arrayOfParsedValue.length > 1) ? 
/* 64 */       arrayOfParsedValue[1].convert(paramFont) : arrayOfBorderStrokeStyle[0];
/*    */     
/* 66 */     arrayOfBorderStrokeStyle[2] = (arrayOfParsedValue.length > 2) ? 
/* 67 */       arrayOfParsedValue[2].convert(paramFont) : arrayOfBorderStrokeStyle[0];
/*    */     
/* 69 */     arrayOfBorderStrokeStyle[3] = (arrayOfParsedValue.length > 3) ? 
/* 70 */       arrayOfParsedValue[3].convert(paramFont) : arrayOfBorderStrokeStyle[1];
/*    */     
/* 72 */     return arrayOfBorderStrokeStyle;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 77 */     return "BorderStrokeStyleSequenceConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\BorderStrokeStyleSequenceConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */