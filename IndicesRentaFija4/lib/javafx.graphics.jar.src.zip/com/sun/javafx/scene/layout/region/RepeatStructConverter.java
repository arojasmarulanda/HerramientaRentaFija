/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.css.converter.EnumConverter;
/*    */ import javafx.scene.layout.BackgroundRepeat;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RepeatStructConverter
/*    */   extends StyleConverter<ParsedValue<String, BackgroundRepeat>[][], RepeatStruct[]>
/*    */ {
/* 38 */   private static final RepeatStructConverter REPEAT_STRUCT_CONVERTER = new RepeatStructConverter();
/*    */   private final EnumConverter<BackgroundRepeat> repeatConverter;
/*    */   
/*    */   public static RepeatStructConverter getInstance() {
/* 42 */     return REPEAT_STRUCT_CONVERTER;
/*    */   }
/*    */ 
/*    */   
/*    */   private RepeatStructConverter() {
/* 47 */     this.repeatConverter = new EnumConverter(BackgroundRepeat.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RepeatStruct[] convert(ParsedValue<ParsedValue<String, BackgroundRepeat>[][], RepeatStruct[]> paramParsedValue, Font paramFont) {
/* 54 */     ParsedValue[][] arrayOfParsedValue = (ParsedValue[][])paramParsedValue.getValue();
/* 55 */     RepeatStruct[] arrayOfRepeatStruct = new RepeatStruct[arrayOfParsedValue.length];
/* 56 */     for (byte b = 0; b < arrayOfParsedValue.length; b++) {
/* 57 */       ParsedValue[] arrayOfParsedValue1 = arrayOfParsedValue[b];
/* 58 */       BackgroundRepeat backgroundRepeat1 = (BackgroundRepeat)this.repeatConverter.convert(arrayOfParsedValue1[0], null);
/* 59 */       BackgroundRepeat backgroundRepeat2 = (BackgroundRepeat)this.repeatConverter.convert(arrayOfParsedValue1[1], null);
/* 60 */       arrayOfRepeatStruct[b] = new RepeatStruct(backgroundRepeat1, backgroundRepeat2);
/*    */     } 
/* 62 */     return arrayOfRepeatStruct;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 69 */     return "RepeatStructConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\RepeatStructConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */