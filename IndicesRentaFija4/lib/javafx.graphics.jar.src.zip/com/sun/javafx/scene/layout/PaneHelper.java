/*    */ package com.sun.javafx.scene.layout;
/*    */ 
/*    */ import com.sun.javafx.scene.NodeHelper;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.layout.Pane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PaneHelper
/*    */   extends RegionHelper
/*    */ {
/* 40 */   private static final PaneHelper theInstance = new PaneHelper(); static {
/* 41 */     Utils.forceInit(Pane.class);
/*    */   }
/*    */   private static PaneAccessor paneAccessor;
/*    */   private static PaneHelper getInstance() {
/* 45 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Pane paramPane) {
/* 49 */     setHelper(paramPane, (NodeHelper)getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   public static void setPaneAccessor(PaneAccessor paramPaneAccessor) {
/* 54 */     if (paneAccessor != null) {
/* 55 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 58 */     paneAccessor = paramPaneAccessor;
/*    */   }
/*    */   
/*    */   public static interface PaneAccessor {}
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\PaneHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */