/*     */ package com.sun.javafx.scene.layout.region;
/*     */ 
/*     */ import com.sun.javafx.css.ParsedValueImpl;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.css.ParsedValue;
/*     */ import javafx.css.Size;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.scene.layout.BorderStrokeStyle;
/*     */ import javafx.scene.shape.StrokeLineCap;
/*     */ import javafx.scene.shape.StrokeLineJoin;
/*     */ import javafx.scene.shape.StrokeType;
/*     */ import javafx.scene.text.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BorderStyleConverter
/*     */   extends StyleConverter<ParsedValue[], BorderStrokeStyle>
/*     */ {
/*  65 */   public static final ParsedValueImpl<ParsedValue[], Number[]> NONE = (ParsedValueImpl)new ParsedValueImpl<>(null, null);
/*  66 */   public static final ParsedValueImpl<ParsedValue[], Number[]> HIDDEN = (ParsedValueImpl)new ParsedValueImpl<>(null, null);
/*  67 */   public static final ParsedValueImpl<ParsedValue[], Number[]> DOTTED = (ParsedValueImpl)new ParsedValueImpl<>(null, null);
/*  68 */   public static final ParsedValueImpl<ParsedValue[], Number[]> DASHED = (ParsedValueImpl)new ParsedValueImpl<>(null, null);
/*  69 */   public static final ParsedValueImpl<ParsedValue[], Number[]> SOLID = (ParsedValueImpl)new ParsedValueImpl<>(null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private static final BorderStyleConverter BORDER_STYLE_CONVERTER = new BorderStyleConverter();
/*     */ 
/*     */   
/*     */   public static BorderStyleConverter getInstance() {
/*  78 */     return BORDER_STYLE_CONVERTER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BorderStrokeStyle convert(ParsedValue<ParsedValue[], BorderStrokeStyle> paramParsedValue, Font paramFont) {
/*     */     List<Double> list;
/*  87 */     ParsedValue[] arrayOfParsedValue1 = paramParsedValue.getValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     ParsedValue parsedValue = arrayOfParsedValue1[0];
/*  95 */     boolean bool = (arrayOfParsedValue1[1] == null && arrayOfParsedValue1[2] == null && arrayOfParsedValue1[3] == null && arrayOfParsedValue1[4] == null && arrayOfParsedValue1[5] == null) ? true : false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     if (NONE == parsedValue) return BorderStrokeStyle.NONE; 
/* 102 */     if (DOTTED == parsedValue && bool)
/* 103 */       return BorderStrokeStyle.DOTTED; 
/* 104 */     if (DASHED == parsedValue && bool)
/* 105 */       return BorderStrokeStyle.DASHED; 
/* 106 */     if (SOLID == parsedValue && bool) {
/* 107 */       return BorderStrokeStyle.SOLID;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 112 */     ParsedValue[] arrayOfParsedValue2 = arrayOfParsedValue1[0].getValue();
/*     */ 
/*     */     
/* 115 */     if (arrayOfParsedValue2 == null) {
/* 116 */       if (DOTTED == parsedValue) {
/* 117 */         list = BorderStrokeStyle.DOTTED.getDashArray();
/* 118 */       } else if (DASHED == parsedValue) {
/* 119 */         list = BorderStrokeStyle.DASHED.getDashArray();
/* 120 */       } else if (SOLID == parsedValue) {
/* 121 */         list = BorderStrokeStyle.SOLID.getDashArray();
/*     */       } else {
/* 123 */         list = Collections.emptyList();
/*     */       } 
/*     */     } else {
/* 126 */       list = new ArrayList(arrayOfParsedValue2.length);
/* 127 */       for (byte b = 0; b < arrayOfParsedValue2.length; b++) {
/* 128 */         Size size = arrayOfParsedValue2[b].convert(paramFont);
/* 129 */         list.add(Double.valueOf(size.pixels(paramFont)));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 134 */     double d1 = (arrayOfParsedValue1[1] != null) ? ((Double)arrayOfParsedValue1[1].convert(paramFont)).doubleValue() : 0.0D;
/*     */ 
/*     */     
/* 137 */     StrokeType strokeType = (arrayOfParsedValue1[2] != null) ? arrayOfParsedValue1[2].convert(paramFont) : StrokeType.INSIDE;
/*     */ 
/*     */     
/* 140 */     StrokeLineJoin strokeLineJoin = (arrayOfParsedValue1[3] != null) ? arrayOfParsedValue1[3].convert(paramFont) : StrokeLineJoin.MITER;
/*     */ 
/*     */     
/* 143 */     double d2 = (arrayOfParsedValue1[4] != null) ? ((Double)arrayOfParsedValue1[4].convert(paramFont)).doubleValue() : 10.0D;
/*     */ 
/*     */     
/* 146 */     StrokeLineCap strokeLineCap = (arrayOfParsedValue1[5] != null) ? arrayOfParsedValue1[5].convert(paramFont) : ((DOTTED == parsedValue) ? StrokeLineCap.ROUND : StrokeLineCap.BUTT);
/*     */     
/* 148 */     BorderStrokeStyle borderStrokeStyle = new BorderStrokeStyle(strokeType, strokeLineJoin, strokeLineCap, d2, d1, list);
/*     */ 
/*     */     
/* 151 */     if (BorderStrokeStyle.SOLID.equals(borderStrokeStyle)) {
/* 152 */       return BorderStrokeStyle.SOLID;
/*     */     }
/* 154 */     return borderStrokeStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 162 */     return "BorderStyleConverter";
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\BorderStyleConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */