/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.Size;
/*    */ import javafx.css.SizeUnits;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.layout.BorderWidths;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BorderImageSliceConverter
/*    */   extends StyleConverter<ParsedValue[], BorderImageSlices>
/*    */ {
/* 39 */   private static final BorderImageSliceConverter BORDER_IMAGE_SLICE_CONVERTER = new BorderImageSliceConverter();
/*    */ 
/*    */   
/*    */   public static BorderImageSliceConverter getInstance() {
/* 43 */     return BORDER_IMAGE_SLICE_CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BorderImageSlices convert(ParsedValue<ParsedValue[], BorderImageSlices> paramParsedValue, Font paramFont) {
/* 52 */     ParsedValue[] arrayOfParsedValue1 = paramParsedValue.getValue();
/*    */ 
/*    */     
/* 55 */     ParsedValue[] arrayOfParsedValue2 = arrayOfParsedValue1[0].getValue();
/* 56 */     Size size1 = arrayOfParsedValue2[0].convert(paramFont);
/* 57 */     Size size2 = arrayOfParsedValue2[1].convert(paramFont);
/* 58 */     Size size3 = arrayOfParsedValue2[2].convert(paramFont);
/* 59 */     Size size4 = arrayOfParsedValue2[3].convert(paramFont);
/*    */     
/* 61 */     return new BorderImageSlices(new BorderWidths(size1
/*    */           
/* 63 */           .pixels(paramFont), size2
/* 64 */           .pixels(paramFont), size3
/* 65 */           .pixels(paramFont), size4
/* 66 */           .pixels(paramFont), 
/* 67 */           (size1.getUnits() == SizeUnits.PERCENT), 
/* 68 */           (size2.getUnits() == SizeUnits.PERCENT), 
/* 69 */           (size3.getUnits() == SizeUnits.PERCENT), 
/* 70 */           (size4.getUnits() == SizeUnits.PERCENT)), ((Boolean)arrayOfParsedValue1[1]
/*    */         
/* 72 */         .getValue()).booleanValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     return "BorderImageSliceConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\BorderImageSliceConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */