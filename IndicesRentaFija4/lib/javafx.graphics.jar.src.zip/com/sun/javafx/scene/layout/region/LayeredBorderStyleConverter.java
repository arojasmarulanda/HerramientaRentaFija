/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.layout.BorderStrokeStyle;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LayeredBorderStyleConverter
/*    */   extends StyleConverter<ParsedValue<ParsedValue<ParsedValue[], BorderStrokeStyle>[], BorderStrokeStyle[]>[], BorderStrokeStyle[][]>
/*    */ {
/* 52 */   private static final LayeredBorderStyleConverter LAYERED_BORDER_STYLE_CONVERTER = new LayeredBorderStyleConverter();
/*    */ 
/*    */   
/*    */   public static LayeredBorderStyleConverter getInstance() {
/* 56 */     return LAYERED_BORDER_STYLE_CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BorderStrokeStyle[][] convert(ParsedValue<ParsedValue<ParsedValue<ParsedValue[], BorderStrokeStyle>[], BorderStrokeStyle[]>[], BorderStrokeStyle[][]> paramParsedValue, Font paramFont) {
/* 67 */     ParsedValue[] arrayOfParsedValue = (ParsedValue[])paramParsedValue.getValue();
/* 68 */     BorderStrokeStyle[][] arrayOfBorderStrokeStyle = new BorderStrokeStyle[arrayOfParsedValue.length][0];
/*    */     
/* 70 */     for (byte b = 0; b < arrayOfParsedValue.length; b++) {
/* 71 */       arrayOfBorderStrokeStyle[b] = arrayOfParsedValue[b].convert(paramFont);
/*    */     }
/* 73 */     return arrayOfBorderStrokeStyle;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 78 */     return "LayeredBorderStyleConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\LayeredBorderStyleConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */