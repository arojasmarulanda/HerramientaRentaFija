/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.Size;
/*    */ import javafx.css.SizeUnits;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.geometry.Side;
/*    */ import javafx.scene.layout.BackgroundPosition;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BackgroundPositionConverter
/*    */   extends StyleConverter<ParsedValue[], BackgroundPosition>
/*    */ {
/* 40 */   private static final BackgroundPositionConverter BACKGROUND_POSITION_CONVERTER = new BackgroundPositionConverter();
/*    */ 
/*    */   
/*    */   public static BackgroundPositionConverter getInstance() {
/* 44 */     return BACKGROUND_POSITION_CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BackgroundPosition convert(ParsedValue<ParsedValue[], BackgroundPosition> paramParsedValue, Font paramFont) {
/* 52 */     ParsedValue[] arrayOfParsedValue = paramParsedValue.getValue();
/*    */ 
/*    */     
/* 55 */     Size size1 = arrayOfParsedValue[0].convert(paramFont);
/* 56 */     Size size2 = arrayOfParsedValue[1].convert(paramFont);
/* 57 */     Size size3 = arrayOfParsedValue[2].convert(paramFont);
/* 58 */     Size size4 = arrayOfParsedValue[3].convert(paramFont);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 63 */     boolean bool1 = ((size3.getValue() > 0.0D && size3.getUnits() == SizeUnits.PERCENT) || (size1.getValue() > 0.0D && size1.getUnits() == SizeUnits.PERCENT) || (size1.getValue() == 0.0D && size3.getValue() == 0.0D)) ? true : false;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 69 */     boolean bool2 = ((size2.getValue() > 0.0D && size2.getUnits() == SizeUnits.PERCENT) || (size4.getValue() > 0.0D && size4.getUnits() == SizeUnits.PERCENT) || (size4.getValue() == 0.0D && size2.getValue() == 0.0D)) ? true : false;
/*    */     
/* 71 */     double d1 = size1.pixels(paramFont);
/* 72 */     double d2 = size2.pixels(paramFont);
/* 73 */     double d3 = size3.pixels(paramFont);
/* 74 */     double d4 = size4.pixels(paramFont);
/*    */     
/* 76 */     return new BackgroundPosition((
/* 77 */         d4 == 0.0D && d2 != 0.0D) ? Side.RIGHT : Side.LEFT, 
/* 78 */         (d4 == 0.0D && d2 != 0.0D) ? d2 : d4, bool2, (
/*    */         
/* 80 */         d1 == 0.0D && d3 != 0.0D) ? Side.BOTTOM : Side.TOP, 
/* 81 */         (d1 == 0.0D && d3 != 0.0D) ? d3 : d1, bool1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 89 */     return "BackgroundPositionConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\BackgroundPositionConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */