/*     */ package com.sun.javafx.scene.layout.region;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.javafx.util.Logging;
/*     */ import javafx.css.ParsedValue;
/*     */ import javafx.css.Size;
/*     */ import javafx.css.SizeUnits;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.scene.text.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Margins
/*     */ {
/*     */   final double top;
/*     */   final double right;
/*     */   final double bottom;
/*     */   final double left;
/*     */   final boolean proportional;
/*     */   
/*     */   private static class Holder
/*     */   {
/*  46 */     static Margins.Converter CONVERTER_INSTANCE = new Margins.Converter();
/*  47 */     static Margins.SequenceConverter SEQUENCE_CONVERTER_INSTANCE = new Margins.SequenceConverter();
/*     */   }
/*     */   
/*     */   public final double getTop() {
/*  51 */     return this.top;
/*     */   }
/*     */   public final double getRight() {
/*  54 */     return this.right;
/*     */   }
/*     */   public final double getBottom() {
/*  57 */     return this.bottom;
/*     */   }
/*     */   public final double getLeft() {
/*  60 */     return this.left;
/*     */   }
/*     */   public final boolean isProportional() {
/*  63 */     return this.proportional;
/*     */   }
/*     */   public Margins(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) {
/*  66 */     this.top = paramDouble1;
/*  67 */     this.right = paramDouble2;
/*  68 */     this.bottom = paramDouble3;
/*  69 */     this.left = paramDouble4;
/*  70 */     this.proportional = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  75 */     return "top: " + this.top + "\nright: " + this.right + "\nbottom: " + this.bottom + "\nleft: " + this.left;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Converter
/*     */     extends StyleConverter<ParsedValue[], Margins>
/*     */   {
/*     */     public static Converter getInstance() {
/*  84 */       return Margins.Holder.CONVERTER_INSTANCE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Converter() {}
/*     */ 
/*     */     
/*     */     public Margins convert(ParsedValue<ParsedValue[], Margins> param1ParsedValue, Font param1Font) {
/*  93 */       ParsedValue[] arrayOfParsedValue = param1ParsedValue.getValue();
/*  94 */       Size size1 = (arrayOfParsedValue.length > 0) ? arrayOfParsedValue[0].convert(param1Font) : new Size(0.0D, SizeUnits.PX);
/*  95 */       Size size2 = (arrayOfParsedValue.length > 1) ? arrayOfParsedValue[1].convert(param1Font) : size1;
/*  96 */       Size size3 = (arrayOfParsedValue.length > 2) ? arrayOfParsedValue[2].convert(param1Font) : size1;
/*  97 */       Size size4 = (arrayOfParsedValue.length > 3) ? arrayOfParsedValue[3].convert(param1Font) : size2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 104 */       boolean bool1 = (size1.getUnits() == SizeUnits.PERCENT || size2.getUnits() == SizeUnits.PERCENT || size3.getUnits() == SizeUnits.PERCENT || size4.getUnits() == SizeUnits.PERCENT) ? true : false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 112 */       boolean bool2 = (!bool1 || (size1.getUnits() == SizeUnits.PERCENT && size2.getUnits() == SizeUnits.PERCENT && size3.getUnits() == SizeUnits.PERCENT && size4.getUnits() == SizeUnits.PERCENT)) ? true : false;
/*     */ 
/*     */ 
/*     */       
/* 116 */       if (!bool2) {
/* 117 */         PlatformLogger platformLogger = Logging.getCSSLogger();
/* 118 */         if (platformLogger.isLoggable(PlatformLogger.Level.WARNING)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 125 */           String str = "units do no match: " + size1.toString() + " ," + size2.toString() + " ," + size3.toString() + " ," + size4.toString();
/* 126 */           platformLogger.warning(str);
/*     */         } 
/*     */       } 
/*     */       
/* 130 */       bool1 = (bool1 && bool2) ? true : false;
/*     */       
/* 132 */       double d1 = size1.pixels(param1Font);
/* 133 */       double d2 = size2.pixels(param1Font);
/* 134 */       double d3 = size3.pixels(param1Font);
/* 135 */       double d4 = size4.pixels(param1Font);
/* 136 */       return new Margins(d1, d2, d3, d4, bool1);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 141 */       return "MarginsConverter";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class SequenceConverter
/*     */     extends StyleConverter<ParsedValue<ParsedValue[], Margins>[], Margins[]>
/*     */   {
/*     */     public static SequenceConverter getInstance() {
/* 151 */       return Margins.Holder.SEQUENCE_CONVERTER_INSTANCE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private SequenceConverter() {}
/*     */ 
/*     */     
/*     */     public Margins[] convert(ParsedValue<ParsedValue<ParsedValue[], Margins>[], Margins[]> param1ParsedValue, Font param1Font) {
/* 160 */       ParsedValue[] arrayOfParsedValue = (ParsedValue[])param1ParsedValue.getValue();
/* 161 */       Margins[] arrayOfMargins = new Margins[arrayOfParsedValue.length];
/* 162 */       for (byte b = 0; b < arrayOfParsedValue.length; b++) {
/* 163 */         arrayOfMargins[b] = Margins.Converter.getInstance().convert(arrayOfParsedValue[b], param1Font);
/*     */       }
/* 165 */       return arrayOfMargins;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 170 */       return "MarginsSequenceConverter";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\Margins.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */