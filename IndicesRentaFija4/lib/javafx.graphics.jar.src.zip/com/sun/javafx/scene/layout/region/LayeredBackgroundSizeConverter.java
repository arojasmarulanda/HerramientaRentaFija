/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.layout.BackgroundSize;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LayeredBackgroundSizeConverter
/*    */   extends StyleConverter<ParsedValue<ParsedValue[], BackgroundSize>[], BackgroundSize[]>
/*    */ {
/* 44 */   private static final LayeredBackgroundSizeConverter LAYERED_BACKGROUND_SIZE_CONVERTER = new LayeredBackgroundSizeConverter();
/*    */ 
/*    */   
/*    */   public static LayeredBackgroundSizeConverter getInstance() {
/* 48 */     return LAYERED_BACKGROUND_SIZE_CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BackgroundSize[] convert(ParsedValue<ParsedValue<ParsedValue[], BackgroundSize>[], BackgroundSize[]> paramParsedValue, Font paramFont) {
/* 57 */     ParsedValue[] arrayOfParsedValue = (ParsedValue[])paramParsedValue.getValue();
/* 58 */     BackgroundSize[] arrayOfBackgroundSize = new BackgroundSize[arrayOfParsedValue.length];
/* 59 */     for (byte b = 0; b < arrayOfParsedValue.length; b++) {
/* 60 */       arrayOfBackgroundSize[b] = arrayOfParsedValue[b].convert(paramFont);
/*    */     }
/* 62 */     return arrayOfBackgroundSize;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\LayeredBackgroundSizeConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */