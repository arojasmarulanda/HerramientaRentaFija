/*    */ package com.sun.javafx.scene.traversal;
/*    */ 
/*    */ import javafx.scene.Parent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ParentTraversalEngine
/*    */   extends TraversalEngine
/*    */ {
/*    */   private final Parent root;
/*    */   private Boolean overridenTraversability;
/*    */   
/*    */   public ParentTraversalEngine(Parent paramParent, Algorithm paramAlgorithm) {
/* 43 */     super(paramAlgorithm);
/* 44 */     this.root = paramParent;
/*    */   }
/*    */ 
/*    */   
/*    */   public ParentTraversalEngine(Parent paramParent) {
/* 49 */     this.root = paramParent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setOverriddenFocusTraversability(Boolean paramBoolean) {
/* 56 */     this.overridenTraversability = paramBoolean;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Parent getRoot() {
/* 61 */     return this.root;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isParentTraversable() {
/* 67 */     return (this.overridenTraversability != null) ? ((this.root.isFocusTraversable() && this.overridenTraversability.booleanValue())) : this.root.isFocusTraversable();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\ParentTraversalEngine.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */