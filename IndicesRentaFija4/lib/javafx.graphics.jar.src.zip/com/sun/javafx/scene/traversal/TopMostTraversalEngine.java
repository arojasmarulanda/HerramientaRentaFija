/*     */ package com.sun.javafx.scene.traversal;
/*     */ 
/*     */ import com.sun.javafx.scene.ParentHelper;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TopMostTraversalEngine
/*     */   extends TraversalEngine
/*     */ {
/*     */   protected TopMostTraversalEngine() {
/*  52 */     super(DEFAULT_ALGORITHM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TopMostTraversalEngine(Algorithm paramAlgorithm) {
/*  59 */     super(paramAlgorithm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Node trav(Node paramNode, Direction paramDirection) {
/*  70 */     Node node1 = null;
/*  71 */     Parent parent = paramNode.getParent();
/*  72 */     Node node2 = paramNode;
/*  73 */     while (parent != null) {
/*     */       
/*  75 */       ParentTraversalEngine parentTraversalEngine = ParentHelper.getTraversalEngine(parent);
/*  76 */       if (parentTraversalEngine != null && parentTraversalEngine.canTraverse()) {
/*  77 */         node1 = parentTraversalEngine.select(paramNode, paramDirection);
/*  78 */         if (node1 != null) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  84 */         node2 = parent;
/*  85 */         if (paramDirection == Direction.NEXT) {
/*  86 */           paramDirection = Direction.NEXT_IN_LINE;
/*     */         }
/*     */       } 
/*     */       
/*  90 */       parent = parent.getParent();
/*     */     } 
/*     */     
/*  93 */     if (node1 == null) {
/*  94 */       node1 = select(node2, paramDirection);
/*     */     }
/*  96 */     if (node1 == null) {
/*  97 */       if (paramDirection == Direction.NEXT || paramDirection == Direction.NEXT_IN_LINE) {
/*  98 */         node1 = selectFirst();
/*  99 */       } else if (paramDirection == Direction.PREVIOUS) {
/* 100 */         node1 = selectLast();
/*     */       } 
/*     */     }
/* 103 */     if (node1 != null) {
/* 104 */       focusAndNotify(node1);
/*     */     }
/* 106 */     return node1;
/*     */   }
/*     */   
/*     */   private void focusAndNotify(Node paramNode) {
/* 110 */     paramNode.requestFocus();
/* 111 */     notifyTreeTraversedTo(paramNode);
/*     */   }
/*     */   
/*     */   private void notifyTreeTraversedTo(Node paramNode) {
/* 115 */     Parent parent = paramNode.getParent();
/* 116 */     while (parent != null) {
/* 117 */       ParentTraversalEngine parentTraversalEngine = ParentHelper.getTraversalEngine(parent);
/* 118 */       if (parentTraversalEngine != null) {
/* 119 */         parentTraversalEngine.notifyTraversedTo(paramNode);
/*     */       }
/* 121 */       parent = parent.getParent();
/*     */     } 
/* 123 */     notifyTraversedTo(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Node traverseToFirst() {
/* 131 */     Node node = selectFirst();
/* 132 */     if (node != null) focusAndNotify(node); 
/* 133 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Node traverseToLast() {
/* 141 */     Node node = selectLast();
/* 142 */     if (node != null) focusAndNotify(node); 
/* 143 */     return node;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\TopMostTraversalEngine.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */