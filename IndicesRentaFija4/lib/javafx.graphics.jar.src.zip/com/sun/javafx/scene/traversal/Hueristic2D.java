/*     */ package com.sun.javafx.scene.traversal;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import java.util.function.Function;
/*     */ import javafx.geometry.BoundingBox;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Hueristic2D
/*     */   implements Algorithm
/*     */ {
/*     */   public Node select(Node paramNode, Direction paramDirection, TraversalContext paramTraversalContext) {
/*  46 */     Node node = null;
/*     */     
/*  48 */     cacheTraversal(paramNode, paramDirection);
/*     */     
/*  50 */     if (Direction.NEXT.equals(paramDirection) || Direction.NEXT_IN_LINE.equals(paramDirection)) {
/*  51 */       node = TabOrderHelper.findNextFocusablePeer(paramNode, paramTraversalContext.getRoot(), (paramDirection == Direction.NEXT));
/*     */     }
/*  53 */     else if (Direction.PREVIOUS.equals(paramDirection)) {
/*  54 */       node = TabOrderHelper.findPreviousFocusablePeer(paramNode, paramTraversalContext.getRoot());
/*     */     }
/*  56 */     else if (Direction.UP.equals(paramDirection) || Direction.DOWN.equals(paramDirection) || Direction.LEFT.equals(paramDirection) || Direction.RIGHT.equals(paramDirection)) {
/*     */ 
/*     */ 
/*     */       
/*  60 */       if (this.reverseDirection == true && !this.traversalNodeStack.empty()) {
/*  61 */         if (!((Node)this.traversalNodeStack.peek()).isFocusTraversable()) {
/*  62 */           this.traversalNodeStack.clear();
/*     */         } else {
/*     */           
/*  65 */           node = this.traversalNodeStack.pop();
/*     */         } 
/*     */       }
/*     */       
/*  69 */       if (node == null) {
/*  70 */         Bounds bounds = paramNode.localToScene(paramNode.getLayoutBounds());
/*  71 */         if (this.cacheStartTraversalNode != null) {
/*  72 */           Bounds bounds1 = this.cacheStartTraversalNode.localToScene(this.cacheStartTraversalNode.getLayoutBounds());
/*  73 */           switch (paramDirection) {
/*     */             case UP:
/*     */             case DOWN:
/*  76 */               node = getNearestNodeUpOrDown(bounds, bounds1, paramTraversalContext, paramDirection);
/*     */               break;
/*     */             case LEFT:
/*     */             case RIGHT:
/*  80 */               node = getNearestNodeLeftOrRight(bounds, bounds1, paramTraversalContext, paramDirection);
/*     */               break;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/*  94 */     if (node != null) {
/*  95 */       this.cacheLastTraversalNode = node;
/*  96 */       if (!this.reverseDirection) {
/*  97 */         this.traversalNodeStack.push(paramNode);
/*     */       }
/*     */     } 
/* 100 */     return node;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node selectFirst(TraversalContext paramTraversalContext) {
/* 105 */     return TabOrderHelper.getFirstTargetNode(paramTraversalContext.getRoot());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node selectLast(TraversalContext paramTraversalContext) {
/* 110 */     return TabOrderHelper.getLastTargetNode(paramTraversalContext.getRoot());
/*     */   }
/*     */   private boolean isOnAxis(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d1;
/*     */     double d2;
/*     */     double d3;
/*     */     double d4;
/* 117 */     if (paramDirection == Direction.UP || paramDirection == Direction.DOWN) {
/* 118 */       d1 = paramBounds1.getMinX();
/* 119 */       d2 = paramBounds1.getMaxX();
/* 120 */       d3 = paramBounds2.getMinX();
/* 121 */       d4 = paramBounds2.getMaxX();
/*     */     } else {
/*     */       
/* 124 */       d1 = paramBounds1.getMinY();
/* 125 */       d2 = paramBounds1.getMaxY();
/* 126 */       d3 = paramBounds2.getMinY();
/* 127 */       d4 = paramBounds2.getMaxY();
/*     */     } 
/*     */     
/* 130 */     return (d3 <= d2 && d4 >= d1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double outDistance(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d;
/* 140 */     if (paramDirection == Direction.UP) {
/* 141 */       d = paramBounds1.getMinY() - paramBounds2.getMaxY();
/*     */     }
/* 143 */     else if (paramDirection == Direction.DOWN) {
/* 144 */       d = paramBounds2.getMinY() - paramBounds1.getMaxY();
/*     */     }
/* 146 */     else if (paramDirection == Direction.LEFT) {
/* 147 */       d = paramBounds1.getMinX() - paramBounds2.getMaxX();
/*     */     } else {
/*     */       
/* 150 */       d = paramBounds2.getMinX() - paramBounds1.getMaxX();
/*     */     } 
/* 152 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double centerSideDistance(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d1;
/*     */     double d2;
/* 163 */     if (paramDirection == Direction.UP || paramDirection == Direction.DOWN) {
/* 164 */       d1 = paramBounds1.getMinX() + paramBounds1.getWidth() / 2.0D;
/* 165 */       d2 = paramBounds2.getMinX() + paramBounds2.getWidth() / 2.0D;
/*     */     } else {
/*     */       
/* 168 */       d1 = paramBounds1.getMinY() + paramBounds1.getHeight() / 2.0D;
/* 169 */       d2 = paramBounds2.getMinY() + paramBounds2.getHeight() / 2.0D;
/*     */     } 
/* 171 */     return Math.abs(d2 - d1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double cornerSideDistance(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d;
/* 182 */     if (paramDirection == Direction.UP || paramDirection == Direction.DOWN) {
/* 183 */       if (paramBounds2.getMinX() > paramBounds1.getMaxX())
/*     */       {
/* 185 */         d = paramBounds2.getMinX() - paramBounds1.getMaxX();
/*     */       }
/*     */       else
/*     */       {
/* 189 */         d = paramBounds1.getMinX() - paramBounds2.getMaxX();
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 194 */     else if (paramBounds2.getMinY() > paramBounds1.getMaxY()) {
/*     */       
/* 196 */       d = paramBounds2.getMinY() - paramBounds1.getMaxY();
/*     */     }
/*     */     else {
/*     */       
/* 200 */       d = paramBounds1.getMinY() - paramBounds2.getMaxY();
/*     */     } 
/*     */     
/* 203 */     return d;
/*     */   }
/*     */   
/* 206 */   protected Node cacheStartTraversalNode = null;
/* 207 */   protected Direction cacheStartTraversalDirection = null;
/*     */   protected boolean reverseDirection = false;
/* 209 */   protected Node cacheLastTraversalNode = null;
/* 210 */   protected Stack<Node> traversalNodeStack = new Stack<>(); private static final Function<Bounds, Double> BOUNDS_TOP_SIDE; private static final Function<Bounds, Double> BOUNDS_BOTTOM_SIDE; private static final Function<Bounds, Double> BOUNDS_LEFT_SIDE; private static final Function<Bounds, Double> BOUNDS_RIGHT_SIDE;
/*     */   
/*     */   private void cacheTraversal(Node paramNode, Direction paramDirection) {
/* 213 */     if (!this.traversalNodeStack.empty() && paramNode != this.cacheLastTraversalNode)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 218 */       this.traversalNodeStack.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 223 */     if (paramDirection == Direction.NEXT || paramDirection == Direction.PREVIOUS) {
/* 224 */       this.traversalNodeStack.clear();
/* 225 */       this.reverseDirection = false;
/*     */     }
/* 227 */     else if (this.cacheStartTraversalNode == null || paramDirection != this.cacheStartTraversalDirection) {
/*     */       
/* 229 */       if ((paramDirection == Direction.UP && this.cacheStartTraversalDirection == Direction.DOWN) || (paramDirection == Direction.DOWN && this.cacheStartTraversalDirection == Direction.UP) || (paramDirection == Direction.LEFT && this.cacheStartTraversalDirection == Direction.RIGHT) || (paramDirection == Direction.RIGHT && this.cacheStartTraversalDirection == Direction.LEFT && 
/*     */ 
/*     */         
/* 232 */         !this.traversalNodeStack.empty())) {
/* 233 */         this.reverseDirection = true;
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 241 */         this.cacheStartTraversalNode = paramNode;
/* 242 */         this.cacheStartTraversalDirection = paramDirection;
/* 243 */         this.reverseDirection = false;
/* 244 */         this.traversalNodeStack.clear();
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 250 */       this.reverseDirection = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   static {
/* 255 */     BOUNDS_TOP_SIDE = (paramBounds -> Double.valueOf(paramBounds.getMinY()));
/*     */     
/* 257 */     BOUNDS_BOTTOM_SIDE = (paramBounds -> Double.valueOf(paramBounds.getMaxY()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 549 */     BOUNDS_LEFT_SIDE = (paramBounds -> Double.valueOf(paramBounds.getMinX()));
/*     */     
/* 551 */     BOUNDS_RIGHT_SIDE = (paramBounds -> Double.valueOf(paramBounds.getMaxX()));
/*     */   }
/*     */   
/*     */   protected Node getNearestNodeLeftOrRight(Bounds paramBounds1, Bounds paramBounds2, TraversalContext paramTraversalContext, Direction paramDirection) {
/* 555 */     List<Node> list = paramTraversalContext.getAllTargetNodes();
/*     */     
/* 557 */     Function<Bounds, Double> function1 = (paramDirection == Direction.LEFT) ? BOUNDS_LEFT_SIDE : BOUNDS_RIGHT_SIDE;
/* 558 */     Function<Bounds, Double> function2 = (paramDirection == Direction.LEFT) ? BOUNDS_RIGHT_SIDE : BOUNDS_LEFT_SIDE;
/*     */     
/* 560 */     BoundingBox boundingBox = new BoundingBox(paramBounds1.getMinX(), paramBounds2.getMinY(), paramBounds1.getWidth(), paramBounds2.getHeight());
/*     */     
/* 562 */     Point2D point2D1 = new Point2D(((Double)function1.apply(paramBounds1)).doubleValue(), paramBounds1.getMinY() + paramBounds1.getHeight() / 2.0D);
/* 563 */     Point2D point2D2 = new Point2D(((Double)function1.apply(paramBounds1)).doubleValue(), paramBounds2.getMinY() + paramBounds2.getHeight() / 2.0D);
/* 564 */     Point2D point2D3 = new Point2D(((Double)function1.apply(paramBounds1)).doubleValue(), paramBounds1.getMinY());
/* 565 */     Point2D point2D4 = new Point2D(((Double)function1.apply(paramBounds1)).doubleValue(), paramBounds2.getMinY());
/* 566 */     Point2D point2D5 = new Point2D(((Double)function1.apply(paramBounds1)).doubleValue(), paramBounds1.getMaxY());
/* 567 */     Point2D point2D6 = new Point2D(((Double)function1.apply(paramBounds1)).doubleValue(), paramBounds2.getMaxY());
/*     */     
/* 569 */     Point2D point2D7 = new Point2D(((Double)function1.apply(paramBounds2)).doubleValue(), paramBounds2.getMinY());
/*     */     
/* 571 */     TargetNode targetNode1 = new TargetNode();
/* 572 */     TargetNode targetNode2 = null;
/* 573 */     TargetNode targetNode3 = null;
/* 574 */     TargetNode targetNode4 = null;
/* 575 */     TargetNode targetNode5 = null;
/* 576 */     TargetNode targetNode6 = null;
/* 577 */     TargetNode targetNode7 = null;
/* 578 */     TargetNode targetNode8 = null;
/*     */     
/* 580 */     for (byte b = 0; b < list.size(); b++) {
/* 581 */       Node node = list.get(b);
/*     */       
/* 583 */       Bounds bounds = node.localToScene(node.getLayoutBounds());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 588 */       if ((paramDirection == Direction.LEFT) ? (paramBounds1.getMinX() > bounds.getMinX()) : (paramBounds1
/* 589 */         .getMaxX() < bounds.getMaxX())) {
/*     */         
/* 591 */         targetNode1.node = node;
/* 592 */         targetNode1.bounds = bounds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 598 */         double d1 = Math.max(0.0D, outDistance(paramDirection, boundingBox, bounds));
/*     */         
/* 600 */         if (isOnAxis(paramDirection, boundingBox, bounds)) {
/* 601 */           targetNode1.biased2DMetric = d1 + centerSideDistance(paramDirection, boundingBox, bounds) / 100.0D;
/*     */         } else {
/* 603 */           double d = cornerSideDistance(paramDirection, boundingBox, bounds);
/* 604 */           targetNode1.biased2DMetric = 100000.0D + d1 * d1 + 9.0D * d * d;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 610 */         double d2 = Math.max(0.0D, outDistance(paramDirection, paramBounds1, bounds));
/*     */         
/* 612 */         if (isOnAxis(paramDirection, paramBounds1, bounds)) {
/* 613 */           targetNode1.current2DMetric = d2 + centerSideDistance(paramDirection, paramBounds1, bounds) / 100.0D;
/*     */         } else {
/* 615 */           double d = cornerSideDistance(paramDirection, paramBounds1, bounds);
/* 616 */           targetNode1.current2DMetric = 100000.0D + d2 * d2 + 9.0D * d * d;
/*     */         } 
/*     */         
/* 619 */         targetNode1.topCornerDistance = point2D3.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMinY());
/* 620 */         targetNode1.bottomCornerDistance = point2D5.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMaxY());
/*     */         
/* 622 */         double d3 = point2D1.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMinY() + bounds.getHeight() / 2.0D);
/* 623 */         double d4 = point2D3.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMaxY());
/* 624 */         double d5 = point2D3.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMinY() + bounds.getHeight() / 2.0D);
/* 625 */         double d6 = point2D5.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMinY());
/* 626 */         double d7 = point2D5.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMaxY());
/* 627 */         double d8 = point2D5.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMinY() + bounds.getHeight() / 2.0D);
/* 628 */         double d9 = point2D1.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMinY());
/* 629 */         double d10 = point2D1.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMaxY());
/* 630 */         double d11 = point2D1.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMinY() + bounds.getHeight() / 2.0D);
/*     */         
/* 632 */         double d12 = point2D4.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMaxY());
/* 633 */         double d13 = point2D4.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMinY() + bounds.getHeight() / 2.0D);
/* 634 */         double d14 = point2D6.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMinY() + bounds.getHeight() / 2.0D);
/* 635 */         double d15 = point2D2.distance(((Double)function2.apply(bounds)).doubleValue(), bounds.getMaxY());
/*     */         
/* 637 */         targetNode1.averageDistance = (targetNode1.topCornerDistance + d12 + d13 + d6 + targetNode1.bottomCornerDistance + d14 + d3) / 7.0D;
/*     */ 
/*     */ 
/*     */         
/* 641 */         targetNode1
/* 642 */           .biasShortestDistance = findMin(new double[] { targetNode1.topCornerDistance, d12, d13, d6, targetNode1.bottomCornerDistance, d14, d9, d15, d3 });
/*     */ 
/*     */ 
/*     */         
/* 646 */         targetNode1
/* 647 */           .shortestDistance = findMin(new double[] { targetNode1.topCornerDistance, d4, d5, d6, d7, d8, d9, d10, d11 });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 654 */         if (d1 >= 0.0D && (
/* 655 */           targetNode3 == null || targetNode1.biased2DMetric < targetNode3.biased2DMetric)) {
/*     */           
/* 657 */           if (targetNode3 == null) {
/* 658 */             targetNode3 = new TargetNode();
/*     */           }
/* 660 */           targetNode3.copy(targetNode1);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 666 */         if (d2 >= 0.0D && (
/* 667 */           targetNode2 == null || targetNode1.current2DMetric < targetNode2.current2DMetric)) {
/*     */           
/* 669 */           if (targetNode2 == null) {
/* 670 */             targetNode2 = new TargetNode();
/*     */           }
/* 672 */           targetNode2.copy(targetNode1);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 678 */         if (paramBounds2.getMaxY() > bounds.getMinY() && bounds.getMaxY() > paramBounds2.getMinY() && (
/* 679 */           targetNode5 == null || targetNode5.topCornerDistance > targetNode1.topCornerDistance)) {
/*     */           
/* 681 */           if (targetNode5 == null) {
/* 682 */             targetNode5 = new TargetNode();
/*     */           }
/* 684 */           targetNode5.copy(targetNode1);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 690 */         if (paramBounds1.getMaxY() > bounds.getMinY() && bounds.getMaxY() > paramBounds1.getMinY() && (
/* 691 */           targetNode6 == null || targetNode6.topCornerDistance > targetNode1.topCornerDistance)) {
/*     */           
/* 693 */           if (targetNode6 == null) {
/* 694 */             targetNode6 = new TargetNode();
/*     */           }
/* 696 */           targetNode6.copy(targetNode1);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 702 */         if (targetNode7 == null || targetNode7.topCornerDistance > targetNode1.topCornerDistance) {
/*     */           
/* 704 */           if (targetNode7 == null) {
/* 705 */             targetNode7 = new TargetNode();
/*     */           }
/* 707 */           targetNode7.copy(targetNode1);
/*     */         } 
/*     */         
/* 710 */         if (targetNode4 == null || targetNode4.averageDistance > targetNode1.averageDistance) {
/*     */           
/* 712 */           if (targetNode4 == null) {
/* 713 */             targetNode4 = new TargetNode();
/*     */           }
/* 715 */           targetNode4.copy(targetNode1);
/*     */         } 
/*     */         
/* 718 */         if (targetNode8 == null || targetNode8.shortestDistance > targetNode1.shortestDistance) {
/*     */           
/* 720 */           if (targetNode8 == null) {
/* 721 */             targetNode8 = new TargetNode();
/*     */           }
/* 723 */           targetNode8.copy(targetNode1);
/*     */         } 
/*     */       } 
/*     */     } 
/* 727 */     list.clear();
/*     */     
/* 729 */     if (targetNode5 != null) {
/* 730 */       targetNode5.originTopCornerDistance = point2D7.distance(((Double)function2.apply(targetNode5.bounds)).doubleValue(), targetNode5.bounds.getMinY());
/*     */     }
/*     */     
/* 733 */     if (targetNode6 != null) {
/* 734 */       targetNode6.originTopCornerDistance = point2D7.distance(((Double)function2.apply(targetNode6.bounds)).doubleValue(), targetNode6.bounds.getMinY());
/*     */     }
/*     */     
/* 737 */     if (targetNode4 != null) {
/* 738 */       targetNode4.originTopCornerDistance = point2D7.distance(((Double)function2.apply(targetNode4.bounds)).doubleValue(), targetNode4.bounds.getMinY());
/*     */     }
/*     */     
/* 741 */     if (targetNode6 == null && targetNode5 == null) {
/* 742 */       this.cacheStartTraversalNode = null;
/* 743 */       this.cacheStartTraversalDirection = null;
/* 744 */       this.reverseDirection = false;
/* 745 */       this.traversalNodeStack.clear();
/*     */     } 
/*     */     
/* 748 */     if (targetNode5 != null) {
/*     */ 
/*     */ 
/*     */       
/* 752 */       if (targetNode6 != null && targetNode5.node == targetNode6.node && ((targetNode4 != null && targetNode5.node == targetNode4.node) || (targetNode7 != null && targetNode5.node == targetNode7.node) || (targetNode8 != null && targetNode5.node == targetNode8.node)))
/*     */       {
/*     */ 
/*     */         
/* 756 */         return targetNode5.node;
/*     */       }
/*     */       
/* 759 */       if (targetNode4 != null && targetNode5.node == targetNode4.node) {
/* 760 */         return targetNode5.node;
/*     */       }
/*     */       
/* 763 */       if (targetNode6 != null) {
/* 764 */         if (targetNode6.bottomCornerDistance < targetNode5.bottomCornerDistance && targetNode6.originTopCornerDistance < targetNode5.originTopCornerDistance && targetNode6.bounds
/*     */           
/* 766 */           .getMinY() - point2D3.getY() < targetNode5.bounds.getMinY() - point2D3.getY())
/*     */         {
/* 768 */           return targetNode6.node; } 
/* 769 */         if (targetNode4 == null || targetNode5.averageDistance < targetNode4.averageDistance) {
/* 770 */           return targetNode5.node;
/*     */         }
/*     */       } 
/*     */     } else {
/* 774 */       if (targetNode6 == null && targetNode2 != null) {
/* 775 */         if (targetNode4 != null && targetNode7 != null && targetNode4.node == targetNode7.node && targetNode4.node == targetNode8.node)
/*     */         {
/* 777 */           return targetNode4.node;
/*     */         }
/* 779 */         return targetNode2.node;
/* 780 */       }  if (targetNode4 != null && targetNode7 != null && targetNode8 != null && targetNode4.biasShortestDistance == targetNode7.biasShortestDistance && targetNode4.biasShortestDistance == targetNode8.biasShortestDistance && targetNode4.biasShortestDistance < Double.MAX_VALUE)
/*     */       {
/*     */ 
/*     */         
/* 784 */         return targetNode4.node;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 791 */     if (targetNode4 != null && (targetNode5 == null || targetNode4.biasShortestDistance < targetNode5.biasShortestDistance)) {
/*     */ 
/*     */ 
/*     */       
/* 795 */       if (targetNode5 != null && ((Double)function2.apply(targetNode5.bounds)).doubleValue() >= ((Double)function2.apply(targetNode4.bounds)).doubleValue()) {
/* 796 */         return targetNode5.node;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 801 */       if (targetNode5 != null && targetNode6 != null && targetNode5.biasShortestDistance < Double.MAX_VALUE && targetNode5.node == targetNode6.node) {
/* 802 */         return targetNode5.node;
/*     */       }
/*     */       
/* 805 */       if (targetNode6 != null && targetNode5 != null && targetNode6.biasShortestDistance < Double.MAX_VALUE && targetNode6.biasShortestDistance < targetNode5.biasShortestDistance) {
/* 806 */         return targetNode6.node;
/*     */       }
/*     */       
/* 809 */       if (targetNode5 != null && targetNode5.biasShortestDistance < Double.MAX_VALUE && targetNode5.originTopCornerDistance < targetNode4.originTopCornerDistance) {
/* 810 */         return targetNode5.node;
/*     */       }
/* 812 */       return targetNode4.node;
/*     */     } 
/*     */ 
/*     */     
/* 816 */     if (targetNode5 != null && targetNode6 != null && targetNode5.bottomCornerDistance < targetNode6.bottomCornerDistance) {
/* 817 */       return targetNode5.node;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 823 */     if (targetNode6 != null && targetNode7 != null && targetNode6.biasShortestDistance < Double.MAX_VALUE && targetNode6.node == targetNode7.node) {
/* 824 */       return targetNode6.node;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 830 */     if (targetNode5 != null)
/* 831 */       return targetNode5.node; 
/* 832 */     if (targetNode3 != null)
/* 833 */       return targetNode3.node; 
/* 834 */     if (targetNode6 != null)
/* 835 */       return targetNode6.node; 
/* 836 */     if (targetNode4 != null)
/* 837 */       return targetNode4.node; 
/* 838 */     if (targetNode7 != null)
/* 839 */       return targetNode7.node; 
/* 840 */     if (targetNode8 != null) {
/* 841 */       return targetNode8.node;
/*     */     }
/* 843 */     return null;
/*     */   } protected Node getNearestNodeUpOrDown(Bounds paramBounds1, Bounds paramBounds2, TraversalContext paramTraversalContext, Direction paramDirection) { List<Node> list = paramTraversalContext.getAllTargetNodes(); Function<Bounds, Double> function1 = (paramDirection == Direction.DOWN) ? BOUNDS_BOTTOM_SIDE : BOUNDS_TOP_SIDE; Function<Bounds, Double> function2 = (paramDirection == Direction.DOWN) ? BOUNDS_TOP_SIDE : BOUNDS_BOTTOM_SIDE; BoundingBox boundingBox = new BoundingBox(paramBounds2.getMinX(), paramBounds1.getMinY(), paramBounds2.getWidth(), paramBounds1.getHeight()); Point2D point2D1 = new Point2D(paramBounds1.getMinX() + paramBounds1.getWidth() / 2.0D, ((Double)function1.apply(paramBounds1)).doubleValue()); Point2D point2D2 = new Point2D(paramBounds2.getMinX() + paramBounds2.getWidth() / 2.0D, ((Double)function1.apply(paramBounds1)).doubleValue()); Point2D point2D3 = new Point2D(paramBounds1.getMinX(), ((Double)function1.apply(paramBounds1)).doubleValue()); Point2D point2D4 = new Point2D(paramBounds2.getMinX(), ((Double)function1.apply(paramBounds1)).doubleValue()); Point2D point2D5 = new Point2D(paramBounds1.getMaxX(), ((Double)function1.apply(paramBounds1)).doubleValue()); Point2D point2D6 = new Point2D(paramBounds2.getMaxX(), ((Double)function1.apply(paramBounds1)).doubleValue()); Point2D point2D7 = new Point2D(paramBounds2.getMinX(), ((Double)function1.apply(paramBounds2)).doubleValue()); TargetNode targetNode1 = new TargetNode(); TargetNode targetNode2 = null; TargetNode targetNode3 = null; TargetNode targetNode4 = null; TargetNode targetNode5 = null; TargetNode targetNode6 = null; TargetNode targetNode7 = null; TargetNode targetNode8 = null; for (byte b = 0; b < list.size(); b++) { Node node = list.get(b); Bounds bounds = node.localToScene(node.getLayoutBounds()); if ((paramDirection == Direction.UP) ? (paramBounds1.getMinY() > bounds.getMaxY()) : (paramBounds1.getMaxY() < bounds.getMinY())) { targetNode1.node = node; targetNode1.bounds = bounds; double d1 = Math.max(0.0D, outDistance(paramDirection, boundingBox, bounds)); if (isOnAxis(paramDirection, boundingBox, bounds)) { targetNode1.biased2DMetric = d1 + centerSideDistance(paramDirection, boundingBox, bounds) / 100.0D; } else { double d = cornerSideDistance(paramDirection, boundingBox, bounds); targetNode1.biased2DMetric = 100000.0D + d1 * d1 + 9.0D * d * d; }  double d2 = Math.max(0.0D, outDistance(paramDirection, paramBounds1, bounds)); if (isOnAxis(paramDirection, paramBounds1, bounds)) { targetNode1.current2DMetric = d2 + centerSideDistance(paramDirection, paramBounds1, bounds) / 100.0D; } else { double d = cornerSideDistance(paramDirection, paramBounds1, bounds); targetNode1.current2DMetric = 100000.0D + d2 * d2 + 9.0D * d * d; }  targetNode1.leftCornerDistance = point2D3.distance(bounds.getMinX(), ((Double)function2.apply(bounds)).doubleValue()); targetNode1.rightCornerDistance = point2D5.distance(bounds.getMaxX(), ((Double)function2.apply(bounds)).doubleValue()); double d3 = point2D1.distance(bounds.getMinX() + bounds.getWidth() / 2.0D, ((Double)function2.apply(bounds)).doubleValue()); double d4 = point2D3.distance(bounds.getMinX() + bounds.getWidth() / 2.0D, ((Double)function2.apply(bounds)).doubleValue()); double d5 = point2D3.distance(bounds.getMaxX(), ((Double)function2.apply(bounds)).doubleValue()); double d6 = point2D5.distance(bounds.getMinX(), ((Double)function2.apply(bounds)).doubleValue()); double d7 = point2D5.distance(bounds.getMinX() + bounds.getWidth() / 2.0D, ((Double)function2.apply(bounds)).doubleValue()); double d8 = point2D5.distance(bounds.getMaxX(), ((Double)function2.apply(bounds)).doubleValue()); double d9 = point2D1.distance(bounds.getMinX(), ((Double)function2.apply(bounds)).doubleValue()); double d10 = point2D1.distance(bounds.getMinX() + bounds.getWidth() / 2.0D, ((Double)function2.apply(bounds)).doubleValue()); double d11 = point2D1.distance(bounds.getMaxX(), ((Double)function2.apply(bounds)).doubleValue()); double d12 = point2D4.distance(bounds.getMinX() + bounds.getWidth() / 2.0D, ((Double)function2.apply(bounds)).doubleValue()); double d13 = point2D4.distance(bounds.getMaxX(), ((Double)function2.apply(bounds)).doubleValue()); double d14 = point2D6.distance(bounds.getMinX() + bounds.getWidth() / 2.0D, ((Double)function2.apply(bounds)).doubleValue()); double d15 = point2D2.distance(bounds.getMaxX(), ((Double)function2.apply(bounds)).doubleValue()); targetNode1.averageDistance = (targetNode1.leftCornerDistance + d12 + d13 + d6 + targetNode1.rightCornerDistance + d14 + d3) / 7.0D; targetNode1.biasShortestDistance = findMin(new double[] { targetNode1.leftCornerDistance, d12, d13, d6, d14, targetNode1.rightCornerDistance, d9, d3, d15 }); targetNode1.shortestDistance = findMin(new double[] { targetNode1.leftCornerDistance, d4, d5, d6, d7, d8, d9, d10, d11 }); if (d1 >= 0.0D && (targetNode3 == null || targetNode1.biased2DMetric < targetNode3.biased2DMetric)) { if (targetNode3 == null) targetNode3 = new TargetNode();  targetNode3.copy(targetNode1); }  if (d2 >= 0.0D && (targetNode2 == null || targetNode1.current2DMetric < targetNode2.current2DMetric)) { if (targetNode2 == null) targetNode2 = new TargetNode();  targetNode2.copy(targetNode1); }  if (paramBounds2.getMaxX() > bounds.getMinX() && bounds.getMaxX() > paramBounds2.getMinX() && (targetNode5 == null || targetNode5.biasShortestDistance > targetNode1.biasShortestDistance)) { if (targetNode5 == null) targetNode5 = new TargetNode();  targetNode5.copy(targetNode1); }  if (paramBounds1.getMaxX() > bounds.getMinX() && bounds.getMaxX() > paramBounds1.getMinX() && (targetNode6 == null || targetNode6.biasShortestDistance > targetNode1.biasShortestDistance)) { if (targetNode6 == null) targetNode6 = new TargetNode();  targetNode6.copy(targetNode1); }  if ((targetNode7 == null || targetNode7.leftCornerDistance > targetNode1.leftCornerDistance) && ((paramBounds2.getMinX() >= paramBounds1.getMinX() && bounds.getMinX() >= paramBounds1.getMinX()) || (paramBounds2.getMinX() <= paramBounds1.getMinX() && bounds.getMinX() <= paramBounds1.getMinX()))) { if (targetNode7 == null) targetNode7 = new TargetNode();  targetNode7.copy(targetNode1); }  if ((targetNode4 == null || targetNode4.averageDistance > targetNode1.averageDistance) && ((paramBounds2.getMinX() >= paramBounds1.getMinX() && bounds.getMinX() >= paramBounds1.getMinX()) || (paramBounds2.getMinX() <= paramBounds1.getMinX() && bounds.getMinX() <= paramBounds1.getMinX()))) { if (targetNode4 == null) targetNode4 = new TargetNode();  targetNode4.copy(targetNode1); }  if (targetNode8 == null || targetNode8.shortestDistance > targetNode1.shortestDistance) { if (targetNode8 == null) targetNode8 = new TargetNode();  targetNode8.copy(targetNode1); }  }  }  list.clear(); if (targetNode5 != null) targetNode5.originLeftCornerDistance = point2D7.distance(targetNode5.bounds.getMinX(), ((Double)function2.apply(targetNode5.bounds)).doubleValue());  if (targetNode6 != null) targetNode6.originLeftCornerDistance = point2D7.distance(targetNode6.bounds.getMinX(), ((Double)function2.apply(targetNode6.bounds)).doubleValue());  if (targetNode4 != null) targetNode4.originLeftCornerDistance = point2D7.distance(targetNode4.bounds.getMinX(), ((Double)function2.apply(targetNode4.bounds)).doubleValue());  if (targetNode5 != null) { if (targetNode6 != null && targetNode5.node == targetNode6.node && ((targetNode4 != null && targetNode5.node == targetNode4.node) || (targetNode3 != null && targetNode5.node == targetNode3.node) || (targetNode7 != null && targetNode5.node == targetNode7.node) || (targetNode8 != null && targetNode5.node == targetNode8.node))) return targetNode5.node;  if (targetNode4 != null && targetNode5.node == targetNode4.node) return targetNode5.node;  if (targetNode6 != null) { if (targetNode6.leftCornerDistance < targetNode5.leftCornerDistance && targetNode6.originLeftCornerDistance < targetNode5.originLeftCornerDistance && targetNode6.bounds.getMinX() - point2D3.getX() < targetNode5.bounds.getMinX() - point2D3.getX()) return targetNode6.node;  if (targetNode4 == null || targetNode5.averageDistance < targetNode4.averageDistance) return targetNode5.node;  }  } else { if (targetNode6 == null && targetNode2 != null) { if (targetNode4 != null && targetNode7 != null && targetNode4.node == targetNode7.node && targetNode4.node == targetNode8.node) return targetNode4.node;  return targetNode2.node; }  if (targetNode4 != null && targetNode7 != null && targetNode8 != null && targetNode4.biasShortestDistance == targetNode7.biasShortestDistance && targetNode4.biasShortestDistance == targetNode8.biasShortestDistance && targetNode4.biasShortestDistance < Double.MAX_VALUE) return targetNode4.node;  }  if (targetNode4 != null && (targetNode5 == null || targetNode4.biasShortestDistance < targetNode5.biasShortestDistance)) { if (targetNode5 != null && ((Double)function2.apply(targetNode5.bounds)).doubleValue() >= ((Double)function2.apply(targetNode4.bounds)).doubleValue()) return targetNode5.node;  if (targetNode3 != null) { if (targetNode3.current2DMetric <= targetNode4.current2DMetric) return targetNode3.node;  if (((Double)function2.apply(targetNode3.bounds)).doubleValue() >= ((Double)function2.apply(targetNode4.bounds)).doubleValue()) return targetNode3.node;  }  return targetNode4.node; }  if (targetNode2 != null && targetNode6 != null && targetNode4 != null && targetNode7 != null && targetNode8 != null && targetNode2.node == targetNode6.node && targetNode2.node == targetNode4.node && targetNode2.node == targetNode7.node && targetNode2.node == targetNode8.node) return targetNode2.node;  if (targetNode5 != null && (targetNode6 == null || targetNode5.rightCornerDistance < targetNode6.rightCornerDistance)) return targetNode5.node;  if (targetNode5 != null) return targetNode5.node;  if (targetNode3 != null) return targetNode3.node;  if (targetNode6 != null) return targetNode6.node;  if (targetNode4 != null)
/*     */       return targetNode4.node;  if (targetNode7 != null)
/*     */       return targetNode7.node;  if (targetNode8 != null)
/* 847 */       return targetNode8.node;  return null; } static final class TargetNode { Node node = null;
/* 848 */     Bounds bounds = null;
/* 849 */     double biased2DMetric = Double.MAX_VALUE;
/* 850 */     double current2DMetric = Double.MAX_VALUE;
/*     */     
/* 852 */     double leftCornerDistance = Double.MAX_VALUE;
/* 853 */     double rightCornerDistance = Double.MAX_VALUE;
/* 854 */     double topCornerDistance = Double.MAX_VALUE;
/* 855 */     double bottomCornerDistance = Double.MAX_VALUE;
/*     */     
/* 857 */     double shortestDistance = Double.MAX_VALUE;
/* 858 */     double biasShortestDistance = Double.MAX_VALUE;
/* 859 */     double averageDistance = Double.MAX_VALUE;
/*     */     
/* 861 */     double originLeftCornerDistance = Double.MAX_VALUE;
/* 862 */     double originTopCornerDistance = Double.MAX_VALUE;
/*     */     
/*     */     void copy(TargetNode param1TargetNode) {
/* 865 */       this.node = param1TargetNode.node;
/* 866 */       this.bounds = param1TargetNode.bounds;
/* 867 */       this.biased2DMetric = param1TargetNode.biased2DMetric;
/* 868 */       this.current2DMetric = param1TargetNode.current2DMetric;
/*     */       
/* 870 */       this.leftCornerDistance = param1TargetNode.leftCornerDistance;
/* 871 */       this.rightCornerDistance = param1TargetNode.rightCornerDistance;
/*     */       
/* 873 */       this.shortestDistance = param1TargetNode.shortestDistance;
/* 874 */       this.biasShortestDistance = param1TargetNode.biasShortestDistance;
/* 875 */       this.averageDistance = param1TargetNode.averageDistance;
/*     */       
/* 877 */       this.topCornerDistance = param1TargetNode.topCornerDistance;
/* 878 */       this.bottomCornerDistance = param1TargetNode.bottomCornerDistance;
/* 879 */       this.originLeftCornerDistance = param1TargetNode.originLeftCornerDistance;
/* 880 */       this.originTopCornerDistance = param1TargetNode.originTopCornerDistance;
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   public static double findMin(double... paramVarArgs) {
/* 886 */     double d = Double.MAX_VALUE;
/*     */     
/* 888 */     for (byte b = 0; b < paramVarArgs.length; b++) {
/* 889 */       d = (d < paramVarArgs[b]) ? d : paramVarArgs[b];
/*     */     }
/* 891 */     return d;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\Hueristic2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */