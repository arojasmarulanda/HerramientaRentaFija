/*     */ package com.sun.javafx.scene.traversal;
/*     */ 
/*     */ import java.util.List;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WeightedClosestCorner
/*     */   implements Algorithm
/*     */ {
/*     */   private boolean isOnAxis(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d1;
/*     */     double d2;
/*     */     double d3;
/*     */     double d4;
/*  68 */     if (paramDirection == Direction.UP || paramDirection == Direction.DOWN) {
/*  69 */       d1 = paramBounds1.getMinX();
/*  70 */       d2 = paramBounds1.getMaxX();
/*  71 */       d3 = paramBounds2.getMinX();
/*  72 */       d4 = paramBounds2.getMaxX();
/*     */     } else {
/*     */       
/*  75 */       d1 = paramBounds1.getMinY();
/*  76 */       d2 = paramBounds1.getMaxY();
/*  77 */       d3 = paramBounds2.getMinY();
/*  78 */       d4 = paramBounds2.getMaxY();
/*     */     } 
/*     */     
/*  81 */     return (d3 <= d2 && d4 >= d1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double outDistance(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d;
/*  92 */     if (paramDirection == Direction.UP) {
/*  93 */       d = paramBounds1.getMinY() - paramBounds2.getMaxY();
/*     */     }
/*  95 */     else if (paramDirection == Direction.DOWN) {
/*  96 */       d = paramBounds2.getMinY() - paramBounds1.getMaxY();
/*     */     }
/*  98 */     else if (paramDirection == Direction.LEFT) {
/*  99 */       d = paramBounds1.getMinX() - paramBounds2.getMaxX();
/*     */     } else {
/*     */       
/* 102 */       d = paramBounds2.getMinX() - paramBounds1.getMaxX();
/*     */     } 
/*     */     
/* 105 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double centerSideDistance(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d1;
/*     */     double d2;
/* 117 */     if (paramDirection == Direction.UP || paramDirection == Direction.DOWN) {
/* 118 */       d1 = paramBounds1.getMinX() + paramBounds1.getWidth() / 2.0D;
/* 119 */       d2 = paramBounds2.getMinX() + paramBounds2.getWidth() / 2.0D;
/*     */     } else {
/*     */       
/* 122 */       d1 = paramBounds1.getMinY() + paramBounds1.getHeight() / 2.0D;
/* 123 */       d2 = paramBounds2.getMinY() + paramBounds2.getHeight() / 2.0D;
/*     */     } 
/*     */     
/* 126 */     return Math.abs(d2 - d1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double cornerSideDistance(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d;
/* 138 */     if (paramDirection == Direction.UP || paramDirection == Direction.DOWN) {
/*     */       
/* 140 */       if (paramBounds2.getMinX() > paramBounds1.getMaxX())
/*     */       {
/* 142 */         d = paramBounds2.getMinX() - paramBounds1.getMaxX();
/*     */       }
/*     */       else
/*     */       {
/* 146 */         d = paramBounds1.getMinX() - paramBounds2.getMaxX();
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 151 */     else if (paramBounds2.getMinY() > paramBounds1.getMaxY()) {
/*     */       
/* 153 */       d = paramBounds2.getMinY() - paramBounds1.getMaxY();
/*     */     }
/*     */     else {
/*     */       
/* 157 */       d = paramBounds1.getMinY() - paramBounds2.getMaxY();
/*     */     } 
/*     */     
/* 160 */     return d;
/*     */   }
/*     */   
/*     */   public Node select(Node paramNode, Direction paramDirection, TraversalContext paramTraversalContext) {
/* 164 */     Node node = null;
/* 165 */     List<Node> list = paramTraversalContext.getAllTargetNodes();
/*     */     
/* 167 */     int i = traverse(paramTraversalContext.getSceneLayoutBounds(paramNode), paramDirection, list, paramTraversalContext);
/* 168 */     if (i != -1) {
/* 169 */       node = list.get(i);
/*     */     }
/*     */     
/* 172 */     return node;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node selectFirst(TraversalContext paramTraversalContext) {
/* 177 */     List<Node> list = paramTraversalContext.getAllTargetNodes();
/* 178 */     Point2D point2D = new Point2D(0.0D, 0.0D);
/*     */     
/* 180 */     if (list.size() > 0) {
/*     */       
/* 182 */       Node node = list.get(0);
/* 183 */       double d = point2D.distance(paramTraversalContext.getSceneLayoutBounds(list.get(0)).getMinX(), paramTraversalContext
/* 184 */           .getSceneLayoutBounds(list.get(0)).getMinY());
/*     */ 
/*     */       
/* 187 */       for (byte b = 1; b < list.size(); b++) {
/* 188 */         double d1 = point2D.distance(paramTraversalContext.getSceneLayoutBounds(list.get(b)).getMinX(), paramTraversalContext
/* 189 */             .getSceneLayoutBounds(list.get(b)).getMinY());
/* 190 */         if (d > d1) {
/* 191 */           d = d1;
/* 192 */           node = list.get(b);
/*     */         } 
/*     */       } 
/* 195 */       return node;
/*     */     } 
/* 197 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node selectLast(TraversalContext paramTraversalContext) {
/* 202 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int traverse(Bounds paramBounds, Direction paramDirection, List<Node> paramList, TraversalContext paramTraversalContext) {
/*     */     int i;
/* 209 */     if (paramDirection == Direction.NEXT || paramDirection == Direction.NEXT_IN_LINE || paramDirection == Direction.PREVIOUS) {
/* 210 */       i = trav1D(paramBounds, paramDirection, paramList, paramTraversalContext);
/*     */     } else {
/* 212 */       i = trav2D(paramBounds, paramDirection, paramList, paramTraversalContext);
/*     */     } 
/*     */     
/* 215 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   private int trav2D(Bounds paramBounds, Direction paramDirection, List<Node> paramList, TraversalContext paramTraversalContext) {
/* 220 */     Bounds bounds = null;
/* 221 */     double d = 0.0D;
/* 222 */     byte b = -1;
/*     */     
/* 224 */     for (byte b1 = 0; b1 < paramList.size(); b1++) {
/* 225 */       double d2; Bounds bounds1 = paramTraversalContext.getSceneLayoutBounds(paramList.get(b1));
/* 226 */       double d1 = outDistance(paramDirection, paramBounds, bounds1);
/*     */ 
/*     */       
/* 229 */       if (isOnAxis(paramDirection, paramBounds, bounds1)) {
/* 230 */         d2 = d1 + centerSideDistance(paramDirection, paramBounds, bounds1) / 100.0D;
/*     */       } else {
/*     */         
/* 233 */         double d3 = cornerSideDistance(paramDirection, paramBounds, bounds1);
/* 234 */         d2 = 100000.0D + d1 * d1 + 9.0D * d3 * d3;
/*     */       } 
/*     */       
/* 237 */       if (d1 >= 0.0D)
/*     */       {
/*     */ 
/*     */         
/* 241 */         if (bounds == null || d2 < d) {
/* 242 */           bounds = bounds1;
/* 243 */           d = d2;
/* 244 */           b = b1;
/*     */         } 
/*     */       }
/*     */     } 
/* 248 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int compare1D(Bounds paramBounds1, Bounds paramBounds2) {
/* 257 */     byte b = 0;
/*     */ 
/*     */     
/* 260 */     double d1 = (paramBounds1.getMinY() + paramBounds1.getMaxY()) / 2.0D;
/* 261 */     double d2 = (paramBounds2.getMinY() + paramBounds2.getMaxY()) / 2.0D;
/* 262 */     double d3 = (paramBounds1.getMinX() + paramBounds1.getMaxX()) / 2.0D;
/* 263 */     double d4 = (paramBounds2.getMinX() + paramBounds2.getMaxX()) / 2.0D;
/* 264 */     double d5 = paramBounds1.hashCode();
/* 265 */     double d6 = paramBounds2.hashCode();
/*     */     
/* 267 */     if (d1 < d2) {
/* 268 */       b = -1;
/*     */     }
/* 270 */     else if (d1 > d2) {
/* 271 */       b = 1;
/*     */     }
/* 273 */     else if (d3 < d4) {
/* 274 */       b = -1;
/*     */     }
/* 276 */     else if (d3 > d4) {
/* 277 */       b = 1;
/*     */     }
/* 279 */     else if (d5 < d6) {
/* 280 */       b = -1;
/*     */     }
/* 282 */     else if (d5 > d6) {
/* 283 */       b = 1;
/*     */     } 
/*     */     
/* 286 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   private int compare1D(Bounds paramBounds1, Bounds paramBounds2, Direction paramDirection) {
/* 291 */     return (paramDirection != Direction.PREVIOUS) ? -compare1D(paramBounds1, paramBounds2) : compare1D(paramBounds1, paramBounds2);
/*     */   }
/*     */   
/*     */   private int trav1D(Bounds paramBounds, Direction paramDirection, List<Node> paramList, TraversalContext paramTraversalContext) {
/* 295 */     byte b1 = -1;
/* 296 */     byte b2 = -1;
/*     */     
/* 298 */     for (byte b = 0; b < paramList.size(); b++) {
/* 299 */       if (b2 == -1 || 
/* 300 */         compare1D(paramTraversalContext.getSceneLayoutBounds(paramList.get(b)), paramTraversalContext
/* 301 */           .getSceneLayoutBounds(paramList.get(b2)), paramDirection) < 0) {
/* 302 */         b2 = b;
/*     */       }
/*     */       
/* 305 */       if (compare1D(paramTraversalContext.getSceneLayoutBounds(paramList.get(b)), paramBounds, paramDirection) >= 0)
/*     */       {
/*     */ 
/*     */         
/* 309 */         if (b1 == -1 || 
/* 310 */           compare1D(paramTraversalContext.getSceneLayoutBounds(paramList.get(b)), paramTraversalContext.getSceneLayoutBounds(paramList.get(b1)), paramDirection) < 0) {
/* 311 */           b1 = b;
/*     */         }
/*     */       }
/*     */     } 
/* 315 */     return (b1 == -1) ? b2 : b1;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\WeightedClosestCorner.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */