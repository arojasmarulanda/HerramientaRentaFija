/*    */ package com.sun.javafx.scene.traversal;
/*    */ 
/*    */ import javafx.scene.Parent;
/*    */ import javafx.scene.Scene;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SceneTraversalEngine
/*    */   extends TopMostTraversalEngine
/*    */ {
/*    */   private final Scene scene;
/*    */   
/*    */   public SceneTraversalEngine(Scene paramScene) {
/* 39 */     this.scene = paramScene;
/*    */   }
/*    */   
/*    */   protected Parent getRoot() {
/* 43 */     return this.scene.getRoot();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\SceneTraversalEngine.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */