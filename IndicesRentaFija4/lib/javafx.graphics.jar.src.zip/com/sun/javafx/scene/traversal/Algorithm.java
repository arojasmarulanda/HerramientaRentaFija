package com.sun.javafx.scene.traversal;

import javafx.scene.Node;

public interface Algorithm {
  Node select(Node paramNode, Direction paramDirection, TraversalContext paramTraversalContext);
  
  Node selectFirst(TraversalContext paramTraversalContext);
  
  Node selectLast(TraversalContext paramTraversalContext);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\Algorithm.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */