/*    */ package com.sun.javafx.scene;
/*    */ 
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.PointLight;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PointLightHelper
/*    */   extends LightBaseHelper
/*    */ {
/* 42 */   private static final PointLightHelper theInstance = new PointLightHelper(); static {
/* 43 */     Utils.forceInit(PointLight.class);
/*    */   }
/*    */   private static PointLightAccessor pointLightAccessor;
/*    */   private static PointLightHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(PointLight paramPointLight) {
/* 51 */     setHelper(paramPointLight, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 56 */     return pointLightAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */   
/*    */   public static void setPointLightAccessor(PointLightAccessor paramPointLightAccessor) {
/* 60 */     if (pointLightAccessor != null) {
/* 61 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 64 */     pointLightAccessor = paramPointLightAccessor;
/*    */   }
/*    */   
/*    */   public static interface PointLightAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\scene\PointLightHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */