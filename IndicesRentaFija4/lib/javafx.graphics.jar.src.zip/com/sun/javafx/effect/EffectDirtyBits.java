/*    */ package com.sun.javafx.effect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EffectDirtyBits
/*    */ {
/* 33 */   EFFECT_DIRTY,
/*    */ 
/*    */ 
/*    */   
/* 37 */   BOUNDS_CHANGED;
/*    */   
/*    */   private int mask;
/*    */   
/*    */   EffectDirtyBits() {
/* 42 */     this.mask = 1 << ordinal();
/*    */   }
/*    */   
/*    */   public final int getMask() {
/* 46 */     return this.mask;
/*    */   }
/*    */   
/*    */   public static boolean isSet(int paramInt, EffectDirtyBits paramEffectDirtyBits) {
/* 50 */     return ((paramInt & paramEffectDirtyBits.getMask()) != 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\effect\EffectDirtyBits.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */