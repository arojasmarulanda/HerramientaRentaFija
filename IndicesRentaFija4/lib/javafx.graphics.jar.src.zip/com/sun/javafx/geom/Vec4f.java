/*    */ package com.sun.javafx.geom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Vec4f
/*    */ {
/*    */   public float x;
/*    */   public float y;
/*    */   public float z;
/*    */   public float w;
/*    */   
/*    */   public Vec4f() {}
/*    */   
/*    */   public Vec4f(Vec4f paramVec4f) {
/* 56 */     this.x = paramVec4f.x;
/* 57 */     this.y = paramVec4f.y;
/* 58 */     this.z = paramVec4f.z;
/* 59 */     this.w = paramVec4f.w;
/*    */   }
/*    */   
/*    */   public Vec4f(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 63 */     this.x = paramFloat1;
/* 64 */     this.y = paramFloat2;
/* 65 */     this.z = paramFloat3;
/* 66 */     this.w = paramFloat4;
/*    */   }
/*    */   
/*    */   public void set(Vec4f paramVec4f) {
/* 70 */     this.x = paramVec4f.x;
/* 71 */     this.y = paramVec4f.y;
/* 72 */     this.z = paramVec4f.z;
/* 73 */     this.w = paramVec4f.w;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 78 */     return "(" + this.x + ", " + this.y + ", " + this.z + ", " + this.w + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Vec4f.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */