/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Line2D
/*     */   extends Shape
/*     */ {
/*     */   public float x1;
/*     */   public float y1;
/*     */   public float x2;
/*     */   public float y2;
/*     */   
/*     */   public Line2D() {}
/*     */   
/*     */   public Line2D(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  75 */     setLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Line2D(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/*  85 */     setLine(paramPoint2D1, paramPoint2D2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLine(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  97 */     this.x1 = paramFloat1;
/*  98 */     this.y1 = paramFloat2;
/*  99 */     this.x2 = paramFloat3;
/* 100 */     this.y2 = paramFloat4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLine(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 110 */     setLine(paramPoint2D1.x, paramPoint2D1.y, paramPoint2D2.x, paramPoint2D2.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLine(Line2D paramLine2D) {
/* 119 */     setLine(paramLine2D.x1, paramLine2D.y1, paramLine2D.x2, paramLine2D.y2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds getBounds() {
/* 126 */     RectBounds rectBounds = new RectBounds();
/* 127 */     rectBounds.setBoundsAndSort(this.x1, this.y1, this.x2, this.y2);
/* 128 */     return rectBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/* 135 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Point2D paramPoint2D) {
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*     */     int j;
/* 155 */     if ((j = outcode(paramFloat1, paramFloat2, paramFloat3, paramFloat4, this.x2, this.y2)) == 0) {
/* 156 */       return true;
/*     */     }
/* 158 */     float f1 = this.x1;
/* 159 */     float f2 = this.y1; int i;
/* 160 */     while ((i = outcode(paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2)) != 0) {
/* 161 */       if ((i & j) != 0) {
/* 162 */         return false;
/*     */       }
/* 164 */       if ((i & 0x5) != 0) {
/* 165 */         f1 = paramFloat1;
/* 166 */         if ((i & 0x4) != 0) {
/* 167 */           f1 += paramFloat3;
/*     */         }
/* 169 */         f2 = this.y1 + (f1 - this.x1) * (this.y2 - this.y1) / (this.x2 - this.x1); continue;
/*     */       } 
/* 171 */       f2 = paramFloat2;
/* 172 */       if ((i & 0x8) != 0) {
/* 173 */         f2 += paramFloat4;
/*     */       }
/* 175 */       f1 = this.x1 + (f2 - this.y1) * (this.x2 - this.x1) / (this.y2 - this.y1);
/*     */     } 
/*     */     
/* 178 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int relativeCCW(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 226 */     paramFloat3 -= paramFloat1;
/* 227 */     paramFloat4 -= paramFloat2;
/* 228 */     paramFloat5 -= paramFloat1;
/* 229 */     paramFloat6 -= paramFloat2;
/* 230 */     float f = paramFloat5 * paramFloat4 - paramFloat6 * paramFloat3;
/* 231 */     if (f == 0.0F) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 238 */       f = paramFloat5 * paramFloat3 + paramFloat6 * paramFloat4;
/* 239 */       if (f > 0.0F) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 247 */         paramFloat5 -= paramFloat3;
/* 248 */         paramFloat6 -= paramFloat4;
/* 249 */         f = paramFloat5 * paramFloat3 + paramFloat6 * paramFloat4;
/* 250 */         if (f < 0.0F) {
/* 251 */           f = 0.0F;
/*     */         }
/*     */       } 
/*     */     } 
/* 255 */     return (f < 0.0F) ? -1 : ((f > 0.0F) ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int relativeCCW(float paramFloat1, float paramFloat2) {
/* 273 */     return relativeCCW(this.x1, this.y1, this.x2, this.y2, paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int relativeCCW(Point2D paramPoint2D) {
/* 289 */     return relativeCCW(this.x1, this.y1, this.x2, this.y2, paramPoint2D.x, paramPoint2D.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean linesIntersect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/* 322 */     return (relativeCCW(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6) * 
/* 323 */       relativeCCW(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat7, paramFloat8) <= 0 && 
/* 324 */       relativeCCW(paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat1, paramFloat2) * 
/* 325 */       relativeCCW(paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat3, paramFloat4) <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersectsLine(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 344 */     return linesIntersect(paramFloat1, paramFloat2, paramFloat3, paramFloat4, this.x1, this.y1, this.x2, this.y2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersectsLine(Line2D paramLine2D) {
/* 355 */     return linesIntersect(paramLine2D.x1, paramLine2D.y1, paramLine2D.x2, paramLine2D.y2, this.x1, this.y1, this.x2, this.y2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float ptSegDistSq(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*     */     float f2;
/* 387 */     paramFloat3 -= paramFloat1;
/* 388 */     paramFloat4 -= paramFloat2;
/*     */     
/* 390 */     paramFloat5 -= paramFloat1;
/* 391 */     paramFloat6 -= paramFloat2;
/* 392 */     float f1 = paramFloat5 * paramFloat3 + paramFloat6 * paramFloat4;
/*     */     
/* 394 */     if (f1 <= 0.0F) {
/*     */ 
/*     */ 
/*     */       
/* 398 */       f2 = 0.0F;
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 405 */       paramFloat5 = paramFloat3 - paramFloat5;
/* 406 */       paramFloat6 = paramFloat4 - paramFloat6;
/* 407 */       f1 = paramFloat5 * paramFloat3 + paramFloat6 * paramFloat4;
/* 408 */       if (f1 <= 0.0F) {
/*     */ 
/*     */ 
/*     */         
/* 412 */         f2 = 0.0F;
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 418 */         f2 = f1 * f1 / (paramFloat3 * paramFloat3 + paramFloat4 * paramFloat4);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 425 */     float f3 = paramFloat5 * paramFloat5 + paramFloat6 * paramFloat6 - f2;
/* 426 */     if (f3 < 0.0F) {
/* 427 */       f3 = 0.0F;
/*     */     }
/* 429 */     return f3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float ptSegDist(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 459 */     return (float)Math.sqrt(ptSegDistSq(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float ptSegDistSq(float paramFloat1, float paramFloat2) {
/* 478 */     return ptSegDistSq(this.x1, this.y1, this.x2, this.y2, paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float ptSegDistSq(Point2D paramPoint2D) {
/* 496 */     return ptSegDistSq(this.x1, this.y1, this.x2, this.y2, paramPoint2D.x, paramPoint2D.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double ptSegDist(float paramFloat1, float paramFloat2) {
/* 515 */     return ptSegDist(this.x1, this.y1, this.x2, this.y2, paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float ptSegDist(Point2D paramPoint2D) {
/* 533 */     return ptSegDist(this.x1, this.y1, this.x2, this.y2, paramPoint2D.x, paramPoint2D.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float ptLineDistSq(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 561 */     paramFloat3 -= paramFloat1;
/* 562 */     paramFloat4 -= paramFloat2;
/*     */     
/* 564 */     paramFloat5 -= paramFloat1;
/* 565 */     paramFloat6 -= paramFloat2;
/* 566 */     float f1 = paramFloat5 * paramFloat3 + paramFloat6 * paramFloat4;
/*     */ 
/*     */ 
/*     */     
/* 570 */     float f2 = f1 * f1 / (paramFloat3 * paramFloat3 + paramFloat4 * paramFloat4);
/*     */ 
/*     */     
/* 573 */     float f3 = paramFloat5 * paramFloat5 + paramFloat6 * paramFloat6 - f2;
/* 574 */     if (f3 < 0.0F) {
/* 575 */       f3 = 0.0F;
/*     */     }
/* 577 */     return f3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float ptLineDist(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 603 */     return (float)Math.sqrt(ptLineDistSq(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float ptLineDistSq(float paramFloat1, float paramFloat2) {
/* 622 */     return ptLineDistSq(this.x1, this.y1, this.x2, this.y2, paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float ptLineDistSq(Point2D paramPoint2D) {
/* 640 */     return ptLineDistSq(this.x1, this.y1, this.x2, this.y2, paramPoint2D.x, paramPoint2D.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float ptLineDist(float paramFloat1, float paramFloat2) {
/* 659 */     return ptLineDist(this.x1, this.y1, this.x2, this.y2, paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float ptLineDist(Point2D paramPoint2D) {
/* 674 */     return ptLineDist(this.x1, this.y1, this.x2, this.y2, paramPoint2D.x, paramPoint2D.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/* 690 */     return new LineIterator(this, paramBaseTransform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform, float paramFloat) {
/* 711 */     return new LineIterator(this, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   public Line2D copy() {
/* 716 */     return new Line2D(this.x1, this.y1, this.x2, this.y2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 721 */     int i = Float.floatToIntBits(this.x1);
/* 722 */     i += Float.floatToIntBits(this.y1) * 37;
/* 723 */     i += Float.floatToIntBits(this.x2) * 43;
/* 724 */     i += Float.floatToIntBits(this.y2) * 47;
/* 725 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 730 */     if (paramObject == this) {
/* 731 */       return true;
/*     */     }
/* 733 */     if (paramObject instanceof Line2D) {
/* 734 */       Line2D line2D = (Line2D)paramObject;
/* 735 */       return (this.x1 == line2D.x1 && this.y1 == line2D.y1 && this.x2 == line2D.x2 && this.y2 == line2D.y2);
/*     */     } 
/*     */     
/* 738 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Line2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */