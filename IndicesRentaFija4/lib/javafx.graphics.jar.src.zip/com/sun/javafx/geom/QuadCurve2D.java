/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuadCurve2D
/*     */   extends Shape
/*     */ {
/*     */   public float x1;
/*     */   public float y1;
/*     */   public float ctrlx;
/*     */   public float ctrly;
/*     */   public float x2;
/*     */   public float y2;
/*     */   private static final int BELOW = -2;
/*     */   private static final int LOWEDGE = -1;
/*     */   private static final int INSIDE = 0;
/*     */   private static final int HIGHEDGE = 1;
/*     */   private static final int ABOVE = 2;
/*     */   
/*     */   public QuadCurve2D() {}
/*     */   
/*     */   public QuadCurve2D(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  99 */     setCurve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 117 */     this.x1 = paramFloat1;
/* 118 */     this.y1 = paramFloat2;
/* 119 */     this.ctrlx = paramFloat3;
/* 120 */     this.ctrly = paramFloat4;
/* 121 */     this.x2 = paramFloat5;
/* 122 */     this.y2 = paramFloat6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds getBounds() {
/* 129 */     float f1 = Math.min(Math.min(this.x1, this.x2), this.ctrlx);
/* 130 */     float f2 = Math.min(Math.min(this.y1, this.y2), this.ctrly);
/* 131 */     float f3 = Math.max(Math.max(this.x1, this.x2), this.ctrlx);
/* 132 */     float f4 = Math.max(Math.max(this.y1, this.y2), this.ctrly);
/* 133 */     return new RectBounds(f1, f2, f3, f4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CubicCurve2D toCubic() {
/* 140 */     return new CubicCurve2D(this.x1, this.y1, (this.x1 + 2.0F * this.ctrlx) / 3.0F, (this.y1 + 2.0F * this.ctrly) / 3.0F, (2.0F * this.ctrlx + this.x2) / 3.0F, (2.0F * this.ctrly + this.y2) / 3.0F, this.x2, this.y2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurve(float[] paramArrayOffloat, int paramInt) {
/* 156 */     setCurve(paramArrayOffloat[paramInt + 0], paramArrayOffloat[paramInt + 1], paramArrayOffloat[paramInt + 2], paramArrayOffloat[paramInt + 3], paramArrayOffloat[paramInt + 4], paramArrayOffloat[paramInt + 5]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurve(Point2D paramPoint2D1, Point2D paramPoint2D2, Point2D paramPoint2D3) {
/* 170 */     setCurve(paramPoint2D1.x, paramPoint2D1.y, paramPoint2D2.x, paramPoint2D2.y, paramPoint2D3.x, paramPoint2D3.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurve(Point2D[] paramArrayOfPoint2D, int paramInt) {
/* 185 */     setCurve((paramArrayOfPoint2D[paramInt + 0]).x, (paramArrayOfPoint2D[paramInt + 0]).y, (paramArrayOfPoint2D[paramInt + 1]).x, (paramArrayOfPoint2D[paramInt + 1]).y, (paramArrayOfPoint2D[paramInt + 2]).x, (paramArrayOfPoint2D[paramInt + 2]).y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurve(QuadCurve2D paramQuadCurve2D) {
/* 197 */     setCurve(paramQuadCurve2D.x1, paramQuadCurve2D.y1, paramQuadCurve2D.ctrlx, paramQuadCurve2D.ctrly, paramQuadCurve2D.x2, paramQuadCurve2D.y2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getFlatnessSq(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 217 */     return Line2D.ptSegDistSq(paramFloat1, paramFloat2, paramFloat5, paramFloat6, paramFloat3, paramFloat4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getFlatness(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 237 */     return Line2D.ptSegDist(paramFloat1, paramFloat2, paramFloat5, paramFloat6, paramFloat3, paramFloat4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getFlatnessSq(float[] paramArrayOffloat, int paramInt) {
/* 252 */     return Line2D.ptSegDistSq(paramArrayOffloat[paramInt + 0], paramArrayOffloat[paramInt + 1], paramArrayOffloat[paramInt + 4], paramArrayOffloat[paramInt + 5], paramArrayOffloat[paramInt + 2], paramArrayOffloat[paramInt + 3]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float getFlatness(float[] paramArrayOffloat, int paramInt) {
/* 269 */     return Line2D.ptSegDist(paramArrayOffloat[paramInt + 0], paramArrayOffloat[paramInt + 1], paramArrayOffloat[paramInt + 4], paramArrayOffloat[paramInt + 5], paramArrayOffloat[paramInt + 2], paramArrayOffloat[paramInt + 3]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFlatnessSq() {
/* 282 */     return Line2D.ptSegDistSq(this.x1, this.y1, this.x2, this.y2, this.ctrlx, this.ctrly);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFlatness() {
/* 292 */     return Line2D.ptSegDist(this.x1, this.y1, this.x2, this.y2, this.ctrlx, this.ctrly);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subdivide(QuadCurve2D paramQuadCurve2D1, QuadCurve2D paramQuadCurve2D2) {
/* 308 */     subdivide(this, paramQuadCurve2D1, paramQuadCurve2D2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void subdivide(QuadCurve2D paramQuadCurve2D1, QuadCurve2D paramQuadCurve2D2, QuadCurve2D paramQuadCurve2D3) {
/* 328 */     float f1 = paramQuadCurve2D1.x1;
/* 329 */     float f2 = paramQuadCurve2D1.y1;
/* 330 */     float f3 = paramQuadCurve2D1.ctrlx;
/* 331 */     float f4 = paramQuadCurve2D1.ctrly;
/* 332 */     float f5 = paramQuadCurve2D1.x2;
/* 333 */     float f6 = paramQuadCurve2D1.y2;
/* 334 */     float f7 = (f1 + f3) / 2.0F;
/* 335 */     float f8 = (f2 + f4) / 2.0F;
/* 336 */     float f9 = (f5 + f3) / 2.0F;
/* 337 */     float f10 = (f6 + f4) / 2.0F;
/* 338 */     f3 = (f7 + f9) / 2.0F;
/* 339 */     f4 = (f8 + f10) / 2.0F;
/* 340 */     if (paramQuadCurve2D2 != null) {
/* 341 */       paramQuadCurve2D2.setCurve(f1, f2, f7, f8, f3, f4);
/*     */     }
/* 343 */     if (paramQuadCurve2D3 != null) {
/* 344 */       paramQuadCurve2D3.setCurve(f3, f4, f9, f10, f5, f6);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void subdivide(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, float[] paramArrayOffloat3, int paramInt3) {
/* 379 */     float f1 = paramArrayOffloat1[paramInt1 + 0];
/* 380 */     float f2 = paramArrayOffloat1[paramInt1 + 1];
/* 381 */     float f3 = paramArrayOffloat1[paramInt1 + 2];
/* 382 */     float f4 = paramArrayOffloat1[paramInt1 + 3];
/* 383 */     float f5 = paramArrayOffloat1[paramInt1 + 4];
/* 384 */     float f6 = paramArrayOffloat1[paramInt1 + 5];
/* 385 */     if (paramArrayOffloat2 != null) {
/* 386 */       paramArrayOffloat2[paramInt2 + 0] = f1;
/* 387 */       paramArrayOffloat2[paramInt2 + 1] = f2;
/*     */     } 
/* 389 */     if (paramArrayOffloat3 != null) {
/* 390 */       paramArrayOffloat3[paramInt3 + 4] = f5;
/* 391 */       paramArrayOffloat3[paramInt3 + 5] = f6;
/*     */     } 
/* 393 */     f1 = (f1 + f3) / 2.0F;
/* 394 */     f2 = (f2 + f4) / 2.0F;
/* 395 */     f5 = (f5 + f3) / 2.0F;
/* 396 */     f6 = (f6 + f4) / 2.0F;
/* 397 */     f3 = (f1 + f5) / 2.0F;
/* 398 */     f4 = (f2 + f6) / 2.0F;
/* 399 */     if (paramArrayOffloat2 != null) {
/* 400 */       paramArrayOffloat2[paramInt2 + 2] = f1;
/* 401 */       paramArrayOffloat2[paramInt2 + 3] = f2;
/* 402 */       paramArrayOffloat2[paramInt2 + 4] = f3;
/* 403 */       paramArrayOffloat2[paramInt2 + 5] = f4;
/*     */     } 
/* 405 */     if (paramArrayOffloat3 != null) {
/* 406 */       paramArrayOffloat3[paramInt3 + 0] = f3;
/* 407 */       paramArrayOffloat3[paramInt3 + 1] = f4;
/* 408 */       paramArrayOffloat3[paramInt3 + 2] = f5;
/* 409 */       paramArrayOffloat3[paramInt3 + 3] = f6;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int solveQuadratic(float[] paramArrayOffloat) {
/* 430 */     return solveQuadratic(paramArrayOffloat, paramArrayOffloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int solveQuadratic(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/* 453 */     float f1 = paramArrayOffloat1[2];
/* 454 */     float f2 = paramArrayOffloat1[1];
/* 455 */     float f3 = paramArrayOffloat1[0];
/* 456 */     byte b = 0;
/* 457 */     if (f1 == 0.0F) {
/*     */       
/* 459 */       if (f2 == 0.0F)
/*     */       {
/* 461 */         return -1;
/*     */       }
/* 463 */       paramArrayOffloat2[b++] = -f3 / f2;
/*     */     } else {
/*     */       
/* 466 */       float f4 = f2 * f2 - 4.0F * f1 * f3;
/* 467 */       if (f4 < 0.0F)
/*     */       {
/* 469 */         return 0;
/*     */       }
/* 471 */       f4 = (float)Math.sqrt(f4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 477 */       if (f2 < 0.0F) {
/* 478 */         f4 = -f4;
/*     */       }
/* 480 */       float f5 = (f2 + f4) / -2.0F;
/*     */       
/* 482 */       paramArrayOffloat2[b++] = f5 / f1;
/* 483 */       if (f5 != 0.0F) {
/* 484 */         paramArrayOffloat2[b++] = f3 / f5;
/*     */       }
/*     */     } 
/* 487 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/* 494 */     float f1 = this.x1;
/* 495 */     float f2 = this.y1;
/* 496 */     float f3 = this.ctrlx;
/* 497 */     float f4 = this.ctrly;
/* 498 */     float f5 = this.x2;
/* 499 */     float f6 = this.y2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 567 */     float f7 = f1 - 2.0F * f3 + f5;
/* 568 */     float f8 = f2 - 2.0F * f4 + f6;
/* 569 */     float f9 = paramFloat1 - f1;
/* 570 */     float f10 = paramFloat2 - f2;
/* 571 */     float f11 = f5 - f1;
/* 572 */     float f12 = f6 - f2;
/*     */     
/* 574 */     float f13 = (f9 * f8 - f10 * f7) / (f11 * f8 - f12 * f7);
/* 575 */     if (f13 < 0.0F || f13 > 1.0F || f13 != f13) {
/* 576 */       return false;
/*     */     }
/*     */     
/* 579 */     float f14 = f7 * f13 * f13 + 2.0F * (f3 - f1) * f13 + f1;
/* 580 */     float f15 = f8 * f13 * f13 + 2.0F * (f4 - f2) * f13 + f2;
/* 581 */     float f16 = f11 * f13 + f1;
/* 582 */     float f17 = f12 * f13 + f2;
/*     */     
/* 584 */     return ((paramFloat1 >= f14 && paramFloat1 < f16) || (paramFloat1 >= f16 && paramFloat1 < f14) || (paramFloat2 >= f15 && paramFloat2 < f17) || (paramFloat2 >= f17 && paramFloat2 < f15));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Point2D paramPoint2D) {
/* 594 */     return contains(paramPoint2D.x, paramPoint2D.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void fillEqn(float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 612 */     paramArrayOffloat[0] = paramFloat2 - paramFloat1;
/* 613 */     paramArrayOffloat[1] = paramFloat3 + paramFloat3 - paramFloat2 - paramFloat2;
/* 614 */     paramArrayOffloat[2] = paramFloat2 - paramFloat3 - paramFloat3 + paramFloat4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int evalQuadratic(float[] paramArrayOffloat1, int paramInt, boolean paramBoolean1, boolean paramBoolean2, float[] paramArrayOffloat2, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 631 */     byte b1 = 0;
/* 632 */     for (byte b2 = 0; b2 < paramInt; b2++) {
/* 633 */       float f = paramArrayOffloat1[b2];
/* 634 */       if ((paramBoolean1 ? (f >= 0.0F) : (f > 0.0F)) && (paramBoolean2 ? (f <= 1.0F) : (f < 1.0F)) && (paramArrayOffloat2 == null || paramArrayOffloat2[1] + 2.0F * paramArrayOffloat2[2] * f != 0.0F)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 639 */         float f1 = 1.0F - f;
/* 640 */         paramArrayOffloat1[b1++] = paramFloat1 * f1 * f1 + 2.0F * paramFloat2 * f * f1 + paramFloat3 * f * f;
/*     */       } 
/*     */     } 
/* 643 */     return b1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getTag(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 659 */     if (paramFloat1 <= paramFloat2) {
/* 660 */       return (paramFloat1 < paramFloat2) ? -2 : -1;
/*     */     }
/* 662 */     if (paramFloat1 >= paramFloat3) {
/* 663 */       return (paramFloat1 > paramFloat3) ? 2 : 1;
/*     */     }
/* 665 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean inwards(int paramInt1, int paramInt2, int paramInt3) {
/* 676 */     switch (paramInt1)
/*     */     
/*     */     { 
/*     */       default:
/* 680 */         return false;
/*     */       case -1:
/* 682 */         return (paramInt2 >= 0 || paramInt3 >= 0);
/*     */       case 0:
/* 684 */         return true;
/*     */       case 1:
/* 686 */         break; }  return (paramInt2 <= 0 || paramInt3 <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 695 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/* 696 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 703 */     float f1 = this.x1;
/* 704 */     float f2 = this.y1;
/* 705 */     int i = getTag(f1, paramFloat1, paramFloat1 + paramFloat3);
/* 706 */     int j = getTag(f2, paramFloat2, paramFloat2 + paramFloat4);
/* 707 */     if (i == 0 && j == 0) {
/* 708 */       return true;
/*     */     }
/* 710 */     float f3 = this.x2;
/* 711 */     float f4 = this.y2;
/* 712 */     int k = getTag(f3, paramFloat1, paramFloat1 + paramFloat3);
/* 713 */     int m = getTag(f4, paramFloat2, paramFloat2 + paramFloat4);
/* 714 */     if (k == 0 && m == 0) {
/* 715 */       return true;
/*     */     }
/* 717 */     float f5 = this.ctrlx;
/* 718 */     float f6 = this.ctrly;
/* 719 */     int n = getTag(f5, paramFloat1, paramFloat1 + paramFloat3);
/* 720 */     int i1 = getTag(f6, paramFloat2, paramFloat2 + paramFloat4);
/*     */ 
/*     */ 
/*     */     
/* 724 */     if (i < 0 && k < 0 && n < 0) {
/* 725 */       return false;
/*     */     }
/* 727 */     if (j < 0 && m < 0 && i1 < 0) {
/* 728 */       return false;
/*     */     }
/* 730 */     if (i > 0 && k > 0 && n > 0) {
/* 731 */       return false;
/*     */     }
/* 733 */     if (j > 0 && m > 0 && i1 > 0) {
/* 734 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 742 */     if (inwards(i, k, n) && 
/* 743 */       inwards(j, m, i1))
/*     */     {
/*     */       
/* 746 */       return true;
/*     */     }
/* 748 */     if (inwards(k, i, n) && 
/* 749 */       inwards(m, j, i1))
/*     */     {
/*     */       
/* 752 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 756 */     boolean bool1 = (i * k <= 0) ? true : false;
/* 757 */     boolean bool2 = (j * m <= 0) ? true : false;
/* 758 */     if (i == 0 && k == 0 && bool2) {
/* 759 */       return true;
/*     */     }
/* 761 */     if (j == 0 && m == 0 && bool1) {
/* 762 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 771 */     float[] arrayOfFloat1 = new float[3];
/* 772 */     float[] arrayOfFloat2 = new float[3];
/* 773 */     if (!bool2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 779 */       fillEqn(arrayOfFloat1, (j < 0) ? paramFloat2 : (paramFloat2 + paramFloat4), f2, f6, f4);
/* 780 */       return (solveQuadratic(arrayOfFloat1, arrayOfFloat2) == 2 && 
/* 781 */         evalQuadratic(arrayOfFloat2, 2, true, true, null, f1, f5, f3) == 2 && 
/*     */         
/* 783 */         getTag(arrayOfFloat2[0], paramFloat1, paramFloat1 + paramFloat3) * getTag(arrayOfFloat2[1], paramFloat1, paramFloat1 + paramFloat3) <= 0);
/*     */     } 
/*     */ 
/*     */     
/* 787 */     if (!bool1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 793 */       fillEqn(arrayOfFloat1, (i < 0) ? paramFloat1 : (paramFloat1 + paramFloat3), f1, f5, f3);
/* 794 */       return (solveQuadratic(arrayOfFloat1, arrayOfFloat2) == 2 && 
/* 795 */         evalQuadratic(arrayOfFloat2, 2, true, true, null, f2, f6, f4) == 2 && 
/*     */         
/* 797 */         getTag(arrayOfFloat2[0], paramFloat2, paramFloat2 + paramFloat4) * getTag(arrayOfFloat2[1], paramFloat2, paramFloat2 + paramFloat4) <= 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 803 */     float f7 = f3 - f1;
/* 804 */     float f8 = f4 - f2;
/* 805 */     float f9 = f4 * f1 - f3 * f2;
/*     */     
/* 807 */     if (j == 0) {
/* 808 */       i2 = i;
/*     */     } else {
/* 810 */       i2 = getTag((f9 + f7 * ((j < 0) ? paramFloat2 : (paramFloat2 + paramFloat4))) / f8, paramFloat1, paramFloat1 + paramFloat3);
/*     */     } 
/* 812 */     if (m == 0) {
/* 813 */       i3 = k;
/*     */     } else {
/* 815 */       i3 = getTag((f9 + f7 * ((m < 0) ? paramFloat2 : (paramFloat2 + paramFloat4))) / f8, paramFloat1, paramFloat1 + paramFloat3);
/*     */     } 
/*     */ 
/*     */     
/* 819 */     if (i2 * i3 <= 0) {
/* 820 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 849 */     int i2 = (i2 * i <= 0) ? j : m;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 856 */     fillEqn(arrayOfFloat1, (i3 < 0) ? paramFloat1 : (paramFloat1 + paramFloat3), f1, f5, f3);
/* 857 */     int i4 = solveQuadratic(arrayOfFloat1, arrayOfFloat2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 862 */     evalQuadratic(arrayOfFloat2, i4, true, true, null, f2, f6, f4);
/*     */ 
/*     */ 
/*     */     
/* 866 */     int i3 = getTag(arrayOfFloat2[0], paramFloat2, paramFloat2 + paramFloat4);
/*     */ 
/*     */ 
/*     */     
/* 870 */     return (i2 * i3 <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 877 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/* 878 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 882 */     return (contains(paramFloat1, paramFloat2) && 
/* 883 */       contains(paramFloat1 + paramFloat3, paramFloat2) && 
/* 884 */       contains(paramFloat1 + paramFloat3, paramFloat2 + paramFloat4) && 
/* 885 */       contains(paramFloat1, paramFloat2 + paramFloat4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/* 902 */     return new QuadIterator(this, paramBaseTransform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform, float paramFloat) {
/* 923 */     return new FlatteningPathIterator(getPathIterator(paramBaseTransform), paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public QuadCurve2D copy() {
/* 928 */     return new QuadCurve2D(this.x1, this.y1, this.ctrlx, this.ctrly, this.x2, this.y2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 933 */     int i = Float.floatToIntBits(this.x1);
/* 934 */     i += Float.floatToIntBits(this.y1) * 37;
/* 935 */     i += Float.floatToIntBits(this.x2) * 43;
/* 936 */     i += Float.floatToIntBits(this.y2) * 47;
/* 937 */     i += Float.floatToIntBits(this.ctrlx) * 53;
/* 938 */     i += Float.floatToIntBits(this.ctrly) * 59;
/* 939 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 944 */     if (paramObject == this) {
/* 945 */       return true;
/*     */     }
/* 947 */     if (paramObject instanceof QuadCurve2D) {
/* 948 */       QuadCurve2D quadCurve2D = (QuadCurve2D)paramObject;
/* 949 */       return (this.x1 == quadCurve2D.x1 && this.y1 == quadCurve2D.y1 && this.x2 == quadCurve2D.x2 && this.y2 == quadCurve2D.y2 && this.ctrlx == quadCurve2D.ctrlx && this.ctrly == quadCurve2D.ctrly);
/*     */     } 
/*     */ 
/*     */     
/* 953 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\QuadCurve2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */