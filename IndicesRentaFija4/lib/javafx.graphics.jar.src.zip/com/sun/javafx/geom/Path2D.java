/*      */ package com.sun.javafx.geom;
/*      */ 
/*      */ import com.sun.javafx.geom.transform.BaseTransform;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Path2D
/*      */   extends Shape
/*      */   implements PathConsumer2D
/*      */ {
/*      */   public static final int WIND_EVEN_ODD = 0;
/*      */   public static final int WIND_NON_ZERO = 1;
/*      */   private static final byte SEG_MOVETO = 0;
/*      */   private static final byte SEG_LINETO = 1;
/*      */   private static final byte SEG_QUADTO = 2;
/*      */   private static final byte SEG_CUBICTO = 3;
/*      */   private static final byte SEG_CLOSE = 4;
/*      */   byte[] pointTypes;
/*      */   int numTypes;
/*      */   int numCoords;
/*      */   int windingRule;
/*      */   static final int INIT_SIZE = 20;
/*      */   static final int EXPAND_MAX = 500;
/*      */   static final int EXPAND_MAX_COORDS = 1000;
/*      */   float[] floatCoords;
/*      */   float moveX;
/*   66 */   static final int[] curvecoords = new int[] { 2, 2, 4, 6, 0 }; float moveY; float prevX; float prevY; float currX;
/*      */   float currY;
/*      */   
/*   69 */   public enum CornerPrefix { CORNER_ONLY,
/*   70 */     MOVE_THEN_CORNER,
/*   71 */     LINE_THEN_CORNER; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Path2D() {
/*  117 */     this(1, 20);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Path2D(int paramInt) {
/*  130 */     this(paramInt, 20);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Path2D(int paramInt1, int paramInt2) {
/*  148 */     setWindingRule(paramInt1);
/*  149 */     this.pointTypes = new byte[paramInt2];
/*  150 */     this.floatCoords = new float[paramInt2 * 2];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Path2D(Shape paramShape) {
/*  162 */     this(paramShape, (BaseTransform)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Path2D(Shape paramShape, BaseTransform paramBaseTransform) {
/*  177 */     if (paramShape instanceof Path2D) {
/*  178 */       Path2D path2D = (Path2D)paramShape;
/*  179 */       setWindingRule(path2D.windingRule);
/*  180 */       this.numTypes = path2D.numTypes;
/*  181 */       this.pointTypes = Arrays.copyOf(path2D.pointTypes, this.numTypes);
/*  182 */       this.numCoords = path2D.numCoords;
/*  183 */       if (paramBaseTransform == null || paramBaseTransform.isIdentity()) {
/*  184 */         this.floatCoords = Arrays.copyOf(path2D.floatCoords, this.numCoords);
/*  185 */         this.moveX = path2D.moveX;
/*  186 */         this.moveY = path2D.moveY;
/*  187 */         this.prevX = path2D.prevX;
/*  188 */         this.prevY = path2D.prevY;
/*  189 */         this.currX = path2D.currX;
/*  190 */         this.currY = path2D.currY;
/*      */       } else {
/*  192 */         this.floatCoords = new float[this.numCoords + 6];
/*  193 */         paramBaseTransform.transform(path2D.floatCoords, 0, this.floatCoords, 0, this.numCoords / 2);
/*  194 */         this.floatCoords[this.numCoords + 0] = this.moveX;
/*  195 */         this.floatCoords[this.numCoords + 1] = this.moveY;
/*  196 */         this.floatCoords[this.numCoords + 2] = this.prevX;
/*  197 */         this.floatCoords[this.numCoords + 3] = this.prevY;
/*  198 */         this.floatCoords[this.numCoords + 4] = this.currX;
/*  199 */         this.floatCoords[this.numCoords + 5] = this.currY;
/*  200 */         paramBaseTransform.transform(this.floatCoords, this.numCoords, this.floatCoords, this.numCoords, 3);
/*  201 */         this.moveX = this.floatCoords[this.numCoords + 0];
/*  202 */         this.moveY = this.floatCoords[this.numCoords + 1];
/*  203 */         this.prevX = this.floatCoords[this.numCoords + 2];
/*  204 */         this.prevY = this.floatCoords[this.numCoords + 3];
/*  205 */         this.currX = this.floatCoords[this.numCoords + 4];
/*  206 */         this.currY = this.floatCoords[this.numCoords + 5];
/*      */       } 
/*      */     } else {
/*  209 */       PathIterator pathIterator = paramShape.getPathIterator(paramBaseTransform);
/*  210 */       setWindingRule(pathIterator.getWindingRule());
/*  211 */       this.pointTypes = new byte[20];
/*  212 */       this.floatCoords = new float[40];
/*  213 */       append(pathIterator, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Path2D(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, float[] paramArrayOffloat, int paramInt3) {
/*  231 */     this.windingRule = paramInt1;
/*  232 */     this.pointTypes = paramArrayOfbyte;
/*  233 */     this.numTypes = paramInt2;
/*  234 */     this.floatCoords = paramArrayOffloat;
/*  235 */     this.numCoords = paramInt3;
/*      */   }
/*      */   
/*      */   Point2D getPoint(int paramInt) {
/*  239 */     return new Point2D(this.floatCoords[paramInt], this.floatCoords[paramInt + 1]);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean close(int paramInt, float paramFloat1, float paramFloat2) {
/*  244 */     return (Math.abs(paramInt - paramFloat1) <= paramFloat2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkAndGetIntRect(Rectangle paramRectangle, float paramFloat) {
/*  270 */     if (this.numTypes == 5) {
/*      */       
/*  272 */       if (this.pointTypes[4] != 1 && this.pointTypes[4] != 4) {
/*  273 */         return false;
/*      */       }
/*  275 */     } else if (this.numTypes == 6) {
/*      */ 
/*      */       
/*  278 */       if (this.pointTypes[4] != 1) return false; 
/*  279 */       if (this.pointTypes[5] != 4) return false; 
/*  280 */     } else if (this.numTypes != 4) {
/*  281 */       return false;
/*      */     } 
/*  283 */     if (this.pointTypes[0] != 0) return false; 
/*  284 */     if (this.pointTypes[1] != 1) return false; 
/*  285 */     if (this.pointTypes[2] != 1) return false; 
/*  286 */     if (this.pointTypes[3] != 1) return false;
/*      */     
/*  288 */     int i = (int)(this.floatCoords[0] + 0.5F);
/*  289 */     int j = (int)(this.floatCoords[1] + 0.5F);
/*  290 */     if (!close(i, this.floatCoords[0], paramFloat)) return false; 
/*  291 */     if (!close(j, this.floatCoords[1], paramFloat)) return false;
/*      */     
/*  293 */     int k = (int)(this.floatCoords[2] + 0.5F);
/*  294 */     int m = (int)(this.floatCoords[3] + 0.5F);
/*  295 */     if (!close(k, this.floatCoords[2], paramFloat)) return false; 
/*  296 */     if (!close(m, this.floatCoords[3], paramFloat)) return false;
/*      */     
/*  298 */     int n = (int)(this.floatCoords[4] + 0.5F);
/*  299 */     int i1 = (int)(this.floatCoords[5] + 0.5F);
/*  300 */     if (!close(n, this.floatCoords[4], paramFloat)) return false; 
/*  301 */     if (!close(i1, this.floatCoords[5], paramFloat)) return false;
/*      */     
/*  303 */     int i2 = (int)(this.floatCoords[6] + 0.5F);
/*  304 */     int i3 = (int)(this.floatCoords[7] + 0.5F);
/*  305 */     if (!close(i2, this.floatCoords[6], paramFloat)) return false; 
/*  306 */     if (!close(i3, this.floatCoords[7], paramFloat)) return false;
/*      */     
/*  308 */     if (this.numTypes > 4 && this.pointTypes[4] == 1) {
/*  309 */       if (!close(i, this.floatCoords[8], paramFloat)) return false; 
/*  310 */       if (!close(j, this.floatCoords[9], paramFloat)) return false;
/*      */     
/*      */     } 
/*  313 */     if ((i == k && n == i2 && j == i3 && m == i1) || (j == m && i1 == i3 && i == i2 && k == n)) {
/*      */       int i4;
/*      */       
/*      */       int i5;
/*      */       
/*      */       int i6;
/*      */       
/*      */       int i7;
/*  321 */       if (n < i) { i4 = n; i6 = i - n; }
/*  322 */       else { i4 = i; i6 = n - i; }
/*  323 */        if (i1 < j) { i5 = i1; i7 = j - i1; }
/*  324 */       else { i5 = j; i7 = i1 - j; }
/*      */       
/*  326 */       if (i6 < 0) return false; 
/*  327 */       if (i7 < 0) return false;
/*      */       
/*  329 */       if (paramRectangle != null) {
/*  330 */         paramRectangle.setBounds(i4, i5, i6, i7);
/*      */       }
/*  332 */       return true;
/*      */     } 
/*  334 */     return false;
/*      */   }
/*      */   
/*      */   void needRoom(boolean paramBoolean, int paramInt) {
/*  338 */     if (paramBoolean && this.numTypes == 0) {
/*  339 */       throw new IllegalPathStateException("missing initial moveto in path definition");
/*      */     }
/*      */     
/*  342 */     int i = this.pointTypes.length;
/*  343 */     if (i == 0) {
/*  344 */       this.pointTypes = new byte[2];
/*  345 */     } else if (this.numTypes >= i) {
/*  346 */       this.pointTypes = expandPointTypes(this.pointTypes, 1);
/*      */     } 
/*  348 */     i = this.floatCoords.length;
/*  349 */     if (this.numCoords > this.floatCoords.length - paramInt) {
/*  350 */       this.floatCoords = expandCoords(this.floatCoords, paramInt);
/*      */     }
/*      */   }
/*      */   
/*      */   static byte[] expandPointTypes(byte[] paramArrayOfbyte, int paramInt) {
/*  355 */     int i = paramArrayOfbyte.length;
/*  356 */     int j = i + paramInt;
/*  357 */     if (j < i)
/*      */     {
/*      */       
/*  360 */       throw new ArrayIndexOutOfBoundsException("pointTypes exceeds maximum capacity !");
/*      */     }
/*      */ 
/*      */     
/*  364 */     int k = i;
/*  365 */     if (k > 500) {
/*  366 */       k = Math.max(500, i >> 3);
/*  367 */     } else if (k < 20) {
/*  368 */       k = 20;
/*      */     } 
/*  370 */     assert k > 0;
/*      */     
/*  372 */     int m = i + k;
/*  373 */     if (m < j)
/*      */     {
/*  375 */       m = Integer.MAX_VALUE;
/*      */     }
/*      */ 
/*      */     
/*      */     while (true) {
/*      */       try {
/*  381 */         return Arrays.copyOf(paramArrayOfbyte, m);
/*  382 */       } catch (OutOfMemoryError outOfMemoryError) {
/*  383 */         if (m == j) {
/*  384 */           throw outOfMemoryError;
/*      */         }
/*      */         
/*  387 */         m = j + (m - j) / 2;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   static float[] expandCoords(float[] paramArrayOffloat, int paramInt) {
/*  392 */     int i = paramArrayOffloat.length;
/*  393 */     int j = i + paramInt;
/*  394 */     if (j < i)
/*      */     {
/*      */       
/*  397 */       throw new ArrayIndexOutOfBoundsException("coords exceeds maximum capacity !");
/*      */     }
/*      */ 
/*      */     
/*  401 */     int k = i;
/*  402 */     if (k > 1000) {
/*  403 */       k = Math.max(1000, i >> 3);
/*  404 */     } else if (k < 20) {
/*  405 */       k = 20;
/*      */     } 
/*  407 */     assert k > paramInt;
/*      */     
/*  409 */     int m = i + k;
/*  410 */     if (m < j)
/*      */     {
/*  412 */       m = Integer.MAX_VALUE;
/*      */     }
/*      */     
/*      */     while (true) {
/*      */       try {
/*  417 */         return Arrays.copyOf(paramArrayOffloat, m);
/*  418 */       } catch (OutOfMemoryError outOfMemoryError) {
/*  419 */         if (m == j) {
/*  420 */           throw outOfMemoryError;
/*      */         }
/*      */         
/*  423 */         m = j + (m - j) / 2;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void moveTo(float paramFloat1, float paramFloat2) {
/*  435 */     if (this.numTypes > 0 && this.pointTypes[this.numTypes - 1] == 0) {
/*  436 */       this.floatCoords[this.numCoords - 2] = this.moveX = this.prevX = this.currX = paramFloat1;
/*  437 */       this.floatCoords[this.numCoords - 1] = this.moveY = this.prevY = this.currY = paramFloat2;
/*      */     } else {
/*  439 */       needRoom(false, 2);
/*  440 */       this.pointTypes[this.numTypes++] = 0;
/*  441 */       this.floatCoords[this.numCoords++] = this.moveX = this.prevX = this.currX = paramFloat1;
/*  442 */       this.floatCoords[this.numCoords++] = this.moveY = this.prevY = this.currY = paramFloat2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void moveToRel(float paramFloat1, float paramFloat2) {
/*  455 */     if (this.numTypes > 0 && this.pointTypes[this.numTypes - 1] == 0) {
/*  456 */       this.floatCoords[this.numCoords - 2] = this.moveX = this.prevX = this.currX += paramFloat1;
/*  457 */       this.floatCoords[this.numCoords - 1] = this.moveY = this.prevY = this.currY += paramFloat2;
/*      */     } else {
/*  459 */       needRoom(true, 2);
/*  460 */       this.pointTypes[this.numTypes++] = 0;
/*  461 */       this.floatCoords[this.numCoords++] = this.moveX = this.prevX = this.currX += paramFloat1;
/*  462 */       this.floatCoords[this.numCoords++] = this.moveY = this.prevY = this.currY += paramFloat2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void lineTo(float paramFloat1, float paramFloat2) {
/*  474 */     needRoom(true, 2);
/*  475 */     this.pointTypes[this.numTypes++] = 1;
/*  476 */     this.floatCoords[this.numCoords++] = this.prevX = this.currX = paramFloat1;
/*  477 */     this.floatCoords[this.numCoords++] = this.prevY = this.currY = paramFloat2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void lineToRel(float paramFloat1, float paramFloat2) {
/*  490 */     needRoom(true, 2);
/*  491 */     this.pointTypes[this.numTypes++] = 1;
/*  492 */     this.floatCoords[this.numCoords++] = this.prevX = this.currX += paramFloat1;
/*  493 */     this.floatCoords[this.numCoords++] = this.prevY = this.currY += paramFloat2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void quadTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  511 */     needRoom(true, 4);
/*  512 */     this.pointTypes[this.numTypes++] = 2;
/*  513 */     this.floatCoords[this.numCoords++] = this.prevX = paramFloat1;
/*  514 */     this.floatCoords[this.numCoords++] = this.prevY = paramFloat2;
/*  515 */     this.floatCoords[this.numCoords++] = this.currX = paramFloat3;
/*  516 */     this.floatCoords[this.numCoords++] = this.currY = paramFloat4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void quadToRel(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  541 */     needRoom(true, 4);
/*  542 */     this.pointTypes[this.numTypes++] = 2;
/*  543 */     this.floatCoords[this.numCoords++] = this.prevX = this.currX + paramFloat1;
/*  544 */     this.floatCoords[this.numCoords++] = this.prevY = this.currY + paramFloat2;
/*  545 */     this.floatCoords[this.numCoords++] = this.currX += paramFloat3;
/*  546 */     this.floatCoords[this.numCoords++] = this.currY += paramFloat4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void quadToSmooth(float paramFloat1, float paramFloat2) {
/*  570 */     needRoom(true, 4);
/*  571 */     this.pointTypes[this.numTypes++] = 2;
/*  572 */     this.floatCoords[this.numCoords++] = this.prevX = this.currX * 2.0F - this.prevX;
/*  573 */     this.floatCoords[this.numCoords++] = this.prevY = this.currY * 2.0F - this.prevY;
/*  574 */     this.floatCoords[this.numCoords++] = this.currX = paramFloat1;
/*  575 */     this.floatCoords[this.numCoords++] = this.currY = paramFloat2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void quadToSmoothRel(float paramFloat1, float paramFloat2) {
/*  600 */     needRoom(true, 4);
/*  601 */     this.pointTypes[this.numTypes++] = 2;
/*  602 */     this.floatCoords[this.numCoords++] = this.prevX = this.currX * 2.0F - this.prevX;
/*  603 */     this.floatCoords[this.numCoords++] = this.prevY = this.currY * 2.0F - this.prevY;
/*  604 */     this.floatCoords[this.numCoords++] = this.currX += paramFloat1;
/*  605 */     this.floatCoords[this.numCoords++] = this.currY += paramFloat2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void curveTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  627 */     needRoom(true, 6);
/*  628 */     this.pointTypes[this.numTypes++] = 3;
/*  629 */     this.floatCoords[this.numCoords++] = paramFloat1;
/*  630 */     this.floatCoords[this.numCoords++] = paramFloat2;
/*  631 */     this.floatCoords[this.numCoords++] = this.prevX = paramFloat3;
/*  632 */     this.floatCoords[this.numCoords++] = this.prevY = paramFloat4;
/*  633 */     this.floatCoords[this.numCoords++] = this.currX = paramFloat5;
/*  634 */     this.floatCoords[this.numCoords++] = this.currY = paramFloat6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void curveToRel(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  663 */     needRoom(true, 6);
/*  664 */     this.pointTypes[this.numTypes++] = 3;
/*  665 */     this.floatCoords[this.numCoords++] = this.currX + paramFloat1;
/*  666 */     this.floatCoords[this.numCoords++] = this.currY + paramFloat2;
/*  667 */     this.floatCoords[this.numCoords++] = this.prevX = this.currX + paramFloat3;
/*  668 */     this.floatCoords[this.numCoords++] = this.prevY = this.currY + paramFloat4;
/*  669 */     this.floatCoords[this.numCoords++] = this.currX += paramFloat5;
/*  670 */     this.floatCoords[this.numCoords++] = this.currY += paramFloat6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void curveToSmooth(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  699 */     needRoom(true, 6);
/*  700 */     this.pointTypes[this.numTypes++] = 3;
/*  701 */     this.floatCoords[this.numCoords++] = this.currX * 2.0F - this.prevX;
/*  702 */     this.floatCoords[this.numCoords++] = this.currY * 2.0F - this.prevY;
/*  703 */     this.floatCoords[this.numCoords++] = this.prevX = paramFloat1;
/*  704 */     this.floatCoords[this.numCoords++] = this.prevY = paramFloat2;
/*  705 */     this.floatCoords[this.numCoords++] = this.currX = paramFloat3;
/*  706 */     this.floatCoords[this.numCoords++] = this.currY = paramFloat4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void curveToSmoothRel(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  737 */     needRoom(true, 6);
/*  738 */     this.pointTypes[this.numTypes++] = 3;
/*  739 */     this.floatCoords[this.numCoords++] = this.currX * 2.0F - this.prevX;
/*  740 */     this.floatCoords[this.numCoords++] = this.currY * 2.0F - this.prevY;
/*  741 */     this.floatCoords[this.numCoords++] = this.prevX = this.currX + paramFloat1;
/*  742 */     this.floatCoords[this.numCoords++] = this.prevY = this.currY + paramFloat2;
/*  743 */     this.floatCoords[this.numCoords++] = this.currX += paramFloat3;
/*  744 */     this.floatCoords[this.numCoords++] = this.currY += paramFloat4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void ovalQuadrantTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  813 */     if (this.numTypes < 1) {
/*  814 */       throw new IllegalPathStateException("missing initial moveto in path definition");
/*      */     }
/*      */     
/*  817 */     appendOvalQuadrant(this.currX, this.currY, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, CornerPrefix.CORNER_ONLY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void appendOvalQuadrant(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, CornerPrefix paramCornerPrefix) {
/*  917 */     if (paramFloat7 < 0.0F || paramFloat7 > paramFloat8 || paramFloat8 > 1.0F) {
/*  918 */       throw new IllegalArgumentException("0 <= tfrom <= tto <= 1 required");
/*      */     }
/*  920 */     float f1 = (float)(paramFloat1 + (paramFloat3 - paramFloat1) * 0.5522847498307933D);
/*  921 */     float f2 = (float)(paramFloat2 + (paramFloat4 - paramFloat2) * 0.5522847498307933D);
/*  922 */     float f3 = (float)(paramFloat5 + (paramFloat3 - paramFloat5) * 0.5522847498307933D);
/*  923 */     float f4 = (float)(paramFloat6 + (paramFloat4 - paramFloat6) * 0.5522847498307933D);
/*  924 */     if (paramFloat8 < 1.0F) {
/*  925 */       float f = 1.0F - paramFloat8;
/*  926 */       paramFloat5 += (f3 - paramFloat5) * f;
/*  927 */       paramFloat6 += (f4 - paramFloat6) * f;
/*  928 */       f3 += (f1 - f3) * f;
/*  929 */       f4 += (f2 - f4) * f;
/*  930 */       f1 += (paramFloat1 - f1) * f;
/*  931 */       f2 += (paramFloat2 - f2) * f;
/*  932 */       paramFloat5 += (f3 - paramFloat5) * f;
/*  933 */       paramFloat6 += (f4 - paramFloat6) * f;
/*  934 */       f3 += (f1 - f3) * f;
/*  935 */       f4 += (f2 - f4) * f;
/*  936 */       paramFloat5 += (f3 - paramFloat5) * f;
/*  937 */       paramFloat6 += (f4 - paramFloat6) * f;
/*      */     } 
/*  939 */     if (paramFloat7 > 0.0F) {
/*  940 */       if (paramFloat8 < 1.0F) {
/*  941 */         paramFloat7 /= paramFloat8;
/*      */       }
/*  943 */       paramFloat1 += (f1 - paramFloat1) * paramFloat7;
/*  944 */       paramFloat2 += (f2 - paramFloat2) * paramFloat7;
/*  945 */       f1 += (f3 - f1) * paramFloat7;
/*  946 */       f2 += (f4 - f2) * paramFloat7;
/*  947 */       f3 += (paramFloat5 - f3) * paramFloat7;
/*  948 */       f4 += (paramFloat6 - f4) * paramFloat7;
/*  949 */       paramFloat1 += (f1 - paramFloat1) * paramFloat7;
/*  950 */       paramFloat2 += (f2 - paramFloat2) * paramFloat7;
/*  951 */       f1 += (f3 - f1) * paramFloat7;
/*  952 */       f2 += (f4 - f2) * paramFloat7;
/*  953 */       paramFloat1 += (f1 - paramFloat1) * paramFloat7;
/*  954 */       paramFloat2 += (f2 - paramFloat2) * paramFloat7;
/*      */     } 
/*  956 */     if (paramCornerPrefix == CornerPrefix.MOVE_THEN_CORNER) {
/*      */       
/*  958 */       moveTo(paramFloat1, paramFloat2);
/*  959 */     } else if (paramCornerPrefix == CornerPrefix.LINE_THEN_CORNER && (
/*  960 */       this.numTypes == 1 || paramFloat1 != this.currX || paramFloat2 != this.currY)) {
/*      */ 
/*      */ 
/*      */       
/*  964 */       lineTo(paramFloat1, paramFloat2);
/*      */     } 
/*      */     
/*  967 */     if (paramFloat7 == paramFloat8 || (paramFloat1 == f1 && f1 == f3 && f3 == paramFloat5 && paramFloat2 == f2 && f2 == f4 && f4 == paramFloat6)) {
/*      */ 
/*      */ 
/*      */       
/*  971 */       if (paramCornerPrefix != CornerPrefix.LINE_THEN_CORNER) {
/*  972 */         lineTo(paramFloat5, paramFloat6);
/*      */       }
/*      */     } else {
/*  975 */       curveTo(f1, f2, f3, f4, paramFloat5, paramFloat6);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void arcTo(float paramFloat1, float paramFloat2, float paramFloat3, boolean paramBoolean1, boolean paramBoolean2, float paramFloat4, float paramFloat5) {
/*      */     double d7, d8;
/* 1030 */     if (this.numTypes < 1) {
/* 1031 */       throw new IllegalPathStateException("missing initial moveto in path definition");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1050 */     double d1 = Math.abs(paramFloat1);
/* 1051 */     double d2 = Math.abs(paramFloat2);
/* 1052 */     if (d1 == 0.0D || d2 == 0.0D) {
/* 1053 */       lineTo(paramFloat4, paramFloat5);
/*      */       return;
/*      */     } 
/* 1056 */     double d3 = this.currX;
/* 1057 */     double d4 = this.currY;
/* 1058 */     double d5 = paramFloat4;
/* 1059 */     double d6 = paramFloat5;
/* 1060 */     if (d3 == d5 && d4 == d6) {
/*      */       return;
/*      */     }
/*      */     
/* 1064 */     if (paramFloat3 == 0.0D) {
/* 1065 */       d7 = 1.0D;
/* 1066 */       d8 = 0.0D;
/*      */     } else {
/* 1068 */       d7 = Math.cos(paramFloat3);
/* 1069 */       d8 = Math.sin(paramFloat3);
/*      */     } 
/* 1071 */     double d9 = (d3 + d5) / 2.0D;
/* 1072 */     double d10 = (d4 + d6) / 2.0D;
/* 1073 */     double d11 = d3 - d9;
/* 1074 */     double d12 = d4 - d10;
/* 1075 */     double d13 = (d7 * d11 + d8 * d12) / d1;
/* 1076 */     double d14 = (d7 * d12 - d8 * d11) / d2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1090 */     double d15 = d13 * d13 + d14 * d14;
/* 1091 */     if (d15 >= 1.0D) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1105 */       double d23 = d14 * d1;
/* 1106 */       double d24 = d13 * d2;
/* 1107 */       if (paramBoolean2) { d23 = -d23; } else { d24 = -d24; }
/* 1108 */        double d25 = d7 * d23 - d8 * d24;
/* 1109 */       double d26 = d7 * d24 + d8 * d23;
/* 1110 */       double d27 = d9 + d25;
/* 1111 */       double d28 = d10 + d26;
/* 1112 */       double d29 = d3 + d25;
/* 1113 */       double d30 = d4 + d26;
/* 1114 */       appendOvalQuadrant((float)d3, (float)d4, (float)d29, (float)d30, (float)d27, (float)d28, 0.0F, 1.0F, CornerPrefix.CORNER_ONLY);
/*      */ 
/*      */ 
/*      */       
/* 1118 */       d29 = d5 + d25;
/* 1119 */       d30 = d6 + d26;
/* 1120 */       appendOvalQuadrant((float)d27, (float)d28, (float)d29, (float)d30, (float)d5, (float)d6, 0.0F, 1.0F, CornerPrefix.CORNER_ONLY);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1143 */     double d16 = Math.sqrt((1.0D - d15) / d15);
/*      */ 
/*      */ 
/*      */     
/* 1147 */     double d17 = d16 * d14;
/* 1148 */     double d18 = d16 * d13;
/*      */ 
/*      */     
/* 1151 */     if (paramBoolean1 == paramBoolean2) { d17 = -d17; } else { d18 = -d18; }
/* 1152 */      d9 += d7 * d17 * d1 - d8 * d18 * d2;
/* 1153 */     d10 += d7 * d18 * d2 + d8 * d17 * d1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1158 */     double d19 = d13 - d17;
/* 1159 */     double d20 = d14 - d18;
/*      */ 
/*      */     
/* 1162 */     double d21 = -(d13 + d17);
/* 1163 */     double d22 = -(d14 + d18);
/*      */ 
/*      */     
/* 1166 */     boolean bool1 = false;
/* 1167 */     float f = 1.0F;
/* 1168 */     boolean bool2 = false;
/*      */     
/*      */     do {
/* 1171 */       double d23 = d20;
/* 1172 */       double d24 = d19;
/* 1173 */       if (paramBoolean2) { d23 = -d23; } else { d24 = -d24; }
/*      */       
/* 1175 */       if (d23 * d21 + d24 * d22 > 0.0D) {
/*      */ 
/*      */         
/* 1178 */         double d = d19 * d21 + d20 * d22;
/* 1179 */         if (d >= 0.0D) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1184 */           f = (float)(Math.acos(d) / 1.5707963267948966D);
/* 1185 */           bool1 = true;
/*      */         } 
/*      */ 
/*      */         
/* 1189 */         bool2 = true;
/* 1190 */       } else if (bool2) {
/*      */         break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1204 */       double d25 = d7 * d23 * d1 - d8 * d24 * d2;
/* 1205 */       double d26 = d7 * d24 * d2 + d8 * d23 * d1;
/* 1206 */       double d27 = d9 + d25;
/* 1207 */       double d28 = d10 + d26;
/* 1208 */       double d29 = d3 + d25;
/* 1209 */       double d30 = d4 + d26;
/* 1210 */       appendOvalQuadrant((float)d3, (float)d4, (float)d29, (float)d30, (float)d27, (float)d28, 0.0F, f, CornerPrefix.CORNER_ONLY);
/*      */ 
/*      */ 
/*      */       
/* 1214 */       d3 = d27;
/* 1215 */       d4 = d28;
/* 1216 */       d19 = d23;
/* 1217 */       d20 = d24;
/* 1218 */     } while (!bool1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void arcToRel(float paramFloat1, float paramFloat2, float paramFloat3, boolean paramBoolean1, boolean paramBoolean2, float paramFloat4, float paramFloat5) {
/* 1247 */     arcTo(paramFloat1, paramFloat2, paramFloat3, paramBoolean1, paramBoolean2, this.currX + paramFloat4, this.currY + paramFloat5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int pointCrossings(float paramFloat1, float paramFloat2) {
/* 1254 */     float[] arrayOfFloat = this.floatCoords;
/* 1255 */     float f1 = arrayOfFloat[0], f3 = f1;
/* 1256 */     float f2 = arrayOfFloat[1], f4 = f2;
/* 1257 */     int i = 0;
/* 1258 */     byte b1 = 2;
/* 1259 */     for (byte b2 = 1; b2 < this.numTypes; b2++) {
/* 1260 */       float f5; float f6; switch (this.pointTypes[b2]) {
/*      */         case 0:
/* 1262 */           if (f4 != f2) {
/* 1263 */             i += 
/* 1264 */               Shape.pointCrossingsForLine(paramFloat1, paramFloat2, f3, f4, f1, f2);
/*      */           }
/*      */ 
/*      */           
/* 1268 */           f1 = f3 = arrayOfFloat[b1++];
/* 1269 */           f2 = f4 = arrayOfFloat[b1++];
/*      */           break;
/*      */         case 1:
/* 1272 */           i += 
/* 1273 */             Shape.pointCrossingsForLine(paramFloat1, paramFloat2, f3, f4, f5 = arrayOfFloat[b1++], f6 = arrayOfFloat[b1++]);
/*      */ 
/*      */ 
/*      */           
/* 1277 */           f3 = f5;
/* 1278 */           f4 = f6;
/*      */           break;
/*      */         case 2:
/* 1281 */           i += 
/* 1282 */             Shape.pointCrossingsForQuad(paramFloat1, paramFloat2, f3, f4, arrayOfFloat[b1++], arrayOfFloat[b1++], f5 = arrayOfFloat[b1++], f6 = arrayOfFloat[b1++], 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1289 */           f3 = f5;
/* 1290 */           f4 = f6;
/*      */           break;
/*      */         case 3:
/* 1293 */           i += 
/* 1294 */             Shape.pointCrossingsForCubic(paramFloat1, paramFloat2, f3, f4, arrayOfFloat[b1++], arrayOfFloat[b1++], arrayOfFloat[b1++], arrayOfFloat[b1++], f5 = arrayOfFloat[b1++], f6 = arrayOfFloat[b1++], 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1303 */           f3 = f5;
/* 1304 */           f4 = f6;
/*      */           break;
/*      */         case 4:
/* 1307 */           if (f4 != f2) {
/* 1308 */             i += 
/* 1309 */               Shape.pointCrossingsForLine(paramFloat1, paramFloat2, f3, f4, f1, f2);
/*      */           }
/*      */ 
/*      */           
/* 1313 */           f3 = f1;
/* 1314 */           f4 = f2;
/*      */           break;
/*      */       } 
/*      */     } 
/* 1318 */     if (f4 != f2) {
/* 1319 */       i += 
/* 1320 */         Shape.pointCrossingsForLine(paramFloat1, paramFloat2, f3, f4, f1, f2);
/*      */     }
/*      */ 
/*      */     
/* 1324 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int rectCrossings(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 1330 */     float[] arrayOfFloat = this.floatCoords;
/*      */     
/* 1332 */     float f3 = arrayOfFloat[0], f1 = f3;
/* 1333 */     float f4 = arrayOfFloat[1], f2 = f4;
/* 1334 */     int i = 0;
/* 1335 */     byte b1 = 2;
/* 1336 */     byte b2 = 1;
/* 1337 */     for (; i != Integer.MIN_VALUE && b2 < this.numTypes; 
/* 1338 */       b2++) {
/*      */       float f5; float f6;
/* 1340 */       switch (this.pointTypes[b2]) {
/*      */         case 0:
/* 1342 */           if (f1 != f3 || f2 != f4)
/*      */           {
/* 1344 */             i = Shape.rectCrossingsForLine(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, f3, f4);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1352 */           f3 = f1 = arrayOfFloat[b1++];
/* 1353 */           f4 = f2 = arrayOfFloat[b1++];
/*      */           break;
/*      */         
/*      */         case 1:
/* 1357 */           i = Shape.rectCrossingsForLine(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, f5 = arrayOfFloat[b1++], f6 = arrayOfFloat[b1++]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1363 */           f1 = f5;
/* 1364 */           f2 = f6;
/*      */           break;
/*      */         
/*      */         case 2:
/* 1368 */           i = Shape.rectCrossingsForQuad(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, arrayOfFloat[b1++], arrayOfFloat[b1++], f5 = arrayOfFloat[b1++], f6 = arrayOfFloat[b1++], 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1377 */           f1 = f5;
/* 1378 */           f2 = f6;
/*      */           break;
/*      */         
/*      */         case 3:
/* 1382 */           i = Shape.rectCrossingsForCubic(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, arrayOfFloat[b1++], arrayOfFloat[b1++], arrayOfFloat[b1++], arrayOfFloat[b1++], f5 = arrayOfFloat[b1++], f6 = arrayOfFloat[b1++], 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1393 */           f1 = f5;
/* 1394 */           f2 = f6;
/*      */           break;
/*      */         case 4:
/* 1397 */           if (f1 != f3 || f2 != f4)
/*      */           {
/* 1399 */             i = Shape.rectCrossingsForLine(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, f3, f4);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1405 */           f1 = f3;
/* 1406 */           f2 = f4;
/*      */           break;
/*      */       } 
/*      */ 
/*      */     
/*      */     } 
/* 1412 */     if (i != Integer.MIN_VALUE && (f1 != f3 || f2 != f4))
/*      */     {
/*      */ 
/*      */       
/* 1416 */       i = Shape.rectCrossingsForLine(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, f3, f4);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1424 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void append(PathIterator paramPathIterator, boolean paramBoolean) {
/* 1431 */     float[] arrayOfFloat = new float[6];
/* 1432 */     while (!paramPathIterator.isDone()) {
/* 1433 */       switch (paramPathIterator.currentSegment(arrayOfFloat)) {
/*      */         case 0:
/* 1435 */           if (!paramBoolean || this.numTypes < 1 || this.numCoords < 1) {
/* 1436 */             moveTo(arrayOfFloat[0], arrayOfFloat[1]);
/*      */             break;
/*      */           } 
/* 1439 */           if (this.pointTypes[this.numTypes - 1] != 4 && this.floatCoords[this.numCoords - 2] == arrayOfFloat[0] && this.floatCoords[this.numCoords - 1] == arrayOfFloat[1]) {
/*      */             break;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 1:
/* 1448 */           lineTo(arrayOfFloat[0], arrayOfFloat[1]);
/*      */           break;
/*      */         case 2:
/* 1451 */           quadTo(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3]);
/*      */           break;
/*      */         
/*      */         case 3:
/* 1455 */           curveTo(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3], arrayOfFloat[4], arrayOfFloat[5]);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/* 1460 */           closePath();
/*      */           break;
/*      */       } 
/* 1463 */       paramPathIterator.next();
/* 1464 */       paramBoolean = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void transform(BaseTransform paramBaseTransform) {
/* 1472 */     if (this.numCoords == 0)
/* 1473 */       return;  needRoom(false, 6);
/* 1474 */     this.floatCoords[this.numCoords + 0] = this.moveX;
/* 1475 */     this.floatCoords[this.numCoords + 1] = this.moveY;
/* 1476 */     this.floatCoords[this.numCoords + 2] = this.prevX;
/* 1477 */     this.floatCoords[this.numCoords + 3] = this.prevY;
/* 1478 */     this.floatCoords[this.numCoords + 4] = this.currX;
/* 1479 */     this.floatCoords[this.numCoords + 5] = this.currY;
/* 1480 */     paramBaseTransform.transform(this.floatCoords, 0, this.floatCoords, 0, this.numCoords / 2 + 3);
/* 1481 */     this.moveX = this.floatCoords[this.numCoords + 0];
/* 1482 */     this.moveY = this.floatCoords[this.numCoords + 1];
/* 1483 */     this.prevX = this.floatCoords[this.numCoords + 2];
/* 1484 */     this.prevY = this.floatCoords[this.numCoords + 3];
/* 1485 */     this.currX = this.floatCoords[this.numCoords + 4];
/* 1486 */     this.currY = this.floatCoords[this.numCoords + 5];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final RectBounds getBounds() {
/*      */     float f1, f2, f3, f4;
/* 1494 */     int i = this.numCoords;
/* 1495 */     if (i > 0) {
/* 1496 */       f2 = f4 = this.floatCoords[--i];
/* 1497 */       f1 = f3 = this.floatCoords[--i];
/* 1498 */       while (i > 0) {
/* 1499 */         float f5 = this.floatCoords[--i];
/* 1500 */         float f6 = this.floatCoords[--i];
/* 1501 */         if (f6 < f1) f1 = f6; 
/* 1502 */         if (f5 < f2) f2 = f5; 
/* 1503 */         if (f6 > f3) f3 = f6; 
/* 1504 */         if (f5 > f4) f4 = f5; 
/*      */       } 
/*      */     } else {
/* 1507 */       f1 = f2 = f3 = f4 = 0.0F;
/*      */     } 
/* 1509 */     return new RectBounds(f1, f2, f3, f4);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNumCommands() {
/* 1515 */     return this.numTypes;
/*      */   }
/*      */   public final byte[] getCommandsNoClone() {
/* 1518 */     return this.pointTypes;
/*      */   }
/*      */   public final float[] getFloatCoordsNoClone() {
/* 1521 */     return this.floatCoords;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/* 1534 */     if (paramBaseTransform == null) {
/* 1535 */       return new CopyIterator(this);
/*      */     }
/* 1537 */     return new TxIterator(this, paramBaseTransform);
/*      */   }
/*      */   
/*      */   static class CopyIterator
/*      */     extends Iterator {
/*      */     float[] floatCoords;
/*      */     
/*      */     CopyIterator(Path2D param1Path2D) {
/* 1545 */       super(param1Path2D);
/* 1546 */       this.floatCoords = param1Path2D.floatCoords;
/*      */     }
/*      */     
/*      */     public int currentSegment(float[] param1ArrayOffloat) {
/* 1550 */       byte b = this.path.pointTypes[this.typeIdx];
/* 1551 */       int i = Path2D.curvecoords[b];
/* 1552 */       if (i > 0) {
/* 1553 */         System.arraycopy(this.floatCoords, this.pointIdx, param1ArrayOffloat, 0, i);
/*      */       }
/*      */       
/* 1556 */       return b;
/*      */     }
/*      */     
/*      */     public int currentSegment(double[] param1ArrayOfdouble) {
/* 1560 */       byte b = this.path.pointTypes[this.typeIdx];
/* 1561 */       int i = Path2D.curvecoords[b];
/* 1562 */       if (i > 0) {
/* 1563 */         for (byte b1 = 0; b1 < i; b1++) {
/* 1564 */           param1ArrayOfdouble[b1] = this.floatCoords[this.pointIdx + b1];
/*      */         }
/*      */       }
/* 1567 */       return b;
/*      */     }
/*      */   }
/*      */   
/*      */   static class TxIterator extends Iterator {
/*      */     float[] floatCoords;
/*      */     BaseTransform transform;
/*      */     
/*      */     TxIterator(Path2D param1Path2D, BaseTransform param1BaseTransform) {
/* 1576 */       super(param1Path2D);
/* 1577 */       this.floatCoords = param1Path2D.floatCoords;
/* 1578 */       this.transform = param1BaseTransform;
/*      */     }
/*      */     
/*      */     public int currentSegment(float[] param1ArrayOffloat) {
/* 1582 */       byte b = this.path.pointTypes[this.typeIdx];
/* 1583 */       int i = Path2D.curvecoords[b];
/* 1584 */       if (i > 0) {
/* 1585 */         this.transform.transform(this.floatCoords, this.pointIdx, param1ArrayOffloat, 0, i / 2);
/*      */       }
/*      */       
/* 1588 */       return b;
/*      */     }
/*      */     
/*      */     public int currentSegment(double[] param1ArrayOfdouble) {
/* 1592 */       byte b = this.path.pointTypes[this.typeIdx];
/* 1593 */       int i = Path2D.curvecoords[b];
/* 1594 */       if (i > 0) {
/* 1595 */         this.transform.transform(this.floatCoords, this.pointIdx, param1ArrayOfdouble, 0, i / 2);
/*      */       }
/*      */       
/* 1598 */       return b;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void closePath() {
/* 1608 */     if (this.numTypes == 0 || this.pointTypes[this.numTypes - 1] != 4) {
/* 1609 */       needRoom(true, 0);
/* 1610 */       this.pointTypes[this.numTypes++] = 4;
/* 1611 */       this.prevX = this.currX = this.moveX;
/* 1612 */       this.prevY = this.currY = this.moveY;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pathDone() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void append(Shape paramShape, boolean paramBoolean) {
/* 1641 */     append(paramShape.getPathIterator(null), paramBoolean);
/*      */   }
/*      */   
/*      */   static class SVGParser {
/*      */     final String svgpath;
/*      */     final int len;
/*      */     int pos;
/*      */     boolean allowcomma;
/*      */     
/*      */     public SVGParser(String param1String) {
/* 1651 */       this.svgpath = param1String;
/* 1652 */       this.len = param1String.length();
/*      */     }
/*      */     
/*      */     public boolean isDone() {
/* 1656 */       return (toNextNonWsp() >= this.len);
/*      */     }
/*      */     
/*      */     public char getChar() {
/* 1660 */       return this.svgpath.charAt(this.pos++);
/*      */     }
/*      */     
/*      */     public boolean nextIsNumber() {
/* 1664 */       if (toNextNonWsp() < this.len) {
/* 1665 */         switch (this.svgpath.charAt(this.pos)) { case '+': case '-': case '.': case '0': case '1': case '2': case '3': case '4':
/*      */           case '5':
/*      */           case '6':
/*      */           case '7':
/*      */           case '8':
/*      */           case '9':
/* 1671 */             return true; }
/*      */       
/*      */       }
/* 1674 */       return false;
/*      */     }
/*      */     
/*      */     public float f() {
/* 1678 */       return getFloat();
/*      */     }
/*      */     
/*      */     public float a() {
/* 1682 */       return (float)Math.toRadians(getFloat());
/*      */     }
/*      */     
/*      */     public float getFloat() {
/* 1686 */       int i = toNextNonWsp();
/* 1687 */       this.allowcomma = true;
/* 1688 */       int j = toNumberEnd();
/* 1689 */       if (i < j) {
/* 1690 */         String str = this.svgpath.substring(i, j);
/*      */         try {
/* 1692 */           return Float.parseFloat(str);
/* 1693 */         } catch (NumberFormatException numberFormatException) {
/*      */           
/* 1695 */           throw new IllegalArgumentException("invalid float (" + str + ") in path at pos=" + i);
/*      */         } 
/*      */       } 
/* 1698 */       throw new IllegalArgumentException("end of path looking for float");
/*      */     }
/*      */     
/*      */     public boolean b() {
/* 1702 */       toNextNonWsp();
/* 1703 */       this.allowcomma = true;
/* 1704 */       if (this.pos < this.len) {
/* 1705 */         char c = this.svgpath.charAt(this.pos);
/* 1706 */         switch (c) { case '0':
/* 1707 */             this.pos++; return false;
/* 1708 */           case '1': this.pos++; return true; }
/*      */         
/* 1710 */         throw new IllegalArgumentException("invalid boolean flag (" + c + ") in path at pos=" + this.pos);
/*      */       } 
/*      */       
/* 1713 */       throw new IllegalArgumentException("end of path looking for boolean");
/*      */     }
/*      */     
/*      */     private int toNextNonWsp() {
/* 1717 */       boolean bool = this.allowcomma;
/* 1718 */       while (this.pos < this.len) {
/* 1719 */         switch (this.svgpath.charAt(this.pos)) {
/*      */           case ',':
/* 1721 */             if (!bool) {
/* 1722 */               return this.pos;
/*      */             }
/* 1724 */             bool = false;
/*      */             break;
/*      */           case '\t':
/*      */           case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*      */             break;
/*      */           default:
/* 1732 */             return this.pos;
/*      */         } 
/* 1734 */         this.pos++;
/*      */       } 
/* 1736 */       return this.pos;
/*      */     }
/*      */     
/*      */     private int toNumberEnd() {
/* 1740 */       boolean bool1 = true;
/* 1741 */       boolean bool2 = false;
/* 1742 */       boolean bool3 = false;
/* 1743 */       while (this.pos < this.len) {
/* 1744 */         switch (this.svgpath.charAt(this.pos)) {
/*      */           case '+':
/*      */           case '-':
/* 1747 */             if (!bool1) return this.pos; 
/* 1748 */             bool1 = false; break;
/*      */           case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7':
/*      */           case '8':
/*      */           case '9':
/* 1752 */             bool1 = false; break;
/*      */           case 'E':
/*      */           case 'e':
/* 1755 */             if (bool2) return this.pos; 
/* 1756 */             bool2 = bool1 = true;
/*      */             break;
/*      */           case '.':
/* 1759 */             if (bool2 || bool3) return this.pos; 
/* 1760 */             bool3 = true;
/* 1761 */             bool1 = false;
/*      */             break;
/*      */           default:
/* 1764 */             return this.pos;
/*      */         } 
/* 1766 */         this.pos++;
/*      */       } 
/* 1768 */       return this.pos;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void appendSVGPath(String paramString) {
/* 1794 */     SVGParser sVGParser = new SVGParser(paramString);
/* 1795 */     sVGParser.allowcomma = false;
/* 1796 */     while (!sVGParser.isDone()) {
/* 1797 */       sVGParser.allowcomma = false;
/* 1798 */       char c = sVGParser.getChar();
/* 1799 */       switch (c) {
/*      */         case 'M':
/* 1801 */           moveTo(sVGParser.f(), sVGParser.f());
/* 1802 */           while (sVGParser.nextIsNumber()) {
/* 1803 */             lineTo(sVGParser.f(), sVGParser.f());
/*      */           }
/*      */           break;
/*      */         case 'm':
/* 1807 */           if (this.numTypes > 0) {
/* 1808 */             moveToRel(sVGParser.f(), sVGParser.f());
/*      */           } else {
/* 1810 */             moveTo(sVGParser.f(), sVGParser.f());
/*      */           } 
/* 1812 */           while (sVGParser.nextIsNumber()) {
/* 1813 */             lineToRel(sVGParser.f(), sVGParser.f());
/*      */           }
/*      */           break;
/*      */         case 'L':
/*      */           do {
/* 1818 */             lineTo(sVGParser.f(), sVGParser.f());
/* 1819 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'l':
/*      */           do {
/* 1823 */             lineToRel(sVGParser.f(), sVGParser.f());
/* 1824 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'H':
/*      */           do {
/* 1828 */             lineTo(sVGParser.f(), this.currY);
/* 1829 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'h':
/*      */           do {
/* 1833 */             lineToRel(sVGParser.f(), 0.0F);
/* 1834 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'V':
/*      */           do {
/* 1838 */             lineTo(this.currX, sVGParser.f());
/* 1839 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'v':
/*      */           do {
/* 1843 */             lineToRel(0.0F, sVGParser.f());
/* 1844 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'Q':
/*      */           do {
/* 1848 */             quadTo(sVGParser.f(), sVGParser.f(), sVGParser.f(), sVGParser.f());
/* 1849 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'q':
/*      */           do {
/* 1853 */             quadToRel(sVGParser.f(), sVGParser.f(), sVGParser.f(), sVGParser.f());
/* 1854 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'T':
/*      */           do {
/* 1858 */             quadToSmooth(sVGParser.f(), sVGParser.f());
/* 1859 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 't':
/*      */           do {
/* 1863 */             quadToSmoothRel(sVGParser.f(), sVGParser.f());
/* 1864 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'C':
/*      */           do {
/* 1868 */             curveTo(sVGParser.f(), sVGParser.f(), sVGParser.f(), sVGParser.f(), sVGParser.f(), sVGParser.f());
/* 1869 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'c':
/*      */           do {
/* 1873 */             curveToRel(sVGParser.f(), sVGParser.f(), sVGParser.f(), sVGParser.f(), sVGParser.f(), sVGParser.f());
/* 1874 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'S':
/*      */           do {
/* 1878 */             curveToSmooth(sVGParser.f(), sVGParser.f(), sVGParser.f(), sVGParser.f());
/* 1879 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 's':
/*      */           do {
/* 1883 */             curveToSmoothRel(sVGParser.f(), sVGParser.f(), sVGParser.f(), sVGParser.f());
/* 1884 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'A':
/*      */           do {
/* 1888 */             arcTo(sVGParser.f(), sVGParser.f(), sVGParser.a(), sVGParser.b(), sVGParser.b(), sVGParser.f(), sVGParser.f());
/* 1889 */           } while (sVGParser.nextIsNumber());
/*      */           break;
/*      */         case 'a':
/*      */           do {
/* 1893 */             arcToRel(sVGParser.f(), sVGParser.f(), sVGParser.a(), sVGParser.b(), sVGParser.b(), sVGParser.f(), sVGParser.f());
/* 1894 */           } while (sVGParser.nextIsNumber()); break;
/*      */         case 'Z': case 'z':
/* 1896 */           closePath(); break;
/*      */         default:
/* 1898 */           throw new IllegalArgumentException("invalid command (" + c + ") in SVG path at pos=" + sVGParser.pos);
/*      */       } 
/*      */       
/* 1901 */       sVGParser.allowcomma = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getWindingRule() {
/* 1914 */     return this.windingRule;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setWindingRule(int paramInt) {
/* 1929 */     if (paramInt != 0 && paramInt != 1) {
/* 1930 */       throw new IllegalArgumentException("winding rule must be WIND_EVEN_ODD or WIND_NON_ZERO");
/*      */     }
/*      */ 
/*      */     
/* 1934 */     this.windingRule = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Point2D getCurrentPoint() {
/* 1945 */     if (this.numTypes < 1) {
/* 1946 */       return null;
/*      */     }
/* 1948 */     return new Point2D(this.currX, this.currY);
/*      */   }
/*      */   
/*      */   public final float getCurrentX() {
/* 1952 */     if (this.numTypes < 1) {
/* 1953 */       throw new IllegalPathStateException("no current point in empty path");
/*      */     }
/* 1955 */     return this.currX;
/*      */   }
/*      */   
/*      */   public final float getCurrentY() {
/* 1959 */     if (this.numTypes < 1) {
/* 1960 */       throw new IllegalPathStateException("no current point in empty path");
/*      */     }
/* 1962 */     return this.currY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void reset() {
/* 1971 */     this.numTypes = this.numCoords = 0;
/* 1972 */     this.moveX = this.moveY = this.prevX = this.prevY = this.currX = this.currY = 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Shape createTransformedShape(BaseTransform paramBaseTransform) {
/* 1993 */     return new Path2D(this, paramBaseTransform);
/*      */   }
/*      */ 
/*      */   
/*      */   public Path2D copy() {
/* 1998 */     return new Path2D(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object paramObject) {
/* 2012 */     if (paramObject == this) {
/* 2013 */       return true;
/*      */     }
/* 2015 */     if (paramObject instanceof Path2D) {
/* 2016 */       Path2D path2D = (Path2D)paramObject;
/* 2017 */       if (path2D.numTypes == this.numTypes && path2D.numCoords == this.numCoords && path2D.windingRule == this.windingRule) {
/*      */         byte b;
/*      */ 
/*      */         
/* 2021 */         for (b = 0; b < this.numTypes; b++) {
/* 2022 */           if (path2D.pointTypes[b] != this.pointTypes[b]) {
/* 2023 */             return false;
/*      */           }
/*      */         } 
/* 2026 */         for (b = 0; b < this.numCoords; b++) {
/* 2027 */           if (path2D.floatCoords[b] != this.floatCoords[b]) {
/* 2028 */             return false;
/*      */           }
/*      */         } 
/* 2031 */         return true;
/*      */       } 
/*      */     } 
/* 2034 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 2039 */     int i = 7;
/* 2040 */     i = 11 * i + this.numTypes;
/* 2041 */     i = 11 * i + this.numCoords;
/* 2042 */     i = 11 * i + this.windingRule; byte b;
/* 2043 */     for (b = 0; b < this.numTypes; b++) {
/* 2044 */       i = 11 * i + this.pointTypes[b];
/*      */     }
/* 2046 */     for (b = 0; b < this.numCoords; b++) {
/* 2047 */       i = 11 * i + Float.floatToIntBits(this.floatCoords[b]);
/*      */     }
/* 2049 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(PathIterator paramPathIterator, float paramFloat1, float paramFloat2) {
/* 2067 */     if (paramFloat1 * 0.0F + paramFloat2 * 0.0F == 0.0F) {
/*      */ 
/*      */ 
/*      */       
/* 2071 */       byte b = (paramPathIterator.getWindingRule() == 1) ? -1 : 1;
/* 2072 */       int i = Shape.pointCrossingsForPath(paramPathIterator, paramFloat1, paramFloat2);
/* 2073 */       return ((i & b) != 0);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2080 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(PathIterator paramPathIterator, Point2D paramPoint2D) {
/* 2098 */     return contains(paramPathIterator, paramPoint2D.x, paramPoint2D.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean contains(float paramFloat1, float paramFloat2) {
/* 2105 */     if (paramFloat1 * 0.0F + paramFloat2 * 0.0F == 0.0F) {
/*      */ 
/*      */ 
/*      */       
/* 2109 */       if (this.numTypes < 2) {
/* 2110 */         return false;
/*      */       }
/* 2112 */       boolean bool = (this.windingRule == 1) ? true : true;
/* 2113 */       return ((pointCrossings(paramFloat1, paramFloat2) & bool) != 0);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2120 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean contains(Point2D paramPoint2D) {
/* 2129 */     return contains(paramPoint2D.x, paramPoint2D.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(PathIterator paramPathIterator, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 2165 */     if (Float.isNaN(paramFloat1 + paramFloat3) || Float.isNaN(paramFloat2 + paramFloat4))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2174 */       return false;
/*      */     }
/* 2176 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/* 2177 */       return false;
/*      */     }
/* 2179 */     byte b = (paramPathIterator.getWindingRule() == 1) ? -1 : 2;
/* 2180 */     int i = Shape.rectCrossingsForPath(paramPathIterator, paramFloat1, paramFloat2, paramFloat1 + paramFloat3, paramFloat2 + paramFloat4);
/* 2181 */     return (i != Integer.MIN_VALUE && (i & b) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 2203 */     if (Float.isNaN(paramFloat1 + paramFloat3) || Float.isNaN(paramFloat2 + paramFloat4))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2212 */       return false;
/*      */     }
/* 2214 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/* 2215 */       return false;
/*      */     }
/* 2217 */     byte b = (this.windingRule == 1) ? -1 : 2;
/* 2218 */     int i = rectCrossings(paramFloat1, paramFloat2, paramFloat1 + paramFloat3, paramFloat2 + paramFloat4);
/* 2219 */     return (i != Integer.MIN_VALUE && (i & b) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean intersects(PathIterator paramPathIterator, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 2257 */     if (Float.isNaN(paramFloat1 + paramFloat3) || Float.isNaN(paramFloat2 + paramFloat4))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2266 */       return false;
/*      */     }
/* 2268 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/* 2269 */       return false;
/*      */     }
/* 2271 */     byte b = (paramPathIterator.getWindingRule() == 1) ? -1 : 2;
/* 2272 */     int i = Shape.rectCrossingsForPath(paramPathIterator, paramFloat1, paramFloat2, paramFloat1 + paramFloat3, paramFloat2 + paramFloat4);
/* 2273 */     return (i == Integer.MIN_VALUE || (i & b) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 2294 */     if (Float.isNaN(paramFloat1 + paramFloat3) || Float.isNaN(paramFloat2 + paramFloat4))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2303 */       return false;
/*      */     }
/* 2305 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/* 2306 */       return false;
/*      */     }
/* 2308 */     byte b = (this.windingRule == 1) ? -1 : 2;
/* 2309 */     int i = rectCrossings(paramFloat1, paramFloat2, paramFloat1 + paramFloat3, paramFloat2 + paramFloat4);
/* 2310 */     return (i == Integer.MIN_VALUE || (i & b) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PathIterator getPathIterator(BaseTransform paramBaseTransform, float paramFloat) {
/* 2326 */     return new FlatteningPathIterator(getPathIterator(paramBaseTransform), paramFloat);
/*      */   }
/*      */   
/*      */   static abstract class Iterator implements PathIterator {
/*      */     int typeIdx;
/*      */     int pointIdx;
/*      */     Path2D path;
/*      */     
/*      */     Iterator(Path2D param1Path2D) {
/* 2335 */       this.path = param1Path2D;
/*      */     }
/*      */     
/*      */     public int getWindingRule() {
/* 2339 */       return this.path.getWindingRule();
/*      */     }
/*      */     
/*      */     public boolean isDone() {
/* 2343 */       return (this.typeIdx >= this.path.numTypes);
/*      */     }
/*      */     
/*      */     public void next() {
/* 2347 */       byte b = this.path.pointTypes[this.typeIdx++];
/* 2348 */       this.pointIdx += Path2D.curvecoords[b];
/*      */     }
/*      */   }
/*      */   
/*      */   public void setTo(Path2D paramPath2D) {
/* 2353 */     this.numTypes = paramPath2D.numTypes;
/* 2354 */     this.numCoords = paramPath2D.numCoords;
/* 2355 */     if (this.numTypes > this.pointTypes.length) {
/* 2356 */       this.pointTypes = new byte[this.numTypes];
/*      */     }
/* 2358 */     System.arraycopy(paramPath2D.pointTypes, 0, this.pointTypes, 0, this.numTypes);
/* 2359 */     if (this.numCoords > this.floatCoords.length) {
/* 2360 */       this.floatCoords = new float[this.numCoords];
/*      */     }
/* 2362 */     System.arraycopy(paramPath2D.floatCoords, 0, this.floatCoords, 0, this.numCoords);
/* 2363 */     this.windingRule = paramPath2D.windingRule;
/* 2364 */     this.moveX = paramPath2D.moveX;
/* 2365 */     this.moveY = paramPath2D.moveY;
/* 2366 */     this.prevX = paramPath2D.prevX;
/* 2367 */     this.prevY = paramPath2D.prevY;
/* 2368 */     this.currX = paramPath2D.currX;
/* 2369 */     this.currY = paramPath2D.currY;
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Path2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */