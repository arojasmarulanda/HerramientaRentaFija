/*    */ package com.sun.javafx.geom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Dimension2D
/*    */ {
/*    */   public float width;
/*    */   public float height;
/*    */   
/*    */   public Dimension2D() {}
/*    */   
/*    */   public Dimension2D(float paramFloat1, float paramFloat2) {
/* 40 */     this.width = paramFloat1;
/* 41 */     this.height = paramFloat2;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Dimension2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */