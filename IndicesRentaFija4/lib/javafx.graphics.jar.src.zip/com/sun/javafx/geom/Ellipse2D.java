/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ellipse2D
/*     */   extends RectangularShape
/*     */ {
/*     */   public float x;
/*     */   public float y;
/*     */   public float width;
/*     */   public float height;
/*     */   
/*     */   public Ellipse2D() {}
/*     */   
/*     */   public Ellipse2D(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  77 */     setFrame(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getX() {
/*  86 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getY() {
/*  94 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWidth() {
/* 102 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHeight() {
/* 110 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 118 */     return (this.width <= 0.0F || this.height <= 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrame(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 133 */     this.x = paramFloat1;
/* 134 */     this.y = paramFloat2;
/* 135 */     this.width = paramFloat3;
/* 136 */     this.height = paramFloat4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds getBounds() {
/* 143 */     return new RectBounds(this.x, this.y, this.x + this.width, this.y + this.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/* 152 */     float f1 = this.width;
/* 153 */     if (f1 <= 0.0F) {
/* 154 */       return false;
/*     */     }
/* 156 */     float f2 = (paramFloat1 - this.x) / f1 - 0.5F;
/* 157 */     float f3 = this.height;
/* 158 */     if (f3 <= 0.0F) {
/* 159 */       return false;
/*     */     }
/* 161 */     float f4 = (paramFloat2 - this.y) / f3 - 0.5F;
/* 162 */     return (f2 * f2 + f4 * f4 < 0.25F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*     */     float f7, f8;
/* 169 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/* 170 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 174 */     float f1 = this.width;
/* 175 */     if (f1 <= 0.0F) {
/* 176 */       return false;
/*     */     }
/* 178 */     float f2 = (paramFloat1 - this.x) / f1 - 0.5F;
/* 179 */     float f3 = f2 + paramFloat3 / f1;
/* 180 */     float f4 = this.height;
/* 181 */     if (f4 <= 0.0F) {
/* 182 */       return false;
/*     */     }
/* 184 */     float f5 = (paramFloat2 - this.y) / f4 - 0.5F;
/* 185 */     float f6 = f5 + paramFloat4 / f4;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     if (f2 > 0.0F) {
/*     */       
/* 192 */       f7 = f2;
/* 193 */     } else if (f3 < 0.0F) {
/*     */       
/* 195 */       f7 = f3;
/*     */     } else {
/* 197 */       f7 = 0.0F;
/*     */     } 
/* 199 */     if (f5 > 0.0F) {
/*     */       
/* 201 */       f8 = f5;
/* 202 */     } else if (f6 < 0.0F) {
/*     */       
/* 204 */       f8 = f6;
/*     */     } else {
/* 206 */       f8 = 0.0F;
/*     */     } 
/* 208 */     return (f7 * f7 + f8 * f8 < 0.25F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 215 */     return (contains(paramFloat1, paramFloat2) && 
/* 216 */       contains(paramFloat1 + paramFloat3, paramFloat2) && 
/* 217 */       contains(paramFloat1, paramFloat2 + paramFloat4) && 
/* 218 */       contains(paramFloat1 + paramFloat3, paramFloat2 + paramFloat4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/* 237 */     return new EllipseIterator(this, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   public Ellipse2D copy() {
/* 242 */     return new Ellipse2D(this.x, this.y, this.width, this.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 251 */     int i = Float.floatToIntBits(this.x);
/* 252 */     i += Float.floatToIntBits(this.y) * 37;
/* 253 */     i += Float.floatToIntBits(this.width) * 43;
/* 254 */     i += Float.floatToIntBits(this.height) * 47;
/* 255 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 272 */     if (paramObject == this) {
/* 273 */       return true;
/*     */     }
/* 275 */     if (paramObject instanceof Ellipse2D) {
/* 276 */       Ellipse2D ellipse2D = (Ellipse2D)paramObject;
/* 277 */       return (this.x == ellipse2D.x && this.y == ellipse2D.y && this.width == ellipse2D.width && this.height == ellipse2D.height);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 282 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Ellipse2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */