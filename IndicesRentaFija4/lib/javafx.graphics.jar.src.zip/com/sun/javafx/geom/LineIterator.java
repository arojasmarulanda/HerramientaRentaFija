/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LineIterator
/*     */   implements PathIterator
/*     */ {
/*     */   Line2D line;
/*     */   BaseTransform transform;
/*     */   int index;
/*     */   
/*     */   LineIterator(Line2D paramLine2D, BaseTransform paramBaseTransform) {
/*  44 */     this.line = paramLine2D;
/*  45 */     this.transform = paramBaseTransform;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWindingRule() {
/*  55 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDone() {
/*  63 */     return (this.index > 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void next() {
/*  72 */     this.index++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int currentSegment(float[] paramArrayOffloat) {
/*     */     boolean bool;
/*  94 */     if (isDone()) {
/*  95 */       throw new NoSuchElementException("line iterator out of bounds");
/*     */     }
/*     */     
/*  98 */     if (this.index == 0) {
/*  99 */       paramArrayOffloat[0] = this.line.x1;
/* 100 */       paramArrayOffloat[1] = this.line.y1;
/* 101 */       bool = false;
/*     */     } else {
/* 103 */       paramArrayOffloat[0] = this.line.x2;
/* 104 */       paramArrayOffloat[1] = this.line.y2;
/* 105 */       bool = true;
/*     */     } 
/* 107 */     if (this.transform != null) {
/* 108 */       this.transform.transform(paramArrayOffloat, 0, paramArrayOffloat, 0, 1);
/*     */     }
/* 110 */     return bool;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\LineIterator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */