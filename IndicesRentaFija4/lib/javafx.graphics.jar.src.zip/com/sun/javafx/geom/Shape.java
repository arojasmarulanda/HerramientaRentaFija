/*      */ package com.sun.javafx.geom;
/*      */ 
/*      */ import com.sun.javafx.geom.transform.BaseTransform;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Shape
/*      */ {
/*      */   public static final int RECT_INTERSECTS = -2147483648;
/*      */   public static final int OUT_LEFT = 1;
/*      */   public static final int OUT_TOP = 2;
/*      */   public static final int OUT_RIGHT = 4;
/*      */   public static final int OUT_BOTTOM = 8;
/*      */   
/*      */   public abstract RectBounds getBounds();
/*      */   
/*      */   public abstract boolean contains(float paramFloat1, float paramFloat2);
/*      */   
/*      */   public boolean contains(Point2D paramPoint2D) {
/*  104 */     return contains(paramPoint2D.x, paramPoint2D.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean intersects(RectBounds paramRectBounds) {
/*  182 */     float f1 = paramRectBounds.getMinX();
/*  183 */     float f2 = paramRectBounds.getMinY();
/*  184 */     float f3 = paramRectBounds.getMaxX() - f1;
/*  185 */     float f4 = paramRectBounds.getMaxY() - f2;
/*  186 */     return intersects(f1, f2, f3, f4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(RectBounds paramRectBounds) {
/*  263 */     float f1 = paramRectBounds.getMinX();
/*  264 */     float f2 = paramRectBounds.getMinY();
/*  265 */     float f3 = paramRectBounds.getMaxX() - f1;
/*  266 */     float f4 = paramRectBounds.getMaxY() - f2;
/*  267 */     return contains(f1, f2, f3, f4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract PathIterator getPathIterator(BaseTransform paramBaseTransform);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract PathIterator getPathIterator(BaseTransform paramBaseTransform, float paramFloat);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Shape copy();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int pointCrossingsForPath(PathIterator paramPathIterator, float paramFloat1, float paramFloat2) {
/*  361 */     if (paramPathIterator.isDone()) {
/*  362 */       return 0;
/*      */     }
/*  364 */     float[] arrayOfFloat = new float[6];
/*  365 */     if (paramPathIterator.currentSegment(arrayOfFloat) != 0) {
/*  366 */       throw new IllegalPathStateException("missing initial moveto in path definition");
/*      */     }
/*      */     
/*  369 */     paramPathIterator.next();
/*  370 */     float f1 = arrayOfFloat[0];
/*  371 */     float f2 = arrayOfFloat[1];
/*  372 */     float f3 = f1;
/*  373 */     float f4 = f2;
/*      */     
/*  375 */     int i = 0;
/*  376 */     while (!paramPathIterator.isDone()) {
/*  377 */       float f5, f6; switch (paramPathIterator.currentSegment(arrayOfFloat)) {
/*      */         case 0:
/*  379 */           if (f4 != f2) {
/*  380 */             i += pointCrossingsForLine(paramFloat1, paramFloat2, f3, f4, f1, f2);
/*      */           }
/*      */ 
/*      */           
/*  384 */           f1 = f3 = arrayOfFloat[0];
/*  385 */           f2 = f4 = arrayOfFloat[1];
/*      */           break;
/*      */         case 1:
/*  388 */           f5 = arrayOfFloat[0];
/*  389 */           f6 = arrayOfFloat[1];
/*  390 */           i += pointCrossingsForLine(paramFloat1, paramFloat2, f3, f4, f5, f6);
/*      */ 
/*      */           
/*  393 */           f3 = f5;
/*  394 */           f4 = f6;
/*      */           break;
/*      */         case 2:
/*  397 */           f5 = arrayOfFloat[2];
/*  398 */           f6 = arrayOfFloat[3];
/*  399 */           i += pointCrossingsForQuad(paramFloat1, paramFloat2, f3, f4, arrayOfFloat[0], arrayOfFloat[1], f5, f6, 0);
/*      */ 
/*      */ 
/*      */           
/*  403 */           f3 = f5;
/*  404 */           f4 = f6;
/*      */           break;
/*      */         case 3:
/*  407 */           f5 = arrayOfFloat[4];
/*  408 */           f6 = arrayOfFloat[5];
/*  409 */           i += pointCrossingsForCubic(paramFloat1, paramFloat2, f3, f4, arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3], f5, f6, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  414 */           f3 = f5;
/*  415 */           f4 = f6;
/*      */           break;
/*      */         case 4:
/*  418 */           if (f4 != f2) {
/*  419 */             i += pointCrossingsForLine(paramFloat1, paramFloat2, f3, f4, f1, f2);
/*      */           }
/*      */ 
/*      */           
/*  423 */           f3 = f1;
/*  424 */           f4 = f2;
/*      */           break;
/*      */       } 
/*  427 */       paramPathIterator.next();
/*      */     } 
/*  429 */     if (f4 != f2) {
/*  430 */       i += pointCrossingsForLine(paramFloat1, paramFloat2, f3, f4, f1, f2);
/*      */     }
/*      */ 
/*      */     
/*  434 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int pointCrossingsForLine(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  448 */     if (paramFloat2 < paramFloat4 && paramFloat2 < paramFloat6) return 0; 
/*  449 */     if (paramFloat2 >= paramFloat4 && paramFloat2 >= paramFloat6) return 0;
/*      */     
/*  451 */     if (paramFloat1 >= paramFloat3 && paramFloat1 >= paramFloat5) return 0; 
/*  452 */     if (paramFloat1 < paramFloat3 && paramFloat1 < paramFloat5) return (paramFloat4 < paramFloat6) ? 1 : -1; 
/*  453 */     float f = paramFloat3 + (paramFloat2 - paramFloat4) * (paramFloat5 - paramFloat3) / (paramFloat6 - paramFloat4);
/*  454 */     if (paramFloat1 >= f) return 0; 
/*  455 */     return (paramFloat4 < paramFloat6) ? 1 : -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int pointCrossingsForQuad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, int paramInt) {
/*  473 */     if (paramFloat2 < paramFloat4 && paramFloat2 < paramFloat6 && paramFloat2 < paramFloat8) return 0; 
/*  474 */     if (paramFloat2 >= paramFloat4 && paramFloat2 >= paramFloat6 && paramFloat2 >= paramFloat8) return 0;
/*      */     
/*  476 */     if (paramFloat1 >= paramFloat3 && paramFloat1 >= paramFloat5 && paramFloat1 >= paramFloat7) return 0; 
/*  477 */     if (paramFloat1 < paramFloat3 && paramFloat1 < paramFloat5 && paramFloat1 < paramFloat7) {
/*  478 */       if (paramFloat2 >= paramFloat4)
/*  479 */       { if (paramFloat2 < paramFloat8) return 1;
/*      */          }
/*      */       
/*  482 */       else if (paramFloat2 >= paramFloat8) { return -1; }
/*      */ 
/*      */       
/*  485 */       return 0;
/*      */     } 
/*      */     
/*  488 */     if (paramInt > 52) return pointCrossingsForLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat7, paramFloat8); 
/*  489 */     float f1 = (paramFloat3 + paramFloat5) / 2.0F;
/*  490 */     float f2 = (paramFloat4 + paramFloat6) / 2.0F;
/*  491 */     float f3 = (paramFloat5 + paramFloat7) / 2.0F;
/*  492 */     float f4 = (paramFloat6 + paramFloat8) / 2.0F;
/*  493 */     paramFloat5 = (f1 + f3) / 2.0F;
/*  494 */     paramFloat6 = (f2 + f4) / 2.0F;
/*  495 */     if (Float.isNaN(paramFloat5) || Float.isNaN(paramFloat6))
/*      */     {
/*      */ 
/*      */       
/*  499 */       return 0;
/*      */     }
/*  501 */     return pointCrossingsForQuad(paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, paramFloat5, paramFloat6, paramInt + 1) + 
/*      */ 
/*      */       
/*  504 */       pointCrossingsForQuad(paramFloat1, paramFloat2, paramFloat5, paramFloat6, f3, f4, paramFloat7, paramFloat8, paramInt + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int pointCrossingsForCubic(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, int paramInt) {
/*  525 */     if (paramFloat2 < paramFloat4 && paramFloat2 < paramFloat6 && paramFloat2 < paramFloat8 && paramFloat2 < paramFloat10) return 0; 
/*  526 */     if (paramFloat2 >= paramFloat4 && paramFloat2 >= paramFloat6 && paramFloat2 >= paramFloat8 && paramFloat2 >= paramFloat10) return 0;
/*      */     
/*  528 */     if (paramFloat1 >= paramFloat3 && paramFloat1 >= paramFloat5 && paramFloat1 >= paramFloat7 && paramFloat1 >= paramFloat9) return 0; 
/*  529 */     if (paramFloat1 < paramFloat3 && paramFloat1 < paramFloat5 && paramFloat1 < paramFloat7 && paramFloat1 < paramFloat9) {
/*  530 */       if (paramFloat2 >= paramFloat4)
/*  531 */       { if (paramFloat2 < paramFloat10) return 1;
/*      */          }
/*      */       
/*  534 */       else if (paramFloat2 >= paramFloat10) { return -1; }
/*      */ 
/*      */       
/*  537 */       return 0;
/*      */     } 
/*      */     
/*  540 */     if (paramInt > 52) return pointCrossingsForLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat9, paramFloat10); 
/*  541 */     float f1 = (paramFloat5 + paramFloat7) / 2.0F;
/*  542 */     float f2 = (paramFloat6 + paramFloat8) / 2.0F;
/*  543 */     paramFloat5 = (paramFloat3 + paramFloat5) / 2.0F;
/*  544 */     paramFloat6 = (paramFloat4 + paramFloat6) / 2.0F;
/*  545 */     paramFloat7 = (paramFloat7 + paramFloat9) / 2.0F;
/*  546 */     paramFloat8 = (paramFloat8 + paramFloat10) / 2.0F;
/*  547 */     float f3 = (paramFloat5 + f1) / 2.0F;
/*  548 */     float f4 = (paramFloat6 + f2) / 2.0F;
/*  549 */     float f5 = (f1 + paramFloat7) / 2.0F;
/*  550 */     float f6 = (f2 + paramFloat8) / 2.0F;
/*  551 */     f1 = (f3 + f5) / 2.0F;
/*  552 */     f2 = (f4 + f6) / 2.0F;
/*  553 */     if (Float.isNaN(f1) || Float.isNaN(f2))
/*      */     {
/*      */ 
/*      */       
/*  557 */       return 0;
/*      */     }
/*  559 */     return pointCrossingsForCubic(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, f3, f4, f1, f2, paramInt + 1) + 
/*      */ 
/*      */       
/*  562 */       pointCrossingsForCubic(paramFloat1, paramFloat2, f1, f2, f5, f6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramInt + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int rectCrossingsForPath(PathIterator paramPathIterator, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  615 */     if (paramFloat3 <= paramFloat1 || paramFloat4 <= paramFloat2) {
/*  616 */       return 0;
/*      */     }
/*  618 */     if (paramPathIterator.isDone()) {
/*  619 */       return 0;
/*      */     }
/*  621 */     float[] arrayOfFloat = new float[6];
/*  622 */     if (paramPathIterator.currentSegment(arrayOfFloat) != 0) {
/*  623 */       throw new IllegalPathStateException("missing initial moveto in path definition");
/*      */     }
/*      */     
/*  626 */     paramPathIterator.next();
/*      */     
/*  628 */     float f3 = arrayOfFloat[0], f1 = f3;
/*  629 */     float f4 = arrayOfFloat[1], f2 = f4;
/*  630 */     int i = 0;
/*  631 */     while (i != Integer.MIN_VALUE && !paramPathIterator.isDone()) {
/*  632 */       float f5, f6; switch (paramPathIterator.currentSegment(arrayOfFloat)) {
/*      */         case 0:
/*  634 */           if (f1 != f3 || f2 != f4) {
/*  635 */             i = rectCrossingsForLine(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, f3, f4);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  643 */           f3 = f1 = arrayOfFloat[0];
/*  644 */           f4 = f2 = arrayOfFloat[1];
/*      */           break;
/*      */         case 1:
/*  647 */           f5 = arrayOfFloat[0];
/*  648 */           f6 = arrayOfFloat[1];
/*  649 */           i = rectCrossingsForLine(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, f5, f6);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  654 */           f1 = f5;
/*  655 */           f2 = f6;
/*      */           break;
/*      */         case 2:
/*  658 */           f5 = arrayOfFloat[2];
/*  659 */           f6 = arrayOfFloat[3];
/*  660 */           i = rectCrossingsForQuad(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, arrayOfFloat[0], arrayOfFloat[1], f5, f6, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  666 */           f1 = f5;
/*  667 */           f2 = f6;
/*      */           break;
/*      */         case 3:
/*  670 */           f5 = arrayOfFloat[4];
/*  671 */           f6 = arrayOfFloat[5];
/*  672 */           i = rectCrossingsForCubic(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3], f5, f6, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  679 */           f1 = f5;
/*  680 */           f2 = f6;
/*      */           break;
/*      */         case 4:
/*  683 */           if (f1 != f3 || f2 != f4) {
/*  684 */             i = rectCrossingsForLine(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, f3, f4);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  690 */           f1 = f3;
/*  691 */           f2 = f4;
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/*  696 */       paramPathIterator.next();
/*      */     } 
/*  698 */     if (i != Integer.MIN_VALUE && (f1 != f3 || f2 != f4)) {
/*  699 */       i = rectCrossingsForLine(i, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, f3, f4);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  707 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int rectCrossingsForLine(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/*  721 */     if (paramFloat6 >= paramFloat4 && paramFloat8 >= paramFloat4) return paramInt; 
/*  722 */     if (paramFloat6 <= paramFloat2 && paramFloat8 <= paramFloat2) return paramInt; 
/*  723 */     if (paramFloat5 <= paramFloat1 && paramFloat7 <= paramFloat1) return paramInt; 
/*  724 */     if (paramFloat5 >= paramFloat3 && paramFloat7 >= paramFloat3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  730 */       if (paramFloat6 < paramFloat8) {
/*      */ 
/*      */         
/*  733 */         if (paramFloat6 <= paramFloat2) paramInt++; 
/*  734 */         if (paramFloat8 >= paramFloat4) paramInt++; 
/*  735 */       } else if (paramFloat8 < paramFloat6) {
/*      */ 
/*      */         
/*  738 */         if (paramFloat8 <= paramFloat2) paramInt--; 
/*  739 */         if (paramFloat6 >= paramFloat4) paramInt--; 
/*      */       } 
/*  741 */       return paramInt;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  747 */     if ((paramFloat5 > paramFloat1 && paramFloat5 < paramFloat3 && paramFloat6 > paramFloat2 && paramFloat6 < paramFloat4) || (paramFloat7 > paramFloat1 && paramFloat7 < paramFloat3 && paramFloat8 > paramFloat2 && paramFloat8 < paramFloat4))
/*      */     {
/*      */       
/*  750 */       return Integer.MIN_VALUE;
/*      */     }
/*      */ 
/*      */     
/*  754 */     float f1 = paramFloat5;
/*  755 */     if (paramFloat6 < paramFloat2) {
/*  756 */       f1 += (paramFloat2 - paramFloat6) * (paramFloat7 - paramFloat5) / (paramFloat8 - paramFloat6);
/*  757 */     } else if (paramFloat6 > paramFloat4) {
/*  758 */       f1 += (paramFloat4 - paramFloat6) * (paramFloat7 - paramFloat5) / (paramFloat8 - paramFloat6);
/*      */     } 
/*  760 */     float f2 = paramFloat7;
/*  761 */     if (paramFloat8 < paramFloat2) {
/*  762 */       f2 += (paramFloat2 - paramFloat8) * (paramFloat5 - paramFloat7) / (paramFloat6 - paramFloat8);
/*  763 */     } else if (paramFloat8 > paramFloat4) {
/*  764 */       f2 += (paramFloat4 - paramFloat8) * (paramFloat5 - paramFloat7) / (paramFloat6 - paramFloat8);
/*      */     } 
/*  766 */     if (f1 <= paramFloat1 && f2 <= paramFloat1) return paramInt; 
/*  767 */     if (f1 >= paramFloat3 && f2 >= paramFloat3) {
/*  768 */       if (paramFloat6 < paramFloat8) {
/*      */ 
/*      */         
/*  771 */         if (paramFloat6 <= paramFloat2) paramInt++; 
/*  772 */         if (paramFloat8 >= paramFloat4) paramInt++; 
/*  773 */       } else if (paramFloat8 < paramFloat6) {
/*      */ 
/*      */         
/*  776 */         if (paramFloat8 <= paramFloat2) paramInt--; 
/*  777 */         if (paramFloat6 >= paramFloat4) paramInt--; 
/*      */       } 
/*  779 */       return paramInt;
/*      */     } 
/*  781 */     return Integer.MIN_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int rectCrossingsForQuad(int paramInt1, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, int paramInt2) {
/*  797 */     if (paramFloat6 >= paramFloat4 && paramFloat8 >= paramFloat4 && paramFloat10 >= paramFloat4) return paramInt1; 
/*  798 */     if (paramFloat6 <= paramFloat2 && paramFloat8 <= paramFloat2 && paramFloat10 <= paramFloat2) return paramInt1; 
/*  799 */     if (paramFloat5 <= paramFloat1 && paramFloat7 <= paramFloat1 && paramFloat9 <= paramFloat1) return paramInt1; 
/*  800 */     if (paramFloat5 >= paramFloat3 && paramFloat7 >= paramFloat3 && paramFloat9 >= paramFloat3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  809 */       if (paramFloat6 < paramFloat10) {
/*      */         
/*  811 */         if (paramFloat6 <= paramFloat2 && paramFloat10 > paramFloat2) paramInt1++; 
/*  812 */         if (paramFloat6 < paramFloat4 && paramFloat10 >= paramFloat4) paramInt1++; 
/*  813 */       } else if (paramFloat10 < paramFloat6) {
/*      */         
/*  815 */         if (paramFloat10 <= paramFloat2 && paramFloat6 > paramFloat2) paramInt1--; 
/*  816 */         if (paramFloat10 < paramFloat4 && paramFloat6 >= paramFloat4) paramInt1--; 
/*      */       } 
/*  818 */       return paramInt1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  823 */     if ((paramFloat5 < paramFloat3 && paramFloat5 > paramFloat1 && paramFloat6 < paramFloat4 && paramFloat6 > paramFloat2) || (paramFloat9 < paramFloat3 && paramFloat9 > paramFloat1 && paramFloat10 < paramFloat4 && paramFloat10 > paramFloat2))
/*      */     {
/*      */       
/*  826 */       return Integer.MIN_VALUE;
/*      */     }
/*      */ 
/*      */     
/*  830 */     if (paramInt2 > 52) {
/*  831 */       return rectCrossingsForLine(paramInt1, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat9, paramFloat10);
/*      */     }
/*      */ 
/*      */     
/*  835 */     float f1 = (paramFloat5 + paramFloat7) / 2.0F;
/*  836 */     float f2 = (paramFloat6 + paramFloat8) / 2.0F;
/*  837 */     float f3 = (paramFloat7 + paramFloat9) / 2.0F;
/*  838 */     float f4 = (paramFloat8 + paramFloat10) / 2.0F;
/*  839 */     paramFloat7 = (f1 + f3) / 2.0F;
/*  840 */     paramFloat8 = (f2 + f4) / 2.0F;
/*  841 */     if (Float.isNaN(paramFloat7) || Float.isNaN(paramFloat8))
/*      */     {
/*      */ 
/*      */       
/*  845 */       return 0;
/*      */     }
/*  847 */     paramInt1 = rectCrossingsForQuad(paramInt1, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, f1, f2, paramFloat7, paramFloat8, paramInt2 + 1);
/*      */ 
/*      */ 
/*      */     
/*  851 */     if (paramInt1 != Integer.MIN_VALUE) {
/*  852 */       paramInt1 = rectCrossingsForQuad(paramInt1, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat7, paramFloat8, f3, f4, paramFloat9, paramFloat10, paramInt2 + 1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  857 */     return paramInt1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int rectCrossingsForCubic(int paramInt1, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, int paramInt2) {
/*  874 */     if (paramFloat6 >= paramFloat4 && paramFloat8 >= paramFloat4 && paramFloat10 >= paramFloat4 && paramFloat12 >= paramFloat4) {
/*  875 */       return paramInt1;
/*      */     }
/*  877 */     if (paramFloat6 <= paramFloat2 && paramFloat8 <= paramFloat2 && paramFloat10 <= paramFloat2 && paramFloat12 <= paramFloat2) {
/*  878 */       return paramInt1;
/*      */     }
/*  880 */     if (paramFloat5 <= paramFloat1 && paramFloat7 <= paramFloat1 && paramFloat9 <= paramFloat1 && paramFloat11 <= paramFloat1) {
/*  881 */       return paramInt1;
/*      */     }
/*  883 */     if (paramFloat5 >= paramFloat3 && paramFloat7 >= paramFloat3 && paramFloat9 >= paramFloat3 && paramFloat11 >= paramFloat3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  892 */       if (paramFloat6 < paramFloat12) {
/*      */         
/*  894 */         if (paramFloat6 <= paramFloat2 && paramFloat12 > paramFloat2) paramInt1++; 
/*  895 */         if (paramFloat6 < paramFloat4 && paramFloat12 >= paramFloat4) paramInt1++; 
/*  896 */       } else if (paramFloat12 < paramFloat6) {
/*      */         
/*  898 */         if (paramFloat12 <= paramFloat2 && paramFloat6 > paramFloat2) paramInt1--; 
/*  899 */         if (paramFloat12 < paramFloat4 && paramFloat6 >= paramFloat4) paramInt1--; 
/*      */       } 
/*  901 */       return paramInt1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  906 */     if ((paramFloat5 > paramFloat1 && paramFloat5 < paramFloat3 && paramFloat6 > paramFloat2 && paramFloat6 < paramFloat4) || (paramFloat11 > paramFloat1 && paramFloat11 < paramFloat3 && paramFloat12 > paramFloat2 && paramFloat12 < paramFloat4))
/*      */     {
/*      */       
/*  909 */       return Integer.MIN_VALUE;
/*      */     }
/*      */ 
/*      */     
/*  913 */     if (paramInt2 > 52) {
/*  914 */       return rectCrossingsForLine(paramInt1, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat11, paramFloat12);
/*      */     }
/*      */ 
/*      */     
/*  918 */     float f1 = (paramFloat7 + paramFloat9) / 2.0F;
/*  919 */     float f2 = (paramFloat8 + paramFloat10) / 2.0F;
/*  920 */     paramFloat7 = (paramFloat5 + paramFloat7) / 2.0F;
/*  921 */     paramFloat8 = (paramFloat6 + paramFloat8) / 2.0F;
/*  922 */     paramFloat9 = (paramFloat9 + paramFloat11) / 2.0F;
/*  923 */     paramFloat10 = (paramFloat10 + paramFloat12) / 2.0F;
/*  924 */     float f3 = (paramFloat7 + f1) / 2.0F;
/*  925 */     float f4 = (paramFloat8 + f2) / 2.0F;
/*  926 */     float f5 = (f1 + paramFloat9) / 2.0F;
/*  927 */     float f6 = (f2 + paramFloat10) / 2.0F;
/*  928 */     f1 = (f3 + f5) / 2.0F;
/*  929 */     f2 = (f4 + f6) / 2.0F;
/*  930 */     if (Float.isNaN(f1) || Float.isNaN(f2))
/*      */     {
/*      */ 
/*      */       
/*  934 */       return 0;
/*      */     }
/*  936 */     paramInt1 = rectCrossingsForCubic(paramInt1, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, f3, f4, f1, f2, paramInt2 + 1);
/*      */ 
/*      */ 
/*      */     
/*  940 */     if (paramInt1 != Integer.MIN_VALUE) {
/*  941 */       paramInt1 = rectCrossingsForCubic(paramInt1, paramFloat1, paramFloat2, paramFloat3, paramFloat4, f1, f2, f5, f6, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramInt2 + 1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  946 */     return paramInt1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean intersectsLine(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/*      */     int j;
/*  957 */     if ((j = outcode(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat7, paramFloat8)) == 0)
/*  958 */       return true; 
/*      */     int i;
/*  960 */     while ((i = outcode(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6)) != 0) {
/*  961 */       if ((i & j) != 0) {
/*  962 */         return false;
/*      */       }
/*  964 */       if ((i & 0x5) != 0) {
/*  965 */         if ((i & 0x4) != 0) {
/*  966 */           paramFloat1 += paramFloat3;
/*      */         }
/*  968 */         paramFloat6 += (paramFloat1 - paramFloat5) * (paramFloat8 - paramFloat6) / (paramFloat7 - paramFloat5);
/*  969 */         paramFloat5 = paramFloat1; continue;
/*      */       } 
/*  971 */       if ((i & 0x8) != 0) {
/*  972 */         paramFloat2 += paramFloat4;
/*      */       }
/*  974 */       paramFloat5 += (paramFloat2 - paramFloat6) * (paramFloat7 - paramFloat5) / (paramFloat8 - paramFloat6);
/*  975 */       paramFloat6 = paramFloat2;
/*      */     } 
/*      */     
/*  978 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int outcode(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  994 */     int i = 0;
/*  995 */     if (paramFloat3 <= 0.0F) {
/*  996 */       i |= 0x5;
/*  997 */     } else if (paramFloat5 < paramFloat1) {
/*  998 */       i |= 0x1;
/*  999 */     } else if (paramFloat5 > paramFloat1 + paramFloat3) {
/* 1000 */       i |= 0x4;
/*      */     } 
/* 1002 */     if (paramFloat4 <= 0.0F) {
/* 1003 */       i |= 0xA;
/* 1004 */     } else if (paramFloat6 < paramFloat2) {
/* 1005 */       i |= 0x2;
/* 1006 */     } else if (paramFloat6 > paramFloat2 + paramFloat4) {
/* 1007 */       i |= 0x8;
/*      */     } 
/* 1009 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void accumulate(float[] paramArrayOffloat, Shape paramShape, BaseTransform paramBaseTransform) {
/* 1050 */     PathIterator pathIterator = paramShape.getPathIterator(paramBaseTransform);
/* 1051 */     float[] arrayOfFloat = new float[6];
/* 1052 */     float f1 = 0.0F, f2 = 0.0F, f3 = 0.0F, f4 = 0.0F;
/* 1053 */     while (!pathIterator.isDone()) {
/* 1054 */       float f5, f6; switch (pathIterator.currentSegment(arrayOfFloat)) {
/*      */         case 0:
/* 1056 */           f1 = arrayOfFloat[0];
/* 1057 */           f2 = arrayOfFloat[1];
/*      */         
/*      */         case 1:
/* 1060 */           f3 = arrayOfFloat[0];
/* 1061 */           f4 = arrayOfFloat[1];
/* 1062 */           if (paramArrayOffloat[0] > f3) paramArrayOffloat[0] = f3; 
/* 1063 */           if (paramArrayOffloat[1] > f4) paramArrayOffloat[1] = f4; 
/* 1064 */           if (paramArrayOffloat[2] < f3) paramArrayOffloat[2] = f3; 
/* 1065 */           if (paramArrayOffloat[3] < f4) paramArrayOffloat[3] = f4; 
/*      */           break;
/*      */         case 2:
/* 1068 */           f5 = arrayOfFloat[2];
/* 1069 */           f6 = arrayOfFloat[3];
/* 1070 */           if (paramArrayOffloat[0] > f5) paramArrayOffloat[0] = f5; 
/* 1071 */           if (paramArrayOffloat[1] > f6) paramArrayOffloat[1] = f6; 
/* 1072 */           if (paramArrayOffloat[2] < f5) paramArrayOffloat[2] = f5; 
/* 1073 */           if (paramArrayOffloat[3] < f6) paramArrayOffloat[3] = f6; 
/* 1074 */           if (paramArrayOffloat[0] > arrayOfFloat[0] || paramArrayOffloat[2] < arrayOfFloat[0]) {
/* 1075 */             accumulateQuad(paramArrayOffloat, 0, f3, arrayOfFloat[0], f5);
/*      */           }
/* 1077 */           if (paramArrayOffloat[1] > arrayOfFloat[1] || paramArrayOffloat[3] < arrayOfFloat[1]) {
/* 1078 */             accumulateQuad(paramArrayOffloat, 1, f4, arrayOfFloat[1], f6);
/*      */           }
/* 1080 */           f3 = f5;
/* 1081 */           f4 = f6;
/*      */           break;
/*      */         case 3:
/* 1084 */           f5 = arrayOfFloat[4];
/* 1085 */           f6 = arrayOfFloat[5];
/* 1086 */           if (paramArrayOffloat[0] > f5) paramArrayOffloat[0] = f5; 
/* 1087 */           if (paramArrayOffloat[1] > f6) paramArrayOffloat[1] = f6; 
/* 1088 */           if (paramArrayOffloat[2] < f5) paramArrayOffloat[2] = f5; 
/* 1089 */           if (paramArrayOffloat[3] < f6) paramArrayOffloat[3] = f6; 
/* 1090 */           if (paramArrayOffloat[0] > arrayOfFloat[0] || paramArrayOffloat[2] < arrayOfFloat[0] || paramArrayOffloat[0] > arrayOfFloat[2] || paramArrayOffloat[2] < arrayOfFloat[2])
/*      */           {
/*      */             
/* 1093 */             accumulateCubic(paramArrayOffloat, 0, f3, arrayOfFloat[0], arrayOfFloat[2], f5);
/*      */           }
/* 1095 */           if (paramArrayOffloat[1] > arrayOfFloat[1] || paramArrayOffloat[3] < arrayOfFloat[1] || paramArrayOffloat[1] > arrayOfFloat[3] || paramArrayOffloat[3] < arrayOfFloat[3])
/*      */           {
/*      */             
/* 1098 */             accumulateCubic(paramArrayOffloat, 1, f4, arrayOfFloat[1], arrayOfFloat[3], f6);
/*      */           }
/* 1100 */           f3 = f5;
/* 1101 */           f4 = f6;
/*      */           break;
/*      */         case 4:
/* 1104 */           f3 = f1;
/* 1105 */           f4 = f2;
/*      */           break;
/*      */       } 
/* 1108 */       pathIterator.next();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void accumulateQuad(float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 1127 */     float f1 = paramFloat1 - paramFloat2;
/* 1128 */     float f2 = paramFloat3 - paramFloat2 + f1;
/* 1129 */     if (f2 != 0.0F) {
/* 1130 */       float f = f1 / f2;
/* 1131 */       if (f > 0.0F && f < 1.0F) {
/* 1132 */         float f3 = 1.0F - f;
/* 1133 */         float f4 = paramFloat1 * f3 * f3 + 2.0F * paramFloat2 * f * f3 + paramFloat3 * f * f;
/* 1134 */         if (paramArrayOffloat[paramInt] > f4) paramArrayOffloat[paramInt] = f4; 
/* 1135 */         if (paramArrayOffloat[paramInt + 2] < f4) paramArrayOffloat[paramInt + 2] = f4;
/*      */       
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void accumulateCubic(float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 1156 */     float f1 = paramFloat2 - paramFloat1;
/* 1157 */     float f2 = 2.0F * (paramFloat3 - paramFloat2 - f1);
/* 1158 */     float f3 = paramFloat4 - paramFloat3 - f2 - f1;
/* 1159 */     if (f3 == 0.0F) {
/*      */       
/* 1161 */       if (f2 == 0.0F) {
/*      */         return;
/*      */       }
/*      */       
/* 1165 */       accumulateCubic(paramArrayOffloat, paramInt, -f1 / f2, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */     } else {
/*      */       
/* 1168 */       float f4 = f2 * f2 - 4.0F * f3 * f1;
/* 1169 */       if (f4 < 0.0F) {
/*      */         return;
/*      */       }
/*      */       
/* 1173 */       f4 = (float)Math.sqrt(f4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1179 */       if (f2 < 0.0F) {
/* 1180 */         f4 = -f4;
/*      */       }
/* 1182 */       float f5 = (f2 + f4) / -2.0F;
/*      */       
/* 1184 */       accumulateCubic(paramArrayOffloat, paramInt, f5 / f3, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 1185 */       if (f5 != 0.0F) {
/* 1186 */         accumulateCubic(paramArrayOffloat, paramInt, f1 / f5, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void accumulateCubic(float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
/* 1194 */     if (paramFloat1 > 0.0F && paramFloat1 < 1.0F) {
/* 1195 */       float f1 = 1.0F - paramFloat1;
/* 1196 */       float f2 = paramFloat2 * f1 * f1 * f1 + 3.0F * paramFloat3 * paramFloat1 * f1 * f1 + 3.0F * paramFloat4 * paramFloat1 * paramFloat1 * f1 + paramFloat5 * paramFloat1 * paramFloat1 * paramFloat1;
/*      */ 
/*      */ 
/*      */       
/* 1200 */       if (paramArrayOffloat[paramInt] > f2) paramArrayOffloat[paramInt] = f2; 
/* 1201 */       if (paramArrayOffloat[paramInt + 2] < f2) paramArrayOffloat[paramInt + 2] = f2; 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Shape.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */