/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoundRectangle2D
/*     */   extends RectangularShape
/*     */ {
/*     */   public float x;
/*     */   public float y;
/*     */   public float width;
/*     */   public float height;
/*     */   public float arcWidth;
/*     */   public float arcHeight;
/*     */   
/*     */   public RoundRectangle2D() {}
/*     */   
/*     */   public RoundRectangle2D(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  97 */     setRoundRect(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getX() {
/* 105 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getY() {
/* 113 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWidth() {
/* 121 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHeight() {
/* 129 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 137 */     return (this.width <= 0.0F || this.height <= 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRoundRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 161 */     this.x = paramFloat1;
/* 162 */     this.y = paramFloat2;
/* 163 */     this.width = paramFloat3;
/* 164 */     this.height = paramFloat4;
/* 165 */     this.arcWidth = paramFloat5;
/* 166 */     this.arcHeight = paramFloat6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds getBounds() {
/* 174 */     return new RectBounds(this.x, this.y, this.x + this.width, this.y + this.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRoundRect(RoundRectangle2D paramRoundRectangle2D) {
/* 183 */     setRoundRect(paramRoundRectangle2D.x, paramRoundRectangle2D.y, paramRoundRectangle2D.width, paramRoundRectangle2D.height, paramRoundRectangle2D.arcWidth, paramRoundRectangle2D.arcHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrame(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 191 */     setRoundRect(paramFloat1, paramFloat2, paramFloat3, paramFloat4, this.arcWidth, this.arcHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/* 199 */     if (isEmpty()) return false; 
/* 200 */     float f1 = this.x;
/* 201 */     float f2 = this.y;
/* 202 */     float f3 = f1 + this.width;
/* 203 */     float f4 = f2 + this.height;
/*     */     
/* 205 */     if (paramFloat1 < f1 || paramFloat2 < f2 || paramFloat1 >= f3 || paramFloat2 >= f4) {
/* 206 */       return false;
/*     */     }
/* 208 */     float f5 = Math.min(this.width, Math.abs(this.arcWidth)) / 2.0F;
/* 209 */     float f6 = Math.min(this.height, Math.abs(this.arcHeight)) / 2.0F;
/*     */ 
/*     */     
/* 212 */     if (paramFloat1 >= (f1 += f5) && paramFloat1 < (f1 = f3 - f5)) {
/* 213 */       return true;
/*     */     }
/* 215 */     if (paramFloat2 >= (f2 += f6) && paramFloat2 < (f2 = f4 - f6)) {
/* 216 */       return true;
/*     */     }
/* 218 */     paramFloat1 = (paramFloat1 - f1) / f5;
/* 219 */     paramFloat2 = (paramFloat2 - f2) / f6;
/* 220 */     return ((paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2) <= 1.0D);
/*     */   }
/*     */   
/*     */   private int classify(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 224 */     if (paramFloat1 < paramFloat2)
/* 225 */       return 0; 
/* 226 */     if (paramFloat1 < paramFloat2 + paramFloat4)
/* 227 */       return 1; 
/* 228 */     if (paramFloat1 < paramFloat3 - paramFloat4)
/* 229 */       return 2; 
/* 230 */     if (paramFloat1 < paramFloat3) {
/* 231 */       return 3;
/*     */     }
/* 233 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 242 */     if (isEmpty() || paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/* 243 */       return false;
/*     */     }
/* 245 */     float f1 = this.x;
/* 246 */     float f2 = this.y;
/* 247 */     float f3 = f1 + this.width;
/* 248 */     float f4 = f2 + this.height;
/*     */     
/* 250 */     if (paramFloat1 + paramFloat3 <= f1 || paramFloat1 >= f3 || paramFloat2 + paramFloat4 <= f2 || paramFloat2 >= f4) {
/* 251 */       return false;
/*     */     }
/* 253 */     float f5 = Math.min(this.width, Math.abs(this.arcWidth)) / 2.0F;
/* 254 */     float f6 = Math.min(this.height, Math.abs(this.arcHeight)) / 2.0F;
/* 255 */     int i = classify(paramFloat1, f1, f3, f5);
/* 256 */     int j = classify(paramFloat1 + paramFloat3, f1, f3, f5);
/* 257 */     int k = classify(paramFloat2, f2, f4, f6);
/* 258 */     int m = classify(paramFloat2 + paramFloat4, f2, f4, f6);
/*     */     
/* 260 */     if (i == 2 || j == 2 || k == 2 || m == 2) {
/* 261 */       return true;
/*     */     }
/*     */     
/* 264 */     if ((i < 2 && j > 2) || (k < 2 && m > 2)) {
/* 265 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     paramFloat1 = (j == 1) ? (paramFloat1 = paramFloat1 + paramFloat3 - f1 + f5) : (paramFloat1 -= f3 - f5);
/* 274 */     paramFloat2 = (m == 1) ? (paramFloat2 = paramFloat2 + paramFloat4 - f2 + f6) : (paramFloat2 -= f4 - f6);
/* 275 */     paramFloat1 /= f5;
/* 276 */     paramFloat2 /= f6;
/* 277 */     return (paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2 <= 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 285 */     if (isEmpty() || paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/* 286 */       return false;
/*     */     }
/* 288 */     return (contains(paramFloat1, paramFloat2) && 
/* 289 */       contains(paramFloat1 + paramFloat3, paramFloat2) && 
/* 290 */       contains(paramFloat1, paramFloat2 + paramFloat4) && 
/* 291 */       contains(paramFloat1 + paramFloat3, paramFloat2 + paramFloat4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/* 311 */     return new RoundRectIterator(this, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   public RoundRectangle2D copy() {
/* 316 */     return new RoundRectangle2D(this.x, this.y, this.width, this.height, this.arcWidth, this.arcHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 325 */     int i = Float.floatToIntBits(this.x);
/* 326 */     i += Float.floatToIntBits(this.y) * 37;
/* 327 */     i += Float.floatToIntBits(this.width) * 43;
/* 328 */     i += Float.floatToIntBits(this.height) * 47;
/* 329 */     i += Float.floatToIntBits(this.arcWidth) * 53;
/* 330 */     i += Float.floatToIntBits(this.arcHeight) * 59;
/* 331 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 349 */     if (paramObject == this) {
/* 350 */       return true;
/*     */     }
/* 352 */     if (paramObject instanceof RoundRectangle2D) {
/* 353 */       RoundRectangle2D roundRectangle2D = (RoundRectangle2D)paramObject;
/* 354 */       return (this.x == roundRectangle2D.x && this.y == roundRectangle2D.y && this.width == roundRectangle2D.width && this.height == roundRectangle2D.height && this.arcWidth == roundRectangle2D.arcWidth && this.arcHeight == roundRectangle2D.arcHeight);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 361 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\RoundRectangle2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */