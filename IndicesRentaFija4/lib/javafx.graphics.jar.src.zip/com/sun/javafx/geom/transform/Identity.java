/*     */ package com.sun.javafx.geom.transform;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Identity
/*     */   extends BaseTransform
/*     */ {
/*     */   public BaseTransform.Degree getDegree() {
/*  41 */     return BaseTransform.Degree.IDENTITY;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/*  46 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIdentity() {
/*  51 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTranslateOrIdentity() {
/*  56 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean is2D() {
/*  61 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDeterminant() {
/*  66 */     return 1.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public Point2D transform(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/*  71 */     if (paramPoint2D2 == null) paramPoint2D2 = makePoint(paramPoint2D1, paramPoint2D2); 
/*  72 */     paramPoint2D2.setLocation(paramPoint2D1);
/*  73 */     return paramPoint2D2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Point2D inverseTransform(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/*  78 */     if (paramPoint2D2 == null) paramPoint2D2 = makePoint(paramPoint2D1, paramPoint2D2); 
/*  79 */     paramPoint2D2.setLocation(paramPoint2D1);
/*  80 */     return paramPoint2D2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3d transform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/*  85 */     if (paramVec3d2 == null) return new Vec3d(paramVec3d1); 
/*  86 */     paramVec3d2.set(paramVec3d1);
/*  87 */     return paramVec3d2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3d deltaTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/*  92 */     if (paramVec3d2 == null) return new Vec3d(paramVec3d1); 
/*  93 */     paramVec3d2.set(paramVec3d1);
/*  94 */     return paramVec3d2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3d inverseTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/*  99 */     if (paramVec3d2 == null) return new Vec3d(paramVec3d1); 
/* 100 */     paramVec3d2.set(paramVec3d1);
/* 101 */     return paramVec3d2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3d inverseDeltaTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/* 106 */     if (paramVec3d2 == null) return new Vec3d(paramVec3d1); 
/* 107 */     paramVec3d2.set(paramVec3d1);
/* 108 */     return paramVec3d2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 115 */     if (paramArrayOffloat1 != paramArrayOffloat2 || paramInt1 != paramInt2) {
/* 116 */       System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) {
/* 124 */     if (paramArrayOfdouble1 != paramArrayOfdouble2 || paramInt1 != paramInt2) {
/* 125 */       System.arraycopy(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3 * 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(float[] paramArrayOffloat, int paramInt1, double[] paramArrayOfdouble, int paramInt2, int paramInt3) {
/* 133 */     for (byte b = 0; b < paramInt3; b++) {
/* 134 */       paramArrayOfdouble[paramInt2++] = paramArrayOffloat[paramInt1++];
/* 135 */       paramArrayOfdouble[paramInt2++] = paramArrayOffloat[paramInt1++];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(double[] paramArrayOfdouble, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3) {
/* 143 */     for (byte b = 0; b < paramInt3; b++) {
/* 144 */       paramArrayOffloat[paramInt2++] = (float)paramArrayOfdouble[paramInt1++];
/* 145 */       paramArrayOffloat[paramInt2++] = (float)paramArrayOfdouble[paramInt1++];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deltaTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 154 */     if (paramArrayOffloat1 != paramArrayOffloat2 || paramInt1 != paramInt2) {
/* 155 */       System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deltaTransform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) {
/* 164 */     if (paramArrayOfdouble1 != paramArrayOfdouble2 || paramInt1 != paramInt2) {
/* 165 */       System.arraycopy(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3 * 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inverseTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 173 */     if (paramArrayOffloat1 != paramArrayOffloat2 || paramInt1 != paramInt2) {
/* 174 */       System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inverseDeltaTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 182 */     if (paramArrayOffloat1 != paramArrayOffloat2 || paramInt1 != paramInt2) {
/* 183 */       System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inverseTransform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) {
/* 191 */     if (paramArrayOfdouble1 != paramArrayOfdouble2 || paramInt1 != paramInt2) {
/* 192 */       System.arraycopy(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3 * 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds transform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) {
/* 198 */     if (paramBaseBounds2 != paramBaseBounds1) {
/* 199 */       paramBaseBounds2 = paramBaseBounds2.deriveWithNewBounds(paramBaseBounds1);
/*     */     }
/* 201 */     return paramBaseBounds2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void transform(Rectangle paramRectangle1, Rectangle paramRectangle2) {
/* 206 */     if (paramRectangle2 != paramRectangle1) {
/* 207 */       paramRectangle2.setBounds(paramRectangle1);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds inverseTransform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) {
/* 213 */     if (paramBaseBounds2 != paramBaseBounds1) {
/* 214 */       paramBaseBounds2 = paramBaseBounds2.deriveWithNewBounds(paramBaseBounds1);
/*     */     }
/* 216 */     return paramBaseBounds2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void inverseTransform(Rectangle paramRectangle1, Rectangle paramRectangle2) {
/* 221 */     if (paramRectangle2 != paramRectangle1) {
/* 222 */       paramRectangle2.setBounds(paramRectangle1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Shape createTransformedShape(Shape paramShape) {
/* 229 */     return new Path2D(paramShape);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setToIdentity() {}
/*     */ 
/*     */   
/*     */   public void setTransform(BaseTransform paramBaseTransform) {
/* 238 */     if (!paramBaseTransform.isIdentity()) {
/* 239 */       degreeError(BaseTransform.Degree.IDENTITY);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invert() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restoreTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 252 */     if (paramDouble1 != 1.0D || paramDouble2 != 0.0D || paramDouble3 != 0.0D || paramDouble4 != 1.0D || paramDouble5 != 0.0D || paramDouble6 != 0.0D)
/*     */     {
/*     */ 
/*     */       
/* 256 */       degreeError(BaseTransform.Degree.IDENTITY);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restoreTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/* 265 */     if (paramDouble1 != 1.0D || paramDouble2 != 0.0D || paramDouble3 != 0.0D || paramDouble4 != 0.0D || paramDouble5 != 0.0D || paramDouble6 != 1.0D || paramDouble7 != 0.0D || paramDouble8 != 0.0D || paramDouble9 != 0.0D || paramDouble10 != 0.0D || paramDouble11 != 1.0D || paramDouble12 != 0.0D)
/*     */     {
/*     */ 
/*     */       
/* 269 */       degreeError(BaseTransform.Degree.IDENTITY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithTranslation(double paramDouble1, double paramDouble2) {
/* 275 */     return Translate2D.getInstance(paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithPreTranslation(double paramDouble1, double paramDouble2) {
/* 280 */     return Translate2D.getInstance(paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithTranslation(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 285 */     if (paramDouble3 == 0.0D) {
/* 286 */       if (paramDouble1 == 0.0D && paramDouble2 == 0.0D) {
/* 287 */         return this;
/*     */       }
/* 289 */       return new Translate2D(paramDouble1, paramDouble2);
/*     */     } 
/* 291 */     Affine3D affine3D = new Affine3D();
/* 292 */     affine3D.translate(paramDouble1, paramDouble2, paramDouble3);
/* 293 */     return affine3D;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithScale(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 298 */     if (paramDouble3 == 1.0D) {
/* 299 */       if (paramDouble1 == 1.0D && paramDouble2 == 1.0D) {
/* 300 */         return this;
/*     */       }
/* 302 */       Affine2D affine2D = new Affine2D();
/* 303 */       affine2D.scale(paramDouble1, paramDouble2);
/* 304 */       return affine2D;
/*     */     } 
/* 306 */     Affine3D affine3D = new Affine3D();
/* 307 */     affine3D.scale(paramDouble1, paramDouble2, paramDouble3);
/* 308 */     return affine3D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithRotation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 315 */     if (paramDouble1 == 0.0D) {
/* 316 */       return this;
/*     */     }
/* 318 */     if (almostZero(paramDouble2) && almostZero(paramDouble3)) {
/* 319 */       if (paramDouble4 == 0.0D) {
/* 320 */         return this;
/*     */       }
/* 322 */       Affine2D affine2D = new Affine2D();
/* 323 */       if (paramDouble4 > 0.0D) {
/* 324 */         affine2D.rotate(paramDouble1);
/* 325 */       } else if (paramDouble4 < 0.0D) {
/* 326 */         affine2D.rotate(-paramDouble1);
/*     */       } 
/* 328 */       return affine2D;
/*     */     } 
/* 330 */     Affine3D affine3D = new Affine3D();
/* 331 */     affine3D.rotate(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/* 332 */     return affine3D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithConcatenation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 340 */     return getInstance(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithConcatenation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/* 350 */     return getInstance(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramDouble9, paramDouble10, paramDouble11, paramDouble12);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithConcatenation(BaseTransform paramBaseTransform) {
/* 357 */     return getInstance(paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithPreConcatenation(BaseTransform paramBaseTransform) {
/* 362 */     return getInstance(paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithNewTransform(BaseTransform paramBaseTransform) {
/* 367 */     return getInstance(paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform createInverse() {
/* 372 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 377 */     return "Identity[]";
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform copy() {
/* 382 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 387 */     return (paramObject instanceof BaseTransform && ((BaseTransform)paramObject)
/* 388 */       .isIdentity());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 393 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\Identity.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */