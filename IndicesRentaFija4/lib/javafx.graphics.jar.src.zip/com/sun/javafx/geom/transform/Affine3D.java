/*      */ package com.sun.javafx.geom.transform;
/*      */ 
/*      */ import com.sun.javafx.geom.BaseBounds;
/*      */ import com.sun.javafx.geom.Point2D;
/*      */ import com.sun.javafx.geom.Rectangle;
/*      */ import com.sun.javafx.geom.Vec3d;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Affine3D
/*      */   extends AffineBase
/*      */ {
/*      */   private double mxz;
/*      */   private double myz;
/*      */   private double mzx;
/*      */   private double mzy;
/*      */   private double mzz;
/*      */   private double mzt;
/*      */   
/*      */   public Affine3D() {
/*   45 */     this.mxx = this.myy = this.mzz = 1.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Affine3D(BaseTransform paramBaseTransform) {
/*   53 */     setTransform(paramBaseTransform);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Affine3D(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/*   60 */     this.mxx = paramDouble1;
/*   61 */     this.mxy = paramDouble2;
/*   62 */     this.mxz = paramDouble3;
/*   63 */     this.mxt = paramDouble4;
/*      */     
/*   65 */     this.myx = paramDouble5;
/*   66 */     this.myy = paramDouble6;
/*   67 */     this.myz = paramDouble7;
/*   68 */     this.myt = paramDouble8;
/*      */     
/*   70 */     this.mzx = paramDouble9;
/*   71 */     this.mzy = paramDouble10;
/*   72 */     this.mzz = paramDouble11;
/*   73 */     this.mzt = paramDouble12;
/*      */     
/*   75 */     updateState();
/*      */   }
/*      */   
/*      */   public Affine3D(Affine3D paramAffine3D) {
/*   79 */     this.mxx = paramAffine3D.mxx;
/*   80 */     this.mxy = paramAffine3D.mxy;
/*   81 */     this.mxz = paramAffine3D.mxz;
/*   82 */     this.mxt = paramAffine3D.mxt;
/*      */     
/*   84 */     this.myx = paramAffine3D.myx;
/*   85 */     this.myy = paramAffine3D.myy;
/*   86 */     this.myz = paramAffine3D.myz;
/*   87 */     this.myt = paramAffine3D.myt;
/*      */     
/*   89 */     this.mzx = paramAffine3D.mzx;
/*   90 */     this.mzy = paramAffine3D.mzy;
/*   91 */     this.mzz = paramAffine3D.mzz;
/*   92 */     this.mzt = paramAffine3D.mzt;
/*      */     
/*   94 */     this.state = paramAffine3D.state;
/*   95 */     this.type = paramAffine3D.type;
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform copy() {
/*  100 */     return new Affine3D(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform.Degree getDegree() {
/*  105 */     return BaseTransform.Degree.AFFINE_3D;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void reset3Delements() {
/*  110 */     this.mxz = 0.0D;
/*  111 */     this.myz = 0.0D;
/*  112 */     this.mzx = 0.0D;
/*  113 */     this.mzy = 0.0D;
/*  114 */     this.mzz = 1.0D;
/*  115 */     this.mzt = 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void updateState() {
/*  120 */     super.updateState();
/*  121 */     if (!almostZero(this.mxz) || 
/*  122 */       !almostZero(this.myz) || 
/*  123 */       !almostZero(this.mzx) || 
/*  124 */       !almostZero(this.mzy) || 
/*  125 */       !almostOne(this.mzz) || 
/*  126 */       !almostZero(this.mzt)) {
/*      */       
/*  128 */       this.state |= 0x8;
/*  129 */       if (this.type != -1)
/*  130 */         this.type |= 0x80; 
/*      */     } 
/*      */   }
/*      */   
/*      */   public double getMxz() {
/*  135 */     return this.mxz;
/*  136 */   } public double getMyz() { return this.myz; }
/*  137 */   public double getMzx() { return this.mzx; }
/*  138 */   public double getMzy() { return this.mzy; }
/*  139 */   public double getMzz() { return this.mzz; } public double getMzt() {
/*  140 */     return this.mzt;
/*      */   }
/*      */   
/*      */   public double getDeterminant() {
/*  144 */     if ((this.state & 0x8) == 0) {
/*  145 */       return super.getDeterminant();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  150 */     return this.mxx * (this.myy * this.mzz - this.mzy * this.myz) + this.mxy * (this.myz * this.mzx - this.mzz * this.myx) + this.mxz * (this.myx * this.mzy - this.mzx * this.myy);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransform(BaseTransform paramBaseTransform) {
/*  156 */     this.mxx = paramBaseTransform.getMxx();
/*  157 */     this.mxy = paramBaseTransform.getMxy();
/*  158 */     this.mxz = paramBaseTransform.getMxz();
/*  159 */     this.mxt = paramBaseTransform.getMxt();
/*  160 */     this.myx = paramBaseTransform.getMyx();
/*  161 */     this.myy = paramBaseTransform.getMyy();
/*  162 */     this.myz = paramBaseTransform.getMyz();
/*  163 */     this.myt = paramBaseTransform.getMyt();
/*  164 */     this.mzx = paramBaseTransform.getMzx();
/*  165 */     this.mzy = paramBaseTransform.getMzy();
/*  166 */     this.mzz = paramBaseTransform.getMzz();
/*  167 */     this.mzt = paramBaseTransform.getMzt();
/*  168 */     updateState();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/*  175 */     this.mxx = paramDouble1;
/*  176 */     this.mxy = paramDouble2;
/*  177 */     this.mxz = paramDouble3;
/*  178 */     this.mxt = paramDouble4;
/*      */     
/*  180 */     this.myx = paramDouble5;
/*  181 */     this.myy = paramDouble6;
/*  182 */     this.myz = paramDouble7;
/*  183 */     this.myt = paramDouble8;
/*      */     
/*  185 */     this.mzx = paramDouble9;
/*  186 */     this.mzy = paramDouble10;
/*  187 */     this.mzz = paramDouble11;
/*  188 */     this.mzt = paramDouble12;
/*      */     
/*  190 */     updateState();
/*      */   }
/*      */   
/*      */   public void setToTranslation(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  194 */     this.mxx = 1.0D;
/*  195 */     this.mxy = 0.0D;
/*  196 */     this.mxz = 0.0D;
/*  197 */     this.mxt = paramDouble1;
/*      */     
/*  199 */     this.myx = 0.0D;
/*  200 */     this.myy = 1.0D;
/*  201 */     this.myz = 0.0D;
/*  202 */     this.myt = paramDouble2;
/*      */     
/*  204 */     this.mzx = 0.0D;
/*  205 */     this.mzy = 0.0D;
/*  206 */     this.mzz = 1.0D;
/*  207 */     this.mzt = paramDouble3;
/*      */     
/*  209 */     if (paramDouble3 == 0.0D) {
/*  210 */       if (paramDouble1 == 0.0D && paramDouble2 == 0.0D) {
/*  211 */         this.state = 0;
/*  212 */         this.type = 0;
/*      */       } else {
/*  214 */         this.state = 1;
/*  215 */         this.type = 1;
/*      */       }
/*      */     
/*  218 */     } else if (paramDouble1 == 0.0D && paramDouble2 == 0.0D) {
/*  219 */       this.state = 8;
/*  220 */       this.type = 128;
/*      */     } else {
/*  222 */       this.state = 9;
/*  223 */       this.type = 129;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setToScale(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  229 */     this.mxx = paramDouble1;
/*  230 */     this.mxy = 0.0D;
/*  231 */     this.mxz = 0.0D;
/*  232 */     this.mxt = 0.0D;
/*      */     
/*  234 */     this.myx = 0.0D;
/*  235 */     this.myy = paramDouble2;
/*  236 */     this.myz = 0.0D;
/*  237 */     this.myt = 0.0D;
/*      */     
/*  239 */     this.mzx = 0.0D;
/*  240 */     this.mzy = 0.0D;
/*  241 */     this.mzz = paramDouble3;
/*  242 */     this.mzt = 0.0D;
/*      */     
/*  244 */     if (paramDouble3 == 1.0D) {
/*  245 */       if (paramDouble1 == 1.0D && paramDouble2 == 1.0D) {
/*  246 */         this.state = 0;
/*  247 */         this.type = 0;
/*      */       } else {
/*  249 */         this.state = 2;
/*  250 */         this.type = -1;
/*      */       }
/*      */     
/*  253 */     } else if (paramDouble1 == 1.0D && paramDouble2 == 1.0D) {
/*  254 */       this.state = 8;
/*  255 */       this.type = 128;
/*      */     } else {
/*  257 */       this.state = 10;
/*  258 */       this.type = -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToRotation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7) {
/*  267 */     setToRotation(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*  268 */     if (paramDouble5 != 0.0D || paramDouble6 != 0.0D || paramDouble7 != 0.0D) {
/*  269 */       preTranslate(paramDouble5, paramDouble6, paramDouble7);
/*  270 */       translate(-paramDouble5, -paramDouble6, -paramDouble7);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setToRotation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  275 */     double d1 = Math.sqrt(paramDouble2 * paramDouble2 + paramDouble3 * paramDouble3 + paramDouble4 * paramDouble4);
/*      */     
/*  277 */     if (almostZero(d1)) {
/*  278 */       setToIdentity();
/*      */       return;
/*      */     } 
/*  281 */     d1 = 1.0D / d1;
/*  282 */     double d2 = paramDouble2 * d1;
/*  283 */     double d3 = paramDouble3 * d1;
/*  284 */     double d4 = paramDouble4 * d1;
/*      */     
/*  286 */     double d5 = Math.sin(paramDouble1);
/*  287 */     double d6 = Math.cos(paramDouble1);
/*  288 */     double d7 = 1.0D - d6;
/*      */     
/*  290 */     double d8 = d2 * d4;
/*  291 */     double d9 = d2 * d3;
/*  292 */     double d10 = d3 * d4;
/*      */     
/*  294 */     this.mxx = d7 * d2 * d2 + d6;
/*  295 */     this.mxy = d7 * d9 - d5 * d4;
/*  296 */     this.mxz = d7 * d8 + d5 * d3;
/*  297 */     this.mxt = 0.0D;
/*      */     
/*  299 */     this.myx = d7 * d9 + d5 * d4;
/*  300 */     this.myy = d7 * d3 * d3 + d6;
/*  301 */     this.myz = d7 * d10 - d5 * d2;
/*  302 */     this.myt = 0.0D;
/*      */     
/*  304 */     this.mzx = d7 * d8 - d5 * d3;
/*  305 */     this.mzy = d7 * d10 + d5 * d2;
/*  306 */     this.mzz = d7 * d4 * d4 + d6;
/*  307 */     this.mzt = 0.0D;
/*      */     
/*  309 */     updateState();
/*      */   }
/*      */   
/*      */   public BaseBounds transform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) {
/*      */     Vec3d vec3d;
/*  314 */     if ((this.state & 0x8) == 0) {
/*  315 */       return paramBaseBounds2 = super.transform(paramBaseBounds1, paramBaseBounds2);
/*      */     }
/*      */     
/*  318 */     switch (this.state)
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  329 */         vec3d = new Vec3d();
/*  330 */         paramBaseBounds2 = TransformHelper.general3dBoundsTransform(this, paramBaseBounds1, paramBaseBounds2, vec3d);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  366 */         return paramBaseBounds2;case 3: paramBaseBounds2 = paramBaseBounds2.deriveWithNewBoundsAndSort((float)(paramBaseBounds1.getMinX() * this.mxx + this.mxt), (float)(paramBaseBounds1.getMinY() * this.myy + this.myt), (float)(paramBaseBounds1.getMinZ() * this.mzz + this.mzt), (float)(paramBaseBounds1.getMaxX() * this.mxx + this.mxt), (float)(paramBaseBounds1.getMaxY() * this.myy + this.myt), (float)(paramBaseBounds1.getMaxZ() * this.mzz + this.mzt)); return paramBaseBounds2;case 2: paramBaseBounds2 = paramBaseBounds2.deriveWithNewBoundsAndSort((float)(paramBaseBounds1.getMinX() * this.mxx), (float)(paramBaseBounds1.getMinY() * this.myy), (float)(paramBaseBounds1.getMinZ() * this.mzz), (float)(paramBaseBounds1.getMaxX() * this.mxx), (float)(paramBaseBounds1.getMaxY() * this.myy), (float)(paramBaseBounds1.getMaxZ() * this.mzz)); return paramBaseBounds2;case 1: paramBaseBounds2 = paramBaseBounds2.deriveWithNewBounds((float)(paramBaseBounds1.getMinX() + this.mxt), (float)(paramBaseBounds1.getMinY() + this.myt), (float)(paramBaseBounds1.getMinZ() + this.mzt), (float)(paramBaseBounds1.getMaxX() + this.mxt), (float)(paramBaseBounds1.getMaxY() + this.myt), (float)(paramBaseBounds1.getMaxZ() + this.mzt)); return paramBaseBounds2;case 0: break; }  if (paramBaseBounds1 != paramBaseBounds2) paramBaseBounds2 = paramBaseBounds2.deriveWithNewBounds(paramBaseBounds1);  return paramBaseBounds2;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Vec3d transform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/*  372 */     if ((this.state & 0x8) == 0) {
/*  373 */       return super.transform(paramVec3d1, paramVec3d2);
/*      */     }
/*  375 */     if (paramVec3d2 == null) {
/*  376 */       paramVec3d2 = new Vec3d();
/*      */     }
/*  378 */     double d1 = paramVec3d1.x;
/*  379 */     double d2 = paramVec3d1.y;
/*  380 */     double d3 = paramVec3d1.z;
/*  381 */     paramVec3d2.x = this.mxx * d1 + this.mxy * d2 + this.mxz * d3 + this.mxt;
/*  382 */     paramVec3d2.y = this.myx * d1 + this.myy * d2 + this.myz * d3 + this.myt;
/*  383 */     paramVec3d2.z = this.mzx * d1 + this.mzy * d2 + this.mzz * d3 + this.mzt;
/*  384 */     return paramVec3d2;
/*      */   }
/*      */ 
/*      */   
/*      */   public Vec3d deltaTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/*  389 */     if ((this.state & 0x8) == 0) {
/*  390 */       return super.deltaTransform(paramVec3d1, paramVec3d2);
/*      */     }
/*  392 */     if (paramVec3d2 == null) {
/*  393 */       paramVec3d2 = new Vec3d();
/*      */     }
/*  395 */     double d1 = paramVec3d1.x;
/*  396 */     double d2 = paramVec3d1.y;
/*  397 */     double d3 = paramVec3d1.z;
/*  398 */     paramVec3d2.x = this.mxx * d1 + this.mxy * d2 + this.mxz * d3;
/*  399 */     paramVec3d2.y = this.myx * d1 + this.myy * d2 + this.myz * d3;
/*  400 */     paramVec3d2.z = this.mzx * d1 + this.mzy * d2 + this.mzz * d3;
/*  401 */     return paramVec3d2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void inverseTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) throws NoninvertibleTransformException {
/*  410 */     if ((this.state & 0x8) == 0) {
/*  411 */       super.inverseTransform(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3);
/*      */     } else {
/*      */       
/*  414 */       createInverse().transform(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void inverseDeltaTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) throws NoninvertibleTransformException {
/*  424 */     if ((this.state & 0x8) == 0) {
/*  425 */       super.inverseDeltaTransform(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3);
/*      */     } else {
/*      */       
/*  428 */       createInverse().deltaTransform(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void inverseTransform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) throws NoninvertibleTransformException {
/*  438 */     if ((this.state & 0x8) == 0) {
/*  439 */       super.inverseTransform(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3);
/*      */     } else {
/*      */       
/*  442 */       createInverse().transform(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Point2D inverseTransform(Point2D paramPoint2D1, Point2D paramPoint2D2) throws NoninvertibleTransformException {
/*  450 */     if ((this.state & 0x8) == 0) {
/*  451 */       return super.inverseTransform(paramPoint2D1, paramPoint2D2);
/*      */     }
/*      */     
/*  454 */     return createInverse().transform(paramPoint2D1, paramPoint2D2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vec3d inverseTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) throws NoninvertibleTransformException {
/*  462 */     if ((this.state & 0x8) == 0) {
/*  463 */       return super.inverseTransform(paramVec3d1, paramVec3d2);
/*      */     }
/*      */     
/*  466 */     return createInverse().transform(paramVec3d1, paramVec3d2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vec3d inverseDeltaTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) throws NoninvertibleTransformException {
/*  474 */     if ((this.state & 0x8) == 0) {
/*  475 */       return super.inverseDeltaTransform(paramVec3d1, paramVec3d2);
/*      */     }
/*      */     
/*  478 */     return createInverse().deltaTransform(paramVec3d1, paramVec3d2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseBounds inverseTransform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) throws NoninvertibleTransformException {
/*  486 */     if ((this.state & 0x8) == 0) {
/*  487 */       paramBaseBounds2 = super.inverseTransform(paramBaseBounds1, paramBaseBounds2);
/*      */     } else {
/*      */       
/*  490 */       paramBaseBounds2 = createInverse().transform(paramBaseBounds1, paramBaseBounds2);
/*      */     } 
/*  492 */     return paramBaseBounds2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void inverseTransform(Rectangle paramRectangle1, Rectangle paramRectangle2) throws NoninvertibleTransformException {
/*  499 */     if ((this.state & 0x8) == 0) {
/*  500 */       super.inverseTransform(paramRectangle1, paramRectangle2);
/*      */     } else {
/*      */       
/*  503 */       createInverse().transform(paramRectangle1, paramRectangle2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseTransform createInverse() throws NoninvertibleTransformException {
/*  511 */     BaseTransform baseTransform = copy();
/*  512 */     baseTransform.invert();
/*  513 */     return baseTransform;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invert() throws NoninvertibleTransformException {
/*  520 */     if ((this.state & 0x8) == 0) {
/*  521 */       super.invert();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  533 */     double d1 = minor(0, 0);
/*  534 */     double d2 = -minor(0, 1);
/*  535 */     double d3 = minor(0, 2);
/*  536 */     double d4 = -minor(1, 0);
/*  537 */     double d5 = minor(1, 1);
/*  538 */     double d6 = -minor(1, 2);
/*  539 */     double d7 = minor(2, 0);
/*  540 */     double d8 = -minor(2, 1);
/*  541 */     double d9 = minor(2, 2);
/*  542 */     double d10 = -minor(3, 0);
/*  543 */     double d11 = minor(3, 1);
/*  544 */     double d12 = -minor(3, 2);
/*  545 */     double d13 = getDeterminant();
/*  546 */     this.mxx = d1 / d13;
/*  547 */     this.mxy = d4 / d13;
/*  548 */     this.mxz = d7 / d13;
/*  549 */     this.mxt = d10 / d13;
/*  550 */     this.myx = d2 / d13;
/*  551 */     this.myy = d5 / d13;
/*  552 */     this.myz = d8 / d13;
/*  553 */     this.myt = d11 / d13;
/*  554 */     this.mzx = d3 / d13;
/*  555 */     this.mzy = d6 / d13;
/*  556 */     this.mzz = d9 / d13;
/*  557 */     this.mzt = d12 / d13;
/*  558 */     updateState();
/*      */   }
/*      */   
/*      */   private double minor(int paramInt1, int paramInt2) {
/*  562 */     double d1 = this.mxx, d2 = this.mxy, d3 = this.mxz;
/*  563 */     double d4 = this.myx, d5 = this.myy, d6 = this.myz;
/*  564 */     double d7 = this.mzx, d8 = this.mzy, d9 = this.mzz;
/*  565 */     switch (paramInt2) {
/*      */       case 0:
/*  567 */         d1 = d2;
/*  568 */         d4 = d5;
/*  569 */         d7 = d8;
/*      */       case 1:
/*  571 */         d2 = d3;
/*  572 */         d5 = d6;
/*  573 */         d8 = d9;
/*      */       case 2:
/*  575 */         d3 = this.mxt;
/*  576 */         d6 = this.myt;
/*  577 */         d9 = this.mzt; break;
/*      */     } 
/*  579 */     switch (paramInt1) {
/*      */       case 0:
/*  581 */         d1 = d4;
/*  582 */         d2 = d5;
/*      */       
/*      */       case 1:
/*  585 */         d4 = d7;
/*  586 */         d5 = d8;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/*  595 */         return d1 * (d5 * d9 - d8 * d6) + d2 * (d6 * d7 - d9 * d4) + d3 * (d4 * d8 - d7 * d5);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  602 */     return d1 * d5 - d2 * d4;
/*      */   }
/*      */ 
/*      */   
/*      */   public Affine3D deriveWithNewTransform(BaseTransform paramBaseTransform) {
/*  607 */     setTransform(paramBaseTransform);
/*  608 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Affine3D deriveWithTranslation(double paramDouble1, double paramDouble2) {
/*  613 */     translate(paramDouble1, paramDouble2, 0.0D);
/*  614 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public void translate(double paramDouble1, double paramDouble2) {
/*  619 */     if ((this.state & 0x8) == 0) {
/*  620 */       super.translate(paramDouble1, paramDouble2);
/*      */     } else {
/*  622 */       translate(paramDouble1, paramDouble2, 0.0D);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void translate(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  627 */     if ((this.state & 0x8) == 0) {
/*  628 */       super.translate(paramDouble1, paramDouble2);
/*  629 */       if (paramDouble3 != 0.0D) {
/*  630 */         this.mzt = paramDouble3;
/*  631 */         this.state |= 0x8;
/*  632 */         if (this.type != -1) {
/*  633 */           this.type |= 0x80;
/*      */         }
/*      */       } 
/*      */       return;
/*      */     } 
/*  638 */     this.mxt = paramDouble1 * this.mxx + paramDouble2 * this.mxy + paramDouble3 * this.mxz + this.mxt;
/*  639 */     this.myt = paramDouble1 * this.myx + paramDouble2 * this.myy + paramDouble3 * this.myz + this.myt;
/*  640 */     this.mzt = paramDouble1 * this.mzx + paramDouble2 * this.mzy + paramDouble3 * this.mzz + this.mzt;
/*  641 */     updateState();
/*      */   }
/*      */ 
/*      */   
/*      */   public Affine3D deriveWithPreTranslation(double paramDouble1, double paramDouble2) {
/*  646 */     preTranslate(paramDouble1, paramDouble2, 0.0D);
/*  647 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithTranslation(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  652 */     translate(paramDouble1, paramDouble2, paramDouble3);
/*  653 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithScale(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  658 */     scale(paramDouble1, paramDouble2, paramDouble3);
/*  659 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithRotation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  665 */     rotate(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*  666 */     return this;
/*      */   }
/*      */   
/*      */   public void preTranslate(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  670 */     this.mxt += paramDouble1;
/*  671 */     this.myt += paramDouble2;
/*  672 */     this.mzt += paramDouble3;
/*  673 */     boolean bool = false;
/*  674 */     int i = 0;
/*  675 */     if (this.mzt == 0.0D) {
/*  676 */       if ((this.state & 0x8) != 0) {
/*      */         
/*  678 */         updateState();
/*      */         return;
/*      */       } 
/*      */     } else {
/*  682 */       this.state |= 0x8;
/*  683 */       i = 128;
/*      */     } 
/*  685 */     if (this.mxt == 0.0D && this.myt == 0.0D) {
/*  686 */       this.state &= 0xFFFFFFFE;
/*  687 */       bool = true;
/*      */     } else {
/*  689 */       this.state |= 0x1;
/*  690 */       i |= 0x1;
/*      */     } 
/*  692 */     if (this.type != -1) {
/*  693 */       this.type = this.type & (bool ^ 0xFFFFFFFF) | i;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void scale(double paramDouble1, double paramDouble2) {
/*  699 */     if ((this.state & 0x8) == 0) {
/*  700 */       super.scale(paramDouble1, paramDouble2);
/*      */     } else {
/*  702 */       scale(paramDouble1, paramDouble2, 1.0D);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void scale(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  707 */     if ((this.state & 0x8) == 0) {
/*  708 */       super.scale(paramDouble1, paramDouble2);
/*  709 */       if (paramDouble3 != 1.0D) {
/*  710 */         this.mzz = paramDouble3;
/*  711 */         this.state |= 0x8;
/*  712 */         if (this.type != -1) {
/*  713 */           this.type |= 0x80;
/*      */         }
/*      */       } 
/*      */       return;
/*      */     } 
/*  718 */     this.mxx *= paramDouble1;
/*  719 */     this.mxy *= paramDouble2;
/*  720 */     this.mxz *= paramDouble3;
/*      */     
/*  722 */     this.myx *= paramDouble1;
/*  723 */     this.myy *= paramDouble2;
/*  724 */     this.myz *= paramDouble3;
/*      */     
/*  726 */     this.mzx *= paramDouble1;
/*  727 */     this.mzy *= paramDouble2;
/*  728 */     this.mzz *= paramDouble3;
/*      */ 
/*      */     
/*  731 */     updateState();
/*      */   }
/*      */ 
/*      */   
/*      */   public void rotate(double paramDouble) {
/*  736 */     if ((this.state & 0x8) == 0) {
/*  737 */       super.rotate(paramDouble);
/*      */     } else {
/*  739 */       rotate(paramDouble, 0.0D, 0.0D, 1.0D);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void rotate(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  744 */     if ((this.state & 0x8) == 0 && almostZero(paramDouble2) && almostZero(paramDouble3)) {
/*  745 */       if (paramDouble4 > 0.0D) {
/*  746 */         super.rotate(paramDouble1);
/*  747 */       } else if (paramDouble4 < 0.0D) {
/*  748 */         super.rotate(-paramDouble1);
/*      */       } 
/*      */       return;
/*      */     } 
/*  752 */     double d1 = Math.sqrt(paramDouble2 * paramDouble2 + paramDouble3 * paramDouble3 + paramDouble4 * paramDouble4);
/*      */     
/*  754 */     if (almostZero(d1)) {
/*      */       return;
/*      */     }
/*  757 */     d1 = 1.0D / d1;
/*  758 */     double d2 = paramDouble2 * d1;
/*  759 */     double d3 = paramDouble3 * d1;
/*  760 */     double d4 = paramDouble4 * d1;
/*      */     
/*  762 */     double d5 = Math.sin(paramDouble1);
/*  763 */     double d6 = Math.cos(paramDouble1);
/*  764 */     double d7 = 1.0D - d6;
/*      */     
/*  766 */     double d8 = d2 * d4;
/*  767 */     double d9 = d2 * d3;
/*  768 */     double d10 = d3 * d4;
/*      */     
/*  770 */     double d11 = d7 * d2 * d2 + d6;
/*  771 */     double d12 = d7 * d9 - d5 * d4;
/*  772 */     double d13 = d7 * d8 + d5 * d3;
/*      */     
/*  774 */     double d14 = d7 * d9 + d5 * d4;
/*  775 */     double d15 = d7 * d3 * d3 + d6;
/*  776 */     double d16 = d7 * d10 - d5 * d2;
/*      */     
/*  778 */     double d17 = d7 * d8 - d5 * d3;
/*  779 */     double d18 = d7 * d10 + d5 * d2;
/*  780 */     double d19 = d7 * d4 * d4 + d6;
/*      */     
/*  782 */     double d20 = this.mxx * d11 + this.mxy * d14 + this.mxz * d17;
/*  783 */     double d21 = this.mxx * d12 + this.mxy * d15 + this.mxz * d18;
/*  784 */     double d22 = this.mxx * d13 + this.mxy * d16 + this.mxz * d19;
/*  785 */     double d23 = this.myx * d11 + this.myy * d14 + this.myz * d17;
/*  786 */     double d24 = this.myx * d12 + this.myy * d15 + this.myz * d18;
/*  787 */     double d25 = this.myx * d13 + this.myy * d16 + this.myz * d19;
/*  788 */     double d26 = this.mzx * d11 + this.mzy * d14 + this.mzz * d17;
/*  789 */     double d27 = this.mzx * d12 + this.mzy * d15 + this.mzz * d18;
/*  790 */     double d28 = this.mzx * d13 + this.mzy * d16 + this.mzz * d19;
/*  791 */     this.mxx = d20;
/*  792 */     this.mxy = d21;
/*  793 */     this.mxz = d22;
/*  794 */     this.myx = d23;
/*  795 */     this.myy = d24;
/*  796 */     this.myz = d25;
/*  797 */     this.mzx = d26;
/*  798 */     this.mzy = d27;
/*  799 */     this.mzz = d28;
/*  800 */     updateState();
/*      */   }
/*      */ 
/*      */   
/*      */   public void shear(double paramDouble1, double paramDouble2) {
/*  805 */     if ((this.state & 0x8) == 0) {
/*  806 */       super.shear(paramDouble1, paramDouble2);
/*      */       return;
/*      */     } 
/*  809 */     double d1 = this.mxx + this.mxy * paramDouble2;
/*  810 */     double d2 = this.mxy + this.mxx * paramDouble1;
/*  811 */     double d3 = this.myx + this.myy * paramDouble2;
/*  812 */     double d4 = this.myy + this.myx * paramDouble1;
/*  813 */     double d5 = this.mzx + this.mzy * paramDouble2;
/*  814 */     double d6 = this.mzy + this.mzx * paramDouble1;
/*  815 */     this.mxx = d1;
/*  816 */     this.mxy = d2;
/*  817 */     this.myx = d3;
/*  818 */     this.myy = d4;
/*  819 */     this.mzx = d5;
/*  820 */     this.mzy = d6;
/*  821 */     updateState();
/*      */   }
/*      */ 
/*      */   
/*      */   public Affine3D deriveWithConcatenation(BaseTransform paramBaseTransform) {
/*  826 */     concatenate(paramBaseTransform);
/*  827 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Affine3D deriveWithPreConcatenation(BaseTransform paramBaseTransform) {
/*  832 */     preConcatenate(paramBaseTransform);
/*  833 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public void concatenate(BaseTransform paramBaseTransform) {
/*  838 */     switch (paramBaseTransform.getDegree()) {
/*      */       case IDENTITY:
/*      */         return;
/*      */       case TRANSLATE_2D:
/*  842 */         translate(paramBaseTransform.getMxt(), paramBaseTransform.getMyt());
/*      */         return;
/*      */       case TRANSLATE_3D:
/*  845 */         translate(paramBaseTransform.getMxt(), paramBaseTransform.getMyt(), paramBaseTransform.getMzt());
/*      */         return;
/*      */       case AFFINE_3D:
/*  848 */         if (!paramBaseTransform.is2D()) {
/*      */           break;
/*      */         }
/*      */       
/*      */       case AFFINE_2D:
/*  853 */         if ((this.state & 0x8) == 0) {
/*  854 */           super.concatenate(paramBaseTransform);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */     } 
/*  859 */     double d1 = paramBaseTransform.getMxx();
/*  860 */     double d2 = paramBaseTransform.getMxy();
/*  861 */     double d3 = paramBaseTransform.getMxz();
/*  862 */     double d4 = paramBaseTransform.getMxt();
/*  863 */     double d5 = paramBaseTransform.getMyx();
/*  864 */     double d6 = paramBaseTransform.getMyy();
/*  865 */     double d7 = paramBaseTransform.getMyz();
/*  866 */     double d8 = paramBaseTransform.getMyt();
/*  867 */     double d9 = paramBaseTransform.getMzx();
/*  868 */     double d10 = paramBaseTransform.getMzy();
/*  869 */     double d11 = paramBaseTransform.getMzz();
/*  870 */     double d12 = paramBaseTransform.getMzt();
/*  871 */     double d13 = this.mxx * d1 + this.mxy * d5 + this.mxz * d9;
/*  872 */     double d14 = this.mxx * d2 + this.mxy * d6 + this.mxz * d10;
/*  873 */     double d15 = this.mxx * d3 + this.mxy * d7 + this.mxz * d11;
/*  874 */     double d16 = this.mxx * d4 + this.mxy * d8 + this.mxz * d12 + this.mxt;
/*  875 */     double d17 = this.myx * d1 + this.myy * d5 + this.myz * d9;
/*  876 */     double d18 = this.myx * d2 + this.myy * d6 + this.myz * d10;
/*  877 */     double d19 = this.myx * d3 + this.myy * d7 + this.myz * d11;
/*  878 */     double d20 = this.myx * d4 + this.myy * d8 + this.myz * d12 + this.myt;
/*  879 */     double d21 = this.mzx * d1 + this.mzy * d5 + this.mzz * d9;
/*  880 */     double d22 = this.mzx * d2 + this.mzy * d6 + this.mzz * d10;
/*  881 */     double d23 = this.mzx * d3 + this.mzy * d7 + this.mzz * d11;
/*  882 */     double d24 = this.mzx * d4 + this.mzy * d8 + this.mzz * d12 + this.mzt;
/*  883 */     this.mxx = d13;
/*  884 */     this.mxy = d14;
/*  885 */     this.mxz = d15;
/*  886 */     this.mxt = d16;
/*  887 */     this.myx = d17;
/*  888 */     this.myy = d18;
/*  889 */     this.myz = d19;
/*  890 */     this.myt = d20;
/*  891 */     this.mzx = d21;
/*  892 */     this.mzy = d22;
/*  893 */     this.mzz = d23;
/*  894 */     this.mzt = d24;
/*  895 */     updateState();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void concatenate(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/*  902 */     double d1 = this.mxx * paramDouble1 + this.mxy * paramDouble5 + this.mxz * paramDouble9;
/*  903 */     double d2 = this.mxx * paramDouble2 + this.mxy * paramDouble6 + this.mxz * paramDouble10;
/*  904 */     double d3 = this.mxx * paramDouble3 + this.mxy * paramDouble7 + this.mxz * paramDouble11;
/*  905 */     double d4 = this.mxx * paramDouble4 + this.mxy * paramDouble8 + this.mxz * paramDouble12 + this.mxt;
/*  906 */     double d5 = this.myx * paramDouble1 + this.myy * paramDouble5 + this.myz * paramDouble9;
/*  907 */     double d6 = this.myx * paramDouble2 + this.myy * paramDouble6 + this.myz * paramDouble10;
/*  908 */     double d7 = this.myx * paramDouble3 + this.myy * paramDouble7 + this.myz * paramDouble11;
/*  909 */     double d8 = this.myx * paramDouble4 + this.myy * paramDouble8 + this.myz * paramDouble12 + this.myt;
/*  910 */     double d9 = this.mzx * paramDouble1 + this.mzy * paramDouble5 + this.mzz * paramDouble9;
/*  911 */     double d10 = this.mzx * paramDouble2 + this.mzy * paramDouble6 + this.mzz * paramDouble10;
/*  912 */     double d11 = this.mzx * paramDouble3 + this.mzy * paramDouble7 + this.mzz * paramDouble11;
/*  913 */     double d12 = this.mzx * paramDouble4 + this.mzy * paramDouble8 + this.mzz * paramDouble12 + this.mzt;
/*  914 */     this.mxx = d1;
/*  915 */     this.mxy = d2;
/*  916 */     this.mxz = d3;
/*  917 */     this.mxt = d4;
/*  918 */     this.myx = d5;
/*  919 */     this.myy = d6;
/*  920 */     this.myz = d7;
/*  921 */     this.myt = d8;
/*  922 */     this.mzx = d9;
/*  923 */     this.mzy = d10;
/*  924 */     this.mzz = d11;
/*  925 */     this.mzt = d12;
/*  926 */     updateState();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Affine3D deriveWithConcatenation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*  934 */     double d1 = this.mxx * paramDouble1 + this.mxy * paramDouble2;
/*  935 */     double d2 = this.mxx * paramDouble3 + this.mxy * paramDouble4;
/*      */     
/*  937 */     double d3 = this.mxx * paramDouble5 + this.mxy * paramDouble6 + this.mxt;
/*  938 */     double d4 = this.myx * paramDouble1 + this.myy * paramDouble2;
/*  939 */     double d5 = this.myx * paramDouble3 + this.myy * paramDouble4;
/*      */     
/*  941 */     double d6 = this.myx * paramDouble5 + this.myy * paramDouble6 + this.myt;
/*  942 */     double d7 = this.mzx * paramDouble1 + this.mzy * paramDouble2;
/*  943 */     double d8 = this.mzx * paramDouble3 + this.mzy * paramDouble4;
/*      */     
/*  945 */     double d9 = this.mzx * paramDouble5 + this.mzy * paramDouble6 + this.mzt;
/*  946 */     this.mxx = d1;
/*  947 */     this.mxy = d2;
/*      */     
/*  949 */     this.mxt = d3;
/*  950 */     this.myx = d4;
/*  951 */     this.myy = d5;
/*      */     
/*  953 */     this.myt = d6;
/*  954 */     this.mzx = d7;
/*  955 */     this.mzy = d8;
/*      */     
/*  957 */     this.mzt = d9;
/*  958 */     updateState();
/*  959 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithConcatenation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/*  967 */     concatenate(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramDouble9, paramDouble10, paramDouble11, paramDouble12);
/*      */ 
/*      */     
/*  970 */     return this;
/*      */   }
/*      */   
/*      */   public void preConcatenate(BaseTransform paramBaseTransform) {
/*  974 */     switch (paramBaseTransform.getDegree()) {
/*      */       case IDENTITY:
/*      */         return;
/*      */       case TRANSLATE_2D:
/*  978 */         preTranslate(paramBaseTransform.getMxt(), paramBaseTransform.getMyt(), 0.0D);
/*      */         return;
/*      */       case TRANSLATE_3D:
/*  981 */         preTranslate(paramBaseTransform.getMxt(), paramBaseTransform.getMyt(), paramBaseTransform.getMzt());
/*      */         return;
/*      */     } 
/*  984 */     double d1 = paramBaseTransform.getMxx();
/*  985 */     double d2 = paramBaseTransform.getMxy();
/*  986 */     double d3 = paramBaseTransform.getMxz();
/*  987 */     double d4 = paramBaseTransform.getMxt();
/*  988 */     double d5 = paramBaseTransform.getMyx();
/*  989 */     double d6 = paramBaseTransform.getMyy();
/*  990 */     double d7 = paramBaseTransform.getMyz();
/*  991 */     double d8 = paramBaseTransform.getMyt();
/*  992 */     double d9 = paramBaseTransform.getMzx();
/*  993 */     double d10 = paramBaseTransform.getMzy();
/*  994 */     double d11 = paramBaseTransform.getMzz();
/*  995 */     double d12 = paramBaseTransform.getMzt();
/*  996 */     double d13 = d1 * this.mxx + d2 * this.myx + d3 * this.mzx;
/*  997 */     double d14 = d1 * this.mxy + d2 * this.myy + d3 * this.mzy;
/*  998 */     double d15 = d1 * this.mxz + d2 * this.myz + d3 * this.mzz;
/*  999 */     double d16 = d1 * this.mxt + d2 * this.myt + d3 * this.mzt + d4;
/* 1000 */     double d17 = d5 * this.mxx + d6 * this.myx + d7 * this.mzx;
/* 1001 */     double d18 = d5 * this.mxy + d6 * this.myy + d7 * this.mzy;
/* 1002 */     double d19 = d5 * this.mxz + d6 * this.myz + d7 * this.mzz;
/* 1003 */     double d20 = d5 * this.mxt + d6 * this.myt + d7 * this.mzt + d8;
/* 1004 */     double d21 = d9 * this.mxx + d10 * this.myx + d11 * this.mzx;
/* 1005 */     double d22 = d9 * this.mxy + d10 * this.myy + d11 * this.mzy;
/* 1006 */     double d23 = d9 * this.mxz + d10 * this.myz + d11 * this.mzz;
/* 1007 */     double d24 = d9 * this.mxt + d10 * this.myt + d11 * this.mzt + d12;
/* 1008 */     this.mxx = d13;
/* 1009 */     this.mxy = d14;
/* 1010 */     this.mxz = d15;
/* 1011 */     this.mxt = d16;
/* 1012 */     this.myx = d17;
/* 1013 */     this.myy = d18;
/* 1014 */     this.myz = d19;
/* 1015 */     this.myt = d20;
/* 1016 */     this.mzx = d21;
/* 1017 */     this.mzy = d22;
/* 1018 */     this.mzz = d23;
/* 1019 */     this.mzt = d24;
/* 1020 */     updateState();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void restoreTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 1028 */     throw new InternalError("must use Affine3D restore method to prevent loss of information");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void restoreTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/* 1037 */     this.mxx = paramDouble1;
/* 1038 */     this.mxy = paramDouble2;
/* 1039 */     this.mxz = paramDouble3;
/* 1040 */     this.mxt = paramDouble4;
/*      */     
/* 1042 */     this.myx = paramDouble5;
/* 1043 */     this.myy = paramDouble6;
/* 1044 */     this.myz = paramDouble7;
/* 1045 */     this.myt = paramDouble8;
/*      */     
/* 1047 */     this.mzx = paramDouble9;
/* 1048 */     this.mzy = paramDouble10;
/* 1049 */     this.mzz = paramDouble11;
/* 1050 */     this.mzt = paramDouble12;
/*      */     
/* 1052 */     updateState();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Affine3D lookAt(Vec3d paramVec3d1, Vec3d paramVec3d2, Vec3d paramVec3d3) {
/* 1074 */     double d1 = paramVec3d1.x - paramVec3d2.x;
/* 1075 */     double d2 = paramVec3d1.y - paramVec3d2.y;
/* 1076 */     double d3 = paramVec3d1.z - paramVec3d2.z;
/*      */     
/* 1078 */     double d4 = 1.0D / Math.sqrt(d1 * d1 + d2 * d2 + d3 * d3);
/* 1079 */     d1 *= d4;
/* 1080 */     d2 *= d4;
/* 1081 */     d3 *= d4;
/*      */     
/* 1083 */     d4 = 1.0D / Math.sqrt(paramVec3d3.x * paramVec3d3.x + paramVec3d3.y * paramVec3d3.y + paramVec3d3.z * paramVec3d3.z);
/* 1084 */     double d5 = paramVec3d3.x * d4;
/* 1085 */     double d6 = paramVec3d3.y * d4;
/* 1086 */     double d7 = paramVec3d3.z * d4;
/*      */ 
/*      */     
/* 1089 */     double d8 = d6 * d3 - d2 * d7;
/* 1090 */     double d9 = d7 * d1 - d5 * d3;
/* 1091 */     double d10 = d5 * d2 - d6 * d1;
/*      */     
/* 1093 */     d4 = 1.0D / Math.sqrt(d8 * d8 + d9 * d9 + d10 * d10);
/* 1094 */     d8 *= d4;
/* 1095 */     d9 *= d4;
/* 1096 */     d10 *= d4;
/*      */ 
/*      */     
/* 1099 */     d5 = d2 * d10 - d9 * d3;
/* 1100 */     d6 = d3 * d8 - d1 * d10;
/* 1101 */     d7 = d1 * d9 - d2 * d8;
/*      */ 
/*      */     
/* 1104 */     this.mxx = d8;
/* 1105 */     this.mxy = d9;
/* 1106 */     this.mxz = d10;
/*      */     
/* 1108 */     this.myx = d5;
/* 1109 */     this.myy = d6;
/* 1110 */     this.myz = d7;
/*      */     
/* 1112 */     this.mzx = d1;
/* 1113 */     this.mzy = d2;
/* 1114 */     this.mzz = d3;
/*      */     
/* 1116 */     this.mxt = -paramVec3d1.x * this.mxx + -paramVec3d1.y * this.mxy + -paramVec3d1.z * this.mxz;
/* 1117 */     this.myt = -paramVec3d1.x * this.myx + -paramVec3d1.y * this.myy + -paramVec3d1.z * this.myz;
/* 1118 */     this.mzt = -paramVec3d1.x * this.mzx + -paramVec3d1.y * this.mzy + -paramVec3d1.z * this.mzz;
/*      */     
/* 1120 */     updateState();
/* 1121 */     return this;
/*      */   }
/*      */   
/*      */   static boolean almostOne(double paramDouble) {
/* 1125 */     return (paramDouble < 1.00001D && paramDouble > 0.99999D);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static double _matround(double paramDouble) {
/* 1131 */     return Math.rint(paramDouble * 1.0E15D) / 1.0E15D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1143 */     return "Affine3D[[" + _matround(this.mxx) + ", " + 
/* 1144 */       _matround(this.mxy) + ", " + 
/* 1145 */       _matround(this.mxz) + ", " + 
/* 1146 */       _matround(this.mxt) + "], [" + 
/* 1147 */       _matround(this.myx) + ", " + 
/* 1148 */       _matround(this.myy) + ", " + 
/* 1149 */       _matround(this.myz) + ", " + 
/* 1150 */       _matround(this.myt) + "], [" + 
/* 1151 */       _matround(this.mzx) + ", " + 
/* 1152 */       _matround(this.mzy) + ", " + 
/* 1153 */       _matround(this.mzz) + ", " + 
/* 1154 */       _matround(this.mzt) + "]]";
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\Affine3D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */