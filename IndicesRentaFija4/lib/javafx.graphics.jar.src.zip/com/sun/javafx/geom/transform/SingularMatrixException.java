/*    */ package com.sun.javafx.geom.transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingularMatrixException
/*    */   extends RuntimeException
/*    */ {
/*    */   public SingularMatrixException() {}
/*    */   
/*    */   public SingularMatrixException(String paramString) {
/* 38 */     super(paramString);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\SingularMatrixException.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */