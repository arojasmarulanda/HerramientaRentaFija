/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Crossings
/*     */ {
/*     */   public static final boolean debug = false;
/*  34 */   int limit = 0;
/*  35 */   double[] yranges = new double[10];
/*     */   double xlo;
/*     */   double ylo;
/*     */   
/*     */   public Crossings(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  40 */     this.xlo = paramDouble1;
/*  41 */     this.ylo = paramDouble2;
/*  42 */     this.xhi = paramDouble3;
/*  43 */     this.yhi = paramDouble4;
/*     */   }
/*     */   double xhi; double yhi;
/*     */   public final double getXLo() {
/*  47 */     return this.xlo;
/*     */   }
/*     */   
/*     */   public final double getYLo() {
/*  51 */     return this.ylo;
/*     */   }
/*     */   
/*     */   public final double getXHi() {
/*  55 */     return this.xhi;
/*     */   }
/*     */   
/*     */   public final double getYHi() {
/*  59 */     return this.yhi;
/*     */   }
/*     */   
/*     */   public abstract void record(double paramDouble1, double paramDouble2, int paramInt);
/*     */   
/*     */   public void print() {
/*  65 */     System.out.println("Crossings [");
/*  66 */     System.out.println("  bounds = [" + this.ylo + ", " + this.yhi + "]");
/*  67 */     for (byte b = 0; b < this.limit; b += 2) {
/*  68 */       System.out.println("  [" + this.yranges[b] + ", " + this.yranges[b + 1] + "]");
/*     */     }
/*  70 */     System.out.println("]");
/*     */   }
/*     */   
/*     */   public final boolean isEmpty() {
/*  74 */     return (this.limit == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean covers(double paramDouble1, double paramDouble2);
/*     */ 
/*     */   
/*     */   public static Crossings findCrossings(Vector paramVector, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  83 */     EvenOdd evenOdd = new EvenOdd(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*  84 */     Enumeration<Curve> enumeration = paramVector.elements();
/*  85 */     while (enumeration.hasMoreElements()) {
/*  86 */       Curve curve = enumeration.nextElement();
/*  87 */       if (curve.accumulateCrossings(evenOdd)) {
/*  88 */         return null;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  94 */     return evenOdd;
/*     */   }
/*     */   
/*     */   public static final class EvenOdd extends Crossings {
/*     */     public EvenOdd(double param1Double1, double param1Double2, double param1Double3, double param1Double4) {
/*  99 */       super(param1Double1, param1Double2, param1Double3, param1Double4);
/*     */     }
/*     */     
/*     */     public final boolean covers(double param1Double1, double param1Double2) {
/* 103 */       return (this.limit == 2 && this.yranges[0] <= param1Double1 && this.yranges[1] >= param1Double2);
/*     */     }
/*     */     
/*     */     public void record(double param1Double1, double param1Double2, int param1Int) {
/* 107 */       if (param1Double1 >= param1Double2) {
/*     */         return;
/*     */       }
/* 110 */       byte b = 0;
/*     */       
/* 112 */       while (b < this.limit && param1Double1 > this.yranges[b + 1]) {
/* 113 */         b += 2;
/*     */       }
/* 115 */       int i = b;
/* 116 */       while (b < this.limit) {
/* 117 */         double d3, d4, d5, d6, d1 = this.yranges[b++];
/* 118 */         double d2 = this.yranges[b++];
/* 119 */         if (param1Double2 < d1) {
/*     */           
/* 121 */           this.yranges[i++] = param1Double1;
/* 122 */           this.yranges[i++] = param1Double2;
/* 123 */           param1Double1 = d1;
/* 124 */           param1Double2 = d2;
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 129 */         if (param1Double1 < d1) {
/* 130 */           d3 = param1Double1;
/* 131 */           d4 = d1;
/*     */         } else {
/* 133 */           d3 = d1;
/* 134 */           d4 = param1Double1;
/*     */         } 
/* 136 */         if (param1Double2 < d2) {
/* 137 */           d5 = param1Double2;
/* 138 */           d6 = d2;
/*     */         } else {
/* 140 */           d5 = d2;
/* 141 */           d6 = param1Double2;
/*     */         } 
/* 143 */         if (d4 == d5) {
/* 144 */           param1Double1 = d3;
/* 145 */           param1Double2 = d6;
/*     */         } else {
/* 147 */           if (d4 > d5) {
/* 148 */             param1Double1 = d5;
/* 149 */             d5 = d4;
/* 150 */             d4 = param1Double1;
/*     */           } 
/* 152 */           if (d3 != d4) {
/* 153 */             this.yranges[i++] = d3;
/* 154 */             this.yranges[i++] = d4;
/*     */           } 
/* 156 */           param1Double1 = d5;
/* 157 */           param1Double2 = d6;
/*     */         } 
/* 159 */         if (param1Double1 >= param1Double2) {
/*     */           break;
/*     */         }
/*     */       } 
/* 163 */       if (i < b && b < this.limit) {
/* 164 */         System.arraycopy(this.yranges, b, this.yranges, i, this.limit - b);
/*     */       }
/* 166 */       i += this.limit - b;
/* 167 */       if (param1Double1 < param1Double2) {
/* 168 */         if (i >= this.yranges.length) {
/* 169 */           double[] arrayOfDouble = new double[i + 10];
/* 170 */           System.arraycopy(this.yranges, 0, arrayOfDouble, 0, i);
/* 171 */           this.yranges = arrayOfDouble;
/*     */         } 
/* 173 */         this.yranges[i++] = param1Double1;
/* 174 */         this.yranges[i++] = param1Double2;
/*     */       } 
/* 176 */       this.limit = i;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Crossings.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */