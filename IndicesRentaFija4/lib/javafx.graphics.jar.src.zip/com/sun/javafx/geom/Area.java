/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Area
/*     */   extends Shape
/*     */ {
/*  96 */   private static final Vector EmptyCurves = new Vector();
/*     */   
/*     */   private Vector curves;
/*     */   
/*     */   private RectBounds cachedBounds;
/*     */ 
/*     */   
/*     */   public Area() {
/* 104 */     this.curves = EmptyCurves;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Area(Shape paramShape) {
/* 117 */     if (paramShape instanceof Area) {
/* 118 */       this.curves = ((Area)paramShape).curves;
/*     */     } else {
/* 120 */       this.curves = pathToCurves(paramShape.getPathIterator(null));
/*     */     } 
/*     */   }
/*     */   
/*     */   public Area(PathIterator paramPathIterator) {
/* 125 */     this.curves = pathToCurves(paramPathIterator);
/*     */   }
/*     */   private static Vector pathToCurves(PathIterator paramPathIterator) {
/*     */     AreaOp.NZWindOp nZWindOp;
/* 129 */     Vector vector = new Vector();
/* 130 */     int i = paramPathIterator.getWindingRule();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     float[] arrayOfFloat = new float[6];
/* 146 */     double[] arrayOfDouble = new double[23];
/* 147 */     double d1 = 0.0D, d2 = 0.0D;
/* 148 */     double d3 = 0.0D, d4 = 0.0D;
/*     */     
/* 150 */     while (!paramPathIterator.isDone()) {
/* 151 */       double d5, d6; switch (paramPathIterator.currentSegment(arrayOfFloat)) {
/*     */         case 0:
/* 153 */           Curve.insertLine(vector, d3, d4, d1, d2);
/* 154 */           d3 = d1 = arrayOfFloat[0];
/* 155 */           d4 = d2 = arrayOfFloat[1];
/* 156 */           Curve.insertMove(vector, d1, d2);
/*     */         
/*     */         case 1:
/* 159 */           d5 = arrayOfFloat[0];
/* 160 */           d6 = arrayOfFloat[1];
/* 161 */           Curve.insertLine(vector, d3, d4, d5, d6);
/* 162 */           d3 = d5;
/* 163 */           d4 = d6;
/*     */           break;
/*     */         case 2:
/* 166 */           d5 = arrayOfFloat[2];
/* 167 */           d6 = arrayOfFloat[3];
/* 168 */           Curve.insertQuad(vector, arrayOfDouble, d3, d4, arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3]);
/*     */ 
/*     */ 
/*     */           
/* 172 */           d3 = d5;
/* 173 */           d4 = d6;
/*     */           break;
/*     */         case 3:
/* 176 */           d5 = arrayOfFloat[4];
/* 177 */           d6 = arrayOfFloat[5];
/* 178 */           Curve.insertCubic(vector, arrayOfDouble, d3, d4, arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3], arrayOfFloat[4], arrayOfFloat[5]);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 183 */           d3 = d5;
/* 184 */           d4 = d6;
/*     */           break;
/*     */         case 4:
/* 187 */           Curve.insertLine(vector, d3, d4, d1, d2);
/* 188 */           d3 = d1;
/* 189 */           d4 = d2;
/*     */           break;
/*     */       } 
/* 192 */       paramPathIterator.next();
/*     */     } 
/* 194 */     Curve.insertLine(vector, d3, d4, d1, d2);
/*     */     
/* 196 */     if (i == 0) {
/* 197 */       AreaOp.EOWindOp eOWindOp = new AreaOp.EOWindOp();
/*     */     } else {
/* 199 */       nZWindOp = new AreaOp.NZWindOp();
/*     */     } 
/* 201 */     return nZWindOp.calculate(vector, EmptyCurves);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Area paramArea) {
/* 232 */     this.curves = (new AreaOp.AddOp()).calculate(this.curves, paramArea.curves);
/* 233 */     invalidateBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subtract(Area paramArea) {
/* 264 */     this.curves = (new AreaOp.SubOp()).calculate(this.curves, paramArea.curves);
/* 265 */     invalidateBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void intersect(Area paramArea) {
/* 296 */     this.curves = (new AreaOp.IntOp()).calculate(this.curves, paramArea.curves);
/* 297 */     invalidateBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void exclusiveOr(Area paramArea) {
/* 329 */     this.curves = (new AreaOp.XorOp()).calculate(this.curves, paramArea.curves);
/* 330 */     invalidateBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 338 */     this.curves = new Vector();
/* 339 */     invalidateBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 348 */     return (this.curves.size() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPolygonal() {
/* 359 */     Enumeration enumeration = this.curves.elements();
/* 360 */     while (enumeration.hasMoreElements()) {
/* 361 */       if (((Curve)enumeration.nextElement()).getOrder() > 1) {
/* 362 */         return false;
/*     */       }
/*     */     } 
/* 365 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRectangular() {
/* 375 */     int i = this.curves.size();
/* 376 */     if (i == 0) {
/* 377 */       return true;
/*     */     }
/* 379 */     if (i > 3) {
/* 380 */       return false;
/*     */     }
/* 382 */     Curve curve1 = this.curves.get(1);
/* 383 */     Curve curve2 = this.curves.get(2);
/* 384 */     if (curve1.getOrder() != 1 || curve2.getOrder() != 1) {
/* 385 */       return false;
/*     */     }
/* 387 */     if (curve1.getXTop() != curve1.getXBot() || curve2.getXTop() != curve2.getXBot()) {
/* 388 */       return false;
/*     */     }
/* 390 */     if (curve1.getYTop() != curve2.getYTop() || curve1.getYBot() != curve2.getYBot())
/*     */     {
/* 392 */       return false;
/*     */     }
/* 394 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingular() {
/* 408 */     if (this.curves.size() < 3) {
/* 409 */       return true;
/*     */     }
/* 411 */     Enumeration<Curve> enumeration = this.curves.elements();
/* 412 */     enumeration.nextElement();
/* 413 */     while (enumeration.hasMoreElements()) {
/* 414 */       if (((Curve)enumeration.nextElement()).getOrder() == 0) {
/* 415 */         return false;
/*     */       }
/*     */     } 
/* 418 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void invalidateBounds() {
/* 423 */     this.cachedBounds = null;
/*     */   }
/*     */   private RectBounds getCachedBounds() {
/* 426 */     if (this.cachedBounds != null) {
/* 427 */       return this.cachedBounds;
/*     */     }
/* 429 */     RectBounds rectBounds = new RectBounds();
/* 430 */     if (this.curves.size() > 0) {
/* 431 */       Curve curve = this.curves.get(0);
/*     */       
/* 433 */       rectBounds.setBounds((float)curve.getX0(), (float)curve.getY0(), 0.0F, 0.0F);
/* 434 */       for (byte b = 1; b < this.curves.size(); b++) {
/* 435 */         ((Curve)this.curves.get(b)).enlarge(rectBounds);
/*     */       }
/*     */     } 
/* 438 */     return this.cachedBounds = rectBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds getBounds() {
/* 454 */     return new RectBounds(getCachedBounds());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEquivalent(Area paramArea) {
/* 470 */     if (paramArea == this) {
/* 471 */       return true;
/*     */     }
/* 473 */     if (paramArea == null) {
/* 474 */       return false;
/*     */     }
/* 476 */     Vector vector = (new AreaOp.XorOp()).calculate(this.curves, paramArea.curves);
/* 477 */     return vector.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(BaseTransform paramBaseTransform) {
/* 488 */     if (paramBaseTransform == null) {
/* 489 */       throw new NullPointerException("transform must not be null");
/*     */     }
/*     */ 
/*     */     
/* 493 */     this.curves = pathToCurves(getPathIterator(paramBaseTransform));
/* 494 */     invalidateBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Area createTransformedArea(BaseTransform paramBaseTransform) {
/* 509 */     Area area = new Area(this);
/* 510 */     area.transform(paramBaseTransform);
/* 511 */     return area;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/* 518 */     if (!getCachedBounds().contains(paramFloat1, paramFloat2)) {
/* 519 */       return false;
/*     */     }
/* 521 */     Enumeration<Curve> enumeration = this.curves.elements();
/* 522 */     int i = 0;
/* 523 */     while (enumeration.hasMoreElements()) {
/* 524 */       Curve curve = enumeration.nextElement();
/* 525 */       i += curve.crossingsFor(paramFloat1, paramFloat2);
/*     */     } 
/* 527 */     return ((i & 0x1) == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Point2D paramPoint2D) {
/* 535 */     return contains(paramPoint2D.x, paramPoint2D.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 542 */     if (paramFloat3 < 0.0F || paramFloat4 < 0.0F) {
/* 543 */       return false;
/*     */     }
/* 545 */     if (!getCachedBounds().contains(paramFloat1, paramFloat2) || !getCachedBounds().contains(paramFloat1 + paramFloat3, paramFloat2 + paramFloat4)) {
/* 546 */       return false;
/*     */     }
/* 548 */     Crossings crossings = Crossings.findCrossings(this.curves, paramFloat1, paramFloat2, (paramFloat1 + paramFloat3), (paramFloat2 + paramFloat4));
/* 549 */     return (crossings != null && crossings.covers(paramFloat2, (paramFloat2 + paramFloat4)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 556 */     if (paramFloat3 < 0.0F || paramFloat4 < 0.0F) {
/* 557 */       return false;
/*     */     }
/* 559 */     if (!getCachedBounds().intersects(paramFloat1, paramFloat2, paramFloat3, paramFloat4)) {
/* 560 */       return false;
/*     */     }
/* 562 */     Crossings crossings = Crossings.findCrossings(this.curves, paramFloat1, paramFloat2, (paramFloat1 + paramFloat3), (paramFloat2 + paramFloat4));
/* 563 */     return (crossings == null || !crossings.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/* 577 */     return new AreaIterator(this.curves, paramBaseTransform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform, float paramFloat) {
/* 598 */     return new FlatteningPathIterator(getPathIterator(paramBaseTransform), paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public Area copy() {
/* 603 */     return new Area(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Area.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */