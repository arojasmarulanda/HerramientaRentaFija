/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EllipseIterator
/*     */   implements PathIterator
/*     */ {
/*     */   double x;
/*     */   double y;
/*     */   double w;
/*     */   double h;
/*     */   BaseTransform transform;
/*     */   int index;
/*     */   public static final double CtrlVal = 0.5522847498307933D;
/*     */   private static final double pcv = 0.7761423749153966D;
/*     */   private static final double ncv = 0.22385762508460333D;
/*     */   
/*     */   EllipseIterator(Ellipse2D paramEllipse2D, BaseTransform paramBaseTransform) {
/*  44 */     this.x = paramEllipse2D.x;
/*  45 */     this.y = paramEllipse2D.y;
/*  46 */     this.w = paramEllipse2D.width;
/*  47 */     this.h = paramEllipse2D.height;
/*  48 */     this.transform = paramBaseTransform;
/*  49 */     if (this.w < 0.0D || this.h < 0.0D) {
/*  50 */       this.index = 6;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWindingRule() {
/*  61 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDone() {
/*  69 */     return (this.index > 5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void next() {
/*  78 */     this.index++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private static final double[][] ctrlpts = new double[][] { { 1.0D, 0.7761423749153966D, 0.7761423749153966D, 1.0D, 0.5D, 1.0D }, { 0.22385762508460333D, 1.0D, 0.0D, 0.7761423749153966D, 0.0D, 0.5D }, { 0.0D, 0.22385762508460333D, 0.22385762508460333D, 0.0D, 0.5D, 0.0D }, { 0.7761423749153966D, 0.0D, 1.0D, 0.22385762508460333D, 1.0D, 0.5D } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int currentSegment(float[] paramArrayOffloat) {
/* 117 */     if (isDone()) {
/* 118 */       throw new NoSuchElementException("ellipse iterator out of bounds");
/*     */     }
/* 120 */     if (this.index == 5) {
/* 121 */       return 4;
/*     */     }
/* 123 */     if (this.index == 0) {
/* 124 */       double[] arrayOfDouble1 = ctrlpts[3];
/* 125 */       paramArrayOffloat[0] = (float)(this.x + arrayOfDouble1[4] * this.w);
/* 126 */       paramArrayOffloat[1] = (float)(this.y + arrayOfDouble1[5] * this.h);
/* 127 */       if (this.transform != null) {
/* 128 */         this.transform.transform(paramArrayOffloat, 0, paramArrayOffloat, 0, 1);
/*     */       }
/* 130 */       return 0;
/*     */     } 
/* 132 */     double[] arrayOfDouble = ctrlpts[this.index - 1];
/* 133 */     paramArrayOffloat[0] = (float)(this.x + arrayOfDouble[0] * this.w);
/* 134 */     paramArrayOffloat[1] = (float)(this.y + arrayOfDouble[1] * this.h);
/* 135 */     paramArrayOffloat[2] = (float)(this.x + arrayOfDouble[2] * this.w);
/* 136 */     paramArrayOffloat[3] = (float)(this.y + arrayOfDouble[3] * this.h);
/* 137 */     paramArrayOffloat[4] = (float)(this.x + arrayOfDouble[4] * this.w);
/* 138 */     paramArrayOffloat[5] = (float)(this.y + arrayOfDouble[5] * this.h);
/* 139 */     if (this.transform != null) {
/* 140 */       this.transform.transform(paramArrayOffloat, 0, paramArrayOffloat, 0, 3);
/*     */     }
/* 142 */     return 3;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\EllipseIterator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */