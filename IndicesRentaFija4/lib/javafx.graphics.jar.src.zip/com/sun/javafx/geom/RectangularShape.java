/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RectangularShape
/*     */   extends Shape
/*     */ {
/*     */   public abstract float getX();
/*     */   
/*     */   public abstract float getY();
/*     */   
/*     */   public abstract float getWidth();
/*     */   
/*     */   public abstract float getHeight();
/*     */   
/*     */   public float getMinX() {
/*  92 */     return getX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMinY() {
/* 103 */     return getY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaxX() {
/* 114 */     return getX() + getWidth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getMaxY() {
/* 125 */     return getY() + getHeight();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getCenterX() {
/* 136 */     return getX() + getWidth() / 2.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getCenterY() {
/* 147 */     return getY() + getHeight() / 2.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isEmpty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setFrame(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrame(Point2D paramPoint2D, Dimension2D paramDimension2D) {
/* 184 */     setFrame(paramPoint2D.x, paramPoint2D.y, paramDimension2D.width, paramDimension2D.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrameFromDiagonal(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 199 */     if (paramFloat3 < paramFloat1) {
/* 200 */       float f = paramFloat1;
/* 201 */       paramFloat1 = paramFloat3;
/* 202 */       paramFloat3 = f;
/*     */     } 
/* 204 */     if (paramFloat4 < paramFloat2) {
/* 205 */       float f = paramFloat2;
/* 206 */       paramFloat2 = paramFloat4;
/* 207 */       paramFloat4 = f;
/*     */     } 
/* 209 */     setFrame(paramFloat1, paramFloat2, paramFloat3 - paramFloat1, paramFloat4 - paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrameFromDiagonal(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 222 */     setFrameFromDiagonal(paramPoint2D1.x, paramPoint2D1.y, paramPoint2D2.x, paramPoint2D2.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrameFromCenter(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 239 */     float f1 = Math.abs(paramFloat3 - paramFloat1);
/* 240 */     float f2 = Math.abs(paramFloat4 - paramFloat2);
/* 241 */     setFrame(paramFloat1 - f1, paramFloat2 - f2, f1 * 2.0F, f2 * 2.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrameFromCenter(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 253 */     setFrameFromCenter(paramPoint2D1.x, paramPoint2D1.y, paramPoint2D2.x, paramPoint2D2.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Point2D paramPoint2D) {
/* 260 */     return contains(paramPoint2D.x, paramPoint2D.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds getBounds() {
/* 267 */     float f1 = getWidth();
/* 268 */     float f2 = getHeight();
/* 269 */     if (f1 < 0.0F || f2 < 0.0F) {
/* 270 */       return new RectBounds();
/*     */     }
/* 272 */     float f3 = getX();
/* 273 */     float f4 = getY();
/* 274 */     float f5 = (float)Math.floor(f3);
/* 275 */     float f6 = (float)Math.floor(f4);
/* 276 */     float f7 = (float)Math.ceil((f3 + f1));
/* 277 */     float f8 = (float)Math.ceil((f4 + f2));
/* 278 */     return new RectBounds(f5, f6, f7, f8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform, float paramFloat) {
/* 307 */     return new FlatteningPathIterator(getPathIterator(paramBaseTransform), paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 312 */     return getClass().getName() + "[x=" + getClass().getName() + ",y=" + 
/* 313 */       getX() + ",w=" + 
/* 314 */       getY() + ",h=" + 
/* 315 */       getWidth() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\RectangularShape.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */