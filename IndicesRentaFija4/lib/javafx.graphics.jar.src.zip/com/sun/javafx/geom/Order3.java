/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Order3
/*     */   extends Curve
/*     */ {
/*     */   private double x0;
/*     */   private double y0;
/*     */   private double cx0;
/*     */   private double cy0;
/*     */   private double cx1;
/*     */   private double cy1;
/*     */   private double x1;
/*     */   private double y1;
/*     */   private double xmin;
/*     */   private double xmax;
/*     */   private double xcoeff0;
/*     */   private double xcoeff1;
/*     */   private double xcoeff2;
/*     */   private double xcoeff3;
/*     */   private double ycoeff0;
/*     */   private double ycoeff1;
/*     */   private double ycoeff2;
/*     */   private double ycoeff3;
/*     */   private double TforY1;
/*     */   private double YforT1;
/*     */   private double TforY2;
/*     */   private double YforT2;
/*     */   private double TforY3;
/*     */   private double YforT3;
/*     */   
/*     */   public static void insert(Vector paramVector, double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, int paramInt) {
/*  60 */     int i = getHorizontalParams(paramDouble2, paramDouble4, paramDouble6, paramDouble8, paramArrayOfdouble);
/*  61 */     if (i == 0) {
/*     */ 
/*     */       
/*  64 */       addInstance(paramVector, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramInt);
/*     */       
/*     */       return;
/*     */     } 
/*  68 */     paramArrayOfdouble[3] = paramDouble1; paramArrayOfdouble[4] = paramDouble2;
/*  69 */     paramArrayOfdouble[5] = paramDouble3; paramArrayOfdouble[6] = paramDouble4;
/*  70 */     paramArrayOfdouble[7] = paramDouble5; paramArrayOfdouble[8] = paramDouble6;
/*  71 */     paramArrayOfdouble[9] = paramDouble7; paramArrayOfdouble[10] = paramDouble8;
/*  72 */     double d = paramArrayOfdouble[0];
/*  73 */     if (i > 1 && d > paramArrayOfdouble[1]) {
/*     */       
/*  75 */       paramArrayOfdouble[0] = paramArrayOfdouble[1];
/*  76 */       paramArrayOfdouble[1] = d;
/*  77 */       d = paramArrayOfdouble[0];
/*     */     } 
/*  79 */     split(paramArrayOfdouble, 3, d);
/*  80 */     if (i > 1) {
/*     */       
/*  82 */       d = (paramArrayOfdouble[1] - d) / (1.0D - d);
/*  83 */       split(paramArrayOfdouble, 9, d);
/*     */     } 
/*  85 */     int j = 3;
/*  86 */     if (paramInt == -1) {
/*  87 */       j += i * 6;
/*     */     }
/*  89 */     while (i >= 0) {
/*  90 */       addInstance(paramVector, paramArrayOfdouble[j + 0], paramArrayOfdouble[j + 1], paramArrayOfdouble[j + 2], paramArrayOfdouble[j + 3], paramArrayOfdouble[j + 4], paramArrayOfdouble[j + 5], paramArrayOfdouble[j + 6], paramArrayOfdouble[j + 7], paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  96 */       i--;
/*  97 */       if (paramInt == 1) {
/*  98 */         j += 6; continue;
/*     */       } 
/* 100 */       j -= 6;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addInstance(Vector<Order3> paramVector, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, int paramInt) {
/* 111 */     if (paramDouble2 > paramDouble8) {
/* 112 */       paramVector.add(new Order3(paramDouble7, paramDouble8, paramDouble5, paramDouble6, paramDouble3, paramDouble4, paramDouble1, paramDouble2, -paramInt));
/*     */     }
/* 114 */     else if (paramDouble8 > paramDouble2) {
/* 115 */       paramVector.add(new Order3(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramInt));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int solveQuadratic(double[] paramArrayOfdouble1, double[] paramArrayOfdouble2) {
/* 141 */     double d1 = paramArrayOfdouble1[2];
/* 142 */     double d2 = paramArrayOfdouble1[1];
/* 143 */     double d3 = paramArrayOfdouble1[0];
/* 144 */     byte b = 0;
/* 145 */     if (d1 == 0.0D) {
/*     */       
/* 147 */       if (d2 == 0.0D)
/*     */       {
/* 149 */         return -1;
/*     */       }
/* 151 */       paramArrayOfdouble2[b++] = -d3 / d2;
/*     */     } else {
/*     */       
/* 154 */       double d4 = d2 * d2 - 4.0D * d1 * d3;
/* 155 */       if (d4 < 0.0D)
/*     */       {
/* 157 */         return 0;
/*     */       }
/* 159 */       d4 = Math.sqrt(d4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 165 */       if (d2 < 0.0D) {
/* 166 */         d4 = -d4;
/*     */       }
/* 168 */       double d5 = (d2 + d4) / -2.0D;
/*     */       
/* 170 */       paramArrayOfdouble2[b++] = d5 / d1;
/* 171 */       if (d5 != 0.0D) {
/* 172 */         paramArrayOfdouble2[b++] = d3 / d5;
/*     */       }
/*     */     } 
/* 175 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getHorizontalParams(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double[] paramArrayOfdouble) {
/* 219 */     if (paramDouble1 <= paramDouble2 && paramDouble2 <= paramDouble3 && paramDouble3 <= paramDouble4) {
/* 220 */       return 0;
/*     */     }
/* 222 */     paramDouble4 -= paramDouble3;
/* 223 */     paramDouble3 -= paramDouble2;
/* 224 */     paramDouble2 -= paramDouble1;
/* 225 */     paramArrayOfdouble[0] = paramDouble2;
/* 226 */     paramArrayOfdouble[1] = (paramDouble3 - paramDouble2) * 2.0D;
/* 227 */     paramArrayOfdouble[2] = paramDouble4 - paramDouble3 - paramDouble3 + paramDouble2;
/* 228 */     int i = solveQuadratic(paramArrayOfdouble, paramArrayOfdouble);
/* 229 */     byte b1 = 0;
/* 230 */     for (byte b2 = 0; b2 < i; b2++) {
/* 231 */       double d = paramArrayOfdouble[b2];
/*     */       
/* 233 */       if (d > 0.0D && d < 1.0D) {
/* 234 */         if (b1 < b2) {
/* 235 */           paramArrayOfdouble[b1] = d;
/*     */         }
/* 237 */         b1++;
/*     */       } 
/*     */     } 
/* 240 */     return b1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void split(double[] paramArrayOfdouble, int paramInt, double paramDouble) {
/* 251 */     double d7 = paramArrayOfdouble[paramInt + 6];
/* 252 */     double d8 = paramArrayOfdouble[paramInt + 7];
/* 253 */     double d5 = paramArrayOfdouble[paramInt + 4];
/* 254 */     double d6 = paramArrayOfdouble[paramInt + 5];
/* 255 */     d7 = d5 + (d7 - d5) * paramDouble;
/* 256 */     d8 = d6 + (d8 - d6) * paramDouble;
/* 257 */     double d1 = paramArrayOfdouble[paramInt + 0];
/* 258 */     double d2 = paramArrayOfdouble[paramInt + 1];
/* 259 */     double d3 = paramArrayOfdouble[paramInt + 2];
/* 260 */     double d4 = paramArrayOfdouble[paramInt + 3];
/* 261 */     d1 += (d3 - d1) * paramDouble;
/* 262 */     d2 += (d4 - d2) * paramDouble;
/* 263 */     d3 += (d5 - d3) * paramDouble;
/* 264 */     d4 += (d6 - d4) * paramDouble;
/* 265 */     d5 = d3 + (d7 - d3) * paramDouble;
/* 266 */     d6 = d4 + (d8 - d4) * paramDouble;
/* 267 */     d3 = d1 + (d3 - d1) * paramDouble;
/* 268 */     d4 = d2 + (d4 - d2) * paramDouble;
/* 269 */     paramArrayOfdouble[paramInt + 2] = d1;
/* 270 */     paramArrayOfdouble[paramInt + 3] = d2;
/* 271 */     paramArrayOfdouble[paramInt + 4] = d3;
/* 272 */     paramArrayOfdouble[paramInt + 5] = d4;
/* 273 */     paramArrayOfdouble[paramInt + 6] = d3 + (d5 - d3) * paramDouble;
/* 274 */     paramArrayOfdouble[paramInt + 7] = d4 + (d6 - d4) * paramDouble;
/* 275 */     paramArrayOfdouble[paramInt + 8] = d5;
/* 276 */     paramArrayOfdouble[paramInt + 9] = d6;
/* 277 */     paramArrayOfdouble[paramInt + 10] = d7;
/* 278 */     paramArrayOfdouble[paramInt + 11] = d8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Order3(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, int paramInt) {
/* 287 */     super(paramInt);
/*     */ 
/*     */ 
/*     */     
/* 291 */     if (paramDouble4 < paramDouble2) paramDouble4 = paramDouble2; 
/* 292 */     if (paramDouble6 > paramDouble8) paramDouble6 = paramDouble8; 
/* 293 */     this.x0 = paramDouble1;
/* 294 */     this.y0 = paramDouble2;
/* 295 */     this.cx0 = paramDouble3;
/* 296 */     this.cy0 = paramDouble4;
/* 297 */     this.cx1 = paramDouble5;
/* 298 */     this.cy1 = paramDouble6;
/* 299 */     this.x1 = paramDouble7;
/* 300 */     this.y1 = paramDouble8;
/* 301 */     this.xmin = Math.min(Math.min(paramDouble1, paramDouble7), Math.min(paramDouble3, paramDouble5));
/* 302 */     this.xmax = Math.max(Math.max(paramDouble1, paramDouble7), Math.max(paramDouble3, paramDouble5));
/* 303 */     this.xcoeff0 = paramDouble1;
/* 304 */     this.xcoeff1 = (paramDouble3 - paramDouble1) * 3.0D;
/* 305 */     this.xcoeff2 = (paramDouble5 - paramDouble3 - paramDouble3 + paramDouble1) * 3.0D;
/* 306 */     this.xcoeff3 = paramDouble7 - (paramDouble5 - paramDouble3) * 3.0D - paramDouble1;
/* 307 */     this.ycoeff0 = paramDouble2;
/* 308 */     this.ycoeff1 = (paramDouble4 - paramDouble2) * 3.0D;
/* 309 */     this.ycoeff2 = (paramDouble6 - paramDouble4 - paramDouble4 + paramDouble2) * 3.0D;
/* 310 */     this.ycoeff3 = paramDouble8 - (paramDouble6 - paramDouble4) * 3.0D - paramDouble2;
/* 311 */     this.YforT1 = this.YforT2 = this.YforT3 = paramDouble2;
/*     */   }
/*     */   
/*     */   public int getOrder() {
/* 315 */     return 3;
/*     */   }
/*     */   
/*     */   public double getXTop() {
/* 319 */     return this.x0;
/*     */   }
/*     */   
/*     */   public double getYTop() {
/* 323 */     return this.y0;
/*     */   }
/*     */   
/*     */   public double getXBot() {
/* 327 */     return this.x1;
/*     */   }
/*     */   
/*     */   public double getYBot() {
/* 331 */     return this.y1;
/*     */   }
/*     */   
/*     */   public double getXMin() {
/* 335 */     return this.xmin;
/*     */   }
/*     */   
/*     */   public double getXMax() {
/* 339 */     return this.xmax;
/*     */   }
/*     */   
/*     */   public double getX0() {
/* 343 */     return (this.direction == 1) ? this.x0 : this.x1;
/*     */   }
/*     */   
/*     */   public double getY0() {
/* 347 */     return (this.direction == 1) ? this.y0 : this.y1;
/*     */   }
/*     */   
/*     */   public double getCX0() {
/* 351 */     return (this.direction == 1) ? this.cx0 : this.cx1;
/*     */   }
/*     */   
/*     */   public double getCY0() {
/* 355 */     return (this.direction == 1) ? this.cy0 : this.cy1;
/*     */   }
/*     */   
/*     */   public double getCX1() {
/* 359 */     return (this.direction == -1) ? this.cx0 : this.cx1;
/*     */   }
/*     */   
/*     */   public double getCY1() {
/* 363 */     return (this.direction == -1) ? this.cy0 : this.cy1;
/*     */   }
/*     */   
/*     */   public double getX1() {
/* 367 */     return (this.direction == -1) ? this.x0 : this.x1;
/*     */   }
/*     */   
/*     */   public double getY1() {
/* 371 */     return (this.direction == -1) ? this.y0 : this.y1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double TforY(double paramDouble) {
/*     */     double d9;
/* 389 */     if (paramDouble <= this.y0) return 0.0D; 
/* 390 */     if (paramDouble >= this.y1) return 1.0D; 
/* 391 */     if (paramDouble == this.YforT1) return this.TforY1; 
/* 392 */     if (paramDouble == this.YforT2) return this.TforY2; 
/* 393 */     if (paramDouble == this.YforT3) return this.TforY3;
/*     */     
/* 395 */     if (this.ycoeff3 == 0.0D)
/*     */     {
/* 397 */       return Order2.TforY(paramDouble, this.ycoeff0, this.ycoeff1, this.ycoeff2);
/*     */     }
/* 399 */     double d1 = this.ycoeff2 / this.ycoeff3;
/* 400 */     double d2 = this.ycoeff1 / this.ycoeff3;
/* 401 */     double d3 = (this.ycoeff0 - paramDouble) / this.ycoeff3;
/* 402 */     boolean bool = false;
/* 403 */     double d4 = (d1 * d1 - 3.0D * d2) / 9.0D;
/* 404 */     double d5 = (2.0D * d1 * d1 * d1 - 9.0D * d1 * d2 + 27.0D * d3) / 54.0D;
/* 405 */     double d6 = d5 * d5;
/* 406 */     double d7 = d4 * d4 * d4;
/* 407 */     double d8 = d1 / 3.0D;
/*     */     
/* 409 */     if (d6 < d7) {
/* 410 */       double d = Math.acos(d5 / Math.sqrt(d7));
/* 411 */       d4 = -2.0D * Math.sqrt(d4);
/* 412 */       d9 = refine(d1, d2, d3, paramDouble, d4 * Math.cos(d / 3.0D) - d8);
/* 413 */       if (d9 < 0.0D) {
/* 414 */         d9 = refine(d1, d2, d3, paramDouble, d4 * 
/* 415 */             Math.cos((d + 6.283185307179586D) / 3.0D) - d8);
/*     */       }
/* 417 */       if (d9 < 0.0D) {
/* 418 */         d9 = refine(d1, d2, d3, paramDouble, d4 * 
/* 419 */             Math.cos((d - 6.283185307179586D) / 3.0D) - d8);
/*     */       }
/*     */     } else {
/* 422 */       boolean bool1 = (d5 < 0.0D) ? true : false;
/* 423 */       double d10 = Math.sqrt(d6 - d7);
/* 424 */       if (bool1) {
/* 425 */         d5 = -d5;
/*     */       }
/* 427 */       double d11 = Math.pow(d5 + d10, 0.3333333333333333D);
/* 428 */       if (!bool1) {
/* 429 */         d11 = -d11;
/*     */       }
/* 431 */       double d12 = (d11 == 0.0D) ? 0.0D : (d4 / d11);
/* 432 */       d9 = refine(d1, d2, d3, paramDouble, d11 + d12 - d8);
/*     */     } 
/* 434 */     if (d9 < 0.0D) {
/*     */       
/* 436 */       double d10 = 0.0D;
/* 437 */       double d11 = 1.0D;
/*     */       while (true) {
/* 439 */         d9 = (d10 + d11) / 2.0D;
/* 440 */         if (d9 == d10 || d9 == d11) {
/*     */           break;
/*     */         }
/* 443 */         double d = YforT(d9);
/* 444 */         if (d < paramDouble) {
/* 445 */           d10 = d9; continue;
/* 446 */         }  if (d > paramDouble) {
/* 447 */           d11 = d9;
/*     */           continue;
/*     */         } 
/*     */         break;
/*     */       } 
/*     */     } 
/* 453 */     if (d9 >= 0.0D) {
/* 454 */       this.TforY3 = this.TforY2;
/* 455 */       this.YforT3 = this.YforT2;
/* 456 */       this.TforY2 = this.TforY1;
/* 457 */       this.YforT2 = this.YforT1;
/* 458 */       this.TforY1 = d9;
/* 459 */       this.YforT1 = paramDouble;
/*     */     } 
/* 461 */     return d9;
/*     */   }
/*     */ 
/*     */   
/*     */   public double refine(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*     */     double d2, d3;
/* 467 */     if (paramDouble5 < -0.1D || paramDouble5 > 1.1D) {
/* 468 */       return -1.0D;
/*     */     }
/* 470 */     double d1 = YforT(paramDouble5);
/*     */     
/* 472 */     if (d1 < paramDouble4) {
/* 473 */       d2 = paramDouble5;
/* 474 */       d3 = 1.0D;
/*     */     } else {
/* 476 */       d2 = 0.0D;
/* 477 */       d3 = paramDouble5;
/*     */     } 
/* 479 */     double d4 = paramDouble5;
/* 480 */     double d5 = d1;
/* 481 */     boolean bool1 = true;
/* 482 */     while (d1 != paramDouble4) {
/* 483 */       if (!bool1) {
/* 484 */         double d = (d2 + d3) / 2.0D;
/* 485 */         if (d == d2 || d == d3) {
/*     */           break;
/*     */         }
/* 488 */         paramDouble5 = d;
/*     */       } else {
/* 490 */         double d6 = dYforT(paramDouble5, 1);
/* 491 */         if (d6 == 0.0D) {
/* 492 */           bool1 = false;
/*     */           continue;
/*     */         } 
/* 495 */         double d7 = paramDouble5 + (paramDouble4 - d1) / d6;
/* 496 */         if (d7 == paramDouble5 || d7 <= d2 || d7 >= d3) {
/* 497 */           bool1 = false;
/*     */           continue;
/*     */         } 
/* 500 */         paramDouble5 = d7;
/*     */       } 
/* 502 */       d1 = YforT(paramDouble5);
/* 503 */       if (d1 < paramDouble4) {
/* 504 */         d2 = paramDouble5; continue;
/* 505 */       }  if (d1 > paramDouble4) {
/* 506 */         d3 = paramDouble5;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 511 */     boolean bool2 = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 535 */     return (paramDouble5 > 1.0D) ? -1.0D : paramDouble5;
/*     */   }
/*     */   
/*     */   public double XforY(double paramDouble) {
/* 539 */     if (paramDouble <= this.y0) {
/* 540 */       return this.x0;
/*     */     }
/* 542 */     if (paramDouble >= this.y1) {
/* 543 */       return this.x1;
/*     */     }
/* 545 */     return XforT(TforY(paramDouble));
/*     */   }
/*     */   
/*     */   public double XforT(double paramDouble) {
/* 549 */     return ((this.xcoeff3 * paramDouble + this.xcoeff2) * paramDouble + this.xcoeff1) * paramDouble + this.xcoeff0;
/*     */   }
/*     */   
/*     */   public double YforT(double paramDouble) {
/* 553 */     return ((this.ycoeff3 * paramDouble + this.ycoeff2) * paramDouble + this.ycoeff1) * paramDouble + this.ycoeff0;
/*     */   }
/*     */   
/*     */   public double dXforT(double paramDouble, int paramInt) {
/* 557 */     switch (paramInt) {
/*     */       case 0:
/* 559 */         return ((this.xcoeff3 * paramDouble + this.xcoeff2) * paramDouble + this.xcoeff1) * paramDouble + this.xcoeff0;
/*     */       case 1:
/* 561 */         return (3.0D * this.xcoeff3 * paramDouble + 2.0D * this.xcoeff2) * paramDouble + this.xcoeff1;
/*     */       case 2:
/* 563 */         return 6.0D * this.xcoeff3 * paramDouble + 2.0D * this.xcoeff2;
/*     */       case 3:
/* 565 */         return 6.0D * this.xcoeff3;
/*     */     } 
/* 567 */     return 0.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public double dYforT(double paramDouble, int paramInt) {
/* 572 */     switch (paramInt) {
/*     */       case 0:
/* 574 */         return ((this.ycoeff3 * paramDouble + this.ycoeff2) * paramDouble + this.ycoeff1) * paramDouble + this.ycoeff0;
/*     */       case 1:
/* 576 */         return (3.0D * this.ycoeff3 * paramDouble + 2.0D * this.ycoeff2) * paramDouble + this.ycoeff1;
/*     */       case 2:
/* 578 */         return 6.0D * this.ycoeff3 * paramDouble + 2.0D * this.ycoeff2;
/*     */       case 3:
/* 580 */         return 6.0D * this.ycoeff3;
/*     */     } 
/* 582 */     return 0.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public double nextVertical(double paramDouble1, double paramDouble2) {
/* 587 */     double[] arrayOfDouble = { this.xcoeff1, 2.0D * this.xcoeff2, 3.0D * this.xcoeff3 };
/* 588 */     int i = solveQuadratic(arrayOfDouble, arrayOfDouble);
/* 589 */     for (byte b = 0; b < i; b++) {
/* 590 */       if (arrayOfDouble[b] > paramDouble1 && arrayOfDouble[b] < paramDouble2) {
/* 591 */         paramDouble2 = arrayOfDouble[b];
/*     */       }
/*     */     } 
/* 594 */     return paramDouble2;
/*     */   }
/*     */   
/*     */   public void enlarge(RectBounds paramRectBounds) {
/* 598 */     paramRectBounds.add((float)this.x0, (float)this.y0);
/* 599 */     double[] arrayOfDouble = { this.xcoeff1, 2.0D * this.xcoeff2, 3.0D * this.xcoeff3 };
/* 600 */     int i = solveQuadratic(arrayOfDouble, arrayOfDouble);
/* 601 */     for (byte b = 0; b < i; b++) {
/* 602 */       double d = arrayOfDouble[b];
/* 603 */       if (d > 0.0D && d < 1.0D) {
/* 604 */         paramRectBounds.add((float)XforT(d), (float)YforT(d));
/*     */       }
/*     */     } 
/* 607 */     paramRectBounds.add((float)this.x1, (float)this.y1);
/*     */   }
/*     */   public Curve getSubCurve(double paramDouble1, double paramDouble2, int paramInt) {
/*     */     byte b;
/* 611 */     if (paramDouble1 <= this.y0 && paramDouble2 >= this.y1) {
/* 612 */       return getWithDirection(paramInt);
/*     */     }
/* 614 */     double[] arrayOfDouble = new double[14];
/*     */     
/* 616 */     double d1 = TforY(paramDouble1);
/* 617 */     double d2 = TforY(paramDouble2);
/* 618 */     arrayOfDouble[0] = this.x0;
/* 619 */     arrayOfDouble[1] = this.y0;
/* 620 */     arrayOfDouble[2] = this.cx0;
/* 621 */     arrayOfDouble[3] = this.cy0;
/* 622 */     arrayOfDouble[4] = this.cx1;
/* 623 */     arrayOfDouble[5] = this.cy1;
/* 624 */     arrayOfDouble[6] = this.x1;
/* 625 */     arrayOfDouble[7] = this.y1;
/* 626 */     if (d1 > d2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 641 */       double d = d1;
/* 642 */       d1 = d2;
/* 643 */       d2 = d;
/*     */     } 
/* 645 */     if (d2 < 1.0D) {
/* 646 */       split(arrayOfDouble, 0, d2);
/*     */     }
/*     */     
/* 649 */     if (d1 <= 0.0D) {
/* 650 */       b = 0;
/*     */     } else {
/* 652 */       split(arrayOfDouble, 0, d1 / d2);
/* 653 */       b = 6;
/*     */     } 
/* 655 */     return new Order3(arrayOfDouble[b + 0], paramDouble1, arrayOfDouble[b + 2], arrayOfDouble[b + 3], arrayOfDouble[b + 4], arrayOfDouble[b + 5], arrayOfDouble[b + 6], paramDouble2, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Curve getReversedCurve() {
/* 663 */     return new Order3(this.x0, this.y0, this.cx0, this.cy0, this.cx1, this.cy1, this.x1, this.y1, -this.direction);
/*     */   }
/*     */   
/*     */   public int getSegment(float[] paramArrayOffloat) {
/* 667 */     if (this.direction == 1) {
/* 668 */       paramArrayOffloat[0] = (float)this.cx0;
/* 669 */       paramArrayOffloat[1] = (float)this.cy0;
/* 670 */       paramArrayOffloat[2] = (float)this.cx1;
/* 671 */       paramArrayOffloat[3] = (float)this.cy1;
/* 672 */       paramArrayOffloat[4] = (float)this.x1;
/* 673 */       paramArrayOffloat[5] = (float)this.y1;
/*     */     } else {
/* 675 */       paramArrayOffloat[0] = (float)this.cx1;
/* 676 */       paramArrayOffloat[1] = (float)this.cy1;
/* 677 */       paramArrayOffloat[2] = (float)this.cx0;
/* 678 */       paramArrayOffloat[3] = (float)this.cy0;
/* 679 */       paramArrayOffloat[4] = (float)this.x0;
/* 680 */       paramArrayOffloat[5] = (float)this.y0;
/*     */     } 
/* 682 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public String controlPointString() {
/* 687 */     return "(" + round(getCX0()) + ", " + round(getCY0()) + "), (" + 
/* 688 */       round(getCX1()) + ", " + round(getCY1()) + "), ";
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Order3.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */