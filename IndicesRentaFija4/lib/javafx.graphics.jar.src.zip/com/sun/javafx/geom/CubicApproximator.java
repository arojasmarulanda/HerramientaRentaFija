/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CubicApproximator
/*     */ {
/*     */   private float accuracy;
/*     */   private float maxCubicSize;
/*     */   
/*     */   public CubicApproximator(float paramFloat1, float paramFloat2) {
/*  39 */     this.accuracy = paramFloat1;
/*  40 */     this.maxCubicSize = paramFloat2;
/*     */   }
/*     */   
/*     */   public void setAccuracy(float paramFloat) {
/*  44 */     this.accuracy = paramFloat;
/*     */   }
/*     */   
/*     */   public float getAccuracy() {
/*  48 */     return this.accuracy;
/*     */   }
/*     */   
/*     */   public void setMaxCubicSize(float paramFloat) {
/*  52 */     this.maxCubicSize = paramFloat;
/*     */   }
/*     */   
/*     */   public float getMaxCubicSize() {
/*  56 */     return this.maxCubicSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public float approximate(List<QuadCurve2D> paramList, List<CubicCurve2D> paramList1, CubicCurve2D paramCubicCurve2D) {
/*  61 */     float f = getApproxError(paramCubicCurve2D);
/*  62 */     if (f < this.accuracy) {
/*  63 */       paramList1.add(paramCubicCurve2D);
/*  64 */       paramList.add(approximate(paramCubicCurve2D));
/*  65 */       return f;
/*     */     } 
/*  67 */     SplitCubic(paramList1, new float[] { paramCubicCurve2D.x1, paramCubicCurve2D.y1, paramCubicCurve2D.ctrlx1, paramCubicCurve2D.ctrly1, paramCubicCurve2D.ctrlx2, paramCubicCurve2D.ctrly2, paramCubicCurve2D.x2, paramCubicCurve2D.y2 });
/*     */ 
/*     */ 
/*     */     
/*  71 */     return approximate(paramList1, paramList);
/*     */   }
/*     */ 
/*     */   
/*     */   public float approximate(List<QuadCurve2D> paramList, CubicCurve2D paramCubicCurve2D) {
/*  76 */     ArrayList<CubicCurve2D> arrayList = new ArrayList();
/*  77 */     return approximate(paramList, arrayList, paramCubicCurve2D);
/*     */   }
/*     */ 
/*     */   
/*     */   private QuadCurve2D approximate(CubicCurve2D paramCubicCurve2D) {
/*  82 */     return new QuadCurve2D(paramCubicCurve2D.x1, paramCubicCurve2D.y1, (3.0F * paramCubicCurve2D.ctrlx1 - paramCubicCurve2D.x1 + 3.0F * paramCubicCurve2D.ctrlx2 - paramCubicCurve2D.x2) / 4.0F, (3.0F * paramCubicCurve2D.ctrly1 - paramCubicCurve2D.y1 + 3.0F * paramCubicCurve2D.ctrly2 - paramCubicCurve2D.y2) / 4.0F, paramCubicCurve2D.x2, paramCubicCurve2D.y2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float approximate(List<CubicCurve2D> paramList, List<QuadCurve2D> paramList1) {
/*  91 */     QuadCurve2D quadCurve2D = approximate(paramList.get(0));
/*  92 */     float f = compareCPs(paramList
/*  93 */         .get(0), elevate(quadCurve2D));
/*     */     
/*  95 */     paramList1.add(quadCurve2D);
/*     */     
/*  97 */     for (byte b = 1; b < paramList.size(); b++) {
/*  98 */       quadCurve2D = approximate(paramList.get(b));
/*  99 */       float f1 = compareCPs(paramList
/* 100 */           .get(b), elevate(quadCurve2D));
/* 101 */       if (f1 > f) {
/* 102 */         f = f1;
/*     */       }
/* 104 */       paramList1.add(quadCurve2D);
/*     */     } 
/* 106 */     return f;
/*     */   }
/*     */   
/*     */   private static CubicCurve2D elevate(QuadCurve2D paramQuadCurve2D) {
/* 110 */     return new CubicCurve2D(paramQuadCurve2D.x1, paramQuadCurve2D.y1, (paramQuadCurve2D.x1 + 2.0F * paramQuadCurve2D.ctrlx) / 3.0F, (paramQuadCurve2D.y1 + 2.0F * paramQuadCurve2D.ctrly) / 3.0F, (2.0F * paramQuadCurve2D.ctrlx + paramQuadCurve2D.x2) / 3.0F, (2.0F * paramQuadCurve2D.ctrly + paramQuadCurve2D.y2) / 3.0F, paramQuadCurve2D.x2, paramQuadCurve2D.y2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float compare(CubicCurve2D paramCubicCurve2D1, CubicCurve2D paramCubicCurve2D2) {
/* 119 */     float f1 = Math.abs(paramCubicCurve2D1.x1 - paramCubicCurve2D2.x1);
/* 120 */     float f2 = Math.abs(paramCubicCurve2D1.y1 - paramCubicCurve2D2.y1);
/* 121 */     if (f1 < f2) f1 = f2; 
/* 122 */     f2 = Math.abs(paramCubicCurve2D1.ctrlx1 - paramCubicCurve2D2.ctrlx1);
/* 123 */     if (f1 < f2) f1 = f2; 
/* 124 */     f2 = Math.abs(paramCubicCurve2D1.ctrly1 - paramCubicCurve2D2.ctrly1);
/* 125 */     if (f1 < f2) f1 = f2; 
/* 126 */     f2 = Math.abs(paramCubicCurve2D1.ctrlx2 - paramCubicCurve2D2.ctrlx2);
/* 127 */     if (f1 < f2) f1 = f2; 
/* 128 */     f2 = Math.abs(paramCubicCurve2D1.ctrly2 - paramCubicCurve2D2.ctrly2);
/* 129 */     if (f1 < f2) f1 = f2; 
/* 130 */     f2 = Math.abs(paramCubicCurve2D1.x2 - paramCubicCurve2D2.x2);
/* 131 */     if (f1 < f2) f1 = f2; 
/* 132 */     f2 = Math.abs(paramCubicCurve2D1.y2 - paramCubicCurve2D2.y2);
/* 133 */     if (f1 < f2) f1 = f2;
/*     */     
/* 135 */     return f1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float getApproxError(float[] paramArrayOffloat) {
/* 142 */     float f1 = (-3.0F * paramArrayOffloat[2] + paramArrayOffloat[0] + 3.0F * paramArrayOffloat[4] - paramArrayOffloat[6]) / 6.0F;
/*     */     
/* 144 */     float f2 = (-3.0F * paramArrayOffloat[3] + paramArrayOffloat[1] + 3.0F * paramArrayOffloat[5] - paramArrayOffloat[7]) / 6.0F;
/* 145 */     if (f1 < f2) f1 = f2; 
/* 146 */     f2 = (3.0F * paramArrayOffloat[2] - paramArrayOffloat[0] - 3.0F * paramArrayOffloat[4] + paramArrayOffloat[6]) / 6.0F;
/* 147 */     if (f1 < f2) f1 = f2; 
/* 148 */     f2 = (3.0F * paramArrayOffloat[3] - paramArrayOffloat[1] - 3.0F * paramArrayOffloat[5] + paramArrayOffloat[7]) / 6.0F;
/* 149 */     if (f1 < f2) f1 = f2; 
/* 150 */     return f1;
/*     */   }
/*     */   
/*     */   public static float getApproxError(CubicCurve2D paramCubicCurve2D) {
/* 154 */     return getApproxError(new float[] { paramCubicCurve2D.x1, paramCubicCurve2D.y1, paramCubicCurve2D.ctrlx1, paramCubicCurve2D.ctrly1, paramCubicCurve2D.ctrlx2, paramCubicCurve2D.ctrly2, paramCubicCurve2D.x2, paramCubicCurve2D.y2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float compareCPs(CubicCurve2D paramCubicCurve2D1, CubicCurve2D paramCubicCurve2D2) {
/* 161 */     float f1 = Math.abs(paramCubicCurve2D1.ctrlx1 - paramCubicCurve2D2.ctrlx1);
/* 162 */     float f2 = Math.abs(paramCubicCurve2D1.ctrly1 - paramCubicCurve2D2.ctrly1);
/* 163 */     if (f1 < f2) f1 = f2; 
/* 164 */     f2 = Math.abs(paramCubicCurve2D1.ctrlx2 - paramCubicCurve2D2.ctrlx2);
/* 165 */     if (f1 < f2) f1 = f2; 
/* 166 */     f2 = Math.abs(paramCubicCurve2D1.ctrly2 - paramCubicCurve2D2.ctrly2);
/* 167 */     if (f1 < f2) f1 = f2; 
/* 168 */     return f1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ProcessMonotonicCubic(List<CubicCurve2D> paramList, float[] paramArrayOffloat) {
/* 181 */     float[] arrayOfFloat = new float[8];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     float f2 = paramArrayOffloat[0], f1 = f2;
/* 187 */     float f4 = paramArrayOffloat[1], f3 = f4;
/*     */     
/* 189 */     for (byte b = 2; b < 8; b += 2) {
/* 190 */       f1 = (f1 > paramArrayOffloat[b]) ? paramArrayOffloat[b] : f1;
/* 191 */       f2 = (f2 < paramArrayOffloat[b]) ? paramArrayOffloat[b] : f2;
/* 192 */       f3 = (f3 > paramArrayOffloat[b + 1]) ? paramArrayOffloat[b + 1] : f3;
/* 193 */       f4 = (f4 < paramArrayOffloat[b + 1]) ? paramArrayOffloat[b + 1] : f4;
/*     */     } 
/*     */     
/* 196 */     if (f2 - f1 > this.maxCubicSize || f4 - f3 > this.maxCubicSize || 
/* 197 */       getApproxError(paramArrayOffloat) > this.accuracy) {
/* 198 */       arrayOfFloat[6] = paramArrayOffloat[6];
/* 199 */       arrayOfFloat[7] = paramArrayOffloat[7];
/* 200 */       arrayOfFloat[4] = (paramArrayOffloat[4] + paramArrayOffloat[6]) / 2.0F;
/* 201 */       arrayOfFloat[5] = (paramArrayOffloat[5] + paramArrayOffloat[7]) / 2.0F;
/* 202 */       float f5 = (paramArrayOffloat[2] + paramArrayOffloat[4]) / 2.0F;
/* 203 */       float f6 = (paramArrayOffloat[3] + paramArrayOffloat[5]) / 2.0F;
/* 204 */       arrayOfFloat[2] = (f5 + arrayOfFloat[4]) / 2.0F;
/* 205 */       arrayOfFloat[3] = (f6 + arrayOfFloat[5]) / 2.0F;
/* 206 */       paramArrayOffloat[2] = (paramArrayOffloat[0] + paramArrayOffloat[2]) / 2.0F;
/* 207 */       paramArrayOffloat[3] = (paramArrayOffloat[1] + paramArrayOffloat[3]) / 2.0F;
/* 208 */       paramArrayOffloat[4] = (paramArrayOffloat[2] + f5) / 2.0F;
/* 209 */       paramArrayOffloat[5] = (paramArrayOffloat[3] + f6) / 2.0F;
/* 210 */       arrayOfFloat[0] = (paramArrayOffloat[4] + arrayOfFloat[2]) / 2.0F; paramArrayOffloat[6] = (paramArrayOffloat[4] + arrayOfFloat[2]) / 2.0F;
/* 211 */       arrayOfFloat[1] = (paramArrayOffloat[5] + arrayOfFloat[3]) / 2.0F; paramArrayOffloat[7] = (paramArrayOffloat[5] + arrayOfFloat[3]) / 2.0F;
/*     */       
/* 213 */       ProcessMonotonicCubic(paramList, paramArrayOffloat);
/*     */       
/* 215 */       ProcessMonotonicCubic(paramList, arrayOfFloat);
/*     */     } else {
/* 217 */       paramList.add(new CubicCurve2D(paramArrayOffloat[0], paramArrayOffloat[1], paramArrayOffloat[2], paramArrayOffloat[3], paramArrayOffloat[4], paramArrayOffloat[5], paramArrayOffloat[6], paramArrayOffloat[7]));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void SplitCubic(List<CubicCurve2D> paramList, float[] paramArrayOffloat) {
/* 234 */     float[] arrayOfFloat1 = new float[4];
/* 235 */     float[] arrayOfFloat2 = new float[3];
/* 236 */     float[] arrayOfFloat3 = new float[2];
/* 237 */     byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 244 */     if ((paramArrayOffloat[0] > paramArrayOffloat[2] || paramArrayOffloat[2] > paramArrayOffloat[4] || paramArrayOffloat[4] > paramArrayOffloat[6]) && (paramArrayOffloat[0] < paramArrayOffloat[2] || paramArrayOffloat[2] < paramArrayOffloat[4] || paramArrayOffloat[4] < paramArrayOffloat[6])) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 254 */       arrayOfFloat2[2] = -paramArrayOffloat[0] + 3.0F * paramArrayOffloat[2] - 3.0F * paramArrayOffloat[4] + paramArrayOffloat[6];
/* 255 */       arrayOfFloat2[1] = 2.0F * (paramArrayOffloat[0] - 2.0F * paramArrayOffloat[2] + paramArrayOffloat[4]);
/* 256 */       arrayOfFloat2[0] = -paramArrayOffloat[0] + paramArrayOffloat[2];
/*     */       
/* 258 */       int i = QuadCurve2D.solveQuadratic(arrayOfFloat2, arrayOfFloat3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 264 */       for (byte b1 = 0; b1 < i; b1++) {
/* 265 */         if (arrayOfFloat3[b1] > 0.0F && arrayOfFloat3[b1] < 1.0F) {
/* 266 */           arrayOfFloat1[b++] = arrayOfFloat3[b1];
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 276 */     if ((paramArrayOffloat[1] > paramArrayOffloat[3] || paramArrayOffloat[3] > paramArrayOffloat[5] || paramArrayOffloat[5] > paramArrayOffloat[7]) && (paramArrayOffloat[1] < paramArrayOffloat[3] || paramArrayOffloat[3] < paramArrayOffloat[5] || paramArrayOffloat[5] < paramArrayOffloat[7])) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 286 */       arrayOfFloat2[2] = -paramArrayOffloat[1] + 3.0F * paramArrayOffloat[3] - 3.0F * paramArrayOffloat[5] + paramArrayOffloat[7];
/* 287 */       arrayOfFloat2[1] = 2.0F * (paramArrayOffloat[1] - 2.0F * paramArrayOffloat[3] + paramArrayOffloat[5]);
/* 288 */       arrayOfFloat2[0] = -paramArrayOffloat[1] + paramArrayOffloat[3];
/*     */       
/* 290 */       int i = QuadCurve2D.solveQuadratic(arrayOfFloat2, arrayOfFloat3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 296 */       for (byte b1 = 0; b1 < i; b1++) {
/* 297 */         if (arrayOfFloat3[b1] > 0.0F && arrayOfFloat3[b1] < 1.0F) {
/* 298 */           arrayOfFloat1[b++] = arrayOfFloat3[b1];
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 303 */     if (b > 0) {
/*     */ 
/*     */ 
/*     */       
/* 307 */       Arrays.sort(arrayOfFloat1, 0, b);
/*     */ 
/*     */       
/* 310 */       ProcessFirstMonotonicPartOfCubic(paramList, paramArrayOffloat, arrayOfFloat1[0]);
/* 311 */       for (byte b1 = 1; b1 < b; b1++) {
/* 312 */         float f = arrayOfFloat1[b1] - arrayOfFloat1[b1 - 1];
/* 313 */         if (f > 0.0F) {
/* 314 */           ProcessFirstMonotonicPartOfCubic(paramList, paramArrayOffloat, f / (1.0F - arrayOfFloat1[b1 - 1]));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 321 */     ProcessMonotonicCubic(paramList, paramArrayOffloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ProcessFirstMonotonicPartOfCubic(List<CubicCurve2D> paramList, float[] paramArrayOffloat, float paramFloat) {
/* 333 */     float[] arrayOfFloat = new float[8];
/*     */ 
/*     */     
/* 336 */     arrayOfFloat[0] = paramArrayOffloat[0];
/* 337 */     arrayOfFloat[1] = paramArrayOffloat[1];
/* 338 */     float f1 = paramArrayOffloat[2] + paramFloat * (paramArrayOffloat[4] - paramArrayOffloat[2]);
/* 339 */     float f2 = paramArrayOffloat[3] + paramFloat * (paramArrayOffloat[5] - paramArrayOffloat[3]);
/* 340 */     arrayOfFloat[2] = paramArrayOffloat[0] + paramFloat * (paramArrayOffloat[2] - paramArrayOffloat[0]);
/* 341 */     arrayOfFloat[3] = paramArrayOffloat[1] + paramFloat * (paramArrayOffloat[3] - paramArrayOffloat[1]);
/* 342 */     arrayOfFloat[4] = arrayOfFloat[2] + paramFloat * (f1 - arrayOfFloat[2]);
/* 343 */     arrayOfFloat[5] = arrayOfFloat[3] + paramFloat * (f2 - arrayOfFloat[3]);
/* 344 */     paramArrayOffloat[4] = paramArrayOffloat[4] + paramFloat * (paramArrayOffloat[6] - paramArrayOffloat[4]);
/* 345 */     paramArrayOffloat[5] = paramArrayOffloat[5] + paramFloat * (paramArrayOffloat[7] - paramArrayOffloat[5]);
/* 346 */     paramArrayOffloat[2] = f1 + paramFloat * (paramArrayOffloat[4] - f1);
/* 347 */     paramArrayOffloat[3] = f2 + paramFloat * (paramArrayOffloat[5] - f2);
/* 348 */     arrayOfFloat[6] = arrayOfFloat[4] + paramFloat * (paramArrayOffloat[2] - arrayOfFloat[4]); paramArrayOffloat[0] = arrayOfFloat[4] + paramFloat * (paramArrayOffloat[2] - arrayOfFloat[4]);
/* 349 */     arrayOfFloat[7] = arrayOfFloat[5] + paramFloat * (paramArrayOffloat[3] - arrayOfFloat[5]); paramArrayOffloat[1] = arrayOfFloat[5] + paramFloat * (paramArrayOffloat[3] - arrayOfFloat[5]);
/*     */     
/* 351 */     ProcessMonotonicCubic(paramList, arrayOfFloat);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\CubicApproximator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */