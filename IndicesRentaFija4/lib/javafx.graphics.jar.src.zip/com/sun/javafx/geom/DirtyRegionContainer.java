/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DirtyRegionContainer
/*     */ {
/*     */   public static final int DTR_OK = 1;
/*     */   public static final int DTR_CONTAINS_CLIP = 0;
/*     */   private RectBounds[] dirtyRegions;
/*     */   private int emptyIndex;
/*     */   private int[][] heap;
/*     */   private int heapSize;
/*     */   private long invalidMask;
/*     */   
/*     */   public DirtyRegionContainer(int paramInt) {
/*  45 */     initDirtyRegions(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  50 */     if (paramObject instanceof DirtyRegionContainer) {
/*  51 */       DirtyRegionContainer dirtyRegionContainer = (DirtyRegionContainer)paramObject;
/*  52 */       if (size() != dirtyRegionContainer.size()) return false; 
/*  53 */       for (byte b = 0; b < this.emptyIndex; b++) {
/*  54 */         if (!getDirtyRegion(b).equals(dirtyRegionContainer.getDirtyRegion(b))) return false; 
/*     */       } 
/*  56 */       return true;
/*     */     } 
/*  58 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  63 */     int i = 5;
/*  64 */     i = 97 * i + Arrays.deepHashCode((Object[])this.dirtyRegions);
/*  65 */     i = 97 * i + this.emptyIndex;
/*  66 */     return i;
/*     */   }
/*     */   
/*     */   public DirtyRegionContainer deriveWithNewRegion(RectBounds paramRectBounds) {
/*  70 */     if (paramRectBounds == null) {
/*  71 */       return this;
/*     */     }
/*  73 */     this.dirtyRegions[0].deriveWithNewBounds(paramRectBounds);
/*  74 */     this.emptyIndex = 1;
/*  75 */     return this;
/*     */   }
/*     */   
/*     */   public DirtyRegionContainer deriveWithNewRegions(RectBounds[] paramArrayOfRectBounds) {
/*  79 */     if (paramArrayOfRectBounds == null || paramArrayOfRectBounds.length == 0)
/*     */     {
/*     */       
/*  82 */       return this;
/*     */     }
/*  84 */     if (paramArrayOfRectBounds.length > maxSpace()) {
/*  85 */       initDirtyRegions(paramArrayOfRectBounds.length);
/*     */     }
/*     */     
/*  88 */     regioncopy(paramArrayOfRectBounds, 0, this.dirtyRegions, 0, paramArrayOfRectBounds.length);
/*  89 */     this.emptyIndex = paramArrayOfRectBounds.length;
/*  90 */     return this;
/*     */   }
/*     */   
/*     */   public DirtyRegionContainer deriveWithNewContainer(DirtyRegionContainer paramDirtyRegionContainer) {
/*  94 */     if (paramDirtyRegionContainer == null || paramDirtyRegionContainer
/*  95 */       .maxSpace() == 0)
/*     */     {
/*  97 */       return this;
/*     */     }
/*     */     
/* 100 */     if (paramDirtyRegionContainer.maxSpace() > maxSpace()) {
/* 101 */       initDirtyRegions(paramDirtyRegionContainer.maxSpace());
/*     */     }
/*     */     
/* 104 */     regioncopy(paramDirtyRegionContainer.dirtyRegions, 0, this.dirtyRegions, 0, paramDirtyRegionContainer.emptyIndex);
/* 105 */     this.emptyIndex = paramDirtyRegionContainer.emptyIndex;
/* 106 */     return this;
/*     */   }
/*     */   
/*     */   private void initDirtyRegions(int paramInt) {
/* 110 */     this.dirtyRegions = new RectBounds[paramInt];
/* 111 */     for (byte b = 0; b < paramInt; b++) {
/* 112 */       this.dirtyRegions[b] = new RectBounds();
/*     */     }
/* 114 */     this.emptyIndex = 0;
/*     */   }
/*     */   
/*     */   public DirtyRegionContainer copy() {
/* 118 */     DirtyRegionContainer dirtyRegionContainer = new DirtyRegionContainer(maxSpace());
/* 119 */     regioncopy(this.dirtyRegions, 0, dirtyRegionContainer.dirtyRegions, 0, this.emptyIndex);
/* 120 */     dirtyRegionContainer.emptyIndex = this.emptyIndex;
/* 121 */     return dirtyRegionContainer;
/*     */   }
/*     */   
/*     */   public int maxSpace() {
/* 125 */     return this.dirtyRegions.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds getDirtyRegion(int paramInt) {
/* 134 */     return this.dirtyRegions[paramInt];
/*     */   }
/*     */   
/*     */   public void setDirtyRegion(int paramInt, RectBounds paramRectBounds) {
/* 138 */     this.dirtyRegions[paramInt] = paramRectBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDirtyRegion(RectBounds paramRectBounds) {
/* 146 */     if (paramRectBounds.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 150 */     byte b1 = 0;
/* 151 */     int i = this.emptyIndex;
/*     */     
/* 153 */     for (byte b2 = 0; b2 < i; b2++) {
/*     */       
/* 155 */       RectBounds rectBounds = this.dirtyRegions[b1];
/* 156 */       if (paramRectBounds.intersects(rectBounds)) {
/* 157 */         paramRectBounds.unionWith(rectBounds);
/* 158 */         RectBounds rectBounds1 = this.dirtyRegions[b1];
/* 159 */         this.dirtyRegions[b1] = this.dirtyRegions[this.emptyIndex - 1];
/* 160 */         this.dirtyRegions[this.emptyIndex - 1] = rectBounds1;
/* 161 */         this.emptyIndex--;
/*     */       } else {
/* 163 */         b1++;
/*     */       } 
/*     */     } 
/* 166 */     if (hasSpace()) {
/* 167 */       RectBounds rectBounds = this.dirtyRegions[this.emptyIndex];
/* 168 */       rectBounds.deriveWithNewBounds(paramRectBounds);
/* 169 */       this.emptyIndex++;
/*     */       
/*     */       return;
/*     */     } 
/* 173 */     if (this.dirtyRegions.length == 1) {
/* 174 */       this.dirtyRegions[0].deriveWithUnion(paramRectBounds);
/*     */     } else {
/* 176 */       compress(paramRectBounds);
/*     */     } 
/*     */   }
/*     */   public void merge(DirtyRegionContainer paramDirtyRegionContainer) {
/* 180 */     int i = paramDirtyRegionContainer.size();
/* 181 */     for (byte b = 0; b < i; b++) {
/* 182 */       addDirtyRegion(paramDirtyRegionContainer.getDirtyRegion(b));
/*     */     }
/*     */   }
/*     */   
/*     */   public int size() {
/* 187 */     return this.emptyIndex;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 191 */     this.emptyIndex = 0;
/*     */   }
/*     */   
/*     */   private RectBounds compress(RectBounds paramRectBounds) {
/* 195 */     compress_heap();
/* 196 */     addDirtyRegion(paramRectBounds);
/* 197 */     return paramRectBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasSpace() {
/* 205 */     return (this.emptyIndex < this.dirtyRegions.length);
/*     */   }
/*     */ 
/*     */   
/*     */   private void regioncopy(RectBounds[] paramArrayOfRectBounds1, int paramInt1, RectBounds[] paramArrayOfRectBounds2, int paramInt2, int paramInt3) {
/* 210 */     for (byte b = 0; b < paramInt3; b++) {
/* 211 */       RectBounds rectBounds = paramArrayOfRectBounds1[paramInt1++];
/* 212 */       if (rectBounds == null) {
/* 213 */         paramArrayOfRectBounds2[paramInt2++].makeEmpty();
/*     */       } else {
/* 215 */         paramArrayOfRectBounds2[paramInt2++].deriveWithNewBounds(rectBounds);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean checkAndClearRegion(int paramInt) {
/* 221 */     boolean bool = false;
/* 222 */     if (this.dirtyRegions[paramInt].isEmpty()) {
/* 223 */       System.arraycopy(this.dirtyRegions, paramInt + 1, this.dirtyRegions, paramInt, this.emptyIndex - paramInt - 1);
/* 224 */       this.emptyIndex--;
/* 225 */       bool = true;
/*     */     } 
/*     */     
/* 228 */     return bool;
/*     */   }
/*     */   
/*     */   public void grow(int paramInt1, int paramInt2) {
/* 232 */     if (paramInt1 != 0 || paramInt2 != 0) {
/* 233 */       for (byte b = 0; b < this.emptyIndex; b++) {
/* 234 */         getDirtyRegion(b).grow(paramInt1, paramInt2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void roundOut() {
/* 240 */     for (byte b = 0; b < this.emptyIndex; b++) {
/* 241 */       this.dirtyRegions[b].roundOut();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 247 */     StringBuilder stringBuilder = new StringBuilder();
/* 248 */     for (byte b = 0; b < this.emptyIndex; b++) {
/* 249 */       stringBuilder.append(this.dirtyRegions[b]);
/* 250 */       stringBuilder.append('\n');
/*     */     } 
/* 252 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void heapCompress() {
/* 263 */     this.invalidMask = 0L;
/* 264 */     int[] arrayOfInt = new int[this.dirtyRegions.length];
/* 265 */     for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
/* 266 */       arrayOfInt[b1] = b1;
/*     */     }
/*     */ 
/*     */     
/* 270 */     for (byte b2 = 0; b2 < this.dirtyRegions.length / 2; b2++) {
/* 271 */       int[] arrayOfInt1 = takeMinWithMap(arrayOfInt);
/* 272 */       int i = resolveMap(arrayOfInt, arrayOfInt1[1]);
/* 273 */       int j = resolveMap(arrayOfInt, arrayOfInt1[2]);
/* 274 */       if (i != j) {
/* 275 */         this.dirtyRegions[i].deriveWithUnion(this.dirtyRegions[j]);
/* 276 */         arrayOfInt[j] = i;
/* 277 */         this.invalidMask |= (1 << i);
/* 278 */         this.invalidMask |= (1 << j);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 284 */     for (byte b3 = 0; b3 < this.emptyIndex; b3++) {
/* 285 */       if (arrayOfInt[b3] != b3) {
/* 286 */         for (; arrayOfInt[this.emptyIndex - 1] != this.emptyIndex - 1; this.emptyIndex--);
/* 287 */         if (b3 < this.emptyIndex - 1) {
/* 288 */           RectBounds rectBounds = this.dirtyRegions[this.emptyIndex - 1];
/* 289 */           this.dirtyRegions[this.emptyIndex - 1] = this.dirtyRegions[b3];
/* 290 */           this.dirtyRegions[b3] = rectBounds;
/* 291 */           arrayOfInt[b3] = b3;
/* 292 */           this.emptyIndex--;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void heapify() {
/* 299 */     for (int i = this.heapSize / 2; i >= 0; i--) {
/* 300 */       siftDown(i);
/*     */     }
/*     */   }
/*     */   
/*     */   private void siftDown(int paramInt) {
/* 305 */     int i = this.heapSize >> 1;
/*     */     
/* 307 */     while (paramInt < i) {
/* 308 */       int j = (paramInt << 1) + 1;
/* 309 */       int[] arrayOfInt2 = this.heap[j];
/* 310 */       if (j + 1 < this.heapSize && this.heap[j + 1][0] < arrayOfInt2[0]) {
/* 311 */         j++;
/*     */       }
/* 313 */       if (this.heap[j][0] >= this.heap[paramInt][0]) {
/*     */         break;
/*     */       }
/* 316 */       int[] arrayOfInt1 = this.heap[j];
/* 317 */       this.heap[j] = this.heap[paramInt];
/* 318 */       this.heap[paramInt] = arrayOfInt1;
/* 319 */       paramInt = j;
/*     */     } 
/*     */   }
/*     */   
/*     */   private int[] takeMinWithMap(int[] paramArrayOfint) {
/* 324 */     int[] arrayOfInt = this.heap[0];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     while (((1 << arrayOfInt[1] | 1 << arrayOfInt[2]) & this.invalidMask) > 0L) {
/* 330 */       arrayOfInt[0] = unifiedRegionArea(resolveMap(paramArrayOfint, arrayOfInt[1]), resolveMap(paramArrayOfint, arrayOfInt[2]));
/* 331 */       siftDown(0);
/* 332 */       if (this.heap[0] == arrayOfInt) {
/*     */         break;
/*     */       }
/* 335 */       arrayOfInt = this.heap[0];
/*     */     } 
/*     */     
/* 338 */     this.heap[this.heapSize - 1] = arrayOfInt;
/* 339 */     siftDown(0);
/* 340 */     this.heapSize--;
/* 341 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   private int[] takeMin() {
/* 345 */     int[] arrayOfInt = this.heap[0];
/* 346 */     this.heap[0] = this.heap[this.heapSize - 1];
/* 347 */     this.heap[this.heapSize - 1] = arrayOfInt;
/* 348 */     siftDown(0);
/* 349 */     this.heapSize--;
/* 350 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   private int resolveMap(int[] paramArrayOfint, int paramInt) {
/* 354 */     for (; paramArrayOfint[paramInt] != paramInt; paramInt = paramArrayOfint[paramInt]);
/* 355 */     return paramInt;
/*     */   }
/*     */   
/*     */   private int unifiedRegionArea(int paramInt1, int paramInt2) {
/* 359 */     RectBounds rectBounds1 = this.dirtyRegions[paramInt1];
/* 360 */     RectBounds rectBounds2 = this.dirtyRegions[paramInt2];
/*     */     
/* 362 */     float f1 = (rectBounds1.getMinX() < rectBounds2.getMinX()) ? rectBounds1.getMinX() : rectBounds2.getMinX();
/* 363 */     float f2 = (rectBounds1.getMinY() < rectBounds2.getMinY()) ? rectBounds1.getMinY() : rectBounds2.getMinY();
/* 364 */     float f3 = (rectBounds1.getMaxX() > rectBounds2.getMaxX()) ? rectBounds1.getMaxX() : rectBounds2.getMaxX();
/* 365 */     float f4 = (rectBounds1.getMaxY() > rectBounds2.getMaxY()) ? rectBounds1.getMaxY() : rectBounds2.getMaxY();
/*     */     
/* 367 */     return (int)((f3 - f1) * (f4 - f2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void compress_heap() {
/* 374 */     assert this.dirtyRegions.length == this.emptyIndex;
/* 375 */     if (this.heap == null) {
/* 376 */       int i = this.dirtyRegions.length;
/* 377 */       this.heap = new int[i * (i - 1) / 2][3];
/*     */     } 
/* 379 */     this.heapSize = this.heap.length;
/* 380 */     byte b1 = 0;
/* 381 */     for (byte b2 = 0; b2 < this.dirtyRegions.length - 1; b2++) {
/* 382 */       for (int i = b2 + 1; i < this.dirtyRegions.length; i++) {
/* 383 */         this.heap[b1][0] = unifiedRegionArea(b2, i);
/* 384 */         this.heap[b1][1] = b2;
/* 385 */         this.heap[b1++][2] = i;
/*     */       } 
/*     */     } 
/* 388 */     heapify();
/* 389 */     heapCompress();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\DirtyRegionContainer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */