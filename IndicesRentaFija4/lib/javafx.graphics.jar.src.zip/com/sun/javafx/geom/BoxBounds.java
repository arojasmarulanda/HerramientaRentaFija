/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.Affine3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoxBounds
/*     */   extends BaseBounds
/*     */ {
/*     */   private float minX;
/*     */   private float maxX;
/*     */   private float minY;
/*     */   private float maxY;
/*     */   private float minZ;
/*     */   private float maxZ;
/*     */   
/*     */   public BoxBounds() {
/*  52 */     this.minX = this.minY = this.minZ = 0.0F;
/*  53 */     this.maxX = this.maxY = this.maxZ = -1.0F;
/*     */   }
/*     */   
/*     */   public BaseBounds copy() {
/*  57 */     return new BoxBounds(this.minX, this.minY, this.minZ, this.maxX, this.maxY, this.maxZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoxBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  65 */     setBounds(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoxBounds(BoxBounds paramBoxBounds) {
/*  73 */     setBounds(paramBoxBounds);
/*     */   }
/*     */   
/*     */   public BaseBounds.BoundsType getBoundsType() {
/*  77 */     return BaseBounds.BoundsType.BOX;
/*     */   }
/*     */   
/*     */   public boolean is2D() {
/*  81 */     return (Affine3D.almostZero(this.minZ) && Affine3D.almostZero(this.maxZ));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWidth() {
/*  89 */     return this.maxX - this.minX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHeight() {
/*  97 */     return this.maxY - this.minY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDepth() {
/* 105 */     return this.maxZ - this.minZ;
/*     */   }
/*     */   
/*     */   public float getMinX() {
/* 109 */     return this.minX;
/*     */   }
/*     */   
/*     */   public void setMinX(float paramFloat) {
/* 113 */     this.minX = paramFloat;
/*     */   }
/*     */   
/*     */   public float getMinY() {
/* 117 */     return this.minY;
/*     */   }
/*     */   
/*     */   public void setMinY(float paramFloat) {
/* 121 */     this.minY = paramFloat;
/*     */   }
/*     */   
/*     */   public float getMinZ() {
/* 125 */     return this.minZ;
/*     */   }
/*     */   
/*     */   public void setMinZ(float paramFloat) {
/* 129 */     this.minZ = paramFloat;
/*     */   }
/*     */   
/*     */   public float getMaxX() {
/* 133 */     return this.maxX;
/*     */   }
/*     */   
/*     */   public void setMaxX(float paramFloat) {
/* 137 */     this.maxX = paramFloat;
/*     */   }
/*     */   
/*     */   public float getMaxY() {
/* 141 */     return this.maxY;
/*     */   }
/*     */   
/*     */   public void setMaxY(float paramFloat) {
/* 145 */     this.maxY = paramFloat;
/*     */   }
/*     */   
/*     */   public float getMaxZ() {
/* 149 */     return this.maxZ;
/*     */   }
/*     */   
/*     */   public void setMaxZ(float paramFloat) {
/* 153 */     this.maxZ = paramFloat;
/*     */   }
/*     */   
/*     */   public Vec2f getMin(Vec2f paramVec2f) {
/* 157 */     if (paramVec2f == null) {
/* 158 */       paramVec2f = new Vec2f();
/*     */     }
/* 160 */     paramVec2f.x = this.minX;
/* 161 */     paramVec2f.y = this.minY;
/* 162 */     return paramVec2f;
/*     */   }
/*     */   
/*     */   public Vec2f getMax(Vec2f paramVec2f) {
/* 166 */     if (paramVec2f == null) {
/* 167 */       paramVec2f = new Vec2f();
/*     */     }
/* 169 */     paramVec2f.x = this.maxX;
/* 170 */     paramVec2f.y = this.maxY;
/* 171 */     return paramVec2f;
/*     */   }
/*     */   
/*     */   public Vec3f getMin(Vec3f paramVec3f) {
/* 175 */     if (paramVec3f == null) {
/* 176 */       paramVec3f = new Vec3f();
/*     */     }
/* 178 */     paramVec3f.x = this.minX;
/* 179 */     paramVec3f.y = this.minY;
/* 180 */     paramVec3f.z = this.minZ;
/* 181 */     return paramVec3f;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3f getMax(Vec3f paramVec3f) {
/* 186 */     if (paramVec3f == null) {
/* 187 */       paramVec3f = new Vec3f();
/*     */     }
/* 189 */     paramVec3f.x = this.maxX;
/* 190 */     paramVec3f.y = this.maxY;
/* 191 */     paramVec3f.z = this.maxZ;
/* 192 */     return paramVec3f;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds deriveWithUnion(BaseBounds paramBaseBounds) {
/* 197 */     if (paramBaseBounds.getBoundsType() == BaseBounds.BoundsType.RECTANGLE || paramBaseBounds
/* 198 */       .getBoundsType() == BaseBounds.BoundsType.BOX) {
/* 199 */       unionWith(paramBaseBounds);
/*     */     } else {
/* 201 */       throw new UnsupportedOperationException("Unknown BoundsType");
/*     */     } 
/* 203 */     return this;
/*     */   }
/*     */   
/*     */   public BaseBounds deriveWithNewBounds(Rectangle paramRectangle) {
/* 207 */     if (paramRectangle.width < 0 || paramRectangle.height < 0) return makeEmpty(); 
/* 208 */     setBounds(paramRectangle.x, paramRectangle.y, 0.0F, (paramRectangle.x + paramRectangle.width), (paramRectangle.y + paramRectangle.height), 0.0F);
/*     */     
/* 210 */     return this;
/*     */   }
/*     */   
/*     */   public BaseBounds deriveWithNewBounds(BaseBounds paramBaseBounds) {
/* 214 */     if (paramBaseBounds.isEmpty()) return makeEmpty(); 
/* 215 */     if (paramBaseBounds.getBoundsType() == BaseBounds.BoundsType.RECTANGLE || paramBaseBounds
/* 216 */       .getBoundsType() == BaseBounds.BoundsType.BOX) {
/* 217 */       this.minX = paramBaseBounds.getMinX();
/* 218 */       this.minY = paramBaseBounds.getMinY();
/* 219 */       this.minZ = paramBaseBounds.getMinZ();
/* 220 */       this.maxX = paramBaseBounds.getMaxX();
/* 221 */       this.maxY = paramBaseBounds.getMaxY();
/* 222 */       this.maxZ = paramBaseBounds.getMaxZ();
/*     */     } else {
/* 224 */       throw new UnsupportedOperationException("Unknown BoundsType");
/*     */     } 
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds deriveWithNewBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 231 */     if (paramFloat4 < paramFloat1 || paramFloat5 < paramFloat2 || paramFloat6 < paramFloat3) return makeEmpty(); 
/* 232 */     this.minX = paramFloat1;
/* 233 */     this.minY = paramFloat2;
/* 234 */     this.minZ = paramFloat3;
/* 235 */     this.maxX = paramFloat4;
/* 236 */     this.maxY = paramFloat5;
/* 237 */     this.maxZ = paramFloat6;
/* 238 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds deriveWithNewBoundsAndSort(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 243 */     setBoundsAndSort(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 244 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RectBounds flattenInto(RectBounds paramRectBounds) {
/* 249 */     if (paramRectBounds == null) paramRectBounds = new RectBounds();
/*     */     
/* 251 */     if (isEmpty()) return paramRectBounds.makeEmpty();
/*     */     
/* 253 */     paramRectBounds.setBounds(this.minX, this.minY, this.maxX, this.maxY);
/* 254 */     return paramRectBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBounds(BaseBounds paramBaseBounds) {
/* 262 */     this.minX = paramBaseBounds.getMinX();
/* 263 */     this.minY = paramBaseBounds.getMinY();
/* 264 */     this.minZ = paramBaseBounds.getMinZ();
/* 265 */     this.maxX = paramBaseBounds.getMaxX();
/* 266 */     this.maxY = paramBaseBounds.getMaxY();
/* 267 */     this.maxZ = paramBaseBounds.getMaxZ();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 275 */     this.minX = paramFloat1;
/* 276 */     this.minY = paramFloat2;
/* 277 */     this.minZ = paramFloat3;
/* 278 */     this.maxX = paramFloat4;
/* 279 */     this.maxY = paramFloat5;
/* 280 */     this.maxZ = paramFloat6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoundsAndSort(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 285 */     setBounds(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 286 */     sortMinMax();
/*     */   }
/*     */   
/*     */   public void setBoundsAndSort(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 290 */     setBoundsAndSort(paramPoint2D1.x, paramPoint2D1.y, 0.0F, paramPoint2D2.x, paramPoint2D2.y, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void unionWith(BaseBounds paramBaseBounds) {
/* 295 */     if (paramBaseBounds.isEmpty())
/* 296 */       return;  if (isEmpty()) {
/* 297 */       setBounds(paramBaseBounds);
/*     */       
/*     */       return;
/*     */     } 
/* 301 */     this.minX = Math.min(this.minX, paramBaseBounds.getMinX());
/* 302 */     this.minY = Math.min(this.minY, paramBaseBounds.getMinY());
/* 303 */     this.minZ = Math.min(this.minZ, paramBaseBounds.getMinZ());
/* 304 */     this.maxX = Math.max(this.maxX, paramBaseBounds.getMaxX());
/* 305 */     this.maxY = Math.max(this.maxY, paramBaseBounds.getMaxY());
/* 306 */     this.maxZ = Math.max(this.maxZ, paramBaseBounds.getMaxZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unionWith(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 313 */     if (paramFloat4 < paramFloat1 || paramFloat5 < paramFloat2 || paramFloat6 < paramFloat3)
/* 314 */       return;  if (isEmpty()) {
/* 315 */       setBounds(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*     */       
/*     */       return;
/*     */     } 
/* 319 */     this.minX = Math.min(this.minX, paramFloat1);
/* 320 */     this.minY = Math.min(this.minY, paramFloat2);
/* 321 */     this.minZ = Math.min(this.minZ, paramFloat3);
/* 322 */     this.maxX = Math.max(this.maxX, paramFloat4);
/* 323 */     this.maxY = Math.max(this.maxY, paramFloat5);
/* 324 */     this.maxZ = Math.max(this.maxZ, paramFloat6);
/*     */   }
/*     */   
/*     */   public void add(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 328 */     unionWith(paramFloat1, paramFloat2, paramFloat3, paramFloat1, paramFloat2, paramFloat3);
/*     */   }
/*     */   
/*     */   public void add(Point2D paramPoint2D) {
/* 332 */     add(paramPoint2D.x, paramPoint2D.y, 0.0F);
/*     */   }
/*     */   
/*     */   public void intersectWith(Rectangle paramRectangle) {
/* 336 */     float f1 = paramRectangle.x;
/* 337 */     float f2 = paramRectangle.y;
/* 338 */     intersectWith(f1, f2, 0.0F, f1 + paramRectangle.width, f2 + paramRectangle.height, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void intersectWith(BaseBounds paramBaseBounds) {
/* 344 */     if (isEmpty())
/* 345 */       return;  if (paramBaseBounds.isEmpty()) {
/* 346 */       makeEmpty();
/*     */       
/*     */       return;
/*     */     } 
/* 350 */     this.minX = Math.max(this.minX, paramBaseBounds.getMinX());
/* 351 */     this.minY = Math.max(this.minY, paramBaseBounds.getMinY());
/* 352 */     this.minZ = Math.max(this.minZ, paramBaseBounds.getMinZ());
/* 353 */     this.maxX = Math.min(this.maxX, paramBaseBounds.getMaxX());
/* 354 */     this.maxY = Math.min(this.maxY, paramBaseBounds.getMaxY());
/* 355 */     this.maxZ = Math.min(this.maxZ, paramBaseBounds.getMaxZ());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void intersectWith(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 361 */     if (isEmpty())
/* 362 */       return;  if (paramFloat4 < paramFloat1 || paramFloat5 < paramFloat2 || paramFloat6 < paramFloat3) {
/* 363 */       makeEmpty();
/*     */       
/*     */       return;
/*     */     } 
/* 367 */     this.minX = Math.max(this.minX, paramFloat1);
/* 368 */     this.minY = Math.max(this.minY, paramFloat2);
/* 369 */     this.minZ = Math.max(this.minZ, paramFloat3);
/* 370 */     this.maxX = Math.min(this.maxX, paramFloat4);
/* 371 */     this.maxY = Math.min(this.maxY, paramFloat5);
/* 372 */     this.maxZ = Math.min(this.maxZ, paramFloat6);
/*     */   }
/*     */   
/*     */   public boolean contains(Point2D paramPoint2D) {
/* 376 */     if (paramPoint2D == null || isEmpty()) return false; 
/* 377 */     return contains(paramPoint2D.x, paramPoint2D.y, 0.0F);
/*     */   }
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/* 381 */     if (isEmpty()) return false; 
/* 382 */     return contains(paramFloat1, paramFloat2, 0.0F);
/*     */   }
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 386 */     if (isEmpty()) return false; 
/* 387 */     return (paramFloat1 >= this.minX && paramFloat1 <= this.maxX && paramFloat2 >= this.minY && paramFloat2 <= this.maxY && paramFloat3 >= this.minZ && paramFloat3 <= this.maxZ);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 393 */     if (isEmpty()) return false; 
/* 394 */     return (contains(paramFloat1, paramFloat2, paramFloat3) && contains(paramFloat1 + paramFloat4, paramFloat2 + paramFloat5, paramFloat3 + paramFloat6));
/*     */   }
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 398 */     return intersects(paramFloat1, paramFloat2, 0.0F, paramFloat3, paramFloat4, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 403 */     if (isEmpty()) return false; 
/* 404 */     return (paramFloat1 + paramFloat4 >= this.minX && paramFloat2 + paramFloat5 >= this.minY && paramFloat3 + paramFloat6 >= this.minZ && paramFloat1 <= this.maxX && paramFloat2 <= this.maxY && paramFloat3 <= this.maxZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(BaseBounds paramBaseBounds) {
/* 413 */     if (paramBaseBounds == null || paramBaseBounds.isEmpty() || isEmpty()) {
/* 414 */       return false;
/*     */     }
/* 416 */     return (paramBaseBounds.getMaxX() >= this.minX && paramBaseBounds
/* 417 */       .getMaxY() >= this.minY && paramBaseBounds
/* 418 */       .getMaxZ() >= this.minZ && paramBaseBounds
/* 419 */       .getMinX() <= this.maxX && paramBaseBounds
/* 420 */       .getMinY() <= this.maxY && paramBaseBounds
/* 421 */       .getMinZ() <= this.maxZ);
/*     */   }
/*     */   
/*     */   public boolean disjoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 425 */     return disjoint(paramFloat1, paramFloat2, 0.0F, paramFloat3, paramFloat4, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean disjoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 430 */     if (isEmpty()) return true; 
/* 431 */     return (paramFloat1 + paramFloat4 < this.minX || paramFloat2 + paramFloat5 < this.minY || paramFloat3 + paramFloat6 < this.minZ || paramFloat1 > this.maxX || paramFloat2 > this.maxY || paramFloat3 > this.maxZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 440 */     return (this.maxX < this.minX || this.maxY < this.minY || this.maxZ < this.minZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void roundOut() {
/* 449 */     this.minX = (float)Math.floor(this.minX);
/* 450 */     this.minY = (float)Math.floor(this.minY);
/* 451 */     this.minZ = (float)Math.floor(this.minZ);
/* 452 */     this.maxX = (float)Math.ceil(this.maxX);
/* 453 */     this.maxY = (float)Math.ceil(this.maxY);
/* 454 */     this.maxZ = (float)Math.ceil(this.maxZ);
/*     */   }
/*     */   
/*     */   public void grow(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 458 */     this.minX -= paramFloat1;
/* 459 */     this.maxX += paramFloat1;
/* 460 */     this.minY -= paramFloat2;
/* 461 */     this.maxY += paramFloat2;
/* 462 */     this.minZ -= paramFloat3;
/* 463 */     this.maxZ += paramFloat3;
/*     */   }
/*     */   
/*     */   public BaseBounds deriveWithPadding(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 467 */     grow(paramFloat1, paramFloat2, paramFloat3);
/* 468 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoxBounds makeEmpty() {
/* 475 */     this.minX = this.minY = this.minZ = 0.0F;
/* 476 */     this.maxX = this.maxY = this.maxZ = -1.0F;
/* 477 */     return this;
/*     */   }
/*     */   
/*     */   protected void sortMinMax() {
/* 481 */     if (this.minX > this.maxX) {
/* 482 */       float f = this.maxX;
/* 483 */       this.maxX = this.minX;
/* 484 */       this.minX = f;
/*     */     } 
/* 486 */     if (this.minY > this.maxY) {
/* 487 */       float f = this.maxY;
/* 488 */       this.maxY = this.minY;
/* 489 */       this.minY = f;
/*     */     } 
/* 491 */     if (this.minZ > this.maxZ) {
/* 492 */       float f = this.maxZ;
/* 493 */       this.maxZ = this.minZ;
/* 494 */       this.minZ = f;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void translate(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 500 */     setMinX(getMinX() + paramFloat1);
/* 501 */     setMinY(getMinY() + paramFloat2);
/* 502 */     setMaxX(getMaxX() + paramFloat1);
/* 503 */     setMaxY(getMaxY() + paramFloat2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 508 */     if (paramObject == null) return false; 
/* 509 */     if (getClass() != paramObject.getClass()) return false;
/*     */     
/* 511 */     BoxBounds boxBounds = (BoxBounds)paramObject;
/* 512 */     if (this.minX != boxBounds.getMinX()) return false; 
/* 513 */     if (this.minY != boxBounds.getMinY()) return false; 
/* 514 */     if (this.minZ != boxBounds.getMinZ()) return false; 
/* 515 */     if (this.maxX != boxBounds.getMaxX()) return false; 
/* 516 */     if (this.maxY != boxBounds.getMaxY()) return false; 
/* 517 */     if (this.maxZ != boxBounds.getMaxZ()) return false; 
/* 518 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 523 */     int i = 7;
/* 524 */     i = 79 * i + Float.floatToIntBits(this.minX);
/* 525 */     i = 79 * i + Float.floatToIntBits(this.minY);
/* 526 */     i = 79 * i + Float.floatToIntBits(this.minZ);
/* 527 */     i = 79 * i + Float.floatToIntBits(this.maxX);
/* 528 */     i = 79 * i + Float.floatToIntBits(this.maxY);
/* 529 */     i = 79 * i + Float.floatToIntBits(this.maxZ);
/*     */     
/* 531 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 536 */     return "BoxBounds { minX:" + this.minX + ", minY:" + this.minY + ", minZ:" + this.minZ + ", maxX:" + this.maxX + ", maxY:" + this.maxY + ", maxZ:" + this.maxZ + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\BoxBounds.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */