/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Arc2D
/*     */   extends RectangularShape
/*     */ {
/*     */   public static final int OPEN = 0;
/*     */   public static final int CHORD = 1;
/*     */   public static final int PIE = 2;
/*     */   private int type;
/*     */   public float x;
/*     */   public float y;
/*     */   public float width;
/*     */   public float height;
/*     */   public float start;
/*     */   public float extent;
/*     */   
/*     */   public Arc2D() {
/* 118 */     this(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Arc2D(int paramInt) {
/* 130 */     setArcType(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Arc2D(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, int paramInt) {
/* 152 */     this(paramInt);
/* 153 */     this.x = paramFloat1;
/* 154 */     this.y = paramFloat2;
/* 155 */     this.width = paramFloat3;
/* 156 */     this.height = paramFloat4;
/* 157 */     this.start = paramFloat5;
/* 158 */     this.extent = paramFloat6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getX() {
/* 166 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getY() {
/* 174 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWidth() {
/* 182 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHeight() {
/* 190 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 197 */     return (this.width <= 0.0F || this.height <= 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, int paramInt) {
/* 205 */     setArcType(paramInt);
/* 206 */     this.x = paramFloat1;
/* 207 */     this.y = paramFloat2;
/* 208 */     this.width = paramFloat3;
/* 209 */     this.height = paramFloat4;
/* 210 */     this.start = paramFloat5;
/* 211 */     this.extent = paramFloat6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getArcType() {
/* 222 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D getStartPoint() {
/* 234 */     double d1 = Math.toRadians(-this.start);
/* 235 */     double d2 = this.x + (Math.cos(d1) * 0.5D + 0.5D) * this.width;
/* 236 */     double d3 = this.y + (Math.sin(d1) * 0.5D + 0.5D) * this.height;
/* 237 */     return new Point2D((float)d2, (float)d3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D getEndPoint() {
/* 250 */     double d1 = Math.toRadians((-this.start - this.extent));
/* 251 */     double d2 = this.x + (Math.cos(d1) * 0.5D + 0.5D) * this.width;
/* 252 */     double d3 = this.y + (Math.sin(d1) * 0.5D + 0.5D) * this.height;
/* 253 */     return new Point2D((float)d2, (float)d3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArc(Point2D paramPoint2D, Dimension2D paramDimension2D, float paramFloat1, float paramFloat2, int paramInt) {
/* 272 */     setArc(paramPoint2D.x, paramPoint2D.y, paramDimension2D.width, paramDimension2D.height, paramFloat1, paramFloat2, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArc(Arc2D paramArc2D) {
/* 281 */     setArc(paramArc2D.x, paramArc2D.y, paramArc2D.width, paramArc2D.height, paramArc2D.start, paramArc2D.extent, paramArc2D.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArcByCenter(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, int paramInt) {
/* 299 */     setArc(paramFloat1 - paramFloat3, paramFloat2 - paramFloat3, paramFloat3 * 2.0F, paramFloat3 * 2.0F, paramFloat4, paramFloat5, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArcByTangent(Point2D paramPoint2D1, Point2D paramPoint2D2, Point2D paramPoint2D3, float paramFloat) {
/* 321 */     double d1 = Math.atan2((paramPoint2D1.y - paramPoint2D2.y), (paramPoint2D1.x - paramPoint2D2.x));
/*     */     
/* 323 */     double d2 = Math.atan2((paramPoint2D3.y - paramPoint2D2.y), (paramPoint2D3.x - paramPoint2D2.x));
/*     */     
/* 325 */     double d3 = d2 - d1;
/* 326 */     if (d3 > Math.PI) {
/* 327 */       d2 -= 6.283185307179586D;
/* 328 */     } else if (d3 < -3.141592653589793D) {
/* 329 */       d2 += 6.283185307179586D;
/*     */     } 
/* 331 */     double d4 = (d1 + d2) / 2.0D;
/* 332 */     double d5 = Math.abs(d2 - d4);
/* 333 */     double d6 = paramFloat / Math.sin(d5);
/* 334 */     double d7 = paramPoint2D2.x + d6 * Math.cos(d4);
/* 335 */     double d8 = paramPoint2D2.y + d6 * Math.sin(d4);
/*     */     
/* 337 */     if (d1 < d2) {
/* 338 */       d1 -= 1.5707963267948966D;
/* 339 */       d2 += 1.5707963267948966D;
/*     */     } else {
/* 341 */       d1 += 1.5707963267948966D;
/* 342 */       d2 -= 1.5707963267948966D;
/*     */     } 
/* 344 */     d1 = Math.toDegrees(-d1);
/* 345 */     d2 = Math.toDegrees(-d2);
/* 346 */     d3 = d2 - d1;
/* 347 */     if (d3 < 0.0D) {
/* 348 */       d3 += 360.0D;
/*     */     } else {
/* 350 */       d3 -= 360.0D;
/*     */     } 
/* 352 */     setArcByCenter((float)d7, (float)d8, paramFloat, (float)d1, (float)d3, this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAngleStart(Point2D paramPoint2D) {
/* 365 */     double d1 = (this.height * (paramPoint2D.x - getCenterX()));
/* 366 */     double d2 = (this.width * (paramPoint2D.y - getCenterY()));
/* 367 */     this.start = (float)-Math.toDegrees(Math.atan2(d2, d1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAngles(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 385 */     double d1 = getCenterX();
/* 386 */     double d2 = getCenterY();
/* 387 */     double d3 = this.width;
/* 388 */     double d4 = this.height;
/*     */ 
/*     */ 
/*     */     
/* 392 */     double d5 = Math.atan2(d3 * (d2 - paramFloat2), d4 * (paramFloat1 - d1));
/* 393 */     double d6 = Math.atan2(d3 * (d2 - paramFloat4), d4 * (paramFloat3 - d1));
/* 394 */     d6 -= d5;
/* 395 */     if (d6 <= 0.0D) {
/* 396 */       d6 += 6.283185307179586D;
/*     */     }
/* 398 */     this.start = (float)Math.toDegrees(d5);
/* 399 */     this.extent = (float)Math.toDegrees(d6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAngles(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 417 */     setAngles(paramPoint2D1.x, paramPoint2D1.y, paramPoint2D2.x, paramPoint2D2.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArcType(int paramInt) {
/* 433 */     if (paramInt < 0 || paramInt > 2) {
/* 434 */       throw new IllegalArgumentException("invalid type for Arc: " + paramInt);
/*     */     }
/* 436 */     this.type = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrame(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 446 */     setArc(paramFloat1, paramFloat2, paramFloat3, paramFloat4, this.start, this.extent, this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds getBounds() {
/* 465 */     if (isEmpty()) {
/* 466 */       return new RectBounds(this.x, this.y, this.x + this.width, this.y + this.height);
/*     */     }
/*     */ 
/*     */     
/* 470 */     double d4 = 0.0D, d3 = d4, d2 = d3, d1 = d2;
/*     */     
/* 472 */     d1 = d2 = 1.0D;
/* 473 */     d3 = d4 = -1.0D;
/*     */     
/* 475 */     double d5 = 0.0D;
/* 476 */     for (byte b = 0; b < 6; b++) {
/* 477 */       if (b < 4) {
/*     */         
/* 479 */         d5 += 90.0D;
/* 480 */         if (!containsAngle((float)d5)) {
/*     */           continue;
/*     */         }
/* 483 */       } else if (b == 4) {
/*     */         
/* 485 */         d5 = this.start;
/*     */       } else {
/*     */         
/* 488 */         d5 += this.extent;
/*     */       } 
/* 490 */       double d8 = Math.toRadians(-d5);
/* 491 */       double d9 = Math.cos(d8);
/* 492 */       double d10 = Math.sin(d8);
/* 493 */       d1 = Math.min(d1, d9);
/* 494 */       d2 = Math.min(d2, d10);
/* 495 */       d3 = Math.max(d3, d9);
/* 496 */       d4 = Math.max(d4, d10); continue;
/*     */     } 
/* 498 */     double d6 = this.width;
/* 499 */     double d7 = this.height;
/* 500 */     d3 = this.x + (d3 * 0.5D + 0.5D) * d6;
/* 501 */     d4 = this.y + (d4 * 0.5D + 0.5D) * d7;
/* 502 */     d1 = this.x + (d1 * 0.5D + 0.5D) * d6;
/* 503 */     d2 = this.y + (d2 * 0.5D + 0.5D) * d7;
/* 504 */     return new RectBounds((float)d1, (float)d2, (float)d3, (float)d4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static float normalizeDegrees(double paramDouble) {
/* 511 */     if (paramDouble > 180.0D) {
/* 512 */       if (paramDouble <= 540.0D) {
/* 513 */         paramDouble -= 360.0D;
/*     */       } else {
/* 515 */         paramDouble = Math.IEEEremainder(paramDouble, 360.0D);
/*     */         
/* 517 */         if (paramDouble == -180.0D) {
/* 518 */           paramDouble = 180.0D;
/*     */         }
/*     */       } 
/* 521 */     } else if (paramDouble <= -180.0D) {
/* 522 */       if (paramDouble > -540.0D) {
/* 523 */         paramDouble += 360.0D;
/*     */       } else {
/* 525 */         paramDouble = Math.IEEEremainder(paramDouble, 360.0D);
/*     */         
/* 527 */         if (paramDouble == -180.0D) {
/* 528 */           paramDouble = 180.0D;
/*     */         }
/*     */       } 
/*     */     } 
/* 532 */     return (float)paramDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsAngle(float paramFloat) {
/* 545 */     double d = this.extent;
/* 546 */     boolean bool = (d < 0.0D) ? true : false;
/* 547 */     if (bool) {
/* 548 */       d = -d;
/*     */     }
/* 550 */     if (d >= 360.0D) {
/* 551 */       return true;
/*     */     }
/* 553 */     paramFloat = normalizeDegrees(paramFloat) - normalizeDegrees(this.start);
/* 554 */     if (bool) {
/* 555 */       paramFloat = -paramFloat;
/*     */     }
/* 557 */     if (paramFloat < 0.0D) {
/* 558 */       paramFloat = (float)(paramFloat + 360.0D);
/*     */     }
/*     */     
/* 561 */     return (paramFloat >= 0.0D && paramFloat < d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/* 578 */     double d1 = this.width;
/* 579 */     if (d1 <= 0.0D) {
/* 580 */       return false;
/*     */     }
/* 582 */     double d2 = (paramFloat1 - this.x) / d1 - 0.5D;
/* 583 */     double d3 = this.height;
/* 584 */     if (d3 <= 0.0D) {
/* 585 */       return false;
/*     */     }
/* 587 */     double d4 = (paramFloat2 - this.y) / d3 - 0.5D;
/* 588 */     double d5 = d2 * d2 + d4 * d4;
/* 589 */     if (d5 >= 0.25D) {
/* 590 */       return false;
/*     */     }
/* 592 */     double d6 = Math.abs(this.extent);
/* 593 */     if (d6 >= 360.0D) {
/* 594 */       return true;
/*     */     }
/* 596 */     boolean bool = containsAngle((float)-Math.toDegrees(Math.atan2(d4, d2)));
/*     */     
/* 598 */     if (this.type == 2) {
/* 599 */       return bool;
/*     */     }
/*     */     
/* 602 */     if (bool) {
/* 603 */       if (d6 >= 180.0D) {
/* 604 */         return true;
/*     */       
/*     */       }
/*     */     }
/* 608 */     else if (d6 <= 180.0D) {
/* 609 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 615 */     double d7 = Math.toRadians(-this.start);
/* 616 */     double d8 = Math.cos(d7);
/* 617 */     double d9 = Math.sin(d7);
/* 618 */     d7 += Math.toRadians(-this.extent);
/* 619 */     double d10 = Math.cos(d7);
/* 620 */     double d11 = Math.sin(d7);
/*     */     
/* 622 */     boolean bool1 = (Line2D.relativeCCW((float)d8, (float)d9, (float)d10, (float)d11, (float)(2.0D * d2), (float)(2.0D * d4)) * Line2D.relativeCCW((float)d8, (float)d9, (float)d10, (float)d11, 0.0F, 0.0F) >= 0) ? true : false;
/* 623 */     return bool ? (!bool1) : bool1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 639 */     float f1 = this.width;
/* 640 */     float f2 = this.height;
/*     */     
/* 642 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F || f1 <= 0.0F || f2 <= 0.0F) {
/* 643 */       return false;
/*     */     }
/* 645 */     float f3 = this.extent;
/* 646 */     if (f3 == 0.0F) {
/* 647 */       return false;
/*     */     }
/*     */     
/* 650 */     float f4 = this.x;
/* 651 */     float f5 = this.y;
/* 652 */     float f6 = f4 + f1;
/* 653 */     float f7 = f5 + f2;
/* 654 */     float f8 = paramFloat1 + paramFloat3;
/* 655 */     float f9 = paramFloat2 + paramFloat4;
/*     */ 
/*     */     
/* 658 */     if (paramFloat1 >= f6 || paramFloat2 >= f7 || f8 <= f4 || f9 <= f5) {
/* 659 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 663 */     float f10 = getCenterX();
/* 664 */     float f11 = getCenterY();
/*     */ 
/*     */     
/* 667 */     double d1 = Math.toRadians(-this.start);
/* 668 */     float f12 = (float)(this.x + (Math.cos(d1) * 0.5D + 0.5D) * this.width);
/* 669 */     float f13 = (float)(this.y + (Math.sin(d1) * 0.5D + 0.5D) * this.height);
/*     */ 
/*     */     
/* 672 */     double d2 = Math.toRadians((-this.start - this.extent));
/* 673 */     float f14 = (float)(this.x + (Math.cos(d2) * 0.5D + 0.5D) * this.width);
/* 674 */     float f15 = (float)(this.y + (Math.sin(d2) * 0.5D + 0.5D) * this.height);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 686 */     if (f11 >= paramFloat2 && f11 <= f9 && ((
/* 687 */       f12 < f8 && f14 < f8 && f10 < f8 && f6 > paramFloat1 && 
/* 688 */       containsAngle(0.0F)) || (f12 > paramFloat1 && f14 > paramFloat1 && f10 > paramFloat1 && f4 < f8 && 
/*     */       
/* 690 */       containsAngle(180.0F)))) {
/* 691 */       return true;
/*     */     }
/*     */     
/* 694 */     if (f10 >= paramFloat1 && f10 <= f8 && ((
/* 695 */       f13 > paramFloat2 && f15 > paramFloat2 && f11 > paramFloat2 && f5 < f9 && 
/* 696 */       containsAngle(90.0F)) || (f13 < f9 && f15 < f9 && f11 < f9 && f7 > paramFloat2 && 
/*     */       
/* 698 */       containsAngle(270.0F)))) {
/* 699 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 710 */     if (this.type == 2 || Math.abs(f3) > 180.0F) {
/*     */       
/* 712 */       if (Shape.intersectsLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4, f10, f11, f12, f13) || 
/* 713 */         Shape.intersectsLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4, f10, f11, f14, f15))
/*     */       {
/* 715 */         return true;
/*     */       
/*     */       }
/*     */     }
/* 719 */     else if (Shape.intersectsLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4, f12, f13, f14, f15)) {
/* 720 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 725 */     if (contains(paramFloat1, paramFloat2) || contains(paramFloat1 + paramFloat3, paramFloat2) || 
/* 726 */       contains(paramFloat1, paramFloat2 + paramFloat4) || contains(paramFloat1 + paramFloat3, paramFloat2 + paramFloat4)) {
/* 727 */       return true;
/*     */     }
/*     */     
/* 730 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 746 */     if (!contains(paramFloat1, paramFloat2) || 
/* 747 */       !contains(paramFloat1 + paramFloat3, paramFloat2) || 
/* 748 */       !contains(paramFloat1, paramFloat2 + paramFloat4) || 
/* 749 */       !contains(paramFloat1 + paramFloat3, paramFloat2 + paramFloat4)) {
/* 750 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 755 */     if (this.type != 2 || Math.abs(this.extent) <= 180.0D) {
/* 756 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 764 */     float f1 = getWidth() / 2.0F;
/* 765 */     float f2 = getHeight() / 2.0F;
/* 766 */     float f3 = paramFloat1 + f1;
/* 767 */     float f4 = paramFloat2 + f2;
/* 768 */     float f5 = (float)Math.toRadians(-this.start);
/* 769 */     float f6 = (float)(f3 + f1 * Math.cos(f5));
/* 770 */     float f7 = (float)(f4 + f2 * Math.sin(f5));
/* 771 */     if (Shape.intersectsLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4, f3, f4, f6, f7)) {
/* 772 */       return false;
/*     */     }
/* 774 */     f5 += (float)Math.toRadians(-this.extent);
/* 775 */     f6 = (float)(f3 + f1 * Math.cos(f5));
/* 776 */     f7 = (float)(f4 + f2 * Math.sin(f5));
/* 777 */     return !Shape.intersectsLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4, f3, f4, f6, f7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/* 796 */     return new ArcIterator(this, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   public Arc2D copy() {
/* 801 */     return new Arc2D(this.x, this.y, this.width, this.height, this.start, this.extent, this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 810 */     int i = Float.floatToIntBits(this.x);
/* 811 */     i += Float.floatToIntBits(this.y) * 37;
/* 812 */     i += Float.floatToIntBits(this.width) * 43;
/* 813 */     i += Float.floatToIntBits(this.height) * 47;
/* 814 */     i += Float.floatToIntBits(this.start) * 53;
/* 815 */     i += Float.floatToIntBits(this.extent) * 59;
/* 816 */     i += getArcType() * 61;
/* 817 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 835 */     if (paramObject == this) return true; 
/* 836 */     if (paramObject instanceof Arc2D) {
/* 837 */       Arc2D arc2D = (Arc2D)paramObject;
/* 838 */       return (this.x == arc2D.x && this.y == arc2D.y && this.width == arc2D.width && this.height == arc2D.height && this.start == arc2D.start && this.extent == arc2D.extent && this.type == arc2D.type);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 846 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Arc2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */