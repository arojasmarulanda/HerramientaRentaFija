/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Matrix3f
/*     */ {
/*     */   public float m00;
/*     */   public float m01;
/*     */   public float m02;
/*     */   public float m10;
/*     */   public float m11;
/*     */   public float m12;
/*     */   public float m20;
/*     */   public float m21;
/*     */   public float m22;
/*     */   
/*     */   public Matrix3f(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9) {
/*  86 */     this.m00 = paramFloat1;
/*  87 */     this.m01 = paramFloat2;
/*  88 */     this.m02 = paramFloat3;
/*     */     
/*  90 */     this.m10 = paramFloat4;
/*  91 */     this.m11 = paramFloat5;
/*  92 */     this.m12 = paramFloat6;
/*     */     
/*  94 */     this.m20 = paramFloat7;
/*  95 */     this.m21 = paramFloat8;
/*  96 */     this.m22 = paramFloat9;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix3f(float[] paramArrayOffloat) {
/* 106 */     this.m00 = paramArrayOffloat[0];
/* 107 */     this.m01 = paramArrayOffloat[1];
/* 108 */     this.m02 = paramArrayOffloat[2];
/*     */     
/* 110 */     this.m10 = paramArrayOffloat[3];
/* 111 */     this.m11 = paramArrayOffloat[4];
/* 112 */     this.m12 = paramArrayOffloat[5];
/*     */     
/* 114 */     this.m20 = paramArrayOffloat[6];
/* 115 */     this.m21 = paramArrayOffloat[7];
/* 116 */     this.m22 = paramArrayOffloat[8];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix3f(Vec3f[] paramArrayOfVec3f) {
/* 126 */     this.m00 = (paramArrayOfVec3f[0]).x;
/* 127 */     this.m01 = (paramArrayOfVec3f[0]).y;
/* 128 */     this.m02 = (paramArrayOfVec3f[0]).z;
/*     */     
/* 130 */     this.m10 = (paramArrayOfVec3f[1]).x;
/* 131 */     this.m11 = (paramArrayOfVec3f[1]).x;
/* 132 */     this.m12 = (paramArrayOfVec3f[1]).x;
/*     */     
/* 134 */     this.m20 = (paramArrayOfVec3f[2]).x;
/* 135 */     this.m21 = (paramArrayOfVec3f[2]).x;
/* 136 */     this.m22 = (paramArrayOfVec3f[2]).x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix3f(Matrix3f paramMatrix3f) {
/* 146 */     this.m00 = paramMatrix3f.m00;
/* 147 */     this.m01 = paramMatrix3f.m01;
/* 148 */     this.m02 = paramMatrix3f.m02;
/*     */     
/* 150 */     this.m10 = paramMatrix3f.m10;
/* 151 */     this.m11 = paramMatrix3f.m11;
/* 152 */     this.m12 = paramMatrix3f.m12;
/*     */     
/* 154 */     this.m20 = paramMatrix3f.m20;
/* 155 */     this.m21 = paramMatrix3f.m21;
/* 156 */     this.m22 = paramMatrix3f.m22;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Matrix3f() {
/* 164 */     this.m00 = 1.0F;
/* 165 */     this.m01 = 0.0F;
/* 166 */     this.m02 = 0.0F;
/*     */     
/* 168 */     this.m10 = 0.0F;
/* 169 */     this.m11 = 1.0F;
/* 170 */     this.m12 = 0.0F;
/*     */     
/* 172 */     this.m20 = 0.0F;
/* 173 */     this.m21 = 0.0F;
/* 174 */     this.m22 = 1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 184 */     return "" + this.m00 + ", " + this.m00 + ", " + this.m01 + "\n" + this.m02 + ", " + this.m10 + ", " + this.m11 + "\n" + this.m12 + ", " + this.m20 + ", " + this.m21 + "\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setIdentity() {
/* 193 */     this.m00 = 1.0F;
/* 194 */     this.m01 = 0.0F;
/* 195 */     this.m02 = 0.0F;
/*     */     
/* 197 */     this.m10 = 0.0F;
/* 198 */     this.m11 = 1.0F;
/* 199 */     this.m12 = 0.0F;
/*     */     
/* 201 */     this.m20 = 0.0F;
/* 202 */     this.m21 = 0.0F;
/* 203 */     this.m22 = 1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setRow(int paramInt, float[] paramArrayOffloat) {
/* 212 */     switch (paramInt) {
/*     */       case 0:
/* 214 */         this.m00 = paramArrayOffloat[0];
/* 215 */         this.m01 = paramArrayOffloat[1];
/* 216 */         this.m02 = paramArrayOffloat[2];
/*     */         return;
/*     */       
/*     */       case 1:
/* 220 */         this.m10 = paramArrayOffloat[0];
/* 221 */         this.m11 = paramArrayOffloat[1];
/* 222 */         this.m12 = paramArrayOffloat[2];
/*     */         return;
/*     */       
/*     */       case 2:
/* 226 */         this.m20 = paramArrayOffloat[0];
/* 227 */         this.m21 = paramArrayOffloat[1];
/* 228 */         this.m22 = paramArrayOffloat[2];
/*     */         return;
/*     */     } 
/*     */     
/* 232 */     throw new ArrayIndexOutOfBoundsException("Matrix3f");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setRow(int paramInt, Vec3f paramVec3f) {
/* 242 */     switch (paramInt) {
/*     */       case 0:
/* 244 */         this.m00 = paramVec3f.x;
/* 245 */         this.m01 = paramVec3f.y;
/* 246 */         this.m02 = paramVec3f.z;
/*     */         return;
/*     */       
/*     */       case 1:
/* 250 */         this.m10 = paramVec3f.x;
/* 251 */         this.m11 = paramVec3f.y;
/* 252 */         this.m12 = paramVec3f.z;
/*     */         return;
/*     */       
/*     */       case 2:
/* 256 */         this.m20 = paramVec3f.x;
/* 257 */         this.m21 = paramVec3f.y;
/* 258 */         this.m22 = paramVec3f.z;
/*     */         return;
/*     */     } 
/*     */     
/* 262 */     throw new ArrayIndexOutOfBoundsException("Matrix3f");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void getRow(int paramInt, Vec3f paramVec3f) {
/* 272 */     if (paramInt == 0) {
/* 273 */       paramVec3f.x = this.m00;
/* 274 */       paramVec3f.y = this.m01;
/* 275 */       paramVec3f.z = this.m02;
/* 276 */     } else if (paramInt == 1) {
/* 277 */       paramVec3f.x = this.m10;
/* 278 */       paramVec3f.y = this.m11;
/* 279 */       paramVec3f.z = this.m12;
/* 280 */     } else if (paramInt == 2) {
/* 281 */       paramVec3f.x = this.m20;
/* 282 */       paramVec3f.y = this.m21;
/* 283 */       paramVec3f.z = this.m22;
/*     */     } else {
/* 285 */       throw new ArrayIndexOutOfBoundsException("Matrix3f");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void getRow(int paramInt, float[] paramArrayOffloat) {
/* 295 */     if (paramInt == 0) {
/* 296 */       paramArrayOffloat[0] = this.m00;
/* 297 */       paramArrayOffloat[1] = this.m01;
/* 298 */       paramArrayOffloat[2] = this.m02;
/* 299 */     } else if (paramInt == 1) {
/* 300 */       paramArrayOffloat[0] = this.m10;
/* 301 */       paramArrayOffloat[1] = this.m11;
/* 302 */       paramArrayOffloat[2] = this.m12;
/* 303 */     } else if (paramInt == 2) {
/* 304 */       paramArrayOffloat[0] = this.m20;
/* 305 */       paramArrayOffloat[1] = this.m21;
/* 306 */       paramArrayOffloat[2] = this.m22;
/*     */     } else {
/* 308 */       throw new ArrayIndexOutOfBoundsException("Matrix3f");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Matrix3f.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */