/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AreaOp
/*     */ {
/*     */   public static final int CTAG_LEFT = 0;
/*     */   public static final int CTAG_RIGHT = 1;
/*     */   public static final int ETAG_IGNORE = 0;
/*     */   public static final int ETAG_ENTER = 1;
/*     */   public static final int ETAG_EXIT = -1;
/*     */   public static final int RSTAG_INSIDE = 1;
/*     */   public static final int RSTAG_OUTSIDE = -1;
/*     */   private static Comparator YXTopComparator;
/*     */   
/*     */   public static abstract class CAGOp
/*     */     extends AreaOp
/*     */   {
/*     */     boolean inLeft;
/*     */     boolean inRight;
/*     */     boolean inResult;
/*     */     
/*     */     public void newRow() {
/*  40 */       this.inLeft = false;
/*  41 */       this.inRight = false;
/*  42 */       this.inResult = false;
/*     */     }
/*     */     
/*     */     public int classify(Edge param1Edge) {
/*  46 */       if (param1Edge.getCurveTag() == 0) {
/*  47 */         this.inLeft = !this.inLeft;
/*     */       } else {
/*  49 */         this.inRight = !this.inRight;
/*     */       } 
/*  51 */       boolean bool = newClassification(this.inLeft, this.inRight);
/*  52 */       if (this.inResult == bool) {
/*  53 */         return 0;
/*     */       }
/*  55 */       this.inResult = bool;
/*  56 */       return bool ? 1 : -1;
/*     */     }
/*     */     
/*     */     public int getState() {
/*  60 */       return this.inResult ? 1 : -1;
/*     */     }
/*     */     
/*     */     public abstract boolean newClassification(boolean param1Boolean1, boolean param1Boolean2);
/*     */   }
/*     */   
/*     */   public static class AddOp
/*     */     extends CAGOp {
/*     */     public boolean newClassification(boolean param1Boolean1, boolean param1Boolean2) {
/*  69 */       return (param1Boolean1 || param1Boolean2);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SubOp extends CAGOp {
/*     */     public boolean newClassification(boolean param1Boolean1, boolean param1Boolean2) {
/*  75 */       return (param1Boolean1 && !param1Boolean2);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class IntOp extends CAGOp {
/*     */     public boolean newClassification(boolean param1Boolean1, boolean param1Boolean2) {
/*  81 */       return (param1Boolean1 && param1Boolean2);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class XorOp extends CAGOp {
/*     */     public boolean newClassification(boolean param1Boolean1, boolean param1Boolean2) {
/*  87 */       return (param1Boolean1 != param1Boolean2);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class NZWindOp extends AreaOp {
/*     */     private int count;
/*     */     
/*     */     public void newRow() {
/*  95 */       this.count = 0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int classify(Edge param1Edge) {
/* 101 */       int i = this.count;
/* 102 */       boolean bool = (i == 0) ? true : false;
/* 103 */       i += param1Edge.getCurve().getDirection();
/* 104 */       this.count = i;
/* 105 */       return (i == 0) ? -1 : bool;
/*     */     }
/*     */     
/*     */     public int getState() {
/* 109 */       return (this.count == 0) ? -1 : 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class EOWindOp extends AreaOp {
/*     */     private boolean inside;
/*     */     
/*     */     public void newRow() {
/* 117 */       this.inside = false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int classify(Edge param1Edge) {
/* 123 */       boolean bool = !this.inside ? true : false;
/* 124 */       this.inside = bool;
/* 125 */       return bool ? 1 : -1;
/*     */     }
/*     */     
/*     */     public int getState() {
/* 129 */       return this.inside ? 1 : -1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AreaOp() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector calculate(Vector paramVector1, Vector paramVector2) {
/* 156 */     Vector vector = new Vector();
/* 157 */     addEdges(vector, paramVector1, 0);
/* 158 */     addEdges(vector, paramVector2, 1);
/* 159 */     vector = pruneEdges(vector);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     return vector;
/*     */   }
/*     */   
/*     */   private static void addEdges(Vector<Edge> paramVector1, Vector paramVector2, int paramInt) {
/* 172 */     Enumeration<Curve> enumeration = paramVector2.elements();
/* 173 */     while (enumeration.hasMoreElements()) {
/* 174 */       Curve curve = enumeration.nextElement();
/* 175 */       if (curve.getOrder() > 0)
/* 176 */         paramVector1.add(new Edge(curve, paramInt)); 
/*     */     } 
/*     */   }
/*     */   
/*     */   static {
/* 181 */     YXTopComparator = ((paramObject1, paramObject2) -> {
/* 182 */         Curve curve1 = ((Edge)paramObject1).getCurve(); Curve curve2 = ((Edge)paramObject2).getCurve(); double d1; double d2; return ((d1 = curve1.getYTop()) == (d2 = curve2.getYTop()) && (d1 = curve1.getXTop()) == (d2 = curve2.getXTop())) ? 0 : ((d1 < d2) ? -1 : 1);
/*     */       });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector pruneEdges(Vector paramVector) {
/* 197 */     int i = paramVector.size();
/* 198 */     if (i < 2) {
/* 199 */       return paramVector;
/*     */     }
/* 201 */     Edge[] arrayOfEdge = (Edge[])paramVector.toArray((Object[])new Edge[i]);
/* 202 */     Arrays.sort(arrayOfEdge, YXTopComparator);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     int j = 0;
/* 211 */     byte b = 0;
/* 212 */     int k = 0;
/* 213 */     int m = 0;
/* 214 */     double[] arrayOfDouble = new double[2];
/* 215 */     Vector vector1 = new Vector();
/* 216 */     Vector vector2 = new Vector();
/* 217 */     Vector<CurveLink> vector = new Vector();
/*     */     
/* 219 */     while (j < i) {
/* 220 */       double d1 = arrayOfDouble[0];
/*     */       
/* 222 */       for (k = m = b - 1; k >= j; k--) {
/* 223 */         Edge edge = arrayOfEdge[k];
/* 224 */         if (edge.getCurve().getYBot() > d1) {
/* 225 */           if (m > k) {
/* 226 */             arrayOfEdge[m] = edge;
/*     */           }
/* 228 */           m--;
/*     */         } 
/*     */       } 
/* 231 */       j = m + 1;
/*     */       
/* 233 */       if (j >= b) {
/* 234 */         if (b >= i) {
/*     */           break;
/*     */         }
/* 237 */         d1 = arrayOfEdge[b].getCurve().getYTop();
/* 238 */         if (d1 > arrayOfDouble[0]) {
/* 239 */           finalizeSubCurves(vector1, vector2);
/*     */         }
/* 241 */         arrayOfDouble[0] = d1;
/*     */       } 
/*     */       
/* 244 */       while (b < i) {
/* 245 */         Edge edge = arrayOfEdge[b];
/* 246 */         if (edge.getCurve().getYTop() > d1) {
/*     */           break;
/*     */         }
/* 249 */         b++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 254 */       arrayOfDouble[1] = arrayOfEdge[j].getCurve().getYBot();
/* 255 */       if (b < i) {
/* 256 */         d1 = arrayOfEdge[b].getCurve().getYTop();
/* 257 */         if (arrayOfDouble[1] > d1) {
/* 258 */           arrayOfDouble[1] = d1;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 270 */       byte b1 = 1;
/* 271 */       for (k = j; k < b; k++) {
/* 272 */         Edge edge = arrayOfEdge[k];
/* 273 */         edge.setEquivalence(0);
/* 274 */         for (m = k; m > j; m--) {
/* 275 */           Edge edge1 = arrayOfEdge[m - 1];
/* 276 */           int n = edge.compareTo(edge1, arrayOfDouble);
/* 277 */           if (arrayOfDouble[1] <= arrayOfDouble[0]) {
/* 278 */             throw new InternalError("backstepping to " + arrayOfDouble[1] + " from " + arrayOfDouble[0]);
/*     */           }
/*     */           
/* 281 */           if (n >= 0) {
/* 282 */             if (n == 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 287 */               int i1 = edge1.getEquivalence();
/* 288 */               if (i1 == 0) {
/* 289 */                 i1 = b1++;
/* 290 */                 edge1.setEquivalence(i1);
/*     */               } 
/* 292 */               edge.setEquivalence(i1);
/*     */             } 
/*     */             break;
/*     */           } 
/* 296 */           arrayOfEdge[m] = edge1;
/*     */         } 
/* 298 */         arrayOfEdge[m] = edge;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 312 */       newRow();
/* 313 */       double d2 = arrayOfDouble[0];
/* 314 */       double d3 = arrayOfDouble[1];
/* 315 */       for (k = j; k < b; k++) {
/* 316 */         int n; Edge edge = arrayOfEdge[k];
/*     */         
/* 318 */         int i1 = edge.getEquivalence();
/* 319 */         if (i1 != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 325 */           int i2 = getState();
/*     */ 
/*     */           
/* 328 */           n = (i2 == 1) ? -1 : 1;
/* 329 */           Edge edge1 = null;
/* 330 */           Edge edge2 = edge;
/* 331 */           double d = d3;
/*     */ 
/*     */           
/*     */           do {
/* 335 */             classify(edge);
/* 336 */             if (edge1 == null && edge
/* 337 */               .isActiveFor(d2, n))
/*     */             {
/* 339 */               edge1 = edge;
/*     */             }
/* 341 */             d1 = edge.getCurve().getYBot();
/* 342 */             if (d1 <= d)
/* 343 */               continue;  edge2 = edge;
/* 344 */             d = d1;
/*     */           }
/* 346 */           while (++k < b && (edge = arrayOfEdge[k])
/* 347 */             .getEquivalence() == i1);
/* 348 */           k--;
/* 349 */           if (getState() == i2) {
/* 350 */             n = 0;
/*     */           } else {
/* 352 */             edge = (edge1 != null) ? edge1 : edge2;
/*     */           } 
/*     */         } else {
/* 355 */           n = classify(edge);
/*     */         } 
/* 357 */         if (n != 0) {
/* 358 */           edge.record(d3, n);
/* 359 */           vector.add(new CurveLink(edge.getCurve(), d2, d3, n));
/*     */         } 
/*     */       } 
/*     */       
/* 363 */       if (getState() != -1) {
/* 364 */         System.out.println("Still inside at end of active edge list!");
/* 365 */         System.out.println("num curves = " + b - j);
/* 366 */         System.out.println("num links = " + vector.size());
/* 367 */         System.out.println("y top = " + arrayOfDouble[0]);
/* 368 */         if (b < i) {
/* 369 */           System.out.println("y top of next curve = " + arrayOfEdge[b]
/* 370 */               .getCurve().getYTop());
/*     */         } else {
/* 372 */           System.out.println("no more curves");
/*     */         } 
/* 374 */         for (k = j; k < b; k++) {
/* 375 */           Edge edge = arrayOfEdge[k];
/* 376 */           System.out.println(edge);
/* 377 */           int n = edge.getEquivalence();
/* 378 */           if (n != 0) {
/* 379 */             System.out.println("  was equal to " + n + "...");
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 390 */       resolveLinks(vector1, vector2, vector);
/* 391 */       vector.clear();
/*     */ 
/*     */       
/* 394 */       arrayOfDouble[0] = d3;
/*     */     } 
/* 396 */     finalizeSubCurves(vector1, vector2);
/* 397 */     Vector<Curve> vector3 = new Vector();
/* 398 */     Enumeration<CurveLink> enumeration = vector1.elements();
/* 399 */     while (enumeration.hasMoreElements()) {
/* 400 */       CurveLink curveLink1 = enumeration.nextElement();
/* 401 */       vector3.add(curveLink1.getMoveto());
/* 402 */       CurveLink curveLink2 = curveLink1;
/* 403 */       while ((curveLink2 = curveLink2.getNext()) != null) {
/* 404 */         if (!curveLink1.absorb(curveLink2)) {
/* 405 */           vector3.add(curveLink1.getSubCurve());
/* 406 */           curveLink1 = curveLink2;
/*     */         } 
/*     */       } 
/* 409 */       vector3.add(curveLink1.getSubCurve());
/*     */     } 
/* 411 */     return vector3;
/*     */   }
/*     */   
/*     */   public static void finalizeSubCurves(Vector<CurveLink> paramVector1, Vector paramVector2) {
/* 415 */     int i = paramVector2.size();
/* 416 */     if (i == 0) {
/*     */       return;
/*     */     }
/* 419 */     if ((i & 0x1) != 0) {
/* 420 */       throw new InternalError("Odd number of chains!");
/*     */     }
/* 422 */     ChainEnd[] arrayOfChainEnd = new ChainEnd[i];
/* 423 */     paramVector2.toArray((Object[])arrayOfChainEnd);
/* 424 */     for (byte b = 1; b < i; b += 2) {
/* 425 */       ChainEnd chainEnd1 = arrayOfChainEnd[b - 1];
/* 426 */       ChainEnd chainEnd2 = arrayOfChainEnd[b];
/* 427 */       CurveLink curveLink = chainEnd1.linkTo(chainEnd2);
/* 428 */       if (curveLink != null) {
/* 429 */         paramVector1.add(curveLink);
/*     */       }
/*     */     } 
/* 432 */     paramVector2.clear();
/*     */   }
/*     */   
/* 435 */   private static final CurveLink[] EmptyLinkList = new CurveLink[2];
/* 436 */   private static final ChainEnd[] EmptyChainList = new ChainEnd[2];
/*     */ 
/*     */   
/*     */   public static void resolveLinks(Vector<CurveLink> paramVector1, Vector<ChainEnd> paramVector2, Vector paramVector3) {
/*     */     CurveLink[] arrayOfCurveLink;
/*     */     ChainEnd[] arrayOfChainEnd;
/* 442 */     int i = paramVector3.size();
/*     */     
/* 444 */     if (i == 0) {
/* 445 */       arrayOfCurveLink = EmptyLinkList;
/*     */     } else {
/* 447 */       if ((i & 0x1) != 0) {
/* 448 */         throw new InternalError("Odd number of new curves!");
/*     */       }
/* 450 */       arrayOfCurveLink = new CurveLink[i + 2];
/* 451 */       paramVector3.toArray((Object[])arrayOfCurveLink);
/*     */     } 
/* 453 */     int j = paramVector2.size();
/*     */     
/* 455 */     if (j == 0) {
/* 456 */       arrayOfChainEnd = EmptyChainList;
/*     */     } else {
/* 458 */       if ((j & 0x1) != 0) {
/* 459 */         throw new InternalError("Odd number of chains!");
/*     */       }
/* 461 */       arrayOfChainEnd = new ChainEnd[j + 2];
/* 462 */       paramVector2.toArray((Object[])arrayOfChainEnd);
/*     */     } 
/* 464 */     byte b1 = 0;
/* 465 */     byte b2 = 0;
/* 466 */     paramVector2.clear();
/* 467 */     ChainEnd chainEnd1 = arrayOfChainEnd[0];
/* 468 */     ChainEnd chainEnd2 = arrayOfChainEnd[1];
/* 469 */     CurveLink curveLink1 = arrayOfCurveLink[0];
/* 470 */     CurveLink curveLink2 = arrayOfCurveLink[1];
/* 471 */     while (chainEnd1 != null || curveLink1 != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 476 */       boolean bool1 = (curveLink1 == null) ? true : false;
/* 477 */       boolean bool2 = (chainEnd1 == null) ? true : false;
/*     */       
/* 479 */       if (!bool1 && !bool2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 486 */         bool1 = ((b1 & 0x1) == 0 && chainEnd1.getX() == chainEnd2.getX()) ? true : false;
/*     */         
/* 488 */         bool2 = ((b2 & 0x1) == 0 && curveLink1.getX() == curveLink2.getX()) ? true : false;
/*     */         
/* 490 */         if (!bool1 && !bool2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 496 */           double d1 = chainEnd1.getX();
/* 497 */           double d2 = curveLink1.getX();
/*     */ 
/*     */           
/* 500 */           bool1 = (chainEnd2 != null && d1 < d2 && obstructs(chainEnd2.getX(), d2, b1)) ? true : false;
/*     */ 
/*     */           
/* 503 */           bool2 = (curveLink2 != null && d2 < d1 && obstructs(curveLink2.getX(), d1, b2)) ? true : false;
/*     */         } 
/*     */       } 
/* 506 */       if (bool1) {
/* 507 */         CurveLink curveLink = chainEnd1.linkTo(chainEnd2);
/* 508 */         if (curveLink != null) {
/* 509 */           paramVector1.add(curveLink);
/*     */         }
/* 511 */         b1 += true;
/* 512 */         chainEnd1 = arrayOfChainEnd[b1];
/* 513 */         chainEnd2 = arrayOfChainEnd[b1 + 1];
/*     */       } 
/* 515 */       if (bool2) {
/* 516 */         ChainEnd chainEnd3 = new ChainEnd(curveLink1, null);
/* 517 */         ChainEnd chainEnd4 = new ChainEnd(curveLink2, chainEnd3);
/* 518 */         chainEnd3.setOtherEnd(chainEnd4);
/* 519 */         paramVector2.add(chainEnd3);
/* 520 */         paramVector2.add(chainEnd4);
/* 521 */         b2 += true;
/* 522 */         curveLink1 = arrayOfCurveLink[b2];
/* 523 */         curveLink2 = arrayOfCurveLink[b2 + 1];
/*     */       } 
/* 525 */       if (!bool1 && !bool2) {
/*     */ 
/*     */ 
/*     */         
/* 529 */         chainEnd1.addLink(curveLink1);
/* 530 */         paramVector2.add(chainEnd1);
/* 531 */         b1++;
/* 532 */         chainEnd1 = chainEnd2;
/* 533 */         chainEnd2 = arrayOfChainEnd[b1 + 1];
/* 534 */         b2++;
/* 535 */         curveLink1 = curveLink2;
/* 536 */         curveLink2 = arrayOfCurveLink[b2 + 1];
/*     */       } 
/*     */     } 
/* 539 */     if ((paramVector2.size() & 0x1) != 0) {
/* 540 */       System.out.println("Odd number of chains!");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean obstructs(double paramDouble1, double paramDouble2, int paramInt) {
/* 557 */     return ((paramInt & 0x1) == 0) ? ((paramDouble1 <= paramDouble2)) : ((paramDouble1 < paramDouble2));
/*     */   }
/*     */   
/*     */   public abstract void newRow();
/*     */   
/*     */   public abstract int classify(Edge paramEdge);
/*     */   
/*     */   public abstract int getState();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\AreaOp.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */