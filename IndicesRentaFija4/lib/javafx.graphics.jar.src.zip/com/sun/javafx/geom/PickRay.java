/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.Affine3D;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.geom.transform.NoninvertibleTransformException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PickRay
/*     */ {
/*  36 */   private Vec3d origin = new Vec3d();
/*  37 */   private Vec3d direction = new Vec3d();
/*  38 */   private double nearClip = 0.0D;
/*  39 */   private double farClip = Double.POSITIVE_INFINITY;
/*     */   
/*     */   static final double EPS = 9.999999747378752E-6D;
/*     */   private static final double EPSILON_ABSOLUTE = 1.0E-5D;
/*     */   
/*     */   public PickRay() {}
/*     */   
/*     */   public PickRay(Vec3d paramVec3d1, Vec3d paramVec3d2, double paramDouble1, double paramDouble2) {
/*  47 */     set(paramVec3d1, paramVec3d2, paramDouble1, paramDouble2);
/*     */   }
/*     */   
/*     */   public PickRay(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  51 */     set(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PickRay computePerspectivePickRay(double paramDouble1, double paramDouble2, boolean paramBoolean1, double paramDouble3, double paramDouble4, double paramDouble5, boolean paramBoolean2, Affine3D paramAffine3D, double paramDouble6, double paramDouble7, PickRay paramPickRay) {
/*  62 */     if (paramPickRay == null) {
/*  63 */       paramPickRay = new PickRay();
/*     */     }
/*     */     
/*  66 */     Vec3d vec3d1 = paramPickRay.getDirectionNoClone();
/*  67 */     double d1 = paramDouble3 / 2.0D;
/*  68 */     double d2 = paramDouble4 / 2.0D;
/*  69 */     double d3 = paramBoolean2 ? d2 : d1;
/*     */     
/*  71 */     double d4 = d3 / Math.tan(paramDouble5 / 2.0D);
/*     */     
/*  73 */     vec3d1.x = paramDouble1 - d1;
/*  74 */     vec3d1.y = paramDouble2 - d2;
/*  75 */     vec3d1.z = d4;
/*     */     
/*  77 */     Vec3d vec3d2 = paramPickRay.getOriginNoClone();
/*     */     
/*  79 */     if (paramBoolean1) {
/*  80 */       vec3d2.set(0.0D, 0.0D, 0.0D);
/*     */     }
/*     */     else {
/*     */       
/*  84 */       vec3d2.set(d1, d2, -d4);
/*     */     } 
/*     */     
/*  87 */     paramPickRay.nearClip = paramDouble6 * vec3d1.length() / (paramBoolean1 ? d4 : 1.0D);
/*  88 */     paramPickRay.farClip = paramDouble7 * vec3d1.length() / (paramBoolean1 ? d4 : 1.0D);
/*     */     
/*  90 */     paramPickRay.transform(paramAffine3D);
/*     */     
/*  92 */     return paramPickRay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PickRay computeParallelPickRay(double paramDouble1, double paramDouble2, double paramDouble3, Affine3D paramAffine3D, double paramDouble4, double paramDouble5, PickRay paramPickRay) {
/* 101 */     if (paramPickRay == null) {
/* 102 */       paramPickRay = new PickRay();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     double d = paramDouble3 / 2.0D / Math.tan(Math.toRadians(15.0D));
/*     */     
/* 110 */     paramPickRay.set(paramDouble1, paramDouble2, d, paramDouble4 * d, paramDouble5 * d);
/*     */     
/* 112 */     if (paramAffine3D != null) {
/* 113 */       paramPickRay.transform(paramAffine3D);
/*     */     }
/*     */     
/* 116 */     return paramPickRay;
/*     */   }
/*     */   
/*     */   public final void set(Vec3d paramVec3d1, Vec3d paramVec3d2, double paramDouble1, double paramDouble2) {
/* 120 */     setOrigin(paramVec3d1);
/* 121 */     setDirection(paramVec3d2);
/* 122 */     this.nearClip = paramDouble1;
/* 123 */     this.farClip = paramDouble2;
/*     */   }
/*     */   
/*     */   public final void set(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 127 */     setOrigin(paramDouble1, paramDouble2, -paramDouble3);
/* 128 */     setDirection(0.0D, 0.0D, paramDouble3);
/* 129 */     this.nearClip = paramDouble4;
/* 130 */     this.farClip = paramDouble5;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPickRay(PickRay paramPickRay) {
/* 135 */     setOrigin(paramPickRay.origin);
/* 136 */     setDirection(paramPickRay.direction);
/* 137 */     this.nearClip = paramPickRay.nearClip;
/* 138 */     this.farClip = paramPickRay.farClip;
/*     */   }
/*     */   
/*     */   public PickRay copy() {
/* 142 */     return new PickRay(this.origin, this.direction, this.nearClip, this.farClip);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrigin(Vec3d paramVec3d) {
/* 151 */     this.origin.set(paramVec3d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrigin(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 162 */     this.origin.set(paramDouble1, paramDouble2, paramDouble3);
/*     */   }
/*     */   
/*     */   public Vec3d getOrigin(Vec3d paramVec3d) {
/* 166 */     if (paramVec3d == null) {
/* 167 */       paramVec3d = new Vec3d();
/*     */     }
/* 169 */     paramVec3d.set(this.origin);
/* 170 */     return paramVec3d;
/*     */   }
/*     */   
/*     */   public Vec3d getOriginNoClone() {
/* 174 */     return this.origin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirection(Vec3d paramVec3d) {
/* 184 */     this.direction.set(paramVec3d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirection(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 195 */     this.direction.set(paramDouble1, paramDouble2, paramDouble3);
/*     */   }
/*     */   
/*     */   public Vec3d getDirection(Vec3d paramVec3d) {
/* 199 */     if (paramVec3d == null) {
/* 200 */       paramVec3d = new Vec3d();
/*     */     }
/* 202 */     paramVec3d.set(this.direction);
/* 203 */     return paramVec3d;
/*     */   }
/*     */   
/*     */   public Vec3d getDirectionNoClone() {
/* 207 */     return this.direction;
/*     */   }
/*     */   
/*     */   public double getNearClip() {
/* 211 */     return this.nearClip;
/*     */   }
/*     */   
/*     */   public double getFarClip() {
/* 215 */     return this.farClip;
/*     */   }
/*     */   
/*     */   public double distance(Vec3d paramVec3d) {
/* 219 */     double d1 = paramVec3d.x - this.origin.x;
/* 220 */     double d2 = paramVec3d.y - this.origin.y;
/* 221 */     double d3 = paramVec3d.z - this.origin.z;
/* 222 */     return Math.sqrt(d1 * d1 + d2 * d2 + d3 * d3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D projectToZeroPlane(BaseTransform paramBaseTransform, boolean paramBoolean, Vec3d paramVec3d, Point2D paramPoint2D) {
/* 246 */     if (paramVec3d == null) {
/* 247 */       paramVec3d = new Vec3d();
/*     */     }
/* 249 */     paramBaseTransform.transform(this.origin, paramVec3d);
/* 250 */     double d1 = paramVec3d.x;
/* 251 */     double d2 = paramVec3d.y;
/* 252 */     double d3 = paramVec3d.z;
/* 253 */     paramVec3d.add(this.origin, this.direction);
/* 254 */     paramBaseTransform.transform(paramVec3d, paramVec3d);
/* 255 */     double d4 = paramVec3d.x - d1;
/* 256 */     double d5 = paramVec3d.y - d2;
/* 257 */     double d6 = paramVec3d.z - d3;
/*     */     
/* 259 */     if (almostZero(d6)) {
/* 260 */       return null;
/*     */     }
/* 262 */     double d7 = -d3 / d6;
/* 263 */     if (paramBoolean && d7 < 0.0D)
/*     */     {
/* 265 */       return null;
/*     */     }
/* 267 */     if (paramPoint2D == null) {
/* 268 */       paramPoint2D = new Point2D();
/*     */     }
/* 270 */     paramPoint2D.setLocation((float)(d1 + d4 * d7), (float)(d2 + d5 * d7));
/*     */     
/* 272 */     return paramPoint2D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean almostZero(double paramDouble) {
/* 281 */     return (paramDouble < 1.0E-5D && paramDouble > -1.0E-5D);
/*     */   }
/*     */   
/*     */   private static boolean isNonZero(double paramDouble) {
/* 285 */     return (paramDouble > 9.999999747378752E-6D || paramDouble < -9.999999747378752E-6D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void transform(BaseTransform paramBaseTransform) {
/* 290 */     paramBaseTransform.transform(this.origin, this.origin);
/* 291 */     paramBaseTransform.deltaTransform(this.direction, this.direction);
/*     */   }
/*     */ 
/*     */   
/*     */   public void inverseTransform(BaseTransform paramBaseTransform) throws NoninvertibleTransformException {
/* 296 */     paramBaseTransform.inverseTransform(this.origin, this.origin);
/* 297 */     paramBaseTransform.inverseDeltaTransform(this.direction, this.direction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PickRay project(BaseTransform paramBaseTransform, boolean paramBoolean, Vec3d paramVec3d, Point2D paramPoint2D) {
/* 304 */     if (paramVec3d == null) {
/* 305 */       paramVec3d = new Vec3d();
/*     */     }
/* 307 */     paramBaseTransform.transform(this.origin, paramVec3d);
/* 308 */     double d1 = paramVec3d.x;
/* 309 */     double d2 = paramVec3d.y;
/* 310 */     double d3 = paramVec3d.z;
/* 311 */     paramVec3d.add(this.origin, this.direction);
/* 312 */     paramBaseTransform.transform(paramVec3d, paramVec3d);
/* 313 */     double d4 = paramVec3d.x - d1;
/* 314 */     double d5 = paramVec3d.y - d2;
/* 315 */     double d6 = paramVec3d.z - d3;
/*     */     
/* 317 */     PickRay pickRay = new PickRay();
/* 318 */     pickRay.origin.x = d1;
/* 319 */     pickRay.origin.y = d2;
/* 320 */     pickRay.origin.z = d3;
/*     */     
/* 322 */     pickRay.direction.x = d4;
/* 323 */     pickRay.direction.y = d5;
/* 324 */     pickRay.direction.z = d6;
/*     */     
/* 326 */     return pickRay;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 331 */     return "origin: " + this.origin + "  direction: " + this.direction;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\PickRay.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */