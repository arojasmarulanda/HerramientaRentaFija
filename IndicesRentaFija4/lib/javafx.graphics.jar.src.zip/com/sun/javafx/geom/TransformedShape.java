/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.geom.transform.NoninvertibleTransformException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransformedShape
/*     */   extends Shape
/*     */ {
/*     */   protected final Shape delegate;
/*     */   private Shape cachedTransformedShape;
/*     */   
/*     */   public static TransformedShape transformedShape(Shape paramShape, BaseTransform paramBaseTransform) {
/*  61 */     if (paramBaseTransform.isTranslateOrIdentity()) {
/*  62 */       return translatedShape(paramShape, paramBaseTransform.getMxt(), paramBaseTransform.getMyt());
/*     */     }
/*  64 */     return new General(paramShape, paramBaseTransform.copy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TransformedShape translatedShape(Shape paramShape, double paramDouble1, double paramDouble2) {
/*  82 */     return new Translate(paramShape, (float)paramDouble1, (float)paramDouble2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TransformedShape(Shape paramShape) {
/*  88 */     this.delegate = paramShape;
/*     */   }
/*     */   
/*     */   public Shape getDelegateNoClone() {
/*  92 */     return this.delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract BaseTransform getTransformNoClone();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract BaseTransform adjust(BaseTransform paramBaseTransform);
/*     */ 
/*     */ 
/*     */   
/*     */   protected Point2D untransform(float paramFloat1, float paramFloat2) {
/* 106 */     Point2D point2D = new Point2D(paramFloat1, paramFloat2);
/*     */     try {
/* 108 */       point2D = getTransformNoClone().inverseTransform(point2D, point2D);
/* 109 */     } catch (NoninvertibleTransformException noninvertibleTransformException) {}
/*     */ 
/*     */ 
/*     */     
/* 113 */     return point2D;
/*     */   }
/*     */   
/*     */   protected BaseBounds untransformedBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 117 */     RectBounds rectBounds = new RectBounds(paramFloat1, paramFloat2, paramFloat1 + paramFloat3, paramFloat2 + paramFloat4);
/*     */     try {
/* 119 */       return getTransformNoClone().inverseTransform(rectBounds, rectBounds);
/* 120 */     } catch (NoninvertibleTransformException noninvertibleTransformException) {
/* 121 */       return rectBounds.makeEmpty();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public RectBounds getBounds() {
/* 127 */     float[] arrayOfFloat = new float[4];
/* 128 */     Shape.accumulate(arrayOfFloat, this.delegate, getTransformNoClone());
/* 129 */     return new RectBounds(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/* 137 */     return this.delegate.contains(untransform(paramFloat1, paramFloat2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Shape getCachedTransformedShape() {
/* 147 */     if (this.cachedTransformedShape == null) {
/* 148 */       this.cachedTransformedShape = copy();
/*     */     }
/* 150 */     return this.cachedTransformedShape;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 156 */     return getCachedTransformedShape().intersects(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 162 */     return getCachedTransformedShape().contains(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */   }
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/* 167 */     return this.delegate.getPathIterator(adjust(paramBaseTransform));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform, float paramFloat) {
/* 174 */     return this.delegate.getPathIterator(adjust(paramBaseTransform), paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape copy() {
/* 179 */     return getTransformNoClone().createTransformedShape(this.delegate);
/*     */   }
/*     */   
/*     */   static final class General extends TransformedShape {
/*     */     BaseTransform transform;
/*     */     
/*     */     General(Shape param1Shape, BaseTransform param1BaseTransform) {
/* 186 */       super(param1Shape);
/* 187 */       this.transform = param1BaseTransform;
/*     */     }
/*     */     
/*     */     public BaseTransform getTransformNoClone() {
/* 191 */       return this.transform;
/*     */     }
/*     */     
/*     */     public BaseTransform adjust(BaseTransform param1BaseTransform) {
/* 195 */       if (param1BaseTransform == null || param1BaseTransform.isIdentity()) {
/* 196 */         return this.transform.copy();
/*     */       }
/* 198 */       return param1BaseTransform.copy().deriveWithConcatenation(this.transform);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class Translate extends TransformedShape {
/*     */     private final float tx;
/*     */     private final float ty;
/*     */     private BaseTransform cachedTx;
/*     */     
/*     */     public Translate(Shape param1Shape, float param1Float1, float param1Float2) {
/* 208 */       super(param1Shape);
/* 209 */       this.tx = param1Float1;
/* 210 */       this.ty = param1Float2;
/*     */     }
/*     */ 
/*     */     
/*     */     public BaseTransform getTransformNoClone() {
/* 215 */       if (this.cachedTx == null) {
/* 216 */         this.cachedTx = BaseTransform.getTranslateInstance(this.tx, this.ty);
/*     */       }
/* 218 */       return this.cachedTx;
/*     */     }
/*     */     
/*     */     public BaseTransform adjust(BaseTransform param1BaseTransform) {
/* 222 */       if (param1BaseTransform == null || param1BaseTransform.isIdentity()) {
/* 223 */         return BaseTransform.getTranslateInstance(this.tx, this.ty);
/*     */       }
/* 225 */       return param1BaseTransform.copy().deriveWithTranslation(this.tx, this.ty);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public RectBounds getBounds() {
/* 231 */       RectBounds rectBounds = this.delegate.getBounds();
/* 232 */       rectBounds.setBounds(rectBounds.getMinX() + this.tx, rectBounds.getMinY() + this.ty, rectBounds
/* 233 */           .getMaxX() + this.tx, rectBounds.getMaxY() + this.ty);
/*     */       
/* 235 */       return rectBounds;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(float param1Float1, float param1Float2) {
/* 240 */       return this.delegate.contains(param1Float1 - this.tx, param1Float2 - this.ty);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean intersects(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
/* 245 */       return this.delegate.intersects(param1Float1 - this.tx, param1Float2 - this.ty, param1Float3, param1Float4);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
/* 250 */       return this.delegate.contains(param1Float1 - this.tx, param1Float2 - this.ty, param1Float3, param1Float4);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geom\TransformedShape.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */