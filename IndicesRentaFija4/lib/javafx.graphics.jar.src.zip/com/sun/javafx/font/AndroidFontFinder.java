/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AndroidFontFinder
/*     */ {
/*     */   private static final String SYSTEM_FONT_NAME = "sans serif";
/*     */   private static final float SYSTEM_FONT_SIZE = 16.0F;
/*     */   static final String fontDescriptor_2_X_Path = "/com/sun/javafx/font/android_system_fonts.xml";
/*     */   static final String fontDescriptor_4_X_Path = "/system/etc/system_fonts.xml";
/*     */   static final String systemFontsDir = "/system/fonts";
/*     */   
/*     */   static {
/*  66 */     AccessController.doPrivileged(() -> {
/*     */           NativeLibLoader.loadLibrary("javafx_font");
/*     */           return null;
/*     */         });
/*     */   }
/*     */   
/*     */   public static String getSystemFont() {
/*  73 */     return "sans serif";
/*     */   }
/*     */   
/*     */   public static float getSystemFontSize() {
/*  77 */     return 16.0F;
/*     */   }
/*     */   
/*     */   public static String getSystemFontsDir() {
/*  81 */     return "/system/fonts";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean parse_2_X_SystemDefaultFonts(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap) {
/*  90 */     InputStream inputStream = AndroidFontFinder.class.getResourceAsStream("/com/sun/javafx/font/android_system_fonts.xml");
/*  91 */     if (inputStream == null) {
/*  92 */       System.err
/*  93 */         .println("Resource not found: /com/sun/javafx/font/android_system_fonts.xml");
/*  94 */       return false;
/*     */     } 
/*  96 */     return parseSystemDefaultFonts(inputStream, paramHashMap1, paramHashMap2, paramHashMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean parse_4_X_SystemDefaultFonts(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap) {
/* 104 */     File file = new File("/system/etc/system_fonts.xml");
/*     */     try {
/* 106 */       return parseSystemDefaultFonts(new FileInputStream(file), paramHashMap1, paramHashMap2, paramHashMap);
/*     */     
/*     */     }
/* 109 */     catch (FileNotFoundException fileNotFoundException) {
/* 110 */       System.err.println("File not found: /system/etc/system_fonts.xml");
/*     */       
/* 112 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean parseSystemDefaultFonts(InputStream paramInputStream, final HashMap<String, String> fontToFileMap, final HashMap<String, String> fontToFamilyNameMap, final HashMap<String, ArrayList<String>> familyToFontListMap) {
/*     */     try {
/* 122 */       SAXParserFactory sAXParserFactory = SAXParserFactory.newInstance();
/* 123 */       SAXParser sAXParser = sAXParserFactory.newSAXParser();
/*     */       
/* 125 */       DefaultHandler defaultHandler = new DefaultHandler()
/*     */         {
/*     */           private static final char DASH = '-';
/*     */           private static final String FAMILY = "family";
/*     */           private static final String FILE = "file";
/*     */           private static final String FILESET = "fileset";
/*     */           private static final String NAME = "name";
/*     */           private static final String NAMESET = "nameset";
/*     */           private static final char SPACE = ' ';
/* 134 */           final List<String> filesets = new ArrayList<>();
/*     */           
/*     */           boolean inFamily = false;
/*     */           
/*     */           boolean inFile = false;
/*     */           boolean inFileset = false;
/*     */           boolean inName = false;
/*     */           boolean inNameset = false;
/* 142 */           private final List<String> namesets = new ArrayList<>();
/* 143 */           private final String[] styles = new String[] { "regular", "bold", "italic", "bold italic" };
/*     */ 
/*     */ 
/*     */           
/*     */           public void characters(char[] param1ArrayOfchar, int param1Int1, int param1Int2) throws SAXException {
/* 148 */             if (this.inName) {
/*     */               
/* 150 */               String str = (new String(param1ArrayOfchar, param1Int1, param1Int2)).toLowerCase();
/* 151 */               this.namesets.add(str);
/* 152 */             } else if (this.inFile) {
/* 153 */               String str = new String(param1ArrayOfchar, param1Int1, param1Int2);
/* 154 */               this.filesets.add(str);
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public void endElement(String param1String1, String param1String2, String param1String3) throws SAXException {
/* 160 */             if (param1String3.equalsIgnoreCase("family")) {
/* 161 */               for (String str1 : this.namesets) {
/* 162 */                 byte b = 0;
/* 163 */                 String str2 = str1.replace('-', ' ');
/* 164 */                 for (String str3 : this.filesets) {
/* 165 */                   String str4 = str2 + " " + str2;
/* 166 */                   String str5 = "/system/fonts" + File.separator + str3;
/*     */                   
/* 168 */                   File file = new File(str5);
/* 169 */                   if (!file.exists() || !file.canRead()) {
/*     */                     continue;
/*     */                   }
/* 172 */                   fontToFileMap.put(str4, str5);
/* 173 */                   fontToFamilyNameMap.put(str4, str2);
/*     */                   
/* 175 */                   ArrayList<String> arrayList = (ArrayList)familyToFontListMap.get(str2);
/* 176 */                   if (arrayList == null) {
/* 177 */                     arrayList = new ArrayList();
/* 178 */                     familyToFontListMap.put(str2, arrayList);
/*     */                   } 
/* 180 */                   arrayList.add(str4);
/* 181 */                   b++;
/*     */                 } 
/*     */               } 
/* 184 */               this.inFamily = false;
/* 185 */             } else if (param1String3.equalsIgnoreCase("nameset")) {
/* 186 */               this.inNameset = false;
/* 187 */             } else if (param1String3.equalsIgnoreCase("fileset")) {
/* 188 */               this.inFileset = false;
/* 189 */             } else if (param1String3.equalsIgnoreCase("name")) {
/* 190 */               this.inName = false;
/* 191 */             } else if (param1String3.equalsIgnoreCase("file")) {
/* 192 */               this.inFile = false;
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void startElement(String param1String1, String param1String2, String param1String3, Attributes param1Attributes) throws SAXException {
/* 200 */             if (param1String3.equalsIgnoreCase("family")) {
/* 201 */               this.inFamily = true;
/* 202 */               this.namesets.clear();
/* 203 */               this.filesets.clear();
/* 204 */             } else if (param1String3.equalsIgnoreCase("nameset")) {
/* 205 */               this.inNameset = true;
/* 206 */             } else if (param1String3.equalsIgnoreCase("fileset")) {
/* 207 */               this.inFileset = true;
/* 208 */             } else if (param1String3.equalsIgnoreCase("name")) {
/* 209 */               this.inName = true;
/* 210 */             } else if (param1String3.equalsIgnoreCase("file")) {
/* 211 */               this.inFile = true;
/*     */             } 
/*     */           }
/*     */         };
/*     */       
/* 216 */       sAXParser.parse(paramInputStream, defaultHandler);
/* 217 */       return true;
/*     */     }
/* 219 */     catch (IOException iOException) {
/* 220 */       System.err.println("Failed to load default fonts descriptor: /system/etc/system_fonts.xml");
/*     */     }
/* 222 */     catch (Exception exception) {
/* 223 */       System.err.println("Failed parsing default fonts descriptor;");
/* 224 */       exception.printStackTrace();
/*     */     } 
/* 226 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void populateFontFileNameMap(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap, Locale paramLocale) {
/* 235 */     if (paramHashMap1 == null || paramHashMap2 == null || paramHashMap == null) {
/*     */       return;
/*     */     }
/*     */     
/* 239 */     if (paramLocale == null) {
/* 240 */       paramLocale = Locale.ENGLISH;
/*     */     }
/*     */     
/* 243 */     boolean bool = parse_4_X_SystemDefaultFonts(paramHashMap1, paramHashMap2, paramHashMap);
/*     */     
/* 245 */     if (!bool)
/* 246 */       parse_2_X_SystemDefaultFonts(paramHashMap1, paramHashMap2, paramHashMap); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\AndroidFontFinder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */