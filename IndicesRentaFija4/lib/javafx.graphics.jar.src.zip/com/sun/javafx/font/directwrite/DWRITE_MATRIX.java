package com.sun.javafx.font.directwrite;

class DWRITE_MATRIX {
  float m11;
  
  float m12;
  
  float m21;
  
  float m22;
  
  float dx;
  
  float dy;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\DWRITE_MATRIX.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */