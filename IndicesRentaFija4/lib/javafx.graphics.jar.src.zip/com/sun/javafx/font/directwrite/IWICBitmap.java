/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IWICBitmap
/*    */   extends IUnknown
/*    */ {
/*    */   IWICBitmap(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   IWICBitmapLock Lock(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 34 */     long l = OS.Lock(this.ptr, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 35 */     return (l != 0L) ? new IWICBitmapLock(l) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IWICBitmap.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */