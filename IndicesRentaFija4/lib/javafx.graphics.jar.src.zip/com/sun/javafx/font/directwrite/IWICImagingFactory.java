/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IWICImagingFactory
/*    */   extends IUnknown
/*    */ {
/*    */   IWICImagingFactory(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   IWICBitmap CreateBitmap(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 34 */     long l = OS.CreateBitmap(this.ptr, paramInt1, paramInt2, paramInt3, paramInt4);
/* 35 */     return (l != 0L) ? new IWICBitmap(l) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IWICImagingFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */