/*     */ package com.sun.javafx.font.directwrite;
/*     */ 
/*     */ import com.sun.javafx.font.CompositeFontResource;
/*     */ import com.sun.javafx.font.FontResource;
/*     */ import com.sun.javafx.font.FontStrike;
/*     */ import com.sun.javafx.font.PGFont;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.scene.text.TextSpan;
/*     */ import com.sun.javafx.text.GlyphLayout;
/*     */ import com.sun.javafx.text.PrismTextLayout;
/*     */ import com.sun.javafx.text.TextRun;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DWGlyphLayout
/*     */   extends GlyphLayout
/*     */ {
/*     */   private static final String LOCALE = "en-us";
/*     */   
/*     */   protected TextRun addTextRun(PrismTextLayout paramPrismTextLayout, char[] paramArrayOfchar, int paramInt1, int paramInt2, PGFont paramPGFont, TextSpan paramTextSpan, byte paramByte) {
/*  48 */     IDWriteFactory iDWriteFactory = DWFactory.getDWriteFactory();
/*  49 */     IDWriteTextAnalyzer iDWriteTextAnalyzer = iDWriteFactory.CreateTextAnalyzer();
/*  50 */     if (iDWriteTextAnalyzer == null) {
/*  51 */       return new TextRun(paramInt1, paramInt2, paramByte, false, 0, paramTextSpan, 0, false);
/*     */     }
/*     */ 
/*     */     
/*  55 */     boolean bool = ((paramByte & 0x1) != 0) ? true : false;
/*  56 */     JFXTextAnalysisSink jFXTextAnalysisSink = OS.NewJFXTextAnalysisSink(paramArrayOfchar, paramInt1, paramInt2, "en-us", bool);
/*  57 */     if (jFXTextAnalysisSink == null) {
/*  58 */       return new TextRun(paramInt1, paramInt2, paramByte, false, 0, paramTextSpan, 0, false);
/*     */     }
/*  60 */     jFXTextAnalysisSink.AddRef();
/*     */     
/*  62 */     TextRun textRun = null;
/*  63 */     int i = iDWriteTextAnalyzer.AnalyzeScript(jFXTextAnalysisSink, 0, paramInt2, jFXTextAnalysisSink);
/*  64 */     if (i == 0) {
/*  65 */       while (jFXTextAnalysisSink.Next()) {
/*  66 */         int j = jFXTextAnalysisSink.GetStart();
/*  67 */         int k = jFXTextAnalysisSink.GetLength();
/*  68 */         DWRITE_SCRIPT_ANALYSIS dWRITE_SCRIPT_ANALYSIS = jFXTextAnalysisSink.GetAnalysis();
/*  69 */         textRun = new TextRun(paramInt1 + j, k, paramByte, true, dWRITE_SCRIPT_ANALYSIS.script, paramTextSpan, dWRITE_SCRIPT_ANALYSIS.shapes, false);
/*     */ 
/*     */         
/*  72 */         paramPrismTextLayout.addTextRun(textRun);
/*     */       } 
/*     */     }
/*     */     
/*  76 */     iDWriteTextAnalyzer.Release();
/*  77 */     jFXTextAnalysisSink.Release();
/*  78 */     return textRun;
/*     */   }
/*     */ 
/*     */   
/*     */   public void layout(TextRun paramTextRun, PGFont paramPGFont, FontStrike paramFontStrike, char[] paramArrayOfchar) {
/*  83 */     int i = 0;
/*  84 */     FontResource fontResource = paramPGFont.getFontResource();
/*  85 */     boolean bool = fontResource instanceof CompositeFontResource;
/*  86 */     if (bool) {
/*  87 */       i = getInitialSlot(fontResource);
/*  88 */       fontResource = ((CompositeFontResource)fontResource).getSlotResource(i);
/*     */     } 
/*  90 */     IDWriteFontFace iDWriteFontFace = ((DWFontFile)fontResource).getFontFace();
/*  91 */     if (iDWriteFontFace == null)
/*     */       return; 
/*  93 */     IDWriteFactory iDWriteFactory = DWFactory.getDWriteFactory();
/*  94 */     IDWriteTextAnalyzer iDWriteTextAnalyzer = iDWriteFactory.CreateTextAnalyzer();
/*  95 */     if (iDWriteTextAnalyzer == null) {
/*     */       return;
/*     */     }
/*  98 */     long[] arrayOfLong = null;
/*  99 */     int[] arrayOfInt1 = null;
/* 100 */     boolean bool1 = false;
/*     */     
/* 102 */     int j = paramTextRun.getLength();
/* 103 */     short[] arrayOfShort1 = new short[j];
/* 104 */     short[] arrayOfShort2 = new short[j];
/* 105 */     int k = j * 3 / 2 + 16;
/* 106 */     short[] arrayOfShort3 = new short[k];
/* 107 */     short[] arrayOfShort4 = new short[k];
/* 108 */     int[] arrayOfInt2 = new int[1];
/* 109 */     boolean bool2 = !paramTextRun.isLeftToRight() ? true : false;
/*     */     
/* 111 */     DWRITE_SCRIPT_ANALYSIS dWRITE_SCRIPT_ANALYSIS = new DWRITE_SCRIPT_ANALYSIS();
/* 112 */     dWRITE_SCRIPT_ANALYSIS.script = (short)paramTextRun.getScript();
/* 113 */     dWRITE_SCRIPT_ANALYSIS.shapes = paramTextRun.getSlot();
/*     */     
/* 115 */     int m = paramTextRun.getStart();
/* 116 */     int n = iDWriteTextAnalyzer.GetGlyphs(paramArrayOfchar, m, j, iDWriteFontFace, false, bool2, dWRITE_SCRIPT_ANALYSIS, (String)null, 0L, arrayOfLong, arrayOfInt1, bool1, k, arrayOfShort1, arrayOfShort2, arrayOfShort3, arrayOfShort4, arrayOfInt2);
/*     */ 
/*     */ 
/*     */     
/* 120 */     if (n == -2147024774) {
/*     */       
/* 122 */       k *= 2;
/* 123 */       arrayOfShort3 = new short[k];
/* 124 */       arrayOfShort4 = new short[k];
/* 125 */       n = iDWriteTextAnalyzer.GetGlyphs(paramArrayOfchar, m, j, iDWriteFontFace, false, bool2, dWRITE_SCRIPT_ANALYSIS, (String)null, 0L, arrayOfLong, arrayOfInt1, bool1, k, arrayOfShort1, arrayOfShort2, arrayOfShort3, arrayOfShort4, arrayOfInt2);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 130 */     if (n != 0) {
/* 131 */       iDWriteTextAnalyzer.Release();
/*     */       return;
/*     */     } 
/* 134 */     int i1 = arrayOfInt2[0];
/*     */ 
/*     */     
/* 137 */     byte b1 = bool2 ? -1 : 1;
/*     */     
/* 139 */     int[] arrayOfInt3 = new int[i1];
/* 140 */     int i3 = i << 24;
/* 141 */     boolean bool3 = false;
/* 142 */     byte b2 = 0; int i2 = bool2 ? (i1 - 1) : 0;
/* 143 */     while (b2 < i1) {
/* 144 */       if (arrayOfShort3[b2] == 0) {
/* 145 */         bool3 = true;
/* 146 */         if (bool)
/*     */           break; 
/* 148 */       }  arrayOfInt3[b2] = arrayOfShort3[i2] | i3;
/* 149 */       b2++;
/* 150 */       i2 += b1;
/*     */     } 
/* 152 */     if (bool3 && bool) {
/* 153 */       iDWriteTextAnalyzer.Release();
/* 154 */       renderShape(paramArrayOfchar, paramTextRun, paramPGFont, i);
/*     */       
/*     */       return;
/*     */     } 
/* 158 */     float f = paramPGFont.getSize();
/* 159 */     float[] arrayOfFloat1 = new float[i1];
/* 160 */     float[] arrayOfFloat2 = new float[i1 * 2];
/* 161 */     iDWriteTextAnalyzer.GetGlyphPlacements(paramArrayOfchar, arrayOfShort1, arrayOfShort2, m, j, arrayOfShort3, arrayOfShort4, i1, iDWriteFontFace, f, false, bool2, dWRITE_SCRIPT_ANALYSIS, (String)null, arrayOfLong, arrayOfInt1, bool1, arrayOfFloat1, arrayOfFloat2);
/*     */ 
/*     */ 
/*     */     
/* 165 */     iDWriteTextAnalyzer.Release();
/*     */     
/* 167 */     float[] arrayOfFloat3 = getPositions(arrayOfFloat1, arrayOfFloat2, i1, bool2);
/* 168 */     int[] arrayOfInt4 = getIndices(arrayOfShort1, i1, bool2);
/* 169 */     paramTextRun.shape(i1, arrayOfInt3, arrayOfFloat3, arrayOfInt4);
/*     */   }
/*     */   
/*     */   private float[] getPositions(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt, boolean paramBoolean) {
/* 173 */     float[] arrayOfFloat = new float[paramInt * 2 + 2];
/* 174 */     byte b1 = 0;
/* 175 */     int i = paramBoolean ? (paramInt - 1) : 0;
/* 176 */     byte b2 = paramBoolean ? -1 : 1;
/* 177 */     float f = 0.0F;
/* 178 */     while (b1 < arrayOfFloat.length - 2) {
/* 179 */       int j = i << 1;
/* 180 */       arrayOfFloat[b1++] = (paramBoolean ? -paramArrayOffloat2[j] : paramArrayOffloat2[j]) + f;
/* 181 */       arrayOfFloat[b1++] = -paramArrayOffloat2[j + 1];
/* 182 */       f += paramArrayOffloat1[i];
/* 183 */       i += b2;
/*     */     } 
/* 185 */     arrayOfFloat[b1++] = f;
/* 186 */     arrayOfFloat[b1++] = 0.0F;
/* 187 */     return arrayOfFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] getIndices(short[] paramArrayOfshort, int paramInt, boolean paramBoolean) {
/* 194 */     int[] arrayOfInt = new int[paramInt];
/* 195 */     Arrays.fill(arrayOfInt, -1); byte b;
/* 196 */     for (b = 0; b < paramArrayOfshort.length; b++) {
/* 197 */       short s = paramArrayOfshort[b];
/*     */       
/* 199 */       if (0 <= s && s < paramInt && arrayOfInt[s] == -1) {
/* 200 */         arrayOfInt[s] = b;
/*     */       }
/*     */     } 
/* 203 */     if (arrayOfInt.length > 0) {
/* 204 */       if (arrayOfInt[0] == -1) arrayOfInt[0] = 0;
/*     */       
/* 206 */       for (b = 1; b < arrayOfInt.length; b++) {
/* 207 */         if (arrayOfInt[b] == -1) arrayOfInt[b] = arrayOfInt[b - 1];
/*     */       
/*     */       } 
/*     */     } 
/* 211 */     if (paramBoolean)
/*     */     {
/* 213 */       for (b = 0; b < arrayOfInt.length / 2; b++) {
/* 214 */         int i = arrayOfInt[b];
/* 215 */         arrayOfInt[b] = arrayOfInt[arrayOfInt.length - b - 1];
/* 216 */         arrayOfInt[arrayOfInt.length - b - 1] = i;
/*     */       } 
/*     */     }
/* 219 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   private String getName(IDWriteLocalizedStrings paramIDWriteLocalizedStrings) {
/* 223 */     if (paramIDWriteLocalizedStrings == null) return null; 
/* 224 */     int i = paramIDWriteLocalizedStrings.FindLocaleName("en-us");
/* 225 */     String str = null;
/* 226 */     if (i >= 0) {
/* 227 */       int j = paramIDWriteLocalizedStrings.GetStringLength(i);
/* 228 */       str = paramIDWriteLocalizedStrings.GetString(i, j);
/*     */     } 
/* 230 */     paramIDWriteLocalizedStrings.Release();
/* 231 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   private FontResource checkFontResource(FontResource paramFontResource, String paramString1, String paramString2) {
/* 236 */     if (paramFontResource == null) return null;
/*     */ 
/*     */     
/* 239 */     if (paramString1 != null && 
/* 240 */       paramString1.equals(paramFontResource.getPSName())) return paramFontResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     if (paramString2 != null) {
/* 248 */       if (paramString2.equals(paramFontResource.getFullName())) return paramFontResource;
/*     */ 
/*     */       
/* 251 */       String str = paramFontResource.getFamilyName() + " " + paramFontResource.getFamilyName();
/* 252 */       if (paramString2.equals(str)) return paramFontResource; 
/*     */     } 
/* 254 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getFontSlot(IDWriteFontFace paramIDWriteFontFace, CompositeFontResource paramCompositeFontResource, String paramString, int paramInt) {
/* 259 */     if (paramIDWriteFontFace == null) return -1; 
/* 260 */     IDWriteFontCollection iDWriteFontCollection = DWFactory.getFontCollection();
/* 261 */     PrismFontFactory prismFontFactory = PrismFontFactory.getFontFactory();
/*     */ 
/*     */ 
/*     */     
/* 265 */     IDWriteFont iDWriteFont = iDWriteFontCollection.GetFontFromFontFace(paramIDWriteFontFace);
/* 266 */     if (iDWriteFont == null) return -1; 
/* 267 */     IDWriteFontFamily iDWriteFontFamily = iDWriteFont.GetFontFamily();
/* 268 */     String str1 = getName(iDWriteFontFamily.GetFamilyNames());
/* 269 */     iDWriteFontFamily.Release();
/* 270 */     int i = (iDWriteFont.GetStyle() != 0) ? 1 : 0;
/* 271 */     int j = (iDWriteFont.GetWeight() > 400) ? 1 : 0;
/* 272 */     int k = iDWriteFont.GetSimulations();
/* 273 */     byte b = 17;
/* 274 */     String str2 = getName(iDWriteFont.GetInformationalStrings(b));
/* 275 */     b = 11;
/* 276 */     String str3 = getName(iDWriteFont.GetInformationalStrings(b));
/* 277 */     b = 12;
/* 278 */     String str4 = getName(iDWriteFont.GetInformationalStrings(b));
/* 279 */     String str5 = str3 + " " + str3;
/*     */     
/* 281 */     if (PrismFontFactory.debugFonts) {
/* 282 */       String str = getName(iDWriteFont.GetFaceNames());
/* 283 */       System.err.println("Mapping IDWriteFont=\"" + str1 + " " + str + "\" Postscript name=\"" + str2 + "\" Win32 name=\"" + str5 + "\"");
/*     */     } 
/*     */ 
/*     */     
/* 287 */     iDWriteFont.Release();
/*     */ 
/*     */     
/* 290 */     FontResource fontResource = prismFontFactory.getFontResource(str1, j, i, false);
/* 291 */     fontResource = checkFontResource(fontResource, str2, str5);
/* 292 */     if (fontResource == null) {
/*     */ 
/*     */       
/* 295 */       i &= ((k & 0x2) == 0) ? 1 : 0;
/* 296 */       j &= ((k & 0x1) == 0) ? 1 : 0;
/* 297 */       fontResource = prismFontFactory.getFontResource(str1, j, i, false);
/* 298 */       fontResource = checkFontResource(fontResource, str2, str5);
/*     */     } 
/* 300 */     if (fontResource == null) {
/*     */       
/* 302 */       fontResource = prismFontFactory.getFontResource(str5, null, false);
/* 303 */       fontResource = checkFontResource(fontResource, str2, str5);
/*     */     } 
/* 305 */     if (fontResource == null) {
/* 306 */       if (PrismFontFactory.debugFonts) {
/* 307 */         System.err.println("\t**** Failed to map IDWriteFont to Prism ****");
/*     */       }
/* 309 */       return -1;
/*     */     } 
/*     */     
/* 312 */     String str6 = fontResource.getFullName();
/* 313 */     if (!paramString.equalsIgnoreCase(str6)) {
/* 314 */       paramInt = paramCompositeFontResource.getSlotForFont(str6);
/*     */     }
/* 316 */     if (PrismFontFactory.debugFonts) {
/* 317 */       System.err.println("\tFallback full name=\"" + str6 + "\" Postscript name=\"" + fontResource
/* 318 */           .getPSName() + "\" Style name=\"" + fontResource
/* 319 */           .getStyleName() + "\" slot=" + paramInt);
/*     */     }
/*     */     
/* 322 */     return paramInt;
/*     */   }
/*     */   
/*     */   private void renderShape(char[] paramArrayOfchar, TextRun paramTextRun, PGFont paramPGFont, int paramInt) {
/* 326 */     CompositeFontResource compositeFontResource = (CompositeFontResource)paramPGFont.getFontResource();
/* 327 */     FontResource fontResource = compositeFontResource.getSlotResource(paramInt);
/* 328 */     String str1 = fontResource.getFamilyName();
/* 329 */     String str2 = fontResource.getFullName();
/*     */     
/* 331 */     char c = fontResource.isBold() ? 'ʼ' : 'Ɛ';
/* 332 */     byte b = 5;
/*     */     
/* 334 */     boolean bool = fontResource.isItalic() ? true : false;
/* 335 */     float f1 = paramPGFont.getSize();
/*     */ 
/*     */     
/* 338 */     float f2 = (f1 > 0.0F) ? f1 : 1.0F;
/*     */     
/* 340 */     IDWriteFactory iDWriteFactory = DWFactory.getDWriteFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 345 */     IDWriteFontCollection iDWriteFontCollection = DWFactory.getFontCollection();
/*     */     
/* 347 */     IDWriteTextFormat iDWriteTextFormat = iDWriteFactory.CreateTextFormat(str1, iDWriteFontCollection, c, bool, b, f2, "en-us");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 354 */     if (iDWriteTextFormat == null)
/*     */       return; 
/* 356 */     int i = paramTextRun.getStart();
/* 357 */     int j = paramTextRun.getLength();
/* 358 */     IDWriteTextLayout iDWriteTextLayout = iDWriteFactory.CreateTextLayout(paramArrayOfchar, i, j, iDWriteTextFormat, 100000.0F, 100000.0F);
/* 359 */     if (iDWriteTextLayout != null) {
/* 360 */       JFXTextRenderer jFXTextRenderer = OS.NewJFXTextRenderer();
/* 361 */       if (jFXTextRenderer != null) {
/* 362 */         jFXTextRenderer.AddRef();
/*     */ 
/*     */         
/* 365 */         iDWriteTextLayout.Draw(0L, jFXTextRenderer, 0.0F, 0.0F);
/*     */ 
/*     */         
/* 368 */         int k = jFXTextRenderer.GetTotalGlyphCount();
/* 369 */         int[] arrayOfInt1 = new int[k];
/* 370 */         float[] arrayOfFloat1 = new float[k];
/* 371 */         float[] arrayOfFloat2 = new float[k * 2];
/* 372 */         short[] arrayOfShort = new short[j];
/* 373 */         int m = 0;
/* 374 */         int n = 0;
/* 375 */         while (jFXTextRenderer.Next()) {
/* 376 */           IDWriteFontFace iDWriteFontFace = jFXTextRenderer.GetFontFace();
/* 377 */           int i1 = getFontSlot(iDWriteFontFace, compositeFontResource, str2, paramInt);
/* 378 */           if (i1 >= 0) {
/* 379 */             jFXTextRenderer.GetGlyphIndices(arrayOfInt1, m, i1 << 24);
/* 380 */             jFXTextRenderer.GetGlyphOffsets(arrayOfFloat2, m * 2);
/*     */           } 
/* 382 */           if (f1 > 0.0F)
/*     */           {
/* 384 */             jFXTextRenderer.GetGlyphAdvances(arrayOfFloat1, m);
/*     */           }
/* 386 */           jFXTextRenderer.GetClusterMap(arrayOfShort, n, m);
/* 387 */           m += jFXTextRenderer.GetGlyphCount();
/* 388 */           n += jFXTextRenderer.GetLength();
/*     */         } 
/* 390 */         jFXTextRenderer.Release();
/*     */ 
/*     */         
/* 393 */         boolean bool1 = !paramTextRun.isLeftToRight() ? true : false;
/* 394 */         if (bool1) {
/* 395 */           for (byte b1 = 0; b1 < k / 2; b1++) {
/* 396 */             int i1 = arrayOfInt1[b1];
/* 397 */             arrayOfInt1[b1] = arrayOfInt1[k - b1 - 1];
/* 398 */             arrayOfInt1[k - b1 - 1] = i1;
/*     */           } 
/*     */         }
/* 401 */         float[] arrayOfFloat3 = getPositions(arrayOfFloat1, arrayOfFloat2, k, bool1);
/* 402 */         int[] arrayOfInt2 = getIndices(arrayOfShort, k, bool1);
/* 403 */         paramTextRun.shape(k, arrayOfInt1, arrayOfFloat3, arrayOfInt2);
/*     */       } 
/* 405 */       iDWriteTextLayout.Release();
/*     */     } 
/* 407 */     iDWriteTextFormat.Release();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\DWGlyphLayout.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */