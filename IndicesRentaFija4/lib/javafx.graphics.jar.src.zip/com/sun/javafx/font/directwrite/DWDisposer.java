/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ import com.sun.javafx.font.DisposerRecord;
/*    */ import com.sun.javafx.font.PrismFontFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DWDisposer
/*    */   implements DisposerRecord
/*    */ {
/*    */   IUnknown resource;
/*    */   
/*    */   DWDisposer(IUnknown paramIUnknown) {
/* 35 */     this.resource = paramIUnknown;
/*    */   }
/*    */   
/*    */   public synchronized void dispose() {
/* 39 */     if (this.resource != null) {
/* 40 */       this.resource.Release();
/* 41 */       if (PrismFontFactory.debugFonts) {
/* 42 */         System.err.println("DisposerRecord=" + this.resource);
/*    */       }
/* 44 */       this.resource = null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\DWDisposer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */