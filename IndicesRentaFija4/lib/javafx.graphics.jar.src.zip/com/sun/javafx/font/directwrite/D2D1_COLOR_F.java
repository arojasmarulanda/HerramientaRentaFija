/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class D2D1_COLOR_F
/*    */ {
/*    */   float r;
/*    */   float g;
/*    */   float b;
/*    */   float a;
/*    */   
/*    */   D2D1_COLOR_F() {}
/*    */   
/*    */   D2D1_COLOR_F(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 33 */     this.r = paramFloat1;
/* 34 */     this.g = paramFloat2;
/* 35 */     this.b = paramFloat3;
/* 36 */     this.a = paramFloat4;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\D2D1_COLOR_F.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */