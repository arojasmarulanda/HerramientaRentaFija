/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JFXTextRenderer
/*    */   extends IUnknown
/*    */ {
/*    */   JFXTextRenderer(long paramLong) {
/* 31 */     super(paramLong);
/*    */   }
/*    */   
/*    */   boolean Next() {
/* 35 */     return OS.JFXTextRendererNext(this.ptr);
/*    */   }
/*    */   
/*    */   int GetStart() {
/* 39 */     return OS.JFXTextRendererGetStart(this.ptr);
/*    */   }
/*    */   
/*    */   int GetLength() {
/* 43 */     return OS.JFXTextRendererGetLength(this.ptr);
/*    */   }
/*    */   
/*    */   int GetGlyphCount() {
/* 47 */     return OS.JFXTextRendererGetGlyphCount(this.ptr);
/*    */   }
/*    */   
/*    */   int GetTotalGlyphCount() {
/* 51 */     return OS.JFXTextRendererGetTotalGlyphCount(this.ptr);
/*    */   }
/*    */   
/*    */   IDWriteFontFace GetFontFace() {
/* 55 */     long l = OS.JFXTextRendererGetFontFace(this.ptr);
/* 56 */     return (l != 0L) ? new IDWriteFontFace(l) : null;
/*    */   }
/*    */   
/*    */   int GetGlyphIndices(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 60 */     return OS.JFXTextRendererGetGlyphIndices(this.ptr, paramArrayOfint, paramInt1, paramInt2);
/*    */   }
/*    */   
/*    */   int GetGlyphAdvances(float[] paramArrayOffloat, int paramInt) {
/* 64 */     return OS.JFXTextRendererGetGlyphAdvances(this.ptr, paramArrayOffloat, paramInt);
/*    */   }
/*    */   
/*    */   int GetGlyphOffsets(float[] paramArrayOffloat, int paramInt) {
/* 68 */     return OS.JFXTextRendererGetGlyphOffsets(this.ptr, paramArrayOffloat, paramInt);
/*    */   }
/*    */   
/*    */   int GetClusterMap(short[] paramArrayOfshort, int paramInt1, int paramInt2) {
/* 72 */     return OS.JFXTextRendererGetClusterMap(this.ptr, paramArrayOfshort, paramInt1, paramInt2);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\JFXTextRenderer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */