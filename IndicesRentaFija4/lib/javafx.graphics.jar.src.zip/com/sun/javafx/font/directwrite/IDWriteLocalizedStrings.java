/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteLocalizedStrings
/*    */   extends IUnknown
/*    */ {
/*    */   IDWriteLocalizedStrings(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   int FindLocaleName(String paramString) {
/* 34 */     return OS.FindLocaleName(this.ptr, (paramString + "\000").toCharArray());
/*    */   }
/*    */   
/*    */   int GetStringLength(int paramInt) {
/* 38 */     return OS.GetStringLength(this.ptr, paramInt);
/*    */   }
/*    */   
/*    */   String GetString(int paramInt1, int paramInt2) {
/* 42 */     char[] arrayOfChar = OS.GetString(this.ptr, paramInt1, paramInt2 + 1);
/* 43 */     return (arrayOfChar != null) ? new String(arrayOfChar, 0, paramInt2) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IDWriteLocalizedStrings.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */