/*     */ package com.sun.javafx.font.directwrite;
/*     */ 
/*     */ import com.sun.javafx.font.Glyph;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DWGlyph
/*     */   implements Glyph
/*     */ {
/*     */   private DWFontStrike strike;
/*     */   private DWRITE_GLYPH_METRICS metrics;
/*     */   private DWRITE_GLYPH_RUN run;
/*     */   private float pixelXAdvance;
/*     */   private float pixelYAdvance;
/*     */   private RECT rect;
/*     */   private boolean drawShapes;
/*     */   private byte[][] pixelData;
/*     */   private RECT[] rects;
/*     */   private static final boolean CACHE_TARGET = true;
/*     */   private static IWICBitmap cachedBitmap;
/*     */   private static ID2D1RenderTarget cachedTarget;
/*     */   private static final int BITMAP_WIDTH = 256;
/*     */   private static final int BITMAP_HEIGHT = 256;
/*     */   private static final int BITMAP_PIXEL_FORMAT = 8;
/*  51 */   private static D2D1_COLOR_F BLACK = new D2D1_COLOR_F(0.0F, 0.0F, 0.0F, 1.0F);
/*  52 */   private static D2D1_COLOR_F WHITE = new D2D1_COLOR_F(1.0F, 1.0F, 1.0F, 1.0F);
/*  53 */   private static D2D1_MATRIX_3X2_F D2D2_MATRIX_IDENTITY = new D2D1_MATRIX_3X2_F(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
/*     */ 
/*     */   
/*     */   DWGlyph(DWFontStrike paramDWFontStrike, int paramInt, boolean paramBoolean) {
/*  57 */     this.strike = paramDWFontStrike;
/*  58 */     this.drawShapes = paramBoolean;
/*  59 */     byte b = DWFontStrike.SUBPIXEL_Y ? 9 : 3;
/*  60 */     this.pixelData = new byte[b][];
/*  61 */     this.rects = new RECT[b];
/*     */     
/*  63 */     IDWriteFontFace iDWriteFontFace = paramDWFontStrike.getFontFace();
/*  64 */     this.run = new DWRITE_GLYPH_RUN();
/*  65 */     this.run.fontFace = (iDWriteFontFace != null) ? iDWriteFontFace.ptr : 0L;
/*  66 */     this.run.fontEmSize = paramDWFontStrike.getSize();
/*  67 */     this.run.glyphIndices = (short)paramInt;
/*  68 */     this.run.glyphAdvances = 0.0F;
/*  69 */     this.run.advanceOffset = 0.0F;
/*  70 */     this.run.ascenderOffset = 0.0F;
/*  71 */     this.run.bidiLevel = 0;
/*  72 */     this.run.isSideways = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void checkMetrics() {
/*  81 */     if (this.metrics != null)
/*     */       return; 
/*  83 */     IDWriteFontFace iDWriteFontFace = this.strike.getFontFace();
/*  84 */     if (iDWriteFontFace == null)
/*  85 */       return;  this.metrics = iDWriteFontFace.GetDesignGlyphMetrics(this.run.glyphIndices, false);
/*  86 */     if (this.metrics != null) {
/*  87 */       float f = this.strike.getUpem();
/*  88 */       this.pixelXAdvance = this.metrics.advanceWidth * this.strike.getSize() / f;
/*  89 */       this.pixelYAdvance = 0.0F;
/*  90 */       if (this.strike.matrix != null) {
/*  91 */         Point2D point2D = new Point2D(this.pixelXAdvance, this.pixelYAdvance);
/*  92 */         this.strike.getTransform().transform(point2D, point2D);
/*  93 */         this.pixelXAdvance = point2D.x;
/*  94 */         this.pixelYAdvance = point2D.y;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void checkBounds() {
/* 100 */     if (this.rect != null) {
/*     */       return;
/*     */     }
/*     */     
/* 104 */     boolean bool = true;
/* 105 */     IDWriteGlyphRunAnalysis iDWriteGlyphRunAnalysis = createAnalysis(0.0F, 0.0F);
/* 106 */     if (iDWriteGlyphRunAnalysis != null) {
/* 107 */       this.rect = iDWriteGlyphRunAnalysis.GetAlphaTextureBounds(bool);
/* 108 */       if (this.rect == null || this.rect.right - this.rect.left == 0 || this.rect.bottom - this.rect.top == 0)
/*     */       {
/*     */ 
/*     */         
/* 112 */         this.rect = iDWriteGlyphRunAnalysis.GetAlphaTextureBounds(0);
/*     */       }
/* 114 */       iDWriteGlyphRunAnalysis.Release();
/*     */     } 
/* 116 */     if (this.rect == null) {
/* 117 */       this.rect = new RECT();
/*     */     } else {
/*     */       
/* 120 */       this.rect.left--;
/* 121 */       this.rect.top--;
/* 122 */       this.rect.right++;
/* 123 */       this.rect.bottom++;
/*     */     } 
/*     */   }
/*     */   
/*     */   byte[] getLCDMask(float paramFloat1, float paramFloat2) {
/* 128 */     IDWriteGlyphRunAnalysis iDWriteGlyphRunAnalysis = createAnalysis(paramFloat1, paramFloat2);
/* 129 */     byte[] arrayOfByte = null;
/* 130 */     if (iDWriteGlyphRunAnalysis != null) {
/* 131 */       boolean bool = true;
/* 132 */       this.rect = iDWriteGlyphRunAnalysis.GetAlphaTextureBounds(bool);
/* 133 */       if (this.rect != null && this.rect.right - this.rect.left != 0 && this.rect.bottom - this.rect.top != 0) {
/* 134 */         arrayOfByte = iDWriteGlyphRunAnalysis.CreateAlphaTexture(bool, this.rect);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 139 */         this.rect = iDWriteGlyphRunAnalysis.GetAlphaTextureBounds(0);
/* 140 */         if (this.rect != null && this.rect.right - this.rect.left != 0 && this.rect.bottom - this.rect.top != 0) {
/* 141 */           arrayOfByte = getD2DMask(paramFloat1, paramFloat2, true);
/*     */         }
/*     */       } 
/* 144 */       iDWriteGlyphRunAnalysis.Release();
/*     */     } 
/* 146 */     if (arrayOfByte == null) {
/* 147 */       arrayOfByte = new byte[0];
/* 148 */       this.rect = new RECT();
/*     */     } 
/* 150 */     return arrayOfByte; } byte[] getD2DMask(float paramFloat1, float paramFloat2, boolean paramBoolean) {
/*     */     IWICBitmap iWICBitmap;
/*     */     ID2D1RenderTarget iD2D1RenderTarget;
/*     */     D2D1_MATRIX_3X2_F d2D1_MATRIX_3X2_F;
/* 154 */     checkBounds();
/* 155 */     if (getWidth() == 0 || getHeight() == 0 || this.run.fontFace == 0L) {
/* 156 */       return new byte[0];
/*     */     }
/*     */     
/* 159 */     float f1 = this.rect.left;
/* 160 */     float f2 = this.rect.top;
/* 161 */     int i = this.rect.right - this.rect.left;
/* 162 */     int j = this.rect.bottom - this.rect.top;
/* 163 */     boolean bool = (256 >= i && 256 >= j) ? true : false;
/*     */ 
/*     */     
/* 166 */     if (bool) {
/* 167 */       iWICBitmap = getCachedBitmap();
/* 168 */       iD2D1RenderTarget = getCachedRenderingTarget();
/*     */     } else {
/* 170 */       iWICBitmap = createBitmap(i, j);
/* 171 */       iD2D1RenderTarget = createRenderingTarget(iWICBitmap);
/*     */     } 
/* 173 */     if (iWICBitmap == null || iD2D1RenderTarget == null) {
/* 174 */       return new byte[0];
/*     */     }
/*     */     
/* 177 */     DWRITE_MATRIX dWRITE_MATRIX = this.strike.matrix;
/*     */     
/* 179 */     if (dWRITE_MATRIX != null) {
/* 180 */       d2D1_MATRIX_3X2_F = new D2D1_MATRIX_3X2_F(dWRITE_MATRIX.m11, dWRITE_MATRIX.m12, dWRITE_MATRIX.m21, dWRITE_MATRIX.m22, -f1 + paramFloat1, -f2 + paramFloat2);
/*     */ 
/*     */       
/* 183 */       f1 = f2 = 0.0F;
/*     */     } else {
/* 185 */       d2D1_MATRIX_3X2_F = D2D2_MATRIX_IDENTITY;
/* 186 */       f1 -= paramFloat1;
/* 187 */       f2 -= paramFloat2;
/*     */     } 
/*     */     
/* 190 */     iD2D1RenderTarget.BeginDraw();
/* 191 */     iD2D1RenderTarget.SetTransform(d2D1_MATRIX_3X2_F);
/* 192 */     iD2D1RenderTarget.Clear(WHITE);
/* 193 */     D2D1_POINT_2F d2D1_POINT_2F = new D2D1_POINT_2F(-f1, -f2);
/* 194 */     ID2D1Brush iD2D1Brush = iD2D1RenderTarget.CreateSolidColorBrush(BLACK);
/* 195 */     if (!paramBoolean) {
/* 196 */       iD2D1RenderTarget.SetTextAntialiasMode(2);
/*     */     }
/* 198 */     iD2D1RenderTarget.DrawGlyphRun(d2D1_POINT_2F, this.run, iD2D1Brush, 0);
/* 199 */     int k = iD2D1RenderTarget.EndDraw();
/* 200 */     iD2D1Brush.Release();
/*     */     
/* 202 */     if (k != 0) {
/*     */       
/* 204 */       iWICBitmap.Release();
/* 205 */       cachedBitmap = null;
/* 206 */       iD2D1RenderTarget.Release();
/* 207 */       cachedTarget = null;
/* 208 */       if (PrismFontFactory.debugFonts) {
/* 209 */         System.err.println("Rendering failed=" + k);
/*     */       }
/* 211 */       this.rect.left = this.rect.top = this.rect.right = this.rect.bottom = 0;
/* 212 */       return null;
/*     */     } 
/*     */     
/* 215 */     byte[] arrayOfByte = null;
/* 216 */     IWICBitmapLock iWICBitmapLock = iWICBitmap.Lock(0, 0, i, j, 1);
/* 217 */     if (iWICBitmapLock != null) {
/* 218 */       byte[] arrayOfByte1 = iWICBitmapLock.GetDataPointer();
/*     */ 
/*     */       
/* 221 */       if (arrayOfByte1 != null) {
/* 222 */         int m = iWICBitmapLock.GetStride();
/* 223 */         byte b = 0; int n = 0;
/* 224 */         byte b1 = -1;
/* 225 */         if (paramBoolean) {
/* 226 */           arrayOfByte = new byte[i * j * 3];
/* 227 */           for (byte b2 = 0; b2 < j; b2++) {
/* 228 */             int i1 = n;
/* 229 */             for (byte b3 = 0; b3 < i; b3++) {
/* 230 */               arrayOfByte[b++] = (byte)(b1 - arrayOfByte1[i1++]);
/* 231 */               arrayOfByte[b++] = (byte)(b1 - arrayOfByte1[i1++]);
/* 232 */               arrayOfByte[b++] = (byte)(b1 - arrayOfByte1[i1++]);
/* 233 */               i1++;
/*     */             } 
/* 235 */             n += m;
/*     */           } 
/*     */         } else {
/* 238 */           arrayOfByte = new byte[i * j];
/* 239 */           for (byte b2 = 0; b2 < j; b2++) {
/* 240 */             int i1 = n;
/* 241 */             for (byte b3 = 0; b3 < i; b3++) {
/* 242 */               arrayOfByte[b++] = (byte)(b1 - arrayOfByte1[i1]);
/* 243 */               i1 += 4;
/*     */             } 
/* 245 */             n += m;
/*     */           } 
/*     */         } 
/*     */       } 
/* 249 */       iWICBitmapLock.Release();
/*     */     } 
/*     */     
/* 252 */     if (!bool) {
/* 253 */       iWICBitmap.Release();
/* 254 */       iD2D1RenderTarget.Release();
/*     */     } 
/* 256 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */   IDWriteGlyphRunAnalysis createAnalysis(float paramFloat1, float paramFloat2) {
/* 260 */     if (this.run.fontFace == 0L) return null; 
/* 261 */     IDWriteFactory iDWriteFactory = DWFactory.getDWriteFactory();
/*     */ 
/*     */     
/* 264 */     byte b = DWFontStrike.SUBPIXEL_Y ? 5 : 4;
/* 265 */     boolean bool = false;
/* 266 */     DWRITE_MATRIX dWRITE_MATRIX = this.strike.matrix;
/* 267 */     float f = 1.0F;
/* 268 */     return iDWriteFactory.CreateGlyphRunAnalysis(this.run, f, dWRITE_MATRIX, b, bool, paramFloat1, paramFloat2);
/*     */   }
/*     */   
/*     */   IWICBitmap getCachedBitmap() {
/* 272 */     if (cachedBitmap == null) {
/* 273 */       cachedBitmap = createBitmap(256, 256);
/*     */     }
/* 275 */     return cachedBitmap;
/*     */   }
/*     */   
/*     */   ID2D1RenderTarget getCachedRenderingTarget() {
/* 279 */     if (cachedTarget == null) {
/* 280 */       cachedTarget = createRenderingTarget(getCachedBitmap());
/*     */     }
/* 282 */     return cachedTarget;
/*     */   }
/*     */   
/*     */   IWICBitmap createBitmap(int paramInt1, int paramInt2) {
/* 286 */     IWICImagingFactory iWICImagingFactory = DWFactory.getWICFactory();
/* 287 */     return iWICImagingFactory.CreateBitmap(paramInt1, paramInt2, 8, 1);
/*     */   }
/*     */   
/*     */   ID2D1RenderTarget createRenderingTarget(IWICBitmap paramIWICBitmap) {
/* 291 */     D2D1_RENDER_TARGET_PROPERTIES d2D1_RENDER_TARGET_PROPERTIES = new D2D1_RENDER_TARGET_PROPERTIES();
/*     */     
/* 293 */     d2D1_RENDER_TARGET_PROPERTIES.type = 0;
/* 294 */     d2D1_RENDER_TARGET_PROPERTIES.pixelFormat.format = 0;
/* 295 */     d2D1_RENDER_TARGET_PROPERTIES.pixelFormat.alphaMode = 0;
/* 296 */     d2D1_RENDER_TARGET_PROPERTIES.dpiX = 0.0F;
/* 297 */     d2D1_RENDER_TARGET_PROPERTIES.dpiY = 0.0F;
/* 298 */     d2D1_RENDER_TARGET_PROPERTIES.usage = 0;
/* 299 */     d2D1_RENDER_TARGET_PROPERTIES.minLevel = 0;
/* 300 */     ID2D1Factory iD2D1Factory = DWFactory.getD2DFactory();
/* 301 */     return iD2D1Factory.CreateWicBitmapRenderTarget(paramIWICBitmap, d2D1_RENDER_TARGET_PROPERTIES);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGlyphCode() {
/* 306 */     return this.run.glyphIndices;
/*     */   }
/*     */ 
/*     */   
/*     */   public RectBounds getBBox() {
/* 311 */     return this.strike.getBBox(this.run.glyphIndices);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAdvance() {
/* 316 */     checkMetrics();
/* 317 */     if (this.metrics == null) return 0.0F; 
/* 318 */     float f = this.strike.getUpem();
/* 319 */     return this.metrics.advanceWidth * this.strike.getSize() / f;
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape getShape() {
/* 324 */     return this.strike.createGlyphOutline(this.run.glyphIndices);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getPixelData() {
/* 329 */     return getPixelData(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getPixelData(int paramInt) {
/* 334 */     byte[] arrayOfByte = this.pixelData[paramInt];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     if (arrayOfByte == null) {
/* 340 */       float f1 = 0.0F, f2 = 0.0F;
/* 341 */       int i = paramInt;
/* 342 */       if (i >= 6) {
/* 343 */         i -= 6;
/* 344 */         f2 = 0.66F;
/* 345 */       } else if (i >= 3) {
/* 346 */         i -= 3;
/* 347 */         f2 = 0.33F;
/*     */       } 
/* 349 */       if (i == 1) f1 = 0.33F; 
/* 350 */       if (i == 2) f1 = 0.66F; 
/* 351 */       this.pixelData[paramInt] = 
/* 352 */         arrayOfByte = isLCDGlyph() ? getLCDMask(f1, f2) : getD2DMask(f1, f2, false);
/* 353 */       this.rects[paramInt] = this.rect;
/*     */     } else {
/* 355 */       this.rect = this.rects[paramInt];
/*     */     } 
/* 357 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getPixelXAdvance() {
/* 362 */     checkMetrics();
/* 363 */     return this.pixelXAdvance;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getPixelYAdvance() {
/* 368 */     checkMetrics();
/* 369 */     return this.pixelYAdvance;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 374 */     checkBounds();
/* 375 */     return (this.rect.right - this.rect.left) * (isLCDGlyph() ? 3 : 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 380 */     checkBounds();
/* 381 */     return this.rect.bottom - this.rect.top;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOriginX() {
/* 386 */     checkBounds();
/* 387 */     return this.rect.left;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOriginY() {
/* 392 */     checkBounds();
/* 393 */     return this.rect.top;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLCDGlyph() {
/* 398 */     return (this.strike.getAAMode() == 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\DWGlyph.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */