/*     */ package com.sun.javafx.font.directwrite;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IDWriteFactory
/*     */   extends IUnknown
/*     */ {
/*     */   IDWriteFactory(long paramLong) {
/*  30 */     super(paramLong);
/*     */   }
/*     */   
/*     */   IDWriteFontCollection GetSystemFontCollection(boolean paramBoolean) {
/*  34 */     long l = OS.GetSystemFontCollection(this.ptr, paramBoolean);
/*  35 */     return (l != 0L) ? new IDWriteFontCollection(l) : null;
/*     */   }
/*     */   
/*     */   IDWriteTextAnalyzer CreateTextAnalyzer() {
/*  39 */     long l = OS.CreateTextAnalyzer(this.ptr);
/*  40 */     return (l != 0L) ? new IDWriteTextAnalyzer(l) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IDWriteTextFormat CreateTextFormat(String paramString1, IDWriteFontCollection paramIDWriteFontCollection, int paramInt1, int paramInt2, int paramInt3, float paramFloat, String paramString2) {
/*  50 */     long l = OS.CreateTextFormat(this.ptr, (paramString1 + "\000")
/*  51 */         .toCharArray(), paramIDWriteFontCollection.ptr, paramInt1, paramInt2, paramInt3, paramFloat, (paramString2 + "\000")
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  57 */         .toCharArray());
/*  58 */     return (l != 0L) ? new IDWriteTextFormat(l) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IDWriteTextLayout CreateTextLayout(char[] paramArrayOfchar, int paramInt1, int paramInt2, IDWriteTextFormat paramIDWriteTextFormat, float paramFloat1, float paramFloat2) {
/*  67 */     long l = OS.CreateTextLayout(this.ptr, paramArrayOfchar, paramInt1, paramInt2, paramIDWriteTextFormat.ptr, paramFloat1, paramFloat2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     return (l != 0L) ? new IDWriteTextLayout(l) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IDWriteGlyphRunAnalysis CreateGlyphRunAnalysis(DWRITE_GLYPH_RUN paramDWRITE_GLYPH_RUN, float paramFloat1, DWRITE_MATRIX paramDWRITE_MATRIX, int paramInt1, int paramInt2, float paramFloat2, float paramFloat3) {
/*  84 */     long l = OS.CreateGlyphRunAnalysis(this.ptr, paramDWRITE_GLYPH_RUN, paramFloat1, paramDWRITE_MATRIX, paramInt1, paramInt2, paramFloat2, paramFloat3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     return (l != 0L) ? new IDWriteGlyphRunAnalysis(l) : null;
/*     */   }
/*     */   
/*     */   IDWriteFontFile CreateFontFileReference(String paramString) {
/*  96 */     long l = OS.CreateFontFileReference(this.ptr, (paramString + "\000").toCharArray());
/*  97 */     return (l != 0L) ? new IDWriteFontFile(l) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IDWriteFontFace CreateFontFace(int paramInt1, IDWriteFontFile paramIDWriteFontFile, int paramInt2, int paramInt3) {
/* 105 */     long l = OS.CreateFontFace(this.ptr, paramInt1, paramIDWriteFontFile.ptr, paramInt2, paramInt3);
/* 106 */     return (l != 0L) ? new IDWriteFontFace(l) : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IDWriteFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */