/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteFontList
/*    */   extends IUnknown
/*    */ {
/*    */   IDWriteFontList(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   int GetFontCount() {
/* 34 */     return OS.GetFontCount(this.ptr);
/*    */   }
/*    */   
/*    */   IDWriteFont GetFont(int paramInt) {
/* 38 */     long l = OS.GetFont(this.ptr, paramInt);
/* 39 */     return (l != 0L) ? new IDWriteFont(l) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IDWriteFontList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */