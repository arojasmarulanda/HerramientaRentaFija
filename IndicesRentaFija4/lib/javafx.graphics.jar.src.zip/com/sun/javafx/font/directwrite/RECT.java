package com.sun.javafx.font.directwrite;

public class RECT {
  public int left;
  
  public int top;
  
  public int right;
  
  public int bottom;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\RECT.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */