/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteFontFamily
/*    */   extends IDWriteFontList
/*    */ {
/*    */   IDWriteFontFamily(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   IDWriteLocalizedStrings GetFamilyNames() {
/* 34 */     long l = OS.GetFamilyNames(this.ptr);
/* 35 */     return (l != 0L) ? new IDWriteLocalizedStrings(l) : null;
/*    */   }
/*    */   
/*    */   IDWriteFont GetFirstMatchingFont(int paramInt1, int paramInt2, int paramInt3) {
/* 39 */     long l = OS.GetFirstMatchingFont(this.ptr, paramInt1, paramInt2, paramInt3);
/* 40 */     return (l != 0L) ? new IDWriteFont(l) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IDWriteFontFamily.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */