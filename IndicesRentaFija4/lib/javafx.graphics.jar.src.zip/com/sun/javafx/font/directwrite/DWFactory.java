/*     */ package com.sun.javafx.font.directwrite;
/*     */ 
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.font.PrismFontFile;
/*     */ import com.sun.javafx.text.GlyphLayout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DWFactory
/*     */   extends PrismFontFactory
/*     */ {
/*  35 */   private static IDWriteFactory DWRITE_FACTORY = null;
/*  36 */   private static IDWriteFontCollection FONT_COLLECTION = null;
/*  37 */   private static IWICImagingFactory WIC_FACTORY = null;
/*  38 */   private static ID2D1Factory D2D_FACTORY = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Thread d2dThread;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrismFontFactory getFactory() {
/*  49 */     if (getDWriteFactory() == null)
/*     */     {
/*     */       
/*  52 */       return null;
/*     */     }
/*  54 */     return new DWFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PrismFontFile createFontFile(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws Exception {
/*  65 */     return new DWFontFile(paramString1, paramString2, paramInt, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
/*     */   }
/*     */ 
/*     */   
/*     */   public GlyphLayout createGlyphLayout() {
/*  70 */     return new DWGlyphLayout();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean registerEmbeddedFont(String paramString) {
/*  75 */     IDWriteFactory iDWriteFactory = getDWriteFactory();
/*  76 */     IDWriteFontFile iDWriteFontFile = iDWriteFactory.CreateFontFileReference(paramString);
/*  77 */     if (iDWriteFontFile == null) return false; 
/*  78 */     boolean[] arrayOfBoolean = new boolean[1];
/*  79 */     int[] arrayOfInt1 = new int[1];
/*  80 */     int[] arrayOfInt2 = new int[1];
/*  81 */     int[] arrayOfInt3 = new int[1];
/*  82 */     int i = iDWriteFontFile.Analyze(arrayOfBoolean, arrayOfInt1, arrayOfInt2, arrayOfInt3);
/*  83 */     iDWriteFontFile.Release();
/*  84 */     if (i != 0) return false; 
/*  85 */     return arrayOfBoolean[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static IDWriteFactory getDWriteFactory() {
/*  91 */     if (DWRITE_FACTORY == null) {
/*  92 */       DWRITE_FACTORY = OS.DWriteCreateFactory(0);
/*     */     }
/*  94 */     return DWRITE_FACTORY;
/*     */   }
/*     */   
/*     */   static IDWriteFontCollection getFontCollection() {
/*  98 */     if (FONT_COLLECTION == null) {
/*  99 */       FONT_COLLECTION = getDWriteFactory().GetSystemFontCollection(false);
/*     */     }
/* 101 */     return FONT_COLLECTION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkThread() {
/* 108 */     Thread thread = Thread.currentThread();
/* 109 */     if (d2dThread == null) {
/* 110 */       d2dThread = thread;
/*     */     }
/* 112 */     if (d2dThread != thread) {
/* 113 */       throw new IllegalStateException("This operation is not permitted on the current thread [" + thread
/*     */           
/* 115 */           .getName() + "]");
/*     */     }
/*     */   }
/*     */   
/*     */   static synchronized IWICImagingFactory getWICFactory() {
/* 120 */     checkThread();
/*     */     
/* 122 */     if (WIC_FACTORY == null) {
/* 123 */       WIC_FACTORY = OS.WICCreateImagingFactory();
/*     */     }
/* 125 */     return WIC_FACTORY;
/*     */   }
/*     */   
/*     */   static synchronized ID2D1Factory getD2DFactory() {
/* 129 */     checkThread();
/*     */     
/* 131 */     if (D2D_FACTORY == null) {
/* 132 */       D2D_FACTORY = OS.D2D1CreateFactory(0);
/*     */     }
/* 134 */     return D2D_FACTORY;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\DWFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */