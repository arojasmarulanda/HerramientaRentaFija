package com.sun.javafx.font.directwrite;

class D2D1_PIXEL_FORMAT {
  int format;
  
  int alphaMode;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\D2D1_PIXEL_FORMAT.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */