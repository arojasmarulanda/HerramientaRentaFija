/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class D2D1_RENDER_TARGET_PROPERTIES
/*    */ {
/*    */   int type;
/* 30 */   D2D1_PIXEL_FORMAT pixelFormat = new D2D1_PIXEL_FORMAT();
/*    */   float dpiX;
/*    */   float dpiY;
/*    */   int usage;
/*    */   int minLevel;
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\D2D1_RENDER_TARGET_PROPERTIES.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */