/*    */ package com.sun.javafx.font;
/*    */ 
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrismFontUtils
/*    */ {
/*    */   static Metrics getFontMetrics(PGFont paramPGFont) {
/* 36 */     FontStrike fontStrike = paramPGFont.getStrike(BaseTransform.IDENTITY_TRANSFORM, 0);
/*    */     
/* 38 */     return fontStrike.getMetrics();
/*    */   }
/*    */   
/*    */   static double getCharWidth(PGFont paramPGFont, char paramChar) {
/* 42 */     FontStrike fontStrike = paramPGFont.getStrike(BaseTransform.IDENTITY_TRANSFORM, 0);
/*    */     
/* 44 */     double d = fontStrike.getCharAdvance(paramChar);
/* 45 */     if (d == 0.0D) {
/* 46 */       d = paramPGFont.getSize() / 2.0D;
/*    */     }
/* 48 */     return d;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\PrismFontUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */