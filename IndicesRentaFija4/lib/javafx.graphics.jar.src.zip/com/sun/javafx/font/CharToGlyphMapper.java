/*    */ package com.sun.javafx.font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CharToGlyphMapper
/*    */ {
/*    */   public static final int HI_SURROGATE_SHIFT = 10;
/*    */   public static final int HI_SURROGATE_START = 55296;
/*    */   public static final int HI_SURROGATE_END = 56319;
/*    */   public static final int LO_SURROGATE_START = 56320;
/*    */   public static final int LO_SURROGATE_END = 57343;
/*    */   public static final int SURROGATES_START = 65536;
/*    */   public static final int MISSING_GLYPH = 0;
/*    */   public static final int INVISIBLE_GLYPH_ID = 65535;
/* 45 */   protected int missingGlyph = 0;
/*    */   
/*    */   public boolean canDisplay(char paramChar) {
/* 48 */     int i = charToGlyph(paramChar);
/* 49 */     return (i != this.missingGlyph);
/*    */   }
/*    */   
/*    */   public int getMissingGlyphCode() {
/* 53 */     return this.missingGlyph;
/*    */   }
/*    */   
/*    */   public abstract int getGlyphCode(int paramInt);
/*    */   
/*    */   public int charToGlyph(char paramChar) {
/* 59 */     return getGlyphCode(paramChar);
/*    */   }
/*    */   
/*    */   public int charToGlyph(int paramInt) {
/* 63 */     return getGlyphCode(paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public void charsToGlyphs(int paramInt1, int paramInt2, char[] paramArrayOfchar, int[] paramArrayOfint, int paramInt3) {
/* 68 */     for (byte b = 0; b < paramInt2; b++) {
/* 69 */       int i = paramArrayOfchar[paramInt1 + b];
/* 70 */       if (i >= 55296 && i <= 56319 && b + 1 < paramInt2) {
/*    */         
/* 72 */         char c = paramArrayOfchar[paramInt1 + b + 1];
/*    */         
/* 74 */         if (c >= '?' && c <= '?') {
/*    */           
/* 76 */           i = (i - 55296 << 10) + c - 56320 + 65536;
/*    */           
/* 78 */           paramArrayOfint[paramInt3 + b] = getGlyphCode(i);
/* 79 */           b++;
/* 80 */           paramArrayOfint[paramInt3 + b] = 65535;
/*    */           continue;
/*    */         } 
/*    */       } 
/* 84 */       paramArrayOfint[paramInt3 + b] = getGlyphCode(i);
/*    */       continue;
/*    */     } 
/*    */   }
/*    */   public void charsToGlyphs(int paramInt1, int paramInt2, char[] paramArrayOfchar, int[] paramArrayOfint) {
/* 89 */     charsToGlyphs(paramInt1, paramInt2, paramArrayOfchar, paramArrayOfint, 0);
/*    */   }
/*    */   
/*    */   public void charsToGlyphs(int paramInt, char[] paramArrayOfchar, int[] paramArrayOfint) {
/* 93 */     charsToGlyphs(0, paramInt, paramArrayOfchar, paramArrayOfint, 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\CharToGlyphMapper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */