package com.sun.javafx.font;

public interface DisposerRecord {
  void dispose();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\DisposerRecord.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */