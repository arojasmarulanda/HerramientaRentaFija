package com.sun.javafx.font;

import com.sun.javafx.geom.transform.BaseTransform;

public interface PGFont {
  String getFullName();
  
  String getFamilyName();
  
  String getStyleName();
  
  String getName();
  
  float getSize();
  
  FontResource getFontResource();
  
  FontStrike getStrike(BaseTransform paramBaseTransform);
  
  FontStrike getStrike(BaseTransform paramBaseTransform, int paramInt);
  
  int getFeatures();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\PGFont.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */