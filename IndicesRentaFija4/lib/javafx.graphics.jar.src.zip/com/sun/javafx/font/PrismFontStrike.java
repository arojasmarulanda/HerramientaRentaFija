/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.transform.Affine2D;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.scene.text.GlyphList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PrismFontStrike<T extends PrismFontFile>
/*     */   implements FontStrike
/*     */ {
/*     */   private DisposerRecord disposer;
/*     */   private T fontResource;
/*  41 */   private Map<Integer, Glyph> glyphMap = new HashMap<>();
/*     */   
/*     */   private PrismMetrics metrics;
/*     */   
/*     */   protected boolean drawShapes = false;
/*     */   private float size;
/*     */   private BaseTransform transform;
/*     */   private int aaMode;
/*     */   private FontStrikeDesc desc;
/*     */   private int hash;
/*     */   
/*     */   protected PrismFontStrike(T paramT, float paramFloat, BaseTransform paramBaseTransform, int paramInt, FontStrikeDesc paramFontStrikeDesc) {
/*  53 */     this.fontResource = paramT;
/*  54 */     this.size = paramFloat;
/*  55 */     this.desc = paramFontStrikeDesc;
/*  56 */     PrismFontFactory prismFontFactory = PrismFontFactory.getFontFactory();
/*  57 */     boolean bool = prismFontFactory.isLCDTextSupported();
/*  58 */     this.aaMode = bool ? paramInt : 0;
/*  59 */     if (paramBaseTransform.isTranslateOrIdentity()) {
/*  60 */       this.transform = BaseTransform.IDENTITY_TRANSFORM;
/*     */     } else {
/*  62 */       this
/*  63 */         .transform = new Affine2D(paramBaseTransform.getMxx(), paramBaseTransform.getMyx(), paramBaseTransform.getMxy(), paramBaseTransform.getMyy(), 0.0D, 0.0D);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   DisposerRecord getDisposer() {
/*  69 */     if (this.disposer == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  77 */       this.disposer = createDisposer(this.desc);
/*     */     }
/*  79 */     return this.disposer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clearDesc() {
/*  85 */     this.fontResource.getStrikeMap().remove(this.desc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getSize() {
/* 100 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Metrics getMetrics() {
/* 113 */     if (this.metrics == null) {
/* 114 */       this.metrics = this.fontResource.getFontMetrics(this.size);
/*     */     }
/* 116 */     return this.metrics;
/*     */   }
/*     */   
/*     */   public T getFontResource() {
/* 120 */     return this.fontResource;
/*     */   }
/*     */   
/*     */   public boolean drawAsShapes() {
/* 124 */     return this.drawShapes;
/*     */   }
/*     */   
/*     */   public int getAAMode() {
/* 128 */     return this.aaMode;
/*     */   }
/*     */   
/*     */   public BaseTransform getTransform() {
/* 132 */     return this.transform;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getQuantizedPosition(Point2D paramPoint2D) {
/* 137 */     if (this.aaMode == 0) {
/*     */       
/* 139 */       paramPoint2D.x = Math.round(paramPoint2D.x);
/*     */     } else {
/*     */       
/* 142 */       paramPoint2D.x = (float)Math.round(3.0D * paramPoint2D.x) / 3.0F;
/*     */     } 
/* 144 */     paramPoint2D.y = Math.round(paramPoint2D.y);
/* 145 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getCharAdvance(char paramChar) {
/* 156 */     int i = this.fontResource.getGlyphMapper().charToGlyph(paramChar);
/* 157 */     return this.fontResource.getAdvance(i, this.size);
/*     */   }
/*     */ 
/*     */   
/*     */   public Glyph getGlyph(char paramChar) {
/* 162 */     int i = this.fontResource.getGlyphMapper().charToGlyph(paramChar);
/* 163 */     return getGlyph(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Glyph getGlyph(int paramInt) {
/* 169 */     Glyph glyph = this.glyphMap.get(Integer.valueOf(paramInt));
/* 170 */     if (glyph == null) {
/* 171 */       glyph = createGlyph(paramInt);
/* 172 */       this.glyphMap.put(Integer.valueOf(paramInt), glyph);
/*     */     } 
/* 174 */     return glyph;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Shape getOutline(GlyphList paramGlyphList, BaseTransform paramBaseTransform) {
/* 180 */     Path2D path2D = new Path2D();
/* 181 */     getOutline(paramGlyphList, paramBaseTransform, path2D);
/* 182 */     return path2D;
/*     */   }
/*     */   
/*     */   void getOutline(GlyphList paramGlyphList, BaseTransform paramBaseTransform, Path2D paramPath2D) {
/* 186 */     paramPath2D.reset();
/* 187 */     if (paramGlyphList == null) {
/*     */       return;
/*     */     }
/* 190 */     if (paramBaseTransform == null) {
/* 191 */       paramBaseTransform = BaseTransform.IDENTITY_TRANSFORM;
/*     */     }
/* 193 */     Affine2D affine2D = new Affine2D();
/* 194 */     for (byte b = 0; b < paramGlyphList.getGlyphCount(); b++) {
/* 195 */       int i = paramGlyphList.getGlyphCode(b);
/* 196 */       if (i != 65535) {
/* 197 */         Path2D path2D = createGlyphOutline(i);
/* 198 */         if (path2D != null) {
/* 199 */           affine2D.setTransform(paramBaseTransform);
/* 200 */           affine2D.translate(paramGlyphList.getPosX(b), paramGlyphList.getPosY(b));
/* 201 */           paramPath2D.append(path2D.getPathIterator(affine2D), false);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 209 */     if (paramObject == null) {
/* 210 */       return false;
/*     */     }
/* 212 */     if (!(paramObject instanceof PrismFontStrike)) {
/* 213 */       return false;
/*     */     }
/* 215 */     PrismFontStrike prismFontStrike = (PrismFontStrike)paramObject;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     return (this.size == prismFontStrike.size && this.transform
/* 221 */       .getMxx() == prismFontStrike.transform.getMxx() && this.transform
/* 222 */       .getMxy() == prismFontStrike.transform.getMxy() && this.transform
/* 223 */       .getMyx() == prismFontStrike.transform.getMyx() && this.transform
/* 224 */       .getMyy() == prismFontStrike.transform.getMyy() && this.fontResource
/* 225 */       .equals(prismFontStrike.fontResource));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 231 */     if (this.hash != 0) {
/* 232 */       return this.hash;
/*     */     }
/* 234 */     this
/*     */ 
/*     */ 
/*     */       
/* 238 */       .hash = Float.floatToIntBits(this.size) + Float.floatToIntBits((float)this.transform.getMxx()) + Float.floatToIntBits((float)this.transform.getMyx()) + Float.floatToIntBits((float)this.transform.getMxy()) + Float.floatToIntBits((float)this.transform.getMyy());
/* 239 */     this.hash = 71 * this.hash + this.fontResource.hashCode();
/* 240 */     return this.hash;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 244 */     return "FontStrike: " + super.toString() + " font resource = " + this.fontResource + " size = " + this.size + " matrix = " + this.transform;
/*     */   }
/*     */   
/*     */   protected abstract DisposerRecord createDisposer(FontStrikeDesc paramFontStrikeDesc);
/*     */   
/*     */   protected abstract Glyph createGlyph(int paramInt);
/*     */   
/*     */   protected abstract Path2D createGlyphOutline(int paramInt);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\PrismFontStrike.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */