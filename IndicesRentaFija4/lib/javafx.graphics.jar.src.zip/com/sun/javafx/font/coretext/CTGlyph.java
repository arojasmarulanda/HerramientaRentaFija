/*     */ package com.sun.javafx.font.coretext;
/*     */ 
/*     */ import com.sun.javafx.font.Glyph;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CTGlyph
/*     */   implements Glyph
/*     */ {
/*     */   private CTFontStrike strike;
/*     */   private int glyphCode;
/*     */   private CGRect bounds;
/*     */   private double xAdvance;
/*     */   private double yAdvance;
/*     */   private boolean drawShapes;
/*     */   private static boolean LCD_CONTEXT = true;
/*     */   private static boolean CACHE_CONTEXT = true;
/*     */   private static long cachedContextRef;
/*     */   private static final int BITMAP_WIDTH = 256;
/*     */   private static final int BITMAP_HEIGHT = 256;
/*     */   private static final int MAX_SIZE = 320;
/*  49 */   private static final long GRAY_COLORSPACE = OS.CGColorSpaceCreateDeviceGray();
/*  50 */   private static final long RGB_COLORSPACE = OS.CGColorSpaceCreateDeviceRGB();
/*     */   
/*     */   CTGlyph(CTFontStrike paramCTFontStrike, int paramInt, boolean paramBoolean) {
/*  53 */     this.strike = paramCTFontStrike;
/*  54 */     this.glyphCode = paramInt;
/*  55 */     this.drawShapes = paramBoolean;
/*     */   }
/*     */   
/*     */   public int getGlyphCode() {
/*  59 */     return this.glyphCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds getBBox() {
/*  67 */     CGRect cGRect = this.strike.getBBox(this.glyphCode);
/*  68 */     if (cGRect == null) return new RectBounds(); 
/*  69 */     return new RectBounds((float)cGRect.origin.x, (float)cGRect.origin.y, (float)(cGRect.origin.x + cGRect.size.width), (float)(cGRect.origin.y + cGRect.size.height));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkBounds() {
/*  76 */     if (this.bounds != null)
/*  77 */       return;  this.bounds = new CGRect();
/*  78 */     if (this.strike.getSize() == 0.0F)
/*     */       return; 
/*  80 */     long l = this.strike.getFontRef();
/*  81 */     if (l == 0L)
/*  82 */       return;  boolean bool = false;
/*  83 */     CGSize cGSize = new CGSize();
/*  84 */     OS.CTFontGetAdvancesForGlyphs(l, bool, (short)this.glyphCode, cGSize);
/*  85 */     this.xAdvance = cGSize.width;
/*  86 */     this.yAdvance = -cGSize.height;
/*     */     
/*  88 */     if (this.drawShapes) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  93 */     CTFontFile cTFontFile = this.strike.getFontResource();
/*  94 */     float[] arrayOfFloat = new float[4];
/*  95 */     cTFontFile.getGlyphBoundingBox((short)this.glyphCode, this.strike.getSize(), arrayOfFloat);
/*  96 */     this.bounds.origin.x = arrayOfFloat[0];
/*  97 */     this.bounds.origin.y = arrayOfFloat[1];
/*  98 */     this.bounds.size.width = (arrayOfFloat[2] - arrayOfFloat[0]);
/*  99 */     this.bounds.size.height = (arrayOfFloat[3] - arrayOfFloat[1]);
/* 100 */     if (this.strike.matrix != null)
/*     */     {
/* 102 */       OS.CGRectApplyAffineTransform(this.bounds, this.strike.matrix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     this.bounds.origin.x = this.bounds.origin.y = this.bounds.size.width = this.bounds.size.height = 0.0D;
/*     */ 
/*     */ 
/*     */     
/* 115 */     this.bounds.origin.x = ((int)Math.floor(this.bounds.origin.x) - 1);
/* 116 */     this.bounds.origin.y = ((int)Math.floor(this.bounds.origin.y) - 1);
/* 117 */     this.bounds.size.width = ((int)Math.ceil(this.bounds.size.width) + 1 + 1 + 1);
/* 118 */     this.bounds.size.height = ((int)Math.ceil(this.bounds.size.height) + 1 + 1 + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape getShape() {
/* 123 */     return this.strike.createGlyphOutline(this.glyphCode);
/*     */   } private long createContext(boolean paramBoolean, int paramInt1, int paramInt2) {
/*     */     long l1;
/*     */     int i;
/*     */     boolean bool;
/* 128 */     byte b = 8;
/* 129 */     if (paramBoolean) {
/* 130 */       l1 = RGB_COLORSPACE;
/* 131 */       i = paramInt1 * 4;
/* 132 */       bool = OS.kCGBitmapByteOrder32Host | 0x2;
/*     */     } else {
/* 134 */       l1 = GRAY_COLORSPACE;
/* 135 */       i = paramInt1;
/* 136 */       bool = false;
/*     */     } 
/* 138 */     long l2 = OS.CGBitmapContextCreate(0L, paramInt1, paramInt2, b, i, l1, bool);
/*     */     
/* 140 */     boolean bool1 = this.strike.isSubPixelGlyph();
/* 141 */     OS.CGContextSetAllowsFontSmoothing(l2, paramBoolean);
/* 142 */     OS.CGContextSetAllowsAntialiasing(l2, true);
/* 143 */     OS.CGContextSetAllowsFontSubpixelPositioning(l2, bool1);
/* 144 */     OS.CGContextSetAllowsFontSubpixelQuantization(l2, bool1);
/* 145 */     return l2;
/*     */   }
/*     */ 
/*     */   
/*     */   private long getCachedContext(boolean paramBoolean) {
/* 150 */     if (cachedContextRef == 0L) {
/* 151 */       cachedContextRef = createContext(paramBoolean, 256, 256);
/*     */     }
/* 153 */     return cachedContextRef;
/*     */   }
/*     */   
/*     */   private synchronized byte[] getImage(double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, int paramInt3) {
/*     */     byte[] arrayOfByte;
/* 158 */     if (paramInt1 == 0 || paramInt2 == 0) return new byte[0];
/*     */     
/* 160 */     long l1 = this.strike.getFontRef();
/* 161 */     boolean bool = isLCDGlyph();
/* 162 */     boolean bool1 = (LCD_CONTEXT || bool) ? true : false;
/* 163 */     CGAffineTransform cGAffineTransform = this.strike.matrix;
/* 164 */     int i = CACHE_CONTEXT & ((256 >= paramInt1) ? 1 : 0) & ((256 >= paramInt2) ? 1 : 0);
/*     */     
/* 166 */     long l2 = (i != 0) ? getCachedContext(bool1) : createContext(bool1, paramInt1, paramInt2);
/* 167 */     if (l2 == 0L) return new byte[0];
/*     */ 
/*     */     
/* 170 */     OS.CGContextSetRGBFillColor(l2, 1.0D, 1.0D, 1.0D, 1.0D);
/* 171 */     CGRect cGRect = new CGRect();
/* 172 */     cGRect.size.width = paramInt1;
/* 173 */     cGRect.size.height = paramInt2;
/* 174 */     OS.CGContextFillRect(l2, cGRect);
/*     */     
/* 176 */     double d1 = 0.0D, d2 = 0.0D;
/* 177 */     if (cGAffineTransform != null) {
/* 178 */       OS.CGContextTranslateCTM(l2, -paramDouble1, -paramDouble2);
/*     */     } else {
/* 180 */       d1 = paramDouble1 - this.strike.getSubPixelPosition(paramInt3);
/* 181 */       d2 = paramDouble2;
/*     */     } 
/*     */ 
/*     */     
/* 185 */     OS.CGContextSetRGBFillColor(l2, 0.0D, 0.0D, 0.0D, 1.0D);
/* 186 */     OS.CTFontDrawGlyphs(l1, (short)this.glyphCode, -d1, -d2, l2);
/*     */     
/* 188 */     if (cGAffineTransform != null) {
/* 189 */       OS.CGContextTranslateCTM(l2, paramDouble1, paramDouble2);
/*     */     }
/*     */ 
/*     */     
/* 193 */     if (bool) {
/* 194 */       arrayOfByte = OS.CGBitmapContextGetData(l2, paramInt1, paramInt2, 24);
/*     */     } else {
/* 196 */       arrayOfByte = OS.CGBitmapContextGetData(l2, paramInt1, paramInt2, 8);
/*     */     } 
/* 198 */     if (arrayOfByte == null) {
/* 199 */       this.bounds = new CGRect();
/* 200 */       arrayOfByte = new byte[0];
/*     */     } 
/*     */     
/* 203 */     if (i == 0) {
/* 204 */       OS.CGContextRelease(l2);
/*     */     }
/* 206 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */   public byte[] getPixelData() {
/* 210 */     return getPixelData(0);
/*     */   }
/*     */   
/*     */   public byte[] getPixelData(int paramInt) {
/* 214 */     checkBounds();
/* 215 */     return getImage(this.bounds.origin.x, this.bounds.origin.y, (int)this.bounds.size.width, (int)this.bounds.size.height, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAdvance() {
/* 220 */     checkBounds();
/*     */     
/* 222 */     return (float)this.xAdvance;
/*     */   }
/*     */   
/*     */   public float getPixelXAdvance() {
/* 226 */     checkBounds();
/* 227 */     return (float)this.xAdvance;
/*     */   }
/*     */   
/*     */   public float getPixelYAdvance() {
/* 231 */     checkBounds();
/* 232 */     return (float)this.yAdvance;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 236 */     checkBounds();
/* 237 */     int i = (int)this.bounds.size.width;
/* 238 */     return isLCDGlyph() ? (i * 3) : i;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 242 */     checkBounds();
/* 243 */     return (int)this.bounds.size.height;
/*     */   }
/*     */   
/*     */   public int getOriginX() {
/* 247 */     checkBounds();
/* 248 */     return (int)this.bounds.origin.x;
/*     */   }
/*     */   
/*     */   public int getOriginY() {
/* 252 */     checkBounds();
/* 253 */     int i = (int)this.bounds.size.height;
/* 254 */     int j = (int)this.bounds.origin.y;
/* 255 */     return -i - j;
/*     */   }
/*     */   
/*     */   public boolean isLCDGlyph() {
/* 259 */     return (this.strike.getAAMode() == 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\coretext\CTGlyph.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */