/*    */ package com.sun.javafx.font.coretext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CGRect
/*    */ {
/* 29 */   CGPoint origin = new CGPoint();
/* 30 */   CGSize size = new CGSize();
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\coretext\CGRect.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */