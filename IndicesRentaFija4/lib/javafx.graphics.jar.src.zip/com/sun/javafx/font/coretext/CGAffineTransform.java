package com.sun.javafx.font.coretext;

class CGAffineTransform {
  double a;
  
  double b;
  
  double c;
  
  double d;
  
  double tx;
  
  double ty;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\coretext\CGAffineTransform.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */