/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FontConfigManager
/*     */ {
/*     */   static boolean debugFonts = false;
/*     */   static boolean useFontConfig = true;
/*     */   static boolean fontConfigFailed = false;
/*     */   static boolean useEmbeddedFontSupport = false;
/*     */   
/*     */   static {
/*  47 */     AccessController.doPrivileged(() -> {
/*     */           String str1 = System.getProperty("prism.debugfonts", "");
/*     */           debugFonts = "true".equals(str1);
/*     */           String str2 = System.getProperty("prism.useFontConfig", "true");
/*     */           useFontConfig = "true".equals(str2);
/*     */           String str3 = System.getProperty("prism.embeddedfonts", "");
/*     */           useEmbeddedFontSupport = "true".equals(str3);
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FontConfigFont
/*     */   {
/*     */     public String familyName;
/*     */ 
/*     */     
/*     */     public String styleStr;
/*     */ 
/*     */     
/*     */     public String fullName;
/*     */ 
/*     */     
/*     */     public String fontFile;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class FcCompFont
/*     */   {
/*     */     public String fcName;
/*     */     
/*     */     public String fcFamily;
/*     */     
/*     */     public int style;
/*     */     
/*     */     public FontConfigManager.FontConfigFont firstFont;
/*     */     
/*     */     public FontConfigManager.FontConfigFont[] allFonts;
/*     */   }
/*     */   
/*  88 */   private static final String[] fontConfigNames = new String[] { "sans:regular:roman", "sans:bold:roman", "sans:regular:italic", "sans:bold:italic", "serif:regular:roman", "serif:bold:roman", "serif:regular:italic", "serif:bold:italic", "monospace:regular:roman", "monospace:bold:roman", "monospace:regular:italic", "monospace:bold:italic" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FcCompFont[] fontConfigFonts;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String defaultFontFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] getFontConfigNames() {
/* 114 */     return fontConfigNames;
/*     */   }
/*     */   
/*     */   private static String getFCLocaleStr() {
/* 118 */     Locale locale = Locale.getDefault();
/* 119 */     String str1 = locale.getLanguage();
/* 120 */     String str2 = locale.getCountry();
/* 121 */     if (!str2.equals("")) {
/* 122 */       str1 = str1 + "-" + str1;
/*     */     }
/* 124 */     return str1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized void initFontConfigLogFonts() {
/*     */     boolean bool;
/* 136 */     if (fontConfigFonts != null || fontConfigFailed) {
/*     */       return;
/*     */     }
/*     */     
/* 140 */     long l = 0L;
/* 141 */     if (debugFonts) {
/* 142 */       l = System.nanoTime();
/*     */     }
/*     */     
/* 145 */     String[] arrayOfString = getFontConfigNames();
/* 146 */     FcCompFont[] arrayOfFcCompFont = new FcCompFont[arrayOfString.length];
/*     */     byte b1;
/* 148 */     for (b1 = 0; b1 < arrayOfFcCompFont.length; b1++) {
/* 149 */       arrayOfFcCompFont[b1] = new FcCompFont();
/* 150 */       (arrayOfFcCompFont[b1]).fcName = arrayOfString[b1];
/* 151 */       int i = (arrayOfFcCompFont[b1]).fcName.indexOf(':');
/* 152 */       (arrayOfFcCompFont[b1]).fcFamily = (arrayOfFcCompFont[b1]).fcName.substring(0, i);
/* 153 */       (arrayOfFcCompFont[b1]).style = b1 % 4;
/*     */     } 
/*     */     
/* 156 */     b1 = 0;
/* 157 */     if (useFontConfig) {
/* 158 */       bool = getFontConfig(getFCLocaleStr(), arrayOfFcCompFont, true);
/*     */     }
/* 160 */     else if (debugFonts) {
/* 161 */       System.err.println("Not using FontConfig");
/*     */     } 
/*     */ 
/*     */     
/* 165 */     if (useEmbeddedFontSupport || !bool)
/*     */     {
/*     */       
/* 168 */       EmbeddedFontSupport.initLogicalFonts(arrayOfFcCompFont);
/*     */     }
/* 170 */     FontConfigFont fontConfigFont = null;
/*     */     byte b2;
/* 172 */     for (b2 = 0; b2 < arrayOfFcCompFont.length; b2++) {
/* 173 */       FcCompFont fcCompFont = arrayOfFcCompFont[b2];
/* 174 */       if (fcCompFont.firstFont == null) {
/* 175 */         if (debugFonts) {
/* 176 */           System.err.println("Fontconfig returned no font for " + (arrayOfFcCompFont[b2]).fcName);
/*     */         }
/*     */         
/* 179 */         fontConfigFailed = true;
/* 180 */       } else if (fontConfigFont == null) {
/* 181 */         fontConfigFont = fcCompFont.firstFont;
/* 182 */         defaultFontFile = fontConfigFont.fontFile;
/*     */       } 
/*     */     } 
/*     */     
/* 186 */     if (fontConfigFont == null) {
/* 187 */       fontConfigFailed = true;
/* 188 */       System.err.println("Error: JavaFX detected no fonts! Please refer to release notes for proper font configuration");
/*     */       return;
/*     */     } 
/* 191 */     if (fontConfigFailed) {
/* 192 */       for (b2 = 0; b2 < arrayOfFcCompFont.length; b2++) {
/* 193 */         if ((arrayOfFcCompFont[b2]).firstFont == null) {
/* 194 */           (arrayOfFcCompFont[b2]).firstFont = fontConfigFont;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 199 */     fontConfigFonts = arrayOfFcCompFont;
/*     */     
/* 201 */     if (debugFonts) {
/*     */       
/* 203 */       long l1 = System.nanoTime();
/* 204 */       System.err.println("Time spent accessing fontconfig=" + (l1 - l) / 1000000L + "ms.");
/*     */ 
/*     */       
/* 207 */       for (byte b = 0; b < fontConfigFonts.length; b++) {
/* 208 */         FcCompFont fcCompFont = fontConfigFonts[b];
/* 209 */         System.err.println("FC font " + fcCompFont.fcName + " maps to " + fcCompFont.firstFont.fullName + " in file " + fcCompFont.firstFont.fontFile);
/*     */ 
/*     */         
/* 212 */         if (fcCompFont.allFonts != null) {
/* 213 */           for (byte b3 = 0; b3 < fcCompFont.allFonts.length; b3++) {
/* 214 */             FontConfigFont fontConfigFont1 = fcCompFont.allFonts[b3];
/* 215 */             System.err.println(" " + b3 + ") Family=" + fontConfigFont1.familyName + ", Style=" + fontConfigFont1.styleStr + ", Fullname=" + fontConfigFont1.fullName + ", File=" + fontConfigFont1.fontFile);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void populateMaps(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap, Locale paramLocale) {
/* 238 */     boolean bool = false;
/* 239 */     if (useFontConfig && !fontConfigFailed) {
/* 240 */       bool = populateMapsNative(paramHashMap1, paramHashMap2, paramHashMap, paramLocale);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 245 */     if (fontConfigFailed || useEmbeddedFontSupport || !bool)
/*     */     {
/*     */       
/* 248 */       EmbeddedFontSupport.populateMaps(paramHashMap1, paramHashMap2, paramHashMap, paramLocale);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String mapFxToFcLogicalFamilyName(String paramString) {
/* 255 */     if (paramString.equals("serif"))
/* 256 */       return "serif"; 
/* 257 */     if (paramString.equals("monospaced")) {
/* 258 */       return "monospace";
/*     */     }
/* 260 */     return "sans";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FcCompFont getFontConfigFont(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 267 */     initFontConfigLogFonts();
/*     */     
/* 269 */     if (fontConfigFonts == null) {
/* 270 */       return null;
/*     */     }
/*     */     
/* 273 */     String str = mapFxToFcLogicalFamilyName(paramString.toLowerCase());
/* 274 */     boolean bool = paramBoolean1 ? true : false;
/* 275 */     if (paramBoolean2) {
/* 276 */       bool += true;
/*     */     }
/*     */     
/* 279 */     FcCompFont fcCompFont = null;
/* 280 */     for (byte b = 0; b < fontConfigFonts.length; b++) {
/* 281 */       if (str.equals((fontConfigFonts[b]).fcFamily) && bool == (fontConfigFonts[b]).style) {
/*     */         
/* 283 */         fcCompFont = fontConfigFonts[b];
/*     */         break;
/*     */       } 
/*     */     } 
/* 287 */     if (fcCompFont == null) {
/* 288 */       fcCompFont = fontConfigFonts[0];
/*     */     }
/*     */     
/* 291 */     if (debugFonts) {
/* 292 */       System.err.println("FC name=" + str + " style=" + bool + " uses " + fcCompFont.firstFont.fullName + " in file: " + fcCompFont.firstFont.fontFile);
/*     */     }
/*     */ 
/*     */     
/* 296 */     return fcCompFont;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getDefaultFontPath() {
/* 301 */     if (fontConfigFonts == null && !fontConfigFailed)
/*     */     {
/* 303 */       getFontConfigFont("System", false, false);
/*     */     }
/* 305 */     return defaultFontFile;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<String> getFileNames(FcCompFont paramFcCompFont, boolean paramBoolean) {
/* 311 */     ArrayList<String> arrayList = new ArrayList();
/*     */     
/* 313 */     if (paramFcCompFont.allFonts != null) {
/* 314 */       byte b1 = paramBoolean ? 1 : 0;
/* 315 */       for (byte b2 = b1; b2 < paramFcCompFont.allFonts.length; b2++) {
/* 316 */         arrayList.add((paramFcCompFont.allFonts[b2]).fontFile);
/*     */       }
/*     */     } 
/* 319 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<String> getFontNames(FcCompFont paramFcCompFont, boolean paramBoolean) {
/* 325 */     ArrayList<String> arrayList = new ArrayList();
/*     */     
/* 327 */     if (paramFcCompFont.allFonts != null) {
/* 328 */       byte b1 = paramBoolean ? 1 : 0;
/* 329 */       for (byte b2 = b1; b2 < paramFcCompFont.allFonts.length; b2++) {
/* 330 */         arrayList.add((paramFcCompFont.allFonts[b2]).fullName);
/*     */       }
/*     */     } 
/* 333 */     return arrayList;
/*     */   }
/*     */ 
/*     */   
/*     */   private static native boolean getFontConfig(String paramString, FcCompFont[] paramArrayOfFcCompFont, boolean paramBoolean);
/*     */ 
/*     */   
/*     */   private static native boolean populateMapsNative(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap, Locale paramLocale);
/*     */ 
/*     */   
/*     */   private static class EmbeddedFontSupport
/*     */   {
/* 345 */     private static String fontDirProp = null;
/*     */     private static String fontDir;
/*     */     private static boolean fontDirFromJRE = false;
/*     */     
/*     */     static {
/* 350 */       AccessController.doPrivileged(() -> {
/*     */             initEmbeddedFonts();
/*     */             return null;
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static void initEmbeddedFonts() {
/* 359 */       fontDirProp = System.getProperty("prism.fontdir");
/* 360 */       if (fontDirProp != null) {
/* 361 */         fontDir = fontDirProp;
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/* 366 */           String str = System.getProperty("java.home");
/* 367 */           if (str == null) {
/*     */             return;
/*     */           }
/* 370 */           File file = new File(str, "lib/fonts");
/* 371 */           if (file.exists()) {
/* 372 */             fontDirFromJRE = true;
/* 373 */             fontDir = file.getPath();
/*     */           } 
/* 375 */           if (FontConfigManager.debugFonts) {
/* 376 */             System.err.println("Fallback fontDir is " + file + " exists = " + file
/*     */                 
/* 378 */                 .exists());
/*     */           }
/* 380 */         } catch (Exception exception) {
/* 381 */           if (FontConfigManager.debugFonts) {
/* 382 */             exception.printStackTrace();
/*     */           }
/* 384 */           fontDir = "/";
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private static String getStyleStr(int param1Int) {
/* 390 */       switch (param1Int) { case 0:
/* 391 */           return "regular";
/* 392 */         case 1: return "bold";
/* 393 */         case 2: return "italic";
/* 394 */         case 3: return "bolditalic"; }
/* 395 */        return "regular";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean exists(File param1File) {
/* 401 */       return ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(param1File.exists()))).booleanValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 408 */     static String[] jreFontsProperties = new String[] { "sans.regular.0.font", "Lucida Sans Regular", "sans.regular.0.file", "LucidaSansRegular.ttf", "sans.bold.0.font", "Lucida Sans Bold", "sans.bold.0.file", "LucidaSansDemiBold.ttf", "monospace.regular.0.font", "Lucida Typewriter Regular", "monospace.regular.0.file", "LucidaTypewriterRegular.ttf", "monospace.bold.0.font", "Lucida Typewriter Bold", "monospace.bold.0.file", "LucidaTypewriterBold.ttf", "serif.regular.0.font", "Lucida Bright", "serif.regular.0.file", "LucidaBrightRegular.ttf", "serif.bold.0.font", "Lucida Bright Demibold", "serif.bold.0.file", "LucidaBrightDemiBold.ttf", "serif.italic.0.font", "Lucida Bright Italic", "serif.italic.0.file", "LucidaBrightItalic.ttf", "serif.bolditalic.0.font", "Lucida Bright Demibold Italic", "serif.bolditalic.0.file", "LucidaBrightDemiItalic.ttf" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static void initLogicalFonts(FontConfigManager.FcCompFont[] param1ArrayOfFcCompFont) {
/* 450 */       Properties properties = new Properties();
/*     */       try {
/* 452 */         File file = new File(fontDir, "logicalfonts.properties");
/* 453 */         if (file.exists()) {
/* 454 */           FileInputStream fileInputStream = new FileInputStream(file);
/* 455 */           properties.load(fileInputStream);
/* 456 */           fileInputStream.close();
/* 457 */         } else if (fontDirFromJRE) {
/*     */ 
/*     */ 
/*     */           
/* 461 */           for (byte b1 = 0; b1 < jreFontsProperties.length; b1 += 2) {
/* 462 */             properties.setProperty(jreFontsProperties[b1], jreFontsProperties[b1 + 1]);
/*     */           }
/* 464 */           if (FontConfigManager.debugFonts) {
/* 465 */             System.err.println("Using fallback implied logicalfonts.properties");
/*     */           }
/*     */         } 
/* 468 */       } catch (IOException iOException) {
/* 469 */         if (FontConfigManager.debugFonts) {
/* 470 */           System.err.println(iOException);
/*     */           return;
/*     */         } 
/*     */       } 
/* 474 */       for (byte b = 0; b < param1ArrayOfFcCompFont.length; b++) {
/* 475 */         String str1 = (param1ArrayOfFcCompFont[b]).fcFamily;
/* 476 */         String str2 = getStyleStr((param1ArrayOfFcCompFont[b]).style);
/* 477 */         String str3 = str1 + "." + str1 + ".";
/* 478 */         ArrayList<FontConfigManager.FontConfigFont> arrayList = new ArrayList();
/*     */         
/* 480 */         byte b1 = 0;
/*     */         while (true) {
/* 482 */           String str4 = properties.getProperty(str3 + str3 + ".file");
/* 483 */           String str5 = properties.getProperty(str3 + str3 + ".font");
/* 484 */           b1++;
/* 485 */           if (str4 == null) {
/*     */             break;
/*     */           }
/* 488 */           File file = new File(fontDir, str4);
/* 489 */           if (!exists(file)) {
/* 490 */             if (FontConfigManager.debugFonts) {
/* 491 */               System.out.println("Failed to find logical font file " + file);
/*     */             }
/*     */             continue;
/*     */           } 
/* 495 */           FontConfigManager.FontConfigFont fontConfigFont = new FontConfigManager.FontConfigFont();
/* 496 */           fontConfigFont.fontFile = file.getPath();
/* 497 */           fontConfigFont.fullName = str5;
/* 498 */           fontConfigFont.familyName = null;
/* 499 */           fontConfigFont.styleStr = null;
/* 500 */           if ((param1ArrayOfFcCompFont[b]).firstFont == null) {
/* 501 */             (param1ArrayOfFcCompFont[b]).firstFont = fontConfigFont;
/*     */           }
/* 503 */           arrayList.add(fontConfigFont);
/*     */         } 
/* 505 */         if (arrayList.size() > 0) {
/* 506 */           (param1ArrayOfFcCompFont[b]).allFonts = new FontConfigManager.FontConfigFont[arrayList.size()];
/* 507 */           arrayList.toArray((param1ArrayOfFcCompFont[b]).allFonts);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static void populateMaps(HashMap<String, String> param1HashMap1, HashMap<String, String> param1HashMap2, HashMap<String, ArrayList<String>> param1HashMap, Locale param1Locale) {
/* 544 */       Properties properties = new Properties();
/* 545 */       AccessController.doPrivileged(() -> {
/*     */             try {
/*     */               String str = fontDir + "/allfonts.properties";
/*     */               
/*     */               FileInputStream fileInputStream = new FileInputStream(str);
/*     */               param1Properties.load(fileInputStream);
/*     */               fileInputStream.close();
/* 552 */             } catch (IOException iOException) {
/*     */               param1Properties.clear();
/*     */               
/*     */               if (FontConfigManager.debugFonts) {
/*     */                 System.err.println(iOException);
/*     */                 
/*     */                 System.err.println("Fall back to opening the files");
/*     */               } 
/*     */             } 
/*     */             return null;
/*     */           });
/* 563 */       if (!properties.isEmpty()) {
/* 564 */         int i = Integer.MAX_VALUE;
/*     */         try {
/* 566 */           i = Integer.parseInt(properties.getProperty("maxFont", ""));
/* 567 */         } catch (NumberFormatException numberFormatException) {}
/*     */         
/* 569 */         if (i <= 0) {
/* 570 */           i = Integer.MAX_VALUE;
/*     */         }
/* 572 */         for (byte b = 0; b < i; b++) {
/* 573 */           String str1 = properties.getProperty("family." + b);
/* 574 */           String str2 = properties.getProperty("font." + b);
/* 575 */           String str3 = properties.getProperty("file." + b);
/* 576 */           if (str3 == null) {
/*     */             break;
/*     */           }
/* 579 */           File file = new File(fontDir, str3);
/* 580 */           if (exists(file))
/*     */           {
/*     */             
/* 583 */             if (str1 != null && str2 != null) {
/*     */ 
/*     */               
/* 586 */               String str4 = str2.toLowerCase(Locale.ENGLISH);
/* 587 */               String str5 = str1.toLowerCase(Locale.ENGLISH);
/* 588 */               param1HashMap1.put(str4, file.getPath());
/* 589 */               param1HashMap2.put(str4, str1);
/*     */               
/* 591 */               ArrayList<String> arrayList = param1HashMap.get(str5);
/* 592 */               if (arrayList == null) {
/* 593 */                 arrayList = new ArrayList(4);
/* 594 */                 param1HashMap.put(str5, arrayList);
/*     */               } 
/* 596 */               arrayList.add(str2);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\FontConfigManager.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */