package com.sun.javafx.font;

import com.sun.javafx.geom.Point2D;
import com.sun.javafx.geom.Shape;
import com.sun.javafx.geom.transform.BaseTransform;
import com.sun.javafx.scene.text.GlyphList;

public interface FontStrike {
  FontResource getFontResource();
  
  float getSize();
  
  BaseTransform getTransform();
  
  boolean drawAsShapes();
  
  int getQuantizedPosition(Point2D paramPoint2D);
  
  Metrics getMetrics();
  
  Glyph getGlyph(char paramChar);
  
  Glyph getGlyph(int paramInt);
  
  void clearDesc();
  
  int getAAMode();
  
  float getCharAdvance(char paramChar);
  
  Shape getOutline(GlyphList paramGlyphList, BaseTransform paramBaseTransform);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\FontStrike.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */