/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrismMetrics
/*     */   implements Metrics
/*     */ {
/*     */   PrismFontFile fontResource;
/*     */   float ascent;
/*     */   float descent;
/*     */   float linegap;
/*     */   private float[] styleMetrics;
/*     */   float size;
/*     */   static final int XHEIGHT = 0;
/*     */   static final int CAPHEIGHT = 1;
/*     */   static final int TYPO_ASCENT = 2;
/*     */   static final int TYPO_DESCENT = 3;
/*     */   static final int TYPO_LINEGAP = 4;
/*     */   static final int STRIKETHROUGH_THICKNESS = 5;
/*     */   static final int STRIKETHROUGH_OFFSET = 6;
/*     */   static final int UNDERLINE_THICKESS = 7;
/*     */   static final int UNDERLINE_OFFSET = 8;
/*     */   static final int METRICS_TOTAL = 9;
/*     */   
/*     */   PrismMetrics(float paramFloat1, float paramFloat2, float paramFloat3, PrismFontFile paramPrismFontFile, float paramFloat4) {
/*  49 */     this.ascent = paramFloat1;
/*  50 */     this.descent = paramFloat2;
/*  51 */     this.linegap = paramFloat3;
/*  52 */     this.fontResource = paramPrismFontFile;
/*  53 */     this.size = paramFloat4;
/*     */   }
/*     */   
/*     */   public float getAscent() {
/*  57 */     return this.ascent;
/*     */   }
/*     */   
/*     */   public float getDescent() {
/*  61 */     return this.descent;
/*     */   }
/*     */   
/*     */   public float getLineGap() {
/*  65 */     return this.linegap;
/*     */   }
/*     */   
/*     */   public float getLineHeight() {
/*  69 */     return -this.ascent + this.descent + this.linegap;
/*     */   }
/*     */   
/*     */   private void checkStyleMetrics() {
/*  73 */     if (this.styleMetrics == null) {
/*  74 */       this.styleMetrics = this.fontResource.getStyleMetrics(this.size);
/*     */     }
/*     */   }
/*     */   
/*     */   public float getTypoAscent() {
/*  79 */     checkStyleMetrics();
/*  80 */     return this.styleMetrics[2];
/*     */   }
/*     */   
/*     */   public float getTypoDescent() {
/*  84 */     checkStyleMetrics();
/*  85 */     return this.styleMetrics[3];
/*     */   }
/*     */   
/*     */   public float getTypoLineGap() {
/*  89 */     checkStyleMetrics();
/*  90 */     return this.styleMetrics[4];
/*     */   }
/*     */   
/*     */   public float getCapHeight() {
/*  94 */     checkStyleMetrics();
/*  95 */     return this.styleMetrics[1];
/*     */   }
/*     */   
/*     */   public float getXHeight() {
/*  99 */     checkStyleMetrics();
/* 100 */     return this.styleMetrics[0];
/*     */   }
/*     */   
/*     */   public float getStrikethroughOffset() {
/* 104 */     checkStyleMetrics();
/* 105 */     return this.styleMetrics[6];
/*     */   }
/*     */   
/*     */   public float getStrikethroughThickness() {
/* 109 */     checkStyleMetrics();
/* 110 */     return this.styleMetrics[5];
/*     */   }
/*     */   
/*     */   public float getUnderLineOffset() {
/* 114 */     checkStyleMetrics();
/* 115 */     return this.styleMetrics[8];
/*     */   }
/*     */   
/*     */   public float getUnderLineThickness() {
/* 119 */     checkStyleMetrics();
/* 120 */     return this.styleMetrics[7];
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 125 */     return "ascent = " + getAscent() + " descent = " + 
/* 126 */       getDescent() + " linegap = " + 
/* 127 */       getLineGap() + " lineheight = " + 
/* 128 */       getLineHeight();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\PrismMetrics.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */