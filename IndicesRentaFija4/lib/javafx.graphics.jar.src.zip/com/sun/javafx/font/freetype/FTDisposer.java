/*    */ package com.sun.javafx.font.freetype;
/*    */ 
/*    */ import com.sun.javafx.font.DisposerRecord;
/*    */ import com.sun.javafx.font.PrismFontFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FTDisposer
/*    */   implements DisposerRecord
/*    */ {
/*    */   long library;
/*    */   long face;
/*    */   
/*    */   FTDisposer(long paramLong1, long paramLong2) {
/* 36 */     this.library = paramLong1;
/* 37 */     this.face = paramLong2;
/*    */   }
/*    */   
/*    */   public synchronized void dispose() {
/* 41 */     if (this.face != 0L) {
/* 42 */       OSFreetype.FT_Done_Face(this.face);
/* 43 */       if (PrismFontFactory.debugFonts) {
/* 44 */         System.err.println("Done Face=" + this.face);
/*    */       }
/* 46 */       this.face = 0L;
/*    */     } 
/* 48 */     if (this.library != 0L) {
/* 49 */       OSFreetype.FT_Done_FreeType(this.library);
/* 50 */       if (PrismFontFactory.debugFonts) {
/* 51 */         System.err.println("Done Library=" + this.library);
/*    */       }
/* 53 */       this.library = 0L;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\freetype\FTDisposer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */