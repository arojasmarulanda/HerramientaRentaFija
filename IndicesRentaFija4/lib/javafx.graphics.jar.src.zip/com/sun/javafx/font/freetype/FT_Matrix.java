package com.sun.javafx.font.freetype;

class FT_Matrix {
  long xx;
  
  long xy;
  
  long yx;
  
  long yy;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\freetype\FT_Matrix.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */