/*    */ package com.sun.javafx.font.freetype;
/*    */ 
/*    */ import com.sun.javafx.font.FontStrike;
/*    */ import com.sun.javafx.font.PGFont;
/*    */ import com.sun.javafx.text.GlyphLayout;
/*    */ import com.sun.javafx.text.TextRun;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HBGlyphLayout
/*    */   extends GlyphLayout
/*    */ {
/*    */   public void layout(TextRun paramTextRun, PGFont paramPGFont, FontStrike paramFontStrike, char[] paramArrayOfchar) {
/* 37 */     System.out.println("Only simple text supported.");
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\freetype\HBGlyphLayout.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */