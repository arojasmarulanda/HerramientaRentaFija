package com.sun.javafx.font.freetype;

class FT_Glyph_Metrics {
  long width;
  
  long height;
  
  long horiBearingX;
  
  long horiBearingY;
  
  long horiAdvance;
  
  long vertBearingX;
  
  long vertBearingY;
  
  long vertAdvance;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\freetype\FT_Glyph_Metrics.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */