/*     */ package com.sun.javafx.font.freetype;
/*     */ 
/*     */ import com.sun.javafx.font.Glyph;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FTGlyph
/*     */   implements Glyph
/*     */ {
/*     */   FTFontStrike strike;
/*     */   int glyphCode;
/*     */   byte[] buffer;
/*     */   FT_Bitmap bitmap;
/*     */   int bitmap_left;
/*     */   int bitmap_top;
/*     */   float advanceX;
/*     */   float advanceY;
/*     */   float userAdvance;
/*     */   boolean lcd;
/*     */   
/*     */   FTGlyph(FTFontStrike paramFTFontStrike, int paramInt, boolean paramBoolean) {
/*  45 */     this.strike = paramFTFontStrike;
/*  46 */     this.glyphCode = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGlyphCode() {
/*  51 */     return this.glyphCode;
/*     */   }
/*     */   
/*     */   private void init() {
/*  55 */     if (this.bitmap != null)
/*  56 */       return;  this.strike.initGlyph(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public RectBounds getBBox() {
/*  61 */     float[] arrayOfFloat = new float[4];
/*  62 */     FTFontFile fTFontFile = this.strike.getFontResource();
/*  63 */     fTFontFile.getGlyphBoundingBox(this.glyphCode, this.strike.getSize(), arrayOfFloat);
/*  64 */     return new RectBounds(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3]);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAdvance() {
/*  69 */     init();
/*  70 */     return this.userAdvance;
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape getShape() {
/*  75 */     return this.strike.createGlyphOutline(this.glyphCode);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getPixelData() {
/*  80 */     init();
/*  81 */     return this.buffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getPixelData(int paramInt) {
/*  86 */     init();
/*  87 */     return this.buffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getPixelXAdvance() {
/*  92 */     init();
/*  93 */     return this.advanceX;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getPixelYAdvance() {
/*  98 */     init();
/*  99 */     return this.advanceY;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 104 */     init();
/*     */     
/* 106 */     return (this.bitmap != null) ? this.bitmap.width : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 111 */     init();
/* 112 */     return (this.bitmap != null) ? this.bitmap.rows : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOriginX() {
/* 117 */     init();
/* 118 */     return this.bitmap_left;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOriginY() {
/* 123 */     init();
/* 124 */     return -this.bitmap_top;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLCDGlyph() {
/* 129 */     return this.lcd;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\freetype\FTGlyph.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */