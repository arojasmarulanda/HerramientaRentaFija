package com.sun.javafx.font.freetype;

class PangoGlyphString {
  int offset;
  
  int length;
  
  int num_chars;
  
  long font;
  
  int num_glyphs;
  
  int[] glyphs;
  
  int[] widths;
  
  int[] log_clusters;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\freetype\PangoGlyphString.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */