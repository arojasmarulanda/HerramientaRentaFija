/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PrismFont
/*     */   implements PGFont
/*     */ {
/*     */   private String name;
/*     */   private float fontSize;
/*     */   protected FontResource fontResource;
/*     */   private int features;
/*     */   private int hash;
/*     */   
/*     */   PrismFont(FontResource paramFontResource, String paramString, float paramFloat) {
/*  39 */     this.fontResource = paramFontResource;
/*  40 */     this.name = paramString;
/*  41 */     this.fontSize = paramFloat;
/*     */   }
/*     */   
/*     */   public String getFullName() {
/*  45 */     return this.fontResource.getFullName();
/*     */   }
/*     */   
/*     */   public String getFamilyName() {
/*  49 */     return this.fontResource.getFamilyName();
/*     */   }
/*     */   
/*     */   public String getStyleName() {
/*  53 */     return this.fontResource.getStyleName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFeatures() {
/*  61 */     return this.features;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  65 */     return this.name;
/*     */   }
/*     */   
/*     */   public float getSize() {
/*  69 */     return this.fontSize;
/*     */   }
/*     */   
/*     */   public FontStrike getStrike(BaseTransform paramBaseTransform) {
/*  73 */     return this.fontResource.getStrike(this.fontSize, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   public FontStrike getStrike(BaseTransform paramBaseTransform, int paramInt) {
/*  78 */     return this.fontResource.getStrike(this.fontSize, paramBaseTransform, paramInt);
/*     */   }
/*     */   
/*     */   public FontResource getFontResource() {
/*  82 */     return this.fontResource;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  87 */     if (paramObject == null) {
/*  88 */       return false;
/*     */     }
/*  90 */     if (!(paramObject instanceof PrismFont)) {
/*  91 */       return false;
/*     */     }
/*  93 */     PrismFont prismFont = (PrismFont)paramObject;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     return (this.fontSize == prismFont.fontSize && this.fontResource
/*     */       
/* 100 */       .equals(prismFont.fontResource));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 106 */     if (this.hash != 0) {
/* 107 */       return this.hash;
/*     */     }
/*     */     
/* 110 */     this.hash = 497 + Float.floatToIntBits(this.fontSize);
/* 111 */     this.hash = 71 * this.hash + this.fontResource.hashCode();
/* 112 */     return this.hash;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\PrismFont.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */