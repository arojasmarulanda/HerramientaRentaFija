package com.sun.javafx.font;

public interface Metrics {
  float getAscent();
  
  float getDescent();
  
  float getLineGap();
  
  float getLineHeight();
  
  float getTypoAscent();
  
  float getTypoDescent();
  
  float getTypoLineGap();
  
  float getXHeight();
  
  float getCapHeight();
  
  float getStrikethroughOffset();
  
  float getStrikethroughThickness();
  
  float getUnderLineOffset();
  
  float getUnderLineThickness();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\Metrics.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */