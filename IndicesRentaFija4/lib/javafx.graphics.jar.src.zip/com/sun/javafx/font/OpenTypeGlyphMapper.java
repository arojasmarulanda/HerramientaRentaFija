/*    */ package com.sun.javafx.font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenTypeGlyphMapper
/*    */   extends CharToGlyphMapper
/*    */ {
/*    */   PrismFontFile font;
/*    */   CMap cmap;
/*    */   
/*    */   public OpenTypeGlyphMapper(PrismFontFile paramPrismFontFile) {
/* 34 */     this.font = paramPrismFontFile;
/*    */     try {
/* 36 */       this.cmap = CMap.initialize(paramPrismFontFile);
/* 37 */     } catch (Exception exception) {
/* 38 */       this.cmap = null;
/*    */     } 
/* 40 */     if (this.cmap == null) {
/* 41 */       handleBadCMAP();
/*    */     }
/* 43 */     this.missingGlyph = 0;
/*    */   }
/*    */   
/*    */   public int getGlyphCode(int paramInt) {
/*    */     try {
/* 48 */       return this.cmap.getGlyph(paramInt);
/* 49 */     } catch (Exception exception) {
/* 50 */       handleBadCMAP();
/* 51 */       return this.missingGlyph;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private void handleBadCMAP() {
/* 57 */     this.cmap = CMap.theNullCmap;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean hasSupplementaryChars() {
/* 64 */     return (this.cmap instanceof CMap.CMapFormat8 || this.cmap instanceof CMap.CMapFormat10 || this.cmap instanceof CMap.CMapFormat12);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\OpenTypeGlyphMapper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */