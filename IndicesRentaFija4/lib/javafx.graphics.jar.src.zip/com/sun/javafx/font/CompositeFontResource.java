package com.sun.javafx.font;

public interface CompositeFontResource extends FontResource {
  FontResource getSlotResource(int paramInt);
  
  int getNumSlots();
  
  int getSlotForFont(String paramString);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\CompositeFontResource.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */