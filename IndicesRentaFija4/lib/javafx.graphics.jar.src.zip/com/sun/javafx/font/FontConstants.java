package com.sun.javafx.font;

public interface FontConstants {
  public static final int ttcfTag = 1953784678;
  
  public static final int v1ttTag = 65536;
  
  public static final int trueTag = 1953658213;
  
  public static final int ottoTag = 1330926671;
  
  public static final int woffTag = 2001684038;
  
  public static final int cmapTag = 1668112752;
  
  public static final int headTag = 1751474532;
  
  public static final int hheaTag = 1751672161;
  
  public static final int hmtxTag = 1752003704;
  
  public static final int maxpTag = 1835104368;
  
  public static final int nameTag = 1851878757;
  
  public static final int os_2Tag = 1330851634;
  
  public static final int postTag = 1886352244;
  
  public static final int TTCHEADERSIZE = 12;
  
  public static final int DIRECTORYHEADERSIZE = 12;
  
  public static final int DIRECTORYENTRYSIZE = 16;
  
  public static final int WOFFHEADERSIZE = 44;
  
  public static final int WOFFDIRECTORYENTRYSIZE = 20;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\font\FontConstants.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */