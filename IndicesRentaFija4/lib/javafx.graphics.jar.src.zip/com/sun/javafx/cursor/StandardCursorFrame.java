/*    */ package com.sun.javafx.cursor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardCursorFrame
/*    */   extends CursorFrame
/*    */ {
/*    */   private CursorType cursorType;
/*    */   
/*    */   public StandardCursorFrame(CursorType paramCursorType) {
/* 32 */     this.cursorType = paramCursorType;
/*    */   }
/*    */ 
/*    */   
/*    */   public CursorType getCursorType() {
/* 37 */     return this.cursorType;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\cursor\StandardCursorFrame.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */