/*    */ package com.sun.javafx.print;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Units
/*    */ {
/* 36 */   MM,
/*    */ 
/*    */ 
/*    */   
/* 40 */   INCH,
/*    */ 
/*    */ 
/*    */   
/* 44 */   POINT;
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\print\Units.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */