/*    */ package com.sun.javafx.animation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum KeyValueType
/*    */ {
/* 29 */   BOOLEAN, DOUBLE, FLOAT, INTEGER, LONG, OBJECT;
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\animation\KeyValueType.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */