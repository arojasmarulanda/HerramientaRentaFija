/*    */ package com.sun.javafx.animation;
/*    */ 
/*    */ import javafx.util.Duration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TickCalculation
/*    */ {
/*    */   public static final int TICKS_PER_SECOND = 6000;
/*    */   private static final double TICKS_PER_MILI = 6.0D;
/*    */   private static final double TICKS_PER_NANO = 6.0E-6D;
/*    */   
/*    */   public static long add(long paramLong1, long paramLong2) {
/* 38 */     assert paramLong1 >= 0L;
/*    */     
/* 40 */     if (paramLong1 == Long.MAX_VALUE || paramLong2 == Long.MAX_VALUE)
/* 41 */       return Long.MAX_VALUE; 
/* 42 */     if (paramLong2 == Long.MIN_VALUE) {
/* 43 */       return 0L;
/*    */     }
/*    */     
/* 46 */     if (paramLong2 >= 0L) {
/* 47 */       long l = paramLong1 + paramLong2;
/* 48 */       return (l < 0L) ? Long.MAX_VALUE : l;
/*    */     } 
/* 50 */     return Math.max(0L, paramLong1 + paramLong2);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static long sub(long paramLong1, long paramLong2) {
/* 56 */     assert paramLong1 >= 0L;
/*    */     
/* 58 */     if (paramLong1 == Long.MAX_VALUE || paramLong2 == Long.MIN_VALUE)
/* 59 */       return Long.MAX_VALUE; 
/* 60 */     if (paramLong2 == Long.MAX_VALUE) {
/* 61 */       return 0L;
/*    */     }
/*    */     
/* 64 */     if (paramLong2 >= 0L) {
/* 65 */       return Math.max(0L, paramLong1 - paramLong2);
/*    */     }
/* 67 */     long l = paramLong1 - paramLong2;
/* 68 */     return (l < 0L) ? Long.MAX_VALUE : l;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static long fromMillis(double paramDouble) {
/* 74 */     return Math.round(6.0D * paramDouble);
/*    */   }
/*    */   
/*    */   public static long fromNano(long paramLong) {
/* 78 */     return Math.round(6.0E-6D * paramLong);
/*    */   }
/*    */   
/*    */   public static long fromDuration(Duration paramDuration) {
/* 82 */     return fromMillis(paramDuration.toMillis());
/*    */   }
/*    */   
/*    */   public static long fromDuration(Duration paramDuration, double paramDouble) {
/* 86 */     return Math.round(6.0D * paramDuration.toMillis() / Math.abs(paramDouble));
/*    */   }
/*    */   
/*    */   public static Duration toDuration(long paramLong) {
/* 90 */     return Duration.millis(toMillis(paramLong));
/*    */   }
/*    */   
/*    */   public static double toMillis(long paramLong) {
/* 94 */     return paramLong / 6.0D;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\animation\TickCalculation.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */