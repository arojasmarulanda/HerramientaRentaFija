package com.sun.javafx.runtime.eula;

public interface Eula {
  boolean show();
  
  void accept();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\runtime\eula\Eula.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */