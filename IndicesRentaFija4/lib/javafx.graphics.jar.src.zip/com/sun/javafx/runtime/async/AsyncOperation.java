package com.sun.javafx.runtime.async;

public interface AsyncOperation {
  void start();
  
  void cancel();
  
  boolean isCancelled();
  
  boolean isDone();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\runtime\async\AsyncOperation.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */