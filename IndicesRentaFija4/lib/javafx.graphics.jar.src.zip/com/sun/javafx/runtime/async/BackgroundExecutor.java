/*    */ package com.sun.javafx.runtime.async;
/*    */ 
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*    */ import java.util.concurrent.ThreadPoolExecutor;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BackgroundExecutor
/*    */ {
/*    */   private static ExecutorService instance;
/*    */   private static ScheduledExecutorService timerInstance;
/*    */   
/*    */   public static synchronized ExecutorService getExecutor() {
/* 49 */     if (instance == null) {
/* 50 */       instance = Executors.newCachedThreadPool(paramRunnable -> {
/*    */             Thread thread = new Thread(paramRunnable);
/*    */             thread.setPriority(1);
/*    */             return thread;
/*    */           });
/* 55 */       ((ThreadPoolExecutor)instance).setKeepAliveTime(1L, TimeUnit.SECONDS);
/*    */     } 
/*    */     
/* 58 */     return instance;
/*    */   }
/*    */   
/*    */   public static synchronized ScheduledExecutorService getTimer() {
/* 62 */     if (timerInstance == null)
/*    */     {
/* 64 */       timerInstance = new ScheduledThreadPoolExecutor(1, paramRunnable -> {
/*    */             Thread thread = new Thread(paramRunnable);
/*    */             
/*    */             thread.setDaemon(true);
/*    */             
/*    */             return thread;
/*    */           });
/*    */     }
/*    */     
/* 73 */     return timerInstance;
/*    */   }
/*    */   
/*    */   private static synchronized void shutdown() {
/* 77 */     if (instance != null) {
/* 78 */       instance.shutdown();
/* 79 */       instance = null;
/*    */     } 
/* 81 */     if (timerInstance != null) {
/* 82 */       timerInstance.shutdown();
/* 83 */       timerInstance = null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\runtime\async\BackgroundExecutor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */