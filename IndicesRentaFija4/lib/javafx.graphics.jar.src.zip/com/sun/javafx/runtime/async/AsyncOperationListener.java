package com.sun.javafx.runtime.async;

public interface AsyncOperationListener<V> {
  void onProgress(int paramInt1, int paramInt2);
  
  void onCompletion(V paramV);
  
  void onCancel();
  
  void onException(Exception paramException);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\runtime\async\AsyncOperationListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */