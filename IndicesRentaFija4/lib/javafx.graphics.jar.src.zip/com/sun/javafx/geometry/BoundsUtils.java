/*     */ package com.sun.javafx.geometry;
/*     */ 
/*     */ import javafx.geometry.BoundingBox;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.Point3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BoundsUtils
/*     */ {
/*     */   private static double min4(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  37 */     return Math.min(Math.min(paramDouble1, paramDouble2), Math.min(paramDouble3, paramDouble4));
/*     */   }
/*     */ 
/*     */   
/*     */   private static double min8(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8) {
/*  42 */     return Math.min(min4(paramDouble1, paramDouble2, paramDouble3, paramDouble4), min4(paramDouble5, paramDouble6, paramDouble7, paramDouble8));
/*     */   }
/*     */   
/*     */   private static double max4(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  46 */     return Math.max(Math.max(paramDouble1, paramDouble2), Math.max(paramDouble3, paramDouble4));
/*     */   }
/*     */ 
/*     */   
/*     */   private static double max8(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8) {
/*  51 */     return Math.max(max4(paramDouble1, paramDouble2, paramDouble3, paramDouble4), max4(paramDouble5, paramDouble6, paramDouble7, paramDouble8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Bounds createBoundingBox(Point2D paramPoint2D1, Point2D paramPoint2D2, Point2D paramPoint2D3, Point2D paramPoint2D4, Point2D paramPoint2D5, Point2D paramPoint2D6, Point2D paramPoint2D7, Point2D paramPoint2D8) {
/*  58 */     if (paramPoint2D1 == null || paramPoint2D2 == null || paramPoint2D3 == null || paramPoint2D4 == null || paramPoint2D5 == null || paramPoint2D6 == null || paramPoint2D7 == null || paramPoint2D8 == null)
/*     */     {
/*  60 */       return null;
/*     */     }
/*     */     
/*  63 */     double d1 = min8(paramPoint2D1.getX(), paramPoint2D2.getX(), paramPoint2D3.getX(), paramPoint2D4.getX(), paramPoint2D5
/*  64 */         .getX(), paramPoint2D6.getX(), paramPoint2D7.getX(), paramPoint2D8.getX());
/*  65 */     double d2 = max8(paramPoint2D1.getX(), paramPoint2D2.getX(), paramPoint2D3.getX(), paramPoint2D4.getX(), paramPoint2D5
/*  66 */         .getX(), paramPoint2D6.getX(), paramPoint2D7.getX(), paramPoint2D8.getX());
/*     */     
/*  68 */     double d3 = min8(paramPoint2D1.getY(), paramPoint2D2.getY(), paramPoint2D3.getY(), paramPoint2D4.getY(), paramPoint2D5
/*  69 */         .getY(), paramPoint2D6.getY(), paramPoint2D7.getY(), paramPoint2D8.getY());
/*  70 */     double d4 = max8(paramPoint2D1.getY(), paramPoint2D2.getY(), paramPoint2D3.getY(), paramPoint2D4.getY(), paramPoint2D5
/*  71 */         .getY(), paramPoint2D6.getY(), paramPoint2D7.getY(), paramPoint2D8.getY());
/*     */     
/*  73 */     return new BoundingBox(d1, d3, d2 - d1, d4 - d3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Bounds createBoundingBox(Point3D paramPoint3D1, Point3D paramPoint3D2, Point3D paramPoint3D3, Point3D paramPoint3D4, Point3D paramPoint3D5, Point3D paramPoint3D6, Point3D paramPoint3D7, Point3D paramPoint3D8) {
/*  79 */     if (paramPoint3D1 == null || paramPoint3D2 == null || paramPoint3D3 == null || paramPoint3D4 == null || paramPoint3D5 == null || paramPoint3D6 == null || paramPoint3D7 == null || paramPoint3D8 == null)
/*     */     {
/*  81 */       return null;
/*     */     }
/*     */     
/*  84 */     double d1 = min8(paramPoint3D1.getX(), paramPoint3D2.getX(), paramPoint3D3.getX(), paramPoint3D4.getX(), paramPoint3D5
/*  85 */         .getX(), paramPoint3D6.getX(), paramPoint3D7.getX(), paramPoint3D8.getX());
/*  86 */     double d2 = max8(paramPoint3D1.getX(), paramPoint3D2.getX(), paramPoint3D3.getX(), paramPoint3D4.getX(), paramPoint3D5
/*  87 */         .getX(), paramPoint3D6.getX(), paramPoint3D7.getX(), paramPoint3D8.getX());
/*     */     
/*  89 */     double d3 = min8(paramPoint3D1.getY(), paramPoint3D2.getY(), paramPoint3D3.getY(), paramPoint3D4.getY(), paramPoint3D5
/*  90 */         .getY(), paramPoint3D6.getY(), paramPoint3D7.getY(), paramPoint3D8.getY());
/*  91 */     double d4 = max8(paramPoint3D1.getY(), paramPoint3D2.getY(), paramPoint3D3.getY(), paramPoint3D4.getY(), paramPoint3D5
/*  92 */         .getY(), paramPoint3D6.getY(), paramPoint3D7.getY(), paramPoint3D8.getY());
/*     */     
/*  94 */     double d5 = min8(paramPoint3D1.getZ(), paramPoint3D2.getZ(), paramPoint3D3.getZ(), paramPoint3D4.getZ(), paramPoint3D5
/*  95 */         .getZ(), paramPoint3D6.getZ(), paramPoint3D7.getZ(), paramPoint3D8.getZ());
/*  96 */     double d6 = max8(paramPoint3D1.getZ(), paramPoint3D2.getZ(), paramPoint3D3.getZ(), paramPoint3D4.getZ(), paramPoint3D5
/*  97 */         .getZ(), paramPoint3D6.getZ(), paramPoint3D7.getZ(), paramPoint3D8.getZ());
/*     */     
/*  99 */     return new BoundingBox(d1, d3, d5, d2 - d1, d4 - d3, d6 - d5);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Bounds createBoundingBox(Point2D paramPoint2D1, Point2D paramPoint2D2, Point2D paramPoint2D3, Point2D paramPoint2D4) {
/* 104 */     if (paramPoint2D1 == null || paramPoint2D2 == null || paramPoint2D3 == null || paramPoint2D4 == null) {
/* 105 */       return null;
/*     */     }
/*     */     
/* 108 */     double d1 = min4(paramPoint2D1.getX(), paramPoint2D2.getX(), paramPoint2D3.getX(), paramPoint2D4.getX());
/* 109 */     double d2 = max4(paramPoint2D1.getX(), paramPoint2D2.getX(), paramPoint2D3.getX(), paramPoint2D4.getX());
/* 110 */     double d3 = min4(paramPoint2D1.getY(), paramPoint2D2.getY(), paramPoint2D3.getY(), paramPoint2D4.getY());
/* 111 */     double d4 = max4(paramPoint2D1.getY(), paramPoint2D2.getY(), paramPoint2D3.getY(), paramPoint2D4.getY());
/*     */     
/* 113 */     return new BoundingBox(d1, d3, d2 - d1, d4 - d3);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\geometry\BoundsUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */