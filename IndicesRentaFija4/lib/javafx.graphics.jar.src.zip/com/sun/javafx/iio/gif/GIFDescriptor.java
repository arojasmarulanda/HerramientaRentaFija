/*    */ package com.sun.javafx.iio.gif;
/*    */ 
/*    */ import com.sun.javafx.iio.ImageFormatDescription;
/*    */ import com.sun.javafx.iio.common.ImageDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GIFDescriptor
/*    */   extends ImageDescriptor
/*    */ {
/*    */   private static final String formatName = "GIF";
/* 33 */   private static final String[] extensions = new String[] { "gif" };
/*    */   
/* 35 */   private static final ImageFormatDescription.Signature[] signatures = new ImageFormatDescription.Signature[] { new ImageFormatDescription.Signature(new byte[] { 71, 73, 70, 56, 55, 97 }), new ImageFormatDescription.Signature(new byte[] { 71, 73, 70, 56, 57, 97 }) };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   private static ImageDescriptor theInstance = null;
/*    */   
/*    */   private GIFDescriptor() {
/* 45 */     super("GIF", extensions, signatures);
/*    */   }
/*    */   
/*    */   public static synchronized ImageDescriptor getInstance() {
/* 49 */     if (theInstance == null) {
/* 50 */       theInstance = new GIFDescriptor();
/*    */     }
/* 52 */     return theInstance;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\gif\GIFDescriptor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */