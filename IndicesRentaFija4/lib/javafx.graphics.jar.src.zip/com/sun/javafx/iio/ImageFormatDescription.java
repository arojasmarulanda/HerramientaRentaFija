/*     */ package com.sun.javafx.iio;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ImageFormatDescription
/*     */ {
/*     */   String getFormatName();
/*     */   
/*     */   List<String> getExtensions();
/*     */   
/*     */   List<Signature> getSignatures();
/*     */   
/*     */   public static final class Signature
/*     */   {
/*     */     private final byte[] bytes;
/*     */     
/*     */     public Signature(byte... param1VarArgs) {
/*  75 */       this.bytes = param1VarArgs;
/*     */     }
/*     */     
/*     */     public int getLength() {
/*  79 */       return this.bytes.length;
/*     */     }
/*     */     
/*     */     public boolean matches(byte[] param1ArrayOfbyte) {
/*  83 */       if (param1ArrayOfbyte.length < this.bytes.length) {
/*  84 */         return false;
/*     */       }
/*     */       
/*  87 */       for (byte b = 0; b < this.bytes.length; b++) {
/*  88 */         if (param1ArrayOfbyte[b] != this.bytes[b]) {
/*  89 */           return false;
/*     */         }
/*     */       } 
/*     */       
/*  93 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  98 */       return Arrays.hashCode(this.bytes);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 103 */       if (this == param1Object) {
/* 104 */         return true;
/*     */       }
/*     */       
/* 107 */       if (!(param1Object instanceof Signature)) {
/* 108 */         return false;
/*     */       }
/*     */       
/* 111 */       return Arrays.equals(this.bytes, ((Signature)param1Object).bytes);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\ImageFormatDescription.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */