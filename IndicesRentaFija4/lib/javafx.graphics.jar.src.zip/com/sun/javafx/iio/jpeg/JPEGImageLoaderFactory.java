/*    */ package com.sun.javafx.iio.jpeg;
/*    */ 
/*    */ import com.sun.javafx.iio.ImageFormatDescription;
/*    */ import com.sun.javafx.iio.ImageLoader;
/*    */ import com.sun.javafx.iio.ImageLoaderFactory;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JPEGImageLoaderFactory
/*    */   implements ImageLoaderFactory
/*    */ {
/* 35 */   private static final JPEGImageLoaderFactory theInstance = new JPEGImageLoaderFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final ImageLoaderFactory getInstance() {
/* 41 */     return theInstance;
/*    */   }
/*    */   
/*    */   public ImageFormatDescription getFormatDescription() {
/* 45 */     return JPEGDescriptor.getInstance();
/*    */   }
/*    */   
/*    */   public ImageLoader createImageLoader(InputStream paramInputStream) throws IOException {
/* 49 */     return new JPEGImageLoader(paramInputStream);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\jpeg\JPEGImageLoaderFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */