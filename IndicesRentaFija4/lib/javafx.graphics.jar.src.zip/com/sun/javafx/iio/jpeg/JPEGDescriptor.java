/*    */ package com.sun.javafx.iio.jpeg;
/*    */ 
/*    */ import com.sun.javafx.iio.ImageFormatDescription;
/*    */ import com.sun.javafx.iio.common.ImageDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JPEGDescriptor
/*    */   extends ImageDescriptor
/*    */ {
/*    */   public static final int SOI = 216;
/*    */   private static final String formatName = "JPEG";
/* 35 */   private static final String[] extensions = new String[] { "jpg", "jpeg" };
/*    */ 
/*    */   
/* 38 */   private static final ImageFormatDescription.Signature[] signatures = new ImageFormatDescription.Signature[] { new ImageFormatDescription.Signature(new byte[] { -1, -40 }) };
/*    */ 
/*    */ 
/*    */   
/* 42 */   private static ImageDescriptor theInstance = null;
/*    */   
/*    */   private JPEGDescriptor() {
/* 45 */     super("JPEG", extensions, signatures);
/*    */   }
/*    */   
/*    */   public static synchronized ImageDescriptor getInstance() {
/* 49 */     if (theInstance == null) {
/* 50 */       theInstance = new JPEGDescriptor();
/*    */     }
/* 52 */     return theInstance;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\jpeg\JPEGDescriptor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */