/*     */ package com.sun.javafx.iio.bmp;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BitmapInfoHeader
/*     */ {
/*     */   static final int BIH_SIZE = 40;
/*     */   static final int BIH4_SIZE = 108;
/*     */   static final int BIH5_SIZE = 124;
/*     */   static final int BI_RGB = 0;
/*     */   static final int BI_RLE8 = 1;
/*     */   static final int BI_RLE4 = 2;
/*     */   static final int BI_BITFIELDS = 3;
/*     */   static final int BI_JPEG = 4;
/*     */   static final int BI_PNG = 5;
/*     */   final int biSize;
/*     */   final int biWidth;
/*     */   final int biHeight;
/*     */   final short biPlanes;
/*     */   final short biBitCount;
/*     */   final int biCompression;
/*     */   final int biSizeImage;
/*     */   final int biXPelsPerMeter;
/*     */   final int biYPelsPerMeter;
/*     */   final int biClrUsed;
/*     */   final int biClrImportant;
/*     */   
/*     */   BitmapInfoHeader(LEInputStream paramLEInputStream) throws IOException {
/* 104 */     this.biSize = paramLEInputStream.readInt();
/* 105 */     this.biWidth = paramLEInputStream.readInt();
/* 106 */     this.biHeight = paramLEInputStream.readInt();
/* 107 */     this.biPlanes = paramLEInputStream.readShort();
/* 108 */     this.biBitCount = paramLEInputStream.readShort();
/* 109 */     this.biCompression = paramLEInputStream.readInt();
/* 110 */     this.biSizeImage = paramLEInputStream.readInt();
/* 111 */     this.biXPelsPerMeter = paramLEInputStream.readInt();
/* 112 */     this.biYPelsPerMeter = paramLEInputStream.readInt();
/* 113 */     this.biClrUsed = paramLEInputStream.readInt();
/* 114 */     this.biClrImportant = paramLEInputStream.readInt();
/*     */     
/* 116 */     if (this.biSize > 40) {
/* 117 */       if (this.biSize == 108 || this.biSize == 124) {
/* 118 */         paramLEInputStream.skipBytes(this.biSize - 40);
/*     */       } else {
/* 120 */         throw new IOException("BitmapInfoHeader is corrupt");
/*     */       } 
/*     */     }
/* 123 */     validate();
/*     */   }
/*     */   
/*     */   void validate() throws IOException {
/* 127 */     if (this.biBitCount < 1 || this.biCompression == 4 || this.biCompression == 5)
/*     */     {
/*     */       
/* 130 */       throw new IOException("Unsupported BMP image: Embedded JPEG or PNG images are not supported");
/*     */     }
/*     */ 
/*     */     
/* 134 */     switch (this.biCompression) {
/*     */       case 2:
/* 136 */         if (this.biBitCount != 4) {
/* 137 */           throw new IOException("Invalid BMP image: Only 4 bpp images can be RLE4 compressed");
/*     */         }
/*     */ 
/*     */       
/*     */       case 1:
/* 142 */         if (this.biBitCount != 8) {
/* 143 */           throw new IOException("Invalid BMP image: Only 8 bpp images can be RLE8 compressed");
/*     */         }
/*     */ 
/*     */       
/*     */       case 3:
/* 148 */         if (this.biBitCount != 16 && this.biBitCount != 32) {
/* 149 */           throw new IOException("Invalid BMP image: Only 16 or 32 bpp images can use BITFIELDS compression");
/*     */         }
/*     */       
/*     */       case 0:
/*     */         return;
/*     */     } 
/*     */     
/* 156 */     throw new IOException("Unknown BMP compression type");
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\bmp\BitmapInfoHeader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */