/*    */ package com.sun.javafx.iio.bmp;
/*    */ 
/*    */ import com.sun.javafx.iio.ImageFormatDescription;
/*    */ import com.sun.javafx.iio.common.ImageDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BMPDescriptor
/*    */   extends ImageDescriptor
/*    */ {
/*    */   static final String formatName = "BMP";
/* 36 */   static final String[] extensions = new String[] { "bmp" };
/* 37 */   static final ImageFormatDescription.Signature[] signatures = new ImageFormatDescription.Signature[] { new ImageFormatDescription.Signature(new byte[] { 66, 77 }) };
/* 38 */   static final ImageDescriptor theInstance = new BMPDescriptor();
/*    */   
/*    */   private BMPDescriptor() {
/* 41 */     super("BMP", extensions, signatures);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\bmp\BMPDescriptor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */