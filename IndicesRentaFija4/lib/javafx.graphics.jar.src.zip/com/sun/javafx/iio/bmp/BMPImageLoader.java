/*     */ package com.sun.javafx.iio.bmp;
/*     */ 
/*     */ import com.sun.javafx.iio.ImageFrame;
/*     */ import com.sun.javafx.iio.ImageMetadata;
/*     */ import com.sun.javafx.iio.ImageStorage;
/*     */ import com.sun.javafx.iio.common.ImageLoaderImpl;
/*     */ import com.sun.javafx.iio.common.ImageTools;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BMPImageLoader
/*     */   extends ImageLoaderImpl
/*     */ {
/*     */   static final short BM = 19778;
/*     */   static final int BFH_SIZE = 14;
/*     */   final LEInputStream data;
/*     */   int bfSize;
/*     */   int bfOffBits;
/*     */   byte[] bgra_palette;
/*     */   BitmapInfoHeader bih;
/*     */   int[] bitMasks;
/*     */   int[] bitOffsets;
/*     */   
/*     */   BMPImageLoader(InputStream paramInputStream) throws IOException {
/* 178 */     super(BMPDescriptor.theInstance);
/* 179 */     this.data = new LEInputStream(paramInputStream);
/* 180 */     if (this.data.readShort() != 19778) {
/* 181 */       throw new IOException("Invalid BMP file signature");
/*     */     }
/* 183 */     readHeader();
/*     */   }
/*     */   
/*     */   private void readHeader() throws IOException {
/* 187 */     this.bfSize = this.data.readInt();
/* 188 */     this.data.skipBytes(4);
/* 189 */     this.bfOffBits = this.data.readInt();
/* 190 */     this.bih = new BitmapInfoHeader(this.data);
/* 191 */     if (this.bfOffBits < this.bih.biSize + 14) {
/* 192 */       throw new IOException("Invalid bitmap bits offset");
/*     */     }
/*     */     
/* 195 */     if (this.bih.biSize + 14 != this.bfOffBits) {
/* 196 */       int i = this.bfOffBits - this.bih.biSize - 14;
/* 197 */       int j = i / 4;
/* 198 */       this.bgra_palette = new byte[j * 4];
/* 199 */       int k = this.data.in.read(this.bgra_palette);
/*     */       
/* 201 */       if (k < i) {
/* 202 */         this.data.skipBytes(i - k);
/*     */       }
/*     */     } 
/*     */     
/* 206 */     if (this.bih.biCompression == 3) {
/* 207 */       parseBitfields();
/* 208 */     } else if (this.bih.biCompression == 0 && this.bih.biBitCount == 16) {
/*     */ 
/*     */       
/* 211 */       this.bitMasks = new int[] { 31744, 992, 31 };
/* 212 */       this.bitOffsets = new int[] { 10, 5, 0 };
/*     */     } 
/*     */   }
/*     */   
/*     */   private void parseBitfields() throws IOException {
/* 217 */     if (this.bgra_palette.length != 12) {
/* 218 */       throw new IOException("Invalid bit masks");
/*     */     }
/* 220 */     this.bitMasks = new int[3];
/* 221 */     this.bitOffsets = new int[3];
/* 222 */     for (byte b = 0; b < 3; b++) {
/* 223 */       int i = getDWord(this.bgra_palette, b * 4);
/* 224 */       this.bitMasks[b] = i;
/* 225 */       byte b1 = 0;
/* 226 */       if (i != 0) {
/* 227 */         while ((i & 0x1) == 0) {
/* 228 */           b1++;
/* 229 */           i >>>= 1;
/*     */         } 
/* 231 */         if (!isPow2Minus1(i)) {
/* 232 */           throw new IOException("Bit mask is not contiguous");
/*     */         }
/*     */       } 
/* 235 */       this.bitOffsets[b] = b1;
/*     */     } 
/* 237 */     if (!checkDisjointMasks(this.bitMasks[0], this.bitMasks[1], this.bitMasks[2])) {
/* 238 */       throw new IOException("Bit masks overlap");
/*     */     }
/*     */   }
/*     */   
/*     */   static boolean checkDisjointMasks(int paramInt1, int paramInt2, int paramInt3) {
/* 243 */     return ((paramInt1 & paramInt2 | paramInt1 & paramInt3 | paramInt2 & paramInt3) == 0);
/*     */   }
/*     */   
/*     */   static boolean isPow2Minus1(int paramInt) {
/* 247 */     return ((paramInt & paramInt + 1) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void readRLE(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, boolean paramBoolean) throws IOException {
/* 257 */     int i = this.bih.biSizeImage;
/* 258 */     if (i == 0) {
/* 259 */       i = this.bfSize - this.bfOffBits;
/*     */     }
/* 261 */     byte[] arrayOfByte = new byte[i];
/* 262 */     ImageTools.readFully(this.data.in, arrayOfByte);
/*     */     
/* 264 */     boolean bool = (this.bih.biHeight > 0) ? true : false;
/* 265 */     int j = bool ? (paramInt2 - 1) : 0;
/* 266 */     byte b = 0;
/* 267 */     int k = j * paramInt1;
/* 268 */     while (b < i) {
/* 269 */       int m = getByte(arrayOfByte, b++);
/* 270 */       int n = getByte(arrayOfByte, b++);
/* 271 */       if (m == 0) {
/* 272 */         int i1, i2; switch (n) {
/*     */           case 0:
/* 274 */             j += bool ? -1 : 1;
/* 275 */             k = j * paramInt1;
/*     */             continue;
/*     */           case 1:
/*     */             return;
/*     */           case 2:
/* 280 */             i1 = getByte(arrayOfByte, b++);
/* 281 */             i2 = getByte(arrayOfByte, b++);
/* 282 */             j += i2;
/* 283 */             k += i2 * paramInt1;
/* 284 */             k += i1 * 3;
/*     */             continue;
/*     */         } 
/* 287 */         int i3 = 0;
/*     */         
/* 289 */         for (byte b2 = 0; b2 < n; b2++) {
/* 290 */           int i4; if (paramBoolean) {
/* 291 */             if ((b2 & 0x1) == 0) {
/* 292 */               i3 = getByte(arrayOfByte, b++);
/* 293 */               i4 = (i3 & 0xF0) >> 4;
/*     */             } else {
/* 295 */               i4 = i3 & 0xF;
/*     */             } 
/*     */           } else {
/* 298 */             i4 = getByte(arrayOfByte, b++);
/*     */           } 
/* 300 */           k = setRGBFromPalette(paramArrayOfbyte, k, i4);
/*     */         } 
/* 302 */         if (paramBoolean) {
/* 303 */           if ((n & 0x3) == 1 || (n & 0x3) == 2) b++;  continue;
/*     */         } 
/* 305 */         if ((n & 0x1) == 1) b++;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/* 310 */       if (paramBoolean) {
/* 311 */         int i1 = (n & 0xF0) >> 4;
/* 312 */         int i2 = n & 0xF;
/* 313 */         for (byte b2 = 0; b2 < m; b2++)
/* 314 */           k = setRGBFromPalette(paramArrayOfbyte, k, 
/* 315 */               ((b2 & 0x1) == 0) ? i1 : i2); 
/*     */         continue;
/*     */       } 
/* 318 */       for (byte b1 = 0; b1 < m; b1++) {
/* 319 */         k = setRGBFromPalette(paramArrayOfbyte, k, n);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int setRGBFromPalette(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 328 */     paramInt2 *= 4;
/* 329 */     paramArrayOfbyte[paramInt1++] = this.bgra_palette[paramInt2 + 2];
/* 330 */     paramArrayOfbyte[paramInt1++] = this.bgra_palette[paramInt2 + 1];
/* 331 */     paramArrayOfbyte[paramInt1++] = this.bgra_palette[paramInt2];
/* 332 */     return paramInt1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readPackedBits(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 338 */     int i = 8 / this.bih.biBitCount;
/* 339 */     int j = (this.bih.biWidth + i - 1) / i;
/* 340 */     int k = j + 3 & 0xFFFFFFFC;
/* 341 */     int m = (1 << this.bih.biBitCount) - 1;
/*     */     
/* 343 */     byte[] arrayOfByte = new byte[k];
/* 344 */     for (int n = 0; n != paramInt2; n++) {
/* 345 */       ImageTools.readFully(this.data.in, arrayOfByte);
/* 346 */       int i1 = (this.bih.biHeight < 0) ? n : (paramInt2 - n - 1);
/* 347 */       int i2 = i1 * paramInt1;
/*     */       
/* 349 */       for (byte b = 0; b != this.bih.biWidth; b++) {
/* 350 */         int i3 = b * this.bih.biBitCount;
/* 351 */         byte b1 = arrayOfByte[i3 / 8];
/* 352 */         int i4 = 8 - (i3 & 0x7) - this.bih.biBitCount;
/* 353 */         int i5 = b1 >> i4 & m;
/* 354 */         i2 = setRGBFromPalette(paramArrayOfbyte, i2, i5);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int getDWord(byte[] paramArrayOfbyte, int paramInt) {
/* 360 */     return paramArrayOfbyte[paramInt] & 0xFF | (paramArrayOfbyte[paramInt + 1] & 0xFF) << 8 | (paramArrayOfbyte[paramInt + 2] & 0xFF) << 16 | (paramArrayOfbyte[paramInt + 3] & 0xFF) << 24;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getWord(byte[] paramArrayOfbyte, int paramInt) {
/* 367 */     return paramArrayOfbyte[paramInt] & 0xFF | (paramArrayOfbyte[paramInt + 1] & 0xFF) << 8;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int getByte(byte[] paramArrayOfbyte, int paramInt) {
/* 372 */     return paramArrayOfbyte[paramInt] & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte convertFrom5To8Bit(int paramInt1, int paramInt2, int paramInt3) {
/* 381 */     int i = (paramInt1 & paramInt2) >>> paramInt3;
/* 382 */     return (byte)(i << 3 | i >> 2);
/*     */   }
/*     */   
/*     */   private static byte convertFromXTo8Bit(int paramInt1, int paramInt2, int paramInt3) {
/* 386 */     int i = (paramInt1 & paramInt2) >>> paramInt3;
/* 387 */     return (byte)(int)(i * 255.0D / (paramInt2 >>> paramInt3));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void read16Bit(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, BitConverter paramBitConverter) throws IOException {
/* 393 */     int i = this.bih.biWidth * 2;
/* 394 */     int j = i + 3 & 0xFFFFFFFC;
/* 395 */     byte[] arrayOfByte = new byte[j];
/* 396 */     for (int k = 0; k != paramInt2; k++) {
/* 397 */       ImageTools.readFully(this.data.in, arrayOfByte);
/* 398 */       int m = (this.bih.biHeight < 0) ? k : (paramInt2 - k - 1);
/* 399 */       int n = m * paramInt1;
/*     */       
/* 401 */       for (byte b = 0; b != this.bih.biWidth; b++) {
/* 402 */         int i1 = getWord(arrayOfByte, b * 2);
/* 403 */         for (byte b1 = 0; b1 < 3; b1++) {
/* 404 */           paramArrayOfbyte[n++] = paramBitConverter
/* 405 */             .convert(i1, this.bitMasks[b1], this.bitOffsets[b1]);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void read32BitRGB(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 412 */     int i = this.bih.biWidth * 4;
/* 413 */     byte[] arrayOfByte = new byte[i];
/* 414 */     for (int j = 0; j != paramInt2; j++) {
/* 415 */       ImageTools.readFully(this.data.in, arrayOfByte);
/* 416 */       int k = (this.bih.biHeight < 0) ? j : (paramInt2 - j - 1);
/* 417 */       int m = k * paramInt1;
/*     */       
/* 419 */       for (byte b = 0; b != this.bih.biWidth; b++) {
/* 420 */         int n = b * 4;
/* 421 */         paramArrayOfbyte[m++] = arrayOfByte[n + 2];
/* 422 */         paramArrayOfbyte[m++] = arrayOfByte[n + 1];
/* 423 */         paramArrayOfbyte[m++] = arrayOfByte[n];
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void read32BitBF(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 429 */     int i = this.bih.biWidth * 4;
/* 430 */     byte[] arrayOfByte = new byte[i];
/* 431 */     for (int j = 0; j != paramInt2; j++) {
/* 432 */       ImageTools.readFully(this.data.in, arrayOfByte);
/* 433 */       int k = (this.bih.biHeight < 0) ? j : (paramInt2 - j - 1);
/* 434 */       int m = k * paramInt1;
/*     */       
/* 436 */       for (byte b = 0; b != this.bih.biWidth; b++) {
/* 437 */         int n = b * 4;
/* 438 */         int i1 = getDWord(arrayOfByte, n);
/* 439 */         for (byte b1 = 0; b1 < 3; b1++) {
/* 440 */           paramArrayOfbyte[m++] = 
/* 441 */             convertFromXTo8Bit(i1, this.bitMasks[b1], this.bitOffsets[b1]);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void read24Bit(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 448 */     int i = paramInt1 + 3 & 0xFFFFFFFC;
/* 449 */     int j = i - paramInt1;
/*     */     
/* 451 */     for (int k = 0; k != paramInt2; k++) {
/* 452 */       int m = (this.bih.biHeight < 0) ? k : (paramInt2 - k - 1);
/* 453 */       int n = m * paramInt1;
/* 454 */       ImageTools.readFully(this.data.in, paramArrayOfbyte, n, paramInt1);
/* 455 */       this.data.skipBytes(j);
/* 456 */       BGRtoRGB(paramArrayOfbyte, n, paramInt1);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void BGRtoRGB(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 461 */     for (int i = paramInt2 / 3; i != 0; i--) {
/* 462 */       byte b1 = paramArrayOfbyte[paramInt1], b2 = paramArrayOfbyte[paramInt1 + 2];
/* 463 */       paramArrayOfbyte[paramInt1 + 2] = b1; paramArrayOfbyte[paramInt1] = b2;
/* 464 */       paramInt1 += 3;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageFrame load(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2) throws IOException {
/* 471 */     if (0 != paramInt1) {
/* 472 */       return null;
/*     */     }
/*     */     
/* 475 */     int i = Math.abs(this.bih.biHeight);
/*     */     
/* 477 */     int[] arrayOfInt = ImageTools.computeDimensions(this.bih.biWidth, i, paramInt2, paramInt3, paramBoolean1);
/* 478 */     paramInt2 = arrayOfInt[0];
/* 479 */     paramInt3 = arrayOfInt[1];
/*     */ 
/*     */ 
/*     */     
/* 483 */     ImageMetadata imageMetadata = new ImageMetadata(null, Boolean.TRUE, null, null, null, null, null, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), null, null, null);
/*     */     
/* 485 */     updateImageMetadata(imageMetadata);
/*     */     
/* 487 */     byte b = 3;
/* 488 */     int j = this.bih.biWidth * b;
/*     */     
/* 490 */     byte[] arrayOfByte = new byte[j * i];
/*     */     
/* 492 */     switch (this.bih.biBitCount) {
/*     */       case 1:
/* 494 */         readPackedBits(arrayOfByte, j, i);
/*     */         break;
/*     */       case 4:
/* 497 */         if (this.bih.biCompression == 2) {
/* 498 */           readRLE(arrayOfByte, j, i, true); break;
/*     */         } 
/* 500 */         readPackedBits(arrayOfByte, j, i);
/*     */         break;
/*     */       
/*     */       case 8:
/* 504 */         if (this.bih.biCompression == 1) {
/* 505 */           readRLE(arrayOfByte, j, i, false); break;
/*     */         } 
/* 507 */         readPackedBits(arrayOfByte, j, i);
/*     */         break;
/*     */       
/*     */       case 16:
/* 511 */         if (this.bih.biCompression == 3) {
/* 512 */           read16Bit(arrayOfByte, j, i, BMPImageLoader::convertFromXTo8Bit); break;
/*     */         } 
/* 514 */         read16Bit(arrayOfByte, j, i, BMPImageLoader::convertFrom5To8Bit);
/*     */         break;
/*     */       
/*     */       case 32:
/* 518 */         if (this.bih.biCompression == 3) {
/* 519 */           read32BitBF(arrayOfByte, j, i); break;
/*     */         } 
/* 521 */         read32BitRGB(arrayOfByte, j, i);
/*     */         break;
/*     */       
/*     */       case 24:
/* 525 */         read24Bit(arrayOfByte, j, i);
/*     */         break;
/*     */       default:
/* 528 */         throw new IOException("Unknown BMP bit depth");
/*     */     } 
/*     */     
/* 531 */     ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
/* 532 */     if (this.bih.biWidth != paramInt2 || i != paramInt3) {
/* 533 */       byteBuffer = ImageTools.scaleImage(byteBuffer, this.bih.biWidth, i, b, paramInt2, paramInt3, paramBoolean2);
/*     */     }
/*     */ 
/*     */     
/* 537 */     return new ImageFrame(ImageStorage.ImageType.RGB, byteBuffer, paramInt2, paramInt3, paramInt2 * b, null, imageMetadata);
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   private static interface BitConverter {
/*     */     byte convert(int param1Int1, int param1Int2, int param1Int3);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\bmp\BMPImageLoader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */