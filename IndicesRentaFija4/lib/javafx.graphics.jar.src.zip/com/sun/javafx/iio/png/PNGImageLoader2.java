/*     */ package com.sun.javafx.iio.png;
/*     */ 
/*     */ import com.sun.javafx.iio.ImageFrame;
/*     */ import com.sun.javafx.iio.ImageMetadata;
/*     */ import com.sun.javafx.iio.ImageStorage;
/*     */ import com.sun.javafx.iio.common.ImageLoaderImpl;
/*     */ import com.sun.javafx.iio.common.ImageTools;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import java.util.zip.Inflater;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PNGImageLoader2
/*     */   extends ImageLoaderImpl
/*     */ {
/*  42 */   static final byte[] FILE_SIG = new byte[] { -119, 80, 78, 71, 13, 10, 26, 10 };
/*     */   
/*     */   static final int IHDR_TYPE = 1229472850;
/*     */   
/*     */   static final int PLTE_TYPE = 1347179589;
/*     */   
/*     */   static final int IDAT_TYPE = 1229209940;
/*     */   
/*     */   static final int IEND_TYPE = 1229278788;
/*     */   
/*     */   static final int tRNS_TYPE = 1951551059;
/*     */   static final int PNG_COLOR_GRAY = 0;
/*     */   static final int PNG_COLOR_RGB = 2;
/*     */   static final int PNG_COLOR_PALETTE = 3;
/*     */   static final int PNG_COLOR_GRAY_ALPHA = 4;
/*     */   static final int PNG_COLOR_RGB_ALPHA = 6;
/*  58 */   static final int[] numBandsPerColorType = new int[] { 1, -1, 3, 1, 2, -1, 4 }; static final int PNG_FILTER_NONE = 0;
/*     */   static final int PNG_FILTER_SUB = 1;
/*     */   static final int PNG_FILTER_UP = 2;
/*     */   static final int PNG_FILTER_AVERAGE = 3;
/*     */   static final int PNG_FILTER_PAETH = 4;
/*     */   private final DataInputStream stream;
/*     */   private int width;
/*     */   private int height;
/*     */   private int bitDepth;
/*     */   private int colorType;
/*     */   private boolean isInterlaced;
/*     */   private boolean tRNS_present = false;
/*     */   private boolean tRNS_GRAY_RGB = false;
/*     */   private int trnsR;
/*     */   private int trnsG;
/*     */   private int trnsB;
/*     */   private byte[][] palette;
/*     */   
/*     */   public PNGImageLoader2(InputStream paramInputStream) throws IOException {
/*  77 */     super(PNGDescriptor.getInstance());
/*  78 */     this.stream = new DataInputStream(paramInputStream);
/*     */     
/*  80 */     byte[] arrayOfByte = readBytes(new byte[8]);
/*     */     
/*  82 */     if (!Arrays.equals(FILE_SIG, arrayOfByte)) {
/*  83 */       throw new IOException("Bad PNG signature!");
/*     */     }
/*     */     
/*  86 */     readHeader();
/*     */   }
/*     */   
/*     */   private void readHeader() throws IOException {
/*  90 */     int[] arrayOfInt = readChunk();
/*     */     
/*  92 */     if (arrayOfInt[1] != 1229472850 && arrayOfInt[0] != 13) {
/*  93 */       throw new IOException("Bad PNG header!");
/*     */     }
/*     */     
/*  96 */     this.width = this.stream.readInt();
/*  97 */     this.height = this.stream.readInt();
/*     */     
/*  99 */     if (this.width == 0 || this.height == 0) {
/* 100 */       throw new IOException("Bad PNG image size!");
/*     */     }
/*     */     
/* 103 */     this.bitDepth = this.stream.readByte();
/* 104 */     if (this.bitDepth != 1 && this.bitDepth != 2 && this.bitDepth != 4 && this.bitDepth != 8 && this.bitDepth != 16)
/*     */     {
/* 106 */       throw new IOException("Bad PNG bit depth");
/*     */     }
/*     */     
/* 109 */     this.colorType = this.stream.readByte();
/*     */     
/* 111 */     if (this.colorType > 6 || this.colorType == 1 || this.colorType == 5) {
/* 112 */       throw new IOException("Bad PNG color type");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 117 */     if ((this.colorType != 3 && this.colorType != 0 && this.bitDepth < 8) || (this.colorType == 3 && this.bitDepth == 16))
/*     */     {
/* 119 */       throw new IOException("Bad color type/bit depth combination!");
/*     */     }
/*     */     
/* 122 */     byte b1 = this.stream.readByte();
/* 123 */     if (b1 != 0) {
/* 124 */       throw new IOException("Bad PNG comression!");
/*     */     }
/*     */     
/* 127 */     byte b2 = this.stream.readByte();
/* 128 */     if (b2 != 0) {
/* 129 */       throw new IOException("Bad PNG filter method!");
/*     */     }
/*     */     
/* 132 */     byte b3 = this.stream.readByte();
/*     */     
/* 134 */     if (b3 != 0 && b3 != 1) {
/* 135 */       throw new IOException("Unknown interlace method (not 0 or 1)!");
/*     */     }
/*     */     
/* 138 */     int i = this.stream.readInt();
/*     */     
/* 140 */     this.isInterlaced = (b3 == 1);
/*     */   }
/*     */   
/*     */   private int[] readChunk() throws IOException {
/* 144 */     return new int[] { this.stream.readInt(), this.stream.readInt() };
/*     */   }
/*     */   
/*     */   private byte[] readBytes(byte[] paramArrayOfbyte) throws IOException {
/* 148 */     return readBytes(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */   
/*     */   private byte[] readBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 152 */     this.stream.readFully(paramArrayOfbyte, paramInt1, paramInt2);
/* 153 */     return paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   private void skip(int paramInt) throws IOException {
/* 157 */     if (paramInt != this.stream.skipBytes(paramInt)) {
/* 158 */       throw new EOFException();
/*     */     }
/*     */   }
/*     */   
/*     */   private void readPaletteChunk(int paramInt) throws IOException {
/* 163 */     int i = paramInt / 3;
/* 164 */     int j = 1 << this.bitDepth;
/* 165 */     if (i > j) {
/* 166 */       emitWarning("PLTE chunk contains too many entries for bit depth, ignoring extras.");
/* 167 */       i = j;
/*     */     } 
/*     */     
/* 170 */     this.palette = new byte[3][j];
/*     */     
/* 172 */     byte[] arrayOfByte = readBytes(new byte[paramInt]); int k;
/*     */     byte b;
/* 174 */     for (k = 0, b = 0; k != i; k++) {
/* 175 */       for (byte b1 = 0; b1 != 3; b1++) {
/* 176 */         this.palette[b1][k] = arrayOfByte[b++];
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void parsePaletteChunk(int paramInt) throws IOException {
/* 182 */     if (this.palette != null) {
/* 183 */       emitWarning("A PNG image may not contain more than one PLTE chunk.\nThe chunk wil be ignored.");
/*     */ 
/*     */       
/* 186 */       skip(paramInt);
/*     */       
/*     */       return;
/*     */     } 
/* 190 */     switch (this.colorType) {
/*     */       case 3:
/* 192 */         readPaletteChunk(paramInt);
/*     */         return;
/*     */       case 0:
/*     */       case 4:
/* 196 */         emitWarning("A PNG gray or gray alpha image cannot have a PLTE chunk.\nThe chunk wil be ignored.");
/*     */         break;
/*     */     } 
/*     */     
/* 200 */     skip(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean readPaletteTransparency(int paramInt) throws IOException {
/* 205 */     if (this.palette == null) {
/* 206 */       emitWarning("tRNS chunk without prior PLTE chunk, ignoring it.");
/* 207 */       skip(paramInt);
/* 208 */       return false;
/*     */     } 
/*     */     
/* 211 */     byte[][] arrayOfByte = new byte[4][];
/*     */     
/* 213 */     System.arraycopy(this.palette, 0, arrayOfByte, 0, 3);
/*     */     
/* 215 */     int i = (this.palette[0]).length;
/* 216 */     arrayOfByte[3] = new byte[i];
/*     */     
/* 218 */     int j = (paramInt < i) ? paramInt : i;
/* 219 */     readBytes(arrayOfByte[3], 0, j);
/*     */     
/* 221 */     for (int k = j; k < i; k++) {
/* 222 */       arrayOfByte[3][k] = -1;
/*     */     }
/*     */     
/* 225 */     if (j < paramInt) {
/* 226 */       skip(paramInt - j);
/*     */     }
/*     */     
/* 229 */     this.palette = arrayOfByte;
/*     */     
/* 231 */     return true;
/*     */   }
/*     */   
/*     */   private boolean readGrayTransparency(int paramInt) throws IOException {
/* 235 */     if (paramInt == 2) {
/* 236 */       this.trnsG = this.stream.readShort();
/* 237 */       return true;
/*     */     } 
/* 239 */     return false;
/*     */   }
/*     */   
/*     */   private boolean readRgbTransparency(int paramInt) throws IOException {
/* 243 */     if (paramInt == 6) {
/* 244 */       this.trnsR = this.stream.readShort();
/* 245 */       this.trnsG = this.stream.readShort();
/* 246 */       this.trnsB = this.stream.readShort();
/* 247 */       return true;
/*     */     } 
/* 249 */     return false;
/*     */   }
/*     */   
/*     */   private void parseTransparencyChunk(int paramInt) throws IOException {
/* 253 */     switch (this.colorType) {
/*     */       case 3:
/* 255 */         this.tRNS_present = readPaletteTransparency(paramInt);
/*     */         return;
/*     */       case 0:
/* 258 */         this.tRNS_GRAY_RGB = this.tRNS_present = readGrayTransparency(paramInt);
/*     */         return;
/*     */       case 2:
/* 261 */         this.tRNS_GRAY_RGB = this.tRNS_present = readRgbTransparency(paramInt);
/*     */         return;
/*     */     } 
/* 264 */     emitWarning("TransparencyChunk may not present when alpha explicitly defined");
/* 265 */     skip(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int parsePngMeta() throws IOException {
/*     */     while (true) {
/* 272 */       int[] arrayOfInt = readChunk();
/*     */       
/* 274 */       if (arrayOfInt[0] < 0) {
/* 275 */         throw new IOException("Invalid chunk length");
/*     */       }
/* 277 */       switch (arrayOfInt[1]) {
/*     */         case 1229209940:
/* 279 */           return arrayOfInt[0];
/*     */         case 1229278788:
/* 281 */           return 0;
/*     */         case 1347179589:
/* 283 */           parsePaletteChunk(arrayOfInt[0]);
/*     */           break;
/*     */         case 1951551059:
/* 286 */           parseTransparencyChunk(arrayOfInt[0]);
/*     */           break;
/*     */         default:
/* 289 */           skip(arrayOfInt[0]); break;
/*     */       } 
/* 291 */       int i = this.stream.readInt();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */   
/*     */   private ImageStorage.ImageType getType() {
/* 299 */     switch (this.colorType) {
/*     */       case 0:
/* 301 */         return this.tRNS_present ? 
/* 302 */           ImageStorage.ImageType.GRAY_ALPHA : 
/* 303 */           ImageStorage.ImageType.GRAY;
/*     */       case 2:
/* 305 */         return this.tRNS_present ? 
/* 306 */           ImageStorage.ImageType.RGBA : 
/* 307 */           ImageStorage.ImageType.RGB;
/*     */       case 3:
/* 309 */         return ImageStorage.ImageType.PALETTE;
/*     */       case 4:
/* 311 */         return ImageStorage.ImageType.GRAY_ALPHA;
/*     */       case 6:
/* 313 */         return ImageStorage.ImageType.RGBA;
/*     */     } 
/* 315 */     throw new RuntimeException();
/*     */   }
/*     */ 
/*     */   
/*     */   private void doSubFilter(byte[] paramArrayOfbyte, int paramInt) {
/* 320 */     int i = paramArrayOfbyte.length;
/* 321 */     for (int j = paramInt; j != i; j++) {
/* 322 */       paramArrayOfbyte[j] = (byte)(paramArrayOfbyte[j] + paramArrayOfbyte[j - paramInt]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void doUpFilter(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/* 327 */     int i = paramArrayOfbyte1.length;
/* 328 */     for (int j = 0; j != i; j++) {
/* 329 */       paramArrayOfbyte1[j] = (byte)(paramArrayOfbyte1[j] + paramArrayOfbyte2[j]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void doAvrgFilter(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt) {
/* 334 */     int i = paramArrayOfbyte1.length; int j;
/* 335 */     for (j = 0; j != paramInt; j++) {
/* 336 */       paramArrayOfbyte1[j] = (byte)(paramArrayOfbyte1[j] + (paramArrayOfbyte2[j] & 0xFF) / 2);
/*     */     }
/* 338 */     for (j = paramInt; j != i; j++) {
/* 339 */       paramArrayOfbyte1[j] = (byte)(paramArrayOfbyte1[j] + ((paramArrayOfbyte1[j - paramInt] & 0xFF) + (paramArrayOfbyte2[j] & 0xFF)) / 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int paethPr(int paramInt1, int paramInt2, int paramInt3) {
/* 346 */     int i = Math.abs(paramInt2 - paramInt3);
/* 347 */     int j = Math.abs(paramInt1 - paramInt3);
/* 348 */     int k = Math.abs(paramInt2 - paramInt3 + paramInt1 - paramInt3);
/* 349 */     return (i <= j && i <= k) ? paramInt1 : ((j <= k) ? paramInt2 : paramInt3);
/*     */   }
/*     */   
/*     */   private void doPaethFilter(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt) {
/* 353 */     int i = paramArrayOfbyte1.length; int j;
/* 354 */     for (j = 0; j != paramInt; j++) {
/* 355 */       paramArrayOfbyte1[j] = (byte)(paramArrayOfbyte1[j] + paramArrayOfbyte2[j]);
/*     */     }
/* 357 */     for (j = paramInt; j != i; j++) {
/* 358 */       paramArrayOfbyte1[j] = 
/* 359 */         (byte)(paramArrayOfbyte1[j] + paethPr(paramArrayOfbyte1[j - paramInt] & 0xFF, paramArrayOfbyte2[j] & 0xFF, paramArrayOfbyte2[j - paramInt] & 0xFF));
/*     */     }
/*     */   }
/*     */   
/*     */   private void doFilter(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) {
/* 364 */     switch (paramInt1) {
/*     */       case 1:
/* 366 */         doSubFilter(paramArrayOfbyte1, paramInt2);
/*     */         break;
/*     */       case 2:
/* 369 */         doUpFilter(paramArrayOfbyte1, paramArrayOfbyte2);
/*     */         break;
/*     */       case 3:
/* 372 */         doAvrgFilter(paramArrayOfbyte1, paramArrayOfbyte2, paramInt2);
/*     */         break;
/*     */       case 4:
/* 375 */         doPaethFilter(paramArrayOfbyte1, paramArrayOfbyte2, paramInt2);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void downsample16to8trns_gray(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) {
/* 381 */     int i = paramArrayOfbyte1.length / 2; byte b; int j;
/* 382 */     for (b = 0, j = paramInt1; b < i; j += paramInt2 * 2, b++) {
/* 383 */       short s = (short)((paramArrayOfbyte1[b * 2] & 0xFF) * 256 + (paramArrayOfbyte1[b * 2 + 1] & 0xFF));
/* 384 */       paramArrayOfbyte2[j + 0] = paramArrayOfbyte1[b * 2];
/* 385 */       paramArrayOfbyte2[j + 1] = (s == this.trnsG) ? 0 : -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void downsample16to8trns_rgb(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) {
/* 390 */     int i = paramArrayOfbyte1.length / 2 / 3; byte b; int j;
/* 391 */     for (b = 0, j = paramInt1; b < i; j += paramInt2 * 4, b++) {
/* 392 */       int k = b * 6;
/* 393 */       short s1 = (short)((paramArrayOfbyte1[k + 0] & 0xFF) * 256 + (paramArrayOfbyte1[k + 1] & 0xFF));
/* 394 */       short s2 = (short)((paramArrayOfbyte1[k + 2] & 0xFF) * 256 + (paramArrayOfbyte1[k + 3] & 0xFF));
/* 395 */       short s3 = (short)((paramArrayOfbyte1[k + 4] & 0xFF) * 256 + (paramArrayOfbyte1[k + 5] & 0xFF));
/* 396 */       paramArrayOfbyte2[j + 0] = paramArrayOfbyte1[k + 0];
/* 397 */       paramArrayOfbyte2[j + 1] = paramArrayOfbyte1[k + 2];
/* 398 */       paramArrayOfbyte2[j + 2] = paramArrayOfbyte1[k + 4];
/* 399 */       paramArrayOfbyte2[j + 3] = (
/* 400 */         s1 == this.trnsR && s2 == this.trnsG && s3 == this.trnsB) ? 0 : -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void downsample16to8_plain(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2, int paramInt3) {
/* 405 */     int i = paramArrayOfbyte1.length / 2 / paramInt3 * paramInt3, j = paramInt2 * paramInt3; int k, m;
/* 406 */     for (k = 0, m = paramInt1; k != i; m += j, k += paramInt3) {
/* 407 */       for (int n = 0; n != paramInt3; n++) {
/* 408 */         paramArrayOfbyte2[m + n] = paramArrayOfbyte1[(k + n) * 2];
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void downsample16to8(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2, int paramInt3) {
/* 414 */     if (!this.tRNS_GRAY_RGB) {
/* 415 */       downsample16to8_plain(paramArrayOfbyte1, paramArrayOfbyte2, paramInt1, paramInt2, paramInt3);
/* 416 */     } else if (this.colorType == 0) {
/* 417 */       downsample16to8trns_gray(paramArrayOfbyte1, paramArrayOfbyte2, paramInt1, paramInt2);
/* 418 */     } else if (this.colorType == 2) {
/* 419 */       downsample16to8trns_rgb(paramArrayOfbyte1, paramArrayOfbyte2, paramInt1, paramInt2);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copyTrns_gray(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) {
/* 424 */     byte b = (byte)this.trnsG; byte b1; int i, j;
/* 425 */     for (b1 = 0, i = paramInt1, j = paramArrayOfbyte1.length; b1 < j; i += 2 * paramInt2, b1++) {
/* 426 */       byte b2 = paramArrayOfbyte1[b1];
/* 427 */       paramArrayOfbyte2[i] = b2;
/* 428 */       paramArrayOfbyte2[i + 1] = (b2 == b) ? 0 : -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copyTrns_rgb(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) {
/* 433 */     byte b1 = (byte)this.trnsR, b2 = (byte)this.trnsG, b3 = (byte)this.trnsB;
/* 434 */     int i = paramArrayOfbyte1.length / 3; byte b; int j;
/* 435 */     for (b = 0, j = paramInt1; b < i; j += paramInt2 * 4, b++) {
/* 436 */       byte b4 = paramArrayOfbyte1[b * 3], b5 = paramArrayOfbyte1[b * 3 + 1], b6 = paramArrayOfbyte1[b * 3 + 2];
/* 437 */       paramArrayOfbyte2[j + 0] = b4;
/* 438 */       paramArrayOfbyte2[j + 1] = b5;
/* 439 */       paramArrayOfbyte2[j + 2] = b6;
/* 440 */       paramArrayOfbyte2[j + 3] = (b4 == b1 && b5 == b2 && b6 == b3) ? 0 : -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copy_plain(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2, int paramInt3) {
/* 445 */     int i = paramArrayOfbyte1.length, j = paramInt2 * paramInt3; int k, m;
/* 446 */     for (k = 0, m = paramInt1; k != i; m += j, k += paramInt3) {
/* 447 */       for (int n = 0; n != paramInt3; n++) {
/* 448 */         paramArrayOfbyte2[m + n] = paramArrayOfbyte1[k + n];
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copy(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2, int paramInt3) {
/* 454 */     if (!this.tRNS_GRAY_RGB) {
/* 455 */       if (paramInt2 == 1) {
/* 456 */         System.arraycopy(paramArrayOfbyte1, 0, paramArrayOfbyte2, paramInt1, paramArrayOfbyte1.length);
/*     */       } else {
/* 458 */         copy_plain(paramArrayOfbyte1, paramArrayOfbyte2, paramInt1, paramInt2, paramInt3);
/*     */       } 
/* 460 */     } else if (this.colorType == 0) {
/* 461 */       copyTrns_gray(paramArrayOfbyte1, paramArrayOfbyte2, paramInt1, paramInt2);
/* 462 */     } else if (this.colorType == 2) {
/* 463 */       copyTrns_rgb(paramArrayOfbyte1, paramArrayOfbyte2, paramInt1, paramInt2);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void upsampleTo8Palette(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2, int paramInt3) {
/* 468 */     int i = 8 / this.bitDepth;
/* 469 */     int j = (1 << this.bitDepth) - 1; int k; byte b;
/* 470 */     for (k = 0, b = 0; k < paramInt2; b++, k += i) {
/* 471 */       int m = (paramInt2 - k < i) ? (paramInt2 - k) : i;
/* 472 */       int n = paramArrayOfbyte1[b] >> (i - m) * this.bitDepth;
/* 473 */       for (int i1 = m - 1; i1 >= 0; i1--) {
/* 474 */         paramArrayOfbyte2[paramInt1 + (k + i1) * paramInt3] = (byte)(n & j);
/* 475 */         n >>= this.bitDepth;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void upsampleTo8Gray(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2, int paramInt3) {
/* 481 */     int i = 8 / this.bitDepth;
/* 482 */     int j = (1 << this.bitDepth) - 1, k = j / 2; int m; byte b;
/* 483 */     for (m = 0, b = 0; m < paramInt2; b++, m += i) {
/* 484 */       int n = (paramInt2 - m < i) ? (paramInt2 - m) : i;
/* 485 */       int i1 = paramArrayOfbyte1[b] >> (i - n) * this.bitDepth;
/* 486 */       for (int i2 = n - 1; i2 >= 0; i2--) {
/* 487 */         paramArrayOfbyte2[paramInt1 + (m + i2) * paramInt3] = (byte)(((i1 & j) * 255 + k) / j);
/* 488 */         i1 >>= this.bitDepth;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void upsampleTo8GrayTrns(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2, int paramInt3) {
/* 494 */     int i = 8 / this.bitDepth;
/* 495 */     int j = (1 << this.bitDepth) - 1, k = j / 2; int m; byte b;
/* 496 */     for (m = 0, b = 0; m < paramInt2; b++, m += i) {
/* 497 */       int n = (paramInt2 - m < i) ? (paramInt2 - m) : i;
/* 498 */       int i1 = paramArrayOfbyte1[b] >> (i - n) * this.bitDepth;
/* 499 */       for (int i2 = n - 1; i2 >= 0; i2--) {
/* 500 */         int i3 = paramInt1 + (m + i2) * paramInt3 * 2;
/* 501 */         int i4 = i1 & j;
/* 502 */         paramArrayOfbyte2[i3] = (byte)((i4 * 255 + k) / j);
/* 503 */         paramArrayOfbyte2[i3 + 1] = (i4 == this.trnsG) ? 0 : -1;
/* 504 */         i1 >>= this.bitDepth;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void upsampleTo8(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 510 */     if (this.colorType == 3) {
/* 511 */       upsampleTo8Palette(paramArrayOfbyte1, paramArrayOfbyte2, paramInt1, paramInt2, paramInt3);
/* 512 */     } else if (paramInt4 == 1) {
/* 513 */       upsampleTo8Gray(paramArrayOfbyte1, paramArrayOfbyte2, paramInt1, paramInt2, paramInt3);
/* 514 */     } else if (this.tRNS_GRAY_RGB && paramInt4 == 2) {
/* 515 */       upsampleTo8GrayTrns(paramArrayOfbyte1, paramArrayOfbyte2, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */   
/* 519 */   private static final int[] starting_y = new int[] { 0, 0, 4, 0, 2, 0, 1, 0 };
/* 520 */   private static final int[] starting_x = new int[] { 0, 4, 0, 2, 0, 1, 0, 0 };
/* 521 */   private static final int[] increment_y = new int[] { 8, 8, 8, 4, 4, 2, 2, 1 };
/* 522 */   private static final int[] increment_x = new int[] { 8, 8, 4, 4, 2, 2, 1, 1 };
/*     */   
/*     */   private static int mipSize(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
/* 525 */     return (paramInt1 - paramArrayOfint1[paramInt2] + paramArrayOfint2[paramInt2] - 1) / paramArrayOfint2[paramInt2];
/*     */   }
/*     */   
/*     */   private static int mipPos(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
/* 529 */     return paramArrayOfint1[paramInt2] + paramInt1 * paramArrayOfint2[paramInt2];
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadMip(byte[] paramArrayOfbyte, InputStream paramInputStream, int paramInt) throws IOException {
/* 534 */     int i = mipSize(this.width, paramInt, starting_x, increment_x);
/* 535 */     int j = mipSize(this.height, paramInt, starting_y, increment_y);
/*     */     
/* 537 */     int k = (i * this.bitDepth * numBandsPerColorType[this.colorType] + 7) / 8;
/* 538 */     byte[] arrayOfByte1 = new byte[k];
/* 539 */     byte[] arrayOfByte2 = new byte[k];
/*     */ 
/*     */ 
/*     */     
/* 543 */     int m = bpp(), n = numBandsPerColorType[this.colorType] * bytesPerColor();
/*     */     
/* 545 */     for (int i1 = 0; i1 != j; i1++) {
/* 546 */       int i2 = paramInputStream.read();
/* 547 */       if (i2 == -1) {
/* 548 */         throw new EOFException();
/*     */       }
/*     */       
/* 551 */       if (paramInputStream.read(arrayOfByte1) != k) {
/* 552 */         throw new EOFException();
/*     */       }
/*     */       
/* 555 */       doFilter(arrayOfByte1, arrayOfByte2, i2, n);
/*     */       
/* 557 */       int i3 = (mipPos(i1, paramInt, starting_y, increment_y) * this.width + starting_x[paramInt]) * m;
/* 558 */       int i4 = increment_x[paramInt];
/*     */       
/* 560 */       if (this.bitDepth == 16) {
/* 561 */         downsample16to8(arrayOfByte1, paramArrayOfbyte, i3, i4, m);
/* 562 */       } else if (this.bitDepth < 8) {
/* 563 */         upsampleTo8(arrayOfByte1, paramArrayOfbyte, i3, i, i4, m);
/*     */       } else {
/* 565 */         copy(arrayOfByte1, paramArrayOfbyte, i3, i4, m);
/*     */       } 
/*     */       
/* 568 */       byte[] arrayOfByte = arrayOfByte1;
/* 569 */       arrayOfByte1 = arrayOfByte2;
/* 570 */       arrayOfByte2 = arrayOfByte;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void load(byte[] paramArrayOfbyte, InputStream paramInputStream) throws IOException {
/* 575 */     if (this.isInterlaced) {
/* 576 */       for (byte b = 0; b != 7; b++) {
/* 577 */         if (this.width > starting_x[b] && this.height > starting_y[b]) {
/* 578 */           loadMip(paramArrayOfbyte, paramInputStream, b);
/*     */         }
/*     */       } 
/*     */     } else {
/* 582 */       loadMip(paramArrayOfbyte, paramInputStream, 7);
/*     */     } 
/*     */   }
/*     */   
/*     */   private ImageFrame decodePalette(byte[] paramArrayOfbyte, ImageMetadata paramImageMetadata) {
/* 587 */     byte b = this.tRNS_present ? 4 : 3;
/* 588 */     byte[] arrayOfByte = new byte[this.width * this.height * b];
/* 589 */     int i = this.width * this.height;
/*     */     
/* 591 */     if (this.tRNS_present) {
/* 592 */       int j; byte b1; for (j = 0, b1 = 0; j != i; b1 += 4, j++) {
/* 593 */         int k = 0xFF & paramArrayOfbyte[j];
/* 594 */         arrayOfByte[b1 + 0] = this.palette[0][k];
/* 595 */         arrayOfByte[b1 + 1] = this.palette[1][k];
/* 596 */         arrayOfByte[b1 + 2] = this.palette[2][k];
/* 597 */         arrayOfByte[b1 + 3] = this.palette[3][k];
/*     */       } 
/*     */     } else {
/* 600 */       int j; byte b1; for (j = 0, b1 = 0; j != i; b1 += 3, j++) {
/* 601 */         int k = 0xFF & paramArrayOfbyte[j];
/* 602 */         arrayOfByte[b1 + 0] = this.palette[0][k];
/* 603 */         arrayOfByte[b1 + 1] = this.palette[1][k];
/* 604 */         arrayOfByte[b1 + 2] = this.palette[2][k];
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 610 */     ImageStorage.ImageType imageType = this.tRNS_present ? ImageStorage.ImageType.RGBA : ImageStorage.ImageType.RGB;
/*     */     
/* 612 */     return new ImageFrame(imageType, ByteBuffer.wrap(arrayOfByte), this.width, this.height, this.width * b, null, paramImageMetadata);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int bpp() {
/* 622 */     return numBandsPerColorType[this.colorType] + (this.tRNS_GRAY_RGB ? 1 : 0);
/*     */   }
/*     */   
/*     */   private int bytesPerColor() {
/* 626 */     return (this.bitDepth == 16) ? 2 : 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageFrame load(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2) throws IOException {
/* 632 */     if (paramInt1 != 0) {
/* 633 */       return null;
/*     */     }
/*     */     
/* 636 */     int i = parsePngMeta();
/*     */     
/* 638 */     if (i == 0) {
/* 639 */       emitWarning("No image data in PNG");
/* 640 */       return null;
/*     */     } 
/*     */     
/* 643 */     int[] arrayOfInt = ImageTools.computeDimensions(this.width, this.height, paramInt2, paramInt3, paramBoolean1);
/* 644 */     paramInt2 = arrayOfInt[0];
/* 645 */     paramInt3 = arrayOfInt[1];
/*     */ 
/*     */     
/* 648 */     ImageMetadata imageMetadata = new ImageMetadata(null, Boolean.valueOf(true), null, null, null, null, null, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), null, null, null);
/* 649 */     updateImageMetadata(imageMetadata);
/*     */     
/* 651 */     int j = bpp();
/* 652 */     ByteBuffer byteBuffer = ByteBuffer.allocate(j * this.width * this.height);
/*     */     
/* 654 */     PNGIDATChunkInputStream pNGIDATChunkInputStream = new PNGIDATChunkInputStream(this.stream, i);
/* 655 */     Inflater inflater = new Inflater();
/* 656 */     BufferedInputStream bufferedInputStream = new BufferedInputStream(new InflaterInputStream(pNGIDATChunkInputStream, inflater));
/*     */     
/*     */     try {
/* 659 */       load(byteBuffer.array(), bufferedInputStream);
/* 660 */     } catch (IOException iOException) {
/* 661 */       throw iOException;
/*     */     } finally {
/* 663 */       if (inflater != null) {
/* 664 */         inflater.end();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 670 */     ImageFrame imageFrame = (this.colorType == 3) ? decodePalette(byteBuffer.array(), imageMetadata) : new ImageFrame(getType(), byteBuffer, this.width, this.height, j * this.width, this.palette, imageMetadata);
/*     */     
/* 672 */     if (this.width != paramInt2 || this.height != paramInt3) {
/* 673 */       imageFrame = ImageTools.scaleImageFrame(imageFrame, paramInt2, paramInt3, paramBoolean2);
/*     */     }
/*     */     
/* 676 */     return imageFrame;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\png\PNGImageLoader2.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */