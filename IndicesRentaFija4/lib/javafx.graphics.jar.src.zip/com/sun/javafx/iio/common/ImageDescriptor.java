/*    */ package com.sun.javafx.iio.common;
/*    */ 
/*    */ import com.sun.javafx.iio.ImageFormatDescription;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageDescriptor
/*    */   implements ImageFormatDescription
/*    */ {
/*    */   private final String formatName;
/*    */   private final List<String> extensions;
/*    */   private final List<ImageFormatDescription.Signature> signatures;
/*    */   
/*    */   public ImageDescriptor(String paramString, String[] paramArrayOfString, ImageFormatDescription.Signature[] paramArrayOfSignature) {
/* 40 */     this.formatName = paramString;
/* 41 */     this.extensions = Collections.unmodifiableList(
/* 42 */         Arrays.asList(paramArrayOfString));
/* 43 */     this.signatures = Collections.unmodifiableList(
/* 44 */         Arrays.asList(paramArrayOfSignature));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getFormatName() {
/* 49 */     return this.formatName;
/*    */   }
/*    */   
/*    */   public List<String> getExtensions() {
/* 53 */     return this.extensions;
/*    */   }
/*    */   
/*    */   public List<ImageFormatDescription.Signature> getSignatures() {
/* 57 */     return this.signatures;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\common\ImageDescriptor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */