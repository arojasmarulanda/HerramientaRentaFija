/*     */ package com.sun.javafx.iio.common;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SmoothMinifier
/*     */   implements PushbroomScaler
/*     */ {
/*     */   protected int sourceWidth;
/*     */   protected int sourceHeight;
/*     */   protected int numBands;
/*     */   protected int destWidth;
/*     */   protected int destHeight;
/*     */   protected double scaleY;
/*     */   protected ByteBuffer destBuf;
/*     */   protected int boxHeight;
/*     */   protected byte[][] sourceData;
/*     */   protected int[] leftPoints;
/*     */   protected int[] rightPoints;
/*     */   protected int[] topPoints;
/*     */   protected int[] bottomPoints;
/*     */   protected int sourceLine;
/*     */   protected int sourceDataLine;
/*     */   protected int destLine;
/*     */   protected int[] tmpBuf;
/*     */   
/*     */   SmoothMinifier(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  89 */     if (paramInt1 <= 0 || paramInt2 <= 0 || paramInt3 <= 0 || paramInt4 <= 0 || paramInt5 <= 0 || paramInt4 > paramInt1 || paramInt5 > paramInt2)
/*     */     {
/*     */       
/*  92 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/*  96 */     this.sourceWidth = paramInt1;
/*  97 */     this.sourceHeight = paramInt2;
/*  98 */     this.numBands = paramInt3;
/*  99 */     this.destWidth = paramInt4;
/* 100 */     this.destHeight = paramInt5;
/*     */ 
/*     */     
/* 103 */     this.destBuf = ByteBuffer.wrap(new byte[paramInt5 * paramInt4 * paramInt3]);
/*     */ 
/*     */     
/* 106 */     double d = paramInt1 / paramInt4;
/* 107 */     this.scaleY = paramInt2 / paramInt5;
/*     */ 
/*     */     
/* 110 */     int i = (paramInt1 + paramInt4 - 1) / paramInt4;
/* 111 */     this.boxHeight = (paramInt2 + paramInt5 - 1) / paramInt5;
/*     */ 
/*     */ 
/*     */     
/* 115 */     int j = i / 2;
/* 116 */     int k = i - j - 1;
/* 117 */     int m = this.boxHeight / 2;
/* 118 */     int n = this.boxHeight - m - 1;
/*     */ 
/*     */     
/* 121 */     this.sourceData = new byte[this.boxHeight][paramInt4 * paramInt3];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     this.leftPoints = new int[paramInt4];
/* 127 */     this.rightPoints = new int[paramInt4]; byte b;
/* 128 */     for (b = 0; b < paramInt4; b++) {
/* 129 */       int i1 = (int)(b * d);
/* 130 */       this.leftPoints[b] = i1 - j;
/* 131 */       this.rightPoints[b] = i1 + k;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     this.topPoints = new int[paramInt5];
/* 138 */     this.bottomPoints = new int[paramInt5];
/* 139 */     for (b = 0; b < paramInt5; b++) {
/* 140 */       int i1 = (int)(b * this.scaleY);
/* 141 */       this.topPoints[b] = i1 - m;
/* 142 */       this.bottomPoints[b] = i1 + n;
/*     */     } 
/*     */ 
/*     */     
/* 146 */     this.sourceLine = 0;
/* 147 */     this.sourceDataLine = 0;
/* 148 */     this.destLine = 0;
/*     */     
/* 150 */     this.tmpBuf = new int[paramInt4 * paramInt3];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getDestination() {
/* 159 */     return this.destBuf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean putSourceScanline(byte[] paramArrayOfbyte, int paramInt) {
/* 172 */     if (paramInt < 0) {
/* 173 */       throw new IllegalArgumentException("off < 0!");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     if (this.numBands == 1) {
/* 184 */       int i = paramArrayOfbyte[paramInt] & 0xFF;
/* 185 */       int j = paramArrayOfbyte[paramInt + this.sourceWidth - 1] & 0xFF;
/* 186 */       for (byte b = 0; b < this.destWidth; b++) {
/* 187 */         int k = 0;
/* 188 */         int m = this.rightPoints[b];
/* 189 */         for (int n = this.leftPoints[b]; n <= m; n++) {
/* 190 */           if (n < 0) {
/* 191 */             k += i;
/* 192 */           } else if (n >= this.sourceWidth) {
/* 193 */             k += j;
/*     */           } else {
/* 195 */             k += paramArrayOfbyte[paramInt + n] & 0xFF;
/*     */           } 
/*     */         } 
/* 198 */         k /= m - this.leftPoints[b] + 1;
/* 199 */         this.sourceData[this.sourceDataLine][b] = (byte)k;
/*     */       } 
/*     */     } else {
/* 202 */       int i = paramInt + (this.sourceWidth - 1) * this.numBands;
/* 203 */       for (byte b = 0; b < this.destWidth; b++) {
/* 204 */         int j = this.leftPoints[b];
/* 205 */         int k = this.rightPoints[b];
/* 206 */         int m = k - j + 1;
/* 207 */         int n = b * this.numBands;
/* 208 */         for (byte b1 = 0; b1 < this.numBands; b1++) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 213 */           int i1 = paramArrayOfbyte[paramInt + b1] & 0xFF;
/* 214 */           int i2 = paramArrayOfbyte[i + b1] & 0xFF;
/*     */           
/* 216 */           int i3 = 0;
/* 217 */           for (int i4 = j; i4 <= k; i4++) {
/* 218 */             if (i4 < 0) {
/* 219 */               i3 += i1;
/* 220 */             } else if (i4 >= this.sourceWidth) {
/* 221 */               i3 += i2;
/*     */             } else {
/* 223 */               i3 += paramArrayOfbyte[paramInt + i4 * this.numBands + b1] & 0xFF;
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 231 */           i3 /= m;
/* 232 */           this.sourceData[this.sourceDataLine][n + b1] = (byte)i3;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     if (this.sourceLine == this.bottomPoints[this.destLine] || (this.destLine == this.destHeight - 1 && this.sourceLine == this.sourceHeight - 1)) {
/*     */ 
/*     */ 
/*     */       
/* 246 */       assert this.destBuf.hasArray() : "destBuf.hasArray() == false => destBuf is direct";
/* 247 */       byte[] arrayOfByte = this.destBuf.array();
/*     */       
/* 249 */       int i = this.destLine * this.destWidth * this.numBands;
/* 250 */       Arrays.fill(this.tmpBuf, 0); int j;
/* 251 */       for (j = this.topPoints[this.destLine]; j <= this.bottomPoints[this.destLine]; j++) {
/* 252 */         int k = 0;
/* 253 */         if (j < 0) {
/* 254 */           k = 0 - this.sourceLine + this.sourceDataLine;
/* 255 */         } else if (j >= this.sourceHeight) {
/* 256 */           k = (this.sourceHeight - 1 - this.sourceLine + this.sourceDataLine) % this.boxHeight;
/*     */         } else {
/* 258 */           k = (j - this.sourceLine + this.sourceDataLine) % this.boxHeight;
/*     */         } 
/* 260 */         if (k < 0) {
/* 261 */           k += this.boxHeight;
/*     */         }
/* 263 */         byte[] arrayOfByte1 = this.sourceData[k];
/* 264 */         int m = arrayOfByte1.length;
/* 265 */         for (byte b1 = 0; b1 < m; b1++) {
/* 266 */           this.tmpBuf[b1] = this.tmpBuf[b1] + (arrayOfByte1[b1] & 0xFF);
/*     */         }
/*     */       } 
/* 269 */       j = this.tmpBuf.length;
/* 270 */       for (byte b = 0; b < j; b++) {
/* 271 */         arrayOfByte[i + b] = (byte)(this.tmpBuf[b] / this.boxHeight);
/*     */       }
/*     */       
/* 274 */       if (this.destLine < this.destHeight - 1) {
/* 275 */         this.destLine++;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 280 */     if (++this.sourceLine != this.sourceHeight) {
/* 281 */       this.sourceDataLine = (this.sourceDataLine + 1) % this.boxHeight;
/*     */     }
/*     */     
/* 284 */     return (this.destLine == this.destHeight);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\common\SmoothMinifier.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */