/*    */ package com.sun.javafx.iio.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScalerFactory
/*    */ {
/*    */   public static PushbroomScaler createScaler(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean) {
/* 46 */     if (paramInt1 <= 0 || paramInt2 <= 0 || paramInt3 <= 0 || paramInt4 <= 0 || paramInt5 <= 0)
/*    */     {
/* 48 */       throw new IllegalArgumentException();
/*    */     }
/*    */     
/* 51 */     RoughScaler roughScaler = null;
/*    */     
/* 53 */     boolean bool = (paramInt4 > paramInt1 || paramInt5 > paramInt2) ? true : false;
/*    */     
/* 55 */     if (bool) {
/* 56 */       if (paramBoolean) {
/*    */ 
/*    */         
/* 59 */         roughScaler = new RoughScaler(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*    */       } else {
/*    */         
/* 62 */         roughScaler = new RoughScaler(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*    */       }
/*    */     
/*    */     }
/* 66 */     else if (paramBoolean) {
/* 67 */       SmoothMinifier smoothMinifier = new SmoothMinifier(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*    */     } else {
/*    */       
/* 70 */       roughScaler = new RoughScaler(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 75 */     return roughScaler;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\common\ScalerFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */