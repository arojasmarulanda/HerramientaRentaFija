/*    */ package com.sun.javafx.iio.common;
/*    */ 
/*    */ import com.sun.javafx.iio.ImageFormatDescription;
/*    */ import com.sun.javafx.iio.ImageLoadListener;
/*    */ import com.sun.javafx.iio.ImageLoader;
/*    */ import com.sun.javafx.iio.ImageMetadata;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ImageLoaderImpl
/*    */   implements ImageLoader
/*    */ {
/*    */   protected ImageFormatDescription formatDescription;
/*    */   protected HashSet<ImageLoadListener> listeners;
/* 39 */   protected int lastPercentDone = -1;
/*    */   
/*    */   protected ImageLoaderImpl(ImageFormatDescription paramImageFormatDescription) {
/* 42 */     if (paramImageFormatDescription == null) {
/* 43 */       throw new IllegalArgumentException("formatDescription == null!");
/*    */     }
/*    */     
/* 46 */     this.formatDescription = paramImageFormatDescription;
/*    */   }
/*    */   
/*    */   public final ImageFormatDescription getFormatDescription() {
/* 50 */     return this.formatDescription;
/*    */   }
/*    */   
/*    */   public final void addListener(ImageLoadListener paramImageLoadListener) {
/* 54 */     if (this.listeners == null) {
/* 55 */       this.listeners = new HashSet<>();
/*    */     }
/* 57 */     this.listeners.add(paramImageLoadListener);
/*    */   }
/*    */   
/*    */   public final void removeListener(ImageLoadListener paramImageLoadListener) {
/* 61 */     if (this.listeners != null) {
/* 62 */       this.listeners.remove(paramImageLoadListener);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void emitWarning(String paramString) {
/* 67 */     if (this.listeners != null && !this.listeners.isEmpty()) {
/* 68 */       Iterator<ImageLoadListener> iterator = this.listeners.iterator();
/* 69 */       while (iterator.hasNext()) {
/* 70 */         ImageLoadListener imageLoadListener = iterator.next();
/* 71 */         imageLoadListener.imageLoadWarning(this, paramString);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void updateImageProgress(float paramFloat) {
/* 77 */     if (this.listeners != null && !this.listeners.isEmpty()) {
/* 78 */       int i = (int)paramFloat;
/* 79 */       byte b = 5;
/* 80 */       if (b * i / b % b == 0 && i != this.lastPercentDone) {
/* 81 */         this.lastPercentDone = i;
/* 82 */         Iterator<ImageLoadListener> iterator = this.listeners.iterator();
/* 83 */         while (iterator.hasNext()) {
/* 84 */           ImageLoadListener imageLoadListener = iterator.next();
/* 85 */           imageLoadListener.imageLoadProgress(this, i);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void updateImageMetadata(ImageMetadata paramImageMetadata) {
/* 92 */     if (this.listeners != null && !this.listeners.isEmpty()) {
/* 93 */       Iterator<ImageLoadListener> iterator = this.listeners.iterator();
/* 94 */       while (iterator.hasNext()) {
/* 95 */         ImageLoadListener imageLoadListener = iterator.next();
/* 96 */         imageLoadListener.imageLoadMetaData(this, paramImageMetadata);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\common\ImageLoaderImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */