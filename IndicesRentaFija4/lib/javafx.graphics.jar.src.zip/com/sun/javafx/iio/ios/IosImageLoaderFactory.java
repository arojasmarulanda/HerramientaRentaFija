/*    */ package com.sun.javafx.iio.ios;
/*    */ 
/*    */ import com.sun.javafx.iio.ImageFormatDescription;
/*    */ import com.sun.javafx.iio.ImageLoader;
/*    */ import com.sun.javafx.iio.ImageLoaderFactory;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IosImageLoaderFactory
/*    */   implements ImageLoaderFactory
/*    */ {
/*    */   private static IosImageLoaderFactory theInstance;
/*    */   
/*    */   public static final synchronized IosImageLoaderFactory getInstance() {
/* 50 */     if (theInstance == null) {
/* 51 */       theInstance = new IosImageLoaderFactory();
/*    */     }
/* 53 */     return theInstance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImageFormatDescription getFormatDescription() {
/* 60 */     return IosDescriptor.getInstance();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImageLoader createImageLoader(InputStream paramInputStream) throws IOException {
/* 67 */     return new IosImageLoader(paramInputStream, IosDescriptor.getInstance());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ImageLoader createImageLoader(String paramString) throws IOException {
/* 78 */     return new IosImageLoader(paramString, IosDescriptor.getInstance());
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\ios\IosImageLoaderFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */