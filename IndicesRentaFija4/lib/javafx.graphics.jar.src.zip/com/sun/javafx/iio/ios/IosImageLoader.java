/*     */ package com.sun.javafx.iio.ios;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import com.sun.javafx.iio.ImageFrame;
/*     */ import com.sun.javafx.iio.ImageMetadata;
/*     */ import com.sun.javafx.iio.ImageStorage;
/*     */ import com.sun.javafx.iio.common.ImageDescriptor;
/*     */ import com.sun.javafx.iio.common.ImageLoaderImpl;
/*     */ import com.sun.javafx.iio.common.ImageTools;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.AccessController;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IosImageLoader
/*     */   extends ImageLoaderImpl
/*     */ {
/*     */   public static final int GRAY = 0;
/*     */   public static final int GRAY_ALPHA = 1;
/*     */   public static final int GRAY_ALPHA_PRE = 2;
/*     */   public static final int PALETTE = 3;
/*     */   public static final int PALETTE_ALPHA = 4;
/*     */   public static final int PALETTE_ALPHA_PRE = 5;
/*     */   public static final int PALETTE_TRANS = 6;
/*     */   public static final int RGB = 7;
/*     */   public static final int RGBA = 8;
/*     */   public static final int RGBA_PRE = 9;
/*  65 */   private static final Map<Integer, ImageStorage.ImageType> colorSpaceMapping = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long structPointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int inWidth;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int inHeight;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int nImages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isDisposed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int delayTime;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int loopCount;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 113 */     AccessController.doPrivileged(() -> {
/*     */           NativeLibLoader.loadLibrary("nativeiio");
/*     */           
/*     */           return null;
/*     */         });
/* 118 */     colorSpaceMapping.put(Integer.valueOf(0), ImageStorage.ImageType.GRAY);
/* 119 */     colorSpaceMapping.put(Integer.valueOf(1), ImageStorage.ImageType.GRAY_ALPHA);
/* 120 */     colorSpaceMapping.put(Integer.valueOf(2), ImageStorage.ImageType.GRAY_ALPHA_PRE);
/* 121 */     colorSpaceMapping.put(Integer.valueOf(3), ImageStorage.ImageType.PALETTE);
/* 122 */     colorSpaceMapping.put(Integer.valueOf(4), ImageStorage.ImageType.PALETTE_ALPHA);
/* 123 */     colorSpaceMapping.put(Integer.valueOf(5), ImageStorage.ImageType.PALETTE_ALPHA_PRE);
/* 124 */     colorSpaceMapping.put(Integer.valueOf(6), ImageStorage.ImageType.PALETTE_TRANS);
/* 125 */     colorSpaceMapping.put(Integer.valueOf(7), ImageStorage.ImageType.RGB);
/* 126 */     colorSpaceMapping.put(Integer.valueOf(8), ImageStorage.ImageType.RGBA);
/* 127 */     colorSpaceMapping.put(Integer.valueOf(9), ImageStorage.ImageType.RGBA_PRE);
/*     */     
/* 129 */     initNativeLoading();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setInputParameters(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 139 */     this.inWidth = paramInt1;
/* 140 */     this.inHeight = paramInt2;
/* 141 */     this.nImages = paramInt3;
/* 142 */     this.loopCount = paramInt4;
/*     */   }
/*     */   
/*     */   private void updateProgress(float paramFloat) {
/* 146 */     updateImageProgress(paramFloat);
/*     */   }
/*     */   
/*     */   private boolean shouldReportProgress() {
/* 150 */     return (this.listeners != null && !this.listeners.isEmpty());
/*     */   }
/*     */   
/*     */   private void checkNativePointer() throws IOException {
/* 154 */     if (this.structPointer == 0L) {
/* 155 */       throw new IOException("Unable to initialize image native loader!");
/*     */     }
/*     */   }
/*     */   
/*     */   private void retrieveDelayTime() {
/* 160 */     if (this.nImages > 1) {
/* 161 */       this.delayTime = getDelayTime(this.structPointer);
/*     */     }
/*     */   }
/*     */   
/*     */   public IosImageLoader(String paramString, ImageDescriptor paramImageDescriptor) throws IOException {
/* 166 */     super(paramImageDescriptor);
/*     */ 
/*     */     
/*     */     try {
/* 170 */       URL uRL = new URL(paramString);
/*     */     }
/* 172 */     catch (MalformedURLException malformedURLException) {
/* 173 */       throw new IllegalArgumentException("Image loader: Malformed URL!");
/*     */     } 
/*     */     
/*     */     try {
/* 177 */       this.structPointer = loadImageFromURL(paramString, shouldReportProgress());
/* 178 */     } catch (IOException iOException) {
/* 179 */       dispose();
/* 180 */       throw iOException;
/*     */     } 
/*     */     
/* 183 */     checkNativePointer();
/* 184 */     retrieveDelayTime();
/*     */   }
/*     */   
/*     */   public IosImageLoader(InputStream paramInputStream, ImageDescriptor paramImageDescriptor) throws IOException {
/* 188 */     super(paramImageDescriptor);
/* 189 */     if (paramInputStream == null) {
/* 190 */       throw new IllegalArgumentException("Image loader: input stream == null");
/*     */     }
/*     */     
/*     */     try {
/* 194 */       this.structPointer = loadImage(paramInputStream, shouldReportProgress());
/* 195 */     } catch (IOException iOException) {
/* 196 */       dispose();
/* 197 */       throw iOException;
/*     */     } 
/*     */     
/* 200 */     checkNativePointer();
/* 201 */     retrieveDelayTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void dispose() {
/* 208 */     if (!this.isDisposed && this.structPointer != 0L) {
/* 209 */       this.isDisposed = true;
/* 210 */       disposeLoader(this.structPointer);
/* 211 */       this.structPointer = 0L;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void finalize() {
/* 216 */     dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageFrame load(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2) throws IOException {
/* 225 */     if (paramInt1 >= this.nImages) {
/* 226 */       dispose();
/* 227 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 231 */     int[] arrayOfInt = ImageTools.computeDimensions(this.inWidth, this.inHeight, paramInt2, paramInt3, paramBoolean1);
/* 232 */     paramInt2 = arrayOfInt[0];
/* 233 */     paramInt3 = arrayOfInt[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 244 */     ImageMetadata imageMetadata = new ImageMetadata(null, Boolean.valueOf(true), null, null, null, (this.delayTime == 0) ? null : Integer.valueOf(this.delayTime), (this.nImages > 1) ? Integer.valueOf(this.loopCount) : null, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), null, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     updateImageMetadata(imageMetadata);
/*     */     
/* 251 */     resizeImage(this.structPointer, paramInt2, paramInt3);
/*     */ 
/*     */     
/* 254 */     int i = getNumberOfComponents(this.structPointer);
/* 255 */     int j = getColorSpaceCode(this.structPointer);
/* 256 */     ImageStorage.ImageType imageType = colorSpaceMapping.get(Integer.valueOf(j));
/*     */     
/* 258 */     byte[] arrayOfByte = getImageBuffer(this.structPointer, paramInt1);
/*     */     
/* 260 */     return new ImageFrame(imageType, 
/* 261 */         ByteBuffer.wrap(arrayOfByte), paramInt2, paramInt3, paramInt2 * i, null, imageMetadata);
/*     */   }
/*     */   
/*     */   private static native void initNativeLoading();
/*     */   
/*     */   private native long loadImage(InputStream paramInputStream, boolean paramBoolean) throws IOException;
/*     */   
/*     */   private native long loadImageFromURL(String paramString, boolean paramBoolean) throws IOException;
/*     */   
/*     */   private native void resizeImage(long paramLong, int paramInt1, int paramInt2);
/*     */   
/*     */   private native byte[] getImageBuffer(long paramLong, int paramInt);
/*     */   
/*     */   private native int getNumberOfComponents(long paramLong);
/*     */   
/*     */   private native int getColorSpaceCode(long paramLong);
/*     */   
/*     */   private native int getDelayTime(long paramLong);
/*     */   
/*     */   private static native void disposeLoader(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\ios\IosImageLoader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */