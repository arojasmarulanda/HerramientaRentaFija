/*    */ package com.sun.javafx.iio.ios;
/*    */ 
/*    */ import com.sun.javafx.iio.ImageFormatDescription;
/*    */ import com.sun.javafx.iio.common.ImageDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IosDescriptor
/*    */   extends ImageDescriptor
/*    */ {
/*    */   private static final String formatName = "PNGorJPEGorBMP";
/* 36 */   private static final String[] extensions = new String[] { "bmp", "png", "jpg", "jpeg", "gif" };
/*    */   
/* 38 */   private static final ImageFormatDescription.Signature[] signatures = new ImageFormatDescription.Signature[] { new ImageFormatDescription.Signature(new byte[] { -1, -40 }), new ImageFormatDescription.Signature(new byte[] { -119, 80, 78, 71, 13, 10, 26, 10 }), new ImageFormatDescription.Signature(new byte[] { 66, 77 }), new ImageFormatDescription.Signature(new byte[] { 71, 73, 70, 56, 55, 97 }), new ImageFormatDescription.Signature(new byte[] { 71, 73, 70, 56, 57, 97 }) };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   private static ImageDescriptor theInstance = null;
/*    */   
/*    */   private IosDescriptor() {
/* 54 */     super("PNGorJPEGorBMP", extensions, signatures);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static synchronized ImageDescriptor getInstance() {
/* 63 */     if (theInstance == null) {
/* 64 */       theInstance = new IosDescriptor();
/*    */     }
/* 66 */     return theInstance;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\iio\ios\IosDescriptor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */