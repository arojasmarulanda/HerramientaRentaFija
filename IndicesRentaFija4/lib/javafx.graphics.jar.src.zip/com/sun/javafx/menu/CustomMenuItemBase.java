package com.sun.javafx.menu;

public interface CustomMenuItemBase extends MenuItemBase {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\menu\CustomMenuItemBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */