package com.sun.javafx.menu;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.input.KeyCombination;

public interface MenuItemBase {
  void setId(String paramString);
  
  String getId();
  
  StringProperty idProperty();
  
  void setText(String paramString);
  
  String getText();
  
  StringProperty textProperty();
  
  void setGraphic(Node paramNode);
  
  Node getGraphic();
  
  ObjectProperty<Node> graphicProperty();
  
  void setOnAction(EventHandler<ActionEvent> paramEventHandler);
  
  EventHandler<ActionEvent> getOnAction();
  
  ObjectProperty<EventHandler<ActionEvent>> onActionProperty();
  
  void setDisable(boolean paramBoolean);
  
  boolean isDisable();
  
  BooleanProperty disableProperty();
  
  void setVisible(boolean paramBoolean);
  
  boolean isVisible();
  
  BooleanProperty visibleProperty();
  
  void setAccelerator(KeyCombination paramKeyCombination);
  
  KeyCombination getAccelerator();
  
  ObjectProperty<KeyCombination> acceleratorProperty();
  
  void setMnemonicParsing(boolean paramBoolean);
  
  boolean isMnemonicParsing();
  
  BooleanProperty mnemonicParsingProperty();
  
  void fire();
  
  void fireValidation();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\menu\MenuItemBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */