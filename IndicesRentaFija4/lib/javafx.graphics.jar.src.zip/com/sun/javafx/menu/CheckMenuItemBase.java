package com.sun.javafx.menu;

import javafx.beans.property.BooleanProperty;

public interface CheckMenuItemBase extends MenuItemBase {
  void setSelected(boolean paramBoolean);
  
  boolean isSelected();
  
  BooleanProperty selectedProperty();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\menu\CheckMenuItemBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */