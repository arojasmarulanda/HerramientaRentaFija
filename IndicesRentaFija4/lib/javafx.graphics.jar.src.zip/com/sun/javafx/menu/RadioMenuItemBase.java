package com.sun.javafx.menu;

import javafx.beans.property.BooleanProperty;

public interface RadioMenuItemBase extends MenuItemBase {
  void setSelected(boolean paramBoolean);
  
  boolean isSelected();
  
  BooleanProperty selectedProperty();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.graphics.jar!\com\sun\javafx\menu\RadioMenuItemBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */