package javax.activation;

import java.io.IOException;

public interface CommandObject {
  void setCommandContext(String paramString, DataHandler paramDataHandler) throws IOException;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\activation-1.1.1.jar!\javax\activation\CommandObject.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */