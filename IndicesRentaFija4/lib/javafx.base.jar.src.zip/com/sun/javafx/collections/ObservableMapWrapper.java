/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.collections.ObservableMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObservableMapWrapper<K, V>
/*     */   implements ObservableMap<K, V>
/*     */ {
/*     */   private ObservableEntrySet entrySet;
/*     */   private ObservableKeySet keySet;
/*     */   private ObservableValues values;
/*     */   private MapListenerHelper<K, V> listenerHelper;
/*     */   private final Map<K, V> backingMap;
/*     */   
/*     */   public ObservableMapWrapper(Map<K, V> paramMap) {
/*  50 */     this.backingMap = paramMap;
/*     */   }
/*     */   
/*     */   private class SimpleChange
/*     */     extends MapChangeListener.Change<K, V> {
/*     */     private final K key;
/*     */     private final V old;
/*     */     private final V added;
/*     */     private final boolean wasAdded;
/*     */     private final boolean wasRemoved;
/*     */     
/*     */     public SimpleChange(K param1K, V param1V1, V param1V2, boolean param1Boolean1, boolean param1Boolean2) {
/*  62 */       super(ObservableMapWrapper.this);
/*  63 */       assert param1Boolean1 || param1Boolean2;
/*  64 */       this.key = param1K;
/*  65 */       this.old = param1V1;
/*  66 */       this.added = param1V2;
/*  67 */       this.wasAdded = param1Boolean1;
/*  68 */       this.wasRemoved = param1Boolean2;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean wasAdded() {
/*  73 */       return this.wasAdded;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean wasRemoved() {
/*  78 */       return this.wasRemoved;
/*     */     }
/*     */ 
/*     */     
/*     */     public K getKey() {
/*  83 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public V getValueAdded() {
/*  88 */       return this.added;
/*     */     }
/*     */ 
/*     */     
/*     */     public V getValueRemoved() {
/*  93 */       return this.old;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  98 */       StringBuilder stringBuilder = new StringBuilder();
/*  99 */       if (this.wasAdded) {
/* 100 */         if (this.wasRemoved) {
/* 101 */           stringBuilder.append(this.old).append(" replaced by ").append(this.added);
/*     */         } else {
/* 103 */           stringBuilder.append(this.added).append(" added");
/*     */         } 
/*     */       } else {
/* 106 */         stringBuilder.append(this.old).append(" removed");
/*     */       } 
/* 108 */       stringBuilder.append(" at key ").append(this.key);
/* 109 */       return stringBuilder.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void callObservers(MapChangeListener.Change<K, V> paramChange) {
/* 115 */     MapListenerHelper.fireValueChangedEvent(this.listenerHelper, paramChange);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(InvalidationListener paramInvalidationListener) {
/* 120 */     this.listenerHelper = MapListenerHelper.addListener(this.listenerHelper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(InvalidationListener paramInvalidationListener) {
/* 125 */     this.listenerHelper = MapListenerHelper.removeListener(this.listenerHelper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener) {
/* 130 */     this.listenerHelper = MapListenerHelper.addListener(this.listenerHelper, paramMapChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener) {
/* 135 */     this.listenerHelper = MapListenerHelper.removeListener(this.listenerHelper, paramMapChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 140 */     return this.backingMap.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 145 */     return this.backingMap.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object paramObject) {
/* 150 */     return this.backingMap.containsKey(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object paramObject) {
/* 155 */     return this.backingMap.containsValue(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public V get(Object paramObject) {
/* 160 */     return this.backingMap.get(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public V put(K paramK, V paramV) {
/*     */     V v;
/* 166 */     if (this.backingMap.containsKey(paramK)) {
/* 167 */       V v1 = this.backingMap.put(paramK, paramV);
/* 168 */       if ((v1 == null && paramV != null) || (v1 != null && !v1.equals(paramV))) {
/* 169 */         callObservers(new SimpleChange(paramK, v1, paramV, true, true));
/*     */       }
/*     */     } else {
/* 172 */       v = this.backingMap.put(paramK, paramV);
/* 173 */       callObservers(new SimpleChange(paramK, v, paramV, true, false));
/*     */     } 
/* 175 */     return v;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V remove(Object paramObject) {
/* 181 */     if (!this.backingMap.containsKey(paramObject)) {
/* 182 */       return null;
/*     */     }
/* 184 */     V v = this.backingMap.remove(paramObject);
/* 185 */     callObservers(new SimpleChange((K)paramObject, v, null, false, true));
/* 186 */     return v;
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> paramMap) {
/* 191 */     for (Map.Entry<? extends K, ? extends V> entry : paramMap.entrySet()) {
/* 192 */       put((K)entry.getKey(), (V)entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 198 */     for (Iterator<Map.Entry> iterator = this.backingMap.entrySet().iterator(); iterator.hasNext(); ) {
/* 199 */       Map.Entry entry = iterator.next();
/* 200 */       Object object1 = entry.getKey();
/* 201 */       Object object2 = entry.getValue();
/* 202 */       iterator.remove();
/* 203 */       callObservers(new SimpleChange((K)object1, (V)object2, null, false, true));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 209 */     if (this.keySet == null) {
/* 210 */       this.keySet = new ObservableKeySet();
/*     */     }
/* 212 */     return this.keySet;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 217 */     if (this.values == null) {
/* 218 */       this.values = new ObservableValues();
/*     */     }
/* 220 */     return this.values;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 225 */     if (this.entrySet == null) {
/* 226 */       this.entrySet = new ObservableEntrySet();
/*     */     }
/* 228 */     return this.entrySet;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 233 */     return this.backingMap.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 238 */     return this.backingMap.equals(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 243 */     return this.backingMap.hashCode();
/*     */   }
/*     */   
/*     */   private class ObservableKeySet implements Set<K> {
/*     */     private ObservableKeySet() {}
/*     */     
/*     */     public int size() {
/* 250 */       return ObservableMapWrapper.this.backingMap.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 255 */       return ObservableMapWrapper.this.backingMap.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object param1Object) {
/* 260 */       return ObservableMapWrapper.this.backingMap.keySet().contains(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<K> iterator() {
/* 265 */       return new Iterator<K>()
/*     */         {
/* 267 */           private Iterator<Map.Entry<K, V>> entryIt = ObservableMapWrapper.this.backingMap.entrySet().iterator();
/*     */           private K lastKey;
/*     */           private V lastValue;
/*     */           
/*     */           public boolean hasNext() {
/* 272 */             return this.entryIt.hasNext();
/*     */           }
/*     */ 
/*     */           
/*     */           public K next() {
/* 277 */             Map.Entry entry = this.entryIt.next();
/* 278 */             this.lastKey = (K)entry.getKey();
/* 279 */             this.lastValue = (V)entry.getValue();
/* 280 */             return (K)entry.getKey();
/*     */           }
/*     */ 
/*     */           
/*     */           public void remove() {
/* 285 */             this.entryIt.remove();
/* 286 */             ObservableMapWrapper.this.callObservers(new ObservableMapWrapper.SimpleChange(this.lastKey, this.lastValue, null, false, true));
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object[] toArray() {
/* 294 */       return ObservableMapWrapper.this.backingMap.keySet().toArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T[] toArray(T[] param1ArrayOfT) {
/* 299 */       return (T[])ObservableMapWrapper.this.backingMap.keySet().toArray((Object[])param1ArrayOfT);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(K param1K) {
/* 304 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean remove(Object param1Object) {
/* 309 */       return (ObservableMapWrapper.this.remove(param1Object) != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection<?> param1Collection) {
/* 314 */       return ObservableMapWrapper.this.backingMap.keySet().containsAll(param1Collection);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends K> param1Collection) {
/* 319 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> param1Collection) {
/* 324 */       return removeRetain(param1Collection, false);
/*     */     }
/*     */     
/*     */     private boolean removeRetain(Collection<?> param1Collection, boolean param1Boolean) {
/* 328 */       boolean bool = false;
/* 329 */       for (Iterator<Map.Entry> iterator = ObservableMapWrapper.this.backingMap.entrySet().iterator(); iterator.hasNext(); ) {
/* 330 */         Map.Entry entry = iterator.next();
/* 331 */         if (param1Boolean == param1Collection.contains(entry.getKey())) {
/* 332 */           bool = true;
/* 333 */           Object object1 = entry.getKey();
/* 334 */           Object object2 = entry.getValue();
/* 335 */           iterator.remove();
/* 336 */           ObservableMapWrapper.this.callObservers(new ObservableMapWrapper.SimpleChange((K)object1, (V)object2, null, false, true));
/*     */         } 
/*     */       } 
/* 339 */       return bool;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> param1Collection) {
/* 344 */       return removeRetain(param1Collection, true);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 349 */       ObservableMapWrapper.this.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 354 */       return ObservableMapWrapper.this.backingMap.keySet().toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 359 */       return ObservableMapWrapper.this.backingMap.keySet().equals(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 364 */       return ObservableMapWrapper.this.backingMap.keySet().hashCode();
/*     */     }
/*     */   }
/*     */   
/*     */   private class ObservableValues
/*     */     implements Collection<V> {
/*     */     private ObservableValues() {}
/*     */     
/*     */     public int size() {
/* 373 */       return ObservableMapWrapper.this.backingMap.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 378 */       return ObservableMapWrapper.this.backingMap.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object param1Object) {
/* 383 */       return ObservableMapWrapper.this.backingMap.values().contains(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<V> iterator() {
/* 388 */       return new Iterator<V>()
/*     */         {
/* 390 */           private Iterator<Map.Entry<K, V>> entryIt = ObservableMapWrapper.this.backingMap.entrySet().iterator();
/*     */           private K lastKey;
/*     */           private V lastValue;
/*     */           
/*     */           public boolean hasNext() {
/* 395 */             return this.entryIt.hasNext();
/*     */           }
/*     */ 
/*     */           
/*     */           public V next() {
/* 400 */             Map.Entry entry = this.entryIt.next();
/* 401 */             this.lastKey = (K)entry.getKey();
/* 402 */             this.lastValue = (V)entry.getValue();
/* 403 */             return this.lastValue;
/*     */           }
/*     */ 
/*     */           
/*     */           public void remove() {
/* 408 */             this.entryIt.remove();
/* 409 */             ObservableMapWrapper.this.callObservers(new ObservableMapWrapper.SimpleChange(this.lastKey, this.lastValue, null, false, true));
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object[] toArray() {
/* 417 */       return ObservableMapWrapper.this.backingMap.values().toArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T[] toArray(T[] param1ArrayOfT) {
/* 422 */       return (T[])ObservableMapWrapper.this.backingMap.values().toArray((Object[])param1ArrayOfT);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(V param1V) {
/* 427 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean remove(Object param1Object) {
/* 432 */       for (Iterator<V> iterator = iterator(); iterator.hasNext();) {
/* 433 */         if (iterator.next().equals(param1Object)) {
/* 434 */           iterator.remove();
/* 435 */           return true;
/*     */         } 
/*     */       } 
/* 438 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection<?> param1Collection) {
/* 443 */       return ObservableMapWrapper.this.backingMap.values().containsAll(param1Collection);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends V> param1Collection) {
/* 448 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> param1Collection) {
/* 453 */       return removeRetain(param1Collection, true);
/*     */     }
/*     */     
/*     */     private boolean removeRetain(Collection<?> param1Collection, boolean param1Boolean) {
/* 457 */       boolean bool = false;
/* 458 */       for (Iterator<Map.Entry> iterator = ObservableMapWrapper.this.backingMap.entrySet().iterator(); iterator.hasNext(); ) {
/* 459 */         Map.Entry entry = iterator.next();
/* 460 */         if (param1Boolean == param1Collection.contains(entry.getValue())) {
/* 461 */           bool = true;
/* 462 */           Object object1 = entry.getKey();
/* 463 */           Object object2 = entry.getValue();
/* 464 */           iterator.remove();
/* 465 */           ObservableMapWrapper.this.callObservers(new ObservableMapWrapper.SimpleChange((K)object1, (V)object2, null, false, true));
/*     */         } 
/*     */       } 
/* 468 */       return bool;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> param1Collection) {
/* 473 */       return removeRetain(param1Collection, false);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 478 */       ObservableMapWrapper.this.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 483 */       return ObservableMapWrapper.this.backingMap.values().toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 488 */       return ObservableMapWrapper.this.backingMap.values().equals(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 493 */       return ObservableMapWrapper.this.backingMap.values().hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class ObservableEntry
/*     */     implements Map.Entry<K, V>
/*     */   {
/*     */     private final Map.Entry<K, V> backingEntry;
/*     */ 
/*     */     
/*     */     public ObservableEntry(Map.Entry<K, V> param1Entry) {
/* 506 */       this.backingEntry = param1Entry;
/*     */     }
/*     */ 
/*     */     
/*     */     public K getKey() {
/* 511 */       return this.backingEntry.getKey();
/*     */     }
/*     */ 
/*     */     
/*     */     public V getValue() {
/* 516 */       return this.backingEntry.getValue();
/*     */     }
/*     */ 
/*     */     
/*     */     public V setValue(V param1V) {
/* 521 */       V v = this.backingEntry.setValue(param1V);
/* 522 */       ObservableMapWrapper.this.callObservers(new ObservableMapWrapper.SimpleChange(getKey(), v, param1V, true, true));
/* 523 */       return v;
/*     */     }
/*     */ 
/*     */     
/*     */     public final boolean equals(Object param1Object) {
/* 528 */       if (!(param1Object instanceof Map.Entry)) {
/* 529 */         return false;
/*     */       }
/* 531 */       Map.Entry entry = (Map.Entry)param1Object;
/* 532 */       K k = getKey();
/* 533 */       Object object = entry.getKey();
/* 534 */       if (k == object || (k != null && k.equals(object))) {
/* 535 */         V v = getValue();
/* 536 */         Object object1 = entry.getValue();
/* 537 */         if (v == object1 || (v != null && v.equals(object1))) {
/* 538 */           return true;
/*     */         }
/*     */       } 
/* 541 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public final int hashCode() {
/* 546 */       return ((getKey() == null) ? 0 : getKey().hashCode()) ^ (
/* 547 */         (getValue() == null) ? 0 : getValue().hashCode());
/*     */     }
/*     */ 
/*     */     
/*     */     public final String toString() {
/* 552 */       return "" + getKey() + "=" + getKey();
/*     */     }
/*     */   }
/*     */   
/*     */   private class ObservableEntrySet
/*     */     implements Set<Map.Entry<K, V>> {
/*     */     private ObservableEntrySet() {}
/*     */     
/*     */     public int size() {
/* 561 */       return ObservableMapWrapper.this.backingMap.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 566 */       return ObservableMapWrapper.this.backingMap.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object param1Object) {
/* 571 */       return ObservableMapWrapper.this.backingMap.entrySet().contains(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Map.Entry<K, V>> iterator() {
/* 576 */       return new Iterator<Map.Entry<K, V>>()
/*     */         {
/* 578 */           private Iterator<Map.Entry<K, V>> backingIt = ObservableMapWrapper.this.backingMap.entrySet().iterator();
/*     */           private K lastKey;
/*     */           private V lastValue;
/*     */           
/*     */           public boolean hasNext() {
/* 583 */             return this.backingIt.hasNext();
/*     */           }
/*     */ 
/*     */           
/*     */           public Map.Entry<K, V> next() {
/* 588 */             Map.Entry<K, V> entry = this.backingIt.next();
/* 589 */             this.lastKey = (K)entry.getKey();
/* 590 */             this.lastValue = (V)entry.getValue();
/* 591 */             return new ObservableMapWrapper.ObservableEntry(entry);
/*     */           }
/*     */ 
/*     */           
/*     */           public void remove() {
/* 596 */             this.backingIt.remove();
/* 597 */             ObservableMapWrapper.this.callObservers(new ObservableMapWrapper.SimpleChange(this.lastKey, this.lastValue, null, false, true));
/*     */           }
/*     */         };
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object[] toArray() {
/* 605 */       Object[] arrayOfObject = ObservableMapWrapper.this.backingMap.entrySet().toArray();
/* 606 */       for (byte b = 0; b < arrayOfObject.length; b++) {
/* 607 */         arrayOfObject[b] = new ObservableMapWrapper.ObservableEntry((Map.Entry<K, V>)arrayOfObject[b]);
/*     */       }
/* 609 */       return arrayOfObject;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> T[] toArray(T[] param1ArrayOfT) {
/* 615 */       Object[] arrayOfObject = ObservableMapWrapper.this.backingMap.entrySet().toArray((Object[])param1ArrayOfT);
/* 616 */       for (byte b = 0; b < arrayOfObject.length; b++) {
/* 617 */         arrayOfObject[b] = new ObservableMapWrapper.ObservableEntry((Map.Entry<K, V>)arrayOfObject[b]);
/*     */       }
/* 619 */       return (T[])arrayOfObject;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(Map.Entry<K, V> param1Entry) {
/* 624 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean remove(Object param1Object) {
/* 630 */       boolean bool = ObservableMapWrapper.this.backingMap.entrySet().remove(param1Object);
/* 631 */       if (bool) {
/* 632 */         Map.Entry entry = (Map.Entry)param1Object;
/* 633 */         ObservableMapWrapper.this.callObservers(new ObservableMapWrapper.SimpleChange((K)entry.getKey(), (V)entry.getValue(), null, false, true));
/*     */       } 
/* 635 */       return bool;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection<?> param1Collection) {
/* 640 */       return ObservableMapWrapper.this.backingMap.entrySet().containsAll(param1Collection);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends Map.Entry<K, V>> param1Collection) {
/* 645 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> param1Collection) {
/* 650 */       return removeRetain(param1Collection, false);
/*     */     }
/*     */     
/*     */     private boolean removeRetain(Collection<?> param1Collection, boolean param1Boolean) {
/* 654 */       boolean bool = false;
/* 655 */       for (Iterator<Map.Entry> iterator = ObservableMapWrapper.this.backingMap.entrySet().iterator(); iterator.hasNext(); ) {
/* 656 */         Map.Entry entry = iterator.next();
/* 657 */         if (param1Boolean == param1Collection.contains(entry)) {
/* 658 */           bool = true;
/* 659 */           Object object1 = entry.getKey();
/* 660 */           Object object2 = entry.getValue();
/* 661 */           iterator.remove();
/* 662 */           ObservableMapWrapper.this.callObservers(new ObservableMapWrapper.SimpleChange((K)object1, (V)object2, null, false, true));
/*     */         } 
/*     */       } 
/* 665 */       return bool;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> param1Collection) {
/* 670 */       return removeRetain(param1Collection, true);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 675 */       ObservableMapWrapper.this.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 680 */       return ObservableMapWrapper.this.backingMap.entrySet().toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 685 */       return ObservableMapWrapper.this.backingMap.entrySet().equals(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 690 */       return ObservableMapWrapper.this.backingMap.entrySet().hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\collections\ObservableMapWrapper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */