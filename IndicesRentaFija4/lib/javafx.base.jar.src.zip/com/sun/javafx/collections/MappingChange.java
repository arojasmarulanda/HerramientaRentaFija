/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import java.util.AbstractList;
/*     */ import java.util.List;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MappingChange<E, F>
/*     */   extends ListChangeListener.Change<F>
/*     */ {
/*     */   private final Map<E, F> map;
/*     */   private final ListChangeListener.Change<? extends E> original;
/*     */   private List<F> removed;
/*     */   
/*  38 */   public static final Map NOOP_MAP = new Map<Object, Object>()
/*     */     {
/*     */       public Object map(Object param1Object)
/*     */       {
/*  42 */         return param1Object;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingChange(ListChangeListener.Change<? extends E> paramChange, Map<E, F> paramMap, ObservableList<F> paramObservableList) {
/*  51 */     super(paramObservableList);
/*  52 */     this.original = paramChange;
/*  53 */     this.map = paramMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean next() {
/*  58 */     return this.original.next();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  63 */     this.original.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFrom() {
/*  68 */     return this.original.getFrom();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTo() {
/*  73 */     return this.original.getTo();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<F> getRemoved() {
/*  78 */     if (this.removed == null) {
/*  79 */       this.removed = new AbstractList<F>()
/*     */         {
/*     */           public F get(int param1Int)
/*     */           {
/*  83 */             return (F)MappingChange.this.map.map(MappingChange.this.original.getRemoved().get(param1Int));
/*     */           }
/*     */ 
/*     */           
/*     */           public int size() {
/*  88 */             return MappingChange.this.original.getRemovedSize();
/*     */           }
/*     */         };
/*     */     }
/*  92 */     return this.removed;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int[] getPermutation() {
/*  97 */     return new int[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean wasPermutated() {
/* 102 */     return this.original.wasPermutated();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean wasUpdated() {
/* 107 */     return this.original.wasUpdated();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPermutation(int paramInt) {
/* 112 */     return this.original.getPermutation(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 120 */     byte b1 = 0;
/* 121 */     while (next()) {
/* 122 */       b1++;
/*     */     }
/*     */     
/* 125 */     byte b2 = 0;
/* 126 */     reset();
/* 127 */     while (next()) {
/* 128 */       b2++;
/*     */     }
/* 130 */     reset();
/* 131 */     StringBuilder stringBuilder = new StringBuilder();
/* 132 */     stringBuilder.append("{ ");
/* 133 */     int i = 0;
/* 134 */     while (next()) {
/* 135 */       if (wasPermutated()) {
/* 136 */         stringBuilder.append(ChangeHelper.permChangeToString(getPermutation()));
/* 137 */       } else if (wasUpdated()) {
/* 138 */         stringBuilder.append(ChangeHelper.updateChangeToString(getFrom(), getTo()));
/*     */       } else {
/* 140 */         stringBuilder.append(ChangeHelper.addRemoveChangeToString(getFrom(), getTo(), getList(), getRemoved()));
/*     */       } 
/* 142 */       if (i != b2) {
/* 143 */         stringBuilder.append(", ");
/*     */       }
/*     */     } 
/* 146 */     stringBuilder.append(" }");
/*     */     
/* 148 */     reset();
/* 149 */     i = b2 - b1;
/* 150 */     while (i-- > 0) {
/* 151 */       next();
/*     */     }
/*     */     
/* 154 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   public static interface Map<E, F> {
/*     */     F map(E param1E);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\collections\MappingChange.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */