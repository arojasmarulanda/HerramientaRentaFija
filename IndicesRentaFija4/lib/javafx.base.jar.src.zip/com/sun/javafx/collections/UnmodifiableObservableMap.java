/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.collections.WeakMapChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnmodifiableObservableMap<K, V>
/*     */   extends AbstractMap<K, V>
/*     */   implements ObservableMap<K, V>
/*     */ {
/*     */   private MapListenerHelper<K, V> listenerHelper;
/*     */   private final ObservableMap<K, V> backingMap;
/*     */   private final MapChangeListener<K, V> listener;
/*     */   private Set<K> keyset;
/*     */   private Collection<V> values;
/*     */   private Set<Map.Entry<K, V>> entryset;
/*     */   
/*     */   public UnmodifiableObservableMap(ObservableMap<K, V> paramObservableMap) {
/*  56 */     this.backingMap = paramObservableMap;
/*  57 */     this.listener = (paramChange -> callObservers(new MapAdapterChange<>(this, paramChange)));
/*     */ 
/*     */     
/*  60 */     this.backingMap.addListener(new WeakMapChangeListener<>(this.listener));
/*     */   }
/*     */   
/*     */   private void callObservers(MapChangeListener.Change<? extends K, ? extends V> paramChange) {
/*  64 */     MapListenerHelper.fireValueChangedEvent(this.listenerHelper, paramChange);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(InvalidationListener paramInvalidationListener) {
/*  69 */     this.listenerHelper = MapListenerHelper.addListener(this.listenerHelper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(InvalidationListener paramInvalidationListener) {
/*  74 */     this.listenerHelper = MapListenerHelper.removeListener(this.listenerHelper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener) {
/*  79 */     this.listenerHelper = MapListenerHelper.addListener(this.listenerHelper, paramMapChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener) {
/*  84 */     this.listenerHelper = MapListenerHelper.removeListener(this.listenerHelper, paramMapChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  89 */     return this.backingMap.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  94 */     return this.backingMap.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object paramObject) {
/*  99 */     return this.backingMap.containsKey(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object paramObject) {
/* 104 */     return this.backingMap.containsValue(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public V get(Object paramObject) {
/* 109 */     return this.backingMap.get(paramObject);
/*     */   }
/*     */   
/*     */   public Set<K> keySet() {
/* 113 */     if (this.keyset == null) {
/* 114 */       this.keyset = Collections.unmodifiableSet(this.backingMap.keySet());
/*     */     }
/* 116 */     return this.keyset;
/*     */   }
/*     */   
/*     */   public Collection<V> values() {
/* 120 */     if (this.values == null) {
/* 121 */       this.values = Collections.unmodifiableCollection(this.backingMap.values());
/*     */     }
/* 123 */     return this.values;
/*     */   }
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 127 */     if (this.entryset == null) {
/* 128 */       this.entryset = Collections.<K, V>unmodifiableMap(this.backingMap).entrySet();
/*     */     }
/* 130 */     return this.entryset;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\collections\UnmodifiableObservableMap.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */