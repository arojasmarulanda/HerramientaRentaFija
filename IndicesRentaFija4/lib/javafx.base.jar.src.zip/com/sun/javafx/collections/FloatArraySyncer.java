package com.sun.javafx.collections;

public interface FloatArraySyncer {
  float[] syncTo(float[] paramArrayOffloat, int[] paramArrayOfint);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\collections\FloatArraySyncer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */