/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import com.sun.javafx.binding.ExpressionHelperBase;
/*     */ import java.util.Arrays;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.ArrayChangeListener;
/*     */ import javafx.collections.ObservableArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ArrayListenerHelper<T extends ObservableArray<T>>
/*     */   extends ExpressionHelperBase
/*     */ {
/*     */   protected final T observable;
/*     */   
/*     */   public static <T extends ObservableArray<T>> ArrayListenerHelper addListener(ArrayListenerHelper paramArrayListenerHelper, T paramT, InvalidationListener paramInvalidationListener) {
/*  42 */     if (paramInvalidationListener == null) {
/*  43 */       throw new NullPointerException();
/*     */     }
/*  45 */     return (paramArrayListenerHelper == null) ? new SingleInvalidation<>((ObservableArray)paramT, paramInvalidationListener) : paramArrayListenerHelper.addListener(paramInvalidationListener);
/*     */   }
/*     */   
/*     */   public static ArrayListenerHelper removeListener(ArrayListenerHelper paramArrayListenerHelper, InvalidationListener paramInvalidationListener) {
/*  49 */     if (paramInvalidationListener == null) {
/*  50 */       throw new NullPointerException();
/*     */     }
/*  52 */     return (paramArrayListenerHelper == null) ? null : paramArrayListenerHelper.removeListener(paramInvalidationListener);
/*     */   }
/*     */   
/*     */   public static <T extends ObservableArray<T>> ArrayListenerHelper addListener(ArrayListenerHelper paramArrayListenerHelper, T paramT, ArrayChangeListener paramArrayChangeListener) {
/*  56 */     if (paramArrayChangeListener == null) {
/*  57 */       throw new NullPointerException();
/*     */     }
/*  59 */     return (paramArrayListenerHelper == null) ? new SingleChange<>((ObservableArray)paramT, paramArrayChangeListener) : paramArrayListenerHelper.addListener(paramArrayChangeListener);
/*     */   }
/*     */   
/*     */   public static ArrayListenerHelper removeListener(ArrayListenerHelper paramArrayListenerHelper, ArrayChangeListener paramArrayChangeListener) {
/*  63 */     if (paramArrayChangeListener == null) {
/*  64 */       throw new NullPointerException();
/*     */     }
/*  66 */     return (paramArrayListenerHelper == null) ? null : paramArrayListenerHelper.removeListener(paramArrayChangeListener);
/*     */   }
/*     */   
/*     */   public static void fireValueChangedEvent(ArrayListenerHelper paramArrayListenerHelper, boolean paramBoolean, int paramInt1, int paramInt2) {
/*  70 */     if (paramArrayListenerHelper != null && (paramInt1 < paramInt2 || paramBoolean)) {
/*  71 */       paramArrayListenerHelper.fireValueChangedEvent(paramBoolean, paramInt1, paramInt2);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean hasListeners(ArrayListenerHelper paramArrayListenerHelper) {
/*  76 */     return (paramArrayListenerHelper != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayListenerHelper(T paramT) {
/*  85 */     this.observable = paramT;
/*     */   }
/*     */   
/*     */   protected abstract ArrayListenerHelper addListener(InvalidationListener paramInvalidationListener);
/*     */   
/*     */   protected abstract ArrayListenerHelper removeListener(InvalidationListener paramInvalidationListener);
/*     */   
/*     */   protected abstract ArrayListenerHelper addListener(ArrayChangeListener<T> paramArrayChangeListener);
/*     */   
/*     */   protected abstract ArrayListenerHelper removeListener(ArrayChangeListener<T> paramArrayChangeListener);
/*     */   
/*     */   protected abstract void fireValueChangedEvent(boolean paramBoolean, int paramInt1, int paramInt2);
/*     */   
/*     */   private static class SingleInvalidation<T extends ObservableArray<T>>
/*     */     extends ArrayListenerHelper<T>
/*     */   {
/*     */     private final InvalidationListener listener;
/*     */     
/*     */     private SingleInvalidation(T param1T, InvalidationListener param1InvalidationListener) {
/* 104 */       super(param1T);
/* 105 */       this.listener = param1InvalidationListener;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper addListener(InvalidationListener param1InvalidationListener) {
/* 110 */       return new ArrayListenerHelper.Generic<>((ObservableArray)this.observable, this.listener, param1InvalidationListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper removeListener(InvalidationListener param1InvalidationListener) {
/* 115 */       return param1InvalidationListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper addListener(ArrayChangeListener param1ArrayChangeListener) {
/* 120 */       return new ArrayListenerHelper.Generic<>((ObservableArray)this.observable, this.listener, param1ArrayChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper removeListener(ArrayChangeListener param1ArrayChangeListener) {
/* 125 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(boolean param1Boolean, int param1Int1, int param1Int2) {
/*     */       try {
/* 131 */         this.listener.invalidated((Observable)this.observable);
/* 132 */       } catch (Exception exception) {
/* 133 */         Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SingleChange<T extends ObservableArray<T>>
/*     */     extends ArrayListenerHelper<T> {
/*     */     private final ArrayChangeListener listener;
/*     */     
/*     */     private SingleChange(T param1T, ArrayChangeListener param1ArrayChangeListener) {
/* 143 */       super(param1T);
/* 144 */       this.listener = param1ArrayChangeListener;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper addListener(InvalidationListener param1InvalidationListener) {
/* 149 */       return new ArrayListenerHelper.Generic<>((ObservableArray)this.observable, param1InvalidationListener, this.listener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper removeListener(InvalidationListener param1InvalidationListener) {
/* 154 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper addListener(ArrayChangeListener param1ArrayChangeListener) {
/* 159 */       return new ArrayListenerHelper.Generic<>((ObservableArray)this.observable, this.listener, param1ArrayChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper removeListener(ArrayChangeListener param1ArrayChangeListener) {
/* 164 */       return param1ArrayChangeListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(boolean param1Boolean, int param1Int1, int param1Int2) {
/*     */       try {
/* 170 */         this.listener.onChanged(this.observable, param1Boolean, param1Int1, param1Int2);
/* 171 */       } catch (Exception exception) {
/* 172 */         Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Generic<T extends ObservableArray<T>>
/*     */     extends ArrayListenerHelper<T> {
/*     */     private InvalidationListener[] invalidationListeners;
/*     */     private ArrayChangeListener[] changeListeners;
/*     */     private int invalidationSize;
/*     */     private int changeSize;
/*     */     private boolean locked;
/*     */     
/*     */     private Generic(T param1T, InvalidationListener param1InvalidationListener1, InvalidationListener param1InvalidationListener2) {
/* 186 */       super(param1T);
/* 187 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener1, param1InvalidationListener2 };
/* 188 */       this.invalidationSize = 2;
/*     */     }
/*     */     
/*     */     private Generic(T param1T, ArrayChangeListener param1ArrayChangeListener1, ArrayChangeListener param1ArrayChangeListener2) {
/* 192 */       super(param1T);
/* 193 */       this.changeListeners = new ArrayChangeListener[] { param1ArrayChangeListener1, param1ArrayChangeListener2 };
/* 194 */       this.changeSize = 2;
/*     */     }
/*     */     
/*     */     private Generic(T param1T, InvalidationListener param1InvalidationListener, ArrayChangeListener param1ArrayChangeListener) {
/* 198 */       super(param1T);
/* 199 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 200 */       this.invalidationSize = 1;
/* 201 */       this.changeListeners = new ArrayChangeListener[] { param1ArrayChangeListener };
/* 202 */       this.changeSize = 1;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Generic addListener(InvalidationListener param1InvalidationListener) {
/* 207 */       if (this.invalidationListeners == null) {
/* 208 */         this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 209 */         this.invalidationSize = 1;
/*     */       } else {
/* 211 */         int i = this.invalidationListeners.length;
/* 212 */         if (this.locked) {
/* 213 */           int j = (this.invalidationSize < i) ? i : (i * 3 / 2 + 1);
/* 214 */           this.invalidationListeners = Arrays.<InvalidationListener>copyOf(this.invalidationListeners, j);
/* 215 */         } else if (this.invalidationSize == i) {
/* 216 */           this.invalidationSize = trim(this.invalidationSize, (Object[])this.invalidationListeners);
/* 217 */           if (this.invalidationSize == i) {
/* 218 */             int j = i * 3 / 2 + 1;
/* 219 */             this.invalidationListeners = Arrays.<InvalidationListener>copyOf(this.invalidationListeners, j);
/*     */           } 
/*     */         } 
/* 222 */         this.invalidationListeners[this.invalidationSize++] = param1InvalidationListener;
/*     */       } 
/* 224 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper removeListener(InvalidationListener param1InvalidationListener) {
/* 229 */       if (this.invalidationListeners != null) {
/* 230 */         for (byte b = 0; b < this.invalidationSize; b++) {
/* 231 */           if (param1InvalidationListener.equals(this.invalidationListeners[b])) {
/* 232 */             if (this.invalidationSize == 1) {
/* 233 */               if (this.changeSize == 1) {
/* 234 */                 return new ArrayListenerHelper.SingleChange<>((ObservableArray)this.observable, this.changeListeners[0]);
/*     */               }
/* 236 */               this.invalidationListeners = null;
/* 237 */               this.invalidationSize = 0; break;
/* 238 */             }  if (this.invalidationSize == 2 && this.changeSize == 0) {
/* 239 */               return new ArrayListenerHelper.SingleInvalidation<>((ObservableArray)this.observable, this.invalidationListeners[1 - b]);
/*     */             }
/* 241 */             int i = this.invalidationSize - b - 1;
/* 242 */             InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
/* 243 */             if (this.locked) {
/* 244 */               this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
/* 245 */               System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, b + 1);
/*     */             } 
/* 247 */             if (i > 0) {
/* 248 */               System.arraycopy(arrayOfInvalidationListener, b + 1, this.invalidationListeners, b, i);
/*     */             }
/* 250 */             this.invalidationSize--;
/* 251 */             if (!this.locked) {
/* 252 */               this.invalidationListeners[this.invalidationSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 259 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper addListener(ArrayChangeListener<T> param1ArrayChangeListener) {
/* 264 */       if (this.changeListeners == null) {
/* 265 */         this.changeListeners = new ArrayChangeListener[] { param1ArrayChangeListener };
/* 266 */         this.changeSize = 1;
/*     */       } else {
/* 268 */         int i = this.changeListeners.length;
/* 269 */         if (this.locked) {
/* 270 */           int j = (this.changeSize < i) ? i : (i * 3 / 2 + 1);
/* 271 */           this.changeListeners = Arrays.<ArrayChangeListener>copyOf(this.changeListeners, j);
/* 272 */         } else if (this.changeSize == i) {
/* 273 */           this.changeSize = trim(this.changeSize, (Object[])this.changeListeners);
/* 274 */           if (this.changeSize == i) {
/* 275 */             int j = i * 3 / 2 + 1;
/* 276 */             this.changeListeners = Arrays.<ArrayChangeListener>copyOf(this.changeListeners, j);
/*     */           } 
/*     */         } 
/* 279 */         this.changeListeners[this.changeSize++] = param1ArrayChangeListener;
/*     */       } 
/* 281 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ArrayListenerHelper removeListener(ArrayChangeListener<T> param1ArrayChangeListener) {
/* 286 */       if (this.changeListeners != null) {
/* 287 */         for (byte b = 0; b < this.changeSize; b++) {
/* 288 */           if (param1ArrayChangeListener.equals(this.changeListeners[b])) {
/* 289 */             if (this.changeSize == 1) {
/* 290 */               if (this.invalidationSize == 1) {
/* 291 */                 return new ArrayListenerHelper.SingleInvalidation<>((ObservableArray)this.observable, this.invalidationListeners[0]);
/*     */               }
/* 293 */               this.changeListeners = null;
/* 294 */               this.changeSize = 0; break;
/* 295 */             }  if (this.changeSize == 2 && this.invalidationSize == 0) {
/* 296 */               return new ArrayListenerHelper.SingleChange<>((ObservableArray)this.observable, this.changeListeners[1 - b]);
/*     */             }
/* 298 */             int i = this.changeSize - b - 1;
/* 299 */             ArrayChangeListener[] arrayOfArrayChangeListener = this.changeListeners;
/* 300 */             if (this.locked) {
/* 301 */               this.changeListeners = new ArrayChangeListener[this.changeListeners.length];
/* 302 */               System.arraycopy(arrayOfArrayChangeListener, 0, this.changeListeners, 0, b + 1);
/*     */             } 
/* 304 */             if (i > 0) {
/* 305 */               System.arraycopy(arrayOfArrayChangeListener, b + 1, this.changeListeners, b, i);
/*     */             }
/* 307 */             this.changeSize--;
/* 308 */             if (!this.locked) {
/* 309 */               this.changeListeners[this.changeSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 316 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(boolean param1Boolean, int param1Int1, int param1Int2) {
/* 321 */       InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
/* 322 */       int i = this.invalidationSize;
/* 323 */       ArrayChangeListener[] arrayOfArrayChangeListener = this.changeListeners;
/* 324 */       int j = this.changeSize;
/*     */       
/*     */       try {
/* 327 */         this.locked = true; byte b;
/* 328 */         for (b = 0; b < i; b++) {
/*     */           try {
/* 330 */             arrayOfInvalidationListener[b].invalidated((Observable)this.observable);
/* 331 */           } catch (Exception exception) {
/* 332 */             Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */           } 
/*     */         } 
/* 335 */         for (b = 0; b < j; b++) {
/*     */           try {
/* 337 */             arrayOfArrayChangeListener[b].onChanged(this.observable, param1Boolean, param1Int1, param1Int2);
/* 338 */           } catch (Exception exception) {
/* 339 */             Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */           } 
/*     */         } 
/*     */       } finally {
/* 343 */         this.locked = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\collections\ArrayListenerHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */