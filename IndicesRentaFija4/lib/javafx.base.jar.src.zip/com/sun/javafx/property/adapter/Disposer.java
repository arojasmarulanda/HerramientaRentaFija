/*    */ package com.sun.javafx.property.adapter;
/*    */ 
/*    */ import java.lang.ref.PhantomReference;
/*    */ import java.lang.ref.Reference;
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Disposer
/*    */   implements Runnable
/*    */ {
/* 46 */   private static final ReferenceQueue queue = new ReferenceQueue();
/* 47 */   private static final Map<Object, Runnable> records = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */   
/* 51 */   private static Disposer disposerInstance = new Disposer();
/*    */   static {
/* 53 */     AccessController.doPrivileged(new PrivilegedAction()
/*    */         {
/*    */ 
/*    */ 
/*    */           
/*    */           public Object run()
/*    */           {
/* 60 */             ThreadGroup threadGroup1 = Thread.currentThread().getThreadGroup();
/* 61 */             ThreadGroup threadGroup2 = threadGroup1;
/* 62 */             while (threadGroup2 != null) {
/* 63 */               threadGroup1 = threadGroup2; threadGroup2 = threadGroup1.getParent();
/*    */             } 
/* 65 */             Thread thread = new Thread(threadGroup1, Disposer.disposerInstance, "Property Disposer");
/* 66 */             thread.setContextClassLoader(null);
/* 67 */             thread.setDaemon(true);
/* 68 */             thread.setPriority(10);
/* 69 */             thread.start();
/* 70 */             return null;
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void addRecord(Object paramObject, Runnable paramRunnable) {
/* 82 */     PhantomReference phantomReference = new PhantomReference(paramObject, queue);
/* 83 */     records.put(phantomReference, paramRunnable);
/*    */   }
/*    */   public void run() {
/*    */     while (true) {
/*    */       try {
/*    */         while (true)
/* 89 */         { Reference reference = queue.remove();
/* 90 */           reference.clear();
/* 91 */           Runnable runnable = records.remove(reference);
/* 92 */           runnable.run(); }  break;
/* 93 */       } catch (Exception exception) {
/* 94 */         System.out.println("Exception while removing reference: " + exception);
/* 95 */         exception.printStackTrace();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\property\adapter\Disposer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */