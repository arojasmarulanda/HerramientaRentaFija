/*    */ package com.sun.javafx.property.adapter;
/*    */ 
/*    */ import javafx.beans.property.adapter.ReadOnlyJavaBeanObjectProperty;
/*    */ import javafx.beans.property.adapter.ReadOnlyJavaBeanObjectPropertyBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JavaBeanQuickAccessor
/*    */ {
/*    */   public static <T> ReadOnlyJavaBeanObjectProperty<T> createReadOnlyJavaBeanObjectProperty(Object paramObject, String paramString) throws NoSuchMethodException {
/* 37 */     return ReadOnlyJavaBeanObjectPropertyBuilder.<T>create().bean(paramObject).name(paramString).build();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\property\adapter\JavaBeanQuickAccessor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */