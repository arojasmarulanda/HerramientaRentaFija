package com.sun.javafx.event;

import javafx.event.EventDispatchChain;
import javafx.event.EventDispatcher;

public interface EventDispatchTree extends EventDispatchChain {
  EventDispatchTree createTree();
  
  EventDispatchTree mergeTree(EventDispatchTree paramEventDispatchTree);
  
  EventDispatchTree append(EventDispatcher paramEventDispatcher);
  
  EventDispatchTree prepend(EventDispatcher paramEventDispatcher);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\event\EventDispatchTree.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */