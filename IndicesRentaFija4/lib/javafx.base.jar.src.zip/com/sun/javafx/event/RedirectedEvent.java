/*    */ package com.sun.javafx.event;
/*    */ 
/*    */ import javafx.event.Event;
/*    */ import javafx.event.EventTarget;
/*    */ import javafx.event.EventType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RedirectedEvent
/*    */   extends Event
/*    */ {
/*    */   private static final long serialVersionUID = 20121107L;
/* 40 */   public static final EventType<RedirectedEvent> REDIRECTED = (EventType)new EventType<>(Event.ANY, "REDIRECTED");
/*    */   
/*    */   private final Event originalEvent;
/*    */ 
/*    */   
/*    */   public RedirectedEvent(Event paramEvent) {
/* 46 */     this(paramEvent, null, null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RedirectedEvent(Event paramEvent, Object paramObject, EventTarget paramEventTarget) {
/* 52 */     super(paramObject, paramEventTarget, (EventType)REDIRECTED);
/* 53 */     this.originalEvent = paramEvent;
/*    */   }
/*    */   
/*    */   public Event getOriginalEvent() {
/* 57 */     return this.originalEvent;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\event\RedirectedEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */