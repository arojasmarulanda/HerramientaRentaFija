/*     */ package com.sun.javafx.event;
/*     */ 
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.WeakEventHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CompositeEventHandler<T extends Event>
/*     */ {
/*     */   private EventProcessorRecord<T> firstRecord;
/*     */   private EventProcessorRecord<T> lastRecord;
/*     */   private EventHandler<? super T> eventHandler;
/*     */   
/*     */   public void setEventHandler(EventHandler<? super T> paramEventHandler) {
/*  39 */     this.eventHandler = paramEventHandler;
/*     */   }
/*     */   
/*     */   public EventHandler<? super T> getEventHandler() {
/*  43 */     return this.eventHandler;
/*     */   }
/*     */   
/*     */   public void addEventHandler(EventHandler<? super T> paramEventHandler) {
/*  47 */     if (find(paramEventHandler, false) == null) {
/*  48 */       append(this.lastRecord, createEventHandlerRecord(paramEventHandler));
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeEventHandler(EventHandler<? super T> paramEventHandler) {
/*  53 */     EventProcessorRecord<T> eventProcessorRecord = find(paramEventHandler, false);
/*  54 */     if (eventProcessorRecord != null) {
/*  55 */       remove(eventProcessorRecord);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addEventFilter(EventHandler<? super T> paramEventHandler) {
/*  60 */     if (find(paramEventHandler, true) == null) {
/*  61 */       append(this.lastRecord, createEventFilterRecord(paramEventHandler));
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeEventFilter(EventHandler<? super T> paramEventHandler) {
/*  66 */     EventProcessorRecord<T> eventProcessorRecord = find(paramEventHandler, true);
/*  67 */     if (eventProcessorRecord != null) {
/*  68 */       remove(eventProcessorRecord);
/*     */     }
/*     */   }
/*     */   
/*     */   public void dispatchBubblingEvent(Event paramEvent) {
/*  73 */     Event event = paramEvent;
/*     */     
/*  75 */     EventProcessorRecord<T> eventProcessorRecord = this.firstRecord;
/*  76 */     while (eventProcessorRecord != null) {
/*  77 */       if (eventProcessorRecord.isDisconnected()) {
/*  78 */         remove(eventProcessorRecord);
/*     */       } else {
/*  80 */         eventProcessorRecord.handleBubblingEvent((T)event);
/*     */       } 
/*  82 */       eventProcessorRecord = eventProcessorRecord.nextRecord;
/*     */     } 
/*     */     
/*  85 */     if (this.eventHandler != null) {
/*  86 */       this.eventHandler.handle((T)event);
/*     */     }
/*     */   }
/*     */   
/*     */   public void dispatchCapturingEvent(Event paramEvent) {
/*  91 */     Event event = paramEvent;
/*     */     
/*  93 */     EventProcessorRecord<T> eventProcessorRecord = this.firstRecord;
/*  94 */     while (eventProcessorRecord != null) {
/*  95 */       if (eventProcessorRecord.isDisconnected()) {
/*  96 */         remove(eventProcessorRecord);
/*     */       } else {
/*  98 */         eventProcessorRecord.handleCapturingEvent((T)event);
/*     */       } 
/* 100 */       eventProcessorRecord = eventProcessorRecord.nextRecord;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   boolean containsHandler(EventHandler<? super T> paramEventHandler) {
/* 106 */     return (find(paramEventHandler, false) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean containsFilter(EventHandler<? super T> paramEventHandler) {
/* 111 */     return (find(paramEventHandler, true) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   private EventProcessorRecord<T> createEventHandlerRecord(EventHandler<? super T> paramEventHandler) {
/* 116 */     return (paramEventHandler instanceof WeakEventHandler) ? 
/* 117 */       new WeakEventHandlerRecord<>((WeakEventHandler<? super T>)paramEventHandler) : 
/*     */       
/* 119 */       new NormalEventHandlerRecord<>(paramEventHandler);
/*     */   }
/*     */ 
/*     */   
/*     */   private EventProcessorRecord<T> createEventFilterRecord(EventHandler<? super T> paramEventHandler) {
/* 124 */     return (paramEventHandler instanceof WeakEventHandler) ? 
/* 125 */       new WeakEventFilterRecord<>((WeakEventHandler<? super T>)paramEventHandler) : 
/*     */       
/* 127 */       new NormalEventFilterRecord<>(paramEventHandler);
/*     */   }
/*     */   
/*     */   private void remove(EventProcessorRecord<T> paramEventProcessorRecord) {
/* 131 */     EventProcessorRecord<T> eventProcessorRecord1 = paramEventProcessorRecord.prevRecord;
/* 132 */     EventProcessorRecord<T> eventProcessorRecord2 = paramEventProcessorRecord.nextRecord;
/*     */     
/* 134 */     if (eventProcessorRecord1 != null) {
/* 135 */       eventProcessorRecord1.nextRecord = eventProcessorRecord2;
/*     */     } else {
/* 137 */       this.firstRecord = eventProcessorRecord2;
/*     */     } 
/*     */     
/* 140 */     if (eventProcessorRecord2 != null) {
/* 141 */       eventProcessorRecord2.prevRecord = eventProcessorRecord1;
/*     */     } else {
/* 143 */       this.lastRecord = eventProcessorRecord1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void append(EventProcessorRecord<T> paramEventProcessorRecord1, EventProcessorRecord<T> paramEventProcessorRecord2) {
/*     */     EventProcessorRecord<T> eventProcessorRecord;
/* 152 */     if (paramEventProcessorRecord1 != null) {
/* 153 */       eventProcessorRecord = paramEventProcessorRecord1.nextRecord;
/* 154 */       paramEventProcessorRecord1.nextRecord = paramEventProcessorRecord2;
/*     */     } else {
/* 156 */       eventProcessorRecord = this.firstRecord;
/* 157 */       this.firstRecord = paramEventProcessorRecord2;
/*     */     } 
/*     */     
/* 160 */     if (eventProcessorRecord != null) {
/* 161 */       eventProcessorRecord.prevRecord = paramEventProcessorRecord2;
/*     */     } else {
/* 163 */       this.lastRecord = paramEventProcessorRecord2;
/*     */     } 
/*     */     
/* 166 */     paramEventProcessorRecord2.prevRecord = paramEventProcessorRecord1;
/* 167 */     paramEventProcessorRecord2.nextRecord = eventProcessorRecord;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private EventProcessorRecord<T> find(EventHandler<? super T> paramEventHandler, boolean paramBoolean) {
/* 173 */     EventProcessorRecord<T> eventProcessorRecord = this.firstRecord;
/* 174 */     while (eventProcessorRecord != null) {
/* 175 */       if (eventProcessorRecord.isDisconnected()) {
/* 176 */         remove(eventProcessorRecord);
/* 177 */       } else if (eventProcessorRecord.stores(paramEventHandler, paramBoolean)) {
/* 178 */         return eventProcessorRecord;
/*     */       } 
/*     */       
/* 181 */       eventProcessorRecord = eventProcessorRecord.nextRecord;
/*     */     } 
/*     */     
/* 184 */     return null;
/*     */   }
/*     */   
/*     */   private static abstract class EventProcessorRecord<T extends Event> {
/*     */     private EventProcessorRecord<T> nextRecord;
/*     */     private EventProcessorRecord<T> prevRecord;
/*     */     
/*     */     private EventProcessorRecord() {}
/*     */     
/*     */     public abstract boolean stores(EventHandler<? super T> param1EventHandler, boolean param1Boolean);
/*     */     
/*     */     public abstract void handleBubblingEvent(T param1T);
/*     */     
/*     */     public abstract void handleCapturingEvent(T param1T);
/*     */     
/*     */     public abstract boolean isDisconnected();
/*     */   }
/*     */   
/*     */   private static final class NormalEventHandlerRecord<T extends Event>
/*     */     extends EventProcessorRecord<T> {
/*     */     private final EventHandler<? super T> eventHandler;
/*     */     
/*     */     public NormalEventHandlerRecord(EventHandler<? super T> param1EventHandler) {
/* 207 */       this.eventHandler = param1EventHandler;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean stores(EventHandler<? super T> param1EventHandler, boolean param1Boolean) {
/* 213 */       return (!param1Boolean && this.eventHandler == param1EventHandler);
/*     */     }
/*     */ 
/*     */     
/*     */     public void handleBubblingEvent(T param1T) {
/* 218 */       this.eventHandler.handle(param1T);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void handleCapturingEvent(T param1T) {}
/*     */ 
/*     */     
/*     */     public boolean isDisconnected() {
/* 227 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class WeakEventHandlerRecord<T extends Event>
/*     */     extends EventProcessorRecord<T>
/*     */   {
/*     */     private final WeakEventHandler<? super T> weakEventHandler;
/*     */     
/*     */     public WeakEventHandlerRecord(WeakEventHandler<? super T> param1WeakEventHandler) {
/* 237 */       this.weakEventHandler = param1WeakEventHandler;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean stores(EventHandler<? super T> param1EventHandler, boolean param1Boolean) {
/* 243 */       return (!param1Boolean && this.weakEventHandler == param1EventHandler);
/*     */     }
/*     */ 
/*     */     
/*     */     public void handleBubblingEvent(T param1T) {
/* 248 */       this.weakEventHandler.handle(param1T);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void handleCapturingEvent(T param1T) {}
/*     */ 
/*     */     
/*     */     public boolean isDisconnected() {
/* 257 */       return this.weakEventHandler.wasGarbageCollected();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class NormalEventFilterRecord<T extends Event>
/*     */     extends EventProcessorRecord<T>
/*     */   {
/*     */     private final EventHandler<? super T> eventFilter;
/*     */     
/*     */     public NormalEventFilterRecord(EventHandler<? super T> param1EventHandler) {
/* 267 */       this.eventFilter = param1EventHandler;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean stores(EventHandler<? super T> param1EventHandler, boolean param1Boolean) {
/* 273 */       return (param1Boolean && this.eventFilter == param1EventHandler);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void handleBubblingEvent(T param1T) {}
/*     */ 
/*     */     
/*     */     public void handleCapturingEvent(T param1T) {
/* 282 */       this.eventFilter.handle(param1T);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisconnected() {
/* 287 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class WeakEventFilterRecord<T extends Event>
/*     */     extends EventProcessorRecord<T>
/*     */   {
/*     */     private final WeakEventHandler<? super T> weakEventFilter;
/*     */     
/*     */     public WeakEventFilterRecord(WeakEventHandler<? super T> param1WeakEventHandler) {
/* 297 */       this.weakEventFilter = param1WeakEventHandler;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean stores(EventHandler<? super T> param1EventHandler, boolean param1Boolean) {
/* 303 */       return (param1Boolean && this.weakEventFilter == param1EventHandler);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void handleBubblingEvent(T param1T) {}
/*     */ 
/*     */     
/*     */     public void handleCapturingEvent(T param1T) {
/* 312 */       this.weakEventFilter.handle(param1T);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDisconnected() {
/* 317 */       return this.weakEventFilter.wasGarbageCollected();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\event\CompositeEventHandler.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */