/*     */ package com.sun.javafx.event;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventHandlerManager
/*     */   extends BasicEventDispatcher
/*     */ {
/*     */   private final Map<EventType<? extends Event>, CompositeEventHandler<? extends Event>> eventHandlerMap;
/*     */   private final Object eventSource;
/*     */   
/*     */   public EventHandlerManager(Object paramObject) {
/*  47 */     this.eventSource = paramObject;
/*     */     
/*  49 */     this.eventHandlerMap = new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T extends Event> void addEventHandler(EventType<T> paramEventType, EventHandler<? super T> paramEventHandler) {
/*  65 */     validateEventType(paramEventType);
/*  66 */     validateEventHandler(paramEventHandler);
/*     */ 
/*     */     
/*  69 */     CompositeEventHandler<T> compositeEventHandler = createGetCompositeEventHandler(paramEventType);
/*     */     
/*  71 */     compositeEventHandler.addEventHandler(paramEventHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T extends Event> void removeEventHandler(EventType<T> paramEventType, EventHandler<? super T> paramEventHandler) {
/*  85 */     validateEventType(paramEventType);
/*  86 */     validateEventHandler(paramEventHandler);
/*     */ 
/*     */     
/*  89 */     CompositeEventHandler<T> compositeEventHandler = (CompositeEventHandler)this.eventHandlerMap.get(paramEventType);
/*     */     
/*  91 */     if (compositeEventHandler != null) {
/*  92 */       compositeEventHandler.removeEventHandler(paramEventHandler);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T extends Event> void addEventFilter(EventType<T> paramEventType, EventHandler<? super T> paramEventHandler) {
/* 107 */     validateEventType(paramEventType);
/* 108 */     validateEventFilter(paramEventHandler);
/*     */ 
/*     */     
/* 111 */     CompositeEventHandler<T> compositeEventHandler = createGetCompositeEventHandler(paramEventType);
/*     */     
/* 113 */     compositeEventHandler.addEventFilter(paramEventHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T extends Event> void removeEventFilter(EventType<T> paramEventType, EventHandler<? super T> paramEventHandler) {
/* 127 */     validateEventType(paramEventType);
/* 128 */     validateEventFilter(paramEventHandler);
/*     */ 
/*     */     
/* 131 */     CompositeEventHandler<T> compositeEventHandler = (CompositeEventHandler)this.eventHandlerMap.get(paramEventType);
/*     */     
/* 133 */     if (compositeEventHandler != null) {
/* 134 */       compositeEventHandler.removeEventFilter(paramEventHandler);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T extends Event> void setEventHandler(EventType<T> paramEventType, EventHandler<? super T> paramEventHandler) {
/* 150 */     validateEventType(paramEventType);
/*     */ 
/*     */     
/* 153 */     CompositeEventHandler<Event> compositeEventHandler = (CompositeEventHandler)this.eventHandlerMap.get(paramEventType);
/*     */     
/* 155 */     if (compositeEventHandler == null) {
/* 156 */       if (paramEventHandler == null) {
/*     */         return;
/*     */       }
/* 159 */       compositeEventHandler = new CompositeEventHandler<>();
/* 160 */       this.eventHandlerMap.put(paramEventType, compositeEventHandler);
/*     */     } 
/*     */     
/* 163 */     compositeEventHandler.setEventHandler(paramEventHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T extends Event> EventHandler<? super T> getEventHandler(EventType<T> paramEventType) {
/* 169 */     CompositeEventHandler<T> compositeEventHandler = (CompositeEventHandler)this.eventHandlerMap.get(paramEventType);
/*     */     
/* 171 */     return (compositeEventHandler != null) ? 
/* 172 */       compositeEventHandler.getEventHandler() : 
/* 173 */       null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Event dispatchCapturingEvent(Event paramEvent) {
/* 178 */     EventType<? extends Event> eventType = paramEvent.getEventType();
/*     */     do {
/* 180 */       paramEvent = dispatchCapturingEvent(eventType, paramEvent);
/* 181 */       eventType = (EventType)eventType.getSuperType();
/* 182 */     } while (eventType != null);
/*     */     
/* 184 */     return paramEvent;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Event dispatchBubblingEvent(Event paramEvent) {
/* 189 */     EventType<? extends Event> eventType = paramEvent.getEventType();
/*     */     do {
/* 191 */       paramEvent = dispatchBubblingEvent(eventType, paramEvent);
/* 192 */       eventType = (EventType)eventType.getSuperType();
/* 193 */     } while (eventType != null);
/*     */     
/* 195 */     return paramEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends Event> CompositeEventHandler<T> createGetCompositeEventHandler(EventType<T> paramEventType) {
/* 201 */     CompositeEventHandler<Event> compositeEventHandler = (CompositeEventHandler)this.eventHandlerMap.get(paramEventType);
/* 202 */     if (compositeEventHandler == null) {
/* 203 */       compositeEventHandler = new CompositeEventHandler<>();
/* 204 */       this.eventHandlerMap.put(paramEventType, compositeEventHandler);
/*     */     } 
/*     */     
/* 207 */     return (CompositeEventHandler)compositeEventHandler;
/*     */   }
/*     */   
/*     */   protected Object getEventSource() {
/* 211 */     return this.eventSource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Event dispatchCapturingEvent(EventType<? extends Event> paramEventType, Event paramEvent) {
/* 217 */     CompositeEventHandler compositeEventHandler = this.eventHandlerMap.get(paramEventType);
/*     */     
/* 219 */     if (compositeEventHandler != null) {
/*     */ 
/*     */       
/* 222 */       paramEvent = fixEventSource(paramEvent, this.eventSource);
/* 223 */       compositeEventHandler.dispatchCapturingEvent(paramEvent);
/*     */     } 
/*     */     
/* 226 */     return paramEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Event dispatchBubblingEvent(EventType<? extends Event> paramEventType, Event paramEvent) {
/* 232 */     CompositeEventHandler compositeEventHandler = this.eventHandlerMap.get(paramEventType);
/*     */     
/* 234 */     if (compositeEventHandler != null) {
/*     */ 
/*     */       
/* 237 */       paramEvent = fixEventSource(paramEvent, this.eventSource);
/* 238 */       compositeEventHandler.dispatchBubblingEvent(paramEvent);
/*     */     } 
/*     */     
/* 241 */     return paramEvent;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Event fixEventSource(Event paramEvent, Object paramObject) {
/* 246 */     return (paramEvent.getSource() != paramObject) ? 
/* 247 */       paramEvent.copyFor(paramObject, paramEvent.getTarget()) : 
/* 248 */       paramEvent;
/*     */   }
/*     */   
/*     */   private static void validateEventType(EventType<?> paramEventType) {
/* 252 */     if (paramEventType == null) {
/* 253 */       throw new NullPointerException("Event type must not be null");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void validateEventHandler(EventHandler<?> paramEventHandler) {
/* 259 */     if (paramEventHandler == null) {
/* 260 */       throw new NullPointerException("Event handler must not be null");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void validateEventFilter(EventHandler<?> paramEventHandler) {
/* 266 */     if (paramEventHandler == null)
/* 267 */       throw new NullPointerException("Event filter must not be null"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\event\EventHandlerManager.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */