/*     */ package com.sun.javafx.binding;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javafx.beans.WeakListener;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.collections.ObservableSet;
/*     */ import javafx.collections.SetChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentBinding
/*     */ {
/*     */   private static void checkParameters(Object paramObject1, Object paramObject2) {
/*  41 */     if (paramObject1 == null || paramObject2 == null) {
/*  42 */       throw new NullPointerException("Both parameters must be specified.");
/*     */     }
/*  44 */     if (paramObject1 == paramObject2) {
/*  45 */       throw new IllegalArgumentException("Cannot bind object to itself");
/*     */     }
/*     */   }
/*     */   
/*     */   public static <E> Object bind(List<E> paramList, ObservableList<? extends E> paramObservableList) {
/*  50 */     checkParameters(paramList, paramObservableList);
/*  51 */     ListContentBinding<E> listContentBinding = new ListContentBinding<>(paramList);
/*  52 */     if (paramList instanceof ObservableList) {
/*  53 */       ((ObservableList<E>)paramList).setAll(paramObservableList);
/*     */     } else {
/*  55 */       paramList.clear();
/*  56 */       paramList.addAll(paramObservableList);
/*     */     } 
/*  58 */     paramObservableList.removeListener(listContentBinding);
/*  59 */     paramObservableList.addListener(listContentBinding);
/*  60 */     return listContentBinding;
/*     */   }
/*     */   
/*     */   public static <E> Object bind(Set<E> paramSet, ObservableSet<? extends E> paramObservableSet) {
/*  64 */     checkParameters(paramSet, paramObservableSet);
/*  65 */     SetContentBinding<E> setContentBinding = new SetContentBinding<>(paramSet);
/*  66 */     paramSet.clear();
/*  67 */     paramSet.addAll(paramObservableSet);
/*  68 */     paramObservableSet.removeListener(setContentBinding);
/*  69 */     paramObservableSet.addListener(setContentBinding);
/*  70 */     return setContentBinding;
/*     */   }
/*     */   
/*     */   public static <K, V> Object bind(Map<K, V> paramMap, ObservableMap<? extends K, ? extends V> paramObservableMap) {
/*  74 */     checkParameters(paramMap, paramObservableMap);
/*  75 */     MapContentBinding<K, V> mapContentBinding = new MapContentBinding<>(paramMap);
/*  76 */     paramMap.clear();
/*  77 */     paramMap.putAll(paramObservableMap);
/*  78 */     paramObservableMap.removeListener(mapContentBinding);
/*  79 */     paramObservableMap.addListener(mapContentBinding);
/*  80 */     return mapContentBinding;
/*     */   }
/*     */   
/*     */   public static void unbind(Object paramObject1, Object paramObject2) {
/*  84 */     checkParameters(paramObject1, paramObject2);
/*  85 */     if (paramObject1 instanceof List && paramObject2 instanceof ObservableList) {
/*  86 */       ((ObservableList)paramObject2).removeListener(new ListContentBinding((List)paramObject1));
/*  87 */     } else if (paramObject1 instanceof Set && paramObject2 instanceof ObservableSet) {
/*  88 */       ((ObservableSet)paramObject2).removeListener(new SetContentBinding((Set)paramObject1));
/*  89 */     } else if (paramObject1 instanceof Map && paramObject2 instanceof ObservableMap) {
/*  90 */       ((ObservableMap)paramObject2).removeListener(new MapContentBinding<>((Map<?, ?>)paramObject1));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class ListContentBinding<E>
/*     */     implements ListChangeListener<E>, WeakListener {
/*     */     private final WeakReference<List<E>> listRef;
/*     */     
/*     */     public ListContentBinding(List<E> param1List) {
/*  99 */       this.listRef = new WeakReference<>(param1List);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onChanged(ListChangeListener.Change<? extends E> param1Change) {
/* 104 */       List list = this.listRef.get();
/* 105 */       if (list == null) {
/* 106 */         param1Change.getList().removeListener(this);
/*     */       } else {
/* 108 */         while (param1Change.next()) {
/* 109 */           if (param1Change.wasPermutated()) {
/* 110 */             list.subList(param1Change.getFrom(), param1Change.getTo()).clear();
/* 111 */             list.addAll(param1Change.getFrom(), param1Change.getList().subList(param1Change.getFrom(), param1Change.getTo())); continue;
/*     */           } 
/* 113 */           if (param1Change.wasRemoved()) {
/* 114 */             list.subList(param1Change.getFrom(), param1Change.getFrom() + param1Change.getRemovedSize()).clear();
/*     */           }
/* 116 */           if (param1Change.wasAdded()) {
/* 117 */             list.addAll(param1Change.getFrom(), param1Change.getAddedSubList());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean wasGarbageCollected() {
/* 126 */       return (this.listRef.get() == null);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 131 */       List list = this.listRef.get();
/* 132 */       return (list == null) ? 0 : list.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 137 */       if (this == param1Object) {
/* 138 */         return true;
/*     */       }
/*     */       
/* 141 */       List list = this.listRef.get();
/* 142 */       if (list == null) {
/* 143 */         return false;
/*     */       }
/*     */       
/* 146 */       if (param1Object instanceof ListContentBinding) {
/* 147 */         ListContentBinding listContentBinding = (ListContentBinding)param1Object;
/* 148 */         List list1 = listContentBinding.listRef.get();
/* 149 */         return (list == list1);
/*     */       } 
/* 151 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SetContentBinding<E>
/*     */     implements SetChangeListener<E>, WeakListener {
/*     */     private final WeakReference<Set<E>> setRef;
/*     */     
/*     */     public SetContentBinding(Set<E> param1Set) {
/* 160 */       this.setRef = new WeakReference<>(param1Set);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onChanged(SetChangeListener.Change<? extends E> param1Change) {
/* 165 */       Set set = this.setRef.get();
/* 166 */       if (set == null) {
/* 167 */         param1Change.getSet().removeListener(this);
/*     */       }
/* 169 */       else if (param1Change.wasRemoved()) {
/* 170 */         set.remove(param1Change.getElementRemoved());
/*     */       } else {
/* 172 */         set.add(param1Change.getElementAdded());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean wasGarbageCollected() {
/* 179 */       return (this.setRef.get() == null);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 184 */       Set set = this.setRef.get();
/* 185 */       return (set == null) ? 0 : set.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 190 */       if (this == param1Object) {
/* 191 */         return true;
/*     */       }
/*     */       
/* 194 */       Set set = this.setRef.get();
/* 195 */       if (set == null) {
/* 196 */         return false;
/*     */       }
/*     */       
/* 199 */       if (param1Object instanceof SetContentBinding) {
/* 200 */         SetContentBinding setContentBinding = (SetContentBinding)param1Object;
/* 201 */         Set set1 = setContentBinding.setRef.get();
/* 202 */         return (set == set1);
/*     */       } 
/* 204 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class MapContentBinding<K, V>
/*     */     implements MapChangeListener<K, V>, WeakListener {
/*     */     private final WeakReference<Map<K, V>> mapRef;
/*     */     
/*     */     public MapContentBinding(Map<K, V> param1Map) {
/* 213 */       this.mapRef = new WeakReference<>(param1Map);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onChanged(MapChangeListener.Change<? extends K, ? extends V> param1Change) {
/* 218 */       Map map = this.mapRef.get();
/* 219 */       if (map == null) {
/* 220 */         param1Change.getMap().removeListener(this);
/*     */       } else {
/* 222 */         if (param1Change.wasRemoved()) {
/* 223 */           map.remove(param1Change.getKey());
/*     */         }
/* 225 */         if (param1Change.wasAdded()) {
/* 226 */           map.put(param1Change.getKey(), param1Change.getValueAdded());
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean wasGarbageCollected() {
/* 233 */       return (this.mapRef.get() == null);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 238 */       Map map = this.mapRef.get();
/* 239 */       return (map == null) ? 0 : map.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 244 */       if (this == param1Object) {
/* 245 */         return true;
/*     */       }
/*     */       
/* 248 */       Map map = this.mapRef.get();
/* 249 */       if (map == null) {
/* 250 */         return false;
/*     */       }
/*     */       
/* 253 */       if (param1Object instanceof MapContentBinding) {
/* 254 */         MapContentBinding mapContentBinding = (MapContentBinding)param1Object;
/* 255 */         Map map1 = mapContentBinding.mapRef.get();
/* 256 */         return (map == map1);
/*     */       } 
/* 258 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\binding\ContentBinding.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */