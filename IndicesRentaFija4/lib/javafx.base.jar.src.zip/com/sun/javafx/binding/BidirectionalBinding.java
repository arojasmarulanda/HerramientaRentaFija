/*     */ package com.sun.javafx.binding;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.text.Format;
/*     */ import java.text.ParseException;
/*     */ import javafx.beans.WeakListener;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.FloatProperty;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.LongProperty;
/*     */ import javafx.beans.property.Property;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BidirectionalBinding<T>
/*     */   implements ChangeListener<T>, WeakListener
/*     */ {
/*     */   private final int cachedHashCode;
/*     */   
/*     */   private static void checkParameters(Object paramObject1, Object paramObject2) {
/*  42 */     if (paramObject1 == null || paramObject2 == null) {
/*  43 */       throw new NullPointerException("Both properties must be specified.");
/*     */     }
/*  45 */     if (paramObject1 == paramObject2) {
/*  46 */       throw new IllegalArgumentException("Cannot bind property to itself");
/*     */     }
/*     */   }
/*     */   
/*     */   public static <T> BidirectionalBinding bind(Property<T> paramProperty1, Property<T> paramProperty2) {
/*  51 */     checkParameters(paramProperty1, paramProperty2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     ChangeListener<? super T> changeListener = (ChangeListener<? super T>)((paramProperty1 instanceof DoubleProperty && paramProperty2 instanceof DoubleProperty) ? new BidirectionalDoubleBinding((DoubleProperty)paramProperty1, (DoubleProperty)paramProperty2) : ((paramProperty1 instanceof FloatProperty && paramProperty2 instanceof FloatProperty) ? new BidirectionalFloatBinding((FloatProperty)paramProperty1, (FloatProperty)paramProperty2) : ((paramProperty1 instanceof IntegerProperty && paramProperty2 instanceof IntegerProperty) ? new BidirectionalIntegerBinding((IntegerProperty)paramProperty1, (IntegerProperty)paramProperty2) : ((paramProperty1 instanceof LongProperty && paramProperty2 instanceof LongProperty) ? new BidirectionalLongBinding((LongProperty)paramProperty1, (LongProperty)paramProperty2) : ((paramProperty1 instanceof BooleanProperty && paramProperty2 instanceof BooleanProperty) ? new BidirectionalBooleanBinding((BooleanProperty)paramProperty1, (BooleanProperty)paramProperty2) : new TypedGenericBidirectionalBinding(paramProperty1, paramProperty2))))));
/*  64 */     paramProperty1.setValue(paramProperty2.getValue());
/*  65 */     paramProperty1.addListener(changeListener);
/*  66 */     paramProperty2.addListener(changeListener);
/*  67 */     return (BidirectionalBinding)changeListener;
/*     */   }
/*     */   
/*     */   public static Object bind(Property<String> paramProperty, Property<?> paramProperty1, Format paramFormat) {
/*  71 */     checkParameters(paramProperty, paramProperty1);
/*  72 */     if (paramFormat == null) {
/*  73 */       throw new NullPointerException("Format cannot be null");
/*     */     }
/*  75 */     StringFormatBidirectionalBinding stringFormatBidirectionalBinding = new StringFormatBidirectionalBinding(paramProperty, paramProperty1, paramFormat);
/*  76 */     paramProperty.setValue(paramFormat.format(paramProperty1.getValue()));
/*  77 */     paramProperty.addListener(stringFormatBidirectionalBinding);
/*  78 */     paramProperty1.addListener(stringFormatBidirectionalBinding);
/*  79 */     return stringFormatBidirectionalBinding;
/*     */   }
/*     */   
/*     */   public static <T> Object bind(Property<String> paramProperty, Property<T> paramProperty1, StringConverter<T> paramStringConverter) {
/*  83 */     checkParameters(paramProperty, paramProperty1);
/*  84 */     if (paramStringConverter == null) {
/*  85 */       throw new NullPointerException("Converter cannot be null");
/*     */     }
/*  87 */     StringConverterBidirectionalBinding<T> stringConverterBidirectionalBinding = new StringConverterBidirectionalBinding<>(paramProperty, paramProperty1, paramStringConverter);
/*  88 */     paramProperty.setValue(paramStringConverter.toString(paramProperty1.getValue()));
/*  89 */     paramProperty.addListener(stringConverterBidirectionalBinding);
/*  90 */     paramProperty1.addListener(stringConverterBidirectionalBinding);
/*  91 */     return stringConverterBidirectionalBinding;
/*     */   }
/*     */   
/*     */   public static <T> void unbind(Property<T> paramProperty1, Property<T> paramProperty2) {
/*  95 */     checkParameters(paramProperty1, paramProperty2);
/*  96 */     UntypedGenericBidirectionalBinding untypedGenericBidirectionalBinding = new UntypedGenericBidirectionalBinding(paramProperty1, paramProperty2);
/*  97 */     paramProperty1.removeListener(untypedGenericBidirectionalBinding);
/*  98 */     paramProperty2.removeListener(untypedGenericBidirectionalBinding);
/*     */   }
/*     */   
/*     */   public static void unbind(Object paramObject1, Object paramObject2) {
/* 102 */     checkParameters(paramObject1, paramObject2);
/* 103 */     UntypedGenericBidirectionalBinding untypedGenericBidirectionalBinding = new UntypedGenericBidirectionalBinding(paramObject1, paramObject2);
/* 104 */     if (paramObject1 instanceof ObservableValue) {
/* 105 */       ((ObservableValue)paramObject1).removeListener(untypedGenericBidirectionalBinding);
/*     */     }
/* 107 */     if (paramObject2 instanceof ObservableValue) {
/* 108 */       ((ObservableValue)paramObject2).removeListener(untypedGenericBidirectionalBinding);
/*     */     }
/*     */   }
/*     */   
/*     */   public static BidirectionalBinding bindNumber(Property<Integer> paramProperty, IntegerProperty paramIntegerProperty) {
/* 113 */     return bindNumber(paramProperty, paramIntegerProperty);
/*     */   }
/*     */   
/*     */   public static BidirectionalBinding bindNumber(Property<Long> paramProperty, LongProperty paramLongProperty) {
/* 117 */     return bindNumber(paramProperty, paramLongProperty);
/*     */   }
/*     */   
/*     */   public static BidirectionalBinding bindNumber(Property<Float> paramProperty, FloatProperty paramFloatProperty) {
/* 121 */     return bindNumber(paramProperty, paramFloatProperty);
/*     */   }
/*     */   
/*     */   public static BidirectionalBinding bindNumber(Property<Double> paramProperty, DoubleProperty paramDoubleProperty) {
/* 125 */     return bindNumber(paramProperty, paramDoubleProperty);
/*     */   }
/*     */   
/*     */   public static BidirectionalBinding bindNumber(IntegerProperty paramIntegerProperty, Property<Integer> paramProperty) {
/* 129 */     return bindNumberObject(paramIntegerProperty, paramProperty);
/*     */   }
/*     */   
/*     */   public static BidirectionalBinding bindNumber(LongProperty paramLongProperty, Property<Long> paramProperty) {
/* 133 */     return bindNumberObject(paramLongProperty, paramProperty);
/*     */   }
/*     */   
/*     */   public static BidirectionalBinding bindNumber(FloatProperty paramFloatProperty, Property<Float> paramProperty) {
/* 137 */     return bindNumberObject(paramFloatProperty, paramProperty);
/*     */   }
/*     */   
/*     */   public static BidirectionalBinding bindNumber(DoubleProperty paramDoubleProperty, Property<Double> paramProperty) {
/* 141 */     return bindNumberObject(paramDoubleProperty, paramProperty);
/*     */   }
/*     */   
/*     */   private static <T extends Number> BidirectionalBinding bindNumberObject(Property<Number> paramProperty, Property<T> paramProperty1) {
/* 145 */     checkParameters(paramProperty, paramProperty1);
/*     */     
/* 147 */     TypedNumberBidirectionalBinding<Number> typedNumberBidirectionalBinding = new TypedNumberBidirectionalBinding<>(paramProperty1, paramProperty);
/*     */     
/* 149 */     paramProperty.setValue((Number)paramProperty1.getValue());
/* 150 */     paramProperty.addListener(typedNumberBidirectionalBinding);
/* 151 */     paramProperty1.addListener((ChangeListener)typedNumberBidirectionalBinding);
/* 152 */     return typedNumberBidirectionalBinding;
/*     */   }
/*     */   
/*     */   private static <T extends Number> BidirectionalBinding bindNumber(Property<T> paramProperty, Property<Number> paramProperty1) {
/* 156 */     checkParameters(paramProperty, paramProperty1);
/*     */     
/* 158 */     TypedNumberBidirectionalBinding<Number> typedNumberBidirectionalBinding = new TypedNumberBidirectionalBinding<>(paramProperty, paramProperty1);
/*     */     
/* 160 */     paramProperty.setValue((T)paramProperty1.getValue());
/* 161 */     paramProperty.addListener((ChangeListener)typedNumberBidirectionalBinding);
/* 162 */     paramProperty1.addListener(typedNumberBidirectionalBinding);
/* 163 */     return typedNumberBidirectionalBinding;
/*     */   }
/*     */   
/*     */   public static <T extends Number> void unbindNumber(Property<T> paramProperty, Property<Number> paramProperty1) {
/* 167 */     checkParameters(paramProperty, paramProperty1);
/* 168 */     UntypedGenericBidirectionalBinding untypedGenericBidirectionalBinding = new UntypedGenericBidirectionalBinding(paramProperty, paramProperty1);
/* 169 */     if (paramProperty instanceof ObservableValue) {
/* 170 */       paramProperty.removeListener(untypedGenericBidirectionalBinding);
/*     */     }
/* 172 */     if (paramProperty1 instanceof javafx.beans.Observable) {
/* 173 */       paramProperty1.removeListener(untypedGenericBidirectionalBinding);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BidirectionalBinding(Object paramObject1, Object paramObject2) {
/* 180 */     this.cachedHashCode = paramObject1.hashCode() * paramObject2.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 189 */     return this.cachedHashCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean wasGarbageCollected() {
/* 194 */     return (getProperty1() == null || getProperty2() == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 199 */     if (this == paramObject) {
/* 200 */       return true;
/*     */     }
/*     */     
/* 203 */     Object object1 = getProperty1();
/* 204 */     Object object2 = getProperty2();
/* 205 */     if (object1 == null || object2 == null) {
/* 206 */       return false;
/*     */     }
/*     */     
/* 209 */     if (paramObject instanceof BidirectionalBinding) {
/* 210 */       BidirectionalBinding bidirectionalBinding = (BidirectionalBinding)paramObject;
/* 211 */       Object object3 = bidirectionalBinding.getProperty1();
/* 212 */       Object object4 = bidirectionalBinding.getProperty2();
/* 213 */       if (object3 == null || object4 == null) {
/* 214 */         return false;
/*     */       }
/*     */       
/* 217 */       if (object1 == object3 && object2 == object4) {
/* 218 */         return true;
/*     */       }
/* 220 */       if (object1 == object4 && object2 == object3) {
/* 221 */         return true;
/*     */       }
/*     */     } 
/* 224 */     return false;
/*     */   }
/*     */   protected abstract Object getProperty1();
/*     */   
/*     */   protected abstract Object getProperty2();
/*     */   
/*     */   private static class BidirectionalBooleanBinding extends BidirectionalBinding<Boolean> { private final WeakReference<BooleanProperty> propertyRef1;
/*     */     
/*     */     private BidirectionalBooleanBinding(BooleanProperty param1BooleanProperty1, BooleanProperty param1BooleanProperty2) {
/* 233 */       super(param1BooleanProperty1, param1BooleanProperty2);
/* 234 */       this.propertyRef1 = new WeakReference<>(param1BooleanProperty1);
/* 235 */       this.propertyRef2 = new WeakReference<>(param1BooleanProperty2);
/*     */     }
/*     */     private final WeakReference<BooleanProperty> propertyRef2; private boolean updating = false;
/*     */     
/*     */     protected Property<Boolean> getProperty1() {
/* 240 */       return this.propertyRef1.get();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<Boolean> getProperty2() {
/* 245 */       return this.propertyRef2.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void changed(ObservableValue<? extends Boolean> param1ObservableValue, Boolean param1Boolean1, Boolean param1Boolean2) {
/* 250 */       if (!this.updating) {
/* 251 */         BooleanProperty booleanProperty1 = this.propertyRef1.get();
/* 252 */         BooleanProperty booleanProperty2 = this.propertyRef2.get();
/* 253 */         if (booleanProperty1 == null || booleanProperty2 == null) {
/* 254 */           if (booleanProperty1 != null) {
/* 255 */             booleanProperty1.removeListener(this);
/*     */           }
/* 257 */           if (booleanProperty2 != null) {
/* 258 */             booleanProperty2.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 262 */             this.updating = true;
/* 263 */             if (booleanProperty1 == param1ObservableValue) {
/* 264 */               booleanProperty2.set(param1Boolean2.booleanValue());
/*     */             } else {
/* 266 */               booleanProperty1.set(param1Boolean2.booleanValue());
/*     */             } 
/* 268 */           } catch (RuntimeException runtimeException) {
/*     */             try {
/* 270 */               if (booleanProperty1 == param1ObservableValue) {
/* 271 */                 booleanProperty1.set(param1Boolean1.booleanValue());
/*     */               } else {
/* 273 */                 booleanProperty2.set(param1Boolean1.booleanValue());
/*     */               } 
/* 275 */             } catch (Exception exception) {
/* 276 */               exception.addSuppressed(runtimeException);
/* 277 */               unbind(booleanProperty1, booleanProperty2);
/* 278 */               throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + booleanProperty1 + " and " + booleanProperty2, exception);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 284 */             throw new RuntimeException("Bidirectional binding failed, setting to the previous value", runtimeException);
/*     */           } finally {
/*     */             
/* 287 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } }
/*     */ 
/*     */   
/*     */   private static class BidirectionalDoubleBinding extends BidirectionalBinding<Number> {
/*     */     private final WeakReference<DoubleProperty> propertyRef1;
/*     */     private final WeakReference<DoubleProperty> propertyRef2;
/*     */     private boolean updating = false;
/*     */     
/*     */     private BidirectionalDoubleBinding(DoubleProperty param1DoubleProperty1, DoubleProperty param1DoubleProperty2) {
/* 300 */       super(param1DoubleProperty1, param1DoubleProperty2);
/* 301 */       this.propertyRef1 = new WeakReference<>(param1DoubleProperty1);
/* 302 */       this.propertyRef2 = new WeakReference<>(param1DoubleProperty2);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<Number> getProperty1() {
/* 307 */       return this.propertyRef1.get();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<Number> getProperty2() {
/* 312 */       return this.propertyRef2.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void changed(ObservableValue<? extends Number> param1ObservableValue, Number param1Number1, Number param1Number2) {
/* 317 */       if (!this.updating) {
/* 318 */         DoubleProperty doubleProperty1 = this.propertyRef1.get();
/* 319 */         DoubleProperty doubleProperty2 = this.propertyRef2.get();
/* 320 */         if (doubleProperty1 == null || doubleProperty2 == null) {
/* 321 */           if (doubleProperty1 != null) {
/* 322 */             doubleProperty1.removeListener(this);
/*     */           }
/* 324 */           if (doubleProperty2 != null) {
/* 325 */             doubleProperty2.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 329 */             this.updating = true;
/* 330 */             if (doubleProperty1 == param1ObservableValue) {
/* 331 */               doubleProperty2.set(param1Number2.doubleValue());
/*     */             } else {
/* 333 */               doubleProperty1.set(param1Number2.doubleValue());
/*     */             } 
/* 335 */           } catch (RuntimeException runtimeException) {
/*     */             try {
/* 337 */               if (doubleProperty1 == param1ObservableValue) {
/* 338 */                 doubleProperty1.set(param1Number1.doubleValue());
/*     */               } else {
/* 340 */                 doubleProperty2.set(param1Number1.doubleValue());
/*     */               } 
/* 342 */             } catch (Exception exception) {
/* 343 */               exception.addSuppressed(runtimeException);
/* 344 */               unbind(doubleProperty1, doubleProperty2);
/* 345 */               throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + doubleProperty1 + " and " + doubleProperty2, exception);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 351 */             throw new RuntimeException("Bidirectional binding failed, setting to the previous value", runtimeException);
/*     */           } finally {
/*     */             
/* 354 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class BidirectionalFloatBinding extends BidirectionalBinding<Number> {
/*     */     private final WeakReference<FloatProperty> propertyRef1;
/*     */     private final WeakReference<FloatProperty> propertyRef2;
/*     */     private boolean updating = false;
/*     */     
/*     */     private BidirectionalFloatBinding(FloatProperty param1FloatProperty1, FloatProperty param1FloatProperty2) {
/* 367 */       super(param1FloatProperty1, param1FloatProperty2);
/* 368 */       this.propertyRef1 = new WeakReference<>(param1FloatProperty1);
/* 369 */       this.propertyRef2 = new WeakReference<>(param1FloatProperty2);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<Number> getProperty1() {
/* 374 */       return this.propertyRef1.get();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<Number> getProperty2() {
/* 379 */       return this.propertyRef2.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void changed(ObservableValue<? extends Number> param1ObservableValue, Number param1Number1, Number param1Number2) {
/* 384 */       if (!this.updating) {
/* 385 */         FloatProperty floatProperty1 = this.propertyRef1.get();
/* 386 */         FloatProperty floatProperty2 = this.propertyRef2.get();
/* 387 */         if (floatProperty1 == null || floatProperty2 == null) {
/* 388 */           if (floatProperty1 != null) {
/* 389 */             floatProperty1.removeListener(this);
/*     */           }
/* 391 */           if (floatProperty2 != null) {
/* 392 */             floatProperty2.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 396 */             this.updating = true;
/* 397 */             if (floatProperty1 == param1ObservableValue) {
/* 398 */               floatProperty2.set(param1Number2.floatValue());
/*     */             } else {
/* 400 */               floatProperty1.set(param1Number2.floatValue());
/*     */             } 
/* 402 */           } catch (RuntimeException runtimeException) {
/*     */             try {
/* 404 */               if (floatProperty1 == param1ObservableValue) {
/* 405 */                 floatProperty1.set(param1Number1.floatValue());
/*     */               } else {
/* 407 */                 floatProperty2.set(param1Number1.floatValue());
/*     */               } 
/* 409 */             } catch (Exception exception) {
/* 410 */               exception.addSuppressed(runtimeException);
/* 411 */               unbind(floatProperty1, floatProperty2);
/* 412 */               throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + floatProperty1 + " and " + floatProperty2, exception);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 418 */             throw new RuntimeException("Bidirectional binding failed, setting to the previous value", runtimeException);
/*     */           } finally {
/*     */             
/* 421 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class BidirectionalIntegerBinding extends BidirectionalBinding<Number> {
/*     */     private final WeakReference<IntegerProperty> propertyRef1;
/*     */     private final WeakReference<IntegerProperty> propertyRef2;
/*     */     private boolean updating = false;
/*     */     
/*     */     private BidirectionalIntegerBinding(IntegerProperty param1IntegerProperty1, IntegerProperty param1IntegerProperty2) {
/* 434 */       super(param1IntegerProperty1, param1IntegerProperty2);
/* 435 */       this.propertyRef1 = new WeakReference<>(param1IntegerProperty1);
/* 436 */       this.propertyRef2 = new WeakReference<>(param1IntegerProperty2);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<Number> getProperty1() {
/* 441 */       return this.propertyRef1.get();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<Number> getProperty2() {
/* 446 */       return this.propertyRef2.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void changed(ObservableValue<? extends Number> param1ObservableValue, Number param1Number1, Number param1Number2) {
/* 451 */       if (!this.updating) {
/* 452 */         IntegerProperty integerProperty1 = this.propertyRef1.get();
/* 453 */         IntegerProperty integerProperty2 = this.propertyRef2.get();
/* 454 */         if (integerProperty1 == null || integerProperty2 == null) {
/* 455 */           if (integerProperty1 != null) {
/* 456 */             integerProperty1.removeListener(this);
/*     */           }
/* 458 */           if (integerProperty2 != null) {
/* 459 */             integerProperty2.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 463 */             this.updating = true;
/* 464 */             if (integerProperty1 == param1ObservableValue) {
/* 465 */               integerProperty2.set(param1Number2.intValue());
/*     */             } else {
/* 467 */               integerProperty1.set(param1Number2.intValue());
/*     */             } 
/* 469 */           } catch (RuntimeException runtimeException) {
/*     */             try {
/* 471 */               if (integerProperty1 == param1ObservableValue) {
/* 472 */                 integerProperty1.set(param1Number1.intValue());
/*     */               } else {
/* 474 */                 integerProperty2.set(param1Number1.intValue());
/*     */               } 
/* 476 */             } catch (Exception exception) {
/* 477 */               exception.addSuppressed(runtimeException);
/* 478 */               unbind(integerProperty1, integerProperty2);
/* 479 */               throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + integerProperty1 + " and " + integerProperty2, exception);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 485 */             throw new RuntimeException("Bidirectional binding failed, setting to the previous value", runtimeException);
/*     */           } finally {
/*     */             
/* 488 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class BidirectionalLongBinding extends BidirectionalBinding<Number> {
/*     */     private final WeakReference<LongProperty> propertyRef1;
/*     */     private final WeakReference<LongProperty> propertyRef2;
/*     */     private boolean updating = false;
/*     */     
/*     */     private BidirectionalLongBinding(LongProperty param1LongProperty1, LongProperty param1LongProperty2) {
/* 501 */       super(param1LongProperty1, param1LongProperty2);
/* 502 */       this.propertyRef1 = new WeakReference<>(param1LongProperty1);
/* 503 */       this.propertyRef2 = new WeakReference<>(param1LongProperty2);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<Number> getProperty1() {
/* 508 */       return this.propertyRef1.get();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<Number> getProperty2() {
/* 513 */       return this.propertyRef2.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void changed(ObservableValue<? extends Number> param1ObservableValue, Number param1Number1, Number param1Number2) {
/* 518 */       if (!this.updating) {
/* 519 */         LongProperty longProperty1 = this.propertyRef1.get();
/* 520 */         LongProperty longProperty2 = this.propertyRef2.get();
/* 521 */         if (longProperty1 == null || longProperty2 == null) {
/* 522 */           if (longProperty1 != null) {
/* 523 */             longProperty1.removeListener(this);
/*     */           }
/* 525 */           if (longProperty2 != null) {
/* 526 */             longProperty2.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 530 */             this.updating = true;
/* 531 */             if (longProperty1 == param1ObservableValue) {
/* 532 */               longProperty2.set(param1Number2.longValue());
/*     */             } else {
/* 534 */               longProperty1.set(param1Number2.longValue());
/*     */             } 
/* 536 */           } catch (RuntimeException runtimeException) {
/*     */             try {
/* 538 */               if (longProperty1 == param1ObservableValue) {
/* 539 */                 longProperty1.set(param1Number1.longValue());
/*     */               } else {
/* 541 */                 longProperty2.set(param1Number1.longValue());
/*     */               } 
/* 543 */             } catch (Exception exception) {
/* 544 */               exception.addSuppressed(runtimeException);
/* 545 */               unbind(longProperty1, longProperty2);
/* 546 */               throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + longProperty1 + " and " + longProperty2, exception);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 552 */             throw new RuntimeException("Bidirectional binding failed, setting to the previous value", runtimeException);
/*     */           } finally {
/*     */             
/* 555 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TypedGenericBidirectionalBinding<T> extends BidirectionalBinding<T> {
/*     */     private final WeakReference<Property<T>> propertyRef1;
/*     */     private final WeakReference<Property<T>> propertyRef2;
/*     */     private boolean updating = false;
/*     */     
/*     */     private TypedGenericBidirectionalBinding(Property<T> param1Property1, Property<T> param1Property2) {
/* 568 */       super(param1Property1, param1Property2);
/* 569 */       this.propertyRef1 = new WeakReference<>(param1Property1);
/* 570 */       this.propertyRef2 = new WeakReference<>(param1Property2);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<T> getProperty1() {
/* 575 */       return this.propertyRef1.get();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<T> getProperty2() {
/* 580 */       return this.propertyRef2.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void changed(ObservableValue<? extends T> param1ObservableValue, T param1T1, T param1T2) {
/* 585 */       if (!this.updating) {
/* 586 */         Property<? extends T> property = this.propertyRef1.get();
/* 587 */         Property<T> property1 = this.propertyRef2.get();
/* 588 */         if (property == null || property1 == null) {
/* 589 */           if (property != null) {
/* 590 */             property.removeListener(this);
/*     */           }
/* 592 */           if (property1 != null) {
/* 593 */             property1.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 597 */             this.updating = true;
/* 598 */             if (property == param1ObservableValue) {
/* 599 */               property1.setValue(param1T2);
/*     */             } else {
/* 601 */               property.setValue(param1T2);
/*     */             } 
/* 603 */           } catch (RuntimeException runtimeException) {
/*     */             try {
/* 605 */               if (property == param1ObservableValue) {
/* 606 */                 property.setValue(param1T1);
/*     */               } else {
/* 608 */                 property1.setValue(param1T1);
/*     */               } 
/* 610 */             } catch (Exception exception) {
/* 611 */               exception.addSuppressed(runtimeException);
/* 612 */               unbind((Property)property, property1);
/* 613 */               throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + property + " and " + property1, exception);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 619 */             throw new RuntimeException("Bidirectional binding failed, setting to the previous value", runtimeException);
/*     */           } finally {
/*     */             
/* 622 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TypedNumberBidirectionalBinding<T extends Number> extends BidirectionalBinding<Number> {
/*     */     private final WeakReference<Property<T>> propertyRef1;
/*     */     private final WeakReference<Property<Number>> propertyRef2;
/*     */     private boolean updating = false;
/*     */     
/*     */     private TypedNumberBidirectionalBinding(Property<T> param1Property, Property<Number> param1Property1) {
/* 635 */       super(param1Property, param1Property1);
/* 636 */       this.propertyRef1 = new WeakReference<>(param1Property);
/* 637 */       this.propertyRef2 = new WeakReference<>(param1Property1);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<T> getProperty1() {
/* 642 */       return this.propertyRef1.get();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Property<Number> getProperty2() {
/* 647 */       return this.propertyRef2.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void changed(ObservableValue<? extends Number> param1ObservableValue, Number param1Number1, Number param1Number2) {
/* 652 */       if (!this.updating) {
/* 653 */         Property<? extends Number> property = this.propertyRef1.get();
/* 654 */         Property<Number> property1 = this.propertyRef2.get();
/* 655 */         if (property == null || property1 == null) {
/* 656 */           if (property != null) {
/* 657 */             property.removeListener(this);
/*     */           }
/* 659 */           if (property1 != null) {
/* 660 */             property1.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 664 */             this.updating = true;
/* 665 */             if (property == param1ObservableValue) {
/* 666 */               property1.setValue(param1Number2);
/*     */             } else {
/* 668 */               property.setValue(param1Number2);
/*     */             } 
/* 670 */           } catch (RuntimeException runtimeException) {
/*     */             try {
/* 672 */               if (property == param1ObservableValue) {
/* 673 */                 property.setValue(param1Number1);
/*     */               } else {
/* 675 */                 property1.setValue(param1Number1);
/*     */               } 
/* 677 */             } catch (Exception exception) {
/* 678 */               exception.addSuppressed(runtimeException);
/* 679 */               unbind(property, property1);
/* 680 */               throw new RuntimeException("Bidirectional binding failed together with an attempt to restore the source property to the previous value. Removing the bidirectional binding from properties " + property + " and " + property1, exception);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 686 */             throw new RuntimeException("Bidirectional binding failed, setting to the previous value", runtimeException);
/*     */           } finally {
/*     */             
/* 689 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class UntypedGenericBidirectionalBinding
/*     */     extends BidirectionalBinding<Object> {
/*     */     private final Object property1;
/*     */     private final Object property2;
/*     */     
/*     */     public UntypedGenericBidirectionalBinding(Object param1Object1, Object param1Object2) {
/* 702 */       super(param1Object1, param1Object2);
/* 703 */       this.property1 = param1Object1;
/* 704 */       this.property2 = param1Object2;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object getProperty1() {
/* 709 */       return this.property1;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object getProperty2() {
/* 714 */       return this.property2;
/*     */     }
/*     */ 
/*     */     
/*     */     public void changed(ObservableValue<? extends Object> param1ObservableValue, Object param1Object1, Object param1Object2) {
/* 719 */       throw new RuntimeException("Should not reach here");
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract class StringConversionBidirectionalBinding<T>
/*     */     extends BidirectionalBinding<Object> {
/*     */     private final WeakReference<Property<String>> stringPropertyRef;
/*     */     private final WeakReference<Property<T>> otherPropertyRef;
/*     */     private boolean updating;
/*     */     
/*     */     public StringConversionBidirectionalBinding(Property<String> param1Property, Property<T> param1Property1) {
/* 730 */       super(param1Property, param1Property1);
/* 731 */       this.stringPropertyRef = new WeakReference<>(param1Property);
/* 732 */       this.otherPropertyRef = new WeakReference<>(param1Property1);
/*     */     }
/*     */ 
/*     */     
/*     */     protected abstract String toString(T param1T);
/*     */     
/*     */     protected abstract T fromString(String param1String) throws ParseException;
/*     */     
/*     */     protected Object getProperty1() {
/* 741 */       return this.stringPropertyRef.get();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object getProperty2() {
/* 746 */       return this.otherPropertyRef.get();
/*     */     }
/*     */ 
/*     */     
/*     */     public void changed(ObservableValue<? extends Object> param1ObservableValue, Object param1Object1, Object param1Object2) {
/* 751 */       if (!this.updating) {
/* 752 */         Property<? extends Object> property = (Property)this.stringPropertyRef.get();
/* 753 */         Property<T> property1 = this.otherPropertyRef.get();
/* 754 */         if (property == null || property1 == null) {
/* 755 */           if (property != null) {
/* 756 */             property.removeListener(this);
/*     */           }
/* 758 */           if (property1 != null) {
/* 759 */             property1.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 763 */             this.updating = true;
/* 764 */             if (property == param1ObservableValue) {
/*     */               try {
/* 766 */                 property1.setValue(fromString((String)property.getValue()));
/* 767 */               } catch (Exception exception) {
/* 768 */                 Logging.getLogger().warning("Exception while parsing String in bidirectional binding", exception);
/* 769 */                 property1.setValue((T)null);
/*     */               } 
/*     */             } else {
/*     */               try {
/* 773 */                 property.setValue(toString(property1.getValue()));
/* 774 */               } catch (Exception exception) {
/* 775 */                 Logging.getLogger().warning("Exception while converting Object to String in bidirectional binding", exception);
/* 776 */                 property.setValue("");
/*     */               } 
/*     */             } 
/*     */           } finally {
/* 780 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class StringFormatBidirectionalBinding
/*     */     extends StringConversionBidirectionalBinding
/*     */   {
/*     */     private final Format format;
/*     */     
/*     */     public StringFormatBidirectionalBinding(Property<String> param1Property, Property<?> param1Property1, Format param1Format) {
/* 793 */       super(param1Property, (Property)param1Property1);
/* 794 */       this.format = param1Format;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String toString(Object param1Object) {
/* 799 */       return this.format.format(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object fromString(String param1String) throws ParseException {
/* 804 */       return this.format.parseObject(param1String);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class StringConverterBidirectionalBinding<T>
/*     */     extends StringConversionBidirectionalBinding<T> {
/*     */     private final StringConverter<T> converter;
/*     */     
/*     */     public StringConverterBidirectionalBinding(Property<String> param1Property, Property<T> param1Property1, StringConverter<T> param1StringConverter) {
/* 813 */       super(param1Property, param1Property1);
/* 814 */       this.converter = param1StringConverter;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String toString(T param1T) {
/* 819 */       return this.converter.toString(param1T);
/*     */     }
/*     */ 
/*     */     
/*     */     protected T fromString(String param1String) throws ParseException {
/* 824 */       return this.converter.fromString(param1String);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\binding\BidirectionalBinding.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */