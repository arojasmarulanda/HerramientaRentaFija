/*     */ package com.sun.javafx.reflect;
/*     */ 
/*     */ import java.lang.reflect.Proxy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReflectUtil
/*     */ {
/*     */   public static final String PROXY_PACKAGE = "com.sun.proxy";
/*     */   
/*     */   public static void checkPackageAccess(Class<?> paramClass) {
/*  44 */     SecurityManager securityManager = System.getSecurityManager();
/*  45 */     if (securityManager != null) {
/*  46 */       privateCheckPackageAccess(securityManager, paramClass);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void privateCheckPackageAccess(SecurityManager paramSecurityManager, Class<?> paramClass) {
/*  54 */     while (paramClass.isArray()) {
/*  55 */       paramClass = paramClass.getComponentType();
/*     */     }
/*     */     
/*  58 */     String str = paramClass.getPackageName();
/*  59 */     if (str != null && !str.isEmpty()) {
/*  60 */       paramSecurityManager.checkPackageAccess(str);
/*     */     }
/*     */     
/*  63 */     if (isNonPublicProxyClass(paramClass)) {
/*  64 */       privateCheckProxyPackageAccess(paramSecurityManager, paramClass);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkPackageAccess(String paramString) {
/*  75 */     SecurityManager securityManager = System.getSecurityManager();
/*  76 */     if (securityManager != null) {
/*  77 */       String str = paramString.replace('/', '.');
/*  78 */       if (str.startsWith("[")) {
/*  79 */         int j = str.lastIndexOf('[') + 2;
/*  80 */         if (j > 1 && j < str.length()) {
/*  81 */           str = str.substring(j);
/*     */         }
/*     */       } 
/*  84 */       int i = str.lastIndexOf('.');
/*  85 */       if (i != -1) {
/*  86 */         securityManager.checkPackageAccess(str.substring(0, i));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isPackageAccessible(Class<?> paramClass) {
/*     */     try {
/*  93 */       checkPackageAccess(paramClass);
/*  94 */     } catch (SecurityException securityException) {
/*  95 */       return false;
/*     */     } 
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void privateCheckProxyPackageAccess(SecurityManager paramSecurityManager, Class<?> paramClass) {
/* 105 */     if (Proxy.isProxyClass(paramClass)) {
/* 106 */       for (Class<?> clazz : paramClass.getInterfaces()) {
/* 107 */         privateCheckPackageAccess(paramSecurityManager, clazz);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNonPublicProxyClass(Class<?> paramClass) {
/* 122 */     if (!Proxy.isProxyClass(paramClass)) {
/* 123 */       return false;
/*     */     }
/* 125 */     String str = paramClass.getPackageName();
/* 126 */     return (str == null || !str.startsWith("com.sun.proxy"));
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\reflect\ReflectUtil.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */