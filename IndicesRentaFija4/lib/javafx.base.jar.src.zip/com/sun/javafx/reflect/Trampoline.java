/*    */ package com.sun.javafx.reflect;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.AccessController;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Trampoline
/*    */ {
/*    */   static {
/* 51 */     if (Trampoline.class.getClassLoader() == null) {
/* 52 */       throw new Error("Trampoline must not be defined by the bootstrap classloader");
/*    */     }
/*    */     
/* 55 */     if (Trampoline.class.getClassLoader() == ClassLoader.getPlatformClassLoader()) {
/* 56 */       throw new Error("Trampoline must not be defined by the platform classloader");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static void ensureInvocableMethod(Method paramMethod) throws InvocationTargetException {
/* 64 */     Class<?> clazz = paramMethod.getDeclaringClass();
/* 65 */     if (clazz.equals(AccessController.class) || clazz
/* 66 */       .equals(Method.class) || clazz
/* 67 */       .getName().startsWith("java.lang.invoke.")) {
/* 68 */       throw new InvocationTargetException(new UnsupportedOperationException("invocation not supported"));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static Object invoke(Method paramMethod, Object paramObject, Object[] paramArrayOfObject) throws InvocationTargetException, IllegalAccessException {
/* 75 */     ensureInvocableMethod(paramMethod);
/* 76 */     return paramMethod.invoke(paramObject, paramArrayOfObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\reflect\Trampoline.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */