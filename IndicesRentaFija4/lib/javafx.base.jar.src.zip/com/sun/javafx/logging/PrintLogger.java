/*     */ package com.sun.javafx.logging;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PrintLogger
/*     */   extends Logger
/*     */ {
/*     */   private static PrintLogger printLogger;
/*  65 */   private static long THRESHOLD = ((Integer)AccessController.<Integer>doPrivileged(() -> Integer.getInteger("javafx.pulseLogger.threshold", 17))).intValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private static final int EXIT_ON_PULSE = ((Integer)AccessController.<Integer>doPrivileged(() -> Integer.getInteger("javafx.pulseLogger.exitOnPulse", 0))).intValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private int pulseCount = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int INTER_PULSE_DATA = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private volatile int wrapCount = 0;
/*     */   
/*     */   private volatile PulseData fxData;
/*     */   
/*     */   private volatile PulseData renderData;
/*     */   
/*     */   private long lastPulseStartTime;
/*     */   
/*     */   private Thread fxThread;
/*     */ 
/*     */   
/*     */   class ThreadLocalData
/*     */   {
/*     */     String phaseName;
/*     */     
/*     */     long phaseStart;
/*     */   }
/*     */ 
/*     */   
/* 112 */   private final ThreadLocal<ThreadLocalData> phaseData = new ThreadLocal<ThreadLocalData>()
/*     */     {
/*     */       public PrintLogger.ThreadLocalData initialValue()
/*     */       {
/* 116 */         return new PrintLogger.ThreadLocalData();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PulseData head;
/*     */ 
/*     */ 
/*     */   
/*     */   private PulseData tail;
/*     */ 
/*     */ 
/*     */   
/*     */   private AtomicInteger active;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int AVAILABLE = 0;
/*     */ 
/*     */   
/*     */   private static final int INCOMPLETE = 1;
/*     */ 
/*     */   
/*     */   private static final int COMPLETE = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   private PrintLogger() {
/* 146 */     this.head = new PulseData();
/* 147 */     this.tail = new PulseData();
/* 148 */     this.head.next = this.tail;
/* 149 */     this.active = new AtomicInteger(0);
/*     */   }
/*     */   
/*     */   public static Logger getInstance() {
/* 153 */     if (printLogger == null) {
/* 154 */       boolean bool = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.pulseLogger")))).booleanValue();
/* 155 */       if (bool) {
/* 156 */         printLogger = new PrintLogger();
/*     */       }
/*     */     } 
/* 159 */     return printLogger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PulseData allocate(int paramInt) {
/*     */     PulseData pulseData;
/* 167 */     if (this.head != this.tail && this.head.state == 0) {
/* 168 */       pulseData = this.head;
/* 169 */       this.head = this.head.next;
/* 170 */       pulseData.next = null;
/*     */     } else {
/*     */       
/* 173 */       pulseData = new PulseData();
/*     */     } 
/* 175 */     this.tail.next = pulseData;
/* 176 */     this.tail = pulseData;
/* 177 */     pulseData.init(paramInt);
/* 178 */     return pulseData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pulseStart() {
/* 188 */     if (this.fxThread == null) {
/* 189 */       this.fxThread = Thread.currentThread();
/*     */     }
/* 191 */     if (this.fxData != null) {
/*     */       
/* 193 */       this.fxData.state = 2;
/* 194 */       if (this.active.incrementAndGet() == 1) {
/* 195 */         this.fxData.printAndReset();
/* 196 */         this.active.decrementAndGet();
/*     */       } 
/*     */     } 
/* 199 */     this.fxData = allocate(this.pulseCount++);
/* 200 */     if (this.lastPulseStartTime > 0L) {
/* 201 */       this.fxData.interval = (this.fxData.startTime - this.lastPulseStartTime) / 1000000L;
/*     */     }
/* 203 */     this.lastPulseStartTime = this.fxData.startTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderStart() {
/* 217 */     newPhase(null);
/* 218 */     this.fxData.pushedRender = true;
/* 219 */     this.renderData = this.fxData;
/* 220 */     this.active.incrementAndGet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pulseEnd() {
/* 232 */     if (this.fxData != null && !this.fxData.pushedRender) {
/* 233 */       this.fxData.state = 2;
/* 234 */       if (this.active.incrementAndGet() == 1) {
/* 235 */         this.fxData.printAndReset();
/* 236 */         this.active.decrementAndGet();
/*     */       } 
/*     */     } 
/* 239 */     this.fxData = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderEnd() {
/* 249 */     newPhase(null);
/* 250 */     this.renderData.state = 2;
/*     */     while (true) {
/* 252 */       this.renderData.printAndReset();
/* 253 */       if (this.active.decrementAndGet() == 0) {
/*     */         break;
/*     */       }
/* 256 */       this.renderData = this.renderData.next;
/*     */     } 
/* 258 */     this.renderData = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMessage(String paramString) {
/*     */     PulseData pulseData;
/* 268 */     if (this.fxThread == null || Thread.currentThread() == this.fxThread) {
/* 269 */       if (this.fxData == null) {
/* 270 */         this.fxData = allocate(-1);
/*     */       }
/* 272 */       pulseData = this.fxData;
/*     */     } else {
/*     */       
/* 275 */       pulseData = this.renderData;
/*     */     } 
/* 277 */     if (pulseData == null) {
/*     */       return;
/*     */     }
/* 280 */     pulseData.message
/* 281 */       .append("T")
/* 282 */       .append(Thread.currentThread().getId())
/* 283 */       .append(" : ")
/* 284 */       .append(paramString)
/* 285 */       .append("\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementCounter(String paramString) {
/*     */     PulseData pulseData;
/* 295 */     if (this.fxThread == null || Thread.currentThread() == this.fxThread) {
/* 296 */       if (this.fxData == null) {
/* 297 */         this.fxData = allocate(-1);
/*     */       }
/* 299 */       pulseData = this.fxData;
/*     */     } else {
/*     */       
/* 302 */       pulseData = this.renderData;
/*     */     } 
/* 304 */     if (pulseData == null) {
/*     */       return;
/*     */     }
/* 307 */     Map<String, Counter> map = pulseData.counters;
/* 308 */     Counter counter = map.get(paramString);
/* 309 */     if (counter == null) {
/* 310 */       counter = new Counter();
/* 311 */       map.put(paramString, counter);
/*     */     } 
/* 313 */     counter.value++;
/*     */   }
/*     */ 
/*     */   
/*     */   public void newPhase(String paramString) {
/* 318 */     long l = System.nanoTime();
/*     */     
/* 320 */     ThreadLocalData threadLocalData = this.phaseData.get();
/* 321 */     if (threadLocalData.phaseName != null) {
/* 322 */       PulseData pulseData = (Thread.currentThread() == this.fxThread) ? this.fxData : this.renderData;
/* 323 */       if (pulseData != null) {
/* 324 */         pulseData.message
/* 325 */           .append("T")
/* 326 */           .append(Thread.currentThread().getId())
/* 327 */           .append(" (").append((threadLocalData.phaseStart - pulseData.startTime) / 1000000L)
/* 328 */           .append(" +").append((l - threadLocalData.phaseStart) / 1000000L).append("ms): ")
/* 329 */           .append(threadLocalData.phaseName)
/* 330 */           .append("\n");
/*     */       }
/*     */     } 
/* 333 */     threadLocalData.phaseName = paramString;
/* 334 */     threadLocalData.phaseStart = l;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Counter
/*     */   {
/*     */     int value;
/*     */ 
/*     */     
/*     */     private Counter() {}
/*     */   }
/*     */ 
/*     */   
/*     */   private final class PulseData
/*     */   {
/*     */     PulseData next;
/*     */     
/* 352 */     volatile int state = 0;
/*     */     long startTime;
/*     */     long interval;
/*     */     int pulseCount;
/*     */     boolean pushedRender;
/* 357 */     StringBuffer message = new StringBuffer();
/* 358 */     Map<String, PrintLogger.Counter> counters = new ConcurrentHashMap<>();
/*     */     
/*     */     void init(int param1Int) {
/* 361 */       this.state = 1;
/* 362 */       this.pulseCount = param1Int;
/* 363 */       this.startTime = System.nanoTime();
/* 364 */       this.interval = 0L;
/* 365 */       this.pushedRender = false;
/*     */     }
/*     */     
/*     */     void printAndReset() {
/* 369 */       long l1 = System.nanoTime();
/* 370 */       long l2 = (l1 - this.startTime) / 1000000L;
/*     */       
/* 372 */       if (this.state != 2) {
/* 373 */         System.err.println("\nWARNING: logging incomplete state");
/*     */       }
/*     */       
/* 376 */       if (l2 <= PrintLogger.THRESHOLD) {
/*     */         
/* 378 */         if (this.pulseCount != -1) {
/* 379 */           System.err.print(((PrintLogger.this.wrapCount++ % 10 == 0) ? "\n[" : "[") + ((PrintLogger.this.wrapCount++ % 10 == 0) ? "\n[" : "[") + " " + this.pulseCount + "ms:" + this.interval + "ms]");
/*     */         }
/*     */       } else {
/*     */         
/* 383 */         if (this.pulseCount == -1) {
/* 384 */           System.err.println("\n\nINTER PULSE LOG DATA");
/*     */         } else {
/*     */           
/* 387 */           System.err.print("\n\nPULSE: " + this.pulseCount + " [" + this.interval + "ms:" + l2 + "ms]");
/*     */           
/* 389 */           if (!this.pushedRender) {
/* 390 */             System.err.print(" Required No Rendering");
/*     */           }
/* 392 */           System.err.println();
/*     */         } 
/* 394 */         System.err.print(this.message);
/* 395 */         if (!this.counters.isEmpty()) {
/* 396 */           System.err.println("Counters:");
/* 397 */           ArrayList<?> arrayList = new ArrayList(this.counters.entrySet());
/* 398 */           Collections.sort(arrayList, (param1Entry1, param1Entry2) -> ((String)param1Entry1.getKey()).compareTo((String)param1Entry2.getKey()));
/* 399 */           for (Map.Entry entry : arrayList) {
/* 400 */             System.err.println("\t" + (String)entry.getKey() + ": " + ((PrintLogger.Counter)entry.getValue()).value);
/*     */           }
/*     */         } 
/* 403 */         PrintLogger.this.wrapCount = 0;
/*     */       } 
/*     */ 
/*     */       
/* 407 */       this.message.setLength(0);
/* 408 */       this.counters.clear();
/* 409 */       this.state = 0;
/* 410 */       if (PrintLogger.EXIT_ON_PULSE > 0 && this.pulseCount >= PrintLogger.EXIT_ON_PULSE) {
/* 411 */         System.err.println("Exiting after pulse #" + this.pulseCount);
/* 412 */         System.exit(0);
/*     */       } 
/*     */     }
/*     */     
/*     */     private PulseData() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\logging\PrintLogger.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */