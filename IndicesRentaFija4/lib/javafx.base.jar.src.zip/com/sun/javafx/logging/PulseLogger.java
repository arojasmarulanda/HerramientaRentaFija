/*     */ package com.sun.javafx.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PulseLogger
/*     */ {
/*     */   public static final boolean PULSE_LOGGING_ENABLED;
/*     */   private static final Logger[] loggers;
/*     */   
/*     */   static {
/*  40 */     ArrayList<Logger> arrayList = new ArrayList();
/*  41 */     Logger logger = PrintLogger.getInstance();
/*  42 */     if (logger != null) {
/*  43 */       arrayList.add(logger);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     loggers = arrayList.<Logger>toArray(new Logger[arrayList.size()]);
/*  62 */     PULSE_LOGGING_ENABLED = (loggers.length > 0);
/*     */   }
/*     */   
/*     */   public static void pulseStart() {
/*  66 */     for (Logger logger : loggers) {
/*  67 */       logger.pulseStart();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void pulseEnd() {
/*  72 */     for (Logger logger : loggers) {
/*  73 */       logger.pulseEnd();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void renderStart() {
/*  78 */     for (Logger logger : loggers) {
/*  79 */       logger.renderStart();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void renderEnd() {
/*  84 */     for (Logger logger : loggers) {
/*  85 */       logger.renderEnd();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void addMessage(String paramString) {
/*  90 */     for (Logger logger : loggers) {
/*  91 */       logger.addMessage(paramString);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void incrementCounter(String paramString) {
/*  96 */     for (Logger logger : loggers) {
/*  97 */       logger.incrementCounter(paramString);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void newPhase(String paramString) {
/* 102 */     for (Logger logger : loggers) {
/* 103 */       logger.newPhase(paramString);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void newInput(String paramString) {
/* 108 */     for (Logger logger : loggers)
/* 109 */       logger.newInput(paramString); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\logging\PulseLogger.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */