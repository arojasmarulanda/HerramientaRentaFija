package com.sun.javafx.logging;

public class Logger {
  public void pulseStart() {}
  
  public void pulseEnd() {}
  
  public void renderStart() {}
  
  public void renderEnd() {}
  
  public void addMessage(String paramString) {}
  
  public void incrementCounter(String paramString) {}
  
  public void newPhase(String paramString) {}
  
  public void newInput(String paramString) {}
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\com\sun\javafx\logging\Logger.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */