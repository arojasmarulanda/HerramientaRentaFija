package javafx.beans;

public interface Observable {
  void addListener(InvalidationListener paramInvalidationListener);
  
  void removeListener(InvalidationListener paramInvalidationListener);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\Observable.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */