/*     */ package javafx.beans.binding;
/*     */ 
/*     */ import com.sun.javafx.binding.BindingHelperObserver;
/*     */ import com.sun.javafx.binding.MapExpressionHelper;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerPropertyBase;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MapBinding<K, V>
/*     */   extends MapExpression<K, V>
/*     */   implements Binding<ObservableMap<K, V>>
/*     */ {
/*  70 */   private final MapChangeListener<K, V> mapChangeListener = new MapChangeListener<K, V>()
/*     */     {
/*     */       public void onChanged(MapChangeListener.Change<? extends K, ? extends V> param1Change) {
/*  73 */         MapBinding.this.invalidateProperties();
/*  74 */         MapBinding.this.onInvalidating();
/*  75 */         MapExpressionHelper.fireValueChangedEvent(MapBinding.this.helper, param1Change);
/*     */       }
/*     */     };
/*     */   
/*     */   private ObservableMap<K, V> value;
/*     */   private boolean valid = false;
/*     */   private BindingHelperObserver observer;
/*  82 */   private MapExpressionHelper<K, V> helper = null;
/*     */   
/*     */   private SizeProperty size0;
/*     */   
/*     */   private EmptyProperty empty0;
/*     */   
/*     */   public ReadOnlyIntegerProperty sizeProperty() {
/*  89 */     if (this.size0 == null) {
/*  90 */       this.size0 = new SizeProperty();
/*     */     }
/*  92 */     return this.size0;
/*     */   }
/*     */   
/*     */   private class SizeProperty
/*     */     extends ReadOnlyIntegerPropertyBase {
/*     */     public int get() {
/*  98 */       return MapBinding.this.size();
/*     */     }
/*     */     private SizeProperty() {}
/*     */     
/*     */     public Object getBean() {
/* 103 */       return MapBinding.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 108 */       return "size";
/*     */     }
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 112 */       super.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ReadOnlyBooleanProperty emptyProperty() {
/* 118 */     if (this.empty0 == null) {
/* 119 */       this.empty0 = new EmptyProperty();
/*     */     }
/* 121 */     return this.empty0;
/*     */   }
/*     */   
/*     */   private class EmptyProperty extends ReadOnlyBooleanPropertyBase {
/*     */     private EmptyProperty() {}
/*     */     
/*     */     public boolean get() {
/* 128 */       return MapBinding.this.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getBean() {
/* 133 */       return MapBinding.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 138 */       return "empty";
/*     */     }
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 142 */       super.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(InvalidationListener paramInvalidationListener) {
/* 148 */     this.helper = MapExpressionHelper.addListener(this.helper, this, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(InvalidationListener paramInvalidationListener) {
/* 153 */     this.helper = MapExpressionHelper.removeListener(this.helper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener) {
/* 158 */     this.helper = MapExpressionHelper.addListener(this.helper, this, paramChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(ChangeListener<? super ObservableMap<K, V>> paramChangeListener) {
/* 163 */     this.helper = MapExpressionHelper.removeListener(this.helper, paramChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener) {
/* 168 */     this.helper = MapExpressionHelper.addListener(this.helper, this, paramMapChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener) {
/* 173 */     this.helper = MapExpressionHelper.removeListener(this.helper, paramMapChangeListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void bind(Observable... paramVarArgs) {
/* 184 */     if (paramVarArgs != null && paramVarArgs.length > 0) {
/* 185 */       if (this.observer == null) {
/* 186 */         this.observer = new BindingHelperObserver(this);
/*     */       }
/* 188 */       for (Observable observable : paramVarArgs) {
/* 189 */         if (observable != null) {
/* 190 */           observable.addListener(this.observer);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void unbind(Observable... paramVarArgs) {
/* 203 */     if (this.observer != null) {
/* 204 */       for (Observable observable : paramVarArgs) {
/* 205 */         if (observable != null) {
/* 206 */           observable.removeListener(this.observer);
/*     */         }
/*     */       } 
/* 209 */       this.observer = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<?> getDependencies() {
/* 228 */     return FXCollections.emptyObservableList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableMap<K, V> get() {
/* 241 */     if (!this.valid) {
/* 242 */       this.value = computeValue();
/* 243 */       this.valid = true;
/* 244 */       if (this.value != null) {
/* 245 */         this.value.addListener(this.mapChangeListener);
/*     */       }
/*     */     } 
/* 248 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onInvalidating() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void invalidateProperties() {
/* 260 */     if (this.size0 != null) {
/* 261 */       this.size0.fireValueChangedEvent();
/*     */     }
/* 263 */     if (this.empty0 != null) {
/* 264 */       this.empty0.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void invalidate() {
/* 270 */     if (this.valid) {
/* 271 */       if (this.value != null) {
/* 272 */         this.value.removeListener(this.mapChangeListener);
/*     */       }
/* 274 */       this.valid = false;
/* 275 */       invalidateProperties();
/* 276 */       onInvalidating();
/* 277 */       MapExpressionHelper.fireValueChangedEvent(this.helper);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isValid() {
/* 283 */     return this.valid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 302 */     return this.valid ? ("MapBinding [value: " + get() + "]") : 
/* 303 */       "MapBinding [invalid]";
/*     */   }
/*     */   
/*     */   protected abstract ObservableMap<K, V> computeValue();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\binding\MapBinding.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */