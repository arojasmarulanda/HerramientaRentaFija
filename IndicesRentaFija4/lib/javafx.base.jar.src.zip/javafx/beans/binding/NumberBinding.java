package javafx.beans.binding;

public interface NumberBinding extends Binding<Number>, NumberExpression {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\binding\NumberBinding.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */