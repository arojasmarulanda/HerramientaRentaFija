package javafx.beans.value;

public interface WritableValue<T> {
  T getValue();
  
  void setValue(T paramT);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\WritableValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */