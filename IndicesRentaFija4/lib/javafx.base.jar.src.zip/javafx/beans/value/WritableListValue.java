package javafx.beans.value;

import javafx.collections.ObservableList;

public interface WritableListValue<E> extends WritableObjectValue<ObservableList<E>>, ObservableList<E> {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\WritableListValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */