package javafx.beans.value;

public interface WritableObjectValue<T> extends WritableValue<T> {
  T get();
  
  void set(T paramT);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\WritableObjectValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */