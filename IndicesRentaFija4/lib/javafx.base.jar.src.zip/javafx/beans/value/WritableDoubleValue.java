package javafx.beans.value;

public interface WritableDoubleValue extends WritableNumberValue {
  double get();
  
  void set(double paramDouble);
  
  void setValue(Number paramNumber);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\WritableDoubleValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */