package javafx.beans.value;

public interface ObservableLongValue extends ObservableNumberValue {
  long get();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\ObservableLongValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */