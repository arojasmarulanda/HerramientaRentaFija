package javafx.beans.value;

public interface WritableStringValue extends WritableObjectValue<String> {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\WritableStringValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */