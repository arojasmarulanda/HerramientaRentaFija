package javafx.beans.value;

import javafx.collections.ObservableSet;

public interface ObservableSetValue<E> extends ObservableObjectValue<ObservableSet<E>>, ObservableSet<E> {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\ObservableSetValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */