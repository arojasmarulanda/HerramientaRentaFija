package javafx.beans.value;

import javafx.collections.ObservableSet;

public interface WritableSetValue<E> extends WritableObjectValue<ObservableSet<E>>, ObservableSet<E> {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\WritableSetValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */