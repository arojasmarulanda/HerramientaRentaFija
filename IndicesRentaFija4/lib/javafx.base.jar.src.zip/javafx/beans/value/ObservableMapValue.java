package javafx.beans.value;

import javafx.collections.ObservableMap;

public interface ObservableMapValue<K, V> extends ObservableObjectValue<ObservableMap<K, V>>, ObservableMap<K, V> {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\ObservableMapValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */