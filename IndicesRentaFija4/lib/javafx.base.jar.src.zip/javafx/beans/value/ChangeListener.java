package javafx.beans.value;

@FunctionalInterface
public interface ChangeListener<T> {
  void changed(ObservableValue<? extends T> paramObservableValue, T paramT1, T paramT2);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\ChangeListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */