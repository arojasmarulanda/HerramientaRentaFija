package javafx.beans.value;

import javafx.collections.ObservableList;

public interface ObservableListValue<E> extends ObservableObjectValue<ObservableList<E>>, ObservableList<E> {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\ObservableListValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */