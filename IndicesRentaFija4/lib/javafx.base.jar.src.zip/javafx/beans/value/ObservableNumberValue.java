package javafx.beans.value;

public interface ObservableNumberValue extends ObservableValue<Number> {
  int intValue();
  
  long longValue();
  
  float floatValue();
  
  double doubleValue();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\value\ObservableNumberValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */