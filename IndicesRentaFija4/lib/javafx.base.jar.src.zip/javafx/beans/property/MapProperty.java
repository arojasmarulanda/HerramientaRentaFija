/*     */ package javafx.beans.property;
/*     */ 
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.value.WritableMapValue;
/*     */ import javafx.collections.ObservableMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MapProperty<K, V>
/*     */   extends ReadOnlyMapProperty<K, V>
/*     */   implements Property<ObservableMap<K, V>>, WritableMapValue<K, V>
/*     */ {
/*     */   public void setValue(ObservableMap<K, V> paramObservableMap) {
/*  64 */     set(paramObservableMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindBidirectional(Property<ObservableMap<K, V>> paramProperty) {
/*  72 */     Bindings.bindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindBidirectional(Property<ObservableMap<K, V>> paramProperty) {
/*  80 */     Bindings.unbindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  89 */     Object object = getBean();
/*  90 */     String str = getName();
/*  91 */     StringBuilder stringBuilder = new StringBuilder("MapProperty [");
/*     */     
/*  93 */     if (object != null) {
/*  94 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/*  96 */     if (str != null && !str.equals("")) {
/*  97 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/*  99 */     stringBuilder.append("value: ").append(get()).append("]");
/* 100 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\property\MapProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */