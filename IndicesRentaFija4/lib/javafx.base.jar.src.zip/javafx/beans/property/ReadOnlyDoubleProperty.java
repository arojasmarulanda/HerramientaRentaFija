/*     */ package javafx.beans.property;
/*     */ 
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.binding.DoubleExpression;
/*     */ import javafx.beans.binding.ObjectExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReadOnlyDoubleProperty
/*     */   extends DoubleExpression
/*     */   implements ReadOnlyProperty<Number>
/*     */ {
/*     */   public String toString() {
/*  57 */     Object object = getBean();
/*  58 */     String str = getName();
/*  59 */     StringBuilder stringBuilder = new StringBuilder("ReadOnlyDoubleProperty [");
/*     */     
/*  61 */     if (object != null) {
/*  62 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/*  64 */     if (str != null && !str.equals("")) {
/*  65 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/*  67 */     stringBuilder.append("value: ").append(get()).append("]");
/*  68 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Number> ReadOnlyDoubleProperty readOnlyDoubleProperty(final ReadOnlyProperty<T> property) {
/*  91 */     if (property == null) {
/*  92 */       throw new NullPointerException("Property cannot be null");
/*     */     }
/*     */     
/*  95 */     return (property instanceof ReadOnlyDoubleProperty) ? (ReadOnlyDoubleProperty)property : 
/*  96 */       new ReadOnlyDoublePropertyBase()
/*     */       {
/*     */         private boolean valid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final InvalidationListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public double get() {
/* 111 */           this.valid = true;
/* 112 */           Number number = property.getValue();
/* 113 */           return (number == null) ? 0.0D : number.doubleValue();
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 118 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 123 */           return property.getName();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyObjectProperty<Double> asObject() {
/* 139 */     return new ReadOnlyObjectPropertyBase<Double>()
/*     */       {
/*     */         private boolean valid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final InvalidationListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 155 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 160 */           return ReadOnlyDoubleProperty.this.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         public Double get() {
/* 165 */           this.valid = true;
/* 166 */           return ReadOnlyDoubleProperty.this.getValue();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\property\ReadOnlyDoubleProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */