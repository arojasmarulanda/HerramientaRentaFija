/*     */ package javafx.beans.property;
/*     */ 
/*     */ import java.text.Format;
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.value.WritableStringValue;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StringProperty
/*     */   extends ReadOnlyStringProperty
/*     */   implements Property<String>, WritableStringValue
/*     */ {
/*     */   public void setValue(String paramString) {
/*  65 */     set(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindBidirectional(Property<String> paramProperty) {
/*  73 */     Bindings.bindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindBidirectional(Property<?> paramProperty, Format paramFormat) {
/*  92 */     Bindings.bindBidirectional(this, paramProperty, paramFormat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void bindBidirectional(Property<T> paramProperty, StringConverter<T> paramStringConverter) {
/* 112 */     Bindings.bindBidirectional(this, paramProperty, paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindBidirectional(Property<String> paramProperty) {
/* 120 */     Bindings.unbindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindBidirectional(Object paramObject) {
/* 139 */     Bindings.unbindBidirectional(this, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     Object object = getBean();
/* 149 */     String str = getName();
/* 150 */     StringBuilder stringBuilder = new StringBuilder("StringProperty [");
/*     */     
/* 152 */     if (object != null) {
/* 153 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 155 */     if (str != null && !str.equals("")) {
/* 156 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 158 */     stringBuilder.append("value: ").append(get()).append("]");
/* 159 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\property\StringProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */