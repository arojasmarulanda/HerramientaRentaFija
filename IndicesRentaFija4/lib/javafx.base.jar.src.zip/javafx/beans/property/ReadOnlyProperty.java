package javafx.beans.property;

import javafx.beans.value.ObservableValue;

public interface ReadOnlyProperty<T> extends ObservableValue<T> {
  Object getBean();
  
  String getName();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\property\ReadOnlyProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */