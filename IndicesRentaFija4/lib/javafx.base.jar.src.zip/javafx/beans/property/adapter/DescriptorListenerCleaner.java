/*    */ package javafx.beans.property.adapter;
/*    */ 
/*    */ import com.sun.javafx.property.adapter.ReadOnlyPropertyDescriptor;
/*    */ import java.lang.ref.WeakReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DescriptorListenerCleaner
/*    */   implements Runnable
/*    */ {
/*    */   private final ReadOnlyPropertyDescriptor pd;
/*    */   private final WeakReference<ReadOnlyPropertyDescriptor.ReadOnlyListener<?>> lRef;
/*    */   
/*    */   DescriptorListenerCleaner(ReadOnlyPropertyDescriptor paramReadOnlyPropertyDescriptor, ReadOnlyPropertyDescriptor.ReadOnlyListener<?> paramReadOnlyListener) {
/* 37 */     this.pd = paramReadOnlyPropertyDescriptor;
/* 38 */     this.lRef = new WeakReference<>(paramReadOnlyListener);
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 43 */     ReadOnlyPropertyDescriptor.ReadOnlyListener readOnlyListener = this.lRef.get();
/* 44 */     if (readOnlyListener != null)
/* 45 */       this.pd.removeListener(readOnlyListener); 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\property\adapter\DescriptorListenerCleaner.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */