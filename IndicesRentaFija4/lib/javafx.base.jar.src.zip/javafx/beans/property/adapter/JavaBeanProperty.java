package javafx.beans.property.adapter;

import javafx.beans.property.Property;

public interface JavaBeanProperty<T> extends ReadOnlyJavaBeanProperty<T>, Property<T> {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\property\adapter\JavaBeanProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */