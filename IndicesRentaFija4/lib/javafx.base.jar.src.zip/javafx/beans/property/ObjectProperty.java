/*     */ package javafx.beans.property;
/*     */ 
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.value.WritableObjectValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ObjectProperty<T>
/*     */   extends ReadOnlyObjectProperty<T>
/*     */   implements Property<T>, WritableObjectValue<T>
/*     */ {
/*     */   public void setValue(T paramT) {
/*  72 */     set(paramT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindBidirectional(Property<T> paramProperty) {
/*  80 */     Bindings.bindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindBidirectional(Property<T> paramProperty) {
/*  88 */     Bindings.unbindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  97 */     Object object = getBean();
/*  98 */     String str = getName();
/*  99 */     StringBuilder stringBuilder = new StringBuilder("ObjectProperty [");
/*     */     
/* 101 */     if (object != null) {
/* 102 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 104 */     if (str != null && !str.equals("")) {
/* 105 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 107 */     stringBuilder.append("value: ").append(get()).append("]");
/* 108 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\property\ObjectProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */