/*    */ package javafx.beans.property;
/*    */ 
/*    */ import javafx.beans.binding.Bindings;
/*    */ import javafx.beans.value.WritableListValue;
/*    */ import javafx.collections.ObservableList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ListProperty<E>
/*    */   extends ReadOnlyListProperty<E>
/*    */   implements Property<ObservableList<E>>, WritableListValue<E>
/*    */ {
/*    */   public void setValue(ObservableList<E> paramObservableList) {
/* 63 */     set(paramObservableList);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void bindBidirectional(Property<ObservableList<E>> paramProperty) {
/* 71 */     Bindings.bindBidirectional(this, paramProperty);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void unbindBidirectional(Property<ObservableList<E>> paramProperty) {
/* 79 */     Bindings.unbindBidirectional(this, paramProperty);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 88 */     Object object = getBean();
/* 89 */     String str = getName();
/* 90 */     StringBuilder stringBuilder = new StringBuilder("ListProperty [");
/*    */     
/* 92 */     if (object != null) {
/* 93 */       stringBuilder.append("bean: ").append(object).append(", ");
/*    */     }
/* 95 */     if (str != null && !str.equals("")) {
/* 96 */       stringBuilder.append("name: ").append(str).append(", ");
/*    */     }
/* 98 */     stringBuilder.append("value: ").append(get()).append("]");
/* 99 */     return stringBuilder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\property\ListProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */