/*     */ package javafx.beans.property;
/*     */ 
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.value.WritableSetValue;
/*     */ import javafx.collections.ObservableSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SetProperty<E>
/*     */   extends ReadOnlySetProperty<E>
/*     */   implements Property<ObservableSet<E>>, WritableSetValue<E>
/*     */ {
/*     */   public void setValue(ObservableSet<E> paramObservableSet) {
/*  65 */     set(paramObservableSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindBidirectional(Property<ObservableSet<E>> paramProperty) {
/*  73 */     Bindings.bindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindBidirectional(Property<ObservableSet<E>> paramProperty) {
/*  81 */     Bindings.unbindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     Object object = getBean();
/*  91 */     String str = getName();
/*  92 */     StringBuilder stringBuilder = new StringBuilder("SetProperty [");
/*     */     
/*  94 */     if (object != null) {
/*  95 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/*  97 */     if (str != null && !str.equals("")) {
/*  98 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 100 */     stringBuilder.append("value: ").append(get()).append("]");
/* 101 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\property\SetProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */