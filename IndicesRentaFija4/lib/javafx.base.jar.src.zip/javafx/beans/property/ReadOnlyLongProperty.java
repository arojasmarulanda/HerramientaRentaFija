/*     */ package javafx.beans.property;
/*     */ 
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.binding.LongExpression;
/*     */ import javafx.beans.binding.ObjectExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReadOnlyLongProperty
/*     */   extends LongExpression
/*     */   implements ReadOnlyProperty<Number>
/*     */ {
/*     */   public String toString() {
/*  57 */     Object object = getBean();
/*  58 */     String str = getName();
/*  59 */     StringBuilder stringBuilder = new StringBuilder("ReadOnlyLongProperty [");
/*  60 */     if (object != null) {
/*  61 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/*  63 */     if (str != null && !str.equals("")) {
/*  64 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/*  66 */     stringBuilder.append("value: ").append(get()).append("]");
/*  67 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Number> ReadOnlyLongProperty readOnlyLongProperty(final ReadOnlyProperty<T> property) {
/*  90 */     if (property == null) {
/*  91 */       throw new NullPointerException("Property cannot be null");
/*     */     }
/*     */     
/*  94 */     return (property instanceof ReadOnlyLongProperty) ? (ReadOnlyLongProperty)property : 
/*  95 */       new ReadOnlyLongPropertyBase()
/*     */       {
/*     */         private boolean valid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final InvalidationListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public long get() {
/* 110 */           this.valid = true;
/* 111 */           Number number = property.getValue();
/* 112 */           return (number == null) ? 0L : number.longValue();
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 117 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 122 */           return property.getName();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyObjectProperty<Long> asObject() {
/* 138 */     return new ReadOnlyObjectPropertyBase<Long>()
/*     */       {
/*     */         private boolean valid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final InvalidationListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 154 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 159 */           return ReadOnlyLongProperty.this.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         public Long get() {
/* 164 */           this.valid = true;
/* 165 */           return ReadOnlyLongProperty.this.getValue();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\property\ReadOnlyLongProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */