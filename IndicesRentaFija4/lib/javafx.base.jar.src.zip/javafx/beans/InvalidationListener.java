package javafx.beans;

@FunctionalInterface
public interface InvalidationListener {
  void invalidated(Observable paramObservable);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\beans\InvalidationListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */