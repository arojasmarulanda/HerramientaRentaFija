package javafx.event;

import java.util.EventListener;

@FunctionalInterface
public interface EventHandler<T extends Event> extends EventListener {
  void handle(T paramT);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\event\EventHandler.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */