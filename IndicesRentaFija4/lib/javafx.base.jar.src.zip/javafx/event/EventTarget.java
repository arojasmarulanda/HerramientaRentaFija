package javafx.event;

public interface EventTarget {
  EventDispatchChain buildEventDispatchChain(EventDispatchChain paramEventDispatchChain);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\event\EventTarget.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */