package javafx.event;

public interface EventDispatcher {
  Event dispatchEvent(Event paramEvent, EventDispatchChain paramEventDispatchChain);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\event\EventDispatcher.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */