package javafx.util;

public abstract class StringConverter<T> {
  public abstract String toString(T paramT);
  
  public abstract T fromString(String paramString);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javaf\\util\StringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */