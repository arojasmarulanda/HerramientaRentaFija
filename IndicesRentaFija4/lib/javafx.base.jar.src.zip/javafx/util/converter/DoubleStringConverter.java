/*    */ package javafx.util.converter;
/*    */ 
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleStringConverter
/*    */   extends StringConverter<Double>
/*    */ {
/*    */   public Double fromString(String paramString) {
/* 39 */     if (paramString == null) {
/* 40 */       return null;
/*    */     }
/*    */     
/* 43 */     paramString = paramString.trim();
/*    */     
/* 45 */     if (paramString.length() < 1) {
/* 46 */       return null;
/*    */     }
/*    */     
/* 49 */     return Double.valueOf(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString(Double paramDouble) {
/* 55 */     if (paramDouble == null) {
/* 56 */       return "";
/*    */     }
/*    */     
/* 59 */     return Double.toString(paramDouble.doubleValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javaf\\util\converter\DoubleStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */