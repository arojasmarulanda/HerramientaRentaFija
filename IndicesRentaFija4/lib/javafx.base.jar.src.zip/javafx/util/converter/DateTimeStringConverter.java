/*     */ package javafx.util.converter;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateTimeStringConverter
/*     */   extends StringConverter<Date>
/*     */ {
/*     */   protected final Locale locale;
/*     */   protected final String pattern;
/*     */   protected final DateFormat dateFormat;
/*     */   protected final int dateStyle;
/*     */   protected final int timeStyle;
/*     */   
/*     */   public DateTimeStringConverter() {
/*  68 */     this(null, null, null, 2, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTimeStringConverter(int paramInt1, int paramInt2) {
/*  83 */     this(null, null, null, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTimeStringConverter(Locale paramLocale) {
/*  93 */     this(paramLocale, null, null, 2, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTimeStringConverter(Locale paramLocale, int paramInt1, int paramInt2) {
/* 109 */     this(paramLocale, null, null, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTimeStringConverter(String paramString) {
/* 119 */     this(null, paramString, null, 2, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTimeStringConverter(Locale paramLocale, String paramString) {
/* 130 */     this(paramLocale, paramString, null, 2, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTimeStringConverter(DateFormat paramDateFormat) {
/* 141 */     this(null, null, paramDateFormat, 2, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   DateTimeStringConverter(Locale paramLocale, String paramString, DateFormat paramDateFormat, int paramInt1, int paramInt2) {
/* 146 */     this.locale = (paramLocale != null) ? paramLocale : Locale.getDefault(Locale.Category.FORMAT);
/* 147 */     this.pattern = paramString;
/* 148 */     this.dateFormat = paramDateFormat;
/* 149 */     this.dateStyle = paramInt1;
/* 150 */     this.timeStyle = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Date fromString(String paramString) {
/*     */     try {
/* 160 */       if (paramString == null) {
/* 161 */         return null;
/*     */       }
/*     */       
/* 164 */       paramString = paramString.trim();
/*     */       
/* 166 */       if (paramString.length() < 1) {
/* 167 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 171 */       DateFormat dateFormat = getDateFormat();
/*     */ 
/*     */       
/* 174 */       return dateFormat.parse(paramString);
/* 175 */     } catch (ParseException parseException) {
/* 176 */       throw new RuntimeException(parseException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(Date paramDate) {
/* 183 */     if (paramDate == null) {
/* 184 */       return "";
/*     */     }
/*     */ 
/*     */     
/* 188 */     DateFormat dateFormat = getDateFormat();
/*     */ 
/*     */     
/* 191 */     return dateFormat.format(paramDate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DateFormat getDateFormat() {
/* 204 */     DateFormat dateFormat = null;
/*     */     
/* 206 */     if (this.dateFormat != null)
/* 207 */       return this.dateFormat; 
/* 208 */     if (this.pattern != null) {
/* 209 */       dateFormat = new SimpleDateFormat(this.pattern, this.locale);
/*     */     } else {
/* 211 */       dateFormat = DateFormat.getDateTimeInstance(this.dateStyle, this.timeStyle, this.locale);
/*     */     } 
/*     */     
/* 214 */     dateFormat.setLenient(false);
/*     */     
/* 216 */     return dateFormat;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javaf\\util\converter\DateTimeStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */