/*    */ package javafx.util.converter;
/*    */ 
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShortStringConverter
/*    */   extends StringConverter<Short>
/*    */ {
/*    */   public Short fromString(String paramString) {
/* 38 */     if (paramString == null) {
/* 39 */       return null;
/*    */     }
/*    */     
/* 42 */     paramString = paramString.trim();
/*    */     
/* 44 */     if (paramString.length() < 1) {
/* 45 */       return null;
/*    */     }
/*    */     
/* 48 */     return Short.valueOf(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString(Short paramShort) {
/* 55 */     if (paramShort == null) {
/* 56 */       return "";
/*    */     }
/*    */     
/* 59 */     return Short.toString(paramShort.shortValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javaf\\util\converter\ShortStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */