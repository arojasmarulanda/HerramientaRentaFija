/*     */ package javafx.util.converter;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumberStringConverter
/*     */   extends StringConverter<Number>
/*     */ {
/*     */   final Locale locale;
/*     */   final String pattern;
/*     */   final NumberFormat numberFormat;
/*     */   
/*     */   public NumberStringConverter() {
/*  49 */     this(Locale.getDefault());
/*     */   }
/*     */   
/*     */   public NumberStringConverter(Locale paramLocale) {
/*  53 */     this(paramLocale, null);
/*     */   }
/*     */   
/*     */   public NumberStringConverter(String paramString) {
/*  57 */     this(Locale.getDefault(), paramString);
/*     */   }
/*     */   
/*     */   public NumberStringConverter(Locale paramLocale, String paramString) {
/*  61 */     this(paramLocale, paramString, null);
/*     */   }
/*     */   
/*     */   public NumberStringConverter(NumberFormat paramNumberFormat) {
/*  65 */     this(null, null, paramNumberFormat);
/*     */   }
/*     */   
/*     */   NumberStringConverter(Locale paramLocale, String paramString, NumberFormat paramNumberFormat) {
/*  69 */     this.locale = paramLocale;
/*  70 */     this.pattern = paramString;
/*  71 */     this.numberFormat = paramNumberFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number fromString(String paramString) {
/*     */     try {
/*  80 */       if (paramString == null) {
/*  81 */         return null;
/*     */       }
/*     */       
/*  84 */       paramString = paramString.trim();
/*     */       
/*  86 */       if (paramString.length() < 1) {
/*  87 */         return null;
/*     */       }
/*     */ 
/*     */       
/*  91 */       NumberFormat numberFormat = getNumberFormat();
/*     */ 
/*     */       
/*  94 */       return numberFormat.parse(paramString);
/*  95 */     } catch (ParseException parseException) {
/*  96 */       throw new RuntimeException(parseException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString(Number paramNumber) {
/* 103 */     if (paramNumber == null) {
/* 104 */       return "";
/*     */     }
/*     */ 
/*     */     
/* 108 */     NumberFormat numberFormat = getNumberFormat();
/*     */ 
/*     */     
/* 111 */     return numberFormat.format(paramNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NumberFormat getNumberFormat() {
/* 122 */     Locale locale = (this.locale == null) ? Locale.getDefault() : this.locale;
/*     */     
/* 124 */     if (this.numberFormat != null)
/* 125 */       return this.numberFormat; 
/* 126 */     if (this.pattern != null) {
/* 127 */       DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols(locale);
/* 128 */       return new DecimalFormat(this.pattern, decimalFormatSymbols);
/*     */     } 
/* 130 */     return NumberFormat.getNumberInstance(locale);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javaf\\util\converter\NumberStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */