/*    */ package javafx.util.converter;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BigIntegerStringConverter
/*    */   extends StringConverter<BigInteger>
/*    */ {
/*    */   public BigInteger fromString(String paramString) {
/* 39 */     if (paramString == null) {
/* 40 */       return null;
/*    */     }
/*    */     
/* 43 */     paramString = paramString.trim();
/*    */     
/* 45 */     if (paramString.length() < 1) {
/* 46 */       return null;
/*    */     }
/*    */     
/* 49 */     return new BigInteger(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString(BigInteger paramBigInteger) {
/* 55 */     if (paramBigInteger == null) {
/* 56 */       return "";
/*    */     }
/*    */     
/* 59 */     return paramBigInteger.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javaf\\util\converter\BigIntegerStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */