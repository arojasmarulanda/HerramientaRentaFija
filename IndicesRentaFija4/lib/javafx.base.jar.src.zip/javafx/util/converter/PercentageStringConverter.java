/*    */ package javafx.util.converter;
/*    */ 
/*    */ import java.text.NumberFormat;
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PercentageStringConverter
/*    */   extends NumberStringConverter
/*    */ {
/*    */   public PercentageStringConverter() {
/* 46 */     this(Locale.getDefault());
/*    */   }
/*    */   
/*    */   public PercentageStringConverter(Locale paramLocale) {
/* 50 */     super(paramLocale, null, null);
/*    */   }
/*    */   
/*    */   public PercentageStringConverter(NumberFormat paramNumberFormat) {
/* 54 */     super(null, null, paramNumberFormat);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NumberFormat getNumberFormat() {
/* 61 */     Locale locale = (this.locale == null) ? Locale.getDefault() : this.locale;
/*    */     
/* 63 */     if (this.numberFormat != null) {
/* 64 */       return this.numberFormat;
/*    */     }
/* 66 */     return NumberFormat.getPercentInstance(locale);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javaf\\util\converter\PercentageStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */