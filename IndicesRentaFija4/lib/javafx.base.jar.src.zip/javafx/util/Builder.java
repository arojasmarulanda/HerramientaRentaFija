package javafx.util;

@FunctionalInterface
public interface Builder<T> {
  T build();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javaf\\util\Builder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */