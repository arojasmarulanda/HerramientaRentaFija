package javafx.util;

@FunctionalInterface
public interface BuilderFactory {
  Builder<?> getBuilder(Class<?> paramClass);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javaf\\util\BuilderFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */