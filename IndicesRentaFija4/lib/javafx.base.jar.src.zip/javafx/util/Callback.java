package javafx.util;

@FunctionalInterface
public interface Callback<P, R> {
  R call(P paramP);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javaf\\util\Callback.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */