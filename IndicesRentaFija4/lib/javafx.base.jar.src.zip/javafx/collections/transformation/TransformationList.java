/*     */ package javafx.collections.transformation;
/*     */ 
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableListBase;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TransformationList<E, F>
/*     */   extends ObservableListBase<E>
/*     */   implements ObservableList<E>
/*     */ {
/*     */   private ObservableList<? extends F> source;
/*     */   private ListChangeListener<F> sourceListener;
/*     */   
/*     */   protected TransformationList(ObservableList<? extends F> paramObservableList) {
/*  64 */     if (paramObservableList == null) {
/*  65 */       throw new NullPointerException();
/*     */     }
/*  67 */     this.source = paramObservableList;
/*  68 */     paramObservableList.addListener(new WeakListChangeListener<>(getListener()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<? extends F> getSource() {
/*  76 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isInTransformationChain(ObservableList<?> paramObservableList) {
/*  90 */     if (this.source == paramObservableList) {
/*  91 */       return true;
/*     */     }
/*  93 */     ObservableList<? extends F> observableList = this.source;
/*  94 */     while (observableList instanceof TransformationList) {
/*  95 */       observableList = ((TransformationList)observableList).source;
/*  96 */       if (observableList == paramObservableList) {
/*  97 */         return true;
/*     */       }
/*     */     } 
/* 100 */     return false;
/*     */   }
/*     */   
/*     */   private ListChangeListener<F> getListener() {
/* 104 */     if (this.sourceListener == null) {
/* 105 */       this.sourceListener = (paramChange -> sourceChanged(paramChange));
/*     */     }
/*     */ 
/*     */     
/* 109 */     return this.sourceListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getSourceIndexFor(ObservableList<?> paramObservableList, int paramInt) {
/* 137 */     if (!isInTransformationChain(paramObservableList)) {
/* 138 */       throw new IllegalArgumentException("Provided list is not in the transformation chain of thistransformation list");
/*     */     }
/*     */     
/* 141 */     ObservableList<? extends F> observableList = this.source;
/* 142 */     int i = getSourceIndex(paramInt);
/* 143 */     while (observableList != paramObservableList && observableList instanceof TransformationList) {
/* 144 */       TransformationList transformationList = (TransformationList)observableList;
/* 145 */       i = transformationList.getSourceIndex(i);
/* 146 */       observableList = transformationList.source;
/*     */     } 
/* 148 */     return i;
/*     */   }
/*     */   
/*     */   protected abstract void sourceChanged(ListChangeListener.Change<? extends F> paramChange);
/*     */   
/*     */   public abstract int getSourceIndex(int paramInt);
/*     */   
/*     */   public abstract int getViewIndex(int paramInt);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\collections\transformation\TransformationList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */