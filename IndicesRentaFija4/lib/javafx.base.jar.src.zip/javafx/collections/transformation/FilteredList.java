/*     */ package javafx.collections.transformation;
/*     */ 
/*     */ import com.sun.javafx.collections.SortHelper;
/*     */ import java.util.Arrays;
/*     */ import java.util.ListIterator;
/*     */ import java.util.function.Predicate;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FilteredList<E>
/*     */   extends TransformationList<E, E>
/*     */ {
/*     */   private int[] filtered;
/*     */   private int size;
/*     */   private SortHelper helper;
/*     */   private static final Predicate ALWAYS_TRUE = paramObject -> true;
/*     */   private ObjectProperty<Predicate<? super E>> predicate;
/*     */   
/*     */   public FilteredList(@NamedArg("source") ObservableList<E> paramObservableList, @NamedArg("predicate") Predicate<? super E> paramPredicate) {
/*  66 */     super(paramObservableList);
/*  67 */     this.filtered = new int[paramObservableList.size() * 3 / 2 + 1];
/*  68 */     if (paramPredicate != null) {
/*  69 */       setPredicate(paramPredicate);
/*     */     } else {
/*  71 */       for (this.size = 0; this.size < paramObservableList.size(); this.size++) {
/*  72 */         this.filtered[this.size] = this.size;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilteredList(@NamedArg("source") ObservableList<E> paramObservableList) {
/*  87 */     this(paramObservableList, (Predicate<? super E>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<Predicate<? super E>> predicateProperty() {
/*  98 */     if (this.predicate == null) {
/*  99 */       this.predicate = new ObjectPropertyBase<Predicate<? super E>>()
/*     */         {
/*     */           protected void invalidated() {
/* 102 */             FilteredList.this.refilter();
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 107 */             return FilteredList.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 112 */             return "predicate";
/*     */           }
/*     */         };
/*     */     }
/*     */     
/* 117 */     return this.predicate;
/*     */   }
/*     */   
/*     */   public final Predicate<? super E> getPredicate() {
/* 121 */     return (this.predicate == null) ? null : this.predicate.get();
/*     */   }
/*     */   
/*     */   public final void setPredicate(Predicate<? super E> paramPredicate) {
/* 125 */     predicateProperty().set(paramPredicate);
/*     */   }
/*     */   
/*     */   private Predicate<? super E> getPredicateImpl() {
/* 129 */     if (getPredicate() != null) {
/* 130 */       return getPredicate();
/*     */     }
/* 132 */     return ALWAYS_TRUE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void sourceChanged(ListChangeListener.Change<? extends E> paramChange) {
/* 137 */     beginChange();
/* 138 */     while (paramChange.next()) {
/* 139 */       if (paramChange.wasPermutated()) {
/* 140 */         permutate(paramChange); continue;
/* 141 */       }  if (paramChange.wasUpdated()) {
/* 142 */         update(paramChange); continue;
/*     */       } 
/* 144 */       addRemove(paramChange);
/*     */     } 
/*     */     
/* 147 */     endChange();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 157 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E get(int paramInt) {
/* 169 */     if (paramInt >= this.size) {
/* 170 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 172 */     return getSource().get(this.filtered[paramInt]);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSourceIndex(int paramInt) {
/* 177 */     if (paramInt >= this.size) {
/* 178 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 180 */     return this.filtered[paramInt];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getViewIndex(int paramInt) {
/* 185 */     return Arrays.binarySearch(this.filtered, 0, this.size, paramInt);
/*     */   }
/*     */   
/*     */   private SortHelper getSortHelper() {
/* 189 */     if (this.helper == null) {
/* 190 */       this.helper = new SortHelper();
/*     */     }
/* 192 */     return this.helper;
/*     */   }
/*     */   
/*     */   private int findPosition(int paramInt) {
/* 196 */     if (this.filtered.length == 0) {
/* 197 */       return 0;
/*     */     }
/* 199 */     if (paramInt == 0) {
/* 200 */       return 0;
/*     */     }
/* 202 */     int i = Arrays.binarySearch(this.filtered, 0, this.size, paramInt);
/* 203 */     if (i < 0) {
/* 204 */       i ^= 0xFFFFFFFF;
/*     */     }
/* 206 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureSize(int paramInt) {
/* 212 */     if (this.filtered.length < paramInt) {
/* 213 */       int[] arrayOfInt = new int[paramInt * 3 / 2 + 1];
/* 214 */       System.arraycopy(this.filtered, 0, arrayOfInt, 0, this.size);
/* 215 */       this.filtered = arrayOfInt;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateIndexes(int paramInt1, int paramInt2) {
/* 220 */     for (int i = paramInt1; i < this.size; i++) {
/* 221 */       this.filtered[i] = this.filtered[i] + paramInt2;
/*     */     }
/*     */   }
/*     */   
/*     */   private void permutate(ListChangeListener.Change<? extends E> paramChange) {
/* 226 */     int i = findPosition(paramChange.getFrom());
/* 227 */     int j = findPosition(paramChange.getTo());
/*     */     
/* 229 */     if (j > i) {
/* 230 */       for (int k = i; k < j; k++) {
/* 231 */         this.filtered[k] = paramChange.getPermutation(this.filtered[k]);
/*     */       }
/*     */       
/* 234 */       int[] arrayOfInt = getSortHelper().sort(this.filtered, i, j);
/* 235 */       nextPermutation(i, j, arrayOfInt);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addRemove(ListChangeListener.Change<? extends E> paramChange) {
/* 240 */     Predicate<? super E> predicate = getPredicateImpl();
/* 241 */     ensureSize(getSource().size());
/* 242 */     int i = findPosition(paramChange.getFrom());
/* 243 */     int j = findPosition(paramChange.getFrom() + paramChange.getRemovedSize());
/*     */     
/*     */     int k;
/* 246 */     for (k = i; k < j; k++) {
/* 247 */       nextRemove(i, paramChange.getRemoved().get(this.filtered[k] - paramChange.getFrom()));
/*     */     }
/*     */ 
/*     */     
/* 251 */     updateIndexes(j, paramChange.getAddedSize() - paramChange.getRemovedSize());
/*     */ 
/*     */     
/* 254 */     k = i;
/* 255 */     int m = paramChange.getFrom();
/*     */     
/* 257 */     ListIterator<? extends E> listIterator = getSource().listIterator(m);
/* 258 */     while (k < j && listIterator.nextIndex() < paramChange.getTo()) {
/* 259 */       if (predicate.test(listIterator.next())) {
/* 260 */         this.filtered[k] = listIterator.previousIndex();
/* 261 */         nextAdd(k, k + 1);
/* 262 */         k++;
/*     */       } 
/*     */     } 
/*     */     
/* 266 */     if (k < j) {
/*     */       
/* 268 */       System.arraycopy(this.filtered, j, this.filtered, k, this.size - j);
/* 269 */       this.size -= j - k;
/*     */     } else {
/*     */       
/* 272 */       while (listIterator.nextIndex() < paramChange.getTo()) {
/* 273 */         if (predicate.test(listIterator.next())) {
/* 274 */           System.arraycopy(this.filtered, k, this.filtered, k + 1, this.size - k);
/* 275 */           this.filtered[k] = listIterator.previousIndex();
/* 276 */           nextAdd(k, k + 1);
/* 277 */           k++;
/* 278 */           this.size++;
/*     */         } 
/* 280 */         m++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void update(ListChangeListener.Change<? extends E> paramChange) {
/* 286 */     Predicate<? super E> predicate = getPredicateImpl();
/* 287 */     ensureSize(getSource().size());
/* 288 */     int i = paramChange.getFrom();
/* 289 */     int j = paramChange.getTo();
/* 290 */     int k = findPosition(i);
/* 291 */     int m = findPosition(j);
/* 292 */     ListIterator<? extends E> listIterator = getSource().listIterator(i);
/* 293 */     int n = k;
/* 294 */     while (n < m || i < j) {
/* 295 */       E e = listIterator.next();
/* 296 */       if (n < this.size && this.filtered[n] == i) {
/* 297 */         if (!predicate.test(e)) {
/* 298 */           nextRemove(n, e);
/* 299 */           System.arraycopy(this.filtered, n + 1, this.filtered, n, this.size - n - 1);
/* 300 */           this.size--;
/* 301 */           m--;
/*     */         } else {
/* 303 */           nextUpdate(n);
/* 304 */           n++;
/*     */         }
/*     */       
/* 307 */       } else if (predicate.test(e)) {
/* 308 */         nextAdd(n, n + 1);
/* 309 */         System.arraycopy(this.filtered, n, this.filtered, n + 1, this.size - n);
/* 310 */         this.filtered[n] = i;
/* 311 */         this.size++;
/* 312 */         n++;
/* 313 */         m++;
/*     */       } 
/*     */       
/* 316 */       i++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void refilter() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_0
/*     */     //   2: invokevirtual getSource : ()Ljavafx/collections/ObservableList;
/*     */     //   5: invokeinterface size : ()I
/*     */     //   10: invokespecial ensureSize : (I)V
/*     */     //   13: aconst_null
/*     */     //   14: astore_1
/*     */     //   15: aload_0
/*     */     //   16: invokevirtual hasListeners : ()Z
/*     */     //   19: ifeq -> 31
/*     */     //   22: new java/util/ArrayList
/*     */     //   25: dup
/*     */     //   26: aload_0
/*     */     //   27: invokespecial <init> : (Ljava/util/Collection;)V
/*     */     //   30: astore_1
/*     */     //   31: aload_0
/*     */     //   32: iconst_0
/*     */     //   33: putfield size : I
/*     */     //   36: iconst_0
/*     */     //   37: istore_2
/*     */     //   38: aload_0
/*     */     //   39: invokespecial getPredicateImpl : ()Ljava/util/function/Predicate;
/*     */     //   42: astore_3
/*     */     //   43: aload_0
/*     */     //   44: invokevirtual getSource : ()Ljavafx/collections/ObservableList;
/*     */     //   47: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   52: astore #4
/*     */     //   54: aload #4
/*     */     //   56: invokeinterface hasNext : ()Z
/*     */     //   61: ifeq -> 107
/*     */     //   64: aload #4
/*     */     //   66: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   71: astore #5
/*     */     //   73: aload_3
/*     */     //   74: aload #5
/*     */     //   76: invokeinterface test : (Ljava/lang/Object;)Z
/*     */     //   81: ifeq -> 101
/*     */     //   84: aload_0
/*     */     //   85: getfield filtered : [I
/*     */     //   88: aload_0
/*     */     //   89: dup
/*     */     //   90: getfield size : I
/*     */     //   93: dup_x1
/*     */     //   94: iconst_1
/*     */     //   95: iadd
/*     */     //   96: putfield size : I
/*     */     //   99: iload_2
/*     */     //   100: iastore
/*     */     //   101: iinc #2, 1
/*     */     //   104: goto -> 54
/*     */     //   107: aload_0
/*     */     //   108: invokevirtual hasListeners : ()Z
/*     */     //   111: ifeq -> 132
/*     */     //   114: aload_0
/*     */     //   115: new com/sun/javafx/collections/NonIterableChange$GenericAddRemoveChange
/*     */     //   118: dup
/*     */     //   119: iconst_0
/*     */     //   120: aload_0
/*     */     //   121: getfield size : I
/*     */     //   124: aload_1
/*     */     //   125: aload_0
/*     */     //   126: invokespecial <init> : (IILjava/util/List;Ljavafx/collections/ObservableList;)V
/*     */     //   129: invokevirtual fireChange : (Ljavafx/collections/ListChangeListener$Change;)V
/*     */     //   132: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #322	-> 0
/*     */     //   #323	-> 13
/*     */     //   #324	-> 15
/*     */     //   #325	-> 22
/*     */     //   #327	-> 31
/*     */     //   #328	-> 36
/*     */     //   #329	-> 38
/*     */     //   #330	-> 43
/*     */     //   #331	-> 64
/*     */     //   #332	-> 73
/*     */     //   #333	-> 84
/*     */     //   #335	-> 101
/*     */     //   #336	-> 104
/*     */     //   #337	-> 107
/*     */     //   #338	-> 114
/*     */     //   #340	-> 132
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\collections\transformation\FilteredList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */