/*     */ package javafx.collections;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModifiableObservableListBase<E>
/*     */   extends ObservableListBase<E>
/*     */ {
/*     */   public boolean setAll(Collection<? extends E> paramCollection) {
/*  85 */     beginChange();
/*     */     try {
/*  87 */       clear();
/*  88 */       addAll(paramCollection);
/*     */     } finally {
/*  90 */       endChange();
/*     */     } 
/*  92 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends E> paramCollection) {
/*  97 */     beginChange();
/*     */     try {
/*  99 */       boolean bool = super.addAll(paramCollection);
/* 100 */       return bool;
/*     */     } finally {
/* 102 */       endChange();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(int paramInt, Collection<? extends E> paramCollection) {
/* 108 */     beginChange();
/*     */     try {
/* 110 */       boolean bool = super.addAll(paramInt, paramCollection);
/* 111 */       return bool;
/*     */     } finally {
/* 113 */       endChange();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void removeRange(int paramInt1, int paramInt2) {
/* 119 */     beginChange();
/*     */     try {
/* 121 */       super.removeRange(paramInt1, paramInt2);
/*     */     } finally {
/* 123 */       endChange();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> paramCollection) {
/* 129 */     beginChange();
/*     */     try {
/* 131 */       boolean bool = super.removeAll(paramCollection);
/* 132 */       return bool;
/*     */     } finally {
/* 134 */       endChange();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> paramCollection) {
/* 140 */     beginChange();
/*     */     try {
/* 142 */       boolean bool = super.retainAll(paramCollection);
/* 143 */       return bool;
/*     */     } finally {
/* 145 */       endChange();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int paramInt, E paramE) {
/* 151 */     doAdd(paramInt, paramE);
/* 152 */     beginChange();
/* 153 */     nextAdd(paramInt, paramInt + 1);
/* 154 */     this.modCount++;
/* 155 */     endChange();
/*     */   }
/*     */ 
/*     */   
/*     */   public E set(int paramInt, E paramE) {
/* 160 */     E e = doSet(paramInt, paramE);
/* 161 */     beginChange();
/* 162 */     nextSet(paramInt, e);
/* 163 */     endChange();
/* 164 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object paramObject) {
/* 169 */     int i = indexOf(paramObject);
/* 170 */     if (i != -1) {
/* 171 */       remove(i);
/* 172 */       return true;
/*     */     } 
/* 174 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public E remove(int paramInt) {
/* 179 */     E e = doRemove(paramInt);
/* 180 */     beginChange();
/* 181 */     nextRemove(paramInt, e);
/* 182 */     this.modCount++;
/* 183 */     endChange();
/* 184 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<E> subList(int paramInt1, int paramInt2) {
/* 189 */     return new SubObservableList(super.subList(paramInt1, paramInt2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract E get(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int size();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void doAdd(int paramInt, E paramE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract E doSet(int paramInt, E paramE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract E doRemove(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class SubObservableList
/*     */     implements List<E>
/*     */   {
/*     */     private List<E> sublist;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SubObservableList(List<E> param1List) {
/* 253 */       this.sublist = param1List;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 259 */       return this.sublist.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 264 */       return this.sublist.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object param1Object) {
/* 269 */       return this.sublist.contains(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<E> iterator() {
/* 274 */       return this.sublist.iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] toArray() {
/* 279 */       return this.sublist.toArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T[] toArray(T[] param1ArrayOfT) {
/* 284 */       return this.sublist.toArray(param1ArrayOfT);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(E param1E) {
/* 289 */       return this.sublist.add(param1E);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean remove(Object param1Object) {
/* 294 */       return this.sublist.remove(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection<?> param1Collection) {
/* 299 */       return this.sublist.containsAll(param1Collection);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends E> param1Collection) {
/* 304 */       ModifiableObservableListBase.this.beginChange();
/*     */       try {
/* 306 */         boolean bool = this.sublist.addAll(param1Collection);
/* 307 */         return bool;
/*     */       } finally {
/* 309 */         ModifiableObservableListBase.this.endChange();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(int param1Int, Collection<? extends E> param1Collection) {
/* 315 */       ModifiableObservableListBase.this.beginChange();
/*     */       try {
/* 317 */         boolean bool = this.sublist.addAll(param1Int, param1Collection);
/* 318 */         return bool;
/*     */       } finally {
/* 320 */         ModifiableObservableListBase.this.endChange();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> param1Collection) {
/* 326 */       ModifiableObservableListBase.this.beginChange();
/*     */       try {
/* 328 */         boolean bool = this.sublist.removeAll(param1Collection);
/* 329 */         return bool;
/*     */       } finally {
/* 331 */         ModifiableObservableListBase.this.endChange();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> param1Collection) {
/* 337 */       ModifiableObservableListBase.this.beginChange();
/*     */       try {
/* 339 */         boolean bool = this.sublist.retainAll(param1Collection);
/* 340 */         return bool;
/*     */       } finally {
/* 342 */         ModifiableObservableListBase.this.endChange();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 348 */       ModifiableObservableListBase.this.beginChange();
/*     */       try {
/* 350 */         this.sublist.clear();
/*     */       } finally {
/* 352 */         ModifiableObservableListBase.this.endChange();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public E get(int param1Int) {
/* 358 */       return this.sublist.get(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public E set(int param1Int, E param1E) {
/* 363 */       return this.sublist.set(param1Int, param1E);
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(int param1Int, E param1E) {
/* 368 */       this.sublist.add(param1Int, param1E);
/*     */     }
/*     */ 
/*     */     
/*     */     public E remove(int param1Int) {
/* 373 */       return this.sublist.remove(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public int indexOf(Object param1Object) {
/* 378 */       return this.sublist.indexOf(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int lastIndexOf(Object param1Object) {
/* 383 */       return this.sublist.lastIndexOf(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public ListIterator<E> listIterator() {
/* 388 */       return this.sublist.listIterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public ListIterator<E> listIterator(int param1Int) {
/* 393 */       return this.sublist.listIterator(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<E> subList(int param1Int1, int param1Int2) {
/* 398 */       return new SubObservableList(this.sublist.subList(param1Int1, param1Int2));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 403 */       return this.sublist.equals(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 408 */       return this.sublist.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 413 */       return this.sublist.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.base.jar!\javafx\collections\ModifiableObservableListBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */