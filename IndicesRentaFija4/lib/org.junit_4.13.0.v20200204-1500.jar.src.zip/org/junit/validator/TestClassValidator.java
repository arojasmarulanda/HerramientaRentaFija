package org.junit.validator;

import java.util.List;
import org.junit.runners.model.TestClass;

public interface TestClassValidator {
  List<Exception> validateTestClass(TestClass paramTestClass);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\validator\TestClassValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */