/*    */ package org.junit.validator;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationValidatorFactory
/*    */ {
/* 11 */   private static final ConcurrentHashMap<ValidateWith, AnnotationValidator> VALIDATORS_FOR_ANNOTATION_TYPES = new ConcurrentHashMap<ValidateWith, AnnotationValidator>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AnnotationValidator createAnnotationValidator(ValidateWith validateWithAnnotation) {
/* 24 */     AnnotationValidator validator = VALIDATORS_FOR_ANNOTATION_TYPES.get(validateWithAnnotation);
/* 25 */     if (validator != null) {
/* 26 */       return validator;
/*    */     }
/*    */     
/* 29 */     Class<? extends AnnotationValidator> clazz = validateWithAnnotation.value();
/*    */     try {
/* 31 */       AnnotationValidator annotationValidator = clazz.newInstance();
/* 32 */       VALIDATORS_FOR_ANNOTATION_TYPES.putIfAbsent(validateWithAnnotation, annotationValidator);
/* 33 */       return VALIDATORS_FOR_ANNOTATION_TYPES.get(validateWithAnnotation);
/* 34 */     } catch (Exception e) {
/* 35 */       throw new RuntimeException("Exception received when creating AnnotationValidator class " + clazz.getName(), e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\validator\AnnotationValidatorFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */