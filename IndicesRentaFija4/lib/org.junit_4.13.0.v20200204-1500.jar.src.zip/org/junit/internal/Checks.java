/*    */ package org.junit.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Checks
/*    */ {
/*    */   public static <T> T notNull(T value) {
/* 16 */     if (value == null) {
/* 17 */       throw new NullPointerException();
/*    */     }
/* 19 */     return value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> T notNull(T value, String message) {
/* 32 */     if (value == null) {
/* 33 */       throw new NullPointerException(message);
/*    */     }
/* 35 */     return value;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\Checks.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */