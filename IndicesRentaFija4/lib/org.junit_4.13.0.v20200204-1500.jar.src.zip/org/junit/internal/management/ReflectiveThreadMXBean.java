/*    */ package org.junit.internal.management;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import org.junit.internal.Classes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ReflectiveThreadMXBean
/*    */   implements ThreadMXBean
/*    */ {
/*    */   private final Object threadMxBean;
/*    */   
/*    */   private static final class Holder
/*    */   {
/*    */     static final Method getThreadCpuTimeMethod;
/*    */     static final Method isThreadCpuTimeSupportedMethod;
/*    */     private static final String FAILURE_MESSAGE = "Unable to access ThreadMXBean";
/*    */     
/*    */     static {
/* 22 */       Method threadCpuTime = null;
/* 23 */       Method threadCpuTimeSupported = null;
/*    */       try {
/* 25 */         Class<?> threadMXBeanClass = Classes.getClass("java.lang.management.ThreadMXBean");
/* 26 */         threadCpuTime = threadMXBeanClass.getMethod("getThreadCpuTime", new Class[] { long.class });
/* 27 */         threadCpuTimeSupported = threadMXBeanClass.getMethod("isThreadCpuTimeSupported", new Class[0]);
/* 28 */       } catch (ClassNotFoundException e) {
/*    */       
/* 30 */       } catch (NoSuchMethodException e) {
/*    */       
/* 32 */       } catch (SecurityException e) {}
/*    */ 
/*    */       
/* 35 */       getThreadCpuTimeMethod = threadCpuTime;
/* 36 */       isThreadCpuTimeSupportedMethod = threadCpuTimeSupported;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   ReflectiveThreadMXBean(Object threadMxBean) {
/* 42 */     this.threadMxBean = threadMxBean;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getThreadCpuTime(long id) {
/* 49 */     if (Holder.getThreadCpuTimeMethod != null) {
/* 50 */       Exception error = null;
/*    */       try {
/* 52 */         return ((Long)Holder.getThreadCpuTimeMethod.invoke(this.threadMxBean, new Object[] { Long.valueOf(id) })).longValue();
/* 53 */       } catch (ClassCastException e) {
/* 54 */         error = e;
/*    */       }
/* 56 */       catch (IllegalAccessException e) {
/* 57 */         error = e;
/*    */       }
/* 59 */       catch (IllegalArgumentException e) {
/* 60 */         error = e;
/*    */       }
/* 62 */       catch (InvocationTargetException e) {
/* 63 */         error = e;
/*    */       } 
/*    */       
/* 66 */       throw new UnsupportedOperationException("Unable to access ThreadMXBean", error);
/*    */     } 
/* 68 */     throw new UnsupportedOperationException("Unable to access ThreadMXBean");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isThreadCpuTimeSupported() {
/* 75 */     if (Holder.isThreadCpuTimeSupportedMethod != null) {
/*    */       try {
/* 77 */         return ((Boolean)Holder.isThreadCpuTimeSupportedMethod.invoke(this.threadMxBean, new Object[0])).booleanValue();
/* 78 */       } catch (ClassCastException e) {
/*    */       
/* 80 */       } catch (IllegalAccessException e) {
/*    */       
/* 82 */       } catch (IllegalArgumentException e) {
/*    */       
/* 84 */       } catch (InvocationTargetException e) {}
/*    */     }
/*    */ 
/*    */     
/* 88 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\management\ReflectiveThreadMXBean.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */