/*    */ package org.junit.internal.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FakeThreadMXBean
/*    */   implements ThreadMXBean
/*    */ {
/*    */   public long getThreadCpuTime(long id) {
/* 14 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isThreadCpuTimeSupported() {
/* 23 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\management\FakeThreadMXBean.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */