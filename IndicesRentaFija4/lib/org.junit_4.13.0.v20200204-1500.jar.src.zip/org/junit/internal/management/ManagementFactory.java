/*    */ package org.junit.internal.management;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import org.junit.internal.Classes;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManagementFactory
/*    */ {
/*    */   private static final class FactoryHolder
/*    */   {
/*    */     private static final Class<?> MANAGEMENT_FACTORY_CLASS;
/*    */     
/*    */     static {
/* 15 */       Class<?> managementFactoryClass = null;
/*    */       try {
/* 17 */         managementFactoryClass = Classes.getClass("java.lang.management.ManagementFactory");
/* 18 */       } catch (ClassNotFoundException e) {}
/*    */ 
/*    */       
/* 21 */       MANAGEMENT_FACTORY_CLASS = managementFactoryClass;
/*    */     }
/*    */     
/*    */     static Object getBeanObject(String methodName) {
/* 25 */       if (MANAGEMENT_FACTORY_CLASS != null) {
/*    */         try {
/* 27 */           return MANAGEMENT_FACTORY_CLASS.getMethod(methodName, new Class[0]).invoke(null, new Object[0]);
/* 28 */         } catch (IllegalAccessException e) {
/*    */         
/* 30 */         } catch (IllegalArgumentException e) {
/*    */         
/* 32 */         } catch (InvocationTargetException e) {
/*    */         
/* 34 */         } catch (NoSuchMethodException e) {
/*    */         
/* 36 */         } catch (SecurityException e) {}
/*    */       }
/*    */ 
/*    */       
/* 40 */       return null;
/*    */     }
/*    */   }
/*    */   
/*    */   private static final class RuntimeHolder {
/* 45 */     private static final RuntimeMXBean RUNTIME_MX_BEAN = getBean(ManagementFactory.FactoryHolder.getBeanObject("getRuntimeMXBean"));
/*    */ 
/*    */     
/*    */     private static final RuntimeMXBean getBean(Object runtimeMxBean) {
/* 49 */       return (runtimeMxBean != null) ? new ReflectiveRuntimeMXBean(runtimeMxBean) : new FakeRuntimeMXBean();
/*    */     }
/*    */   }
/*    */   
/*    */   private static final class ThreadHolder
/*    */   {
/* 55 */     private static final ThreadMXBean THREAD_MX_BEAN = getBean(ManagementFactory.FactoryHolder.getBeanObject("getThreadMXBean"));
/*    */ 
/*    */     
/*    */     private static final ThreadMXBean getBean(Object threadMxBean) {
/* 59 */       return (threadMxBean != null) ? new ReflectiveThreadMXBean(threadMxBean) : new FakeThreadMXBean();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static RuntimeMXBean getRuntimeMXBean() {
/* 68 */     return RuntimeHolder.RUNTIME_MX_BEAN;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ThreadMXBean getThreadMXBean() {
/* 75 */     return ThreadHolder.THREAD_MX_BEAN;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\management\ManagementFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */