/*    */ package org.junit.internal.management;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.junit.internal.Classes;
/*    */ 
/*    */ final class ReflectiveRuntimeMXBean
/*    */   implements RuntimeMXBean
/*    */ {
/*    */   private final Object runtimeMxBean;
/*    */   
/*    */   private static final class Holder
/*    */   {
/*    */     private static final Method getInputArgumentsMethod;
/*    */     
/*    */     static {
/* 19 */       Method inputArguments = null;
/*    */       try {
/* 21 */         Class<?> threadMXBeanClass = Classes.getClass("java.lang.management.RuntimeMXBean");
/* 22 */         inputArguments = threadMXBeanClass.getMethod("getInputArguments", new Class[0]);
/* 23 */       } catch (ClassNotFoundException e) {
/*    */       
/* 25 */       } catch (NoSuchMethodException e) {
/*    */       
/* 27 */       } catch (SecurityException e) {}
/*    */ 
/*    */       
/* 30 */       getInputArgumentsMethod = inputArguments;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   ReflectiveRuntimeMXBean(Object runtimeMxBean) {
/* 36 */     this.runtimeMxBean = runtimeMxBean;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getInputArguments() {
/* 44 */     if (Holder.getInputArgumentsMethod != null) {
/*    */       try {
/* 46 */         return (List<String>)Holder.getInputArgumentsMethod.invoke(this.runtimeMxBean, new Object[0]);
/* 47 */       } catch (ClassCastException e) {
/*    */       
/* 49 */       } catch (IllegalAccessException e) {
/*    */       
/* 51 */       } catch (IllegalArgumentException e) {
/*    */       
/* 53 */       } catch (InvocationTargetException e) {}
/*    */     }
/*    */ 
/*    */     
/* 57 */     return Collections.emptyList();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\management\ReflectiveRuntimeMXBean.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */