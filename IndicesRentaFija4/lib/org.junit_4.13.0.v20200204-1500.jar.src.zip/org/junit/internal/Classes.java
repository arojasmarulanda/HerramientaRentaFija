/*    */ package org.junit.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Classes
/*    */ {
/*    */   public static Class<?> getClass(String className) throws ClassNotFoundException {
/* 27 */     return getClass(className, Classes.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Class<?> getClass(String className, Class<?> callingClass) throws ClassNotFoundException {
/* 41 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 42 */     return Class.forName(className, true, (classLoader == null) ? callingClass.getClassLoader() : classLoader);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\Classes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */