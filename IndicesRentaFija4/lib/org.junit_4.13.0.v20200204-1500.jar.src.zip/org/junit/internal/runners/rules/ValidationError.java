/*    */ package org.junit.internal.runners.rules;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.junit.runners.model.FrameworkMember;
/*    */ 
/*    */ class ValidationError
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 3176511008672645574L;
/*    */   
/*    */   public ValidationError(FrameworkMember<?> member, Class<? extends Annotation> annotation, String suffix) {
/* 12 */     super(String.format("The @%s '%s' %s", new Object[] { annotation.getSimpleName(), member.getName(), suffix }));
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\runners\rules\ValidationError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */