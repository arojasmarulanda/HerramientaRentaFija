/*    */ package org.junit.internal.runners;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.junit.runner.Description;
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runner.notification.Failure;
/*    */ import org.junit.runner.notification.RunNotifier;
/*    */ import org.junit.runners.model.InitializationError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorReportingRunner
/*    */   extends Runner
/*    */ {
/*    */   private final List<Throwable> causes;
/*    */   private final String classNames;
/*    */   
/*    */   public ErrorReportingRunner(Class<?> testClass, Throwable cause) {
/* 21 */     this(cause, new Class[] { testClass });
/*    */   }
/*    */   
/*    */   public ErrorReportingRunner(Throwable cause, Class<?>... testClasses) {
/* 25 */     if (testClasses == null || testClasses.length == 0) {
/* 26 */       throw new NullPointerException("Test classes cannot be null or empty");
/*    */     }
/* 28 */     for (Class<?> testClass : testClasses) {
/* 29 */       if (testClass == null) {
/* 30 */         throw new NullPointerException("Test class cannot be null");
/*    */       }
/*    */     } 
/* 33 */     this.classNames = getClassNames(testClasses);
/* 34 */     this.causes = getCauses(cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public Description getDescription() {
/* 39 */     Description description = Description.createSuiteDescription(this.classNames, new java.lang.annotation.Annotation[0]);
/* 40 */     for (Throwable each : this.causes) {
/* 41 */       description.addChild(describeCause());
/*    */     }
/* 43 */     return description;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run(RunNotifier notifier) {
/* 48 */     for (Throwable each : this.causes) {
/* 49 */       runCause(each, notifier);
/*    */     }
/*    */   }
/*    */   
/*    */   private String getClassNames(Class<?>... testClasses) {
/* 54 */     StringBuilder builder = new StringBuilder();
/* 55 */     for (Class<?> testClass : testClasses) {
/* 56 */       if (builder.length() != 0) {
/* 57 */         builder.append(", ");
/*    */       }
/* 59 */       builder.append(testClass.getName());
/*    */     } 
/* 61 */     return builder.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   private List<Throwable> getCauses(Throwable cause) {
/* 66 */     if (cause instanceof java.lang.reflect.InvocationTargetException) {
/* 67 */       return getCauses(cause.getCause());
/*    */     }
/* 69 */     if (cause instanceof org.junit.runners.model.InvalidTestClassError) {
/* 70 */       return Collections.singletonList(cause);
/*    */     }
/* 72 */     if (cause instanceof InitializationError) {
/* 73 */       return ((InitializationError)cause).getCauses();
/*    */     }
/* 75 */     if (cause instanceof InitializationError) {
/* 76 */       return ((InitializationError)cause).getCauses();
/*    */     }
/*    */     
/* 79 */     return Collections.singletonList(cause);
/*    */   }
/*    */   
/*    */   private Description describeCause() {
/* 83 */     return Description.createTestDescription(this.classNames, "initializationError", new java.lang.annotation.Annotation[0]);
/*    */   }
/*    */   
/*    */   private void runCause(Throwable child, RunNotifier notifier) {
/* 87 */     Description description = describeCause();
/* 88 */     notifier.fireTestStarted(description);
/* 89 */     notifier.fireTestFailure(new Failure(description, child));
/* 90 */     notifier.fireTestFinished(description);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\runners\ErrorReportingRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */