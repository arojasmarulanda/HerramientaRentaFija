/*     */ package org.junit.internal.runners.statements;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.junit.internal.management.ManagementFactory;
/*     */ import org.junit.internal.management.ThreadMXBean;
/*     */ import org.junit.runners.model.MultipleFailureException;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestTimedOutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FailOnTimeout
/*     */   extends Statement
/*     */ {
/*     */   private final Statement originalStatement;
/*     */   private final TimeUnit timeUnit;
/*     */   private final long timeout;
/*     */   private final boolean lookForStuckThread;
/*     */   
/*     */   public static Builder builder() {
/*  31 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public FailOnTimeout(Statement statement, long timeoutMillis) {
/*  43 */     this(builder().withTimeout(timeoutMillis, TimeUnit.MILLISECONDS), statement);
/*     */   }
/*     */   
/*     */   private FailOnTimeout(Builder builder, Statement statement) {
/*  47 */     this.originalStatement = statement;
/*  48 */     this.timeout = builder.timeout;
/*  49 */     this.timeUnit = builder.unit;
/*  50 */     this.lookForStuckThread = builder.lookForStuckThread;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private boolean lookForStuckThread = false;
/*     */ 
/*     */     
/*  60 */     private long timeout = 0L;
/*  61 */     private TimeUnit unit = TimeUnit.SECONDS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withTimeout(long timeout, TimeUnit unit) {
/*  80 */       if (timeout < 0L) {
/*  81 */         throw new IllegalArgumentException("timeout must be non-negative");
/*     */       }
/*  83 */       if (unit == null) {
/*  84 */         throw new NullPointerException("TimeUnit cannot be null");
/*     */       }
/*  86 */       this.timeout = timeout;
/*  87 */       this.unit = unit;
/*  88 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder withLookingForStuckThread(boolean enable) {
/* 101 */       this.lookForStuckThread = enable;
/* 102 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FailOnTimeout build(Statement statement) {
/* 112 */       if (statement == null) {
/* 113 */         throw new NullPointerException("statement cannot be null");
/*     */       }
/* 115 */       return new FailOnTimeout(this, statement);
/*     */     }
/*     */     
/*     */     private Builder() {} }
/*     */   
/*     */   public void evaluate() throws Throwable {
/* 121 */     CallableStatement callable = new CallableStatement();
/* 122 */     FutureTask<Throwable> task = new FutureTask<Throwable>(callable);
/* 123 */     ThreadGroup threadGroup = new ThreadGroup("FailOnTimeoutGroup");
/* 124 */     Thread thread = new Thread(threadGroup, task, "Time-limited test");
/*     */     try {
/* 126 */       thread.setDaemon(true);
/* 127 */       thread.start();
/* 128 */       callable.awaitStarted();
/* 129 */       Throwable throwable = getResult(task, thread);
/* 130 */       if (throwable != null) {
/* 131 */         throw throwable;
/*     */       }
/*     */     } finally {
/*     */       try {
/* 135 */         thread.join(1L);
/* 136 */       } catch (InterruptedException e) {
/* 137 */         Thread.currentThread().interrupt();
/*     */       } 
/*     */       try {
/* 140 */         threadGroup.destroy();
/* 141 */       } catch (IllegalThreadStateException e) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Throwable getResult(FutureTask<Throwable> task, Thread thread) {
/*     */     try {
/* 155 */       if (this.timeout > 0L) {
/* 156 */         return task.get(this.timeout, this.timeUnit);
/*     */       }
/* 158 */       return task.get();
/*     */     }
/* 160 */     catch (InterruptedException e) {
/* 161 */       return e;
/* 162 */     } catch (ExecutionException e) {
/*     */       
/* 164 */       return e.getCause();
/* 165 */     } catch (TimeoutException e) {
/* 166 */       return createTimeoutException(thread);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Exception createTimeoutException(Thread thread) {
/* 171 */     StackTraceElement[] stackTrace = thread.getStackTrace();
/* 172 */     Thread stuckThread = this.lookForStuckThread ? getStuckThread(thread) : null;
/* 173 */     TestTimedOutException testTimedOutException = new TestTimedOutException(this.timeout, this.timeUnit);
/* 174 */     if (stackTrace != null) {
/* 175 */       testTimedOutException.setStackTrace(stackTrace);
/* 176 */       thread.interrupt();
/*     */     } 
/* 178 */     if (stuckThread != null) {
/* 179 */       Exception stuckThreadException = new Exception("Appears to be stuck in thread " + stuckThread.getName());
/*     */ 
/*     */       
/* 182 */       stuckThreadException.setStackTrace(getStackTrace(stuckThread));
/* 183 */       return (Exception)new MultipleFailureException(Arrays.asList(new Throwable[] { (Throwable)testTimedOutException, stuckThreadException }));
/*     */     } 
/*     */     
/* 186 */     return (Exception)testTimedOutException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StackTraceElement[] getStackTrace(Thread thread) {
/*     */     try {
/* 198 */       return thread.getStackTrace();
/* 199 */     } catch (SecurityException e) {
/* 200 */       return new StackTraceElement[0];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Thread getStuckThread(Thread mainThread) {
/* 215 */     List<Thread> threadsInGroup = getThreadsInGroup(mainThread.getThreadGroup());
/* 216 */     if (threadsInGroup.isEmpty()) {
/* 217 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     Thread stuckThread = null;
/* 226 */     long maxCpuTime = 0L;
/* 227 */     for (Thread thread : threadsInGroup) {
/* 228 */       if (thread.getState() == Thread.State.RUNNABLE) {
/* 229 */         long threadCpuTime = cpuTime(thread);
/* 230 */         if (stuckThread == null || threadCpuTime > maxCpuTime) {
/* 231 */           stuckThread = thread;
/* 232 */           maxCpuTime = threadCpuTime;
/*     */         } 
/*     */       } 
/*     */     } 
/* 236 */     return (stuckThread == mainThread) ? null : stuckThread;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Thread> getThreadsInGroup(ThreadGroup group) {
/* 248 */     int activeThreadCount = group.activeCount();
/* 249 */     int threadArraySize = Math.max(activeThreadCount * 2, 100);
/* 250 */     for (int loopCount = 0; loopCount < 5; loopCount++) {
/* 251 */       Thread[] threads = new Thread[threadArraySize];
/* 252 */       int enumCount = group.enumerate(threads);
/* 253 */       if (enumCount < threadArraySize) {
/* 254 */         return Arrays.<Thread>asList(threads).subList(0, enumCount);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 259 */       threadArraySize += 100;
/*     */     } 
/*     */ 
/*     */     
/* 263 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long cpuTime(Thread thr) {
/* 272 */     ThreadMXBean mxBean = ManagementFactory.getThreadMXBean();
/* 273 */     if (mxBean.isThreadCpuTimeSupported()) {
/*     */       try {
/* 275 */         return mxBean.getThreadCpuTime(thr.getId());
/* 276 */       } catch (UnsupportedOperationException e) {}
/*     */     }
/*     */     
/* 279 */     return 0L;
/*     */   }
/*     */   
/*     */   private class CallableStatement implements Callable<Throwable> { private CallableStatement() {
/* 283 */       this.startLatch = new CountDownLatch(1);
/*     */     } private final CountDownLatch startLatch;
/*     */     public Throwable call() throws Exception {
/*     */       try {
/* 287 */         this.startLatch.countDown();
/* 288 */         FailOnTimeout.this.originalStatement.evaluate();
/* 289 */       } catch (Exception e) {
/* 290 */         throw e;
/* 291 */       } catch (Throwable e) {
/* 292 */         return e;
/*     */       } 
/* 294 */       return null;
/*     */     }
/*     */     
/*     */     public void awaitStarted() throws InterruptedException {
/* 298 */       this.startLatch.await();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\runners\statements\FailOnTimeout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */