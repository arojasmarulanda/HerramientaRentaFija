/*    */ package org.junit.internal.builders;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runners.model.RunnerBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllDefaultPossibilitiesBuilder
/*    */   extends RunnerBuilder
/*    */ {
/*    */   private final boolean canUseSuiteMethod;
/*    */   
/*    */   public AllDefaultPossibilitiesBuilder() {
/* 16 */     this.canUseSuiteMethod = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public AllDefaultPossibilitiesBuilder(boolean canUseSuiteMethod) {
/* 24 */     this.canUseSuiteMethod = canUseSuiteMethod;
/*    */   }
/*    */ 
/*    */   
/*    */   public Runner runnerForClass(Class<?> testClass) throws Throwable {
/* 29 */     List<RunnerBuilder> builders = Arrays.asList(new RunnerBuilder[] { ignoredBuilder(), annotatedBuilder(), suiteMethodBuilder(), junit3Builder(), junit4Builder() });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 36 */     for (RunnerBuilder each : builders) {
/* 37 */       Runner runner = each.safeRunnerForClass(testClass);
/* 38 */       if (runner != null) {
/* 39 */         return runner;
/*    */       }
/*    */     } 
/* 42 */     return null;
/*    */   }
/*    */   
/*    */   protected JUnit4Builder junit4Builder() {
/* 46 */     return new JUnit4Builder();
/*    */   }
/*    */   
/*    */   protected JUnit3Builder junit3Builder() {
/* 50 */     return new JUnit3Builder();
/*    */   }
/*    */   
/*    */   protected AnnotatedBuilder annotatedBuilder() {
/* 54 */     return new AnnotatedBuilder(this);
/*    */   }
/*    */   
/*    */   protected IgnoredBuilder ignoredBuilder() {
/* 58 */     return new IgnoredBuilder();
/*    */   }
/*    */   
/*    */   protected RunnerBuilder suiteMethodBuilder() {
/* 62 */     if (this.canUseSuiteMethod) {
/* 63 */       return new SuiteMethodBuilder();
/*    */     }
/* 65 */     return new NullBuilder();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\builders\AllDefaultPossibilitiesBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */