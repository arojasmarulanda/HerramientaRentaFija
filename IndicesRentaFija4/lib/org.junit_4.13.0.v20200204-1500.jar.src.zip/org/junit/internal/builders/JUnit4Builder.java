/*    */ package org.junit.internal.builders;
/*    */ 
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runners.JUnit4;
/*    */ import org.junit.runners.model.RunnerBuilder;
/*    */ 
/*    */ public class JUnit4Builder
/*    */   extends RunnerBuilder {
/*    */   public Runner runnerForClass(Class<?> testClass) throws Throwable {
/* 10 */     return (Runner)new JUnit4(testClass);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\builders\JUnit4Builder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */