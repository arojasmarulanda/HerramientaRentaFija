/*     */ package org.junit.internal;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.AbstractList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Throwables
/*     */ {
/*     */   public static Exception rethrowAsException(Throwable e) throws Exception {
/*  46 */     rethrow(e);
/*  47 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T extends Throwable> void rethrow(Throwable e) throws T {
/*  52 */     throw (T)e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getStacktrace(Throwable exception) {
/*  61 */     StringWriter stringWriter = new StringWriter();
/*  62 */     PrintWriter writer = new PrintWriter(stringWriter);
/*  63 */     exception.printStackTrace(writer);
/*  64 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTrimmedStackTrace(Throwable exception) {
/*  74 */     List<String> trimmedStackTraceLines = getTrimmedStackTraceLines(exception);
/*  75 */     if (trimmedStackTraceLines.isEmpty()) {
/*  76 */       return getFullStackTrace(exception);
/*     */     }
/*     */     
/*  79 */     StringBuilder result = new StringBuilder(exception.toString());
/*  80 */     appendStackTraceLines(trimmedStackTraceLines, result);
/*  81 */     appendStackTraceLines(getCauseStackTraceLines(exception), result);
/*  82 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static List<String> getTrimmedStackTraceLines(Throwable exception) {
/*  86 */     List<StackTraceElement> stackTraceElements = Arrays.asList(exception.getStackTrace());
/*  87 */     int linesToInclude = stackTraceElements.size();
/*     */     
/*  89 */     State state = State.PROCESSING_OTHER_CODE;
/*  90 */     for (StackTraceElement stackTraceElement : asReversedList(stackTraceElements)) {
/*  91 */       state = state.processStackTraceElement(stackTraceElement);
/*  92 */       if (state == State.DONE) {
/*  93 */         List<String> trimmedLines = new ArrayList<String>(linesToInclude + 2);
/*  94 */         trimmedLines.add("");
/*  95 */         for (StackTraceElement each : stackTraceElements.subList(0, linesToInclude)) {
/*  96 */           trimmedLines.add("\tat " + each);
/*     */         }
/*  98 */         if (exception.getCause() != null) {
/*  99 */           trimmedLines.add("\t... " + (stackTraceElements.size() - trimmedLines.size()) + " trimmed");
/*     */         }
/* 101 */         return trimmedLines;
/*     */       } 
/* 103 */       linesToInclude--;
/*     */     } 
/* 105 */     return Collections.emptyList();
/*     */   }
/*     */   
/* 108 */   private static final Method getSuppressed = initGetSuppressed();
/*     */   
/*     */   private static Method initGetSuppressed() {
/*     */     try {
/* 112 */       return Throwable.class.getMethod("getSuppressed", new Class[0]);
/* 113 */     } catch (Throwable e) {
/* 114 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean hasSuppressed(Throwable exception) {
/* 119 */     if (getSuppressed == null) {
/* 120 */       return false;
/*     */     }
/*     */     try {
/* 123 */       Throwable[] suppressed = (Throwable[])getSuppressed.invoke(exception, new Object[0]);
/* 124 */       return (suppressed.length != 0);
/* 125 */     } catch (Throwable e) {
/* 126 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static List<String> getCauseStackTraceLines(Throwable exception) {
/* 131 */     if (exception.getCause() != null || hasSuppressed(exception)) {
/* 132 */       String fullTrace = getFullStackTrace(exception);
/* 133 */       BufferedReader reader = new BufferedReader(new StringReader(fullTrace.substring(exception.toString().length())));
/*     */       
/* 135 */       List<String> causedByLines = new ArrayList<String>();
/*     */       
/*     */       try {
/*     */         String line;
/* 139 */         while ((line = reader.readLine()) != null) {
/* 140 */           if (line.startsWith("Caused by: ") || line.trim().startsWith("Suppressed: ")) {
/* 141 */             causedByLines.add(line);
/* 142 */             while ((line = reader.readLine()) != null) {
/* 143 */               causedByLines.add(line);
/*     */             }
/* 145 */             return causedByLines;
/*     */           } 
/*     */         } 
/* 148 */       } catch (IOException e) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 153 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   private static String getFullStackTrace(Throwable exception) {
/* 157 */     StringWriter stringWriter = new StringWriter();
/* 158 */     PrintWriter writer = new PrintWriter(stringWriter);
/* 159 */     exception.printStackTrace(writer);
/* 160 */     return stringWriter.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void appendStackTraceLines(List<String> stackTraceLines, StringBuilder destBuilder) {
/* 165 */     for (String stackTraceLine : stackTraceLines) {
/* 166 */       destBuilder.append(String.format("%s%n", new Object[] { stackTraceLine }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static <T> List<T> asReversedList(final List<T> list) {
/* 171 */     return new AbstractList<T>()
/*     */       {
/*     */         public T get(int index)
/*     */         {
/* 175 */           return list.get(list.size() - index - 1);
/*     */         }
/*     */ 
/*     */         
/*     */         public int size() {
/* 180 */           return list.size();
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private enum State {
/* 186 */     PROCESSING_OTHER_CODE {
/*     */       public State processLine(String methodName) {
/* 188 */         if (Throwables.isTestFrameworkMethod(methodName)) {
/* 189 */           return PROCESSING_TEST_FRAMEWORK_CODE;
/*     */         }
/* 191 */         return this;
/*     */       }
/*     */     },
/* 194 */     PROCESSING_TEST_FRAMEWORK_CODE {
/*     */       public State processLine(String methodName) {
/* 196 */         if (Throwables.isReflectionMethod(methodName))
/* 197 */           return PROCESSING_REFLECTION_CODE; 
/* 198 */         if (Throwables.isTestFrameworkMethod(methodName)) {
/* 199 */           return this;
/*     */         }
/* 201 */         return PROCESSING_OTHER_CODE;
/*     */       }
/*     */     },
/* 204 */     PROCESSING_REFLECTION_CODE {
/*     */       public State processLine(String methodName) {
/* 206 */         if (Throwables.isReflectionMethod(methodName))
/* 207 */           return this; 
/* 208 */         if (Throwables.isTestFrameworkMethod(methodName))
/*     */         {
/* 210 */           return PROCESSING_TEST_FRAMEWORK_CODE;
/*     */         }
/* 212 */         return DONE;
/*     */       }
/*     */     },
/* 215 */     DONE {
/*     */       public State processLine(String methodName) {
/* 217 */         return this;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final State processStackTraceElement(StackTraceElement element) {
/* 226 */       return processLine(element.getClassName() + "." + element.getMethodName() + "()");
/*     */     }
/*     */     
/*     */     protected abstract State processLine(String param1String); }
/* 230 */   private static final String[] TEST_FRAMEWORK_METHOD_NAME_PREFIXES = new String[] { "org.junit.runner.", "org.junit.runners.", "org.junit.experimental.runners.", "org.junit.internal.", "junit." };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 238 */   private static final String[] TEST_FRAMEWORK_TEST_METHOD_NAME_PREFIXES = new String[] { "org.junit.internal.StackTracesTest" };
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isTestFrameworkMethod(String methodName) {
/* 243 */     return (isMatchingMethod(methodName, TEST_FRAMEWORK_METHOD_NAME_PREFIXES) && !isMatchingMethod(methodName, TEST_FRAMEWORK_TEST_METHOD_NAME_PREFIXES));
/*     */   }
/*     */ 
/*     */   
/* 247 */   private static final String[] REFLECTION_METHOD_NAME_PREFIXES = new String[] { "sun.reflect.", "java.lang.reflect.", "jdk.internal.reflect.", "org.junit.rules.RunRules.<init>(", "org.junit.rules.RunRules.applyAll(", "org.junit.runners.RuleContainer.apply(", "junit.framework.TestCase.runBare(" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isReflectionMethod(String methodName) {
/* 258 */     return isMatchingMethod(methodName, REFLECTION_METHOD_NAME_PREFIXES);
/*     */   }
/*     */   
/*     */   private static boolean isMatchingMethod(String methodName, String[] methodNamePrefixes) {
/* 262 */     for (String methodNamePrefix : methodNamePrefixes) {
/* 263 */       if (methodName.startsWith(methodNamePrefix)) {
/* 264 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 268 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\Throwables.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */