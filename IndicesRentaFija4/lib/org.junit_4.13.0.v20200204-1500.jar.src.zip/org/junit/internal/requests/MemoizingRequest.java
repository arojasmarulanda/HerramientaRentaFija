/*    */ package org.junit.internal.requests;
/*    */ 
/*    */ import java.util.concurrent.locks.Lock;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ import org.junit.runner.Request;
/*    */ import org.junit.runner.Runner;
/*    */ 
/*    */ abstract class MemoizingRequest
/*    */   extends Request {
/* 10 */   private final Lock runnerLock = new ReentrantLock();
/*    */   
/*    */   private volatile Runner runner;
/*    */   
/*    */   public final Runner getRunner() {
/* 15 */     if (this.runner == null) {
/* 16 */       this.runnerLock.lock();
/*    */       try {
/* 18 */         if (this.runner == null) {
/* 19 */           this.runner = createRunner();
/*    */         }
/*    */       } finally {
/* 22 */         this.runnerLock.unlock();
/*    */       } 
/*    */     } 
/* 25 */     return this.runner;
/*    */   }
/*    */   
/*    */   protected abstract Runner createRunner();
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\requests\MemoizingRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */