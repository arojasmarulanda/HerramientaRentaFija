/*    */ package org.junit.internal.requests;
/*    */ 
/*    */ import org.junit.internal.builders.AllDefaultPossibilitiesBuilder;
/*    */ import org.junit.internal.builders.SuiteMethodBuilder;
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runners.model.RunnerBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassRequest
/*    */   extends MemoizingRequest
/*    */ {
/*    */   private final Class<?> fTestClass;
/*    */   private final boolean canUseSuiteMethod;
/*    */   
/*    */   public ClassRequest(Class<?> testClass, boolean canUseSuiteMethod) {
/* 18 */     this.fTestClass = testClass;
/* 19 */     this.canUseSuiteMethod = canUseSuiteMethod;
/*    */   }
/*    */   
/*    */   public ClassRequest(Class<?> testClass) {
/* 23 */     this(testClass, true);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Runner createRunner() {
/* 28 */     return (new CustomAllDefaultPossibilitiesBuilder()).safeRunnerForClass(this.fTestClass);
/*    */   }
/*    */   
/*    */   private class CustomAllDefaultPossibilitiesBuilder extends AllDefaultPossibilitiesBuilder {
/*    */     private CustomAllDefaultPossibilitiesBuilder() {}
/*    */     
/*    */     protected RunnerBuilder suiteMethodBuilder() {
/* 35 */       return (RunnerBuilder)new ClassRequest.CustomSuiteMethodBuilder();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private class CustomSuiteMethodBuilder
/*    */     extends SuiteMethodBuilder
/*    */   {
/*    */     private CustomSuiteMethodBuilder() {}
/*    */ 
/*    */     
/*    */     public Runner runnerForClass(Class<?> testClass) throws Throwable {
/* 48 */       if (testClass == ClassRequest.this.fTestClass && !ClassRequest.this.canUseSuiteMethod) {
/* 49 */         return null;
/*    */       }
/* 51 */       return super.runnerForClass(testClass);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\requests\ClassRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */