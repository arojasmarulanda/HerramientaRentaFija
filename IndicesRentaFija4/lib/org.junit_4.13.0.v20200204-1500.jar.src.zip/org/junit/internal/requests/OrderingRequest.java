/*    */ package org.junit.internal.requests;
/*    */ 
/*    */ import org.junit.internal.runners.ErrorReportingRunner;
/*    */ import org.junit.runner.Request;
/*    */ import org.junit.runner.Runner;
/*    */ import org.junit.runner.manipulation.InvalidOrderingException;
/*    */ import org.junit.runner.manipulation.Ordering;
/*    */ 
/*    */ public class OrderingRequest
/*    */   extends MemoizingRequest {
/*    */   private final Request request;
/*    */   private final Ordering ordering;
/*    */   
/*    */   public OrderingRequest(Request request, Ordering ordering) {
/* 15 */     this.request = request;
/* 16 */     this.ordering = ordering;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Runner createRunner() {
/* 21 */     Runner runner = this.request.getRunner();
/*    */     try {
/* 23 */       this.ordering.apply(runner);
/* 24 */     } catch (InvalidOrderingException e) {
/* 25 */       return (Runner)new ErrorReportingRunner(this.ordering.getClass(), (Throwable)e);
/*    */     } 
/* 27 */     return runner;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\requests\OrderingRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */