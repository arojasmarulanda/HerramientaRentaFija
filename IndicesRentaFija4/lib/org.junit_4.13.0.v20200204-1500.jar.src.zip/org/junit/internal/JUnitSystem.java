package org.junit.internal;

import java.io.PrintStream;

public interface JUnitSystem {
  @Deprecated
  void exit(int paramInt);
  
  PrintStream out();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\JUnitSystem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */