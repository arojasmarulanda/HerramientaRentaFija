/*    */ package org.junit.internal.matchers;
/*    */ 
/*    */ import org.hamcrest.Description;
/*    */ import org.hamcrest.Factory;
/*    */ import org.hamcrest.Matcher;
/*    */ import org.hamcrest.TypeSafeMatcher;
/*    */ import org.junit.internal.Throwables;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StacktracePrintingMatcher<T extends Throwable>
/*    */   extends TypeSafeMatcher<T>
/*    */ {
/*    */   private final Matcher<T> throwableMatcher;
/*    */   
/*    */   public StacktracePrintingMatcher(Matcher<T> throwableMatcher) {
/* 19 */     this.throwableMatcher = throwableMatcher;
/*    */   }
/*    */   
/*    */   public void describeTo(Description description) {
/* 23 */     this.throwableMatcher.describeTo(description);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean matchesSafely(T item) {
/* 28 */     return this.throwableMatcher.matches(item);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void describeMismatchSafely(T item, Description description) {
/* 33 */     this.throwableMatcher.describeMismatch(item, description);
/* 34 */     description.appendText("\nStacktrace was: ");
/* 35 */     description.appendText(readStacktrace((Throwable)item));
/*    */   }
/*    */   
/*    */   private String readStacktrace(Throwable throwable) {
/* 39 */     return Throwables.getStacktrace(throwable);
/*    */   }
/*    */ 
/*    */   
/*    */   @Factory
/*    */   public static <T extends Throwable> Matcher<T> isThrowable(Matcher<T> throwableMatcher) {
/* 45 */     return (Matcher<T>)new StacktracePrintingMatcher<T>(throwableMatcher);
/*    */   }
/*    */ 
/*    */   
/*    */   @Factory
/*    */   public static <T extends Exception> Matcher<T> isException(Matcher<T> exceptionMatcher) {
/* 51 */     return (Matcher)new StacktracePrintingMatcher<Throwable>((Matcher)exceptionMatcher);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\matchers\StacktracePrintingMatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */