/*     */ package org.junit.internal;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import org.junit.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ComparisonCriteria
/*     */ {
/*     */   public void arrayEquals(String message, Object expecteds, Object actuals) throws ArrayComparisonFailure {
/*  28 */     arrayEquals(message, expecteds, actuals, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private void arrayEquals(String message, Object expecteds, Object actuals, boolean outer) throws ArrayComparisonFailure {
/*  33 */     if (expecteds == actuals || Arrays.deepEquals(new Object[] { expecteds }, new Object[] { actuals })) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     String header = (message == null) ? "" : (message + ": ");
/*     */ 
/*     */     
/*  43 */     String exceptionMessage = outer ? header : "";
/*     */     
/*  45 */     if (expecteds == null) {
/*  46 */       Assert.fail(exceptionMessage + "expected array was null");
/*     */     }
/*  48 */     if (actuals == null) {
/*  49 */       Assert.fail(exceptionMessage + "actual array was null");
/*     */     }
/*     */     
/*  52 */     int actualsLength = Array.getLength(actuals);
/*  53 */     int expectedsLength = Array.getLength(expecteds);
/*  54 */     if (actualsLength != expectedsLength) {
/*  55 */       header = header + "array lengths differed, expected.length=" + expectedsLength + " actual.length=" + actualsLength + "; ";
/*     */     }
/*     */     
/*  58 */     int prefixLength = Math.min(actualsLength, expectedsLength);
/*     */     
/*  60 */     for (int i = 0; i < prefixLength; i++) {
/*  61 */       Object expected = Array.get(expecteds, i);
/*  62 */       Object actual = Array.get(actuals, i);
/*     */       
/*  64 */       if (isArray(expected) && isArray(actual)) {
/*     */         try {
/*  66 */           arrayEquals(message, expected, actual, false);
/*  67 */         } catch (ArrayComparisonFailure e) {
/*  68 */           e.addDimension(i);
/*  69 */           throw e;
/*  70 */         } catch (AssertionError e) {
/*     */           
/*  72 */           throw new ArrayComparisonFailure(header, e, i);
/*     */         } 
/*     */       } else {
/*     */         try {
/*  76 */           assertElementsEqual(expected, actual);
/*  77 */         } catch (AssertionError e) {
/*  78 */           throw new ArrayComparisonFailure(header, e, i);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  83 */     if (actualsLength != expectedsLength) {
/*  84 */       Object expected = getToStringableArrayElement(expecteds, expectedsLength, prefixLength);
/*  85 */       Object actual = getToStringableArrayElement(actuals, actualsLength, prefixLength);
/*     */       try {
/*  87 */         Assert.assertEquals(expected, actual);
/*  88 */       } catch (AssertionError e) {
/*  89 */         throw new ArrayComparisonFailure(header, e, prefixLength);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*  94 */   private static final Object END_OF_ARRAY_SENTINEL = objectWithToString("end of array");
/*     */   
/*     */   private Object getToStringableArrayElement(Object array, int length, int index) {
/*  97 */     if (index < length) {
/*  98 */       Object element = Array.get(array, index);
/*  99 */       if (isArray(element)) {
/* 100 */         return objectWithToString(componentTypeName(element.getClass()) + "[" + Array.getLength(element) + "]");
/*     */       }
/* 102 */       return element;
/*     */     } 
/*     */     
/* 105 */     return END_OF_ARRAY_SENTINEL;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object objectWithToString(final String string) {
/* 110 */     return new Object()
/*     */       {
/*     */         public String toString() {
/* 113 */           return string;
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private String componentTypeName(Class<?> arrayClass) {
/* 119 */     Class<?> componentType = arrayClass.getComponentType();
/* 120 */     if (componentType.isArray()) {
/* 121 */       return componentTypeName(componentType) + "[]";
/*     */     }
/* 123 */     return componentType.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isArray(Object expected) {
/* 128 */     return (expected != null && expected.getClass().isArray());
/*     */   }
/*     */   
/*     */   protected abstract void assertElementsEqual(Object paramObject1, Object paramObject2);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\internal\ComparisonCriteria.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */