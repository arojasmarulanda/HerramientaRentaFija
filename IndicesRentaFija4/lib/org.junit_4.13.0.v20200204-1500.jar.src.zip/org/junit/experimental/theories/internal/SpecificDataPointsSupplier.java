/*    */ package org.junit.experimental.theories.internal;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.junit.experimental.theories.DataPoint;
/*    */ import org.junit.experimental.theories.DataPoints;
/*    */ import org.junit.experimental.theories.FromDataPoints;
/*    */ import org.junit.experimental.theories.ParameterSignature;
/*    */ import org.junit.runners.model.FrameworkMethod;
/*    */ import org.junit.runners.model.TestClass;
/*    */ 
/*    */ public class SpecificDataPointsSupplier
/*    */   extends AllMembersSupplier
/*    */ {
/*    */   public SpecificDataPointsSupplier(TestClass testClass) {
/* 19 */     super(testClass);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<Field> getSingleDataPointFields(ParameterSignature sig) {
/* 24 */     Collection<Field> fields = super.getSingleDataPointFields(sig);
/* 25 */     String requestedName = ((FromDataPoints)sig.getAnnotation(FromDataPoints.class)).value();
/*    */     
/* 27 */     List<Field> fieldsWithMatchingNames = new ArrayList<Field>();
/*    */     
/* 29 */     for (Field field : fields) {
/* 30 */       String[] fieldNames = ((DataPoint)field.<DataPoint>getAnnotation(DataPoint.class)).value();
/* 31 */       if (Arrays.<String>asList(fieldNames).contains(requestedName)) {
/* 32 */         fieldsWithMatchingNames.add(field);
/*    */       }
/*    */     } 
/*    */     
/* 36 */     return fieldsWithMatchingNames;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<Field> getDataPointsFields(ParameterSignature sig) {
/* 41 */     Collection<Field> fields = super.getDataPointsFields(sig);
/* 42 */     String requestedName = ((FromDataPoints)sig.getAnnotation(FromDataPoints.class)).value();
/*    */     
/* 44 */     List<Field> fieldsWithMatchingNames = new ArrayList<Field>();
/*    */     
/* 46 */     for (Field field : fields) {
/* 47 */       String[] fieldNames = ((DataPoints)field.<DataPoints>getAnnotation(DataPoints.class)).value();
/* 48 */       if (Arrays.<String>asList(fieldNames).contains(requestedName)) {
/* 49 */         fieldsWithMatchingNames.add(field);
/*    */       }
/*    */     } 
/*    */     
/* 53 */     return fieldsWithMatchingNames;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<FrameworkMethod> getSingleDataPointMethods(ParameterSignature sig) {
/* 58 */     Collection<FrameworkMethod> methods = super.getSingleDataPointMethods(sig);
/* 59 */     String requestedName = ((FromDataPoints)sig.getAnnotation(FromDataPoints.class)).value();
/*    */     
/* 61 */     List<FrameworkMethod> methodsWithMatchingNames = new ArrayList<FrameworkMethod>();
/*    */     
/* 63 */     for (FrameworkMethod method : methods) {
/* 64 */       String[] methodNames = ((DataPoint)method.getAnnotation(DataPoint.class)).value();
/* 65 */       if (Arrays.<String>asList(methodNames).contains(requestedName)) {
/* 66 */         methodsWithMatchingNames.add(method);
/*    */       }
/*    */     } 
/*    */     
/* 70 */     return methodsWithMatchingNames;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<FrameworkMethod> getDataPointsMethods(ParameterSignature sig) {
/* 75 */     Collection<FrameworkMethod> methods = super.getDataPointsMethods(sig);
/* 76 */     String requestedName = ((FromDataPoints)sig.getAnnotation(FromDataPoints.class)).value();
/*    */     
/* 78 */     List<FrameworkMethod> methodsWithMatchingNames = new ArrayList<FrameworkMethod>();
/*    */     
/* 80 */     for (FrameworkMethod method : methods) {
/* 81 */       String[] methodNames = ((DataPoints)method.getAnnotation(DataPoints.class)).value();
/* 82 */       if (Arrays.<String>asList(methodNames).contains(requestedName)) {
/* 83 */         methodsWithMatchingNames.add(method);
/*    */       }
/*    */     } 
/*    */     
/* 87 */     return methodsWithMatchingNames;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\experimental\theories\internal\SpecificDataPointsSupplier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */