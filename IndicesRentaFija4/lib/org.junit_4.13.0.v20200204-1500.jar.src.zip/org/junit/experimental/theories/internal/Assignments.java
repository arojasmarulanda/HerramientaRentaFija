/*     */ package org.junit.experimental.theories.internal;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.junit.experimental.theories.ParameterSignature;
/*     */ import org.junit.experimental.theories.ParameterSupplier;
/*     */ import org.junit.experimental.theories.ParametersSuppliedBy;
/*     */ import org.junit.experimental.theories.PotentialAssignment;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Assignments
/*     */ {
/*     */   private final List<PotentialAssignment> assigned;
/*     */   private final List<ParameterSignature> unassigned;
/*     */   private final TestClass clazz;
/*     */   
/*     */   private Assignments(List<PotentialAssignment> assigned, List<ParameterSignature> unassigned, TestClass clazz) {
/*  30 */     this.unassigned = unassigned;
/*  31 */     this.assigned = assigned;
/*  32 */     this.clazz = clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Assignments allUnassigned(Method testMethod, TestClass testClass) {
/*  42 */     List<ParameterSignature> signatures = ParameterSignature.signatures(testClass.getOnlyConstructor());
/*     */     
/*  44 */     signatures.addAll(ParameterSignature.signatures(testMethod));
/*  45 */     return new Assignments(new ArrayList<PotentialAssignment>(), signatures, testClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isComplete() {
/*  50 */     return this.unassigned.isEmpty();
/*     */   }
/*     */   
/*     */   public ParameterSignature nextUnassigned() {
/*  54 */     return this.unassigned.get(0);
/*     */   }
/*     */   
/*     */   public Assignments assignNext(PotentialAssignment source) {
/*  58 */     List<PotentialAssignment> potentialAssignments = new ArrayList<PotentialAssignment>(this.assigned);
/*  59 */     potentialAssignments.add(source);
/*     */     
/*  61 */     return new Assignments(potentialAssignments, this.unassigned.subList(1, this.unassigned.size()), this.clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getActualValues(int start, int stop) throws PotentialAssignment.CouldNotGenerateValueException {
/*  67 */     Object[] values = new Object[stop - start];
/*  68 */     for (int i = start; i < stop; i++) {
/*  69 */       values[i - start] = ((PotentialAssignment)this.assigned.get(i)).getValue();
/*     */     }
/*  71 */     return values;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<PotentialAssignment> potentialsForNextUnassigned() throws Throwable {
/*  76 */     ParameterSignature unassigned = nextUnassigned();
/*  77 */     List<PotentialAssignment> assignments = getSupplier(unassigned).getValueSources(unassigned);
/*     */     
/*  79 */     if (assignments.isEmpty()) {
/*  80 */       assignments = generateAssignmentsFromTypeAlone(unassigned);
/*     */     }
/*     */     
/*  83 */     return assignments;
/*     */   }
/*     */   
/*     */   private List<PotentialAssignment> generateAssignmentsFromTypeAlone(ParameterSignature unassigned) {
/*  87 */     Class<?> paramType = unassigned.getType();
/*     */     
/*  89 */     if (paramType.isEnum())
/*  90 */       return (new EnumSupplier(paramType)).getValueSources(unassigned); 
/*  91 */     if (paramType.equals(Boolean.class) || paramType.equals(boolean.class)) {
/*  92 */       return (new BooleanSupplier()).getValueSources(unassigned);
/*     */     }
/*  94 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ParameterSupplier getSupplier(ParameterSignature unassigned) throws Exception {
/* 100 */     ParametersSuppliedBy annotation = (ParametersSuppliedBy)unassigned.findDeepAnnotation(ParametersSuppliedBy.class);
/*     */ 
/*     */     
/* 103 */     if (annotation != null) {
/* 104 */       return buildParameterSupplierFromClass(annotation.value());
/*     */     }
/* 106 */     return new AllMembersSupplier(this.clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ParameterSupplier buildParameterSupplierFromClass(Class<? extends ParameterSupplier> cls) throws Exception {
/* 112 */     Constructor[] arrayOfConstructor = (Constructor[])cls.getConstructors();
/*     */     
/* 114 */     for (Constructor<?> constructor : arrayOfConstructor) {
/* 115 */       Class<?>[] parameterTypes = constructor.getParameterTypes();
/* 116 */       if (parameterTypes.length == 1 && parameterTypes[0].equals(TestClass.class))
/*     */       {
/* 118 */         return (ParameterSupplier)constructor.newInstance(new Object[] { this.clazz });
/*     */       }
/*     */     } 
/*     */     
/* 122 */     return cls.newInstance();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getConstructorArguments() throws PotentialAssignment.CouldNotGenerateValueException {
/* 127 */     return getActualValues(0, getConstructorParameterCount());
/*     */   }
/*     */   
/*     */   public Object[] getMethodArguments() throws PotentialAssignment.CouldNotGenerateValueException {
/* 131 */     return getActualValues(getConstructorParameterCount(), this.assigned.size());
/*     */   }
/*     */   
/*     */   public Object[] getAllArguments() throws PotentialAssignment.CouldNotGenerateValueException {
/* 135 */     return getActualValues(0, this.assigned.size());
/*     */   }
/*     */   
/*     */   private int getConstructorParameterCount() {
/* 139 */     List<ParameterSignature> signatures = ParameterSignature.signatures(this.clazz.getOnlyConstructor());
/*     */     
/* 141 */     int constructorParameterCount = signatures.size();
/* 142 */     return constructorParameterCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getArgumentStrings(boolean nullsOk) throws PotentialAssignment.CouldNotGenerateValueException {
/* 147 */     Object[] values = new Object[this.assigned.size()];
/* 148 */     for (int i = 0; i < values.length; i++) {
/* 149 */       values[i] = ((PotentialAssignment)this.assigned.get(i)).getDescription();
/*     */     }
/* 151 */     return values;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\experimental\theories\internal\Assignments.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */