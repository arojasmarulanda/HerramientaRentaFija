/*     */ package org.junit.experimental.theories;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.junit.Assert;
/*     */ import org.junit.Assume;
/*     */ import org.junit.experimental.theories.internal.Assignments;
/*     */ import org.junit.experimental.theories.internal.ParameterizedAssertionError;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.runners.BlockJUnit4ClassRunner;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Theories
/*     */   extends BlockJUnit4ClassRunner
/*     */ {
/*     */   public Theories(Class<?> klass) throws InitializationError {
/*  73 */     super(klass);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Theories(TestClass testClass) throws InitializationError {
/*  78 */     super(testClass);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void collectInitializationErrors(List<Throwable> errors) {
/*  83 */     super.collectInitializationErrors(errors);
/*  84 */     validateDataPointFields(errors);
/*  85 */     validateDataPointMethods(errors);
/*     */   }
/*     */   
/*     */   private void validateDataPointFields(List<Throwable> errors) {
/*  89 */     Field[] fields = getTestClass().getJavaClass().getDeclaredFields();
/*     */     
/*  91 */     for (Field field : fields) {
/*  92 */       if (field.getAnnotation(DataPoint.class) != null || field.getAnnotation(DataPoints.class) != null) {
/*     */ 
/*     */         
/*  95 */         if (!Modifier.isStatic(field.getModifiers())) {
/*  96 */           errors.add(new Error("DataPoint field " + field.getName() + " must be static"));
/*     */         }
/*  98 */         if (!Modifier.isPublic(field.getModifiers()))
/*  99 */           errors.add(new Error("DataPoint field " + field.getName() + " must be public")); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateDataPointMethods(List<Throwable> errors) {
/* 105 */     Method[] methods = getTestClass().getJavaClass().getDeclaredMethods();
/*     */     
/* 107 */     for (Method method : methods) {
/* 108 */       if (method.getAnnotation(DataPoint.class) != null || method.getAnnotation(DataPoints.class) != null) {
/*     */ 
/*     */         
/* 111 */         if (!Modifier.isStatic(method.getModifiers())) {
/* 112 */           errors.add(new Error("DataPoint method " + method.getName() + " must be static"));
/*     */         }
/* 114 */         if (!Modifier.isPublic(method.getModifiers())) {
/* 115 */           errors.add(new Error("DataPoint method " + method.getName() + " must be public"));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void validateConstructor(List<Throwable> errors) {
/* 122 */     validateOnlyOneConstructor(errors);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validateTestMethods(List<Throwable> errors) {
/* 127 */     for (FrameworkMethod each : computeTestMethods()) {
/* 128 */       if (each.getAnnotation(Theory.class) != null) {
/* 129 */         each.validatePublicVoid(false, errors);
/* 130 */         each.validateNoTypeParametersOnArgs(errors);
/*     */       } else {
/* 132 */         each.validatePublicVoidNoArg(false, errors);
/*     */       } 
/*     */       
/* 135 */       for (ParameterSignature signature : ParameterSignature.signatures(each.getMethod())) {
/* 136 */         ParametersSuppliedBy annotation = signature.<ParametersSuppliedBy>findDeepAnnotation(ParametersSuppliedBy.class);
/* 137 */         if (annotation != null) {
/* 138 */           validateParameterSupplier(annotation.value(), errors);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateParameterSupplier(Class<? extends ParameterSupplier> supplierClass, List<Throwable> errors) {
/* 145 */     Constructor[] arrayOfConstructor = (Constructor[])supplierClass.getConstructors();
/*     */     
/* 147 */     if (arrayOfConstructor.length != 1) {
/* 148 */       errors.add(new Error("ParameterSupplier " + supplierClass.getName() + " must have only one constructor (either empty or taking only a TestClass)"));
/*     */     } else {
/*     */       
/* 151 */       Class<?>[] paramTypes = arrayOfConstructor[0].getParameterTypes();
/* 152 */       if (paramTypes.length != 0 && !paramTypes[0].equals(TestClass.class)) {
/* 153 */         errors.add(new Error("ParameterSupplier " + supplierClass.getName() + " constructor must take either nothing or a single TestClass instance"));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<FrameworkMethod> computeTestMethods() {
/* 161 */     List<FrameworkMethod> testMethods = new ArrayList<FrameworkMethod>(super.computeTestMethods());
/* 162 */     List<FrameworkMethod> theoryMethods = getTestClass().getAnnotatedMethods(Theory.class);
/* 163 */     testMethods.removeAll(theoryMethods);
/* 164 */     testMethods.addAll(theoryMethods);
/* 165 */     return testMethods;
/*     */   }
/*     */ 
/*     */   
/*     */   public Statement methodBlock(FrameworkMethod method) {
/* 170 */     return new TheoryAnchor(method, getTestClass());
/*     */   }
/*     */   
/*     */   public static class TheoryAnchor extends Statement {
/* 174 */     private int successes = 0;
/*     */     
/*     */     private final FrameworkMethod testMethod;
/*     */     
/*     */     private final TestClass testClass;
/* 179 */     private List<AssumptionViolatedException> fInvalidParameters = new ArrayList<AssumptionViolatedException>();
/*     */     
/*     */     public TheoryAnchor(FrameworkMethod testMethod, TestClass testClass) {
/* 182 */       this.testMethod = testMethod;
/* 183 */       this.testClass = testClass;
/*     */     }
/*     */     
/*     */     private TestClass getTestClass() {
/* 187 */       return this.testClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public void evaluate() throws Throwable {
/* 192 */       runWithAssignment(Assignments.allUnassigned(this.testMethod.getMethod(), getTestClass()));
/*     */ 
/*     */ 
/*     */       
/* 196 */       boolean hasTheoryAnnotation = (this.testMethod.getAnnotation(Theory.class) != null);
/* 197 */       if (this.successes == 0 && hasTheoryAnnotation) {
/* 198 */         Assert.fail("Never found parameters that satisfied method assumptions.  Violated assumptions: " + this.fInvalidParameters);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void runWithAssignment(Assignments parameterAssignment) throws Throwable {
/* 206 */       if (!parameterAssignment.isComplete()) {
/* 207 */         runWithIncompleteAssignment(parameterAssignment);
/*     */       } else {
/* 209 */         runWithCompleteAssignment(parameterAssignment);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected void runWithIncompleteAssignment(Assignments incomplete) throws Throwable {
/* 215 */       for (PotentialAssignment source : incomplete.potentialsForNextUnassigned())
/*     */       {
/* 217 */         runWithAssignment(incomplete.assignNext(source));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     protected void runWithCompleteAssignment(final Assignments complete) throws Throwable {
/* 223 */       (new BlockJUnit4ClassRunner(getTestClass())
/*     */         {
/*     */           protected void collectInitializationErrors(List<Throwable> errors) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public Statement methodBlock(FrameworkMethod method) {
/* 232 */             final Statement statement = super.methodBlock(method);
/* 233 */             return new Statement()
/*     */               {
/*     */                 public void evaluate() throws Throwable {
/*     */                   try {
/* 237 */                     statement.evaluate();
/* 238 */                     Theories.TheoryAnchor.this.handleDataPointSuccess();
/* 239 */                   } catch (AssumptionViolatedException e) {
/* 240 */                     Theories.TheoryAnchor.this.handleAssumptionViolation(e);
/* 241 */                   } catch (Throwable e) {
/* 242 */                     Theories.TheoryAnchor.this.reportParameterizedError(e, complete.getArgumentStrings(Theories.TheoryAnchor.this.nullsOk()));
/*     */                   } 
/*     */                 }
/*     */               };
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           protected Statement methodInvoker(FrameworkMethod method, Object test) {
/* 252 */             return Theories.TheoryAnchor.this.methodCompletesWithParameters(method, complete, test);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object createTest() throws Exception {
/* 257 */             Object[] params = complete.getConstructorArguments();
/*     */             
/* 259 */             if (!Theories.TheoryAnchor.this.nullsOk()) {
/* 260 */               Assume.assumeNotNull(params);
/*     */             }
/*     */             
/* 263 */             return getTestClass().getOnlyConstructor().newInstance(params);
/*     */           }
/*     */         }).methodBlock(this.testMethod).evaluate();
/*     */     }
/*     */ 
/*     */     
/*     */     private Statement methodCompletesWithParameters(final FrameworkMethod method, final Assignments complete, final Object freshInstance) {
/* 270 */       return new Statement()
/*     */         {
/*     */           public void evaluate() throws Throwable {
/* 273 */             Object[] values = complete.getMethodArguments();
/*     */             
/* 275 */             if (!Theories.TheoryAnchor.this.nullsOk()) {
/* 276 */               Assume.assumeNotNull(values);
/*     */             }
/*     */             
/* 279 */             method.invokeExplosively(freshInstance, values);
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     protected void handleAssumptionViolation(AssumptionViolatedException e) {
/* 285 */       this.fInvalidParameters.add(e);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void reportParameterizedError(Throwable e, Object... params) throws Throwable {
/* 290 */       if (params.length == 0) {
/* 291 */         throw e;
/*     */       }
/* 293 */       throw new ParameterizedAssertionError(e, this.testMethod.getName(), params);
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean nullsOk() {
/* 298 */       Theory annotation = this.testMethod.getMethod().<Theory>getAnnotation(Theory.class);
/*     */       
/* 300 */       if (annotation == null) {
/* 301 */         return false;
/*     */       }
/* 303 */       return annotation.nullsAccepted();
/*     */     }
/*     */     
/*     */     protected void handleDataPointSuccess() {
/* 307 */       this.successes++;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\experimental\theories\Theories.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */