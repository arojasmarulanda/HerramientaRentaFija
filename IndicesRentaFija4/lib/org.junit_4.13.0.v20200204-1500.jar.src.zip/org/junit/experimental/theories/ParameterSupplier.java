package org.junit.experimental.theories;

import java.util.List;

public abstract class ParameterSupplier {
  public abstract List<PotentialAssignment> getValueSources(ParameterSignature paramParameterSignature) throws Throwable;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\experimental\theories\ParameterSupplier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */