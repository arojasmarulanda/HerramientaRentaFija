/*    */ package org.junit.experimental.max;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CouldNotReadCoreException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public CouldNotReadCoreException(Throwable e) {
/* 13 */     super(e);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\experimental\max\CouldNotReadCoreException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */