/*     */ package org.junit.experimental.max;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.Result;
/*     */ import org.junit.runner.notification.Failure;
/*     */ import org.junit.runner.notification.RunListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MaxHistory
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public static MaxHistory forFolder(File file) {
/*  34 */     if (file.exists()) {
/*     */       try {
/*  36 */         return readHistory(file);
/*  37 */       } catch (CouldNotReadCoreException e) {
/*  38 */         e.printStackTrace();
/*  39 */         file.delete();
/*     */       } 
/*     */     }
/*  42 */     return new MaxHistory(file);
/*     */   }
/*     */ 
/*     */   
/*     */   private static MaxHistory readHistory(File storedResults) throws CouldNotReadCoreException {
/*     */     try {
/*  48 */       FileInputStream file = new FileInputStream(storedResults);
/*     */       try {
/*  50 */         ObjectInputStream stream = new ObjectInputStream(file);
/*     */ 
/*     */       
/*     */       }
/*     */       finally {
/*     */ 
/*     */         
/*  57 */         file.close();
/*     */       } 
/*  59 */     } catch (Exception e) {
/*  60 */       throw new CouldNotReadCoreException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private final Map<String, Long> fDurations = new HashMap<String, Long>();
/*  70 */   private final Map<String, Long> fFailureTimestamps = new HashMap<String, Long>();
/*     */   private final File fHistoryStore;
/*     */   
/*     */   private MaxHistory(File storedResults) {
/*  74 */     this.fHistoryStore = storedResults;
/*     */   }
/*     */   
/*     */   private void save() throws IOException {
/*  78 */     ObjectOutputStream stream = null;
/*     */     try {
/*  80 */       stream = new ObjectOutputStream(new FileOutputStream(this.fHistoryStore));
/*  81 */       stream.writeObject(this);
/*     */     } finally {
/*  83 */       if (stream != null) {
/*  84 */         stream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   Long getFailureTimestamp(Description key) {
/*  90 */     return this.fFailureTimestamps.get(key.toString());
/*     */   }
/*     */   
/*     */   void putTestFailureTimestamp(Description key, long end) {
/*  94 */     this.fFailureTimestamps.put(key.toString(), Long.valueOf(end));
/*     */   }
/*     */   
/*     */   boolean isNewTest(Description key) {
/*  98 */     return !this.fDurations.containsKey(key.toString());
/*     */   }
/*     */   
/*     */   Long getTestDuration(Description key) {
/* 102 */     return this.fDurations.get(key.toString());
/*     */   }
/*     */   
/*     */   void putTestDuration(Description description, long duration) {
/* 106 */     this.fDurations.put(description.toString(), Long.valueOf(duration));
/*     */   }
/*     */   
/*     */   private final class RememberingListener extends RunListener {
/* 110 */     private long overallStart = System.currentTimeMillis();
/*     */     
/* 112 */     private Map<Description, Long> starts = new HashMap<Description, Long>();
/*     */ 
/*     */     
/*     */     public void testStarted(Description description) throws Exception {
/* 116 */       this.starts.put(description, Long.valueOf(System.nanoTime()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void testFinished(Description description) throws Exception {
/* 122 */       long end = System.nanoTime();
/* 123 */       long start = ((Long)this.starts.get(description)).longValue();
/* 124 */       MaxHistory.this.putTestDuration(description, end - start);
/*     */     }
/*     */ 
/*     */     
/*     */     public void testFailure(Failure failure) throws Exception {
/* 129 */       MaxHistory.this.putTestFailureTimestamp(failure.getDescription(), this.overallStart);
/*     */     }
/*     */ 
/*     */     
/*     */     public void testRunFinished(Result result) throws Exception {
/* 134 */       MaxHistory.this.save();
/*     */     }
/*     */     
/*     */     private RememberingListener() {} }
/*     */   
/*     */   private class TestComparator implements Comparator<Description> {
/*     */     public int compare(Description o1, Description o2) {
/* 141 */       if (MaxHistory.this.isNewTest(o1)) {
/* 142 */         return -1;
/*     */       }
/* 144 */       if (MaxHistory.this.isNewTest(o2)) {
/* 145 */         return 1;
/*     */       }
/*     */       
/* 148 */       int result = getFailure(o2).compareTo(getFailure(o1));
/* 149 */       return (result != 0) ? result : MaxHistory.this.getTestDuration(o1).compareTo(MaxHistory.this.getTestDuration(o2));
/*     */     }
/*     */     
/*     */     private TestComparator() {}
/*     */     
/*     */     private Long getFailure(Description key) {
/* 155 */       Long result = MaxHistory.this.getFailureTimestamp(key);
/* 156 */       if (result == null) {
/* 157 */         return Long.valueOf(0L);
/*     */       }
/* 159 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RunListener listener() {
/* 168 */     return new RememberingListener();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparator<Description> testComparator() {
/* 176 */     return new TestComparator();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\experimental\max\MaxHistory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */