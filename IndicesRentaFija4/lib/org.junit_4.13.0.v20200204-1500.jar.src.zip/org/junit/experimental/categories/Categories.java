/*     */ package org.junit.experimental.categories;
/*     */ 
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.manipulation.Filter;
/*     */ import org.junit.runner.manipulation.NoTestsRemainException;
/*     */ import org.junit.runners.Suite;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.RunnerBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Categories
/*     */   extends Suite
/*     */ {
/*     */   public static class CategoryFilter
/*     */     extends Filter
/*     */   {
/*     */     private final Set<Class<?>> included;
/*     */     private final Set<Class<?>> excluded;
/*     */     private final boolean includedAny;
/*     */     private final boolean excludedAny;
/*     */     
/*     */     public static CategoryFilter include(boolean matchAny, Class<?>... categories) {
/* 122 */       return new CategoryFilter(matchAny, categories, true, null);
/*     */     }
/*     */     
/*     */     public static CategoryFilter include(Class<?> category) {
/* 126 */       return include(true, new Class[] { category });
/*     */     }
/*     */     
/*     */     public static CategoryFilter include(Class<?>... categories) {
/* 130 */       return include(true, categories);
/*     */     }
/*     */     
/*     */     public static CategoryFilter exclude(boolean matchAny, Class<?>... categories) {
/* 134 */       return new CategoryFilter(true, null, matchAny, categories);
/*     */     }
/*     */     
/*     */     public static CategoryFilter exclude(Class<?> category) {
/* 138 */       return exclude(true, new Class[] { category });
/*     */     }
/*     */     
/*     */     public static CategoryFilter exclude(Class<?>... categories) {
/* 142 */       return exclude(true, categories);
/*     */     }
/*     */ 
/*     */     
/*     */     public static CategoryFilter categoryFilter(boolean matchAnyInclusions, Set<Class<?>> inclusions, boolean matchAnyExclusions, Set<Class<?>> exclusions) {
/* 147 */       return new CategoryFilter(matchAnyInclusions, inclusions, matchAnyExclusions, exclusions);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public CategoryFilter(Class<?> includedCategory, Class<?> excludedCategory) {
/* 152 */       this.includedAny = true;
/* 153 */       this.excludedAny = true;
/* 154 */       this.included = Categories.nullableClassToSet(includedCategory);
/* 155 */       this.excluded = Categories.nullableClassToSet(excludedCategory);
/*     */     }
/*     */ 
/*     */     
/*     */     protected CategoryFilter(boolean matchAnyIncludes, Set<Class<?>> includes, boolean matchAnyExcludes, Set<Class<?>> excludes) {
/* 160 */       this.includedAny = matchAnyIncludes;
/* 161 */       this.excludedAny = matchAnyExcludes;
/* 162 */       this.included = copyAndRefine(includes);
/* 163 */       this.excluded = copyAndRefine(excludes);
/*     */     }
/*     */ 
/*     */     
/*     */     private CategoryFilter(boolean matchAnyIncludes, Class<?>[] inclusions, boolean matchAnyExcludes, Class<?>[] exclusions) {
/* 168 */       this.includedAny = matchAnyIncludes;
/* 169 */       this.excludedAny = matchAnyExcludes;
/* 170 */       this.included = Categories.createSet(inclusions);
/* 171 */       this.excluded = Categories.createSet(exclusions);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String describe() {
/* 179 */       return toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 196 */       StringBuilder description = (new StringBuilder("categories ")).append(this.included.isEmpty() ? "[all]" : this.included);
/*     */       
/* 198 */       if (!this.excluded.isEmpty()) {
/* 199 */         description.append(" - ").append(this.excluded);
/*     */       }
/* 201 */       return description.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean shouldRun(Description description) {
/* 206 */       if (hasCorrectCategoryAnnotation(description)) {
/* 207 */         return true;
/*     */       }
/*     */       
/* 210 */       for (Description each : description.getChildren()) {
/* 211 */         if (shouldRun(each)) {
/* 212 */           return true;
/*     */         }
/*     */       } 
/*     */       
/* 216 */       return false;
/*     */     }
/*     */     
/*     */     private boolean hasCorrectCategoryAnnotation(Description description) {
/* 220 */       Set<Class<?>> childCategories = categories(description);
/*     */ 
/*     */       
/* 223 */       if (childCategories.isEmpty()) {
/* 224 */         return this.included.isEmpty();
/*     */       }
/*     */       
/* 227 */       if (!this.excluded.isEmpty()) {
/* 228 */         if (this.excludedAny) {
/* 229 */           if (matchesAnyParentCategories(childCategories, this.excluded)) {
/* 230 */             return false;
/*     */           }
/*     */         }
/* 233 */         else if (matchesAllParentCategories(childCategories, this.excluded)) {
/* 234 */           return false;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 239 */       if (this.included.isEmpty())
/*     */       {
/* 241 */         return true;
/*     */       }
/* 243 */       if (this.includedAny) {
/* 244 */         return matchesAnyParentCategories(childCategories, this.included);
/*     */       }
/* 246 */       return matchesAllParentCategories(childCategories, this.included);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean matchesAnyParentCategories(Set<Class<?>> childCategories, Set<Class<?>> parentCategories) {
/* 256 */       for (Class<?> parentCategory : parentCategories) {
/* 257 */         if (Categories.hasAssignableTo(childCategories, parentCategory)) {
/* 258 */           return true;
/*     */         }
/*     */       } 
/* 261 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean matchesAllParentCategories(Set<Class<?>> childCategories, Set<Class<?>> parentCategories) {
/* 269 */       for (Class<?> parentCategory : parentCategories) {
/* 270 */         if (!Categories.hasAssignableTo(childCategories, parentCategory)) {
/* 271 */           return false;
/*     */         }
/*     */       } 
/* 274 */       return true;
/*     */     }
/*     */     
/*     */     private static Set<Class<?>> categories(Description description) {
/* 278 */       Set<Class<?>> categories = new HashSet<Class<?>>();
/* 279 */       Collections.addAll(categories, directCategories(description));
/* 280 */       Collections.addAll(categories, directCategories(parentDescription(description)));
/* 281 */       return categories;
/*     */     }
/*     */     
/*     */     private static Description parentDescription(Description description) {
/* 285 */       Class<?> testClass = description.getTestClass();
/* 286 */       return (testClass == null) ? null : Description.createSuiteDescription(testClass);
/*     */     }
/*     */     
/*     */     private static Class<?>[] directCategories(Description description) {
/* 290 */       if (description == null) {
/* 291 */         return new Class[0];
/*     */       }
/*     */       
/* 294 */       Category annotation = (Category)description.getAnnotation(Category.class);
/* 295 */       return (annotation == null) ? new Class[0] : annotation.value();
/*     */     }
/*     */     
/*     */     private static Set<Class<?>> copyAndRefine(Set<Class<?>> classes) {
/* 299 */       Set<Class<?>> c = new LinkedHashSet<Class<?>>();
/* 300 */       if (classes != null) {
/* 301 */         c.addAll(classes);
/*     */       }
/* 303 */       c.remove(null);
/* 304 */       return c;
/*     */     }
/*     */   }
/*     */   
/*     */   public Categories(Class<?> klass, RunnerBuilder builder) throws InitializationError {
/* 309 */     super(klass, builder);
/*     */     try {
/* 311 */       Set<Class<?>> included = getIncludedCategory(klass);
/* 312 */       Set<Class<?>> excluded = getExcludedCategory(klass);
/* 313 */       boolean isAnyIncluded = isAnyIncluded(klass);
/* 314 */       boolean isAnyExcluded = isAnyExcluded(klass);
/*     */       
/* 316 */       filter(CategoryFilter.categoryFilter(isAnyIncluded, included, isAnyExcluded, excluded));
/* 317 */     } catch (NoTestsRemainException e) {
/* 318 */       throw new InitializationError(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Set<Class<?>> getIncludedCategory(Class<?> klass) {
/* 323 */     IncludeCategory annotation = klass.<IncludeCategory>getAnnotation(IncludeCategory.class);
/* 324 */     return createSet((annotation == null) ? null : annotation.value());
/*     */   }
/*     */   
/*     */   private static boolean isAnyIncluded(Class<?> klass) {
/* 328 */     IncludeCategory annotation = klass.<IncludeCategory>getAnnotation(IncludeCategory.class);
/* 329 */     return (annotation == null || annotation.matchAny());
/*     */   }
/*     */   
/*     */   private static Set<Class<?>> getExcludedCategory(Class<?> klass) {
/* 333 */     ExcludeCategory annotation = klass.<ExcludeCategory>getAnnotation(ExcludeCategory.class);
/* 334 */     return createSet((annotation == null) ? null : annotation.value());
/*     */   }
/*     */   
/*     */   private static boolean isAnyExcluded(Class<?> klass) {
/* 338 */     ExcludeCategory annotation = klass.<ExcludeCategory>getAnnotation(ExcludeCategory.class);
/* 339 */     return (annotation == null || annotation.matchAny());
/*     */   }
/*     */   
/*     */   private static boolean hasAssignableTo(Set<Class<?>> assigns, Class<?> to) {
/* 343 */     for (Class<?> from : assigns) {
/* 344 */       if (to.isAssignableFrom(from)) {
/* 345 */         return true;
/*     */       }
/*     */     } 
/* 348 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Set<Class<?>> createSet(Class<?>[] classes) {
/* 354 */     if (classes == null || classes.length == 0) {
/* 355 */       return Collections.emptySet();
/*     */     }
/* 357 */     for (Class<?> category : classes) {
/* 358 */       if (category == null) {
/* 359 */         throw new NullPointerException("has null category");
/*     */       }
/*     */     } 
/*     */     
/* 363 */     return (classes.length == 1) ? Collections.<Class<?>>singleton(classes[0]) : new LinkedHashSet<Class<?>>(Arrays.asList(classes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Set<Class<?>> nullableClassToSet(Class<?> nullableClass) {
/* 371 */     return (nullableClass == null) ? Collections.<Class<?>>emptySet() : Collections.<Class<?>>singleton(nullableClass);
/*     */   }
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   public static @interface ExcludeCategory {
/*     */     Class<?>[] value() default {};
/*     */     
/*     */     boolean matchAny() default true;
/*     */   }
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   public static @interface IncludeCategory {
/*     */     Class<?>[] value() default {};
/*     */     
/*     */     boolean matchAny() default true;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\experimental\categories\Categories.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */