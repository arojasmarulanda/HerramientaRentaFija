/*     */ package org.junit.runners.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.junit.internal.runners.ErrorReportingRunner;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.OrderWith;
/*     */ import org.junit.runner.Runner;
/*     */ import org.junit.runner.manipulation.InvalidOrderingException;
/*     */ import org.junit.runner.manipulation.Ordering;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RunnerBuilder
/*     */ {
/*  44 */   private final Set<Class<?>> parents = new HashSet<Class<?>>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Runner runnerForClass(Class<?> paramClass) throws Throwable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Runner safeRunnerForClass(Class<?> testClass) {
/*     */     try {
/*  70 */       Runner runner = runnerForClass(testClass);
/*  71 */       if (runner != null) {
/*  72 */         configureRunner(runner);
/*     */       }
/*  74 */       return runner;
/*  75 */     } catch (Throwable e) {
/*  76 */       return (Runner)new ErrorReportingRunner(testClass, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void configureRunner(Runner runner) throws InvalidOrderingException {
/*  81 */     Description description = runner.getDescription();
/*  82 */     OrderWith orderWith = (OrderWith)description.getAnnotation(OrderWith.class);
/*  83 */     if (orderWith != null) {
/*  84 */       Ordering ordering = Ordering.definedBy(orderWith.value(), description);
/*  85 */       ordering.apply(runner);
/*     */     } 
/*     */   }
/*     */   
/*     */   Class<?> addParent(Class<?> parent) throws InitializationError {
/*  90 */     if (!this.parents.add(parent)) {
/*  91 */       throw new InitializationError(String.format("class '%s' (possibly indirectly) contains itself as a SuiteClass", new Object[] { parent.getName() }));
/*     */     }
/*  93 */     return parent;
/*     */   }
/*     */   
/*     */   void removeParent(Class<?> klass) {
/*  97 */     this.parents.remove(klass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Runner> runners(Class<?> parent, Class<?>[] children) throws InitializationError {
/* 108 */     addParent(parent);
/*     */     
/*     */     try {
/* 111 */       return runners(children);
/*     */     } finally {
/* 113 */       removeParent(parent);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Runner> runners(Class<?> parent, List<Class<?>> children) throws InitializationError {
/* 119 */     return runners(parent, (Class[])children.<Class<?>[]>toArray((Class<?>[][])new Class[0]));
/*     */   }
/*     */   
/*     */   private List<Runner> runners(Class<?>[] children) {
/* 123 */     List<Runner> runners = new ArrayList<Runner>();
/* 124 */     for (Class<?> each : children) {
/* 125 */       Runner childRunner = safeRunnerForClass(each);
/* 126 */       if (childRunner != null) {
/* 127 */         runners.add(childRunner);
/*     */       }
/*     */     } 
/* 130 */     return runners;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\model\RunnerBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */