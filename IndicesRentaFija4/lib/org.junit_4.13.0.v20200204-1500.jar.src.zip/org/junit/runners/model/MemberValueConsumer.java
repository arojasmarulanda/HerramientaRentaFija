package org.junit.runners.model;

public interface MemberValueConsumer<T> {
  void accept(FrameworkMember<?> paramFrameworkMember, T paramT);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\model\MemberValueConsumer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */