/*    */ package org.junit.runners.model;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FrameworkField
/*    */   extends FrameworkMember<FrameworkField>
/*    */ {
/*    */   private final Field field;
/*    */   
/*    */   FrameworkField(Field field) {
/* 19 */     if (field == null) {
/* 20 */       throw new NullPointerException("FrameworkField cannot be created without an underlying field.");
/*    */     }
/*    */     
/* 23 */     this.field = field;
/*    */     
/* 25 */     if (isPublic()) {
/*    */       
/*    */       try {
/* 28 */         field.setAccessible(true);
/* 29 */       } catch (SecurityException e) {}
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 37 */     return getField().getName();
/*    */   }
/*    */   
/*    */   public Annotation[] getAnnotations() {
/* 41 */     return this.field.getAnnotations();
/*    */   }
/*    */   
/*    */   public <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 45 */     return this.field.getAnnotation(annotationType);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isShadowedBy(FrameworkField otherMember) {
/* 50 */     return otherMember.getName().equals(getName());
/*    */   }
/*    */ 
/*    */   
/*    */   boolean isBridgeMethod() {
/* 55 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getModifiers() {
/* 60 */     return this.field.getModifiers();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Field getField() {
/* 67 */     return this.field;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getType() {
/* 76 */     return this.field.getType();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getDeclaringClass() {
/* 81 */     return this.field.getDeclaringClass();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object get(Object target) throws IllegalArgumentException, IllegalAccessException {
/* 88 */     return this.field.get(target);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 93 */     return this.field.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\model\FrameworkField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */