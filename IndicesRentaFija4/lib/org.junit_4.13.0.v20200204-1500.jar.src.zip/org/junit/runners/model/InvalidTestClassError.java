/*    */ package org.junit.runners.model;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidTestClassError
/*    */   extends InitializationError
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final String message;
/*    */   
/*    */   public InvalidTestClassError(Class<?> offendingTestClass, List<Throwable> validationErrors) {
/* 18 */     super(validationErrors);
/* 19 */     this.message = createMessage(offendingTestClass, validationErrors);
/*    */   }
/*    */   
/*    */   private static String createMessage(Class<?> testClass, List<Throwable> validationErrors) {
/* 23 */     StringBuilder sb = new StringBuilder();
/* 24 */     sb.append(String.format("Invalid test class '%s':", new Object[] { testClass.getName() }));
/* 25 */     int i = 1;
/* 26 */     for (Throwable error : validationErrors) {
/* 27 */       sb.append("\n  " + i++ + ". " + error.getMessage());
/*    */     }
/* 29 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 37 */     return this.message;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\model\InvalidTestClassError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */