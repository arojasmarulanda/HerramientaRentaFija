/*     */ package org.junit.runners.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import org.junit.internal.runners.model.ReflectiveCallable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FrameworkMethod
/*     */   extends FrameworkMember<FrameworkMethod>
/*     */ {
/*     */   private final Method method;
/*     */   
/*     */   public FrameworkMethod(Method method) {
/*  26 */     if (method == null) {
/*  27 */       throw new NullPointerException("FrameworkMethod cannot be created without an underlying method.");
/*     */     }
/*     */     
/*  30 */     this.method = method;
/*     */     
/*  32 */     if (isPublic()) {
/*     */       
/*     */       try {
/*  35 */         method.setAccessible(true);
/*  36 */       } catch (SecurityException e) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method getMethod() {
/*  46 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invokeExplosively(final Object target, Object... params) throws Throwable {
/*  56 */     return (new ReflectiveCallable()
/*     */       {
/*     */         protected Object runReflectiveCall() throws Throwable {
/*  59 */           return FrameworkMethod.this.method.invoke(target, params);
/*     */         }
/*     */       }).run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  69 */     return this.method.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validatePublicVoidNoArg(boolean isStatic, List<Throwable> errors) {
/*  83 */     validatePublicVoid(isStatic, errors);
/*  84 */     if ((this.method.getParameterTypes()).length != 0) {
/*  85 */       errors.add(new Exception("Method " + this.method.getName() + " should have no parameters"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validatePublicVoid(boolean isStatic, List<Throwable> errors) {
/* 100 */     if (isStatic() != isStatic) {
/* 101 */       String state = isStatic ? "should" : "should not";
/* 102 */       errors.add(new Exception("Method " + this.method.getName() + "() " + state + " be static"));
/*     */     } 
/* 104 */     if (!isPublic()) {
/* 105 */       errors.add(new Exception("Method " + this.method.getName() + "() should be public"));
/*     */     }
/* 107 */     if (this.method.getReturnType() != void.class) {
/* 108 */       errors.add(new Exception("Method " + this.method.getName() + "() should be void"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getModifiers() {
/* 114 */     return this.method.getModifiers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getReturnType() {
/* 121 */     return this.method.getReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType() {
/* 129 */     return getReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getDeclaringClass() {
/* 137 */     return this.method.getDeclaringClass();
/*     */   }
/*     */   
/*     */   public void validateNoTypeParametersOnArgs(List<Throwable> errors) {
/* 141 */     (new NoGenericTypeParametersValidator(this.method)).validate(errors);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isShadowedBy(FrameworkMethod other) {
/* 146 */     if (!other.getName().equals(getName())) {
/* 147 */       return false;
/*     */     }
/* 149 */     if ((other.getParameterTypes()).length != (getParameterTypes()).length) {
/* 150 */       return false;
/*     */     }
/* 152 */     for (int i = 0; i < (other.getParameterTypes()).length; i++) {
/* 153 */       if (!other.getParameterTypes()[i].equals(getParameterTypes()[i])) {
/* 154 */         return false;
/*     */       }
/*     */     } 
/* 157 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isBridgeMethod() {
/* 162 */     return this.method.isBridge();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 167 */     if (!FrameworkMethod.class.isInstance(obj)) {
/* 168 */       return false;
/*     */     }
/* 170 */     return ((FrameworkMethod)obj).method.equals(this.method);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 175 */     return this.method.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean producesType(Type type) {
/* 189 */     return ((getParameterTypes()).length == 0 && type instanceof Class && ((Class)type).isAssignableFrom(this.method.getReturnType()));
/*     */   }
/*     */ 
/*     */   
/*     */   private Class<?>[] getParameterTypes() {
/* 194 */     return this.method.getParameterTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[] getAnnotations() {
/* 201 */     return this.method.getAnnotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 209 */     return this.method.getAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 214 */     return this.method.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\model\FrameworkMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */