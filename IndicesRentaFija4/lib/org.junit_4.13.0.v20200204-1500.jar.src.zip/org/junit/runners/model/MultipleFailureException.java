/*     */ package org.junit.runners.model;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.junit.TestCouldNotBeSkippedException;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.internal.Throwables;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipleFailureException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final List<Throwable> fErrors;
/*     */   
/*     */   public MultipleFailureException(List<Throwable> errors) {
/*  29 */     if (errors.isEmpty()) {
/*  30 */       throw new IllegalArgumentException("List of Throwables must not be empty");
/*     */     }
/*     */     
/*  33 */     this.fErrors = new ArrayList<Throwable>(errors.size());
/*  34 */     for (Throwable error : errors) {
/*  35 */       TestCouldNotBeSkippedException testCouldNotBeSkippedException; if (error instanceof AssumptionViolatedException) {
/*  36 */         testCouldNotBeSkippedException = new TestCouldNotBeSkippedException((AssumptionViolatedException)error);
/*     */       }
/*  38 */       this.fErrors.add(testCouldNotBeSkippedException);
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<Throwable> getFailures() {
/*  43 */     return Collections.unmodifiableList(this.fErrors);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage() {
/*  48 */     StringBuilder sb = new StringBuilder(String.format("There were %d errors:", new Object[] { Integer.valueOf(this.fErrors.size()) }));
/*     */     
/*  50 */     for (Throwable e : this.fErrors) {
/*  51 */       sb.append(String.format("%n  %s(%s)", new Object[] { e.getClass().getName(), e.getMessage() }));
/*     */     } 
/*  53 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void printStackTrace() {
/*  58 */     for (Throwable e : this.fErrors) {
/*  59 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream s) {
/*  65 */     for (Throwable e : this.fErrors) {
/*  66 */       e.printStackTrace(s);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter s) {
/*  72 */     for (Throwable e : this.fErrors) {
/*  73 */       e.printStackTrace(s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEmpty(List<Throwable> errors) throws Exception {
/*  88 */     if (errors.isEmpty()) {
/*     */       return;
/*     */     }
/*  91 */     if (errors.size() == 1) {
/*  92 */       throw Throwables.rethrowAsException((Throwable)errors.get(0));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     throw new org.junit.internal.runners.model.MultipleFailureException(errors);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\model\MultipleFailureException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */