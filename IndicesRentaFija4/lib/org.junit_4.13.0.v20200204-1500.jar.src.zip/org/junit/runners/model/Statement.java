package org.junit.runners.model;

public abstract class Statement {
  public abstract void evaluate() throws Throwable;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\model\Statement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */