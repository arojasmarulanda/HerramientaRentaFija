/*    */ package org.junit.runners.model;
/*    */ 
/*    */ import java.lang.reflect.Modifier;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FrameworkMember<T extends FrameworkMember<T>>
/*    */   implements Annotatable
/*    */ {
/*    */   abstract boolean isShadowedBy(T paramT);
/*    */   
/*    */   T handlePossibleBridgeMethod(List<T> members) {
/* 16 */     for (int i = members.size() - 1; i >= 0; i--) {
/* 17 */       FrameworkMember frameworkMember = (FrameworkMember)members.get(i);
/* 18 */       if (isShadowedBy((T)frameworkMember)) {
/* 19 */         if (frameworkMember.isBridgeMethod()) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */           
/* 25 */           members.remove(i);
/* 26 */           return (T)frameworkMember;
/*    */         } 
/*    */         
/* 29 */         return null;
/*    */       } 
/*    */     } 
/*    */     
/* 33 */     return (T)this;
/*    */   }
/*    */ 
/*    */   
/*    */   abstract boolean isBridgeMethod();
/*    */ 
/*    */   
/*    */   protected abstract int getModifiers();
/*    */ 
/*    */   
/*    */   public boolean isStatic() {
/* 44 */     return Modifier.isStatic(getModifiers());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPublic() {
/* 51 */     return Modifier.isPublic(getModifiers());
/*    */   }
/*    */   
/*    */   public abstract String getName();
/*    */   
/*    */   public abstract Class<?> getType();
/*    */   
/*    */   public abstract Class<?> getDeclaringClass();
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\model\FrameworkMember.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */