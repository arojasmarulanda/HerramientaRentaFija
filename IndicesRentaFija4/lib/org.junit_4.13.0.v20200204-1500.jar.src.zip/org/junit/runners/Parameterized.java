/*     */ package org.junit.runners;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.annotation.Inherited;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.Runner;
/*     */ import org.junit.runner.notification.Failure;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InvalidTestClassError;
/*     */ import org.junit.runners.model.TestClass;
/*     */ import org.junit.runners.parameterized.BlockJUnit4ClassRunnerWithParametersFactory;
/*     */ import org.junit.runners.parameterized.ParametersRunnerFactory;
/*     */ import org.junit.runners.parameterized.TestWithParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parameterized
/*     */   extends Suite
/*     */ {
/*     */   public Parameterized(Class<?> klass) throws Throwable {
/* 303 */     this(klass, new RunnersFactory(klass, null));
/*     */   }
/*     */   
/*     */   private Parameterized(Class<?> klass, RunnersFactory runnersFactory) throws Exception {
/* 307 */     super(klass, runnersFactory.createRunners());
/* 308 */     validateBeforeParamAndAfterParamMethods(Integer.valueOf(runnersFactory.parameterCount));
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateBeforeParamAndAfterParamMethods(Integer parameterCount) throws InvalidTestClassError {
/* 313 */     List<Throwable> errors = new ArrayList<Throwable>();
/* 314 */     validatePublicStaticVoidMethods((Class)BeforeParam.class, parameterCount, errors);
/* 315 */     validatePublicStaticVoidMethods((Class)AfterParam.class, parameterCount, errors);
/* 316 */     if (!errors.isEmpty()) {
/* 317 */       throw new InvalidTestClassError(getTestClass().getJavaClass(), errors);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void validatePublicStaticVoidMethods(Class<? extends Annotation> annotation, Integer parameterCount, List<Throwable> errors) {
/* 324 */     List<FrameworkMethod> methods = getTestClass().getAnnotatedMethods(annotation);
/* 325 */     for (FrameworkMethod fm : methods) {
/* 326 */       fm.validatePublicVoid(true, errors);
/* 327 */       if (parameterCount != null) {
/* 328 */         int methodParameterCount = (fm.getMethod().getParameterTypes()).length;
/* 329 */         if (methodParameterCount != 0 && methodParameterCount != parameterCount.intValue())
/* 330 */           errors.add(new Exception("Method " + fm.getName() + "() should have 0 or " + parameterCount + " parameter(s)")); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   @Target({ElementType.METHOD})
/*     */   public static @interface AfterParam {}
/*     */   
/*     */   private static class AssumptionViolationRunner extends Runner { private final Description description;
/*     */     private final AssumptionViolatedException exception;
/*     */     
/*     */     AssumptionViolationRunner(TestClass testClass, String methodName, AssumptionViolatedException exception) {
/* 343 */       this.description = Description.createTestDescription(testClass.getJavaClass(), methodName + "() assumption violation");
/*     */ 
/*     */       
/* 346 */       this.exception = exception;
/*     */     }
/*     */ 
/*     */     
/*     */     public Description getDescription() {
/* 351 */       return this.description;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run(RunNotifier notifier) {
/* 356 */       notifier.fireTestAssumptionFailed(new Failure(this.description, (Throwable)this.exception)); } } @Retention(RetentionPolicy.RUNTIME) @Target({ElementType.METHOD}) public static @interface BeforeParam {} @Retention(RetentionPolicy.RUNTIME) @Target({ElementType.FIELD})
/*     */   public static @interface Parameter {
/*     */     int value() default 0;
/*     */   } @Retention(RetentionPolicy.RUNTIME)
/*     */   @Target({ElementType.METHOD})
/* 361 */   public static @interface Parameters { String name() default "{index}"; } private static class RunnersFactory { private static final ParametersRunnerFactory DEFAULT_FACTORY = (ParametersRunnerFactory)new BlockJUnit4ClassRunnerWithParametersFactory();
/*     */     private final TestClass testClass;
/*     */     private final FrameworkMethod parametersMethod;
/*     */     private final List<Object> allParameters;
/*     */     private final int parameterCount;
/*     */     private final Runner runnerOverride;
/*     */     
/*     */     private RunnersFactory(Class<?> klass) throws Throwable {
/*     */       List<?> list;
/* 370 */       this.testClass = new TestClass(klass);
/* 371 */       this.parametersMethod = getParametersMethod(this.testClass);
/*     */       
/* 373 */       Parameterized.AssumptionViolationRunner assumptionViolationRunner = null;
/*     */       try {
/* 375 */         list = allParameters(this.testClass, this.parametersMethod);
/* 376 */       } catch (AssumptionViolatedException e) {
/* 377 */         list = Collections.emptyList();
/* 378 */         assumptionViolationRunner = new Parameterized.AssumptionViolationRunner(this.testClass, this.parametersMethod.getName(), e);
/*     */       } 
/*     */       
/* 381 */       this.allParameters = (List)list;
/* 382 */       this.runnerOverride = assumptionViolationRunner;
/* 383 */       this.parameterCount = this.allParameters.isEmpty() ? 0 : (normalizeParameters(this.allParameters.get(0))).length;
/*     */     }
/*     */ 
/*     */     
/*     */     private List<Runner> createRunners() throws Exception {
/* 388 */       if (this.runnerOverride != null) {
/* 389 */         return Collections.singletonList(this.runnerOverride);
/*     */       }
/* 391 */       Parameterized.Parameters parameters = (Parameterized.Parameters)this.parametersMethod.getAnnotation(Parameterized.Parameters.class);
/* 392 */       return Collections.unmodifiableList(createRunnersForParameters(this.allParameters, parameters.name(), getParametersRunnerFactory()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ParametersRunnerFactory getParametersRunnerFactory() throws InstantiationException, IllegalAccessException {
/* 399 */       Parameterized.UseParametersRunnerFactory annotation = (Parameterized.UseParametersRunnerFactory)this.testClass.getAnnotation(Parameterized.UseParametersRunnerFactory.class);
/*     */       
/* 401 */       if (annotation == null) {
/* 402 */         return DEFAULT_FACTORY;
/*     */       }
/* 404 */       Class<? extends ParametersRunnerFactory> factoryClass = annotation.value();
/*     */       
/* 406 */       return factoryClass.newInstance();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private TestWithParameters createTestWithNotNormalizedParameters(String pattern, int index, Object parametersOrSingleParameter) {
/* 412 */       Object[] parameters = normalizeParameters(parametersOrSingleParameter);
/* 413 */       return createTestWithParameters(this.testClass, pattern, index, parameters);
/*     */     }
/*     */     
/*     */     private static Object[] normalizeParameters(Object parametersOrSingleParameter) {
/* 417 */       (new Object[1])[0] = parametersOrSingleParameter; return (parametersOrSingleParameter instanceof Object[]) ? (Object[])parametersOrSingleParameter : new Object[1];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static List<Object> allParameters(TestClass testClass, FrameworkMethod parametersMethod) throws Throwable {
/* 424 */       Object parameters = parametersMethod.invokeExplosively(null, new Object[0]);
/* 425 */       if (parameters instanceof List)
/* 426 */         return (List<Object>)parameters; 
/* 427 */       if (parameters instanceof Collection)
/* 428 */         return new ArrayList((Collection)parameters); 
/* 429 */       if (parameters instanceof Iterable) {
/* 430 */         List<Object> result = new ArrayList();
/* 431 */         for (Object entry : parameters) {
/* 432 */           result.add(entry);
/*     */         }
/* 434 */         return result;
/* 435 */       }  if (parameters instanceof Object[]) {
/* 436 */         return Arrays.asList((Object[])parameters);
/*     */       }
/* 438 */       throw parametersMethodReturnedWrongType(testClass, parametersMethod);
/*     */     }
/*     */ 
/*     */     
/*     */     private static FrameworkMethod getParametersMethod(TestClass testClass) throws Exception {
/* 443 */       List<FrameworkMethod> methods = testClass.getAnnotatedMethods(Parameterized.Parameters.class);
/*     */       
/* 445 */       for (FrameworkMethod each : methods) {
/* 446 */         if (each.isStatic() && each.isPublic()) {
/* 447 */           return each;
/*     */         }
/*     */       } 
/*     */       
/* 451 */       throw new Exception("No public static parameters method on class " + testClass.getName());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private List<Runner> createRunnersForParameters(Iterable<Object> allParameters, String namePattern, ParametersRunnerFactory runnerFactory) throws Exception {
/*     */       try {
/* 459 */         List<TestWithParameters> tests = createTestsForParameters(allParameters, namePattern);
/*     */         
/* 461 */         List<Runner> runners = new ArrayList<Runner>();
/* 462 */         for (TestWithParameters test : tests) {
/* 463 */           runners.add(runnerFactory.createRunnerForTestWithParameters(test));
/*     */         }
/*     */         
/* 466 */         return runners;
/* 467 */       } catch (ClassCastException e) {
/* 468 */         throw parametersMethodReturnedWrongType(this.testClass, this.parametersMethod);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private List<TestWithParameters> createTestsForParameters(Iterable<Object> allParameters, String namePattern) throws Exception {
/* 475 */       int i = 0;
/* 476 */       List<TestWithParameters> children = new ArrayList<TestWithParameters>();
/* 477 */       for (Object parametersOfSingleTest : allParameters) {
/* 478 */         children.add(createTestWithNotNormalizedParameters(namePattern, i++, parametersOfSingleTest));
/*     */       }
/*     */       
/* 481 */       return children;
/*     */     }
/*     */ 
/*     */     
/*     */     private static Exception parametersMethodReturnedWrongType(TestClass testClass, FrameworkMethod parametersMethod) throws Exception {
/* 486 */       String className = testClass.getName();
/* 487 */       String methodName = parametersMethod.getName();
/* 488 */       String message = MessageFormat.format("{0}.{1}() must return an Iterable of arrays.", new Object[] { className, methodName });
/*     */ 
/*     */       
/* 491 */       return new Exception(message);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private TestWithParameters createTestWithParameters(TestClass testClass, String pattern, int index, Object[] parameters) {
/* 497 */       String finalPattern = pattern.replaceAll("\\{index\\}", Integer.toString(index));
/*     */       
/* 499 */       String name = MessageFormat.format(finalPattern, parameters);
/* 500 */       return new TestWithParameters("[" + name + "]", testClass, Arrays.asList(parameters));
/*     */     } }
/*     */ 
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   @Inherited
/*     */   @Target({ElementType.TYPE})
/*     */   public static @interface UseParametersRunnerFactory {
/*     */     Class<? extends ParametersRunnerFactory> value() default BlockJUnit4ClassRunnerWithParametersFactory.class;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\Parameterized.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */