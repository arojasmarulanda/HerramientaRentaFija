/*    */ package org.junit.runners.parameterized;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.junit.internal.Checks;
/*    */ import org.junit.runners.model.TestClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestWithParameters
/*    */ {
/*    */   private final String name;
/*    */   private final TestClass testClass;
/*    */   private final List<Object> parameters;
/*    */   
/*    */   public TestWithParameters(String name, TestClass testClass, List<Object> parameters) {
/* 27 */     Checks.notNull(name, "The name is missing.");
/* 28 */     Checks.notNull(testClass, "The test class is missing.");
/* 29 */     Checks.notNull(parameters, "The parameters are missing.");
/* 30 */     this.name = name;
/* 31 */     this.testClass = testClass;
/* 32 */     this.parameters = Collections.unmodifiableList(new ArrayList(parameters));
/*    */   }
/*    */   
/*    */   public String getName() {
/* 36 */     return this.name;
/*    */   }
/*    */   
/*    */   public TestClass getTestClass() {
/* 40 */     return this.testClass;
/*    */   }
/*    */   
/*    */   public List<Object> getParameters() {
/* 44 */     return this.parameters;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 49 */     int prime = 14747;
/* 50 */     int result = prime + this.name.hashCode();
/* 51 */     result = prime * result + this.testClass.hashCode();
/* 52 */     return prime * result + this.parameters.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 57 */     if (this == obj) {
/* 58 */       return true;
/*    */     }
/* 60 */     if (obj == null) {
/* 61 */       return false;
/*    */     }
/* 63 */     if (getClass() != obj.getClass()) {
/* 64 */       return false;
/*    */     }
/* 66 */     TestWithParameters other = (TestWithParameters)obj;
/* 67 */     return (this.name.equals(other.name) && this.parameters.equals(other.parameters) && this.testClass.equals(other.testClass));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     return this.testClass.getName() + " '" + this.name + "' with parameters " + this.parameters;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\parameterized\TestWithParameters.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */