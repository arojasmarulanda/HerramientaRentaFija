/*     */ package org.junit.runners.parameterized;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.List;
/*     */ import org.junit.internal.runners.statements.RunAfters;
/*     */ import org.junit.internal.runners.statements.RunBefores;
/*     */ import org.junit.runner.RunWith;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ import org.junit.runners.BlockJUnit4ClassRunner;
/*     */ import org.junit.runners.Parameterized;
/*     */ import org.junit.runners.model.FrameworkField;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.Statement;
/*     */ 
/*     */ 
/*     */ public class BlockJUnit4ClassRunnerWithParameters
/*     */   extends BlockJUnit4ClassRunner
/*     */ {
/*     */   private final Object[] parameters;
/*     */   private final String name;
/*     */   
/*     */   private enum InjectionType
/*     */   {
/*  26 */     CONSTRUCTOR, FIELD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockJUnit4ClassRunnerWithParameters(TestWithParameters test) throws InitializationError {
/*  35 */     super(test.getTestClass());
/*  36 */     this.parameters = test.getParameters().toArray(new Object[test.getParameters().size()]);
/*     */     
/*  38 */     this.name = test.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object createTest() throws Exception {
/*  43 */     InjectionType injectionType = getInjectionType();
/*  44 */     switch (injectionType) {
/*     */       case CONSTRUCTOR:
/*  46 */         return createTestUsingConstructorInjection();
/*     */       case FIELD:
/*  48 */         return createTestUsingFieldInjection();
/*     */     } 
/*  50 */     throw new IllegalStateException("The injection type " + injectionType + " is not supported.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object createTestUsingConstructorInjection() throws Exception {
/*  56 */     return getTestClass().getOnlyConstructor().newInstance(this.parameters);
/*     */   }
/*     */   
/*     */   private Object createTestUsingFieldInjection() throws Exception {
/*  60 */     List<FrameworkField> annotatedFieldsByParameter = getAnnotatedFieldsByParameter();
/*  61 */     if (annotatedFieldsByParameter.size() != this.parameters.length) {
/*  62 */       throw new Exception("Wrong number of parameters and @Parameter fields. @Parameter fields counted: " + annotatedFieldsByParameter.size() + ", available parameters: " + this.parameters.length + ".");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     Object testClassInstance = getTestClass().getJavaClass().newInstance();
/*  70 */     for (FrameworkField each : annotatedFieldsByParameter) {
/*  71 */       Field field = each.getField();
/*  72 */       Parameterized.Parameter annotation = field.<Parameterized.Parameter>getAnnotation(Parameterized.Parameter.class);
/*  73 */       int index = annotation.value();
/*     */       try {
/*  75 */         field.set(testClassInstance, this.parameters[index]);
/*  76 */       } catch (IllegalAccessException e) {
/*  77 */         IllegalAccessException wrappedException = new IllegalAccessException("Cannot set parameter '" + field.getName() + "'. Ensure that the field '" + field.getName() + "' is public.");
/*     */ 
/*     */ 
/*     */         
/*  81 */         wrappedException.initCause(e);
/*  82 */         throw wrappedException;
/*  83 */       } catch (IllegalArgumentException iare) {
/*  84 */         throw new Exception(getTestClass().getName() + ": Trying to set " + field.getName() + " with the value " + this.parameters[index] + " that is not the right type (" + this.parameters[index].getClass().getSimpleName() + " instead of " + field.getType().getSimpleName() + ").", iare);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     return testClassInstance;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getName() {
/*  98 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String testName(FrameworkMethod method) {
/* 103 */     return method.getName() + getName();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validateConstructor(List<Throwable> errors) {
/* 108 */     validateOnlyOneConstructor(errors);
/* 109 */     if (getInjectionType() != InjectionType.CONSTRUCTOR) {
/* 110 */       validateZeroArgConstructor(errors);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void validateFields(List<Throwable> errors) {
/* 116 */     super.validateFields(errors);
/* 117 */     if (getInjectionType() == InjectionType.FIELD) {
/* 118 */       List<FrameworkField> annotatedFieldsByParameter = getAnnotatedFieldsByParameter();
/* 119 */       int[] usedIndices = new int[annotatedFieldsByParameter.size()];
/* 120 */       for (FrameworkField each : annotatedFieldsByParameter) {
/* 121 */         int i = ((Parameterized.Parameter)each.getField().<Parameterized.Parameter>getAnnotation(Parameterized.Parameter.class)).value();
/*     */         
/* 123 */         if (i < 0 || i > annotatedFieldsByParameter.size() - 1) {
/* 124 */           errors.add(new Exception("Invalid @Parameter value: " + i + ". @Parameter fields counted: " + annotatedFieldsByParameter.size() + ". Please use an index between 0 and " + (annotatedFieldsByParameter.size() - 1) + "."));
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 130 */         usedIndices[i] = usedIndices[i] + 1;
/*     */       } 
/*     */       
/* 133 */       for (int index = 0; index < usedIndices.length; index++) {
/* 134 */         int numberOfUse = usedIndices[index];
/* 135 */         if (numberOfUse == 0) {
/* 136 */           errors.add(new Exception("@Parameter(" + index + ") is never used."));
/*     */         }
/* 138 */         else if (numberOfUse > 1) {
/* 139 */           errors.add(new Exception("@Parameter(" + index + ") is used more than once (" + numberOfUse + ")."));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Statement classBlock(RunNotifier notifier) {
/* 148 */     Statement statement = childrenInvoker(notifier);
/* 149 */     statement = withBeforeParams(statement);
/* 150 */     statement = withAfterParams(statement);
/* 151 */     return statement;
/*     */   }
/*     */   
/*     */   private Statement withBeforeParams(Statement statement) {
/* 155 */     List<FrameworkMethod> befores = getTestClass().getAnnotatedMethods(Parameterized.BeforeParam.class);
/*     */     
/* 157 */     return befores.isEmpty() ? statement : (Statement)new RunBeforeParams(statement, befores);
/*     */   }
/*     */   
/*     */   private class RunBeforeParams extends RunBefores {
/*     */     RunBeforeParams(Statement next, List<FrameworkMethod> befores) {
/* 162 */       super(next, befores, null);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void invokeMethod(FrameworkMethod method) throws Throwable {
/* 167 */       int paramCount = (method.getMethod().getParameterTypes()).length;
/* 168 */       method.invokeExplosively(null, (paramCount == 0) ? (Object[])null : BlockJUnit4ClassRunnerWithParameters.this.parameters);
/*     */     }
/*     */   }
/*     */   
/*     */   private Statement withAfterParams(Statement statement) {
/* 173 */     List<FrameworkMethod> afters = getTestClass().getAnnotatedMethods(Parameterized.AfterParam.class);
/*     */     
/* 175 */     return afters.isEmpty() ? statement : (Statement)new RunAfterParams(statement, afters);
/*     */   }
/*     */   
/*     */   private class RunAfterParams extends RunAfters {
/*     */     RunAfterParams(Statement next, List<FrameworkMethod> afters) {
/* 180 */       super(next, afters, null);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void invokeMethod(FrameworkMethod method) throws Throwable {
/* 185 */       int paramCount = (method.getMethod().getParameterTypes()).length;
/* 186 */       method.invokeExplosively(null, (paramCount == 0) ? (Object[])null : BlockJUnit4ClassRunnerWithParameters.this.parameters);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Annotation[] getRunnerAnnotations() {
/* 192 */     Annotation[] allAnnotations = super.getRunnerAnnotations();
/* 193 */     Annotation[] annotationsWithoutRunWith = new Annotation[allAnnotations.length - 1];
/* 194 */     int i = 0;
/* 195 */     for (Annotation annotation : allAnnotations) {
/* 196 */       if (!annotation.annotationType().equals(RunWith.class)) {
/* 197 */         annotationsWithoutRunWith[i] = annotation;
/* 198 */         i++;
/*     */       } 
/*     */     } 
/* 201 */     return annotationsWithoutRunWith;
/*     */   }
/*     */   
/*     */   private List<FrameworkField> getAnnotatedFieldsByParameter() {
/* 205 */     return getTestClass().getAnnotatedFields(Parameterized.Parameter.class);
/*     */   }
/*     */   
/*     */   private InjectionType getInjectionType() {
/* 209 */     if (fieldsAreAnnotated()) {
/* 210 */       return InjectionType.FIELD;
/*     */     }
/* 212 */     return InjectionType.CONSTRUCTOR;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean fieldsAreAnnotated() {
/* 217 */     return !getAnnotatedFieldsByParameter().isEmpty();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\parameterized\BlockJUnit4ClassRunnerWithParameters.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */