/*     */ package org.junit.runners;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import org.junit.rules.MethodRule;
/*     */ import org.junit.rules.TestRule;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RuleContainer
/*     */ {
/*  22 */   private final IdentityHashMap<Object, Integer> orderValues = new IdentityHashMap<Object, Integer>();
/*  23 */   private final List<TestRule> testRules = new ArrayList<TestRule>();
/*  24 */   private final List<MethodRule> methodRules = new ArrayList<MethodRule>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrder(Object rule, int order) {
/*  30 */     this.orderValues.put(rule, Integer.valueOf(order));
/*     */   }
/*     */   
/*     */   public void add(MethodRule methodRule) {
/*  34 */     this.methodRules.add(methodRule);
/*     */   }
/*     */   
/*     */   public void add(TestRule testRule) {
/*  38 */     this.testRules.add(testRule);
/*     */   }
/*     */   
/*  41 */   static final Comparator<RuleEntry> ENTRY_COMPARATOR = new Comparator<RuleEntry>() {
/*     */       public int compare(RuleContainer.RuleEntry o1, RuleContainer.RuleEntry o2) {
/*  43 */         int result = compareInt(o1.order, o2.order);
/*  44 */         return (result != 0) ? result : (o1.type - o2.type);
/*     */       }
/*     */       
/*     */       private int compareInt(int a, int b) {
/*  48 */         return (a < b) ? 1 : ((a == b) ? 0 : -1);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<RuleEntry> getSortedEntries() {
/*  56 */     List<RuleEntry> ruleEntries = new ArrayList<RuleEntry>(this.methodRules.size() + this.testRules.size());
/*     */     
/*  58 */     for (MethodRule rule : this.methodRules) {
/*  59 */       ruleEntries.add(new RuleEntry(rule, 0, this.orderValues.get(rule)));
/*     */     }
/*  61 */     for (TestRule rule : this.testRules) {
/*  62 */       ruleEntries.add(new RuleEntry(rule, 1, this.orderValues.get(rule)));
/*     */     }
/*  64 */     Collections.sort(ruleEntries, ENTRY_COMPARATOR);
/*  65 */     return ruleEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement apply(FrameworkMethod method, Description description, Object target, Statement statement) {
/*  73 */     if (this.methodRules.isEmpty() && this.testRules.isEmpty()) {
/*  74 */       return statement;
/*     */     }
/*  76 */     Statement result = statement;
/*  77 */     for (RuleEntry ruleEntry : getSortedEntries()) {
/*  78 */       if (ruleEntry.type == 1) {
/*  79 */         result = ((TestRule)ruleEntry.rule).apply(result, description); continue;
/*     */       } 
/*  81 */       result = ((MethodRule)ruleEntry.rule).apply(result, method, target);
/*     */     } 
/*     */     
/*  84 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<Object> getSortedRules() {
/*  92 */     List<Object> result = new ArrayList();
/*  93 */     for (RuleEntry entry : getSortedEntries()) {
/*  94 */       result.add(entry.rule);
/*     */     }
/*  96 */     return result;
/*     */   }
/*     */   
/*     */   static class RuleEntry
/*     */   {
/*     */     static final int TYPE_TEST_RULE = 1;
/*     */     static final int TYPE_METHOD_RULE = 0;
/*     */     final Object rule;
/*     */     final int type;
/*     */     final int order;
/*     */     
/*     */     RuleEntry(Object rule, int type, Integer order) {
/* 108 */       this.rule = rule;
/* 109 */       this.type = type;
/* 110 */       this.order = (order != null) ? order.intValue() : -1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\RuleContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */