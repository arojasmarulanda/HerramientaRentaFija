/*     */ package org.junit.runners;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.junit.AfterClass;
/*     */ import org.junit.BeforeClass;
/*     */ import org.junit.ClassRule;
/*     */ import org.junit.FixMethodOrder;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.internal.Checks;
/*     */ import org.junit.internal.runners.model.EachTestNotifier;
/*     */ import org.junit.internal.runners.rules.RuleMemberValidator;
/*     */ import org.junit.internal.runners.statements.RunAfters;
/*     */ import org.junit.internal.runners.statements.RunBefores;
/*     */ import org.junit.rules.RunRules;
/*     */ import org.junit.rules.TestRule;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.Runner;
/*     */ import org.junit.runner.manipulation.Filter;
/*     */ import org.junit.runner.manipulation.Filterable;
/*     */ import org.junit.runner.manipulation.InvalidOrderingException;
/*     */ import org.junit.runner.manipulation.NoTestsRemainException;
/*     */ import org.junit.runner.manipulation.Orderable;
/*     */ import org.junit.runner.manipulation.Orderer;
/*     */ import org.junit.runner.manipulation.Sorter;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ import org.junit.runner.notification.StoppedByUserException;
/*     */ import org.junit.runners.model.FrameworkMember;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.InvalidTestClassError;
/*     */ import org.junit.runners.model.MemberValueConsumer;
/*     */ import org.junit.runners.model.RunnerScheduler;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ import org.junit.validator.AnnotationsValidator;
/*     */ import org.junit.validator.TestClassValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParentRunner<T>
/*     */   extends Runner
/*     */   implements Filterable, Orderable
/*     */ {
/*  68 */   private static final List<TestClassValidator> VALIDATORS = (List)Collections.singletonList(new AnnotationsValidator());
/*     */ 
/*     */   
/*  71 */   private final Lock childrenLock = new ReentrantLock();
/*     */   
/*     */   private final TestClass testClass;
/*     */   
/*  75 */   private volatile List<T> filteredChildren = null;
/*     */   
/*  77 */   private volatile RunnerScheduler scheduler = new RunnerScheduler() {
/*     */       public void schedule(Runnable childStatement) {
/*  79 */         childStatement.run();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void finished() {}
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParentRunner(Class<?> testClass) throws InitializationError {
/*  91 */     this.testClass = createTestClass(testClass);
/*  92 */     validate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParentRunner(TestClass testClass) throws InitializationError {
/* 101 */     this.testClass = (TestClass)Checks.notNull(testClass);
/* 102 */     validate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected TestClass createTestClass(Class<?> testClass) {
/* 111 */     return new TestClass(testClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void collectInitializationErrors(List<Throwable> errors) {
/* 148 */     validatePublicVoidNoArgMethods((Class)BeforeClass.class, true, errors);
/* 149 */     validatePublicVoidNoArgMethods((Class)AfterClass.class, true, errors);
/* 150 */     validateClassRules(errors);
/* 151 */     applyValidators(errors);
/*     */   }
/*     */   
/*     */   private void applyValidators(List<Throwable> errors) {
/* 155 */     if (getTestClass().getJavaClass() != null) {
/* 156 */       for (TestClassValidator each : VALIDATORS) {
/* 157 */         errors.addAll(each.validateTestClass(getTestClass()));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validatePublicVoidNoArgMethods(Class<? extends Annotation> annotation, boolean isStatic, List<Throwable> errors) {
/* 175 */     List<FrameworkMethod> methods = getTestClass().getAnnotatedMethods(annotation);
/*     */     
/* 177 */     for (FrameworkMethod eachTestMethod : methods) {
/* 178 */       eachTestMethod.validatePublicVoidNoArg(isStatic, errors);
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateClassRules(List<Throwable> errors) {
/* 183 */     RuleMemberValidator.CLASS_RULE_VALIDATOR.validate(getTestClass(), errors);
/* 184 */     RuleMemberValidator.CLASS_RULE_METHOD_VALIDATOR.validate(getTestClass(), errors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Statement classBlock(RunNotifier notifier) {
/* 213 */     Statement statement = childrenInvoker(notifier);
/* 214 */     if (!areAllChildrenIgnored()) {
/* 215 */       statement = withBeforeClasses(statement);
/* 216 */       statement = withAfterClasses(statement);
/* 217 */       statement = withClassRules(statement);
/* 218 */       statement = withInterruptIsolation(statement);
/*     */     } 
/* 220 */     return statement;
/*     */   }
/*     */   
/*     */   private boolean areAllChildrenIgnored() {
/* 224 */     for (T child : getFilteredChildren()) {
/* 225 */       if (!isIgnored(child)) {
/* 226 */         return false;
/*     */       }
/*     */     } 
/* 229 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Statement withBeforeClasses(Statement statement) {
/* 238 */     List<FrameworkMethod> befores = this.testClass.getAnnotatedMethods(BeforeClass.class);
/*     */     
/* 240 */     return befores.isEmpty() ? statement : (Statement)new RunBefores(statement, befores, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Statement withAfterClasses(Statement statement) {
/* 252 */     List<FrameworkMethod> afters = this.testClass.getAnnotatedMethods(AfterClass.class);
/*     */     
/* 254 */     return afters.isEmpty() ? statement : (Statement)new RunAfters(statement, afters, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Statement withClassRules(Statement statement) {
/* 268 */     List<TestRule> classRules = classRules();
/* 269 */     return classRules.isEmpty() ? statement : (Statement)new RunRules(statement, classRules, getDescription());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<TestRule> classRules() {
/* 278 */     ClassRuleCollector collector = new ClassRuleCollector();
/* 279 */     this.testClass.collectAnnotatedMethodValues(null, ClassRule.class, TestRule.class, collector);
/* 280 */     this.testClass.collectAnnotatedFieldValues(null, ClassRule.class, TestRule.class, collector);
/* 281 */     return collector.getOrderedRules();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Statement childrenInvoker(final RunNotifier notifier) {
/* 290 */     return new Statement()
/*     */       {
/*     */         public void evaluate() {
/* 293 */           ParentRunner.this.runChildren(notifier);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Statement withInterruptIsolation(final Statement statement) {
/* 302 */     return new Statement()
/*     */       {
/*     */         public void evaluate() throws Throwable {
/*     */           try {
/* 306 */             statement.evaluate();
/*     */           } finally {
/* 308 */             Thread.interrupted();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isIgnored(T child) {
/* 322 */     return false;
/*     */   }
/*     */   
/*     */   private void runChildren(final RunNotifier notifier) {
/* 326 */     RunnerScheduler currentScheduler = this.scheduler;
/*     */     try {
/* 328 */       for (T each : getFilteredChildren()) {
/* 329 */         currentScheduler.schedule(new Runnable() {
/*     */               public void run() {
/* 331 */                 ParentRunner.this.runChild(each, notifier);
/*     */               }
/*     */             });
/*     */       } 
/*     */     } finally {
/* 336 */       currentScheduler.finished();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getName() {
/* 344 */     return this.testClass.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TestClass getTestClass() {
/* 355 */     return this.testClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void runLeaf(Statement statement, Description description, RunNotifier notifier) {
/* 363 */     EachTestNotifier eachNotifier = new EachTestNotifier(notifier, description);
/* 364 */     eachNotifier.fireTestStarted();
/*     */     try {
/* 366 */       statement.evaluate();
/* 367 */     } catch (AssumptionViolatedException e) {
/* 368 */       eachNotifier.addFailedAssumption(e);
/* 369 */     } catch (Throwable e) {
/* 370 */       eachNotifier.addFailure(e);
/*     */     } finally {
/* 372 */       eachNotifier.fireTestFinished();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Annotation[] getRunnerAnnotations() {
/* 381 */     return this.testClass.getAnnotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Description getDescription() {
/*     */     Description description;
/* 390 */     Class<?> clazz = getTestClass().getJavaClass();
/*     */ 
/*     */ 
/*     */     
/* 394 */     if (clazz == null || !clazz.getName().equals(getName())) {
/* 395 */       description = Description.createSuiteDescription(getName(), getRunnerAnnotations());
/*     */     } else {
/* 397 */       description = Description.createSuiteDescription(clazz, getRunnerAnnotations());
/*     */     } 
/*     */     
/* 400 */     for (T child : getFilteredChildren()) {
/* 401 */       description.addChild(describeChild(child));
/*     */     }
/* 403 */     return description;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run(RunNotifier notifier) {
/* 408 */     EachTestNotifier testNotifier = new EachTestNotifier(notifier, getDescription());
/*     */     
/* 410 */     testNotifier.fireTestSuiteStarted();
/*     */     try {
/* 412 */       Statement statement = classBlock(notifier);
/* 413 */       statement.evaluate();
/* 414 */     } catch (AssumptionViolatedException e) {
/* 415 */       testNotifier.addFailedAssumption(e);
/* 416 */     } catch (StoppedByUserException e) {
/* 417 */       throw e;
/* 418 */     } catch (Throwable e) {
/* 419 */       testNotifier.addFailure(e);
/*     */     } finally {
/* 421 */       testNotifier.fireTestSuiteFinished();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void filter(Filter filter) throws NoTestsRemainException {
/* 430 */     this.childrenLock.lock();
/*     */     try {
/* 432 */       List<T> children = new ArrayList<T>(getFilteredChildren());
/* 433 */       for (Iterator<T> iter = children.iterator(); iter.hasNext(); ) {
/* 434 */         T each = iter.next();
/* 435 */         if (shouldRun(filter, each)) {
/*     */           try {
/* 437 */             filter.apply(each);
/* 438 */           } catch (NoTestsRemainException e) {
/* 439 */             iter.remove();
/*     */           }  continue;
/*     */         } 
/* 442 */         iter.remove();
/*     */       } 
/*     */       
/* 445 */       this.filteredChildren = Collections.unmodifiableList(children);
/* 446 */       if (this.filteredChildren.isEmpty()) {
/* 447 */         throw new NoTestsRemainException();
/*     */       }
/*     */     } finally {
/* 450 */       this.childrenLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void sort(Sorter sorter) {
/* 455 */     if (shouldNotReorder()) {
/*     */       return;
/*     */     }
/*     */     
/* 459 */     this.childrenLock.lock();
/*     */     try {
/* 461 */       for (T each : getFilteredChildren()) {
/* 462 */         sorter.apply(each);
/*     */       }
/* 464 */       List<T> sortedChildren = new ArrayList<T>(getFilteredChildren());
/* 465 */       Collections.sort(sortedChildren, comparator(sorter));
/* 466 */       this.filteredChildren = Collections.unmodifiableList(sortedChildren);
/*     */     } finally {
/* 468 */       this.childrenLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void order(Orderer orderer) throws InvalidOrderingException {
/* 478 */     if (shouldNotReorder()) {
/*     */       return;
/*     */     }
/*     */     
/* 482 */     this.childrenLock.lock();
/*     */     try {
/* 484 */       List<T> children = getFilteredChildren();
/*     */ 
/*     */       
/* 487 */       Map<Description, List<T>> childMap = new LinkedHashMap<Description, List<T>>(children.size());
/*     */       
/* 489 */       for (T child : children) {
/* 490 */         Description description = describeChild(child);
/* 491 */         List<T> childrenWithDescription = childMap.get(description);
/* 492 */         if (childrenWithDescription == null) {
/* 493 */           childrenWithDescription = new ArrayList<T>(1);
/* 494 */           childMap.put(description, childrenWithDescription);
/*     */         } 
/* 496 */         childrenWithDescription.add(child);
/* 497 */         orderer.apply(child);
/*     */       } 
/*     */       
/* 500 */       List<Description> inOrder = orderer.order(childMap.keySet());
/*     */       
/* 502 */       children = new ArrayList<T>(children.size());
/* 503 */       for (Description description : inOrder) {
/* 504 */         children.addAll(childMap.get(description));
/*     */       }
/* 506 */       this.filteredChildren = Collections.unmodifiableList(children);
/*     */     } finally {
/* 508 */       this.childrenLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean shouldNotReorder() {
/* 518 */     return (getDescription().getAnnotation(FixMethodOrder.class) != null);
/*     */   }
/*     */   
/*     */   private void validate() throws InitializationError {
/* 522 */     List<Throwable> errors = new ArrayList<Throwable>();
/* 523 */     collectInitializationErrors(errors);
/* 524 */     if (!errors.isEmpty()) {
/* 525 */       throw new InvalidTestClassError(this.testClass.getJavaClass(), errors);
/*     */     }
/*     */   }
/*     */   
/*     */   private List<T> getFilteredChildren() {
/* 530 */     if (this.filteredChildren == null) {
/* 531 */       this.childrenLock.lock();
/*     */       try {
/* 533 */         if (this.filteredChildren == null) {
/* 534 */           this.filteredChildren = Collections.unmodifiableList(new ArrayList<T>(getChildren()));
/*     */         }
/*     */       } finally {
/*     */         
/* 538 */         this.childrenLock.unlock();
/*     */       } 
/*     */     } 
/* 541 */     return this.filteredChildren;
/*     */   }
/*     */   
/*     */   private boolean shouldRun(Filter filter, T each) {
/* 545 */     return filter.shouldRun(describeChild(each));
/*     */   }
/*     */   
/*     */   private Comparator<? super T> comparator(final Sorter sorter) {
/* 549 */     return new Comparator<T>() {
/*     */         public int compare(T o1, T o2) {
/* 551 */           return sorter.compare(ParentRunner.this.describeChild(o1), ParentRunner.this.describeChild(o2));
/*     */         }
/*     */       };
/*     */   }
/*     */   protected abstract List<T> getChildren();
/*     */   protected abstract Description describeChild(T paramT);
/*     */   
/*     */   protected abstract void runChild(T paramT, RunNotifier paramRunNotifier);
/*     */   
/*     */   public void setScheduler(RunnerScheduler scheduler) {
/* 561 */     this.scheduler = scheduler;
/*     */   }
/*     */   private static class ClassRuleCollector implements MemberValueConsumer<TestRule> { final List<RuleContainer.RuleEntry> entries;
/*     */     private ClassRuleCollector() {
/* 565 */       this.entries = new ArrayList<RuleContainer.RuleEntry>();
/*     */     }
/*     */     public void accept(FrameworkMember<?> member, TestRule value) {
/* 568 */       ClassRule rule = (ClassRule)member.getAnnotation(ClassRule.class);
/* 569 */       this.entries.add(new RuleContainer.RuleEntry(value, 1, (rule != null) ? Integer.valueOf(rule.order()) : null));
/*     */     }
/*     */ 
/*     */     
/*     */     public List<TestRule> getOrderedRules() {
/* 574 */       Collections.sort(this.entries, RuleContainer.ENTRY_COMPARATOR);
/* 575 */       List<TestRule> result = new ArrayList<TestRule>(this.entries.size());
/* 576 */       for (RuleContainer.RuleEntry entry : this.entries) {
/* 577 */         result.add((TestRule)entry.rule);
/*     */       }
/* 579 */       return result;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\ParentRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */