/*    */ package org.junit.runners;
/*    */ 
/*    */ import org.junit.internal.runners.SuiteMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllTests
/*    */   extends SuiteMethod
/*    */ {
/*    */   public AllTests(Class<?> klass) throws Throwable {
/* 25 */     super(klass);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\AllTests.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */