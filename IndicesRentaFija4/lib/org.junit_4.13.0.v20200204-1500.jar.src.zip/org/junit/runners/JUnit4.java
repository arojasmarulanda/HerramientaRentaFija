/*    */ package org.junit.runners;
/*    */ 
/*    */ import org.junit.runners.model.InitializationError;
/*    */ import org.junit.runners.model.TestClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JUnit4
/*    */   extends BlockJUnit4ClassRunner
/*    */ {
/*    */   public JUnit4(Class<?> klass) throws InitializationError {
/* 23 */     super(new TestClass(klass));
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\JUnit4.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */