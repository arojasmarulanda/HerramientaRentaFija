/*     */ package org.junit.runners;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.junit.After;
/*     */ import org.junit.Before;
/*     */ import org.junit.Ignore;
/*     */ import org.junit.Rule;
/*     */ import org.junit.Test;
/*     */ import org.junit.internal.runners.model.ReflectiveCallable;
/*     */ import org.junit.internal.runners.rules.RuleMemberValidator;
/*     */ import org.junit.internal.runners.statements.ExpectException;
/*     */ import org.junit.internal.runners.statements.Fail;
/*     */ import org.junit.internal.runners.statements.FailOnTimeout;
/*     */ import org.junit.internal.runners.statements.InvokeMethod;
/*     */ import org.junit.internal.runners.statements.RunAfters;
/*     */ import org.junit.internal.runners.statements.RunBefores;
/*     */ import org.junit.rules.MethodRule;
/*     */ import org.junit.rules.TestRule;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.notification.RunNotifier;
/*     */ import org.junit.runners.model.FrameworkMember;
/*     */ import org.junit.runners.model.FrameworkMethod;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.MemberValueConsumer;
/*     */ import org.junit.runners.model.Statement;
/*     */ import org.junit.runners.model.TestClass;
/*     */ import org.junit.validator.PublicClassValidator;
/*     */ import org.junit.validator.TestClassValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockJUnit4ClassRunner
/*     */   extends ParentRunner<FrameworkMethod>
/*     */ {
/*  64 */   private static TestClassValidator PUBLIC_CLASS_VALIDATOR = (TestClassValidator)new PublicClassValidator();
/*     */   
/*  66 */   private final ConcurrentMap<FrameworkMethod, Description> methodDescriptions = new ConcurrentHashMap<FrameworkMethod, Description>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlockJUnit4ClassRunner(Class<?> testClass) throws InitializationError {
/*  74 */     super(testClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BlockJUnit4ClassRunner(TestClass testClass) throws InitializationError {
/*  84 */     super(testClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void runChild(final FrameworkMethod method, RunNotifier notifier) {
/*  93 */     Description description = describeChild(method);
/*  94 */     if (isIgnored(method)) {
/*  95 */       notifier.fireTestIgnored(description);
/*     */     } else {
/*  97 */       Statement statement = new Statement()
/*     */         {
/*     */           public void evaluate() throws Throwable {
/* 100 */             BlockJUnit4ClassRunner.this.methodBlock(method).evaluate();
/*     */           }
/*     */         };
/* 103 */       runLeaf(statement, description, notifier);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isIgnored(FrameworkMethod child) {
/* 113 */     return (child.getAnnotation(Ignore.class) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Description describeChild(FrameworkMethod method) {
/* 118 */     Description description = this.methodDescriptions.get(method);
/*     */     
/* 120 */     if (description == null) {
/* 121 */       description = Description.createTestDescription(getTestClass().getJavaClass(), testName(method), method.getAnnotations());
/*     */       
/* 123 */       this.methodDescriptions.putIfAbsent(method, description);
/*     */     } 
/*     */     
/* 126 */     return description;
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<FrameworkMethod> getChildren() {
/* 131 */     return computeTestMethods();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<FrameworkMethod> computeTestMethods() {
/* 144 */     return getTestClass().getAnnotatedMethods(Test.class);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void collectInitializationErrors(List<Throwable> errors) {
/* 149 */     super.collectInitializationErrors(errors);
/*     */     
/* 151 */     validatePublicConstructor(errors);
/* 152 */     validateNoNonStaticInnerClass(errors);
/* 153 */     validateConstructor(errors);
/* 154 */     validateInstanceMethods(errors);
/* 155 */     validateFields(errors);
/* 156 */     validateMethods(errors);
/*     */   }
/*     */   
/*     */   private void validatePublicConstructor(List<Throwable> errors) {
/* 160 */     if (getTestClass().getJavaClass() != null) {
/* 161 */       errors.addAll(PUBLIC_CLASS_VALIDATOR.validateTestClass(getTestClass()));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void validateNoNonStaticInnerClass(List<Throwable> errors) {
/* 166 */     if (getTestClass().isANonStaticInnerClass()) {
/* 167 */       String gripe = "The inner class " + getTestClass().getName() + " is not static.";
/*     */       
/* 169 */       errors.add(new Exception(gripe));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateConstructor(List<Throwable> errors) {
/* 179 */     validateOnlyOneConstructor(errors);
/* 180 */     validateZeroArgConstructor(errors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateOnlyOneConstructor(List<Throwable> errors) {
/* 188 */     if (!hasOneConstructor()) {
/* 189 */       String gripe = "Test class should have exactly one public constructor";
/* 190 */       errors.add(new Exception(gripe));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateZeroArgConstructor(List<Throwable> errors) {
/* 199 */     if (!getTestClass().isANonStaticInnerClass() && hasOneConstructor() && (getTestClass().getOnlyConstructor().getParameterTypes()).length != 0) {
/*     */ 
/*     */       
/* 202 */       String gripe = "Test class should have exactly one public zero-argument constructor";
/* 203 */       errors.add(new Exception(gripe));
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasOneConstructor() {
/* 208 */     return ((getTestClass().getJavaClass().getConstructors()).length == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void validateInstanceMethods(List<Throwable> errors) {
/* 219 */     validatePublicVoidNoArgMethods((Class)After.class, false, errors);
/* 220 */     validatePublicVoidNoArgMethods((Class)Before.class, false, errors);
/* 221 */     validateTestMethods(errors);
/*     */     
/* 223 */     if (computeTestMethods().isEmpty()) {
/* 224 */       errors.add(new Exception("No runnable methods"));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void validateFields(List<Throwable> errors) {
/* 229 */     RuleMemberValidator.RULE_VALIDATOR.validate(getTestClass(), errors);
/*     */   }
/*     */   
/*     */   private void validateMethods(List<Throwable> errors) {
/* 233 */     RuleMemberValidator.RULE_METHOD_VALIDATOR.validate(getTestClass(), errors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateTestMethods(List<Throwable> errors) {
/* 241 */     validatePublicVoidNoArgMethods((Class)Test.class, false, errors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object createTest() throws Exception {
/* 250 */     return getTestClass().getOnlyConstructor().newInstance(new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object createTest(FrameworkMethod method) throws Exception {
/* 260 */     return createTest();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String testName(FrameworkMethod method) {
/* 268 */     return method.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Statement methodBlock(final FrameworkMethod method) {
/*     */     Object test;
/*     */     try {
/* 306 */       test = (new ReflectiveCallable()
/*     */         {
/*     */           protected Object runReflectiveCall() throws Throwable {
/* 309 */             return BlockJUnit4ClassRunner.this.createTest(method);
/*     */           }
/*     */         }).run();
/* 312 */     } catch (Throwable e) {
/* 313 */       return (Statement)new Fail(e);
/*     */     } 
/*     */     
/* 316 */     Statement statement = methodInvoker(method, test);
/* 317 */     statement = possiblyExpectingExceptions(method, test, statement);
/* 318 */     statement = withPotentialTimeout(method, test, statement);
/* 319 */     statement = withBefores(method, test, statement);
/* 320 */     statement = withAfters(method, test, statement);
/* 321 */     statement = withRules(method, test, statement);
/* 322 */     statement = withInterruptIsolation(statement);
/* 323 */     return statement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Statement methodInvoker(FrameworkMethod method, Object test) {
/* 334 */     return (Statement)new InvokeMethod(method, test);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Statement possiblyExpectingExceptions(FrameworkMethod method, Object test, Statement next) {
/* 345 */     Test annotation = (Test)method.getAnnotation(Test.class);
/* 346 */     Class<? extends Throwable> expectedExceptionClass = getExpectedException(annotation);
/* 347 */     return (expectedExceptionClass != null) ? (Statement)new ExpectException(next, expectedExceptionClass) : next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Statement withPotentialTimeout(FrameworkMethod method, Object test, Statement next) {
/* 359 */     long timeout = getTimeout((Test)method.getAnnotation(Test.class));
/* 360 */     if (timeout <= 0L) {
/* 361 */       return next;
/*     */     }
/* 363 */     return (Statement)FailOnTimeout.builder().withTimeout(timeout, TimeUnit.MILLISECONDS).build(next);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Statement withBefores(FrameworkMethod method, Object target, Statement statement) {
/* 375 */     List<FrameworkMethod> befores = getTestClass().getAnnotatedMethods(Before.class);
/*     */     
/* 377 */     return befores.isEmpty() ? statement : (Statement)new RunBefores(statement, befores, target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Statement withAfters(FrameworkMethod method, Object target, Statement statement) {
/* 390 */     List<FrameworkMethod> afters = getTestClass().getAnnotatedMethods(After.class);
/*     */     
/* 392 */     return afters.isEmpty() ? statement : (Statement)new RunAfters(statement, afters, target);
/*     */   }
/*     */ 
/*     */   
/*     */   private Statement withRules(FrameworkMethod method, Object target, Statement statement) {
/* 397 */     RuleContainer ruleContainer = new RuleContainer();
/* 398 */     CURRENT_RULE_CONTAINER.set(ruleContainer);
/*     */     try {
/* 400 */       List<TestRule> testRules = getTestRules(target);
/* 401 */       for (MethodRule each : rules(target)) {
/* 402 */         if (!(each instanceof TestRule) || !testRules.contains(each)) {
/* 403 */           ruleContainer.add(each);
/*     */         }
/*     */       } 
/* 406 */       for (TestRule rule : testRules) {
/* 407 */         ruleContainer.add(rule);
/*     */       }
/*     */     } finally {
/* 410 */       CURRENT_RULE_CONTAINER.remove();
/*     */     } 
/* 412 */     return ruleContainer.apply(method, describeChild(method), target, statement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<MethodRule> rules(Object target) {
/* 421 */     RuleCollector<MethodRule> collector = new RuleCollector<MethodRule>();
/* 422 */     getTestClass().collectAnnotatedMethodValues(target, Rule.class, MethodRule.class, collector);
/*     */     
/* 424 */     getTestClass().collectAnnotatedFieldValues(target, Rule.class, MethodRule.class, collector);
/*     */     
/* 426 */     return collector.result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<TestRule> getTestRules(Object target) {
/* 435 */     RuleCollector<TestRule> collector = new RuleCollector<TestRule>();
/* 436 */     getTestClass().collectAnnotatedMethodValues(target, Rule.class, TestRule.class, collector);
/* 437 */     getTestClass().collectAnnotatedFieldValues(target, Rule.class, TestRule.class, collector);
/* 438 */     return collector.result;
/*     */   }
/*     */   
/*     */   private Class<? extends Throwable> getExpectedException(Test annotation) {
/* 442 */     if (annotation == null || annotation.expected() == Test.None.class) {
/* 443 */       return null;
/*     */     }
/* 445 */     return annotation.expected();
/*     */   }
/*     */ 
/*     */   
/*     */   private long getTimeout(Test annotation) {
/* 450 */     if (annotation == null) {
/* 451 */       return 0L;
/*     */     }
/* 453 */     return annotation.timeout();
/*     */   }
/*     */   
/* 456 */   private static final ThreadLocal<RuleContainer> CURRENT_RULE_CONTAINER = new ThreadLocal<RuleContainer>();
/*     */   
/*     */   private static class RuleCollector<T> implements MemberValueConsumer<T> {
/*     */     private RuleCollector() {
/* 460 */       this.result = new ArrayList<T>();
/*     */     } final List<T> result;
/*     */     public void accept(FrameworkMember<?> member, T value) {
/* 463 */       Rule rule = (Rule)member.getAnnotation(Rule.class);
/* 464 */       if (rule != null) {
/* 465 */         RuleContainer container = BlockJUnit4ClassRunner.CURRENT_RULE_CONTAINER.get();
/* 466 */         if (container != null) {
/* 467 */           container.setOrder(value, rule.order());
/*     */         }
/*     */       } 
/* 470 */       this.result.add(value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runners\BlockJUnit4ClassRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */