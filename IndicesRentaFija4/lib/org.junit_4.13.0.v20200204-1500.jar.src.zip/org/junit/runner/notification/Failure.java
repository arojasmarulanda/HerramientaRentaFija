/*    */ package org.junit.runner.notification;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.junit.internal.Throwables;
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Failure
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Description fDescription;
/*    */   private final Throwable fThrownException;
/*    */   
/*    */   public Failure(Description description, Throwable thrownException) {
/* 35 */     this.fThrownException = thrownException;
/* 36 */     this.fDescription = description;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getTestHeader() {
/* 43 */     return this.fDescription.getDisplayName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Description getDescription() {
/* 50 */     return this.fDescription;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Throwable getException() {
/* 58 */     return this.fThrownException;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     return getTestHeader() + ": " + this.fThrownException.getMessage();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getTrace() {
/* 70 */     return Throwables.getStacktrace(getException());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getTrimmedTrace() {
/* 79 */     return Throwables.getTrimmedStackTrace(getException());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 88 */     return getException().getMessage();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\notification\Failure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */