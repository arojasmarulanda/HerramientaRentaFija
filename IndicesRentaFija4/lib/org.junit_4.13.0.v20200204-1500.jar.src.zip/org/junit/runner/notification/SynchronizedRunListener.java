/*     */ package org.junit.runner.notification;
/*     */ 
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.Result;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ThreadSafe
/*     */ final class SynchronizedRunListener
/*     */   extends RunListener
/*     */ {
/*     */   private final RunListener listener;
/*     */   private final Object monitor;
/*     */   
/*     */   SynchronizedRunListener(RunListener listener, Object monitor) {
/*  28 */     this.listener = listener;
/*  29 */     this.monitor = monitor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void testRunStarted(Description description) throws Exception {
/*  34 */     synchronized (this.monitor) {
/*  35 */       this.listener.testRunStarted(description);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void testRunFinished(Result result) throws Exception {
/*  41 */     synchronized (this.monitor) {
/*  42 */       this.listener.testRunFinished(result);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testSuiteStarted(Description description) throws Exception {
/*  57 */     synchronized (this.monitor) {
/*  58 */       this.listener.testSuiteStarted(description);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void testSuiteFinished(Description description) throws Exception {
/*  72 */     synchronized (this.monitor) {
/*  73 */       this.listener.testSuiteFinished(description);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void testStarted(Description description) throws Exception {
/*  79 */     synchronized (this.monitor) {
/*  80 */       this.listener.testStarted(description);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void testFinished(Description description) throws Exception {
/*  86 */     synchronized (this.monitor) {
/*  87 */       this.listener.testFinished(description);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void testFailure(Failure failure) throws Exception {
/*  93 */     synchronized (this.monitor) {
/*  94 */       this.listener.testFailure(failure);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void testAssumptionFailure(Failure failure) {
/* 100 */     synchronized (this.monitor) {
/* 101 */       this.listener.testAssumptionFailure(failure);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void testIgnored(Description description) throws Exception {
/* 107 */     synchronized (this.monitor) {
/* 108 */       this.listener.testIgnored(description);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 114 */     return this.listener.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 119 */     if (this == other) {
/* 120 */       return true;
/*     */     }
/* 122 */     if (!(other instanceof SynchronizedRunListener)) {
/* 123 */       return false;
/*     */     }
/* 125 */     SynchronizedRunListener that = (SynchronizedRunListener)other;
/*     */     
/* 127 */     return this.listener.equals(that.listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return this.listener.toString() + " (with synchronization wrapper)";
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\notification\SynchronizedRunListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */