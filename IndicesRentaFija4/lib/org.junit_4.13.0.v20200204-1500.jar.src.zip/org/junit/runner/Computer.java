/*    */ package org.junit.runner;
/*    */ 
/*    */ import org.junit.runners.Suite;
/*    */ import org.junit.runners.model.InitializationError;
/*    */ import org.junit.runners.model.RunnerBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Computer
/*    */ {
/*    */   public static Computer serial() {
/* 19 */     return new Computer();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Runner getSuite(final RunnerBuilder builder, Class<?>[] classes) throws InitializationError {
/* 28 */     return (Runner)new Suite(new RunnerBuilder()
/*    */         {
/*    */           public Runner runnerForClass(Class<?> testClass) throws Throwable {
/* 31 */             return Computer.this.getRunner(builder, testClass);
/*    */           }
/*    */         }classes)
/*    */       {
/*    */ 
/*    */ 
/*    */ 
/*    */         
/*    */         protected String getName()
/*    */         {
/* 41 */           return "classes";
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Runner getRunner(RunnerBuilder builder, Class<?> testClass) throws Throwable {
/* 50 */     return builder.runnerForClass(testClass);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\Computer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */