/*     */ package org.junit.runner;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Description
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  33 */   private static final Pattern METHOD_AND_CLASS_NAME_PATTERN = Pattern.compile("([\\s\\S]*)\\((.*)\\)");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Description createSuiteDescription(String name, Annotation... annotations) {
/*  45 */     return new Description(null, name, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Description createSuiteDescription(String name, Serializable uniqueId, Annotation... annotations) {
/*  58 */     return new Description(null, name, uniqueId, annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Description createTestDescription(String className, String name, Annotation... annotations) {
/*  73 */     return new Description(null, formatDisplayName(name, className), annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Description createTestDescription(Class<?> clazz, String name, Annotation... annotations) {
/*  86 */     return new Description(clazz, formatDisplayName(name, clazz.getName()), annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Description createTestDescription(Class<?> clazz, String name) {
/*  99 */     return new Description(clazz, formatDisplayName(name, clazz.getName()), new Annotation[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Description createTestDescription(String className, String name, Serializable uniqueId) {
/* 110 */     return new Description(null, formatDisplayName(name, className), uniqueId, new Annotation[0]);
/*     */   }
/*     */   
/*     */   private static String formatDisplayName(String name, String className) {
/* 114 */     return String.format("%s(%s)", new Object[] { name, className });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Description createSuiteDescription(Class<?> testClass) {
/* 124 */     return new Description(testClass, testClass.getName(), testClass.getAnnotations());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Description createSuiteDescription(Class<?> testClass, Annotation... annotations) {
/* 135 */     return new Description(testClass, testClass.getName(), annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public static final Description EMPTY = new Description(null, "No Tests", new Annotation[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public static final Description TEST_MECHANISM = new Description(null, "Test mechanism", new Annotation[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   private final Collection<Description> fChildren = new ConcurrentLinkedQueue<Description>();
/*     */   private final String fDisplayName;
/*     */   private final Serializable fUniqueId;
/*     */   private final Annotation[] fAnnotations;
/*     */   private volatile Class<?> fTestClass;
/*     */   
/*     */   private Description(Class<?> clazz, String displayName, Annotation... annotations) {
/* 162 */     this(clazz, displayName, displayName, annotations);
/*     */   }
/*     */   
/*     */   private Description(Class<?> testClass, String displayName, Serializable uniqueId, Annotation... annotations) {
/* 166 */     if (displayName == null || displayName.length() == 0) {
/* 167 */       throw new IllegalArgumentException("The display name must not be empty.");
/*     */     }
/*     */     
/* 170 */     if (uniqueId == null) {
/* 171 */       throw new IllegalArgumentException("The unique id must not be null.");
/*     */     }
/*     */     
/* 174 */     this.fTestClass = testClass;
/* 175 */     this.fDisplayName = displayName;
/* 176 */     this.fUniqueId = uniqueId;
/* 177 */     this.fAnnotations = annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDisplayName() {
/* 184 */     return this.fDisplayName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChild(Description description) {
/* 193 */     this.fChildren.add(description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<Description> getChildren() {
/* 201 */     return new ArrayList<Description>(this.fChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSuite() {
/* 208 */     return !isTest();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTest() {
/* 215 */     return this.fChildren.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int testCount() {
/* 222 */     if (isTest()) {
/* 223 */       return 1;
/*     */     }
/* 225 */     int result = 0;
/* 226 */     for (Description child : this.fChildren) {
/* 227 */       result += child.testCount();
/*     */     }
/* 229 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 234 */     return this.fUniqueId.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 239 */     if (!(obj instanceof Description)) {
/* 240 */       return false;
/*     */     }
/* 242 */     Description d = (Description)obj;
/* 243 */     return this.fUniqueId.equals(d.fUniqueId);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 248 */     return getDisplayName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 255 */     return equals(EMPTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Description childlessCopy() {
/* 263 */     return new Description(this.fTestClass, this.fDisplayName, this.fAnnotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Annotation> T getAnnotation(Class<T> annotationType) {
/* 271 */     for (Annotation each : this.fAnnotations) {
/* 272 */       if (each.annotationType().equals(annotationType)) {
/* 273 */         return annotationType.cast(each);
/*     */       }
/*     */     } 
/* 276 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Annotation> getAnnotations() {
/* 283 */     return Arrays.asList(this.fAnnotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getTestClass() {
/* 291 */     if (this.fTestClass != null) {
/* 292 */       return this.fTestClass;
/*     */     }
/* 294 */     String name = getClassName();
/* 295 */     if (name == null) {
/* 296 */       return null;
/*     */     }
/*     */     try {
/* 299 */       this.fTestClass = Class.forName(name, false, getClass().getClassLoader());
/* 300 */       return this.fTestClass;
/* 301 */     } catch (ClassNotFoundException e) {
/* 302 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 311 */     return (this.fTestClass != null) ? this.fTestClass.getName() : methodAndClassNamePatternGroupOrDefault(2, toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethodName() {
/* 319 */     return methodAndClassNamePatternGroupOrDefault(1, null);
/*     */   }
/*     */ 
/*     */   
/*     */   private String methodAndClassNamePatternGroupOrDefault(int group, String defaultString) {
/* 324 */     Matcher matcher = METHOD_AND_CLASS_NAME_PATTERN.matcher(toString());
/* 325 */     return matcher.matches() ? matcher.group(group) : defaultString;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\Description.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */