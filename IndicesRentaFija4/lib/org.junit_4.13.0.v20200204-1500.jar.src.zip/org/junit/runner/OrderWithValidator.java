/*    */ package org.junit.runner;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.junit.FixMethodOrder;
/*    */ import org.junit.runners.model.TestClass;
/*    */ import org.junit.validator.AnnotationValidator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OrderWithValidator
/*    */   extends AnnotationValidator
/*    */ {
/*    */   public List<Exception> validateAnnotatedClass(TestClass testClass) {
/* 32 */     if (testClass.getAnnotation(FixMethodOrder.class) != null) {
/* 33 */       return Collections.singletonList(new Exception("@FixMethodOrder cannot be combined with @OrderWith"));
/*    */     }
/*    */     
/* 36 */     return Collections.emptyList();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\OrderWithValidator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */