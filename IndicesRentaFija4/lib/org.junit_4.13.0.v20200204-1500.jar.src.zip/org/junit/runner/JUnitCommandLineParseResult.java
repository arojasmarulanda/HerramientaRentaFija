/*     */ package org.junit.runner;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.junit.internal.Classes;
/*     */ import org.junit.runner.manipulation.Filter;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ 
/*     */ 
/*     */ class JUnitCommandLineParseResult
/*     */ {
/*  13 */   private final List<String> filterSpecs = new ArrayList<String>();
/*  14 */   private final List<Class<?>> classes = new ArrayList<Class<?>>();
/*  15 */   private final List<Throwable> parserErrors = new ArrayList<Throwable>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFilterSpecs() {
/*  26 */     return Collections.unmodifiableList(this.filterSpecs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Class<?>> getClasses() {
/*  33 */     return Collections.unmodifiableList(this.classes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JUnitCommandLineParseResult parse(String[] args) {
/*  42 */     JUnitCommandLineParseResult result = new JUnitCommandLineParseResult();
/*     */     
/*  44 */     result.parseArgs(args);
/*     */     
/*  46 */     return result;
/*     */   }
/*     */   
/*     */   private void parseArgs(String[] args) {
/*  50 */     parseParameters(parseOptions(args));
/*     */   }
/*     */   
/*     */   String[] parseOptions(String... args) {
/*  54 */     for (int i = 0; i != args.length; i++) {
/*  55 */       String arg = args[i];
/*     */       
/*  57 */       if (arg.equals("--"))
/*  58 */         return copyArray(args, i + 1, args.length); 
/*  59 */       if (arg.startsWith("--")) {
/*  60 */         if (arg.startsWith("--filter=") || arg.equals("--filter")) {
/*     */           String filterSpec;
/*  62 */           if (arg.equals("--filter")) {
/*  63 */             i++;
/*     */             
/*  65 */             if (i < args.length) {
/*  66 */               filterSpec = args[i];
/*     */             } else {
/*  68 */               this.parserErrors.add(new CommandLineParserError(arg + " value not specified"));
/*     */               break;
/*     */             } 
/*     */           } else {
/*  72 */             filterSpec = arg.substring(arg.indexOf('=') + 1);
/*     */           } 
/*     */           
/*  75 */           this.filterSpecs.add(filterSpec);
/*     */         } else {
/*  77 */           this.parserErrors.add(new CommandLineParserError("JUnit knows nothing about the " + arg + " option"));
/*     */         } 
/*     */       } else {
/*  80 */         return copyArray(args, i, args.length);
/*     */       } 
/*     */     } 
/*     */     
/*  84 */     return new String[0];
/*     */   }
/*     */   
/*     */   private String[] copyArray(String[] args, int from, int to) {
/*  88 */     String[] result = new String[to - from];
/*  89 */     for (int j = from; j != to; j++) {
/*  90 */       result[j - from] = args[j];
/*     */     }
/*  92 */     return result;
/*     */   }
/*     */   
/*     */   void parseParameters(String[] args) {
/*  96 */     for (String arg : args) {
/*     */       try {
/*  98 */         this.classes.add(Classes.getClass(arg));
/*  99 */       } catch (ClassNotFoundException e) {
/* 100 */         this.parserErrors.add(new IllegalArgumentException("Could not find class [" + arg + "]", e));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Request errorReport(Throwable cause) {
/* 106 */     return Request.errorReport(JUnitCommandLineParseResult.class, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request createRequest(Computer computer) {
/* 115 */     if (this.parserErrors.isEmpty()) {
/* 116 */       Request request = Request.classes(computer, (Class[])this.classes.<Class<?>[]>toArray((Class<?>[][])new Class[this.classes.size()]));
/*     */       
/* 118 */       return applyFilterSpecs(request);
/*     */     } 
/* 120 */     return errorReport((Throwable)new InitializationError(this.parserErrors));
/*     */   }
/*     */ 
/*     */   
/*     */   private Request applyFilterSpecs(Request request) {
/*     */     try {
/* 126 */       for (String filterSpec : this.filterSpecs) {
/* 127 */         Filter filter = FilterFactories.createFilterFromFilterSpec(request, filterSpec);
/*     */         
/* 129 */         request = request.filterWith(filter);
/*     */       } 
/* 131 */       return request;
/* 132 */     } catch (FilterNotCreatedException e) {
/* 133 */       return errorReport(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static class CommandLineParserError
/*     */     extends Exception
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public CommandLineParserError(String message) {
/* 144 */       super(message);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\JUnitCommandLineParseResult.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */