/*    */ package org.junit.runner.manipulation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Orderer
/*    */ {
/*    */   private final Ordering ordering;
/*    */   
/*    */   Orderer(Ordering delegate) {
/* 20 */     this.ordering = delegate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Description> order(Collection<Description> descriptions) throws InvalidOrderingException {
/* 30 */     List<Description> inOrder = this.ordering.orderItems(Collections.unmodifiableCollection(descriptions));
/*    */     
/* 32 */     if (!this.ordering.validateOrderingIsCorrect()) {
/* 33 */       return inOrder;
/*    */     }
/*    */     
/* 36 */     Set<Description> uniqueDescriptions = new HashSet<Description>(descriptions);
/* 37 */     if (!uniqueDescriptions.containsAll(inOrder)) {
/* 38 */       throw new InvalidOrderingException("Ordering added items");
/*    */     }
/* 40 */     Set<Description> resultAsSet = new HashSet<Description>(inOrder);
/* 41 */     if (resultAsSet.size() != inOrder.size())
/* 42 */       throw new InvalidOrderingException("Ordering duplicated items"); 
/* 43 */     if (!resultAsSet.containsAll(uniqueDescriptions)) {
/* 44 */       throw new InvalidOrderingException("Ordering removed items");
/*    */     }
/*    */     
/* 47 */     return inOrder;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void apply(Object target) throws InvalidOrderingException {
/* 57 */     if (target instanceof Orderable) {
/* 58 */       Orderable orderable = (Orderable)target;
/* 59 */       orderable.order(this);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\manipulation\Orderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */