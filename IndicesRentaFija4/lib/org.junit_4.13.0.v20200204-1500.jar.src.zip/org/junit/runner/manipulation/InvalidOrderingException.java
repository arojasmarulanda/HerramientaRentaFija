/*    */ package org.junit.runner.manipulation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidOrderingException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public InvalidOrderingException() {}
/*    */   
/*    */   public InvalidOrderingException(String message) {
/* 15 */     super(message);
/*    */   }
/*    */   
/*    */   public InvalidOrderingException(String message, Throwable cause) {
/* 19 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\manipulation\InvalidOrderingException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */