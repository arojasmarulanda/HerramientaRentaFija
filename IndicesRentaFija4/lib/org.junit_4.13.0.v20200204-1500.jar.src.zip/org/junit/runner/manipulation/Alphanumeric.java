/*    */ package org.junit.runner.manipulation;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Alphanumeric
/*    */   extends Sorter
/*    */   implements Ordering.Factory
/*    */ {
/*    */   public Alphanumeric() {
/* 15 */     super(COMPARATOR);
/*    */   }
/*    */   
/*    */   public Ordering create(Ordering.Context context) {
/* 19 */     return this;
/*    */   }
/*    */   
/* 22 */   private static final Comparator<Description> COMPARATOR = new Comparator<Description>() {
/*    */       public int compare(Description o1, Description o2) {
/* 24 */         return o1.getDisplayName().compareTo(o2.getDisplayName());
/*    */       }
/*    */     };
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\manipulation\Alphanumeric.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */