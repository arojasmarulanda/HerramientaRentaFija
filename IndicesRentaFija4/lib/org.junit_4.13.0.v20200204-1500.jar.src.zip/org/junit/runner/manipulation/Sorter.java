/*    */ package org.junit.runner.manipulation;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import org.junit.runner.Description;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Sorter
/*    */   extends Ordering
/*    */   implements Comparator<Description>
/*    */ {
/* 22 */   public static final Sorter NULL = new Sorter(new Comparator<Description>() {
/*    */         public int compare(Description o1, Description o2) {
/* 24 */           return 0;
/*    */         }
/*    */       });
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final Comparator<Description> comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Sorter(Comparator<Description> comparator) {
/* 38 */     this.comparator = comparator;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void apply(Object target) {
/* 53 */     if (target instanceof Sortable) {
/* 54 */       Sortable sortable = (Sortable)target;
/* 55 */       sortable.sort(this);
/*    */     } 
/*    */   }
/*    */   
/*    */   public int compare(Description o1, Description o2) {
/* 60 */     return this.comparator.compare(o1, o2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final List<Description> orderItems(Collection<Description> descriptions) {
/* 76 */     List<Description> sorted = new ArrayList<Description>(descriptions);
/* 77 */     Collections.sort(sorted, this);
/* 78 */     return sorted;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean validateOrderingIsCorrect() {
/* 88 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\manipulation\Sorter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */