/*     */ package org.junit.runner.manipulation;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import org.junit.runner.Description;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Ordering
/*     */ {
/*     */   private static final String CONSTRUCTOR_ERROR_FORMAT = "Ordering class %s should have a public constructor with signature %s(Ordering.Context context)";
/*     */   
/*     */   public static Ordering shuffledBy(final Random random) {
/*  32 */     return new Ordering()
/*     */       {
/*     */         boolean validateOrderingIsCorrect() {
/*  35 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         protected List<Description> orderItems(Collection<Description> descriptions) {
/*  40 */           List<Description> shuffled = new ArrayList<Description>(descriptions);
/*  41 */           Collections.shuffle(shuffled, random);
/*  42 */           return shuffled;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ordering definedBy(Class<? extends Factory> factoryClass, Description annotatedTestClass) throws InvalidOrderingException {
/*     */     Factory factory;
/*  58 */     if (factoryClass == null) {
/*  59 */       throw new NullPointerException("factoryClass cannot be null");
/*     */     }
/*  61 */     if (annotatedTestClass == null) {
/*  62 */       throw new NullPointerException("annotatedTestClass cannot be null");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  67 */       Constructor<? extends Factory> constructor = factoryClass.getConstructor(new Class[0]);
/*  68 */       factory = constructor.newInstance(new Object[0]);
/*  69 */     } catch (NoSuchMethodException e) {
/*  70 */       throw new InvalidOrderingException(String.format("Ordering class %s should have a public constructor with signature %s(Ordering.Context context)", new Object[] { getClassName(factoryClass), factoryClass.getSimpleName() }));
/*     */ 
/*     */     
/*     */     }
/*  74 */     catch (Exception e) {
/*  75 */       throw new InvalidOrderingException("Could not create ordering for " + annotatedTestClass, e);
/*     */     } 
/*     */     
/*  78 */     return definedBy(factory, annotatedTestClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Ordering definedBy(Factory factory, Description annotatedTestClass) throws InvalidOrderingException {
/*  91 */     if (factory == null) {
/*  92 */       throw new NullPointerException("factory cannot be null");
/*     */     }
/*  94 */     if (annotatedTestClass == null) {
/*  95 */       throw new NullPointerException("annotatedTestClass cannot be null");
/*     */     }
/*     */     
/*  98 */     return factory.create(new Context(annotatedTestClass));
/*     */   }
/*     */   
/*     */   private static String getClassName(Class<?> clazz) {
/* 102 */     String name = clazz.getCanonicalName();
/* 103 */     if (name == null) {
/* 104 */       return clazz.getName();
/*     */     }
/* 106 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void apply(Object target) throws InvalidOrderingException {
/* 121 */     if (target instanceof Orderable) {
/* 122 */       Orderable orderable = (Orderable)target;
/* 123 */       orderable.order(new Orderer(this));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean validateOrderingIsCorrect() {
/* 132 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract List<Description> orderItems(Collection<Description> paramCollection);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Context
/*     */   {
/*     */     private final Description description;
/*     */ 
/*     */ 
/*     */     
/*     */     public Description getTarget() {
/* 150 */       return this.description;
/*     */     }
/*     */     
/*     */     private Context(Description description) {
/* 154 */       this.description = description;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Factory {
/*     */     Ordering create(Ordering.Context param1Context);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\manipulation\Ordering.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */