package org.junit.runner.manipulation;

public interface Filterable {
  void filter(Filter paramFilter) throws NoTestsRemainException;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\manipulation\Filterable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */