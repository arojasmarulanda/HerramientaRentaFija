/*     */ package org.junit.runner;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.junit.internal.builders.AllDefaultPossibilitiesBuilder;
/*     */ import org.junit.internal.requests.ClassRequest;
/*     */ import org.junit.internal.requests.FilterRequest;
/*     */ import org.junit.internal.requests.OrderingRequest;
/*     */ import org.junit.internal.requests.SortingRequest;
/*     */ import org.junit.internal.runners.ErrorReportingRunner;
/*     */ import org.junit.runner.manipulation.Filter;
/*     */ import org.junit.runner.manipulation.Ordering;
/*     */ import org.junit.runners.model.InitializationError;
/*     */ import org.junit.runners.model.RunnerBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Request
/*     */ {
/*     */   public static Request method(Class<?> clazz, String methodName) {
/*  40 */     Description method = Description.createTestDescription(clazz, methodName);
/*  41 */     return aClass(clazz).filterWith(method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Request aClass(Class<?> clazz) {
/*  52 */     return (Request)new ClassRequest(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Request classWithoutSuiteMethod(Class<?> clazz) {
/*  63 */     return (Request)new ClassRequest(clazz, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Request classes(Computer computer, Class<?>... classes) {
/*     */     try {
/*  76 */       AllDefaultPossibilitiesBuilder builder = new AllDefaultPossibilitiesBuilder();
/*  77 */       Runner suite = computer.getSuite((RunnerBuilder)builder, classes);
/*  78 */       return runner(suite);
/*  79 */     } catch (InitializationError e) {
/*  80 */       return runner((Runner)new ErrorReportingRunner((Throwable)e, classes));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Request classes(Class<?>... classes) {
/*  92 */     return classes(JUnitCore.defaultComputer(), classes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Request errorReport(Class<?> klass, Throwable cause) {
/* 101 */     return runner((Runner)new ErrorReportingRunner(klass, cause));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Request runner(final Runner runner) {
/* 109 */     return new Request()
/*     */       {
/*     */         public Runner getRunner() {
/* 112 */           return runner;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Runner getRunner();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request filterWith(Filter filter) {
/* 132 */     return (Request)new FilterRequest(this, filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request filterWith(Description desiredDescription) {
/* 146 */     return filterWith(Filter.matchMethodDescription(desiredDescription));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request sortWith(Comparator<Description> comparator) {
/* 172 */     return (Request)new SortingRequest(this, comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request orderWith(Ordering ordering) {
/* 200 */     return (Request)new OrderingRequest(this, ordering);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\Request.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */