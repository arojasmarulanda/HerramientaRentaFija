/*     */ package org.junit.runner;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamClass;
/*     */ import java.io.ObjectStreamField;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.junit.runner.notification.Failure;
/*     */ import org.junit.runner.notification.RunListener;
/*     */ import org.junit.runner.notification.RunListener.ThreadSafe;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Result
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  27 */   private static final ObjectStreamField[] serialPersistentFields = ObjectStreamClass.lookup(SerializedForm.class).getFields();
/*     */   
/*     */   private final AtomicInteger count;
/*     */   
/*     */   private final AtomicInteger ignoreCount;
/*     */   
/*     */   private final AtomicInteger assumptionFailureCount;
/*     */   private final CopyOnWriteArrayList<Failure> failures;
/*     */   private final AtomicLong runTime;
/*     */   private final AtomicLong startTime;
/*     */   private SerializedForm serializedForm;
/*     */   
/*     */   public Result() {
/*  40 */     this.count = new AtomicInteger();
/*  41 */     this.ignoreCount = new AtomicInteger();
/*  42 */     this.assumptionFailureCount = new AtomicInteger();
/*  43 */     this.failures = new CopyOnWriteArrayList<Failure>();
/*  44 */     this.runTime = new AtomicLong();
/*  45 */     this.startTime = new AtomicLong();
/*     */   }
/*     */   
/*     */   private Result(SerializedForm serializedForm) {
/*  49 */     this.count = serializedForm.fCount;
/*  50 */     this.ignoreCount = serializedForm.fIgnoreCount;
/*  51 */     this.assumptionFailureCount = serializedForm.assumptionFailureCount;
/*  52 */     this.failures = new CopyOnWriteArrayList<Failure>(serializedForm.fFailures);
/*  53 */     this.runTime = new AtomicLong(serializedForm.fRunTime);
/*  54 */     this.startTime = new AtomicLong(serializedForm.fStartTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRunCount() {
/*  61 */     return this.count.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFailureCount() {
/*  68 */     return this.failures.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getRunTime() {
/*  75 */     return this.runTime.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Failure> getFailures() {
/*  82 */     return this.failures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIgnoreCount() {
/*  89 */     return this.ignoreCount.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAssumptionFailureCount() {
/*  99 */     if (this.assumptionFailureCount == null) {
/* 100 */       throw new UnsupportedOperationException("Result was serialized from a version of JUnit that doesn't support this method");
/*     */     }
/*     */     
/* 103 */     return this.assumptionFailureCount.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean wasSuccessful() {
/* 110 */     return (getFailureCount() == 0);
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream s) throws IOException {
/* 114 */     SerializedForm serializedForm = new SerializedForm(this);
/* 115 */     serializedForm.serialize(s);
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream s) throws ClassNotFoundException, IOException {
/* 120 */     this.serializedForm = SerializedForm.deserialize(s);
/*     */   }
/*     */   
/*     */   private Object readResolve() {
/* 124 */     return new Result(this.serializedForm);
/*     */   }
/*     */   
/*     */   @ThreadSafe
/*     */   private class Listener
/*     */     extends RunListener {
/*     */     public void testRunStarted(Description description) throws Exception {
/* 131 */       Result.this.startTime.set(System.currentTimeMillis());
/*     */     }
/*     */     private Listener() {}
/*     */     
/*     */     public void testRunFinished(Result result) throws Exception {
/* 136 */       long endTime = System.currentTimeMillis();
/* 137 */       Result.this.runTime.addAndGet(endTime - Result.this.startTime.get());
/*     */     }
/*     */ 
/*     */     
/*     */     public void testFinished(Description description) throws Exception {
/* 142 */       Result.this.count.getAndIncrement();
/*     */     }
/*     */ 
/*     */     
/*     */     public void testFailure(Failure failure) throws Exception {
/* 147 */       Result.this.failures.add(failure);
/*     */     }
/*     */ 
/*     */     
/*     */     public void testIgnored(Description description) throws Exception {
/* 152 */       Result.this.ignoreCount.getAndIncrement();
/*     */     }
/*     */ 
/*     */     
/*     */     public void testAssumptionFailure(Failure failure) {
/* 157 */       Result.this.assumptionFailureCount.getAndIncrement();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RunListener createListener() {
/* 165 */     return new Listener();
/*     */   }
/*     */ 
/*     */   
/*     */   private static class SerializedForm
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private final AtomicInteger fCount;
/*     */     private final AtomicInteger fIgnoreCount;
/*     */     private final AtomicInteger assumptionFailureCount;
/*     */     private final List<Failure> fFailures;
/*     */     private final long fRunTime;
/*     */     private final long fStartTime;
/*     */     
/*     */     public SerializedForm(Result result) {
/* 182 */       this.fCount = result.count;
/* 183 */       this.fIgnoreCount = result.ignoreCount;
/* 184 */       this.assumptionFailureCount = result.assumptionFailureCount;
/* 185 */       this.fFailures = Collections.synchronizedList(new ArrayList<Failure>(result.failures));
/* 186 */       this.fRunTime = result.runTime.longValue();
/* 187 */       this.fStartTime = result.startTime.longValue();
/*     */     }
/*     */ 
/*     */     
/*     */     private SerializedForm(ObjectInputStream.GetField fields) throws IOException {
/* 192 */       this.fCount = (AtomicInteger)fields.get("fCount", (Object)null);
/* 193 */       this.fIgnoreCount = (AtomicInteger)fields.get("fIgnoreCount", (Object)null);
/* 194 */       this.assumptionFailureCount = (AtomicInteger)fields.get("assumptionFailureCount", (Object)null);
/* 195 */       this.fFailures = (List<Failure>)fields.get("fFailures", (Object)null);
/* 196 */       this.fRunTime = fields.get("fRunTime", 0L);
/* 197 */       this.fStartTime = fields.get("fStartTime", 0L);
/*     */     }
/*     */     
/*     */     public void serialize(ObjectOutputStream s) throws IOException {
/* 201 */       ObjectOutputStream.PutField fields = s.putFields();
/* 202 */       fields.put("fCount", this.fCount);
/* 203 */       fields.put("fIgnoreCount", this.fIgnoreCount);
/* 204 */       fields.put("fFailures", this.fFailures);
/* 205 */       fields.put("fRunTime", this.fRunTime);
/* 206 */       fields.put("fStartTime", this.fStartTime);
/* 207 */       fields.put("assumptionFailureCount", this.assumptionFailureCount);
/* 208 */       s.writeFields();
/*     */     }
/*     */ 
/*     */     
/*     */     public static SerializedForm deserialize(ObjectInputStream s) throws ClassNotFoundException, IOException {
/* 213 */       ObjectInputStream.GetField fields = s.readFields();
/* 214 */       return new SerializedForm(fields);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\runner\Result.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */