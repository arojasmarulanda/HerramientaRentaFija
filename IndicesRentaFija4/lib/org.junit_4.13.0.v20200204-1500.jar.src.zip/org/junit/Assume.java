/*     */ package org.junit;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.hamcrest.CoreMatchers;
/*     */ import org.hamcrest.Matcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Assume
/*     */ {
/*     */   public static void assumeTrue(boolean b) {
/*  50 */     assumeThat(Boolean.valueOf(b), CoreMatchers.is(Boolean.valueOf(true)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assumeFalse(boolean b) {
/*  57 */     assumeThat(Boolean.valueOf(b), CoreMatchers.is(Boolean.valueOf(false)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assumeTrue(String message, boolean b) {
/*  68 */     if (!b) throw new AssumptionViolatedException(message);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assumeFalse(String message, boolean b) {
/*  75 */     assumeTrue(message, !b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assumeNotNull(Object... objects) {
/*  83 */     assumeThat(objects, CoreMatchers.notNullValue());
/*  84 */     assumeThat(Arrays.asList(objects), CoreMatchers.everyItem(CoreMatchers.notNullValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> void assumeThat(T actual, Matcher<T> matcher) {
/* 105 */     if (!matcher.matches(actual)) {
/* 106 */       throw new AssumptionViolatedException(actual, matcher);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> void assumeThat(String message, T actual, Matcher<T> matcher) {
/* 128 */     if (!matcher.matches(actual)) {
/* 129 */       throw new AssumptionViolatedException(message, actual, matcher);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assumeNoException(Throwable e) {
/* 153 */     assumeThat(e, CoreMatchers.nullValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assumeNoException(String message, Throwable e) {
/* 167 */     assumeThat(message, e, CoreMatchers.nullValue());
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\Assume.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */