/*     */ package org.junit.rules;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.junit.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemporaryFolder
/*     */   extends ExternalResource
/*     */ {
/*     */   private final File parentFolder;
/*     */   private final boolean assureDeletion;
/*     */   private File folder;
/*     */   private static final int TEMP_DIR_ATTEMPTS = 10000;
/*     */   private static final String TMP_PREFIX = "junit";
/*     */   
/*     */   public TemporaryFolder() {
/*  55 */     this((File)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemporaryFolder(File parentFolder) {
/*  66 */     this.parentFolder = parentFolder;
/*  67 */     this.assureDeletion = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TemporaryFolder(Builder builder) {
/*  75 */     this.parentFolder = builder.parentFolder;
/*  76 */     this.assureDeletion = builder.assureDeletion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/*  85 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private File parentFolder;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean assureDeletion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder parentFolder(File parentFolder) {
/* 107 */       this.parentFolder = parentFolder;
/* 108 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder assureDeletion() {
/* 119 */       this.assureDeletion = true;
/* 120 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TemporaryFolder build() {
/* 127 */       return new TemporaryFolder(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void before() throws Throwable {
/* 133 */     create();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void after() {
/* 138 */     delete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void create() throws IOException {
/* 147 */     this.folder = createTemporaryFolderIn(this.parentFolder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File newFile(String fileName) throws IOException {
/* 154 */     File file = new File(getRoot(), fileName);
/* 155 */     if (!file.createNewFile()) {
/* 156 */       throw new IOException("a file with the name '" + fileName + "' already exists in the test folder");
/*     */     }
/*     */     
/* 159 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File newFile() throws IOException {
/* 166 */     return File.createTempFile("junit", null, getRoot());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File newFolder(String path) throws IOException {
/* 174 */     return newFolder(new String[] { path });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File newFolder(String... paths) throws IOException {
/* 185 */     if (paths.length == 0) {
/* 186 */       throw new IllegalArgumentException("must pass at least one path");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     File root = getRoot();
/* 194 */     for (String path : paths) {
/* 195 */       if ((new File(path)).isAbsolute()) {
/* 196 */         throw new IOException("folder path '" + path + "' is not a relative path");
/*     */       }
/*     */     } 
/*     */     
/* 200 */     File relativePath = null;
/* 201 */     File file = root;
/* 202 */     boolean lastMkdirsCallSuccessful = true;
/* 203 */     for (String path : paths) {
/* 204 */       relativePath = new File(relativePath, path);
/* 205 */       file = new File(root, relativePath.getPath());
/*     */       
/* 207 */       lastMkdirsCallSuccessful = file.mkdirs();
/* 208 */       if (!lastMkdirsCallSuccessful && !file.isDirectory()) {
/* 209 */         if (file.exists()) {
/* 210 */           throw new IOException("a file with the path '" + relativePath.getPath() + "' exists");
/*     */         }
/*     */         
/* 213 */         throw new IOException("could not create a folder with the path '" + relativePath.getPath() + "'");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 218 */     if (!lastMkdirsCallSuccessful) {
/* 219 */       throw new IOException("a folder with the path '" + relativePath.getPath() + "' already exists");
/*     */     }
/*     */     
/* 222 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File newFolder() throws IOException {
/* 229 */     return createTemporaryFolderIn(getRoot());
/*     */   }
/*     */   
/*     */   private File createTemporaryFolderIn(File parentFolder) throws IOException {
/* 233 */     File createdFolder = null;
/* 234 */     for (int i = 0; i < 10000; i++) {
/*     */       
/* 236 */       String suffix = ".tmp";
/* 237 */       File tmpFile = File.createTempFile("junit", suffix, parentFolder);
/* 238 */       String tmpName = tmpFile.toString();
/*     */       
/* 240 */       String folderName = tmpName.substring(0, tmpName.length() - suffix.length());
/* 241 */       createdFolder = new File(folderName);
/* 242 */       if (createdFolder.mkdir()) {
/* 243 */         tmpFile.delete();
/* 244 */         return createdFolder;
/*     */       } 
/* 246 */       tmpFile.delete();
/*     */     } 
/* 248 */     throw new IOException("Unable to create temporary directory in: " + parentFolder.toString() + ". Tried " + '✐' + " times. " + "Last attempted to create: " + createdFolder.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getRoot() {
/* 257 */     if (this.folder == null) {
/* 258 */       throw new IllegalStateException("the temporary folder has not yet been created");
/*     */     }
/*     */     
/* 261 */     return this.folder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete() {
/* 272 */     if (!tryDelete() && 
/* 273 */       this.assureDeletion) {
/* 274 */       Assert.fail("Unable to clean up temporary folder " + this.folder);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean tryDelete() {
/* 287 */     if (this.folder == null) {
/* 288 */       return true;
/*     */     }
/*     */     
/* 291 */     return recursiveDelete(this.folder);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean recursiveDelete(File file) {
/* 297 */     if (file.delete()) {
/* 298 */       return true;
/*     */     }
/* 300 */     File[] files = file.listFiles();
/* 301 */     if (files != null) {
/* 302 */       for (File each : files) {
/* 303 */         if (!recursiveDelete(each)) {
/* 304 */           return false;
/*     */         }
/*     */       } 
/*     */     }
/* 308 */     return file.delete();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\rules\TemporaryFolder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */