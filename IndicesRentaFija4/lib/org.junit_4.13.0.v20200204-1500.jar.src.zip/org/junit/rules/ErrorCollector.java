/*     */ package org.junit.rules;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import org.hamcrest.Matcher;
/*     */ import org.junit.Assert;
/*     */ import org.junit.function.ThrowingRunnable;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.runners.model.MultipleFailureException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorCollector
/*     */   extends Verifier
/*     */ {
/*  38 */   private List<Throwable> errors = new ArrayList<Throwable>();
/*     */ 
/*     */   
/*     */   protected void verify() throws Throwable {
/*  42 */     MultipleFailureException.assertEmpty(this.errors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addError(Throwable error) {
/*  49 */     if (error == null) {
/*  50 */       throw new NullPointerException("Error cannot be null");
/*     */     }
/*  52 */     if (error instanceof AssumptionViolatedException) {
/*  53 */       AssertionError e = new AssertionError(error.getMessage());
/*  54 */       e.initCause(error);
/*  55 */       this.errors.add(e);
/*     */     } else {
/*  57 */       this.errors.add(error);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void checkThat(T value, Matcher<T> matcher) {
/*  66 */     checkThat("", value, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void checkThat(final String reason, final T value, final Matcher<T> matcher) {
/*  75 */     checkSucceeds(new Callable() {
/*     */           public Object call() throws Exception {
/*  77 */             Assert.assertThat(reason, value, matcher);
/*  78 */             return value;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T checkSucceeds(Callable<T> callable) {
/*     */     try {
/*  90 */       return callable.call();
/*  91 */     } catch (AssumptionViolatedException e) {
/*  92 */       AssertionError error = new AssertionError("Callable threw AssumptionViolatedException");
/*  93 */       error.initCause((Throwable)e);
/*  94 */       addError(error);
/*  95 */       return null;
/*  96 */     } catch (Throwable e) {
/*  97 */       addError(e);
/*  98 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkThrows(Class<? extends Throwable> expectedThrowable, ThrowingRunnable runnable) {
/*     */     try {
/* 114 */       Assert.assertThrows(expectedThrowable, runnable);
/* 115 */     } catch (AssertionError e) {
/* 116 */       addError(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\rules\ErrorCollector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */