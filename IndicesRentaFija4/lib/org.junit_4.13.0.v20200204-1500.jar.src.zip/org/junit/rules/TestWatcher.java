/*     */ package org.junit.rules;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.junit.AssumptionViolatedException;
/*     */ import org.junit.internal.AssumptionViolatedException;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runners.model.MultipleFailureException;
/*     */ import org.junit.runners.model.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TestWatcher
/*     */   implements TestRule
/*     */ {
/*     */   public Statement apply(final Statement base, final Description description) {
/*  54 */     return new Statement()
/*     */       {
/*     */         public void evaluate() throws Throwable {
/*  57 */           List<Throwable> errors = new ArrayList<Throwable>();
/*     */           
/*  59 */           TestWatcher.this.startingQuietly(description, errors);
/*     */           try {
/*  61 */             base.evaluate();
/*  62 */             TestWatcher.this.succeededQuietly(description, errors);
/*  63 */           } catch (AssumptionViolatedException e) {
/*  64 */             errors.add(e);
/*  65 */             TestWatcher.this.skippedQuietly(e, description, errors);
/*  66 */           } catch (Throwable e) {
/*  67 */             errors.add(e);
/*  68 */             TestWatcher.this.failedQuietly(e, description, errors);
/*     */           } finally {
/*  70 */             TestWatcher.this.finishedQuietly(description, errors);
/*     */           } 
/*     */           
/*  73 */           MultipleFailureException.assertEmpty(errors);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   private void succeededQuietly(Description description, List<Throwable> errors) {
/*     */     try {
/*  81 */       succeeded(description);
/*  82 */     } catch (Throwable e) {
/*  83 */       errors.add(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void failedQuietly(Throwable e, Description description, List<Throwable> errors) {
/*     */     try {
/*  90 */       failed(e, description);
/*  91 */     } catch (Throwable e1) {
/*  92 */       errors.add(e1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void skippedQuietly(AssumptionViolatedException e, Description description, List<Throwable> errors) {
/*     */     try {
/* 100 */       if (e instanceof AssumptionViolatedException) {
/* 101 */         skipped((AssumptionViolatedException)e, description);
/*     */       } else {
/* 103 */         skipped(e, description);
/*     */       } 
/* 105 */     } catch (Throwable e1) {
/* 106 */       errors.add(e1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void startingQuietly(Description description, List<Throwable> errors) {
/*     */     try {
/* 113 */       starting(description);
/* 114 */     } catch (Throwable e) {
/* 115 */       errors.add(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void finishedQuietly(Description description, List<Throwable> errors) {
/*     */     try {
/* 122 */       finished(description);
/* 123 */     } catch (Throwable e) {
/* 124 */       errors.add(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void succeeded(Description description) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void failed(Throwable e, Description description) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void skipped(AssumptionViolatedException e, Description description) {
/* 145 */     AssumptionViolatedException assumptionViolatedException = e;
/* 146 */     skipped((AssumptionViolatedException)assumptionViolatedException, description);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected void skipped(AssumptionViolatedException e, Description description) {}
/*     */   
/*     */   protected void starting(Description description) {}
/*     */   
/*     */   protected void finished(Description description) {}
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\rules\TestWatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */