/*     */ package org.junit.rules;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runners.model.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuleChain
/*     */   implements TestRule
/*     */ {
/*  59 */   private static final RuleChain EMPTY_CHAIN = new RuleChain(Collections.emptyList());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<TestRule> rulesStartingWithInnerMost;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuleChain emptyRuleChain() {
/*  71 */     return EMPTY_CHAIN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RuleChain outerRule(TestRule outerRule) {
/*  82 */     return emptyRuleChain().around(outerRule);
/*     */   }
/*     */   
/*     */   private RuleChain(List<TestRule> rules) {
/*  86 */     this.rulesStartingWithInnerMost = rules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleChain around(TestRule enclosedRule) {
/*  98 */     if (enclosedRule == null) {
/*  99 */       throw new NullPointerException("The enclosed rule must not be null");
/*     */     }
/* 101 */     List<TestRule> rulesOfNewChain = new ArrayList<TestRule>();
/* 102 */     rulesOfNewChain.add(enclosedRule);
/* 103 */     rulesOfNewChain.addAll(this.rulesStartingWithInnerMost);
/* 104 */     return new RuleChain(rulesOfNewChain);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement apply(Statement base, Description description) {
/* 111 */     return new RunRules(base, this.rulesStartingWithInnerMost, description);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\rules\RuleChain.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */