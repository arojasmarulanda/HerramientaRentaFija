/*    */ package org.junit.rules;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.junit.runner.Description;
/*    */ import org.junit.runners.model.MultipleFailureException;
/*    */ import org.junit.runners.model.Statement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ExternalResource
/*    */   implements TestRule
/*    */ {
/*    */   public Statement apply(Statement base, Description description) {
/* 43 */     return statement(base);
/*    */   }
/*    */   
/*    */   private Statement statement(final Statement base) {
/* 47 */     return new Statement()
/*    */       {
/*    */         public void evaluate() throws Throwable {
/* 50 */           ExternalResource.this.before();
/*    */           
/* 52 */           List<Throwable> errors = new ArrayList<Throwable>();
/*    */           try {
/* 54 */             base.evaluate();
/* 55 */           } catch (Throwable t) {
/* 56 */             errors.add(t);
/*    */           } finally {
/*    */             try {
/* 59 */               ExternalResource.this.after();
/* 60 */             } catch (Throwable t) {
/* 61 */               errors.add(t);
/*    */             } 
/*    */           } 
/* 64 */           MultipleFailureException.assertEmpty(errors);
/*    */         }
/*    */       };
/*    */   }
/*    */   
/*    */   protected void before() throws Throwable {}
/*    */   
/*    */   protected void after() {}
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\rules\ExternalResource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */