/*     */ package org.junit.rules;
/*     */ 
/*     */ import org.hamcrest.CoreMatchers;
/*     */ import org.hamcrest.Matcher;
/*     */ import org.hamcrest.SelfDescribing;
/*     */ import org.hamcrest.StringDescription;
/*     */ import org.junit.Assert;
/*     */ import org.junit.internal.matchers.ThrowableCauseMatcher;
/*     */ import org.junit.internal.matchers.ThrowableMessageMatcher;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runners.model.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpectedException
/*     */   implements TestRule
/*     */ {
/*     */   @Deprecated
/*     */   public static ExpectedException none() {
/* 123 */     return new ExpectedException();
/*     */   }
/*     */   
/* 126 */   private final ExpectedExceptionMatcherBuilder matcherBuilder = new ExpectedExceptionMatcherBuilder();
/*     */   
/* 128 */   private String missingExceptionMessage = "Expected test to throw %s";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ExpectedException handleAssertionErrors() {
/* 140 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ExpectedException handleAssumptionViolatedExceptions() {
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpectedException reportMissingExceptionWithMessage(String message) {
/* 164 */     this.missingExceptionMessage = message;
/* 165 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Statement apply(Statement base, Description description) {
/* 170 */     return new ExpectedExceptionStatement(base);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expect(Matcher<?> matcher) {
/* 184 */     this.matcherBuilder.add(matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expect(Class<? extends Throwable> type) {
/* 197 */     expect(CoreMatchers.instanceOf(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expectMessage(String substring) {
/* 210 */     expectMessage(CoreMatchers.containsString(substring));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expectMessage(Matcher<String> matcher) {
/* 223 */     expect(ThrowableMessageMatcher.hasMessage(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expectCause(Matcher<?> expectedCause) {
/* 237 */     expect(ThrowableCauseMatcher.hasCause(expectedCause));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isAnyExceptionExpected() {
/* 245 */     return this.matcherBuilder.expectsThrowable();
/*     */   }
/*     */   
/*     */   private class ExpectedExceptionStatement extends Statement {
/*     */     private final Statement next;
/*     */     
/*     */     public ExpectedExceptionStatement(Statement base) {
/* 252 */       this.next = base;
/*     */     }
/*     */ 
/*     */     
/*     */     public void evaluate() throws Throwable {
/*     */       try {
/* 258 */         this.next.evaluate();
/* 259 */       } catch (Throwable e) {
/* 260 */         ExpectedException.this.handleException(e);
/*     */         return;
/*     */       } 
/* 263 */       if (ExpectedException.this.isAnyExceptionExpected()) {
/* 264 */         ExpectedException.this.failDueToMissingException();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleException(Throwable e) throws Throwable {
/* 270 */     if (isAnyExceptionExpected()) {
/* 271 */       Assert.assertThat(e, this.matcherBuilder.build());
/*     */     } else {
/* 273 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void failDueToMissingException() throws AssertionError {
/* 278 */     Assert.fail(missingExceptionMessage());
/*     */   }
/*     */   
/*     */   private String missingExceptionMessage() {
/* 282 */     String expectation = StringDescription.toString((SelfDescribing)this.matcherBuilder.build());
/* 283 */     return String.format(this.missingExceptionMessage, new Object[] { expectation });
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\rules\ExpectedException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */