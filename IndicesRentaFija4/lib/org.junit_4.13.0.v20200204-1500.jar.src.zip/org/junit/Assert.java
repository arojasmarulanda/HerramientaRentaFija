/*      */ package org.junit;
/*      */ 
/*      */ import org.hamcrest.Matcher;
/*      */ import org.hamcrest.MatcherAssert;
/*      */ import org.junit.function.ThrowingRunnable;
/*      */ import org.junit.internal.ArrayComparisonFailure;
/*      */ import org.junit.internal.ExactComparisonCriteria;
/*      */ import org.junit.internal.InexactComparisonCriteria;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Assert
/*      */ {
/*      */   public static void assertTrue(String message, boolean condition) {
/*   41 */     if (!condition) {
/*   42 */       fail(message);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertTrue(boolean condition) {
/*   53 */     assertTrue(null, condition);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertFalse(String message, boolean condition) {
/*   65 */     assertTrue(message, !condition);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertFalse(boolean condition) {
/*   75 */     assertFalse(null, condition);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void fail(String message) {
/*   86 */     if (message == null) {
/*   87 */       throw new AssertionError();
/*      */     }
/*   89 */     throw new AssertionError(message);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void fail() {
/*   96 */     fail(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, Object expected, Object actual) {
/*  112 */     if (equalsRegardingNull(expected, actual)) {
/*      */       return;
/*      */     }
/*  115 */     if (expected instanceof String && actual instanceof String) {
/*  116 */       String cleanMessage = (message == null) ? "" : message;
/*  117 */       throw new ComparisonFailure(cleanMessage, (String)expected, (String)actual);
/*      */     } 
/*      */     
/*  120 */     failNotEquals(message, expected, actual);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean equalsRegardingNull(Object expected, Object actual) {
/*  125 */     if (expected == null) {
/*  126 */       return (actual == null);
/*      */     }
/*      */     
/*  129 */     return isEquals(expected, actual);
/*      */   }
/*      */   
/*      */   private static boolean isEquals(Object expected, Object actual) {
/*  133 */     return expected.equals(actual);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(Object expected, Object actual) {
/*  146 */     assertEquals((String)null, expected, actual);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotEquals(String message, Object unexpected, Object actual) {
/*  162 */     if (equalsRegardingNull(unexpected, actual)) {
/*  163 */       failEquals(message, actual);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotEquals(Object unexpected, Object actual) {
/*  177 */     assertNotEquals((String)null, unexpected, actual);
/*      */   }
/*      */   
/*      */   private static void failEquals(String message, Object actual) {
/*  181 */     String formatted = "Values should be different. ";
/*  182 */     if (message != null) {
/*  183 */       formatted = message + ". ";
/*      */     }
/*      */     
/*  186 */     formatted = formatted + "Actual: " + actual;
/*  187 */     fail(formatted);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotEquals(String message, long unexpected, long actual) {
/*  200 */     if (unexpected == actual) {
/*  201 */       failEquals(message, Long.valueOf(actual));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotEquals(long unexpected, long actual) {
/*  213 */     assertNotEquals((String)null, unexpected, actual);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotEquals(String message, double unexpected, double actual, double delta) {
/*  233 */     if (!doubleIsDifferent(unexpected, actual, delta)) {
/*  234 */       failEquals(message, Double.valueOf(actual));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotEquals(double unexpected, double actual, double delta) {
/*  251 */     assertNotEquals((String)null, unexpected, actual, delta);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotEquals(float unexpected, float actual, float delta) {
/*  267 */     assertNotEquals((String)null, unexpected, actual, delta);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(String message, Object[] expecteds, Object[] actuals) throws ArrayComparisonFailure {
/*  285 */     internalArrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(Object[] expecteds, Object[] actuals) {
/*  300 */     assertArrayEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(String message, boolean[] expecteds, boolean[] actuals) throws ArrayComparisonFailure {
/*  316 */     internalArrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(boolean[] expecteds, boolean[] actuals) {
/*  329 */     assertArrayEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(String message, byte[] expecteds, byte[] actuals) throws ArrayComparisonFailure {
/*  343 */     internalArrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(byte[] expecteds, byte[] actuals) {
/*  354 */     assertArrayEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(String message, char[] expecteds, char[] actuals) throws ArrayComparisonFailure {
/*  368 */     internalArrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(char[] expecteds, char[] actuals) {
/*  379 */     assertArrayEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(String message, short[] expecteds, short[] actuals) throws ArrayComparisonFailure {
/*  393 */     internalArrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(short[] expecteds, short[] actuals) {
/*  404 */     assertArrayEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(String message, int[] expecteds, int[] actuals) throws ArrayComparisonFailure {
/*  418 */     internalArrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(int[] expecteds, int[] actuals) {
/*  429 */     assertArrayEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(String message, long[] expecteds, long[] actuals) throws ArrayComparisonFailure {
/*  443 */     internalArrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(long[] expecteds, long[] actuals) {
/*  454 */     assertArrayEquals((String)null, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(String message, double[] expecteds, double[] actuals, double delta) throws ArrayComparisonFailure {
/*  471 */     (new InexactComparisonCriteria(delta)).arrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(double[] expecteds, double[] actuals, double delta) {
/*  485 */     assertArrayEquals((String)null, expecteds, actuals, delta);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(String message, float[] expecteds, float[] actuals, float delta) throws ArrayComparisonFailure {
/*  502 */     (new InexactComparisonCriteria(delta)).arrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertArrayEquals(float[] expecteds, float[] actuals, float delta) {
/*  516 */     assertArrayEquals((String)null, expecteds, actuals, delta);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void internalArrayEquals(String message, Object expecteds, Object actuals) throws ArrayComparisonFailure {
/*  534 */     (new ExactComparisonCriteria()).arrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, double expected, double actual, double delta) {
/*  554 */     if (doubleIsDifferent(expected, actual, delta)) {
/*  555 */       failNotEquals(message, Double.valueOf(expected), Double.valueOf(actual));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, float expected, float actual, float delta) {
/*  576 */     if (floatIsDifferent(expected, actual, delta)) {
/*  577 */       failNotEquals(message, Float.valueOf(expected), Float.valueOf(actual));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotEquals(String message, float unexpected, float actual, float delta) {
/*  598 */     if (!floatIsDifferent(unexpected, actual, delta)) {
/*  599 */       failEquals(message, Float.valueOf(actual));
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean doubleIsDifferent(double d1, double d2, double delta) {
/*  604 */     if (Double.compare(d1, d2) == 0) {
/*  605 */       return false;
/*      */     }
/*  607 */     if (Math.abs(d1 - d2) <= delta) {
/*  608 */       return false;
/*      */     }
/*      */     
/*  611 */     return true;
/*      */   }
/*      */   
/*      */   private static boolean floatIsDifferent(float f1, float f2, float delta) {
/*  615 */     if (Float.compare(f1, f2) == 0) {
/*  616 */       return false;
/*      */     }
/*  618 */     if (Math.abs(f1 - f2) <= delta) {
/*  619 */       return false;
/*      */     }
/*      */     
/*  622 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(long expected, long actual) {
/*  633 */     assertEquals((String)null, expected, actual);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(String message, long expected, long actual) {
/*  646 */     if (expected != actual) {
/*  647 */       failNotEquals(message, Long.valueOf(expected), Long.valueOf(actual));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void assertEquals(double expected, double actual) {
/*  658 */     assertEquals((String)null, expected, actual);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void assertEquals(String message, double expected, double actual) {
/*  669 */     fail("Use assertEquals(expected, actual, delta) to compare floating-point numbers");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(double expected, double actual, double delta) {
/*  685 */     assertEquals((String)null, expected, actual, delta);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertEquals(float expected, float actual, float delta) {
/*  701 */     assertEquals((String)null, expected, actual, delta);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotNull(String message, Object object) {
/*  713 */     assertTrue(message, (object != null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotNull(Object object) {
/*  723 */     assertNotNull(null, object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNull(String message, Object object) {
/*  735 */     if (object == null) {
/*      */       return;
/*      */     }
/*  738 */     failNotNull(message, object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNull(Object object) {
/*  748 */     assertNull(null, object);
/*      */   }
/*      */   
/*      */   private static void failNotNull(String message, Object actual) {
/*  752 */     String formatted = "";
/*  753 */     if (message != null) {
/*  754 */       formatted = message + " ";
/*      */     }
/*  756 */     fail(formatted + "expected null, but was:<" + actual + ">");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertSame(String message, Object expected, Object actual) {
/*  769 */     if (expected == actual) {
/*      */       return;
/*      */     }
/*  772 */     failNotSame(message, expected, actual);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertSame(Object expected, Object actual) {
/*  783 */     assertSame(null, expected, actual);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotSame(String message, Object unexpected, Object actual) {
/*  798 */     if (unexpected == actual) {
/*  799 */       failSame(message);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void assertNotSame(Object unexpected, Object actual) {
/*  812 */     assertNotSame(null, unexpected, actual);
/*      */   }
/*      */   
/*      */   private static void failSame(String message) {
/*  816 */     String formatted = "";
/*  817 */     if (message != null) {
/*  818 */       formatted = message + " ";
/*      */     }
/*  820 */     fail(formatted + "expected not same");
/*      */   }
/*      */ 
/*      */   
/*      */   private static void failNotSame(String message, Object expected, Object actual) {
/*  825 */     String formatted = "";
/*  826 */     if (message != null) {
/*  827 */       formatted = message + " ";
/*      */     }
/*  829 */     fail(formatted + "expected same:<" + expected + "> was not:<" + actual + ">");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void failNotEquals(String message, Object expected, Object actual) {
/*  835 */     fail(format(message, expected, actual));
/*      */   }
/*      */   
/*      */   static String format(String message, Object expected, Object actual) {
/*  839 */     String formatted = "";
/*  840 */     if (message != null && !"".equals(message)) {
/*  841 */       formatted = message + " ";
/*      */     }
/*  843 */     String expectedString = String.valueOf(expected);
/*  844 */     String actualString = String.valueOf(actual);
/*  845 */     if (equalsRegardingNull(expectedString, actualString)) {
/*  846 */       return formatted + "expected: " + formatClassAndValue(expected, expectedString) + " but was: " + formatClassAndValue(actual, actualString);
/*      */     }
/*      */ 
/*      */     
/*  850 */     return formatted + "expected:<" + expectedString + "> but was:<" + actualString + ">";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static String formatClass(Class<?> value) {
/*  856 */     String className = value.getCanonicalName();
/*  857 */     return (className == null) ? value.getName() : className;
/*      */   }
/*      */   
/*      */   private static String formatClassAndValue(Object value, String valueString) {
/*  861 */     String className = (value == null) ? "null" : value.getClass().getName();
/*  862 */     return className + "<" + valueString + ">";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void assertEquals(String message, Object[] expecteds, Object[] actuals) {
/*  882 */     assertArrayEquals(message, expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void assertEquals(Object[] expecteds, Object[] actuals) {
/*  899 */     assertArrayEquals(expecteds, actuals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> void assertThat(T actual, Matcher<? super T> matcher) {
/*  930 */     assertThat("", actual, matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static <T> void assertThat(String reason, T actual, Matcher<? super T> matcher) {
/*  964 */     MatcherAssert.assertThat(reason, actual, matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Throwable> T assertThrows(Class<T> expectedThrowable, ThrowingRunnable runnable) {
/*  981 */     return assertThrows(null, expectedThrowable, runnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Throwable> T assertThrows(String message, Class<T> expectedThrowable, ThrowingRunnable runnable) {
/*      */     try {
/* 1001 */       runnable.run();
/* 1002 */     } catch (Throwable actualThrown) {
/* 1003 */       if (expectedThrowable.isInstance(actualThrown)) {
/* 1004 */         return (T)actualThrown;
/*      */       }
/*      */       
/* 1007 */       String expected = formatClass(expectedThrowable);
/* 1008 */       Class<? extends Throwable> actualThrowable = (Class)actualThrown.getClass();
/* 1009 */       String actual = formatClass(actualThrowable);
/* 1010 */       if (expected.equals(actual)) {
/*      */ 
/*      */         
/* 1013 */         expected = expected + "@" + Integer.toHexString(System.identityHashCode(expectedThrowable));
/* 1014 */         actual = actual + "@" + Integer.toHexString(System.identityHashCode(actualThrowable));
/*      */       } 
/* 1016 */       String mismatchMessage = buildPrefix(message) + format("unexpected exception type thrown;", expected, actual);
/*      */ 
/*      */ 
/*      */       
/* 1020 */       AssertionError assertionError = new AssertionError(mismatchMessage);
/* 1021 */       assertionError.initCause(actualThrown);
/* 1022 */       throw assertionError;
/*      */     } 
/*      */     
/* 1025 */     String notThrownMessage = buildPrefix(message) + String.format("expected %s to be thrown, but nothing was thrown", new Object[] { formatClass(expectedThrowable) });
/*      */ 
/*      */     
/* 1028 */     throw new AssertionError(notThrownMessage);
/*      */   }
/*      */   
/*      */   private static String buildPrefix(String message) {
/* 1032 */     return (message != null && message.length() != 0) ? (message + ": ") : "";
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\org\junit\Assert.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */