package junit.framework;

public interface Test {
  int countTestCases();
  
  void run(TestResult paramTestResult);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\junit\framework\Test.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */