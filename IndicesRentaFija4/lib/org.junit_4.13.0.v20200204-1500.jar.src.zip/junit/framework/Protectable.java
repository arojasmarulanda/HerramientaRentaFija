package junit.framework;

public interface Protectable {
  void protect() throws Throwable;
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\junit\framework\Protectable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */