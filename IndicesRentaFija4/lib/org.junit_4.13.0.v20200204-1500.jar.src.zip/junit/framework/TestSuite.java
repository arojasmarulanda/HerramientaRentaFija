/*     */ package junit.framework;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import org.junit.internal.MethodSorter;
/*     */ import org.junit.internal.Throwables;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestSuite
/*     */   implements Test
/*     */ {
/*     */   private String fName;
/*     */   
/*     */   public static Test createTest(Class<?> theClass, String name) {
/*     */     Constructor<?> constructor;
/*     */     Object test;
/*     */     try {
/*  52 */       constructor = getTestConstructor(theClass);
/*  53 */     } catch (NoSuchMethodException e) {
/*  54 */       return warning("Class " + theClass.getName() + " has no public constructor TestCase(String name) or TestCase()");
/*     */     } 
/*     */     
/*     */     try {
/*  58 */       if ((constructor.getParameterTypes()).length == 0) {
/*  59 */         test = constructor.newInstance(new Object[0]);
/*  60 */         if (test instanceof TestCase) {
/*  61 */           ((TestCase)test).setName(name);
/*     */         }
/*     */       } else {
/*  64 */         test = constructor.newInstance(new Object[] { name });
/*     */       } 
/*  66 */     } catch (InstantiationException e) {
/*  67 */       return warning("Cannot instantiate test case: " + name + " (" + Throwables.getStacktrace(e) + ")");
/*  68 */     } catch (InvocationTargetException e) {
/*  69 */       return warning("Exception in constructor: " + name + " (" + Throwables.getStacktrace(e.getTargetException()) + ")");
/*  70 */     } catch (IllegalAccessException e) {
/*  71 */       return warning("Cannot access test case: " + name + " (" + Throwables.getStacktrace(e) + ")");
/*     */     } 
/*  73 */     return (Test)test;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Constructor<?> getTestConstructor(Class<?> theClass) throws NoSuchMethodException {
/*     */     try {
/*  82 */       return theClass.getConstructor(new Class[] { String.class });
/*  83 */     } catch (NoSuchMethodException e) {
/*     */ 
/*     */       
/*  86 */       return theClass.getConstructor(new Class[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Test warning(final String message) {
/*  93 */     return new TestCase("warning")
/*     */       {
/*     */         protected void runTest() {
/*  96 */           fail(message);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 103 */   private Vector<Test> fTests = new Vector<Test>(10);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestSuite() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestSuite(Class<?> theClass) {
/* 118 */     addTestsFromTestCase(theClass);
/*     */   }
/*     */   
/*     */   private void addTestsFromTestCase(Class<?> theClass) {
/* 122 */     this.fName = theClass.getName();
/*     */     try {
/* 124 */       getTestConstructor(theClass);
/* 125 */     } catch (NoSuchMethodException e) {
/* 126 */       addTest(warning("Class " + theClass.getName() + " has no public constructor TestCase(String name) or TestCase()"));
/*     */       
/*     */       return;
/*     */     } 
/* 130 */     if (!Modifier.isPublic(theClass.getModifiers())) {
/* 131 */       addTest(warning("Class " + theClass.getName() + " is not public"));
/*     */       
/*     */       return;
/*     */     } 
/* 135 */     Class<?> superClass = theClass;
/* 136 */     List<String> names = new ArrayList<String>();
/* 137 */     while (Test.class.isAssignableFrom(superClass)) {
/* 138 */       for (Method each : MethodSorter.getDeclaredMethods(superClass)) {
/* 139 */         addTestMethod(each, names, theClass);
/*     */       }
/* 141 */       superClass = superClass.getSuperclass();
/*     */     } 
/* 143 */     if (this.fTests.size() == 0) {
/* 144 */       addTest(warning("No tests found in " + theClass.getName()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestSuite(Class<? extends TestCase> theClass, String name) {
/* 154 */     this(theClass);
/* 155 */     setName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestSuite(String name) {
/* 162 */     setName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestSuite(Class<?>... classes) {
/* 171 */     for (Class<?> each : classes) {
/* 172 */       addTest(testCaseForClass(each));
/*     */     }
/*     */   }
/*     */   
/*     */   private Test testCaseForClass(Class<?> each) {
/* 177 */     if (TestCase.class.isAssignableFrom(each)) {
/* 178 */       return new TestSuite(each.asSubclass(TestCase.class));
/*     */     }
/* 180 */     return warning(each.getCanonicalName() + " does not extend TestCase");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestSuite(Class<? extends TestCase>[] classes, String name) {
/* 190 */     this((Class<?>[])classes);
/* 191 */     setName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTest(Test test) {
/* 198 */     this.fTests.add(test);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTestSuite(Class<? extends TestCase> testClass) {
/* 205 */     addTest(new TestSuite(testClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countTestCases() {
/* 212 */     int count = 0;
/* 213 */     for (Test each : this.fTests) {
/* 214 */       count += each.countTestCases();
/*     */     }
/* 216 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 225 */     return this.fName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(TestResult result) {
/* 232 */     for (Test each : this.fTests) {
/* 233 */       if (result.shouldStop()) {
/*     */         break;
/*     */       }
/* 236 */       runTest(each, result);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void runTest(Test test, TestResult result) {
/* 241 */     test.run(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 250 */     this.fName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Test testAt(int index) {
/* 257 */     return this.fTests.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int testCount() {
/* 264 */     return this.fTests.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<Test> tests() {
/* 271 */     return this.fTests.elements();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 278 */     if (getName() != null) {
/* 279 */       return getName();
/*     */     }
/* 281 */     return super.toString();
/*     */   }
/*     */   
/*     */   private void addTestMethod(Method m, List<String> names, Class<?> theClass) {
/* 285 */     String name = m.getName();
/* 286 */     if (names.contains(name)) {
/*     */       return;
/*     */     }
/* 289 */     if (!isPublicTestMethod(m)) {
/* 290 */       if (isTestMethod(m)) {
/* 291 */         addTest(warning("Test method isn't public: " + m.getName() + "(" + theClass.getCanonicalName() + ")"));
/*     */       }
/*     */       return;
/*     */     } 
/* 295 */     names.add(name);
/* 296 */     addTest(createTest(theClass, name));
/*     */   }
/*     */   
/*     */   private boolean isPublicTestMethod(Method m) {
/* 300 */     return (isTestMethod(m) && Modifier.isPublic(m.getModifiers()));
/*     */   }
/*     */   
/*     */   private boolean isTestMethod(Method m) {
/* 304 */     return ((m.getParameterTypes()).length == 0 && m.getName().startsWith("test") && m.getReturnType().equals(void.class));
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\junit\framework\TestSuite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */