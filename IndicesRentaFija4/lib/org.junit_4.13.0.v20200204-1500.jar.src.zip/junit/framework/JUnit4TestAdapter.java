/*     */ package junit.framework;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.junit.Ignore;
/*     */ import org.junit.runner.Describable;
/*     */ import org.junit.runner.Description;
/*     */ import org.junit.runner.Request;
/*     */ import org.junit.runner.Runner;
/*     */ import org.junit.runner.manipulation.Filter;
/*     */ import org.junit.runner.manipulation.Filterable;
/*     */ import org.junit.runner.manipulation.InvalidOrderingException;
/*     */ import org.junit.runner.manipulation.NoTestsRemainException;
/*     */ import org.junit.runner.manipulation.Orderable;
/*     */ import org.junit.runner.manipulation.Orderer;
/*     */ import org.junit.runner.manipulation.Sorter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JUnit4TestAdapter
/*     */   implements Test, Filterable, Orderable, Describable
/*     */ {
/*     */   private final Class<?> fNewTestClass;
/*     */   private final Runner fRunner;
/*     */   private final JUnit4TestAdapterCache fCache;
/*     */   
/*     */   public JUnit4TestAdapter(Class<?> newTestClass) {
/*  36 */     this(newTestClass, JUnit4TestAdapterCache.getDefault());
/*     */   }
/*     */   
/*     */   public JUnit4TestAdapter(Class<?> newTestClass, JUnit4TestAdapterCache cache) {
/*  40 */     this.fCache = cache;
/*  41 */     this.fNewTestClass = newTestClass;
/*  42 */     this.fRunner = Request.classWithoutSuiteMethod(newTestClass).getRunner();
/*     */   }
/*     */   
/*     */   public int countTestCases() {
/*  46 */     return this.fRunner.testCount();
/*     */   }
/*     */   
/*     */   public void run(TestResult result) {
/*  50 */     this.fRunner.run(this.fCache.getNotifier(result, this));
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Test> getTests() {
/*  55 */     return this.fCache.asTestList(getDescription());
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getTestClass() {
/*  60 */     return this.fNewTestClass;
/*     */   }
/*     */   
/*     */   public Description getDescription() {
/*  64 */     Description description = this.fRunner.getDescription();
/*  65 */     return removeIgnored(description);
/*     */   }
/*     */   
/*     */   private Description removeIgnored(Description description) {
/*  69 */     if (isIgnored(description)) {
/*  70 */       return Description.EMPTY;
/*     */     }
/*  72 */     Description result = description.childlessCopy();
/*  73 */     for (Description each : description.getChildren()) {
/*  74 */       Description child = removeIgnored(each);
/*  75 */       if (!child.isEmpty()) {
/*  76 */         result.addChild(child);
/*     */       }
/*     */     } 
/*  79 */     return result;
/*     */   }
/*     */   
/*     */   private boolean isIgnored(Description description) {
/*  83 */     return (description.getAnnotation(Ignore.class) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  88 */     return this.fNewTestClass.getName();
/*     */   }
/*     */   
/*     */   public void filter(Filter filter) throws NoTestsRemainException {
/*  92 */     filter.apply(this.fRunner);
/*     */   }
/*     */   
/*     */   public void sort(Sorter sorter) {
/*  96 */     sorter.apply(this.fRunner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void order(Orderer orderer) throws InvalidOrderingException {
/* 105 */     orderer.apply(this.fRunner);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\junit\framework\JUnit4TestAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */