/*     */ package junit.framework;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TestCase
/*     */   extends Assert
/*     */   implements Test
/*     */ {
/*     */   private String fName;
/*     */   
/*     */   public TestCase() {
/*  88 */     this.fName = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestCase(String name) {
/*  95 */     this.fName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int countTestCases() {
/* 102 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TestResult createResult() {
/* 111 */     return new TestResult();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TestResult run() {
/* 121 */     TestResult result = createResult();
/* 122 */     run(result);
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(TestResult result) {
/* 130 */     result.run(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void runBare() throws Throwable {
/* 139 */     Throwable exception = null;
/* 140 */     setUp();
/*     */     try {
/* 142 */       runTest();
/* 143 */     } catch (Throwable running) {
/* 144 */       exception = running;
/*     */     } finally {
/*     */       try {
/* 147 */         tearDown();
/* 148 */       } catch (Throwable tearingDown) {
/* 149 */         if (exception == null) exception = tearingDown; 
/*     */       } 
/*     */     } 
/* 152 */     if (exception != null) throw exception;
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void runTest() throws Throwable {
/* 161 */     assertNotNull("TestCase.fName cannot be null", this.fName);
/* 162 */     Method runMethod = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 168 */       runMethod = getClass().getMethod(this.fName, (Class[])null);
/* 169 */     } catch (NoSuchMethodException e) {
/* 170 */       fail("Method \"" + this.fName + "\" not found");
/*     */     } 
/* 172 */     if (!Modifier.isPublic(runMethod.getModifiers())) {
/* 173 */       fail("Method \"" + this.fName + "\" should be public");
/*     */     }
/*     */     
/*     */     try {
/* 177 */       runMethod.invoke(this, new Object[0]);
/* 178 */     } catch (InvocationTargetException e) {
/* 179 */       e.fillInStackTrace();
/* 180 */       throw e.getTargetException();
/* 181 */     } catch (IllegalAccessException e) {
/* 182 */       e.fillInStackTrace();
/* 183 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertTrue(String message, boolean condition) {
/* 192 */     Assert.assertTrue(message, condition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertTrue(boolean condition) {
/* 200 */     Assert.assertTrue(condition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertFalse(String message, boolean condition) {
/* 208 */     Assert.assertFalse(message, condition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertFalse(boolean condition) {
/* 216 */     Assert.assertFalse(condition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fail(String message) {
/* 223 */     Assert.fail(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fail() {
/* 230 */     Assert.fail();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, Object expected, Object actual) {
/* 238 */     Assert.assertEquals(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(Object expected, Object actual) {
/* 246 */     Assert.assertEquals(expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, String expected, String actual) {
/* 253 */     Assert.assertEquals(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String expected, String actual) {
/* 260 */     Assert.assertEquals(expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, double expected, double actual, double delta) {
/* 269 */     Assert.assertEquals(message, expected, actual, delta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(double expected, double actual, double delta) {
/* 277 */     Assert.assertEquals(expected, actual, delta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, float expected, float actual, float delta) {
/* 286 */     Assert.assertEquals(message, expected, actual, delta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(float expected, float actual, float delta) {
/* 294 */     Assert.assertEquals(expected, actual, delta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, long expected, long actual) {
/* 302 */     Assert.assertEquals(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(long expected, long actual) {
/* 309 */     Assert.assertEquals(expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, boolean expected, boolean actual) {
/* 317 */     Assert.assertEquals(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(boolean expected, boolean actual) {
/* 324 */     Assert.assertEquals(expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, byte expected, byte actual) {
/* 332 */     Assert.assertEquals(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(byte expected, byte actual) {
/* 339 */     Assert.assertEquals(expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, char expected, char actual) {
/* 347 */     Assert.assertEquals(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(char expected, char actual) {
/* 354 */     Assert.assertEquals(expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, short expected, short actual) {
/* 362 */     Assert.assertEquals(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(short expected, short actual) {
/* 369 */     Assert.assertEquals(expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(String message, int expected, int actual) {
/* 377 */     Assert.assertEquals(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertEquals(int expected, int actual) {
/* 384 */     Assert.assertEquals(expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertNotNull(Object object) {
/* 391 */     Assert.assertNotNull(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertNotNull(String message, Object object) {
/* 399 */     Assert.assertNotNull(message, object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertNull(Object object) {
/* 410 */     Assert.assertNull(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertNull(String message, Object object) {
/* 418 */     Assert.assertNull(message, object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertSame(String message, Object expected, Object actual) {
/* 426 */     Assert.assertSame(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertSame(Object expected, Object actual) {
/* 434 */     Assert.assertSame(expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertNotSame(String message, Object expected, Object actual) {
/* 443 */     Assert.assertNotSame(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertNotSame(Object expected, Object actual) {
/* 451 */     Assert.assertNotSame(expected, actual);
/*     */   }
/*     */   
/*     */   public static void failSame(String message) {
/* 455 */     Assert.failSame(message);
/*     */   }
/*     */   
/*     */   public static void failNotSame(String message, Object expected, Object actual) {
/* 459 */     Assert.failNotSame(message, expected, actual);
/*     */   }
/*     */   
/*     */   public static void failNotEquals(String message, Object expected, Object actual) {
/* 463 */     Assert.failNotEquals(message, expected, actual);
/*     */   }
/*     */   
/*     */   public static String format(String message, Object expected, Object actual) {
/* 467 */     return Assert.format(message, expected, actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setUp() throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void tearDown() throws Exception {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 489 */     return getName() + "(" + getClass().getName() + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 498 */     return this.fName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 507 */     this.fName = name;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\junit\framework\TestCase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */