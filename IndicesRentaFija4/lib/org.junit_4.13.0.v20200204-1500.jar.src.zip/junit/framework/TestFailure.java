/*    */ package junit.framework;
/*    */ 
/*    */ import org.junit.internal.Throwables;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestFailure
/*    */ {
/*    */   protected Test fFailedTest;
/*    */   protected Throwable fThrownException;
/*    */   
/*    */   public TestFailure(Test failedTest, Throwable thrownException) {
/* 20 */     this.fFailedTest = failedTest;
/* 21 */     this.fThrownException = thrownException;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Test failedTest() {
/* 28 */     return this.fFailedTest;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Throwable thrownException() {
/* 35 */     return this.fThrownException;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 43 */     return this.fFailedTest + ": " + this.fThrownException.getMessage();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String trace() {
/* 51 */     return Throwables.getStacktrace(thrownException());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String exceptionMessage() {
/* 58 */     return thrownException().getMessage();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isFailure() {
/* 67 */     return thrownException() instanceof AssertionFailedError;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\junit\framework\TestFailure.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */