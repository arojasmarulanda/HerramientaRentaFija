/*    */ package junit.framework;
/*    */ 
/*    */ 
/*    */ public class ComparisonCompactor
/*    */ {
/*    */   private static final String ELLIPSIS = "...";
/*    */   private static final String DELTA_END = "]";
/*    */   private static final String DELTA_START = "[";
/*    */   private int fContextLength;
/*    */   private String fExpected;
/*    */   private String fActual;
/*    */   private int fPrefix;
/*    */   private int fSuffix;
/*    */   
/*    */   public ComparisonCompactor(int contextLength, String expected, String actual) {
/* 16 */     this.fContextLength = contextLength;
/* 17 */     this.fExpected = expected;
/* 18 */     this.fActual = actual;
/*    */   }
/*    */ 
/*    */   
/*    */   public String compact(String message) {
/* 23 */     if (this.fExpected == null || this.fActual == null || areStringsEqual()) {
/* 24 */       return Assert.format(message, this.fExpected, this.fActual);
/*    */     }
/*    */     
/* 27 */     findCommonPrefix();
/* 28 */     findCommonSuffix();
/* 29 */     String expected = compactString(this.fExpected);
/* 30 */     String actual = compactString(this.fActual);
/* 31 */     return Assert.format(message, expected, actual);
/*    */   }
/*    */   
/*    */   private String compactString(String source) {
/* 35 */     String result = "[" + source.substring(this.fPrefix, source.length() - this.fSuffix + 1) + "]";
/* 36 */     if (this.fPrefix > 0) {
/* 37 */       result = computeCommonPrefix() + result;
/*    */     }
/* 39 */     if (this.fSuffix > 0) {
/* 40 */       result = result + computeCommonSuffix();
/*    */     }
/* 42 */     return result;
/*    */   }
/*    */   
/*    */   private void findCommonPrefix() {
/* 46 */     this.fPrefix = 0;
/* 47 */     int end = Math.min(this.fExpected.length(), this.fActual.length());
/* 48 */     for (; this.fPrefix < end && 
/* 49 */       this.fExpected.charAt(this.fPrefix) == this.fActual.charAt(this.fPrefix); this.fPrefix++);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void findCommonSuffix() {
/* 56 */     int expectedSuffix = this.fExpected.length() - 1;
/* 57 */     int actualSuffix = this.fActual.length() - 1;
/* 58 */     while (actualSuffix >= this.fPrefix && expectedSuffix >= this.fPrefix && 
/* 59 */       this.fExpected.charAt(expectedSuffix) == this.fActual.charAt(actualSuffix)) {
/*    */       actualSuffix--;
/*    */       expectedSuffix--;
/*    */     } 
/* 63 */     this.fSuffix = this.fExpected.length() - expectedSuffix;
/*    */   }
/*    */   
/*    */   private String computeCommonPrefix() {
/* 67 */     return ((this.fPrefix > this.fContextLength) ? "..." : "") + this.fExpected.substring(Math.max(0, this.fPrefix - this.fContextLength), this.fPrefix);
/*    */   }
/*    */   
/*    */   private String computeCommonSuffix() {
/* 71 */     int end = Math.min(this.fExpected.length() - this.fSuffix + 1 + this.fContextLength, this.fExpected.length());
/* 72 */     return this.fExpected.substring(this.fExpected.length() - this.fSuffix + 1, end) + ((this.fExpected.length() - this.fSuffix + 1 < this.fExpected.length() - this.fContextLength) ? "..." : "");
/*    */   }
/*    */   
/*    */   private boolean areStringsEqual() {
/* 76 */     return this.fExpected.equals(this.fActual);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\junit\framework\ComparisonCompactor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */