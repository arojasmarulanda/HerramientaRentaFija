/*     */ package junit.runner;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Properties;
/*     */ import junit.framework.AssertionFailedError;
/*     */ import junit.framework.Test;
/*     */ import junit.framework.TestListener;
/*     */ import junit.framework.TestSuite;
/*     */ import org.junit.internal.Throwables;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseTestRunner
/*     */   implements TestListener
/*     */ {
/*     */   public static final String SUITE_METHODNAME = "suite";
/*     */   private static Properties fPreferences;
/*  33 */   static int fgMaxMessageLength = 500;
/*     */   
/*     */   static boolean fgFilterStack = true;
/*     */   
/*     */   boolean fLoading = true;
/*     */ 
/*     */   
/*     */   public synchronized void startTest(Test test) {
/*  41 */     testStarted(test.toString());
/*     */   }
/*     */   
/*     */   protected static void setPreferences(Properties preferences) {
/*  45 */     fPreferences = preferences;
/*     */   }
/*     */   
/*     */   protected static Properties getPreferences() {
/*  49 */     if (fPreferences == null) {
/*  50 */       fPreferences = new Properties();
/*  51 */       fPreferences.put("loading", "true");
/*  52 */       fPreferences.put("filterstack", "true");
/*  53 */       readPreferences();
/*     */     } 
/*  55 */     return fPreferences;
/*     */   }
/*     */   
/*     */   public static void savePreferences() throws IOException {
/*  59 */     FileOutputStream fos = new FileOutputStream(getPreferencesFile());
/*     */     try {
/*  61 */       getPreferences().store(fos, "");
/*     */     } finally {
/*  63 */       fos.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setPreference(String key, String value) {
/*  68 */     getPreferences().put(key, value);
/*     */   }
/*     */   
/*     */   public synchronized void endTest(Test test) {
/*  72 */     testEnded(test.toString());
/*     */   }
/*     */   
/*     */   public synchronized void addError(Test test, Throwable e) {
/*  76 */     testFailed(1, test, e);
/*     */   }
/*     */   
/*     */   public synchronized void addFailure(Test test, AssertionFailedError e) {
/*  80 */     testFailed(2, test, (Throwable)e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void testStarted(String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void testEnded(String paramString);
/*     */ 
/*     */   
/*     */   public abstract void testFailed(int paramInt, Test paramTest, Throwable paramThrowable);
/*     */ 
/*     */   
/*     */   public Test getTest(String suiteClassName) {
/*  96 */     if (suiteClassName.length() <= 0) {
/*  97 */       clearStatus();
/*  98 */       return null;
/*     */     } 
/* 100 */     Class<?> testClass = null;
/*     */     try {
/* 102 */       testClass = loadSuiteClass(suiteClassName);
/* 103 */     } catch (ClassNotFoundException e) {
/* 104 */       String clazz = e.getMessage();
/* 105 */       if (clazz == null) {
/* 106 */         clazz = suiteClassName;
/*     */       }
/* 108 */       runFailed("Class not found \"" + clazz + "\"");
/* 109 */       return null;
/* 110 */     } catch (Exception e) {
/* 111 */       runFailed("Error: " + e.toString());
/* 112 */       return null;
/*     */     } 
/* 114 */     Method suiteMethod = null;
/*     */     try {
/* 116 */       suiteMethod = testClass.getMethod("suite", new Class[0]);
/* 117 */     } catch (Exception e) {
/*     */       
/* 119 */       clearStatus();
/* 120 */       return (Test)new TestSuite(testClass);
/*     */     } 
/* 122 */     if (!Modifier.isStatic(suiteMethod.getModifiers())) {
/* 123 */       runFailed("Suite() method must be static");
/* 124 */       return null;
/*     */     } 
/* 126 */     Test test = null;
/*     */     try {
/* 128 */       test = (Test)suiteMethod.invoke(null, new Object[0]);
/* 129 */       if (test == null) {
/* 130 */         return test;
/*     */       }
/* 132 */     } catch (InvocationTargetException e) {
/* 133 */       runFailed("Failed to invoke suite():" + e.getTargetException().toString());
/* 134 */       return null;
/* 135 */     } catch (IllegalAccessException e) {
/* 136 */       runFailed("Failed to invoke suite():" + e.toString());
/* 137 */       return null;
/*     */     } 
/*     */     
/* 140 */     clearStatus();
/* 141 */     return test;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String elapsedTimeAsString(long runTime) {
/* 148 */     return NumberFormat.getInstance().format(runTime / 1000.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String processArguments(String[] args) {
/* 156 */     String suiteName = null;
/* 157 */     for (int i = 0; i < args.length; i++) {
/* 158 */       if (args[i].equals("-noloading")) {
/* 159 */         setLoading(false);
/* 160 */       } else if (args[i].equals("-nofilterstack")) {
/* 161 */         fgFilterStack = false;
/* 162 */       } else if (args[i].equals("-c")) {
/* 163 */         if (args.length > i + 1) {
/* 164 */           suiteName = extractClassName(args[i + 1]);
/*     */         } else {
/* 166 */           System.out.println("Missing Test class name");
/*     */         } 
/* 168 */         i++;
/*     */       } else {
/* 170 */         suiteName = args[i];
/*     */       } 
/*     */     } 
/* 173 */     return suiteName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoading(boolean enable) {
/* 180 */     this.fLoading = enable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String extractClassName(String className) {
/* 187 */     if (className.startsWith("Default package for")) {
/* 188 */       return className.substring(className.lastIndexOf(".") + 1);
/*     */     }
/* 190 */     return className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String truncate(String s) {
/* 197 */     if (fgMaxMessageLength != -1 && s.length() > fgMaxMessageLength) {
/* 198 */       s = s.substring(0, fgMaxMessageLength) + "...";
/*     */     }
/* 200 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void runFailed(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> loadSuiteClass(String suiteClassName) throws ClassNotFoundException {
/* 213 */     return Class.forName(suiteClassName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clearStatus() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean useReloadingTestSuiteLoader() {
/* 223 */     return (getPreference("loading").equals("true") && this.fLoading);
/*     */   }
/*     */   
/*     */   private static File getPreferencesFile() {
/* 227 */     String home = System.getProperty("user.home");
/* 228 */     return new File(home, "junit.properties");
/*     */   }
/*     */   
/*     */   private static void readPreferences() {
/* 232 */     InputStream is = null;
/*     */     
/* 234 */     try { is = new FileInputStream(getPreferencesFile());
/* 235 */       setPreferences(new Properties(getPreferences()));
/* 236 */       getPreferences().load(is); }
/* 237 */     catch (IOException ignored)
/*     */     
/*     */     { 
/*     */       try {
/* 241 */         if (is != null) {
/* 242 */           is.close();
/*     */         }
/* 244 */       } catch (IOException e1) {} } catch (SecurityException ignored) { try { if (is != null) is.close();  } catch (IOException e1) {} } finally { try { if (is != null) is.close();  } catch (IOException e1) {} }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getPreference(String key) {
/* 250 */     return getPreferences().getProperty(key);
/*     */   }
/*     */   
/*     */   public static int getPreference(String key, int dflt) {
/* 254 */     String value = getPreference(key);
/* 255 */     int intValue = dflt;
/* 256 */     if (value == null) {
/* 257 */       return intValue;
/*     */     }
/*     */     try {
/* 260 */       intValue = Integer.parseInt(value);
/* 261 */     } catch (NumberFormatException ne) {}
/*     */     
/* 263 */     return intValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFilteredTrace(Throwable e) {
/* 270 */     return getFilteredTrace(Throwables.getStacktrace(e));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getFilteredTrace(String stack) {
/* 277 */     if (showStackRaw()) {
/* 278 */       return stack;
/*     */     }
/*     */     
/* 281 */     StringWriter sw = new StringWriter();
/* 282 */     PrintWriter pw = new PrintWriter(sw);
/* 283 */     StringReader sr = new StringReader(stack);
/* 284 */     BufferedReader br = new BufferedReader(sr);
/*     */     
/*     */     try {
/*     */       String line;
/* 288 */       while ((line = br.readLine()) != null) {
/* 289 */         if (!filterLine(line)) {
/* 290 */           pw.println(line);
/*     */         }
/*     */       } 
/* 293 */     } catch (Exception IOException) {
/* 294 */       return stack;
/*     */     } 
/* 296 */     return sw.toString();
/*     */   }
/*     */   
/*     */   protected static boolean showStackRaw() {
/* 300 */     return (!getPreference("filterstack").equals("true") || !fgFilterStack);
/*     */   }
/*     */   
/*     */   static boolean filterLine(String line) {
/* 304 */     String[] patterns = { "junit.framework.TestCase", "junit.framework.TestResult", "junit.framework.TestSuite", "junit.framework.Assert.", "junit.swingui.TestRunner", "junit.awtui.TestRunner", "junit.textui.TestRunner", "java.lang.reflect.Method.invoke(" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 314 */     for (int i = 0; i < patterns.length; i++) {
/* 315 */       if (line.indexOf(patterns[i]) > 0) {
/* 316 */         return true;
/*     */       }
/*     */     } 
/* 319 */     return false;
/*     */   }
/*     */   
/*     */   static {
/* 323 */     fgMaxMessageLength = getPreference("maxmessage", fgMaxMessageLength);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\junit\runner\BaseTestRunner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */