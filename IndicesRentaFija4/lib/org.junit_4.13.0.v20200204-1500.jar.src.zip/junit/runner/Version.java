/*    */ package junit.runner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Version
/*    */ {
/*    */   public static String id() {
/* 12 */     return "4.13";
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 16 */     System.out.println(id());
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\org.junit_4.13.0.v20200204-1500.jar!\junit\runner\Version.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */