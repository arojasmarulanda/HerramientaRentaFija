/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import com.sun.javafx.charts.Legend;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.animation.FadeTransition;
/*     */ import javafx.animation.Interpolator;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.KeyValue;
/*     */ import javafx.animation.ParallelTransition;
/*     */ import javafx.animation.Timeline;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StackedBarChart<X, Y>
/*     */   extends XYChart<X, Y>
/*     */ {
/*  67 */   private Map<XYChart.Series<X, Y>, Map<String, List<XYChart.Data<X, Y>>>> seriesCategoryMap = new HashMap<>();
/*     */   
/*     */   private final Orientation orientation;
/*     */   private CategoryAxis categoryAxis;
/*     */   private ValueAxis valueAxis;
/*     */   
/*  73 */   private ListChangeListener<String> categoriesListener = new ListChangeListener<String>() {
/*     */       public void onChanged(ListChangeListener.Change<? extends String> param1Change) {
/*  75 */         while (param1Change.next()) {
/*  76 */           for (String str : param1Change.getRemoved()) {
/*  77 */             for (XYChart.Series series : StackedBarChart.this.getData()) {
/*  78 */               for (XYChart.Data data : series.getData()) {
/*  79 */                 StackedBarChart.this.orientation; if (str.equals((StackedBarChart.this.orientation == Orientation.VERTICAL) ? 
/*  80 */                     data.getXValue() : data.getYValue())) {
/*  81 */                   boolean bool = StackedBarChart.this.getAnimated();
/*  82 */                   StackedBarChart.this.setAnimated(false);
/*  83 */                   StackedBarChart.this.dataItemRemoved(data, series);
/*  84 */                   StackedBarChart.this.setAnimated(bool);
/*     */                 } 
/*     */               } 
/*     */             } 
/*  88 */             StackedBarChart.this.requestChartLayout();
/*     */           } 
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*  96 */   private DoubleProperty categoryGap = new StyleableDoubleProperty(10.0D) {
/*     */       protected void invalidated() {
/*  98 */         get();
/*  99 */         StackedBarChart.this.requestChartLayout();
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 104 */         return StackedBarChart.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 109 */         return "categoryGap";
/*     */       }
/*     */       
/*     */       public CssMetaData<StackedBarChart<?, ?>, Number> getCssMetaData() {
/* 113 */         return StackedBarChart.StyleableProperties.CATEGORY_GAP;
/*     */       }
/*     */     };
/*     */   
/*     */   public double getCategoryGap() {
/* 118 */     return this.categoryGap.getValue().doubleValue();
/*     */   }
/*     */   
/*     */   public void setCategoryGap(double paramDouble) {
/* 122 */     this.categoryGap.setValue(Double.valueOf(paramDouble));
/*     */   }
/*     */   
/*     */   public DoubleProperty categoryGapProperty() {
/* 126 */     return this.categoryGap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackedBarChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1) {
/* 138 */     this(paramAxis, paramAxis1, FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackedBarChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1, @NamedArg("data") ObservableList<XYChart.Series<X, Y>> paramObservableList) {
/* 150 */     super(paramAxis, paramAxis1);
/* 151 */     getStyleClass().add("stacked-bar-chart");
/* 152 */     if ((!(paramAxis instanceof ValueAxis) || !(paramAxis1 instanceof CategoryAxis)) && (!(paramAxis1 instanceof ValueAxis) || !(paramAxis instanceof CategoryAxis)))
/*     */     {
/* 154 */       throw new IllegalArgumentException("Axis type incorrect, one of X,Y should be CategoryAxis and the other NumberAxis");
/*     */     }
/* 156 */     if (paramAxis instanceof CategoryAxis) {
/* 157 */       this.categoryAxis = (CategoryAxis)paramAxis;
/* 158 */       this.valueAxis = (ValueAxis)paramAxis1;
/* 159 */       this.orientation = Orientation.VERTICAL;
/*     */     } else {
/* 161 */       this.categoryAxis = (CategoryAxis)paramAxis1;
/* 162 */       this.valueAxis = (ValueAxis)paramAxis;
/* 163 */       this.orientation = Orientation.HORIZONTAL;
/*     */     } 
/*     */     
/* 166 */     pseudoClassStateChanged(HORIZONTAL_PSEUDOCLASS_STATE, (this.orientation == Orientation.HORIZONTAL));
/* 167 */     pseudoClassStateChanged(VERTICAL_PSEUDOCLASS_STATE, (this.orientation == Orientation.VERTICAL));
/* 168 */     setData(paramObservableList);
/* 169 */     this.categoryAxis.getCategories().addListener(this.categoriesListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackedBarChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1, @NamedArg("data") ObservableList<XYChart.Series<X, Y>> paramObservableList, @NamedArg("categoryGap") double paramDouble) {
/* 182 */     this(paramAxis, paramAxis1);
/* 183 */     setData(paramObservableList);
/* 184 */     setCategoryGap(paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void dataItemAdded(XYChart.Series<X, Y> paramSeries, int paramInt, XYChart.Data<X, Y> paramData) {
/*     */     String str;
/* 190 */     if (this.orientation == Orientation.VERTICAL) {
/* 191 */       str = (String)paramData.getXValue();
/*     */     } else {
/* 193 */       str = (String)paramData.getYValue();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 198 */     Map<Object, Object> map = (Map)this.seriesCategoryMap.get(paramSeries);
/*     */     
/* 200 */     if (map == null) {
/* 201 */       map = new HashMap<>();
/* 202 */       this.seriesCategoryMap.put(paramSeries, map);
/*     */     } 
/*     */     
/* 205 */     List<XYChart.Data<X, Y>> list = (map.get(str) != null) ? (List)map.get(str) : new ArrayList();
/* 206 */     list.add(paramData);
/* 207 */     map.put(str, list);
/*     */     
/* 209 */     Node node = createBar(paramSeries, getData().indexOf(paramSeries), paramData, paramInt);
/* 210 */     if (shouldAnimate()) {
/* 211 */       animateDataAdd(paramData, node);
/*     */     } else {
/* 213 */       getPlotChildren().add(node);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void dataItemRemoved(XYChart.Data<X, Y> paramData, XYChart.Series<X, Y> paramSeries) {
/* 218 */     Node node = paramData.getNode();
/*     */     
/* 220 */     if (node != null) {
/* 221 */       node.focusTraversableProperty().unbind();
/*     */     }
/*     */     
/* 224 */     if (shouldAnimate()) {
/* 225 */       Timeline timeline = createDataRemoveTimeline(paramData, node, paramSeries);
/* 226 */       timeline.setOnFinished(paramActionEvent -> removeDataItemFromDisplay(paramSeries, paramData));
/*     */ 
/*     */       
/* 229 */       timeline.play();
/*     */     } else {
/* 231 */       processDataRemove(paramSeries, paramData);
/* 232 */       removeDataItemFromDisplay(paramSeries, paramData);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void dataItemChanged(XYChart.Data<X, Y> paramData) {
/*     */     double d1;
/*     */     double d2;
/* 240 */     if (this.orientation == Orientation.VERTICAL) {
/* 241 */       d1 = ((Number)paramData.getYValue()).doubleValue();
/* 242 */       d2 = ((Number)getCurrentDisplayedYValue(paramData)).doubleValue();
/*     */     } else {
/* 244 */       d1 = ((Number)paramData.getXValue()).doubleValue();
/* 245 */       d2 = ((Number)getCurrentDisplayedXValue(paramData)).doubleValue();
/*     */     } 
/* 247 */     if (d2 > 0.0D && d1 < 0.0D) {
/*     */       
/* 249 */       paramData.getNode().getStyleClass().add("negative");
/* 250 */     } else if (d2 < 0.0D && d1 > 0.0D) {
/*     */       
/* 252 */       paramData.getNode().getStyleClass().remove("negative");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void seriesChanged(ListChangeListener.Change<? extends XYChart.Series> paramChange) {
/* 259 */     for (byte b = 0; b < getDataSize(); b++) {
/* 260 */       XYChart.Series series = getData().get(b);
/* 261 */       for (byte b1 = 0; b1 < series.getData().size(); b1++) {
/* 262 */         XYChart.Data data = series.getData().get(b1);
/* 263 */         Node node = data.getNode();
/* 264 */         node.getStyleClass().setAll(new String[] { "chart-bar", "series" + b, "data" + b1, series.defaultColorStyleClass });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void seriesAdded(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 273 */     HashMap<Object, Object> hashMap = new HashMap<>();
/* 274 */     for (byte b = 0; b < paramSeries.getData().size(); b++) {
/* 275 */       String str; XYChart.Data<X, Y> data = paramSeries.getData().get(b);
/* 276 */       Node node = createBar(paramSeries, paramInt, data, b);
/*     */       
/* 278 */       if (this.orientation == Orientation.VERTICAL) {
/* 279 */         str = (String)data.getXValue();
/*     */       } else {
/* 281 */         str = (String)data.getYValue();
/*     */       } 
/*     */       
/* 284 */       List<XYChart.Data<X, Y>> list = (hashMap.get(str) != null) ? (List)hashMap.get(str) : new ArrayList();
/* 285 */       list.add(data);
/* 286 */       hashMap.put(str, list);
/* 287 */       if (shouldAnimate()) {
/* 288 */         animateDataAdd(data, node);
/*     */       } else {
/*     */         
/* 291 */         double d = (this.orientation == Orientation.VERTICAL) ? ((Number)data.getYValue()).doubleValue() : ((Number)data.getXValue()).doubleValue();
/* 292 */         if (d < 0.0D) {
/* 293 */           node.getStyleClass().add("negative");
/*     */         }
/* 295 */         getPlotChildren().add(node);
/*     */       } 
/*     */     } 
/* 298 */     if (hashMap.size() > 0) {
/* 299 */       this.seriesCategoryMap.put(paramSeries, hashMap);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void seriesRemoved(XYChart.Series<X, Y> paramSeries) {
/* 305 */     if (shouldAnimate()) {
/* 306 */       ParallelTransition parallelTransition = new ParallelTransition();
/* 307 */       parallelTransition.setOnFinished(paramActionEvent -> {
/*     */             removeSeriesFromDisplay(paramSeries);
/*     */             requestChartLayout();
/*     */           });
/* 311 */       for (Iterator<XYChart.Data> iterator = paramSeries.getData().iterator(); iterator.hasNext(); ) { XYChart.Data<X, Y> data = iterator.next();
/* 312 */         Node node = data.getNode();
/*     */         
/* 314 */         if (getSeriesSize() > 1) {
/* 315 */           Timeline timeline = createDataRemoveTimeline(data, node, paramSeries);
/* 316 */           parallelTransition.getChildren().add(timeline);
/*     */           continue;
/*     */         } 
/* 319 */         FadeTransition fadeTransition = new FadeTransition(Duration.millis(700.0D), node);
/* 320 */         fadeTransition.setFromValue(1.0D);
/* 321 */         fadeTransition.setToValue(0.0D);
/* 322 */         fadeTransition.setOnFinished(paramActionEvent -> {
/*     */               processDataRemove(paramSeries, paramData);
/*     */               paramNode.setOpacity(1.0D);
/*     */             });
/* 326 */         parallelTransition.getChildren().add(fadeTransition); }
/*     */ 
/*     */       
/* 329 */       parallelTransition.play();
/*     */     } else {
/* 331 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) {
/* 332 */         processDataRemove(paramSeries, data);
/*     */       }
/* 334 */       removeSeriesFromDisplay(paramSeries);
/* 335 */       requestChartLayout();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateAxisRange() {
/* 343 */     boolean bool = (this.categoryAxis == getXAxis()) ? true : false;
/* 344 */     if (this.categoryAxis.isAutoRanging()) {
/* 345 */       ArrayList<String> arrayList = new ArrayList();
/* 346 */       for (XYChart.Series<X, Y> series : getData()) {
/* 347 */         for (XYChart.Data data : series.getData()) {
/* 348 */           if (data != null) arrayList.add(bool ? data.getXValue() : data.getYValue()); 
/*     */         } 
/*     */       } 
/* 351 */       this.categoryAxis.invalidateRange(arrayList);
/*     */     } 
/* 353 */     if (this.valueAxis.isAutoRanging()) {
/* 354 */       ArrayList<Double> arrayList = new ArrayList();
/* 355 */       for (String str : this.categoryAxis.getAllDataCategories()) {
/* 356 */         double d1 = 0.0D;
/* 357 */         double d2 = 0.0D;
/* 358 */         Iterator<XYChart.Series<X, Y>> iterator = getDisplayedSeriesIterator();
/* 359 */         while (iterator.hasNext()) {
/* 360 */           XYChart.Series<X, Y> series = iterator.next();
/* 361 */           for (XYChart.Data<X, Y> data : getDataItem(series, str)) {
/* 362 */             if (data != null) {
/* 363 */               boolean bool1 = data.getNode().getStyleClass().contains("negative");
/* 364 */               Number number = bool ? (Number)data.getYValue() : (Number)data.getXValue();
/* 365 */               if (!bool1) {
/* 366 */                 d2 += this.valueAxis.toNumericValue(number); continue;
/*     */               } 
/* 368 */               d1 += this.valueAxis.toNumericValue(number);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 373 */         arrayList.add(Double.valueOf(d2));
/* 374 */         arrayList.add(Double.valueOf(d1));
/*     */       } 
/* 376 */       this.valueAxis.invalidateRange(arrayList);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void layoutPlotChildren() {
/* 382 */     double d1 = this.categoryAxis.getCategorySpacing();
/*     */     
/* 384 */     double d2 = d1 - getCategoryGap();
/* 385 */     double d3 = d2;
/* 386 */     double d4 = -((d1 - getCategoryGap()) / 2.0D);
/*     */     
/* 388 */     for (String str : this.categoryAxis.getCategories()) {
/* 389 */       double d5 = 0.0D;
/* 390 */       double d6 = 0.0D;
/* 391 */       Iterator<XYChart.Series<X, Y>> iterator = getDisplayedSeriesIterator();
/* 392 */       while (iterator.hasNext()) {
/* 393 */         XYChart.Series<X, Y> series = iterator.next();
/* 394 */         for (XYChart.Data<X, Y> data : getDataItem(series, str)) {
/* 395 */           if (data != null) {
/* 396 */             double d7, d8, d9, d10; Node node = data.getNode();
/*     */ 
/*     */             
/* 399 */             X x = getCurrentDisplayedXValue(data);
/* 400 */             Y y = getCurrentDisplayedYValue(data);
/* 401 */             if (this.orientation == Orientation.VERTICAL) {
/* 402 */               d7 = getXAxis().getDisplayPosition(x);
/* 403 */               d8 = getYAxis().toNumericValue(y);
/*     */             } else {
/* 405 */               d7 = getYAxis().getDisplayPosition(y);
/* 406 */               d8 = getXAxis().toNumericValue(x);
/*     */             } 
/*     */ 
/*     */             
/* 410 */             boolean bool = node.getStyleClass().contains("negative");
/* 411 */             if (!bool) {
/* 412 */               d9 = this.valueAxis.getDisplayPosition(Double.valueOf(d5));
/* 413 */               d10 = this.valueAxis.getDisplayPosition(Double.valueOf(d5 + d8));
/* 414 */               d5 += d8;
/*     */             } else {
/* 416 */               d9 = this.valueAxis.getDisplayPosition(Double.valueOf(d6 + d8));
/* 417 */               d10 = this.valueAxis.getDisplayPosition(Double.valueOf(d6));
/* 418 */               d6 += d8;
/*     */             } 
/*     */             
/* 421 */             if (this.orientation == Orientation.VERTICAL) {
/* 422 */               node.resizeRelocate(d7 + d4, d10, d3, d9 - d10);
/*     */               continue;
/*     */             } 
/* 425 */             node.resizeRelocate(d9, d7 + d4, d10 - d9, d3);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Legend.LegendItem createLegendItemForSeries(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 437 */     Legend.LegendItem legendItem = new Legend.LegendItem(paramSeries.getName());
/* 438 */     legendItem.getSymbol().getStyleClass().addAll(new String[] { "chart-bar", "series" + paramInt, "bar-legend-symbol", paramSeries.defaultColorStyleClass });
/*     */     
/* 440 */     return legendItem;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateMap(XYChart.Series<X, Y> paramSeries, XYChart.Data<X, Y> paramData) {
/* 445 */     String str = (this.orientation == Orientation.VERTICAL) ? (String)paramData.getXValue() : (String)paramData.getYValue();
/* 446 */     Map map = this.seriesCategoryMap.get(paramSeries);
/* 447 */     if (map != null) {
/* 448 */       map.remove(str);
/* 449 */       if (map.isEmpty()) this.seriesCategoryMap.remove(paramSeries); 
/*     */     } 
/* 451 */     if (this.seriesCategoryMap.isEmpty() && this.categoryAxis.isAutoRanging()) this.categoryAxis.getCategories().clear(); 
/*     */   }
/*     */   
/*     */   private void processDataRemove(XYChart.Series<X, Y> paramSeries, XYChart.Data<X, Y> paramData) {
/* 455 */     Node node = paramData.getNode();
/* 456 */     getPlotChildren().remove(node);
/* 457 */     updateMap(paramSeries, paramData);
/*     */   }
/*     */ 
/*     */   
/*     */   private void animateDataAdd(XYChart.Data<X, Y> paramData, Node paramNode) {
/* 462 */     if (this.orientation == Orientation.VERTICAL) {
/* 463 */       double d = ((Number)paramData.getYValue()).doubleValue();
/* 464 */       if (d < 0.0D) {
/* 465 */         paramNode.getStyleClass().add("negative");
/*     */       }
/* 467 */       paramData.setYValue(getYAxis().toRealValue(getYAxis().getZeroPosition()));
/* 468 */       setCurrentDisplayedYValue(paramData, getYAxis().toRealValue(getYAxis().getZeroPosition()));
/* 469 */       getPlotChildren().add(paramNode);
/* 470 */       paramData.setYValue(getYAxis().toRealValue(d));
/* 471 */       animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(
/*     */                   
/* 473 */                   currentDisplayedYValueProperty(paramData), 
/* 474 */                   getCurrentDisplayedYValue(paramData)) }), new KeyFrame(
/* 475 */               Duration.millis(700.0D), new KeyValue[] { new KeyValue(
/* 476 */                   currentDisplayedYValueProperty(paramData), paramData
/* 477 */                   .getYValue(), Interpolator.EASE_BOTH) }) });
/*     */     } else {
/*     */       
/* 480 */       double d = ((Number)paramData.getXValue()).doubleValue();
/* 481 */       if (d < 0.0D) {
/* 482 */         paramNode.getStyleClass().add("negative");
/*     */       }
/* 484 */       paramData.setXValue(getXAxis().toRealValue(getXAxis().getZeroPosition()));
/* 485 */       setCurrentDisplayedXValue(paramData, getXAxis().toRealValue(getXAxis().getZeroPosition()));
/* 486 */       getPlotChildren().add(paramNode);
/* 487 */       paramData.setXValue(getXAxis().toRealValue(d));
/* 488 */       animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(
/*     */                   
/* 490 */                   currentDisplayedXValueProperty(paramData), 
/* 491 */                   getCurrentDisplayedXValue(paramData)) }), new KeyFrame(
/* 492 */               Duration.millis(700.0D), new KeyValue[] { new KeyValue(
/* 493 */                   currentDisplayedXValueProperty(paramData), paramData
/* 494 */                   .getXValue(), Interpolator.EASE_BOTH) }) });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Timeline createDataRemoveTimeline(XYChart.Data<X, Y> paramData, Node paramNode, XYChart.Series<X, Y> paramSeries) {
/* 500 */     Timeline timeline = new Timeline();
/* 501 */     if (this.orientation == Orientation.VERTICAL) {
/* 502 */       paramData.setYValue(getYAxis().toRealValue(getYAxis().getZeroPosition()));
/* 503 */       timeline.getKeyFrames().addAll(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(
/*     */                   
/* 505 */                   currentDisplayedYValueProperty(paramData), 
/* 506 */                   getCurrentDisplayedYValue(paramData)) }), new KeyFrame(
/* 507 */               Duration.millis(700.0D), paramActionEvent -> processDataRemove(paramSeries, paramData), new KeyValue[] { new KeyValue(
/*     */ 
/*     */                   
/* 510 */                   currentDisplayedYValueProperty(paramData), paramData
/* 511 */                   .getYValue(), Interpolator.EASE_BOTH) }) });
/*     */     } else {
/*     */       
/* 514 */       paramData.setXValue(getXAxis().toRealValue(getXAxis().getZeroPosition()));
/* 515 */       timeline.getKeyFrames().addAll(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(
/*     */                   
/* 517 */                   currentDisplayedXValueProperty(paramData), 
/* 518 */                   getCurrentDisplayedXValue(paramData)) }), new KeyFrame(
/* 519 */               Duration.millis(700.0D), paramActionEvent -> processDataRemove(paramSeries, paramData), new KeyValue[] { new KeyValue(
/*     */ 
/*     */                   
/* 522 */                   currentDisplayedXValueProperty(paramData), paramData
/* 523 */                   .getXValue(), Interpolator.EASE_BOTH) }) });
/*     */     } 
/*     */     
/* 526 */     return timeline;
/*     */   }
/*     */   
/*     */   private Node createBar(XYChart.Series<X, Y> paramSeries, int paramInt1, XYChart.Data<X, Y> paramData, int paramInt2) {
/* 530 */     Node node = paramData.getNode();
/* 531 */     if (node == null) {
/* 532 */       node = new StackPane();
/* 533 */       node.setAccessibleRole(AccessibleRole.TEXT);
/* 534 */       node.setAccessibleRoleDescription("Bar");
/* 535 */       node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
/* 536 */       paramData.setNode(node);
/*     */     } 
/* 538 */     node.getStyleClass().setAll(new String[] { "chart-bar", "series" + paramInt1, "data" + paramInt2, paramSeries.defaultColorStyleClass });
/* 539 */     return node;
/*     */   }
/*     */   
/*     */   private List<XYChart.Data<X, Y>> getDataItem(XYChart.Series<X, Y> paramSeries, String paramString) {
/* 543 */     Map map = this.seriesCategoryMap.get(paramSeries);
/* 544 */     return (map != null) ? ((map.get(paramString) != null) ? 
/* 545 */       (List<XYChart.Data<X, Y>>)map.get(paramString) : new ArrayList<>()) : new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 555 */     private static final CssMetaData<StackedBarChart<?, ?>, Number> CATEGORY_GAP = new CssMetaData<StackedBarChart<?, ?>, Number>("-fx-category-gap", 
/*     */         
/* 557 */         SizeConverter.getInstance(), Double.valueOf(10.0D))
/*     */       {
/*     */         public boolean isSettable(StackedBarChart<?, ?> param2StackedBarChart)
/*     */         {
/* 561 */           return (param2StackedBarChart.categoryGap == null || !param2StackedBarChart.categoryGap.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(StackedBarChart<?, ?> param2StackedBarChart) {
/* 566 */           return (StyleableProperty<Number>)param2StackedBarChart.categoryGapProperty();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 574 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(XYChart.getClassCssMetaData());
/* 575 */       arrayList.add(CATEGORY_GAP);
/* 576 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 586 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 595 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 600 */   private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
/*     */ 
/*     */ 
/*     */   
/* 604 */   private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\StackedBarChart.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */