/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import com.sun.javafx.charts.ChartLayoutAnimator;
/*     */ import com.sun.javafx.charts.Legend;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.animation.Animation;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.beans.property.StringPropertyBase;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.css.converter.EnumConverter;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.layout.Pane;
/*     */ import javafx.scene.layout.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Chart
/*     */   extends Region
/*     */ {
/*     */   private static final int MIN_WIDTH_TO_LEAVE_FOR_CHART_CONTENT = 200;
/*     */   private static final int MIN_HEIGHT_TO_LEAVE_FOR_CHART_CONTENT = 150;
/*  80 */   private final Label titleLabel = new Label();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   private final Pane chartContent = new Pane() {
/*     */       protected void layoutChildren() {
/*  87 */         double d1 = snappedTopInset();
/*  88 */         double d2 = snappedLeftInset();
/*  89 */         double d3 = snappedBottomInset();
/*  90 */         double d4 = snappedRightInset();
/*  91 */         double d5 = getWidth();
/*  92 */         double d6 = getHeight();
/*  93 */         double d7 = snapSizeX(d5 - d2 + d4);
/*  94 */         double d8 = snapSizeY(d6 - d1 + d3);
/*  95 */         Chart.this.layoutChartChildren(snapPositionY(d1), snapPositionX(d2), d7, d8);
/*     */       }
/*     */       public boolean usesMirroring() {
/*  98 */         return Chart.this.useChartContentMirroring;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   boolean useChartContentMirroring = true;
/*     */   
/* 105 */   private final ChartLayoutAnimator animator = new ChartLayoutAnimator(this.chartContent);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private StringProperty title = new StringPropertyBase() {
/*     */       protected void invalidated() {
/* 112 */         Chart.this.titleLabel.setText(get());
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 117 */         return Chart.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 122 */         return "title";
/*     */       }
/*     */     };
/* 125 */   public final String getTitle() { return this.title.get(); }
/* 126 */   public final void setTitle(String paramString) { this.title.set(paramString); } public final StringProperty titleProperty() {
/* 127 */     return this.title;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   private ObjectProperty<Side> titleSide = new StyleableObjectProperty<Side>(Side.TOP) {
/*     */       protected void invalidated() {
/* 135 */         Chart.this.requestLayout();
/*     */       }
/*     */ 
/*     */       
/*     */       public CssMetaData<Chart, Side> getCssMetaData() {
/* 140 */         return Chart.StyleableProperties.TITLE_SIDE;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 145 */         return Chart.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 150 */         return "titleSide";
/*     */       }
/*     */     };
/* 153 */   public final Side getTitleSide() { return this.titleSide.get(); }
/* 154 */   public final void setTitleSide(Side paramSide) { this.titleSide.set(paramSide); } public final ObjectProperty<Side> titleSideProperty() {
/* 155 */     return this.titleSide;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   private final ObjectProperty<Node> legend = new ObjectPropertyBase<Node>() {
/* 162 */       private Node old = null;
/*     */       protected void invalidated() {
/* 164 */         Node node = get();
/* 165 */         if (this.old != null) Chart.this.getChildren().remove(this.old); 
/* 166 */         if (node != null) {
/* 167 */           Chart.this.getChildren().add(node);
/* 168 */           node.setVisible(Chart.this.isLegendVisible());
/*     */         } 
/* 170 */         this.old = node;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 175 */         return Chart.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 180 */         return "legend";
/*     */       }
/*     */     };
/* 183 */   protected final Node getLegend() { return this.legend.getValue(); }
/* 184 */   protected final void setLegend(Node paramNode) { this.legend.setValue(paramNode); } protected final ObjectProperty<Node> legendProperty() {
/* 185 */     return this.legend;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 190 */   private final BooleanProperty legendVisible = new StyleableBooleanProperty(true) {
/*     */       protected void invalidated() {
/* 192 */         Chart.this.requestLayout();
/*     */       }
/*     */ 
/*     */       
/*     */       public CssMetaData<Chart, Boolean> getCssMetaData() {
/* 197 */         return Chart.StyleableProperties.LEGEND_VISIBLE;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 202 */         return Chart.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 207 */         return "legendVisible";
/*     */       }
/*     */     };
/* 210 */   public final boolean isLegendVisible() { return this.legendVisible.getValue().booleanValue(); }
/* 211 */   public final void setLegendVisible(boolean paramBoolean) { this.legendVisible.setValue(Boolean.valueOf(paramBoolean)); } public final BooleanProperty legendVisibleProperty() {
/* 212 */     return this.legendVisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   private ObjectProperty<Side> legendSide = new StyleableObjectProperty<Side>(Side.BOTTOM) {
/*     */       protected void invalidated() {
/* 221 */         Side side = get();
/* 222 */         Node node = Chart.this.getLegend();
/* 223 */         if (node instanceof Legend) ((Legend)node).setVertical((Side.LEFT.equals(side) || Side.RIGHT.equals(side))); 
/* 224 */         Chart.this.requestLayout();
/*     */       }
/*     */ 
/*     */       
/*     */       public CssMetaData<Chart, Side> getCssMetaData() {
/* 229 */         return Chart.StyleableProperties.LEGEND_SIDE;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 234 */         return Chart.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 239 */         return "legendSide";
/*     */       }
/*     */     };
/* 242 */   public final Side getLegendSide() { return this.legendSide.get(); }
/* 243 */   public final void setLegendSide(Side paramSide) { this.legendSide.set(paramSide); } public final ObjectProperty<Side> legendSideProperty() {
/* 244 */     return this.legendSide;
/*     */   }
/*     */   
/* 247 */   private BooleanProperty animated = new SimpleBooleanProperty(this, "animated", true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getAnimated() {
/* 254 */     return this.animated.get();
/* 255 */   } public final void setAnimated(boolean paramBoolean) { this.animated.set(paramBoolean); } public final BooleanProperty animatedProperty() {
/* 256 */     return this.animated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObservableList<Node> getChartChildren() {
/* 267 */     return this.chartContent.getChildren();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Chart() {
/* 276 */     this.titleLabel.setAlignment(Pos.CENTER);
/* 277 */     this.titleLabel.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
/* 278 */     getChildren().addAll(new Node[] { this.titleLabel, this.chartContent });
/* 279 */     getStyleClass().add("chart");
/* 280 */     this.titleLabel.getStyleClass().add("chart-title");
/* 281 */     this.chartContent.getStyleClass().add("chart-content");
/*     */     
/* 283 */     this.chartContent.setManaged(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void animate(KeyFrame... paramVarArgs) {
/* 293 */     this.animator.animate(paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void animate(Animation paramAnimation) {
/* 302 */     this.animator.animate(paramAnimation);
/*     */   }
/*     */   
/*     */   protected void requestChartLayout() {
/* 306 */     this.chartContent.requestLayout();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean shouldAnimate() {
/* 315 */     return (getAnimated() && NodeHelper.isTreeShowing(this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren() {
/* 332 */     double d1 = snappedTopInset();
/* 333 */     double d2 = snappedLeftInset();
/* 334 */     double d3 = snappedBottomInset();
/* 335 */     double d4 = snappedRightInset();
/* 336 */     double d5 = getWidth();
/* 337 */     double d6 = getHeight();
/*     */     
/* 339 */     if (getTitle() != null) {
/* 340 */       this.titleLabel.setVisible(true);
/* 341 */       if (getTitleSide().equals(Side.TOP)) {
/* 342 */         double d = snapSizeY(this.titleLabel.prefHeight(d5 - d2 - d4));
/* 343 */         this.titleLabel.resizeRelocate(d2, d1, d5 - d2 - d4, d);
/* 344 */         d1 += d;
/* 345 */       } else if (getTitleSide().equals(Side.BOTTOM)) {
/* 346 */         double d = snapSizeY(this.titleLabel.prefHeight(d5 - d2 - d4));
/* 347 */         this.titleLabel.resizeRelocate(d2, d6 - d3 - d, d5 - d2 - d4, d);
/* 348 */         d3 += d;
/* 349 */       } else if (getTitleSide().equals(Side.LEFT)) {
/* 350 */         double d = snapSizeX(this.titleLabel.prefWidth(d6 - d1 - d3));
/* 351 */         this.titleLabel.resizeRelocate(d2, d1, d, d6 - d1 - d3);
/* 352 */         d2 += d;
/* 353 */       } else if (getTitleSide().equals(Side.RIGHT)) {
/* 354 */         double d = snapSizeX(this.titleLabel.prefWidth(d6 - d1 - d3));
/* 355 */         this.titleLabel.resizeRelocate(d5 - d4 - d, d1, d, d6 - d1 - d3);
/* 356 */         d4 += d;
/*     */       } 
/*     */     } else {
/* 359 */       this.titleLabel.setVisible(false);
/*     */     } 
/*     */     
/* 362 */     Node node = getLegend();
/* 363 */     if (node != null) {
/* 364 */       boolean bool = isLegendVisible();
/* 365 */       if (bool) {
/* 366 */         if (getLegendSide() == Side.TOP) {
/* 367 */           double d7 = snapSizeY(node.prefHeight(d5 - d2 - d4));
/* 368 */           double d8 = Utils.boundedSize(snapSizeX(node.prefWidth(d7)), 0.0D, d5 - d2 - d4);
/* 369 */           node.resizeRelocate(d2 + (d5 - d2 - d4 - d8) / 2.0D, d1, d8, d7);
/* 370 */           if (d6 - d3 - d1 - d7 < 150.0D) {
/* 371 */             bool = false;
/*     */           } else {
/* 373 */             d1 += d7;
/*     */           } 
/* 375 */         } else if (getLegendSide() == Side.BOTTOM) {
/* 376 */           double d7 = snapSizeY(node.prefHeight(d5 - d2 - d4));
/* 377 */           double d8 = Utils.boundedSize(snapSizeX(node.prefWidth(d7)), 0.0D, d5 - d2 - d4);
/* 378 */           node.resizeRelocate(d2 + (d5 - d2 - d4 - d8) / 2.0D, d6 - d3 - d7, d8, d7);
/* 379 */           if (d6 - d3 - d1 - d7 < 150.0D) {
/* 380 */             bool = false;
/*     */           } else {
/* 382 */             d3 += d7;
/*     */           } 
/* 384 */         } else if (getLegendSide() == Side.LEFT) {
/* 385 */           double d7 = snapSizeX(node.prefWidth(d6 - d1 - d3));
/* 386 */           double d8 = Utils.boundedSize(snapSizeY(node.prefHeight(d7)), 0.0D, d6 - d1 - d3);
/* 387 */           node.resizeRelocate(d2, d1 + (d6 - d1 - d3 - d8) / 2.0D, d7, d8);
/* 388 */           if (d5 - d2 - d4 - d7 < 200.0D) {
/* 389 */             bool = false;
/*     */           } else {
/* 391 */             d2 += d7;
/*     */           } 
/* 393 */         } else if (getLegendSide() == Side.RIGHT) {
/* 394 */           double d7 = snapSizeX(node.prefWidth(d6 - d1 - d3));
/* 395 */           double d8 = Utils.boundedSize(snapSizeY(node.prefHeight(d7)), 0.0D, d6 - d1 - d3);
/* 396 */           node.resizeRelocate(d5 - d4 - d7, d1 + (d6 - d1 - d3 - d8) / 2.0D, d7, d8);
/* 397 */           if (d5 - d2 - d4 - d7 < 200.0D) {
/* 398 */             bool = false;
/*     */           } else {
/* 400 */             d4 += d7;
/*     */           } 
/*     */         } 
/*     */       }
/* 404 */       node.setVisible(bool);
/*     */     } 
/*     */     
/* 407 */     this.chartContent.resizeRelocate(d2, d1, d5 - d2 - d4, d6 - d1 - d3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble) {
/* 414 */     return 150.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble) {
/* 420 */     return 200.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble) {
/* 426 */     return 500.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble) {
/* 432 */     return 400.0D;
/*     */   }
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 437 */     private static final CssMetaData<Chart, Side> TITLE_SIDE = new CssMetaData<Chart, Side>("-fx-title-side", (StyleConverter)new EnumConverter(Side.class), Side.TOP)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean isSettable(Chart param2Chart)
/*     */         {
/* 444 */           return (param2Chart.titleSide == null || !param2Chart.titleSide.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Side> getStyleableProperty(Chart param2Chart) {
/* 449 */           return (StyleableProperty<Side>)param2Chart.titleSideProperty();
/*     */         }
/*     */       };
/*     */     
/* 453 */     private static final CssMetaData<Chart, Side> LEGEND_SIDE = new CssMetaData<Chart, Side>("-fx-legend-side", (StyleConverter)new EnumConverter(Side.class), Side.BOTTOM)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean isSettable(Chart param2Chart)
/*     */         {
/* 460 */           return (param2Chart.legendSide == null || !param2Chart.legendSide.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Side> getStyleableProperty(Chart param2Chart) {
/* 465 */           return (StyleableProperty<Side>)param2Chart.legendSideProperty();
/*     */         }
/*     */       };
/*     */     
/* 469 */     private static final CssMetaData<Chart, Boolean> LEGEND_VISIBLE = new CssMetaData<Chart, Boolean>("-fx-legend-visible", 
/*     */         
/* 471 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(Chart param2Chart)
/*     */         {
/* 475 */           return (param2Chart.legendVisible == null || !param2Chart.legendVisible.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(Chart param2Chart) {
/* 480 */           return (StyleableProperty<Boolean>)param2Chart.legendVisibleProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 487 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Region.getClassCssMetaData());
/* 488 */       arrayList.add(TITLE_SIDE);
/* 489 */       arrayList.add(LEGEND_VISIBLE);
/* 490 */       arrayList.add(LEGEND_SIDE);
/* 491 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 501 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 510 */     return getClassCssMetaData();
/*     */   }
/*     */   
/*     */   protected abstract void layoutChartChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\Chart.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */