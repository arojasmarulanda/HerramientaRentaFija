/*      */ package javafx.scene.chart;
/*      */ 
/*      */ import com.sun.javafx.charts.Legend;
/*      */ import com.sun.javafx.collections.NonIterableChange;
/*      */ import java.util.ArrayList;
/*      */ import java.util.BitSet;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import javafx.animation.Animation;
/*      */ import javafx.animation.FadeTransition;
/*      */ import javafx.animation.Interpolator;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.KeyValue;
/*      */ import javafx.animation.Timeline;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.binding.StringBinding;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.DoublePropertyBase;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*      */ import javafx.beans.property.SimpleDoubleProperty;
/*      */ import javafx.beans.property.StringProperty;
/*      */ import javafx.beans.property.StringPropertyBase;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableBooleanProperty;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.BooleanConverter;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.geometry.Side;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.layout.Region;
/*      */ import javafx.scene.shape.Arc;
/*      */ import javafx.scene.shape.ArcTo;
/*      */ import javafx.scene.shape.ArcType;
/*      */ import javafx.scene.shape.ClosePath;
/*      */ import javafx.scene.shape.LineTo;
/*      */ import javafx.scene.shape.MoveTo;
/*      */ import javafx.scene.shape.Path;
/*      */ import javafx.scene.text.Text;
/*      */ import javafx.scene.transform.Scale;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PieChart
/*      */   extends Chart
/*      */ {
/*      */   private static final int MIN_PIE_RADIUS = 25;
/*      */   private static final double LABEL_TICK_GAP = 6.0D;
/*      */   private static final double LABEL_BALL_RADIUS = 2.0D;
/*  103 */   private BitSet colorBits = new BitSet(8);
/*      */   private double pieRadius;
/*  105 */   private Data begin = null;
/*  106 */   private final Path labelLinePath = new Path() {
/*      */       public boolean usesMirroring() {
/*  108 */         return false;
/*      */       }
/*      */     };
/*  111 */   private List<LabelLayoutInfo> labelLayoutInfos = null;
/*  112 */   private Legend legend = new Legend();
/*  113 */   private Data dataItemBeingRemoved = null;
/*  114 */   private Timeline dataRemoveTimeline = null; private final ListChangeListener<Data> dataChangeListener; private ObjectProperty<ObservableList<Data>> data; private DoubleProperty startAngle; private BooleanProperty clockwise; private DoubleProperty labelLineLength; private BooleanProperty labelsVisible;
/*  115 */   public PieChart(ObservableList<Data> paramObservableList) { this.dataChangeListener = (paramChange -> {
/*      */         while (paramChange.next()) {
/*      */           if (paramChange.wasPermutated()) {
/*      */             Data data = this.begin;
/*      */             
/*      */             for (byte b = 0; b < getData().size(); b++) {
/*      */               Data data1 = getData().get(b);
/*      */               
/*      */               updateDataItemStyleClass(data1, b);
/*      */               
/*      */               if (b == 0) {
/*      */                 this.begin = data1;
/*      */                 
/*      */                 data = this.begin;
/*      */                 
/*      */                 this.begin.next = null;
/*      */               } else {
/*      */                 data.next = data1;
/*      */                 
/*      */                 data1.next = null;
/*      */                 
/*      */                 data = data1;
/*      */               } 
/*      */             } 
/*      */             
/*      */             updateLegend();
/*      */             
/*      */             requestChartLayout();
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           int i;
/*      */           for (i = paramChange.getFrom(); i < paramChange.getTo(); i++) {
/*      */             Data data = getData().get(i);
/*      */             data.setChart(this);
/*      */             if (this.begin == null) {
/*      */               this.begin = data;
/*      */               this.begin.next = null;
/*      */             } else if (i == 0) {
/*      */               data.next = this.begin;
/*      */               this.begin = data;
/*      */             } else {
/*      */               Data data1 = this.begin;
/*      */               for (byte b = 0; b < i - 1; b++) {
/*      */                 data1 = data1.next;
/*      */               }
/*      */               data.next = data1.next;
/*      */               data1.next = data;
/*      */             } 
/*      */           } 
/*      */           for (Data data : paramChange.getRemoved()) {
/*      */             dataItemRemoved(data);
/*      */           }
/*      */           for (i = paramChange.getFrom(); i < paramChange.getTo(); i++) {
/*      */             Data data = getData().get(i);
/*      */             data.defaultColorIndex = this.colorBits.nextClearBit(0);
/*      */             this.colorBits.set(data.defaultColorIndex);
/*      */             dataItemAdded(data, i);
/*      */           } 
/*      */           if (paramChange.wasRemoved() || paramChange.wasAdded()) {
/*      */             for (i = 0; i < getData().size(); i++) {
/*      */               Data data = getData().get(i);
/*      */               updateDataItemStyleClass(data, i);
/*      */             } 
/*      */             updateLegend();
/*      */           } 
/*      */         } 
/*      */         requestChartLayout();
/*      */       });
/*  185 */     this.data = new ObjectPropertyBase<ObservableList<Data>>() { private ObservableList<PieChart.Data> old;
/*      */         
/*      */         protected void invalidated() {
/*  188 */           ObservableList<PieChart.Data> observableList = getValue();
/*      */           
/*  190 */           if (this.old != null) this.old.removeListener(PieChart.this.dataChangeListener); 
/*  191 */           if (observableList != null) observableList.addListener(PieChart.this.dataChangeListener);
/*      */           
/*  193 */           if (this.old != null || observableList != null) {
/*  194 */             final List removed = (List)((this.old != null) ? this.old : Collections.emptyList());
/*  195 */             boolean bool = (observableList != null) ? observableList.size() : false;
/*      */             
/*  197 */             if (!bool || !list.isEmpty()) {
/*  198 */               PieChart.this.dataChangeListener.onChanged(new NonIterableChange<PieChart.Data>(0, bool, observableList) {
/*  199 */                     public List<PieChart.Data> getRemoved() { return removed; } public boolean wasPermutated() {
/*  200 */                       return false;
/*      */                     } protected int[] getPermutation() {
/*  202 */                       return new int[0];
/*      */                     }
/*      */                   });
/*      */             }
/*  206 */           } else if (this.old != null && this.old.size() > 0) {
/*      */             
/*  208 */             PieChart.this.dataChangeListener.onChanged(new NonIterableChange<PieChart.Data>(0, 0, observableList) {
/*  209 */                   public List<PieChart.Data> getRemoved() { return PieChart.null.this.old; } public boolean wasPermutated() {
/*  210 */                     return false;
/*      */                   } protected int[] getPermutation() {
/*  212 */                     return new int[0];
/*      */                   }
/*      */                 });
/*      */           } 
/*  216 */           this.old = observableList;
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  220 */           return PieChart.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  224 */           return "data";
/*      */         } }
/*      */       ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  232 */     this.startAngle = new StyleableDoubleProperty(0.0D) {
/*      */         public void invalidated() {
/*  234 */           get();
/*  235 */           PieChart.this.requestChartLayout();
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  240 */           return PieChart.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  245 */           return "startAngle";
/*      */         }
/*      */         
/*      */         public CssMetaData<PieChart, Number> getCssMetaData() {
/*  249 */           return PieChart.StyleableProperties.START_ANGLE;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  257 */     this.clockwise = new StyleableBooleanProperty(true) {
/*      */         public void invalidated() {
/*  259 */           get();
/*  260 */           PieChart.this.requestChartLayout();
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  265 */           return PieChart.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  270 */           return "clockwise";
/*      */         }
/*      */         
/*      */         public CssMetaData<PieChart, Boolean> getCssMetaData() {
/*  274 */           return PieChart.StyleableProperties.CLOCKWISE;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  283 */     this.labelLineLength = new StyleableDoubleProperty(20.0D) {
/*      */         public void invalidated() {
/*  285 */           get();
/*  286 */           PieChart.this.requestChartLayout();
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  291 */           return PieChart.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  296 */           return "labelLineLength";
/*      */         }
/*      */         
/*      */         public CssMetaData<PieChart, Number> getCssMetaData() {
/*  300 */           return PieChart.StyleableProperties.LABEL_LINE_LENGTH;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  308 */     this.labelsVisible = new StyleableBooleanProperty(true) {
/*      */         public void invalidated() {
/*  310 */           get();
/*  311 */           PieChart.this.requestChartLayout();
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  316 */           return PieChart.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  321 */           return "labelsVisible";
/*      */         }
/*      */         
/*      */         public CssMetaData<PieChart, Boolean> getCssMetaData() {
/*  325 */           return PieChart.StyleableProperties.LABELS_VISIBLE;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  352 */     getChartChildren().add(this.labelLinePath);
/*  353 */     this.labelLinePath.getStyleClass().add("chart-pie-label-line");
/*  354 */     setLegend(this.legend);
/*  355 */     setData(paramObservableList);
/*      */ 
/*      */     
/*  358 */     this.useChartContentMirroring = false; }
/*      */   public final ObservableList<Data> getData() { return this.data.getValue(); }
/*      */   public final void setData(ObservableList<Data> paramObservableList) { this.data.setValue(paramObservableList); }
/*      */   public final ObjectProperty<ObservableList<Data>> dataProperty() { return this.data; }
/*      */   public final double getStartAngle() { return this.startAngle.getValue().doubleValue(); }
/*      */   public final void setStartAngle(double paramDouble) { this.startAngle.setValue(Double.valueOf(paramDouble)); }
/*  364 */   public final DoubleProperty startAngleProperty() { return this.startAngle; } public final void setClockwise(boolean paramBoolean) { this.clockwise.setValue(Boolean.valueOf(paramBoolean)); } public final boolean isClockwise() { return this.clockwise.getValue().booleanValue(); } private void dataNameChanged(Data paramData) { paramData.textNode.setText(paramData.getName());
/*  365 */     requestChartLayout();
/*  366 */     updateLegend(); }
/*      */   public final BooleanProperty clockwiseProperty() { return this.clockwise; }
/*      */   public final double getLabelLineLength() { return this.labelLineLength.getValue().doubleValue(); }
/*      */   public final void setLabelLineLength(double paramDouble) { this.labelLineLength.setValue(Double.valueOf(paramDouble)); }
/*  370 */   public final DoubleProperty labelLineLengthProperty() { return this.labelLineLength; } public final void setLabelsVisible(boolean paramBoolean) { this.labelsVisible.setValue(Boolean.valueOf(paramBoolean)); } public final boolean getLabelsVisible() { return this.labelsVisible.getValue().booleanValue(); } public final BooleanProperty labelsVisibleProperty() { return this.labelsVisible; } public PieChart() { this(FXCollections.observableArrayList()); } private void dataPieValueChanged(Data paramData) { if (shouldAnimate()) {
/*  371 */       animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(
/*  372 */                   Data.access$700(paramData), 
/*  373 */                   (T)Double.valueOf(Data.access$800(paramData))) }), new KeyFrame(
/*  374 */               Duration.millis(500.0D), new KeyValue[] { new KeyValue(Data.access$700(paramData), 
/*  375 */                   (T)Double.valueOf(paramData.getPieValue()), Interpolator.EASE_BOTH) }) });
/*      */     } else {
/*      */       
/*  378 */       paramData.setCurrentPieValue(paramData.getPieValue());
/*  379 */       requestChartLayout();
/*      */     }  }
/*      */ 
/*      */   
/*      */   private Node createArcRegion(Data paramData) {
/*  384 */     Node node = paramData.getNode();
/*      */     
/*  386 */     if (node == null) {
/*  387 */       node = new Region();
/*  388 */       node.setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
/*  389 */       node.setPickOnBounds(false);
/*  390 */       paramData.setNode(node);
/*      */     } 
/*  392 */     return node;
/*      */   }
/*      */   
/*      */   private Text createPieLabel(Data paramData) {
/*  396 */     Text text = paramData.textNode;
/*  397 */     text.setText(paramData.getName());
/*  398 */     return text;
/*      */   }
/*      */   
/*      */   private void updateDataItemStyleClass(Data paramData, int paramInt) {
/*  402 */     Node node = paramData.getNode();
/*  403 */     if (node != null) {
/*      */       
/*  405 */       node.getStyleClass().setAll(new String[] { "chart-pie", "data" + paramInt, "default-color" + 
/*  406 */             Data.access$1100(paramData) % 8 });
/*  407 */       if (paramData.getPieValue() < 0.0D) {
/*  408 */         node.getStyleClass().add("negative");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void dataItemAdded(Data paramData, int paramInt) {
/*  415 */     Node node = createArcRegion(paramData);
/*  416 */     Text text = createPieLabel(paramData);
/*  417 */     paramData.getChart().getChartChildren().add(node);
/*  418 */     if (shouldAnimate()) {
/*      */ 
/*      */       
/*  421 */       if (this.dataRemoveTimeline != null && this.dataRemoveTimeline.getStatus().equals(Animation.Status.RUNNING) && 
/*  422 */         this.dataItemBeingRemoved == paramData) {
/*  423 */         this.dataRemoveTimeline.stop();
/*  424 */         this.dataRemoveTimeline = null;
/*  425 */         getChartChildren().remove(paramData.textNode);
/*  426 */         getChartChildren().remove(node);
/*  427 */         removeDataItemRef(paramData);
/*      */       } 
/*      */       
/*  430 */       animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(
/*      */                   
/*  432 */                   Data.access$700(paramData), (T)Double.valueOf(Data.access$800(paramData))), new KeyValue(
/*  433 */                   Data.access$1200(paramData), (T)Double.valueOf(Data.access$1300(paramData))) }), new KeyFrame(
/*  434 */               Duration.millis(500.0D), paramActionEvent -> { paramText.setOpacity(0.0D); if (paramData.getChart() == null) paramData.setChart(this);  paramData.getChart().getChartChildren().add(paramText); FadeTransition fadeTransition = new FadeTransition(Duration.millis(150.0D), paramText); fadeTransition.setToValue(1.0D); fadeTransition.play(); }new KeyValue[] { new KeyValue(
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  445 */                   Data.access$700(paramData), (T)Double.valueOf(paramData.getPieValue()), Interpolator.EASE_BOTH), new KeyValue(
/*  446 */                   Data.access$1200(paramData), (T)Integer.valueOf(1), Interpolator.EASE_BOTH) }) });
/*      */     } else {
/*      */       
/*  449 */       getChartChildren().add(text);
/*  450 */       paramData.setRadiusMultiplier(1.0D);
/*  451 */       paramData.setCurrentPieValue(paramData.getPieValue());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  456 */     for (byte b = 0; b < getChartChildren().size(); b++) {
/*  457 */       Node node1 = getChartChildren().get(b);
/*  458 */       if (node1 instanceof Text) {
/*  459 */         node1.toFront();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void removeDataItemRef(Data paramData) {
/*  465 */     if (this.begin == paramData) {
/*  466 */       this.begin = paramData.next;
/*      */     } else {
/*  468 */       Data data = this.begin;
/*  469 */       while (data != null && data.next != paramData) {
/*  470 */         data = data.next;
/*      */       }
/*  472 */       if (data != null) data.next = paramData.next; 
/*      */     } 
/*      */   }
/*      */   
/*      */   private Timeline createDataRemoveTimeline(final Data item) {
/*  477 */     Node node = item.getNode();
/*  478 */     Timeline timeline = new Timeline();
/*  479 */     timeline.getKeyFrames().addAll(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(
/*  480 */                 Data.access$700(item), (T)Double.valueOf(Data.access$800(item))), new KeyValue(
/*  481 */                 Data.access$1200(item), (T)Double.valueOf(Data.access$1300(item))) }), new KeyFrame(
/*  482 */             Duration.millis(500.0D), paramActionEvent -> {
/*      */               this.colorBits.clear(paramData.defaultColorIndex);
/*      */               
/*      */               getChartChildren().remove(paramNode);
/*      */               FadeTransition fadeTransition = new FadeTransition(Duration.millis(150.0D), paramData.textNode);
/*      */               fadeTransition.setFromValue(1.0D);
/*      */               fadeTransition.setToValue(0.0D);
/*      */               fadeTransition.setOnFinished(new EventHandler<ActionEvent>()
/*      */                   {
/*      */                     public void handle(ActionEvent param1ActionEvent)
/*      */                     {
/*  493 */                       PieChart.this.getChartChildren().remove(item.textNode);
/*      */                       
/*  495 */                       item.setChart(null);
/*  496 */                       PieChart.this.removeDataItemRef(item);
/*  497 */                       item.textNode.setOpacity(1.0D);
/*      */                     }
/*      */                   });
/*      */               
/*      */               fadeTransition.play();
/*  502 */             }new KeyValue[] { new KeyValue(Data.access$700(item), (T)Integer.valueOf(0), Interpolator.EASE_BOTH), new KeyValue(
/*  503 */                 Data.access$1200(item), (T)Integer.valueOf(0)) }) });
/*      */     
/*  505 */     return timeline;
/*      */   }
/*      */   
/*      */   private void dataItemRemoved(Data paramData) {
/*  509 */     Node node = paramData.getNode();
/*  510 */     if (shouldAnimate()) {
/*  511 */       this.dataRemoveTimeline = createDataRemoveTimeline(paramData);
/*  512 */       this.dataItemBeingRemoved = paramData;
/*  513 */       animate(this.dataRemoveTimeline);
/*      */     } else {
/*  515 */       this.colorBits.clear(paramData.defaultColorIndex);
/*  516 */       getChartChildren().remove(paramData.textNode);
/*  517 */       getChartChildren().remove(node);
/*      */       
/*  519 */       paramData.setChart(null);
/*  520 */       removeDataItemRef(paramData);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void layoutChartChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  526 */     double d1 = 0.0D;
/*  527 */     for (Data data = this.begin; data != null; data = data.next) {
/*  528 */       d1 += Math.abs(data.getCurrentPieValue());
/*      */     }
/*  530 */     double d2 = (d1 != 0.0D) ? (360.0D / d1) : 0.0D;
/*      */ 
/*      */     
/*  533 */     double[] arrayOfDouble1 = null;
/*  534 */     double[] arrayOfDouble2 = null;
/*  535 */     double[] arrayOfDouble3 = null;
/*  536 */     double d3 = 1.0D;
/*  537 */     ArrayList<LabelLayoutInfo> arrayList = null;
/*  538 */     boolean bool = getLabelsVisible();
/*  539 */     if (bool) {
/*  540 */       double d4 = 0.0D;
/*  541 */       double d5 = 0.0D;
/*      */       
/*  543 */       arrayOfDouble1 = new double[getDataSize()];
/*  544 */       arrayOfDouble2 = new double[getDataSize()];
/*  545 */       arrayOfDouble3 = new double[getDataSize()];
/*  546 */       arrayList = new ArrayList();
/*  547 */       byte b = 0;
/*  548 */       double d6 = getStartAngle();
/*  549 */       for (Data data1 = this.begin; data1 != null; data1 = data1.next) {
/*      */         
/*  551 */         data1.textNode.getTransforms().clear();
/*      */         
/*  553 */         double d7 = isClockwise() ? (-d2 * Math.abs(data1.getCurrentPieValue())) : (d2 * Math.abs(data1.getCurrentPieValue()));
/*  554 */         arrayOfDouble3[b] = normalizeAngle(d6 + d7 / 2.0D);
/*  555 */         double d8 = calcX(arrayOfDouble3[b], getLabelLineLength(), 0.0D);
/*  556 */         double d9 = calcY(arrayOfDouble3[b], getLabelLineLength(), 0.0D);
/*  557 */         arrayOfDouble1[b] = d8;
/*  558 */         arrayOfDouble2[b] = d9;
/*  559 */         d4 = Math.max(d4, 2.0D * (data1.textNode.getLayoutBounds().getWidth() + 6.0D + Math.abs(d8)));
/*  560 */         if (d9 > 0.0D) {
/*  561 */           d5 = Math.max(d5, 2.0D * Math.abs(d9 + data1.textNode.getLayoutBounds().getMaxY()));
/*      */         } else {
/*  563 */           d5 = Math.max(d5, 2.0D * Math.abs(d9 + data1.textNode.getLayoutBounds().getMinY()));
/*      */         } 
/*  565 */         d6 += d7;
/*  566 */         b++;
/*      */       } 
/*  568 */       this.pieRadius = Math.min(paramDouble3 - d4, paramDouble4 - d5) / 2.0D;
/*      */       
/*  570 */       if (this.pieRadius < 25.0D) {
/*      */         
/*  572 */         double d7 = paramDouble3 - 25.0D - 25.0D;
/*  573 */         double d8 = paramDouble4 - 25.0D - 25.0D;
/*  574 */         d3 = Math.min(d7 / d4, d8 / d5);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  579 */         if ((this.begin == null && d3 < 0.7D) || this.begin.textNode.getFont().getSize() * d3 < 9.0D) {
/*  580 */           bool = false;
/*  581 */           d3 = 1.0D;
/*      */         } else {
/*      */           
/*  584 */           this.pieRadius = 25.0D;
/*      */           
/*  586 */           for (byte b1 = 0; b1 < arrayOfDouble1.length; b1++) {
/*  587 */             arrayOfDouble1[b1] = arrayOfDouble1[b1] * d3;
/*  588 */             arrayOfDouble2[b1] = arrayOfDouble2[b1] * d3;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  594 */     if (!bool) {
/*  595 */       this.pieRadius = Math.min(paramDouble3, paramDouble4) / 2.0D;
/*  596 */       this.labelLinePath.getElements().clear();
/*      */     } 
/*      */     
/*  599 */     if (getChartChildren().size() > 0) {
/*  600 */       double d4 = paramDouble3 / 2.0D + paramDouble2;
/*  601 */       double d5 = paramDouble4 / 2.0D + paramDouble1;
/*  602 */       byte b = 0;
/*  603 */       for (Data data1 = this.begin; data1 != null; data1 = data1.next) {
/*      */         
/*  605 */         data1.textNode.setVisible(bool);
/*  606 */         if (bool) {
/*  607 */           double d7 = isClockwise() ? (-d2 * Math.abs(data1.getCurrentPieValue())) : (d2 * Math.abs(data1.getCurrentPieValue()));
/*  608 */           boolean bool1 = (arrayOfDouble3[b] <= -90.0D || arrayOfDouble3[b] >= 90.0D) ? true : false;
/*      */           
/*  610 */           double d8 = calcX(arrayOfDouble3[b], this.pieRadius, d4);
/*  611 */           double d9 = calcY(arrayOfDouble3[b], this.pieRadius, d5);
/*      */ 
/*      */           
/*  614 */           double d10 = bool1 ? (arrayOfDouble1[b] + d8 - data1.textNode.getLayoutBounds().getMaxX() - 6.0D) : (arrayOfDouble1[b] + d8 - data1.textNode.getLayoutBounds().getMinX() + 6.0D);
/*  615 */           double d11 = arrayOfDouble2[b] + d9 - data1.textNode.getLayoutBounds().getMinY() / 2.0D - 2.0D;
/*      */ 
/*      */           
/*  618 */           double d12 = d8 + arrayOfDouble1[b];
/*  619 */           double d13 = d9 + arrayOfDouble2[b];
/*      */           
/*  621 */           LabelLayoutInfo labelLayoutInfo = new LabelLayoutInfo(d8, d9, d12, d13, d10, d11, data1.textNode, Math.abs(d7));
/*  622 */           arrayList.add(labelLayoutInfo);
/*      */ 
/*      */           
/*  625 */           if (d3 < 1.0D) {
/*  626 */             data1.textNode.getTransforms().add(new Scale(d3, d3, 
/*      */ 
/*      */                   
/*  629 */                   bool1 ? data1.textNode.getLayoutBounds().getWidth() : 0.0D, 0.0D));
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  634 */         b++;
/*      */       } 
/*      */ 
/*      */       
/*  638 */       double d6 = getStartAngle();
/*  639 */       for (Data data2 = this.begin; data2 != null; data2 = data2.next) {
/*  640 */         Node node = data2.getNode();
/*  641 */         Arc arc = null;
/*  642 */         if (node != null && 
/*  643 */           node instanceof Region) {
/*  644 */           Region region = (Region)node;
/*  645 */           if (region.getShape() == null) {
/*  646 */             arc = new Arc();
/*  647 */             region.setShape(arc);
/*      */           } else {
/*  649 */             arc = (Arc)region.getShape();
/*      */           } 
/*  651 */           region.setScaleShape(false);
/*  652 */           region.setCenterShape(false);
/*  653 */           region.setCacheShape(false);
/*      */         } 
/*      */         
/*  656 */         double d = isClockwise() ? (-d2 * Math.abs(data2.getCurrentPieValue())) : (d2 * Math.abs(data2.getCurrentPieValue()));
/*      */         
/*  658 */         arc.setStartAngle(d6);
/*  659 */         arc.setLength(d);
/*  660 */         arc.setType(ArcType.ROUND);
/*  661 */         arc.setRadiusX(this.pieRadius * data2.getRadiusMultiplier());
/*  662 */         arc.setRadiusY(this.pieRadius * data2.getRadiusMultiplier());
/*  663 */         node.setLayoutX(d4);
/*  664 */         node.setLayoutY(d5);
/*  665 */         d6 += d;
/*      */       } 
/*      */       
/*  668 */       if (arrayList != null) {
/*      */         
/*  670 */         resolveCollision(arrayList);
/*      */         
/*  672 */         if (!arrayList.equals(this.labelLayoutInfos)) {
/*  673 */           this.labelLinePath.getElements().clear();
/*  674 */           for (LabelLayoutInfo labelLayoutInfo : arrayList) {
/*  675 */             if (labelLayoutInfo.text.isVisible()) drawLabelLinePath(labelLayoutInfo); 
/*      */           } 
/*  677 */           this.labelLayoutInfos = arrayList;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void resolveCollision(List<LabelLayoutInfo> paramList) {
/*  686 */     boolean bool = (this.begin != null) ? (int)this.begin.textNode.getLayoutBounds().getHeight() : false;
/*  687 */     for (byte b = 0; b < paramList.size(); b++) {
/*  688 */       for (int i = b + 1; i < paramList.size(); i++) {
/*  689 */         LabelLayoutInfo labelLayoutInfo1 = paramList.get(b);
/*  690 */         LabelLayoutInfo labelLayoutInfo2 = paramList.get(i);
/*  691 */         if (labelLayoutInfo1.text.isVisible() && labelLayoutInfo2.text.isVisible() && (
/*  692 */           fuzzyGT(labelLayoutInfo2.textY, labelLayoutInfo1.textY) ? fuzzyLT(labelLayoutInfo2.textY - bool - labelLayoutInfo1.textY, 2.0D) : 
/*  693 */           fuzzyLT(labelLayoutInfo1.textY - bool - labelLayoutInfo2.textY, 2.0D)))
/*  694 */           if (fuzzyGT(labelLayoutInfo1.textX, labelLayoutInfo2.textX) ? fuzzyLT(labelLayoutInfo1.textX - labelLayoutInfo2.textX, labelLayoutInfo2.text.prefWidth(-1.0D)) : 
/*  695 */             fuzzyLT(labelLayoutInfo2.textX - labelLayoutInfo1.textX, labelLayoutInfo1.text.prefWidth(-1.0D))) {
/*  696 */             if (fuzzyLT(labelLayoutInfo1.size, labelLayoutInfo2.size)) {
/*  697 */               labelLayoutInfo1.text.setVisible(false);
/*      */             } else {
/*  699 */               labelLayoutInfo2.text.setVisible(false);
/*      */             } 
/*      */           } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private int fuzzyCompare(double paramDouble1, double paramDouble2) {
/*  707 */     double d = 1.0E-5D;
/*  708 */     return (Math.abs(paramDouble1 - paramDouble2) < d) ? 0 : ((paramDouble1 < paramDouble2) ? -1 : 1);
/*      */   }
/*      */   
/*      */   private boolean fuzzyGT(double paramDouble1, double paramDouble2) {
/*  712 */     return (fuzzyCompare(paramDouble1, paramDouble2) == 1);
/*      */   }
/*      */   
/*      */   private boolean fuzzyLT(double paramDouble1, double paramDouble2) {
/*  716 */     return (fuzzyCompare(paramDouble1, paramDouble2) == -1);
/*      */   }
/*      */   
/*      */   private void drawLabelLinePath(LabelLayoutInfo paramLabelLayoutInfo) {
/*  720 */     paramLabelLayoutInfo.text.setLayoutX(paramLabelLayoutInfo.textX);
/*  721 */     paramLabelLayoutInfo.text.setLayoutY(paramLabelLayoutInfo.textY);
/*  722 */     this.labelLinePath.getElements().add(new MoveTo(paramLabelLayoutInfo.startX, paramLabelLayoutInfo.startY));
/*  723 */     this.labelLinePath.getElements().add(new LineTo(paramLabelLayoutInfo.endX, paramLabelLayoutInfo.endY));
/*      */     
/*  725 */     this.labelLinePath.getElements().add(new MoveTo(paramLabelLayoutInfo.endX - 2.0D, paramLabelLayoutInfo.endY));
/*  726 */     this.labelLinePath.getElements().add(new ArcTo(2.0D, 2.0D, 90.0D, paramLabelLayoutInfo.endX, paramLabelLayoutInfo.endY - 2.0D, false, true));
/*      */     
/*  728 */     this.labelLinePath.getElements().add(new ArcTo(2.0D, 2.0D, 90.0D, paramLabelLayoutInfo.endX + 2.0D, paramLabelLayoutInfo.endY, false, true));
/*      */     
/*  730 */     this.labelLinePath.getElements().add(new ArcTo(2.0D, 2.0D, 90.0D, paramLabelLayoutInfo.endX, paramLabelLayoutInfo.endY + 2.0D, false, true));
/*      */     
/*  732 */     this.labelLinePath.getElements().add(new ArcTo(2.0D, 2.0D, 90.0D, paramLabelLayoutInfo.endX - 2.0D, paramLabelLayoutInfo.endY, false, true));
/*      */     
/*  734 */     this.labelLinePath.getElements().add(new ClosePath());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateLegend() {
/*  740 */     Node node = getLegend();
/*  741 */     if (node != null && node != this.legend)
/*  742 */       return;  this.legend.setVertical((getLegendSide().equals(Side.LEFT) || getLegendSide().equals(Side.RIGHT)));
/*  743 */     ArrayList<Legend.LegendItem> arrayList = new ArrayList();
/*  744 */     if (getData() != null) {
/*  745 */       for (Data data : getData()) {
/*  746 */         Legend.LegendItem legendItem = new Legend.LegendItem(data.getName());
/*  747 */         legendItem.getSymbol().getStyleClass().addAll(data.getNode().getStyleClass());
/*  748 */         legendItem.getSymbol().getStyleClass().add("pie-legend-symbol");
/*  749 */         arrayList.add(legendItem);
/*      */       } 
/*      */     }
/*  752 */     this.legend.getItems().setAll(arrayList);
/*  753 */     if (arrayList.size() > 0) {
/*  754 */       if (node == null) {
/*  755 */         setLegend(this.legend);
/*      */       }
/*      */     } else {
/*  758 */       setLegend(null);
/*      */     } 
/*      */   }
/*      */   
/*      */   private int getDataSize() {
/*  763 */     byte b = 0;
/*  764 */     for (Data data = this.begin; data != null; data = data.next) {
/*  765 */       b++;
/*      */     }
/*  767 */     return b;
/*      */   }
/*      */   
/*      */   private static double calcX(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  771 */     return paramDouble3 + paramDouble2 * Math.cos(Math.toRadians(-paramDouble1));
/*      */   }
/*      */   
/*      */   private static double calcY(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  775 */     return paramDouble3 + paramDouble2 * Math.sin(Math.toRadians(-paramDouble1));
/*      */   }
/*      */ 
/*      */   
/*      */   private static double normalizeAngle(double paramDouble) {
/*  780 */     double d = paramDouble % 360.0D;
/*  781 */     if (d <= -180.0D) d += 360.0D; 
/*  782 */     if (d > 180.0D) d -= 360.0D; 
/*  783 */     return d;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class LabelLayoutInfo
/*      */   {
/*      */     double startX;
/*      */     
/*      */     double startY;
/*      */     
/*      */     double endX;
/*      */     double endY;
/*      */     double textX;
/*      */     double textY;
/*      */     Text text;
/*      */     double size;
/*      */     
/*      */     LabelLayoutInfo(double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6, Text param1Text, double param1Double7) {
/*  801 */       this.startX = param1Double1;
/*  802 */       this.startY = param1Double2;
/*  803 */       this.endX = param1Double3;
/*  804 */       this.endY = param1Double4;
/*  805 */       this.textX = param1Double5;
/*  806 */       this.textY = param1Double6;
/*  807 */       this.text = param1Text;
/*  808 */       this.size = param1Double7;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object param1Object) {
/*  813 */       if (this == param1Object) return true; 
/*  814 */       if (param1Object == null || getClass() != param1Object.getClass()) return false; 
/*  815 */       LabelLayoutInfo labelLayoutInfo = (LabelLayoutInfo)param1Object;
/*  816 */       return (Double.compare(labelLayoutInfo.startX, this.startX) == 0 && 
/*  817 */         Double.compare(labelLayoutInfo.startY, this.startY) == 0 && 
/*  818 */         Double.compare(labelLayoutInfo.endX, this.endX) == 0 && 
/*  819 */         Double.compare(labelLayoutInfo.endY, this.endY) == 0 && 
/*  820 */         Double.compare(labelLayoutInfo.textX, this.textX) == 0 && 
/*  821 */         Double.compare(labelLayoutInfo.textY, this.textY) == 0 && 
/*  822 */         Double.compare(labelLayoutInfo.size, this.size) == 0);
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  827 */       return Objects.hash(new Object[] { Double.valueOf(this.startX), Double.valueOf(this.startY), Double.valueOf(this.endX), Double.valueOf(this.endY), Double.valueOf(this.textX), Double.valueOf(this.textY), Double.valueOf(this.size) });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Data
/*      */   {
/*  838 */     private Text textNode = new Text();
/*      */ 
/*      */ 
/*      */     
/*  842 */     private Data next = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int defaultColorIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  854 */     private ReadOnlyObjectWrapper<PieChart> chart = new ReadOnlyObjectWrapper<>(this, "chart");
/*      */     
/*      */     public final PieChart getChart() {
/*  857 */       return this.chart.getValue();
/*      */     }
/*      */     
/*      */     private void setChart(PieChart param1PieChart) {
/*  861 */       this.chart.setValue(param1PieChart);
/*      */     }
/*      */     
/*      */     public final ReadOnlyObjectProperty<PieChart> chartProperty() {
/*  865 */       return this.chart.getReadOnlyProperty();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  871 */     private StringProperty name = new StringPropertyBase()
/*      */       {
/*      */         protected void invalidated() {
/*  874 */           if (PieChart.Data.this.getChart() != null) PieChart.Data.this.getChart().dataNameChanged(PieChart.Data.this);
/*      */         
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  879 */           return PieChart.Data.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  884 */           return "name";
/*      */         }
/*      */       };
/*      */     
/*      */     public final void setName(String param1String) {
/*  889 */       this.name.setValue(param1String);
/*      */     }
/*      */     
/*      */     public final String getName() {
/*  893 */       return this.name.getValue();
/*      */     }
/*      */     
/*      */     public final StringProperty nameProperty() {
/*  897 */       return this.name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  903 */     private DoubleProperty pieValue = new DoublePropertyBase()
/*      */       {
/*      */         protected void invalidated() {
/*  906 */           if (PieChart.Data.this.getChart() != null) PieChart.Data.this.getChart().dataPieValueChanged(PieChart.Data.this);
/*      */         
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  911 */           return PieChart.Data.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  916 */           return "pieValue";
/*      */         }
/*      */       };
/*      */     
/*      */     public final double getPieValue() {
/*  921 */       return this.pieValue.getValue().doubleValue();
/*      */     }
/*      */     
/*      */     public final void setPieValue(double param1Double) {
/*  925 */       this.pieValue.setValue(Double.valueOf(param1Double));
/*      */     }
/*      */     
/*      */     public final DoubleProperty pieValueProperty() {
/*  929 */       return this.pieValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  936 */     private DoubleProperty currentPieValue = new SimpleDoubleProperty(this, "currentPieValue");
/*      */     
/*      */     private double getCurrentPieValue() {
/*  939 */       return this.currentPieValue.getValue().doubleValue();
/*      */     }
/*      */     
/*      */     private void setCurrentPieValue(double param1Double) {
/*  943 */       this.currentPieValue.setValue(Double.valueOf(param1Double));
/*      */     }
/*      */     
/*      */     private DoubleProperty currentPieValueProperty() {
/*  947 */       return this.currentPieValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  953 */     private DoubleProperty radiusMultiplier = new SimpleDoubleProperty(this, "radiusMultiplier");
/*      */     
/*      */     private double getRadiusMultiplier() {
/*  956 */       return this.radiusMultiplier.getValue().doubleValue();
/*      */     }
/*      */     
/*      */     private void setRadiusMultiplier(double param1Double) {
/*  960 */       this.radiusMultiplier.setValue(Double.valueOf(param1Double));
/*      */     }
/*      */     
/*      */     private DoubleProperty radiusMultiplierProperty() {
/*  964 */       return this.radiusMultiplier;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  970 */     private ReadOnlyObjectWrapper<Node> node = new ReadOnlyObjectWrapper<>(this, "node");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Node getNode() {
/*  978 */       return this.node.getValue();
/*      */     }
/*      */     
/*      */     private void setNode(Node param1Node) {
/*  982 */       this.node.setValue(param1Node);
/*      */     }
/*      */     
/*      */     public ReadOnlyObjectProperty<Node> nodeProperty() {
/*  986 */       return this.node.getReadOnlyProperty();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Data(String param1String, double param1Double) {
/*  998 */       setName(param1String);
/*  999 */       setPieValue(param1Double);
/* 1000 */       this.textNode.getStyleClass().addAll(new String[] { "text", "chart-pie-label" });
/* 1001 */       this.textNode.setAccessibleRole(AccessibleRole.TEXT);
/* 1002 */       this.textNode.setAccessibleRoleDescription("slice");
/* 1003 */       this.textNode.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
/* 1004 */       this.textNode.accessibleTextProperty().bind(new StringBinding()
/*      */           {
/*      */             protected String computeValue() {
/* 1007 */               return PieChart.Data.this.getName() + " represents " + PieChart.Data.this.getName() + " percent";
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1021 */       return "Data[" + getName() + "," + getPieValue() + "]";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class StyleableProperties
/*      */   {
/* 1031 */     private static final CssMetaData<PieChart, Boolean> CLOCKWISE = new CssMetaData<PieChart, Boolean>("-fx-clockwise", 
/*      */         
/* 1033 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(PieChart param2PieChart)
/*      */         {
/* 1037 */           return (param2PieChart.clockwise == null || !param2PieChart.clockwise.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(PieChart param2PieChart) {
/* 1042 */           return (StyleableProperty<Boolean>)param2PieChart.clockwiseProperty();
/*      */         }
/*      */       };
/*      */     
/* 1046 */     private static final CssMetaData<PieChart, Boolean> LABELS_VISIBLE = new CssMetaData<PieChart, Boolean>("-fx-pie-label-visible", 
/*      */         
/* 1048 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(PieChart param2PieChart)
/*      */         {
/* 1052 */           return (param2PieChart.labelsVisible == null || !param2PieChart.labelsVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(PieChart param2PieChart) {
/* 1057 */           return (StyleableProperty<Boolean>)param2PieChart.labelsVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/* 1061 */     private static final CssMetaData<PieChart, Number> LABEL_LINE_LENGTH = new CssMetaData<PieChart, Number>("-fx-label-line-length", 
/*      */         
/* 1063 */         SizeConverter.getInstance(), Double.valueOf(20.0D))
/*      */       {
/*      */         public boolean isSettable(PieChart param2PieChart)
/*      */         {
/* 1067 */           return (param2PieChart.labelLineLength == null || !param2PieChart.labelLineLength.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(PieChart param2PieChart) {
/* 1072 */           return (StyleableProperty<Number>)param2PieChart.labelLineLengthProperty();
/*      */         }
/*      */       };
/*      */     
/* 1076 */     private static final CssMetaData<PieChart, Number> START_ANGLE = new CssMetaData<PieChart, Number>("-fx-start-angle", 
/*      */         
/* 1078 */         SizeConverter.getInstance(), Double.valueOf(0.0D))
/*      */       {
/*      */         public boolean isSettable(PieChart param2PieChart)
/*      */         {
/* 1082 */           return (param2PieChart.startAngle == null || !param2PieChart.startAngle.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(PieChart param2PieChart) {
/* 1087 */           return (StyleableProperty<Number>)param2PieChart.startAngleProperty();
/*      */         }
/*      */       };
/*      */ 
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1095 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Chart.getClassCssMetaData());
/* 1096 */       arrayList.add(CLOCKWISE);
/* 1097 */       arrayList.add(LABELS_VISIBLE);
/* 1098 */       arrayList.add(LABEL_LINE_LENGTH);
/* 1099 */       arrayList.add(START_ANGLE);
/* 1100 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1110 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 1119 */     return getClassCssMetaData();
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\PieChart.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */