/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import com.sun.javafx.charts.Legend;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.animation.FadeTransition;
/*     */ import javafx.animation.Interpolator;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.KeyValue;
/*     */ import javafx.animation.Timeline;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Group;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.shape.ClosePath;
/*     */ import javafx.scene.shape.LineTo;
/*     */ import javafx.scene.shape.MoveTo;
/*     */ import javafx.scene.shape.Path;
/*     */ import javafx.scene.shape.PathElement;
/*     */ import javafx.scene.shape.StrokeLineJoin;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AreaChart<X, Y>
/*     */   extends XYChart<X, Y>
/*     */ {
/*  73 */   private Map<XYChart.Series<X, Y>, DoubleProperty> seriesYMultiplierMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private BooleanProperty createSymbols = new StyleableBooleanProperty(true) {
/*     */       protected void invalidated() {
/*  83 */         for (byte b = 0; b < AreaChart.this.getData().size(); b++) {
/*  84 */           XYChart.Series series = AreaChart.this.getData().get(b);
/*  85 */           for (byte b1 = 0; b1 < series.getData().size(); b1++) {
/*  86 */             XYChart.Data data = series.getData().get(b1);
/*  87 */             Node node = data.getNode();
/*  88 */             if (get() && node == null) {
/*  89 */               node = AreaChart.this.createSymbol(series, AreaChart.this.getData().indexOf(series), data, b1);
/*  90 */               if (null != node) {
/*  91 */                 AreaChart.this.getPlotChildren().add(node);
/*     */               }
/*  93 */             } else if (!get() && node != null) {
/*  94 */               AreaChart.this.getPlotChildren().remove(node);
/*  95 */               node = null;
/*  96 */               data.setNode(null);
/*     */             } 
/*     */           } 
/*     */         } 
/* 100 */         AreaChart.this.requestChartLayout();
/*     */       }
/*     */       
/*     */       public Object getBean() {
/* 104 */         return this;
/*     */       }
/*     */       
/*     */       public String getName() {
/* 108 */         return "createSymbols";
/*     */       }
/*     */       
/*     */       public CssMetaData<AreaChart<?, ?>, Boolean> getCssMetaData() {
/* 112 */         return AreaChart.StyleableProperties.CREATE_SYMBOLS;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getCreateSymbols() {
/* 122 */     return this.createSymbols.getValue().booleanValue();
/* 123 */   } public final void setCreateSymbols(boolean paramBoolean) { this.createSymbols.setValue(Boolean.valueOf(paramBoolean)); } public final BooleanProperty createSymbolsProperty() {
/* 124 */     return this.createSymbols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AreaChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1) {
/* 136 */     this(paramAxis, paramAxis1, FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AreaChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1, @NamedArg("data") ObservableList<XYChart.Series<X, Y>> paramObservableList) {
/* 147 */     super(paramAxis, paramAxis1);
/* 148 */     setData(paramObservableList);
/*     */   }
/*     */ 
/*     */   
/*     */   private static double doubleValue(Number paramNumber) {
/* 153 */     return doubleValue(paramNumber, 0.0D);
/*     */   } private static double doubleValue(Number paramNumber, double paramDouble) {
/* 155 */     return (paramNumber == null) ? paramDouble : paramNumber.doubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateAxisRange() {
/* 160 */     Axis<X> axis = getXAxis();
/* 161 */     Axis<Y> axis1 = getYAxis();
/* 162 */     ArrayList<X> arrayList = null;
/* 163 */     ArrayList<Y> arrayList1 = null;
/* 164 */     if (axis.isAutoRanging()) arrayList = new ArrayList(); 
/* 165 */     if (axis1.isAutoRanging()) arrayList1 = new ArrayList(); 
/* 166 */     if (arrayList != null || arrayList1 != null) {
/* 167 */       for (XYChart.Series<X, Y> series : getData()) {
/* 168 */         for (XYChart.Data data : series.getData()) {
/* 169 */           if (arrayList != null) arrayList.add(data.getXValue()); 
/* 170 */           if (arrayList1 != null) arrayList1.add(data.getYValue()); 
/*     */         } 
/*     */       } 
/* 173 */       if (arrayList != null && (arrayList.size() != 1 || getXAxis().toNumericValue(arrayList.get(0)) != 0.0D)) {
/* 174 */         axis.invalidateRange(arrayList);
/*     */       }
/* 176 */       if (arrayList1 != null && (arrayList1.size() != 1 || getYAxis().toNumericValue(arrayList1.get(0)) != 0.0D)) {
/* 177 */         axis1.invalidateRange(arrayList1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void dataItemAdded(XYChart.Series<X, Y> paramSeries, int paramInt, XYChart.Data<X, Y> paramData) {
/* 183 */     Node node = createSymbol(paramSeries, getData().indexOf(paramSeries), paramData, paramInt);
/* 184 */     if (shouldAnimate()) {
/* 185 */       boolean bool = false;
/* 186 */       if (paramInt > 0 && paramInt < paramSeries.getData().size() - 1) {
/* 187 */         bool = true;
/* 188 */         XYChart.Data data1 = paramSeries.getData().get(paramInt - 1);
/* 189 */         XYChart.Data data2 = paramSeries.getData().get(paramInt + 1);
/* 190 */         double d1 = getXAxis().toNumericValue((X)data1.getXValue());
/* 191 */         double d2 = getYAxis().toNumericValue((Y)data1.getYValue());
/* 192 */         double d3 = getXAxis().toNumericValue((X)data2.getXValue());
/* 193 */         double d4 = getYAxis().toNumericValue((Y)data2.getYValue());
/*     */         
/* 195 */         double d5 = getXAxis().toNumericValue(paramData.getXValue());
/* 196 */         double d6 = getYAxis().toNumericValue(paramData.getYValue());
/*     */ 
/*     */         
/* 199 */         double d7 = (d4 - d2) / (d3 - d1) * d5 + (d3 * d2 - d4 * d1) / (d3 - d1);
/* 200 */         paramData.setCurrentY(getYAxis().toRealValue(d7));
/* 201 */         paramData.setCurrentX(getXAxis().toRealValue(d5));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 207 */       else if (paramInt == 0 && paramSeries.getData().size() > 1) {
/* 208 */         bool = true;
/* 209 */         paramData.setCurrentX((X)((XYChart.Data)paramSeries.getData().get(1)).getXValue());
/* 210 */         paramData.setCurrentY((Y)((XYChart.Data)paramSeries.getData().get(1)).getYValue());
/* 211 */       } else if (paramInt == paramSeries.getData().size() - 1 && paramSeries.getData().size() > 1) {
/* 212 */         bool = true;
/* 213 */         int i = paramSeries.getData().size() - 2;
/* 214 */         paramData.setCurrentX((X)((XYChart.Data)paramSeries.getData().get(i)).getXValue());
/* 215 */         paramData.setCurrentY((Y)((XYChart.Data)paramSeries.getData().get(i)).getYValue());
/*     */       } 
/* 217 */       if (node != null) {
/*     */         
/* 219 */         node.setOpacity(0.0D);
/* 220 */         getPlotChildren().add(node);
/* 221 */         FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 222 */         fadeTransition.setToValue(1.0D);
/* 223 */         fadeTransition.play();
/*     */       } 
/* 225 */       if (bool) {
/* 226 */         animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, paramActionEvent -> { if (paramNode != null && !getPlotChildren().contains(paramNode)) getPlotChildren().add(paramNode);  }new KeyValue[] { new KeyValue(paramData
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                     
/* 232 */                     .currentYProperty(), paramData
/* 233 */                     .getCurrentY()), new KeyValue(paramData
/* 234 */                     .currentXProperty(), paramData
/* 235 */                     .getCurrentX()) }), new KeyFrame(
/*     */                 
/* 237 */                 Duration.millis(800.0D), new KeyValue[] { new KeyValue(paramData.currentYProperty(), paramData
/* 238 */                     .getYValue(), Interpolator.EASE_BOTH), new KeyValue(paramData
/* 239 */                     .currentXProperty(), paramData
/* 240 */                     .getXValue(), Interpolator.EASE_BOTH) }) });
/*     */       
/*     */       }
/*     */     }
/* 244 */     else if (node != null) {
/* 245 */       getPlotChildren().add(node);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void dataItemRemoved(XYChart.Data<X, Y> paramData, XYChart.Series<X, Y> paramSeries) {
/* 250 */     Node node = paramData.getNode();
/*     */     
/* 252 */     if (node != null) {
/* 253 */       node.focusTraversableProperty().unbind();
/*     */     }
/*     */ 
/*     */     
/* 257 */     int i = paramSeries.getItemIndex(paramData);
/* 258 */     if (shouldAnimate()) {
/* 259 */       boolean bool = false;
/*     */       
/* 261 */       int j = paramSeries.getDataSize();
/*     */ 
/*     */       
/* 264 */       int k = paramSeries.getData().size();
/* 265 */       if (i > 0 && i < j - 1) {
/* 266 */         bool = true;
/* 267 */         XYChart.Data<X, Y> data1 = paramSeries.getItem(i - 1);
/* 268 */         XYChart.Data<X, Y> data2 = paramSeries.getItem(i + 1);
/* 269 */         double d1 = getXAxis().toNumericValue(data1.getXValue());
/* 270 */         double d2 = getYAxis().toNumericValue(data1.getYValue());
/* 271 */         double d3 = getXAxis().toNumericValue(data2.getXValue());
/* 272 */         double d4 = getYAxis().toNumericValue(data2.getYValue());
/*     */         
/* 274 */         double d5 = getXAxis().toNumericValue(paramData.getXValue());
/* 275 */         double d6 = getYAxis().toNumericValue(paramData.getYValue());
/*     */ 
/*     */         
/* 278 */         double d7 = (d4 - d2) / (d3 - d1) * d5 + (d3 * d2 - d4 * d1) / (d3 - d1);
/* 279 */         paramData.setCurrentX(getXAxis().toRealValue(d5));
/* 280 */         paramData.setCurrentY(getYAxis().toRealValue(d6));
/* 281 */         paramData.setXValue(getXAxis().toRealValue(d5));
/* 282 */         paramData.setYValue(getYAxis().toRealValue(d7));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 288 */       else if (i == 0 && k > 1) {
/* 289 */         bool = true;
/* 290 */         paramData.setXValue((X)((XYChart.Data)paramSeries.getData().get(0)).getXValue());
/* 291 */         paramData.setYValue((Y)((XYChart.Data)paramSeries.getData().get(0)).getYValue());
/* 292 */       } else if (i == j - 1 && k > 1) {
/* 293 */         bool = true;
/* 294 */         int m = k - 1;
/* 295 */         paramData.setXValue((X)((XYChart.Data)paramSeries.getData().get(m)).getXValue());
/* 296 */         paramData.setYValue((Y)((XYChart.Data)paramSeries.getData().get(m)).getYValue());
/* 297 */       } else if (node != null) {
/*     */         
/* 299 */         node.setOpacity(0.0D);
/* 300 */         FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 301 */         fadeTransition.setToValue(0.0D);
/* 302 */         fadeTransition.setOnFinished(paramActionEvent -> {
/*     */               getPlotChildren().remove(paramNode);
/*     */               removeDataItemFromDisplay(paramSeries, paramData);
/*     */             });
/* 306 */         fadeTransition.play();
/*     */       } else {
/* 308 */         paramData.setSeries(null);
/* 309 */         removeDataItemFromDisplay(paramSeries, paramData);
/*     */       } 
/* 311 */       if (bool) {
/* 312 */         animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(paramData.currentYProperty(), paramData
/* 313 */                     .getCurrentY()), new KeyValue(paramData.currentXProperty(), paramData
/* 314 */                     .getCurrentX()) }), new KeyFrame(
/* 315 */                 Duration.millis(800.0D), paramActionEvent -> { paramData.setSeries(null); getPlotChildren().remove(paramNode); removeDataItemFromDisplay(paramSeries, paramData); }new KeyValue[] { new KeyValue(paramData
/*     */ 
/*     */ 
/*     */ 
/*     */                     
/* 320 */                     .currentYProperty(), paramData
/* 321 */                     .getYValue(), Interpolator.EASE_BOTH), new KeyValue(paramData
/* 322 */                     .currentXProperty(), paramData
/* 323 */                     .getXValue(), Interpolator.EASE_BOTH) }) });
/*     */       }
/*     */     } else {
/*     */       
/* 327 */       paramData.setSeries(null);
/* 328 */       getPlotChildren().remove(node);
/* 329 */       removeDataItemFromDisplay(paramSeries, paramData);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dataItemChanged(XYChart.Data<X, Y> paramData) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void seriesChanged(ListChangeListener.Change<? extends XYChart.Series> paramChange) {
/* 341 */     for (byte b = 0; b < getDataSize(); b++) {
/* 342 */       XYChart.Series series = getData().get(b);
/* 343 */       Path path1 = (Path)((Group)series.getNode()).getChildren().get(1);
/* 344 */       Path path2 = (Path)((Group)series.getNode()).getChildren().get(0);
/* 345 */       path1.getStyleClass().setAll(new String[] { "chart-series-area-line", "series" + b, series.defaultColorStyleClass });
/* 346 */       path2.getStyleClass().setAll(new String[] { "chart-series-area-fill", "series" + b, series.defaultColorStyleClass });
/* 347 */       for (byte b1 = 0; b1 < series.getData().size(); b1++) {
/* 348 */         XYChart.Data data = series.getData().get(b1);
/* 349 */         Node node = data.getNode();
/* 350 */         if (node != null) node.getStyleClass().setAll(new String[] { "chart-area-symbol", "series" + b, "data" + b1, series.defaultColorStyleClass });
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void seriesAdded(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 357 */     Path path1 = new Path();
/* 358 */     Path path2 = new Path();
/* 359 */     path1.setStrokeLineJoin(StrokeLineJoin.BEVEL);
/* 360 */     Group group = new Group(new Node[] { path2, path1 });
/* 361 */     paramSeries.setNode(group);
/*     */     
/* 363 */     SimpleDoubleProperty simpleDoubleProperty = new SimpleDoubleProperty(this, "seriesYMultiplier");
/* 364 */     this.seriesYMultiplierMap.put(paramSeries, simpleDoubleProperty);
/*     */     
/* 366 */     if (shouldAnimate()) {
/* 367 */       simpleDoubleProperty.setValue(Double.valueOf(0.0D));
/*     */     } else {
/* 369 */       simpleDoubleProperty.setValue(Double.valueOf(1.0D));
/*     */     } 
/* 371 */     getPlotChildren().add(group);
/* 372 */     ArrayList<KeyFrame> arrayList = new ArrayList();
/* 373 */     if (shouldAnimate()) {
/*     */       
/* 375 */       arrayList.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(group
/* 376 */                 .opacityProperty(), Integer.valueOf(0)), new KeyValue(simpleDoubleProperty, 
/* 377 */                 Integer.valueOf(0)) }));
/*     */       
/* 379 */       arrayList.add(new KeyFrame(Duration.millis(200.0D), new KeyValue[] { new KeyValue(group
/* 380 */                 .opacityProperty(), Integer.valueOf(1)) }));
/*     */       
/* 382 */       arrayList.add(new KeyFrame(Duration.millis(500.0D), new KeyValue[] { new KeyValue(simpleDoubleProperty, 
/* 383 */                 Integer.valueOf(1)) }));
/*     */     } 
/*     */     
/* 386 */     for (byte b = 0; b < paramSeries.getData().size(); b++) {
/* 387 */       XYChart.Data<X, Y> data = paramSeries.getData().get(b);
/* 388 */       Node node = createSymbol(paramSeries, paramInt, data, b);
/* 389 */       if (node != null) {
/* 390 */         if (shouldAnimate()) {
/* 391 */           node.setOpacity(0.0D);
/* 392 */           getPlotChildren().add(node);
/*     */           
/* 394 */           arrayList.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(node.opacityProperty(), Integer.valueOf(0)) }));
/* 395 */           arrayList.add(new KeyFrame(Duration.millis(200.0D), new KeyValue[] { new KeyValue(node.opacityProperty(), Integer.valueOf(1)) }));
/*     */         } else {
/*     */           
/* 398 */           getPlotChildren().add(node);
/*     */         } 
/*     */       }
/*     */     } 
/* 402 */     if (shouldAnimate()) animate(arrayList.<KeyFrame>toArray(new KeyFrame[arrayList.size()]));
/*     */   
/*     */   }
/*     */   
/*     */   protected void seriesRemoved(XYChart.Series<X, Y> paramSeries) {
/* 407 */     this.seriesYMultiplierMap.remove(paramSeries);
/*     */     
/* 409 */     if (shouldAnimate()) {
/* 410 */       Timeline timeline = new Timeline(createSeriesRemoveTimeLine(paramSeries, 400L));
/* 411 */       timeline.play();
/*     */     } else {
/* 413 */       getPlotChildren().remove(paramSeries.getNode());
/* 414 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) getPlotChildren().remove(data.getNode()); 
/* 415 */       removeSeriesFromDisplay(paramSeries);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void layoutPlotChildren() {
/* 421 */     ArrayList<LineTo> arrayList = new ArrayList(getDataSize());
/* 422 */     for (byte b = 0; b < getDataSize(); b++) {
/* 423 */       XYChart.Series<?, ?> series = getData().get(b);
/* 424 */       DoubleProperty doubleProperty = this.seriesYMultiplierMap.get(series);
/* 425 */       ObservableList<Node> observableList = ((Group)series.getNode()).getChildren();
/* 426 */       Path path1 = (Path)observableList.get(0);
/* 427 */       Path path2 = (Path)observableList.get(1);
/* 428 */       makePaths(this, series, arrayList, path1, path2, doubleProperty
/* 429 */           .get(), LineChart.SortingPolicy.X_AXIS);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <X, Y> void makePaths(XYChart<X, Y> paramXYChart, XYChart.Series<X, Y> paramSeries, List<LineTo> paramList, Path paramPath1, Path paramPath2, double paramDouble, LineChart.SortingPolicy paramSortingPolicy) {
/* 438 */     Axis<X> axis = paramXYChart.getXAxis();
/* 439 */     Axis<Y> axis1 = paramXYChart.getYAxis();
/* 440 */     double d1 = paramPath2.getStrokeWidth() / 2.0D;
/* 441 */     boolean bool1 = (paramSortingPolicy == LineChart.SortingPolicy.X_AXIS) ? true : false;
/* 442 */     boolean bool2 = (paramSortingPolicy == LineChart.SortingPolicy.Y_AXIS) ? true : false;
/* 443 */     double d2 = bool1 ? -d1 : Double.NEGATIVE_INFINITY;
/* 444 */     double d3 = bool1 ? (axis.getWidth() + d1) : Double.POSITIVE_INFINITY;
/* 445 */     double d4 = bool2 ? -d1 : Double.NEGATIVE_INFINITY;
/* 446 */     double d5 = bool2 ? (axis1.getHeight() + d1) : Double.POSITIVE_INFINITY;
/* 447 */     LineTo lineTo1 = null;
/* 448 */     LineTo lineTo2 = null;
/* 449 */     paramList.clear();
/* 450 */     for (Iterator<XYChart.Data<X, Y>> iterator = paramXYChart.getDisplayedDataIterator(paramSeries); iterator.hasNext(); ) {
/* 451 */       XYChart.Data data = iterator.next();
/* 452 */       double d6 = axis.getDisplayPosition((X)data.getCurrentX());
/* 453 */       double d7 = axis1.getDisplayPosition(axis1
/* 454 */           .toRealValue(axis1.toNumericValue((Y)data.getCurrentY()) * paramDouble));
/* 455 */       boolean bool = (Double.isNaN(d6) || Double.isNaN(d7)) ? true : false;
/* 456 */       Node node = data.getNode();
/* 457 */       if (node != null) {
/* 458 */         double d8 = node.prefWidth(-1.0D);
/* 459 */         double d9 = node.prefHeight(-1.0D);
/* 460 */         if (bool) {
/* 461 */           node.resizeRelocate(-d8 * 2.0D, -d9 * 2.0D, d8, d9);
/*     */         } else {
/* 463 */           node.resizeRelocate(d6 - d8 / 2.0D, d7 - d9 / 2.0D, d8, d9);
/*     */         } 
/*     */       } 
/* 466 */       if (bool)
/* 467 */         continue;  if (d6 < d2 || d7 < d4) {
/* 468 */         if (lineTo1 == null) {
/* 469 */           lineTo1 = new LineTo(d6, d7); continue;
/* 470 */         }  if ((bool1 && lineTo1.getX() <= d6) || (bool2 && lineTo1
/* 471 */           .getY() <= d7)) {
/*     */           
/* 473 */           lineTo1.setX(d6);
/* 474 */           lineTo1.setY(d7);
/*     */         }  continue;
/* 476 */       }  if (d6 <= d3 && d7 <= d5) {
/* 477 */         paramList.add(new LineTo(d6, d7)); continue;
/*     */       } 
/* 479 */       if (lineTo2 == null) {
/* 480 */         lineTo2 = new LineTo(d6, d7); continue;
/* 481 */       }  if ((bool1 && d6 <= lineTo2.getX()) || (bool2 && d7 <= lineTo2
/* 482 */         .getY())) {
/*     */         
/* 484 */         lineTo2.setX(d6);
/* 485 */         lineTo2.setY(d7);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 490 */     if (!paramList.isEmpty() || lineTo1 != null || lineTo2 != null) {
/* 491 */       if (bool1) {
/* 492 */         Collections.sort(paramList, (paramLineTo1, paramLineTo2) -> Double.compare(paramLineTo1.getX(), paramLineTo2.getX()));
/* 493 */       } else if (bool2) {
/* 494 */         Collections.sort(paramList, (paramLineTo1, paramLineTo2) -> Double.compare(paramLineTo1.getY(), paramLineTo2.getY()));
/*     */       } 
/*     */ 
/*     */       
/* 498 */       if (lineTo1 != null) {
/* 499 */         paramList.add(0, lineTo1);
/*     */       }
/* 501 */       if (lineTo2 != null) {
/* 502 */         paramList.add(lineTo2);
/*     */       }
/*     */ 
/*     */       
/* 506 */       LineTo lineTo3 = paramList.get(0);
/* 507 */       LineTo lineTo4 = paramList.get(paramList.size() - 1);
/*     */       
/* 509 */       double d = lineTo3.getY();
/*     */       
/* 511 */       ObservableList<PathElement> observableList = paramPath2.getElements();
/* 512 */       observableList.clear();
/* 513 */       observableList.add(new MoveTo(lineTo3.getX(), d));
/* 514 */       observableList.addAll((Collection)paramList);
/*     */       
/* 516 */       if (paramPath1 != null) {
/* 517 */         ObservableList<PathElement> observableList1 = paramPath1.getElements();
/* 518 */         observableList1.clear();
/* 519 */         double d6 = axis1.getDisplayPosition(axis1.toRealValue(0.0D));
/*     */         
/* 521 */         observableList1.add(new MoveTo(lineTo3.getX(), d6));
/* 522 */         observableList1.addAll((Collection)paramList);
/* 523 */         observableList1.add(new LineTo(lineTo4.getX(), d6));
/* 524 */         observableList1.add(new ClosePath());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Node createSymbol(XYChart.Series<X, Y> paramSeries, int paramInt1, XYChart.Data<X, Y> paramData, int paramInt2) {
/* 530 */     Node node = paramData.getNode();
/*     */     
/* 532 */     if (node == null && getCreateSymbols()) {
/* 533 */       node = new StackPane();
/* 534 */       node.setAccessibleRole(AccessibleRole.TEXT);
/* 535 */       node.setAccessibleRoleDescription("Point");
/* 536 */       node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
/* 537 */       paramData.setNode(node);
/*     */     } 
/*     */ 
/*     */     
/* 541 */     if (node != null) node.getStyleClass().setAll(new String[] { "chart-area-symbol", "series" + paramInt1, "data" + paramInt2, paramSeries.defaultColorStyleClass });
/*     */     
/* 543 */     return node;
/*     */   }
/*     */ 
/*     */   
/*     */   Legend.LegendItem createLegendItemForSeries(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 548 */     Legend.LegendItem legendItem = new Legend.LegendItem(paramSeries.getName());
/* 549 */     legendItem.getSymbol().getStyleClass().addAll(new String[] { "chart-area-symbol", "series" + paramInt, "area-legend-symbol", paramSeries.defaultColorStyleClass });
/*     */     
/* 551 */     return legendItem;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 557 */     private static final CssMetaData<AreaChart<?, ?>, Boolean> CREATE_SYMBOLS = new CssMetaData<AreaChart<?, ?>, Boolean>("-fx-create-symbols", 
/*     */         
/* 559 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(AreaChart<?, ?> param2AreaChart)
/*     */         {
/* 563 */           return (param2AreaChart.createSymbols == null || !param2AreaChart.createSymbols.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(AreaChart<?, ?> param2AreaChart) {
/* 568 */           return (StyleableProperty<Boolean>)param2AreaChart.createSymbolsProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 575 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(XYChart.getClassCssMetaData());
/* 576 */       arrayList.add(CREATE_SYMBOLS);
/* 577 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 587 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 596 */     return getClassCssMetaData();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\AreaChart.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */