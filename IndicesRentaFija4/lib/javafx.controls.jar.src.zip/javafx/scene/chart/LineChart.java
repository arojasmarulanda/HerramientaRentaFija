/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import com.sun.javafx.charts.Legend;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.animation.Animation;
/*     */ import javafx.animation.FadeTransition;
/*     */ import javafx.animation.Interpolator;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.KeyValue;
/*     */ import javafx.animation.Timeline;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.shape.LineTo;
/*     */ import javafx.scene.shape.Path;
/*     */ import javafx.scene.shape.StrokeLineJoin;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineChart<X, Y>
/*     */   extends XYChart<X, Y>
/*     */ {
/*  83 */   private Map<XYChart.Series<X, Y>, DoubleProperty> seriesYMultiplierMap = new HashMap<>();
/*     */   private Timeline dataRemoveTimeline;
/*  85 */   private XYChart.Series<X, Y> seriesOfDataRemoved = null;
/*  86 */   private XYChart.Data<X, Y> dataItemBeingRemoved = null;
/*  87 */   private FadeTransition fadeSymbolTransition = null;
/*  88 */   private Map<XYChart.Data<X, Y>, Double> XYValueMap = new HashMap<>();
/*     */   
/*  90 */   private Timeline seriesRemoveTimeline = null;
/*     */ 
/*     */ 
/*     */   
/*  94 */   private BooleanProperty createSymbols = new StyleableBooleanProperty(true) {
/*     */       protected void invalidated() {
/*  96 */         for (byte b = 0; b < LineChart.this.getData().size(); b++) {
/*  97 */           XYChart.Series series = LineChart.this.getData().get(b);
/*  98 */           for (byte b1 = 0; b1 < series.getData().size(); b1++) {
/*  99 */             XYChart.Data data = series.getData().get(b1);
/* 100 */             Node node = data.getNode();
/* 101 */             if (get() && node == null) {
/* 102 */               node = LineChart.this.createSymbol(series, LineChart.this.getData().indexOf(series), data, b1);
/* 103 */               LineChart.this.getPlotChildren().add(node);
/* 104 */             } else if (!get() && node != null) {
/* 105 */               LineChart.this.getPlotChildren().remove(node);
/* 106 */               node = null;
/* 107 */               data.setNode(null);
/*     */             } 
/*     */           } 
/*     */         } 
/* 111 */         LineChart.this.requestChartLayout();
/*     */       }
/*     */       
/*     */       public Object getBean() {
/* 115 */         return LineChart.this;
/*     */       }
/*     */       
/*     */       public String getName() {
/* 119 */         return "createSymbols";
/*     */       }
/*     */       
/*     */       public CssMetaData<LineChart<?, ?>, Boolean> getCssMetaData() {
/* 123 */         return LineChart.StyleableProperties.CREATE_SYMBOLS;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getCreateSymbols() {
/* 132 */     return this.createSymbols.getValue().booleanValue();
/* 133 */   } public final void setCreateSymbols(boolean paramBoolean) { this.createSymbols.setValue(Boolean.valueOf(paramBoolean)); } public final BooleanProperty createSymbolsProperty() {
/* 134 */     return this.createSymbols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   private ObjectProperty<SortingPolicy> axisSortingPolicy = new ObjectPropertyBase<SortingPolicy>(SortingPolicy.X_AXIS) {
/*     */       protected void invalidated() {
/* 147 */         LineChart.this.requestChartLayout();
/*     */       }
/*     */       
/*     */       public Object getBean() {
/* 151 */         return LineChart.this;
/*     */       }
/*     */       
/*     */       public String getName() {
/* 155 */         return "axisSortingPolicy";
/*     */       }
/*     */     };
/*     */   
/*     */   public final SortingPolicy getAxisSortingPolicy() {
/* 160 */     return this.axisSortingPolicy.getValue();
/* 161 */   } public final void setAxisSortingPolicy(SortingPolicy paramSortingPolicy) { this.axisSortingPolicy.setValue(paramSortingPolicy); } public final ObjectProperty<SortingPolicy> axisSortingPolicyProperty() {
/* 162 */     return this.axisSortingPolicy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1) {
/* 173 */     this(paramAxis, paramAxis1, FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1, @NamedArg("data") ObservableList<XYChart.Series<X, Y>> paramObservableList) {
/* 184 */     super(paramAxis, paramAxis1);
/* 185 */     setData(paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateAxisRange() {
/* 192 */     Axis<X> axis = getXAxis();
/* 193 */     Axis<Y> axis1 = getYAxis();
/* 194 */     ArrayList<X> arrayList = null;
/* 195 */     ArrayList<Y> arrayList1 = null;
/* 196 */     if (axis.isAutoRanging()) arrayList = new ArrayList(); 
/* 197 */     if (axis1.isAutoRanging()) arrayList1 = new ArrayList(); 
/* 198 */     if (arrayList != null || arrayList1 != null) {
/* 199 */       for (XYChart.Series<X, Y> series : getData()) {
/* 200 */         for (XYChart.Data data : series.getData()) {
/* 201 */           if (arrayList != null) arrayList.add(data.getXValue()); 
/* 202 */           if (arrayList1 != null) arrayList1.add(data.getYValue());
/*     */         
/*     */         } 
/*     */       } 
/* 206 */       if (arrayList != null && (arrayList.size() != 1 || getXAxis().toNumericValue(arrayList.get(0)) != 0.0D)) {
/* 207 */         axis.invalidateRange(arrayList);
/*     */       }
/* 209 */       if (arrayList1 != null && (arrayList1.size() != 1 || getYAxis().toNumericValue(arrayList1.get(0)) != 0.0D)) {
/* 210 */         axis1.invalidateRange(arrayList1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void dataItemAdded(XYChart.Series<X, Y> paramSeries, int paramInt, XYChart.Data<X, Y> paramData) {
/* 217 */     Node node = createSymbol(paramSeries, getData().indexOf(paramSeries), paramData, paramInt);
/* 218 */     if (shouldAnimate())
/* 219 */     { if (this.dataRemoveTimeline != null && this.dataRemoveTimeline.getStatus().equals(Animation.Status.RUNNING) && 
/* 220 */         this.seriesOfDataRemoved == paramSeries) {
/* 221 */         this.dataRemoveTimeline.stop();
/* 222 */         this.dataRemoveTimeline = null;
/* 223 */         getPlotChildren().remove(this.dataItemBeingRemoved.getNode());
/* 224 */         removeDataItemFromDisplay(this.seriesOfDataRemoved, this.dataItemBeingRemoved);
/* 225 */         this.seriesOfDataRemoved = null;
/* 226 */         this.dataItemBeingRemoved = null;
/*     */       } 
/*     */       
/* 229 */       boolean bool = false;
/* 230 */       if (paramInt > 0 && paramInt < paramSeries.getData().size() - 1) {
/* 231 */         bool = true;
/* 232 */         XYChart.Data data1 = paramSeries.getData().get(paramInt - 1);
/* 233 */         XYChart.Data data2 = paramSeries.getData().get(paramInt + 1);
/* 234 */         if (data1 != null && data2 != null) {
/* 235 */           double d1 = getXAxis().toNumericValue((X)data1.getXValue());
/* 236 */           double d2 = getYAxis().toNumericValue((Y)data1.getYValue());
/* 237 */           double d3 = getXAxis().toNumericValue((X)data2.getXValue());
/* 238 */           double d4 = getYAxis().toNumericValue((Y)data2.getYValue());
/*     */           
/* 240 */           double d5 = getXAxis().toNumericValue(paramData.getXValue());
/*     */           
/* 242 */           if (d5 > d1 && d5 < d3) {
/*     */             
/* 244 */             double d = (d4 - d2) / (d3 - d1) * d5 + (d3 * d2 - d4 * d1) / (d3 - d1);
/* 245 */             paramData.setCurrentY(getYAxis().toRealValue(d));
/* 246 */             paramData.setCurrentX(getXAxis().toRealValue(d5));
/*     */           } else {
/*     */             
/* 249 */             double d6 = (d3 + d1) / 2.0D;
/* 250 */             double d7 = (d4 + d2) / 2.0D;
/* 251 */             paramData.setCurrentX(getXAxis().toRealValue(d6));
/* 252 */             paramData.setCurrentY(getYAxis().toRealValue(d7));
/*     */           } 
/*     */         } 
/* 255 */       } else if (paramInt == 0 && paramSeries.getData().size() > 1) {
/* 256 */         bool = true;
/* 257 */         paramData.setCurrentX((X)((XYChart.Data)paramSeries.getData().get(1)).getXValue());
/* 258 */         paramData.setCurrentY((Y)((XYChart.Data)paramSeries.getData().get(1)).getYValue());
/* 259 */       } else if (paramInt == paramSeries.getData().size() - 1 && paramSeries.getData().size() > 1) {
/* 260 */         bool = true;
/* 261 */         int i = paramSeries.getData().size() - 2;
/* 262 */         paramData.setCurrentX((X)((XYChart.Data)paramSeries.getData().get(i)).getXValue());
/* 263 */         paramData.setCurrentY((Y)((XYChart.Data)paramSeries.getData().get(i)).getYValue());
/* 264 */       } else if (node != null) {
/*     */         
/* 266 */         node.setOpacity(0.0D);
/* 267 */         getPlotChildren().add(node);
/* 268 */         FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 269 */         fadeTransition.setToValue(1.0D);
/* 270 */         fadeTransition.play();
/*     */       } 
/* 272 */       if (bool) {
/* 273 */         animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, paramActionEvent -> { if (paramNode != null && !getPlotChildren().contains(paramNode)) getPlotChildren().add(paramNode);  }new KeyValue[] { new KeyValue(paramData
/*     */ 
/*     */                     
/* 276 */                     .currentYProperty(), paramData
/* 277 */                     .getCurrentY()), new KeyValue(paramData
/* 278 */                     .currentXProperty(), paramData
/* 279 */                     .getCurrentX()) }), new KeyFrame(
/* 280 */                 Duration.millis(700.0D), new KeyValue[] { new KeyValue(paramData.currentYProperty(), paramData
/* 281 */                     .getYValue(), Interpolator.EASE_BOTH), new KeyValue(paramData
/* 282 */                     .currentXProperty(), paramData
/* 283 */                     .getXValue(), Interpolator.EASE_BOTH) }) });
/*     */       
/*     */       }
/*     */        }
/*     */     
/* 288 */     else if (node != null) { getPlotChildren().add(node); }
/*     */   
/*     */   }
/*     */   
/*     */   protected void dataItemRemoved(XYChart.Data<X, Y> paramData, XYChart.Series<X, Y> paramSeries) {
/* 293 */     Node node = paramData.getNode();
/*     */     
/* 295 */     if (node != null) {
/* 296 */       node.focusTraversableProperty().unbind();
/*     */     }
/*     */ 
/*     */     
/* 300 */     int i = paramSeries.getItemIndex(paramData);
/* 301 */     if (shouldAnimate()) {
/* 302 */       this.XYValueMap.clear();
/* 303 */       boolean bool = false;
/*     */       
/* 305 */       int j = paramSeries.getDataSize();
/*     */ 
/*     */       
/* 308 */       int k = paramSeries.getData().size();
/* 309 */       if (i > 0 && i < j - 1) {
/* 310 */         bool = true;
/* 311 */         XYChart.Data<X, Y> data1 = paramSeries.getItem(i - 1);
/* 312 */         XYChart.Data<X, Y> data2 = paramSeries.getItem(i + 1);
/* 313 */         double d1 = getXAxis().toNumericValue(data1.getXValue());
/* 314 */         double d2 = getYAxis().toNumericValue(data1.getYValue());
/* 315 */         double d3 = getXAxis().toNumericValue(data2.getXValue());
/* 316 */         double d4 = getYAxis().toNumericValue(data2.getYValue());
/*     */         
/* 318 */         double d5 = getXAxis().toNumericValue(paramData.getXValue());
/* 319 */         double d6 = getYAxis().toNumericValue(paramData.getYValue());
/* 320 */         if (d5 > d1 && d5 < d3) {
/*     */           
/* 322 */           double d = (d4 - d2) / (d3 - d1) * d5 + (d3 * d2 - d4 * d1) / (d3 - d1);
/* 323 */           paramData.setCurrentX(getXAxis().toRealValue(d5));
/* 324 */           paramData.setCurrentY(getYAxis().toRealValue(d6));
/* 325 */           paramData.setXValue(getXAxis().toRealValue(d5));
/* 326 */           paramData.setYValue(getYAxis().toRealValue(d));
/*     */         } else {
/*     */           
/* 329 */           double d7 = (d3 + d1) / 2.0D;
/* 330 */           double d8 = (d4 + d2) / 2.0D;
/* 331 */           paramData.setCurrentX(getXAxis().toRealValue(d7));
/* 332 */           paramData.setCurrentY(getYAxis().toRealValue(d8));
/*     */         } 
/* 334 */       } else if (i == 0 && k > 1) {
/* 335 */         bool = true;
/* 336 */         paramData.setXValue((X)((XYChart.Data)paramSeries.getData().get(0)).getXValue());
/* 337 */         paramData.setYValue((Y)((XYChart.Data)paramSeries.getData().get(0)).getYValue());
/* 338 */       } else if (i == j - 1 && k > 1) {
/* 339 */         bool = true;
/* 340 */         int m = k - 1;
/* 341 */         paramData.setXValue((X)((XYChart.Data)paramSeries.getData().get(m)).getXValue());
/* 342 */         paramData.setYValue((Y)((XYChart.Data)paramSeries.getData().get(m)).getYValue());
/* 343 */       } else if (node != null) {
/*     */         
/* 345 */         this.fadeSymbolTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 346 */         this.fadeSymbolTransition.setToValue(0.0D);
/* 347 */         this.fadeSymbolTransition.setOnFinished(paramActionEvent -> {
/*     */               paramData.setSeries(null);
/*     */               getPlotChildren().remove(paramNode);
/*     */               removeDataItemFromDisplay(paramSeries, paramData);
/*     */               paramNode.setOpacity(1.0D);
/*     */             });
/* 353 */         this.fadeSymbolTransition.play();
/*     */       } else {
/* 355 */         paramData.setSeries(null);
/* 356 */         removeDataItemFromDisplay(paramSeries, paramData);
/*     */       } 
/* 358 */       if (bool) {
/* 359 */         this.dataRemoveTimeline = createDataRemoveTimeline(paramData, node, paramSeries);
/* 360 */         this.seriesOfDataRemoved = paramSeries;
/* 361 */         this.dataItemBeingRemoved = paramData;
/* 362 */         this.dataRemoveTimeline.play();
/*     */       } 
/*     */     } else {
/* 365 */       paramData.setSeries(null);
/* 366 */       if (node != null) getPlotChildren().remove(node); 
/* 367 */       removeDataItemFromDisplay(paramSeries, paramData);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dataItemChanged(XYChart.Data<X, Y> paramData) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void seriesChanged(ListChangeListener.Change<? extends XYChart.Series> paramChange) {
/* 379 */     for (byte b = 0; b < getDataSize(); b++) {
/* 380 */       XYChart.Series series = getData().get(b);
/* 381 */       Node node = series.getNode();
/* 382 */       if (node != null) node.getStyleClass().setAll(new String[] { "chart-series-line", "series" + b, series.defaultColorStyleClass }); 
/* 383 */       for (byte b1 = 0; b1 < series.getData().size(); b1++) {
/* 384 */         Node node1 = ((XYChart.Data)series.getData().get(b1)).getNode();
/* 385 */         if (node1 != null) node1.getStyleClass().setAll(new String[] { "chart-line-symbol", "series" + b, "data" + b1, series.defaultColorStyleClass });
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void seriesAdded(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 392 */     Path path = new Path();
/* 393 */     path.setStrokeLineJoin(StrokeLineJoin.BEVEL);
/* 394 */     paramSeries.setNode(path);
/*     */     
/* 396 */     SimpleDoubleProperty simpleDoubleProperty = new SimpleDoubleProperty(this, "seriesYMultiplier");
/* 397 */     this.seriesYMultiplierMap.put(paramSeries, simpleDoubleProperty);
/*     */     
/* 399 */     if (shouldAnimate()) {
/* 400 */       path.setOpacity(0.0D);
/* 401 */       simpleDoubleProperty.setValue(Double.valueOf(0.0D));
/*     */     } else {
/* 403 */       simpleDoubleProperty.setValue(Double.valueOf(1.0D));
/*     */     } 
/* 405 */     getPlotChildren().add(path);
/*     */     
/* 407 */     ArrayList<KeyFrame> arrayList = new ArrayList();
/* 408 */     if (shouldAnimate()) {
/*     */       
/* 410 */       arrayList.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(path
/* 411 */                 .opacityProperty(), Integer.valueOf(0)), new KeyValue(simpleDoubleProperty, 
/* 412 */                 Integer.valueOf(0)) }));
/*     */       
/* 414 */       arrayList.add(new KeyFrame(Duration.millis(200.0D), new KeyValue[] { new KeyValue(path
/* 415 */                 .opacityProperty(), Integer.valueOf(1)) }));
/*     */       
/* 417 */       arrayList.add(new KeyFrame(Duration.millis(500.0D), new KeyValue[] { new KeyValue(simpleDoubleProperty, 
/* 418 */                 Integer.valueOf(1)) }));
/*     */     } 
/*     */     
/* 421 */     for (byte b = 0; b < paramSeries.getData().size(); b++) {
/* 422 */       XYChart.Data<X, Y> data = paramSeries.getData().get(b);
/* 423 */       Node node = createSymbol(paramSeries, paramInt, data, b);
/* 424 */       if (node != null) {
/* 425 */         if (shouldAnimate()) node.setOpacity(0.0D); 
/* 426 */         getPlotChildren().add(node);
/* 427 */         if (shouldAnimate()) {
/*     */           
/* 429 */           arrayList.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(node.opacityProperty(), Integer.valueOf(0)) }));
/* 430 */           arrayList.add(new KeyFrame(Duration.millis(200.0D), new KeyValue[] { new KeyValue(node.opacityProperty(), Integer.valueOf(1)) }));
/*     */         } 
/*     */       } 
/*     */     } 
/* 434 */     if (shouldAnimate()) animate(arrayList.<KeyFrame>toArray(new KeyFrame[arrayList.size()]));
/*     */   
/*     */   }
/*     */   
/*     */   protected void seriesRemoved(XYChart.Series<X, Y> paramSeries) {
/* 439 */     this.seriesYMultiplierMap.remove(paramSeries);
/* 440 */     if (shouldAnimate()) {
/* 441 */       this.seriesRemoveTimeline = new Timeline(createSeriesRemoveTimeLine(paramSeries, 900L));
/* 442 */       this.seriesRemoveTimeline.play();
/*     */     } else {
/* 444 */       getPlotChildren().remove(paramSeries.getNode());
/* 445 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) getPlotChildren().remove(data.getNode()); 
/* 446 */       removeSeriesFromDisplay(paramSeries);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void layoutPlotChildren() {
/* 452 */     ArrayList<LineTo> arrayList = new ArrayList(getDataSize());
/* 453 */     for (byte b = 0; b < getDataSize(); b++) {
/* 454 */       XYChart.Series<?, ?> series = getData().get(b);
/* 455 */       DoubleProperty doubleProperty = this.seriesYMultiplierMap.get(series);
/* 456 */       Node node = series.getNode();
/* 457 */       if (node instanceof Path) {
/* 458 */         AreaChart.makePaths(this, series, arrayList, null, (Path)node, doubleProperty
/*     */             
/* 460 */             .get(), getAxisSortingPolicy());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void dataBeingRemovedIsAdded(XYChart.Data<X, Y> paramData, XYChart.Series<X, Y> paramSeries) {
/* 467 */     if (this.fadeSymbolTransition != null) {
/* 468 */       this.fadeSymbolTransition.setOnFinished(null);
/* 469 */       this.fadeSymbolTransition.stop();
/*     */     } 
/* 471 */     if (this.dataRemoveTimeline != null) {
/* 472 */       this.dataRemoveTimeline.setOnFinished(null);
/* 473 */       this.dataRemoveTimeline.stop();
/*     */     } 
/* 475 */     Node node = paramData.getNode();
/* 476 */     if (node != null) getPlotChildren().remove(node);
/*     */     
/* 478 */     paramData.setSeries(null);
/* 479 */     removeDataItemFromDisplay(paramSeries, paramData);
/*     */ 
/*     */     
/* 482 */     Double double_ = this.XYValueMap.get(paramData);
/* 483 */     if (double_ != null) {
/* 484 */       paramData.setYValue((Y)double_);
/* 485 */       paramData.setCurrentY((Y)double_);
/*     */     } 
/* 487 */     this.XYValueMap.clear();
/*     */   }
/*     */   
/*     */   void seriesBeingRemovedIsAdded(XYChart.Series<X, Y> paramSeries) {
/* 491 */     if (this.seriesRemoveTimeline != null) {
/* 492 */       this.seriesRemoveTimeline.setOnFinished(null);
/* 493 */       this.seriesRemoveTimeline.stop();
/* 494 */       getPlotChildren().remove(paramSeries.getNode());
/* 495 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) getPlotChildren().remove(data.getNode()); 
/* 496 */       removeSeriesFromDisplay(paramSeries);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Timeline createDataRemoveTimeline(XYChart.Data<X, Y> paramData, Node paramNode, XYChart.Series<X, Y> paramSeries) {
/* 501 */     Timeline timeline = new Timeline();
/*     */     
/* 503 */     this.XYValueMap.put(paramData, Double.valueOf(((Number)paramData.getYValue()).doubleValue()));
/*     */     
/* 505 */     timeline.getKeyFrames().addAll(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(paramData.currentYProperty(), paramData
/* 506 */                 .getCurrentY()), new KeyValue(paramData.currentXProperty(), paramData
/* 507 */                 .getCurrentX()) }), new KeyFrame(
/* 508 */             Duration.millis(500.0D), paramActionEvent -> { if (paramNode != null) getPlotChildren().remove(paramNode);  removeDataItemFromDisplay(paramSeries, paramData); this.XYValueMap.clear(); }new KeyValue[] { new KeyValue(paramData
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 513 */                 .currentYProperty(), paramData
/* 514 */                 .getYValue(), Interpolator.EASE_BOTH), new KeyValue(paramData
/* 515 */                 .currentXProperty(), paramData
/* 516 */                 .getXValue(), Interpolator.EASE_BOTH) }) });
/*     */     
/* 518 */     return timeline;
/*     */   }
/*     */   
/*     */   private Node createSymbol(XYChart.Series<X, Y> paramSeries, int paramInt1, XYChart.Data<X, Y> paramData, int paramInt2) {
/* 522 */     Node node = paramData.getNode();
/*     */     
/* 524 */     if (node == null && getCreateSymbols()) {
/* 525 */       node = new StackPane();
/* 526 */       node.setAccessibleRole(AccessibleRole.TEXT);
/* 527 */       node.setAccessibleRoleDescription("Point");
/* 528 */       node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
/* 529 */       paramData.setNode(node);
/*     */     } 
/*     */     
/* 532 */     if (node != null) node.getStyleClass().addAll(new String[] { "chart-line-symbol", "series" + paramInt1, "data" + paramInt2, paramSeries.defaultColorStyleClass });
/*     */     
/* 534 */     return node;
/*     */   }
/*     */ 
/*     */   
/*     */   Legend.LegendItem createLegendItemForSeries(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 539 */     Legend.LegendItem legendItem = new Legend.LegendItem(paramSeries.getName());
/* 540 */     legendItem.getSymbol().getStyleClass().addAll(new String[] { "chart-line-symbol", "series" + paramInt, paramSeries.defaultColorStyleClass });
/*     */     
/* 542 */     return legendItem;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 548 */     private static final CssMetaData<LineChart<?, ?>, Boolean> CREATE_SYMBOLS = new CssMetaData<LineChart<?, ?>, Boolean>("-fx-create-symbols", 
/*     */         
/* 550 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(LineChart<?, ?> param2LineChart)
/*     */         {
/* 554 */           return (param2LineChart.createSymbols == null || !param2LineChart.createSymbols.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(LineChart<?, ?> param2LineChart) {
/* 559 */           return (StyleableProperty<Boolean>)param2LineChart.createSymbolsProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 566 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(XYChart.getClassCssMetaData());
/* 567 */       arrayList.add(CREATE_SYMBOLS);
/* 568 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 578 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 587 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum SortingPolicy
/*     */   {
/* 598 */     NONE,
/*     */ 
/*     */ 
/*     */     
/* 602 */     X_AXIS,
/*     */ 
/*     */ 
/*     */     
/* 606 */     Y_AXIS;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\LineChart.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */