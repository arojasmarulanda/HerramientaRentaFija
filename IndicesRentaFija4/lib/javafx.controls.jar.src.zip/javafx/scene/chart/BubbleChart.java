/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import com.sun.javafx.charts.Legend;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javafx.animation.FadeTransition;
/*     */ import javafx.animation.ParallelTransition;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.shape.Ellipse;
/*     */ import javafx.scene.shape.Shape;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BubbleChart<X, Y>
/*     */   extends XYChart<X, Y>
/*     */ {
/*     */   public BubbleChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1) {
/*  64 */     this(paramAxis, paramAxis1, FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BubbleChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1, @NamedArg("data") ObservableList<XYChart.Series<X, Y>> paramObservableList) {
/*  76 */     super(paramAxis, paramAxis1);
/*  77 */     if (!(paramAxis instanceof ValueAxis) || !(paramAxis1 instanceof ValueAxis)) {
/*  78 */       throw new IllegalArgumentException("Axis type incorrect, X and Y should both be NumberAxis");
/*     */     }
/*  80 */     setData(paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double getDoubleValue(Object paramObject, double paramDouble) {
/*  93 */     return !(paramObject instanceof Number) ? paramDouble : ((Number)paramObject).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutPlotChildren() {
/*  99 */     for (byte b = 0; b < getDataSize(); b++) {
/* 100 */       XYChart.Series<X, Y> series = getData().get(b);
/*     */       
/* 102 */       Iterator<XYChart.Data<X, Y>> iterator = getDisplayedDataIterator(series);
/* 103 */       while (iterator.hasNext()) {
/* 104 */         XYChart.Data data = iterator.next();
/* 105 */         double d1 = getXAxis().getDisplayPosition((X)data.getCurrentX());
/* 106 */         double d2 = getYAxis().getDisplayPosition((Y)data.getCurrentY());
/* 107 */         if (Double.isNaN(d1) || Double.isNaN(d2)) {
/*     */           continue;
/*     */         }
/* 110 */         Node node = data.getNode();
/*     */         
/* 112 */         if (node != null && 
/* 113 */           node instanceof StackPane) {
/* 114 */           Ellipse ellipse; StackPane stackPane = (StackPane)data.getNode();
/* 115 */           if (stackPane.getShape() == null) {
/* 116 */             ellipse = new Ellipse(getDoubleValue(data.getExtraValue(), 1.0D), getDoubleValue(data.getExtraValue(), 1.0D));
/* 117 */           } else if (stackPane.getShape() instanceof Ellipse) {
/* 118 */             ellipse = (Ellipse)stackPane.getShape();
/*     */           } else {
/*     */             return;
/*     */           } 
/* 122 */           ellipse.setRadiusX(getDoubleValue(data.getExtraValue(), 1.0D) * ((getXAxis() instanceof NumberAxis) ? Math.abs(((NumberAxis)getXAxis()).getScale()) : 1.0D));
/* 123 */           ellipse.setRadiusY(getDoubleValue(data.getExtraValue(), 1.0D) * ((getYAxis() instanceof NumberAxis) ? Math.abs(((NumberAxis)getYAxis()).getScale()) : 1.0D));
/*     */ 
/*     */ 
/*     */           
/* 127 */           stackPane.setShape((Shape)null);
/* 128 */           stackPane.setShape(ellipse);
/* 129 */           stackPane.setScaleShape(false);
/* 130 */           stackPane.setCenterShape(false);
/* 131 */           stackPane.setCacheShape(false);
/*     */           
/* 133 */           node.setLayoutX(d1);
/* 134 */           node.setLayoutY(d2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void dataItemAdded(XYChart.Series<X, Y> paramSeries, int paramInt, XYChart.Data<X, Y> paramData) {
/* 142 */     Node node = createBubble(paramSeries, getData().indexOf(paramSeries), paramData, paramInt);
/* 143 */     if (shouldAnimate()) {
/*     */       
/* 145 */       node.setOpacity(0.0D);
/* 146 */       getPlotChildren().add(node);
/* 147 */       FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 148 */       fadeTransition.setToValue(1.0D);
/* 149 */       fadeTransition.play();
/*     */     } else {
/* 151 */       getPlotChildren().add(node);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void dataItemRemoved(XYChart.Data<X, Y> paramData, XYChart.Series<X, Y> paramSeries) {
/* 156 */     Node node = paramData.getNode();
/* 157 */     if (shouldAnimate()) {
/*     */       
/* 159 */       FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 160 */       fadeTransition.setToValue(0.0D);
/* 161 */       fadeTransition.setOnFinished(paramActionEvent -> {
/*     */             getPlotChildren().remove(paramNode);
/*     */             removeDataItemFromDisplay(paramSeries, paramData);
/*     */             paramNode.setOpacity(1.0D);
/*     */           });
/* 166 */       fadeTransition.play();
/*     */     } else {
/* 168 */       getPlotChildren().remove(node);
/* 169 */       removeDataItemFromDisplay(paramSeries, paramData);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dataItemChanged(XYChart.Data<X, Y> paramData) {}
/*     */ 
/*     */   
/*     */   protected void seriesAdded(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 179 */     for (byte b = 0; b < paramSeries.getData().size(); b++) {
/* 180 */       XYChart.Data<X, Y> data = paramSeries.getData().get(b);
/* 181 */       Node node = createBubble(paramSeries, paramInt, data, b);
/* 182 */       if (shouldAnimate()) {
/* 183 */         node.setOpacity(0.0D);
/* 184 */         getPlotChildren().add(node);
/*     */         
/* 186 */         FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 187 */         fadeTransition.setToValue(1.0D);
/* 188 */         fadeTransition.play();
/*     */       } else {
/* 190 */         getPlotChildren().add(node);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void seriesRemoved(XYChart.Series<X, Y> paramSeries) {
/* 197 */     if (shouldAnimate()) {
/* 198 */       ParallelTransition parallelTransition = new ParallelTransition();
/* 199 */       parallelTransition.setOnFinished(paramActionEvent -> removeSeriesFromDisplay(paramSeries));
/*     */ 
/*     */       
/* 202 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) {
/* 203 */         Node node = data.getNode();
/*     */         
/* 205 */         FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 206 */         fadeTransition.setToValue(0.0D);
/* 207 */         fadeTransition.setOnFinished(paramActionEvent -> {
/*     */               getPlotChildren().remove(paramNode);
/*     */               paramNode.setOpacity(1.0D);
/*     */             });
/* 211 */         parallelTransition.getChildren().add(fadeTransition);
/*     */       } 
/* 213 */       parallelTransition.play();
/*     */     } else {
/* 215 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) {
/* 216 */         Node node = data.getNode();
/* 217 */         getPlotChildren().remove(node);
/*     */       } 
/* 219 */       removeSeriesFromDisplay(paramSeries);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Node createBubble(XYChart.Series<X, Y> paramSeries, int paramInt1, final XYChart.Data<X, Y> item, int paramInt2) {
/* 235 */     Node node = item.getNode();
/*     */     
/* 237 */     if (node == null) {
/* 238 */       node = new StackPane() {
/*     */           public Object queryAccessibleAttribute(AccessibleAttribute param1AccessibleAttribute, Object... param1VarArgs) {
/*     */             String str;
/* 241 */             switch (param1AccessibleAttribute) {
/*     */               case TEXT:
/* 243 */                 str = getAccessibleText();
/* 244 */                 if (item.getExtraValue() == null) {
/* 245 */                   return str;
/*     */                 }
/* 247 */                 return str + " Bubble radius is " + str;
/*     */             } 
/*     */             
/* 250 */             return super.queryAccessibleAttribute(param1AccessibleAttribute, param1VarArgs);
/*     */           }
/*     */         };
/*     */       
/* 254 */       node.setAccessibleRole(AccessibleRole.TEXT);
/* 255 */       node.setAccessibleRoleDescription("Bubble");
/* 256 */       node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
/* 257 */       item.setNode(node);
/*     */     } 
/*     */     
/* 260 */     node.getStyleClass().setAll(new String[] { "chart-bubble", "series" + paramInt1, "data" + paramInt2, paramSeries.defaultColorStyleClass });
/*     */     
/* 262 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateAxisRange() {
/* 273 */     Axis<X> axis = getXAxis();
/* 274 */     Axis<Y> axis1 = getYAxis();
/* 275 */     ArrayList<X> arrayList = null;
/* 276 */     ArrayList<Y> arrayList1 = null;
/* 277 */     if (axis.isAutoRanging()) arrayList = new ArrayList(); 
/* 278 */     if (axis1.isAutoRanging()) arrayList1 = new ArrayList(); 
/* 279 */     boolean bool1 = axis instanceof CategoryAxis;
/* 280 */     boolean bool2 = axis1 instanceof CategoryAxis;
/* 281 */     if (arrayList != null || arrayList1 != null) {
/* 282 */       for (XYChart.Series<X, Y> series : getData()) {
/* 283 */         for (XYChart.Data data : series.getData()) {
/* 284 */           if (arrayList != null) {
/* 285 */             if (bool1) {
/* 286 */               arrayList.add(data.getXValue());
/*     */             } else {
/* 288 */               arrayList.add(axis.toRealValue(axis.toNumericValue((X)data.getXValue()) + getDoubleValue(data.getExtraValue(), 0.0D)));
/* 289 */               arrayList.add(axis.toRealValue(axis.toNumericValue((X)data.getXValue()) - getDoubleValue(data.getExtraValue(), 0.0D)));
/*     */             } 
/*     */           }
/* 292 */           if (arrayList1 != null) {
/* 293 */             if (bool2) {
/* 294 */               arrayList1.add(data.getYValue()); continue;
/*     */             } 
/* 296 */             arrayList1.add(axis1.toRealValue(axis1.toNumericValue((Y)data.getYValue()) + getDoubleValue(data.getExtraValue(), 0.0D)));
/* 297 */             arrayList1.add(axis1.toRealValue(axis1.toNumericValue((Y)data.getYValue()) - getDoubleValue(data.getExtraValue(), 0.0D)));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 302 */       if (arrayList != null) axis.invalidateRange(arrayList); 
/* 303 */       if (arrayList1 != null) axis1.invalidateRange(arrayList1);
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   Legend.LegendItem createLegendItemForSeries(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 309 */     Legend.LegendItem legendItem = new Legend.LegendItem(paramSeries.getName());
/* 310 */     legendItem.getSymbol().getStyleClass().addAll(new String[] { "series" + paramInt, "chart-bubble", "bubble-legend-symbol", paramSeries.defaultColorStyleClass });
/*     */     
/* 312 */     return legendItem;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\BubbleChart.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */