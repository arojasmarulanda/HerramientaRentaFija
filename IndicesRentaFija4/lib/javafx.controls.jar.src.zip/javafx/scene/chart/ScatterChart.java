/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import com.sun.javafx.charts.Legend;
/*     */ import java.util.Iterator;
/*     */ import javafx.animation.FadeTransition;
/*     */ import javafx.animation.ParallelTransition;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScatterChart<X, Y>
/*     */   extends XYChart<X, Y>
/*     */ {
/*     */   public ScatterChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1) {
/*  58 */     this(paramAxis, paramAxis1, FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScatterChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1, @NamedArg("data") ObservableList<XYChart.Series<X, Y>> paramObservableList) {
/*  69 */     super(paramAxis, paramAxis1);
/*  70 */     setData(paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dataItemAdded(XYChart.Series<X, Y> paramSeries, int paramInt, XYChart.Data<X, Y> paramData) {
/*  77 */     Node node = paramData.getNode();
/*     */     
/*  79 */     if (node == null) {
/*  80 */       node = new StackPane();
/*  81 */       node.setAccessibleRole(AccessibleRole.TEXT);
/*  82 */       node.setAccessibleRoleDescription("Point");
/*  83 */       node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
/*  84 */       paramData.setNode(node);
/*     */     } 
/*     */     
/*  87 */     node.getStyleClass().setAll(new String[] { "chart-symbol", "series" + getData().indexOf(paramSeries), "data" + paramInt, paramSeries.defaultColorStyleClass });
/*     */ 
/*     */     
/*  90 */     if (shouldAnimate()) {
/*  91 */       node.setOpacity(0.0D);
/*  92 */       getPlotChildren().add(node);
/*  93 */       FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/*  94 */       fadeTransition.setToValue(1.0D);
/*  95 */       fadeTransition.play();
/*     */     } else {
/*  97 */       getPlotChildren().add(node);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void dataItemRemoved(XYChart.Data<X, Y> paramData, XYChart.Series<X, Y> paramSeries) {
/* 103 */     Node node = paramData.getNode();
/*     */     
/* 105 */     if (node != null) {
/* 106 */       node.focusTraversableProperty().unbind();
/*     */     }
/*     */     
/* 109 */     if (shouldAnimate()) {
/*     */       
/* 111 */       FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 112 */       fadeTransition.setToValue(0.0D);
/* 113 */       fadeTransition.setOnFinished(paramActionEvent -> {
/*     */             getPlotChildren().remove(paramNode);
/*     */             removeDataItemFromDisplay(paramSeries, paramData);
/*     */             paramNode.setOpacity(1.0D);
/*     */           });
/* 118 */       fadeTransition.play();
/*     */     } else {
/* 120 */       getPlotChildren().remove(node);
/* 121 */       removeDataItemFromDisplay(paramSeries, paramData);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dataItemChanged(XYChart.Data<X, Y> paramData) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void seriesAdded(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 132 */     for (byte b = 0; b < paramSeries.getData().size(); b++) {
/* 133 */       dataItemAdded(paramSeries, b, paramSeries.getData().get(b));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void seriesRemoved(XYChart.Series<X, Y> paramSeries) {
/* 140 */     if (shouldAnimate()) {
/* 141 */       ParallelTransition parallelTransition = new ParallelTransition();
/* 142 */       parallelTransition.setOnFinished(paramActionEvent -> removeSeriesFromDisplay(paramSeries));
/*     */ 
/*     */       
/* 145 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) {
/* 146 */         Node node = data.getNode();
/*     */         
/* 148 */         FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 149 */         fadeTransition.setToValue(0.0D);
/* 150 */         fadeTransition.setOnFinished(paramActionEvent -> {
/*     */               getPlotChildren().remove(paramNode);
/*     */               paramNode.setOpacity(1.0D);
/*     */             });
/* 154 */         parallelTransition.getChildren().add(fadeTransition);
/*     */       } 
/* 156 */       parallelTransition.play();
/*     */     } else {
/* 158 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) {
/* 159 */         Node node = data.getNode();
/* 160 */         getPlotChildren().remove(node);
/*     */       } 
/* 162 */       removeSeriesFromDisplay(paramSeries);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutPlotChildren() {
/* 169 */     for (byte b = 0; b < getDataSize(); b++) {
/* 170 */       XYChart.Series<X, Y> series = getData().get(b);
/* 171 */       for (Iterator<XYChart.Data<X, Y>> iterator = getDisplayedDataIterator(series); iterator.hasNext(); ) {
/* 172 */         XYChart.Data data = iterator.next();
/* 173 */         double d1 = getXAxis().getDisplayPosition((X)data.getCurrentX());
/* 174 */         double d2 = getYAxis().getDisplayPosition((Y)data.getCurrentY());
/* 175 */         if (Double.isNaN(d1) || Double.isNaN(d2)) {
/*     */           continue;
/*     */         }
/* 178 */         Node node = data.getNode();
/* 179 */         if (node != null) {
/* 180 */           double d3 = node.prefWidth(-1.0D);
/* 181 */           double d4 = node.prefHeight(-1.0D);
/* 182 */           node.resizeRelocate(d1 - d3 / 2.0D, d2 - d4 / 2.0D, d3, d4);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   Legend.LegendItem createLegendItemForSeries(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 190 */     Legend.LegendItem legendItem = new Legend.LegendItem(paramSeries.getName());
/* 191 */     Node node = paramSeries.getData().isEmpty() ? null : ((XYChart.Data)paramSeries.getData().get(0)).getNode();
/* 192 */     if (node != null) {
/* 193 */       legendItem.getSymbol().getStyleClass().addAll(node.getStyleClass());
/*     */     }
/* 195 */     return legendItem;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\ScatterChart.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */