/*      */ package javafx.scene.chart;
/*      */ 
/*      */ import com.sun.javafx.charts.Legend;
/*      */ import com.sun.javafx.collections.NonIterableChange;
/*      */ import java.util.ArrayList;
/*      */ import java.util.BitSet;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javafx.animation.Interpolator;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.KeyValue;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.binding.StringBinding;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.beans.property.StringProperty;
/*      */ import javafx.beans.property.StringPropertyBase;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableBooleanProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.BooleanConverter;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.geometry.Side;
/*      */ import javafx.scene.Group;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.layout.Region;
/*      */ import javafx.scene.shape.ClosePath;
/*      */ import javafx.scene.shape.Line;
/*      */ import javafx.scene.shape.LineTo;
/*      */ import javafx.scene.shape.MoveTo;
/*      */ import javafx.scene.shape.Path;
/*      */ import javafx.scene.shape.PathElement;
/*      */ import javafx.scene.shape.Rectangle;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class XYChart<X, Y>
/*      */   extends Chart
/*      */ {
/*   99 */   private final BitSet colorBits = new BitSet(8);
/*  100 */   static String DEFAULT_COLOR = "default-color";
/*  101 */   final Map<Series<X, Y>, Integer> seriesColorMap = new HashMap<>();
/*      */   private boolean rangeValid = false;
/*  103 */   private final Line verticalZeroLine = new Line();
/*  104 */   private final Line horizontalZeroLine = new Line();
/*  105 */   private final Path verticalGridLines = new Path();
/*  106 */   private final Path horizontalGridLines = new Path();
/*  107 */   private final Path horizontalRowFill = new Path();
/*  108 */   private final Path verticalRowFill = new Path();
/*  109 */   private final Region plotBackground = new Region();
/*  110 */   private final Group plotArea = new Group() { public void requestLayout() {} }
/*      */   ;
/*      */   
/*  113 */   private final Group plotContent = new Group();
/*  114 */   private final Rectangle plotAreaClip = new Rectangle();
/*      */   
/*  116 */   private final List<Series<X, Y>> displayedSeries = new ArrayList<>();
/*  117 */   private Legend legend = new Legend();
/*      */   private final ListChangeListener<Series<X, Y>> seriesChanged;
/*      */   private final Axis<X> xAxis;
/*  120 */   private final Axis<Y> yAxis; private ObjectProperty<ObservableList<Series<X, Y>>> data; private BooleanProperty verticalGridLinesVisible; private BooleanProperty horizontalGridLinesVisible; private BooleanProperty alternativeColumnFillVisible; private BooleanProperty alternativeRowFillVisible; private BooleanProperty verticalZeroLineVisible; private BooleanProperty horizontalZeroLineVisible; public Axis<X> getXAxis() { return this.xAxis; } public Axis<Y> getYAxis() { return this.yAxis; } public final ObservableList<Series<X, Y>> getData() { return this.data.getValue(); } public final void setData(ObservableList<Series<X, Y>> paramObservableList) { this.data.setValue(paramObservableList); } public final ObjectProperty<ObservableList<Series<X, Y>>> dataProperty() { return this.data; } public final boolean getVerticalGridLinesVisible() { return this.verticalGridLinesVisible.get(); } public XYChart(Axis<X> paramAxis, Axis<Y> paramAxis1) { this.seriesChanged = (paramChange -> {
/*      */         ObservableList observableList = paramChange.getList();
/*      */ 
/*      */         
/*      */         while (paramChange.next()) {
/*      */           if (paramChange.wasPermutated()) {
/*      */             this.displayedSeries.sort(());
/*      */           }
/*      */           
/*      */           if (paramChange.getRemoved().size() > 0) {
/*      */             updateLegend();
/*      */           }
/*      */           
/*      */           HashSet<Series<X, Y>> hashSet = new HashSet<>(this.displayedSeries);
/*      */           
/*      */           hashSet.removeAll(paramChange.getRemoved());
/*      */           
/*      */           for (Series<X, Y> series : paramChange.getAddedSubList()) {
/*      */             if (!hashSet.add(series)) {
/*      */               throw new IllegalArgumentException("Duplicate series added");
/*      */             }
/*      */           } 
/*      */           
/*      */           for (Series<X, Y> series : paramChange.getRemoved()) {
/*      */             series.setToRemove = true;
/*      */             
/*      */             seriesRemoved(series);
/*      */           } 
/*      */           
/*      */           int i = paramChange.getFrom();
/*      */           
/*      */           while (i < paramChange.getTo() && !paramChange.wasPermutated()) {
/*      */             Series<X, Y> series = paramChange.getList().get(i);
/*      */             
/*      */             series.setChart(this);
/*      */             
/*      */             if (series.setToRemove) {
/*      */               series.setToRemove = false;
/*      */               
/*      */               series.getChart().seriesBeingRemovedIsAdded(series);
/*      */             } 
/*      */             
/*      */             this.displayedSeries.add(series);
/*      */             
/*      */             int j = this.colorBits.nextClearBit(0);
/*      */             
/*      */             this.colorBits.set(j, true);
/*      */             
/*      */             series.defaultColorStyleClass = DEFAULT_COLOR + DEFAULT_COLOR;
/*      */             
/*      */             this.seriesColorMap.put(series, Integer.valueOf(j % 8));
/*      */             
/*      */             seriesAdded(series, i);
/*      */             
/*      */             i++;
/*      */           } 
/*      */           
/*      */           if (paramChange.getFrom() < paramChange.getTo()) {
/*      */             updateLegend();
/*      */           }
/*      */           
/*      */           seriesChanged((ListChangeListener.Change)paramChange);
/*      */         } 
/*      */         
/*      */         invalidateRange();
/*      */         
/*      */         requestChartLayout();
/*      */       });
/*      */     
/*  189 */     this.data = new ObjectPropertyBase<ObservableList<Series<X, Y>>>() { private ObservableList<XYChart.Series<X, Y>> old;
/*      */         
/*      */         protected void invalidated() {
/*  192 */           ObservableList<XYChart.Series<X, Y>> observableList = getValue();
/*  193 */           if (observableList == this.old)
/*  194 */             return;  byte b = -1;
/*      */           
/*  196 */           if (this.old != null) {
/*  197 */             this.old.removeListener(XYChart.this.seriesChanged);
/*      */ 
/*      */ 
/*      */             
/*  201 */             if (observableList != null && this.old.size() > 0) {
/*  202 */               b = ((XYChart.Series)this.old.get(0)).getChart().getAnimated() ? 1 : 2;
/*  203 */               ((XYChart.Series)this.old.get(0)).getChart().setAnimated(false);
/*      */             } 
/*      */           } 
/*  206 */           if (observableList != null) observableList.addListener(XYChart.this.seriesChanged);
/*      */           
/*  208 */           if (this.old != null || observableList != null) {
/*  209 */             final List removed = (List)((this.old != null) ? this.old : Collections.emptyList());
/*  210 */             boolean bool = (observableList != null) ? observableList.size() : false;
/*      */             
/*  212 */             if (!bool || !list.isEmpty()) {
/*  213 */               XYChart.this.seriesChanged.onChanged(new NonIterableChange<XYChart.Series<X, Y>>(0, bool, observableList) { public List<XYChart.Series<X, Y>> getRemoved() {
/*  214 */                       return removed;
/*      */                     } protected int[] getPermutation() {
/*  216 */                       return new int[0];
/*      */                     } }
/*      */                 );
/*      */             }
/*  220 */           } else if (this.old != null && this.old.size() > 0) {
/*      */             
/*  222 */             XYChart.this.seriesChanged.onChanged(new NonIterableChange<XYChart.Series<X, Y>>(0, 0, observableList) { public List<XYChart.Series<X, Y>> getRemoved() {
/*  223 */                     return XYChart.null.this.old;
/*      */                   } protected int[] getPermutation() {
/*  225 */                     return new int[0];
/*      */                   } }
/*      */               );
/*      */           } 
/*      */           
/*  230 */           if (observableList != null && observableList.size() > 0 && b != -1) {
/*  231 */             ((XYChart.Series)observableList.get(0)).getChart().setAnimated((b == 1));
/*      */           }
/*  233 */           this.old = observableList;
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  237 */           return XYChart.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  241 */           return "data";
/*      */         } }
/*      */       ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  249 */     this.verticalGridLinesVisible = new StyleableBooleanProperty(true) {
/*      */         protected void invalidated() {
/*  251 */           XYChart.this.requestChartLayout();
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  256 */           return XYChart.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  261 */           return "verticalGridLinesVisible";
/*      */         }
/*      */ 
/*      */         
/*      */         public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
/*  266 */           return XYChart.StyleableProperties.VERTICAL_GRID_LINE_VISIBLE;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  280 */     this.horizontalGridLinesVisible = new StyleableBooleanProperty(true) {
/*      */         protected void invalidated() {
/*  282 */           XYChart.this.requestChartLayout();
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  287 */           return XYChart.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  292 */           return "horizontalGridLinesVisible";
/*      */         }
/*      */ 
/*      */         
/*      */         public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
/*  297 */           return XYChart.StyleableProperties.HORIZONTAL_GRID_LINE_VISIBLE;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  305 */     this.alternativeColumnFillVisible = new StyleableBooleanProperty(false) {
/*      */         protected void invalidated() {
/*  307 */           XYChart.this.requestChartLayout();
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  312 */           return XYChart.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  317 */           return "alternativeColumnFillVisible";
/*      */         }
/*      */ 
/*      */         
/*      */         public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
/*  322 */           return XYChart.StyleableProperties.ALTERNATIVE_COLUMN_FILL_VISIBLE;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  330 */     this.alternativeRowFillVisible = new StyleableBooleanProperty(true) {
/*      */         protected void invalidated() {
/*  332 */           XYChart.this.requestChartLayout();
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  337 */           return XYChart.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  342 */           return "alternativeRowFillVisible";
/*      */         }
/*      */ 
/*      */         
/*      */         public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
/*  347 */           return XYChart.StyleableProperties.ALTERNATIVE_ROW_FILL_VISIBLE;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  360 */     this.verticalZeroLineVisible = new StyleableBooleanProperty(true) {
/*      */         protected void invalidated() {
/*  362 */           XYChart.this.requestChartLayout();
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  367 */           return XYChart.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  372 */           return "verticalZeroLineVisible";
/*      */         }
/*      */ 
/*      */         
/*      */         public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
/*  377 */           return XYChart.StyleableProperties.VERTICAL_ZERO_LINE_VISIBLE;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  390 */     this.horizontalZeroLineVisible = new StyleableBooleanProperty(true) {
/*      */         protected void invalidated() {
/*  392 */           XYChart.this.requestChartLayout();
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  397 */           return XYChart.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  402 */           return "horizontalZeroLineVisible";
/*      */         }
/*      */ 
/*      */         
/*      */         public CssMetaData<XYChart<?, ?>, Boolean> getCssMetaData() {
/*  407 */           return XYChart.StyleableProperties.HORIZONTAL_ZERO_LINE_VISIBLE;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  437 */     this.xAxis = paramAxis;
/*  438 */     if (paramAxis.getSide() == null) paramAxis.setSide(Side.BOTTOM); 
/*  439 */     paramAxis.setEffectiveOrientation(Orientation.HORIZONTAL);
/*  440 */     this.yAxis = paramAxis1;
/*  441 */     if (paramAxis1.getSide() == null) paramAxis1.setSide(Side.LEFT); 
/*  442 */     paramAxis1.setEffectiveOrientation(Orientation.VERTICAL);
/*      */     
/*  444 */     paramAxis.autoRangingProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> updateAxisRange());
/*      */ 
/*      */     
/*  447 */     paramAxis1.autoRangingProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> updateAxisRange());
/*      */ 
/*      */ 
/*      */     
/*  451 */     getChartChildren().addAll(new Node[] { this.plotBackground, this.plotArea, paramAxis, paramAxis1 });
/*      */     
/*  453 */     this.plotArea.setAutoSizeChildren(false);
/*  454 */     this.plotContent.setAutoSizeChildren(false);
/*      */     
/*  456 */     this.plotAreaClip.setSmooth(false);
/*  457 */     this.plotArea.setClip(this.plotAreaClip);
/*      */     
/*  459 */     this.plotArea.getChildren().addAll(new Node[] { this.verticalRowFill, this.horizontalRowFill, this.verticalGridLines, this.horizontalGridLines, this.verticalZeroLine, this.horizontalZeroLine, this.plotContent });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  465 */     this.plotContent.getStyleClass().setAll(new String[] { "plot-content" });
/*  466 */     this.plotBackground.getStyleClass().setAll(new String[] { "chart-plot-background" });
/*  467 */     this.verticalRowFill.getStyleClass().setAll(new String[] { "chart-alternative-column-fill" });
/*  468 */     this.horizontalRowFill.getStyleClass().setAll(new String[] { "chart-alternative-row-fill" });
/*  469 */     this.verticalGridLines.getStyleClass().setAll(new String[] { "chart-vertical-grid-lines" });
/*  470 */     this.horizontalGridLines.getStyleClass().setAll(new String[] { "chart-horizontal-grid-lines" });
/*  471 */     this.verticalZeroLine.getStyleClass().setAll(new String[] { "chart-vertical-zero-line" });
/*  472 */     this.horizontalZeroLine.getStyleClass().setAll(new String[] { "chart-horizontal-zero-line" });
/*      */     
/*  474 */     this.plotContent.setManaged(false);
/*  475 */     this.plotArea.setManaged(false);
/*      */     
/*  477 */     animatedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*      */           if (getXAxis() != null)
/*      */             getXAxis().setAnimated(paramBoolean2.booleanValue());  if (getYAxis() != null)
/*      */             getYAxis().setAnimated(paramBoolean2.booleanValue()); 
/*  481 */         }); setLegend(this.legend); }
/*      */   public final void setVerticalGridLinesVisible(boolean paramBoolean) { this.verticalGridLinesVisible.set(paramBoolean); }
/*      */   public final BooleanProperty verticalGridLinesVisibleProperty() { return this.verticalGridLinesVisible; } public final boolean isHorizontalGridLinesVisible() {
/*      */     return this.horizontalGridLinesVisible.get();
/*      */   } public final void setHorizontalGridLinesVisible(boolean paramBoolean) {
/*      */     this.horizontalGridLinesVisible.set(paramBoolean);
/*      */   } public final BooleanProperty horizontalGridLinesVisibleProperty() {
/*      */     return this.horizontalGridLinesVisible;
/*      */   } public final boolean isAlternativeColumnFillVisible() {
/*      */     return this.alternativeColumnFillVisible.getValue().booleanValue();
/*      */   } final int getDataSize() {
/*  492 */     ObservableList<Series<X, Y>> observableList = getData();
/*  493 */     return (observableList != null) ? observableList.size() : 0; } public final void setAlternativeColumnFillVisible(boolean paramBoolean) { this.alternativeColumnFillVisible.setValue(Boolean.valueOf(paramBoolean)); } public final BooleanProperty alternativeColumnFillVisibleProperty() { return this.alternativeColumnFillVisible; }
/*      */   public final boolean isAlternativeRowFillVisible() { return this.alternativeRowFillVisible.getValue().booleanValue(); }
/*      */   public final void setAlternativeRowFillVisible(boolean paramBoolean) { this.alternativeRowFillVisible.setValue(Boolean.valueOf(paramBoolean)); }
/*      */   public final BooleanProperty alternativeRowFillVisibleProperty() { return this.alternativeRowFillVisible; }
/*      */   public final boolean isVerticalZeroLineVisible() { return this.verticalZeroLineVisible.get(); }
/*  498 */   private void seriesNameChanged() { updateLegend();
/*  499 */     requestChartLayout(); } public final void setVerticalZeroLineVisible(boolean paramBoolean) { this.verticalZeroLineVisible.set(paramBoolean); } public final BooleanProperty verticalZeroLineVisibleProperty() { return this.verticalZeroLineVisible; }
/*      */   public final boolean isHorizontalZeroLineVisible() { return this.horizontalZeroLineVisible.get(); }
/*      */   public final void setHorizontalZeroLineVisible(boolean paramBoolean) { this.horizontalZeroLineVisible.set(paramBoolean); }
/*      */   public final BooleanProperty horizontalZeroLineVisibleProperty() { return this.horizontalZeroLineVisible; }
/*      */   protected ObservableList<Node> getPlotChildren() { return this.plotContent.getChildren(); }
/*  504 */   private void dataItemsChanged(Series<X, Y> paramSeries, List<Data<X, Y>> paramList, int paramInt1, int paramInt2, boolean paramBoolean) { for (Data<X, Y> data : paramList) {
/*  505 */       dataItemRemoved(data, paramSeries);
/*      */     }
/*  507 */     for (int i = paramInt1; i < paramInt2; i++) {
/*  508 */       Data<X, Y> data = paramSeries.getData().get(i);
/*  509 */       dataItemAdded(paramSeries, i, data);
/*      */     } 
/*  511 */     invalidateRange();
/*  512 */     requestChartLayout(); }
/*      */ 
/*      */   
/*      */   private <T> void dataValueChanged(Data<X, Y> paramData, T paramT, ObjectProperty<T> paramObjectProperty) {
/*  516 */     if (paramObjectProperty.get() != paramT) invalidateRange(); 
/*  517 */     dataItemChanged(paramData);
/*  518 */     if (shouldAnimate()) {
/*  519 */       animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(paramObjectProperty, paramObjectProperty
/*  520 */                   .get()) }), new KeyFrame(
/*  521 */               Duration.millis(700.0D), new KeyValue[] { new KeyValue(paramObjectProperty, paramT, Interpolator.EASE_BOTH) }) });
/*      */     } else {
/*      */       
/*  524 */       paramObjectProperty.set(paramT);
/*  525 */       requestChartLayout();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateLegend() {
/*  533 */     ArrayList<Legend.LegendItem> arrayList = new ArrayList();
/*  534 */     if (getData() != null) {
/*  535 */       for (byte b = 0; b < getData().size(); b++) {
/*  536 */         Series<X, Y> series = getData().get(b);
/*  537 */         arrayList.add(createLegendItemForSeries(series, b));
/*      */       } 
/*      */     }
/*  540 */     this.legend.getItems().setAll(arrayList);
/*  541 */     if (arrayList.size() > 0) {
/*  542 */       if (getLegend() == null) {
/*  543 */         setLegend(this.legend);
/*      */       }
/*      */     } else {
/*  546 */       setLegend((Node)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Legend.LegendItem createLegendItemForSeries(Series<X, Y> paramSeries, int paramInt) {
/*  558 */     return new Legend.LegendItem(paramSeries.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void seriesBeingRemovedIsAdded(Series<X, Y> paramSeries) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void dataBeingRemovedIsAdded(Data<X, Y> paramData, Series<X, Y> paramSeries) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void seriesChanged(ListChangeListener.Change<? extends Series> paramChange) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invalidateRange() {
/*  631 */     this.rangeValid = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateAxisRange() {
/*  640 */     Axis<X> axis = getXAxis();
/*  641 */     Axis<Y> axis1 = getYAxis();
/*  642 */     ArrayList<X> arrayList = null;
/*  643 */     ArrayList<Y> arrayList1 = null;
/*  644 */     if (axis.isAutoRanging()) arrayList = new ArrayList(); 
/*  645 */     if (axis1.isAutoRanging()) arrayList1 = new ArrayList(); 
/*  646 */     if (arrayList != null || arrayList1 != null) {
/*  647 */       for (Series<X, Y> series : getData()) {
/*  648 */         for (Data data : series.getData()) {
/*  649 */           if (arrayList != null) arrayList.add(data.getXValue()); 
/*  650 */           if (arrayList1 != null) arrayList1.add(data.getYValue()); 
/*      */         } 
/*      */       } 
/*  653 */       if (arrayList != null) axis.invalidateRange(arrayList); 
/*  654 */       if (arrayList1 != null) axis1.invalidateRange(arrayList1);
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void layoutChartChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  667 */     if (getData() == null)
/*  668 */       return;  if (!this.rangeValid) {
/*  669 */       this.rangeValid = true;
/*  670 */       if (getData() != null) updateAxisRange();
/*      */     
/*      */     } 
/*  673 */     paramDouble1 = snapPositionY(paramDouble1);
/*  674 */     paramDouble2 = snapPositionX(paramDouble2);
/*      */     
/*  676 */     Axis<X> axis = getXAxis();
/*  677 */     ObservableList<Axis.TickMark<X>> observableList = axis.getTickMarks();
/*  678 */     Axis<Y> axis1 = getYAxis();
/*  679 */     ObservableList<Axis.TickMark<Y>> observableList1 = axis1.getTickMarks();
/*      */     
/*  681 */     if (axis == null || axis1 == null)
/*      */       return; 
/*  683 */     double d1 = 0.0D;
/*  684 */     double d2 = 30.0D;
/*  685 */     double d3 = 0.0D;
/*  686 */     double d4 = 0.0D;
/*  687 */     for (byte b = 0; b < 5; b++) {
/*  688 */       d4 = snapSizeY(paramDouble4 - d2);
/*  689 */       if (d4 < 0.0D) {
/*  690 */         d4 = 0.0D;
/*      */       }
/*  692 */       d3 = axis1.prefWidth(d4);
/*  693 */       d1 = snapSizeX(paramDouble3 - d3);
/*  694 */       if (d1 < 0.0D) {
/*  695 */         d1 = 0.0D;
/*      */       }
/*  697 */       double d = axis.prefHeight(d1);
/*  698 */       if (d == d2)
/*  699 */         break;  d2 = d;
/*      */     } 
/*      */     
/*  702 */     d1 = Math.ceil(d1);
/*  703 */     d2 = Math.ceil(d2);
/*  704 */     d3 = Math.ceil(d3);
/*  705 */     d4 = Math.ceil(d4);
/*      */     
/*  707 */     double d5 = 0.0D;
/*  708 */     switch (axis.getEffectiveSide()) {
/*      */       case TOP:
/*  710 */         axis.setVisible(true);
/*  711 */         d5 = paramDouble1 + 1.0D;
/*  712 */         paramDouble1 += d2;
/*      */         break;
/*      */       case BOTTOM:
/*  715 */         axis.setVisible(true);
/*  716 */         d5 = paramDouble1 + d4;
/*      */         break;
/*      */     } 
/*      */     
/*  720 */     double d6 = 0.0D;
/*  721 */     switch (axis1.getEffectiveSide()) {
/*      */       case LEFT:
/*  723 */         axis1.setVisible(true);
/*  724 */         d6 = paramDouble2 + 1.0D;
/*  725 */         paramDouble2 += d3;
/*      */         break;
/*      */       case RIGHT:
/*  728 */         axis1.setVisible(true);
/*  729 */         d6 = paramDouble2 + d1;
/*      */         break;
/*      */     } 
/*  732 */     axis.resizeRelocate(paramDouble2, d5, d1, d2);
/*  733 */     axis1.resizeRelocate(d6, paramDouble1, d3, d4);
/*      */ 
/*      */     
/*  736 */     axis.requestAxisLayout();
/*  737 */     axis.layout();
/*  738 */     axis1.requestAxisLayout();
/*  739 */     axis1.layout();
/*      */     
/*  741 */     layoutPlotChildren();
/*      */     
/*  743 */     double d7 = axis.getZeroPosition();
/*  744 */     double d8 = axis1.getZeroPosition();
/*      */     
/*  746 */     if (Double.isNaN(d7) || !isVerticalZeroLineVisible()) {
/*  747 */       this.verticalZeroLine.setVisible(false);
/*      */     } else {
/*  749 */       this.verticalZeroLine.setStartX(paramDouble2 + d7 + 0.5D);
/*  750 */       this.verticalZeroLine.setStartY(paramDouble1);
/*  751 */       this.verticalZeroLine.setEndX(paramDouble2 + d7 + 0.5D);
/*  752 */       this.verticalZeroLine.setEndY(paramDouble1 + d4);
/*  753 */       this.verticalZeroLine.setVisible(true);
/*      */     } 
/*  755 */     if (Double.isNaN(d8) || !isHorizontalZeroLineVisible()) {
/*  756 */       this.horizontalZeroLine.setVisible(false);
/*      */     } else {
/*  758 */       this.horizontalZeroLine.setStartX(paramDouble2);
/*  759 */       this.horizontalZeroLine.setStartY(paramDouble1 + d8 + 0.5D);
/*  760 */       this.horizontalZeroLine.setEndX(paramDouble2 + d1);
/*  761 */       this.horizontalZeroLine.setEndY(paramDouble1 + d8 + 0.5D);
/*  762 */       this.horizontalZeroLine.setVisible(true);
/*      */     } 
/*      */     
/*  765 */     this.plotBackground.resizeRelocate(paramDouble2, paramDouble1, d1, d4);
/*      */     
/*  767 */     this.plotAreaClip.setX(paramDouble2);
/*  768 */     this.plotAreaClip.setY(paramDouble1);
/*  769 */     this.plotAreaClip.setWidth(d1 + 1.0D);
/*  770 */     this.plotAreaClip.setHeight(d4 + 1.0D);
/*      */ 
/*      */     
/*  773 */     this.plotContent.setLayoutX(paramDouble2);
/*  774 */     this.plotContent.setLayoutY(paramDouble1);
/*  775 */     this.plotContent.requestLayout();
/*      */     
/*  777 */     this.verticalGridLines.getElements().clear();
/*  778 */     if (getVerticalGridLinesVisible()) {
/*  779 */       for (byte b1 = 0; b1 < observableList.size(); b1++) {
/*  780 */         Axis.TickMark<X> tickMark = observableList.get(b1);
/*  781 */         double d = axis.getDisplayPosition(tickMark.getValue());
/*  782 */         if ((d != d7 || !isVerticalZeroLineVisible()) && d > 0.0D && d <= d1) {
/*  783 */           this.verticalGridLines.getElements().add(new MoveTo(paramDouble2 + d + 0.5D, paramDouble1));
/*  784 */           this.verticalGridLines.getElements().add(new LineTo(paramDouble2 + d + 0.5D, paramDouble1 + d4));
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  789 */     this.horizontalGridLines.getElements().clear();
/*  790 */     if (isHorizontalGridLinesVisible()) {
/*  791 */       for (byte b1 = 0; b1 < observableList1.size(); b1++) {
/*  792 */         Axis.TickMark<Y> tickMark = observableList1.get(b1);
/*  793 */         double d = axis1.getDisplayPosition(tickMark.getValue());
/*  794 */         if ((d != d8 || !isHorizontalZeroLineVisible()) && d >= 0.0D && d < d4) {
/*  795 */           this.horizontalGridLines.getElements().add(new MoveTo(paramDouble2, paramDouble1 + d + 0.5D));
/*  796 */           this.horizontalGridLines.getElements().add(new LineTo(paramDouble2 + d1, paramDouble1 + d + 0.5D));
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  802 */     this.verticalRowFill.getElements().clear();
/*  803 */     if (isAlternativeColumnFillVisible()) {
/*      */       
/*  805 */       ArrayList<Double> arrayList1 = new ArrayList();
/*  806 */       ArrayList<Double> arrayList2 = new ArrayList(); byte b1;
/*  807 */       for (b1 = 0; b1 < observableList.size(); b1++) {
/*  808 */         double d = axis.getDisplayPosition(((Axis.TickMark<X>)observableList.get(b1)).getValue());
/*  809 */         if (d == d7) {
/*  810 */           arrayList1.add(Double.valueOf(d));
/*  811 */           arrayList2.add(Double.valueOf(d));
/*  812 */         } else if (d < d7) {
/*  813 */           arrayList1.add(Double.valueOf(d));
/*      */         } else {
/*  815 */           arrayList2.add(Double.valueOf(d));
/*      */         } 
/*      */       } 
/*  818 */       Collections.sort(arrayList1);
/*  819 */       Collections.sort(arrayList2);
/*      */       
/*  821 */       for (b1 = 1; b1 < arrayList1.size(); b1 += 2) {
/*  822 */         if (b1 + 1 < arrayList1.size()) {
/*  823 */           double d9 = ((Double)arrayList1.get(b1)).doubleValue();
/*  824 */           double d10 = ((Double)arrayList1.get(b1 + 1)).doubleValue();
/*  825 */           this.verticalRowFill.getElements().addAll(new PathElement[] { new MoveTo(paramDouble2 + d9, paramDouble1), new LineTo(paramDouble2 + d9, paramDouble1 + d4), new LineTo(paramDouble2 + d10, paramDouble1 + d4), new LineTo(paramDouble2 + d10, paramDouble1), new ClosePath() });
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  834 */       for (b1 = 0; b1 < arrayList2.size(); b1 += 2) {
/*  835 */         if (b1 + 1 < arrayList2.size()) {
/*  836 */           double d9 = ((Double)arrayList2.get(b1)).doubleValue();
/*  837 */           double d10 = ((Double)arrayList2.get(b1 + 1)).doubleValue();
/*  838 */           this.verticalRowFill.getElements().addAll(new PathElement[] { new MoveTo(paramDouble2 + d9, paramDouble1), new LineTo(paramDouble2 + d9, paramDouble1 + d4), new LineTo(paramDouble2 + d10, paramDouble1 + d4), new LineTo(paramDouble2 + d10, paramDouble1), new ClosePath() });
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  848 */     this.horizontalRowFill.getElements().clear();
/*  849 */     if (isAlternativeRowFillVisible()) {
/*      */       
/*  851 */       ArrayList<Double> arrayList1 = new ArrayList();
/*  852 */       ArrayList<Double> arrayList2 = new ArrayList(); byte b1;
/*  853 */       for (b1 = 0; b1 < observableList1.size(); b1++) {
/*  854 */         double d = axis1.getDisplayPosition(((Axis.TickMark<Y>)observableList1.get(b1)).getValue());
/*  855 */         if (d == d8) {
/*  856 */           arrayList1.add(Double.valueOf(d));
/*  857 */           arrayList2.add(Double.valueOf(d));
/*  858 */         } else if (d < d8) {
/*  859 */           arrayList1.add(Double.valueOf(d));
/*      */         } else {
/*  861 */           arrayList2.add(Double.valueOf(d));
/*      */         } 
/*      */       } 
/*  864 */       Collections.sort(arrayList1);
/*  865 */       Collections.sort(arrayList2);
/*      */       
/*  867 */       for (b1 = 1; b1 < arrayList1.size(); b1 += 2) {
/*  868 */         if (b1 + 1 < arrayList1.size()) {
/*  869 */           double d9 = ((Double)arrayList1.get(b1)).doubleValue();
/*  870 */           double d10 = ((Double)arrayList1.get(b1 + 1)).doubleValue();
/*  871 */           this.horizontalRowFill.getElements().addAll(new PathElement[] { new MoveTo(paramDouble2, paramDouble1 + d9), new LineTo(paramDouble2 + d1, paramDouble1 + d9), new LineTo(paramDouble2 + d1, paramDouble1 + d10), new LineTo(paramDouble2, paramDouble1 + d10), new ClosePath() });
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  880 */       for (b1 = 0; b1 < arrayList2.size(); b1 += 2) {
/*  881 */         if (b1 + 1 < arrayList2.size()) {
/*  882 */           double d9 = ((Double)arrayList2.get(b1)).doubleValue();
/*  883 */           double d10 = ((Double)arrayList2.get(b1 + 1)).doubleValue();
/*  884 */           this.horizontalRowFill.getElements().addAll(new PathElement[] { new MoveTo(paramDouble2, paramDouble1 + d9), new LineTo(paramDouble2 + d1, paramDouble1 + d9), new LineTo(paramDouble2 + d1, paramDouble1 + d10), new LineTo(paramDouble2, paramDouble1 + d10), new ClosePath() });
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getSeriesIndex(Series<X, Y> paramSeries) {
/*  903 */     return this.displayedSeries.indexOf(paramSeries);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getSeriesSize() {
/*  911 */     return this.displayedSeries.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void removeSeriesFromDisplay(Series<X, Y> paramSeries) {
/*  921 */     if (paramSeries != null) paramSeries.setToRemove = false; 
/*  922 */     paramSeries.setChart(null);
/*  923 */     this.displayedSeries.remove(paramSeries);
/*  924 */     int i = ((Integer)this.seriesColorMap.remove(paramSeries)).intValue();
/*  925 */     this.colorBits.clear(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Iterator<Series<X, Y>> getDisplayedSeriesIterator() {
/*  936 */     return Collections.<Series<X, Y>>unmodifiableList(this.displayedSeries).iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final KeyFrame[] createSeriesRemoveTimeLine(Series<X, Y> paramSeries, long paramLong) {
/*  947 */     ArrayList<Node> arrayList = new ArrayList();
/*  948 */     arrayList.add(paramSeries.getNode());
/*  949 */     for (Data<X, Y> data : paramSeries.getData()) {
/*  950 */       if (data.getNode() != null) {
/*  951 */         arrayList.add(data.getNode());
/*      */       }
/*      */     } 
/*      */     
/*  955 */     KeyValue[] arrayOfKeyValue1 = new KeyValue[arrayList.size()];
/*  956 */     KeyValue[] arrayOfKeyValue2 = new KeyValue[arrayList.size()];
/*  957 */     for (byte b = 0; b < arrayList.size(); b++) {
/*  958 */       arrayOfKeyValue1[b] = new KeyValue(((Node)arrayList.get(b)).opacityProperty(), Integer.valueOf(1));
/*  959 */       arrayOfKeyValue2[b] = new KeyValue(((Node)arrayList.get(b)).opacityProperty(), Integer.valueOf(0));
/*      */     } 
/*  961 */     return new KeyFrame[] { new KeyFrame(Duration.ZERO, arrayOfKeyValue1), new KeyFrame(
/*      */           
/*  963 */           Duration.millis(paramLong), paramActionEvent -> { getPlotChildren().removeAll(paramList); removeSeriesFromDisplay(paramSeries); }arrayOfKeyValue2) };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final X getCurrentDisplayedXValue(Data<X, Y> paramData) {
/*  978 */     return paramData.getCurrentX();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setCurrentDisplayedXValue(Data<X, Y> paramData, X paramX) {
/*  986 */     paramData.setCurrentX(paramX);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ObjectProperty<X> currentDisplayedXValueProperty(Data<X, Y> paramData) {
/*  994 */     return paramData.currentXProperty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Y getCurrentDisplayedYValue(Data<X, Y> paramData) {
/* 1004 */     return paramData.getCurrentY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setCurrentDisplayedYValue(Data<X, Y> paramData, Y paramY) {
/* 1013 */     paramData.setCurrentY(paramY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ObjectProperty<Y> currentDisplayedYValueProperty(Data<X, Y> paramData) {
/* 1021 */     return paramData.currentYProperty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object getCurrentDisplayedExtraValue(Data<X, Y> paramData) {
/* 1030 */     return paramData.getCurrentExtraValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setCurrentDisplayedExtraValue(Data<X, Y> paramData, Object paramObject) {
/* 1039 */     paramData.setCurrentExtraValue(paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ObjectProperty<Object> currentDisplayedExtraValueProperty(Data<X, Y> paramData) {
/* 1048 */     return paramData.currentExtraValueProperty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Iterator<Data<X, Y>> getDisplayedDataIterator(Series<X, Y> paramSeries) {
/* 1059 */     return Collections.<Data<X, Y>>unmodifiableList(paramSeries.displayedData).iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void removeDataItemFromDisplay(Series<X, Y> paramSeries, Data<X, Y> paramData) {
/* 1070 */     paramSeries.removeDataItemRef(paramData);
/*      */   }
/*      */ 
/*      */   
/*      */   private static class StyleableProperties
/*      */   {
/* 1076 */     private static final CssMetaData<XYChart<?, ?>, Boolean> HORIZONTAL_GRID_LINE_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>("-fx-horizontal-grid-lines-visible", 
/*      */         
/* 1078 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(XYChart<?, ?> param2XYChart)
/*      */         {
/* 1082 */           return (param2XYChart.horizontalGridLinesVisible == null || 
/* 1083 */             !param2XYChart.horizontalGridLinesVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(XYChart<?, ?> param2XYChart) {
/* 1088 */           return (StyleableProperty<Boolean>)param2XYChart.horizontalGridLinesVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/* 1092 */     private static final CssMetaData<XYChart<?, ?>, Boolean> HORIZONTAL_ZERO_LINE_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>("-fx-horizontal-zero-line-visible", 
/*      */         
/* 1094 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(XYChart<?, ?> param2XYChart)
/*      */         {
/* 1098 */           return (param2XYChart.horizontalZeroLineVisible == null || 
/* 1099 */             !param2XYChart.horizontalZeroLineVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(XYChart<?, ?> param2XYChart) {
/* 1104 */           return (StyleableProperty<Boolean>)param2XYChart.horizontalZeroLineVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/* 1108 */     private static final CssMetaData<XYChart<?, ?>, Boolean> ALTERNATIVE_ROW_FILL_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>("-fx-alternative-row-fill-visible", 
/*      */         
/* 1110 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(XYChart<?, ?> param2XYChart)
/*      */         {
/* 1114 */           return (param2XYChart.alternativeRowFillVisible == null || 
/* 1115 */             !param2XYChart.alternativeRowFillVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(XYChart<?, ?> param2XYChart) {
/* 1120 */           return (StyleableProperty<Boolean>)param2XYChart.alternativeRowFillVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/* 1124 */     private static final CssMetaData<XYChart<?, ?>, Boolean> VERTICAL_GRID_LINE_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>("-fx-vertical-grid-lines-visible", 
/*      */         
/* 1126 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(XYChart<?, ?> param2XYChart)
/*      */         {
/* 1130 */           return (param2XYChart.verticalGridLinesVisible == null || 
/* 1131 */             !param2XYChart.verticalGridLinesVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(XYChart<?, ?> param2XYChart) {
/* 1136 */           return (StyleableProperty<Boolean>)param2XYChart.verticalGridLinesVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/* 1140 */     private static final CssMetaData<XYChart<?, ?>, Boolean> VERTICAL_ZERO_LINE_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>("-fx-vertical-zero-line-visible", 
/*      */         
/* 1142 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(XYChart<?, ?> param2XYChart)
/*      */         {
/* 1146 */           return (param2XYChart.verticalZeroLineVisible == null || 
/* 1147 */             !param2XYChart.verticalZeroLineVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(XYChart<?, ?> param2XYChart) {
/* 1152 */           return (StyleableProperty<Boolean>)param2XYChart.verticalZeroLineVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/* 1156 */     private static final CssMetaData<XYChart<?, ?>, Boolean> ALTERNATIVE_COLUMN_FILL_VISIBLE = new CssMetaData<XYChart<?, ?>, Boolean>("-fx-alternative-column-fill-visible", 
/*      */         
/* 1158 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(XYChart<?, ?> param2XYChart)
/*      */         {
/* 1162 */           return (param2XYChart.alternativeColumnFillVisible == null || 
/* 1163 */             !param2XYChart.alternativeColumnFillVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(XYChart<?, ?> param2XYChart) {
/* 1168 */           return (StyleableProperty<Boolean>)param2XYChart.alternativeColumnFillVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1175 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Chart.getClassCssMetaData());
/* 1176 */       arrayList.add(HORIZONTAL_GRID_LINE_VISIBLE);
/* 1177 */       arrayList.add(HORIZONTAL_ZERO_LINE_VISIBLE);
/* 1178 */       arrayList.add(ALTERNATIVE_ROW_FILL_VISIBLE);
/* 1179 */       arrayList.add(VERTICAL_GRID_LINE_VISIBLE);
/* 1180 */       arrayList.add(VERTICAL_ZERO_LINE_VISIBLE);
/* 1181 */       arrayList.add(ALTERNATIVE_COLUMN_FILL_VISIBLE);
/* 1182 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1192 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 1201 */     return getClassCssMetaData();
/*      */   }
/*      */   protected abstract void dataItemAdded(Series<X, Y> paramSeries, int paramInt, Data<X, Y> paramData);
/*      */   protected abstract void dataItemRemoved(Data<X, Y> paramData, Series<X, Y> paramSeries);
/*      */   protected abstract void dataItemChanged(Data<X, Y> paramData);
/*      */   
/*      */   protected abstract void seriesAdded(Series<X, Y> paramSeries, int paramInt);
/*      */   
/*      */   protected abstract void seriesRemoved(Series<X, Y> paramSeries);
/*      */   
/*      */   protected abstract void layoutPlotChildren();
/*      */   
/*      */   public static final class Data<X, Y> { private boolean setToRemove = false;
/*      */     private XYChart.Series<X, Y> series;
/*      */     
/*      */     void setSeries(XYChart.Series<X, Y> param1Series) {
/* 1217 */       this.series = param1Series;
/*      */     }
/*      */ 
/*      */     
/* 1221 */     private ObjectProperty<X> xValue = new SimpleObjectProperty<X>(this, "XValue") {
/*      */         protected void invalidated() {
/* 1223 */           if (XYChart.Data.this.series != null) {
/* 1224 */             XYChart xYChart = XYChart.Data.this.series.getChart();
/* 1225 */             if (xYChart != null) xYChart.dataValueChanged(XYChart.Data.this, (T)get(), XYChart.Data.this.currentXProperty());
/*      */           
/*      */           } else {
/*      */             
/* 1229 */             XYChart.Data.this.setCurrentX(get());
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */     
/*      */     public final X getXValue() {
/* 1237 */       return this.xValue.get();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setXValue(X param1X) {
/* 1243 */       this.xValue.set(param1X);
/*      */ 
/*      */       
/* 1246 */       if (this.currentX.get() == null || (this.series != null && this.series
/* 1247 */         .getChart() == null)) this.currentX.setValue(param1X);
/*      */     
/*      */     }
/*      */ 
/*      */     
/*      */     public final ObjectProperty<X> XValueProperty() {
/* 1253 */       return this.xValue;
/*      */     }
/*      */     
/* 1256 */     private ObjectProperty<Y> yValue = new SimpleObjectProperty<Y>(this, "YValue") {
/*      */         protected void invalidated() {
/* 1258 */           if (XYChart.Data.this.series != null) {
/* 1259 */             XYChart xYChart = XYChart.Data.this.series.getChart();
/* 1260 */             if (xYChart != null) xYChart.dataValueChanged(XYChart.Data.this, (T)get(), XYChart.Data.this.currentYProperty());
/*      */           
/*      */           } else {
/*      */             
/* 1264 */             XYChart.Data.this.setCurrentY(get());
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */     
/*      */     public final Y getYValue() {
/* 1272 */       return this.yValue.get();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setYValue(Y param1Y) {
/* 1278 */       this.yValue.set(param1Y);
/*      */ 
/*      */       
/* 1281 */       if (this.currentY.get() == null || (this.series != null && this.series
/* 1282 */         .getChart() == null)) this.currentY.setValue(param1Y);
/*      */     
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final ObjectProperty<Y> YValueProperty() {
/* 1289 */       return this.yValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1295 */     private ObjectProperty<Object> extraValue = new SimpleObjectProperty(this, "extraValue") {
/*      */         protected void invalidated() {
/* 1297 */           if (XYChart.Data.this.series != null) {
/* 1298 */             XYChart xYChart = XYChart.Data.this.series.getChart();
/* 1299 */             if (xYChart != null) xYChart.dataValueChanged(XYChart.Data.this, (T)get(), XYChart.Data.this.currentExtraValueProperty()); 
/*      */           } 
/*      */         }
/*      */       };
/* 1303 */     public final Object getExtraValue() { return this.extraValue.get(); }
/* 1304 */     public final void setExtraValue(Object param1Object) { this.extraValue.set(param1Object); } public final ObjectProperty<Object> extraValueProperty() {
/* 1305 */       return this.extraValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1315 */     private ObjectProperty<Node> node = new SimpleObjectProperty<Node>(this, "node") {
/*      */         protected void invalidated() {
/* 1317 */           Node node = get();
/* 1318 */           if (node != null) {
/* 1319 */             node.accessibleTextProperty().unbind();
/* 1320 */             node.accessibleTextProperty().bind(new StringBinding()
/*      */                 {
/*      */                   protected String computeValue() {
/* 1323 */                     String str = (XYChart.Data.this.series != null) ? XYChart.Data.this.series.getName() : "";
/* 1324 */                     return str + " X Axis is " + str + " Y Axis is " + XYChart.Data.this.getCurrentX();
/*      */                   }
/*      */                 });
/*      */           } 
/*      */         }
/*      */       };
/* 1330 */     public final Node getNode() { return this.node.get(); }
/* 1331 */     public final void setNode(Node param1Node) { this.node.set(param1Node); } public final ObjectProperty<Node> nodeProperty() {
/* 1332 */       return this.node;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1340 */     private ObjectProperty<X> currentX = new SimpleObjectProperty<>(this, "currentX");
/* 1341 */     final X getCurrentX() { return this.currentX.get(); }
/* 1342 */     final void setCurrentX(X param1X) { this.currentX.set(param1X); } final ObjectProperty<X> currentXProperty() {
/* 1343 */       return this.currentX;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1351 */     private ObjectProperty<Y> currentY = new SimpleObjectProperty<>(this, "currentY");
/* 1352 */     final Y getCurrentY() { return this.currentY.get(); }
/* 1353 */     final void setCurrentY(Y param1Y) { this.currentY.set(param1Y); } final ObjectProperty<Y> currentYProperty() {
/* 1354 */       return this.currentY;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1361 */     private ObjectProperty<Object> currentExtraValue = new SimpleObjectProperty(this, "currentExtraValue");
/* 1362 */     final Object getCurrentExtraValue() { return this.currentExtraValue.getValue(); }
/* 1363 */     final void setCurrentExtraValue(Object param1Object) { this.currentExtraValue.setValue(param1Object); } final ObjectProperty<Object> currentExtraValueProperty() {
/* 1364 */       return this.currentExtraValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Data(X param1X, Y param1Y) {
/* 1381 */       setXValue(param1X);
/* 1382 */       setYValue(param1Y);
/* 1383 */       setCurrentX(param1X);
/* 1384 */       setCurrentY(param1Y);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Data(X param1X, Y param1Y, Object param1Object) {
/* 1396 */       setXValue(param1X);
/* 1397 */       setYValue(param1Y);
/* 1398 */       setExtraValue(param1Object);
/* 1399 */       setCurrentX(param1X);
/* 1400 */       setCurrentY(param1Y);
/* 1401 */       setCurrentExtraValue(param1Object);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1411 */       return "Data[" + getXValue() + "," + getYValue() + "," + getExtraValue() + "]";
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Data() {} }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Series<X, Y>
/*      */   {
/*      */     String defaultColorStyleClass;
/*      */ 
/*      */     
/*      */     boolean setToRemove = false;
/*      */     
/* 1428 */     private List<XYChart.Data<X, Y>> displayedData = new ArrayList<>();
/*      */     
/* 1430 */     private final ListChangeListener<XYChart.Data<X, Y>> dataChangeListener = new ListChangeListener<XYChart.Data<X, Y>>() {
/*      */         public void onChanged(ListChangeListener.Change<? extends XYChart.Data<X, Y>> param2Change) {
/* 1432 */           ObservableList<? extends XYChart.Data<X, Y>> observableList = param2Change.getList();
/* 1433 */           XYChart xYChart = XYChart.Series.this.getChart();
/* 1434 */           while (param2Change.next()) {
/* 1435 */             if (xYChart != null) {
/*      */               
/* 1437 */               if (param2Change.wasPermutated()) {
/* 1438 */                 XYChart.Series.this.displayedData.sort((param2Data1, param2Data2) -> param2ObservableList.indexOf(param2Data2) - param2ObservableList.indexOf(param2Data1));
/*      */                 
/*      */                 return;
/*      */               } 
/* 1442 */               HashSet<XYChart.Data> hashSet1 = new HashSet(XYChart.Series.this.displayedData);
/* 1443 */               hashSet1.removeAll(param2Change.getRemoved());
/* 1444 */               for (XYChart.Data<X, Y> data : param2Change.getAddedSubList()) {
/* 1445 */                 if (!hashSet1.add(data)) {
/* 1446 */                   throw new IllegalArgumentException("Duplicate data added");
/*      */                 }
/*      */               } 
/*      */ 
/*      */               
/* 1451 */               for (XYChart.Data<X, Y> data : param2Change.getRemoved()) {
/* 1452 */                 data.setToRemove = true;
/*      */               }
/*      */               
/* 1455 */               if (param2Change.getAddedSize() > 0) {
/* 1456 */                 for (XYChart.Data<X, Y> data : param2Change.getAddedSubList()) {
/* 1457 */                   if (data.setToRemove) {
/* 1458 */                     if (xYChart != null) xYChart.dataBeingRemovedIsAdded(data, XYChart.Series.this); 
/* 1459 */                     data.setToRemove = false;
/*      */                   } 
/*      */                 } 
/*      */                 
/* 1463 */                 for (XYChart.Data<X, Y> data : param2Change.getAddedSubList()) {
/* 1464 */                   data.setSeries(XYChart.Series.this);
/*      */                 }
/* 1466 */                 if (param2Change.getFrom() == 0) {
/* 1467 */                   XYChart.Series.this.displayedData.addAll(0, param2Change.getAddedSubList());
/*      */                 } else {
/* 1469 */                   XYChart.Series.this.displayedData.addAll(XYChart.Series.this.displayedData.indexOf(observableList.get(param2Change.getFrom() - 1)) + 1, param2Change.getAddedSubList());
/*      */                 } 
/*      */               } 
/*      */               
/* 1473 */               xYChart.dataItemsChanged(XYChart.Series.this, (List)param2Change
/* 1474 */                   .getRemoved(), param2Change.getFrom(), param2Change.getTo(), param2Change.wasPermutated()); continue;
/*      */             } 
/* 1476 */             HashSet<XYChart.Data> hashSet = new HashSet();
/* 1477 */             for (XYChart.Data<X, Y> data : observableList) {
/* 1478 */               if (!hashSet.add(data)) {
/* 1479 */                 throw new IllegalArgumentException("Duplicate data added");
/*      */               }
/*      */             } 
/*      */             
/* 1483 */             for (XYChart.Data<X, Y> data : param2Change.getAddedSubList()) {
/* 1484 */               data.setSeries(XYChart.Series.this);
/*      */             }
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1495 */     private final ReadOnlyObjectWrapper<XYChart<X, Y>> chart = new ReadOnlyObjectWrapper<XYChart<X, Y>>(this, "chart")
/*      */       {
/*      */         protected void invalidated() {
/* 1498 */           if (get() == null) {
/* 1499 */             XYChart.Series.this.displayedData.clear();
/*      */           } else {
/* 1501 */             XYChart.Series.this.displayedData.addAll(XYChart.Series.this.getData());
/*      */           } 
/*      */         }
/*      */       };
/* 1505 */     public final XYChart<X, Y> getChart() { return this.chart.get(); }
/* 1506 */     private void setChart(XYChart<X, Y> param1XYChart) { this.chart.set(param1XYChart); } public final ReadOnlyObjectProperty<XYChart<X, Y>> chartProperty() {
/* 1507 */       return this.chart.getReadOnlyProperty();
/*      */     }
/*      */     
/* 1510 */     private final StringProperty name = new StringPropertyBase() {
/*      */         protected void invalidated() {
/* 1512 */           get();
/* 1513 */           if (XYChart.Series.this.getChart() != null) XYChart.Series.this.getChart().seriesNameChanged();
/*      */         
/*      */         }
/*      */         
/*      */         public Object getBean() {
/* 1518 */           return XYChart.Series.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/* 1523 */           return "name";
/*      */         }
/*      */       };
/* 1526 */     public final String getName() { return this.name.get(); }
/* 1527 */     public final void setName(String param1String) { this.name.set(param1String); } public final StringProperty nameProperty() {
/* 1528 */       return this.name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1535 */     private ObjectProperty<Node> node = new SimpleObjectProperty<>(this, "node");
/* 1536 */     public final Node getNode() { return this.node.get(); }
/* 1537 */     public final void setNode(Node param1Node) { this.node.set(param1Node); } public final ObjectProperty<Node> nodeProperty() {
/* 1538 */       return this.node;
/*      */     }
/*      */     
/* 1541 */     private final ObjectProperty<ObservableList<XYChart.Data<X, Y>>> data = new ObjectPropertyBase<ObservableList<XYChart.Data<X, Y>>>() { private ObservableList<XYChart.Data<X, Y>> old;
/*      */         
/*      */         protected void invalidated() {
/* 1544 */           ObservableList<XYChart.Data<X, Y>> observableList = getValue();
/*      */           
/* 1546 */           if (this.old != null) this.old.removeListener(XYChart.Series.this.dataChangeListener); 
/* 1547 */           if (observableList != null) observableList.addListener(XYChart.Series.this.dataChangeListener);
/*      */           
/* 1549 */           if (this.old != null || observableList != null) {
/* 1550 */             final List removed = (List)((this.old != null) ? this.old : Collections.emptyList());
/* 1551 */             boolean bool = (observableList != null) ? observableList.size() : false;
/*      */             
/* 1553 */             if (!bool || !list.isEmpty()) {
/* 1554 */               XYChart.Series.this.dataChangeListener.onChanged(new NonIterableChange<XYChart.Data<X, Y>>(0, bool, observableList) { public List<XYChart.Data<X, Y>> getRemoved() {
/* 1555 */                       return removed;
/*      */                     }
/*      */                     protected int[] getPermutation() {
/* 1558 */                       return new int[0];
/*      */                     } }
/*      */                 );
/*      */             }
/* 1562 */           } else if (this.old != null && this.old.size() > 0) {
/*      */             
/* 1564 */             XYChart.Series.this.dataChangeListener.onChanged(new NonIterableChange<XYChart.Data<X, Y>>(0, 0, observableList) { public List<XYChart.Data<X, Y>> getRemoved() {
/* 1565 */                     return XYChart.Series.null.this.old;
/*      */                   } protected int[] getPermutation() {
/* 1567 */                     return new int[0];
/*      */                   } }
/*      */               );
/*      */           } 
/* 1571 */           this.old = observableList;
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/* 1576 */           return XYChart.Series.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/* 1581 */           return "data";
/*      */         } }
/*      */     ;
/* 1584 */     public final ObservableList<XYChart.Data<X, Y>> getData() { return this.data.getValue(); }
/* 1585 */     public final void setData(ObservableList<XYChart.Data<X, Y>> param1ObservableList) { this.data.setValue(param1ObservableList); } public final ObjectProperty<ObservableList<XYChart.Data<X, Y>>> dataProperty() {
/* 1586 */       return this.data;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Series() {
/* 1594 */       this(FXCollections.observableArrayList());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Series(ObservableList<XYChart.Data<X, Y>> param1ObservableList) {
/* 1603 */       setData(param1ObservableList);
/* 1604 */       for (XYChart.Data<X, Y> data : param1ObservableList) data.setSeries(this);
/*      */     
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Series(String param1String, ObservableList<XYChart.Data<X, Y>> param1ObservableList) {
/* 1614 */       this(param1ObservableList);
/* 1615 */       setName(param1String);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1625 */       return "Series[" + getName() + "]";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void removeDataItemRef(XYChart.Data<X, Y> param1Data) {
/* 1635 */       if (param1Data != null) param1Data.setToRemove = false; 
/* 1636 */       this.displayedData.remove(param1Data);
/*      */     }
/*      */     
/*      */     int getItemIndex(XYChart.Data<X, Y> param1Data) {
/* 1640 */       return this.displayedData.indexOf(param1Data);
/*      */     }
/*      */     
/*      */     XYChart.Data<X, Y> getItem(int param1Int) {
/* 1644 */       return this.displayedData.get(param1Int);
/*      */     }
/*      */     
/*      */     int getDataSize() {
/* 1648 */       return this.displayedData.size();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\XYChart.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */