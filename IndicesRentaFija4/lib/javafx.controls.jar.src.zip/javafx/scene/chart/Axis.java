/*      */ package javafx.scene.chart;
/*      */ 
/*      */ import com.sun.javafx.scene.NodeHelper;
/*      */ import java.util.ArrayList;
/*      */ import java.util.BitSet;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import javafx.beans.binding.DoubleExpression;
/*      */ import javafx.beans.binding.ObjectExpression;
/*      */ import javafx.beans.binding.StringExpression;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.BooleanPropertyBase;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.DoublePropertyBase;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.property.SimpleDoubleProperty;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.beans.property.StringProperty;
/*      */ import javafx.beans.property.StringPropertyBase;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.FontCssMetaData;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableBooleanProperty;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.BooleanConverter;
/*      */ import javafx.css.converter.EnumConverter;
/*      */ import javafx.css.converter.PaintConverter;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.geometry.Bounds;
/*      */ import javafx.geometry.Dimension2D;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.geometry.Pos;
/*      */ import javafx.geometry.Side;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.Label;
/*      */ import javafx.scene.layout.Region;
/*      */ import javafx.scene.paint.Color;
/*      */ import javafx.scene.paint.Paint;
/*      */ import javafx.scene.shape.LineTo;
/*      */ import javafx.scene.shape.MoveTo;
/*      */ import javafx.scene.shape.Path;
/*      */ import javafx.scene.shape.PathElement;
/*      */ import javafx.scene.text.Font;
/*      */ import javafx.scene.text.Text;
/*      */ import javafx.scene.transform.Rotate;
/*      */ import javafx.scene.transform.Transform;
/*      */ import javafx.scene.transform.Translate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Axis<T>
/*      */   extends Region
/*      */ {
/*   85 */   Text measure = new Text();
/*      */   private Orientation effectiveOrientation;
/*   87 */   private double effectiveTickLabelRotation = Double.NaN;
/*   88 */   private Label axisLabel = new Label();
/*   89 */   private final Path tickMarkPath = new Path();
/*   90 */   private double oldLength = 0.0D;
/*      */   
/*      */   boolean rangeValid = false;
/*      */   
/*      */   boolean measureInvalid = false;
/*      */   boolean tickLabelsVisibleInvalid = false;
/*   96 */   private BitSet labelsToSkip = new BitSet();
/*      */ 
/*      */ 
/*      */   
/*  100 */   private final ObservableList<TickMark<T>> tickMarks = FXCollections.observableArrayList();
/*  101 */   private final ObservableList<TickMark<T>> unmodifiableTickMarks = FXCollections.unmodifiableObservableList(this.tickMarks);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObservableList<TickMark<T>> getTickMarks() {
/*  108 */     return this.unmodifiableTickMarks;
/*      */   }
/*      */   
/*  111 */   private ObjectProperty<Side> side = new StyleableObjectProperty<Side>()
/*      */     {
/*      */       protected void invalidated() {
/*  114 */         Side side = get();
/*  115 */         Axis.this.pseudoClassStateChanged(Axis.TOP_PSEUDOCLASS_STATE, (side == Side.TOP));
/*  116 */         Axis.this.pseudoClassStateChanged(Axis.RIGHT_PSEUDOCLASS_STATE, (side == Side.RIGHT));
/*  117 */         Axis.this.pseudoClassStateChanged(Axis.BOTTOM_PSEUDOCLASS_STATE, (side == Side.BOTTOM));
/*  118 */         Axis.this.pseudoClassStateChanged(Axis.LEFT_PSEUDOCLASS_STATE, (side == Side.LEFT));
/*  119 */         Axis.this.requestAxisLayout();
/*      */       }
/*      */ 
/*      */       
/*      */       public CssMetaData<Axis<?>, Side> getCssMetaData() {
/*  124 */         return Axis.StyleableProperties.SIDE;
/*      */       }
/*      */ 
/*      */       
/*      */       public Object getBean() {
/*  129 */         return Axis.this;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  134 */         return "side";
/*      */       }
/*      */     };
/*  137 */   public final Side getSide() { return this.side.get(); }
/*  138 */   public final void setSide(Side paramSide) { this.side.set(paramSide); } public final ObjectProperty<Side> sideProperty() {
/*  139 */     return this.side;
/*      */   }
/*      */   final void setEffectiveOrientation(Orientation paramOrientation) {
/*  142 */     this.effectiveOrientation = paramOrientation;
/*      */   }
/*      */   
/*      */   final Side getEffectiveSide() {
/*  146 */     Side side = getSide();
/*  147 */     if (side == null || (side.isVertical() && this.effectiveOrientation == Orientation.HORIZONTAL) || (side
/*  148 */       .isHorizontal() && this.effectiveOrientation == Orientation.VERTICAL))
/*      */     {
/*  150 */       return (this.effectiveOrientation == Orientation.VERTICAL) ? Side.LEFT : Side.BOTTOM;
/*      */     }
/*  152 */     return side;
/*      */   }
/*      */ 
/*      */   
/*  156 */   private ObjectProperty<String> label = new ObjectPropertyBase<String>() {
/*      */       protected void invalidated() {
/*  158 */         Axis.this.axisLabel.setText(get());
/*  159 */         Axis.this.requestAxisLayout();
/*      */       }
/*      */ 
/*      */       
/*      */       public Object getBean() {
/*  164 */         return Axis.this;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  169 */         return "label";
/*      */       }
/*      */     };
/*  172 */   public final String getLabel() { return this.label.get(); }
/*  173 */   public final void setLabel(String paramString) { this.label.set(paramString); } public final ObjectProperty<String> labelProperty() {
/*  174 */     return this.label;
/*      */   }
/*      */   
/*  177 */   private BooleanProperty tickMarkVisible = new StyleableBooleanProperty(true) {
/*      */       protected void invalidated() {
/*  179 */         Axis.this.tickMarkPath.setVisible(get());
/*  180 */         Axis.this.requestAxisLayout();
/*      */       }
/*      */ 
/*      */       
/*      */       public CssMetaData<Axis<?>, Boolean> getCssMetaData() {
/*  185 */         return Axis.StyleableProperties.TICK_MARK_VISIBLE;
/*      */       }
/*      */       
/*      */       public Object getBean() {
/*  189 */         return Axis.this;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  194 */         return "tickMarkVisible";
/*      */       }
/*      */     };
/*  197 */   public final boolean isTickMarkVisible() { return this.tickMarkVisible.get(); }
/*  198 */   public final void setTickMarkVisible(boolean paramBoolean) { this.tickMarkVisible.set(paramBoolean); } public final BooleanProperty tickMarkVisibleProperty() {
/*  199 */     return this.tickMarkVisible;
/*      */   }
/*      */   
/*  202 */   private BooleanProperty tickLabelsVisible = new StyleableBooleanProperty(true)
/*      */     {
/*      */       protected void invalidated() {
/*  205 */         for (Axis.TickMark tickMark : Axis.this.tickMarks) {
/*  206 */           tickMark.setTextVisible(get());
/*      */         }
/*  208 */         Axis.this.tickLabelsVisibleInvalid = true;
/*  209 */         Axis.this.requestAxisLayout();
/*      */       }
/*      */ 
/*      */       
/*      */       public CssMetaData<Axis<?>, Boolean> getCssMetaData() {
/*  214 */         return Axis.StyleableProperties.TICK_LABELS_VISIBLE;
/*      */       }
/*      */ 
/*      */       
/*      */       public Object getBean() {
/*  219 */         return Axis.this;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  224 */         return "tickLabelsVisible";
/*      */       }
/*      */     }; public final boolean isTickLabelsVisible() {
/*  227 */     return this.tickLabelsVisible.get();
/*      */   }
/*  229 */   public final void setTickLabelsVisible(boolean paramBoolean) { this.tickLabelsVisible.set(paramBoolean); } public final BooleanProperty tickLabelsVisibleProperty() {
/*  230 */     return this.tickLabelsVisible;
/*      */   }
/*      */   
/*  233 */   private DoubleProperty tickLength = new StyleableDoubleProperty(8.0D) {
/*      */       protected void invalidated() {
/*  235 */         if (Axis.this.tickLength.get() < 0.0D && !Axis.this.tickLength.isBound()) {
/*  236 */           Axis.this.tickLength.set(0.0D);
/*      */         }
/*      */         
/*  239 */         Axis.this.requestAxisLayout();
/*      */       }
/*      */ 
/*      */       
/*      */       public CssMetaData<Axis<?>, Number> getCssMetaData() {
/*  244 */         return Axis.StyleableProperties.TICK_LENGTH;
/*      */       }
/*      */       
/*      */       public Object getBean() {
/*  248 */         return Axis.this;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  253 */         return "tickLength";
/*      */       }
/*      */     };
/*  256 */   public final double getTickLength() { return this.tickLength.get(); }
/*  257 */   public final void setTickLength(double paramDouble) { this.tickLength.set(paramDouble); } public final DoubleProperty tickLengthProperty() {
/*  258 */     return this.tickLength;
/*      */   }
/*      */   
/*  261 */   private BooleanProperty autoRanging = new BooleanPropertyBase(true) {
/*      */       protected void invalidated() {
/*  263 */         if (get())
/*      */         {
/*      */           
/*  266 */           Axis.this.requestAxisLayout();
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*      */       public Object getBean() {
/*  272 */         return Axis.this;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  277 */         return "autoRanging";
/*      */       }
/*      */     };
/*  280 */   public final boolean isAutoRanging() { return this.autoRanging.get(); }
/*  281 */   public final void setAutoRanging(boolean paramBoolean) { this.autoRanging.set(paramBoolean); } public final BooleanProperty autoRangingProperty() {
/*  282 */     return this.autoRanging;
/*      */   }
/*      */   
/*  285 */   private ObjectProperty<Font> tickLabelFont = new StyleableObjectProperty<Font>(Font.font("System", 8.0D)) {
/*      */       protected void invalidated() {
/*  287 */         Font font = get();
/*  288 */         Axis.this.measure.setFont(font);
/*  289 */         for (Axis.TickMark tickMark : Axis.this.getTickMarks()) {
/*  290 */           tickMark.textNode.setFont(font);
/*      */         }
/*  292 */         Axis.this.measureInvalid = true;
/*  293 */         Axis.this.requestAxisLayout();
/*      */       }
/*      */ 
/*      */       
/*      */       public CssMetaData<Axis<?>, Font> getCssMetaData() {
/*  298 */         return Axis.StyleableProperties.TICK_LABEL_FONT;
/*      */       }
/*      */ 
/*      */       
/*      */       public Object getBean() {
/*  303 */         return Axis.this;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  308 */         return "tickLabelFont";
/*      */       }
/*      */     };
/*  311 */   public final Font getTickLabelFont() { return this.tickLabelFont.get(); }
/*  312 */   public final void setTickLabelFont(Font paramFont) { this.tickLabelFont.set(paramFont); } public final ObjectProperty<Font> tickLabelFontProperty() {
/*  313 */     return this.tickLabelFont;
/*      */   }
/*      */   
/*  316 */   private ObjectProperty<Paint> tickLabelFill = new StyleableObjectProperty<Paint>(Color.BLACK) {
/*      */       protected void invalidated() {
/*  318 */         for (Axis.TickMark tickMark : Axis.this.tickMarks) {
/*  319 */           tickMark.textNode.setFill(Axis.this.getTickLabelFill());
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*      */       public CssMetaData<Axis<?>, Paint> getCssMetaData() {
/*  325 */         return Axis.StyleableProperties.TICK_LABEL_FILL;
/*      */       }
/*      */ 
/*      */       
/*      */       public Object getBean() {
/*  330 */         return Axis.this;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  335 */         return "tickLabelFill";
/*      */       }
/*      */     };
/*  338 */   public final Paint getTickLabelFill() { return this.tickLabelFill.get(); }
/*  339 */   public final void setTickLabelFill(Paint paramPaint) { this.tickLabelFill.set(paramPaint); } public final ObjectProperty<Paint> tickLabelFillProperty() {
/*  340 */     return this.tickLabelFill;
/*      */   }
/*      */   
/*  343 */   private DoubleProperty tickLabelGap = new StyleableDoubleProperty(3.0D) {
/*      */       protected void invalidated() {
/*  345 */         Axis.this.requestAxisLayout();
/*      */       }
/*      */ 
/*      */       
/*      */       public CssMetaData<Axis<?>, Number> getCssMetaData() {
/*  350 */         return Axis.StyleableProperties.TICK_LABEL_TICK_GAP;
/*      */       }
/*      */ 
/*      */       
/*      */       public Object getBean() {
/*  355 */         return Axis.this;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  360 */         return "tickLabelGap";
/*      */       }
/*      */     };
/*  363 */   public final double getTickLabelGap() { return this.tickLabelGap.get(); }
/*  364 */   public final void setTickLabelGap(double paramDouble) { this.tickLabelGap.set(paramDouble); } public final DoubleProperty tickLabelGapProperty() {
/*  365 */     return this.tickLabelGap;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  370 */   private BooleanProperty animated = new SimpleBooleanProperty(this, "animated", true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean getAnimated() {
/*  377 */     return this.animated.get();
/*  378 */   } public final void setAnimated(boolean paramBoolean) { this.animated.set(paramBoolean); } public final BooleanProperty animatedProperty() {
/*  379 */     return this.animated;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  384 */   private DoubleProperty tickLabelRotation = new DoublePropertyBase(0.0D) {
/*      */       protected void invalidated() {
/*  386 */         if (Axis.this.isAutoRanging()) {
/*  387 */           Axis.this.invalidateRange();
/*      */         }
/*  389 */         Axis.this.requestAxisLayout();
/*      */       }
/*      */ 
/*      */       
/*      */       public Object getBean() {
/*  394 */         return Axis.this;
/*      */       }
/*      */ 
/*      */       
/*      */       public String getName() {
/*  399 */         return "tickLabelRotation";
/*      */       }
/*      */     };
/*  402 */   public final double getTickLabelRotation() { return this.tickLabelRotation.getValue().doubleValue(); }
/*  403 */   public final void setTickLabelRotation(double paramDouble) { this.tickLabelRotation.setValue(Double.valueOf(paramDouble)); } public final DoubleProperty tickLabelRotationProperty() {
/*  404 */     return this.tickLabelRotation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Axis() {
/*  412 */     getStyleClass().setAll(new String[] { "axis" });
/*  413 */     this.axisLabel.getStyleClass().add("axis-label");
/*  414 */     this.axisLabel.setAlignment(Pos.CENTER);
/*  415 */     this.tickMarkPath.getStyleClass().add("axis-tick-mark");
/*  416 */     getChildren().addAll(new Node[] { this.axisLabel, this.tickMarkPath });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean isRangeValid() {
/*  426 */     return this.rangeValid;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void invalidateRange() {
/*  432 */     this.rangeValid = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean shouldAnimate() {
/*  441 */     return (getAnimated() && NodeHelper.isTreeShowing(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void requestLayout() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void requestAxisLayout() {
/*  457 */     super.requestLayout();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invalidateRange(List<T> paramList) {
/*  468 */     invalidateRange();
/*  469 */     requestAxisLayout();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computePrefHeight(double paramDouble) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual getEffectiveSide : ()Ljavafx/geometry/Side;
/*      */     //   4: astore_3
/*      */     //   5: aload_3
/*      */     //   6: invokevirtual isVertical : ()Z
/*      */     //   9: ifeq -> 16
/*      */     //   12: ldc2_w 100.0
/*      */     //   15: dreturn
/*      */     //   16: aload_0
/*      */     //   17: dload_1
/*      */     //   18: invokevirtual autoRange : (D)Ljava/lang/Object;
/*      */     //   21: astore #4
/*      */     //   23: dconst_0
/*      */     //   24: dstore #5
/*      */     //   26: aload_0
/*      */     //   27: invokevirtual isTickLabelsVisible : ()Z
/*      */     //   30: ifeq -> 91
/*      */     //   33: aload_0
/*      */     //   34: dload_1
/*      */     //   35: aload #4
/*      */     //   37: invokevirtual calculateTickValues : (DLjava/lang/Object;)Ljava/util/List;
/*      */     //   40: astore #7
/*      */     //   42: aload #7
/*      */     //   44: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   49: astore #8
/*      */     //   51: aload #8
/*      */     //   53: invokeinterface hasNext : ()Z
/*      */     //   58: ifeq -> 91
/*      */     //   61: aload #8
/*      */     //   63: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   68: astore #9
/*      */     //   70: dload #5
/*      */     //   72: aload_0
/*      */     //   73: aload #9
/*      */     //   75: aload #4
/*      */     //   77: invokevirtual measureTickMarkSize : (Ljava/lang/Object;Ljava/lang/Object;)Ljavafx/geometry/Dimension2D;
/*      */     //   80: invokevirtual getHeight : ()D
/*      */     //   83: invokestatic max : (DD)D
/*      */     //   86: dstore #5
/*      */     //   88: goto -> 51
/*      */     //   91: aload_0
/*      */     //   92: invokevirtual isTickMarkVisible : ()Z
/*      */     //   95: ifeq -> 118
/*      */     //   98: aload_0
/*      */     //   99: invokevirtual getTickLength : ()D
/*      */     //   102: dconst_0
/*      */     //   103: dcmpl
/*      */     //   104: ifle -> 114
/*      */     //   107: aload_0
/*      */     //   108: invokevirtual getTickLength : ()D
/*      */     //   111: goto -> 119
/*      */     //   114: dconst_0
/*      */     //   115: goto -> 119
/*      */     //   118: dconst_0
/*      */     //   119: dstore #7
/*      */     //   121: aload_0
/*      */     //   122: getfield axisLabel : Ljavafx/scene/control/Label;
/*      */     //   125: invokevirtual getText : ()Ljava/lang/String;
/*      */     //   128: ifnull -> 144
/*      */     //   131: aload_0
/*      */     //   132: getfield axisLabel : Ljavafx/scene/control/Label;
/*      */     //   135: invokevirtual getText : ()Ljava/lang/String;
/*      */     //   138: invokevirtual length : ()I
/*      */     //   141: ifne -> 148
/*      */     //   144: dconst_0
/*      */     //   145: goto -> 158
/*      */     //   148: aload_0
/*      */     //   149: getfield axisLabel : Ljavafx/scene/control/Label;
/*      */     //   152: ldc2_w -1.0
/*      */     //   155: invokevirtual prefHeight : (D)D
/*      */     //   158: dstore #9
/*      */     //   160: dload #5
/*      */     //   162: aload_0
/*      */     //   163: invokevirtual getTickLabelGap : ()D
/*      */     //   166: dadd
/*      */     //   167: dload #7
/*      */     //   169: dadd
/*      */     //   170: dload #9
/*      */     //   172: dadd
/*      */     //   173: dreturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #570	-> 0
/*      */     //   #571	-> 5
/*      */     //   #574	-> 12
/*      */     //   #577	-> 16
/*      */     //   #579	-> 23
/*      */     //   #581	-> 26
/*      */     //   #582	-> 33
/*      */     //   #583	-> 42
/*      */     //   #584	-> 70
/*      */     //   #585	-> 88
/*      */     //   #588	-> 91
/*      */     //   #591	-> 121
/*      */     //   #592	-> 144
/*      */     //   #593	-> 160
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computePrefWidth(double paramDouble) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual getEffectiveSide : ()Ljavafx/geometry/Side;
/*      */     //   4: astore_3
/*      */     //   5: aload_3
/*      */     //   6: invokevirtual isVertical : ()Z
/*      */     //   9: ifeq -> 170
/*      */     //   12: aload_0
/*      */     //   13: dload_1
/*      */     //   14: invokevirtual autoRange : (D)Ljava/lang/Object;
/*      */     //   17: astore #4
/*      */     //   19: dconst_0
/*      */     //   20: dstore #5
/*      */     //   22: aload_0
/*      */     //   23: invokevirtual isTickLabelsVisible : ()Z
/*      */     //   26: ifeq -> 87
/*      */     //   29: aload_0
/*      */     //   30: dload_1
/*      */     //   31: aload #4
/*      */     //   33: invokevirtual calculateTickValues : (DLjava/lang/Object;)Ljava/util/List;
/*      */     //   36: astore #7
/*      */     //   38: aload #7
/*      */     //   40: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   45: astore #8
/*      */     //   47: aload #8
/*      */     //   49: invokeinterface hasNext : ()Z
/*      */     //   54: ifeq -> 87
/*      */     //   57: aload #8
/*      */     //   59: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   64: astore #9
/*      */     //   66: dload #5
/*      */     //   68: aload_0
/*      */     //   69: aload #9
/*      */     //   71: aload #4
/*      */     //   73: invokevirtual measureTickMarkSize : (Ljava/lang/Object;Ljava/lang/Object;)Ljavafx/geometry/Dimension2D;
/*      */     //   76: invokevirtual getWidth : ()D
/*      */     //   79: invokestatic max : (DD)D
/*      */     //   82: dstore #5
/*      */     //   84: goto -> 47
/*      */     //   87: aload_0
/*      */     //   88: invokevirtual isTickMarkVisible : ()Z
/*      */     //   91: ifeq -> 114
/*      */     //   94: aload_0
/*      */     //   95: invokevirtual getTickLength : ()D
/*      */     //   98: dconst_0
/*      */     //   99: dcmpl
/*      */     //   100: ifle -> 110
/*      */     //   103: aload_0
/*      */     //   104: invokevirtual getTickLength : ()D
/*      */     //   107: goto -> 115
/*      */     //   110: dconst_0
/*      */     //   111: goto -> 115
/*      */     //   114: dconst_0
/*      */     //   115: dstore #7
/*      */     //   117: aload_0
/*      */     //   118: getfield axisLabel : Ljavafx/scene/control/Label;
/*      */     //   121: invokevirtual getText : ()Ljava/lang/String;
/*      */     //   124: ifnull -> 140
/*      */     //   127: aload_0
/*      */     //   128: getfield axisLabel : Ljavafx/scene/control/Label;
/*      */     //   131: invokevirtual getText : ()Ljava/lang/String;
/*      */     //   134: invokevirtual length : ()I
/*      */     //   137: ifne -> 144
/*      */     //   140: dconst_0
/*      */     //   141: goto -> 154
/*      */     //   144: aload_0
/*      */     //   145: getfield axisLabel : Ljavafx/scene/control/Label;
/*      */     //   148: ldc2_w -1.0
/*      */     //   151: invokevirtual prefHeight : (D)D
/*      */     //   154: dstore #9
/*      */     //   156: dload #5
/*      */     //   158: aload_0
/*      */     //   159: invokevirtual getTickLabelGap : ()D
/*      */     //   162: dadd
/*      */     //   163: dload #7
/*      */     //   165: dadd
/*      */     //   166: dload #9
/*      */     //   168: dadd
/*      */     //   169: dreturn
/*      */     //   170: ldc2_w 100.0
/*      */     //   173: dreturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #605	-> 0
/*      */     //   #606	-> 5
/*      */     //   #608	-> 12
/*      */     //   #610	-> 19
/*      */     //   #612	-> 22
/*      */     //   #613	-> 29
/*      */     //   #614	-> 38
/*      */     //   #615	-> 66
/*      */     //   #616	-> 84
/*      */     //   #619	-> 87
/*      */     //   #622	-> 117
/*      */     //   #623	-> 140
/*      */     //   #624	-> 156
/*      */     //   #628	-> 170
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void tickMarksUpdated() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutChildren() {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield oldLength : D
/*      */     //   4: dconst_0
/*      */     //   5: dcmpl
/*      */     //   6: ifne -> 13
/*      */     //   9: iconst_1
/*      */     //   10: goto -> 14
/*      */     //   13: iconst_0
/*      */     //   14: istore_1
/*      */     //   15: aload_0
/*      */     //   16: invokevirtual getEffectiveSide : ()Ljavafx/geometry/Side;
/*      */     //   19: astore_2
/*      */     //   20: aload_2
/*      */     //   21: invokevirtual isVertical : ()Z
/*      */     //   24: ifeq -> 34
/*      */     //   27: aload_0
/*      */     //   28: invokevirtual getHeight : ()D
/*      */     //   31: goto -> 38
/*      */     //   34: aload_0
/*      */     //   35: invokevirtual getWidth : ()D
/*      */     //   38: dstore_3
/*      */     //   39: aload_0
/*      */     //   40: invokevirtual isRangeValid : ()Z
/*      */     //   43: ifne -> 50
/*      */     //   46: iconst_1
/*      */     //   47: goto -> 51
/*      */     //   50: iconst_0
/*      */     //   51: istore #5
/*      */     //   53: aload_0
/*      */     //   54: getfield oldLength : D
/*      */     //   57: dload_3
/*      */     //   58: dcmpl
/*      */     //   59: ifeq -> 66
/*      */     //   62: iconst_1
/*      */     //   63: goto -> 67
/*      */     //   66: iconst_0
/*      */     //   67: istore #6
/*      */     //   69: iload #6
/*      */     //   71: ifne -> 79
/*      */     //   74: iload #5
/*      */     //   76: ifeq -> 456
/*      */     //   79: aload_0
/*      */     //   80: invokevirtual isAutoRanging : ()Z
/*      */     //   83: ifeq -> 130
/*      */     //   86: aload_0
/*      */     //   87: dload_3
/*      */     //   88: invokevirtual autoRange : (D)Ljava/lang/Object;
/*      */     //   91: astore #7
/*      */     //   93: aload_0
/*      */     //   94: aload #7
/*      */     //   96: aload_0
/*      */     //   97: invokevirtual getAnimated : ()Z
/*      */     //   100: ifeq -> 123
/*      */     //   103: iload_1
/*      */     //   104: ifne -> 123
/*      */     //   107: aload_0
/*      */     //   108: invokestatic isTreeShowing : (Ljavafx/scene/Node;)Z
/*      */     //   111: ifeq -> 123
/*      */     //   114: iload #5
/*      */     //   116: ifeq -> 123
/*      */     //   119: iconst_1
/*      */     //   120: goto -> 124
/*      */     //   123: iconst_0
/*      */     //   124: invokevirtual setRange : (Ljava/lang/Object;Z)V
/*      */     //   127: goto -> 136
/*      */     //   130: aload_0
/*      */     //   131: invokevirtual getRange : ()Ljava/lang/Object;
/*      */     //   134: astore #7
/*      */     //   136: aload_0
/*      */     //   137: dload_3
/*      */     //   138: aload #7
/*      */     //   140: invokevirtual calculateTickValues : (DLjava/lang/Object;)Ljava/util/List;
/*      */     //   143: astore #8
/*      */     //   145: aload_0
/*      */     //   146: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   149: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   154: astore #9
/*      */     //   156: aload #9
/*      */     //   158: invokeinterface hasNext : ()Z
/*      */     //   163: ifeq -> 261
/*      */     //   166: aload #9
/*      */     //   168: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   173: checkcast javafx/scene/chart/Axis$TickMark
/*      */     //   176: astore #10
/*      */     //   178: aload #10
/*      */     //   180: astore #11
/*      */     //   182: aload_0
/*      */     //   183: invokevirtual shouldAnimate : ()Z
/*      */     //   186: ifeq -> 236
/*      */     //   189: new javafx/animation/FadeTransition
/*      */     //   192: dup
/*      */     //   193: ldc2_w 250.0
/*      */     //   196: invokestatic millis : (D)Ljavafx/util/Duration;
/*      */     //   199: aload #10
/*      */     //   201: getfield textNode : Ljavafx/scene/text/Text;
/*      */     //   204: invokespecial <init> : (Ljavafx/util/Duration;Ljavafx/scene/Node;)V
/*      */     //   207: astore #12
/*      */     //   209: aload #12
/*      */     //   211: dconst_0
/*      */     //   212: invokevirtual setToValue : (D)V
/*      */     //   215: aload #12
/*      */     //   217: aload_0
/*      */     //   218: aload #11
/*      */     //   220: <illegal opcode> handle : (Ljavafx/scene/chart/Axis;Ljavafx/scene/chart/Axis$TickMark;)Ljavafx/event/EventHandler;
/*      */     //   225: invokevirtual setOnFinished : (Ljavafx/event/EventHandler;)V
/*      */     //   228: aload #12
/*      */     //   230: invokevirtual play : ()V
/*      */     //   233: goto -> 251
/*      */     //   236: aload_0
/*      */     //   237: invokevirtual getChildren : ()Ljavafx/collections/ObservableList;
/*      */     //   240: aload #11
/*      */     //   242: getfield textNode : Ljavafx/scene/text/Text;
/*      */     //   245: invokeinterface remove : (Ljava/lang/Object;)Z
/*      */     //   250: pop
/*      */     //   251: aload #9
/*      */     //   253: invokeinterface remove : ()V
/*      */     //   258: goto -> 156
/*      */     //   261: aload #8
/*      */     //   263: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   268: astore #10
/*      */     //   270: aload #10
/*      */     //   272: invokeinterface hasNext : ()Z
/*      */     //   277: ifeq -> 442
/*      */     //   280: aload #10
/*      */     //   282: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   287: astore #11
/*      */     //   289: new javafx/scene/chart/Axis$TickMark
/*      */     //   292: dup
/*      */     //   293: invokespecial <init> : ()V
/*      */     //   296: astore #12
/*      */     //   298: aload #12
/*      */     //   300: aload #11
/*      */     //   302: invokevirtual setValue : (Ljava/lang/Object;)V
/*      */     //   305: aload #12
/*      */     //   307: getfield textNode : Ljavafx/scene/text/Text;
/*      */     //   310: aload_0
/*      */     //   311: aload #11
/*      */     //   313: invokevirtual getTickMarkLabel : (Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   316: invokevirtual setText : (Ljava/lang/String;)V
/*      */     //   319: aload #12
/*      */     //   321: getfield textNode : Ljavafx/scene/text/Text;
/*      */     //   324: aload_0
/*      */     //   325: invokevirtual getTickLabelFont : ()Ljavafx/scene/text/Font;
/*      */     //   328: invokevirtual setFont : (Ljavafx/scene/text/Font;)V
/*      */     //   331: aload #12
/*      */     //   333: getfield textNode : Ljavafx/scene/text/Text;
/*      */     //   336: aload_0
/*      */     //   337: invokevirtual getTickLabelFill : ()Ljavafx/scene/paint/Paint;
/*      */     //   340: invokevirtual setFill : (Ljavafx/scene/paint/Paint;)V
/*      */     //   343: aload #12
/*      */     //   345: aload_0
/*      */     //   346: invokevirtual isTickLabelsVisible : ()Z
/*      */     //   349: invokevirtual setTextVisible : (Z)V
/*      */     //   352: aload_0
/*      */     //   353: invokevirtual shouldAnimate : ()Z
/*      */     //   356: ifeq -> 368
/*      */     //   359: aload #12
/*      */     //   361: getfield textNode : Ljavafx/scene/text/Text;
/*      */     //   364: dconst_0
/*      */     //   365: invokevirtual setOpacity : (D)V
/*      */     //   368: aload_0
/*      */     //   369: invokevirtual getChildren : ()Ljavafx/collections/ObservableList;
/*      */     //   372: aload #12
/*      */     //   374: getfield textNode : Ljavafx/scene/text/Text;
/*      */     //   377: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   382: pop
/*      */     //   383: aload_0
/*      */     //   384: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   387: aload #12
/*      */     //   389: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   394: pop
/*      */     //   395: aload_0
/*      */     //   396: invokevirtual shouldAnimate : ()Z
/*      */     //   399: ifeq -> 439
/*      */     //   402: new javafx/animation/FadeTransition
/*      */     //   405: dup
/*      */     //   406: ldc2_w 750.0
/*      */     //   409: invokestatic millis : (D)Ljavafx/util/Duration;
/*      */     //   412: aload #12
/*      */     //   414: getfield textNode : Ljavafx/scene/text/Text;
/*      */     //   417: invokespecial <init> : (Ljavafx/util/Duration;Ljavafx/scene/Node;)V
/*      */     //   420: astore #13
/*      */     //   422: aload #13
/*      */     //   424: dconst_0
/*      */     //   425: invokevirtual setFromValue : (D)V
/*      */     //   428: aload #13
/*      */     //   430: dconst_1
/*      */     //   431: invokevirtual setToValue : (D)V
/*      */     //   434: aload #13
/*      */     //   436: invokevirtual play : ()V
/*      */     //   439: goto -> 270
/*      */     //   442: aload_0
/*      */     //   443: invokevirtual tickMarksUpdated : ()V
/*      */     //   446: aload_0
/*      */     //   447: dload_3
/*      */     //   448: putfield oldLength : D
/*      */     //   451: aload_0
/*      */     //   452: iconst_1
/*      */     //   453: putfield rangeValid : Z
/*      */     //   456: iload #6
/*      */     //   458: ifne -> 480
/*      */     //   461: iload #5
/*      */     //   463: ifne -> 480
/*      */     //   466: aload_0
/*      */     //   467: getfield measureInvalid : Z
/*      */     //   470: ifne -> 480
/*      */     //   473: aload_0
/*      */     //   474: getfield tickLabelsVisibleInvalid : Z
/*      */     //   477: ifeq -> 846
/*      */     //   480: aload_0
/*      */     //   481: iconst_0
/*      */     //   482: putfield measureInvalid : Z
/*      */     //   485: aload_0
/*      */     //   486: iconst_0
/*      */     //   487: putfield tickLabelsVisibleInvalid : Z
/*      */     //   490: aload_0
/*      */     //   491: getfield labelsToSkip : Ljava/util/BitSet;
/*      */     //   494: invokevirtual clear : ()V
/*      */     //   497: iconst_0
/*      */     //   498: istore #7
/*      */     //   500: dconst_0
/*      */     //   501: dstore #8
/*      */     //   503: dconst_0
/*      */     //   504: dstore #10
/*      */     //   506: aload_0
/*      */     //   507: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   510: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   515: astore #12
/*      */     //   517: aload #12
/*      */     //   519: invokeinterface hasNext : ()Z
/*      */     //   524: ifeq -> 596
/*      */     //   527: aload #12
/*      */     //   529: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   534: checkcast javafx/scene/chart/Axis$TickMark
/*      */     //   537: astore #13
/*      */     //   539: aload #13
/*      */     //   541: aload_0
/*      */     //   542: aload #13
/*      */     //   544: invokevirtual getValue : ()Ljava/lang/Object;
/*      */     //   547: invokevirtual getDisplayPosition : (Ljava/lang/Object;)D
/*      */     //   550: invokevirtual setPosition : (D)V
/*      */     //   553: aload #13
/*      */     //   555: invokevirtual isTextVisible : ()Z
/*      */     //   558: ifeq -> 593
/*      */     //   561: aload_0
/*      */     //   562: aload #13
/*      */     //   564: invokevirtual getValue : ()Ljava/lang/Object;
/*      */     //   567: aload_2
/*      */     //   568: invokespecial measureTickMarkSize : (Ljava/lang/Object;Ljavafx/geometry/Side;)D
/*      */     //   571: dstore #14
/*      */     //   573: dload #8
/*      */     //   575: dload #14
/*      */     //   577: dadd
/*      */     //   578: dstore #8
/*      */     //   580: dload #10
/*      */     //   582: dload #14
/*      */     //   584: invokestatic max : (DD)D
/*      */     //   587: invokestatic round : (D)J
/*      */     //   590: l2d
/*      */     //   591: dstore #10
/*      */     //   593: goto -> 517
/*      */     //   596: dload #10
/*      */     //   598: dconst_0
/*      */     //   599: dcmpl
/*      */     //   600: ifle -> 630
/*      */     //   603: dload_3
/*      */     //   604: dload #8
/*      */     //   606: dcmpg
/*      */     //   607: ifge -> 630
/*      */     //   610: aload_0
/*      */     //   611: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   614: invokeinterface size : ()I
/*      */     //   619: i2d
/*      */     //   620: dload #10
/*      */     //   622: dmul
/*      */     //   623: dload_3
/*      */     //   624: ddiv
/*      */     //   625: d2i
/*      */     //   626: iconst_1
/*      */     //   627: iadd
/*      */     //   628: istore #7
/*      */     //   630: iload #7
/*      */     //   632: ifle -> 703
/*      */     //   635: iconst_0
/*      */     //   636: istore #12
/*      */     //   638: aload_0
/*      */     //   639: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   642: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   647: astore #13
/*      */     //   649: aload #13
/*      */     //   651: invokeinterface hasNext : ()Z
/*      */     //   656: ifeq -> 703
/*      */     //   659: aload #13
/*      */     //   661: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   666: checkcast javafx/scene/chart/Axis$TickMark
/*      */     //   669: astore #14
/*      */     //   671: aload #14
/*      */     //   673: invokevirtual isTextVisible : ()Z
/*      */     //   676: ifeq -> 700
/*      */     //   679: aload #14
/*      */     //   681: iload #12
/*      */     //   683: iinc #12, 1
/*      */     //   686: iload #7
/*      */     //   688: irem
/*      */     //   689: ifne -> 696
/*      */     //   692: iconst_1
/*      */     //   693: goto -> 697
/*      */     //   696: iconst_0
/*      */     //   697: invokevirtual setTextVisible : (Z)V
/*      */     //   700: goto -> 649
/*      */     //   703: aload_0
/*      */     //   704: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   707: invokeinterface size : ()I
/*      */     //   712: iconst_2
/*      */     //   713: if_icmple -> 840
/*      */     //   716: aload_0
/*      */     //   717: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   720: iconst_0
/*      */     //   721: invokeinterface get : (I)Ljava/lang/Object;
/*      */     //   726: checkcast javafx/scene/chart/Axis$TickMark
/*      */     //   729: astore #12
/*      */     //   731: aload_0
/*      */     //   732: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   735: iconst_1
/*      */     //   736: invokeinterface get : (I)Ljava/lang/Object;
/*      */     //   741: checkcast javafx/scene/chart/Axis$TickMark
/*      */     //   744: astore #13
/*      */     //   746: aload_0
/*      */     //   747: aload_2
/*      */     //   748: aload #12
/*      */     //   750: aload #13
/*      */     //   752: aload_0
/*      */     //   753: invokevirtual getTickLabelGap : ()D
/*      */     //   756: invokespecial isTickLabelsOverlap : (Ljavafx/geometry/Side;Ljavafx/scene/chart/Axis$TickMark;Ljavafx/scene/chart/Axis$TickMark;D)Z
/*      */     //   759: ifeq -> 768
/*      */     //   762: aload #13
/*      */     //   764: iconst_0
/*      */     //   765: invokevirtual setTextVisible : (Z)V
/*      */     //   768: aload_0
/*      */     //   769: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   772: aload_0
/*      */     //   773: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   776: invokeinterface size : ()I
/*      */     //   781: iconst_2
/*      */     //   782: isub
/*      */     //   783: invokeinterface get : (I)Ljava/lang/Object;
/*      */     //   788: checkcast javafx/scene/chart/Axis$TickMark
/*      */     //   791: astore #12
/*      */     //   793: aload_0
/*      */     //   794: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   797: aload_0
/*      */     //   798: getfield tickMarks : Ljavafx/collections/ObservableList;
/*      */     //   801: invokeinterface size : ()I
/*      */     //   806: iconst_1
/*      */     //   807: isub
/*      */     //   808: invokeinterface get : (I)Ljava/lang/Object;
/*      */     //   813: checkcast javafx/scene/chart/Axis$TickMark
/*      */     //   816: astore #13
/*      */     //   818: aload_0
/*      */     //   819: aload_2
/*      */     //   820: aload #12
/*      */     //   822: aload #13
/*      */     //   824: aload_0
/*      */     //   825: invokevirtual getTickLabelGap : ()D
/*      */     //   828: invokespecial isTickLabelsOverlap : (Ljavafx/geometry/Side;Ljavafx/scene/chart/Axis$TickMark;Ljavafx/scene/chart/Axis$TickMark;D)Z
/*      */     //   831: ifeq -> 840
/*      */     //   834: aload #12
/*      */     //   836: iconst_0
/*      */     //   837: invokevirtual setTextVisible : (Z)V
/*      */     //   840: aload_0
/*      */     //   841: aload_2
/*      */     //   842: dload_3
/*      */     //   843: invokespecial updateTickMarks : (Ljavafx/geometry/Side;D)V
/*      */     //   846: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #642	-> 0
/*      */     //   #644	-> 15
/*      */     //   #645	-> 20
/*      */     //   #646	-> 39
/*      */     //   #647	-> 53
/*      */     //   #648	-> 69
/*      */     //   #651	-> 79
/*      */     //   #653	-> 86
/*      */     //   #655	-> 93
/*      */     //   #657	-> 130
/*      */     //   #660	-> 136
/*      */     //   #663	-> 145
/*      */     //   #664	-> 156
/*      */     //   #665	-> 166
/*      */     //   #666	-> 178
/*      */     //   #667	-> 182
/*      */     //   #668	-> 189
/*      */     //   #669	-> 209
/*      */     //   #670	-> 215
/*      */     //   #673	-> 228
/*      */     //   #674	-> 233
/*      */     //   #675	-> 236
/*      */     //   #678	-> 251
/*      */     //   #679	-> 258
/*      */     //   #682	-> 261
/*      */     //   #683	-> 289
/*      */     //   #684	-> 298
/*      */     //   #685	-> 305
/*      */     //   #686	-> 319
/*      */     //   #687	-> 331
/*      */     //   #688	-> 343
/*      */     //   #689	-> 352
/*      */     //   #690	-> 368
/*      */     //   #691	-> 383
/*      */     //   #692	-> 395
/*      */     //   #693	-> 402
/*      */     //   #694	-> 422
/*      */     //   #695	-> 428
/*      */     //   #696	-> 434
/*      */     //   #698	-> 439
/*      */     //   #701	-> 442
/*      */     //   #703	-> 446
/*      */     //   #704	-> 451
/*      */     //   #707	-> 456
/*      */     //   #708	-> 480
/*      */     //   #709	-> 485
/*      */     //   #712	-> 490
/*      */     //   #713	-> 497
/*      */     //   #714	-> 500
/*      */     //   #715	-> 503
/*      */     //   #716	-> 506
/*      */     //   #717	-> 539
/*      */     //   #718	-> 553
/*      */     //   #719	-> 561
/*      */     //   #720	-> 573
/*      */     //   #721	-> 580
/*      */     //   #723	-> 593
/*      */     //   #724	-> 596
/*      */     //   #725	-> 610
/*      */     //   #728	-> 630
/*      */     //   #729	-> 635
/*      */     //   #730	-> 638
/*      */     //   #731	-> 671
/*      */     //   #732	-> 679
/*      */     //   #734	-> 700
/*      */     //   #739	-> 703
/*      */     //   #740	-> 716
/*      */     //   #741	-> 731
/*      */     //   #742	-> 746
/*      */     //   #743	-> 762
/*      */     //   #745	-> 768
/*      */     //   #746	-> 793
/*      */     //   #747	-> 818
/*      */     //   #748	-> 834
/*      */     //   #751	-> 840
/*      */     //   #753	-> 846
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateTickMarks(Side paramSide, double paramDouble) {
/*  757 */     this.tickMarkPath.getElements().clear();
/*      */     
/*  759 */     double d1 = getWidth();
/*  760 */     double d2 = getHeight();
/*  761 */     double d3 = (isTickMarkVisible() && getTickLength() > 0.0D) ? getTickLength() : 0.0D;
/*  762 */     double d4 = getEffectiveTickLabelRotation();
/*  763 */     if (Side.LEFT.equals(paramSide)) {
/*      */       
/*  765 */       this.tickMarkPath.setLayoutX(-0.5D);
/*  766 */       this.tickMarkPath.setLayoutY(0.5D);
/*  767 */       if (getLabel() != null) {
/*  768 */         this.axisLabel.getTransforms().setAll(new Transform[] { new Translate(0.0D, d2), new Rotate(-90.0D, 0.0D, 0.0D) });
/*  769 */         this.axisLabel.setLayoutX(0.0D);
/*  770 */         this.axisLabel.setLayoutY(0.0D);
/*      */         
/*  772 */         this.axisLabel.resize(d2, Math.ceil(this.axisLabel.prefHeight(d1)));
/*      */       } 
/*  774 */       for (TickMark<T> tickMark : this.tickMarks) {
/*  775 */         positionTextNode(tickMark.textNode, d1 - getTickLabelGap() - d3, tickMark
/*  776 */             .getPosition(), d4, paramSide);
/*  777 */         updateTickMark(tickMark, paramDouble, d1 - d3, tickMark
/*  778 */             .getPosition(), d1, tickMark
/*  779 */             .getPosition());
/*      */       } 
/*  781 */     } else if (Side.RIGHT.equals(paramSide)) {
/*      */       
/*  783 */       this.tickMarkPath.setLayoutX(0.5D);
/*  784 */       this.tickMarkPath.setLayoutY(0.5D);
/*  785 */       if (getLabel() != null) {
/*  786 */         double d = Math.ceil(this.axisLabel.prefHeight(d1));
/*  787 */         this.axisLabel.getTransforms().setAll(new Transform[] { new Translate(0.0D, d2), new Rotate(-90.0D, 0.0D, 0.0D) });
/*  788 */         this.axisLabel.setLayoutX(d1 - d);
/*  789 */         this.axisLabel.setLayoutY(0.0D);
/*      */         
/*  791 */         this.axisLabel.resize(d2, d);
/*      */       } 
/*  793 */       for (TickMark<T> tickMark : this.tickMarks) {
/*  794 */         positionTextNode(tickMark.textNode, getTickLabelGap() + d3, tickMark
/*  795 */             .getPosition(), d4, paramSide);
/*  796 */         updateTickMark(tickMark, paramDouble, 0.0D, tickMark
/*  797 */             .getPosition(), d3, tickMark
/*  798 */             .getPosition());
/*      */       } 
/*  800 */     } else if (Side.TOP.equals(paramSide)) {
/*      */       
/*  802 */       this.tickMarkPath.setLayoutX(0.5D);
/*  803 */       this.tickMarkPath.setLayoutY(-0.5D);
/*  804 */       if (getLabel() != null) {
/*  805 */         this.axisLabel.getTransforms().clear();
/*  806 */         this.axisLabel.setLayoutX(0.0D);
/*  807 */         this.axisLabel.setLayoutY(0.0D);
/*  808 */         this.axisLabel.resize(d1, Math.ceil(this.axisLabel.prefHeight(d1)));
/*      */       } 
/*  810 */       for (TickMark<T> tickMark : this.tickMarks) {
/*  811 */         positionTextNode(tickMark.textNode, tickMark.getPosition(), d2 - d3 - getTickLabelGap(), d4, paramSide);
/*      */         
/*  813 */         updateTickMark(tickMark, paramDouble, tickMark
/*  814 */             .getPosition(), d2, tickMark
/*  815 */             .getPosition(), d2 - d3);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  820 */       this.tickMarkPath.setLayoutX(0.5D);
/*  821 */       this.tickMarkPath.setLayoutY(0.5D);
/*  822 */       if (getLabel() != null) {
/*  823 */         this.axisLabel.getTransforms().clear();
/*  824 */         double d = Math.ceil(this.axisLabel.prefHeight(d1));
/*  825 */         this.axisLabel.setLayoutX(0.0D);
/*  826 */         this.axisLabel.setLayoutY(d2 - d);
/*  827 */         this.axisLabel.resize(d1, d);
/*      */       } 
/*  829 */       for (TickMark<T> tickMark : this.tickMarks) {
/*  830 */         positionTextNode(tickMark.textNode, tickMark.getPosition(), d3 + getTickLabelGap(), d4, paramSide);
/*      */         
/*  832 */         updateTickMark(tickMark, paramDouble, tickMark
/*  833 */             .getPosition(), 0.0D, tickMark
/*  834 */             .getPosition(), d3);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isTickLabelsOverlap(Side paramSide, TickMark<T> paramTickMark1, TickMark<T> paramTickMark2, double paramDouble) {
/*  848 */     if (!paramTickMark1.isTextVisible() || !paramTickMark2.isTextVisible()) return false; 
/*  849 */     double d1 = measureTickMarkSize(paramTickMark1.getValue(), paramSide);
/*  850 */     double d2 = measureTickMarkSize(paramTickMark2.getValue(), paramSide);
/*  851 */     double d3 = paramTickMark1.getPosition() - d1 / 2.0D;
/*  852 */     double d4 = paramTickMark1.getPosition() + d1 / 2.0D;
/*  853 */     double d5 = paramTickMark2.getPosition() - d2 / 2.0D;
/*  854 */     double d6 = paramTickMark2.getPosition() + d2 / 2.0D;
/*  855 */     return paramSide.isVertical() ? ((d3 - d6 <= paramDouble)) : ((d5 - d4 <= paramDouble));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void positionTextNode(Text paramText, double paramDouble1, double paramDouble2, double paramDouble3, Side paramSide) {
/*  869 */     paramText.setLayoutX(0.0D);
/*  870 */     paramText.setLayoutY(0.0D);
/*  871 */     paramText.setRotate(paramDouble3);
/*  872 */     Bounds bounds = paramText.getBoundsInParent();
/*  873 */     if (Side.LEFT.equals(paramSide)) {
/*  874 */       paramText.setLayoutX(paramDouble1 - bounds.getWidth() - bounds.getMinX());
/*  875 */       paramText.setLayoutY(paramDouble2 - bounds.getHeight() / 2.0D - bounds.getMinY());
/*  876 */     } else if (Side.RIGHT.equals(paramSide)) {
/*  877 */       paramText.setLayoutX(paramDouble1 - bounds.getMinX());
/*  878 */       paramText.setLayoutY(paramDouble2 - bounds.getHeight() / 2.0D - bounds.getMinY());
/*  879 */     } else if (Side.TOP.equals(paramSide)) {
/*  880 */       paramText.setLayoutX(paramDouble1 - bounds.getWidth() / 2.0D - bounds.getMinX());
/*  881 */       paramText.setLayoutY(paramDouble2 - bounds.getHeight() - bounds.getMinY());
/*      */     } else {
/*  883 */       paramText.setLayoutX(paramDouble1 - bounds.getWidth() / 2.0D - bounds.getMinX());
/*  884 */       paramText.setLayoutY(paramDouble2 - bounds.getMinY());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateTickMark(TickMark<T> paramTickMark, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  895 */     if (paramTickMark.getPosition() >= 0.0D && paramTickMark.getPosition() <= Math.ceil(paramDouble1)) {
/*  896 */       paramTickMark.textNode.setVisible(paramTickMark.isTextVisible());
/*      */       
/*  898 */       this.tickMarkPath.getElements().addAll(new PathElement[] { new MoveTo(paramDouble2, paramDouble3), new LineTo(paramDouble4, paramDouble5) });
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  903 */       paramTickMark.textNode.setVisible(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Dimension2D measureTickMarkLabelSize(String paramString, double paramDouble) {
/*  923 */     this.measure.setRotate(paramDouble);
/*  924 */     this.measure.setText(paramString);
/*  925 */     Bounds bounds = this.measure.getBoundsInParent();
/*  926 */     return new Dimension2D(bounds.getWidth(), bounds.getHeight());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Dimension2D measureTickMarkSize(T paramT, double paramDouble) {
/*  937 */     return measureTickMarkLabelSize(getTickMarkLabel(paramT), paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Dimension2D measureTickMarkSize(T paramT, Object paramObject) {
/*  948 */     return measureTickMarkSize(paramT, getEffectiveTickLabelRotation());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double measureTickMarkSize(T paramT, Side paramSide) {
/*  960 */     Dimension2D dimension2D = measureTickMarkSize(paramT, getEffectiveTickLabelRotation());
/*  961 */     return paramSide.isVertical() ? dimension2D.getHeight() : dimension2D.getWidth();
/*      */   }
/*      */   
/*      */   final double getEffectiveTickLabelRotation() {
/*  965 */     return (!isAutoRanging() || Double.isNaN(this.effectiveTickLabelRotation)) ? getTickLabelRotation() : this.effectiveTickLabelRotation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setEffectiveTickLabelRotation(double paramDouble) {
/*  973 */     this.effectiveTickLabelRotation = paramDouble;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class TickMark<T>
/*      */   {
/*  987 */     private StringProperty label = new StringPropertyBase() {
/*      */         protected void invalidated() {
/*  989 */           Axis.TickMark.this.textNode.setText(getValue());
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  994 */           return Axis.TickMark.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  999 */           return "label";
/*      */         }
/*      */       };
/* 1002 */     public final String getLabel() { return this.label.get(); }
/* 1003 */     public final void setLabel(String param1String) { this.label.set(param1String); } public final StringExpression labelProperty() {
/* 1004 */       return this.label;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1009 */     private ObjectProperty<T> value = new SimpleObjectProperty<>(this, "value");
/* 1010 */     public final T getValue() { return this.value.get(); }
/* 1011 */     public final void setValue(T param1T) { this.value.set(param1T); } public final ObjectExpression<T> valueProperty() {
/* 1012 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1017 */     private DoubleProperty position = new SimpleDoubleProperty(this, "position");
/* 1018 */     public final double getPosition() { return this.position.get(); }
/* 1019 */     public final void setPosition(double param1Double) { this.position.set(param1Double); } public final DoubleExpression positionProperty() {
/* 1020 */       return this.position;
/*      */     }
/* 1022 */     Text textNode = new Text();
/*      */ 
/*      */     
/* 1025 */     private BooleanProperty textVisible = new BooleanPropertyBase(true) {
/*      */         protected void invalidated() {
/* 1027 */           if (!get()) {
/* 1028 */             Axis.TickMark.this.textNode.setVisible(false);
/*      */           }
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/* 1034 */           return Axis.TickMark.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/* 1039 */           return "textVisible";
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean isTextVisible() {
/* 1047 */       return this.textVisible.get();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setTextVisible(boolean param1Boolean) {
/* 1053 */       this.textVisible.set(param1Boolean);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1066 */       return this.value.get().toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class StyleableProperties
/*      */   {
/* 1073 */     private static final CssMetaData<Axis<?>, Side> SIDE = new CssMetaData<Axis<?>, Side>("-fx-side", (StyleConverter)new EnumConverter(Side.class))
/*      */       {
/*      */ 
/*      */         
/*      */         public boolean isSettable(Axis<?> param2Axis)
/*      */         {
/* 1079 */           return (param2Axis.side == null || !param2Axis.side.isBound());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public StyleableProperty<Side> getStyleableProperty(Axis<?> param2Axis) {
/* 1085 */           return (StyleableProperty<Side>)param2Axis.sideProperty();
/*      */         }
/*      */       };
/*      */     
/* 1089 */     private static final CssMetaData<Axis<?>, Number> TICK_LENGTH = new CssMetaData<Axis<?>, Number>("-fx-tick-length", 
/*      */         
/* 1091 */         SizeConverter.getInstance(), Double.valueOf(8.0D))
/*      */       {
/*      */         public boolean isSettable(Axis<?> param2Axis)
/*      */         {
/* 1095 */           return (param2Axis.tickLength == null || !param2Axis.tickLength.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(Axis<?> param2Axis) {
/* 1100 */           return (StyleableProperty<Number>)param2Axis.tickLengthProperty();
/*      */         }
/*      */       };
/*      */     
/* 1104 */     private static final CssMetaData<Axis<?>, Font> TICK_LABEL_FONT = new FontCssMetaData<Axis<?>>("-fx-tick-label-font", 
/*      */         
/* 1106 */         Font.font("system", 8.0D))
/*      */       {
/*      */         public boolean isSettable(Axis<?> param2Axis)
/*      */         {
/* 1110 */           return (param2Axis.tickLabelFont == null || !param2Axis.tickLabelFont.isBound());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public StyleableProperty<Font> getStyleableProperty(Axis<?> param2Axis) {
/* 1116 */           return (StyleableProperty<Font>)param2Axis.tickLabelFontProperty();
/*      */         }
/*      */       };
/*      */     
/* 1120 */     private static final CssMetaData<Axis<?>, Paint> TICK_LABEL_FILL = new CssMetaData<Axis<?>, Paint>("-fx-tick-label-fill", 
/*      */         
/* 1122 */         PaintConverter.getInstance(), Color.BLACK)
/*      */       {
/*      */         public boolean isSettable(Axis<?> param2Axis)
/*      */         {
/* 1126 */           return ((param2Axis.tickLabelFill == null)) | (!param2Axis.tickLabelFill.isBound());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public StyleableProperty<Paint> getStyleableProperty(Axis<?> param2Axis) {
/* 1132 */           return (StyleableProperty<Paint>)param2Axis.tickLabelFillProperty();
/*      */         }
/*      */       };
/*      */     
/* 1136 */     private static final CssMetaData<Axis<?>, Number> TICK_LABEL_TICK_GAP = new CssMetaData<Axis<?>, Number>("-fx-tick-label-gap", 
/*      */         
/* 1138 */         SizeConverter.getInstance(), Double.valueOf(3.0D))
/*      */       {
/*      */         public boolean isSettable(Axis<?> param2Axis)
/*      */         {
/* 1142 */           return (param2Axis.tickLabelGap == null || !param2Axis.tickLabelGap.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(Axis<?> param2Axis) {
/* 1147 */           return (StyleableProperty<Number>)param2Axis.tickLabelGapProperty();
/*      */         }
/*      */       };
/*      */     
/* 1151 */     private static final CssMetaData<Axis<?>, Boolean> TICK_MARK_VISIBLE = new CssMetaData<Axis<?>, Boolean>("-fx-tick-mark-visible", 
/*      */         
/* 1153 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(Axis<?> param2Axis)
/*      */         {
/* 1157 */           return (param2Axis.tickMarkVisible == null || !param2Axis.tickMarkVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(Axis<?> param2Axis) {
/* 1162 */           return (StyleableProperty<Boolean>)param2Axis.tickMarkVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/* 1166 */     private static final CssMetaData<Axis<?>, Boolean> TICK_LABELS_VISIBLE = new CssMetaData<Axis<?>, Boolean>("-fx-tick-labels-visible", 
/*      */         
/* 1168 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(Axis<?> param2Axis)
/*      */         {
/* 1172 */           return (param2Axis.tickLabelsVisible == null || !param2Axis.tickLabelsVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(Axis<?> param2Axis) {
/* 1177 */           return (StyleableProperty<Boolean>)param2Axis.tickLabelsVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1184 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Region.getClassCssMetaData());
/* 1185 */       arrayList.add(SIDE);
/* 1186 */       arrayList.add(TICK_LENGTH);
/* 1187 */       arrayList.add(TICK_LABEL_FONT);
/* 1188 */       arrayList.add(TICK_LABEL_FILL);
/* 1189 */       arrayList.add(TICK_LABEL_TICK_GAP);
/* 1190 */       arrayList.add(TICK_MARK_VISIBLE);
/* 1191 */       arrayList.add(TICK_LABELS_VISIBLE);
/* 1192 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1202 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 1211 */     return getClassCssMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1216 */   private static final PseudoClass TOP_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("top");
/*      */ 
/*      */   
/* 1219 */   private static final PseudoClass BOTTOM_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("bottom");
/*      */ 
/*      */   
/* 1222 */   private static final PseudoClass LEFT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("left");
/*      */ 
/*      */   
/* 1225 */   private static final PseudoClass RIGHT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("right");
/*      */   
/*      */   protected abstract Object autoRange(double paramDouble);
/*      */   
/*      */   protected abstract void setRange(Object paramObject, boolean paramBoolean);
/*      */   
/*      */   protected abstract Object getRange();
/*      */   
/*      */   public abstract double getZeroPosition();
/*      */   
/*      */   public abstract double getDisplayPosition(T paramT);
/*      */   
/*      */   public abstract T getValueForDisplay(double paramDouble);
/*      */   
/*      */   public abstract boolean isValueOnAxis(T paramT);
/*      */   
/*      */   public abstract double toNumericValue(T paramT);
/*      */   
/*      */   public abstract T toRealValue(double paramDouble);
/*      */   
/*      */   protected abstract List<T> calculateTickValues(double paramDouble, Object paramObject);
/*      */   
/*      */   protected abstract String getTickMarkLabel(T paramT);
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\Axis.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */