/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import com.sun.javafx.charts.ChartLayoutAnimator;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.ParseException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.KeyValue;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.SimpleStringProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.geometry.Dimension2D;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.util.Duration;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NumberAxis
/*     */   extends ValueAxis<Number>
/*     */ {
/*     */   private Object currentAnimationID;
/*  66 */   private final ChartLayoutAnimator animator = new ChartLayoutAnimator(this);
/*  67 */   private final StringProperty currentFormatterProperty = new SimpleStringProperty(this, "currentFormatter", "");
/*  68 */   private final DefaultFormatter defaultFormatter = new DefaultFormatter(this);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private BooleanProperty forceZeroInRange = new BooleanPropertyBase(true)
/*     */     {
/*     */       protected void invalidated() {
/*  76 */         if (NumberAxis.this.isAutoRanging()) {
/*  77 */           NumberAxis.this.requestAxisLayout();
/*  78 */           NumberAxis.this.invalidateRange();
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/*  84 */         return NumberAxis.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/*  89 */         return "forceZeroInRange";
/*     */       }
/*     */     };
/*  92 */   public final boolean isForceZeroInRange() { return this.forceZeroInRange.getValue().booleanValue(); }
/*  93 */   public final void setForceZeroInRange(boolean paramBoolean) { this.forceZeroInRange.setValue(Boolean.valueOf(paramBoolean)); } public final BooleanProperty forceZeroInRangeProperty() {
/*  94 */     return this.forceZeroInRange;
/*     */   }
/*     */   
/*  97 */   private DoubleProperty tickUnit = new StyleableDoubleProperty(5.0D) {
/*     */       protected void invalidated() {
/*  99 */         if (!NumberAxis.this.isAutoRanging()) {
/* 100 */           NumberAxis.this.invalidateRange();
/* 101 */           NumberAxis.this.requestAxisLayout();
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public CssMetaData<NumberAxis, Number> getCssMetaData() {
/* 107 */         return NumberAxis.StyleableProperties.TICK_UNIT;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 112 */         return NumberAxis.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 117 */         return "tickUnit";
/*     */       }
/*     */     };
/* 120 */   public final double getTickUnit() { return this.tickUnit.get(); }
/* 121 */   public final void setTickUnit(double paramDouble) { this.tickUnit.set(paramDouble); } public final DoubleProperty tickUnitProperty() {
/* 122 */     return this.tickUnit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberAxis(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 139 */     super(paramDouble1, paramDouble2);
/* 140 */     setTickUnit(paramDouble3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberAxis(String paramString, double paramDouble1, double paramDouble2, double paramDouble3) {
/* 152 */     super(paramDouble1, paramDouble2);
/* 153 */     setTickUnit(paramDouble3);
/* 154 */     setLabel(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getTickMarkLabel(Number paramNumber) {
/* 166 */     StringConverter<Number> stringConverter = getTickLabelFormatter();
/* 167 */     if (stringConverter == null) stringConverter = this.defaultFormatter; 
/* 168 */     return stringConverter.toString(paramNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getRange() {
/* 177 */     return new Object[] {
/* 178 */         Double.valueOf(getLowerBound()), 
/* 179 */         Double.valueOf(getUpperBound()), 
/* 180 */         Double.valueOf(getTickUnit()), 
/* 181 */         Double.valueOf(getScale()), this.currentFormatterProperty
/* 182 */         .get()
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRange(Object paramObject, boolean paramBoolean) {
/* 194 */     Object[] arrayOfObject = (Object[])paramObject;
/* 195 */     double d1 = ((Double)arrayOfObject[0]).doubleValue();
/* 196 */     double d2 = ((Double)arrayOfObject[1]).doubleValue();
/* 197 */     double d3 = ((Double)arrayOfObject[2]).doubleValue();
/* 198 */     double d4 = ((Double)arrayOfObject[3]).doubleValue();
/* 199 */     String str = (String)arrayOfObject[4];
/* 200 */     this.currentFormatterProperty.set(str);
/* 201 */     double d5 = getLowerBound();
/* 202 */     setLowerBound(d1);
/* 203 */     setUpperBound(d2);
/* 204 */     setTickUnit(d3);
/* 205 */     if (paramBoolean) {
/* 206 */       this.animator.stop(this.currentAnimationID);
/* 207 */       this.currentAnimationID = this.animator.animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(this.currentLowerBound, 
/*     */                   
/* 209 */                   (T)Double.valueOf(d5)), new KeyValue(
/* 210 */                   scalePropertyImpl(), (T)Double.valueOf(getScale())) }), new KeyFrame(
/*     */               
/* 212 */               Duration.millis(700.0D), new KeyValue[] { new KeyValue(this.currentLowerBound, 
/* 213 */                   (T)Double.valueOf(d1)), new KeyValue(
/* 214 */                   scalePropertyImpl(), (T)Double.valueOf(d4)) }) });
/*     */     }
/*     */     else {
/*     */       
/* 218 */       this.currentLowerBound.set(d1);
/* 219 */       setScale(d4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Number> calculateTickValues(double paramDouble, Object paramObject) {
/* 231 */     Object[] arrayOfObject = (Object[])paramObject;
/* 232 */     double d1 = ((Double)arrayOfObject[0]).doubleValue();
/* 233 */     double d2 = ((Double)arrayOfObject[1]).doubleValue();
/* 234 */     double d3 = ((Double)arrayOfObject[2]).doubleValue();
/* 235 */     ArrayList<Double> arrayList = new ArrayList();
/* 236 */     if (d1 == d2) {
/* 237 */       arrayList.add(Double.valueOf(d1));
/* 238 */     } else if (d3 <= 0.0D) {
/* 239 */       arrayList.add(Double.valueOf(d1));
/* 240 */       arrayList.add(Double.valueOf(d2));
/* 241 */     } else if (d3 > 0.0D) {
/* 242 */       arrayList.add(Double.valueOf(d1));
/* 243 */       if ((d2 - d1) / d3 > 2000.0D) {
/*     */         
/* 245 */         System.err.println("Warning we tried to create more than 2000 major tick marks on a NumberAxis. Lower Bound=" + d1 + ", Upper Bound=" + d2 + ", Tick Unit=" + d3);
/*     */       
/*     */       }
/* 248 */       else if (d1 + d3 < d2) {
/*     */         
/* 250 */         double d = (Math.rint(d3) == d3) ? Math.ceil(d1) : (d1 + d3);
/* 251 */         int i = (int)Math.ceil((d2 - d) / d3);
/* 252 */         for (byte b = 0; d < d2 && b < i; d += d3, b++) {
/* 253 */           if (!arrayList.contains(Double.valueOf(d))) {
/* 254 */             arrayList.add(Double.valueOf(d));
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 259 */       arrayList.add(Double.valueOf(d2));
/*     */     } 
/* 261 */     return (List)arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Number> calculateMinorTickMarks() {
/* 270 */     ArrayList<Number> arrayList = new ArrayList();
/* 271 */     double d1 = getLowerBound();
/* 272 */     double d2 = getUpperBound();
/* 273 */     double d3 = getTickUnit();
/* 274 */     double d4 = d3 / Math.max(1, getMinorTickCount());
/* 275 */     if (d3 > 0.0D) {
/* 276 */       if ((d2 - d1) / d4 > 10000.0D) {
/*     */         
/* 278 */         System.err.println("Warning we tried to create more than 10000 minor tick marks on a NumberAxis. Lower Bound=" + 
/* 279 */             getLowerBound() + ", Upper Bound=" + getUpperBound() + ", Tick Unit=" + d3);
/* 280 */         return arrayList;
/*     */       } 
/* 282 */       boolean bool = (Math.rint(d3) == d3) ? true : false;
/* 283 */       if (bool) {
/* 284 */         double d5 = Math.floor(d1) + d4;
/* 285 */         int j = (int)Math.ceil((Math.ceil(d1) - d5) / d4);
/* 286 */         for (byte b1 = 0; d5 < Math.ceil(d1) && b1 < j; d5 += d4, b1++) {
/* 287 */           if (d5 > d1) {
/* 288 */             arrayList.add(Double.valueOf(d5));
/*     */           }
/*     */         } 
/*     */       } 
/* 292 */       double d = bool ? Math.ceil(d1) : d1;
/* 293 */       int i = (int)Math.ceil((d2 - d) / d3);
/* 294 */       for (byte b = 0; d < d2 && b < i; d += d3, b++) {
/* 295 */         double d5 = Math.min(d + d3, d2);
/* 296 */         double d6 = d + d4;
/* 297 */         int j = (int)Math.ceil((d5 - d6) / d4);
/* 298 */         for (byte b1 = 0; d6 < d5 && b1 < j; d6 += d4, b1++) {
/* 299 */           arrayList.add(Double.valueOf(d6));
/*     */         }
/*     */       } 
/*     */     } 
/* 303 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Dimension2D measureTickMarkSize(Number paramNumber, Object paramObject) {
/* 314 */     Object[] arrayOfObject = (Object[])paramObject;
/* 315 */     String str = (String)arrayOfObject[4];
/* 316 */     return measureTickMarkSize(paramNumber, getTickLabelRotation(), str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension2D measureTickMarkSize(Number paramNumber, double paramDouble, String paramString) {
/*     */     String str;
/* 329 */     StringConverter<Number> stringConverter = getTickLabelFormatter();
/* 330 */     if (stringConverter == null) stringConverter = this.defaultFormatter; 
/* 331 */     if (stringConverter instanceof DefaultFormatter) {
/* 332 */       str = ((DefaultFormatter)stringConverter).toString(paramNumber, paramString);
/*     */     } else {
/* 334 */       str = stringConverter.toString(paramNumber);
/*     */     } 
/* 336 */     return measureTickMarkLabelSize(str, paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object autoRange(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 349 */     Side side = getEffectiveSide();
/*     */     
/* 351 */     if (isForceZeroInRange()) {
/* 352 */       if (paramDouble2 < 0.0D) {
/* 353 */         paramDouble2 = 0.0D;
/* 354 */       } else if (paramDouble1 > 0.0D) {
/* 355 */         paramDouble1 = 0.0D;
/*     */       } 
/*     */     }
/*     */     
/* 359 */     int i = (int)Math.floor(paramDouble3 / paramDouble4);
/*     */     
/* 361 */     i = Math.max(i, 2);
/* 362 */     int j = Math.max(getMinorTickCount(), 1);
/*     */     
/* 364 */     double d1 = paramDouble2 - paramDouble1;
/*     */     
/* 366 */     if (d1 != 0.0D && d1 / (i * j) <= Math.ulp(paramDouble1)) {
/* 367 */       d1 = 0.0D;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 372 */     double d2 = (d1 == 0.0D) ? ((paramDouble1 == 0.0D) ? 2.0D : (Math.abs(paramDouble1) * 0.02D)) : (Math.abs(d1) * 1.02D);
/* 373 */     double d3 = (d2 - d1) / 2.0D;
/*     */     
/* 375 */     double d4 = paramDouble1 - d3;
/* 376 */     double d5 = paramDouble2 + d3;
/*     */     
/* 378 */     if ((d4 < 0.0D && paramDouble1 >= 0.0D) || (d4 > 0.0D && paramDouble1 <= 0.0D))
/*     */     {
/* 380 */       d4 = 0.0D;
/*     */     }
/* 382 */     if ((d5 < 0.0D && paramDouble2 >= 0.0D) || (d5 > 0.0D && paramDouble2 <= 0.0D))
/*     */     {
/* 384 */       d5 = 0.0D;
/*     */     }
/*     */     
/* 387 */     double d6 = d2 / i;
/*     */     
/* 389 */     double d7 = 0.0D;
/* 390 */     double d8 = 0.0D;
/* 391 */     double d9 = 0.0D;
/* 392 */     int k = 0;
/* 393 */     double d10 = Double.MAX_VALUE;
/* 394 */     String str = "0.00000000";
/*     */     
/* 396 */     while (d10 > paramDouble3 || k > 20) {
/* 397 */       int m = (int)Math.floor(Math.log10(d6));
/* 398 */       double d12 = d6 / Math.pow(10.0D, m);
/* 399 */       double d13 = d12;
/* 400 */       if (d12 > 5.0D) {
/* 401 */         m++;
/* 402 */         d13 = 1.0D;
/* 403 */       } else if (d12 > 1.0D) {
/* 404 */         d13 = (d12 > 2.5D) ? 5.0D : 2.5D;
/*     */       } 
/* 406 */       if (m > 1) {
/* 407 */         str = "#,##0";
/* 408 */       } else if (m == 1) {
/* 409 */         str = "0";
/*     */       } else {
/* 411 */         boolean bool = (Math.rint(d13) != d13) ? true : false;
/* 412 */         StringBuilder stringBuilder = new StringBuilder("0");
/* 413 */         int n = bool ? (Math.abs(m) + 1) : Math.abs(m);
/* 414 */         if (n > 0) stringBuilder.append("."); 
/* 415 */         for (byte b1 = 0; b1 < n; b1++) {
/* 416 */           stringBuilder.append("0");
/*     */         }
/* 418 */         str = stringBuilder.toString();
/*     */       } 
/*     */       
/* 421 */       d7 = d13 * Math.pow(10.0D, m);
/*     */       
/* 423 */       d8 = Math.floor(d4 / d7) * d7;
/* 424 */       d9 = Math.ceil(d5 / d7) * d7;
/*     */ 
/*     */       
/* 427 */       double d14 = 0.0D;
/* 428 */       double d15 = 0.0D;
/* 429 */       k = (int)Math.ceil((d9 - d8) / d7);
/* 430 */       double d16 = d8;
/* 431 */       for (byte b = 0; d16 <= d9 && b < k; d16 += d7, b++) {
/* 432 */         Dimension2D dimension2D = measureTickMarkSize(Double.valueOf(d16), getTickLabelRotation(), str);
/* 433 */         double d = side.isVertical() ? dimension2D.getHeight() : dimension2D.getWidth();
/* 434 */         if (b == 0) {
/* 435 */           d15 = d / 2.0D;
/*     */         } else {
/* 437 */           d14 = Math.max(d14, d15 + 6.0D + d / 2.0D);
/*     */         } 
/*     */       } 
/* 440 */       d10 = (k - 1) * d14;
/* 441 */       d6 = d7;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 446 */       if (i == 2 && d10 > paramDouble3) {
/*     */         break;
/*     */       }
/* 449 */       if (d10 > paramDouble3 || k > 20) d6 *= 2.0D;
/*     */     
/*     */     } 
/* 452 */     double d11 = calculateNewScale(paramDouble3, d8, d9);
/*     */     
/* 454 */     return new Object[] { Double.valueOf(d8), Double.valueOf(d9), Double.valueOf(d7), Double.valueOf(d11), str };
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 460 */     private static final CssMetaData<NumberAxis, Number> TICK_UNIT = new CssMetaData<NumberAxis, Number>("-fx-tick-unit", 
/*     */         
/* 462 */         SizeConverter.getInstance(), Double.valueOf(5.0D))
/*     */       {
/*     */         public boolean isSettable(NumberAxis param2NumberAxis)
/*     */         {
/* 466 */           return (param2NumberAxis.tickUnit == null || !param2NumberAxis.tickUnit.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(NumberAxis param2NumberAxis) {
/* 471 */           return (StyleableProperty<Number>)param2NumberAxis.tickUnitProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 478 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(ValueAxis.getClassCssMetaData());
/* 479 */       arrayList.add(TICK_UNIT);
/* 480 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 490 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 499 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */   
/*     */   public NumberAxis() {}
/*     */ 
/*     */   
/*     */   public static class DefaultFormatter
/*     */     extends StringConverter<Number>
/*     */   {
/*     */     private DecimalFormat formatter;
/*     */     
/* 511 */     private String prefix = null;
/* 512 */     private String suffix = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultFormatter(NumberAxis param1NumberAxis) {
/* 520 */       this.formatter = param1NumberAxis.isAutoRanging() ? new DecimalFormat(param1NumberAxis.currentFormatterProperty.get()) : new DecimalFormat();
/* 521 */       ChangeListener<? super String> changeListener = (param1ObservableValue, param1Object1, param1Object2) -> this.formatter = param1NumberAxis.isAutoRanging() ? new DecimalFormat(param1NumberAxis.currentFormatterProperty.get()) : new DecimalFormat();
/*     */ 
/*     */       
/* 524 */       param1NumberAxis.currentFormatterProperty.addListener(changeListener);
/* 525 */       param1NumberAxis.autoRangingProperty().addListener((ChangeListener)changeListener);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultFormatter(NumberAxis param1NumberAxis, String param1String1, String param1String2) {
/* 536 */       this(param1NumberAxis);
/* 537 */       this.prefix = param1String1;
/* 538 */       this.suffix = param1String2;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString(Number param1Number) {
/* 548 */       return toString(param1Number, this.formatter);
/*     */     }
/*     */     
/*     */     private String toString(Number param1Number, String param1String) {
/* 552 */       if (param1String == null || param1String.isEmpty()) {
/* 553 */         return toString(param1Number, this.formatter);
/*     */       }
/* 555 */       return toString(param1Number, new DecimalFormat(param1String));
/*     */     }
/*     */ 
/*     */     
/*     */     private String toString(Number param1Number, DecimalFormat param1DecimalFormat) {
/* 560 */       if (this.prefix != null && this.suffix != null)
/* 561 */         return this.prefix + this.prefix + param1DecimalFormat.format(param1Number); 
/* 562 */       if (this.prefix != null)
/* 563 */         return this.prefix + this.prefix; 
/* 564 */       if (this.suffix != null) {
/* 565 */         return param1DecimalFormat.format(param1Number) + param1DecimalFormat.format(param1Number);
/*     */       }
/* 567 */       return param1DecimalFormat.format(param1Number);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Number fromString(String param1String) {
/*     */       try {
/* 579 */         boolean bool = (this.prefix == null) ? false : this.prefix.length();
/* 580 */         byte b = (this.suffix == null) ? 0 : this.suffix.length();
/* 581 */         return this.formatter.parse(param1String.substring(bool, param1String.length() - b));
/* 582 */       } catch (ParseException parseException) {
/* 583 */         return null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\NumberAxis.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */