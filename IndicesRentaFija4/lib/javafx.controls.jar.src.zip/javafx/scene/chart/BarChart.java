/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import com.sun.javafx.charts.Legend;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.animation.Animation;
/*     */ import javafx.animation.FadeTransition;
/*     */ import javafx.animation.Interpolator;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.KeyValue;
/*     */ import javafx.animation.ParallelTransition;
/*     */ import javafx.animation.Timeline;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BarChart<X, Y>
/*     */   extends XYChart<X, Y>
/*     */ {
/*  70 */   private Map<XYChart.Series<X, Y>, Map<String, XYChart.Data<X, Y>>> seriesCategoryMap = new HashMap<>();
/*     */   private final Orientation orientation;
/*     */   private CategoryAxis categoryAxis;
/*     */   private ValueAxis valueAxis;
/*     */   private Timeline dataRemoveTimeline;
/*  75 */   private double bottomPos = 0.0D;
/*  76 */   private static String NEGATIVE_STYLE = "negative";
/*     */   
/*     */   private ParallelTransition pt;
/*  79 */   private Map<XYChart.Data<X, Y>, Double> XYValueMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private DoubleProperty barGap = new StyleableDoubleProperty(4.0D) {
/*     */       protected void invalidated() {
/*  86 */         get();
/*  87 */         BarChart.this.requestChartLayout();
/*     */       }
/*     */       
/*     */       public Object getBean() {
/*  91 */         return BarChart.this;
/*     */       }
/*     */       
/*     */       public String getName() {
/*  95 */         return "barGap";
/*     */       }
/*     */       
/*     */       public CssMetaData<BarChart<?, ?>, Number> getCssMetaData() {
/*  99 */         return BarChart.StyleableProperties.BAR_GAP;
/*     */       }
/*     */     };
/* 102 */   public final double getBarGap() { return this.barGap.getValue().doubleValue(); }
/* 103 */   public final void setBarGap(double paramDouble) { this.barGap.setValue(Double.valueOf(paramDouble)); } public final DoubleProperty barGapProperty() {
/* 104 */     return this.barGap;
/*     */   }
/*     */   
/* 107 */   private DoubleProperty categoryGap = new StyleableDoubleProperty(10.0D) {
/*     */       protected void invalidated() {
/* 109 */         get();
/* 110 */         BarChart.this.requestChartLayout();
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 115 */         return BarChart.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 120 */         return "categoryGap";
/*     */       }
/*     */       
/*     */       public CssMetaData<BarChart<?, ?>, Number> getCssMetaData() {
/* 124 */         return BarChart.StyleableProperties.CATEGORY_GAP;
/*     */       }
/*     */     };
/* 127 */   public final double getCategoryGap() { return this.categoryGap.getValue().doubleValue(); }
/* 128 */   public final void setCategoryGap(double paramDouble) { this.categoryGap.setValue(Double.valueOf(paramDouble)); } public final DoubleProperty categoryGapProperty() {
/* 129 */     return this.categoryGap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BarChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1) {
/* 141 */     this(paramAxis, paramAxis1, FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BarChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1, @NamedArg("data") ObservableList<XYChart.Series<X, Y>> paramObservableList) {
/* 153 */     super(paramAxis, paramAxis1);
/* 154 */     getStyleClass().add("bar-chart");
/* 155 */     if ((!(paramAxis instanceof ValueAxis) || !(paramAxis1 instanceof CategoryAxis)) && (!(paramAxis1 instanceof ValueAxis) || !(paramAxis instanceof CategoryAxis)))
/*     */     {
/* 157 */       throw new IllegalArgumentException("Axis type incorrect, one of X,Y should be CategoryAxis and the other NumberAxis");
/*     */     }
/* 159 */     if (paramAxis instanceof CategoryAxis) {
/* 160 */       this.categoryAxis = (CategoryAxis)paramAxis;
/* 161 */       this.valueAxis = (ValueAxis)paramAxis1;
/* 162 */       this.orientation = Orientation.VERTICAL;
/*     */     } else {
/* 164 */       this.categoryAxis = (CategoryAxis)paramAxis1;
/* 165 */       this.valueAxis = (ValueAxis)paramAxis;
/* 166 */       this.orientation = Orientation.HORIZONTAL;
/*     */     } 
/*     */     
/* 169 */     pseudoClassStateChanged(HORIZONTAL_PSEUDOCLASS_STATE, (this.orientation == Orientation.HORIZONTAL));
/* 170 */     pseudoClassStateChanged(VERTICAL_PSEUDOCLASS_STATE, (this.orientation == Orientation.VERTICAL));
/* 171 */     setData(paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BarChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1, @NamedArg("data") ObservableList<XYChart.Series<X, Y>> paramObservableList, @NamedArg("categoryGap") double paramDouble) {
/* 184 */     this(paramAxis, paramAxis1);
/* 185 */     setData(paramObservableList);
/* 186 */     setCategoryGap(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dataItemAdded(XYChart.Series<X, Y> paramSeries, int paramInt, XYChart.Data<X, Y> paramData) {
/*     */     String str;
/* 193 */     if (this.orientation == Orientation.VERTICAL) {
/* 194 */       str = (String)paramData.getXValue();
/*     */     } else {
/* 196 */       str = (String)paramData.getYValue();
/*     */     } 
/* 198 */     Map<Object, Object> map = (Map)this.seriesCategoryMap.get(paramSeries);
/*     */     
/* 200 */     if (map == null) {
/* 201 */       map = new HashMap<>();
/* 202 */       this.seriesCategoryMap.put(paramSeries, map);
/*     */     } 
/*     */     
/* 205 */     if (!this.categoryAxis.getCategories().contains(str)) {
/*     */       
/* 207 */       this.categoryAxis.getCategories().add(paramInt, str);
/* 208 */     } else if (map.containsKey(str)) {
/*     */       
/* 210 */       XYChart.Data<X, Y> data = (XYChart.Data)map.get(str);
/* 211 */       getPlotChildren().remove(data.getNode());
/* 212 */       removeDataItemFromDisplay(paramSeries, data);
/* 213 */       requestChartLayout();
/* 214 */       map.remove(str);
/*     */     } 
/* 216 */     map.put(str, paramData);
/* 217 */     Node node = createBar(paramSeries, getData().indexOf(paramSeries), paramData, paramInt);
/* 218 */     if (shouldAnimate()) {
/* 219 */       animateDataAdd(paramData, node);
/*     */     } else {
/* 221 */       getPlotChildren().add(node);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void dataItemRemoved(XYChart.Data<X, Y> paramData, XYChart.Series<X, Y> paramSeries) {
/* 226 */     Node node = paramData.getNode();
/*     */     
/* 228 */     if (node != null) {
/* 229 */       node.focusTraversableProperty().unbind();
/*     */     }
/*     */     
/* 232 */     if (shouldAnimate()) {
/* 233 */       this.XYValueMap.clear();
/* 234 */       this.dataRemoveTimeline = createDataRemoveTimeline(paramData, node, paramSeries);
/* 235 */       this.dataRemoveTimeline.setOnFinished(paramActionEvent -> {
/*     */             paramData.setSeries(null);
/*     */             removeDataItemFromDisplay(paramSeries, paramData);
/*     */           });
/* 239 */       this.dataRemoveTimeline.play();
/*     */     } else {
/* 241 */       processDataRemove(paramSeries, paramData);
/* 242 */       removeDataItemFromDisplay(paramSeries, paramData);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void dataItemChanged(XYChart.Data<X, Y> paramData) {
/*     */     double d1;
/*     */     double d2;
/* 250 */     if (this.orientation == Orientation.VERTICAL) {
/* 251 */       d1 = ((Number)paramData.getYValue()).doubleValue();
/* 252 */       d2 = ((Number)paramData.getCurrentY()).doubleValue();
/*     */     } else {
/* 254 */       d1 = ((Number)paramData.getXValue()).doubleValue();
/* 255 */       d2 = ((Number)paramData.getCurrentX()).doubleValue();
/*     */     } 
/* 257 */     if (d2 > 0.0D && d1 < 0.0D) {
/*     */       
/* 259 */       paramData.getNode().getStyleClass().add(NEGATIVE_STYLE);
/* 260 */     } else if (d2 < 0.0D && d1 > 0.0D) {
/*     */ 
/*     */ 
/*     */       
/* 264 */       paramData.getNode().getStyleClass().remove(NEGATIVE_STYLE);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void seriesChanged(ListChangeListener.Change<? extends XYChart.Series> paramChange) {
/* 271 */     for (byte b = 0; b < getDataSize(); b++) {
/* 272 */       XYChart.Series series = getData().get(b);
/* 273 */       for (byte b1 = 0; b1 < series.getData().size(); b1++) {
/* 274 */         XYChart.Data data = series.getData().get(b1);
/* 275 */         Node node = data.getNode();
/* 276 */         node.getStyleClass().setAll(new String[] { "chart-bar", "series" + b, "data" + b1, series.defaultColorStyleClass });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void seriesAdded(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 284 */     HashMap<Object, Object> hashMap = new HashMap<>();
/* 285 */     for (byte b = 0; b < paramSeries.getData().size(); b++) {
/* 286 */       String str; XYChart.Data<X, Y> data = paramSeries.getData().get(b);
/* 287 */       Node node = createBar(paramSeries, paramInt, data, b);
/*     */       
/* 289 */       if (this.orientation == Orientation.VERTICAL) {
/* 290 */         str = (String)data.getXValue();
/*     */       } else {
/* 292 */         str = (String)data.getYValue();
/*     */       } 
/* 294 */       hashMap.put(str, data);
/* 295 */       if (shouldAnimate()) {
/* 296 */         animateDataAdd(data, node);
/*     */       }
/*     */       else {
/*     */         
/* 300 */         double d = (this.orientation == Orientation.VERTICAL) ? ((Number)data.getYValue()).doubleValue() : ((Number)data.getXValue()).doubleValue();
/* 301 */         if (d < 0.0D) {
/* 302 */           node.getStyleClass().add(NEGATIVE_STYLE);
/*     */         }
/* 304 */         getPlotChildren().add(node);
/*     */       } 
/*     */     } 
/* 307 */     if (hashMap.size() > 0) this.seriesCategoryMap.put(paramSeries, hashMap);
/*     */   
/*     */   }
/*     */   
/*     */   protected void seriesRemoved(XYChart.Series<X, Y> paramSeries) {
/* 312 */     if (shouldAnimate()) {
/* 313 */       this.pt = new ParallelTransition();
/* 314 */       this.pt.setOnFinished(paramActionEvent -> removeSeriesFromDisplay(paramSeries));
/*     */ 
/*     */ 
/*     */       
/* 318 */       this.XYValueMap.clear();
/* 319 */       for (Iterator<XYChart.Data> iterator = paramSeries.getData().iterator(); iterator.hasNext(); ) { XYChart.Data<X, Y> data = iterator.next();
/* 320 */         Node node = data.getNode();
/*     */         
/* 322 */         if (getSeriesSize() > 1) {
/* 323 */           Timeline timeline = createDataRemoveTimeline(data, node, paramSeries);
/* 324 */           this.pt.getChildren().add(timeline);
/*     */           continue;
/*     */         } 
/* 327 */         FadeTransition fadeTransition = new FadeTransition(Duration.millis(700.0D), node);
/* 328 */         fadeTransition.setFromValue(1.0D);
/* 329 */         fadeTransition.setToValue(0.0D);
/* 330 */         fadeTransition.setOnFinished(paramActionEvent -> {
/*     */               processDataRemove(paramSeries, paramData);
/*     */               paramNode.setOpacity(1.0D);
/*     */             });
/* 334 */         this.pt.getChildren().add(fadeTransition); }
/*     */ 
/*     */       
/* 337 */       this.pt.play();
/*     */     } else {
/* 339 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) {
/* 340 */         processDataRemove(paramSeries, data);
/*     */       }
/* 342 */       removeSeriesFromDisplay(paramSeries);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void layoutPlotChildren() {
/* 348 */     double d1 = this.categoryAxis.getCategorySpacing();
/*     */     
/* 350 */     double d2 = d1 - getCategoryGap() + getBarGap();
/* 351 */     double d3 = d2 / getSeriesSize() - getBarGap();
/* 352 */     double d4 = -((d1 - getCategoryGap()) / 2.0D);
/*     */     
/* 354 */     double d5 = (this.valueAxis.getLowerBound() > 0.0D) ? this.valueAxis.getDisplayPosition(Double.valueOf(this.valueAxis.getLowerBound())) : this.valueAxis.getZeroPosition();
/*     */     
/* 356 */     if (d3 <= 0.0D) d3 = 1.0D;
/*     */     
/* 358 */     byte b = 0;
/* 359 */     for (String str : this.categoryAxis.getCategories()) {
/* 360 */       byte b1 = 0;
/* 361 */       for (Iterator<XYChart.Series<X, Y>> iterator = getDisplayedSeriesIterator(); iterator.hasNext(); ) {
/* 362 */         XYChart.Series<X, Y> series = iterator.next();
/* 363 */         XYChart.Data<X, Y> data = getDataItem(series, b1, b, str);
/* 364 */         if (data != null) {
/* 365 */           double d6, d7; Node node = data.getNode();
/*     */ 
/*     */           
/* 368 */           if (this.orientation == Orientation.VERTICAL) {
/* 369 */             d6 = getXAxis().getDisplayPosition(data.getCurrentX());
/* 370 */             d7 = getYAxis().getDisplayPosition(data.getCurrentY());
/*     */           } else {
/* 372 */             d6 = getYAxis().getDisplayPosition(data.getCurrentY());
/* 373 */             d7 = getXAxis().getDisplayPosition(data.getCurrentX());
/*     */           } 
/* 375 */           if (Double.isNaN(d6) || Double.isNaN(d7)) {
/*     */             continue;
/*     */           }
/* 378 */           double d8 = Math.min(d7, d5);
/* 379 */           double d9 = Math.max(d7, d5);
/* 380 */           this.bottomPos = d8;
/* 381 */           if (this.orientation == Orientation.VERTICAL) {
/* 382 */             node.resizeRelocate(d6 + d4 + (d3 + getBarGap()) * b1, d8, d3, d9 - d8);
/*     */           }
/*     */           else {
/*     */             
/* 386 */             node.resizeRelocate(d8, d6 + d4 + (d3 + getBarGap()) * b1, d9 - d8, d3);
/*     */           } 
/*     */ 
/*     */           
/* 390 */           b1++;
/*     */         } 
/*     */       } 
/* 393 */       b++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   Legend.LegendItem createLegendItemForSeries(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 399 */     Legend.LegendItem legendItem = new Legend.LegendItem(paramSeries.getName());
/* 400 */     legendItem.getSymbol().getStyleClass().addAll(new String[] { "chart-bar", "series" + paramInt, "bar-legend-symbol", paramSeries.defaultColorStyleClass });
/*     */     
/* 402 */     return legendItem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateMap(XYChart.Series<X, Y> paramSeries, XYChart.Data<X, Y> paramData) {
/* 409 */     String str = (this.orientation == Orientation.VERTICAL) ? (String)paramData.getXValue() : (String)paramData.getYValue();
/* 410 */     Map map = this.seriesCategoryMap.get(paramSeries);
/* 411 */     if (map != null) {
/* 412 */       map.remove(str);
/* 413 */       if (map.isEmpty()) this.seriesCategoryMap.remove(paramSeries); 
/*     */     } 
/* 415 */     if (this.seriesCategoryMap.isEmpty() && this.categoryAxis.isAutoRanging()) this.categoryAxis.getCategories().clear(); 
/*     */   }
/*     */   
/*     */   private void processDataRemove(XYChart.Series<X, Y> paramSeries, XYChart.Data<X, Y> paramData) {
/* 419 */     Node node = paramData.getNode();
/* 420 */     getPlotChildren().remove(node);
/* 421 */     updateMap(paramSeries, paramData);
/*     */   }
/*     */ 
/*     */   
/*     */   private void animateDataAdd(XYChart.Data<X, Y> paramData, Node paramNode) {
/* 426 */     if (this.orientation == Orientation.VERTICAL) {
/* 427 */       double d = ((Number)paramData.getYValue()).doubleValue();
/* 428 */       if (d < 0.0D) {
/* 429 */         paramNode.getStyleClass().add(NEGATIVE_STYLE);
/*     */       }
/* 431 */       paramData.setCurrentY(getYAxis().toRealValue((d < 0.0D) ? -this.bottomPos : this.bottomPos));
/* 432 */       getPlotChildren().add(paramNode);
/* 433 */       paramData.setYValue(getYAxis().toRealValue(d));
/* 434 */       animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(paramData
/*     */                   
/* 436 */                   .currentYProperty(), paramData
/* 437 */                   .getCurrentY()) }), new KeyFrame(
/* 438 */               Duration.millis(700.0D), new KeyValue[] { new KeyValue(paramData
/* 439 */                   .currentYProperty(), paramData
/* 440 */                   .getYValue(), Interpolator.EASE_BOTH) }) });
/*     */     } else {
/*     */       
/* 443 */       double d = ((Number)paramData.getXValue()).doubleValue();
/* 444 */       if (d < 0.0D) {
/* 445 */         paramNode.getStyleClass().add(NEGATIVE_STYLE);
/*     */       }
/* 447 */       paramData.setCurrentX(getXAxis().toRealValue((d < 0.0D) ? -this.bottomPos : this.bottomPos));
/* 448 */       getPlotChildren().add(paramNode);
/* 449 */       paramData.setXValue(getXAxis().toRealValue(d));
/* 450 */       animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(paramData
/*     */                   
/* 452 */                   .currentXProperty(), paramData
/* 453 */                   .getCurrentX()) }), new KeyFrame(
/* 454 */               Duration.millis(700.0D), new KeyValue[] { new KeyValue(paramData
/* 455 */                   .currentXProperty(), paramData
/* 456 */                   .getXValue(), Interpolator.EASE_BOTH) }) });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Timeline createDataRemoveTimeline(XYChart.Data<X, Y> paramData, Node paramNode, XYChart.Series<X, Y> paramSeries) {
/* 462 */     Timeline timeline = new Timeline();
/* 463 */     if (this.orientation == Orientation.VERTICAL) {
/*     */ 
/*     */ 
/*     */       
/* 467 */       this.XYValueMap.put(paramData, Double.valueOf(((Number)paramData.getYValue()).doubleValue()));
/* 468 */       paramData.setYValue(getYAxis().toRealValue(this.bottomPos));
/* 469 */       timeline.getKeyFrames().addAll(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(paramData
/*     */                   
/* 471 */                   .currentYProperty(), paramData.getCurrentY()) }), new KeyFrame(
/* 472 */               Duration.millis(700.0D), paramActionEvent -> { processDataRemove(paramSeries, paramData); this.XYValueMap.clear(); }new KeyValue[] { new KeyValue(paramData
/*     */ 
/*     */ 
/*     */                   
/* 476 */                   .currentYProperty(), paramData
/* 477 */                   .getYValue(), Interpolator.EASE_BOTH) }) });
/*     */     }
/*     */     else {
/*     */       
/* 481 */       this.XYValueMap.put(paramData, Double.valueOf(((Number)paramData.getXValue()).doubleValue()));
/* 482 */       paramData.setXValue(getXAxis().toRealValue(getXAxis().getZeroPosition()));
/* 483 */       timeline.getKeyFrames().addAll(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(paramData
/*     */                   
/* 485 */                   .currentXProperty(), paramData.getCurrentX()) }), new KeyFrame(
/* 486 */               Duration.millis(700.0D), paramActionEvent -> { processDataRemove(paramSeries, paramData); this.XYValueMap.clear(); }new KeyValue[] { new KeyValue(paramData
/*     */ 
/*     */ 
/*     */                   
/* 490 */                   .currentXProperty(), paramData
/* 491 */                   .getXValue(), Interpolator.EASE_BOTH) }) });
/*     */     } 
/*     */     
/* 494 */     return timeline;
/*     */   }
/*     */   
/*     */   void dataBeingRemovedIsAdded(XYChart.Data<X, Y> paramData, XYChart.Series<X, Y> paramSeries) {
/* 498 */     if (this.dataRemoveTimeline != null) {
/* 499 */       this.dataRemoveTimeline.setOnFinished(null);
/* 500 */       this.dataRemoveTimeline.stop();
/*     */     } 
/* 502 */     processDataRemove(paramSeries, paramData);
/* 503 */     paramData.setSeries(null);
/* 504 */     removeDataItemFromDisplay(paramSeries, paramData);
/* 505 */     restoreDataValues(paramData);
/* 506 */     this.XYValueMap.clear();
/*     */   }
/*     */   
/*     */   private void restoreDataValues(XYChart.Data paramData) {
/* 510 */     Double double_ = this.XYValueMap.get(paramData);
/* 511 */     if (double_ != null)
/*     */     {
/* 513 */       if (this.orientation.equals(Orientation.VERTICAL)) {
/* 514 */         paramData.setYValue(double_);
/* 515 */         paramData.setCurrentY(double_);
/*     */       } else {
/* 517 */         paramData.setXValue(double_);
/* 518 */         paramData.setCurrentX(double_);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   void seriesBeingRemovedIsAdded(XYChart.Series<X, Y> paramSeries) {
/* 524 */     boolean bool = (this.pt.getChildren().size() == 1) ? true : false;
/* 525 */     if (this.pt != null) {
/* 526 */       if (!this.pt.getChildren().isEmpty()) {
/* 527 */         for (Animation animation : this.pt.getChildren()) {
/* 528 */           animation.setOnFinished(null);
/*     */         }
/*     */       }
/* 531 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) {
/* 532 */         processDataRemove(paramSeries, data);
/* 533 */         if (!bool) {
/* 534 */           restoreDataValues(data);
/*     */         }
/*     */       } 
/* 537 */       this.XYValueMap.clear();
/* 538 */       this.pt.setOnFinished(null);
/* 539 */       this.pt.getChildren().clear();
/* 540 */       this.pt.stop();
/* 541 */       removeSeriesFromDisplay(paramSeries);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Node createBar(XYChart.Series<X, Y> paramSeries, int paramInt1, XYChart.Data<X, Y> paramData, int paramInt2) {
/* 546 */     Node node = paramData.getNode();
/* 547 */     if (node == null) {
/* 548 */       node = new StackPane();
/* 549 */       node.setAccessibleRole(AccessibleRole.TEXT);
/* 550 */       node.setAccessibleRoleDescription("Bar");
/* 551 */       node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
/* 552 */       paramData.setNode(node);
/*     */     } 
/* 554 */     node.getStyleClass().setAll(new String[] { "chart-bar", "series" + paramInt1, "data" + paramInt2, paramSeries.defaultColorStyleClass });
/* 555 */     return node;
/*     */   }
/*     */   
/*     */   private XYChart.Data<X, Y> getDataItem(XYChart.Series<X, Y> paramSeries, int paramInt1, int paramInt2, String paramString) {
/* 559 */     Map map = this.seriesCategoryMap.get(paramSeries);
/* 560 */     return (map != null) ? (XYChart.Data<X, Y>)map.get(paramString) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 569 */     private static final CssMetaData<BarChart<?, ?>, Number> BAR_GAP = new CssMetaData<BarChart<?, ?>, Number>("-fx-bar-gap", 
/*     */         
/* 571 */         SizeConverter.getInstance(), Double.valueOf(4.0D))
/*     */       {
/*     */         public boolean isSettable(BarChart<?, ?> param2BarChart)
/*     */         {
/* 575 */           return (param2BarChart.barGap == null || !param2BarChart.barGap.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(BarChart<?, ?> param2BarChart) {
/* 580 */           return (StyleableProperty<Number>)param2BarChart.barGapProperty();
/*     */         }
/*     */       };
/*     */     
/* 584 */     private static final CssMetaData<BarChart<?, ?>, Number> CATEGORY_GAP = new CssMetaData<BarChart<?, ?>, Number>("-fx-category-gap", 
/*     */         
/* 586 */         SizeConverter.getInstance(), Double.valueOf(10.0D))
/*     */       {
/*     */         public boolean isSettable(BarChart<?, ?> param2BarChart)
/*     */         {
/* 590 */           return (param2BarChart.categoryGap == null || !param2BarChart.categoryGap.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(BarChart<?, ?> param2BarChart) {
/* 595 */           return (StyleableProperty<Number>)param2BarChart.categoryGapProperty();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 603 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(XYChart.getClassCssMetaData());
/* 604 */       arrayList.add(BAR_GAP);
/* 605 */       arrayList.add(CATEGORY_GAP);
/* 606 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 616 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 625 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 630 */   private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
/*     */ 
/*     */ 
/*     */   
/* 634 */   private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\BarChart.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */