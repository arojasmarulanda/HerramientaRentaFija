/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import com.sun.javafx.charts.Legend;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import javafx.animation.FadeTransition;
/*     */ import javafx.animation.Interpolator;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.KeyValue;
/*     */ import javafx.animation.Timeline;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Group;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.shape.ClosePath;
/*     */ import javafx.scene.shape.LineTo;
/*     */ import javafx.scene.shape.MoveTo;
/*     */ import javafx.scene.shape.Path;
/*     */ import javafx.scene.shape.StrokeLineJoin;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StackedAreaChart<X, Y>
/*     */   extends XYChart<X, Y>
/*     */ {
/*  75 */   private Map<XYChart.Series<X, Y>, DoubleProperty> seriesYMultiplierMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private BooleanProperty createSymbols = new StyleableBooleanProperty(true)
/*     */     {
/*     */       protected void invalidated() {
/*  86 */         for (byte b = 0; b < StackedAreaChart.this.getData().size(); b++) {
/*  87 */           XYChart.Series series = StackedAreaChart.this.getData().get(b);
/*  88 */           for (byte b1 = 0; b1 < series.getData().size(); b1++) {
/*  89 */             XYChart.Data data = series.getData().get(b1);
/*  90 */             Node node = data.getNode();
/*  91 */             if (get() && node == null) {
/*  92 */               node = StackedAreaChart.this.createSymbol(series, StackedAreaChart.this.getData().indexOf(series), data, b1);
/*  93 */               if (null != node) {
/*  94 */                 StackedAreaChart.this.getPlotChildren().add(node);
/*     */               }
/*  96 */             } else if (!get() && node != null) {
/*  97 */               StackedAreaChart.this.getPlotChildren().remove(node);
/*  98 */               node = null;
/*  99 */               data.setNode(null);
/*     */             } 
/*     */           } 
/*     */         } 
/* 103 */         StackedAreaChart.this.requestChartLayout();
/*     */       }
/*     */       
/*     */       public Object getBean() {
/* 107 */         return this;
/*     */       }
/*     */       
/*     */       public String getName() {
/* 111 */         return "createSymbols";
/*     */       }
/*     */       
/*     */       public CssMetaData<StackedAreaChart<?, ?>, Boolean> getCssMetaData() {
/* 115 */         return StackedAreaChart.StyleableProperties.CREATE_SYMBOLS;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getCreateSymbols() {
/* 125 */     return this.createSymbols.getValue().booleanValue();
/* 126 */   } public final void setCreateSymbols(boolean paramBoolean) { this.createSymbols.setValue(Boolean.valueOf(paramBoolean)); } public final BooleanProperty createSymbolsProperty() {
/* 127 */     return this.createSymbols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackedAreaChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1) {
/* 138 */     this(paramAxis, paramAxis1, FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackedAreaChart(@NamedArg("xAxis") Axis<X> paramAxis, @NamedArg("yAxis") Axis<Y> paramAxis1, @NamedArg("data") ObservableList<XYChart.Series<X, Y>> paramObservableList) {
/* 153 */     super(paramAxis, paramAxis1);
/* 154 */     if (!(paramAxis1 instanceof ValueAxis)) {
/* 155 */       throw new IllegalArgumentException("Axis type incorrect, yAxis must be of ValueAxis type.");
/*     */     }
/* 157 */     setData(paramObservableList);
/*     */   }
/*     */ 
/*     */   
/*     */   private static double doubleValue(Number paramNumber) {
/* 162 */     return doubleValue(paramNumber, 0.0D);
/*     */   } private static double doubleValue(Number paramNumber, double paramDouble) {
/* 164 */     return (paramNumber == null) ? paramDouble : paramNumber.doubleValue();
/*     */   }
/*     */   
/*     */   protected void dataItemAdded(XYChart.Series<X, Y> paramSeries, int paramInt, XYChart.Data<X, Y> paramData) {
/* 168 */     Node node = createSymbol(paramSeries, getData().indexOf(paramSeries), paramData, paramInt);
/* 169 */     if (shouldAnimate()) {
/* 170 */       boolean bool = false;
/* 171 */       if (paramInt > 0 && paramInt < paramSeries.getData().size() - 1) {
/* 172 */         bool = true;
/* 173 */         XYChart.Data data1 = paramSeries.getData().get(paramInt - 1);
/* 174 */         XYChart.Data data2 = paramSeries.getData().get(paramInt + 1);
/* 175 */         double d1 = getXAxis().toNumericValue((X)data1.getXValue());
/* 176 */         double d2 = getYAxis().toNumericValue((Y)data1.getYValue());
/* 177 */         double d3 = getXAxis().toNumericValue((X)data2.getXValue());
/* 178 */         double d4 = getYAxis().toNumericValue((Y)data2.getYValue());
/*     */         
/* 180 */         double d5 = getXAxis().toNumericValue(paramData.getXValue());
/* 181 */         double d6 = getYAxis().toNumericValue(paramData.getYValue());
/*     */ 
/*     */         
/* 184 */         double d7 = (d4 - d2) / (d3 - d1) * d5 + (d3 * d2 - d4 * d1) / (d3 - d1);
/* 185 */         paramData.setCurrentY(getYAxis().toRealValue(d7));
/* 186 */         paramData.setCurrentX(getXAxis().toRealValue(d5));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 192 */       else if (paramInt == 0 && paramSeries.getData().size() > 1) {
/* 193 */         bool = true;
/* 194 */         paramData.setCurrentX((X)((XYChart.Data)paramSeries.getData().get(1)).getXValue());
/* 195 */         paramData.setCurrentY((Y)((XYChart.Data)paramSeries.getData().get(1)).getYValue());
/* 196 */       } else if (paramInt == paramSeries.getData().size() - 1 && paramSeries.getData().size() > 1) {
/* 197 */         bool = true;
/* 198 */         int i = paramSeries.getData().size() - 2;
/* 199 */         paramData.setCurrentX((X)((XYChart.Data)paramSeries.getData().get(i)).getXValue());
/* 200 */         paramData.setCurrentY((Y)((XYChart.Data)paramSeries.getData().get(i)).getYValue());
/* 201 */       } else if (node != null) {
/*     */         
/* 203 */         node.setOpacity(0.0D);
/* 204 */         getPlotChildren().add(node);
/* 205 */         FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 206 */         fadeTransition.setToValue(1.0D);
/* 207 */         fadeTransition.play();
/*     */       } 
/* 209 */       if (bool) {
/* 210 */         animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, paramActionEvent -> { if (paramNode != null && !getPlotChildren().contains(paramNode)) getPlotChildren().add(paramNode);  }new KeyValue[] { new KeyValue(paramData
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                     
/* 216 */                     .currentYProperty(), paramData
/* 217 */                     .getCurrentY()), new KeyValue(paramData
/* 218 */                     .currentXProperty(), paramData
/* 219 */                     .getCurrentX()) }), new KeyFrame(
/*     */                 
/* 221 */                 Duration.millis(800.0D), new KeyValue[] { new KeyValue(paramData.currentYProperty(), paramData
/* 222 */                     .getYValue(), Interpolator.EASE_BOTH), new KeyValue(paramData
/* 223 */                     .currentXProperty(), paramData
/* 224 */                     .getXValue(), Interpolator.EASE_BOTH) }) });
/*     */       
/*     */       }
/*     */     }
/* 228 */     else if (node != null) {
/* 229 */       getPlotChildren().add(node);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void dataItemRemoved(XYChart.Data<X, Y> paramData, XYChart.Series<X, Y> paramSeries) {
/* 234 */     Node node = paramData.getNode();
/*     */     
/* 236 */     if (node != null) {
/* 237 */       node.focusTraversableProperty().unbind();
/*     */     }
/*     */ 
/*     */     
/* 241 */     int i = paramSeries.getItemIndex(paramData);
/* 242 */     if (shouldAnimate()) {
/* 243 */       boolean bool = false;
/*     */       
/* 245 */       int j = paramSeries.getDataSize();
/*     */ 
/*     */       
/* 248 */       int k = paramSeries.getData().size();
/* 249 */       if (i > 0 && i < j - 1) {
/* 250 */         bool = true;
/* 251 */         XYChart.Data<X, Y> data1 = paramSeries.getItem(i - 1);
/* 252 */         XYChart.Data<X, Y> data2 = paramSeries.getItem(i + 1);
/* 253 */         double d1 = getXAxis().toNumericValue(data1.getXValue());
/* 254 */         double d2 = getYAxis().toNumericValue(data1.getYValue());
/* 255 */         double d3 = getXAxis().toNumericValue(data2.getXValue());
/* 256 */         double d4 = getYAxis().toNumericValue(data2.getYValue());
/*     */         
/* 258 */         double d5 = getXAxis().toNumericValue(paramData.getXValue());
/* 259 */         double d6 = getYAxis().toNumericValue(paramData.getYValue());
/*     */ 
/*     */         
/* 262 */         double d7 = (d4 - d2) / (d3 - d1) * d5 + (d3 * d2 - d4 * d1) / (d3 - d1);
/* 263 */         paramData.setCurrentX(getXAxis().toRealValue(d5));
/* 264 */         paramData.setCurrentY(getYAxis().toRealValue(d6));
/* 265 */         paramData.setXValue(getXAxis().toRealValue(d5));
/* 266 */         paramData.setYValue(getYAxis().toRealValue(d7));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 272 */       else if (i == 0 && k > 1) {
/* 273 */         bool = true;
/* 274 */         paramData.setXValue((X)((XYChart.Data)paramSeries.getData().get(0)).getXValue());
/* 275 */         paramData.setYValue((Y)((XYChart.Data)paramSeries.getData().get(0)).getYValue());
/* 276 */       } else if (i == j - 1 && k > 1) {
/* 277 */         bool = true;
/* 278 */         int m = k - 1;
/* 279 */         paramData.setXValue((X)((XYChart.Data)paramSeries.getData().get(m)).getXValue());
/* 280 */         paramData.setYValue((Y)((XYChart.Data)paramSeries.getData().get(m)).getYValue());
/* 281 */       } else if (node != null) {
/*     */         
/* 283 */         node.setOpacity(0.0D);
/* 284 */         FadeTransition fadeTransition = new FadeTransition(Duration.millis(500.0D), node);
/* 285 */         fadeTransition.setToValue(0.0D);
/* 286 */         fadeTransition.setOnFinished(paramActionEvent -> {
/*     */               getPlotChildren().remove(paramNode);
/*     */               removeDataItemFromDisplay(paramSeries, paramData);
/*     */               paramNode.setOpacity(1.0D);
/*     */             });
/* 291 */         fadeTransition.play();
/*     */       } else {
/* 293 */         paramData.setSeries(null);
/* 294 */         removeDataItemFromDisplay(paramSeries, paramData);
/*     */       } 
/* 296 */       if (bool) {
/* 297 */         animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(paramData.currentYProperty(), paramData
/* 298 */                     .getCurrentY()), new KeyValue(paramData.currentXProperty(), paramData
/* 299 */                     .getCurrentX()) }), new KeyFrame(
/* 300 */                 Duration.millis(800.0D), paramActionEvent -> { getPlotChildren().remove(paramNode); removeDataItemFromDisplay(paramSeries, paramData); }new KeyValue[] { new KeyValue(paramData
/*     */ 
/*     */ 
/*     */                     
/* 304 */                     .currentYProperty(), paramData
/* 305 */                     .getYValue(), Interpolator.EASE_BOTH), new KeyValue(paramData
/* 306 */                     .currentXProperty(), paramData
/* 307 */                     .getXValue(), Interpolator.EASE_BOTH) }) });
/*     */       }
/*     */     } else {
/*     */       
/* 311 */       getPlotChildren().remove(node);
/* 312 */       removeDataItemFromDisplay(paramSeries, paramData);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dataItemChanged(XYChart.Data<X, Y> paramData) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void seriesChanged(ListChangeListener.Change<? extends XYChart.Series> paramChange) {
/* 323 */     for (byte b = 0; b < getDataSize(); b++) {
/* 324 */       XYChart.Series series = getData().get(b);
/* 325 */       Path path1 = (Path)((Group)series.getNode()).getChildren().get(1);
/* 326 */       Path path2 = (Path)((Group)series.getNode()).getChildren().get(0);
/* 327 */       path1.getStyleClass().setAll(new String[] { "chart-series-area-line", "series" + b, series.defaultColorStyleClass });
/* 328 */       path2.getStyleClass().setAll(new String[] { "chart-series-area-fill", "series" + b, series.defaultColorStyleClass });
/* 329 */       for (byte b1 = 0; b1 < series.getData().size(); b1++) {
/* 330 */         XYChart.Data data = series.getData().get(b1);
/* 331 */         Node node = data.getNode();
/* 332 */         if (node != null) node.getStyleClass().setAll(new String[] { "chart-area-symbol", "series" + b, "data" + b1, series.defaultColorStyleClass });
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void seriesAdded(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 339 */     Path path1 = new Path();
/* 340 */     Path path2 = new Path();
/* 341 */     path1.setStrokeLineJoin(StrokeLineJoin.BEVEL);
/* 342 */     path2.setStrokeLineJoin(StrokeLineJoin.BEVEL);
/* 343 */     Group group = new Group(new Node[] { path2, path1 });
/* 344 */     paramSeries.setNode(group);
/*     */     
/* 346 */     SimpleDoubleProperty simpleDoubleProperty = new SimpleDoubleProperty(this, "seriesYMultiplier");
/* 347 */     this.seriesYMultiplierMap.put(paramSeries, simpleDoubleProperty);
/*     */     
/* 349 */     if (shouldAnimate()) {
/* 350 */       simpleDoubleProperty.setValue(Double.valueOf(0.0D));
/*     */     } else {
/* 352 */       simpleDoubleProperty.setValue(Double.valueOf(1.0D));
/*     */     } 
/* 354 */     getPlotChildren().add(group);
/* 355 */     ArrayList<KeyFrame> arrayList = new ArrayList();
/* 356 */     if (shouldAnimate()) {
/*     */       
/* 358 */       arrayList.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(group
/* 359 */                 .opacityProperty(), Integer.valueOf(0)), new KeyValue(simpleDoubleProperty, 
/* 360 */                 Integer.valueOf(0)) }));
/*     */       
/* 362 */       arrayList.add(new KeyFrame(Duration.millis(200.0D), new KeyValue[] { new KeyValue(group
/* 363 */                 .opacityProperty(), Integer.valueOf(1)) }));
/*     */       
/* 365 */       arrayList.add(new KeyFrame(Duration.millis(500.0D), new KeyValue[] { new KeyValue(simpleDoubleProperty, 
/* 366 */                 Integer.valueOf(1)) }));
/*     */     } 
/*     */     
/* 369 */     for (byte b = 0; b < paramSeries.getData().size(); b++) {
/* 370 */       XYChart.Data<X, Y> data = paramSeries.getData().get(b);
/* 371 */       Node node = createSymbol(paramSeries, paramInt, data, b);
/* 372 */       if (node != null) {
/* 373 */         if (shouldAnimate()) node.setOpacity(0.0D); 
/* 374 */         getPlotChildren().add(node);
/* 375 */         if (shouldAnimate()) {
/*     */           
/* 377 */           arrayList.add(new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(node.opacityProperty(), Integer.valueOf(0)) }));
/* 378 */           arrayList.add(new KeyFrame(Duration.millis(200.0D), new KeyValue[] { new KeyValue(node.opacityProperty(), Integer.valueOf(1)) }));
/*     */         } 
/*     */       } 
/*     */     } 
/* 382 */     if (shouldAnimate()) animate(arrayList.<KeyFrame>toArray(new KeyFrame[arrayList.size()]));
/*     */   
/*     */   }
/*     */   
/*     */   protected void seriesRemoved(XYChart.Series<X, Y> paramSeries) {
/* 387 */     this.seriesYMultiplierMap.remove(paramSeries);
/*     */     
/* 389 */     if (shouldAnimate()) {
/* 390 */       Timeline timeline = new Timeline(createSeriesRemoveTimeLine(paramSeries, 400L));
/* 391 */       timeline.play();
/*     */     } else {
/* 393 */       getPlotChildren().remove(paramSeries.getNode());
/* 394 */       for (XYChart.Data<X, Y> data : paramSeries.getData()) getPlotChildren().remove(data.getNode()); 
/* 395 */       removeSeriesFromDisplay(paramSeries);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateAxisRange() {
/* 403 */     Axis<X> axis = getXAxis();
/* 404 */     Axis<Y> axis1 = getYAxis();
/* 405 */     if (axis.isAutoRanging()) {
/* 406 */       ArrayList<X> arrayList = new ArrayList();
/* 407 */       for (XYChart.Series<X, Y> series : getData()) {
/* 408 */         for (XYChart.Data data : series.getData()) {
/* 409 */           arrayList.add(data.getXValue());
/*     */         }
/*     */       } 
/* 412 */       axis.invalidateRange(arrayList);
/*     */     } 
/* 414 */     if (axis1.isAutoRanging()) {
/* 415 */       double d = Double.MAX_VALUE;
/* 416 */       Iterator<XYChart.Series<X, Y>> iterator = getDisplayedSeriesIterator();
/* 417 */       boolean bool = true;
/* 418 */       TreeMap<Object, Object> treeMap1 = new TreeMap<>();
/* 419 */       TreeMap<Object, Object> treeMap2 = new TreeMap<>();
/* 420 */       TreeMap<Object, Object> treeMap3 = new TreeMap<>();
/* 421 */       while (iterator.hasNext()) {
/* 422 */         treeMap3.clear();
/* 423 */         XYChart.Series series = iterator.next();
/* 424 */         for (XYChart.Data data : series.getData()) {
/* 425 */           if (data != null) {
/* 426 */             double d1 = axis.toNumericValue((X)data.getXValue());
/* 427 */             double d2 = axis1.toNumericValue((Y)data.getYValue());
/* 428 */             treeMap3.put(Double.valueOf(d1), Double.valueOf(d2));
/* 429 */             if (bool) {
/*     */               
/* 431 */               treeMap1.put(Double.valueOf(d1), Double.valueOf(d2));
/*     */               
/* 433 */               d = Math.min(d, d2); continue;
/*     */             } 
/* 435 */             if (treeMap2.containsKey(Double.valueOf(d1))) {
/* 436 */               treeMap1.put(Double.valueOf(d1), Double.valueOf(((Double)treeMap2.get(Double.valueOf(d1))).doubleValue() + d2));
/*     */               continue;
/*     */             } 
/* 439 */             Map.Entry<Object, Object> entry1 = treeMap2.higherEntry(Double.valueOf(d1));
/* 440 */             Map.Entry<Object, Object> entry2 = treeMap2.lowerEntry(Double.valueOf(d1));
/* 441 */             if (entry1 != null && entry2 != null) {
/*     */               
/* 443 */               treeMap1.put(Double.valueOf(d1), Double.valueOf((d1 - ((Double)entry2.getKey()).doubleValue()) / (((Double)entry1.getKey()).doubleValue() - ((Double)entry2.getKey()).doubleValue()) * (((Double)entry2
/* 444 */                     .getValue()).doubleValue() + ((Double)entry1.getValue()).doubleValue()) + d2)); continue;
/* 445 */             }  if (entry1 != null) {
/*     */               
/* 447 */               treeMap1.put(Double.valueOf(d1), Double.valueOf(((Double)entry1.getValue()).doubleValue() + d2)); continue;
/* 448 */             }  if (entry2 != null) {
/*     */               
/* 450 */               treeMap1.put(Double.valueOf(d1), Double.valueOf(((Double)entry2.getValue()).doubleValue() + d2));
/*     */               continue;
/*     */             } 
/* 453 */             treeMap1.put(Double.valueOf(d1), Double.valueOf(d2));
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 460 */         for (Map.Entry<Object, Object> entry1 : treeMap2.entrySet()) {
/* 461 */           if (treeMap1.keySet().contains(entry1.getKey())) {
/*     */             continue;
/*     */           }
/* 464 */           Double double_1 = (Double)entry1.getKey();
/* 465 */           Double double_2 = (Double)entry1.getValue();
/*     */           
/* 467 */           Map.Entry<Object, Object> entry2 = treeMap3.higherEntry(double_1);
/* 468 */           Map.Entry<Object, Object> entry3 = treeMap3.lowerEntry(double_1);
/* 469 */           if (entry2 != null && entry3 != null) {
/*     */             
/* 471 */             treeMap1.put(double_1, Double.valueOf((double_1.doubleValue() - ((Double)entry3.getKey()).doubleValue()) / (((Double)entry2.getKey()).doubleValue() - ((Double)entry3.getKey()).doubleValue()) * (((Double)entry3
/* 472 */                   .getValue()).doubleValue() + ((Double)entry2.getValue()).doubleValue()) + double_2.doubleValue())); continue;
/* 473 */           }  if (entry2 != null) {
/*     */             
/* 475 */             treeMap1.put(double_1, Double.valueOf(((Double)entry2.getValue()).doubleValue() + double_2.doubleValue())); continue;
/* 476 */           }  if (entry3 != null) {
/*     */             
/* 478 */             treeMap1.put(double_1, Double.valueOf(((Double)entry3.getValue()).doubleValue() + double_2.doubleValue()));
/*     */             continue;
/*     */           } 
/* 481 */           treeMap1.put(double_1, double_2);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 486 */         treeMap2.clear();
/* 487 */         treeMap2.putAll(treeMap1);
/* 488 */         treeMap1.clear();
/* 489 */         bool = (d == Double.MAX_VALUE) ? true : false;
/*     */       } 
/*     */ 
/*     */       
/* 493 */       if (d != Double.MAX_VALUE) axis1.invalidateRange(Arrays.asList((Y[])new Object[] { axis1.toRealValue(d), axis1
/* 494 */                 .toRealValue(((Double)Collections.<Double>max(treeMap2.values())).doubleValue()) }));
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutPlotChildren() {
/* 502 */     ArrayList<DataPointInfo<X, Y>> arrayList = new ArrayList();
/*     */ 
/*     */     
/* 505 */     ArrayList<DataPointInfo> arrayList1 = new ArrayList();
/* 506 */     for (byte b = 0; b < getDataSize(); b++) {
/* 507 */       XYChart.Series<X, Y> series = getData().get(b);
/* 508 */       arrayList1.clear();
/*     */       
/* 510 */       for (DataPointInfo dataPointInfo : arrayList) {
/* 511 */         dataPointInfo.partOf = PartOf.PREVIOUS;
/* 512 */         arrayList1.add(dataPointInfo);
/*     */       } 
/* 514 */       arrayList.clear();
/*     */       
/* 516 */       for (Iterator<XYChart.Data<X, Y>> iterator = getDisplayedDataIterator(series); iterator.hasNext(); ) {
/* 517 */         XYChart.Data<?, ?> data = iterator.next();
/*     */         
/* 519 */         DataPointInfo<Object, Object> dataPointInfo = new DataPointInfo<>(data, data.getXValue(), data.getYValue(), PartOf.CURRENT);
/* 520 */         arrayList1.add(dataPointInfo);
/*     */       } 
/* 522 */       DoubleProperty doubleProperty = this.seriesYMultiplierMap.get(series);
/* 523 */       Path path1 = (Path)((Group)series.getNode()).getChildren().get(1);
/* 524 */       Path path2 = (Path)((Group)series.getNode()).getChildren().get(0);
/* 525 */       path1.getElements().clear();
/* 526 */       path2.getElements().clear();
/* 527 */       int i = 0;
/*     */       
/* 529 */       sortAggregateList((ArrayList)arrayList1);
/*     */       
/* 531 */       Axis<Y> axis = getYAxis();
/* 532 */       Axis<X> axis1 = getXAxis();
/* 533 */       boolean bool1 = false;
/* 534 */       boolean bool2 = false;
/* 535 */       int j = findNextCurrent((ArrayList)arrayList1, -1);
/* 536 */       int k = findPreviousCurrent((ArrayList)arrayList1, arrayList1.size());
/* 537 */       double d = axis.getZeroPosition();
/* 538 */       if (Double.isNaN(d)) {
/* 539 */         ValueAxis<Double> valueAxis = (ValueAxis)axis;
/* 540 */         if (valueAxis.getLowerBound() > 0.0D) {
/* 541 */           d = valueAxis.getDisplayPosition(Double.valueOf(valueAxis.getLowerBound()));
/*     */         } else {
/* 543 */           d = valueAxis.getDisplayPosition(Double.valueOf(valueAxis.getUpperBound()));
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 549 */       for (DataPointInfo dataPointInfo : arrayList1) {
/* 550 */         if (i == k) bool2 = true; 
/* 551 */         if (i == j) bool1 = true; 
/* 552 */         XYChart.Data<X, Y> data = dataPointInfo.dataItem;
/* 553 */         if (dataPointInfo.partOf.equals(PartOf.CURRENT)) {
/* 554 */           int n = findPreviousPrevious((ArrayList)arrayList1, i);
/* 555 */           int i1 = findNextPrevious((ArrayList)arrayList1, i);
/*     */ 
/*     */           
/* 558 */           if (n == -1 || (i1 == -1 && !((DataPointInfo)arrayList1.get(n)).x.equals(dataPointInfo.x))) {
/* 559 */             if (bool1) {
/*     */               
/* 561 */               XYChart.Data<X, Integer> data1 = new XYChart.Data<>(dataPointInfo.x, Integer.valueOf(0));
/* 562 */               addDropDown(arrayList, (XYChart.Data)data1, data1.getXValue(), (Y)data1.getYValue(), axis1
/* 563 */                   .getDisplayPosition(data1.getCurrentX()), d);
/*     */             } 
/* 565 */             double d1 = axis1.getDisplayPosition((X)data.getCurrentX());
/* 566 */             double d2 = axis.getDisplayPosition(axis
/* 567 */                 .toRealValue(axis.toNumericValue((Y)data.getCurrentY()) * doubleProperty.getValue().doubleValue()));
/* 568 */             addPoint(arrayList, data, data.getXValue(), data.getYValue(), d1, d2, PartOf.CURRENT, false, 
/* 569 */                 !bool1);
/* 570 */             if (i == k) {
/*     */               
/* 572 */               XYChart.Data<X, Integer> data1 = new XYChart.Data<>(dataPointInfo.x, Integer.valueOf(0));
/* 573 */               addDropDown(arrayList, (XYChart.Data)data1, data1.getXValue(), (Y)data1.getYValue(), axis1
/* 574 */                   .getDisplayPosition(data1.getCurrentX()), d);
/*     */             } 
/*     */           } else {
/* 577 */             DataPointInfo dataPointInfo1 = arrayList1.get(n);
/* 578 */             if (dataPointInfo1.x.equals(dataPointInfo.x)) {
/*     */ 
/*     */               
/* 581 */               if (dataPointInfo1.dropDown) {
/* 582 */                 n = findPreviousPrevious((ArrayList)arrayList1, n);
/* 583 */                 dataPointInfo1 = arrayList1.get(n);
/*     */               } 
/*     */               
/* 586 */               if (dataPointInfo1.x.equals(dataPointInfo.x)) {
/* 587 */                 double d1 = axis1.getDisplayPosition(data.getCurrentX());
/* 588 */                 double d2 = axis.toNumericValue(data.getCurrentY()) + axis.toNumericValue(dataPointInfo1.y);
/* 589 */                 double d3 = axis.getDisplayPosition(axis
/* 590 */                     .toRealValue(d2 * doubleProperty.getValue().doubleValue()));
/* 591 */                 addPoint(arrayList, data, dataPointInfo.x, axis.toRealValue(d2), d1, d3, PartOf.CURRENT, false, 
/* 592 */                     !bool1);
/*     */               } 
/* 594 */               if (bool2) {
/* 595 */                 addDropDown(arrayList, data, dataPointInfo1.x, dataPointInfo1.y, dataPointInfo1.displayX, dataPointInfo1.displayY);
/*     */               }
/*     */             } else {
/*     */               
/* 599 */               DataPointInfo dataPointInfo2 = (i1 == -1) ? null : arrayList1.get(i1);
/* 600 */               dataPointInfo1 = (n == -1) ? null : arrayList1.get(n);
/* 601 */               double d1 = axis.toNumericValue(data.getCurrentY());
/* 602 */               if (dataPointInfo1 != null && dataPointInfo2 != null) {
/* 603 */                 double d2 = axis1.getDisplayPosition(data.getCurrentX());
/* 604 */                 double d3 = interpolate(dataPointInfo1.displayX, dataPointInfo1.displayY, dataPointInfo2.displayX, dataPointInfo2.displayY, d2);
/*     */                 
/* 606 */                 double d4 = interpolate(axis1.toNumericValue(dataPointInfo1.x), axis
/* 607 */                     .toNumericValue(dataPointInfo1.y), axis1
/* 608 */                     .toNumericValue(dataPointInfo2.x), axis
/* 609 */                     .toNumericValue(dataPointInfo2.y), axis1
/* 610 */                     .toNumericValue(dataPointInfo.x));
/* 611 */                 if (bool1) {
/*     */                   
/* 613 */                   XYChart.Data<X, Double> data1 = new XYChart.Data<>(dataPointInfo.x, Double.valueOf(d4));
/* 614 */                   addDropDown(arrayList, (XYChart.Data)data1, dataPointInfo.x, axis.toRealValue(d4), d2, d3);
/*     */                 } 
/* 616 */                 double d5 = axis.getDisplayPosition(axis.toRealValue((d1 + d4) * doubleProperty.getValue().doubleValue()));
/*     */                 
/* 618 */                 addPoint(arrayList, data, dataPointInfo.x, axis.toRealValue(d1 + d4), d2, d5, PartOf.CURRENT, false, 
/* 619 */                     !bool1);
/* 620 */                 if (i == k)
/*     */                 {
/* 622 */                   XYChart.Data<X, Double> data1 = new XYChart.Data<>(dataPointInfo.x, Double.valueOf(d4));
/* 623 */                   addDropDown(arrayList, (XYChart.Data)data1, dataPointInfo.x, axis.toRealValue(d4), d2, d3);
/*     */                 }
/*     */               
/*     */               }
/*     */             
/*     */             }
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 635 */           int n = findPreviousCurrent((ArrayList)arrayList1, i);
/* 636 */           int i1 = findNextCurrent((ArrayList)arrayList1, i);
/*     */ 
/*     */           
/* 639 */           if (dataPointInfo.dropDown) {
/* 640 */             if (axis1.toNumericValue(dataPointInfo.x) <= axis1
/* 641 */               .toNumericValue(((DataPointInfo)arrayList1.get(j)).x) || axis1
/* 642 */               .toNumericValue(dataPointInfo.x) > axis1.toNumericValue(((DataPointInfo)arrayList1.get(k)).x)) {
/* 643 */               addDropDown(arrayList, data, dataPointInfo.x, dataPointInfo.y, dataPointInfo.displayX, dataPointInfo.displayY);
/*     */             }
/*     */           }
/* 646 */           else if (n == -1 || i1 == -1) {
/* 647 */             addPoint(arrayList, data, dataPointInfo.x, dataPointInfo.y, dataPointInfo.displayX, dataPointInfo.displayY, PartOf.CURRENT, true, false);
/*     */           } else {
/*     */             
/* 650 */             DataPointInfo dataPointInfo1 = arrayList1.get(i1);
/* 651 */             if (!dataPointInfo1.x.equals(dataPointInfo.x)) {
/*     */ 
/*     */ 
/*     */               
/* 655 */               DataPointInfo dataPointInfo2 = arrayList1.get(n);
/* 656 */               double d1 = axis1.getDisplayPosition(data.getCurrentX());
/* 657 */               double d2 = interpolate(axis1.toNumericValue(dataPointInfo2.x), axis
/* 658 */                   .toNumericValue(dataPointInfo2.y), axis1
/* 659 */                   .toNumericValue(dataPointInfo1.x), axis
/* 660 */                   .toNumericValue(dataPointInfo1.y), axis1
/* 661 */                   .toNumericValue(dataPointInfo.x));
/* 662 */               double d3 = axis.toNumericValue(dataPointInfo.y) + d2;
/* 663 */               double d4 = axis.getDisplayPosition(axis
/* 664 */                   .toRealValue(d3 * doubleProperty.getValue().doubleValue()));
/* 665 */               addPoint(arrayList, new XYChart.Data<>(dataPointInfo.x, (Y)Double.valueOf(d2)), dataPointInfo.x, axis.toRealValue(d3), d1, d4, PartOf.CURRENT, true, true);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 670 */         i++;
/* 671 */         if (bool1) bool1 = false; 
/* 672 */         if (bool2) bool2 = false;
/*     */       
/*     */       } 
/*     */       
/* 676 */       if (!arrayList.isEmpty()) {
/* 677 */         path1.getElements().add(new MoveTo(((DataPointInfo)arrayList.get(0)).displayX, ((DataPointInfo)arrayList.get(0)).displayY));
/* 678 */         path2.getElements().add(new MoveTo(((DataPointInfo)arrayList.get(0)).displayX, ((DataPointInfo)arrayList.get(0)).displayY));
/*     */       } 
/* 680 */       for (DataPointInfo<X, Y> dataPointInfo : arrayList) {
/* 681 */         if (dataPointInfo.lineTo) {
/* 682 */           path1.getElements().add(new LineTo(dataPointInfo.displayX, dataPointInfo.displayY));
/*     */         } else {
/* 684 */           path1.getElements().add(new MoveTo(dataPointInfo.displayX, dataPointInfo.displayY));
/*     */         } 
/* 686 */         path2.getElements().add(new LineTo(dataPointInfo.displayX, dataPointInfo.displayY));
/*     */         
/* 688 */         if (!dataPointInfo.skipSymbol) {
/* 689 */           Node node = dataPointInfo.dataItem.getNode();
/* 690 */           if (node != null) {
/* 691 */             double d1 = node.prefWidth(-1.0D);
/* 692 */             double d2 = node.prefHeight(-1.0D);
/* 693 */             node.resizeRelocate(dataPointInfo.displayX - d1 / 2.0D, dataPointInfo.displayY - d2 / 2.0D, d1, d2);
/*     */           } 
/*     */         } 
/*     */       } 
/* 697 */       for (int m = arrayList1.size() - 1; m > 0; m--) {
/* 698 */         DataPointInfo dataPointInfo = arrayList1.get(m);
/* 699 */         if (PartOf.PREVIOUS.equals(dataPointInfo.partOf)) {
/* 700 */           path2.getElements().add(new LineTo(dataPointInfo.displayX, dataPointInfo.displayY));
/*     */         }
/*     */       } 
/* 703 */       if (!path2.getElements().isEmpty()) {
/* 704 */         path2.getElements().add(new ClosePath());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void addDropDown(ArrayList<DataPointInfo<X, Y>> paramArrayList, XYChart.Data<X, Y> paramData, X paramX, Y paramY, double paramDouble1, double paramDouble2) {
/* 711 */     DataPointInfo<Object, Object> dataPointInfo = new DataPointInfo<>(true);
/* 712 */     dataPointInfo.setValues((XYChart.Data)paramData, paramX, paramY, paramDouble1, paramDouble2, PartOf.CURRENT, true, false);
/* 713 */     paramArrayList.add(dataPointInfo);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addPoint(ArrayList<DataPointInfo<X, Y>> paramArrayList, XYChart.Data<X, Y> paramData, X paramX, Y paramY, double paramDouble1, double paramDouble2, PartOf paramPartOf, boolean paramBoolean1, boolean paramBoolean2) {
/* 718 */     DataPointInfo<Object, Object> dataPointInfo = new DataPointInfo<>();
/* 719 */     dataPointInfo.setValues((XYChart.Data)paramData, paramX, paramY, paramDouble1, paramDouble2, paramPartOf, paramBoolean1, paramBoolean2);
/* 720 */     paramArrayList.add(dataPointInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int findNextCurrent(ArrayList<DataPointInfo<X, Y>> paramArrayList, int paramInt) {
/* 726 */     for (int i = paramInt + 1; i < paramArrayList.size(); i++) {
/* 727 */       if (((DataPointInfo)paramArrayList.get(i)).partOf.equals(PartOf.CURRENT)) {
/* 728 */         return i;
/*     */       }
/*     */     } 
/* 731 */     return -1;
/*     */   }
/*     */   
/*     */   private int findPreviousCurrent(ArrayList<DataPointInfo<X, Y>> paramArrayList, int paramInt) {
/* 735 */     for (int i = paramInt - 1; i >= 0; i--) {
/* 736 */       if (((DataPointInfo)paramArrayList.get(i)).partOf.equals(PartOf.CURRENT)) {
/* 737 */         return i;
/*     */       }
/*     */     } 
/* 740 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private int findPreviousPrevious(ArrayList<DataPointInfo<X, Y>> paramArrayList, int paramInt) {
/* 745 */     for (int i = paramInt - 1; i >= 0; i--) {
/* 746 */       if (((DataPointInfo)paramArrayList.get(i)).partOf.equals(PartOf.PREVIOUS)) {
/* 747 */         return i;
/*     */       }
/*     */     } 
/* 750 */     return -1;
/*     */   }
/*     */   private int findNextPrevious(ArrayList<DataPointInfo<X, Y>> paramArrayList, int paramInt) {
/* 753 */     for (int i = paramInt + 1; i < paramArrayList.size(); i++) {
/* 754 */       if (((DataPointInfo)paramArrayList.get(i)).partOf.equals(PartOf.PREVIOUS)) {
/* 755 */         return i;
/*     */       }
/*     */     } 
/* 758 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private void sortAggregateList(ArrayList<DataPointInfo<X, Y>> paramArrayList) {
/* 763 */     Collections.sort(paramArrayList, (paramDataPointInfo1, paramDataPointInfo2) -> {
/*     */           XYChart.Data data1 = paramDataPointInfo1.dataItem;
/*     */           XYChart.Data data2 = paramDataPointInfo2.dataItem;
/*     */           double d1 = getXAxis().toNumericValue((X)data1.getXValue());
/*     */           double d2 = getXAxis().toNumericValue((X)data2.getXValue());
/*     */           return (d1 < d2) ? -1 : ((d1 == d2) ? 0 : 1);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private double interpolate(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 774 */     return (paramDouble4 - paramDouble2) / (paramDouble3 - paramDouble1) * (paramDouble5 - paramDouble1) + paramDouble2;
/*     */   }
/*     */   
/*     */   private Node createSymbol(XYChart.Series<X, Y> paramSeries, int paramInt1, XYChart.Data<X, Y> paramData, int paramInt2) {
/* 778 */     Node node = paramData.getNode();
/*     */     
/* 780 */     if (node == null && getCreateSymbols()) {
/* 781 */       node = new StackPane();
/* 782 */       node.setAccessibleRole(AccessibleRole.TEXT);
/* 783 */       node.setAccessibleRoleDescription("Point");
/* 784 */       node.focusTraversableProperty().bind(Platform.accessibilityActiveProperty());
/* 785 */       paramData.setNode(node);
/*     */     } 
/*     */ 
/*     */     
/* 789 */     if (node != null) node.getStyleClass().setAll(new String[] { "chart-area-symbol", "series" + paramInt1, "data" + paramInt2, paramSeries.defaultColorStyleClass });
/*     */     
/* 791 */     return node;
/*     */   }
/*     */ 
/*     */   
/*     */   Legend.LegendItem createLegendItemForSeries(XYChart.Series<X, Y> paramSeries, int paramInt) {
/* 796 */     Legend.LegendItem legendItem = new Legend.LegendItem(paramSeries.getName());
/* 797 */     legendItem.getSymbol().getStyleClass().addAll(new String[] { "chart-area-symbol", "series" + paramInt, "area-legend-symbol", paramSeries.defaultColorStyleClass });
/*     */     
/* 799 */     return legendItem;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class DataPointInfo<X, Y>
/*     */   {
/*     */     X x;
/*     */     
/*     */     Y y;
/*     */     
/*     */     double displayX;
/*     */     
/*     */     double displayY;
/*     */     
/*     */     XYChart.Data<X, Y> dataItem;
/*     */     StackedAreaChart.PartOf partOf;
/*     */     boolean skipSymbol = false;
/*     */     boolean lineTo = false;
/*     */     boolean dropDown = false;
/*     */     
/*     */     DataPointInfo() {}
/*     */     
/*     */     DataPointInfo(XYChart.Data<X, Y> param1Data, X param1X, Y param1Y, StackedAreaChart.PartOf param1PartOf) {
/* 822 */       this.dataItem = param1Data;
/* 823 */       this.x = param1X;
/* 824 */       this.y = param1Y;
/* 825 */       this.partOf = param1PartOf;
/*     */     }
/*     */     
/*     */     DataPointInfo(boolean param1Boolean) {
/* 829 */       this.dropDown = param1Boolean;
/*     */     }
/*     */ 
/*     */     
/*     */     void setValues(XYChart.Data<X, Y> param1Data, X param1X, Y param1Y, double param1Double1, double param1Double2, StackedAreaChart.PartOf param1PartOf, boolean param1Boolean1, boolean param1Boolean2) {
/* 834 */       this.dataItem = param1Data;
/* 835 */       this.x = param1X;
/* 836 */       this.y = param1Y;
/* 837 */       this.displayX = param1Double1;
/* 838 */       this.displayY = param1Double2;
/* 839 */       this.partOf = param1PartOf;
/* 840 */       this.skipSymbol = param1Boolean1;
/* 841 */       this.lineTo = param1Boolean2;
/*     */     }
/*     */     
/*     */     public final X getX() {
/* 845 */       return this.x;
/*     */     }
/*     */     
/*     */     public final Y getY() {
/* 849 */       return this.y;
/*     */     }
/*     */   }
/*     */   
/*     */   private enum PartOf
/*     */   {
/* 855 */     CURRENT,
/* 856 */     PREVIOUS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 863 */     private static final CssMetaData<StackedAreaChart<?, ?>, Boolean> CREATE_SYMBOLS = new CssMetaData<StackedAreaChart<?, ?>, Boolean>("-fx-create-symbols", 
/*     */         
/* 865 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(StackedAreaChart<?, ?> param2StackedAreaChart) {
/* 868 */           return (param2StackedAreaChart.createSymbols == null || !param2StackedAreaChart.createSymbols.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(StackedAreaChart<?, ?> param2StackedAreaChart) {
/* 873 */           return (StyleableProperty<Boolean>)param2StackedAreaChart.createSymbolsProperty();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 881 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(XYChart.getClassCssMetaData());
/* 882 */       arrayList.add(CREATE_SYMBOLS);
/* 883 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 894 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 903 */     return getClassCssMetaData();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\StackedAreaChart.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */