/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import com.sun.javafx.charts.ChartLayoutAnimator;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.KeyValue;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyDoubleProperty;
/*     */ import javafx.beans.property.ReadOnlyDoubleWrapper;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.geometry.Dimension2D;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CategoryAxis
/*     */   extends Axis<String>
/*     */ {
/*  70 */   private List<String> allDataCategories = new ArrayList<>();
/*     */   
/*     */   private boolean changeIsLocal = false;
/*  73 */   private final DoubleProperty firstCategoryPos = new SimpleDoubleProperty(this, "firstCategoryPos", 0.0D);
/*     */   private Object currentAnimationID;
/*  75 */   private final ChartLayoutAnimator animator = new ChartLayoutAnimator(this);
/*  76 */   private ListChangeListener<String> itemsListener; private DoubleProperty startMargin; private DoubleProperty endMargin; private BooleanProperty gapStartAndEnd; private ObjectProperty<ObservableList<String>> categories; private final ReadOnlyDoubleWrapper categorySpacing; public CategoryAxis() { this.itemsListener = (paramChange -> {
/*     */         while (paramChange.next()) {
/*     */           if (!paramChange.getAddedSubList().isEmpty()) {
/*     */             for (String str : paramChange.getAddedSubList()) {
/*     */               checkAndRemoveDuplicates(str);
/*     */             }
/*     */           }
/*     */           
/*     */           if (!isAutoRanging()) {
/*     */             this.allDataCategories.clear();
/*     */             
/*     */             this.allDataCategories.addAll(getCategories());
/*     */             
/*     */             this.rangeValid = false;
/*     */           } 
/*     */           
/*     */           requestAxisLayout();
/*     */         } 
/*     */       });
/*     */     
/*  96 */     this.startMargin = new StyleableDoubleProperty(5.0D) {
/*     */         protected void invalidated() {
/*  98 */           CategoryAxis.this.requestAxisLayout();
/*     */         }
/*     */         
/*     */         public CssMetaData<CategoryAxis, Number> getCssMetaData() {
/* 102 */           return CategoryAxis.StyleableProperties.START_MARGIN;
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 107 */           return CategoryAxis.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 112 */           return "startMargin";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     this.endMargin = new StyleableDoubleProperty(5.0D) {
/*     */         protected void invalidated() {
/* 122 */           CategoryAxis.this.requestAxisLayout();
/*     */         }
/*     */ 
/*     */         
/*     */         public CssMetaData<CategoryAxis, Number> getCssMetaData() {
/* 127 */           return CategoryAxis.StyleableProperties.END_MARGIN;
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 132 */           return CategoryAxis.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 137 */           return "endMargin";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     this.gapStartAndEnd = new StyleableBooleanProperty(true) {
/*     */         protected void invalidated() {
/* 149 */           CategoryAxis.this.requestAxisLayout();
/*     */         }
/*     */ 
/*     */         
/*     */         public CssMetaData<CategoryAxis, Boolean> getCssMetaData() {
/* 154 */           return CategoryAxis.StyleableProperties.GAP_START_AND_END;
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 159 */           return CategoryAxis.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 164 */           return "gapStartAndEnd";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     this.categories = new ObjectPropertyBase<ObservableList<String>>() { ObservableList<String> old;
/*     */         
/*     */         protected void invalidated() {
/* 174 */           if (CategoryAxis.this.getDuplicate() != null) {
/* 175 */             throw new IllegalArgumentException("Duplicate category added; " + CategoryAxis.this.getDuplicate() + " already present");
/*     */           }
/* 177 */           ObservableList<String> observableList = get();
/* 178 */           if (this.old != observableList) {
/*     */             
/* 180 */             if (this.old != null) this.old.removeListener(CategoryAxis.this.itemsListener); 
/* 181 */             if (observableList != null) observableList.addListener(CategoryAxis.this.itemsListener); 
/* 182 */             this.old = observableList;
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 188 */           return CategoryAxis.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 193 */           return "categories";
/*     */         } }
/*     */       ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     this.categorySpacing = new ReadOnlyDoubleWrapper(this, "categorySpacing", 1.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 257 */     this.changeIsLocal = true;
/* 258 */     setCategories(FXCollections.observableArrayList());
/* 259 */     this.changeIsLocal = false; }
/*     */   public CategoryAxis(ObservableList<String> paramObservableList) { this.itemsListener = (paramChange -> { while (paramChange.next()) { if (!paramChange.getAddedSubList().isEmpty()) for (String str : paramChange.getAddedSubList()) checkAndRemoveDuplicates(str);   if (!isAutoRanging()) { this.allDataCategories.clear(); this.allDataCategories.addAll(getCategories()); this.rangeValid = false; }  requestAxisLayout(); }  }); this.startMargin = new StyleableDoubleProperty(5.0D) {
/*     */         protected void invalidated() { CategoryAxis.this.requestAxisLayout(); } public CssMetaData<CategoryAxis, Number> getCssMetaData() { return CategoryAxis.StyleableProperties.START_MARGIN; } public Object getBean() { return CategoryAxis.this; } public String getName() { return "startMargin"; }
/*     */       }; this.endMargin = new StyleableDoubleProperty(5.0D) {
/*     */         protected void invalidated() { CategoryAxis.this.requestAxisLayout(); } public CssMetaData<CategoryAxis, Number> getCssMetaData() { return CategoryAxis.StyleableProperties.END_MARGIN; } public Object getBean() { return CategoryAxis.this; } public String getName() { return "endMargin"; }
/*     */       }; this.gapStartAndEnd = new StyleableBooleanProperty(true) {
/*     */         protected void invalidated() { CategoryAxis.this.requestAxisLayout(); } public CssMetaData<CategoryAxis, Boolean> getCssMetaData() { return CategoryAxis.StyleableProperties.GAP_START_AND_END; } public Object getBean() { return CategoryAxis.this; } public String getName() { return "gapStartAndEnd"; }
/*     */       }; this.categories = new ObjectPropertyBase<ObservableList<String>>() {
/*     */         ObservableList<String> old; protected void invalidated() { if (CategoryAxis.this.getDuplicate() != null) throw new IllegalArgumentException("Duplicate category added; " + CategoryAxis.this.getDuplicate() + " already present");  ObservableList<String> observableList = get(); if (this.old != observableList) { if (this.old != null) this.old.removeListener(CategoryAxis.this.itemsListener);  if (observableList != null) observableList.addListener(CategoryAxis.this.itemsListener);  this.old = observableList; }  } public Object getBean() { return CategoryAxis.this; } public String getName() { return "categories"; }
/* 268 */       }; this.categorySpacing = new ReadOnlyDoubleWrapper(this, "categorySpacing", 1.0D); setCategories(paramObservableList); }
/*     */   public final double getStartMargin() { return this.startMargin.getValue().doubleValue(); }
/*     */   public final void setStartMargin(double paramDouble) { this.startMargin.setValue(Double.valueOf(paramDouble)); }
/*     */   public final DoubleProperty startMarginProperty() { return this.startMargin; }
/*     */   public final double getEndMargin() { return this.endMargin.getValue().doubleValue(); }
/*     */   public final void setEndMargin(double paramDouble) { this.endMargin.setValue(Double.valueOf(paramDouble)); }
/* 274 */   public final DoubleProperty endMarginProperty() { return this.endMargin; } public final boolean isGapStartAndEnd() { return this.gapStartAndEnd.getValue().booleanValue(); } public final void setGapStartAndEnd(boolean paramBoolean) { this.gapStartAndEnd.setValue(Boolean.valueOf(paramBoolean)); } public final BooleanProperty gapStartAndEndProperty() { return this.gapStartAndEnd; } public final void setCategories(ObservableList<String> paramObservableList) { this.categories.set(paramObservableList); if (!this.changeIsLocal) { setAutoRanging(false); this.allDataCategories.clear(); this.allDataCategories.addAll(getCategories()); }  requestAxisLayout(); } private void checkAndRemoveDuplicates(String paramString) { if (getDuplicate() != null) { getCategories().remove(paramString); throw new IllegalArgumentException("Duplicate category ; " + paramString + " already present"); }  } private String getDuplicate() { if (getCategories() != null) for (byte b = 0; b < getCategories().size(); b++) { for (byte b1 = 0; b1 < getCategories().size(); b1++) { if (((String)getCategories().get(b)).equals(getCategories().get(b1)) && b != b1) return getCategories().get(b);  }  }   return null; } public final ObservableList<String> getCategories() { return this.categories.get(); } public final double getCategorySpacing() { return this.categorySpacing.get(); } public final ReadOnlyDoubleProperty categorySpacingProperty() { return this.categorySpacing.getReadOnlyProperty(); } private double calculateNewSpacing(double paramDouble, List<String> paramList) { Side side = getEffectiveSide();
/* 275 */     double d = 1.0D;
/* 276 */     if (paramList != null) {
/* 277 */       double d1 = (isGapStartAndEnd() ? paramList.size() : (paramList.size() - 1));
/*     */       
/* 279 */       d = (d1 == 0.0D) ? 1.0D : ((paramDouble - getStartMargin() - getEndMargin()) / d1);
/*     */     } 
/*     */     
/* 282 */     if (!isAutoRanging()) this.categorySpacing.set(d); 
/* 283 */     return d; }
/*     */ 
/*     */   
/*     */   private double calculateNewFirstPos(double paramDouble1, double paramDouble2) {
/* 287 */     Side side = getEffectiveSide();
/* 288 */     double d1 = 1.0D;
/* 289 */     double d2 = isGapStartAndEnd() ? (paramDouble2 / 2.0D) : 0.0D;
/* 290 */     if (side.isHorizontal()) {
/* 291 */       d1 = 0.0D + getStartMargin() + d2;
/*     */     } else {
/* 293 */       d1 = paramDouble1 - getStartMargin() - d2;
/*     */     } 
/*     */     
/* 296 */     if (!isAutoRanging()) this.firstCategoryPos.set(d1); 
/* 297 */     return d1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getRange() {
/* 308 */     return new Object[] { getCategories(), Double.valueOf(this.categorySpacing.get()), Double.valueOf(this.firstCategoryPos.get()), Double.valueOf(getEffectiveTickLabelRotation()) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRange(Object paramObject, boolean paramBoolean) {
/* 319 */     Object[] arrayOfObject = (Object[])paramObject;
/* 320 */     List<? extends String> list = (List)arrayOfObject[0];
/*     */     
/* 322 */     double d1 = ((Double)arrayOfObject[1]).doubleValue();
/* 323 */     double d2 = ((Double)arrayOfObject[2]).doubleValue();
/* 324 */     setEffectiveTickLabelRotation(((Double)arrayOfObject[3]).doubleValue());
/*     */     
/* 326 */     this.changeIsLocal = true;
/* 327 */     setCategories(FXCollections.observableArrayList(list));
/* 328 */     this.changeIsLocal = false;
/* 329 */     if (paramBoolean) {
/* 330 */       this.animator.stop(this.currentAnimationID);
/* 331 */       this.currentAnimationID = this.animator.animate(new KeyFrame[] { new KeyFrame(Duration.ZERO, new KeyValue[] { new KeyValue(this.firstCategoryPos, 
/*     */                   
/* 333 */                   (T)Double.valueOf(this.firstCategoryPos.get())), new KeyValue(this.categorySpacing, 
/* 334 */                   (T)Double.valueOf(this.categorySpacing.get())) }), new KeyFrame(
/*     */               
/* 336 */               Duration.millis(1000.0D), new KeyValue[] { new KeyValue(this.firstCategoryPos, 
/* 337 */                   (T)Double.valueOf(d2)), new KeyValue(this.categorySpacing, 
/* 338 */                   (T)Double.valueOf(d1)) }) });
/*     */     }
/*     */     else {
/*     */       
/* 342 */       this.categorySpacing.set(d1);
/* 343 */       this.firstCategoryPos.set(d2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object autoRange(double paramDouble) {
/* 357 */     Side side = getEffectiveSide();
/*     */     
/* 359 */     double d1 = calculateNewSpacing(paramDouble, this.allDataCategories);
/* 360 */     double d2 = calculateNewFirstPos(paramDouble, d1);
/* 361 */     double d3 = getTickLabelRotation();
/* 362 */     if (paramDouble >= 0.0D) {
/* 363 */       double d = calculateRequiredSize(side.isVertical(), d3);
/* 364 */       if (d > paramDouble) {
/*     */         
/* 366 */         if (side.isHorizontal() && d3 != 90.0D) {
/* 367 */           d3 = 90.0D;
/*     */         }
/* 369 */         if (side.isVertical() && d3 != 0.0D) {
/* 370 */           d3 = 0.0D;
/*     */         }
/*     */       } 
/*     */     } 
/* 374 */     return new Object[] { this.allDataCategories, Double.valueOf(d1), Double.valueOf(d2), Double.valueOf(d3) };
/*     */   }
/*     */ 
/*     */   
/*     */   private double calculateRequiredSize(boolean paramBoolean, double paramDouble) {
/* 379 */     double d1 = 0.0D;
/* 380 */     double d2 = 0.0D;
/* 381 */     boolean bool = true;
/* 382 */     for (String str : this.allDataCategories) {
/* 383 */       Dimension2D dimension2D = measureTickMarkSize(str, paramDouble);
/* 384 */       double d = (paramBoolean || paramDouble != 0.0D) ? dimension2D.getHeight() : dimension2D.getWidth();
/*     */       
/* 386 */       if (bool) {
/* 387 */         bool = false;
/* 388 */         d2 = d / 2.0D; continue;
/*     */       } 
/* 390 */       d1 = Math.max(d1, d2 + 6.0D + d / 2.0D);
/*     */     } 
/*     */     
/* 393 */     return getStartMargin() + d1 * this.allDataCategories.size() + getEndMargin();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<String> calculateTickValues(double paramDouble, Object paramObject) {
/* 403 */     Object[] arrayOfObject = (Object[])paramObject;
/*     */     
/* 405 */     return (List<String>)arrayOfObject[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getTickMarkLabel(String paramString) {
/* 416 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Dimension2D measureTickMarkSize(String paramString, Object paramObject) {
/* 427 */     Object[] arrayOfObject = (Object[])paramObject;
/* 428 */     double d = ((Double)arrayOfObject[3]).doubleValue();
/* 429 */     return measureTickMarkSize(paramString, d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invalidateRange(List<String> paramList) {
/* 442 */     super.invalidateRange(paramList);
/*     */     
/* 444 */     ArrayList<String> arrayList = new ArrayList();
/* 445 */     arrayList.addAll(this.allDataCategories);
/*     */ 
/*     */ 
/*     */     
/* 449 */     for (String str : this.allDataCategories) {
/* 450 */       if (!paramList.contains(str)) arrayList.remove(str);
/*     */     
/*     */     } 
/*     */     
/* 454 */     for (byte b = 0; b < paramList.size(); b++) {
/* 455 */       int i = arrayList.size();
/* 456 */       if (!arrayList.contains(paramList.get(b))) arrayList.add((b > i) ? i : b, paramList.get(b)); 
/*     */     } 
/* 458 */     this.allDataCategories.clear();
/* 459 */     this.allDataCategories.addAll(arrayList);
/*     */   }
/*     */   
/*     */   final List<String> getAllDataCategories() {
/* 463 */     return this.allDataCategories;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDisplayPosition(String paramString) {
/* 476 */     ObservableList<String> observableList = getCategories();
/* 477 */     if (!observableList.contains(paramString)) {
/* 478 */       return Double.NaN;
/*     */     }
/* 480 */     if (getEffectiveSide().isHorizontal()) {
/* 481 */       return this.firstCategoryPos.get() + observableList.indexOf(paramString) * this.categorySpacing.get();
/*     */     }
/* 483 */     return this.firstCategoryPos.get() + observableList.indexOf(paramString) * this.categorySpacing.get() * -1.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValueForDisplay(double paramDouble) {
/* 496 */     if (getEffectiveSide().isHorizontal()) {
/* 497 */       if (paramDouble < 0.0D || paramDouble > getWidth()) return null; 
/* 498 */       double d1 = (paramDouble - this.firstCategoryPos.get()) / this.categorySpacing.get();
/* 499 */       return toRealValue(d1);
/*     */     } 
/* 501 */     if (paramDouble < 0.0D || paramDouble > getHeight()) return null; 
/* 502 */     double d = (paramDouble - this.firstCategoryPos.get()) / this.categorySpacing.get() * -1.0D;
/* 503 */     return toRealValue(d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueOnAxis(String paramString) {
/* 514 */     return (getCategories().indexOf(paramString) != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double toNumericValue(String paramString) {
/* 524 */     return getCategories().indexOf(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toRealValue(double paramDouble) {
/* 534 */     int i = (int)Math.round(paramDouble);
/* 535 */     ObservableList<String> observableList = getCategories();
/* 536 */     if (i >= 0 && i < observableList.size()) {
/* 537 */       return getCategories().get(i);
/*     */     }
/* 539 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getZeroPosition() {
/* 550 */     return Double.NaN;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 556 */     private static final CssMetaData<CategoryAxis, Number> START_MARGIN = new CssMetaData<CategoryAxis, Number>("-fx-start-margin", 
/*     */         
/* 558 */         SizeConverter.getInstance(), Double.valueOf(5.0D))
/*     */       {
/*     */         public boolean isSettable(CategoryAxis param2CategoryAxis)
/*     */         {
/* 562 */           return (param2CategoryAxis.startMargin == null || !param2CategoryAxis.startMargin.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(CategoryAxis param2CategoryAxis) {
/* 567 */           return (StyleableProperty<Number>)param2CategoryAxis.startMarginProperty();
/*     */         }
/*     */       };
/*     */     
/* 571 */     private static final CssMetaData<CategoryAxis, Number> END_MARGIN = new CssMetaData<CategoryAxis, Number>("-fx-end-margin", 
/*     */         
/* 573 */         SizeConverter.getInstance(), Double.valueOf(5.0D))
/*     */       {
/*     */         public boolean isSettable(CategoryAxis param2CategoryAxis)
/*     */         {
/* 577 */           return (param2CategoryAxis.endMargin == null || !param2CategoryAxis.endMargin.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(CategoryAxis param2CategoryAxis) {
/* 582 */           return (StyleableProperty<Number>)param2CategoryAxis.endMarginProperty();
/*     */         }
/*     */       };
/*     */     
/* 586 */     private static final CssMetaData<CategoryAxis, Boolean> GAP_START_AND_END = new CssMetaData<CategoryAxis, Boolean>("-fx-gap-start-and-end", 
/*     */         
/* 588 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(CategoryAxis param2CategoryAxis)
/*     */         {
/* 592 */           return (param2CategoryAxis.gapStartAndEnd == null || !param2CategoryAxis.gapStartAndEnd.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(CategoryAxis param2CategoryAxis) {
/* 597 */           return (StyleableProperty<Boolean>)param2CategoryAxis.gapStartAndEndProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 604 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Axis.getClassCssMetaData());
/* 605 */       arrayList.add(START_MARGIN);
/* 606 */       arrayList.add(END_MARGIN);
/* 607 */       arrayList.add(GAP_START_AND_END);
/* 608 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 618 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 627 */     return getClassCssMetaData();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\CategoryAxis.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */