/*     */ package javafx.scene.chart;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.DoublePropertyBase;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyDoubleProperty;
/*     */ import javafx.beans.property.ReadOnlyDoubleWrapper;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableIntegerProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.scene.shape.LineTo;
/*     */ import javafx.scene.shape.MoveTo;
/*     */ import javafx.scene.shape.Path;
/*     */ import javafx.scene.shape.PathElement;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ValueAxis<T extends Number>
/*     */   extends Axis<T>
/*     */ {
/*  60 */   private final Path minorTickPath = new Path();
/*     */ 
/*     */   
/*     */   private double offset;
/*     */ 
/*     */   
/*     */   double dataMinValue;
/*     */   
/*     */   double dataMaxValue;
/*     */   
/*  70 */   private List<T> minorTickMarkValues = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean minorTickMarksDirty = true;
/*     */ 
/*     */ 
/*     */   
/*  79 */   protected final DoubleProperty currentLowerBound = new SimpleDoubleProperty(this, "currentLowerBound");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private BooleanProperty minorTickVisible = new StyleableBooleanProperty(true) {
/*     */       protected void invalidated() {
/*  86 */         ValueAxis.this.minorTickPath.setVisible(get());
/*  87 */         ValueAxis.this.requestAxisLayout();
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/*  92 */         return ValueAxis.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/*  97 */         return "minorTickVisible";
/*     */       }
/*     */ 
/*     */       
/*     */       public CssMetaData<ValueAxis<? extends Number>, Boolean> getCssMetaData() {
/* 102 */         return ValueAxis.StyleableProperties.MINOR_TICK_VISIBLE;
/*     */       }
/*     */     };
/* 105 */   public final boolean isMinorTickVisible() { return this.minorTickVisible.get(); }
/* 106 */   public final void setMinorTickVisible(boolean paramBoolean) { this.minorTickVisible.set(paramBoolean); } public final BooleanProperty minorTickVisibleProperty() {
/* 107 */     return this.minorTickVisible;
/*     */   }
/*     */ 
/*     */   
/* 111 */   private ReadOnlyDoubleWrapper scale = new ReadOnlyDoubleWrapper(this, "scale", 0.0D)
/*     */     {
/*     */       protected void invalidated() {
/* 114 */         ValueAxis.this.requestAxisLayout();
/* 115 */         ValueAxis.this.measureInvalid = true;
/*     */       }
/*     */     };
/* 118 */   public final double getScale() { return this.scale.get(); }
/* 119 */   protected final void setScale(double paramDouble) { this.scale.set(paramDouble); }
/* 120 */   public final ReadOnlyDoubleProperty scaleProperty() { return this.scale.getReadOnlyProperty(); } ReadOnlyDoubleWrapper scalePropertyImpl() {
/* 121 */     return this.scale;
/*     */   }
/*     */   
/* 124 */   private DoubleProperty upperBound = new DoublePropertyBase(100.0D) {
/*     */       protected void invalidated() {
/* 126 */         if (!ValueAxis.this.isAutoRanging()) {
/* 127 */           ValueAxis.this.invalidateRange();
/* 128 */           ValueAxis.this.requestAxisLayout();
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 134 */         return ValueAxis.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 139 */         return "upperBound";
/*     */       }
/*     */     };
/* 142 */   public final double getUpperBound() { return this.upperBound.get(); }
/* 143 */   public final void setUpperBound(double paramDouble) { this.upperBound.set(paramDouble); } public final DoubleProperty upperBoundProperty() {
/* 144 */     return this.upperBound;
/*     */   }
/*     */   
/* 147 */   private DoubleProperty lowerBound = new DoublePropertyBase(0.0D) {
/*     */       protected void invalidated() {
/* 149 */         if (!ValueAxis.this.isAutoRanging()) {
/* 150 */           ValueAxis.this.invalidateRange();
/* 151 */           ValueAxis.this.requestAxisLayout();
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 157 */         return ValueAxis.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 162 */         return "lowerBound";
/*     */       }
/*     */     };
/* 165 */   public final double getLowerBound() { return this.lowerBound.get(); }
/* 166 */   public final void setLowerBound(double paramDouble) { this.lowerBound.set(paramDouble); } public final DoubleProperty lowerBoundProperty() {
/* 167 */     return this.lowerBound;
/*     */   }
/*     */   
/* 170 */   private final ObjectProperty<StringConverter<T>> tickLabelFormatter = (ObjectProperty)new ObjectPropertyBase<StringConverter<StringConverter<T>>>(null) {
/*     */       protected void invalidated() {
/* 172 */         ValueAxis.this.invalidateRange();
/* 173 */         ValueAxis.this.requestAxisLayout();
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 178 */         return ValueAxis.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 183 */         return "tickLabelFormatter";
/*     */       }
/*     */     };
/* 186 */   public final StringConverter<T> getTickLabelFormatter() { return this.tickLabelFormatter.getValue(); }
/* 187 */   public final void setTickLabelFormatter(StringConverter<T> paramStringConverter) { this.tickLabelFormatter.setValue(paramStringConverter); } public final ObjectProperty<StringConverter<T>> tickLabelFormatterProperty() {
/* 188 */     return this.tickLabelFormatter;
/*     */   }
/*     */   
/* 191 */   private DoubleProperty minorTickLength = new StyleableDoubleProperty(5.0D) {
/*     */       protected void invalidated() {
/* 193 */         ValueAxis.this.requestAxisLayout();
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 198 */         return ValueAxis.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 203 */         return "minorTickLength";
/*     */       }
/*     */ 
/*     */       
/*     */       public CssMetaData<ValueAxis<? extends Number>, Number> getCssMetaData() {
/* 208 */         return ValueAxis.StyleableProperties.MINOR_TICK_LENGTH;
/*     */       }
/*     */     };
/* 211 */   public final double getMinorTickLength() { return this.minorTickLength.get(); }
/* 212 */   public final void setMinorTickLength(double paramDouble) { this.minorTickLength.set(paramDouble); } public final DoubleProperty minorTickLengthProperty() {
/* 213 */     return this.minorTickLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   private IntegerProperty minorTickCount = new StyleableIntegerProperty(5) {
/*     */       protected void invalidated() {
/* 221 */         ValueAxis.this.invalidateRange();
/* 222 */         ValueAxis.this.requestAxisLayout();
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 227 */         return ValueAxis.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 232 */         return "minorTickCount";
/*     */       }
/*     */ 
/*     */       
/*     */       public CssMetaData<ValueAxis<? extends Number>, Number> getCssMetaData() {
/* 237 */         return ValueAxis.StyleableProperties.MINOR_TICK_COUNT;
/*     */       }
/*     */     };
/* 240 */   public final int getMinorTickCount() { return this.minorTickCount.get(); }
/* 241 */   public final void setMinorTickCount(int paramInt) { this.minorTickCount.set(paramInt); } public final IntegerProperty minorTickCountProperty() {
/* 242 */     return this.minorTickCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueAxis() {
/* 250 */     this.minorTickPath.getStyleClass().add("axis-minor-tick-mark");
/* 251 */     getChildren().add(this.minorTickPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueAxis(double paramDouble1, double paramDouble2) {
/* 261 */     this();
/* 262 */     setAutoRanging(false);
/* 263 */     setLowerBound(paramDouble1);
/* 264 */     setUpperBound(paramDouble2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object autoRange(double paramDouble) {
/* 281 */     if (isAutoRanging()) {
/*     */       
/* 283 */       double d = getTickLabelFont().getSize() * 2.0D;
/* 284 */       return autoRange(this.dataMinValue, this.dataMaxValue, paramDouble, d);
/*     */     } 
/* 286 */     return getRange();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final double calculateNewScale(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 299 */     double d = 1.0D;
/* 300 */     Side side = getEffectiveSide();
/* 301 */     if (side.isVertical()) {
/* 302 */       this.offset = paramDouble1;
/* 303 */       d = (paramDouble3 - paramDouble2 == 0.0D) ? -paramDouble1 : -(paramDouble1 / (paramDouble3 - paramDouble2));
/*     */     } else {
/* 305 */       this.offset = 0.0D;
/* 306 */       d = (paramDouble3 - paramDouble2 == 0.0D) ? paramDouble1 : (paramDouble1 / (paramDouble3 - paramDouble2));
/*     */     } 
/* 308 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object autoRange(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 323 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void tickMarksUpdated() {
/* 340 */     super.tickMarksUpdated();
/*     */     
/* 342 */     this.minorTickMarkValues = calculateMinorTickMarks();
/* 343 */     this.minorTickMarksDirty = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren() {
/* 350 */     Side side = getEffectiveSide();
/* 351 */     double d = side.isVertical() ? getHeight() : getWidth();
/*     */     
/* 353 */     if (!isAutoRanging()) {
/*     */       
/* 355 */       setScale(calculateNewScale(d, getLowerBound(), getUpperBound()));
/*     */       
/* 357 */       this.currentLowerBound.set(getLowerBound());
/*     */     } 
/*     */     
/* 360 */     super.layoutChildren();
/*     */     
/* 362 */     if (this.minorTickMarksDirty) {
/* 363 */       this.minorTickMarksDirty = false;
/* 364 */       updateMinorTickPath(side, d);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateMinorTickPath(Side paramSide, double paramDouble) {
/* 369 */     int i = (getTickMarks().size() - 1) * (Math.max(1, getMinorTickCount()) - 1);
/* 370 */     double d1 = ((getTickMarks().size() + i) * 2);
/*     */ 
/*     */     
/* 373 */     this.minorTickPath.getElements().clear();
/*     */ 
/*     */     
/* 376 */     double d2 = Math.max(0.0D, getMinorTickLength());
/* 377 */     if (d2 > 0.0D && paramDouble > d1) {
/* 378 */       if (Side.LEFT.equals(paramSide)) {
/*     */         
/* 380 */         this.minorTickPath.setLayoutX(-0.5D);
/* 381 */         this.minorTickPath.setLayoutY(0.5D);
/* 382 */         for (Number number : this.minorTickMarkValues) {
/* 383 */           double d = getDisplayPosition((T)number);
/* 384 */           if (d >= 0.0D && d <= paramDouble) {
/* 385 */             this.minorTickPath.getElements().addAll(new PathElement[] { new MoveTo(
/* 386 */                     getWidth() - d2, d), new LineTo(
/* 387 */                     getWidth() - 1.0D, d) });
/*     */           }
/*     */         } 
/* 390 */       } else if (Side.RIGHT.equals(paramSide)) {
/*     */         
/* 392 */         this.minorTickPath.setLayoutX(0.5D);
/* 393 */         this.minorTickPath.setLayoutY(0.5D);
/* 394 */         for (Number number : this.minorTickMarkValues) {
/* 395 */           double d = getDisplayPosition((T)number);
/* 396 */           if (d >= 0.0D && d <= paramDouble) {
/* 397 */             this.minorTickPath.getElements().addAll(new PathElement[] { new MoveTo(1.0D, d), new LineTo(d2, d) });
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 402 */       else if (Side.TOP.equals(paramSide)) {
/*     */         
/* 404 */         this.minorTickPath.setLayoutX(0.5D);
/* 405 */         this.minorTickPath.setLayoutY(-0.5D);
/* 406 */         for (Number number : this.minorTickMarkValues) {
/* 407 */           double d = getDisplayPosition((T)number);
/* 408 */           if (d >= 0.0D && d <= paramDouble) {
/* 409 */             this.minorTickPath.getElements().addAll(new PathElement[] { new MoveTo(d, 
/* 410 */                     getHeight() - 1.0D), new LineTo(d, 
/* 411 */                     getHeight() - d2) });
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 416 */         this.minorTickPath.setLayoutX(0.5D);
/* 417 */         this.minorTickPath.setLayoutY(0.5D);
/* 418 */         for (Number number : this.minorTickMarkValues) {
/* 419 */           double d = getDisplayPosition((T)number);
/* 420 */           if (d >= 0.0D && d <= paramDouble) {
/* 421 */             this.minorTickPath.getElements().addAll(new PathElement[] { new MoveTo(d, 1.0D), new LineTo(d, d2) });
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invalidateRange(List<T> paramList) {
/* 440 */     if (paramList.isEmpty()) {
/* 441 */       this.dataMaxValue = getUpperBound();
/* 442 */       this.dataMinValue = getLowerBound();
/*     */     } else {
/* 444 */       this.dataMinValue = Double.MAX_VALUE;
/*     */ 
/*     */       
/* 447 */       this.dataMaxValue = -1.7976931348623157E308D;
/*     */     } 
/* 449 */     for (Number number : paramList) {
/* 450 */       this.dataMinValue = Math.min(this.dataMinValue, number.doubleValue());
/* 451 */       this.dataMaxValue = Math.max(this.dataMaxValue, number.doubleValue());
/*     */     } 
/* 453 */     super.invalidateRange(paramList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDisplayPosition(T paramT) {
/* 465 */     return this.offset + (paramT.doubleValue() - this.currentLowerBound.get()) * getScale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValueForDisplay(double paramDouble) {
/* 477 */     return toRealValue((paramDouble - this.offset) / getScale() + this.currentLowerBound.get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getZeroPosition() {
/* 486 */     if (0.0D < getLowerBound() || 0.0D > getUpperBound()) return Double.NaN;
/*     */     
/* 488 */     return getDisplayPosition((T)Double.valueOf(0.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueOnAxis(T paramT) {
/* 498 */     double d = paramT.doubleValue();
/* 499 */     return (d >= getLowerBound() && d <= getUpperBound());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double toNumericValue(T paramT) {
/* 509 */     return (paramT == null) ? Double.NaN : paramT.doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T toRealValue(double paramDouble) {
/* 520 */     return (T)new Double(paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 526 */     private static final CssMetaData<ValueAxis<? extends Number>, Number> MINOR_TICK_LENGTH = new CssMetaData<ValueAxis<? extends Number>, Number>("-fx-minor-tick-length", 
/*     */         
/* 528 */         SizeConverter.getInstance(), Double.valueOf(5.0D))
/*     */       {
/*     */         public boolean isSettable(ValueAxis<? extends Number> param2ValueAxis)
/*     */         {
/* 532 */           return (param2ValueAxis.minorTickLength == null || !param2ValueAxis.minorTickLength.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(ValueAxis<? extends Number> param2ValueAxis) {
/* 537 */           return (StyleableProperty<Number>)param2ValueAxis.minorTickLengthProperty();
/*     */         }
/*     */       };
/*     */     
/* 541 */     private static final CssMetaData<ValueAxis<? extends Number>, Number> MINOR_TICK_COUNT = new CssMetaData<ValueAxis<? extends Number>, Number>("-fx-minor-tick-count", 
/*     */         
/* 543 */         SizeConverter.getInstance(), Integer.valueOf(5))
/*     */       {
/*     */         public boolean isSettable(ValueAxis<? extends Number> param2ValueAxis)
/*     */         {
/* 547 */           return (param2ValueAxis.minorTickCount == null || !param2ValueAxis.minorTickCount.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(ValueAxis<? extends Number> param2ValueAxis) {
/* 552 */           return (StyleableProperty<Number>)param2ValueAxis.minorTickCountProperty();
/*     */         }
/*     */       };
/*     */     
/* 556 */     private static final CssMetaData<ValueAxis<? extends Number>, Boolean> MINOR_TICK_VISIBLE = new CssMetaData<ValueAxis<? extends Number>, Boolean>("-fx-minor-tick-visible", 
/*     */         
/* 558 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(ValueAxis<? extends Number> param2ValueAxis)
/*     */         {
/* 562 */           return (param2ValueAxis.minorTickVisible == null || !param2ValueAxis.minorTickVisible.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(ValueAxis<? extends Number> param2ValueAxis) {
/* 567 */           return (StyleableProperty<Boolean>)param2ValueAxis.minorTickVisibleProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 574 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Axis.getClassCssMetaData());
/* 575 */       arrayList.add(MINOR_TICK_COUNT);
/* 576 */       arrayList.add(MINOR_TICK_LENGTH);
/* 577 */       arrayList.add(MINOR_TICK_COUNT);
/* 578 */       arrayList.add(MINOR_TICK_VISIBLE);
/* 579 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 589 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 598 */     return getClassCssMetaData();
/*     */   }
/*     */   
/*     */   protected abstract List<T> calculateMinorTickMarks();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\chart\ValueAxis.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */