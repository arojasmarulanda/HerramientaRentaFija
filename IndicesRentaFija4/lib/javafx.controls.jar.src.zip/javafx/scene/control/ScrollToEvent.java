/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.event.EventType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrollToEvent<T>
/*     */   extends Event
/*     */ {
/*  52 */   public static final EventType<ScrollToEvent> ANY = (EventType)new EventType<>(Event.ANY, "SCROLL_TO");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EventType<ScrollToEvent<Integer>> scrollToTopIndex() {
/*  60 */     return SCROLL_TO_TOP_INDEX;
/*     */   }
/*  62 */   private static final EventType<ScrollToEvent<Integer>> SCROLL_TO_TOP_INDEX = new EventType<>((EventType)ANY, "SCROLL_TO_TOP_INDEX");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends TableColumnBase<?, ?>> EventType<ScrollToEvent<T>> scrollToColumn() {
/*  74 */     return (EventType)SCROLL_TO_COLUMN;
/*     */   }
/*  76 */   private static final EventType<?> SCROLL_TO_COLUMN = new EventType(ANY, "SCROLL_TO_COLUMN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = -8557345736849482516L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final T scrollTarget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScrollToEvent(@NamedArg("source") Object paramObject, @NamedArg("target") EventTarget paramEventTarget, @NamedArg("type") EventType<ScrollToEvent<T>> paramEventType, @NamedArg("scrollTarget") T paramT) {
/*  94 */     super(paramObject, paramEventTarget, (EventType)paramEventType);
/*  95 */     assert paramT != null;
/*  96 */     this.scrollTarget = paramT;
/*     */   }
/*     */ 
/*     */   
/*     */   public T getScrollTarget() {
/* 101 */     return this.scrollTarget;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ScrollToEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */