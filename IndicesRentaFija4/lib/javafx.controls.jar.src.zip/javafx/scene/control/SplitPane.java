/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.WeakHashMap;
/*     */ import javafx.beans.DefaultProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.EnumConverter;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.SplitPaneSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @DefaultProperty("items")
/*     */ public class SplitPane
/*     */   extends Control
/*     */ {
/*     */   private static final String RESIZABLE_WITH_PARENT = "resizable-with-parent";
/*     */   private ObjectProperty<Orientation> orientation;
/*     */   private final ObservableList<Node> items;
/*     */   private final ObservableList<Divider> dividers;
/*     */   private final ObservableList<Divider> unmodifiableDividers;
/*     */   private final WeakHashMap<Integer, Double> dividerCache;
/*     */   private static final String DEFAULT_STYLE_CLASS = "split-pane";
/*     */   
/*     */   public static void setResizableWithParent(Node paramNode, Boolean paramBoolean) {
/* 141 */     if (paramBoolean == null) {
/* 142 */       paramNode.getProperties().remove("resizable-with-parent");
/*     */     } else {
/* 144 */       paramNode.getProperties().put("resizable-with-parent", paramBoolean);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean isResizableWithParent(Node paramNode) {
/* 156 */     if (paramNode.hasProperties()) {
/* 157 */       Object object = paramNode.getProperties().get("resizable-with-parent");
/* 158 */       if (object != null) {
/* 159 */         return (Boolean)object;
/*     */       }
/*     */     } 
/* 162 */     return Boolean.valueOf(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SplitPane() {
/* 175 */     this((Node[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOrientation(Orientation paramOrientation) {
/*     */     orientationProperty().set(paramOrientation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SplitPane(Node... paramVarArgs) {
/* 309 */     this.items = FXCollections.observableArrayList();
/*     */     
/* 311 */     this.dividers = FXCollections.observableArrayList();
/* 312 */     this.unmodifiableDividers = FXCollections.unmodifiableObservableList(this.dividers);
/*     */ 
/*     */     
/* 315 */     this.dividerCache = new WeakHashMap<>(); getStyleClass().setAll(new String[] { "split-pane" }); ((StyleableProperty<Boolean>)focusTraversableProperty()).applyStyle(null, Boolean.FALSE); getItems().addListener(new ListChangeListener<Node>() { public void onChanged(ListChangeListener.Change<? extends Node> param1Change) { while (param1Change.next()) { int i = param1Change.getFrom(); int j = i; byte b1; for (b1 = 0; b1 < param1Change.getRemovedSize(); b1++) { if (j < SplitPane.this.dividers.size()) { SplitPane.this.dividerCache.put(Integer.valueOf(j), Double.valueOf(Double.MAX_VALUE)); }
/*     */                 else if (j == SplitPane.this.dividers.size() && !SplitPane.this.dividers.isEmpty()) { if (param1Change.wasReplaced()) { SplitPane.this.dividerCache.put(Integer.valueOf(j - 1), Double.valueOf(((SplitPane.Divider)SplitPane.this.dividers.get(j - 1)).getPosition())); }
/*     */                   else { SplitPane.this.dividerCache.put(Integer.valueOf(j - 1), Double.valueOf(Double.MAX_VALUE)); }
/*     */                    }
/*     */                  j++; }
/*     */                for (b1 = 0; b1 < SplitPane.this.dividers.size(); b1++) { if (SplitPane.this.dividerCache.get(Integer.valueOf(b1)) == null)
/*     */                   SplitPane.this.dividerCache.put(Integer.valueOf(b1), Double.valueOf(((SplitPane.Divider)SplitPane.this.dividers.get(b1)).getPosition()));  }
/*     */                }
/*     */              SplitPane.this.dividers.clear(); for (byte b = 0; b < SplitPane.this.getItems().size() - 1; b++) { if (SplitPane.this.dividerCache.containsKey(Integer.valueOf(b)) && ((Double)SplitPane.this.dividerCache.get(Integer.valueOf(b))).doubleValue() != Double.MAX_VALUE) {
/*     */                 SplitPane.Divider divider = new SplitPane.Divider(); divider.setPosition(((Double)SplitPane.this.dividerCache.get(Integer.valueOf(b))).doubleValue()); SplitPane.this.dividers.add(divider);
/*     */               } else {
/*     */                 SplitPane.this.dividers.add(new SplitPane.Divider());
/*     */               }  SplitPane.this.dividerCache.remove(Integer.valueOf(b)); }
/*     */              } }); if (paramVarArgs != null)
/*     */       getItems().addAll(paramVarArgs);  pseudoClassStateChanged(HORIZONTAL_PSEUDOCLASS_STATE, true);
/* 330 */   } public ObservableList<Node> getItems() { return this.items; } public final Orientation getOrientation() { return (this.orientation == null) ? Orientation.HORIZONTAL : this.orientation.get(); }
/*     */   public final ObjectProperty<Orientation> orientationProperty() { if (this.orientation == null)
/*     */       this.orientation = new StyleableObjectProperty<Orientation>(Orientation.HORIZONTAL) { public void invalidated() { boolean bool = (get() == Orientation.VERTICAL) ? true : false; SplitPane.this.pseudoClassStateChanged(SplitPane.VERTICAL_PSEUDOCLASS_STATE, bool);
/*     */             SplitPane.this.pseudoClassStateChanged(SplitPane.HORIZONTAL_PSEUDOCLASS_STATE, !bool); }
/*     */           public CssMetaData<SplitPane, Orientation> getCssMetaData() { return SplitPane.StyleableProperties.ORIENTATION; }
/*     */           public Object getBean() { return SplitPane.this; }
/*     */           public String getName() { return "orientation"; } }
/*     */         ; 
/*     */     return this.orientation; }
/* 339 */   public ObservableList<Divider> getDividers() { return this.unmodifiableDividers; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDividerPosition(int paramInt, double paramDouble) {
/* 349 */     if (getDividers().size() <= paramInt) {
/* 350 */       this.dividerCache.put(Integer.valueOf(paramInt), Double.valueOf(paramDouble));
/*     */       return;
/*     */     } 
/* 353 */     if (paramInt >= 0) {
/* 354 */       ((Divider)getDividers().get(paramInt)).setPosition(paramDouble);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDividerPositions(double... paramVarArgs) {
/* 364 */     if (this.dividers.isEmpty()) {
/* 365 */       for (byte b1 = 0; b1 < paramVarArgs.length; b1++) {
/* 366 */         this.dividerCache.put(Integer.valueOf(b1), Double.valueOf(paramVarArgs[b1]));
/*     */       }
/*     */       return;
/*     */     } 
/* 370 */     for (byte b = 0; b < paramVarArgs.length && b < this.dividers.size(); b++) {
/* 371 */       ((Divider)this.dividers.get(b)).setPosition(paramVarArgs[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getDividerPositions() {
/* 381 */     double[] arrayOfDouble = new double[this.dividers.size()];
/* 382 */     for (byte b = 0; b < this.dividers.size(); b++) {
/* 383 */       arrayOfDouble[b] = ((Divider)this.dividers.get(b)).getPosition();
/*     */     }
/* 385 */     return arrayOfDouble;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 390 */     return (Skin<?>)new SplitPaneSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 402 */     private static final CssMetaData<SplitPane, Orientation> ORIENTATION = new CssMetaData<SplitPane, Orientation>("-fx-orientation", (StyleConverter)new EnumConverter(Orientation.class), Orientation.HORIZONTAL)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Orientation getInitialValue(SplitPane param2SplitPane)
/*     */         {
/* 410 */           return param2SplitPane.getOrientation();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isSettable(SplitPane param2SplitPane) {
/* 415 */           return (param2SplitPane.orientation == null || !param2SplitPane.orientation.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Orientation> getStyleableProperty(SplitPane param2SplitPane) {
/* 420 */           return (StyleableProperty<Orientation>)param2SplitPane.orientationProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 427 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 428 */       arrayList.add(ORIENTATION);
/* 429 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 439 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 448 */     return getClassCssMetaData();
/*     */   }
/*     */   
/* 451 */   private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
/* 452 */   private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean getInitialFocusTraversable() {
/* 463 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Divider
/*     */   {
/*     */     private DoubleProperty position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setPosition(double param1Double) {
/* 501 */       positionProperty().set(param1Double);
/*     */     }
/*     */     
/*     */     public final double getPosition() {
/* 505 */       return (this.position == null) ? 0.5D : this.position.get();
/*     */     }
/*     */     
/*     */     public final DoubleProperty positionProperty() {
/* 509 */       if (this.position == null) {
/* 510 */         this.position = new SimpleDoubleProperty(this, "position", 0.5D);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 520 */       return this.position;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\SplitPane.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */