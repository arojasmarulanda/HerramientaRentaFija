/*    */ package javafx.scene.control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum OverrunStyle
/*    */ {
/* 37 */   CLIP,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   ELLIPSIS,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   WORD_ELLIPSIS,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   CENTER_ELLIPSIS,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 66 */   CENTER_WORD_ELLIPSIS,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   LEADING_ELLIPSIS,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 76 */   LEADING_WORD_ELLIPSIS;
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\OverrunStyle.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */