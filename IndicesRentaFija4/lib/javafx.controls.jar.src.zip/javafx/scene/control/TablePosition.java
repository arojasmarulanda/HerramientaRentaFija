/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TablePosition<S, T>
/*     */   extends TablePositionBase<TableColumn<S, T>>
/*     */ {
/*     */   private final WeakReference<TableView<S>> controlRef;
/*     */   private final WeakReference<S> itemRef;
/*     */   int fixedColumnIndex;
/*     */   private final int nonFixedColumnIndex;
/*     */   
/*     */   public TablePosition(@NamedArg("tableView") TableView<S> paramTableView, @NamedArg("row") int paramInt, @NamedArg("tableColumn") TableColumn<S, T> paramTableColumn) {
/*  70 */     super(paramInt, paramTableColumn);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     this.fixedColumnIndex = -1;
/*     */     this.controlRef = new WeakReference<>(paramTableView);
/*     */     ObservableList<S> observableList = paramTableView.getItems();
/*     */     this.itemRef = new WeakReference<>((observableList != null && paramInt >= 0 && paramInt < observableList.size()) ? observableList.get(paramInt) : null);
/*     */     this.nonFixedColumnIndex = (paramTableView == null || paramTableColumn == null) ? -1 : paramTableView.getVisibleLeafIndex(paramTableColumn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 105 */     if (this.fixedColumnIndex > -1) {
/* 106 */       return this.fixedColumnIndex;
/*     */     }
/*     */     
/* 109 */     return this.nonFixedColumnIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TableView<S> getTableView() {
/* 117 */     return this.controlRef.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final TableColumn<S, T> getTableColumn() {
/* 123 */     return super.getTableColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final S getItem() {
/* 131 */     return (this.itemRef == null) ? null : this.itemRef.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 139 */     return "TablePosition [ row: " + getRow() + ", column: " + getTableColumn() + ", tableView: " + 
/* 140 */       getTableView() + " ]";
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TablePosition.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */