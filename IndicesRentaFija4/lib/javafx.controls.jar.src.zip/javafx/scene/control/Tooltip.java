/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.beans.IDProperty;
/*      */ import com.sun.javafx.css.StyleManager;
/*      */ import com.sun.javafx.scene.NodeHelper;
/*      */ import com.sun.javafx.stage.PopupWindowHelper;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import javafx.animation.Animation;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.Timeline;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*      */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*      */ import javafx.beans.property.SimpleStringProperty;
/*      */ import javafx.beans.property.StringProperty;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.FontCssMetaData;
/*      */ import javafx.css.SimpleStyleableBooleanProperty;
/*      */ import javafx.css.SimpleStyleableDoubleProperty;
/*      */ import javafx.css.SimpleStyleableObjectProperty;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.StyleOrigin;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.StyleableStringProperty;
/*      */ import javafx.css.converter.BooleanConverter;
/*      */ import javafx.css.converter.DurationConverter;
/*      */ import javafx.css.converter.EnumConverter;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.css.converter.StringConverter;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Parent;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.control.skin.TooltipSkin;
/*      */ import javafx.scene.image.Image;
/*      */ import javafx.scene.image.ImageView;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.text.Font;
/*      */ import javafx.scene.text.TextAlignment;
/*      */ import javafx.stage.Window;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @IDProperty("id")
/*      */ public class Tooltip
/*      */   extends PopupControl
/*      */ {
/*  116 */   private static String TOOLTIP_PROP_KEY = "javafx.scene.control.Tooltip";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  124 */   private static int TOOLTIP_XOFFSET = 10;
/*  125 */   private static int TOOLTIP_YOFFSET = 7;
/*      */   
/*  127 */   private static TooltipBehavior BEHAVIOR = new TooltipBehavior(false); private final StringProperty text; private final ObjectProperty<TextAlignment> textAlignment; private final ObjectProperty<OverrunStyle> textOverrun; private final BooleanProperty wrapText; private final ObjectProperty<Font> font;
/*      */   private final ObjectProperty<Duration> showDelayProperty;
/*      */   private final ObjectProperty<Duration> showDurationProperty;
/*      */   private final ObjectProperty<Duration> hideDelayProperty;
/*      */   private final ObjectProperty<Node> graphic;
/*      */   private StyleableStringProperty imageUrl;
/*      */   private final ObjectProperty<ContentDisplay> contentDisplay;
/*      */   private final DoubleProperty graphicTextGap;
/*      */   private final ReadOnlyBooleanWrapper activated;
/*      */   
/*      */   public static void install(Node paramNode, Tooltip paramTooltip) {
/*  138 */     BEHAVIOR.install(paramNode, paramTooltip);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void uninstall(Node paramNode, Tooltip paramTooltip) {
/*  150 */     BEHAVIOR.uninstall(paramNode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Tooltip() {
/*  163 */     this((String)null);
/*      */   } public final StringProperty textProperty() { return this.text; } public final void setText(String paramString) { textProperty().setValue(paramString); } public final String getText() { return (this.text.getValue() == null) ? "" : this.text.getValue(); } public final ObjectProperty<TextAlignment> textAlignmentProperty() { return this.textAlignment; } public final void setTextAlignment(TextAlignment paramTextAlignment) {
/*      */     textAlignmentProperty().setValue(paramTextAlignment);
/*      */   } public final TextAlignment getTextAlignment() {
/*      */     return textAlignmentProperty().getValue();
/*      */   } public final ObjectProperty<OverrunStyle> textOverrunProperty() {
/*      */     return this.textOverrun;
/*      */   } public final void setTextOverrun(OverrunStyle paramOverrunStyle) {
/*      */     textOverrunProperty().setValue(paramOverrunStyle);
/*      */   } public final OverrunStyle getTextOverrun() {
/*      */     return textOverrunProperty().getValue();
/*      */   } public final BooleanProperty wrapTextProperty() {
/*      */     return this.wrapText;
/*      */   } public final void setWrapText(boolean paramBoolean) {
/*      */     wrapTextProperty().setValue(Boolean.valueOf(paramBoolean));
/*      */   } public final boolean isWrapText() {
/*      */     return wrapTextProperty().getValue().booleanValue();
/*      */   } public final ObjectProperty<Font> fontProperty() {
/*      */     return this.font;
/*      */   } public final void setFont(Font paramFont) {
/*      */     fontProperty().setValue(paramFont);
/*      */   }
/*      */   public final Font getFont() {
/*      */     return fontProperty().getValue();
/*      */   }
/*      */   public final ObjectProperty<Duration> showDelayProperty() {
/*      */     return this.showDelayProperty;
/*      */   }
/*      */   public final void setShowDelay(Duration paramDuration) {
/*      */     this.showDelayProperty.set(paramDuration);
/*      */   }
/*  194 */   public Tooltip(String paramString) { this.text = new SimpleStringProperty(this, "text", "") {
/*      */         protected void invalidated() {
/*  196 */           super.invalidated();
/*  197 */           String str = get();
/*  198 */           if (Tooltip.this.isShowing() && str != null && !str.equals(Tooltip.this.getText())) {
/*      */ 
/*      */             
/*  201 */             Tooltip.this.setAnchorX(Tooltip.BEHAVIOR.lastMouseX);
/*  202 */             Tooltip.this.setAnchorY(Tooltip.BEHAVIOR.lastMouseY);
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  223 */     this.textAlignment = new SimpleStyleableObjectProperty<>((CssMetaData)TEXT_ALIGNMENT, this, "textAlignment", TextAlignment.LEFT);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  240 */     this.textOverrun = new SimpleStyleableObjectProperty<>((CssMetaData)TEXT_OVERRUN, this, "textOverrun", OverrunStyle.ELLIPSIS);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  257 */     this.wrapText = new SimpleStyleableBooleanProperty((CssMetaData)WRAP_TEXT, this, "wrapText", false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  277 */     this.font = new StyleableObjectProperty<Font>(Font.getDefault())
/*      */       {
/*      */         private boolean fontSetByCss = false;
/*      */ 
/*      */ 
/*      */         
/*      */         public void applyStyle(StyleOrigin param1StyleOrigin, Font param1Font) {
/*      */           try {
/*  285 */             this.fontSetByCss = true;
/*  286 */             super.applyStyle(param1StyleOrigin, param1Font);
/*  287 */           } catch (Exception exception) {
/*  288 */             throw exception;
/*      */           } finally {
/*  290 */             this.fontSetByCss = false;
/*      */           } 
/*      */         }
/*      */         
/*      */         public void set(Font param1Font) {
/*  295 */           Font font = get();
/*  296 */           StyleOrigin styleOrigin = ((StyleableObjectProperty)Tooltip.this.font).getStyleOrigin();
/*  297 */           if (styleOrigin == null || ((param1Font != null) ? !param1Font.equals(font) : (font != null))) {
/*  298 */             super.set(param1Font);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected void invalidated() {
/*  306 */           if (!this.fontSetByCss) {
/*  307 */             NodeHelper.reapplyCSS(Tooltip.this.bridge);
/*      */           }
/*      */         }
/*      */         
/*      */         public CssMetaData<Tooltip.CSSBridge, Font> getCssMetaData() {
/*  312 */           return Tooltip.FONT;
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  316 */           return Tooltip.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  320 */           return "font";
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  342 */     this.showDelayProperty = new SimpleStyleableObjectProperty<>((CssMetaData)SHOW_DELAY, this, "showDelay", new Duration(1000.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  365 */     this.showDurationProperty = new SimpleStyleableObjectProperty<>((CssMetaData)SHOW_DURATION, this, "showDuration", new Duration(5000.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  386 */     this.hideDelayProperty = new SimpleStyleableObjectProperty<>((CssMetaData)HIDE_DELAY, this, "hideDelay", new Duration(200.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  408 */     this.graphic = new StyleableObjectProperty<Node>()
/*      */       {
/*      */         public CssMetaData getCssMetaData()
/*      */         {
/*  412 */           return Tooltip.GRAPHIC;
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  416 */           return Tooltip.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  420 */           return "graphic";
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  522 */     this.imageUrl = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  537 */     this.contentDisplay = new SimpleStyleableObjectProperty<>((CssMetaData)CONTENT_DISPLAY, this, "contentDisplay", ContentDisplay.LEFT);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  553 */     this
/*  554 */       .graphicTextGap = new SimpleStyleableDoubleProperty((CssMetaData)GRAPHIC_TEXT_GAP, this, "graphicTextGap", Double.valueOf(4.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  562 */     this.activated = new ReadOnlyBooleanWrapper(this, "activated"); if (paramString != null) setText(paramString);  this.bridge = new CSSBridge(); PopupWindowHelper.getContent(this).setAll(new Node[] { this.bridge }); getStyleClass().setAll(new String[] { "tooltip" }); }
/*  563 */   public final Duration getShowDelay() { return this.showDelayProperty.get(); } public final ObjectProperty<Duration> showDurationProperty() { return this.showDurationProperty; } public final void setShowDuration(Duration paramDuration) { this.showDurationProperty.set(paramDuration); } public final Duration getShowDuration() { return this.showDurationProperty.get(); } public final ObjectProperty<Duration> hideDelayProperty() { return this.hideDelayProperty; } public final void setHideDelay(Duration paramDuration) { this.hideDelayProperty.set(paramDuration); } public final Duration getHideDelay() { return this.hideDelayProperty.get(); } public final ObjectProperty<Node> graphicProperty() { return this.graphic; } final void setActivated(boolean paramBoolean) { this.activated.set(paramBoolean); } public final void setGraphic(Node paramNode) { graphicProperty().setValue(paramNode); } public final Node getGraphic() { return graphicProperty().getValue(); } private StyleableStringProperty imageUrlProperty() { if (this.imageUrl == null) this.imageUrl = new StyleableStringProperty() { StyleOrigin origin = StyleOrigin.USER; public void applyStyle(StyleOrigin param1StyleOrigin, String param1String) { this.origin = param1StyleOrigin; if (Tooltip.this.graphic == null || !Tooltip.this.graphic.isBound()) super.applyStyle(param1StyleOrigin, param1String);  this.origin = StyleOrigin.USER; } protected void invalidated() { String str = super.get(); if (str == null) { ((StyleableProperty)Tooltip.this.graphicProperty()).applyStyle(this.origin, null); } else { Node node = Tooltip.this.getGraphic(); if (node instanceof ImageView) { ImageView imageView = (ImageView)node; Image image1 = imageView.getImage(); if (image1 != null) { String str1 = image1.getUrl(); if (str.equals(str1)) return;  }  }  Image image = StyleManager.getInstance().getCachedImage(str); if (image != null) ((StyleableProperty)Tooltip.this.graphicProperty()).applyStyle(this.origin, new ImageView(image));  }  } public String get() { Node node = Tooltip.this.getGraphic(); if (node instanceof ImageView) { Image image = ((ImageView)node).getImage(); if (image != null) return image.getUrl();  }  return null; } public StyleOrigin getStyleOrigin() { return (Tooltip.this.graphic != null) ? ((StyleableProperty)Tooltip.this.graphic).getStyleOrigin() : null; } public Object getBean() { return Tooltip.this; } public String getName() { return "imageUrl"; } public CssMetaData<Tooltip.CSSBridge, String> getCssMetaData() { return Tooltip.GRAPHIC; } }
/*  564 */         ;  return this.imageUrl; } public final ObjectProperty<ContentDisplay> contentDisplayProperty() { return this.contentDisplay; } public final void setContentDisplay(ContentDisplay paramContentDisplay) { contentDisplayProperty().setValue(paramContentDisplay); } public final ContentDisplay getContentDisplay() { return contentDisplayProperty().getValue(); } public final DoubleProperty graphicTextGapProperty() { return this.graphicTextGap; } public final void setGraphicTextGap(double paramDouble) { graphicTextGapProperty().setValue(Double.valueOf(paramDouble)); } public final double getGraphicTextGap() { return graphicTextGapProperty().getValue().doubleValue(); } public final boolean isActivated() { return this.activated.get(); } public final ReadOnlyBooleanProperty activatedProperty() {
/*  565 */     return this.activated.getReadOnlyProperty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Skin<?> createDefaultSkin() {
/*  577 */     return (Skin<?>)new TooltipSkin(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  589 */   private static final CssMetaData<CSSBridge, Font> FONT = new FontCssMetaData<CSSBridge>("-fx-font", 
/*  590 */       Font.getDefault())
/*      */     {
/*      */       public boolean isSettable(Tooltip.CSSBridge param1CSSBridge)
/*      */       {
/*  594 */         return !param1CSSBridge.tooltip.fontProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<Font> getStyleableProperty(Tooltip.CSSBridge param1CSSBridge) {
/*  599 */         return (StyleableProperty<Font>)param1CSSBridge.tooltip.fontProperty();
/*      */       }
/*      */     };
/*      */   
/*  603 */   private static final CssMetaData<CSSBridge, TextAlignment> TEXT_ALIGNMENT = new CssMetaData<CSSBridge, TextAlignment>("-fx-text-alignment", (StyleConverter)new EnumConverter(TextAlignment.class), TextAlignment.LEFT)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isSettable(Tooltip.CSSBridge param1CSSBridge)
/*      */       {
/*  610 */         return !param1CSSBridge.tooltip.textAlignmentProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<TextAlignment> getStyleableProperty(Tooltip.CSSBridge param1CSSBridge) {
/*  615 */         return (StyleableProperty<TextAlignment>)param1CSSBridge.tooltip.textAlignmentProperty();
/*      */       }
/*      */     };
/*      */   
/*  619 */   private static final CssMetaData<CSSBridge, OverrunStyle> TEXT_OVERRUN = new CssMetaData<CSSBridge, OverrunStyle>("-fx-text-overrun", (StyleConverter)new EnumConverter(OverrunStyle.class), OverrunStyle.ELLIPSIS)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isSettable(Tooltip.CSSBridge param1CSSBridge)
/*      */       {
/*  626 */         return !param1CSSBridge.tooltip.textOverrunProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<OverrunStyle> getStyleableProperty(Tooltip.CSSBridge param1CSSBridge) {
/*  631 */         return (StyleableProperty<OverrunStyle>)param1CSSBridge.tooltip.textOverrunProperty();
/*      */       }
/*      */     };
/*      */   
/*  635 */   private static final CssMetaData<CSSBridge, Boolean> WRAP_TEXT = new CssMetaData<CSSBridge, Boolean>("-fx-wrap-text", 
/*      */       
/*  637 */       BooleanConverter.getInstance(), Boolean.FALSE)
/*      */     {
/*      */       public boolean isSettable(Tooltip.CSSBridge param1CSSBridge)
/*      */       {
/*  641 */         return !param1CSSBridge.tooltip.wrapTextProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<Boolean> getStyleableProperty(Tooltip.CSSBridge param1CSSBridge) {
/*  646 */         return (StyleableProperty<Boolean>)param1CSSBridge.tooltip.wrapTextProperty();
/*      */       }
/*      */     };
/*      */   
/*  650 */   private static final CssMetaData<CSSBridge, String> GRAPHIC = new CssMetaData<CSSBridge, String>("-fx-graphic", 
/*      */       
/*  652 */       StringConverter.getInstance())
/*      */     {
/*      */       public boolean isSettable(Tooltip.CSSBridge param1CSSBridge)
/*      */       {
/*  656 */         return !param1CSSBridge.tooltip.graphicProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<String> getStyleableProperty(Tooltip.CSSBridge param1CSSBridge) {
/*  661 */         return param1CSSBridge.tooltip.imageUrlProperty();
/*      */       }
/*      */     };
/*      */   
/*  665 */   private static final CssMetaData<CSSBridge, ContentDisplay> CONTENT_DISPLAY = new CssMetaData<CSSBridge, ContentDisplay>("-fx-content-display", (StyleConverter)new EnumConverter(ContentDisplay.class), ContentDisplay.LEFT)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isSettable(Tooltip.CSSBridge param1CSSBridge)
/*      */       {
/*  672 */         return !param1CSSBridge.tooltip.contentDisplayProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<ContentDisplay> getStyleableProperty(Tooltip.CSSBridge param1CSSBridge) {
/*  677 */         return (StyleableProperty<ContentDisplay>)param1CSSBridge.tooltip.contentDisplayProperty();
/*      */       }
/*      */     };
/*      */   
/*  681 */   private static final CssMetaData<CSSBridge, Number> GRAPHIC_TEXT_GAP = new CssMetaData<CSSBridge, Number>("-fx-graphic-text-gap", 
/*      */       
/*  683 */       SizeConverter.getInstance(), Double.valueOf(4.0D))
/*      */     {
/*      */       public boolean isSettable(Tooltip.CSSBridge param1CSSBridge)
/*      */       {
/*  687 */         return !param1CSSBridge.tooltip.graphicTextGapProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<Number> getStyleableProperty(Tooltip.CSSBridge param1CSSBridge) {
/*  692 */         return (StyleableProperty<Number>)param1CSSBridge.tooltip.graphicTextGapProperty();
/*      */       }
/*      */     };
/*      */   
/*  696 */   private static final CssMetaData<CSSBridge, Duration> SHOW_DELAY = new CssMetaData<CSSBridge, Duration>("-fx-show-delay", 
/*      */       
/*  698 */       DurationConverter.getInstance(), new Duration(1000.0D))
/*      */     {
/*      */       public boolean isSettable(Tooltip.CSSBridge param1CSSBridge)
/*      */       {
/*  702 */         return !param1CSSBridge.tooltip.showDelayProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<Duration> getStyleableProperty(Tooltip.CSSBridge param1CSSBridge) {
/*  707 */         return (StyleableProperty<Duration>)param1CSSBridge.tooltip.showDelayProperty();
/*      */       }
/*      */     };
/*      */   
/*  711 */   private static final CssMetaData<CSSBridge, Duration> SHOW_DURATION = new CssMetaData<CSSBridge, Duration>("-fx-show-duration", 
/*      */       
/*  713 */       DurationConverter.getInstance(), new Duration(5000.0D))
/*      */     {
/*      */       public boolean isSettable(Tooltip.CSSBridge param1CSSBridge)
/*      */       {
/*  717 */         return !param1CSSBridge.tooltip.showDurationProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<Duration> getStyleableProperty(Tooltip.CSSBridge param1CSSBridge) {
/*  722 */         return (StyleableProperty<Duration>)param1CSSBridge.tooltip.showDurationProperty();
/*      */       }
/*      */     };
/*      */   
/*  726 */   private static final CssMetaData<CSSBridge, Duration> HIDE_DELAY = new CssMetaData<CSSBridge, Duration>("-fx-hide-delay", 
/*      */       
/*  728 */       DurationConverter.getInstance(), new Duration(200.0D))
/*      */     {
/*      */       public boolean isSettable(Tooltip.CSSBridge param1CSSBridge)
/*      */       {
/*  732 */         return !param1CSSBridge.tooltip.hideDelayProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<Duration> getStyleableProperty(Tooltip.CSSBridge param1CSSBridge) {
/*  737 */         return (StyleableProperty<Duration>)param1CSSBridge.tooltip.hideDelayProperty();
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*      */   private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */   
/*      */   static {
/*  745 */     ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(PopupControl.getClassCssMetaData());
/*  746 */     arrayList.add(FONT);
/*  747 */     arrayList.add(TEXT_ALIGNMENT);
/*  748 */     arrayList.add(TEXT_OVERRUN);
/*  749 */     arrayList.add(WRAP_TEXT);
/*  750 */     arrayList.add(GRAPHIC);
/*  751 */     arrayList.add(CONTENT_DISPLAY);
/*  752 */     arrayList.add(GRAPHIC_TEXT_GAP);
/*  753 */     arrayList.add(SHOW_DELAY);
/*  754 */     arrayList.add(SHOW_DURATION);
/*  755 */     arrayList.add(HIDE_DELAY);
/*  756 */     STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/*  765 */     return STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/*  774 */     return getClassCssMetaData();
/*      */   }
/*      */   
/*      */   public Styleable getStyleableParent() {
/*  778 */     if (BEHAVIOR.hoveredNode == null) {
/*  779 */       return super.getStyleableParent();
/*      */     }
/*  781 */     return BEHAVIOR.hoveredNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class CSSBridge
/*      */     extends PopupControl.CSSBridge
/*      */   {
/*  793 */     private Tooltip tooltip = Tooltip.this;
/*      */ 
/*      */     
/*      */     CSSBridge() {
/*  797 */       setAccessibleRole(AccessibleRole.TOOLTIP);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class TooltipBehavior
/*      */   {
/*  838 */     private Timeline activationTimer = new Timeline();
/*  839 */     private Timeline hideTimer = new Timeline();
/*  840 */     private Timeline leftTimer = new Timeline();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Node hoveredNode;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Tooltip activatedTooltip;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Tooltip visibleTooltip;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private double lastMouseX;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private double lastMouseY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean hideOnExit;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean cssForced = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private EventHandler<MouseEvent> MOVE_HANDLER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private EventHandler<MouseEvent> LEAVING_HANDLER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private EventHandler<MouseEvent> KILL_HANDLER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     TooltipBehavior(boolean param1Boolean)
/*      */     {
/*  962 */       this.MOVE_HANDLER = (param1MouseEvent -> {
/*      */           this.lastMouseX = param1MouseEvent.getScreenX();
/*      */ 
/*      */           
/*      */           this.lastMouseY = param1MouseEvent.getScreenY();
/*      */ 
/*      */           
/*      */           if (this.hideTimer.getStatus() == Animation.Status.RUNNING) {
/*      */             return;
/*      */           }
/*      */ 
/*      */           
/*      */           this.hoveredNode = (Node)param1MouseEvent.getSource();
/*      */ 
/*      */           
/*      */           Tooltip tooltip = (Tooltip)this.hoveredNode.getProperties().get(Tooltip.TOOLTIP_PROP_KEY);
/*      */ 
/*      */           
/*      */           if (tooltip != null) {
/*      */             Window window = getWindow(this.hoveredNode);
/*      */ 
/*      */             
/*      */             boolean bool = isWindowHierarchyVisible(this.hoveredNode);
/*      */ 
/*      */             
/*      */             if (window != null && bool) {
/*      */               if (this.leftTimer.getStatus() == Animation.Status.RUNNING) {
/*      */                 if (this.visibleTooltip != null) {
/*      */                   this.visibleTooltip.hide();
/*      */                 }
/*      */ 
/*      */                 
/*      */                 this.visibleTooltip = tooltip;
/*      */                 
/*      */                 tooltip.show(window, param1MouseEvent.getScreenX() + Tooltip.TOOLTIP_XOFFSET, param1MouseEvent.getScreenY() + Tooltip.TOOLTIP_YOFFSET);
/*      */                 
/*      */                 this.leftTimer.stop();
/*      */                 
/*      */                 if (tooltip.getShowDuration() != null) {
/*      */                   this.hideTimer.getKeyFrames().setAll(new KeyFrame[] { new KeyFrame(tooltip.getShowDuration(), new javafx.animation.KeyValue[0]) });
/*      */                 }
/*      */                 
/*      */                 this.hideTimer.playFromStart();
/*      */               } else {
/*      */                 if (!this.cssForced) {
/*      */                   double d = tooltip.getOpacity();
/*      */                   
/*      */                   tooltip.setOpacity(0.0D);
/*      */                   
/*      */                   tooltip.show(window);
/*      */                   
/*      */                   tooltip.hide();
/*      */                   
/*      */                   tooltip.setOpacity(d);
/*      */                   
/*      */                   this.cssForced = true;
/*      */                 } 
/*      */                 
/*      */                 tooltip.setActivated(true);
/*      */                 
/*      */                 this.activatedTooltip = tooltip;
/*      */                 
/*      */                 this.activationTimer.stop();
/*      */                 
/*      */                 if (tooltip.getShowDelay() != null) {
/*      */                   this.activationTimer.getKeyFrames().setAll(new KeyFrame[] { new KeyFrame(tooltip.getShowDelay(), new javafx.animation.KeyValue[0]) });
/*      */                 }
/*      */                 
/*      */                 this.activationTimer.playFromStart();
/*      */               } 
/*      */             }
/*      */           } 
/*      */         });
/*      */       
/* 1036 */       this.LEAVING_HANDLER = (param1MouseEvent -> {
/*      */           if (this.activationTimer.getStatus() == Animation.Status.RUNNING) {
/*      */             this.activationTimer.stop();
/*      */           } else if (this.hideTimer.getStatus() == Animation.Status.RUNNING) {
/*      */             assert this.visibleTooltip != null;
/*      */             
/*      */             this.hideTimer.stop();
/*      */             
/*      */             if (this.hideOnExit) {
/*      */               this.visibleTooltip.hide();
/*      */             }
/*      */             
/*      */             Node node = (Node)param1MouseEvent.getSource();
/*      */             
/*      */             Tooltip tooltip = (Tooltip)node.getProperties().get(Tooltip.TOOLTIP_PROP_KEY);
/*      */             if (tooltip != null) {
/*      */               if (tooltip.getHideDelay() != null) {
/*      */                 this.leftTimer.getKeyFrames().setAll(new KeyFrame[] { new KeyFrame(tooltip.getHideDelay(), new javafx.animation.KeyValue[0]) });
/*      */               }
/*      */               this.leftTimer.playFromStart();
/*      */             } 
/*      */           } 
/*      */           this.hoveredNode = null;
/*      */           this.activatedTooltip = null;
/*      */           if (this.hideOnExit) {
/*      */             this.visibleTooltip = null;
/*      */           }
/*      */         });
/* 1064 */       this.KILL_HANDLER = (param1MouseEvent -> { this.activationTimer.stop(); this.hideTimer.stop(); this.leftTimer.stop(); if (this.visibleTooltip != null)
/*      */             this.visibleTooltip.hide();  this.hoveredNode = null; this.activatedTooltip = null; this.visibleTooltip = null;
/*      */         }); this.hideOnExit = param1Boolean; this.activationTimer.setOnFinished(param1ActionEvent -> { assert this.activatedTooltip != null; Window window = getWindow(this.hoveredNode); boolean bool = isWindowHierarchyVisible(this.hoveredNode); if (window != null && window.isShowing() && bool) {
/*      */               double d1 = this.lastMouseX; double d2 = this.lastMouseY; NodeOrientation nodeOrientation = this.hoveredNode.getEffectiveNodeOrientation(); this.activatedTooltip.getScene().setNodeOrientation(nodeOrientation); if (nodeOrientation == NodeOrientation.RIGHT_TO_LEFT)
/*      */                 d1 -= this.activatedTooltip.getWidth();  this.activatedTooltip.show(window, d1 + Tooltip.TOOLTIP_XOFFSET, d2 + Tooltip.TOOLTIP_YOFFSET); if (d2 + Tooltip.TOOLTIP_YOFFSET > this.activatedTooltip.getAnchorY()) {
/*      */                 this.activatedTooltip.hide(); d2 -= this.activatedTooltip.getHeight(); this.activatedTooltip.show(window, d1 + Tooltip.TOOLTIP_XOFFSET, d2);
/*      */               }  this.visibleTooltip = this.activatedTooltip; this.hoveredNode = null; if (this.activatedTooltip.getShowDuration() != null)
/*      */                 this.hideTimer.getKeyFrames().setAll(new KeyFrame[] { new KeyFrame(this.activatedTooltip.getShowDuration(), new javafx.animation.KeyValue[0]) });  this.hideTimer.playFromStart();
/*      */             }  this.activatedTooltip.setActivated(false); this.activatedTooltip = null;
/*      */           }); this.hideTimer.setOnFinished(param1ActionEvent -> {
/*      */             assert this.visibleTooltip != null; this.visibleTooltip.hide(); this.visibleTooltip = null; this.hoveredNode = null;
/*      */           }); this.leftTimer.setOnFinished(param1ActionEvent -> {
/*      */             if (!param1Boolean) {
/*      */               assert this.visibleTooltip != null; this.visibleTooltip.hide(); this.visibleTooltip = null; this.hoveredNode = null;
/*      */             } 
/* 1079 */           }); } private void install(Node param1Node, Tooltip param1Tooltip) { if (param1Node == null)
/* 1080 */         return;  param1Node.addEventHandler(MouseEvent.MOUSE_MOVED, this.MOVE_HANDLER);
/* 1081 */       param1Node.addEventHandler(MouseEvent.MOUSE_EXITED, this.LEAVING_HANDLER);
/* 1082 */       param1Node.addEventHandler(MouseEvent.MOUSE_PRESSED, this.KILL_HANDLER);
/* 1083 */       param1Node.getProperties().put(Tooltip.TOOLTIP_PROP_KEY, param1Tooltip); }
/*      */ 
/*      */     
/*      */     private void uninstall(Node param1Node) {
/* 1087 */       if (param1Node == null)
/* 1088 */         return;  param1Node.removeEventHandler(MouseEvent.MOUSE_MOVED, this.MOVE_HANDLER);
/* 1089 */       param1Node.removeEventHandler(MouseEvent.MOUSE_EXITED, this.LEAVING_HANDLER);
/* 1090 */       param1Node.removeEventHandler(MouseEvent.MOUSE_PRESSED, this.KILL_HANDLER);
/* 1091 */       Tooltip tooltip = (Tooltip)param1Node.getProperties().get(Tooltip.TOOLTIP_PROP_KEY);
/* 1092 */       if (tooltip != null) {
/* 1093 */         param1Node.getProperties().remove(Tooltip.TOOLTIP_PROP_KEY);
/* 1094 */         if (tooltip.equals(this.visibleTooltip) || tooltip.equals(this.activatedTooltip)) {
/* 1095 */           this.KILL_HANDLER.handle(null);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Window getWindow(Node param1Node) {
/* 1106 */       Scene scene = (param1Node == null) ? null : param1Node.getScene();
/* 1107 */       return (scene == null) ? null : scene.getWindow();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean isWindowHierarchyVisible(Node param1Node) {
/* 1116 */       boolean bool = (param1Node != null);
/* 1117 */       Parent parent = (param1Node == null) ? null : param1Node.getParent();
/* 1118 */       while (parent != null && bool) {
/* 1119 */         bool = parent.isVisible();
/* 1120 */         parent = parent.getParent();
/*      */       } 
/* 1122 */       return bool;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Tooltip.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */