/*    */ package javafx.scene.control;
/*    */ 
/*    */ import javafx.geometry.Orientation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SeparatorMenuItem
/*    */   extends CustomMenuItem
/*    */ {
/*    */   private static final String DEFAULT_STYLE_CLASS = "separator-menu-item";
/*    */   
/*    */   public SeparatorMenuItem() {
/* 63 */     super(new Separator(Orientation.HORIZONTAL), false);
/* 64 */     getStyleClass().add("separator-menu-item");
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\SeparatorMenuItem.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */