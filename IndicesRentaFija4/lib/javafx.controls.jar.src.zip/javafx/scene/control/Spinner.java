/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.control.FakeFocusTextField;
/*     */ import java.math.BigDecimal;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalTime;
/*     */ import java.time.temporal.TemporalUnit;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.SimpleStyleableObjectProperty;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.DurationConverter;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.SpinnerSkin;
/*     */ import javafx.util.Duration;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Spinner<T>
/*     */   extends Control
/*     */ {
/*     */   private static final String DEFAULT_STYLE_CLASS = "spinner";
/*     */   public static final String STYLE_CLASS_ARROWS_ON_RIGHT_HORIZONTAL = "arrows-on-right-horizontal";
/*     */   public static final String STYLE_CLASS_ARROWS_ON_LEFT_VERTICAL = "arrows-on-left-vertical";
/*     */   public static final String STYLE_CLASS_ARROWS_ON_LEFT_HORIZONTAL = "arrows-on-left-horizontal";
/*     */   public static final String STYLE_CLASS_SPLIT_ARROWS_VERTICAL = "split-arrows-vertical";
/*     */   public static final String STYLE_CLASS_SPLIT_ARROWS_HORIZONTAL = "split-arrows-horizontal";
/*     */   private ReadOnlyObjectWrapper<T> value;
/*     */   private ObjectProperty<SpinnerValueFactory<T>> valueFactory;
/*     */   private BooleanProperty editable;
/*     */   private TextField textField;
/*     */   private ReadOnlyObjectWrapper<TextField> editor;
/*     */   private final ObjectProperty<Duration> initialDelay;
/*     */   private final ObjectProperty<Duration> repeatDelay;
/*     */   
/*     */   public Spinner() {
/* 504 */     this.value = new ReadOnlyObjectWrapper<>(this, "value");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 530 */     this.valueFactory = (ObjectProperty)new SimpleObjectProperty<SpinnerValueFactory<SpinnerValueFactory<T>>>(this, "valueFactory")
/*     */       {
/*     */         protected void invalidated() {
/* 533 */           Spinner.this.value.unbind();
/*     */           
/* 535 */           SpinnerValueFactory<T> spinnerValueFactory = get();
/* 536 */           if (spinnerValueFactory != null)
/*     */           {
/*     */             
/* 539 */             Spinner.this.value.bind(spinnerValueFactory.valueProperty());
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 614 */     this.initialDelay = new SimpleStyleableObjectProperty<>((CssMetaData)INITIAL_DELAY, this, "initialDelay", new Duration(300.0D));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 641 */     this.repeatDelay = new SimpleStyleableObjectProperty<>((CssMetaData)REPEAT_DELAY, this, "repeatDelay", new Duration(60.0D)); getStyleClass().add("spinner"); setAccessibleRole(AccessibleRole.SPINNER); getEditor().setOnAction(paramActionEvent -> commitValue()); getEditor().editableProperty().bind(editableProperty()); this.value.addListener((paramObservableValue, paramObject1, paramObject2) -> setText((T)paramObject2)); getProperties().addListener(paramChange -> { if (paramChange.wasAdded() && paramChange.getKey() == "FOCUSED") { setFocused(((Boolean)paramChange.getValueAdded()).booleanValue()); getProperties().remove("FOCUSED"); }  }); focusedProperty().addListener(paramObservable -> { if (!isFocused()) commitValue();  });
/*     */   }
/*     */   public Spinner(@NamedArg("min") int paramInt1, @NamedArg("max") int paramInt2, @NamedArg("initialValue") int paramInt3) { this(new SpinnerValueFactory.IntegerSpinnerValueFactory(paramInt1, paramInt2, paramInt3)); }
/*     */   public Spinner(@NamedArg("min") int paramInt1, @NamedArg("max") int paramInt2, @NamedArg("initialValue") int paramInt3, @NamedArg("amountToStepBy") int paramInt4) { this(new SpinnerValueFactory.IntegerSpinnerValueFactory(paramInt1, paramInt2, paramInt3, paramInt4)); }
/*     */   public Spinner(@NamedArg("min") double paramDouble1, @NamedArg("max") double paramDouble2, @NamedArg("initialValue") double paramDouble3) { this(new SpinnerValueFactory.DoubleSpinnerValueFactory(paramDouble1, paramDouble2, paramDouble3)); }
/*     */   public Spinner(@NamedArg("min") double paramDouble1, @NamedArg("max") double paramDouble2, @NamedArg("initialValue") double paramDouble3, @NamedArg("amountToStepBy") double paramDouble4) { this(new SpinnerValueFactory.DoubleSpinnerValueFactory(paramDouble1, paramDouble2, paramDouble3, paramDouble4)); }
/*     */   Spinner(@NamedArg("min") LocalDate paramLocalDate1, @NamedArg("max") LocalDate paramLocalDate2, @NamedArg("initialValue") LocalDate paramLocalDate3) { this(new SpinnerValueFactory.LocalDateSpinnerValueFactory(paramLocalDate1, paramLocalDate2, paramLocalDate3)); }
/*     */   Spinner(@NamedArg("min") LocalDate paramLocalDate1, @NamedArg("max") LocalDate paramLocalDate2, @NamedArg("initialValue") LocalDate paramLocalDate3, @NamedArg("amountToStepBy") long paramLong, @NamedArg("temporalUnit") TemporalUnit paramTemporalUnit) { this(new SpinnerValueFactory.LocalDateSpinnerValueFactory(paramLocalDate1, paramLocalDate2, paramLocalDate3, paramLong, paramTemporalUnit)); }
/*     */   Spinner(@NamedArg("min") LocalTime paramLocalTime1, @NamedArg("max") LocalTime paramLocalTime2, @NamedArg("initialValue") LocalTime paramLocalTime3) { this(new SpinnerValueFactory.LocalTimeSpinnerValueFactory(paramLocalTime1, paramLocalTime2, paramLocalTime3)); }
/*     */   Spinner(@NamedArg("min") LocalTime paramLocalTime1, @NamedArg("max") LocalTime paramLocalTime2, @NamedArg("initialValue") LocalTime paramLocalTime3, @NamedArg("amountToStepBy") long paramLong, @NamedArg("temporalUnit") TemporalUnit paramTemporalUnit) { this(new SpinnerValueFactory.LocalTimeSpinnerValueFactory(paramLocalTime1, paramLocalTime2, paramLocalTime3, paramLong, paramTemporalUnit)); }
/*     */   public Spinner(@NamedArg("items") ObservableList<T> paramObservableList) { this(new SpinnerValueFactory.ListSpinnerValueFactory<>(paramObservableList)); }
/*     */   public Spinner(@NamedArg("valueFactory") SpinnerValueFactory<T> paramSpinnerValueFactory) { this(); setValueFactory(paramSpinnerValueFactory); }
/*     */   public void increment() { increment(1); }
/*     */   public void increment(int paramInt) { SpinnerValueFactory<T> spinnerValueFactory = getValueFactory(); if (spinnerValueFactory == null) throw new IllegalStateException("Can't increment Spinner with a null SpinnerValueFactory");  commitValue(); spinnerValueFactory.increment(paramInt); }
/* 655 */   public void decrement() { decrement(1); } public void decrement(int paramInt) { SpinnerValueFactory<T> spinnerValueFactory = getValueFactory(); if (spinnerValueFactory == null) throw new IllegalStateException("Can't decrement Spinner with a null SpinnerValueFactory");  commitValue(); spinnerValueFactory.decrement(paramInt); } protected Skin<?> createDefaultSkin() { return (Skin<?>)new SpinnerSkin(this); } public final void commitValue() { if (!isEditable()) return;  String str = getEditor().getText(); SpinnerValueFactory<T> spinnerValueFactory = getValueFactory(); if (spinnerValueFactory != null) { StringConverter<T> stringConverter = spinnerValueFactory.getConverter(); if (stringConverter != null) { T t = stringConverter.fromString(str); spinnerValueFactory.setValue(t); }  }  } public final ObjectProperty<Duration> repeatDelayProperty() { return this.repeatDelay; }
/*     */   public final void cancelEdit() { if (!isEditable()) return;  T t = getValue(); SpinnerValueFactory<T> spinnerValueFactory = getValueFactory(); if (spinnerValueFactory != null) { StringConverter<T> stringConverter = spinnerValueFactory.getConverter(); if (stringConverter != null) { String str = stringConverter.toString(t); getEditor().setText(str); }  }  }
/*     */   public final T getValue() { return this.value.get(); }
/*     */   public final ReadOnlyObjectProperty<T> valueProperty() { return this.value; }
/* 659 */   public final void setValueFactory(SpinnerValueFactory<T> paramSpinnerValueFactory) { this.valueFactory.setValue(paramSpinnerValueFactory); } public final SpinnerValueFactory<T> getValueFactory() { return this.valueFactory.get(); } public final ObjectProperty<SpinnerValueFactory<T>> valueFactoryProperty() { return this.valueFactory; } public final void setEditable(boolean paramBoolean) { editableProperty().set(paramBoolean); } public final boolean isEditable() { return (this.editable == null) ? true : this.editable.get(); } public final BooleanProperty editableProperty() { if (this.editable == null) this.editable = new SimpleBooleanProperty(this, "editable", false);  return this.editable; } public final ReadOnlyObjectProperty<TextField> editorProperty() { if (this.editor == null) { this.editor = new ReadOnlyObjectWrapper<>(this, "editor"); this.textField = (TextField)new FakeFocusTextField(); this.textField.tooltipProperty().bind(tooltipProperty()); this.editor.set(this.textField); }  return this.editor.getReadOnlyProperty(); } public final TextField getEditor() { return editorProperty().get(); } public final StringProperty promptTextProperty() { return getEditor().promptTextProperty(); } public final String getPromptText() { return getEditor().getPromptText(); } public final void setPromptText(String paramString) { getEditor().setPromptText(paramString); } public final ObjectProperty<Duration> initialDelayProperty() { return this.initialDelay; } public final void setInitialDelay(Duration paramDuration) { if (paramDuration != null) this.initialDelay.set(paramDuration);  } public final Duration getInitialDelay() { return this.initialDelay.get(); } public final void setRepeatDelay(Duration paramDuration) { if (paramDuration != null) {
/* 660 */       this.repeatDelay.set(paramDuration);
/*     */     } }
/*     */ 
/*     */   
/*     */   public final Duration getRepeatDelay() {
/* 665 */     return this.repeatDelay.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 674 */   private static final CssMetaData<Spinner<?>, Duration> INITIAL_DELAY = new CssMetaData<Spinner<?>, Duration>("-fx-initial-delay", 
/*     */       
/* 676 */       DurationConverter.getInstance(), new Duration(300.0D))
/*     */     {
/*     */       public boolean isSettable(Spinner<?> param1Spinner)
/*     */       {
/* 680 */         return !param1Spinner.initialDelayProperty().isBound();
/*     */       }
/*     */ 
/*     */       
/*     */       public StyleableProperty<Duration> getStyleableProperty(Spinner<?> param1Spinner) {
/* 685 */         return (StyleableProperty<Duration>)param1Spinner.initialDelayProperty();
/*     */       }
/*     */     };
/*     */   
/* 689 */   private static final CssMetaData<Spinner<?>, Duration> REPEAT_DELAY = new CssMetaData<Spinner<?>, Duration>("-fx-repeat-delay", 
/*     */       
/* 691 */       DurationConverter.getInstance(), new Duration(60.0D))
/*     */     {
/*     */       public boolean isSettable(Spinner<?> param1Spinner)
/*     */       {
/* 695 */         return !param1Spinner.repeatDelayProperty().isBound();
/*     */       }
/*     */ 
/*     */       
/*     */       public StyleableProperty<Duration> getStyleableProperty(Spinner<?> param1Spinner) {
/* 700 */         return (StyleableProperty<Duration>)param1Spinner.repeatDelayProperty();
/*     */       }
/*     */     };
/*     */   
/*     */   private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */   
/*     */   static {
/* 707 */     ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 708 */     arrayList.add(INITIAL_DELAY);
/* 709 */     arrayList.add(REPEAT_DELAY);
/* 710 */     STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 719 */     return STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 728 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setText(T paramT) {
/* 741 */     String str = null;
/*     */     
/* 743 */     SpinnerValueFactory<T> spinnerValueFactory = getValueFactory();
/* 744 */     if (spinnerValueFactory != null) {
/* 745 */       StringConverter<T> stringConverter = spinnerValueFactory.getConverter();
/* 746 */       if (stringConverter != null) {
/* 747 */         str = stringConverter.toString(paramT);
/*     */       }
/*     */     } 
/*     */     
/* 751 */     notifyAccessibleAttributeChanged(AccessibleAttribute.TEXT);
/* 752 */     if (str == null) {
/* 753 */       if (paramT == null) {
/* 754 */         getEditor().clear();
/*     */         return;
/*     */       } 
/* 757 */       str = paramT.toString();
/*     */     } 
/*     */ 
/*     */     
/* 761 */     getEditor().setText(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int wrapValue(int paramInt1, int paramInt2, int paramInt3) {
/* 770 */     if (paramInt3 == 0) {
/* 771 */       throw new RuntimeException();
/*     */     }
/*     */     
/* 774 */     int i = paramInt1 % paramInt3;
/* 775 */     if (i > paramInt2 && paramInt3 < paramInt2) {
/* 776 */       i = i + paramInt3 - paramInt2;
/* 777 */     } else if (i < paramInt2 && paramInt3 > paramInt2) {
/* 778 */       i = i + paramInt3 - paramInt2;
/*     */     } 
/* 780 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BigDecimal wrapValue(BigDecimal paramBigDecimal1, BigDecimal paramBigDecimal2, BigDecimal paramBigDecimal3) {
/* 789 */     if (paramBigDecimal3.doubleValue() == 0.0D) {
/* 790 */       throw new RuntimeException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 796 */     if (paramBigDecimal1.compareTo(paramBigDecimal2) < 0)
/* 797 */       return paramBigDecimal3; 
/* 798 */     if (paramBigDecimal1.compareTo(paramBigDecimal3) > 0) {
/* 799 */       return paramBigDecimal2;
/*     */     }
/* 801 */     return paramBigDecimal1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*     */     T t;
/*     */     SpinnerValueFactory<T> spinnerValueFactory;
/* 815 */     switch (paramAccessibleAttribute) {
/*     */       case INCREMENT:
/* 817 */         t = getValue();
/* 818 */         spinnerValueFactory = getValueFactory();
/* 819 */         if (spinnerValueFactory != null) {
/* 820 */           StringConverter<T> stringConverter = spinnerValueFactory.getConverter();
/* 821 */           if (stringConverter != null) {
/* 822 */             return stringConverter.toString(t);
/*     */           }
/*     */         } 
/* 825 */         return (t != null) ? t.toString() : "";
/*     */     } 
/* 827 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/* 834 */     switch (paramAccessibleAction) {
/*     */       case INCREMENT:
/* 836 */         increment();
/*     */         return;
/*     */       case DECREMENT:
/* 839 */         decrement(); return;
/*     */     } 
/* 841 */     super.executeAccessibleAction(paramAccessibleAction, new Object[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Spinner.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */