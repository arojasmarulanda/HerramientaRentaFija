/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.control.skin.ColorPickerSkin;
/*     */ import javafx.scene.paint.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorPicker
/*     */   extends ComboBoxBase<Color>
/*     */ {
/*     */   public static final String STYLE_CLASS_BUTTON = "button";
/*     */   public static final String STYLE_CLASS_SPLIT_BUTTON = "split-button";
/*  95 */   private ObservableList<Color> customColors = FXCollections.observableArrayList();
/*     */   
/*     */   private static final String DEFAULT_STYLE_CLASS = "color-picker";
/*     */ 
/*     */   
/*     */   public final ObservableList<Color> getCustomColors() {
/* 101 */     return this.customColors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorPicker() {
/* 108 */     this(Color.WHITE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColorPicker(Color paramColor) {
/* 116 */     setValue(paramColor);
/* 117 */     getStyleClass().add("color-picker");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 128 */     return (Skin<?>)new ColorPickerSkin(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ColorPicker.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */