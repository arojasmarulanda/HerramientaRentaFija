/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.beans.value.WritableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.NestedTableColumnHeader;
/*     */ import javafx.scene.control.skin.TableColumnHeader;
/*     */ import javafx.scene.control.skin.TableHeaderRow;
/*     */ import javafx.scene.control.skin.TableViewSkin;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableColumn<S, T>
/*     */   extends TableColumnBase<S, T>
/*     */   implements EventTarget
/*     */ {
/*     */   public static <S, T> EventType<CellEditEvent<S, T>> editAnyEvent() {
/* 152 */     return (EventType)EDIT_ANY_EVENT;
/*     */   }
/* 154 */   private static final EventType<?> EDIT_ANY_EVENT = new EventType(Event.ANY, "TABLE_COLUMN_EDIT");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> EventType<CellEditEvent<S, T>> editStartEvent() {
/* 167 */     return (EventType)EDIT_START_EVENT;
/*     */   }
/* 169 */   private static final EventType<?> EDIT_START_EVENT = new EventType(
/* 170 */       editAnyEvent(), "EDIT_START");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> EventType<CellEditEvent<S, T>> editCancelEvent() {
/* 181 */     return (EventType)EDIT_CANCEL_EVENT;
/*     */   }
/* 183 */   private static final EventType<?> EDIT_CANCEL_EVENT = new EventType(
/* 184 */       editAnyEvent(), "EDIT_CANCEL");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> EventType<CellEditEvent<S, T>> editCommitEvent() {
/* 196 */     return (EventType)EDIT_COMMIT_EVENT;
/*     */   }
/* 198 */   private static final EventType<?> EDIT_COMMIT_EVENT = new EventType(
/* 199 */       editAnyEvent(), "EDIT_COMMIT");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   public static final Callback<TableColumn<?, ?>, TableCell<?, ?>> DEFAULT_CELL_FACTORY = new Callback<TableColumn<?, ?>, TableCell<?, ?>>()
/*     */     {
/*     */       public TableCell<?, ?> call(TableColumn<?, ?> param1TableColumn)
/*     */       {
/* 215 */         return new TableCell<Object, Object>() {
/*     */             protected void updateItem(Object param2Object, boolean param2Boolean) {
/* 217 */               if (param2Object == getItem())
/*     */                 return; 
/* 219 */               super.updateItem(param2Object, param2Boolean);
/*     */               
/* 221 */               if (param2Object == null) {
/* 222 */                 setText(null);
/* 223 */                 setGraphic(null);
/* 224 */               } else if (param2Object instanceof Node) {
/* 225 */                 setText(null);
/* 226 */                 setGraphic((Node)param2Object);
/*     */               } else {
/* 228 */                 setText(param2Object.toString());
/* 229 */                 setGraphic(null);
/*     */               } 
/*     */             }
/*     */           };
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EventHandler<CellEditEvent<S, T>> DEFAULT_EDIT_COMMIT_HANDLER;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ListChangeListener<TableColumn<S, ?>> columnsListener;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WeakListChangeListener<TableColumn<S, ?>> weakColumnsListener;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ObservableList<TableColumn<S, ?>> columns;
/*     */ 
/*     */ 
/*     */   
/*     */   private ReadOnlyObjectWrapper<TableView<S>> tableView;
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<Callback<CellDataFeatures<S, T>, ObservableValue<T>>> cellValueFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ObjectProperty<Callback<TableColumn<S, T>, TableCell<S, T>>> cellFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<SortType> sortType;
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditStart;
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCommit;
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCancel;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_STYLE_CLASS = "table-column";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableColumn() {
/* 292 */     this.DEFAULT_EDIT_COMMIT_HANDLER = (paramCellEditEvent -> {
/*     */         int i = paramCellEditEvent.getTablePosition().getRow();
/*     */         ObservableList<Object> observableList = paramCellEditEvent.getTableView().getItems();
/*     */         if (observableList == null || i < 0 || i >= observableList.size()) {
/*     */           return;
/*     */         }
/*     */         S s = (S)observableList.get(i);
/*     */         ObservableValue<T> observableValue = getCellObservableValue(s);
/*     */         if (observableValue instanceof WritableValue) {
/*     */           ((WritableValue)observableValue).setValue(paramCellEditEvent.getNewValue());
/*     */         }
/*     */       });
/* 304 */     this.columnsListener = (paramChange -> {
/*     */         while (paramChange.next()) {
/*     */           for (TableColumn tableColumn : paramChange.getRemoved()) {
/*     */             if (getColumns().contains(tableColumn)) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/*     */             tableColumn.setTableView((TableView)null);
/*     */ 
/*     */             
/*     */             tableColumn.setParentColumn(null);
/*     */           } 
/*     */ 
/*     */           
/*     */           for (TableColumn tableColumn : paramChange.getAddedSubList()) {
/*     */             tableColumn.setTableView(getTableView());
/*     */           }
/*     */ 
/*     */           
/*     */           updateColumnWidths();
/*     */         } 
/*     */       });
/*     */     
/* 328 */     this.weakColumnsListener = new WeakListChangeListener<>(this.columnsListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 340 */     this.columns = FXCollections.observableArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 354 */     this.tableView = new ReadOnlyObjectWrapper<>(this, "tableView");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 426 */     this.cellFactory = (ObjectProperty)new SimpleObjectProperty<Callback<TableColumn<S, Callback<TableColumn<S, T>, TableCell<S, T>>>, TableCell<S, Callback<TableColumn<S, T>, TableCell<S, T>>>>>(this, "cellFactory", DEFAULT_CELL_FACTORY)
/*     */       {
/*     */         protected void invalidated()
/*     */         {
/* 430 */           TableView tableView = TableColumn.this.getTableView();
/* 431 */           if (tableView == null)
/* 432 */             return;  ObservableMap<Object, Object> observableMap = tableView.getProperties();
/* 433 */           if (observableMap.containsKey("recreateKey")) {
/* 434 */             observableMap.remove("recreateKey");
/*     */           }
/* 436 */           observableMap.put("recreateKey", Boolean.TRUE);
/*     */         }
/*     */       }; getStyleClass().add("table-column"); setOnEditCommit(this.DEFAULT_EDIT_COMMIT_HANDLER); getColumns().addListener(this.weakColumnsListener); tableViewProperty().addListener(paramObservable -> { for (TableColumn<S, ?> tableColumn : getColumns())
/*     */             tableColumn.setTableView(getTableView()); 
/*     */         });
/* 441 */   } public TableColumn(String paramString) { this(); setText(paramString); } public final ReadOnlyObjectProperty<TableView<S>> tableViewProperty() { return this.tableView.getReadOnlyProperty(); } final void setTableView(TableView<S> paramTableView) { this.tableView.set(paramTableView); } public final void setCellFactory(Callback<TableColumn<S, T>, TableCell<S, T>> paramCallback) { this.cellFactory.set(paramCallback); }
/*     */   public final TableView<S> getTableView() { return this.tableView.get(); }
/*     */   public final void setCellValueFactory(Callback<CellDataFeatures<S, T>, ObservableValue<T>> paramCallback) { cellValueFactoryProperty().set(paramCallback); }
/*     */   public final Callback<CellDataFeatures<S, T>, ObservableValue<T>> getCellValueFactory() { return (this.cellValueFactory == null) ? null : this.cellValueFactory.get(); }
/* 445 */   public final ObjectProperty<Callback<CellDataFeatures<S, T>, ObservableValue<T>>> cellValueFactoryProperty() { if (this.cellValueFactory == null) this.cellValueFactory = new SimpleObjectProperty<>(this, "cellValueFactory");  return this.cellValueFactory; } public final Callback<TableColumn<S, T>, TableCell<S, T>> getCellFactory() { return this.cellFactory.get(); }
/*     */ 
/*     */   
/*     */   public final ObjectProperty<Callback<TableColumn<S, T>, TableCell<S, T>>> cellFactoryProperty() {
/* 449 */     return this.cellFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<SortType> sortTypeProperty() {
/* 465 */     if (this.sortType == null) {
/* 466 */       this.sortType = new SimpleObjectProperty<>(this, "sortType", SortType.ASCENDING);
/*     */     }
/* 468 */     return this.sortType;
/*     */   }
/*     */   public final void setSortType(SortType paramSortType) {
/* 471 */     sortTypeProperty().set(paramSortType);
/*     */   }
/*     */   public final SortType getSortType() {
/* 474 */     return (this.sortType == null) ? SortType.ASCENDING : this.sortType.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOnEditStart(EventHandler<CellEditEvent<S, T>> paramEventHandler) {
/* 482 */     onEditStartProperty().set(paramEventHandler);
/*     */   }
/*     */   public final EventHandler<CellEditEvent<S, T>> getOnEditStart() {
/* 485 */     return (this.onEditStart == null) ? null : this.onEditStart.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditStartProperty() {
/* 493 */     if (this.onEditStart == null) {
/* 494 */       this.onEditStart = (ObjectProperty)new SimpleObjectProperty<EventHandler<CellEditEvent<S, EventHandler<CellEditEvent<S, T>>>>>(this, "onEditStart") {
/*     */           protected void invalidated() {
/* 496 */             TableColumn.this.eventHandlerManager.setEventHandler(TableColumn.editStartEvent(), get());
/*     */           }
/*     */         };
/*     */     }
/* 500 */     return this.onEditStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOnEditCommit(EventHandler<CellEditEvent<S, T>> paramEventHandler) {
/* 507 */     onEditCommitProperty().set(paramEventHandler);
/*     */   }
/*     */   public final EventHandler<CellEditEvent<S, T>> getOnEditCommit() {
/* 510 */     return (this.onEditCommit == null) ? null : this.onEditCommit.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCommitProperty() {
/* 518 */     if (this.onEditCommit == null) {
/* 519 */       this.onEditCommit = (ObjectProperty)new SimpleObjectProperty<EventHandler<CellEditEvent<S, EventHandler<CellEditEvent<S, T>>>>>(this, "onEditCommit") {
/*     */           protected void invalidated() {
/* 521 */             TableColumn.this.eventHandlerManager.setEventHandler(TableColumn.editCommitEvent(), get());
/*     */           }
/*     */         };
/*     */     }
/* 525 */     return this.onEditCommit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOnEditCancel(EventHandler<CellEditEvent<S, T>> paramEventHandler) {
/* 532 */     onEditCancelProperty().set(paramEventHandler);
/*     */   }
/*     */   public final EventHandler<CellEditEvent<S, T>> getOnEditCancel() {
/* 535 */     return (this.onEditCancel == null) ? null : this.onEditCancel.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCancelProperty() {
/* 542 */     if (this.onEditCancel == null) {
/* 543 */       this.onEditCancel = (ObjectProperty)new SimpleObjectProperty<EventHandler<CellEditEvent<S, EventHandler<CellEditEvent<S, T>>>>>(this, "onEditCancel") {
/*     */           protected void invalidated() {
/* 545 */             TableColumn.this.eventHandlerManager.setEventHandler(TableColumn.editCancelEvent(), get());
/*     */           }
/*     */         };
/*     */     }
/* 549 */     return this.onEditCancel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<TableColumn<S, ?>> getColumns() {
/* 562 */     return this.columns;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ObservableValue<T> getCellObservableValue(int paramInt) {
/* 567 */     if (paramInt < 0) return null;
/*     */ 
/*     */     
/* 570 */     TableView<S> tableView = getTableView();
/* 571 */     if (tableView == null || tableView.getItems() == null) return null;
/*     */ 
/*     */     
/* 574 */     ObservableList<S> observableList = tableView.getItems();
/* 575 */     if (paramInt >= observableList.size()) return null;
/*     */     
/* 577 */     S s = observableList.get(paramInt);
/* 578 */     return getCellObservableValue(s);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableValue<T> getCellObservableValue(S paramS) {
/* 584 */     Callback<CellDataFeatures<S, T>, ObservableValue<T>> callback = getCellValueFactory();
/* 585 */     if (callback == null) return null;
/*     */ 
/*     */     
/* 588 */     TableView<S> tableView = getTableView();
/* 589 */     if (tableView == null) return null;
/*     */ 
/*     */     
/* 592 */     CellDataFeatures<S, Object> cellDataFeatures = new CellDataFeatures<>(tableView, this, paramS);
/* 593 */     return callback.call(cellDataFeatures);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTypeSelector() {
/* 613 */     return "TableColumn";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Styleable getStyleableParent() {
/* 623 */     return getTableView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 632 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 641 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getStyleableNode() {
/* 646 */     if (!(getTableView().getSkin() instanceof TableViewSkin)) return null; 
/* 647 */     TableViewSkin tableViewSkin = (TableViewSkin)getTableView().getSkin();
/*     */     
/* 649 */     TableHeaderRow tableHeaderRow = null;
/* 650 */     for (Node node : tableViewSkin.getChildren()) {
/* 651 */       if (node instanceof TableHeaderRow) {
/* 652 */         tableHeaderRow = (TableHeaderRow)node;
/*     */       }
/*     */     } 
/*     */     
/* 656 */     NestedTableColumnHeader nestedTableColumnHeader = null;
/* 657 */     for (Node node : tableHeaderRow.getChildren()) {
/* 658 */       if (node instanceof NestedTableColumnHeader) {
/* 659 */         nestedTableColumnHeader = (NestedTableColumnHeader)node;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 664 */     return (Node)scan((TableColumnHeader)nestedTableColumnHeader);
/*     */   }
/*     */ 
/*     */   
/*     */   private TableColumnHeader scan(TableColumnHeader paramTableColumnHeader) {
/* 669 */     if (equals(paramTableColumnHeader.getTableColumn())) {
/* 670 */       return paramTableColumnHeader;
/*     */     }
/*     */     
/* 673 */     if (paramTableColumnHeader instanceof NestedTableColumnHeader) {
/* 674 */       NestedTableColumnHeader nestedTableColumnHeader = (NestedTableColumnHeader)paramTableColumnHeader;
/* 675 */       for (byte b = 0; b < nestedTableColumnHeader.getColumnHeaders().size(); b++) {
/* 676 */         TableColumnHeader tableColumnHeader = scan(nestedTableColumnHeader.getColumnHeaders().get(b));
/* 677 */         if (tableColumnHeader != null) {
/* 678 */           return tableColumnHeader;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 683 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CellDataFeatures<S, T>
/*     */   {
/*     */     private final TableView<S> tableView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TableColumn<S, T> tableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final S value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CellDataFeatures(TableView<S> param1TableView, TableColumn<S, T> param1TableColumn, S param1S) {
/* 718 */       this.tableView = param1TableView;
/* 719 */       this.tableColumn = param1TableColumn;
/* 720 */       this.value = param1S;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public S getValue() {
/* 728 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TableColumn<S, T> getTableColumn() {
/* 736 */       return this.tableColumn;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TableView<S> getTableView() {
/* 744 */       return this.tableView;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CellEditEvent<S, T>
/*     */     extends Event
/*     */   {
/*     */     private static final long serialVersionUID = -609964441682677579L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 763 */     public static final EventType<?> ANY = TableColumn.EDIT_ANY_EVENT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final T newValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final transient TablePosition<S, T> pos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CellEditEvent(TableView<S> param1TableView, TablePosition<S, T> param1TablePosition, EventType<CellEditEvent<S, T>> param1EventType, T param1T) {
/* 784 */       super(param1TableView, Event.NULL_SOURCE_TARGET, (EventType)param1EventType);
/*     */       
/* 786 */       if (param1TableView == null) {
/* 787 */         throw new NullPointerException("TableView can not be null");
/*     */       }
/* 789 */       this.pos = param1TablePosition;
/* 790 */       this.newValue = param1T;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TableView<S> getTableView() {
/* 798 */       return this.pos.getTableView();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TableColumn<S, T> getTableColumn() {
/* 807 */       return this.pos.getTableColumn();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TablePosition<S, T> getTablePosition() {
/* 815 */       return this.pos;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T getNewValue() {
/* 827 */       return this.newValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T getOldValue() {
/* 839 */       S s = getRowValue();
/* 840 */       if (s == null || this.pos.getTableColumn() == null) {
/* 841 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 845 */       return this.pos.getTableColumn().getCellData(s);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public S getRowValue() {
/* 856 */       ObservableList<S> observableList = getTableView().getItems();
/* 857 */       if (observableList == null) return null;
/*     */       
/* 859 */       int i = this.pos.getRow();
/* 860 */       if (i < 0 || i >= observableList.size()) return null;
/*     */       
/* 862 */       return observableList.get(i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum SortType
/*     */   {
/* 875 */     ASCENDING,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 880 */     DESCENDING;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TableColumn.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */