/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.DefaultProperty;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleIntegerProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableIntegerProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.PaginationSkin;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @DefaultProperty("pages")
/*     */ public class Pagination
/*     */   extends Control
/*     */ {
/*     */   private static final int DEFAULT_MAX_PAGE_INDICATOR_COUNT = 10;
/*     */   public static final String STYLE_CLASS_BULLET = "bullet";
/*     */   public static final int INDETERMINATE = 2147483647;
/*     */   private int oldMaxPageIndicatorCount;
/*     */   private IntegerProperty maxPageIndicatorCount;
/*     */   private int oldPageCount;
/*     */   private IntegerProperty pageCount;
/*     */   private final IntegerProperty currentPageIndex;
/*     */   private ObjectProperty<Callback<Integer, Node>> pageFactory;
/*     */   private static final String DEFAULT_STYLE_CLASS = "pagination";
/*     */   
/*     */   public Pagination(int paramInt) {
/*     */     this(paramInt, 0);
/*     */   }
/*     */   
/*     */   public Pagination() {
/*     */     this(2147483647, 0);
/*     */   }
/*     */   
/*     */   public final void setMaxPageIndicatorCount(int paramInt) {
/*     */     maxPageIndicatorCountProperty().set(paramInt);
/*     */   }
/*     */   
/*     */   public final int getMaxPageIndicatorCount() {
/*     */     return (this.maxPageIndicatorCount == null) ? 10 : this.maxPageIndicatorCount.get();
/*     */   }
/*     */   
/*     */   public final IntegerProperty maxPageIndicatorCountProperty() {
/*     */     if (this.maxPageIndicatorCount == null)
/*     */       this.maxPageIndicatorCount = new StyleableIntegerProperty(10)
/*     */         {
/*     */           protected void invalidated() {
/*     */             if (!Pagination.this.maxPageIndicatorCount.isBound()) {
/*     */               if (Pagination.this.getMaxPageIndicatorCount() < 1 || Pagination.this.getMaxPageIndicatorCount() > Pagination.this.getPageCount())
/*     */                 Pagination.this.setMaxPageIndicatorCount(Pagination.this.oldMaxPageIndicatorCount); 
/*     */               Pagination.this.oldMaxPageIndicatorCount = Pagination.this.getMaxPageIndicatorCount();
/*     */             } 
/*     */           }
/*     */           
/*     */           public CssMetaData<Pagination, Number> getCssMetaData() {
/*     */             return Pagination.StyleableProperties.MAX_PAGE_INDICATOR_COUNT;
/*     */           }
/*     */           
/*     */           public Object getBean() {
/*     */             return Pagination.this;
/*     */           }
/*     */           
/*     */           public String getName() {
/*     */             return "maxPageIndicatorCount";
/*     */           }
/*     */         }; 
/*     */     return this.maxPageIndicatorCount;
/*     */   }
/*     */   
/*     */   public Pagination(int paramInt1, int paramInt2) {
/* 158 */     this.oldMaxPageIndicatorCount = 10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     this.oldPageCount = Integer.MAX_VALUE;
/* 218 */     this.pageCount = new SimpleIntegerProperty(this, "pageCount", 2147483647) {
/*     */         protected void invalidated() {
/* 220 */           if (!Pagination.this.pageCount.isBound()) {
/* 221 */             if (Pagination.this.getPageCount() < 1) {
/* 222 */               Pagination.this.setPageCount(Pagination.this.oldPageCount);
/*     */             }
/* 224 */             Pagination.this.oldPageCount = Pagination.this.getPageCount();
/*     */           } 
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     this.currentPageIndex = new SimpleIntegerProperty(this, "currentPageIndex", 0) {
/*     */         protected void invalidated() {
/* 254 */           if (!Pagination.this.currentPageIndex.isBound()) {
/* 255 */             if (Pagination.this.getCurrentPageIndex() < 0) {
/* 256 */               Pagination.this.setCurrentPageIndex(0);
/* 257 */             } else if (Pagination.this.getCurrentPageIndex() > Pagination.this.getPageCount() - 1) {
/* 258 */               Pagination.this.setCurrentPageIndex(Pagination.this.getPageCount() - 1);
/*     */             } 
/*     */           }
/*     */         }
/*     */ 
/*     */         
/*     */         public void bind(ObservableValue<? extends Number> param1ObservableValue) {
/* 265 */           throw new UnsupportedOperationException("currentPageIndex supports only bidirectional binding");
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 297 */     this.pageFactory = new SimpleObjectProperty<>(this, "pageFactory");
/*     */     getStyleClass().setAll(new String[] { "pagination" });
/*     */     setAccessibleRole(AccessibleRole.PAGINATION);
/*     */     setPageCount(paramInt1);
/*     */     setCurrentPageIndex(paramInt2);
/*     */   }
/*     */   public final void setPageCount(int paramInt) { this.pageCount.set(paramInt); } public final int getPageCount() { return this.pageCount.get(); } public final void setPageFactory(Callback<Integer, Node> paramCallback) {
/* 304 */     this.pageFactory.set(paramCallback);
/*     */   }
/*     */   public final IntegerProperty pageCountProperty() {
/*     */     return this.pageCount;
/*     */   }
/*     */   public final Callback<Integer, Node> getPageFactory() {
/* 310 */     return this.pageFactory.get();
/*     */   }
/*     */   public final void setCurrentPageIndex(int paramInt) {
/*     */     this.currentPageIndex.set(paramInt);
/*     */   }
/*     */   public final int getCurrentPageIndex() {
/*     */     return this.currentPageIndex.get();
/*     */   }
/*     */   
/*     */   public final IntegerProperty currentPageIndexProperty() {
/*     */     return this.currentPageIndex;
/*     */   }
/*     */   
/*     */   public final ObjectProperty<Callback<Integer, Node>> pageFactoryProperty() {
/* 324 */     return this.pageFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 335 */     return (Skin<?>)new PaginationSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 347 */     private static final CssMetaData<Pagination, Number> MAX_PAGE_INDICATOR_COUNT = new CssMetaData<Pagination, Number>("-fx-max-page-indicator-count", 
/*     */         
/* 349 */         SizeConverter.getInstance(), Integer.valueOf(10))
/*     */       {
/*     */         public boolean isSettable(Pagination param2Pagination)
/*     */         {
/* 353 */           return (param2Pagination.maxPageIndicatorCount == null || !param2Pagination.maxPageIndicatorCount.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(Pagination param2Pagination) {
/* 358 */           return (StyleableProperty<Number>)param2Pagination.maxPageIndicatorCountProperty();
/*     */         }
/*     */       };
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 364 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 365 */       arrayList.add(MAX_PAGE_INDICATOR_COUNT);
/* 366 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 376 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 385 */     return getClassCssMetaData();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Pagination.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */