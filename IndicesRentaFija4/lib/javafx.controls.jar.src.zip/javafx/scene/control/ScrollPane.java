/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.DefaultProperty;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.css.converter.EnumConverter;
/*     */ import javafx.geometry.BoundingBox;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.ScrollPaneSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @DefaultProperty("content")
/*     */ public class ScrollPane
/*     */   extends Control
/*     */ {
/*     */   private ObjectProperty<ScrollBarPolicy> hbarPolicy;
/*     */   private ObjectProperty<ScrollBarPolicy> vbarPolicy;
/*     */   private ObjectProperty<Node> content;
/*     */   private DoubleProperty hvalue;
/*     */   private DoubleProperty vvalue;
/*     */   private DoubleProperty hmin;
/*     */   private DoubleProperty vmin;
/*     */   private DoubleProperty hmax;
/*     */   private DoubleProperty vmax;
/*     */   private BooleanProperty fitToWidth;
/*     */   private BooleanProperty fitToHeight;
/*     */   private BooleanProperty pannable;
/*     */   private DoubleProperty prefViewportWidth;
/*     */   private DoubleProperty prefViewportHeight;
/*     */   private DoubleProperty minViewportWidth;
/*     */   private DoubleProperty minViewportHeight;
/*     */   private ObjectProperty<Bounds> viewportBounds;
/*     */   private static final String DEFAULT_STYLE_CLASS = "scroll-pane";
/*     */   
/*     */   public ScrollPane() {
/* 105 */     getStyleClass().setAll(new String[] { "scroll-pane" });
/* 106 */     setAccessibleRole(AccessibleRole.SCROLL_PANE);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     ((StyleableProperty<Boolean>)focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScrollPane(Node paramNode) {
/* 120 */     this();
/* 121 */     setContent(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setHbarPolicy(ScrollBarPolicy paramScrollBarPolicy) {
/* 134 */     hbarPolicyProperty().set(paramScrollBarPolicy);
/*     */   }
/*     */   
/*     */   public final ScrollBarPolicy getHbarPolicy() {
/* 138 */     return (this.hbarPolicy == null) ? ScrollBarPolicy.AS_NEEDED : this.hbarPolicy.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<ScrollBarPolicy> hbarPolicyProperty() {
/* 142 */     if (this.hbarPolicy == null) {
/* 143 */       this.hbarPolicy = new StyleableObjectProperty<ScrollBarPolicy>(ScrollBarPolicy.AS_NEEDED)
/*     */         {
/*     */           public CssMetaData<ScrollPane, ScrollPane.ScrollBarPolicy> getCssMetaData()
/*     */           {
/* 147 */             return ScrollPane.StyleableProperties.HBAR_POLICY;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 152 */             return ScrollPane.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 157 */             return "hbarPolicy";
/*     */           }
/*     */         };
/*     */     }
/* 161 */     return this.hbarPolicy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setVbarPolicy(ScrollBarPolicy paramScrollBarPolicy) {
/* 168 */     vbarPolicyProperty().set(paramScrollBarPolicy);
/*     */   }
/*     */   
/*     */   public final ScrollBarPolicy getVbarPolicy() {
/* 172 */     return (this.vbarPolicy == null) ? ScrollBarPolicy.AS_NEEDED : this.vbarPolicy.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<ScrollBarPolicy> vbarPolicyProperty() {
/* 176 */     if (this.vbarPolicy == null) {
/* 177 */       this.vbarPolicy = new StyleableObjectProperty<ScrollBarPolicy>(ScrollBarPolicy.AS_NEEDED)
/*     */         {
/*     */           public CssMetaData<ScrollPane, ScrollPane.ScrollBarPolicy> getCssMetaData()
/*     */           {
/* 181 */             return ScrollPane.StyleableProperties.VBAR_POLICY;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 186 */             return ScrollPane.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 191 */             return "vbarPolicy";
/*     */           }
/*     */         };
/*     */     }
/* 195 */     return this.vbarPolicy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setContent(Node paramNode) {
/* 203 */     contentProperty().set(paramNode);
/*     */   }
/*     */   
/*     */   public final Node getContent() {
/* 207 */     return (this.content == null) ? null : this.content.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<Node> contentProperty() {
/* 211 */     if (this.content == null) {
/* 212 */       this.content = new SimpleObjectProperty<>(this, "content");
/*     */     }
/* 214 */     return this.content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setHvalue(double paramDouble) {
/* 233 */     hvalueProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getHvalue() {
/* 237 */     return (this.hvalue == null) ? 0.0D : this.hvalue.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty hvalueProperty() {
/* 241 */     if (this.hvalue == null) {
/* 242 */       this.hvalue = new SimpleDoubleProperty(this, "hvalue");
/*     */     }
/* 244 */     return this.hvalue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setVvalue(double paramDouble) {
/* 263 */     vvalueProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getVvalue() {
/* 267 */     return (this.vvalue == null) ? 0.0D : this.vvalue.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty vvalueProperty() {
/* 271 */     if (this.vvalue == null) {
/* 272 */       this.vvalue = new SimpleDoubleProperty(this, "vvalue");
/*     */     }
/* 274 */     return this.vvalue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setHmin(double paramDouble) {
/* 283 */     hminProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getHmin() {
/* 287 */     return (this.hmin == null) ? 0.0D : this.hmin.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty hminProperty() {
/* 291 */     if (this.hmin == null) {
/* 292 */       this.hmin = new SimpleDoubleProperty(this, "hmin", 0.0D);
/*     */     }
/* 294 */     return this.hmin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setVmin(double paramDouble) {
/* 303 */     vminProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getVmin() {
/* 307 */     return (this.vmin == null) ? 0.0D : this.vmin.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty vminProperty() {
/* 311 */     if (this.vmin == null) {
/* 312 */       this.vmin = new SimpleDoubleProperty(this, "vmin", 0.0D);
/*     */     }
/* 314 */     return this.vmin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setHmax(double paramDouble) {
/* 323 */     hmaxProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getHmax() {
/* 327 */     return (this.hmax == null) ? 1.0D : this.hmax.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty hmaxProperty() {
/* 331 */     if (this.hmax == null) {
/* 332 */       this.hmax = new SimpleDoubleProperty(this, "hmax", 1.0D);
/*     */     }
/* 334 */     return this.hmax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setVmax(double paramDouble) {
/* 343 */     vmaxProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getVmax() {
/* 347 */     return (this.vmax == null) ? 1.0D : this.vmax.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty vmaxProperty() {
/* 351 */     if (this.vmax == null) {
/* 352 */       this.vmax = new SimpleDoubleProperty(this, "vmax", 1.0D);
/*     */     }
/* 354 */     return this.vmax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setFitToWidth(boolean paramBoolean) {
/* 363 */     fitToWidthProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isFitToWidth() {
/* 366 */     return (this.fitToWidth == null) ? false : this.fitToWidth.get();
/*     */   }
/*     */   public final BooleanProperty fitToWidthProperty() {
/* 369 */     if (this.fitToWidth == null) {
/* 370 */       this.fitToWidth = new StyleableBooleanProperty(false) {
/*     */           public void invalidated() {
/* 372 */             ScrollPane.this.pseudoClassStateChanged(ScrollPane.FIT_TO_WIDTH_PSEUDOCLASS_STATE, get());
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<ScrollPane, Boolean> getCssMetaData() {
/* 377 */             return ScrollPane.StyleableProperties.FIT_TO_WIDTH;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 382 */             return ScrollPane.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 387 */             return "fitToWidth";
/*     */           }
/*     */         };
/*     */     }
/* 391 */     return this.fitToWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setFitToHeight(boolean paramBoolean) {
/* 400 */     fitToHeightProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isFitToHeight() {
/* 403 */     return (this.fitToHeight == null) ? false : this.fitToHeight.get();
/*     */   }
/*     */   public final BooleanProperty fitToHeightProperty() {
/* 406 */     if (this.fitToHeight == null) {
/* 407 */       this.fitToHeight = new StyleableBooleanProperty(false) {
/*     */           public void invalidated() {
/* 409 */             ScrollPane.this.pseudoClassStateChanged(ScrollPane.FIT_TO_HEIGHT_PSEUDOCLASS_STATE, get());
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<ScrollPane, Boolean> getCssMetaData() {
/* 414 */             return ScrollPane.StyleableProperties.FIT_TO_HEIGHT;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 419 */             return ScrollPane.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 424 */             return "fitToHeight";
/*     */           }
/*     */         };
/*     */     }
/* 428 */     return this.fitToHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setPannable(boolean paramBoolean) {
/* 439 */     pannableProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isPannable() {
/* 442 */     return (this.pannable == null) ? false : this.pannable.get();
/*     */   }
/*     */   public final BooleanProperty pannableProperty() {
/* 445 */     if (this.pannable == null) {
/* 446 */       this.pannable = new StyleableBooleanProperty(false) {
/*     */           public void invalidated() {
/* 448 */             ScrollPane.this.pseudoClassStateChanged(ScrollPane.PANNABLE_PSEUDOCLASS_STATE, get());
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<ScrollPane, Boolean> getCssMetaData() {
/* 453 */             return ScrollPane.StyleableProperties.PANNABLE;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 458 */             return ScrollPane.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 463 */             return "pannable";
/*     */           }
/*     */         };
/*     */     }
/* 467 */     return this.pannable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setPrefViewportWidth(double paramDouble) {
/* 479 */     prefViewportWidthProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getPrefViewportWidth() {
/* 483 */     return (this.prefViewportWidth == null) ? 0.0D : this.prefViewportWidth.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty prefViewportWidthProperty() {
/* 487 */     if (this.prefViewportWidth == null) {
/* 488 */       this.prefViewportWidth = new SimpleDoubleProperty(this, "prefViewportWidth");
/*     */     }
/* 490 */     return this.prefViewportWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setPrefViewportHeight(double paramDouble) {
/* 501 */     prefViewportHeightProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getPrefViewportHeight() {
/* 505 */     return (this.prefViewportHeight == null) ? 0.0D : this.prefViewportHeight.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty prefViewportHeightProperty() {
/* 509 */     if (this.prefViewportHeight == null) {
/* 510 */       this.prefViewportHeight = new SimpleDoubleProperty(this, "prefViewportHeight");
/*     */     }
/* 512 */     return this.prefViewportHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMinViewportWidth(double paramDouble) {
/* 526 */     minViewportWidthProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getMinViewportWidth() {
/* 530 */     return (this.minViewportWidth == null) ? 0.0D : this.minViewportWidth.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty minViewportWidthProperty() {
/* 534 */     if (this.minViewportWidth == null) {
/* 535 */       this.minViewportWidth = new SimpleDoubleProperty(this, "minViewportWidth");
/*     */     }
/* 537 */     return this.minViewportWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMinViewportHeight(double paramDouble) {
/* 550 */     minViewportHeightProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getMinViewportHeight() {
/* 554 */     return (this.minViewportHeight == null) ? 0.0D : this.minViewportHeight.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty minViewportHeightProperty() {
/* 558 */     if (this.minViewportHeight == null) {
/* 559 */       this.minViewportHeight = new SimpleDoubleProperty(this, "minViewportHeight");
/*     */     }
/* 561 */     return this.minViewportHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setViewportBounds(Bounds paramBounds) {
/* 571 */     viewportBoundsProperty().set(paramBounds);
/*     */   }
/*     */   
/*     */   public final Bounds getViewportBounds() {
/* 575 */     return (this.viewportBounds == null) ? new BoundingBox(0.0D, 0.0D, 0.0D, 0.0D) : this.viewportBounds.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<Bounds> viewportBoundsProperty() {
/* 579 */     if (this.viewportBounds == null) {
/* 580 */       this.viewportBounds = new SimpleObjectProperty<>(this, "viewportBounds", new BoundingBox(0.0D, 0.0D, 0.0D, 0.0D));
/*     */     }
/* 582 */     return this.viewportBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 634 */     return (Skin<?>)new ScrollPaneSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 652 */     private static final CssMetaData<ScrollPane, ScrollPane.ScrollBarPolicy> HBAR_POLICY = new CssMetaData<ScrollPane, ScrollPane.ScrollBarPolicy>("-fx-hbar-policy", (StyleConverter)new EnumConverter(ScrollPane.ScrollBarPolicy.class), ScrollPane.ScrollBarPolicy.AS_NEEDED)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean isSettable(ScrollPane param2ScrollPane)
/*     */         {
/* 659 */           return (param2ScrollPane.hbarPolicy == null || !param2ScrollPane.hbarPolicy.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<ScrollPane.ScrollBarPolicy> getStyleableProperty(ScrollPane param2ScrollPane) {
/* 664 */           return (StyleableProperty<ScrollPane.ScrollBarPolicy>)param2ScrollPane.hbarPolicyProperty();
/*     */         }
/*     */       };
/*     */     
/* 668 */     private static final CssMetaData<ScrollPane, ScrollPane.ScrollBarPolicy> VBAR_POLICY = new CssMetaData<ScrollPane, ScrollPane.ScrollBarPolicy>("-fx-vbar-policy", (StyleConverter)new EnumConverter(ScrollPane.ScrollBarPolicy.class), ScrollPane.ScrollBarPolicy.AS_NEEDED)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean isSettable(ScrollPane param2ScrollPane)
/*     */         {
/* 675 */           return (param2ScrollPane.vbarPolicy == null || !param2ScrollPane.vbarPolicy.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<ScrollPane.ScrollBarPolicy> getStyleableProperty(ScrollPane param2ScrollPane) {
/* 680 */           return (StyleableProperty<ScrollPane.ScrollBarPolicy>)param2ScrollPane.vbarPolicyProperty();
/*     */         }
/*     */       };
/*     */     
/* 684 */     private static final CssMetaData<ScrollPane, Boolean> FIT_TO_WIDTH = new CssMetaData<ScrollPane, Boolean>("-fx-fit-to-width", 
/*     */         
/* 686 */         BooleanConverter.getInstance(), Boolean.FALSE)
/*     */       {
/*     */         public boolean isSettable(ScrollPane param2ScrollPane)
/*     */         {
/* 690 */           return (param2ScrollPane.fitToWidth == null || !param2ScrollPane.fitToWidth.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(ScrollPane param2ScrollPane) {
/* 695 */           return (StyleableProperty<Boolean>)param2ScrollPane.fitToWidthProperty();
/*     */         }
/*     */       };
/*     */     
/* 699 */     private static final CssMetaData<ScrollPane, Boolean> FIT_TO_HEIGHT = new CssMetaData<ScrollPane, Boolean>("-fx-fit-to-height", 
/*     */         
/* 701 */         BooleanConverter.getInstance(), Boolean.FALSE)
/*     */       {
/*     */         public boolean isSettable(ScrollPane param2ScrollPane)
/*     */         {
/* 705 */           return (param2ScrollPane.fitToHeight == null || !param2ScrollPane.fitToHeight.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(ScrollPane param2ScrollPane) {
/* 710 */           return (StyleableProperty<Boolean>)param2ScrollPane.fitToHeightProperty();
/*     */         }
/*     */       };
/*     */     
/* 714 */     private static final CssMetaData<ScrollPane, Boolean> PANNABLE = new CssMetaData<ScrollPane, Boolean>("-fx-pannable", 
/*     */         
/* 716 */         BooleanConverter.getInstance(), Boolean.FALSE)
/*     */       {
/*     */         public boolean isSettable(ScrollPane param2ScrollPane)
/*     */         {
/* 720 */           return (param2ScrollPane.pannable == null || !param2ScrollPane.pannable.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(ScrollPane param2ScrollPane) {
/* 725 */           return (StyleableProperty<Boolean>)param2ScrollPane.pannableProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 732 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 733 */       arrayList.add(HBAR_POLICY);
/* 734 */       arrayList.add(VBAR_POLICY);
/* 735 */       arrayList.add(FIT_TO_WIDTH);
/* 736 */       arrayList.add(FIT_TO_HEIGHT);
/* 737 */       arrayList.add(PANNABLE);
/* 738 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 748 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 757 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */   
/* 761 */   private static final PseudoClass PANNABLE_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("pannable");
/*     */   
/* 763 */   private static final PseudoClass FIT_TO_WIDTH_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("fitToWidth");
/*     */   
/* 765 */   private static final PseudoClass FIT_TO_HEIGHT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("fitToHeight");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean getInitialFocusTraversable() {
/* 776 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 789 */     switch (paramAccessibleAttribute) { case CONTENTS:
/* 790 */         return getContent(); }
/* 791 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ScrollBarPolicy
/*     */   {
/* 811 */     NEVER,
/*     */ 
/*     */ 
/*     */     
/* 815 */     ALWAYS,
/*     */ 
/*     */ 
/*     */     
/* 819 */     AS_NEEDED;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ScrollPane.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */