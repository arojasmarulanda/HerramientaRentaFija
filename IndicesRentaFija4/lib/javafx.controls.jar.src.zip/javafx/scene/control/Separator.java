/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.EnumConverter;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.control.skin.SeparatorSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Separator
/*     */   extends Control
/*     */ {
/*     */   private ObjectProperty<Orientation> orientation;
/*     */   private ObjectProperty<HPos> halignment;
/*     */   private ObjectProperty<VPos> valignment;
/*     */   private static final String DEFAULT_STYLE_CLASS = "separator";
/*     */   
/*     */   public Separator() {
/*  84 */     this(Orientation.HORIZONTAL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separator(Orientation paramOrientation) {
/* 122 */     this.orientation = new StyleableObjectProperty<Orientation>(Orientation.HORIZONTAL)
/*     */       {
/*     */         protected void invalidated()
/*     */         {
/* 126 */           boolean bool = (get() == Orientation.VERTICAL) ? true : false;
/* 127 */           Separator.this.pseudoClassStateChanged(Separator.VERTICAL_PSEUDOCLASS_STATE, bool);
/* 128 */           Separator.this.pseudoClassStateChanged(Separator.HORIZONTAL_PSEUDOCLASS_STATE, !bool);
/*     */         }
/*     */ 
/*     */         
/*     */         public CssMetaData<Separator, Orientation> getCssMetaData() {
/* 133 */           return Separator.StyleableProperties.ORIENTATION;
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 138 */           return Separator.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 143 */           return "orientation"; } }; getStyleClass().setAll(new String[] { "separator" }); ((StyleableProperty<Boolean>)focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
/*     */     pseudoClassStateChanged(HORIZONTAL_PSEUDOCLASS_STATE, (paramOrientation != Orientation.VERTICAL));
/*     */     pseudoClassStateChanged(VERTICAL_PSEUDOCLASS_STATE, (paramOrientation == Orientation.VERTICAL));
/* 146 */     ((StyleableProperty<Orientation>)orientationProperty()).applyStyle(null, (paramOrientation != null) ? paramOrientation : Orientation.HORIZONTAL); } public final void setOrientation(Orientation paramOrientation) { this.orientation.set(paramOrientation); }
/* 147 */   public final Orientation getOrientation() { return this.orientation.get(); } public final ObjectProperty<Orientation> orientationProperty() {
/* 148 */     return this.orientation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setHalignment(HPos paramHPos) {
/* 158 */     halignmentProperty().set(paramHPos);
/*     */   }
/*     */   
/*     */   public final HPos getHalignment() {
/* 162 */     return (this.halignment == null) ? HPos.CENTER : this.halignment.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<HPos> halignmentProperty() {
/* 166 */     if (this.halignment == null) {
/* 167 */       this.halignment = new StyleableObjectProperty<HPos>(HPos.CENTER)
/*     */         {
/*     */           public Object getBean()
/*     */           {
/* 171 */             return Separator.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 176 */             return "halignment";
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<Separator, HPos> getCssMetaData() {
/* 181 */             return Separator.StyleableProperties.HALIGNMENT;
/*     */           }
/*     */         };
/*     */     }
/*     */     
/* 186 */     return this.halignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setValignment(VPos paramVPos) {
/* 196 */     valignmentProperty().set(paramVPos);
/*     */   }
/*     */   
/*     */   public final VPos getValignment() {
/* 200 */     return (this.valignment == null) ? VPos.CENTER : this.valignment.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<VPos> valignmentProperty() {
/* 204 */     if (this.valignment == null) {
/* 205 */       this.valignment = new StyleableObjectProperty<VPos>(VPos.CENTER)
/*     */         {
/*     */           public Object getBean()
/*     */           {
/* 209 */             return Separator.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 214 */             return "valignment";
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<Separator, VPos> getCssMetaData() {
/* 219 */             return Separator.StyleableProperties.VALIGNMENT;
/*     */           }
/*     */         };
/*     */     }
/*     */     
/* 224 */     return this.valignment;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 229 */     return (Skin<?>)new SeparatorSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 241 */     private static final CssMetaData<Separator, Orientation> ORIENTATION = new CssMetaData<Separator, Orientation>("-fx-orientation", (StyleConverter)new EnumConverter(Orientation.class), Orientation.HORIZONTAL)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Orientation getInitialValue(Separator param2Separator)
/*     */         {
/* 249 */           return param2Separator.getOrientation();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isSettable(Separator param2Separator) {
/* 254 */           return (param2Separator.orientation == null || !param2Separator.orientation.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Orientation> getStyleableProperty(Separator param2Separator) {
/* 259 */           return (StyleableProperty<Orientation>)param2Separator.orientationProperty();
/*     */         }
/*     */       };
/*     */     
/* 263 */     private static final CssMetaData<Separator, HPos> HALIGNMENT = new CssMetaData<Separator, HPos>("-fx-halignment", (StyleConverter)new EnumConverter(HPos.class), HPos.CENTER)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean isSettable(Separator param2Separator)
/*     */         {
/* 270 */           return (param2Separator.halignment == null || !param2Separator.halignment.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<HPos> getStyleableProperty(Separator param2Separator) {
/* 275 */           return (StyleableProperty<HPos>)param2Separator.halignmentProperty();
/*     */         }
/*     */       };
/*     */     
/* 279 */     private static final CssMetaData<Separator, VPos> VALIGNMENT = new CssMetaData<Separator, VPos>("-fx-valignment", (StyleConverter)new EnumConverter(VPos.class), VPos.CENTER)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean isSettable(Separator param2Separator)
/*     */         {
/* 286 */           return (param2Separator.valignment == null || !param2Separator.valignment.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<VPos> getStyleableProperty(Separator param2Separator) {
/* 291 */           return (StyleableProperty<VPos>)param2Separator.valignmentProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 298 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 299 */       arrayList.add(ORIENTATION);
/* 300 */       arrayList.add(HALIGNMENT);
/* 301 */       arrayList.add(VALIGNMENT);
/* 302 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 312 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 320 */     return getClassCssMetaData();
/*     */   }
/*     */   
/* 323 */   private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
/* 324 */   private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean getInitialFocusTraversable() {
/* 335 */     return Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Separator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */