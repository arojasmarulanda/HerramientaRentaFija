package javafx.scene.control;

public abstract class TableFocusModel<T, TC extends TableColumnBase<T, ?>> extends FocusModel<T> {
  public abstract void focus(int paramInt, TC paramTC);
  
  public abstract boolean isFocused(int paramInt, TC paramTC);
  
  public abstract void focusAboveCell();
  
  public abstract void focusBelowCell();
  
  public abstract void focusLeftCell();
  
  public abstract void focusRightCell();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TableFocusModel.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */