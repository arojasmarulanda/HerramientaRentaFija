/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.application.PlatformImpl;
/*      */ import com.sun.javafx.css.CssError;
/*      */ import com.sun.javafx.css.StyleManager;
/*      */ import com.sun.javafx.logging.PlatformLogger;
/*      */ import com.sun.javafx.scene.NodeHelper;
/*      */ import com.sun.javafx.scene.ParentHelper;
/*      */ import com.sun.javafx.scene.control.Logging;
/*      */ import com.sun.javafx.scene.layout.PaneHelper;
/*      */ import com.sun.javafx.stage.PopupWindowHelper;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import javafx.application.Application;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.DoublePropertyBase;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.StringProperty;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.collections.ObservableSet;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.CssParser;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.StyleableStringProperty;
/*      */ import javafx.css.converter.StringConverter;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Parent;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.layout.Pane;
/*      */ import javafx.stage.PopupWindow;
/*      */ import javafx.stage.Window;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PopupControl
/*      */   extends PopupWindow
/*      */   implements Skinnable, Styleable
/*      */ {
/*      */   public static final double USE_PREF_SIZE = -InfinityD;
/*      */   public static final double USE_COMPUTED_SIZE = -1.0D;
/*      */   protected CSSBridge bridge;
/*      */   private final ObjectProperty<Skin<?>> skin;
/*      */   private String currentSkinClassName;
/*      */   private StringProperty skinClassName;
/*      */   private DoubleProperty minWidth;
/*      */   private DoubleProperty minHeight;
/*      */   private DoubleProperty prefWidth;
/*      */   private DoubleProperty prefHeight;
/*      */   private DoubleProperty maxWidth;
/*      */   private DoubleProperty maxHeight;
/*      */   private double prefWidthCache;
/*      */   private double prefHeightCache;
/*      */   private double minWidthCache;
/*      */   private double minHeightCache;
/*      */   private double maxWidthCache;
/*      */   private double maxHeightCache;
/*      */   private boolean skinSizeComputed;
/*      */   
/*      */   static {
/*   89 */     if (Application.getUserAgentStylesheet() == null) {
/*   90 */       PlatformImpl.setDefaultPlatformUserAgentStylesheet();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final StringProperty idProperty() {
/*      */     return this.bridge.idProperty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setId(String paramString) {
/*      */     idProperty().set(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getId() {
/*      */     return idProperty().get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObservableList<String> getStyleClass() {
/*      */     return this.bridge.getStyleClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setStyle(String paramString) {
/*      */     styleProperty().set(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getStyle() {
/*      */     return styleProperty().get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final StringProperty styleProperty() {
/*      */     return this.bridge.styleProperty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<Skin<?>> skinProperty() {
/*      */     return this.skin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setSkin(Skin<?> paramSkin) {
/*      */     skinProperty().setValue(paramSkin);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Skin<?> getSkin() {
/*      */     return skinProperty().getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private StringProperty skinClassNameProperty() {
/*      */     if (this.skinClassName == null) {
/*      */       this.skinClassName = new StyleableStringProperty()
/*      */         {
/*      */           public void set(String param1String) {
/*      */             if (param1String == null || param1String.isEmpty() || param1String.equals(get())) {
/*      */               return;
/*      */             }
/*      */             super.set(param1String);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void invalidated() {
/*      */             if (get() != null && !get().equals(PopupControl.this.currentSkinClassName)) {
/*      */               Control.loadSkinClass(PopupControl.this, get());
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*      */             return PopupControl.this;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public String getName() {
/*      */             return "skinClassName";
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public CssMetaData<PopupControl.CSSBridge, String> getCssMetaData() {
/*      */             return PopupControl.SKIN;
/*      */           }
/*      */         };
/*      */     }
/*      */     return this.skinClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Node getSkinNode() {
/*      */     return (getSkin() == null) ? null : getSkin().getNode();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public PopupControl() {
/*  221 */     this.skin = new ObjectPropertyBase<Skin<?>>()
/*      */       {
/*      */         private Skin<?> oldValue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void set(Skin<?> param1Skin) {
/*  231 */           if ((param1Skin == null) ? (this.oldValue == null) : (this.oldValue != null && param1Skin
/*      */             
/*  233 */             .getClass().equals(this.oldValue.getClass()))) {
/*      */             return;
/*      */           }
/*  236 */           super.set(param1Skin);
/*      */         }
/*      */ 
/*      */         
/*      */         protected void invalidated() {
/*  241 */           Skin<?> skin = get();
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  246 */           PopupControl.this.currentSkinClassName = (skin == null) ? null : skin.getClass().getName();
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  251 */           PopupControl.this.skinClassNameProperty().set(PopupControl.this.currentSkinClassName);
/*      */ 
/*      */ 
/*      */           
/*  255 */           if (this.oldValue != null) {
/*  256 */             this.oldValue.dispose();
/*      */           }
/*      */ 
/*      */           
/*  260 */           this.oldValue = getValue();
/*      */           
/*  262 */           PopupControl.this.prefWidthCache = -1.0D;
/*  263 */           PopupControl.this.prefHeightCache = -1.0D;
/*  264 */           PopupControl.this.minWidthCache = -1.0D;
/*  265 */           PopupControl.this.minHeightCache = -1.0D;
/*  266 */           PopupControl.this.maxWidthCache = -1.0D;
/*  267 */           PopupControl.this.maxHeightCache = -1.0D;
/*  268 */           PopupControl.this.skinSizeComputed = false;
/*      */           
/*  270 */           Node node = PopupControl.this.getSkinNode();
/*  271 */           if (node != null) {
/*  272 */             PopupControl.this.bridge.getChildren().setAll(new Node[] { node });
/*      */           } else {
/*  274 */             PopupControl.this.bridge.getChildren().clear();
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  282 */           NodeHelper.reapplyCSS(PopupControl.this.bridge);
/*      */ 
/*      */           
/*  285 */           PlatformLogger platformLogger = Logging.getControlsLogger();
/*  286 */           if (platformLogger.isLoggable(PlatformLogger.Level.FINEST)) {
/*  287 */             platformLogger.finest("Stored skin[" + getValue() + "] on " + this);
/*      */           }
/*      */         }
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  293 */           return PopupControl.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  298 */           return "skin";
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */     
/*  304 */     this.currentSkinClassName = null;
/*      */ 
/*      */ 
/*      */     
/*  308 */     this.skinClassName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  817 */     this.prefWidthCache = -1.0D;
/*  818 */     this.prefHeightCache = -1.0D;
/*  819 */     this.minWidthCache = -1.0D;
/*  820 */     this.minHeightCache = -1.0D;
/*  821 */     this.maxWidthCache = -1.0D;
/*  822 */     this.maxHeightCache = -1.0D;
/*  823 */     this.skinSizeComputed = false; this.bridge = new CSSBridge();
/*      */     setAnchorLocation(PopupWindow.AnchorLocation.CONTENT_TOP_LEFT);
/*      */     PopupWindowHelper.getContent(this).add(this.bridge);
/*      */   } public final void setMinWidth(double paramDouble) { minWidthProperty().set(paramDouble); } public final double getMinWidth() { return (this.minWidth == null) ? -1.0D : this.minWidth.get(); }
/*      */   public final DoubleProperty minWidthProperty() { if (this.minWidth == null)
/*      */       this.minWidth = new DoublePropertyBase(-1.0D) { public void invalidated() { if (PopupControl.this.isShowing())
/*      */               PopupControl.this.bridge.requestLayout();  }
/*      */           public Object getBean() { return PopupControl.this; }
/*      */           public String getName() { return "minWidth"; } }
/*      */         ; 
/*      */     return this.minWidth; }
/*      */   public final void setMinHeight(double paramDouble) { minHeightProperty().set(paramDouble); }
/*  835 */   public final double minWidth(double paramDouble) { double d = getMinWidth();
/*  836 */     if (d == -1.0D) {
/*  837 */       if (this.minWidthCache == -1.0D) this.minWidthCache = recalculateMinWidth(paramDouble); 
/*  838 */       return this.minWidthCache;
/*  839 */     }  if (d == Double.NEGATIVE_INFINITY) {
/*  840 */       return prefWidth(paramDouble);
/*      */     }
/*  842 */     return d; }
/*      */   public final double getMinHeight() { return (this.minHeight == null) ? -1.0D : this.minHeight.get(); }
/*      */   public final DoubleProperty minHeightProperty() { if (this.minHeight == null)
/*      */       this.minHeight = new DoublePropertyBase(-1.0D)
/*      */         {
/*      */           public void invalidated() { if (PopupControl.this.isShowing())
/*      */               PopupControl.this.bridge.requestLayout();  }
/*      */           public Object getBean() { return PopupControl.this; }
/*      */           public String getName() { return "minHeight"; }
/*      */         }; 
/*      */     return this.minHeight; }
/*      */   public void setMinSize(double paramDouble1, double paramDouble2) { setMinWidth(paramDouble1);
/*      */     setMinHeight(paramDouble2); }
/*  855 */   public final void setPrefWidth(double paramDouble) { prefWidthProperty().set(paramDouble); } public final double minHeight(double paramDouble) { double d = getMinHeight();
/*  856 */     if (d == -1.0D) {
/*  857 */       if (this.minHeightCache == -1.0D) this.minHeightCache = recalculateMinHeight(paramDouble); 
/*  858 */       return this.minHeightCache;
/*  859 */     }  if (d == Double.NEGATIVE_INFINITY) {
/*  860 */       return prefHeight(paramDouble);
/*      */     }
/*  862 */     return d; }
/*      */   public final double getPrefWidth() { return (this.prefWidth == null) ? -1.0D : this.prefWidth.get(); }
/*      */   public final DoubleProperty prefWidthProperty() { if (this.prefWidth == null) this.prefWidth = new DoublePropertyBase(-1.0D) {
/*      */           public void invalidated() { if (PopupControl.this.isShowing()) PopupControl.this.bridge.requestLayout();  }
/*      */           public Object getBean() { return PopupControl.this; }
/*      */           public String getName() { return "prefWidth"; }
/*      */         };  return this.prefWidth; }
/*      */   public final void setPrefHeight(double paramDouble) { prefHeightProperty().set(paramDouble); }
/*      */   public final double getPrefHeight() { return (this.prefHeight == null) ? -1.0D : this.prefHeight.get(); }
/*      */   public final DoubleProperty prefHeightProperty() { if (this.prefHeight == null) this.prefHeight = new DoublePropertyBase(-1.0D) {
/*      */           public void invalidated() { if (PopupControl.this.isShowing()) PopupControl.this.bridge.requestLayout();  }
/*      */           public Object getBean() { return PopupControl.this; }
/*      */           public String getName() { return "prefHeight"; }
/*      */         };  return this.prefHeight; }
/*  876 */   public void setPrefSize(double paramDouble1, double paramDouble2) { setPrefWidth(paramDouble1); setPrefHeight(paramDouble2); } public final void setMaxWidth(double paramDouble) { maxWidthProperty().set(paramDouble); } public final double getMaxWidth() { return (this.maxWidth == null) ? -1.0D : this.maxWidth.get(); } public final double prefWidth(double paramDouble) { double d = getPrefWidth();
/*  877 */     if (d == -1.0D) {
/*  878 */       if (this.prefWidthCache == -1.0D) this.prefWidthCache = recalculatePrefWidth(paramDouble); 
/*  879 */       return this.prefWidthCache;
/*  880 */     }  if (d == Double.NEGATIVE_INFINITY) {
/*  881 */       return prefWidth(paramDouble);
/*      */     }
/*  883 */     return d; } public final DoubleProperty maxWidthProperty() { if (this.maxWidth == null) this.maxWidth = new DoublePropertyBase(-1.0D) { public void invalidated() { if (PopupControl.this.isShowing()) PopupControl.this.bridge.requestLayout();  }
/*      */           public Object getBean() { return PopupControl.this; }
/*      */           public String getName() { return "maxWidth"; } }
/*      */         ;  return this.maxWidth; }
/*      */   public final void setMaxHeight(double paramDouble) { maxHeightProperty().set(paramDouble); }
/*      */   public final double getMaxHeight() { return (this.maxHeight == null) ? -1.0D : this.maxHeight.get(); }
/*      */   public final DoubleProperty maxHeightProperty() { if (this.maxHeight == null)
/*      */       this.maxHeight = new DoublePropertyBase(-1.0D) { public void invalidated() { if (PopupControl.this.isShowing())
/*      */               PopupControl.this.bridge.requestLayout();  }
/*      */           public Object getBean() { return PopupControl.this; }
/*      */           public String getName() { return "maxHeight"; } }
/*      */         ;  return this.maxHeight; }
/*      */   public void setMaxSize(double paramDouble1, double paramDouble2) { setMaxWidth(paramDouble1); setMaxHeight(paramDouble2); }
/*  896 */   public final double prefHeight(double paramDouble) { double d = getPrefHeight();
/*  897 */     if (d == -1.0D) {
/*  898 */       if (this.prefHeightCache == -1.0D) this.prefHeightCache = recalculatePrefHeight(paramDouble); 
/*  899 */       return this.prefHeightCache;
/*  900 */     }  if (d == Double.NEGATIVE_INFINITY) {
/*  901 */       return prefHeight(paramDouble);
/*      */     }
/*  903 */     return d; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double maxWidth(double paramDouble) {
/*  916 */     double d = getMaxWidth();
/*  917 */     if (d == -1.0D) {
/*  918 */       if (this.maxWidthCache == -1.0D) this.maxWidthCache = recalculateMaxWidth(paramDouble); 
/*  919 */       return this.maxWidthCache;
/*  920 */     }  if (d == Double.NEGATIVE_INFINITY) {
/*  921 */       return prefWidth(paramDouble);
/*      */     }
/*  923 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double maxHeight(double paramDouble) {
/*  936 */     double d = getMaxHeight();
/*  937 */     if (d == -1.0D) {
/*  938 */       if (this.maxHeightCache == -1.0D) this.maxHeightCache = recalculateMaxHeight(paramDouble); 
/*  939 */       return this.maxHeightCache;
/*  940 */     }  if (d == Double.NEGATIVE_INFINITY) {
/*  941 */       return prefHeight(paramDouble);
/*      */     }
/*  943 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double recalculateMinWidth(double paramDouble) {
/*  952 */     recomputeSkinSize();
/*  953 */     return (getSkinNode() == null) ? 0.0D : getSkinNode().minWidth(paramDouble);
/*      */   }
/*      */   private double recalculateMinHeight(double paramDouble) {
/*  956 */     recomputeSkinSize();
/*  957 */     return (getSkinNode() == null) ? 0.0D : getSkinNode().minHeight(paramDouble);
/*      */   }
/*      */   private double recalculateMaxWidth(double paramDouble) {
/*  960 */     recomputeSkinSize();
/*  961 */     return (getSkinNode() == null) ? 0.0D : getSkinNode().maxWidth(paramDouble);
/*      */   }
/*      */   private double recalculateMaxHeight(double paramDouble) {
/*  964 */     recomputeSkinSize();
/*  965 */     return (getSkinNode() == null) ? 0.0D : getSkinNode().maxHeight(paramDouble);
/*      */   }
/*      */   private double recalculatePrefWidth(double paramDouble) {
/*  968 */     recomputeSkinSize();
/*  969 */     return (getSkinNode() == null) ? 0.0D : getSkinNode().prefWidth(paramDouble);
/*      */   }
/*      */   private double recalculatePrefHeight(double paramDouble) {
/*  972 */     recomputeSkinSize();
/*  973 */     return (getSkinNode() == null) ? 0.0D : getSkinNode().prefHeight(paramDouble);
/*      */   }
/*      */   
/*      */   private void recomputeSkinSize() {
/*  977 */     if (!this.skinSizeComputed) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  982 */       this.bridge.applyCss();
/*  983 */       this.skinSizeComputed = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Skin<?> createDefaultSkin() {
/*  997 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1006 */   private static final CssMetaData<CSSBridge, String> SKIN = new CssMetaData<CSSBridge, String>("-fx-skin", 
/*      */       
/* 1008 */       StringConverter.getInstance())
/*      */     {
/*      */       public boolean isSettable(PopupControl.CSSBridge param1CSSBridge)
/*      */       {
/* 1012 */         return !param1CSSBridge.popupControl.skinProperty().isBound();
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<String> getStyleableProperty(PopupControl.CSSBridge param1CSSBridge) {
/* 1017 */         return (StyleableProperty<String>)param1CSSBridge.popupControl.skinClassNameProperty();
/*      */       }
/*      */     };
/*      */   private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */   
/*      */   static {
/* 1023 */     ArrayList<? super CssMetaData> arrayList = new ArrayList();
/*      */     
/* 1025 */     Collections.addAll(arrayList, new CssMetaData[] { SKIN });
/*      */ 
/*      */     
/* 1028 */     STYLEABLES = Collections.unmodifiableList((List)arrayList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1037 */     return STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 1046 */     return getClassCssMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void pseudoClassStateChanged(PseudoClass paramPseudoClass, boolean paramBoolean) {
/* 1056 */     this.bridge.pseudoClassStateChanged(paramPseudoClass, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTypeSelector() {
/* 1066 */     return "PopupControl";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Styleable getStyleableParent() {
/* 1089 */     Node node = getOwnerNode();
/* 1090 */     if (node != null) {
/* 1091 */       return node;
/*      */     }
/*      */ 
/*      */     
/* 1095 */     Window window = getOwnerWindow();
/* 1096 */     if (window != null) {
/*      */       
/* 1098 */       Scene scene = window.getScene();
/* 1099 */       if (scene != null) {
/* 1100 */         return scene.getRoot();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1105 */     return this.bridge.getParent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObservableSet<PseudoClass> getPseudoClassStates() {
/* 1115 */     return FXCollections.emptyObservableSet();
/*      */   }
/*      */ 
/*      */   
/*      */   public Node getStyleableNode() {
/* 1120 */     return this.bridge;
/*      */   }
/*      */ 
/*      */   
/*      */   protected class CSSBridge
/*      */     extends Pane
/*      */   {
/*      */     private final PopupControl popupControl;
/*      */     
/*      */     protected CSSBridge() {
/* 1130 */       this.popupControl = PopupControl.this;
/*      */ 
/*      */ 
/*      */       
/* 1134 */       PopupControl.CSSBridgeHelper.initHelper(this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void requestLayout() {
/* 1147 */       PopupControl.this.prefWidthCache = -1.0D;
/* 1148 */       PopupControl.this.prefHeightCache = -1.0D;
/* 1149 */       PopupControl.this.minWidthCache = -1.0D;
/* 1150 */       PopupControl.this.minHeightCache = -1.0D;
/* 1151 */       PopupControl.this.maxWidthCache = -1.0D;
/* 1152 */       PopupControl.this.maxHeightCache = -1.0D;
/*      */       
/* 1154 */       super.requestLayout();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Styleable getStyleableParent() {
/* 1163 */       return PopupControl.this.getStyleableParent();
/*      */     }
/*      */ 
/*      */     
/*      */     public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 1168 */       return PopupControl.this.getCssMetaData();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private List<String> doGetAllParentStylesheets() {
/* 1175 */       Styleable styleable = getStyleableParent();
/* 1176 */       if (styleable instanceof Parent) {
/* 1177 */         return ParentHelper.getAllParentStylesheets((Parent)styleable);
/*      */       }
/* 1179 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void doProcessCSS() {
/* 1186 */       PopupControl.CSSBridgeHelper.superProcessCSS(this);
/*      */       
/* 1188 */       if (PopupControl.this.getSkin() == null) {
/*      */         
/* 1190 */         Skin<?> skin = PopupControl.this.createDefaultSkin();
/* 1191 */         if (skin != null) {
/* 1192 */           PopupControl.this.skinProperty().set(skin);
/* 1193 */           PopupControl.CSSBridgeHelper.superProcessCSS(this);
/*      */         } else {
/* 1195 */           String str = "The -fx-skin property has not been defined in CSS for " + this + " and createDefaultSkin() returned null.";
/*      */           
/* 1197 */           ObservableList<CssError> observableList = StyleManager.getErrors();
/* 1198 */           if (observableList != null) {
/* 1199 */             CssParser.ParseError parseError = new CssParser.ParseError(str);
/* 1200 */             observableList.add(parseError);
/*      */           } 
/* 1202 */           Logging.getControlsLogger().severe(str);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final class CSSBridgeHelper
/*      */     extends PaneHelper
/*      */   {
/* 1216 */     private static final CSSBridgeHelper theInstance = new CSSBridgeHelper();
/*      */ 
/*      */     
/*      */     private static CSSBridgeHelper getInstance() {
/* 1220 */       return theInstance;
/*      */     }
/*      */     
/*      */     public static void initHelper(PopupControl.CSSBridge param1CSSBridge) {
/* 1224 */       setHelper(param1CSSBridge, (NodeHelper)getInstance());
/*      */     }
/*      */     
/*      */     public static void superProcessCSS(Node param1Node) {
/* 1228 */       ((CSSBridgeHelper)getHelper(param1Node)).superProcessCSSImpl(param1Node);
/*      */     }
/*      */     
/*      */     void superProcessCSSImpl(Node param1Node) {
/* 1232 */       super.processCSSImpl(param1Node);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void processCSSImpl(Node param1Node) {
/* 1237 */       ((PopupControl.CSSBridge)param1Node).doProcessCSS();
/*      */     }
/*      */ 
/*      */     
/*      */     protected List<String> getAllParentStylesheetsImpl(Parent param1Parent) {
/* 1242 */       return ((PopupControl.CSSBridge)param1Parent).doGetAllParentStylesheets();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\PopupControl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */