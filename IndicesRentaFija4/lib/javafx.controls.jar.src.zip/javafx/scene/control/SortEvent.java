/*    */ package javafx.scene.control;
/*    */ 
/*    */ import javafx.beans.NamedArg;
/*    */ import javafx.event.Event;
/*    */ import javafx.event.EventTarget;
/*    */ import javafx.event.EventType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SortEvent<C>
/*    */   extends Event
/*    */ {
/* 42 */   public static final EventType<SortEvent> ANY = (EventType)new EventType<>(Event.ANY, "SORT");
/*    */ 
/*    */ 
/*    */   
/*    */   public static <C> EventType<SortEvent<C>> sortEvent() {
/* 47 */     return (EventType)SORT_EVENT;
/*    */   }
/*    */   
/* 50 */   private static final EventType<?> SORT_EVENT = new EventType(ANY, "SORT_EVENT");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SortEvent(@NamedArg("source") C paramC, @NamedArg("target") EventTarget paramEventTarget) {
/* 63 */     super(paramC, paramEventTarget, (EventType)sortEvent());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public C getSource() {
/* 69 */     return (C)super.getSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\SortEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */