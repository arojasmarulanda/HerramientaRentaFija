/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.DefaultProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.EnumConverter;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.ToolBarSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @DefaultProperty("items")
/*     */ public class ToolBar
/*     */   extends Control
/*     */ {
/*     */   private final ObservableList<Node> items;
/*     */   private ObjectProperty<Orientation> orientation;
/*     */   private static final String DEFAULT_STYLE_CLASS = "tool-bar";
/*     */   
/*     */   public ToolBar() {
/* 143 */     this.items = FXCollections.observableArrayList(); initialize(); } public ToolBar(Node... paramVarArgs) { this.items = FXCollections.observableArrayList();
/*     */     initialize();
/*     */     this.items.addAll(paramVarArgs); }
/*     */   private void initialize() {
/*     */     getStyleClass().setAll(new String[] { "tool-bar" });
/*     */     setAccessibleRole(AccessibleRole.TOOL_BAR);
/*     */     ((StyleableProperty<Boolean>)focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
/*     */     pseudoClassStateChanged(HORIZONTAL_PSEUDOCLASS_STATE, true);
/* 151 */   } public final void setOrientation(Orientation paramOrientation) { orientationProperty().set(paramOrientation); } public final ObservableList<Node> getItems() {
/*     */     return this.items;
/*     */   } public final Orientation getOrientation() {
/* 154 */     return (this.orientation == null) ? Orientation.HORIZONTAL : this.orientation.get();
/*     */   }
/*     */   public final ObjectProperty<Orientation> orientationProperty() {
/* 157 */     if (this.orientation == null) {
/* 158 */       this.orientation = new StyleableObjectProperty<Orientation>(Orientation.HORIZONTAL) {
/*     */           public void invalidated() {
/* 160 */             boolean bool = (get() == Orientation.VERTICAL) ? true : false;
/* 161 */             ToolBar.this.pseudoClassStateChanged(ToolBar.VERTICAL_PSEUDOCLASS_STATE, bool);
/* 162 */             ToolBar.this.pseudoClassStateChanged(ToolBar.HORIZONTAL_PSEUDOCLASS_STATE, !bool);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 167 */             return ToolBar.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 172 */             return "orientation";
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<ToolBar, Orientation> getCssMetaData() {
/* 177 */             return ToolBar.StyleableProperties.ORIENTATION;
/*     */           }
/*     */         };
/*     */     }
/* 181 */     return this.orientation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 192 */     return (Skin<?>)new ToolBarSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 204 */     private static final CssMetaData<ToolBar, Orientation> ORIENTATION = new CssMetaData<ToolBar, Orientation>("-fx-orientation", (StyleConverter)new EnumConverter(Orientation.class), Orientation.HORIZONTAL)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Orientation getInitialValue(ToolBar param2ToolBar)
/*     */         {
/* 212 */           return param2ToolBar.getOrientation();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isSettable(ToolBar param2ToolBar) {
/* 217 */           return (param2ToolBar.orientation == null || !param2ToolBar.orientation.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Orientation> getStyleableProperty(ToolBar param2ToolBar) {
/* 222 */           return (StyleableProperty<Orientation>)param2ToolBar.orientationProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 229 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 230 */       arrayList.add(ORIENTATION);
/* 231 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 241 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 250 */     return getClassCssMetaData();
/*     */   }
/*     */   
/* 253 */   private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
/* 254 */   private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean getInitialFocusTraversable() {
/* 265 */     return Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ToolBar.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */