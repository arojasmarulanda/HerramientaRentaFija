/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Alert
/*     */   extends Dialog<ButtonType>
/*     */ {
/*     */   private WeakReference<DialogPane> dialogPaneRef;
/*     */   
/*     */   public enum AlertType
/*     */   {
/* 127 */     NONE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     INFORMATION,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     WARNING,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     CONFIRMATION,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     ERROR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean installingDefaults = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasCustomButtons = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasCustomTitle = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasCustomHeaderText = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final InvalidationListener headerTextListener = paramObservable -> {
/*     */       if (!this.installingDefaults) {
/*     */         this.hasCustomHeaderText = true;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final InvalidationListener titleListener = paramObservable -> {
/*     */       if (!this.installingDefaults) {
/*     */         this.hasCustomTitle = true;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ListChangeListener<ButtonType> buttonsListener = paramChange -> {
/*     */       if (!this.installingDefaults) {
/*     */         this.hasCustomButtons = true;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private final ObjectProperty<AlertType> alertType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Alert(@NamedArg("alertType") AlertType paramAlertType) {
/* 220 */     this(paramAlertType, "", new ButtonType[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Alert(@NamedArg("alertType") AlertType paramAlertType, @NamedArg("contentText") String paramString, @NamedArg("buttonTypes") ButtonType... paramVarArgs) {
/* 286 */     this.alertType = new SimpleObjectProperty<AlertType>(null) {
/* 287 */         final String[] styleClasses = new String[] { "information", "warning", "error", "confirmation" };
/*     */ 
/*     */         
/*     */         protected void invalidated() {
/* 291 */           String str1 = "";
/* 292 */           String str2 = "";
/*     */           
/* 294 */           String str3 = "";
/* 295 */           ButtonType[] arrayOfButtonType = { ButtonType.OK };
/* 296 */           switch (Alert.this.getAlertType()) {
/*     */             case NONE:
/* 298 */               arrayOfButtonType = new ButtonType[0];
/*     */               break;
/*     */             
/*     */             case INFORMATION:
/* 302 */               str1 = ControlResources.getString("Dialog.info.title");
/* 303 */               str2 = ControlResources.getString("Dialog.info.header");
/* 304 */               str3 = "information";
/*     */               break;
/*     */             
/*     */             case WARNING:
/* 308 */               str1 = ControlResources.getString("Dialog.warning.title");
/* 309 */               str2 = ControlResources.getString("Dialog.warning.header");
/* 310 */               str3 = "warning";
/*     */               break;
/*     */             
/*     */             case ERROR:
/* 314 */               str1 = ControlResources.getString("Dialog.error.title");
/* 315 */               str2 = ControlResources.getString("Dialog.error.header");
/* 316 */               str3 = "error";
/*     */               break;
/*     */             
/*     */             case CONFIRMATION:
/* 320 */               str1 = ControlResources.getString("Dialog.confirm.title");
/* 321 */               str2 = ControlResources.getString("Dialog.confirm.header");
/* 322 */               str3 = "confirmation";
/* 323 */               arrayOfButtonType = new ButtonType[] { ButtonType.OK, ButtonType.CANCEL };
/*     */               break;
/*     */           } 
/*     */ 
/*     */           
/* 328 */           Alert.this.installingDefaults = true;
/* 329 */           if (!Alert.this.hasCustomTitle) Alert.this.setTitle(str1); 
/* 330 */           if (!Alert.this.hasCustomHeaderText) Alert.this.setHeaderText(str2); 
/* 331 */           if (!Alert.this.hasCustomButtons) Alert.this.getButtonTypes().setAll(arrayOfButtonType);
/*     */ 
/*     */ 
/*     */           
/* 335 */           DialogPane dialogPane = Alert.this.getDialogPane();
/* 336 */           if (dialogPane != null) {
/* 337 */             ArrayList<?> arrayList = new ArrayList(Arrays.asList((Object[])this.styleClasses));
/* 338 */             arrayList.remove(str3);
/* 339 */             dialogPane.getStyleClass().removeAll(arrayList);
/* 340 */             if (!dialogPane.getStyleClass().contains(str3)) {
/* 341 */               dialogPane.getStyleClass().add(str3);
/*     */             }
/*     */           } 
/*     */           
/* 345 */           Alert.this.installingDefaults = false; } }; DialogPane dialogPane = getDialogPane(); dialogPane.setContentText(paramString); getDialogPane().getStyleClass().add("alert"); this.dialogPaneRef = new WeakReference<>(dialogPane); this.hasCustomButtons = (paramVarArgs != null && paramVarArgs.length > 0); if (this.hasCustomButtons)
/*     */       for (ButtonType buttonType : paramVarArgs) {
/*     */         dialogPane.getButtonTypes().addAll(new ButtonType[] { buttonType });
/*     */       }   setAlertType(paramAlertType); dialogPaneProperty().addListener(paramObservable -> updateListeners());
/*     */     titleProperty().addListener(this.titleListener);
/* 350 */     updateListeners(); } public final AlertType getAlertType() { return this.alertType.get(); }
/*     */ 
/*     */   
/*     */   public final void setAlertType(AlertType paramAlertType) {
/* 354 */     this.alertType.setValue(paramAlertType);
/*     */   }
/*     */   
/*     */   public final ObjectProperty<AlertType> alertTypeProperty() {
/* 358 */     return this.alertType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<ButtonType> getButtonTypes() {
/* 379 */     return getDialogPane().getButtonTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateListeners() {
/* 391 */     DialogPane dialogPane1 = this.dialogPaneRef.get();
/*     */     
/* 393 */     if (dialogPane1 != null) {
/* 394 */       dialogPane1.headerTextProperty().removeListener(this.headerTextListener);
/* 395 */       dialogPane1.getButtonTypes().removeListener(this.buttonsListener);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 403 */     DialogPane dialogPane2 = getDialogPane();
/* 404 */     if (dialogPane2 != null) {
/* 405 */       dialogPane2.headerTextProperty().addListener(this.headerTextListener);
/* 406 */       dialogPane2.getButtonTypes().addListener(this.buttonsListener);
/*     */     } 
/*     */     
/* 409 */     this.dialogPaneRef = new WeakReference<>(dialogPane2);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Alert.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */