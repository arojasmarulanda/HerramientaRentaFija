/*    */ package javafx.scene.control;
/*    */ 
/*    */ import java.time.LocalDate;
/*    */ import javafx.scene.AccessibleAttribute;
/*    */ import javafx.scene.AccessibleRole;
/*    */ import javafx.scene.control.skin.DateCellSkin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateCell
/*    */   extends Cell<LocalDate>
/*    */ {
/*    */   private static final String DEFAULT_STYLE_CLASS = "date-cell";
/*    */   
/*    */   public DateCell() {
/* 45 */     getStyleClass().add("date-cell");
/* 46 */     setAccessibleRole(AccessibleRole.TEXT);
/*    */   }
/*    */ 
/*    */   
/*    */   public void updateItem(LocalDate paramLocalDate, boolean paramBoolean) {
/* 51 */     super.updateItem(paramLocalDate, paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Skin<?> createDefaultSkin() {
/* 56 */     return (Skin<?>)new DateCellSkin(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 76 */     switch (paramAccessibleAttribute) {
/*    */       case TEXT:
/* 78 */         if (isFocused()) {
/* 79 */           return getText();
/*    */         }
/* 81 */         return "";
/*    */     } 
/* 83 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\DateCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */