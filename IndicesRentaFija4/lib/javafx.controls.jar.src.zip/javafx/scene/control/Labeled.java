/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.css.StyleManager;
/*      */ import com.sun.javafx.scene.NodeHelper;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import javafx.beans.DefaultProperty;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.property.SimpleStringProperty;
/*      */ import javafx.beans.property.StringProperty;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.FontCssMetaData;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.StyleOrigin;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableBooleanProperty;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.StyleableStringProperty;
/*      */ import javafx.css.converter.BooleanConverter;
/*      */ import javafx.css.converter.EnumConverter;
/*      */ import javafx.css.converter.InsetsConverter;
/*      */ import javafx.css.converter.PaintConverter;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.css.converter.StringConverter;
/*      */ import javafx.geometry.Insets;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.geometry.Pos;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.image.Image;
/*      */ import javafx.scene.image.ImageView;
/*      */ import javafx.scene.paint.Color;
/*      */ import javafx.scene.paint.Paint;
/*      */ import javafx.scene.text.Font;
/*      */ import javafx.scene.text.TextAlignment;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @DefaultProperty("text")
/*      */ public abstract class Labeled
/*      */   extends Control
/*      */ {
/*      */   private static final String DEFAULT_ELLIPSIS_STRING = "...";
/*      */   private StringProperty text;
/*      */   private ObjectProperty<Pos> alignment;
/*      */   private ObjectProperty<TextAlignment> textAlignment;
/*      */   private ObjectProperty<OverrunStyle> textOverrun;
/*      */   private StringProperty ellipsisString;
/*      */   private BooleanProperty wrapText;
/*      */   private ObjectProperty<Font> font;
/*      */   private ObjectProperty<Node> graphic;
/*      */   
/*      */   public Labeled(String paramString) {
/*  118 */     setText(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Labeled(String paramString, Node paramNode) {
/*  127 */     setText(paramString);
/*  128 */     ((StyleableProperty<Node>)graphicProperty()).applyStyle(null, paramNode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final StringProperty textProperty() {
/*  141 */     if (this.text == null) {
/*  142 */       this.text = new SimpleStringProperty(this, "text", "");
/*      */     }
/*  144 */     return this.text;
/*      */   }
/*      */   
/*  147 */   public final void setText(String paramString) { textProperty().setValue(paramString); } public final String getText() {
/*  148 */     return (this.text == null) ? "" : this.text.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<Pos> alignmentProperty() {
/*  156 */     if (this.alignment == null) {
/*  157 */       this.alignment = new StyleableObjectProperty<Pos>(Pos.CENTER_LEFT)
/*      */         {
/*      */           public CssMetaData<Labeled, Pos> getCssMetaData() {
/*  160 */             return Labeled.StyleableProperties.ALIGNMENT;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  165 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  170 */             return "alignment";
/*      */           }
/*      */         };
/*      */     }
/*  174 */     return this.alignment;
/*      */   }
/*      */   
/*  177 */   public final void setAlignment(Pos paramPos) { alignmentProperty().set(paramPos); } public final Pos getAlignment() {
/*  178 */     return (this.alignment == null) ? Pos.CENTER_LEFT : this.alignment.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<TextAlignment> textAlignmentProperty() {
/*  188 */     if (this.textAlignment == null) {
/*  189 */       this.textAlignment = new StyleableObjectProperty<TextAlignment>(TextAlignment.LEFT)
/*      */         {
/*      */           public CssMetaData<Labeled, TextAlignment> getCssMetaData()
/*      */           {
/*  193 */             return Labeled.StyleableProperties.TEXT_ALIGNMENT;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  198 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  203 */             return "textAlignment";
/*      */           }
/*      */         };
/*      */     }
/*  207 */     return this.textAlignment;
/*      */   }
/*      */   
/*  210 */   public final void setTextAlignment(TextAlignment paramTextAlignment) { textAlignmentProperty().setValue(paramTextAlignment); } public final TextAlignment getTextAlignment() {
/*  211 */     return (this.textAlignment == null) ? TextAlignment.LEFT : this.textAlignment.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<OverrunStyle> textOverrunProperty() {
/*  219 */     if (this.textOverrun == null) {
/*  220 */       this.textOverrun = new StyleableObjectProperty<OverrunStyle>(OverrunStyle.ELLIPSIS)
/*      */         {
/*      */           public CssMetaData<Labeled, OverrunStyle> getCssMetaData()
/*      */           {
/*  224 */             return Labeled.StyleableProperties.TEXT_OVERRUN;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  229 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  234 */             return "textOverrun";
/*      */           }
/*      */         };
/*      */     }
/*  238 */     return this.textOverrun;
/*      */   }
/*      */   
/*  241 */   public final void setTextOverrun(OverrunStyle paramOverrunStyle) { textOverrunProperty().setValue(paramOverrunStyle); } public final OverrunStyle getTextOverrun() {
/*  242 */     return (this.textOverrun == null) ? OverrunStyle.ELLIPSIS : this.textOverrun.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final StringProperty ellipsisStringProperty() {
/*  265 */     if (this.ellipsisString == null) {
/*  266 */       this.ellipsisString = new StyleableStringProperty("...") {
/*      */           public Object getBean() {
/*  268 */             return Labeled.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  272 */             return "ellipsisString";
/*      */           }
/*      */           
/*      */           public CssMetaData<Labeled, String> getCssMetaData() {
/*  276 */             return Labeled.StyleableProperties.ELLIPSIS_STRING;
/*      */           }
/*      */         };
/*      */     }
/*  280 */     return this.ellipsisString;
/*      */   }
/*      */   
/*  283 */   public final void setEllipsisString(String paramString) { ellipsisStringProperty().set((paramString == null) ? "" : paramString); } public final String getEllipsisString() {
/*  284 */     return (this.ellipsisString == null) ? "..." : this.ellipsisString.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final BooleanProperty wrapTextProperty() {
/*  293 */     if (this.wrapText == null) {
/*  294 */       this.wrapText = new StyleableBooleanProperty()
/*      */         {
/*      */           public CssMetaData<Labeled, Boolean> getCssMetaData()
/*      */           {
/*  298 */             return Labeled.StyleableProperties.WRAP_TEXT;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  303 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  308 */             return "wrapText";
/*      */           }
/*      */         };
/*      */     }
/*  312 */     return this.wrapText;
/*      */   }
/*      */   
/*  315 */   public final void setWrapText(boolean paramBoolean) { wrapTextProperty().setValue(Boolean.valueOf(paramBoolean)); } public final boolean isWrapText() {
/*  316 */     return (this.wrapText == null) ? false : this.wrapText.getValue().booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Orientation getContentBias() {
/*  323 */     return isWrapText() ? Orientation.HORIZONTAL : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<Font> fontProperty() {
/*  335 */     if (this.font == null) {
/*  336 */       this.font = new StyleableObjectProperty<Font>(Font.getDefault())
/*      */         {
/*      */           private boolean fontSetByCss = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyStyle(StyleOrigin param1StyleOrigin, Font param1Font) {
/*      */             try {
/*  349 */               this.fontSetByCss = true;
/*  350 */               super.applyStyle(param1StyleOrigin, param1Font);
/*  351 */             } catch (Exception exception) {
/*  352 */               throw exception;
/*      */             } finally {
/*  354 */               this.fontSetByCss = false;
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void set(Font param1Font) {
/*  361 */             Font font = get();
/*  362 */             if ((param1Font != null) ? !param1Font.equals(font) : (font != null)) {
/*  363 */               super.set(param1Font);
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected void invalidated() {
/*  373 */             if (!this.fontSetByCss) {
/*  374 */               NodeHelper.reapplyCSS(Labeled.this);
/*      */             }
/*      */           }
/*      */ 
/*      */           
/*      */           public CssMetaData<Labeled, Font> getCssMetaData() {
/*  380 */             return Labeled.StyleableProperties.FONT;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  385 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  390 */             return "font";
/*      */           }
/*      */         };
/*      */     }
/*  394 */     return this.font;
/*      */   }
/*      */   
/*  397 */   public final void setFont(Font paramFont) { fontProperty().setValue(paramFont); } public final Font getFont() {
/*  398 */     return (this.font == null) ? Font.getDefault() : this.font.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<Node> graphicProperty() {
/*  410 */     if (this.graphic == null) {
/*  411 */       this.graphic = new StyleableObjectProperty<Node>()
/*      */         {
/*      */ 
/*      */           
/*      */           public CssMetaData getCssMetaData()
/*      */           {
/*  417 */             return Labeled.StyleableProperties.GRAPHIC;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  422 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  427 */             return "graphic";
/*      */           }
/*      */         };
/*      */     }
/*  431 */     return this.graphic;
/*      */   }
/*      */   
/*      */   public final void setGraphic(Node paramNode) {
/*  435 */     graphicProperty().setValue(paramNode);
/*      */   } public final Node getGraphic() {
/*  437 */     return (this.graphic == null) ? null : this.graphic.getValue();
/*      */   }
/*  439 */   private StyleableStringProperty imageUrl = null; private BooleanProperty underline; private DoubleProperty lineSpacing; private ObjectProperty<ContentDisplay> contentDisplay;
/*      */   private ObjectProperty<Insets> labelPadding;
/*      */   private DoubleProperty graphicTextGap;
/*      */   private ObjectProperty<Paint> textFill;
/*      */   private BooleanProperty mnemonicParsing;
/*      */   
/*      */   private StyleableStringProperty imageUrlProperty() {
/*  446 */     if (this.imageUrl == null) {
/*  447 */       this.imageUrl = new StyleableStringProperty()
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  462 */           StyleOrigin origin = StyleOrigin.USER;
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyStyle(StyleOrigin param1StyleOrigin, String param1String) {
/*  467 */             this.origin = param1StyleOrigin;
/*      */ 
/*      */             
/*  470 */             if (Labeled.this.graphic == null || !Labeled.this.graphic.isBound()) super.applyStyle(param1StyleOrigin, param1String);
/*      */ 
/*      */             
/*  473 */             this.origin = StyleOrigin.USER;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected void invalidated() {
/*  480 */             String str = super.get();
/*      */             
/*  482 */             if (str == null) {
/*  483 */               ((StyleableProperty)Labeled.this.graphicProperty()).applyStyle(this.origin, null);
/*      */             } else {
/*      */               
/*  486 */               Node node = Labeled.this.getGraphic();
/*  487 */               if (node instanceof ImageView) {
/*  488 */                 ImageView imageView = (ImageView)node;
/*  489 */                 Image image1 = imageView.getImage();
/*  490 */                 if (image1 != null) {
/*  491 */                   String str1 = image1.getUrl();
/*  492 */                   if (str.equals(str1)) {
/*      */                     return;
/*      */                   }
/*      */                 } 
/*      */               } 
/*  497 */               Image image = StyleManager.getInstance().getCachedImage(str);
/*      */               
/*  499 */               if (image != null)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  511 */                 ((StyleableProperty)Labeled.this.graphicProperty()).applyStyle(this.origin, new ImageView(image));
/*      */               }
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public String get() {
/*  523 */             Node node = Labeled.this.getGraphic();
/*  524 */             if (node instanceof ImageView) {
/*  525 */               Image image = ((ImageView)node).getImage();
/*  526 */               if (image != null) {
/*  527 */                 return image.getUrl();
/*      */               }
/*      */             } 
/*  530 */             return null;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public StyleOrigin getStyleOrigin() {
/*  540 */             return (Labeled.this.graphic != null) ? ((StyleableProperty)Labeled.this.graphic).getStyleOrigin() : null;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  545 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  550 */             return "imageUrl";
/*      */           }
/*      */ 
/*      */           
/*      */           public CssMetaData<Labeled, String> getCssMetaData() {
/*  555 */             return Labeled.StyleableProperties.GRAPHIC;
/*      */           }
/*      */         };
/*      */     }
/*      */     
/*  560 */     return this.imageUrl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final BooleanProperty underlineProperty() {
/*  568 */     if (this.underline == null) {
/*  569 */       this.underline = new StyleableBooleanProperty(false)
/*      */         {
/*      */           public CssMetaData<Labeled, Boolean> getCssMetaData()
/*      */           {
/*  573 */             return Labeled.StyleableProperties.UNDERLINE;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  578 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  583 */             return "underline";
/*      */           }
/*      */         };
/*      */     }
/*  587 */     return this.underline;
/*      */   }
/*      */   
/*  590 */   public final void setUnderline(boolean paramBoolean) { underlineProperty().setValue(Boolean.valueOf(paramBoolean)); } public final boolean isUnderline() {
/*  591 */     return (this.underline == null) ? false : this.underline.getValue().booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DoubleProperty lineSpacingProperty() {
/*  599 */     if (this.lineSpacing == null) {
/*  600 */       this.lineSpacing = new StyleableDoubleProperty(0.0D)
/*      */         {
/*      */           public CssMetaData<Labeled, Number> getCssMetaData()
/*      */           {
/*  604 */             return Labeled.StyleableProperties.LINE_SPACING;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  609 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  614 */             return "lineSpacing";
/*      */           }
/*      */         };
/*      */     }
/*  618 */     return this.lineSpacing;
/*      */   }
/*      */   
/*  621 */   public final void setLineSpacing(double paramDouble) { lineSpacingProperty().setValue(Double.valueOf(paramDouble)); } public final double getLineSpacing() {
/*  622 */     return (this.lineSpacing == null) ? 0.0D : this.lineSpacing.getValue().doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<ContentDisplay> contentDisplayProperty() {
/*  629 */     if (this.contentDisplay == null) {
/*  630 */       this.contentDisplay = new StyleableObjectProperty<ContentDisplay>(ContentDisplay.LEFT)
/*      */         {
/*      */           public CssMetaData<Labeled, ContentDisplay> getCssMetaData()
/*      */           {
/*  634 */             return Labeled.StyleableProperties.CONTENT_DISPLAY;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  639 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  644 */             return "contentDisplay";
/*      */           }
/*      */         };
/*      */     }
/*  648 */     return this.contentDisplay;
/*      */   }
/*      */   
/*  651 */   public final void setContentDisplay(ContentDisplay paramContentDisplay) { contentDisplayProperty().setValue(paramContentDisplay); } public final ContentDisplay getContentDisplay() {
/*  652 */     return (this.contentDisplay == null) ? ContentDisplay.LEFT : this.contentDisplay.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ReadOnlyObjectProperty<Insets> labelPaddingProperty() {
/*  663 */     return labelPaddingPropertyImpl();
/*      */   }
/*      */   private ObjectProperty<Insets> labelPaddingPropertyImpl() {
/*  666 */     if (this.labelPadding == null) {
/*  667 */       this.labelPadding = new StyleableObjectProperty<Insets>(Insets.EMPTY) {
/*  668 */           private Insets lastValidValue = Insets.EMPTY;
/*      */ 
/*      */           
/*      */           public void invalidated() {
/*  672 */             Insets insets = get();
/*  673 */             if (insets == null) {
/*  674 */               set(this.lastValidValue);
/*  675 */               throw new NullPointerException("cannot set labelPadding to null");
/*      */             } 
/*  677 */             this.lastValidValue = insets;
/*  678 */             Labeled.this.requestLayout();
/*      */           }
/*      */ 
/*      */           
/*      */           public CssMetaData<Labeled, Insets> getCssMetaData() {
/*  683 */             return Labeled.StyleableProperties.LABEL_PADDING;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  688 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  693 */             return "labelPadding";
/*      */           }
/*      */         };
/*      */     }
/*  697 */     return this.labelPadding;
/*      */   }
/*      */   
/*  700 */   private void setLabelPadding(Insets paramInsets) { labelPaddingPropertyImpl().set(paramInsets); } public final Insets getLabelPadding() {
/*  701 */     return (this.labelPadding == null) ? Insets.EMPTY : this.labelPadding.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DoubleProperty graphicTextGapProperty() {
/*  708 */     if (this.graphicTextGap == null) {
/*  709 */       this.graphicTextGap = new StyleableDoubleProperty(4.0D)
/*      */         {
/*      */           public CssMetaData<Labeled, Number> getCssMetaData()
/*      */           {
/*  713 */             return Labeled.StyleableProperties.GRAPHIC_TEXT_GAP;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  718 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  723 */             return "graphicTextGap";
/*      */           }
/*      */         };
/*      */     }
/*  727 */     return this.graphicTextGap;
/*      */   }
/*      */   
/*  730 */   public final void setGraphicTextGap(double paramDouble) { graphicTextGapProperty().setValue(Double.valueOf(paramDouble)); } public final double getGraphicTextGap() {
/*  731 */     return (this.graphicTextGap == null) ? 4.0D : this.graphicTextGap.getValue().doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTextFill(Paint paramPaint) {
/*  740 */     textFillProperty().set(paramPaint);
/*      */   }
/*      */   
/*      */   public final Paint getTextFill() {
/*  744 */     return (this.textFill == null) ? Color.BLACK : this.textFill.get();
/*      */   }
/*      */   
/*      */   public final ObjectProperty<Paint> textFillProperty() {
/*  748 */     if (this.textFill == null) {
/*  749 */       this.textFill = new StyleableObjectProperty<Paint>(Color.BLACK)
/*      */         {
/*      */           public CssMetaData<Labeled, Paint> getCssMetaData()
/*      */           {
/*  753 */             return Labeled.StyleableProperties.TEXT_FILL;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  758 */             return Labeled.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  763 */             return "textFill";
/*      */           }
/*      */         };
/*      */     }
/*  767 */     return this.textFill;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setMnemonicParsing(boolean paramBoolean) {
/*  786 */     mnemonicParsingProperty().set(paramBoolean);
/*      */   }
/*      */   public final boolean isMnemonicParsing() {
/*  789 */     return (this.mnemonicParsing == null) ? false : this.mnemonicParsing.get();
/*      */   }
/*      */   public final BooleanProperty mnemonicParsingProperty() {
/*  792 */     if (this.mnemonicParsing == null) {
/*  793 */       this.mnemonicParsing = new SimpleBooleanProperty(this, "mnemonicParsing");
/*      */     }
/*  795 */     return this.mnemonicParsing;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  812 */     StringBuilder stringBuilder = (new StringBuilder(super.toString())).append("'").append(getText()).append("'");
/*  813 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Pos getInitialAlignment() {
/*  831 */     return Pos.CENTER_LEFT;
/*      */   }
/*      */   
/*      */   private static class StyleableProperties {
/*  835 */     private static final FontCssMetaData<Labeled> FONT = new FontCssMetaData<Labeled>("-fx-font", 
/*  836 */         Font.getDefault())
/*      */       {
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/*  840 */           return (param2Labeled.font == null || !param2Labeled.font.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Font> getStyleableProperty(Labeled param2Labeled) {
/*  845 */           return (StyleableProperty<Font>)param2Labeled.fontProperty();
/*      */         }
/*      */       };
/*      */     
/*  849 */     private static final CssMetaData<Labeled, Pos> ALIGNMENT = new CssMetaData<Labeled, Pos>("-fx-alignment", (StyleConverter)new EnumConverter(Pos.class), Pos.CENTER_LEFT)
/*      */       {
/*      */ 
/*      */         
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/*  855 */           return (param2Labeled.alignment == null || !param2Labeled.alignment.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Pos> getStyleableProperty(Labeled param2Labeled) {
/*  860 */           return (StyleableProperty<Pos>)param2Labeled.alignmentProperty();
/*      */         }
/*      */ 
/*      */         
/*      */         public Pos getInitialValue(Labeled param2Labeled) {
/*  865 */           return param2Labeled.getInitialAlignment();
/*      */         }
/*      */       };
/*      */     
/*  869 */     private static final CssMetaData<Labeled, TextAlignment> TEXT_ALIGNMENT = new CssMetaData<Labeled, TextAlignment>("-fx-text-alignment", (StyleConverter)new EnumConverter(TextAlignment.class), TextAlignment.LEFT)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/*  876 */           return (param2Labeled.textAlignment == null || !param2Labeled.textAlignment.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<TextAlignment> getStyleableProperty(Labeled param2Labeled) {
/*  881 */           return (StyleableProperty<TextAlignment>)param2Labeled.textAlignmentProperty();
/*      */         }
/*      */       };
/*      */     
/*  885 */     private static final CssMetaData<Labeled, Paint> TEXT_FILL = new CssMetaData<Labeled, Paint>("-fx-text-fill", 
/*      */         
/*  887 */         PaintConverter.getInstance(), Color.BLACK)
/*      */       {
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/*  891 */           return (param2Labeled.textFill == null || !param2Labeled.textFill.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Paint> getStyleableProperty(Labeled param2Labeled) {
/*  896 */           return (StyleableProperty<Paint>)param2Labeled.textFillProperty();
/*      */         }
/*      */       };
/*      */     
/*  900 */     private static final CssMetaData<Labeled, OverrunStyle> TEXT_OVERRUN = new CssMetaData<Labeled, OverrunStyle>("-fx-text-overrun", (StyleConverter)new EnumConverter(OverrunStyle.class), OverrunStyle.ELLIPSIS)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/*  907 */           return (param2Labeled.textOverrun == null || !param2Labeled.textOverrun.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<OverrunStyle> getStyleableProperty(Labeled param2Labeled) {
/*  912 */           return (StyleableProperty<OverrunStyle>)param2Labeled.textOverrunProperty();
/*      */         }
/*      */       };
/*      */     
/*  916 */     private static final CssMetaData<Labeled, String> ELLIPSIS_STRING = new CssMetaData<Labeled, String>("-fx-ellipsis-string", 
/*      */         
/*  918 */         StringConverter.getInstance(), "...")
/*      */       {
/*      */         public boolean isSettable(Labeled param2Labeled) {
/*  921 */           return (param2Labeled.ellipsisString == null || !param2Labeled.ellipsisString.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<String> getStyleableProperty(Labeled param2Labeled) {
/*  925 */           return (StyleableProperty<String>)param2Labeled.ellipsisStringProperty();
/*      */         }
/*      */       };
/*      */     
/*  929 */     private static final CssMetaData<Labeled, Boolean> WRAP_TEXT = new CssMetaData<Labeled, Boolean>("-fx-wrap-text", 
/*      */         
/*  931 */         BooleanConverter.getInstance(), Boolean.valueOf(false))
/*      */       {
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/*  935 */           return (param2Labeled.wrapText == null || !param2Labeled.wrapText.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(Labeled param2Labeled) {
/*  940 */           return (StyleableProperty<Boolean>)param2Labeled.wrapTextProperty();
/*      */         }
/*      */       };
/*      */     
/*  944 */     private static final CssMetaData<Labeled, String> GRAPHIC = new CssMetaData<Labeled, String>("-fx-graphic", 
/*      */         
/*  946 */         StringConverter.getInstance())
/*      */       {
/*      */         
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/*  951 */           return (param2Labeled.graphic == null || !param2Labeled.graphic.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<String> getStyleableProperty(Labeled param2Labeled) {
/*  956 */           return param2Labeled.imageUrlProperty();
/*      */         }
/*      */       };
/*      */     
/*  960 */     private static final CssMetaData<Labeled, Boolean> UNDERLINE = new CssMetaData<Labeled, Boolean>("-fx-underline", 
/*      */         
/*  962 */         BooleanConverter.getInstance(), Boolean.FALSE)
/*      */       {
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/*  966 */           return (param2Labeled.underline == null || !param2Labeled.underline.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(Labeled param2Labeled) {
/*  971 */           return (StyleableProperty<Boolean>)param2Labeled.underlineProperty();
/*      */         }
/*      */       };
/*      */     
/*  975 */     private static final CssMetaData<Labeled, Number> LINE_SPACING = new CssMetaData<Labeled, Number>("-fx-line-spacing", 
/*      */         
/*  977 */         SizeConverter.getInstance(), Integer.valueOf(0))
/*      */       {
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/*  981 */           return (param2Labeled.lineSpacing == null || !param2Labeled.lineSpacing.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(Labeled param2Labeled) {
/*  986 */           return (StyleableProperty<Number>)param2Labeled.lineSpacingProperty();
/*      */         }
/*      */       };
/*      */     
/*  990 */     private static final CssMetaData<Labeled, ContentDisplay> CONTENT_DISPLAY = new CssMetaData<Labeled, ContentDisplay>("-fx-content-display", (StyleConverter)new EnumConverter(ContentDisplay.class), ContentDisplay.LEFT)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/*  997 */           return (param2Labeled.contentDisplay == null || !param2Labeled.contentDisplay.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<ContentDisplay> getStyleableProperty(Labeled param2Labeled) {
/* 1002 */           return (StyleableProperty<ContentDisplay>)param2Labeled.contentDisplayProperty();
/*      */         }
/*      */       };
/*      */     
/* 1006 */     private static final CssMetaData<Labeled, Insets> LABEL_PADDING = new CssMetaData<Labeled, Insets>("-fx-label-padding", 
/*      */         
/* 1008 */         InsetsConverter.getInstance(), Insets.EMPTY)
/*      */       {
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/* 1012 */           return (param2Labeled.labelPadding == null || !param2Labeled.labelPadding.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Insets> getStyleableProperty(Labeled param2Labeled) {
/* 1017 */           return (StyleableProperty<Insets>)param2Labeled.labelPaddingPropertyImpl();
/*      */         }
/*      */       };
/*      */     
/* 1021 */     private static final CssMetaData<Labeled, Number> GRAPHIC_TEXT_GAP = new CssMetaData<Labeled, Number>("-fx-graphic-text-gap", 
/*      */         
/* 1023 */         SizeConverter.getInstance(), Double.valueOf(4.0D))
/*      */       {
/*      */         public boolean isSettable(Labeled param2Labeled)
/*      */         {
/* 1027 */           return (param2Labeled.graphicTextGap == null || !param2Labeled.graphicTextGap.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(Labeled param2Labeled) {
/* 1032 */           return (StyleableProperty<Number>)param2Labeled.graphicTextGapProperty();
/*      */         }
/*      */       };
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1039 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 1040 */       Collections.addAll(arrayList, (CssMetaData<? extends Styleable, ?>[])new CssMetaData[] { FONT, ALIGNMENT, TEXT_ALIGNMENT, TEXT_FILL, TEXT_OVERRUN, ELLIPSIS_STRING, WRAP_TEXT, GRAPHIC, UNDERLINE, LINE_SPACING, CONTENT_DISPLAY, LABEL_PADDING, GRAPHIC_TEXT_GAP });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1055 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1065 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 1074 */     return getClassCssMetaData();
/*      */   }
/*      */   
/*      */   public Labeled() {}
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Labeled.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */