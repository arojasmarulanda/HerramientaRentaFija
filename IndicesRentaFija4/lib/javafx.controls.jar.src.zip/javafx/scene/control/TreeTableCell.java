/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Collection;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.Event;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.TreeTableCellSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeTableCell<S, T>
/*     */   extends IndexedCell<T>
/*     */ {
/*     */   boolean lockItemOnEdit;
/*     */   private boolean itemDirty;
/*     */   private ListChangeListener<TreeTablePosition<S, ?>> selectedListener;
/*     */   private final InvalidationListener focusedListener;
/*     */   private final InvalidationListener tableRowUpdateObserver;
/*     */   private final InvalidationListener editingListener;
/*     */   private ListChangeListener<TreeTableColumn<S, ?>> visibleLeafColumnsListener;
/*     */   private ListChangeListener<String> columnStyleClassListener;
/*     */   private final InvalidationListener rootPropertyListener;
/*     */   private final InvalidationListener columnStyleListener;
/*     */   private final InvalidationListener columnIdListener;
/*     */   private final WeakListChangeListener<TreeTablePosition<S, ?>> weakSelectedListener;
/*     */   private final WeakInvalidationListener weakFocusedListener;
/*     */   private final WeakInvalidationListener weaktableRowUpdateObserver;
/*     */   private final WeakInvalidationListener weakEditingListener;
/*     */   private final WeakListChangeListener<TreeTableColumn<S, ?>> weakVisibleLeafColumnsListener;
/*     */   private final WeakListChangeListener<String> weakColumnStyleClassListener;
/*     */   private final WeakInvalidationListener weakColumnStyleListener;
/*     */   private final WeakInvalidationListener weakColumnIdListener;
/*     */   private final WeakInvalidationListener weakRootPropertyListener;
/*     */   private ReadOnlyObjectWrapper<TreeTableColumn<S, T>> treeTableColumn;
/*     */   private ReadOnlyObjectWrapper<TreeTableView<S>> treeTableView;
/*     */   private ReadOnlyObjectWrapper<TreeTableRow<S>> treeTableRow;
/*     */   private boolean isLastVisibleColumn;
/*     */   private int columnIndex;
/*     */   private boolean updateEditingIndex;
/*     */   private ObservableValue<T> currentObservableValue;
/*     */   private boolean isFirstRun;
/*     */   private WeakReference<S> oldRowItemRef;
/*     */   private static final String DEFAULT_STYLE_CLASS = "tree-table-cell";
/*     */   
/*     */   public TreeTableCell() {
/* 102 */     this.lockItemOnEdit = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     this.itemDirty = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     this.selectedListener = (paramChange -> {
/*     */         while (paramChange.next()) {
/*     */           if (paramChange.wasAdded() || paramChange.wasRemoved()) {
/*     */             updateSelection();
/*     */           }
/*     */         } 
/*     */       });
/*     */ 
/*     */     
/* 129 */     this.focusedListener = (paramObservable -> updateFocus());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     this.tableRowUpdateObserver = (paramObservable -> {
/*     */         this.itemDirty = true;
/*     */         
/*     */         requestLayout();
/*     */       });
/* 139 */     this.editingListener = (paramObservable -> updateEditing());
/*     */ 
/*     */ 
/*     */     
/* 143 */     this.visibleLeafColumnsListener = (paramChange -> updateColumnIndex());
/*     */ 
/*     */ 
/*     */     
/* 147 */     this.columnStyleClassListener = (paramChange -> {
/*     */         while (paramChange.next()) {
/*     */           if (paramChange.wasRemoved()) {
/*     */             getStyleClass().removeAll(paramChange.getRemoved());
/*     */           }
/*     */           
/*     */           if (paramChange.wasAdded()) {
/*     */             getStyleClass().addAll((Collection)paramChange.getAddedSubList());
/*     */           }
/*     */         } 
/*     */       });
/*     */     
/* 159 */     this.rootPropertyListener = (paramObservable -> updateItem(-1));
/*     */ 
/*     */ 
/*     */     
/* 163 */     this.columnStyleListener = (paramObservable -> {
/*     */         if (getTableColumn() != null) {
/*     */           possiblySetStyle(getTableColumn().getStyle());
/*     */         }
/*     */       });
/*     */     
/* 169 */     this.columnIdListener = (paramObservable -> {
/*     */         if (getTableColumn() != null) {
/*     */           possiblySetId(getTableColumn().getId());
/*     */         }
/*     */       });
/*     */     
/* 175 */     this.weakSelectedListener = new WeakListChangeListener<>(this.selectedListener);
/*     */     
/* 177 */     this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
/*     */     
/* 179 */     this.weaktableRowUpdateObserver = new WeakInvalidationListener(this.tableRowUpdateObserver);
/*     */     
/* 181 */     this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
/*     */     
/* 183 */     this.weakVisibleLeafColumnsListener = new WeakListChangeListener<>(this.visibleLeafColumnsListener);
/*     */     
/* 185 */     this.weakColumnStyleClassListener = new WeakListChangeListener<>(this.columnStyleClassListener);
/*     */     
/* 187 */     this.weakColumnStyleListener = new WeakInvalidationListener(this.columnStyleListener);
/*     */     
/* 189 */     this.weakColumnIdListener = new WeakInvalidationListener(this.columnIdListener);
/*     */     
/* 191 */     this.weakRootPropertyListener = new WeakInvalidationListener(this.rootPropertyListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     this.treeTableColumn = (ReadOnlyObjectWrapper)new ReadOnlyObjectWrapper<TreeTableColumn<S, TreeTableColumn<S, T>>>(this, "treeTableColumn")
/*     */       {
/*     */         protected void invalidated() {
/* 208 */           TreeTableCell.this.updateColumnIndex();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 289 */     this.treeTableRow = new ReadOnlyObjectWrapper<>(this, "treeTableRow");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 464 */     this.isLastVisibleColumn = false;
/* 465 */     this.columnIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 557 */     this.updateEditingIndex = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 577 */     this.currentObservableValue = null;
/*     */     
/* 579 */     this.isFirstRun = true;
/*     */     getStyleClass().addAll(new String[] { "tree-table-cell" });
/*     */     setAccessibleRole(AccessibleRole.TREE_TABLE_CELL);
/*     */     updateColumnIndex();
/*     */   }
/*     */   public final ReadOnlyObjectProperty<TreeTableColumn<S, T>> tableColumnProperty() {
/*     */     return this.treeTableColumn.getReadOnlyProperty();
/*     */   }
/*     */   private void setTableColumn(TreeTableColumn<S, T> paramTreeTableColumn) {
/*     */     this.treeTableColumn.set(paramTreeTableColumn);
/*     */   }
/*     */   public final TreeTableColumn<S, T> getTableColumn() {
/*     */     return this.treeTableColumn.get();
/*     */   }
/*     */   private void setTreeTableView(TreeTableView<S> paramTreeTableView) {
/*     */     treeTableViewPropertyImpl().set(paramTreeTableView);
/*     */   }
/*     */   public final TreeTableView<S> getTreeTableView() {
/*     */     return (this.treeTableView == null) ? null : this.treeTableView.get();
/*     */   }
/*     */   public final ReadOnlyObjectProperty<TreeTableView<S>> treeTableViewProperty() {
/*     */     return treeTableViewPropertyImpl().getReadOnlyProperty();
/*     */   }
/*     */   private ReadOnlyObjectWrapper<TreeTableView<S>> treeTableViewPropertyImpl() {
/*     */     if (this.treeTableView == null)
/*     */       this.treeTableView = new ReadOnlyObjectWrapper<TreeTableView<S>>(this, "treeTableView") { private WeakReference<TreeTableView<S>> weakTableViewRef;
/*     */           protected void invalidated() {
/*     */             if (this.weakTableViewRef != null) {
/*     */               TreeTableView treeTableView1 = this.weakTableViewRef.get();
/*     */               if (treeTableView1 != null) {
/*     */                 TreeTableView.TreeTableViewSelectionModel treeTableViewSelectionModel = treeTableView1.getSelectionModel();
/*     */                 if (treeTableViewSelectionModel != null)
/*     */                   treeTableViewSelectionModel.getSelectedCells().removeListener(TreeTableCell.this.weakSelectedListener); 
/*     */                 TreeTableView.TreeTableViewFocusModel treeTableViewFocusModel = treeTableView1.getFocusModel();
/*     */                 if (treeTableViewFocusModel != null)
/*     */                   treeTableViewFocusModel.focusedCellProperty().removeListener(TreeTableCell.this.weakFocusedListener); 
/*     */                 treeTableView1.editingCellProperty().removeListener(TreeTableCell.this.weakEditingListener);
/*     */                 treeTableView1.getVisibleLeafColumns().removeListener(TreeTableCell.this.weakVisibleLeafColumnsListener);
/*     */                 treeTableView1.rootProperty().removeListener(TreeTableCell.this.weakRootPropertyListener);
/*     */               } 
/*     */             } 
/*     */             TreeTableView<S> treeTableView = get();
/*     */             if (treeTableView != null) {
/*     */               TreeTableView.TreeTableViewSelectionModel<S> treeTableViewSelectionModel = treeTableView.getSelectionModel();
/*     */               if (treeTableViewSelectionModel != null)
/*     */                 treeTableViewSelectionModel.getSelectedCells().addListener(TreeTableCell.this.weakSelectedListener); 
/*     */               TreeTableView.TreeTableViewFocusModel<S> treeTableViewFocusModel = treeTableView.getFocusModel();
/*     */               if (treeTableViewFocusModel != null)
/*     */                 treeTableViewFocusModel.focusedCellProperty().addListener(TreeTableCell.this.weakFocusedListener); 
/*     */               treeTableView.editingCellProperty().addListener(TreeTableCell.this.weakEditingListener);
/*     */               treeTableView.getVisibleLeafColumns().addListener(TreeTableCell.this.weakVisibleLeafColumnsListener);
/*     */               treeTableView.rootProperty().addListener(TreeTableCell.this.weakRootPropertyListener);
/*     */               this.weakTableViewRef = new WeakReference<>(treeTableView);
/*     */             } 
/*     */             TreeTableCell.this.updateColumnIndex();
/*     */           } }
/*     */         ; 
/*     */     return this.treeTableView;
/*     */   }
/*     */   private void setTreeTableRow(TreeTableRow<S> paramTreeTableRow) {
/*     */     this.treeTableRow.set(paramTreeTableRow);
/*     */   }
/*     */   
/*     */   public final TreeTableRow<S> getTreeTableRow() {
/*     */     return this.treeTableRow.get();
/*     */   }
/*     */   
/*     */   public final ReadOnlyObjectProperty<TreeTableRow<S>> tableRowProperty() {
/*     */     return this.treeTableRow;
/*     */   }
/*     */   
/*     */   public void startEdit() {
/*     */     if (isEditing())
/*     */       return; 
/*     */     TreeTableView<S> treeTableView = getTreeTableView();
/*     */     TreeTableColumn<S, T> treeTableColumn = getTableColumn();
/*     */     if (!isEditable() || (treeTableView != null && !treeTableView.isEditable()) || (treeTableColumn != null && !getTableColumn().isEditable()))
/*     */       return; 
/*     */     if (!this.lockItemOnEdit)
/*     */       updateItem(-1); 
/*     */     super.startEdit();
/*     */     if (treeTableColumn != null) {
/*     */       TreeTableColumn.CellEditEvent<S, Object> cellEditEvent = new TreeTableColumn.CellEditEvent<>(treeTableView, treeTableView.getEditingCell(), TreeTableColumn.editStartEvent(), null);
/*     */       Event.fireEvent(treeTableColumn, cellEditEvent);
/*     */     } 
/*     */   }
/*     */   
/* 666 */   protected void layoutChildren() { if (this.itemDirty) {
/* 667 */       updateItem(-1);
/* 668 */       this.itemDirty = false;
/*     */     } 
/* 670 */     super.layoutChildren(); } public void commitEdit(T paramT) { if (!isEditing())
/*     */       return;  TreeTableView<S> treeTableView = getTreeTableView(); if (treeTableView != null) {
/*     */       TreeTablePosition<S, ?> treeTablePosition = treeTableView.getEditingCell(); TreeTableColumn.CellEditEvent<S, Object> cellEditEvent = new TreeTableColumn.CellEditEvent<>(treeTableView, treeTablePosition, TreeTableColumn.editCommitEvent(), paramT); Event.fireEvent(getTableColumn(), cellEditEvent);
/*     */     }  super.commitEdit(paramT); updateItem(paramT, false); if (treeTableView != null) {
/*     */       treeTableView.edit(-1, null); ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(treeTableView);
/*     */     }  }
/*     */   public void cancelEdit() { if (!isEditing())
/*     */       return;  TreeTableView<S> treeTableView = getTreeTableView(); super.cancelEdit(); if (treeTableView != null) {
/*     */       TreeTablePosition<S, ?> treeTablePosition = treeTableView.getEditingCell(); if (this.updateEditingIndex)
/*     */         treeTableView.edit(-1, null);  ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(treeTableView); TreeTableColumn.CellEditEvent<S, Object> cellEditEvent = new TreeTableColumn.CellEditEvent<>(treeTableView, treeTablePosition, TreeTableColumn.editCancelEvent(), null); Event.fireEvent(getTableColumn(), cellEditEvent);
/*     */     }  }
/*     */   public void updateSelected(boolean paramBoolean) { if (getTreeTableRow() == null || getTreeTableRow().isEmpty())
/*     */       return;  setSelected(paramBoolean); }
/*     */   void indexChanged(int paramInt1, int paramInt2) { super.indexChanged(paramInt1, paramInt2); if (!isEditing() || paramInt2 != paramInt1) {
/*     */       updateItem(paramInt1); updateSelection(); updateFocus();
/*     */       updateEditing();
/*     */     }  }
/*     */   private void updateColumnIndex() { TreeTableView<S> treeTableView = getTreeTableView();
/*     */     TreeTableColumn<S, T> treeTableColumn = getTableColumn();
/*     */     this.columnIndex = (treeTableView == null || treeTableColumn == null) ? -1 : treeTableView.getVisibleLeafIndex(treeTableColumn);
/*     */     this.isLastVisibleColumn = (getTableColumn() != null && this.columnIndex != -1 && this.columnIndex == treeTableView.getVisibleLeafColumns().size() - 1);
/*     */     pseudoClassStateChanged(PSEUDO_CLASS_LAST_VISIBLE, this.isLastVisibleColumn); }
/* 692 */   public final void updateTreeTableView(TreeTableView<S> paramTreeTableView) { setTreeTableView(paramTreeTableView); }
/*     */   private void updateSelection() { if (isEmpty())
/*     */       return;  boolean bool1 = isSelected(); if (!isInCellSelectionMode()) {
/*     */       if (bool1)
/*     */         updateSelected(false);  return;
/*     */     }  TreeTableView<S> treeTableView = getTreeTableView(); if (getIndex() == -1 || treeTableView == null)
/*     */       return;  TreeTableView.TreeTableViewSelectionModel<S> treeTableViewSelectionModel = treeTableView.getSelectionModel(); if (treeTableViewSelectionModel == null) {
/*     */       updateSelected(false); return;
/*     */     } 
/*     */     boolean bool2 = treeTableViewSelectionModel.isSelected(getIndex(), getTableColumn());
/*     */     if (bool1 == bool2)
/*     */       return; 
/* 704 */     updateSelected(bool2); } public final void updateTreeTableRow(TreeTableRow<S> paramTreeTableRow) { setTreeTableRow(paramTreeTableRow); }
/*     */   private void updateFocus() { boolean bool = isFocused(); if (!isInCellSelectionMode()) { if (bool)
/*     */         setFocused(false);  return; }
/*     */      TreeTableView<S> treeTableView = getTreeTableView(); if (getIndex() == -1 || treeTableView == null)
/*     */       return;  TreeTableView.TreeTableViewFocusModel<S> treeTableViewFocusModel = treeTableView.getFocusModel(); if (treeTableViewFocusModel == null) { setFocused(false); return; }
/*     */      setFocused(treeTableViewFocusModel.isFocused(getIndex(), getTableColumn())); }
/*     */   private void updateEditing() { TreeTableView<S> treeTableView = getTreeTableView(); if (getIndex() == -1 || treeTableView == null)
/*     */       return;  TreeTablePosition<S, ?> treeTablePosition = treeTableView.getEditingCell(); boolean bool = match(treeTablePosition); if (bool && !isEditing()) { startEdit(); }
/*     */     else if (!bool && isEditing()) { this.updateEditingIndex = false; cancelEdit(); this.updateEditingIndex = true; }
/*     */      }
/*     */   private boolean match(TreeTablePosition<S, T> paramTreeTablePosition) { return (paramTreeTablePosition != null && paramTreeTablePosition.getRow() == getIndex() && paramTreeTablePosition.getTableColumn() == getTableColumn()); }
/*     */   private boolean isInCellSelectionMode() { TreeTableView<S> treeTableView = getTreeTableView(); if (treeTableView == null)
/*     */       return false;  TreeTableView.TreeTableViewSelectionModel<S> treeTableViewSelectionModel = treeTableView.getSelectionModel(); return (treeTableViewSelectionModel != null && treeTableViewSelectionModel.isCellSelectionEnabled()); }
/*     */   private void updateItem(int paramInt) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   4: ifnull -> 20
/*     */     //   7: aload_0
/*     */     //   8: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   11: aload_0
/*     */     //   12: getfield weaktableRowUpdateObserver : Ljavafx/beans/WeakInvalidationListener;
/*     */     //   15: invokeinterface removeListener : (Ljavafx/beans/InvalidationListener;)V
/*     */     //   20: aload_0
/*     */     //   21: invokevirtual getTreeTableView : ()Ljavafx/scene/control/TreeTableView;
/*     */     //   24: astore_2
/*     */     //   25: aload_0
/*     */     //   26: invokevirtual getTableColumn : ()Ljavafx/scene/control/TreeTableColumn;
/*     */     //   29: astore_3
/*     */     //   30: aload_2
/*     */     //   31: ifnonnull -> 38
/*     */     //   34: iconst_m1
/*     */     //   35: goto -> 45
/*     */     //   38: aload_0
/*     */     //   39: invokevirtual getTreeTableView : ()Ljavafx/scene/control/TreeTableView;
/*     */     //   42: invokevirtual getExpandedItemCount : ()I
/*     */     //   45: istore #4
/*     */     //   47: aload_0
/*     */     //   48: invokevirtual getIndex : ()I
/*     */     //   51: istore #5
/*     */     //   53: aload_0
/*     */     //   54: invokevirtual isEmpty : ()Z
/*     */     //   57: istore #6
/*     */     //   59: aload_0
/*     */     //   60: invokevirtual getItem : ()Ljava/lang/Object;
/*     */     //   63: astore #7
/*     */     //   65: aload_0
/*     */     //   66: invokevirtual getTreeTableRow : ()Ljavafx/scene/control/TreeTableRow;
/*     */     //   69: astore #8
/*     */     //   71: aload #8
/*     */     //   73: ifnonnull -> 80
/*     */     //   76: aconst_null
/*     */     //   77: goto -> 85
/*     */     //   80: aload #8
/*     */     //   82: invokevirtual getItem : ()Ljava/lang/Object;
/*     */     //   85: astore #9
/*     */     //   87: iload #5
/*     */     //   89: iload #4
/*     */     //   91: if_icmplt -> 98
/*     */     //   94: iconst_1
/*     */     //   95: goto -> 99
/*     */     //   98: iconst_0
/*     */     //   99: istore #10
/*     */     //   101: iload #10
/*     */     //   103: ifne -> 143
/*     */     //   106: iload #5
/*     */     //   108: iflt -> 143
/*     */     //   111: aload_0
/*     */     //   112: getfield columnIndex : I
/*     */     //   115: iflt -> 143
/*     */     //   118: aload_0
/*     */     //   119: invokevirtual isVisible : ()Z
/*     */     //   122: ifeq -> 143
/*     */     //   125: aload_3
/*     */     //   126: ifnull -> 143
/*     */     //   129: aload_3
/*     */     //   130: invokevirtual isVisible : ()Z
/*     */     //   133: ifeq -> 143
/*     */     //   136: aload_2
/*     */     //   137: invokevirtual getRoot : ()Ljavafx/scene/control/TreeItem;
/*     */     //   140: ifnonnull -> 177
/*     */     //   143: iload #6
/*     */     //   145: ifne -> 153
/*     */     //   148: aload #7
/*     */     //   150: ifnonnull -> 165
/*     */     //   153: aload_0
/*     */     //   154: getfield isFirstRun : Z
/*     */     //   157: ifne -> 165
/*     */     //   160: iload #10
/*     */     //   162: ifeq -> 176
/*     */     //   165: aload_0
/*     */     //   166: aconst_null
/*     */     //   167: iconst_1
/*     */     //   168: invokevirtual updateItem : (Ljava/lang/Object;Z)V
/*     */     //   171: aload_0
/*     */     //   172: iconst_0
/*     */     //   173: putfield isFirstRun : Z
/*     */     //   176: return
/*     */     //   177: aload_0
/*     */     //   178: aload_3
/*     */     //   179: iload #5
/*     */     //   181: invokevirtual getCellObservableValue : (I)Ljavafx/beans/value/ObservableValue;
/*     */     //   184: putfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   187: aload_0
/*     */     //   188: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   191: ifnonnull -> 198
/*     */     //   194: aconst_null
/*     */     //   195: goto -> 207
/*     */     //   198: aload_0
/*     */     //   199: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   202: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   207: astore #11
/*     */     //   209: iload_1
/*     */     //   210: iload #5
/*     */     //   212: if_icmpne -> 264
/*     */     //   215: aload_0
/*     */     //   216: aload #7
/*     */     //   218: aload #11
/*     */     //   220: invokevirtual isItemChanged : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   223: ifne -> 264
/*     */     //   226: aload_0
/*     */     //   227: getfield oldRowItemRef : Ljava/lang/ref/WeakReference;
/*     */     //   230: ifnull -> 243
/*     */     //   233: aload_0
/*     */     //   234: getfield oldRowItemRef : Ljava/lang/ref/WeakReference;
/*     */     //   237: invokevirtual get : ()Ljava/lang/Object;
/*     */     //   240: goto -> 244
/*     */     //   243: aconst_null
/*     */     //   244: astore #12
/*     */     //   246: aload #12
/*     */     //   248: ifnull -> 264
/*     */     //   251: aload #12
/*     */     //   253: aload #9
/*     */     //   255: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   258: ifeq -> 264
/*     */     //   261: goto -> 271
/*     */     //   264: aload_0
/*     */     //   265: aload #11
/*     */     //   267: iconst_0
/*     */     //   268: invokevirtual updateItem : (Ljava/lang/Object;Z)V
/*     */     //   271: aload_0
/*     */     //   272: new java/lang/ref/WeakReference
/*     */     //   275: dup
/*     */     //   276: aload #9
/*     */     //   278: invokespecial <init> : (Ljava/lang/Object;)V
/*     */     //   281: putfield oldRowItemRef : Ljava/lang/ref/WeakReference;
/*     */     //   284: aload_0
/*     */     //   285: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   288: ifnonnull -> 292
/*     */     //   291: return
/*     */     //   292: aload_0
/*     */     //   293: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   296: aload_0
/*     */     //   297: getfield weaktableRowUpdateObserver : Ljavafx/beans/WeakInvalidationListener;
/*     */     //   300: invokeinterface addListener : (Ljavafx/beans/InvalidationListener;)V
/*     */     //   305: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #589	-> 0
/*     */     //   #590	-> 7
/*     */     //   #594	-> 20
/*     */     //   #595	-> 25
/*     */     //   #596	-> 30
/*     */     //   #597	-> 47
/*     */     //   #598	-> 53
/*     */     //   #599	-> 59
/*     */     //   #601	-> 65
/*     */     //   #602	-> 71
/*     */     //   #604	-> 87
/*     */     //   #607	-> 101
/*     */     //   #610	-> 119
/*     */     //   #612	-> 130
/*     */     //   #613	-> 137
/*     */     //   #626	-> 143
/*     */     //   #627	-> 165
/*     */     //   #628	-> 171
/*     */     //   #630	-> 176
/*     */     //   #632	-> 177
/*     */     //   #634	-> 187
/*     */     //   #638	-> 209
/*     */     //   #639	-> 215
/*     */     //   #643	-> 226
/*     */     //   #644	-> 246
/*     */     //   #648	-> 261
/*     */     //   #652	-> 264
/*     */     //   #655	-> 271
/*     */     //   #657	-> 284
/*     */     //   #658	-> 291
/*     */     //   #662	-> 292
/* 717 */     //   #663	-> 305 } public final void updateTreeTableColumn(TreeTableColumn<S, T> paramTreeTableColumn) { TreeTableColumn<S, T> treeTableColumn = getTableColumn();
/* 718 */     if (treeTableColumn != null) {
/* 719 */       treeTableColumn.getStyleClass().removeListener(this.weakColumnStyleClassListener);
/* 720 */       getStyleClass().removeAll(treeTableColumn.getStyleClass());
/*     */       
/* 722 */       treeTableColumn.idProperty().removeListener(this.weakColumnIdListener);
/* 723 */       treeTableColumn.styleProperty().removeListener(this.weakColumnStyleListener);
/*     */       
/* 725 */       String str1 = getId();
/* 726 */       String str2 = getStyle();
/* 727 */       if (str1 != null && str1.equals(treeTableColumn.getId())) {
/* 728 */         setId(null);
/*     */       }
/* 730 */       if (str2 != null && str2.equals(treeTableColumn.getStyle())) {
/* 731 */         setStyle("");
/*     */       }
/*     */     } 
/*     */     
/* 735 */     setTableColumn(paramTreeTableColumn);
/*     */     
/* 737 */     if (paramTreeTableColumn != null) {
/* 738 */       getStyleClass().addAll(paramTreeTableColumn.getStyleClass());
/* 739 */       paramTreeTableColumn.getStyleClass().addListener(this.weakColumnStyleClassListener);
/*     */       
/* 741 */       paramTreeTableColumn.idProperty().addListener(this.weakColumnIdListener);
/* 742 */       paramTreeTableColumn.styleProperty().addListener(this.weakColumnStyleListener);
/*     */       
/* 744 */       possiblySetId(paramTreeTableColumn.getId());
/* 745 */       possiblySetStyle(paramTreeTableColumn.getStyle());
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 759 */   private static final PseudoClass PSEUDO_CLASS_LAST_VISIBLE = PseudoClass.getPseudoClass("last-visible");
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 763 */     return (Skin<?>)new TreeTableCellSkin(this);
/*     */   }
/*     */   
/*     */   private void possiblySetId(String paramString) {
/* 767 */     if (getId() == null || getId().isEmpty()) {
/* 768 */       setId(paramString);
/*     */     }
/*     */   }
/*     */   
/*     */   private void possiblySetStyle(String paramString) {
/* 773 */     if (getStyle() == null || getStyle().isEmpty()) {
/* 774 */       setStyle(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 788 */     switch (paramAccessibleAttribute) { case REQUEST_FOCUS:
/* 789 */         return Integer.valueOf(getIndex());
/* 790 */       case null: return Integer.valueOf(this.columnIndex);
/* 791 */       case null: return Boolean.valueOf(isInCellSelectionMode() ? isSelected() : getTreeTableRow().isSelected()); }
/* 792 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     TreeTableView<S> treeTableView;
/* 799 */     switch (paramAccessibleAction) {
/*     */       case REQUEST_FOCUS:
/* 801 */         treeTableView = getTreeTableView();
/* 802 */         if (treeTableView != null) {
/* 803 */           TreeTableView.TreeTableViewFocusModel<S> treeTableViewFocusModel = treeTableView.getFocusModel();
/* 804 */           if (treeTableViewFocusModel != null) {
/* 805 */             treeTableViewFocusModel.focus(getIndex(), getTableColumn());
/*     */           }
/*     */         } 
/*     */         return;
/*     */     } 
/* 810 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TreeTableCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */