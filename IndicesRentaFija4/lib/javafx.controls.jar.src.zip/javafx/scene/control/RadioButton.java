/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.RadioButtonSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RadioButton
/*     */   extends ToggleButton
/*     */ {
/*     */   private static final String DEFAULT_STYLE_CLASS = "radio-button";
/*     */   
/*     */   public RadioButton() {
/*  77 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RadioButton(String paramString) {
/*  86 */     setText(paramString);
/*  87 */     initialize();
/*     */   }
/*     */   
/*     */   private void initialize() {
/*  91 */     getStyleClass().setAll(new String[] { "radio-button" });
/*  92 */     setAccessibleRole(AccessibleRole.RADIO_BUTTON);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     ((StyleableProperty<Pos>)alignmentProperty()).applyStyle(null, Pos.CENTER_LEFT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fire() {
/* 112 */     if (getToggleGroup() == null || !isSelected()) {
/* 113 */       super.fire();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 119 */     return (Skin<?>)new RadioButtonSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Pos getInitialAlignment() {
/* 139 */     return Pos.CENTER_LEFT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 151 */     switch (paramAccessibleAttribute) { case SELECTED:
/* 152 */         return Boolean.valueOf(isSelected()); }
/* 153 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\RadioButton.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */