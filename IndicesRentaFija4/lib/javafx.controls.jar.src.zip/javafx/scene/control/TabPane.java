/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.collections.UnmodifiableListSet;
/*     */ import com.sun.javafx.scene.control.TabObservableList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javafx.beans.DefaultProperty;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.TabPaneSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @DefaultProperty("tabs")
/*     */ public class TabPane
/*     */   extends Control
/*     */ {
/*     */   private static final double DEFAULT_TAB_MIN_WIDTH = 0.0D;
/*     */   private static final double DEFAULT_TAB_MAX_WIDTH = 1.7976931348623157E308D;
/*     */   private static final double DEFAULT_TAB_MIN_HEIGHT = 0.0D;
/*     */   private static final double DEFAULT_TAB_MAX_HEIGHT = 1.7976931348623157E308D;
/*     */   public static final String STYLE_CLASS_FLOATING = "floating";
/*     */   private ObservableList<Tab> tabs;
/*     */   private ObjectProperty<SingleSelectionModel<Tab>> selectionModel;
/*     */   private ObjectProperty<Side> side;
/*     */   private ObjectProperty<TabClosingPolicy> tabClosingPolicy;
/*     */   private BooleanProperty rotateGraphic;
/*     */   private DoubleProperty tabMinWidth;
/*     */   private DoubleProperty tabMaxWidth;
/*     */   private DoubleProperty tabMinHeight;
/*     */   private DoubleProperty tabMaxHeight;
/*     */   
/*     */   public TabPane() {
/* 111 */     this((Tab[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TabPane(Tab... paramVarArgs) {
/* 154 */     this.tabs = (ObservableList<Tab>)new TabObservableList(new ArrayList());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     this.selectionModel = new SimpleObjectProperty<>(this, "selectionModel"); getStyleClass().setAll(new String[] { "tab-pane" }); setAccessibleRole(AccessibleRole.TAB_PANE); setSelectionModel(new TabPaneSelectionModel(this)); this.tabs.addListener(paramChange -> { while (paramChange.next()) { for (Tab tab : paramChange.getRemoved()) { if (tab != null && !getTabs().contains(tab))
/*     */                 tab.setTabPane(null);  }
/*     */              for (Tab tab : paramChange.getAddedSubList()) { if (tab != null)
/*     */                 tab.setTabPane(this);  }
/*     */              }
/*     */         
/*     */         }); if (paramVarArgs != null)
/* 178 */       getTabs().addAll(paramVarArgs);  Side side = getSide(); pseudoClassStateChanged(TOP_PSEUDOCLASS_STATE, (side == Side.TOP)); pseudoClassStateChanged(RIGHT_PSEUDOCLASS_STATE, (side == Side.RIGHT)); pseudoClassStateChanged(BOTTOM_PSEUDOCLASS_STATE, (side == Side.BOTTOM)); pseudoClassStateChanged(LEFT_PSEUDOCLASS_STATE, (side == Side.LEFT)); } public final void setSelectionModel(SingleSelectionModel<Tab> paramSingleSelectionModel) { this.selectionModel.set(paramSingleSelectionModel); }
/*     */   
/*     */   public final ObservableList<Tab> getTabs() {
/*     */     return this.tabs;
/*     */   }
/*     */   public final SingleSelectionModel<Tab> getSelectionModel() {
/* 184 */     return this.selectionModel.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<SingleSelectionModel<Tab>> selectionModelProperty() {
/* 190 */     return this.selectionModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSide(Side paramSide) {
/* 202 */     sideProperty().set(paramSide);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Side getSide() {
/* 212 */     return (this.side == null) ? Side.TOP : this.side.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<Side> sideProperty() {
/* 220 */     if (this.side == null) {
/* 221 */       this.side = new ObjectPropertyBase<Side>(Side.TOP) {
/*     */           private Side oldSide;
/*     */           
/*     */           protected void invalidated() {
/* 225 */             this.oldSide = get();
/*     */             
/* 227 */             TabPane.this.pseudoClassStateChanged(TabPane.TOP_PSEUDOCLASS_STATE, (this.oldSide == Side.TOP || this.oldSide == null));
/* 228 */             TabPane.this.pseudoClassStateChanged(TabPane.RIGHT_PSEUDOCLASS_STATE, (this.oldSide == Side.RIGHT));
/* 229 */             TabPane.this.pseudoClassStateChanged(TabPane.BOTTOM_PSEUDOCLASS_STATE, (this.oldSide == Side.BOTTOM));
/* 230 */             TabPane.this.pseudoClassStateChanged(TabPane.LEFT_PSEUDOCLASS_STATE, (this.oldSide == Side.LEFT));
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 235 */             return TabPane.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 240 */             return "side";
/*     */           }
/*     */         };
/*     */     }
/* 244 */     return this.side;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTabClosingPolicy(TabClosingPolicy paramTabClosingPolicy) {
/* 269 */     tabClosingPolicyProperty().set(paramTabClosingPolicy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TabClosingPolicy getTabClosingPolicy() {
/* 278 */     return (this.tabClosingPolicy == null) ? TabClosingPolicy.SELECTED_TAB : this.tabClosingPolicy.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<TabClosingPolicy> tabClosingPolicyProperty() {
/* 286 */     if (this.tabClosingPolicy == null) {
/* 287 */       this.tabClosingPolicy = new SimpleObjectProperty<>(this, "tabClosingPolicy", TabClosingPolicy.SELECTED_TAB);
/*     */     }
/* 289 */     return this.tabClosingPolicy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setRotateGraphic(boolean paramBoolean) {
/* 306 */     rotateGraphicProperty().set(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isRotateGraphic() {
/* 316 */     return (this.rotateGraphic == null) ? false : this.rotateGraphic.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BooleanProperty rotateGraphicProperty() {
/* 324 */     if (this.rotateGraphic == null) {
/* 325 */       this.rotateGraphic = new SimpleBooleanProperty(this, "rotateGraphic", false);
/*     */     }
/* 327 */     return this.rotateGraphic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTabMinWidth(double paramDouble) {
/* 343 */     tabMinWidthProperty().setValue(Double.valueOf(paramDouble));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getTabMinWidth() {
/* 352 */     return (this.tabMinWidth == null) ? 0.0D : this.tabMinWidth.getValue().doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DoubleProperty tabMinWidthProperty() {
/* 360 */     if (this.tabMinWidth == null) {
/* 361 */       this.tabMinWidth = new StyleableDoubleProperty(0.0D)
/*     */         {
/*     */           public CssMetaData<TabPane, Number> getCssMetaData()
/*     */           {
/* 365 */             return TabPane.StyleableProperties.TAB_MIN_WIDTH;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 370 */             return TabPane.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 375 */             return "tabMinWidth";
/*     */           }
/*     */         };
/*     */     }
/* 379 */     return this.tabMinWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTabMaxWidth(double paramDouble) {
/* 392 */     tabMaxWidthProperty().setValue(Double.valueOf(paramDouble));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getTabMaxWidth() {
/* 401 */     return (this.tabMaxWidth == null) ? Double.MAX_VALUE : this.tabMaxWidth.getValue().doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DoubleProperty tabMaxWidthProperty() {
/* 409 */     if (this.tabMaxWidth == null) {
/* 410 */       this.tabMaxWidth = new StyleableDoubleProperty(Double.MAX_VALUE)
/*     */         {
/*     */           public CssMetaData<TabPane, Number> getCssMetaData()
/*     */           {
/* 414 */             return TabPane.StyleableProperties.TAB_MAX_WIDTH;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 419 */             return TabPane.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 424 */             return "tabMaxWidth";
/*     */           }
/*     */         };
/*     */     }
/* 428 */     return this.tabMaxWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTabMinHeight(double paramDouble) {
/* 443 */     tabMinHeightProperty().setValue(Double.valueOf(paramDouble));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getTabMinHeight() {
/* 452 */     return (this.tabMinHeight == null) ? 0.0D : this.tabMinHeight.getValue().doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DoubleProperty tabMinHeightProperty() {
/* 460 */     if (this.tabMinHeight == null) {
/* 461 */       this.tabMinHeight = new StyleableDoubleProperty(0.0D)
/*     */         {
/*     */           public CssMetaData<TabPane, Number> getCssMetaData()
/*     */           {
/* 465 */             return TabPane.StyleableProperties.TAB_MIN_HEIGHT;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 470 */             return TabPane.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 475 */             return "tabMinHeight";
/*     */           }
/*     */         };
/*     */     }
/* 479 */     return this.tabMinHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTabMaxHeight(double paramDouble) {
/* 492 */     tabMaxHeightProperty().setValue(Double.valueOf(paramDouble));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getTabMaxHeight() {
/* 501 */     return (this.tabMaxHeight == null) ? Double.MAX_VALUE : this.tabMaxHeight.getValue().doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DoubleProperty tabMaxHeightProperty() {
/* 509 */     if (this.tabMaxHeight == null) {
/* 510 */       this.tabMaxHeight = new StyleableDoubleProperty(Double.MAX_VALUE)
/*     */         {
/*     */           public CssMetaData<TabPane, Number> getCssMetaData()
/*     */           {
/* 514 */             return TabPane.StyleableProperties.TAB_MAX_HEIGHT;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 519 */             return TabPane.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 524 */             return "tabMaxHeight";
/*     */           }
/*     */         };
/*     */     }
/* 528 */     return this.tabMaxHeight;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 533 */     return (Skin<?>)new TabPaneSkin(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node lookup(String paramString) {
/* 538 */     Node node = super.lookup(paramString);
/* 539 */     if (node == null)
/* 540 */       for (Tab tab : this.tabs) {
/* 541 */         node = tab.lookup(paramString);
/* 542 */         if (node != null)
/*     */           break; 
/*     */       }  
/* 545 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Node> lookupAll(String paramString) {
/* 551 */     if (paramString == null) return null;
/*     */     
/* 553 */     ArrayList<Node> arrayList = new ArrayList();
/*     */     
/* 555 */     arrayList.addAll(super.lookupAll(paramString));
/* 556 */     for (Tab tab : this.tabs) {
/* 557 */       arrayList.addAll(tab.lookupAll(paramString));
/*     */     }
/*     */     
/* 560 */     return new UnmodifiableListSet<>(arrayList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 571 */     private static final CssMetaData<TabPane, Number> TAB_MIN_WIDTH = new CssMetaData<TabPane, Number>("-fx-tab-min-width", 
/*     */         
/* 573 */         SizeConverter.getInstance(), Double.valueOf(0.0D))
/*     */       {
/*     */         public boolean isSettable(TabPane param2TabPane)
/*     */         {
/* 577 */           return (param2TabPane.tabMinWidth == null || !param2TabPane.tabMinWidth.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(TabPane param2TabPane) {
/* 582 */           return (StyleableProperty<Number>)param2TabPane.tabMinWidthProperty();
/*     */         }
/*     */       };
/*     */     
/* 586 */     private static final CssMetaData<TabPane, Number> TAB_MAX_WIDTH = new CssMetaData<TabPane, Number>("-fx-tab-max-width", 
/*     */         
/* 588 */         SizeConverter.getInstance(), Double.valueOf(Double.MAX_VALUE))
/*     */       {
/*     */         public boolean isSettable(TabPane param2TabPane)
/*     */         {
/* 592 */           return (param2TabPane.tabMaxWidth == null || !param2TabPane.tabMaxWidth.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(TabPane param2TabPane) {
/* 597 */           return (StyleableProperty<Number>)param2TabPane.tabMaxWidthProperty();
/*     */         }
/*     */       };
/*     */     
/* 601 */     private static final CssMetaData<TabPane, Number> TAB_MIN_HEIGHT = new CssMetaData<TabPane, Number>("-fx-tab-min-height", 
/*     */         
/* 603 */         SizeConverter.getInstance(), Double.valueOf(0.0D))
/*     */       {
/*     */         public boolean isSettable(TabPane param2TabPane)
/*     */         {
/* 607 */           return (param2TabPane.tabMinHeight == null || !param2TabPane.tabMinHeight.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(TabPane param2TabPane) {
/* 612 */           return (StyleableProperty<Number>)param2TabPane.tabMinHeightProperty();
/*     */         }
/*     */       };
/*     */     
/* 616 */     private static final CssMetaData<TabPane, Number> TAB_MAX_HEIGHT = new CssMetaData<TabPane, Number>("-fx-tab-max-height", 
/*     */         
/* 618 */         SizeConverter.getInstance(), Double.valueOf(Double.MAX_VALUE))
/*     */       {
/*     */         public boolean isSettable(TabPane param2TabPane)
/*     */         {
/* 622 */           return (param2TabPane.tabMaxHeight == null || !param2TabPane.tabMaxHeight.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(TabPane param2TabPane) {
/* 627 */           return (StyleableProperty<Number>)param2TabPane.tabMaxHeightProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 634 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 635 */       arrayList.add(TAB_MIN_WIDTH);
/* 636 */       arrayList.add(TAB_MAX_WIDTH);
/* 637 */       arrayList.add(TAB_MIN_HEIGHT);
/* 638 */       arrayList.add(TAB_MAX_HEIGHT);
/* 639 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 649 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 658 */     return getClassCssMetaData();
/*     */   }
/*     */   
/* 661 */   private static final PseudoClass TOP_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("top");
/* 662 */   private static final PseudoClass BOTTOM_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("bottom");
/* 663 */   private static final PseudoClass LEFT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("left");
/* 664 */   private static final PseudoClass RIGHT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("right");
/*     */   
/*     */   private ObjectProperty<TabDragPolicy> tabDragPolicy;
/*     */ 
/*     */   
/*     */   static class TabPaneSelectionModel
/*     */     extends SingleSelectionModel<Tab>
/*     */   {
/*     */     private final TabPane tabPane;
/*     */ 
/*     */     
/*     */     public TabPaneSelectionModel(TabPane param1TabPane) {
/* 676 */       if (param1TabPane == null) {
/* 677 */         throw new NullPointerException("TabPane can not be null");
/*     */       }
/* 679 */       this.tabPane = param1TabPane;
/*     */ 
/*     */       
/* 682 */       ListChangeListener<? super Tab> listChangeListener = param1Change -> {
/*     */           while (param1Change.next()) {
/*     */             for (Tab tab : param1Change.getRemoved()) {
/*     */               if (tab != null && !this.tabPane.getTabs().contains(tab) && tab.isSelected()) {
/*     */                 tab.setSelected(false);
/*     */ 
/*     */                 
/*     */                 int i = param1Change.getFrom();
/*     */ 
/*     */                 
/*     */                 findNearestAvailableTab(i, true);
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/*     */             if (param1Change.wasAdded() || param1Change.wasRemoved()) {
/*     */               if (getSelectedIndex() != this.tabPane.getTabs().indexOf(getSelectedItem())) {
/*     */                 clearAndSelect(this.tabPane.getTabs().indexOf(getSelectedItem()));
/*     */               }
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/*     */           if (getSelectedIndex() == -1 && getSelectedItem() == null && this.tabPane.getTabs().size() > 0) {
/*     */             findNearestAvailableTab(0, true);
/*     */           } else if (this.tabPane.getTabs().isEmpty()) {
/*     */             clearSelection();
/*     */           } 
/*     */         };
/*     */       
/* 712 */       if (this.tabPane.getTabs() != null) {
/* 713 */         this.tabPane.getTabs().addListener(listChangeListener);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void select(int param1Int) {
/* 719 */       if (param1Int < 0 || (getItemCount() > 0 && param1Int >= getItemCount()) || (param1Int == 
/* 720 */         getSelectedIndex() && getModelItem(param1Int).isSelected())) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 725 */       if (getSelectedIndex() >= 0 && getSelectedIndex() < this.tabPane.getTabs().size()) {
/* 726 */         ((Tab)this.tabPane.getTabs().get(getSelectedIndex())).setSelected(false);
/*     */       }
/*     */       
/* 729 */       setSelectedIndex(param1Int);
/*     */       
/* 731 */       Tab tab = getModelItem(param1Int);
/* 732 */       if (tab != null) {
/* 733 */         setSelectedItem(tab);
/*     */       }
/*     */ 
/*     */       
/* 737 */       if (getSelectedIndex() >= 0 && getSelectedIndex() < this.tabPane.getTabs().size()) {
/* 738 */         ((Tab)this.tabPane.getTabs().get(getSelectedIndex())).setSelected(true);
/*     */       }
/*     */ 
/*     */       
/* 742 */       this.tabPane.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
/*     */     }
/*     */     
/*     */     public void select(Tab param1Tab) {
/* 746 */       int i = getItemCount();
/*     */       
/* 748 */       for (byte b = 0; b < i; b++) {
/* 749 */         Tab tab = getModelItem(b);
/* 750 */         if (tab != null && tab.equals(param1Tab)) {
/* 751 */           select(b);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     protected Tab getModelItem(int param1Int) {
/* 758 */       ObservableList<Tab> observableList = this.tabPane.getTabs();
/* 759 */       if (observableList == null) return null; 
/* 760 */       if (param1Int < 0 || param1Int >= observableList.size()) return null; 
/* 761 */       return observableList.get(param1Int);
/*     */     }
/*     */     
/*     */     protected int getItemCount() {
/* 765 */       ObservableList<Tab> observableList = this.tabPane.getTabs();
/* 766 */       return (observableList == null) ? 0 : observableList.size();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Tab findNearestAvailableTab(int param1Int, boolean param1Boolean) {
/* 772 */       int i = getItemCount();
/* 773 */       byte b = 1;
/* 774 */       Tab tab = null;
/*     */       
/*     */       while (true) {
/* 777 */         int j = param1Int - b;
/* 778 */         if (j >= 0) {
/* 779 */           Tab tab1 = getModelItem(j);
/* 780 */           if (tab1 != null && !tab1.isDisable()) {
/* 781 */             tab = tab1;
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 791 */         int k = param1Int + b - 1;
/* 792 */         if (k < i) {
/* 793 */           Tab tab1 = getModelItem(k);
/* 794 */           if (tab1 != null && !tab1.isDisable()) {
/* 795 */             tab = tab1;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 800 */         if (j < 0 && k >= i) {
/*     */           break;
/*     */         }
/* 803 */         b++;
/*     */       } 
/*     */       
/* 806 */       if (param1Boolean && tab != null) {
/* 807 */         select(tab);
/*     */       }
/*     */       
/* 810 */       return tab;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum TabClosingPolicy
/*     */   {
/* 836 */     SELECTED_TAB,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 841 */     ALL_TABS,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 846 */     UNAVAILABLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<TabDragPolicy> tabDragPolicyProperty() {
/* 861 */     if (this.tabDragPolicy == null) {
/* 862 */       this.tabDragPolicy = new SimpleObjectProperty<>(this, "tabDragPolicy", TabDragPolicy.FIXED);
/*     */     }
/* 864 */     return this.tabDragPolicy;
/*     */   }
/*     */   public final void setTabDragPolicy(TabDragPolicy paramTabDragPolicy) {
/* 867 */     tabDragPolicyProperty().set(paramTabDragPolicy);
/*     */   }
/*     */   public final TabDragPolicy getTabDragPolicy() {
/* 870 */     return tabDragPolicyProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum TabDragPolicy
/*     */   {
/* 882 */     FIXED,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 896 */     REORDER;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TabPane.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */