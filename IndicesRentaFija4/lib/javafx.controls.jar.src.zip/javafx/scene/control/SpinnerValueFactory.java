/*      */ package javafx.scene.control;
/*      */ 
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.math.BigDecimal;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.ParseException;
/*      */ import java.time.Duration;
/*      */ import java.time.LocalDate;
/*      */ import java.time.LocalTime;
/*      */ import java.time.format.DateTimeFormatter;
/*      */ import java.time.format.FormatStyle;
/*      */ import java.time.temporal.ChronoUnit;
/*      */ import java.time.temporal.TemporalUnit;
/*      */ import javafx.beans.NamedArg;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.IntegerProperty;
/*      */ import javafx.beans.property.LongProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.property.SimpleDoubleProperty;
/*      */ import javafx.beans.property.SimpleIntegerProperty;
/*      */ import javafx.beans.property.SimpleLongProperty;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.collections.WeakListChangeListener;
/*      */ import javafx.util.StringConverter;
/*      */ import javafx.util.converter.IntegerStringConverter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class SpinnerValueFactory<T>
/*      */ {
/*  136 */   private ObjectProperty<T> value = new SimpleObjectProperty<>(this, "value"); public abstract void decrement(int paramInt); public abstract void increment(int paramInt);
/*      */   public final T getValue() {
/*  138 */     return this.value.get();
/*      */   }
/*      */   public final void setValue(T paramT) {
/*  141 */     this.value.set(paramT);
/*      */   }
/*      */   public final ObjectProperty<T> valueProperty() {
/*  144 */     return this.value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  155 */   private ObjectProperty<StringConverter<T>> converter = new SimpleObjectProperty<>(this, "converter"); private BooleanProperty wrapAround;
/*      */   public final StringConverter<T> getConverter() {
/*  157 */     return this.converter.get();
/*      */   }
/*      */   public final void setConverter(StringConverter<T> paramStringConverter) {
/*  160 */     this.converter.set(paramStringConverter);
/*      */   }
/*      */   public final ObjectProperty<StringConverter<T>> converterProperty() {
/*  163 */     return this.converter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setWrapAround(boolean paramBoolean) {
/*  175 */     wrapAroundProperty().set(paramBoolean);
/*      */   }
/*      */   public final boolean isWrapAround() {
/*  178 */     return (this.wrapAround == null) ? false : this.wrapAround.get();
/*      */   }
/*      */   public final BooleanProperty wrapAroundProperty() {
/*  181 */     if (this.wrapAround == null) {
/*  182 */       this.wrapAround = new SimpleBooleanProperty(this, "wrapAround", false);
/*      */     }
/*  184 */     return this.wrapAround;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ListSpinnerValueFactory<T>
/*      */     extends SpinnerValueFactory<T>
/*      */   {
/*  228 */     private int currentIndex = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ListChangeListener<T> itemsContentObserver = param1Change -> updateCurrentIndex();
/*      */ 
/*      */ 
/*      */     
/*  237 */     private WeakListChangeListener<T> weakItemsContentObserver = new WeakListChangeListener<>(this.itemsContentObserver);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ObjectProperty<ObservableList<T>> items;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ListSpinnerValueFactory(@NamedArg("items") ObservableList<T> param1ObservableList) {
/*  255 */       setItems(param1ObservableList);
/*  256 */       setConverter(new StringConverter<T>() {
/*      */             public String toString(T param2T) {
/*  258 */               if (param2T == null) {
/*  259 */                 return "";
/*      */               }
/*  261 */               return param2T.toString();
/*      */             }
/*      */             
/*      */             public T fromString(String param2String) {
/*  265 */               return (T)param2String;
/*      */             }
/*      */           });
/*      */       
/*  269 */       valueProperty().addListener((param1ObservableValue, param1Object1, param1Object2) -> {
/*      */             int i = -1;
/*      */             
/*      */             if (param1ObservableList.contains(param1Object2)) {
/*      */               i = param1ObservableList.indexOf(param1Object2);
/*      */             } else {
/*      */               param1ObservableList.add(param1Object2);
/*      */               
/*      */               i = param1ObservableList.indexOf(param1Object2);
/*      */             } 
/*      */             
/*      */             this.currentIndex = i;
/*      */           });
/*  282 */       setValue(_getValue(this.currentIndex));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setItems(ObservableList<T> param1ObservableList) {
/*  301 */       itemsProperty().set(param1ObservableList);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final ObservableList<T> getItems() {
/*  314 */       return (this.items == null) ? null : this.items.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final ObjectProperty<ObservableList<T>> itemsProperty() {
/*  323 */       if (this.items == null) {
/*  324 */         this.items = (ObjectProperty)new SimpleObjectProperty<ObservableList<ObservableList<T>>>(this, "items") {
/*      */             WeakReference<ObservableList<T>> oldItemsRef;
/*      */             
/*      */             protected void invalidated() {
/*  328 */               ObservableList observableList1 = (this.oldItemsRef == null) ? null : this.oldItemsRef.get();
/*  329 */               ObservableList observableList2 = SpinnerValueFactory.ListSpinnerValueFactory.this.getItems();
/*      */ 
/*      */               
/*  332 */               if (observableList1 != null) {
/*  333 */                 observableList1.removeListener(SpinnerValueFactory.ListSpinnerValueFactory.this.weakItemsContentObserver);
/*      */               }
/*  335 */               if (observableList2 != null) {
/*  336 */                 observableList2.addListener(SpinnerValueFactory.ListSpinnerValueFactory.this.weakItemsContentObserver);
/*      */               }
/*      */ 
/*      */               
/*  340 */               SpinnerValueFactory.ListSpinnerValueFactory.this.updateCurrentIndex();
/*      */               
/*  342 */               this.oldItemsRef = new WeakReference<>(SpinnerValueFactory.ListSpinnerValueFactory.this.getItems());
/*      */             }
/*      */           };
/*      */       }
/*  346 */       return this.items;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void decrement(int param1Int) {
/*  359 */       int i = getItemsSize() - 1;
/*  360 */       int j = this.currentIndex - param1Int;
/*  361 */       this.currentIndex = (j >= 0) ? j : (isWrapAround() ? Spinner.wrapValue(j, 0, i + 1) : 0);
/*  362 */       setValue(_getValue(this.currentIndex));
/*      */     }
/*      */ 
/*      */     
/*      */     public void increment(int param1Int) {
/*  367 */       int i = getItemsSize() - 1;
/*  368 */       int j = this.currentIndex + param1Int;
/*  369 */       this.currentIndex = (j <= i) ? j : (isWrapAround() ? Spinner.wrapValue(j, 0, i + 1) : i);
/*  370 */       setValue(_getValue(this.currentIndex));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int getItemsSize() {
/*  381 */       ObservableList<T> observableList = getItems();
/*  382 */       return (observableList == null) ? 0 : observableList.size();
/*      */     }
/*      */     
/*      */     private void updateCurrentIndex() {
/*  386 */       int i = getItemsSize();
/*  387 */       if (this.currentIndex < 0 || this.currentIndex >= i) {
/*  388 */         this.currentIndex = 0;
/*      */       }
/*  390 */       setValue(_getValue(this.currentIndex));
/*      */     }
/*      */     
/*      */     private T _getValue(int param1Int) {
/*  394 */       ObservableList<T> observableList = getItems();
/*  395 */       return (observableList == null) ? null : ((param1Int >= 0 && param1Int < observableList.size()) ? observableList.get(param1Int) : null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class IntegerSpinnerValueFactory
/*      */     extends SpinnerValueFactory<Integer>
/*      */   {
/*      */     private IntegerProperty min;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private IntegerProperty max;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private IntegerProperty amountToStepBy;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IntegerSpinnerValueFactory(@NamedArg("min") int param1Int1, @NamedArg("max") int param1Int2) {
/*  427 */       this(param1Int1, param1Int2, param1Int1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IntegerSpinnerValueFactory(@NamedArg("min") int param1Int1, @NamedArg("max") int param1Int2, @NamedArg("initialValue") int param1Int3) {
/*  443 */       this(param1Int1, param1Int2, param1Int3, 1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setMin(int param1Int) {
/*      */       this.min.set(param1Int);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final int getMin() {
/*      */       return this.min.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final IntegerProperty minProperty() {
/*      */       return this.min;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IntegerSpinnerValueFactory(@NamedArg("min") int param1Int1, @NamedArg("max") int param1Int2, @NamedArg("initialValue") int param1Int3, @NamedArg("amountToStepBy") int param1Int4) {
/*  485 */       this.min = new SimpleIntegerProperty(this, "min") {
/*      */           protected void invalidated() {
/*  487 */             Integer integer = SpinnerValueFactory.IntegerSpinnerValueFactory.this.getValue();
/*  488 */             if (integer == null) {
/*      */               return;
/*      */             }
/*      */             
/*  492 */             int i = get();
/*  493 */             if (i > SpinnerValueFactory.IntegerSpinnerValueFactory.this.getMax()) {
/*  494 */               SpinnerValueFactory.IntegerSpinnerValueFactory.this.setMin(SpinnerValueFactory.IntegerSpinnerValueFactory.this.getMax());
/*      */               
/*      */               return;
/*      */             } 
/*  498 */             if (integer.intValue() < i) {
/*  499 */               SpinnerValueFactory.IntegerSpinnerValueFactory.this.setValue(Integer.valueOf(i));
/*      */             }
/*      */           }
/*      */         };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  519 */       this.max = new SimpleIntegerProperty(this, "max") {
/*      */           protected void invalidated() {
/*  521 */             Integer integer = SpinnerValueFactory.IntegerSpinnerValueFactory.this.getValue();
/*  522 */             if (integer == null) {
/*      */               return;
/*      */             }
/*      */             
/*  526 */             int i = get();
/*  527 */             if (i < SpinnerValueFactory.IntegerSpinnerValueFactory.this.getMin()) {
/*  528 */               SpinnerValueFactory.IntegerSpinnerValueFactory.this.setMax(SpinnerValueFactory.IntegerSpinnerValueFactory.this.getMin());
/*      */               
/*      */               return;
/*      */             } 
/*  532 */             if (integer.intValue() > i) {
/*  533 */               SpinnerValueFactory.IntegerSpinnerValueFactory.this.setValue(Integer.valueOf(i));
/*      */             }
/*      */           }
/*      */         };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  553 */       this.amountToStepBy = new SimpleIntegerProperty(this, "amountToStepBy"); setMin(param1Int1); setMax(param1Int2); setAmountToStepBy(param1Int4); setConverter(new IntegerStringConverter()); valueProperty().addListener((param1ObservableValue, param1Integer1, param1Integer2) -> { if (param1Integer2.intValue() < getMin()) { setValue(Integer.valueOf(getMin())); } else if (param1Integer2.intValue() > getMax()) { setValue(Integer.valueOf(getMax())); }  }); setValue(Integer.valueOf((param1Int3 >= param1Int1 && param1Int3 <= param1Int2) ? param1Int3 : param1Int1));
/*      */     }
/*  555 */     public final void setMax(int param1Int) { this.max.set(param1Int); } public final int getMax() { return this.max.get(); } public final IntegerProperty maxProperty() { return this.max; } public final void setAmountToStepBy(int param1Int) { this.amountToStepBy.set(param1Int); }
/*      */     
/*      */     public final int getAmountToStepBy() {
/*  558 */       return this.amountToStepBy.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final IntegerProperty amountToStepByProperty() {
/*  565 */       return this.amountToStepBy;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void decrement(int param1Int) {
/*  578 */       int i = getMin();
/*  579 */       int j = getMax();
/*  580 */       int k = getValue().intValue() - param1Int * getAmountToStepBy();
/*  581 */       setValue(Integer.valueOf((k >= i) ? k : (isWrapAround() ? (Spinner.wrapValue(k, i, j) + 1) : i)));
/*      */     }
/*      */ 
/*      */     
/*      */     public void increment(int param1Int) {
/*  586 */       int i = getMin();
/*  587 */       int j = getMax();
/*  588 */       int k = getValue().intValue();
/*  589 */       int m = k + param1Int * getAmountToStepBy();
/*  590 */       setValue(Integer.valueOf((m <= j) ? m : (isWrapAround() ? (Spinner.wrapValue(m, i, j) - 1) : j)));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DoubleSpinnerValueFactory
/*      */     extends SpinnerValueFactory<Double>
/*      */   {
/*      */     private DoubleProperty min;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private DoubleProperty max;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private DoubleProperty amountToStepBy;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DoubleSpinnerValueFactory(@NamedArg("min") double param1Double1, @NamedArg("max") double param1Double2) {
/*  656 */       this(param1Double1, param1Double2, param1Double1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DoubleSpinnerValueFactory(@NamedArg("min") double param1Double1, @NamedArg("max") double param1Double2, @NamedArg("initialValue") double param1Double3) {
/*  672 */       this(param1Double1, param1Double2, param1Double3, 1.0D);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setMin(double param1Double) {
/*      */       this.min.set(param1Double);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final double getMin() {
/*      */       return this.min.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final DoubleProperty minProperty() {
/*      */       return this.min;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setMax(double param1Double) {
/*      */       this.max.set(param1Double);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final double getMax() {
/*      */       return this.max.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final DoubleProperty maxProperty() {
/*      */       return this.max;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DoubleSpinnerValueFactory(@NamedArg("min") double param1Double1, @NamedArg("max") double param1Double2, @NamedArg("initialValue") double param1Double3, @NamedArg("amountToStepBy") double param1Double4) {
/*  748 */       this.min = new SimpleDoubleProperty(this, "min") {
/*      */           protected void invalidated() {
/*  750 */             Double double_ = SpinnerValueFactory.DoubleSpinnerValueFactory.this.getValue();
/*  751 */             if (double_ == null) {
/*      */               return;
/*      */             }
/*      */             
/*  755 */             double d = get();
/*  756 */             if (d > SpinnerValueFactory.DoubleSpinnerValueFactory.this.getMax()) {
/*  757 */               SpinnerValueFactory.DoubleSpinnerValueFactory.this.setMin(SpinnerValueFactory.DoubleSpinnerValueFactory.this.getMax());
/*      */               
/*      */               return;
/*      */             } 
/*  761 */             if (double_.doubleValue() < d) {
/*  762 */               SpinnerValueFactory.DoubleSpinnerValueFactory.this.setValue(Double.valueOf(d));
/*      */             }
/*      */           }
/*      */         };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  782 */       this.max = new SimpleDoubleProperty(this, "max") {
/*      */           protected void invalidated() {
/*  784 */             Double double_ = SpinnerValueFactory.DoubleSpinnerValueFactory.this.getValue();
/*  785 */             if (double_ == null) {
/*      */               return;
/*      */             }
/*      */             
/*  789 */             double d = get();
/*  790 */             if (d < SpinnerValueFactory.DoubleSpinnerValueFactory.this.getMin()) {
/*  791 */               SpinnerValueFactory.DoubleSpinnerValueFactory.this.setMax(SpinnerValueFactory.DoubleSpinnerValueFactory.this.getMin());
/*      */               
/*      */               return;
/*      */             } 
/*  795 */             if (double_.doubleValue() > d) {
/*  796 */               SpinnerValueFactory.DoubleSpinnerValueFactory.this.setValue(Double.valueOf(d));
/*      */             }
/*      */           }
/*      */         };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  816 */       this.amountToStepBy = new SimpleDoubleProperty(this, "amountToStepBy"); setMin(param1Double1); setMax(param1Double2); setAmountToStepBy(param1Double4); setConverter(new StringConverter<Double>() { private final DecimalFormat df = new DecimalFormat("#.##"); public String toString(Double param2Double) { if (param2Double == null) return "";  return this.df.format(param2Double); } public Double fromString(String param2String) { try { if (param2String == null) return null;  param2String = param2String.trim(); if (param2String.length() < 1) return null;  return Double.valueOf(this.df.parse(param2String).doubleValue()); } catch (ParseException parseException) { throw new RuntimeException(parseException); }  } }
/*      */         ); valueProperty().addListener((param1ObservableValue, param1Double1, param1Double2) -> { if (param1Double2 == null) return;  if (param1Double2.doubleValue() < getMin()) { setValue(Double.valueOf(getMin())); } else if (param1Double2.doubleValue() > getMax()) { setValue(Double.valueOf(getMax())); }  }); setValue(Double.valueOf((param1Double3 >= param1Double1 && param1Double3 <= param1Double2) ? param1Double3 : param1Double1));
/*  818 */     } public final void setAmountToStepBy(double param1Double) { this.amountToStepBy.set(param1Double); }
/*      */     
/*      */     public final double getAmountToStepBy() {
/*  821 */       return this.amountToStepBy.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final DoubleProperty amountToStepByProperty() {
/*  828 */       return this.amountToStepBy;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void decrement(int param1Int) {
/*  835 */       BigDecimal bigDecimal1 = BigDecimal.valueOf(getValue().doubleValue());
/*  836 */       BigDecimal bigDecimal2 = BigDecimal.valueOf(getMin());
/*  837 */       BigDecimal bigDecimal3 = BigDecimal.valueOf(getMax());
/*  838 */       BigDecimal bigDecimal4 = BigDecimal.valueOf(getAmountToStepBy());
/*  839 */       BigDecimal bigDecimal5 = bigDecimal1.subtract(bigDecimal4.multiply(BigDecimal.valueOf(param1Int)));
/*  840 */       setValue(Double.valueOf((bigDecimal5.compareTo(bigDecimal2) >= 0) ? bigDecimal5.doubleValue() : (
/*  841 */             isWrapAround() ? Spinner.wrapValue(bigDecimal5, bigDecimal2, bigDecimal3).doubleValue() : getMin())));
/*      */     }
/*      */ 
/*      */     
/*      */     public void increment(int param1Int) {
/*  846 */       BigDecimal bigDecimal1 = BigDecimal.valueOf(getValue().doubleValue());
/*  847 */       BigDecimal bigDecimal2 = BigDecimal.valueOf(getMin());
/*  848 */       BigDecimal bigDecimal3 = BigDecimal.valueOf(getMax());
/*  849 */       BigDecimal bigDecimal4 = BigDecimal.valueOf(getAmountToStepBy());
/*  850 */       BigDecimal bigDecimal5 = bigDecimal1.add(bigDecimal4.multiply(BigDecimal.valueOf(param1Int)));
/*  851 */       setValue(Double.valueOf((bigDecimal5.compareTo(bigDecimal3) <= 0) ? bigDecimal5.doubleValue() : (
/*  852 */             isWrapAround() ? Spinner.wrapValue(bigDecimal5, bigDecimal2, bigDecimal3).doubleValue() : getMax())));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class LocalDateSpinnerValueFactory
/*      */     extends SpinnerValueFactory<LocalDate>
/*      */   {
/*      */     private ObjectProperty<LocalDate> min;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ObjectProperty<LocalDate> max;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ObjectProperty<TemporalUnit> temporalUnit;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private LongProperty amountToStepBy;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LocalDateSpinnerValueFactory() {
/*  886 */       this(LocalDate.now());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LocalDateSpinnerValueFactory(@NamedArg("initialValue") LocalDate param1LocalDate) {
/*  896 */       this(LocalDate.MIN, LocalDate.MAX, param1LocalDate);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LocalDateSpinnerValueFactory(@NamedArg("min") LocalDate param1LocalDate1, @NamedArg("min") LocalDate param1LocalDate2, @NamedArg("initialValue") LocalDate param1LocalDate3) {
/*  910 */       this(param1LocalDate1, param1LocalDate2, param1LocalDate3, 1L, ChronoUnit.DAYS);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setMin(LocalDate param1LocalDate) {
/*      */       this.min.set(param1LocalDate);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final LocalDate getMin() {
/*      */       return this.min.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final ObjectProperty<LocalDate> minProperty() {
/*      */       return this.min;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setMax(LocalDate param1LocalDate) {
/*      */       this.max.set(param1LocalDate);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final LocalDate getMax() {
/*      */       return this.max.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final ObjectProperty<LocalDate> maxProperty() {
/*      */       return this.max;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setTemporalUnit(TemporalUnit param1TemporalUnit) {
/*      */       this.temporalUnit.set(param1TemporalUnit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LocalDateSpinnerValueFactory(@NamedArg("min") LocalDate param1LocalDate1, @NamedArg("min") LocalDate param1LocalDate2, @NamedArg("initialValue") LocalDate param1LocalDate3, @NamedArg("amountToStepBy") long param1Long, @NamedArg("temporalUnit") TemporalUnit param1TemporalUnit) {
/*  975 */       this.min = new SimpleObjectProperty<LocalDate>(this, "min") {
/*      */           protected void invalidated() {
/*  977 */             LocalDate localDate1 = SpinnerValueFactory.LocalDateSpinnerValueFactory.this.getValue();
/*  978 */             if (localDate1 == null) {
/*      */               return;
/*      */             }
/*      */             
/*  982 */             LocalDate localDate2 = get();
/*  983 */             if (localDate2.isAfter(SpinnerValueFactory.LocalDateSpinnerValueFactory.this.getMax())) {
/*  984 */               SpinnerValueFactory.LocalDateSpinnerValueFactory.this.setMin(SpinnerValueFactory.LocalDateSpinnerValueFactory.this.getMax());
/*      */               
/*      */               return;
/*      */             } 
/*  988 */             if (localDate1.isBefore(localDate2)) {
/*  989 */               SpinnerValueFactory.LocalDateSpinnerValueFactory.this.setValue(localDate2);
/*      */             }
/*      */           }
/*      */         };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1008 */       this.max = new SimpleObjectProperty<LocalDate>(this, "max") {
/*      */           protected void invalidated() {
/* 1010 */             LocalDate localDate1 = SpinnerValueFactory.LocalDateSpinnerValueFactory.this.getValue();
/* 1011 */             if (localDate1 == null) {
/*      */               return;
/*      */             }
/*      */             
/* 1015 */             LocalDate localDate2 = get();
/* 1016 */             if (localDate2.isBefore(SpinnerValueFactory.LocalDateSpinnerValueFactory.this.getMin())) {
/* 1017 */               SpinnerValueFactory.LocalDateSpinnerValueFactory.this.setMax(SpinnerValueFactory.LocalDateSpinnerValueFactory.this.getMin());
/*      */               
/*      */               return;
/*      */             } 
/* 1021 */             if (localDate1.isAfter(localDate2)) {
/* 1022 */               SpinnerValueFactory.LocalDateSpinnerValueFactory.this.setValue(localDate2);
/*      */             }
/*      */           }
/*      */         };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1041 */       this.temporalUnit = new SimpleObjectProperty<>(this, "temporalUnit");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1056 */       this.amountToStepBy = new SimpleLongProperty(this, "amountToStepBy"); setMin(param1LocalDate1); setMax(param1LocalDate2); setAmountToStepBy(param1Long); setTemporalUnit(param1TemporalUnit); setConverter(new StringConverter<LocalDate>() { public String toString(LocalDate param2LocalDate) { if (param2LocalDate == null) return "";  return param2LocalDate.toString(); } public LocalDate fromString(String param2String) { return LocalDate.parse(param2String); } }
/*      */         ); valueProperty().addListener((param1ObservableValue, param1LocalDate1, param1LocalDate2) -> { if (getMin() != null && param1LocalDate2.isBefore(getMin())) { setValue(getMin()); } else if (getMax() != null && param1LocalDate2.isAfter(getMax())) { setValue(getMax()); }  }); setValue((param1LocalDate3 != null) ? param1LocalDate3 : LocalDate.now());
/* 1058 */     } public final TemporalUnit getTemporalUnit() { return this.temporalUnit.get(); } public final ObjectProperty<TemporalUnit> temporalUnitProperty() { return this.temporalUnit; } public final void setAmountToStepBy(long param1Long) { this.amountToStepBy.set(param1Long); }
/*      */     
/*      */     public final long getAmountToStepBy() {
/* 1061 */       return this.amountToStepBy.get();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final LongProperty amountToStepByProperty() {
/* 1067 */       return this.amountToStepBy;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void decrement(int param1Int) {
/* 1080 */       LocalDate localDate1 = getValue();
/* 1081 */       LocalDate localDate2 = getMin();
/* 1082 */       LocalDate localDate3 = localDate1.minus(getAmountToStepBy() * param1Int, getTemporalUnit());
/*      */       
/* 1084 */       if (localDate2 != null && isWrapAround() && localDate3.isBefore(localDate2))
/*      */       {
/* 1086 */         localDate3 = getMax();
/*      */       }
/*      */       
/* 1089 */       setValue(localDate3);
/*      */     }
/*      */ 
/*      */     
/*      */     public void increment(int param1Int) {
/* 1094 */       LocalDate localDate1 = getValue();
/* 1095 */       LocalDate localDate2 = getMax();
/* 1096 */       LocalDate localDate3 = localDate1.plus(getAmountToStepBy() * param1Int, getTemporalUnit());
/*      */       
/* 1098 */       if (localDate2 != null && isWrapAround() && localDate3.isAfter(localDate2))
/*      */       {
/* 1100 */         localDate3 = getMin();
/*      */       }
/*      */       
/* 1103 */       setValue(localDate3);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class LocalTimeSpinnerValueFactory
/*      */     extends SpinnerValueFactory<LocalTime>
/*      */   {
/*      */     private ObjectProperty<LocalTime> min;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ObjectProperty<LocalTime> max;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ObjectProperty<TemporalUnit> temporalUnit;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private LongProperty amountToStepBy;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LocalTimeSpinnerValueFactory() {
/* 1141 */       this(LocalTime.now());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LocalTimeSpinnerValueFactory(@NamedArg("initialValue") LocalTime param1LocalTime) {
/* 1151 */       this(LocalTime.MIN, LocalTime.MAX, param1LocalTime);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LocalTimeSpinnerValueFactory(@NamedArg("min") LocalTime param1LocalTime1, @NamedArg("min") LocalTime param1LocalTime2, @NamedArg("initialValue") LocalTime param1LocalTime3) {
/* 1165 */       this(param1LocalTime1, param1LocalTime2, param1LocalTime3, 1L, ChronoUnit.HOURS);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setMin(LocalTime param1LocalTime) {
/*      */       this.min.set(param1LocalTime);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final LocalTime getMin() {
/*      */       return this.min.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final ObjectProperty<LocalTime> minProperty() {
/*      */       return this.min;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setMax(LocalTime param1LocalTime) {
/*      */       this.max.set(param1LocalTime);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final LocalTime getMax() {
/*      */       return this.max.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final ObjectProperty<LocalTime> maxProperty() {
/*      */       return this.max;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setTemporalUnit(TemporalUnit param1TemporalUnit) {
/*      */       this.temporalUnit.set(param1TemporalUnit);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LocalTimeSpinnerValueFactory(@NamedArg("min") LocalTime param1LocalTime1, @NamedArg("min") LocalTime param1LocalTime2, @NamedArg("initialValue") LocalTime param1LocalTime3, @NamedArg("amountToStepBy") long param1Long, @NamedArg("temporalUnit") TemporalUnit param1TemporalUnit) {
/* 1231 */       this.min = new SimpleObjectProperty<LocalTime>(this, "min") {
/*      */           protected void invalidated() {
/* 1233 */             LocalTime localTime1 = SpinnerValueFactory.LocalTimeSpinnerValueFactory.this.getValue();
/* 1234 */             if (localTime1 == null) {
/*      */               return;
/*      */             }
/*      */             
/* 1238 */             LocalTime localTime2 = get();
/* 1239 */             if (localTime2.isAfter(SpinnerValueFactory.LocalTimeSpinnerValueFactory.this.getMax())) {
/* 1240 */               SpinnerValueFactory.LocalTimeSpinnerValueFactory.this.setMin(SpinnerValueFactory.LocalTimeSpinnerValueFactory.this.getMax());
/*      */               
/*      */               return;
/*      */             } 
/* 1244 */             if (localTime1.isBefore(localTime2)) {
/* 1245 */               SpinnerValueFactory.LocalTimeSpinnerValueFactory.this.setValue(localTime2);
/*      */             }
/*      */           }
/*      */         };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1264 */       this.max = new SimpleObjectProperty<LocalTime>(this, "max") {
/*      */           protected void invalidated() {
/* 1266 */             LocalTime localTime1 = SpinnerValueFactory.LocalTimeSpinnerValueFactory.this.getValue();
/* 1267 */             if (localTime1 == null) {
/*      */               return;
/*      */             }
/*      */             
/* 1271 */             LocalTime localTime2 = get();
/* 1272 */             if (localTime2.isBefore(SpinnerValueFactory.LocalTimeSpinnerValueFactory.this.getMin())) {
/* 1273 */               SpinnerValueFactory.LocalTimeSpinnerValueFactory.this.setMax(SpinnerValueFactory.LocalTimeSpinnerValueFactory.this.getMin());
/*      */               
/*      */               return;
/*      */             } 
/* 1277 */             if (localTime1.isAfter(localTime2)) {
/* 1278 */               SpinnerValueFactory.LocalTimeSpinnerValueFactory.this.setValue(localTime2);
/*      */             }
/*      */           }
/*      */         };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1297 */       this.temporalUnit = new SimpleObjectProperty<>(this, "temporalUnit");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1312 */       this.amountToStepBy = new SimpleLongProperty(this, "amountToStepBy"); setMin(param1LocalTime1); setMax(param1LocalTime2); setAmountToStepBy(param1Long); setTemporalUnit(param1TemporalUnit); setConverter(new StringConverter<LocalTime>() { private DateTimeFormatter dtf = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT); public String toString(LocalTime param2LocalTime) { if (param2LocalTime == null) return "";  return param2LocalTime.format(this.dtf); } public LocalTime fromString(String param2String) { return LocalTime.parse(param2String); } }
/*      */         ); valueProperty().addListener((param1ObservableValue, param1LocalTime1, param1LocalTime2) -> { if (getMin() != null && param1LocalTime2.isBefore(getMin())) { setValue(getMin()); } else if (getMax() != null && param1LocalTime2.isAfter(getMax())) { setValue(getMax()); }  }); setValue((param1LocalTime3 != null) ? param1LocalTime3 : LocalTime.now());
/* 1314 */     } public final TemporalUnit getTemporalUnit() { return this.temporalUnit.get(); } public final ObjectProperty<TemporalUnit> temporalUnitProperty() { return this.temporalUnit; } public final void setAmountToStepBy(long param1Long) { this.amountToStepBy.set(param1Long); }
/*      */     
/*      */     public final long getAmountToStepBy() {
/* 1317 */       return this.amountToStepBy.get();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final LongProperty amountToStepByProperty() {
/* 1323 */       return this.amountToStepBy;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void decrement(int param1Int) {
/* 1336 */       LocalTime localTime1 = getValue();
/* 1337 */       LocalTime localTime2 = getMin();
/*      */       
/* 1339 */       Duration duration = Duration.of(getAmountToStepBy() * param1Int, getTemporalUnit());
/*      */       
/* 1341 */       long l1 = duration.toMinutes() * 60L;
/* 1342 */       long l2 = localTime1.toSecondOfDay();
/*      */       
/* 1344 */       if (!isWrapAround() && l1 > l2) {
/* 1345 */         setValue((localTime2 == null) ? LocalTime.MIN : localTime2);
/*      */       } else {
/* 1347 */         setValue(localTime1.minus(duration));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void increment(int param1Int) {
/* 1353 */       LocalTime localTime1 = getValue();
/* 1354 */       LocalTime localTime2 = getMax();
/*      */       
/* 1356 */       Duration duration = Duration.of(getAmountToStepBy() * param1Int, getTemporalUnit());
/*      */       
/* 1358 */       long l1 = duration.toMinutes() * 60L;
/* 1359 */       long l2 = localTime1.toSecondOfDay();
/*      */       
/* 1361 */       if (!isWrapAround() && l1 > LocalTime.MAX.toSecondOfDay() - l2) {
/* 1362 */         setValue((localTime2 == null) ? LocalTime.MAX : localTime2);
/*      */       } else {
/* 1364 */         setValue(localTime1.plus(duration));
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\SpinnerValueFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */