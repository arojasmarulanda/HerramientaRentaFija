/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckBoxTreeItem<T>
/*     */   extends TreeItem<T>
/*     */ {
/*     */   public static <T> EventType<TreeModificationEvent<T>> checkBoxSelectionChangedEvent() {
/* 108 */     return (EventType)CHECK_BOX_SELECTION_CHANGED_EVENT;
/*     */   }
/* 110 */   private static final EventType<? extends Event> CHECK_BOX_SELECTION_CHANGED_EVENT = new EventType<>(TreeModificationEvent.ANY, "checkBoxSelectionChangedEvent");
/*     */ 
/*     */   
/*     */   private final ChangeListener<Boolean> stateChangeListener;
/*     */   
/*     */   private final BooleanProperty selected;
/*     */   
/*     */   private final BooleanProperty indeterminate;
/*     */   
/*     */   private final BooleanProperty independent;
/*     */ 
/*     */   
/*     */   public CheckBoxTreeItem() {
/* 123 */     this((T)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxTreeItem(T paramT) {
/* 133 */     this(paramT, (Node)null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxTreeItem(T paramT, Node paramNode) {
/* 144 */     this(paramT, paramNode, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxTreeItem(T paramT, Node paramNode, boolean paramBoolean) {
/* 158 */     this(paramT, paramNode, paramBoolean, false);
/*     */   }
/*     */   public final void setSelected(boolean paramBoolean) {
/*     */     selectedProperty().setValue(Boolean.valueOf(paramBoolean));
/*     */   } public final boolean isSelected() {
/*     */     return this.selected.getValue().booleanValue();
/*     */   } public final BooleanProperty selectedProperty() {
/*     */     return this.selected;
/*     */   }
/*     */   public final void setIndeterminate(boolean paramBoolean) {
/*     */     indeterminateProperty().setValue(Boolean.valueOf(paramBoolean));
/*     */   }
/*     */   public final boolean isIndeterminate() {
/*     */     return this.indeterminate.getValue().booleanValue();
/*     */   }
/*     */   public final BooleanProperty indeterminateProperty() {
/*     */     return this.indeterminate;
/*     */   }
/* 176 */   public CheckBoxTreeItem(T paramT, Node paramNode, boolean paramBoolean1, boolean paramBoolean2) { super(paramT, paramNode);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     this.stateChangeListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> updateState());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     this.selected = new SimpleBooleanProperty(this, "selected", false) {
/*     */         protected void invalidated() {
/* 205 */           super.invalidated();
/* 206 */           CheckBoxTreeItem.this.fireEvent(CheckBoxTreeItem.this, true);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     this.indeterminate = new SimpleBooleanProperty(this, "indeterminate", false) {
/*     */         protected void invalidated() {
/* 232 */           super.invalidated();
/* 233 */           CheckBoxTreeItem.this.fireEvent(CheckBoxTreeItem.this, false);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 270 */     this.independent = new SimpleBooleanProperty(this, "independent", false); setSelected(paramBoolean1); setIndependent(paramBoolean2); selectedProperty().addListener(this.stateChangeListener); indeterminateProperty().addListener(this.stateChangeListener); }
/* 271 */   public final BooleanProperty independentProperty() { return this.independent; } public final void setIndependent(boolean paramBoolean) { independentProperty().setValue(Boolean.valueOf(paramBoolean)); } public final boolean isIndependent() {
/* 272 */     return this.independent.getValue().booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean updateLock = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateState() {
/* 285 */     if (isIndependent())
/*     */       return; 
/* 287 */     boolean bool = !updateLock ? true : false;
/*     */ 
/*     */     
/* 290 */     updateLock = true;
/* 291 */     updateUpwards();
/*     */     
/* 293 */     if (bool) updateLock = false;
/*     */ 
/*     */     
/* 296 */     if (updateLock)
/* 297 */       return;  updateDownwards();
/*     */   }
/*     */   
/*     */   private void updateUpwards() {
/* 301 */     if (!(getParent() instanceof CheckBoxTreeItem))
/*     */       return; 
/* 303 */     CheckBoxTreeItem checkBoxTreeItem = (CheckBoxTreeItem)getParent();
/* 304 */     int i = 0;
/* 305 */     int j = 0;
/* 306 */     for (TreeItem treeItem : checkBoxTreeItem.getChildren()) {
/* 307 */       if (!(treeItem instanceof CheckBoxTreeItem))
/*     */         continue; 
/* 309 */       CheckBoxTreeItem checkBoxTreeItem1 = (CheckBoxTreeItem)treeItem;
/*     */       
/* 311 */       i += (checkBoxTreeItem1.isSelected() && !checkBoxTreeItem1.isIndeterminate()) ? 1 : 0;
/* 312 */       j += checkBoxTreeItem1.isIndeterminate() ? 1 : 0;
/*     */     } 
/*     */     
/* 315 */     if (i == checkBoxTreeItem.getChildren().size()) {
/* 316 */       checkBoxTreeItem.setSelected(true);
/* 317 */       checkBoxTreeItem.setIndeterminate(false);
/* 318 */     } else if (i == 0 && j == 0) {
/* 319 */       checkBoxTreeItem.setSelected(false);
/* 320 */       checkBoxTreeItem.setIndeterminate(false);
/*     */     } else {
/* 322 */       checkBoxTreeItem.setIndeterminate(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateDownwards() {
/* 329 */     if (!isLeaf()) {
/* 330 */       for (TreeItem<T> treeItem : getChildren()) {
/* 331 */         if (treeItem instanceof CheckBoxTreeItem) {
/* 332 */           CheckBoxTreeItem checkBoxTreeItem = (CheckBoxTreeItem)treeItem;
/* 333 */           checkBoxTreeItem.setSelected(isSelected());
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void fireEvent(CheckBoxTreeItem<T> paramCheckBoxTreeItem, boolean paramBoolean) {
/* 340 */     TreeModificationEvent<T> treeModificationEvent = new TreeModificationEvent<>(CHECK_BOX_SELECTION_CHANGED_EVENT, paramCheckBoxTreeItem, paramBoolean);
/* 341 */     Event.fireEvent(this, treeModificationEvent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TreeModificationEvent<T>
/*     */     extends Event
/*     */   {
/*     */     private static final long serialVersionUID = -8445355590698862999L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final transient CheckBoxTreeItem<T> treeItem;
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean selectionChanged;
/*     */ 
/*     */ 
/*     */     
/* 364 */     public static final EventType<Event> ANY = new EventType<>(Event.ANY, "TREE_MODIFICATION");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeModificationEvent(EventType<? extends Event> param1EventType, CheckBoxTreeItem<T> param1CheckBoxTreeItem, boolean param1Boolean) {
/* 376 */       super(param1EventType);
/* 377 */       this.treeItem = param1CheckBoxTreeItem;
/* 378 */       this.selectionChanged = param1Boolean;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CheckBoxTreeItem<T> getTreeItem() {
/* 386 */       return this.treeItem;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean wasSelectionChanged() {
/* 395 */       return this.selectionChanged;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean wasIndeterminateChanged() {
/* 405 */       return !this.selectionChanged;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\CheckBoxTreeItem.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */