/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.beans.value.WritableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.NestedTableColumnHeader;
/*     */ import javafx.scene.control.skin.TableColumnHeader;
/*     */ import javafx.scene.control.skin.TableHeaderRow;
/*     */ import javafx.scene.control.skin.TreeTableViewSkin;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeTableColumn<S, T>
/*     */   extends TableColumnBase<TreeItem<S>, T>
/*     */   implements EventTarget
/*     */ {
/*     */   public static <S, T> EventType<CellEditEvent<S, T>> editAnyEvent() {
/* 144 */     return (EventType)EDIT_ANY_EVENT;
/*     */   }
/* 146 */   private static final EventType<?> EDIT_ANY_EVENT = new EventType(Event.ANY, "TREE_TABLE_COLUMN_EDIT");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> EventType<CellEditEvent<S, T>> editStartEvent() {
/* 160 */     return (EventType)EDIT_START_EVENT;
/*     */   }
/* 162 */   private static final EventType<?> EDIT_START_EVENT = new EventType(
/* 163 */       editAnyEvent(), "EDIT_START");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> EventType<CellEditEvent<S, T>> editCancelEvent() {
/* 174 */     return (EventType)EDIT_CANCEL_EVENT;
/*     */   }
/* 176 */   private static final EventType<?> EDIT_CANCEL_EVENT = new EventType(
/* 177 */       editAnyEvent(), "EDIT_CANCEL");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> EventType<CellEditEvent<S, T>> editCommitEvent() {
/* 189 */     return (EventType)EDIT_COMMIT_EVENT;
/*     */   }
/* 191 */   private static final EventType<?> EDIT_COMMIT_EVENT = new EventType(
/* 192 */       editAnyEvent(), "EDIT_COMMIT");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public static final Callback<TreeTableColumn<?, ?>, TreeTableCell<?, ?>> DEFAULT_CELL_FACTORY = new Callback<TreeTableColumn<?, ?>, TreeTableCell<?, ?>>()
/*     */     {
/*     */       public TreeTableCell<?, ?> call(TreeTableColumn<?, ?> param1TreeTableColumn) {
/* 207 */         return new TreeTableCell<Object, Object>() {
/*     */             protected void updateItem(Object param2Object, boolean param2Boolean) {
/* 209 */               if (param2Object == getItem())
/*     */                 return; 
/* 211 */               super.updateItem(param2Object, param2Boolean);
/*     */               
/* 213 */               if (param2Object == null) {
/* 214 */                 setText(null);
/* 215 */                 setGraphic(null);
/* 216 */               } else if (param2Object instanceof Node) {
/* 217 */                 setText(null);
/* 218 */                 setGraphic((Node)param2Object);
/*     */               } else {
/* 220 */                 setText(param2Object.toString());
/* 221 */                 setGraphic(null);
/*     */               } 
/*     */             }
/*     */           };
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EventHandler<CellEditEvent<S, T>> DEFAULT_EDIT_COMMIT_HANDLER;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ListChangeListener<TreeTableColumn<S, ?>> columnsListener;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WeakListChangeListener<TreeTableColumn<S, ?>> weakColumnsListener;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ObservableList<TreeTableColumn<S, ?>> columns;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ReadOnlyObjectWrapper<TreeTableView<S>> treeTableView;
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<Callback<CellDataFeatures<S, T>, ObservableValue<T>>> cellValueFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ObjectProperty<Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>>> cellFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<SortType> sortType;
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditStart;
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCommit;
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCancel;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_STYLE_CLASS = "table-column";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeTableColumn() {
/* 286 */     this.DEFAULT_EDIT_COMMIT_HANDLER = (paramCellEditEvent -> {
/*     */         ObservableValue<T> observableValue = getCellObservableValue(paramCellEditEvent.getRowValue());
/*     */         
/*     */         if (observableValue instanceof WritableValue) {
/*     */           ((WritableValue)observableValue).setValue(paramCellEditEvent.getNewValue());
/*     */         }
/*     */       });
/*     */     
/* 294 */     this.columnsListener = new ListChangeListener<TreeTableColumn<S, ?>>() {
/*     */         public void onChanged(ListChangeListener.Change<? extends TreeTableColumn<S, ?>> param1Change) {
/* 296 */           while (param1Change.next()) {
/*     */             
/* 298 */             for (TreeTableColumn<S, ?> treeTableColumn : param1Change.getRemoved()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 306 */               if (TreeTableColumn.this.getColumns().contains(treeTableColumn))
/*     */                 continue; 
/* 308 */               treeTableColumn.setTreeTableView((TreeTableView)null);
/* 309 */               treeTableColumn.setParentColumn(null);
/*     */             } 
/* 311 */             for (TreeTableColumn<S, ?> treeTableColumn : param1Change.getAddedSubList()) {
/* 312 */               treeTableColumn.setTreeTableView(TreeTableColumn.this.getTreeTableView());
/*     */             }
/*     */             
/* 315 */             TreeTableColumn.this.updateColumnWidths();
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 320 */     this.weakColumnsListener = new WeakListChangeListener<>(this.columnsListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 331 */     this.columns = FXCollections.observableArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 346 */     this.treeTableView = new ReadOnlyObjectWrapper<>(this, "treeTableView");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 420 */     this.cellFactory = (ObjectProperty)new SimpleObjectProperty<Callback<TreeTableColumn<S, Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>>>, TreeTableCell<S, Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>>>>>(this, "cellFactory", DEFAULT_CELL_FACTORY)
/*     */       {
/*     */         protected void invalidated()
/*     */         {
/* 424 */           TreeTableView treeTableView = TreeTableColumn.this.getTreeTableView();
/* 425 */           if (treeTableView == null)
/* 426 */             return;  ObservableMap<Object, Object> observableMap = treeTableView.getProperties();
/* 427 */           if (observableMap.containsKey("recreateKey")) {
/* 428 */             observableMap.remove("recreateKey");
/*     */           }
/* 430 */           observableMap.put("recreateKey", Boolean.TRUE);
/*     */         }
/*     */       }; getStyleClass().add("table-column"); setOnEditCommit(this.DEFAULT_EDIT_COMMIT_HANDLER); getColumns().addListener(this.weakColumnsListener); treeTableViewProperty().addListener(paramObservable -> { for (TreeTableColumn<S, ?> treeTableColumn : getColumns())
/*     */             treeTableColumn.setTreeTableView(getTreeTableView());  });
/* 434 */   } public TreeTableColumn(String paramString) { this(); setText(paramString); } public final ReadOnlyObjectProperty<TreeTableView<S>> treeTableViewProperty() { return this.treeTableView.getReadOnlyProperty(); } final void setTreeTableView(TreeTableView<S> paramTreeTableView) { this.treeTableView.set(paramTreeTableView); } public final void setCellFactory(Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> paramCallback) { this.cellFactory.set(paramCallback); }
/*     */   public final TreeTableView<S> getTreeTableView() { return this.treeTableView.get(); }
/*     */   public final void setCellValueFactory(Callback<CellDataFeatures<S, T>, ObservableValue<T>> paramCallback) { cellValueFactoryProperty().set(paramCallback); }
/* 437 */   public final Callback<CellDataFeatures<S, T>, ObservableValue<T>> getCellValueFactory() { return (this.cellValueFactory == null) ? null : this.cellValueFactory.get(); } public final ObjectProperty<Callback<CellDataFeatures<S, T>, ObservableValue<T>>> cellValueFactoryProperty() { if (this.cellValueFactory == null) this.cellValueFactory = new SimpleObjectProperty<>(this, "cellValueFactory");  return this.cellValueFactory; } public final Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> getCellFactory() { return this.cellFactory.get(); }
/*     */   
/*     */   public final ObjectProperty<Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>>> cellFactoryProperty() {
/* 440 */     return this.cellFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<SortType> sortTypeProperty() {
/* 455 */     if (this.sortType == null) {
/* 456 */       this.sortType = new SimpleObjectProperty<>(this, "sortType", SortType.ASCENDING);
/*     */     }
/* 458 */     return this.sortType;
/*     */   }
/*     */   public final void setSortType(SortType paramSortType) {
/* 461 */     sortTypeProperty().set(paramSortType);
/*     */   }
/*     */   public final SortType getSortType() {
/* 464 */     return (this.sortType == null) ? SortType.ASCENDING : this.sortType.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOnEditStart(EventHandler<CellEditEvent<S, T>> paramEventHandler) {
/* 475 */     onEditStartProperty().set(paramEventHandler);
/*     */   }
/*     */   public final EventHandler<CellEditEvent<S, T>> getOnEditStart() {
/* 478 */     return (this.onEditStart == null) ? null : this.onEditStart.get();
/*     */   }
/*     */   public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditStartProperty() {
/* 481 */     if (this.onEditStart == null) {
/* 482 */       this.onEditStart = (ObjectProperty)new SimpleObjectProperty<EventHandler<CellEditEvent<S, EventHandler<CellEditEvent<S, T>>>>>(this, "onEditStart") {
/*     */           protected void invalidated() {
/* 484 */             TreeTableColumn.this.eventHandlerManager.setEventHandler(TreeTableColumn.editStartEvent(), get());
/*     */           }
/*     */         };
/*     */     }
/* 488 */     return this.onEditStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOnEditCommit(EventHandler<CellEditEvent<S, T>> paramEventHandler) {
/* 499 */     onEditCommitProperty().set(paramEventHandler);
/*     */   }
/*     */   public final EventHandler<CellEditEvent<S, T>> getOnEditCommit() {
/* 502 */     return (this.onEditCommit == null) ? null : this.onEditCommit.get();
/*     */   }
/*     */   public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCommitProperty() {
/* 505 */     if (this.onEditCommit == null) {
/* 506 */       this.onEditCommit = (ObjectProperty)new SimpleObjectProperty<EventHandler<CellEditEvent<S, EventHandler<CellEditEvent<S, T>>>>>(this, "onEditCommit") {
/*     */           protected void invalidated() {
/* 508 */             TreeTableColumn.this.eventHandlerManager.setEventHandler(TreeTableColumn.editCommitEvent(), get());
/*     */           }
/*     */         };
/*     */     }
/* 512 */     return this.onEditCommit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOnEditCancel(EventHandler<CellEditEvent<S, T>> paramEventHandler) {
/* 522 */     onEditCancelProperty().set(paramEventHandler);
/*     */   }
/*     */   public final EventHandler<CellEditEvent<S, T>> getOnEditCancel() {
/* 525 */     return (this.onEditCancel == null) ? null : this.onEditCancel.get();
/*     */   }
/*     */   public final ObjectProperty<EventHandler<CellEditEvent<S, T>>> onEditCancelProperty() {
/* 528 */     if (this.onEditCancel == null) {
/* 529 */       this.onEditCancel = (ObjectProperty)new SimpleObjectProperty<EventHandler<CellEditEvent<S, EventHandler<CellEditEvent<S, T>>>>>(this, "onEditCancel") {
/*     */           protected void invalidated() {
/* 531 */             TreeTableColumn.this.eventHandlerManager.setEventHandler(TreeTableColumn.editCancelEvent(), get());
/*     */           }
/*     */         };
/*     */     }
/* 535 */     return this.onEditCancel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<TreeTableColumn<S, ?>> getColumns() {
/* 548 */     return this.columns;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ObservableValue<T> getCellObservableValue(int paramInt) {
/* 553 */     if (paramInt < 0) return null;
/*     */ 
/*     */     
/* 556 */     TreeTableView<S> treeTableView = getTreeTableView();
/* 557 */     if (treeTableView == null || paramInt >= treeTableView.getExpandedItemCount()) return null;
/*     */ 
/*     */     
/* 560 */     TreeItem<S> treeItem = treeTableView.getTreeItem(paramInt);
/* 561 */     return getCellObservableValue(treeItem);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableValue<T> getCellObservableValue(TreeItem<S> paramTreeItem) {
/* 567 */     Callback<CellDataFeatures<S, T>, ObservableValue<T>> callback = getCellValueFactory();
/* 568 */     if (callback == null) return null;
/*     */ 
/*     */     
/* 571 */     TreeTableView<S> treeTableView = getTreeTableView();
/* 572 */     if (treeTableView == null) return null;
/*     */ 
/*     */     
/* 575 */     CellDataFeatures<S, Object> cellDataFeatures = new CellDataFeatures<>(treeTableView, this, paramTreeItem);
/* 576 */     return callback.call(cellDataFeatures);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTypeSelector() {
/* 602 */     return "TreeTableColumn";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Styleable getStyleableParent() {
/* 610 */     return getTreeTableView();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 617 */     return getClassCssMetaData();
/*     */   }
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 621 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getStyleableNode() {
/* 626 */     if (!(getTreeTableView().getSkin() instanceof TreeTableViewSkin)) return null; 
/* 627 */     TreeTableViewSkin treeTableViewSkin = (TreeTableViewSkin)getTreeTableView().getSkin();
/*     */     
/* 629 */     TableHeaderRow tableHeaderRow = null;
/* 630 */     for (Node node : treeTableViewSkin.getChildren()) {
/* 631 */       if (node instanceof TableHeaderRow) {
/* 632 */         tableHeaderRow = (TableHeaderRow)node;
/*     */       }
/*     */     } 
/*     */     
/* 636 */     NestedTableColumnHeader nestedTableColumnHeader = null;
/* 637 */     for (Node node : tableHeaderRow.getChildren()) {
/* 638 */       if (node instanceof NestedTableColumnHeader) {
/* 639 */         nestedTableColumnHeader = (NestedTableColumnHeader)node;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 644 */     return (Node)scan((TableColumnHeader)nestedTableColumnHeader);
/*     */   }
/*     */ 
/*     */   
/*     */   private TableColumnHeader scan(TableColumnHeader paramTableColumnHeader) {
/* 649 */     if (equals(paramTableColumnHeader.getTableColumn())) {
/* 650 */       return paramTableColumnHeader;
/*     */     }
/*     */     
/* 653 */     if (paramTableColumnHeader instanceof NestedTableColumnHeader) {
/* 654 */       NestedTableColumnHeader nestedTableColumnHeader = (NestedTableColumnHeader)paramTableColumnHeader;
/* 655 */       for (byte b = 0; b < nestedTableColumnHeader.getColumnHeaders().size(); b++) {
/* 656 */         TableColumnHeader tableColumnHeader = scan(nestedTableColumnHeader.getColumnHeaders().get(b));
/* 657 */         if (tableColumnHeader != null) {
/* 658 */           return tableColumnHeader;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 663 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CellDataFeatures<S, T>
/*     */   {
/*     */     private final TreeTableView<S> treeTableView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TreeTableColumn<S, T> tableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TreeItem<S> value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CellDataFeatures(TreeTableView<S> param1TreeTableView, TreeTableColumn<S, T> param1TreeTableColumn, TreeItem<S> param1TreeItem) {
/* 698 */       this.treeTableView = param1TreeTableView;
/* 699 */       this.tableColumn = param1TreeTableColumn;
/* 700 */       this.value = param1TreeItem;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeItem<S> getValue() {
/* 708 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeTableColumn<S, T> getTreeTableColumn() {
/* 716 */       return this.tableColumn;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeTableView<S> getTreeTableView() {
/* 724 */       return this.treeTableView;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CellEditEvent<S, T>
/*     */     extends Event
/*     */   {
/*     */     private static final long serialVersionUID = -609964441682677579L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 740 */     public static final EventType<?> ANY = TreeTableColumn.EDIT_ANY_EVENT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final T newValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final transient TreeTablePosition<S, T> pos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CellEditEvent(TreeTableView<S> param1TreeTableView, TreeTablePosition<S, T> param1TreeTablePosition, EventType<CellEditEvent<S, T>> param1EventType, T param1T) {
/* 761 */       super(param1TreeTableView, Event.NULL_SOURCE_TARGET, (EventType)param1EventType);
/*     */       
/* 763 */       if (param1TreeTableView == null) {
/* 764 */         throw new NullPointerException("TableView can not be null");
/*     */       }
/* 766 */       this.pos = param1TreeTablePosition;
/* 767 */       this.newValue = param1T;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeTableView<S> getTreeTableView() {
/* 775 */       return this.pos.getTreeTableView();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeTableColumn<S, T> getTableColumn() {
/* 784 */       return this.pos.getTableColumn();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeTablePosition<S, T> getTreeTablePosition() {
/* 792 */       return this.pos;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T getNewValue() {
/* 804 */       return this.newValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T getOldValue() {
/* 816 */       TreeItem<S> treeItem = getRowValue();
/* 817 */       if (treeItem == null || this.pos.getTableColumn() == null) {
/* 818 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 822 */       return this.pos.getTableColumn().getCellData(treeItem);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TreeItem<S> getRowValue() {
/* 836 */       TreeTableView<S> treeTableView = getTreeTableView();
/* 837 */       int i = this.pos.getRow();
/* 838 */       if (i < 0 || i >= treeTableView.getExpandedItemCount()) return null;
/*     */       
/* 840 */       return treeTableView.getTreeItem(i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum SortType
/*     */   {
/* 853 */     ASCENDING,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 858 */     DESCENDING;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TreeTableColumn.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */