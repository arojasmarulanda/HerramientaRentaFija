/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.property.SimpleStringProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.ButtonBarSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ButtonBar
/*     */   extends Control
/*     */ {
/*     */   public static final String BUTTON_ORDER_WINDOWS = "L_E+U+FBXI_YNOCAH_R";
/*     */   public static final String BUTTON_ORDER_MAC_OS = "L_HE+U+FBIX_NCYOA_R";
/*     */   public static final String BUTTON_ORDER_LINUX = "L_HE+UNYACBXIO_R";
/*     */   public static final String BUTTON_ORDER_NONE = "";
/*     */   
/*     */   public enum ButtonData
/*     */   {
/* 202 */     LEFT("L", false, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     RIGHT("R", false, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     HELP("H", false, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     HELP_2("E", false, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     YES("Y", false, true),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     NO("N", true, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     NEXT_FORWARD("X", false, true),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     BACK_PREVIOUS("B", false, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 262 */     FINISH("I", false, true),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     APPLY("A", false, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     CANCEL_CLOSE("C", true, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     OK_DONE("O", false, true),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 292 */     OTHER("U", false, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 301 */     BIG_GAP("+", false, false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 308 */     SMALL_GAP("_", false, false);
/*     */     
/*     */     private final String typeCode;
/*     */     
/*     */     private final boolean cancelButton;
/*     */     private final boolean defaultButton;
/*     */     
/*     */     ButtonData(String param1String1, boolean param1Boolean1, boolean param1Boolean2) {
/* 316 */       this.typeCode = param1String1;
/* 317 */       this.cancelButton = param1Boolean1;
/* 318 */       this.defaultButton = param1Boolean2;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getTypeCode() {
/* 329 */       return this.typeCode;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isCancelButton() {
/* 343 */       return this.cancelButton;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isDefaultButton() {
/* 357 */       return this.defaultButton;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setButtonData(Node paramNode, ButtonData paramButtonData) {
/* 371 */     ObservableMap<Object, Object> observableMap = paramNode.getProperties();
/*     */     
/* 373 */     ObjectProperty<ButtonData> objectProperty = (ObjectProperty)observableMap.getOrDefault("javafx.scene.control.ButtonBar.ButtonData", new SimpleObjectProperty<>(paramNode, "buttonData", paramButtonData));
/*     */ 
/*     */ 
/*     */     
/* 377 */     objectProperty.set(paramButtonData);
/* 378 */     observableMap.putIfAbsent("javafx.scene.control.ButtonBar.ButtonData", objectProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ButtonData getButtonData(Node paramNode) {
/* 389 */     ObservableMap<Object, Object> observableMap = paramNode.getProperties();
/* 390 */     if (observableMap.containsKey("javafx.scene.control.ButtonBar.ButtonData")) {
/* 391 */       ObjectProperty<ButtonData> objectProperty = (ObjectProperty)observableMap.get("javafx.scene.control.ButtonBar.ButtonData");
/* 392 */       return (objectProperty == null) ? null : objectProperty.get();
/*     */     } 
/* 394 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setButtonUniformSize(Node paramNode, boolean paramBoolean) {
/* 415 */     if (paramBoolean) {
/* 416 */       paramNode.getProperties().remove("javafx.scene.control.ButtonBar.independentSize");
/*     */     } else {
/* 418 */       paramNode.getProperties().put("javafx.scene.control.ButtonBar.independentSize", Boolean.valueOf(paramBoolean));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isButtonUniformSize(Node paramNode) {
/* 430 */     return ((Boolean)paramNode.getProperties().getOrDefault("javafx.scene.control.ButtonBar.independentSize", Boolean.valueOf(true))).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 441 */   private ObservableList<Node> buttons = FXCollections.observableArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StringProperty buttonOrderProperty;
/*     */ 
/*     */ 
/*     */   
/*     */   private final DoubleProperty buttonMinWidthProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ButtonBar() {
/* 456 */     this((String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 503 */     return (Skin<?>)new ButtonBarSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<Node> getButtons() {
/* 517 */     return this.buttons;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final StringProperty buttonOrderProperty() {
/* 537 */     return this.buttonOrderProperty;
/*     */   }
/* 539 */   public final void setButtonOrder(String paramString) { this.buttonOrderProperty.set(paramString); } public ButtonBar(String paramString) { this.buttonOrderProperty = new SimpleStringProperty(this, "buttonOrder");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 568 */     this.buttonMinWidthProperty = new SimpleDoubleProperty(this, "buttonMinWidthProperty"); getStyleClass().add("button-bar"); ((StyleableProperty<Boolean>)focusTraversableProperty()).applyStyle(null, Boolean.FALSE); boolean bool = (paramString == null || paramString.isEmpty()) ? true : false; if (Utils.isMac()) {
/*     */       setButtonOrder(bool ? "L_HE+U+FBIX_NCYOA_R" : paramString); setButtonMinWidth(70.0D);
/*     */     } else if (Utils.isUnix()) {
/*     */       setButtonOrder(bool ? "L_HE+UNYACBXIO_R" : paramString);
/*     */       setButtonMinWidth(85.0D);
/*     */     } else {
/*     */       setButtonOrder(bool ? "L_E+U+FBXI_YNOCAH_R" : paramString);
/*     */       setButtonMinWidth(75.0D);
/* 576 */     }  } public final void setButtonMinWidth(double paramDouble) { this.buttonMinWidthProperty.set(paramDouble); }
/*     */    public final String getButtonOrder() {
/*     */     return this.buttonOrderProperty.get();
/*     */   }
/*     */   public final DoubleProperty buttonMinWidthProperty() {
/*     */     return this.buttonMinWidthProperty;
/*     */   }
/*     */   public final double getButtonMinWidth() {
/* 584 */     return this.buttonMinWidthProperty.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean getInitialFocusTraversable() {
/* 604 */     return Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ButtonBar.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */