/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.collections.TrackableObservableList;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.AccordionSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Accordion
/*     */   extends Control
/*     */ {
/*     */   private boolean biasDirty = true;
/*     */   private Orientation bias;
/*     */   private final ObservableList<TitledPane> panes;
/*     */   private ObjectProperty<TitledPane> expandedPane;
/*     */   private static final String DEFAULT_STYLE_CLASS = "accordion";
/*     */   
/*     */   public Accordion() {
/*  81 */     this((TitledPane[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Accordion(TitledPane... paramVarArgs) {
/* 111 */     this.panes = new TrackableObservableList<TitledPane>()
/*     */       {
/*     */ 
/*     */         
/*     */         protected void onChanged(ListChangeListener.Change<TitledPane> param1Change)
/*     */         {
/* 117 */           while (param1Change.next()) {
/* 118 */             if (param1Change.wasRemoved() && !Accordion.this.expandedPane.isBound()) {
/* 119 */               for (TitledPane titledPane : param1Change.getRemoved()) {
/* 120 */                 if (!param1Change.getAddedSubList().contains(titledPane) && Accordion.this.getExpandedPane() == titledPane) {
/* 121 */                   Accordion.this.setExpandedPane((TitledPane)null);
/*     */                 }
/*     */               } 
/*     */             }
/*     */           } 
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     this.expandedPane = new ObjectPropertyBase<TitledPane>()
/*     */       {
/*     */         private TitledPane oldValue;
/*     */ 
/*     */         
/*     */         protected void invalidated() {
/* 143 */           TitledPane titledPane = get();
/* 144 */           if (titledPane != null) {
/* 145 */             titledPane.setExpanded(true);
/*     */           }
/* 147 */           else if (this.oldValue != null) {
/* 148 */             this.oldValue.setExpanded(false);
/*     */           } 
/*     */           
/* 151 */           this.oldValue = titledPane;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 156 */           return "expandedPane";
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 161 */           return Accordion.this;
/*     */         }
/*     */       };
/*     */     getStyleClass().setAll(new String[] { "accordion" });
/*     */     if (paramVarArgs != null) {
/*     */       getPanes().addAll(paramVarArgs);
/*     */     }
/*     */     ((StyleableProperty<Boolean>)focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setExpandedPane(TitledPane paramTitledPane) {
/* 176 */     expandedPaneProperty().set(paramTitledPane);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TitledPane getExpandedPane() {
/* 184 */     return this.expandedPane.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<TitledPane> expandedPaneProperty() {
/* 191 */     return this.expandedPane;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<TitledPane> getPanes() {
/* 206 */     return this.panes;
/*     */   }
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 210 */     return (Skin<?>)new AccordionSkin(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void requestLayout() {
/* 215 */     this.biasDirty = true;
/* 216 */     this.bias = null;
/* 217 */     super.requestLayout();
/*     */   }
/*     */ 
/*     */   
/*     */   public Orientation getContentBias() {
/* 222 */     if (this.biasDirty) {
/* 223 */       this.bias = null;
/* 224 */       List<Node> list = getManagedChildren();
/* 225 */       for (Node node : list) {
/* 226 */         Orientation orientation = node.getContentBias();
/* 227 */         if (orientation != null) {
/* 228 */           this.bias = orientation;
/* 229 */           if (orientation == Orientation.HORIZONTAL) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/* 234 */       this.biasDirty = false;
/*     */     } 
/* 236 */     return this.bias;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean getInitialFocusTraversable() {
/* 256 */     return Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Accordion.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */