/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import javafx.beans.NamedArg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeTablePosition<S, T>
/*     */   extends TablePositionBase<TreeTableColumn<S, T>>
/*     */ {
/*     */   private final WeakReference<TreeTableView<S>> controlRef;
/*     */   private final WeakReference<TreeItem<S>> treeItemRef;
/*     */   int fixedColumnIndex;
/*     */   private final int nonFixedColumnIndex;
/*     */   
/*     */   public TreeTablePosition(@NamedArg("treeTableView") TreeTableView<S> paramTreeTableView, @NamedArg("row") int paramInt, @NamedArg("tableColumn") TreeTableColumn<S, T> paramTreeTableColumn) {
/*  68 */     this(paramTreeTableView, paramInt, paramTreeTableColumn, true);
/*     */   }
/*     */ 
/*     */   
/*     */   TreeTablePosition(@NamedArg("treeTableView") TreeTableView<S> paramTreeTableView, @NamedArg("row") int paramInt, @NamedArg("tableColumn") TreeTableColumn<S, T> paramTreeTableColumn, boolean paramBoolean) {
/*  73 */     super(paramInt, paramTreeTableColumn);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     this.fixedColumnIndex = -1;
/*     */     this.controlRef = new WeakReference<>(paramTreeTableView);
/*     */     this.treeItemRef = new WeakReference<>(paramBoolean ? paramTreeTableView.getTreeItem(paramInt) : null);
/*     */     this.nonFixedColumnIndex = (paramTreeTableView == null || paramTreeTableColumn == null) ? -1 : paramTreeTableView.getVisibleLeafIndex(paramTreeTableColumn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 105 */     if (this.fixedColumnIndex > -1) {
/* 106 */       return this.fixedColumnIndex;
/*     */     }
/*     */     
/* 109 */     return this.nonFixedColumnIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TreeTableView<S> getTreeTableView() {
/* 117 */     return this.controlRef.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public final TreeTableColumn<S, T> getTableColumn() {
/* 122 */     return super.getTableColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TreeItem<S> getTreeItem() {
/* 130 */     return this.treeItemRef.get();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TreeTablePosition.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */