/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.beans.IDProperty;
/*     */ import com.sun.javafx.event.EventHandlerManager;
/*     */ import com.sun.javafx.scene.control.ControlAcceleratorSupport;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javafx.beans.DefaultProperty;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.property.SimpleStringProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.collections.ObservableSet;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventDispatchChain;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @DefaultProperty("content")
/*     */ @IDProperty("id")
/*     */ public class Tab
/*     */   implements EventTarget, Styleable
/*     */ {
/*     */   private StringProperty id;
/*     */   private StringProperty style;
/*     */   private ReadOnlyBooleanWrapper selected;
/*     */   private ReadOnlyObjectWrapper<TabPane> tabPane;
/*     */   private final InvalidationListener parentDisabledChangedListener;
/*     */   private StringProperty text;
/*     */   private ObjectProperty<Node> graphic;
/*     */   private ObjectProperty<Node> content;
/*     */   private ObjectProperty<ContextMenu> contextMenu;
/*     */   private BooleanProperty closable;
/*     */   
/*     */   public Tab() {
/*  91 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Tab(String paramString) {
/* 100 */     this(paramString, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Tab(String paramString, Node paramNode) {
/* 277 */     this.parentDisabledChangedListener = (paramObservable -> updateDisabled());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 592 */     this.styleClass = FXCollections.observableArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 820 */     this.eventHandlerManager = new EventHandlerManager(this); setText(paramString); setContent(paramNode); this.styleClass.addAll(new String[] { "tab" });
/*     */   } public final void setId(String paramString) { idProperty().set(paramString); } public final String getId() { return (this.id == null) ? null : this.id.get(); } public final StringProperty idProperty() { if (this.id == null) this.id = new SimpleStringProperty(this, "id");  return this.id; } public final void setStyle(String paramString) { styleProperty().set(paramString); } public final String getStyle() { return (this.style == null) ? null : this.style.get(); } public final StringProperty styleProperty() { if (this.style == null) this.style = new SimpleStringProperty(this, "style");  return this.style; } final void setSelected(boolean paramBoolean) { selectedPropertyImpl().set(paramBoolean); } public final boolean isSelected() { return (this.selected == null) ? false : this.selected.get(); } public final ReadOnlyBooleanProperty selectedProperty() { return selectedPropertyImpl().getReadOnlyProperty(); } private ReadOnlyBooleanWrapper selectedPropertyImpl() { if (this.selected == null) this.selected = new ReadOnlyBooleanWrapper() { protected void invalidated() { if (Tab.this.getOnSelectionChanged() != null) Event.fireEvent(Tab.this, new Event(Tab.SELECTION_CHANGED_EVENT));  } public Object getBean() { return Tab.this; } public String getName() { return "selected"; } }
/*     */         ;  return this.selected; } final void setTabPane(TabPane paramTabPane) { tabPanePropertyImpl().set(paramTabPane); } public final TabPane getTabPane() { return (this.tabPane == null) ? null : this.tabPane.get(); } public final ReadOnlyObjectProperty<TabPane> tabPaneProperty() { return tabPanePropertyImpl().getReadOnlyProperty(); } private ReadOnlyObjectWrapper<TabPane> tabPanePropertyImpl() { if (this.tabPane == null) this.tabPane = new ReadOnlyObjectWrapper<TabPane>(this, "tabPane") { private WeakReference<TabPane> oldParent; protected void invalidated() { if (this.oldParent != null && this.oldParent.get() != null) ((TabPane)this.oldParent.get()).disabledProperty().removeListener(Tab.this.parentDisabledChangedListener);  Tab.this.updateDisabled(); TabPane tabPane = get(); if (tabPane != null) tabPane.disabledProperty().addListener(Tab.this.parentDisabledChangedListener);  this.oldParent = new WeakReference<>(tabPane); super.invalidated(); } }
/*     */         ;  return this.tabPane; } public final void setText(String paramString) { textProperty().set(paramString); } public final String getText() { return (this.text == null) ? null : this.text.get(); } public final StringProperty textProperty() { if (this.text == null) this.text = new SimpleStringProperty(this, "text");  return this.text; } public final void setGraphic(Node paramNode) { graphicProperty().set(paramNode); } public final Node getGraphic() { return (this.graphic == null) ? null : this.graphic.get(); } public final ObjectProperty<Node> graphicProperty() { if (this.graphic == null) this.graphic = new SimpleObjectProperty<>(this, "graphic");  return this.graphic; } public final void setContent(Node paramNode) { contentProperty().set(paramNode); } public final Node getContent() { return (this.content == null) ? null : this.content.get(); } public final ObjectProperty<Node> contentProperty() { if (this.content == null) this.content = new SimpleObjectProperty<Node>(this, "content") { protected void invalidated() { Tab.this.updateDisabled(); } }
/*     */         ;  return this.content; } public final void setContextMenu(ContextMenu paramContextMenu) { contextMenuProperty().set(paramContextMenu); } public final ContextMenu getContextMenu() { return (this.contextMenu == null) ? null : this.contextMenu.get(); } public final ObjectProperty<ContextMenu> contextMenuProperty() { if (this.contextMenu == null) this.contextMenu = new SimpleObjectProperty<ContextMenu>(this, "contextMenu") { private WeakReference<ContextMenu> contextMenuRef; protected void invalidated() { ContextMenu contextMenu1 = (this.contextMenuRef == null) ? null : this.contextMenuRef.get(); if (contextMenu1 != null) ControlAcceleratorSupport.removeAcceleratorsFromScene(contextMenu1.getItems(), Tab.this);  ContextMenu contextMenu2 = get(); this.contextMenuRef = new WeakReference<>(contextMenu2); if (contextMenu2 != null) ControlAcceleratorSupport.addAcceleratorsIntoScene(contextMenu2.getItems(), Tab.this);  } }
/*     */         ;  return this.contextMenu; } public final void setClosable(boolean paramBoolean) { closableProperty().set(paramBoolean); } public final boolean isClosable() { return (this.closable == null) ? true : this.closable.get(); } public final BooleanProperty closableProperty() { if (this.closable == null) this.closable = new SimpleBooleanProperty(this, "closable", true);  return this.closable; } public static final EventType<Event> SELECTION_CHANGED_EVENT = new EventType<>(Event.ANY, "SELECTION_CHANGED_EVENT"); private ObjectProperty<EventHandler<Event>> onSelectionChanged; public final void setOnSelectionChanged(EventHandler<Event> paramEventHandler) { onSelectionChangedProperty().set(paramEventHandler); } public final EventHandler<Event> getOnSelectionChanged() { return (this.onSelectionChanged == null) ? null : this.onSelectionChanged.get(); } public final ObjectProperty<EventHandler<Event>> onSelectionChangedProperty() { if (this.onSelectionChanged == null) this.onSelectionChanged = new ObjectPropertyBase<EventHandler<Event>>() { protected void invalidated() { Tab.this.setEventHandler(Tab.SELECTION_CHANGED_EVENT, get()); } public Object getBean() { return Tab.this; } public String getName() { return "onSelectionChanged"; } }
/* 826 */         ;  return this.onSelectionChanged; } public EventDispatchChain buildEventDispatchChain(EventDispatchChain paramEventDispatchChain) { return paramEventDispatchChain.prepend(this.eventHandlerManager); } public static final EventType<Event> CLOSED_EVENT = new EventType<>(Event.ANY, "TAB_CLOSED"); private ObjectProperty<EventHandler<Event>> onClosed; private ObjectProperty<Tooltip> tooltip; private final ObservableList<String> styleClass; private BooleanProperty disable; private ReadOnlyBooleanWrapper disabled; public final void setOnClosed(EventHandler<Event> paramEventHandler) { onClosedProperty().set(paramEventHandler); } public final EventHandler<Event> getOnClosed() { return (this.onClosed == null) ? null : this.onClosed.get(); } public final ObjectProperty<EventHandler<Event>> onClosedProperty() { if (this.onClosed == null) this.onClosed = new ObjectPropertyBase<EventHandler<Event>>() { protected void invalidated() { Tab.this.setEventHandler(Tab.CLOSED_EVENT, get()); } public Object getBean() { return Tab.this; } public String getName() { return "onClosed"; } }
/*     */         ;  return this.onClosed; } public final void setTooltip(Tooltip paramTooltip) { tooltipProperty().setValue(paramTooltip); } public final Tooltip getTooltip() { return (this.tooltip == null) ? null : this.tooltip.getValue(); } public final ObjectProperty<Tooltip> tooltipProperty() { if (this.tooltip == null) this.tooltip = new SimpleObjectProperty<>(this, "tooltip");  return this.tooltip; } public final void setDisable(boolean paramBoolean) { disableProperty().set(paramBoolean); } public final boolean isDisable() { return (this.disable == null) ? false : this.disable.get(); } public final BooleanProperty disableProperty() { if (this.disable == null) this.disable = new BooleanPropertyBase(false) { protected void invalidated() { Tab.this.updateDisabled(); } public Object getBean() { return Tab.this; } public String getName() { return "disable"; } }
/*     */         ;  return this.disable; } private final void setDisabled(boolean paramBoolean) { disabledPropertyImpl().set(paramBoolean); } public final boolean isDisabled() { return (this.disabled == null) ? false : this.disabled.get(); } public final ReadOnlyBooleanProperty disabledProperty() { return disabledPropertyImpl().getReadOnlyProperty(); } private ReadOnlyBooleanWrapper disabledPropertyImpl() { if (this.disabled == null) this.disabled = new ReadOnlyBooleanWrapper() { public Object getBean() { return Tab.this; } public String getName() { return "disabled"; } }
/*     */         ;  return this.disabled; } private void updateDisabled() { boolean bool = (isDisable() || (getTabPane() != null && getTabPane().isDisabled())) ? true : false; setDisabled(bool); Node node = getContent(); if (node != null) node.setDisable(bool);  } public static final EventType<Event> TAB_CLOSE_REQUEST_EVENT = new EventType<>(Event.ANY, "TAB_CLOSE_REQUEST_EVENT"); private ObjectProperty<EventHandler<Event>> onCloseRequest; public final ObjectProperty<EventHandler<Event>> onCloseRequestProperty() { if (this.onCloseRequest == null) this.onCloseRequest = new ObjectPropertyBase<EventHandler<Event>>() { protected void invalidated() { Tab.this.setEventHandler(Tab.TAB_CLOSE_REQUEST_EVENT, get()); } public Object getBean() { return Tab.this; } public String getName() { return "onCloseRequest"; } }
/* 830 */         ;  return this.onCloseRequest; } public EventHandler<Event> getOnCloseRequest() { if (this.onCloseRequest == null) return null;  return this.onCloseRequest.get(); } public void setOnCloseRequest(EventHandler<Event> paramEventHandler) { onCloseRequestProperty().set(paramEventHandler); } private static final Object USER_DATA_KEY = new Object(); private ObservableMap<Object, Object> properties; private final EventHandlerManager eventHandlerManager; private static final String DEFAULT_STYLE_CLASS = "tab"; public final ObservableMap<Object, Object> getProperties() { if (this.properties == null) this.properties = FXCollections.observableMap(new HashMap<>());  return this.properties; } public boolean hasProperties() { return (this.properties != null && !this.properties.isEmpty()); } public void setUserData(Object paramObject) { getProperties().put(USER_DATA_KEY, paramObject); } public Object getUserData() { return getProperties().get(USER_DATA_KEY); } public ObservableList<String> getStyleClass() { return this.styleClass; } <E extends Event> void setEventHandler(EventType<E> paramEventType, EventHandler<E> paramEventHandler) { this.eventHandlerManager.setEventHandler(paramEventType, paramEventHandler); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Node lookup(String paramString) {
/* 837 */     if (paramString == null) return null; 
/* 838 */     Node node = null;
/* 839 */     if (getContent() != null) {
/* 840 */       node = getContent().lookup(paramString);
/*     */     }
/* 842 */     if (node == null && getGraphic() != null) {
/* 843 */       node = getGraphic().lookup(paramString);
/*     */     }
/* 845 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<Node> lookupAll(String paramString) {
/* 852 */     ArrayList<Node> arrayList = new ArrayList();
/* 853 */     if (getContent() != null) {
/* 854 */       Set<Node> set = getContent().lookupAll(paramString);
/* 855 */       if (!set.isEmpty()) {
/* 856 */         arrayList.addAll(set);
/*     */       }
/*     */     } 
/* 859 */     if (getGraphic() != null) {
/* 860 */       Set<Node> set = getGraphic().lookupAll(paramString);
/* 861 */       if (!set.isEmpty()) {
/* 862 */         arrayList.addAll(set);
/*     */       }
/*     */     } 
/* 865 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTypeSelector() {
/* 884 */     return "Tab";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Styleable getStyleableParent() {
/* 894 */     return getTabPane();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableSet<PseudoClass> getPseudoClassStates() {
/* 902 */     return FXCollections.emptyObservableSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 911 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 920 */     return Collections.emptyList();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Tab.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */