/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ChoiceBox;
/*     */ import javafx.scene.control.TableCell;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChoiceBoxTableCell<S, T>
/*     */   extends TableCell<S, T>
/*     */ {
/*     */   private final ObservableList<T> items;
/*     */   private ChoiceBox<T> choiceBox;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   
/*     */   @SafeVarargs
/*     */   public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(T... paramVarArgs) {
/*  86 */     return forTableColumn((StringConverter<T>)null, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 114 */     return forTableColumn(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(ObservableList<T> paramObservableList) {
/* 138 */     return forTableColumn((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList) {
/* 165 */     return paramTableColumn -> new ChoiceBoxTableCell<>(paramStringConverter, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBoxTableCell() {
/* 192 */     this(FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ChoiceBoxTableCell(T... paramVarArgs) {
/* 204 */     this(FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ChoiceBoxTableCell(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 221 */     this(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBoxTableCell(ObservableList<T> paramObservableList) {
/* 232 */     this((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBoxTableCell(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList) {
/* 261 */     this.converter = new SimpleObjectProperty<>(this, "converter");
/*     */     getStyleClass().add("choice-box-table-cell");
/*     */     this.items = paramObservableList;
/*     */     setConverter((paramStringConverter != null) ? paramStringConverter : CellUtils.<T>defaultStringConverter());
/*     */   }
/*     */ 
/*     */   
/*     */   public final ObjectProperty<StringConverter<T>> converterProperty() {
/* 269 */     return this.converter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) {
/* 277 */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final StringConverter<T> getConverter() {
/* 285 */     return converterProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<T> getItems() {
/* 301 */     return this.items;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startEdit() {
/* 306 */     if (!isEditable() || !getTableView().isEditable() || !getTableColumn().isEditable()) {
/*     */       return;
/*     */     }
/*     */     
/* 310 */     if (this.choiceBox == null) {
/* 311 */       this.choiceBox = CellUtils.createChoiceBox(this, this.items, converterProperty());
/*     */     }
/*     */     
/* 314 */     this.choiceBox.getSelectionModel().select(getItem());
/*     */     
/* 316 */     super.startEdit();
/* 317 */     setText(null);
/* 318 */     setGraphic(this.choiceBox);
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancelEdit() {
/* 323 */     super.cancelEdit();
/*     */     
/* 325 */     setText(getConverter().toString(getItem()));
/* 326 */     setGraphic(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 331 */     super.updateItem(paramT, paramBoolean);
/* 332 */     CellUtils.updateItem(this, getConverter(), (HBox)null, (Node)null, this.choiceBox);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\ChoiceBoxTableCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */