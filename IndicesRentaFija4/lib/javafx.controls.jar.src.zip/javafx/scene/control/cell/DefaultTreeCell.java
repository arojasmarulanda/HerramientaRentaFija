/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.TreeCell;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.layout.HBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultTreeCell<T>
/*     */   extends TreeCell<T>
/*     */ {
/*     */   private HBox hbox;
/*     */   private WeakReference<TreeItem<T>> treeItemRef;
/*     */   private InvalidationListener treeItemGraphicListener = paramObservable -> updateDisplay(getItem(), isEmpty());
/*     */   
/*  51 */   private InvalidationListener treeItemListener = new InvalidationListener() {
/*     */       public void invalidated(Observable param1Observable) {
/*  53 */         TreeItem treeItem1 = (DefaultTreeCell.this.treeItemRef == null) ? null : DefaultTreeCell.this.treeItemRef.get();
/*  54 */         if (treeItem1 != null) {
/*  55 */           treeItem1.graphicProperty().removeListener(DefaultTreeCell.this.weakTreeItemGraphicListener);
/*     */         }
/*     */         
/*  58 */         TreeItem treeItem2 = DefaultTreeCell.this.getTreeItem();
/*  59 */         if (treeItem2 != null) {
/*  60 */           treeItem2.graphicProperty().addListener(DefaultTreeCell.this.weakTreeItemGraphicListener);
/*  61 */           DefaultTreeCell.this.treeItemRef = new WeakReference<>(treeItem2);
/*     */         } 
/*     */       }
/*     */     };
/*     */   
/*  66 */   private WeakInvalidationListener weakTreeItemGraphicListener = new WeakInvalidationListener(this.treeItemGraphicListener);
/*     */ 
/*     */   
/*  69 */   private WeakInvalidationListener weakTreeItemListener = new WeakInvalidationListener(this.treeItemListener);
/*     */ 
/*     */   
/*     */   public DefaultTreeCell() {
/*  73 */     treeItemProperty().addListener(this.weakTreeItemListener);
/*     */     
/*  75 */     if (getTreeItem() != null) {
/*  76 */       getTreeItem().graphicProperty().addListener(this.weakTreeItemGraphicListener);
/*     */     }
/*     */   }
/*     */   
/*     */   void updateDisplay(T paramT, boolean paramBoolean) {
/*  81 */     if (paramT == null || paramBoolean) {
/*  82 */       this.hbox = null;
/*  83 */       setText(null);
/*  84 */       setGraphic(null);
/*     */     } else {
/*     */       
/*  87 */       TreeItem<T> treeItem = getTreeItem();
/*  88 */       if (treeItem != null && treeItem.getGraphic() != null) {
/*  89 */         if (paramT instanceof Node) {
/*  90 */           setText(null);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  95 */           if (this.hbox == null) {
/*  96 */             this.hbox = new HBox(3.0D);
/*     */           }
/*  98 */           this.hbox.getChildren().setAll(new Node[] { treeItem.getGraphic(), (Node)paramT });
/*  99 */           setGraphic(this.hbox);
/*     */         } else {
/* 101 */           this.hbox = null;
/* 102 */           setText(paramT.toString());
/* 103 */           setGraphic(treeItem.getGraphic());
/*     */         } 
/*     */       } else {
/* 106 */         this.hbox = null;
/* 107 */         if (paramT instanceof Node) {
/* 108 */           setText(null);
/* 109 */           setGraphic((Node)paramT);
/*     */         } else {
/* 111 */           setText(paramT.toString());
/* 112 */           setGraphic(null);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 119 */     super.updateItem(paramT, paramBoolean);
/* 120 */     updateDisplay(paramT, paramBoolean);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\DefaultTreeCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */