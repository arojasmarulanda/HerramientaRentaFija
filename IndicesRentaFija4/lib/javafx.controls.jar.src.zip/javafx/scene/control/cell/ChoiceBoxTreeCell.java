/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ChoiceBox;
/*     */ import javafx.scene.control.TreeCell;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeView;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChoiceBoxTreeCell<T>
/*     */   extends DefaultTreeCell<T>
/*     */ {
/*     */   private final ObservableList<T> items;
/*     */   private ChoiceBox<T> choiceBox;
/*     */   private HBox hbox;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(T... paramVarArgs) {
/*  81 */     return forTreeView(FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(ObservableList<T> paramObservableList) {
/* 105 */     return forTreeView((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 129 */     return forTreeView(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList) {
/* 153 */     return paramTreeView -> new ChoiceBoxTreeCell(paramStringConverter, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBoxTreeCell() {
/* 182 */     this(FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ChoiceBoxTreeCell(T... paramVarArgs) {
/* 194 */     this(FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ChoiceBoxTreeCell(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 211 */     this(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBoxTreeCell(ObservableList<T> paramObservableList) {
/* 222 */     this((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBoxTreeCell(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList) {
/* 252 */     this.converter = new SimpleObjectProperty<>(this, "converter");
/*     */     getStyleClass().add("choice-box-tree-cell");
/*     */     this.items = paramObservableList;
/*     */     setConverter((paramStringConverter != null) ? paramStringConverter : CellUtils.<T>defaultStringConverter());
/*     */   }
/*     */ 
/*     */   
/*     */   public final ObjectProperty<StringConverter<T>> converterProperty() {
/* 260 */     return this.converter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) {
/* 268 */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final StringConverter<T> getConverter() {
/* 276 */     return converterProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<T> getItems() {
/* 292 */     return this.items;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startEdit() {
/* 297 */     if (!isEditable() || !getTreeView().isEditable()) {
/*     */       return;
/*     */     }
/*     */     
/* 301 */     TreeItem<T> treeItem = getTreeItem();
/* 302 */     if (treeItem == null) {
/*     */       return;
/*     */     }
/*     */     
/* 306 */     if (this.choiceBox == null) {
/* 307 */       this.choiceBox = CellUtils.createChoiceBox(this, this.items, converterProperty());
/*     */     }
/* 309 */     if (this.hbox == null) {
/* 310 */       this.hbox = new HBox(CellUtils.TREE_VIEW_HBOX_GRAPHIC_PADDING);
/*     */     }
/*     */     
/* 313 */     this.choiceBox.getSelectionModel().select(treeItem.getValue());
/*     */     
/* 315 */     super.startEdit();
/*     */     
/* 317 */     if (isEditing()) {
/* 318 */       setText(null);
/*     */       
/* 320 */       Node node = getTreeItemGraphic();
/* 321 */       if (node != null) {
/* 322 */         this.hbox.getChildren().setAll(new Node[] { node, this.choiceBox });
/* 323 */         setGraphic(this.hbox);
/*     */       } else {
/* 325 */         setGraphic(this.choiceBox);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancelEdit() {
/* 332 */     super.cancelEdit();
/*     */     
/* 334 */     setText(getConverter().toString(getItem()));
/* 335 */     setGraphic(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 340 */     super.updateItem(paramT, paramBoolean);
/*     */     
/* 342 */     CellUtils.updateItem(this, getConverter(), this.hbox, getTreeItemGraphic(), this.choiceBox);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Node getTreeItemGraphic() {
/* 354 */     TreeItem<T> treeItem = getTreeItem();
/* 355 */     return (treeItem == null) ? null : treeItem.getGraphic();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\ChoiceBoxTreeCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */