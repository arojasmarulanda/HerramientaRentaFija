/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.control.CheckBox;
/*     */ import javafx.scene.control.ContentDisplay;
/*     */ import javafx.scene.control.ListCell;
/*     */ import javafx.scene.control.ListView;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckBoxListCell<T>
/*     */   extends ListCell<T>
/*     */ {
/*     */   private final CheckBox checkBox;
/*     */   private ObservableValue<Boolean> booleanProperty;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   private ObjectProperty<Callback<T, ObservableValue<Boolean>>> selectedStateCallback;
/*     */   
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(Callback<T, ObservableValue<Boolean>> paramCallback) {
/* 101 */     return forListView(paramCallback, CellUtils.defaultStringConverter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(Callback<T, ObservableValue<Boolean>> paramCallback, StringConverter<T> paramStringConverter) {
/* 128 */     return paramListView -> new CheckBoxListCell(paramCallback, paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxListCell() {
/* 153 */     this((Callback<T, ObservableValue<Boolean>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxListCell(Callback<T, ObservableValue<Boolean>> paramCallback) {
/* 164 */     this(paramCallback, CellUtils.defaultStringConverter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxListCell(Callback<T, ObservableValue<Boolean>> paramCallback, StringConverter<T> paramStringConverter) {
/* 199 */     this.converter = new SimpleObjectProperty<>(this, "converter");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     this.selectedStateCallback = new SimpleObjectProperty<>(this, "selectedStateCallback");
/*     */     getStyleClass().add("check-box-list-cell");
/*     */     setSelectedStateCallback(paramCallback);
/*     */     setConverter(paramStringConverter);
/*     */     this.checkBox = new CheckBox();
/*     */     setAlignment(Pos.CENTER_LEFT);
/*     */     setContentDisplay(ContentDisplay.LEFT);
/*     */     setGraphic(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public final ObjectProperty<Callback<T, ObservableValue<Boolean>>> selectedStateCallbackProperty() {
/* 240 */     return this.selectedStateCallback;
/*     */   } public final ObjectProperty<StringConverter<T>> converterProperty() {
/*     */     return this.converter;
/*     */   }
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) {
/*     */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */   public final void setSelectedStateCallback(Callback<T, ObservableValue<Boolean>> paramCallback) {
/* 248 */     selectedStateCallbackProperty().set(paramCallback);
/*     */   }
/*     */   
/*     */   public final StringConverter<T> getConverter() {
/*     */     return converterProperty().get();
/*     */   }
/*     */   
/*     */   public final Callback<T, ObservableValue<Boolean>> getSelectedStateCallback() {
/* 256 */     return selectedStateCallbackProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 269 */     super.updateItem(paramT, paramBoolean);
/*     */     
/* 271 */     if (!paramBoolean) {
/* 272 */       StringConverter<T> stringConverter = getConverter();
/* 273 */       Callback<T, ObservableValue<Boolean>> callback = getSelectedStateCallback();
/* 274 */       if (callback == null) {
/* 275 */         throw new NullPointerException("The CheckBoxListCell selectedStateCallbackProperty can not be null");
/*     */       }
/*     */ 
/*     */       
/* 279 */       setGraphic(this.checkBox);
/* 280 */       setText((stringConverter != null) ? stringConverter.toString(paramT) : ((paramT == null) ? "" : paramT.toString()));
/*     */       
/* 282 */       if (this.booleanProperty != null) {
/* 283 */         this.checkBox.selectedProperty().unbindBidirectional((BooleanProperty)this.booleanProperty);
/*     */       }
/* 285 */       this.booleanProperty = callback.call(paramT);
/* 286 */       if (this.booleanProperty != null) {
/* 287 */         this.checkBox.selectedProperty().bindBidirectional((BooleanProperty)this.booleanProperty);
/*     */       }
/*     */     } else {
/* 290 */       setGraphic(null);
/* 291 */       setText(null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\CheckBoxListCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */