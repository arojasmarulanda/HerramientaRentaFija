/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*     */ import javafx.beans.property.ReadOnlyDoubleWrapper;
/*     */ import javafx.beans.property.ReadOnlyFloatWrapper;
/*     */ import javafx.beans.property.ReadOnlyIntegerWrapper;
/*     */ import javafx.beans.property.ReadOnlyLongWrapper;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.ReadOnlyStringWrapper;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapValueFactory<T>
/*     */   implements Callback<TableColumn.CellDataFeatures<Map, T>, ObservableValue<T>>
/*     */ {
/*     */   private final Object key;
/*     */   
/*     */   public MapValueFactory(@NamedArg("key") Object paramObject) {
/*  87 */     this.key = paramObject;
/*     */   }
/*     */   
/*     */   public ObservableValue<T> call(TableColumn.CellDataFeatures<Map, T> paramCellDataFeatures) {
/*  91 */     Map map = paramCellDataFeatures.getValue();
/*  92 */     Object object = map.get(this.key);
/*     */ 
/*     */ 
/*     */     
/*  96 */     if (object instanceof ObservableValue) {
/*  97 */       return (ObservableValue<T>)object;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     if (object instanceof Boolean)
/* 113 */       return new ReadOnlyBooleanWrapper(((Boolean)object).booleanValue()); 
/* 114 */     if (object instanceof Integer)
/* 115 */       return new ReadOnlyIntegerWrapper(((Integer)object).intValue()); 
/* 116 */     if (object instanceof Float)
/* 117 */       return new ReadOnlyFloatWrapper(((Float)object).floatValue()); 
/* 118 */     if (object instanceof Long)
/* 119 */       return new ReadOnlyLongWrapper(((Long)object).longValue()); 
/* 120 */     if (object instanceof Double)
/* 121 */       return new ReadOnlyDoubleWrapper(((Double)object).doubleValue()); 
/* 122 */     if (object instanceof String) {
/* 123 */       return new ReadOnlyStringWrapper((String)object);
/*     */     }
/*     */ 
/*     */     
/* 127 */     return new ReadOnlyObjectWrapper<>((T)object);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\MapValueFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */