/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.scene.control.ProgressBar;
/*     */ import javafx.scene.control.TreeTableCell;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProgressBarTreeTableCell<S>
/*     */   extends TreeTableCell<S, Double>
/*     */ {
/*     */   private final ProgressBar progressBar;
/*     */   private ObservableValue<Double> observable;
/*     */   
/*     */   public static <S> Callback<TreeTableColumn<S, Double>, TreeTableCell<S, Double>> forTreeTableColumn() {
/*  61 */     return paramTreeTableColumn -> new ProgressBarTreeTableCell();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProgressBarTreeTableCell() {
/*  88 */     getStyleClass().add("progress-bar-tree-table-cell");
/*     */     
/*  90 */     this.progressBar = new ProgressBar();
/*  91 */     this.progressBar.setMaxWidth(Double.MAX_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateItem(Double paramDouble, boolean paramBoolean) {
/* 104 */     super.updateItem(paramDouble, paramBoolean);
/*     */     
/* 106 */     if (paramBoolean) {
/* 107 */       setGraphic(null);
/*     */     } else {
/* 109 */       this.progressBar.progressProperty().unbind();
/*     */       
/* 111 */       TreeTableColumn<S, Double> treeTableColumn = getTableColumn();
/* 112 */       this.observable = (treeTableColumn == null) ? null : treeTableColumn.getCellObservableValue(getIndex());
/*     */       
/* 114 */       if (this.observable != null) {
/* 115 */         this.progressBar.progressProperty().bind((ObservableValue)this.observable);
/* 116 */       } else if (paramDouble != null) {
/* 117 */         this.progressBar.setProgress(paramDouble.doubleValue());
/*     */       } 
/*     */       
/* 120 */       setGraphic(this.progressBar);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\ProgressBarTreeTableCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */