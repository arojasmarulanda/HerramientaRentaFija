/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.scene.control.CheckBox;
/*     */ import javafx.scene.control.CheckBoxTreeItem;
/*     */ import javafx.scene.control.TreeCell;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeView;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckBoxTreeCell<T>
/*     */   extends DefaultTreeCell<T>
/*     */ {
/*     */   private final CheckBox checkBox;
/*     */   private ObservableValue<Boolean> booleanProperty;
/*     */   private BooleanProperty indeterminateProperty;
/*     */   private ObjectProperty<StringConverter<TreeItem<T>>> converter;
/*     */   private ObjectProperty<Callback<TreeItem<T>, ObservableValue<Boolean>>> selectedStateCallback;
/*     */   
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView() {
/* 138 */     Callback<TreeItem<T>, ObservableValue<Boolean>> callback = paramTreeItem -> (paramTreeItem instanceof CheckBoxTreeItem) ? ((CheckBoxTreeItem)paramTreeItem).selectedProperty() : null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     return forTreeView(callback, 
/* 146 */         CellUtils.defaultTreeItemStringConverter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(Callback<TreeItem<T>, ObservableValue<Boolean>> paramCallback) {
/* 182 */     return forTreeView(paramCallback, CellUtils.defaultTreeItemStringConverter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(Callback<TreeItem<T>, ObservableValue<Boolean>> paramCallback, StringConverter<TreeItem<T>> paramStringConverter) {
/* 223 */     return paramTreeView -> new CheckBoxTreeCell(paramCallback, paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxTreeCell() {
/* 258 */     this(paramTreeItem -> (paramTreeItem instanceof CheckBoxTreeItem) ? ((CheckBoxTreeItem)paramTreeItem).selectedProperty() : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxTreeCell(Callback<TreeItem<T>, ObservableValue<Boolean>> paramCallback) {
/* 295 */     this(paramCallback, CellUtils.defaultTreeItemStringConverter(), (Callback<TreeItem<T>, ObservableValue<Boolean>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxTreeCell(Callback<TreeItem<T>, ObservableValue<Boolean>> paramCallback, StringConverter<TreeItem<T>> paramStringConverter) {
/* 331 */     this(paramCallback, paramStringConverter, (Callback<TreeItem<T>, ObservableValue<Boolean>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CheckBoxTreeCell(Callback<TreeItem<T>, ObservableValue<Boolean>> paramCallback1, StringConverter<TreeItem<T>> paramStringConverter, Callback<TreeItem<T>, ObservableValue<Boolean>> paramCallback2) {
/* 358 */     this.converter = new SimpleObjectProperty<>(this, "converter");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 388 */     this.selectedStateCallback = new SimpleObjectProperty<>(this, "selectedStateCallback");
/*     */     getStyleClass().add("check-box-tree-cell");
/*     */     setSelectedStateCallback(paramCallback1);
/*     */     setConverter(paramStringConverter);
/*     */     this.checkBox = new CheckBox();
/*     */     this.checkBox.setAllowIndeterminate(false);
/*     */     setGraphic(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<Callback<TreeItem<T>, ObservableValue<Boolean>>> selectedStateCallbackProperty() {
/* 400 */     return this.selectedStateCallback;
/*     */   } public final ObjectProperty<StringConverter<TreeItem<T>>> converterProperty() {
/*     */     return this.converter;
/*     */   }
/*     */   public final void setConverter(StringConverter<TreeItem<T>> paramStringConverter) {
/*     */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */   public final void setSelectedStateCallback(Callback<TreeItem<T>, ObservableValue<Boolean>> paramCallback) {
/* 408 */     selectedStateCallbackProperty().set(paramCallback);
/*     */   }
/*     */   
/*     */   public final StringConverter<TreeItem<T>> getConverter() {
/*     */     return converterProperty().get();
/*     */   }
/*     */   
/*     */   public final Callback<TreeItem<T>, ObservableValue<Boolean>> getSelectedStateCallback() {
/* 416 */     return selectedStateCallbackProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 429 */     super.updateItem(paramT, paramBoolean);
/*     */     
/* 431 */     if (paramBoolean) {
/* 432 */       setText(null);
/* 433 */       setGraphic(null);
/*     */     } else {
/* 435 */       StringConverter<TreeItem<T>> stringConverter = getConverter();
/*     */       
/* 437 */       TreeItem<T> treeItem = getTreeItem();
/*     */ 
/*     */       
/* 440 */       setText((stringConverter != null) ? stringConverter.toString(treeItem) : ((treeItem == null) ? "" : treeItem.toString()));
/* 441 */       this.checkBox.setGraphic((treeItem == null) ? null : treeItem.getGraphic());
/* 442 */       setGraphic(this.checkBox);
/*     */ 
/*     */       
/* 445 */       if (this.booleanProperty != null) {
/* 446 */         this.checkBox.selectedProperty().unbindBidirectional((BooleanProperty)this.booleanProperty);
/*     */       }
/* 448 */       if (this.indeterminateProperty != null) {
/* 449 */         this.checkBox.indeterminateProperty().unbindBidirectional(this.indeterminateProperty);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 454 */       if (treeItem instanceof CheckBoxTreeItem) {
/* 455 */         CheckBoxTreeItem checkBoxTreeItem = (CheckBoxTreeItem)treeItem;
/* 456 */         this.booleanProperty = checkBoxTreeItem.selectedProperty();
/* 457 */         this.checkBox.selectedProperty().bindBidirectional((BooleanProperty)this.booleanProperty);
/*     */         
/* 459 */         this.indeterminateProperty = checkBoxTreeItem.indeterminateProperty();
/* 460 */         this.checkBox.indeterminateProperty().bindBidirectional(this.indeterminateProperty);
/*     */       } else {
/* 462 */         Callback<TreeItem<T>, ObservableValue<Boolean>> callback = getSelectedStateCallback();
/* 463 */         if (callback == null) {
/* 464 */           throw new NullPointerException("The CheckBoxTreeCell selectedStateCallbackProperty can not be null");
/*     */         }
/*     */ 
/*     */         
/* 468 */         this.booleanProperty = callback.call(treeItem);
/* 469 */         if (this.booleanProperty != null)
/* 470 */           this.checkBox.selectedProperty().bindBidirectional((BooleanProperty)this.booleanProperty); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void updateDisplay(T paramT, boolean paramBoolean) {}
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\CheckBoxTreeCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */