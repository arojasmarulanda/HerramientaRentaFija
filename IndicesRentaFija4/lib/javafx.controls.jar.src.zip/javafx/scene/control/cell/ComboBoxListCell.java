/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ComboBox;
/*     */ import javafx.scene.control.ListCell;
/*     */ import javafx.scene.control.ListView;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboBoxListCell<T>
/*     */   extends ListCell<T>
/*     */ {
/*     */   private final ObservableList<T> items;
/*     */   private ComboBox<T> comboBox;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   private BooleanProperty comboBoxEditable;
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(T... paramVarArgs) {
/*  81 */     return forListView(FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 105 */     return forListView(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(ObservableList<T> paramObservableList) {
/* 125 */     return forListView((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList) {
/* 148 */     return paramListView -> new ComboBoxListCell(paramStringConverter, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxListCell() {
/* 175 */     this(FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ComboBoxListCell(T... paramVarArgs) {
/* 187 */     this(FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ComboBoxListCell(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 204 */     this(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxListCell(ObservableList<T> paramObservableList) {
/* 215 */     this((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxListCell(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList)
/*     */   {
/* 245 */     this.converter = new SimpleObjectProperty<>(this, "converter");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     this.comboBoxEditable = new SimpleBooleanProperty(this, "comboBoxEditable");
/*     */     getStyleClass().add("combo-box-list-cell");
/*     */     this.items = paramObservableList;
/*     */     setConverter((paramStringConverter != null) ? paramStringConverter : CellUtils.<T>defaultStringConverter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BooleanProperty comboBoxEditableProperty() {
/* 284 */     return this.comboBoxEditable;
/*     */   }
/*     */   public final ObjectProperty<StringConverter<T>> converterProperty() {
/*     */     return this.converter;
/*     */   }
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) {
/*     */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */   public final void setComboBoxEditable(boolean paramBoolean) {
/* 293 */     comboBoxEditableProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final StringConverter<T> getConverter() {
/*     */     return converterProperty().get();
/*     */   }
/*     */   
/*     */   public final boolean isComboBoxEditable() {
/* 301 */     return comboBoxEditableProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<T> getItems() {
/* 317 */     return this.items;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startEdit() {
/* 322 */     if (!isEditable() || !getListView().isEditable()) {
/*     */       return;
/*     */     }
/*     */     
/* 326 */     if (this.comboBox == null) {
/* 327 */       this.comboBox = CellUtils.createComboBox(this, this.items, converterProperty());
/* 328 */       this.comboBox.editableProperty().bind(comboBoxEditableProperty());
/*     */     } 
/*     */     
/* 331 */     this.comboBox.getSelectionModel().select(getItem());
/*     */     
/* 333 */     super.startEdit();
/*     */     
/* 335 */     if (isEditing()) {
/* 336 */       setText(null);
/* 337 */       setGraphic(this.comboBox);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancelEdit() {
/* 343 */     super.cancelEdit();
/*     */     
/* 345 */     setText(getConverter().toString(getItem()));
/* 346 */     setGraphic(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 351 */     super.updateItem(paramT, paramBoolean);
/* 352 */     CellUtils.updateItem(this, getConverter(), (HBox)null, (Node)null, this.comboBox);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\ComboBoxListCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */