/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Cell;
/*     */ import javafx.scene.control.ChoiceBox;
/*     */ import javafx.scene.control.ComboBox;
/*     */ import javafx.scene.control.Skin;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.skin.ComboBoxListViewSkin;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CellUtils
/*     */ {
/*  50 */   static int TREE_VIEW_HBOX_GRAPHIC_PADDING = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private static final StringConverter<?> defaultStringConverter = new StringConverter() {
/*     */       public String toString(Object param1Object) {
/*  60 */         return (param1Object == null) ? null : param1Object.toString();
/*     */       }
/*     */       
/*     */       public Object fromString(String param1String) {
/*  64 */         return param1String;
/*     */       }
/*     */     };
/*     */   
/*  68 */   private static final StringConverter<?> defaultTreeItemStringConverter = new StringConverter<TreeItem<?>>()
/*     */     {
/*     */       public String toString(TreeItem<?> param1TreeItem) {
/*  71 */         return (param1TreeItem == null || param1TreeItem.getValue() == null) ? 
/*  72 */           "" : param1TreeItem.getValue().toString();
/*     */       }
/*     */       
/*     */       public TreeItem<?> fromString(String param1String) {
/*  76 */         return new TreeItem(param1String);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> StringConverter<T> defaultStringConverter() {
/*  92 */     return (StringConverter)defaultStringConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> StringConverter<TreeItem<T>> defaultTreeItemStringConverter() {
/* 101 */     return (StringConverter)defaultTreeItemStringConverter;
/*     */   }
/*     */   
/*     */   private static <T> String getItemText(Cell<T> paramCell, StringConverter<T> paramStringConverter) {
/* 105 */     return (paramStringConverter == null) ? (
/* 106 */       (paramCell.getItem() == null) ? "" : paramCell.getItem().toString()) : 
/* 107 */       paramStringConverter.toString(paramCell.getItem());
/*     */   }
/*     */ 
/*     */   
/*     */   static Node getGraphic(TreeItem<?> paramTreeItem) {
/* 112 */     return (paramTreeItem == null) ? null : paramTreeItem.getGraphic();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void updateItem(Cell<T> paramCell, StringConverter<T> paramStringConverter, ChoiceBox<T> paramChoiceBox) {
/* 126 */     updateItem(paramCell, paramStringConverter, (HBox)null, (Node)null, paramChoiceBox);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void updateItem(Cell<T> paramCell, StringConverter<T> paramStringConverter, HBox paramHBox, Node paramNode, ChoiceBox<T> paramChoiceBox) {
/* 134 */     if (paramCell.isEmpty()) {
/* 135 */       paramCell.setText(null);
/* 136 */       paramCell.setGraphic(null);
/*     */     }
/* 138 */     else if (paramCell.isEditing()) {
/* 139 */       if (paramChoiceBox != null) {
/* 140 */         paramChoiceBox.getSelectionModel().select(paramCell.getItem());
/*     */       }
/* 142 */       paramCell.setText(null);
/*     */       
/* 144 */       if (paramNode != null) {
/* 145 */         paramHBox.getChildren().setAll(new Node[] { paramNode, paramChoiceBox });
/* 146 */         paramCell.setGraphic(paramHBox);
/*     */       } else {
/* 148 */         paramCell.setGraphic(paramChoiceBox);
/*     */       } 
/*     */     } else {
/* 151 */       paramCell.setText(getItemText(paramCell, paramStringConverter));
/* 152 */       paramCell.setGraphic(paramNode);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> ChoiceBox<T> createChoiceBox(Cell<T> paramCell, ObservableList<T> paramObservableList, ObjectProperty<StringConverter<T>> paramObjectProperty) {
/* 161 */     ChoiceBox<T> choiceBox = new ChoiceBox<>(paramObservableList);
/* 162 */     choiceBox.setMaxWidth(Double.MAX_VALUE);
/* 163 */     choiceBox.converterProperty().bind(paramObjectProperty);
/* 164 */     choiceBox.showingProperty().addListener(paramObservable -> {
/*     */           if (!paramChoiceBox.isShowing()) {
/*     */             paramCell.commitEdit(paramChoiceBox.getSelectionModel().getSelectedItem());
/*     */           }
/*     */         });
/* 169 */     return choiceBox;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void updateItem(Cell<T> paramCell, StringConverter<T> paramStringConverter, TextField paramTextField) {
/* 183 */     updateItem(paramCell, paramStringConverter, (HBox)null, (Node)null, paramTextField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void updateItem(Cell<T> paramCell, StringConverter<T> paramStringConverter, HBox paramHBox, Node paramNode, TextField paramTextField) {
/* 191 */     if (paramCell.isEmpty()) {
/* 192 */       paramCell.setText(null);
/* 193 */       paramCell.setGraphic(null);
/*     */     }
/* 195 */     else if (paramCell.isEditing()) {
/* 196 */       if (paramTextField != null) {
/* 197 */         paramTextField.setText(getItemText(paramCell, paramStringConverter));
/*     */       }
/* 199 */       paramCell.setText(null);
/*     */       
/* 201 */       if (paramNode != null) {
/* 202 */         paramHBox.getChildren().setAll(new Node[] { paramNode, paramTextField });
/* 203 */         paramCell.setGraphic(paramHBox);
/*     */       } else {
/* 205 */         paramCell.setGraphic(paramTextField);
/*     */       } 
/*     */     } else {
/* 208 */       paramCell.setText(getItemText(paramCell, paramStringConverter));
/* 209 */       paramCell.setGraphic(paramNode);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void startEdit(Cell<T> paramCell, StringConverter<T> paramStringConverter, HBox paramHBox, Node paramNode, TextField paramTextField) {
/* 219 */     if (paramTextField != null) {
/* 220 */       paramTextField.setText(getItemText(paramCell, paramStringConverter));
/*     */     }
/* 222 */     paramCell.setText(null);
/*     */     
/* 224 */     if (paramNode != null) {
/* 225 */       paramHBox.getChildren().setAll(new Node[] { paramNode, paramTextField });
/* 226 */       paramCell.setGraphic(paramHBox);
/*     */     } else {
/* 228 */       paramCell.setGraphic(paramTextField);
/*     */     } 
/*     */     
/* 231 */     paramTextField.selectAll();
/*     */ 
/*     */ 
/*     */     
/* 235 */     paramTextField.requestFocus();
/*     */   }
/*     */   
/*     */   static <T> void cancelEdit(Cell<T> paramCell, StringConverter<T> paramStringConverter, Node paramNode) {
/* 239 */     paramCell.setText(getItemText(paramCell, paramStringConverter));
/* 240 */     paramCell.setGraphic(paramNode);
/*     */   }
/*     */   
/*     */   static <T> TextField createTextField(Cell<T> paramCell, StringConverter<T> paramStringConverter) {
/* 244 */     TextField textField = new TextField(getItemText(paramCell, paramStringConverter));
/*     */ 
/*     */ 
/*     */     
/* 248 */     textField.setOnAction(paramActionEvent -> {
/*     */           if (paramStringConverter == null) {
/*     */             throw new IllegalStateException("Attempting to convert text input into Object, but provided StringConverter is null. Be sure to set a StringConverter in your cell factory.");
/*     */           }
/*     */           
/*     */           paramCell.commitEdit(paramStringConverter.fromString(paramTextField.getText()));
/*     */           
/*     */           paramActionEvent.consume();
/*     */         });
/*     */     
/* 258 */     textField.setOnKeyReleased(paramKeyEvent -> {
/*     */           if (paramKeyEvent.getCode() == KeyCode.ESCAPE) {
/*     */             paramCell.cancelEdit();
/*     */             paramKeyEvent.consume();
/*     */           } 
/*     */         });
/* 264 */     return textField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void updateItem(Cell<T> paramCell, StringConverter<T> paramStringConverter, ComboBox<T> paramComboBox) {
/* 276 */     updateItem(paramCell, paramStringConverter, (HBox)null, (Node)null, paramComboBox);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> void updateItem(Cell<T> paramCell, StringConverter<T> paramStringConverter, HBox paramHBox, Node paramNode, ComboBox<T> paramComboBox) {
/* 284 */     if (paramCell.isEmpty()) {
/* 285 */       paramCell.setText(null);
/* 286 */       paramCell.setGraphic(null);
/*     */     }
/* 288 */     else if (paramCell.isEditing()) {
/* 289 */       if (paramComboBox != null) {
/* 290 */         paramComboBox.getSelectionModel().select(paramCell.getItem());
/*     */       }
/* 292 */       paramCell.setText(null);
/*     */       
/* 294 */       if (paramNode != null) {
/* 295 */         paramHBox.getChildren().setAll(new Node[] { paramNode, paramComboBox });
/* 296 */         paramCell.setGraphic(paramHBox);
/*     */       } else {
/* 298 */         paramCell.setGraphic(paramComboBox);
/*     */       } 
/*     */     } else {
/* 301 */       paramCell.setText(getItemText(paramCell, paramStringConverter));
/* 302 */       paramCell.setGraphic(paramNode);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> ComboBox<T> createComboBox(final Cell<T> cell, ObservableList<T> paramObservableList, ObjectProperty<StringConverter<T>> paramObjectProperty) {
/* 310 */     final ComboBox<T> comboBox = new ComboBox<>(paramObservableList);
/* 311 */     comboBox.converterProperty().bind(paramObjectProperty);
/* 312 */     comboBox.setMaxWidth(Double.MAX_VALUE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 318 */     comboBox.addEventFilter((EventType)KeyEvent.KEY_RELEASED, paramKeyEvent -> {
/*     */           if (paramKeyEvent.getCode() == KeyCode.ENTER) {
/*     */             tryComboBoxCommit(paramComboBox, paramCell);
/*     */           } else if (paramKeyEvent.getCode() == KeyCode.ESCAPE) {
/*     */             paramCell.cancelEdit();
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 328 */     comboBox.getEditor().focusedProperty().addListener(paramObservable -> {
/*     */           if (!paramComboBox.isFocused()) {
/*     */             tryComboBoxCommit(paramComboBox, paramCell);
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 337 */     boolean bool = listenToComboBoxSkin(comboBox, cell);
/* 338 */     if (!bool) {
/* 339 */       comboBox.skinProperty().addListener(new InvalidationListener() {
/*     */             public void invalidated(Observable param1Observable) {
/* 341 */               boolean bool = CellUtils.listenToComboBoxSkin(comboBox, cell);
/* 342 */               if (bool) {
/* 343 */                 comboBox.skinProperty().removeListener(this);
/*     */               }
/*     */             }
/*     */           });
/*     */     }
/*     */     
/* 349 */     return comboBox;
/*     */   }
/*     */   
/*     */   private static <T> void tryComboBoxCommit(ComboBox<T> paramComboBox, Cell<T> paramCell) {
/* 353 */     StringConverter<T> stringConverter = paramComboBox.getConverter();
/* 354 */     if (paramComboBox.isEditable() && stringConverter != null) {
/* 355 */       T t = stringConverter.fromString(paramComboBox.getEditor().getText());
/* 356 */       paramCell.commitEdit(t);
/*     */     } else {
/* 358 */       paramCell.commitEdit(paramComboBox.getValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static <T> boolean listenToComboBoxSkin(ComboBox<T> paramComboBox, Cell<T> paramCell) {
/* 363 */     Skin<?> skin = paramComboBox.getSkin();
/* 364 */     if (skin != null && skin instanceof ComboBoxListViewSkin) {
/* 365 */       ComboBoxListViewSkin comboBoxListViewSkin = (ComboBoxListViewSkin)skin;
/* 366 */       Node node = comboBoxListViewSkin.getPopupContent();
/* 367 */       if (node != null && node instanceof javafx.scene.control.ListView) {
/* 368 */         node.addEventHandler(MouseEvent.MOUSE_RELEASED, paramMouseEvent -> paramCell.commitEdit(paramComboBox.getValue()));
/* 369 */         return true;
/*     */       } 
/*     */     } 
/* 372 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\CellUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */