/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ListCell;
/*     */ import javafx.scene.control.ListView;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ import javafx.util.converter.DefaultStringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextFieldListCell<T>
/*     */   extends ListCell<T>
/*     */ {
/*     */   private TextField textField;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   
/*     */   public static Callback<ListView<String>, ListCell<String>> forListView() {
/*  68 */     return forListView(new DefaultStringConverter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(StringConverter<T> paramStringConverter) {
/*  88 */     return paramListView -> new TextFieldListCell(paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextFieldListCell() {
/* 116 */     this((StringConverter<T>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextFieldListCell(StringConverter<T> paramStringConverter) {
/* 146 */     this.converter = new SimpleObjectProperty<>(this, "converter");
/*     */     getStyleClass().add("text-field-list-cell");
/*     */     setConverter(paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<StringConverter<T>> converterProperty() {
/* 154 */     return this.converter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) {
/* 162 */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final StringConverter<T> getConverter() {
/* 170 */     return converterProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startEdit() {
/* 182 */     if (!isEditable() || !getListView().isEditable()) {
/*     */       return;
/*     */     }
/* 185 */     super.startEdit();
/*     */     
/* 187 */     if (isEditing()) {
/* 188 */       if (this.textField == null) {
/* 189 */         this.textField = CellUtils.createTextField(this, getConverter());
/*     */       }
/*     */       
/* 192 */       CellUtils.startEdit(this, getConverter(), null, null, this.textField);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancelEdit() {
/* 198 */     super.cancelEdit();
/* 199 */     CellUtils.cancelEdit(this, getConverter(), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 204 */     super.updateItem(paramT, paramBoolean);
/* 205 */     CellUtils.updateItem(this, getConverter(), (HBox)null, (Node)null, this.textField);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\TextFieldListCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */