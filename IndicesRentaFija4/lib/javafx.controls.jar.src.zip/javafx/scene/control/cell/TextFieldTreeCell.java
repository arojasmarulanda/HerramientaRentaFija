/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.control.TreeCell;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeView;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ import javafx.util.converter.DefaultStringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextFieldTreeCell<T>
/*     */   extends DefaultTreeCell<T>
/*     */ {
/*     */   private TextField textField;
/*     */   private HBox hbox;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   
/*     */   public static Callback<TreeView<String>, TreeCell<String>> forTreeView() {
/*  72 */     return forTreeView(new DefaultStringConverter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(StringConverter<T> paramStringConverter) {
/*  95 */     return paramTreeView -> new TextFieldTreeCell(paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextFieldTreeCell() {
/* 125 */     this((StringConverter<T>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextFieldTreeCell(StringConverter<T> paramStringConverter) {
/* 155 */     this.converter = new SimpleObjectProperty<>(this, "converter");
/*     */     getStyleClass().add("text-field-tree-cell");
/*     */     setConverter(paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<StringConverter<T>> converterProperty() {
/* 163 */     return this.converter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) {
/* 171 */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final StringConverter<T> getConverter() {
/* 179 */     return converterProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startEdit() {
/* 192 */     if (!isEditable() || !getTreeView().isEditable()) {
/*     */       return;
/*     */     }
/* 195 */     super.startEdit();
/*     */     
/* 197 */     if (isEditing()) {
/* 198 */       StringConverter<T> stringConverter = getConverter();
/* 199 */       if (this.textField == null) {
/* 200 */         this.textField = CellUtils.createTextField(this, stringConverter);
/*     */       }
/* 202 */       if (this.hbox == null) {
/* 203 */         this.hbox = new HBox(CellUtils.TREE_VIEW_HBOX_GRAPHIC_PADDING);
/*     */       }
/*     */       
/* 206 */       CellUtils.startEdit(this, stringConverter, this.hbox, getTreeItemGraphic(), this.textField);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancelEdit() {
/* 212 */     super.cancelEdit();
/* 213 */     CellUtils.cancelEdit(this, getConverter(), getTreeItemGraphic());
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 218 */     super.updateItem(paramT, paramBoolean);
/* 219 */     CellUtils.updateItem(this, getConverter(), this.hbox, getTreeItemGraphic(), this.textField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Node getTreeItemGraphic() {
/* 231 */     TreeItem<T> treeItem = getTreeItem();
/* 232 */     return (treeItem == null) ? null : treeItem.getGraphic();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\TextFieldTreeCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */