/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.CheckBox;
/*     */ import javafx.scene.control.TableCell;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckBoxTableCell<S, T>
/*     */   extends TableCell<S, T>
/*     */ {
/*     */   private final CheckBox checkBox;
/*     */   private boolean showLabel;
/*     */   private ObservableValue<Boolean> booleanProperty;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   private ObjectProperty<Callback<Integer, ObservableValue<Boolean>>> selectedStateCallback;
/*     */   
/*     */   public static <S> Callback<TableColumn<S, Boolean>, TableCell<S, Boolean>> forTableColumn(TableColumn<S, Boolean> paramTableColumn) {
/*  99 */     return forTableColumn((Callback<Integer, ObservableValue<Boolean>>)null, (StringConverter<Boolean>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(Callback<Integer, ObservableValue<Boolean>> paramCallback) {
/* 126 */     return forTableColumn(paramCallback, (StringConverter<T>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(Callback<Integer, ObservableValue<Boolean>> paramCallback, boolean paramBoolean) {
/* 163 */     StringConverter<T> stringConverter = !paramBoolean ? null : CellUtils.<T>defaultStringConverter();
/* 164 */     return forTableColumn(paramCallback, stringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> Callback<TableColumn<S, T>, TableCell<S, T>> forTableColumn(Callback<Integer, ObservableValue<Boolean>> paramCallback, StringConverter<T> paramStringConverter) {
/* 198 */     return paramTableColumn -> new CheckBoxTableCell<>(paramCallback, paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxTableCell() {
/* 226 */     this((Callback<Integer, ObservableValue<Boolean>>)null, (StringConverter<T>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxTableCell(Callback<Integer, ObservableValue<Boolean>> paramCallback) {
/* 238 */     this(paramCallback, (StringConverter<T>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxTableCell(Callback<Integer, ObservableValue<Boolean>> paramCallback, StringConverter<T> paramStringConverter)
/*     */   {
/* 282 */     this.converter = (ObjectProperty)new SimpleObjectProperty<StringConverter<StringConverter<T>>>(this, "converter")
/*     */       {
/*     */         protected void invalidated() {
/* 285 */           CheckBoxTableCell.this.updateShowLabel();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 316 */     this.selectedStateCallback = new SimpleObjectProperty<>(this, "selectedStateCallback");
/*     */     getStyleClass().add("check-box-table-cell");
/*     */     this.checkBox = new CheckBox();
/*     */     setGraphic((Node)null);
/*     */     setSelectedStateCallback(paramCallback);
/*     */     setConverter(paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<Callback<Integer, ObservableValue<Boolean>>> selectedStateCallbackProperty() {
/* 328 */     return this.selectedStateCallback;
/*     */   }
/*     */   public final ObjectProperty<StringConverter<T>> converterProperty() {
/*     */     return this.converter;
/*     */   }
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) {
/*     */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */   public final void setSelectedStateCallback(Callback<Integer, ObservableValue<Boolean>> paramCallback) {
/* 337 */     selectedStateCallbackProperty().set(paramCallback);
/*     */   }
/*     */   
/*     */   public final StringConverter<T> getConverter() {
/*     */     return converterProperty().get();
/*     */   }
/*     */   
/*     */   public final Callback<Integer, ObservableValue<Boolean>> getSelectedStateCallback() {
/* 345 */     return selectedStateCallbackProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 359 */     super.updateItem(paramT, paramBoolean);
/*     */     
/* 361 */     if (paramBoolean) {
/* 362 */       setText((String)null);
/* 363 */       setGraphic((Node)null);
/*     */     } else {
/* 365 */       StringConverter<T> stringConverter = getConverter();
/*     */       
/* 367 */       if (this.showLabel) {
/* 368 */         setText(stringConverter.toString(paramT));
/*     */       }
/* 370 */       setGraphic(this.checkBox);
/*     */       
/* 372 */       if (this.booleanProperty instanceof BooleanProperty) {
/* 373 */         this.checkBox.selectedProperty().unbindBidirectional((BooleanProperty)this.booleanProperty);
/*     */       }
/* 375 */       ObservableValue<?> observableValue = getSelectedProperty();
/* 376 */       if (observableValue instanceof BooleanProperty) {
/* 377 */         this.booleanProperty = (ObservableValue)observableValue;
/* 378 */         this.checkBox.selectedProperty().bindBidirectional((BooleanProperty)this.booleanProperty);
/*     */       } 
/*     */       
/* 381 */       this.checkBox.disableProperty().bind(Bindings.not(
/* 382 */             getTableView().editableProperty().and(
/* 383 */               getTableColumn().editableProperty()).and(
/* 384 */               editableProperty())));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateShowLabel() {
/* 398 */     this.showLabel = (this.converter != null);
/* 399 */     this.checkBox.setAlignment(this.showLabel ? Pos.CENTER_LEFT : Pos.CENTER);
/*     */   }
/*     */   
/*     */   private ObservableValue<?> getSelectedProperty() {
/* 403 */     return (getSelectedStateCallback() != null) ? 
/* 404 */       getSelectedStateCallback().call(Integer.valueOf(getIndex())) : 
/* 405 */       getTableColumn().getCellObservableValue(getIndex());
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\CheckBoxTableCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */