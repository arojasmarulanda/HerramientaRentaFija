/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.javafx.property.PropertyReference;
/*     */ import com.sun.javafx.scene.control.Logging;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeItemPropertyValueFactory<S, T>
/*     */   implements Callback<TreeTableColumn.CellDataFeatures<S, T>, ObservableValue<T>>
/*     */ {
/*     */   private final String property;
/*     */   private Class<?> columnClass;
/*     */   private String previousProperty;
/*     */   private PropertyReference<T> propertyRef;
/*     */   
/*     */   public TreeItemPropertyValueFactory(@NamedArg("property") String paramString) {
/* 152 */     this.property = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public ObservableValue<T> call(TreeTableColumn.CellDataFeatures<S, T> paramCellDataFeatures) {
/* 157 */     TreeItem<S> treeItem = paramCellDataFeatures.getValue();
/* 158 */     return getCellDataReflectively(treeItem.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getProperty() {
/* 165 */     return this.property;
/*     */   }
/*     */   private ObservableValue<T> getCellDataReflectively(S paramS) {
/* 168 */     if (getProperty() == null || getProperty().isEmpty() || paramS == null) return null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 174 */       if (this.columnClass == null || this.previousProperty == null || 
/* 175 */         !this.columnClass.equals(paramS.getClass()) || 
/* 176 */         !this.previousProperty.equals(getProperty())) {
/*     */ 
/*     */         
/* 179 */         this.columnClass = paramS.getClass();
/* 180 */         this.previousProperty = getProperty();
/* 181 */         this.propertyRef = new PropertyReference<>(paramS.getClass(), getProperty());
/*     */       } 
/*     */       
/* 184 */       if (this.propertyRef != null) {
/* 185 */         return this.propertyRef.getProperty(paramS);
/*     */       }
/* 187 */     } catch (RuntimeException runtimeException) {
/*     */       
/*     */       try {
/* 190 */         T t = this.propertyRef.get(paramS);
/* 191 */         return new ReadOnlyObjectWrapper<>(t);
/* 192 */       } catch (RuntimeException runtimeException1) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 197 */         PlatformLogger platformLogger = Logging.getControlsLogger();
/* 198 */         if (platformLogger.isLoggable(PlatformLogger.Level.WARNING)) {
/* 199 */           platformLogger.warning("Can not retrieve property '" + getProperty() + "' in TreeItemPropertyValueFactory: " + this + " with provided class type: " + paramS
/*     */               
/* 201 */               .getClass(), runtimeException);
/*     */         }
/* 203 */         this.propertyRef = null;
/*     */       } 
/*     */     } 
/* 206 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\TreeItemPropertyValueFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */