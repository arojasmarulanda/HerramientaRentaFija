/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ComboBox;
/*     */ import javafx.scene.control.TreeTableCell;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboBoxTreeTableCell<S, T>
/*     */   extends TreeTableCell<S, T>
/*     */ {
/*     */   private final ObservableList<T> items;
/*     */   private ComboBox<T> comboBox;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   private BooleanProperty comboBoxEditable;
/*     */   
/*     */   @SafeVarargs
/*     */   public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(T... paramVarArgs) {
/*  89 */     return forTreeTableColumn((StringConverter<T>)null, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 117 */     return forTreeTableColumn(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(ObservableList<T> paramObservableList) {
/* 141 */     return forTreeTableColumn((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S, T> Callback<TreeTableColumn<S, T>, TreeTableCell<S, T>> forTreeTableColumn(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList) {
/* 168 */     return paramTreeTableColumn -> new ComboBoxTreeTableCell<>(paramStringConverter, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxTreeTableCell() {
/* 195 */     this(FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ComboBoxTreeTableCell(T... paramVarArgs) {
/* 207 */     this(FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ComboBoxTreeTableCell(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 224 */     this(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxTreeTableCell(ObservableList<T> paramObservableList) {
/* 235 */     this((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxTreeTableCell(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList)
/*     */   {
/* 265 */     this.converter = new SimpleObjectProperty<>(this, "converter");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 294 */     this.comboBoxEditable = new SimpleBooleanProperty(this, "comboBoxEditable");
/*     */     getStyleClass().add("combo-box-tree-table-cell");
/*     */     this.items = paramObservableList;
/*     */     setConverter((paramStringConverter != null) ? paramStringConverter : CellUtils.<T>defaultStringConverter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BooleanProperty comboBoxEditableProperty() {
/* 304 */     return this.comboBoxEditable;
/*     */   }
/*     */   public final ObjectProperty<StringConverter<T>> converterProperty() {
/*     */     return this.converter;
/*     */   }
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) {
/*     */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */   public final void setComboBoxEditable(boolean paramBoolean) {
/* 313 */     comboBoxEditableProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final StringConverter<T> getConverter() {
/*     */     return converterProperty().get();
/*     */   }
/*     */   
/*     */   public final boolean isComboBoxEditable() {
/* 321 */     return comboBoxEditableProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<T> getItems() {
/* 337 */     return this.items;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startEdit() {
/* 342 */     if (!isEditable() || !getTreeTableView().isEditable() || !getTableColumn().isEditable()) {
/*     */       return;
/*     */     }
/*     */     
/* 346 */     if (this.comboBox == null) {
/* 347 */       this.comboBox = CellUtils.createComboBox(this, this.items, converterProperty());
/* 348 */       this.comboBox.editableProperty().bind(comboBoxEditableProperty());
/*     */     } 
/*     */     
/* 351 */     this.comboBox.getSelectionModel().select(getItem());
/*     */     
/* 353 */     super.startEdit();
/* 354 */     setText(null);
/* 355 */     setGraphic(this.comboBox);
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancelEdit() {
/* 360 */     super.cancelEdit();
/*     */     
/* 362 */     setText(getConverter().toString(getItem()));
/* 363 */     setGraphic(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 368 */     super.updateItem(paramT, paramBoolean);
/* 369 */     CellUtils.updateItem(this, getConverter(), (HBox)null, (Node)null, this.comboBox);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\ComboBoxTreeTableCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */