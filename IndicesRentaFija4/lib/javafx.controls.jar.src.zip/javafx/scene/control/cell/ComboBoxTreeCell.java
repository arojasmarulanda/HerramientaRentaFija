/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ComboBox;
/*     */ import javafx.scene.control.TreeCell;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeView;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboBoxTreeCell<T>
/*     */   extends DefaultTreeCell<T>
/*     */ {
/*     */   private final ObservableList<T> items;
/*     */   private ComboBox<T> comboBox;
/*     */   private HBox hbox;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   private BooleanProperty comboBoxEditable;
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(T... paramVarArgs) {
/*  83 */     return forTreeView(FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(ObservableList<T> paramObservableList) {
/* 106 */     return forTreeView((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 130 */     return forTreeView(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<TreeView<T>, TreeCell<T>> forTreeView(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList) {
/* 154 */     return paramTreeView -> new ComboBoxTreeCell(paramStringConverter, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxTreeCell() {
/* 181 */     this(FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ComboBoxTreeCell(T... paramVarArgs) {
/* 193 */     this(FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ComboBoxTreeCell(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 210 */     this(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxTreeCell(ObservableList<T> paramObservableList) {
/* 221 */     this((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxTreeCell(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList)
/*     */   {
/* 251 */     this.converter = new SimpleObjectProperty<>(this, "converter");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 280 */     this.comboBoxEditable = new SimpleBooleanProperty(this, "comboBoxEditable");
/*     */     getStyleClass().add("combo-box-tree-cell");
/*     */     this.items = paramObservableList;
/*     */     setConverter((paramStringConverter != null) ? paramStringConverter : CellUtils.<T>defaultStringConverter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BooleanProperty comboBoxEditableProperty() {
/* 290 */     return this.comboBoxEditable;
/*     */   }
/*     */   public final ObjectProperty<StringConverter<T>> converterProperty() {
/*     */     return this.converter;
/*     */   }
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) {
/*     */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */   public final void setComboBoxEditable(boolean paramBoolean) {
/* 299 */     comboBoxEditableProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final StringConverter<T> getConverter() {
/*     */     return converterProperty().get();
/*     */   }
/*     */   
/*     */   public final boolean isComboBoxEditable() {
/* 307 */     return comboBoxEditableProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<T> getItems() {
/* 323 */     return this.items;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startEdit() {
/* 328 */     if (!isEditable() || !getTreeView().isEditable()) {
/*     */       return;
/*     */     }
/*     */     
/* 332 */     TreeItem<T> treeItem = getTreeItem();
/* 333 */     if (treeItem == null) {
/*     */       return;
/*     */     }
/*     */     
/* 337 */     if (this.comboBox == null) {
/* 338 */       this.comboBox = CellUtils.createComboBox(this, this.items, converterProperty());
/* 339 */       this.comboBox.editableProperty().bind(comboBoxEditableProperty());
/*     */     } 
/* 341 */     if (this.hbox == null) {
/* 342 */       this.hbox = new HBox(CellUtils.TREE_VIEW_HBOX_GRAPHIC_PADDING);
/*     */     }
/*     */     
/* 345 */     this.comboBox.getSelectionModel().select(treeItem.getValue());
/*     */     
/* 347 */     super.startEdit();
/*     */     
/* 349 */     if (isEditing()) {
/* 350 */       setText(null);
/*     */       
/* 352 */       Node node = CellUtils.getGraphic(treeItem);
/* 353 */       if (node != null) {
/* 354 */         this.hbox.getChildren().setAll(new Node[] { node, this.comboBox });
/* 355 */         setGraphic(this.hbox);
/*     */       } else {
/* 357 */         setGraphic(this.comboBox);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancelEdit() {
/* 364 */     super.cancelEdit();
/*     */     
/* 366 */     setText(getConverter().toString(getItem()));
/* 367 */     setGraphic(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 372 */     super.updateItem(paramT, paramBoolean);
/*     */     
/* 374 */     Node node = CellUtils.getGraphic(getTreeItem());
/* 375 */     CellUtils.updateItem(this, getConverter(), this.hbox, node, this.comboBox);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\ComboBoxTreeCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */