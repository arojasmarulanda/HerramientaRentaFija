/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ChoiceBox;
/*     */ import javafx.scene.control.ListCell;
/*     */ import javafx.scene.control.ListView;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChoiceBoxListCell<T>
/*     */   extends ListCell<T>
/*     */ {
/*     */   private final ObservableList<T> items;
/*     */   private ChoiceBox<T> choiceBox;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(T... paramVarArgs) {
/*  82 */     return forListView(FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 106 */     return forListView(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(ObservableList<T> paramObservableList) {
/* 126 */     return forListView((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Callback<ListView<T>, ListCell<T>> forListView(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList) {
/* 149 */     return paramListView -> new ChoiceBoxListCell(paramStringConverter, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBoxListCell() {
/* 176 */     this(FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ChoiceBoxListCell(T... paramVarArgs) {
/* 188 */     this(FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public ChoiceBoxListCell(StringConverter<T> paramStringConverter, T... paramVarArgs) {
/* 205 */     this(paramStringConverter, FXCollections.observableArrayList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBoxListCell(ObservableList<T> paramObservableList) {
/* 216 */     this((StringConverter<T>)null, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBoxListCell(StringConverter<T> paramStringConverter, ObservableList<T> paramObservableList) {
/* 246 */     this.converter = new SimpleObjectProperty<>(this, "converter");
/*     */     getStyleClass().add("choice-box-list-cell");
/*     */     this.items = paramObservableList;
/*     */     setConverter((paramStringConverter != null) ? paramStringConverter : CellUtils.<T>defaultStringConverter());
/*     */   }
/*     */ 
/*     */   
/*     */   public final ObjectProperty<StringConverter<T>> converterProperty() {
/* 254 */     return this.converter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) {
/* 262 */     converterProperty().set(paramStringConverter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final StringConverter<T> getConverter() {
/* 270 */     return converterProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<T> getItems() {
/* 286 */     return this.items;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startEdit() {
/* 291 */     if (!isEditable() || !getListView().isEditable()) {
/*     */       return;
/*     */     }
/*     */     
/* 295 */     if (this.choiceBox == null) {
/* 296 */       this.choiceBox = CellUtils.createChoiceBox(this, this.items, converterProperty());
/*     */     }
/*     */     
/* 299 */     this.choiceBox.getSelectionModel().select(getItem());
/*     */     
/* 301 */     super.startEdit();
/*     */     
/* 303 */     if (isEditing()) {
/* 304 */       setText(null);
/* 305 */       setGraphic(this.choiceBox);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancelEdit() {
/* 311 */     super.cancelEdit();
/*     */     
/* 313 */     setText(getConverter().toString(getItem()));
/* 314 */     setGraphic(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateItem(T paramT, boolean paramBoolean) {
/* 319 */     super.updateItem(paramT, paramBoolean);
/* 320 */     CellUtils.updateItem(this, getConverter(), (HBox)null, (Node)null, this.choiceBox);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\ChoiceBoxListCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */