/*     */ package javafx.scene.control.cell;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.javafx.property.PropertyReference;
/*     */ import com.sun.javafx.scene.control.Logging;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyValueFactory<S, T>
/*     */   implements Callback<TableColumn.CellDataFeatures<S, T>, ObservableValue<T>>
/*     */ {
/*     */   private final String property;
/*     */   private Class<?> columnClass;
/*     */   private String previousProperty;
/*     */   private PropertyReference<T> propertyRef;
/*     */   
/*     */   public PropertyValueFactory(@NamedArg("property") String paramString) {
/* 149 */     this.property = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public ObservableValue<T> call(TableColumn.CellDataFeatures<S, T> paramCellDataFeatures) {
/* 154 */     return getCellDataReflectively(paramCellDataFeatures.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getProperty() {
/* 161 */     return this.property;
/*     */   }
/*     */   private ObservableValue<T> getCellDataReflectively(S paramS) {
/* 164 */     if (getProperty() == null || getProperty().isEmpty() || paramS == null) return null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 170 */       if (this.columnClass == null || this.previousProperty == null || 
/* 171 */         !this.columnClass.equals(paramS.getClass()) || 
/* 172 */         !this.previousProperty.equals(getProperty())) {
/*     */ 
/*     */         
/* 175 */         this.columnClass = paramS.getClass();
/* 176 */         this.previousProperty = getProperty();
/* 177 */         this.propertyRef = new PropertyReference<>(paramS.getClass(), getProperty());
/*     */       } 
/*     */       
/* 180 */       if (this.propertyRef != null) {
/* 181 */         if (this.propertyRef.hasProperty()) {
/* 182 */           return this.propertyRef.getProperty(paramS);
/*     */         }
/* 184 */         T t = this.propertyRef.get(paramS);
/* 185 */         return new ReadOnlyObjectWrapper<>(t);
/*     */       }
/*     */     
/* 188 */     } catch (RuntimeException runtimeException) {
/*     */       
/* 190 */       PlatformLogger platformLogger = Logging.getControlsLogger();
/* 191 */       if (platformLogger.isLoggable(PlatformLogger.Level.WARNING)) {
/* 192 */         platformLogger.warning("Can not retrieve property '" + getProperty() + "' in PropertyValueFactory: " + this + " with provided class type: " + paramS
/*     */             
/* 194 */             .getClass(), runtimeException);
/*     */       }
/* 196 */       this.propertyRef = null;
/*     */     } 
/*     */     
/* 199 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\cell\PropertyValueFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */