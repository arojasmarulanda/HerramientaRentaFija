/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.EnumConverter;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.ScrollBarSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrollBar
/*     */   extends Control
/*     */ {
/*     */   private DoubleProperty min;
/*     */   private DoubleProperty max;
/*     */   private DoubleProperty value;
/*     */   private ObjectProperty<Orientation> orientation;
/*     */   private DoubleProperty unitIncrement;
/*     */   private DoubleProperty blockIncrement;
/*     */   private DoubleProperty visibleAmount;
/*     */   private static final String DEFAULT_STYLE_CLASS = "scroll-bar";
/*     */   
/*     */   public ScrollBar() {
/*  90 */     setWidth(20.0D);
/*  91 */     setHeight(100.0D);
/*  92 */     getStyleClass().setAll(new String[] { "scroll-bar" });
/*  93 */     setAccessibleRole(AccessibleRole.SCROLL_BAR);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     ((StyleableProperty<Boolean>)focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
/*     */ 
/*     */     
/* 101 */     pseudoClassStateChanged(HORIZONTAL_PSEUDOCLASS_STATE, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMin(double paramDouble) {
/* 115 */     minProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getMin() {
/* 119 */     return (this.min == null) ? 0.0D : this.min.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty minProperty() {
/* 123 */     if (this.min == null) {
/* 124 */       this.min = new SimpleDoubleProperty(this, "min");
/*     */     }
/* 126 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMax(double paramDouble) {
/* 134 */     maxProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getMax() {
/* 138 */     return (this.max == null) ? 100.0D : this.max.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty maxProperty() {
/* 142 */     if (this.max == null) {
/* 143 */       this.max = new SimpleDoubleProperty(this, "max", 100.0D);
/*     */     }
/* 145 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setValue(double paramDouble) {
/* 153 */     valueProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getValue() {
/* 157 */     return (this.value == null) ? 0.0D : this.value.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty valueProperty() {
/* 161 */     if (this.value == null) {
/* 162 */       this.value = new SimpleDoubleProperty(this, "value");
/*     */     }
/* 164 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOrientation(Orientation paramOrientation) {
/* 172 */     orientationProperty().set(paramOrientation);
/*     */   }
/*     */   
/*     */   public final Orientation getOrientation() {
/* 176 */     return (this.orientation == null) ? Orientation.HORIZONTAL : this.orientation.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<Orientation> orientationProperty() {
/* 180 */     if (this.orientation == null) {
/* 181 */       this.orientation = new StyleableObjectProperty<Orientation>(Orientation.HORIZONTAL) {
/*     */           protected void invalidated() {
/* 183 */             boolean bool = (get() == Orientation.VERTICAL) ? true : false;
/* 184 */             ScrollBar.this.pseudoClassStateChanged(ScrollBar.VERTICAL_PSEUDOCLASS_STATE, bool);
/* 185 */             ScrollBar.this.pseudoClassStateChanged(ScrollBar.HORIZONTAL_PSEUDOCLASS_STATE, !bool);
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<ScrollBar, Orientation> getCssMetaData() {
/* 190 */             return ScrollBar.StyleableProperties.ORIENTATION;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 195 */             return ScrollBar.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 200 */             return "orientation";
/*     */           }
/*     */         };
/*     */     }
/* 204 */     return this.orientation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setUnitIncrement(double paramDouble) {
/* 213 */     unitIncrementProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getUnitIncrement() {
/* 217 */     return (this.unitIncrement == null) ? 1.0D : this.unitIncrement.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty unitIncrementProperty() {
/* 221 */     if (this.unitIncrement == null) {
/* 222 */       this.unitIncrement = new StyleableDoubleProperty(1.0D)
/*     */         {
/*     */           public CssMetaData<ScrollBar, Number> getCssMetaData()
/*     */           {
/* 226 */             return ScrollBar.StyleableProperties.UNIT_INCREMENT;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 231 */             return ScrollBar.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 236 */             return "unitIncrement";
/*     */           }
/*     */         };
/*     */     }
/* 240 */     return this.unitIncrement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBlockIncrement(double paramDouble) {
/* 248 */     blockIncrementProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getBlockIncrement() {
/* 252 */     return (this.blockIncrement == null) ? 10.0D : this.blockIncrement.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty blockIncrementProperty() {
/* 256 */     if (this.blockIncrement == null) {
/* 257 */       this.blockIncrement = new StyleableDoubleProperty(10.0D)
/*     */         {
/*     */           public CssMetaData<ScrollBar, Number> getCssMetaData()
/*     */           {
/* 261 */             return ScrollBar.StyleableProperties.BLOCK_INCREMENT;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 266 */             return ScrollBar.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 271 */             return "blockIncrement";
/*     */           }
/*     */         };
/*     */     }
/* 275 */     return this.blockIncrement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setVisibleAmount(double paramDouble) {
/* 284 */     visibleAmountProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getVisibleAmount() {
/* 288 */     return (this.visibleAmount == null) ? 15.0D : this.visibleAmount.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty visibleAmountProperty() {
/* 292 */     if (this.visibleAmount == null) {
/* 293 */       this.visibleAmount = new SimpleDoubleProperty(this, "visibleAmount");
/*     */     }
/* 295 */     return this.visibleAmount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustValue(double paramDouble) {
/* 322 */     double d = (getMax() - getMin()) * Utils.clamp(0.0D, paramDouble, 1.0D) + getMin();
/*     */     
/* 324 */     if (Double.compare(d, getValue()) != 0) {
/* 325 */       double d1; if (d > getValue()) {
/* 326 */         d1 = getValue() + getBlockIncrement();
/*     */       } else {
/*     */         
/* 329 */         d1 = getValue() - getBlockIncrement();
/*     */       } 
/*     */       
/* 332 */       boolean bool = (paramDouble > (getValue() - getMin()) / (getMax() - getMin())) ? true : false;
/* 333 */       if (bool && d1 > d) d1 = d; 
/* 334 */       if (!bool && d1 < d) d1 = d; 
/* 335 */       setValue(Utils.clamp(getMin(), d1, getMax()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void increment() {
/* 344 */     setValue(Utils.clamp(getMin(), getValue() + getUnitIncrement(), getMax()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decrement() {
/* 352 */     setValue(Utils.clamp(getMin(), getValue() - getUnitIncrement(), getMax()));
/*     */   }
/*     */   
/*     */   private void blockIncrement() {
/* 356 */     adjustValue(getValue() + getBlockIncrement());
/*     */   }
/*     */   
/*     */   private void blockDecrement() {
/* 360 */     adjustValue(getValue() - getBlockIncrement());
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 365 */     return (Skin<?>)new ScrollBarSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 383 */     private static final CssMetaData<ScrollBar, Orientation> ORIENTATION = new CssMetaData<ScrollBar, Orientation>("-fx-orientation", (StyleConverter)new EnumConverter(Orientation.class), Orientation.HORIZONTAL)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Orientation getInitialValue(ScrollBar param2ScrollBar)
/*     */         {
/* 391 */           return param2ScrollBar.getOrientation();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isSettable(ScrollBar param2ScrollBar) {
/* 396 */           return (param2ScrollBar.orientation == null || !param2ScrollBar.orientation.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Orientation> getStyleableProperty(ScrollBar param2ScrollBar) {
/* 401 */           return (StyleableProperty<Orientation>)param2ScrollBar.orientationProperty();
/*     */         }
/*     */       };
/*     */     
/* 405 */     private static final CssMetaData<ScrollBar, Number> UNIT_INCREMENT = new CssMetaData<ScrollBar, Number>("-fx-unit-increment", 
/*     */         
/* 407 */         SizeConverter.getInstance(), Double.valueOf(1.0D))
/*     */       {
/*     */         public boolean isSettable(ScrollBar param2ScrollBar)
/*     */         {
/* 411 */           return (param2ScrollBar.unitIncrement == null || !param2ScrollBar.unitIncrement.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(ScrollBar param2ScrollBar) {
/* 416 */           return (StyleableProperty<Number>)param2ScrollBar.unitIncrementProperty();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 421 */     private static final CssMetaData<ScrollBar, Number> BLOCK_INCREMENT = new CssMetaData<ScrollBar, Number>("-fx-block-increment", 
/*     */         
/* 423 */         SizeConverter.getInstance(), Double.valueOf(10.0D))
/*     */       {
/*     */         public boolean isSettable(ScrollBar param2ScrollBar)
/*     */         {
/* 427 */           return (param2ScrollBar.blockIncrement == null || !param2ScrollBar.blockIncrement.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(ScrollBar param2ScrollBar) {
/* 432 */           return (StyleableProperty<Number>)param2ScrollBar.blockIncrementProperty();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 440 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 441 */       arrayList.add(ORIENTATION);
/* 442 */       arrayList.add(UNIT_INCREMENT);
/* 443 */       arrayList.add(BLOCK_INCREMENT);
/* 444 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 454 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 463 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 470 */   private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 476 */   private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean getInitialFocusTraversable() {
/* 487 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 501 */     switch (paramAccessibleAttribute) { case INCREMENT:
/* 502 */         return Double.valueOf(getValue());
/* 503 */       case DECREMENT: return Double.valueOf(getMax());
/* 504 */       case BLOCK_INCREMENT: return Double.valueOf(getMin());
/* 505 */       case BLOCK_DECREMENT: return getOrientation(); }
/* 506 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     Double double_;
/* 513 */     switch (paramAccessibleAction) { case INCREMENT:
/* 514 */         increment(); return;
/* 515 */       case DECREMENT: decrement(); return;
/* 516 */       case BLOCK_INCREMENT: blockIncrement(); return;
/* 517 */       case BLOCK_DECREMENT: blockDecrement(); return;
/*     */       case SET_VALUE:
/* 519 */         double_ = (Double)paramVarArgs[0];
/* 520 */         if (double_ != null) setValue(double_.doubleValue()); 
/*     */         return; }
/*     */     
/* 523 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ScrollBar.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */