/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerWrapper;
/*     */ import javafx.css.PseudoClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IndexedCell<T>
/*     */   extends Cell<T>
/*     */ {
/*     */   private ReadOnlyIntegerWrapper index;
/*     */   private static final String DEFAULT_STYLE_CLASS = "indexed-cell";
/*     */   
/*     */   public IndexedCell() {
/*  76 */     this.index = new ReadOnlyIntegerWrapper(this, "index", -1) {
/*     */         protected void invalidated() {
/*  78 */           boolean bool = (get() % 2 == 0) ? true : false;
/*  79 */           IndexedCell.this.pseudoClassStateChanged(IndexedCell.PSEUDO_CLASS_EVEN, bool);
/*  80 */           IndexedCell.this.pseudoClassStateChanged(IndexedCell.PSEUDO_CLASS_ODD, !bool);
/*     */         }
/*     */       };
/*     */     getStyleClass().addAll(new String[] { "indexed-cell" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getIndex() {
/*  90 */     return this.index.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ReadOnlyIntegerProperty indexProperty() {
/* 101 */     return this.index.getReadOnlyProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateIndex(int paramInt) {
/* 118 */     int i = this.index.get();
/* 119 */     this.index.set(paramInt);
/* 120 */     indexChanged(i, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void indexChanged(int paramInt1, int paramInt2) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   private static final PseudoClass PSEUDO_CLASS_ODD = PseudoClass.getPseudoClass("odd");
/* 142 */   private static final PseudoClass PSEUDO_CLASS_EVEN = PseudoClass.getPseudoClass("even");
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\IndexedCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */