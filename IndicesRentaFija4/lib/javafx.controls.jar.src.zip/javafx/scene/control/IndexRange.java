/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.NamedArg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IndexRange
/*     */ {
/*     */   private int start;
/*     */   private int end;
/*     */   public static final String VALUE_DELIMITER = ",";
/*     */   
/*     */   public IndexRange(@NamedArg("start") int paramInt1, @NamedArg("end") int paramInt2) {
/*  52 */     if (paramInt2 < paramInt1) {
/*  53 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  56 */     this.start = paramInt1;
/*  57 */     this.end = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndexRange(@NamedArg("range") IndexRange paramIndexRange) {
/*  68 */     this.start = paramIndexRange.start;
/*  69 */     this.end = paramIndexRange.end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStart() {
/*  77 */     return this.start;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEnd() {
/*  85 */     return this.end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/*  93 */     return this.end - this.start;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 103 */     if (paramObject == this) return true; 
/* 104 */     if (paramObject instanceof IndexRange) {
/* 105 */       IndexRange indexRange = (IndexRange)paramObject;
/* 106 */       return (this.start == indexRange.start && this.end == indexRange.end);
/*     */     } 
/*     */ 
/*     */     
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 119 */     return 31 * this.start + this.end;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 128 */     return "" + this.start + ", " + this.start;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IndexRange normalize(int paramInt1, int paramInt2) {
/* 141 */     return new IndexRange(Math.min(paramInt1, paramInt2), Math.max(paramInt1, paramInt2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IndexRange valueOf(String paramString) {
/* 154 */     if (paramString == null) {
/* 155 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 158 */     String[] arrayOfString = paramString.split(",");
/* 159 */     if (arrayOfString.length != 2) {
/* 160 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 165 */     int i = Integer.parseInt(arrayOfString[0].trim());
/* 166 */     int j = Integer.parseInt(arrayOfString[1].trim());
/*     */     
/* 168 */     return normalize(i, j);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\IndexRange.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */