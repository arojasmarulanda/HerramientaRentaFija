/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyDoubleProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Parent;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.stage.Modality;
/*     */ import javafx.stage.Stage;
/*     */ import javafx.stage.StageStyle;
/*     */ import javafx.stage.Window;
/*     */ import javafx.stage.WindowEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HeavyweightDialog
/*     */   extends FXDialog
/*     */ {
/*  52 */   final Stage stage = new Stage() {
/*     */       public void centerOnScreen() {
/*  54 */         Window window = HeavyweightDialog.this.getOwner();
/*  55 */         if (window != null) {
/*  56 */           HeavyweightDialog.this.positionStage();
/*     */         }
/*  58 */         else if (getWidth() > 0.0D && getHeight() > 0.0D) {
/*  59 */           super.centerOnScreen();
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private Scene scene;
/*     */   
/*  67 */   private final Parent DUMMY_ROOT = new Region();
/*     */   
/*     */   private final Dialog<?> dialog;
/*     */   private DialogPane dialogPane;
/*  71 */   private double prefX = Double.NaN;
/*  72 */   private double prefY = Double.NaN;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HeavyweightDialog(Dialog<?> paramDialog) {
/*  83 */     this.dialog = paramDialog;
/*     */     
/*  85 */     this.stage.setResizable(false);
/*     */     
/*  87 */     this.stage.setOnCloseRequest(paramWindowEvent -> {
/*     */           if (requestPermissionToClose(paramDialog)) {
/*     */             paramDialog.close();
/*     */           } else {
/*     */             paramWindowEvent.consume();
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/*  96 */     this.stage.addEventHandler(KeyEvent.KEY_PRESSED, paramKeyEvent -> {
/*     */           if (paramKeyEvent.getCode() == KeyCode.ESCAPE && !paramKeyEvent.isConsumed() && requestPermissionToClose(paramDialog)) {
/*     */             paramDialog.close();
/*     */             paramKeyEvent.consume();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initStyle(StageStyle paramStageStyle) {
/* 115 */     this.stage.initStyle(paramStageStyle);
/*     */   }
/*     */   
/*     */   StageStyle getStyle() {
/* 119 */     return this.stage.getStyle();
/*     */   }
/*     */   
/*     */   public void initOwner(Window paramWindow) {
/* 123 */     updateStageBindings(this.stage.getOwner(), paramWindow);
/* 124 */     this.stage.initOwner(paramWindow);
/*     */   }
/*     */   
/*     */   public Window getOwner() {
/* 128 */     return this.stage.getOwner();
/*     */   }
/*     */   
/*     */   public void initModality(Modality paramModality) {
/* 132 */     this.stage.initModality((paramModality == null) ? Modality.APPLICATION_MODAL : paramModality);
/*     */   }
/*     */   
/*     */   public Modality getModality() {
/* 136 */     return this.stage.getModality();
/*     */   }
/*     */   
/*     */   public void setDialogPane(DialogPane paramDialogPane) {
/* 140 */     this.dialogPane = paramDialogPane;
/*     */     
/* 142 */     if (this.scene == null) {
/* 143 */       this.scene = new Scene(paramDialogPane);
/* 144 */       this.stage.setScene(this.scene);
/*     */     } else {
/* 146 */       this.scene.setRoot(paramDialogPane);
/*     */     } 
/*     */     
/* 149 */     paramDialogPane.autosize();
/* 150 */     this.stage.sizeToScene();
/*     */   }
/*     */   
/*     */   public void show() {
/* 154 */     this.scene.setRoot(this.dialogPane);
/* 155 */     this.stage.centerOnScreen();
/* 156 */     this.stage.show();
/*     */   }
/*     */   
/*     */   public void showAndWait() {
/* 160 */     this.scene.setRoot(this.dialogPane);
/* 161 */     this.stage.centerOnScreen();
/* 162 */     this.stage.showAndWait();
/*     */   }
/*     */   
/*     */   public void close() {
/* 166 */     if (this.stage.isShowing()) {
/* 167 */       this.stage.hide();
/*     */     }
/*     */ 
/*     */     
/* 171 */     if (this.scene != null) {
/* 172 */       this.scene.setRoot(this.DUMMY_ROOT);
/*     */     }
/*     */   }
/*     */   
/*     */   public ReadOnlyBooleanProperty showingProperty() {
/* 177 */     return this.stage.showingProperty();
/*     */   }
/*     */   
/*     */   public Window getWindow() {
/* 181 */     return this.stage;
/*     */   }
/*     */   
/*     */   public Node getRoot() {
/* 185 */     return this.stage.getScene().getRoot();
/*     */   }
/*     */ 
/*     */   
/*     */   public double getX() {
/* 190 */     return this.stage.getX();
/*     */   }
/*     */   
/*     */   public void setX(double paramDouble) {
/* 194 */     this.stage.setX(paramDouble);
/*     */   }
/*     */   
/*     */   public ReadOnlyDoubleProperty xProperty() {
/* 198 */     return this.stage.xProperty();
/*     */   }
/*     */ 
/*     */   
/*     */   public double getY() {
/* 203 */     return this.stage.getY();
/*     */   }
/*     */   
/*     */   public void setY(double paramDouble) {
/* 207 */     this.stage.setY(paramDouble);
/*     */   }
/*     */   
/*     */   public ReadOnlyDoubleProperty yProperty() {
/* 211 */     return this.stage.yProperty();
/*     */   }
/*     */   
/*     */   ReadOnlyDoubleProperty heightProperty() {
/* 215 */     return this.stage.heightProperty();
/*     */   }
/*     */   
/*     */   void setHeight(double paramDouble) {
/* 219 */     this.stage.setHeight(paramDouble);
/*     */   }
/*     */   
/*     */   double getSceneHeight() {
/* 223 */     return (this.scene == null) ? 0.0D : this.scene.getHeight();
/*     */   }
/*     */   
/*     */   ReadOnlyDoubleProperty widthProperty() {
/* 227 */     return this.stage.widthProperty();
/*     */   }
/*     */   
/*     */   void setWidth(double paramDouble) {
/* 231 */     this.stage.setWidth(paramDouble);
/*     */   }
/*     */   
/*     */   BooleanProperty resizableProperty() {
/* 235 */     return this.stage.resizableProperty();
/*     */   }
/*     */   
/*     */   StringProperty titleProperty() {
/* 239 */     return this.stage.titleProperty();
/*     */   }
/*     */   
/*     */   ReadOnlyBooleanProperty focusedProperty() {
/* 243 */     return this.stage.focusedProperty();
/*     */   }
/*     */   
/*     */   public void sizeToScene() {
/* 247 */     this.stage.sizeToScene();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void positionStage() {
/* 259 */     double d1 = getX();
/* 260 */     double d2 = getY();
/*     */ 
/*     */     
/* 263 */     if (!Double.isNaN(d1) && !Double.isNaN(d2) && 
/* 264 */       Double.compare(d1, this.prefX) != 0 && Double.compare(d2, this.prefY) != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 271 */       setX(d1);
/* 272 */       setY(d2);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 278 */     this.dialogPane.applyCss();
/* 279 */     this.dialogPane.layout();
/*     */     
/* 281 */     Window window = getOwner();
/* 282 */     Scene scene = window.getScene();
/*     */ 
/*     */ 
/*     */     
/* 286 */     double d3 = scene.getY();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 292 */     double d4 = this.dialogPane.prefWidth(-1.0D);
/* 293 */     double d5 = this.dialogPane.prefHeight(d4);
/*     */ 
/*     */ 
/*     */     
/* 297 */     d1 = window.getX() + scene.getWidth() / 2.0D - d4 / 2.0D;
/* 298 */     d2 = window.getY() + d3 / 2.0D + scene.getHeight() / 2.0D - d5 / 2.0D;
/*     */     
/* 300 */     this.prefX = d1;
/* 301 */     this.prefY = d2;
/*     */     
/* 303 */     setX(d1);
/* 304 */     setY(d2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateStageBindings(Window paramWindow1, Window paramWindow2) {
/* 310 */     Scene scene = this.stage.getScene();
/*     */     
/* 312 */     if (paramWindow1 != null && paramWindow1 instanceof Stage) {
/* 313 */       Stage stage = (Stage)paramWindow1;
/* 314 */       Bindings.unbindContent(this.stage.getIcons(), stage.getIcons());
/*     */       
/* 316 */       Scene scene1 = stage.getScene();
/* 317 */       if (this.scene != null && scene != null) {
/* 318 */         Bindings.unbindContent(scene.getStylesheets(), scene1.getStylesheets());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 323 */     if (paramWindow2 instanceof Stage) {
/* 324 */       Stage stage = (Stage)paramWindow2;
/* 325 */       Bindings.bindContent(this.stage.getIcons(), stage.getIcons());
/*     */       
/* 327 */       Scene scene1 = stage.getScene();
/* 328 */       if (this.scene != null && scene != null)
/* 329 */         Bindings.bindContent(scene.getStylesheets(), scene1.getStylesheets()); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\HeavyweightDialog.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */