/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.LabelSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Label
/*     */   extends Labeled
/*     */ {
/*     */   private ChangeListener<Boolean> mnemonicStateListener;
/*     */   private ObjectProperty<Node> labelFor;
/*     */   
/*     */   public Label() {
/* 104 */     this.mnemonicStateListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> NodeHelper.showMnemonicsProperty(this).setValue(paramBoolean2)); initialize(); } public Label(String paramString) { super(paramString); this.mnemonicStateListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> NodeHelper.showMnemonicsProperty(this).setValue(paramBoolean2)); initialize(); } public Label(String paramString, Node paramNode) { super(paramString, paramNode); this.mnemonicStateListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> NodeHelper.showMnemonicsProperty(this).setValue(paramBoolean2));
/*     */     initialize(); }
/*     */ 
/*     */   
/*     */   private void initialize() {
/*     */     getStyleClass().setAll(new String[] { "label" });
/*     */     setAccessibleRole(AccessibleRole.TEXT);
/*     */     ((StyleableProperty<Boolean>)focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
/*     */   }
/*     */   
/*     */   public ObjectProperty<Node> labelForProperty() {
/* 115 */     if (this.labelFor == null) {
/* 116 */       this.labelFor = new ObjectPropertyBase<Node>() {
/* 117 */           Node oldValue = null;
/*     */           protected void invalidated() {
/* 119 */             if (this.oldValue != null) {
/* 120 */               NodeHelper.getNodeAccessor().setLabeledBy(this.oldValue, null);
/* 121 */               NodeHelper.showMnemonicsProperty(this.oldValue).removeListener(Label.this.mnemonicStateListener);
/*     */             } 
/* 123 */             Node node = get();
/* 124 */             if (node != null) {
/* 125 */               NodeHelper.getNodeAccessor().setLabeledBy(node, Label.this);
/* 126 */               NodeHelper.showMnemonicsProperty(node).addListener(Label.this.mnemonicStateListener);
/* 127 */               NodeHelper.setShowMnemonics(Label.this, NodeHelper.isShowMnemonics(node));
/*     */             } else {
/* 129 */               NodeHelper.setShowMnemonics(Label.this, false);
/*     */             } 
/* 131 */             this.oldValue = node;
/*     */           }
/*     */           
/*     */           public Object getBean() {
/* 135 */             return Label.this;
/*     */           }
/*     */           
/*     */           public String getName() {
/* 139 */             return "labelFor";
/*     */           }
/*     */         };
/*     */     }
/*     */     
/* 144 */     return this.labelFor;
/*     */   }
/*     */   
/*     */   public final void setLabelFor(Node paramNode) {
/* 148 */     labelForProperty().setValue(paramNode); } public final Node getLabelFor() {
/* 149 */     return (this.labelFor == null) ? null : this.labelFor.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 159 */     return (Skin<?>)new LabelSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean getInitialFocusTraversable() {
/* 177 */     return Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Label.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */