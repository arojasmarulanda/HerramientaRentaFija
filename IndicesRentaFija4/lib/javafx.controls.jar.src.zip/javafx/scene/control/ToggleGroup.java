/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.collections.TrackableObservableList;
/*     */ import com.sun.javafx.collections.VetoableListDecorator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToggleGroup
/*     */ {
/*     */   public final ObservableList<Toggle> getToggles() {
/*  68 */     return this.toggles;
/*     */   }
/*     */   
/*  71 */   private final ObservableList<Toggle> toggles = new VetoableListDecorator<Toggle>(new TrackableObservableList<Toggle>() {
/*     */         protected void onChanged(ListChangeListener.Change<Toggle> param1Change) {
/*  73 */           while (param1Change.next()) {
/*     */ 
/*     */ 
/*     */             
/*  77 */             for (Toggle toggle : param1Change.getRemoved()) {
/*  78 */               if (toggle.isSelected()) {
/*  79 */                 ToggleGroup.this.selectToggle(null);
/*     */               }
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  86 */             for (Toggle toggle : param1Change.getAddedSubList()) {
/*  87 */               if (!ToggleGroup.this.equals(toggle.getToggleGroup())) {
/*  88 */                 if (toggle.getToggleGroup() != null) {
/*  89 */                   toggle.getToggleGroup().getToggles().remove(toggle);
/*     */                 }
/*  91 */                 toggle.setToggleGroup(ToggleGroup.this);
/*     */               } 
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  98 */             for (Toggle toggle : param1Change.getAddedSubList()) {
/*  99 */               if (toggle.isSelected()) {
/* 100 */                 ToggleGroup.this.selectToggle(toggle);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         }
/*     */       })
/*     */     {
/*     */       protected void onProposedChange(List<Toggle> param1List, int... param1VarArgs) {
/* 108 */         for (Toggle toggle : param1List) {
/* 109 */           if (param1VarArgs[0] == 0 && param1VarArgs[1] == size()) {
/*     */             break;
/*     */           }
/*     */           
/* 113 */           if (ToggleGroup.this.toggles.contains(toggle)) {
/* 114 */             throw new IllegalArgumentException("Duplicate toggles are not allow in a ToggleGroup.");
/*     */           }
/*     */         } 
/*     */       }
/*     */     };
/*     */   
/* 120 */   private final ReadOnlyObjectWrapper<Toggle> selectedToggle = new ReadOnlyObjectWrapper<Toggle>()
/*     */     {
/*     */       
/*     */       public void set(Toggle param1Toggle)
/*     */       {
/* 125 */         if (isBound()) {
/* 126 */           throw new RuntimeException("A bound value cannot be set.");
/*     */         }
/* 128 */         Toggle toggle = get();
/* 129 */         if (toggle == param1Toggle) {
/*     */           return;
/*     */         }
/* 132 */         if (ToggleGroup.this.setSelected(param1Toggle, true) || (param1Toggle != null && param1Toggle
/* 133 */           .getToggleGroup() == ToggleGroup.this) || param1Toggle == null) {
/*     */           
/* 135 */           if (toggle == null || toggle.getToggleGroup() == ToggleGroup.this || !toggle.isSelected()) {
/* 136 */             ToggleGroup.this.setSelected(toggle, false);
/*     */           }
/* 138 */           super.set(param1Toggle);
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void selectToggle(Toggle paramToggle) {
/* 150 */     this.selectedToggle.set(paramToggle);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Toggle getSelectedToggle() {
/* 156 */     return this.selectedToggle.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ReadOnlyObjectProperty<Toggle> selectedToggleProperty() {
/* 162 */     return this.selectedToggle.getReadOnlyProperty();
/*     */   }
/*     */   private boolean setSelected(Toggle paramToggle, boolean paramBoolean) {
/* 165 */     if (paramToggle != null && paramToggle
/* 166 */       .getToggleGroup() == this && 
/* 167 */       !paramToggle.selectedProperty().isBound()) {
/* 168 */       paramToggle.setSelected(paramBoolean);
/* 169 */       return true;
/*     */     } 
/* 171 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   final void clearSelectedToggle() {
/* 176 */     if (!((Toggle)this.selectedToggle.getValue()).isSelected()) {
/* 177 */       for (Toggle toggle : getToggles()) {
/* 178 */         if (toggle.isSelected()) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */     }
/* 183 */     this.selectedToggle.set((Toggle)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   private static final Object USER_DATA_KEY = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObservableMap<Object, Object> properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableMap<Object, Object> getProperties() {
/* 206 */     if (this.properties == null) {
/* 207 */       this.properties = FXCollections.observableMap(new HashMap<>());
/*     */     }
/* 209 */     return this.properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProperties() {
/* 219 */     return (this.properties != null && !this.properties.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserData(Object paramObject) {
/* 234 */     getProperties().put(USER_DATA_KEY, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getUserData() {
/* 247 */     return getProperties().get(USER_DATA_KEY);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ToggleGroup.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */