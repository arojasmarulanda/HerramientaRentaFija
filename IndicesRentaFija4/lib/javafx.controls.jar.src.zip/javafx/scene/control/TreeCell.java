/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.beans.value.WeakChangeListener;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.TreeCellSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeCell<T>
/*     */   extends IndexedCell<T>
/*     */ {
/*     */   private final ListChangeListener<Integer> selectedListener;
/*     */   private final ChangeListener<MultipleSelectionModel<TreeItem<T>>> selectionModelPropertyListener;
/*     */   private final InvalidationListener focusedListener;
/*     */   private final ChangeListener<FocusModel<TreeItem<T>>> focusModelPropertyListener;
/*     */   private final InvalidationListener editingListener;
/*     */   private final InvalidationListener leafListener;
/*     */   private boolean oldIsExpanded;
/*     */   private final InvalidationListener treeItemExpandedInvalidationListener;
/*     */   private final InvalidationListener rootPropertyListener;
/*     */   private final WeakListChangeListener<Integer> weakSelectedListener;
/*     */   private final WeakChangeListener<MultipleSelectionModel<TreeItem<T>>> weakSelectionModelPropertyListener;
/*     */   private final WeakInvalidationListener weakFocusedListener;
/*     */   private final WeakChangeListener<FocusModel<TreeItem<T>>> weakFocusModelPropertyListener;
/*     */   private final WeakInvalidationListener weakEditingListener;
/*     */   private final WeakInvalidationListener weakLeafListener;
/*     */   private final WeakInvalidationListener weakTreeItemExpandedInvalidationListener;
/*     */   private final WeakInvalidationListener weakRootPropertyListener;
/*     */   private ReadOnlyObjectWrapper<TreeItem<T>> treeItem;
/*     */   private ObjectProperty<Node> disclosureNode;
/*     */   private ReadOnlyObjectWrapper<TreeView<T>> treeView;
/*     */   private boolean isFirstRun;
/*     */   private boolean updateEditingIndex;
/*     */   private static final String DEFAULT_STYLE_CLASS = "tree-cell";
/*     */   
/*     */   public TreeCell() {
/*  99 */     this.selectedListener = (paramChange -> updateSelection());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     this.selectionModelPropertyListener = (ChangeListener)new ChangeListener<MultipleSelectionModel<TreeItem<MultipleSelectionModel<TreeItem<T>>>>>()
/*     */       {
/*     */         public void changed(ObservableValue<? extends MultipleSelectionModel<TreeItem<T>>> param1ObservableValue, MultipleSelectionModel<TreeItem<T>> param1MultipleSelectionModel1, MultipleSelectionModel<TreeItem<T>> param1MultipleSelectionModel2)
/*     */         {
/* 111 */           if (param1MultipleSelectionModel1 != null) {
/* 112 */             param1MultipleSelectionModel1.getSelectedIndices().removeListener(TreeCell.this.weakSelectedListener);
/*     */           }
/* 114 */           if (param1MultipleSelectionModel2 != null) {
/* 115 */             param1MultipleSelectionModel2.getSelectedIndices().addListener(TreeCell.this.weakSelectedListener);
/*     */           }
/* 117 */           TreeCell.this.updateSelection();
/*     */         }
/*     */       };
/*     */     
/* 121 */     this.focusedListener = (paramObservable -> updateFocus());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     this.focusModelPropertyListener = (ChangeListener)new ChangeListener<FocusModel<TreeItem<FocusModel<TreeItem<T>>>>>()
/*     */       {
/*     */         public void changed(ObservableValue<? extends FocusModel<TreeItem<T>>> param1ObservableValue, FocusModel<TreeItem<T>> param1FocusModel1, FocusModel<TreeItem<T>> param1FocusModel2)
/*     */         {
/* 133 */           if (param1FocusModel1 != null) {
/* 134 */             param1FocusModel1.focusedIndexProperty().removeListener(TreeCell.this.weakFocusedListener);
/*     */           }
/* 136 */           if (param1FocusModel2 != null) {
/* 137 */             param1FocusModel2.focusedIndexProperty().addListener(TreeCell.this.weakFocusedListener);
/*     */           }
/* 139 */           TreeCell.this.updateFocus();
/*     */         }
/*     */       };
/*     */     
/* 143 */     this.editingListener = (paramObservable -> updateEditing());
/*     */ 
/*     */ 
/*     */     
/* 147 */     this.leafListener = new InvalidationListener()
/*     */       {
/*     */         public void invalidated(Observable param1Observable)
/*     */         {
/* 151 */           TreeItem treeItem = TreeCell.this.getTreeItem();
/* 152 */           if (treeItem != null) {
/* 153 */             TreeCell.this.requestLayout();
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */     
/* 160 */     this.treeItemExpandedInvalidationListener = new InvalidationListener() {
/*     */         public void invalidated(Observable param1Observable) {
/* 162 */           boolean bool = ((BooleanProperty)param1Observable).get();
/* 163 */           TreeCell.this.pseudoClassStateChanged(TreeCell.EXPANDED_PSEUDOCLASS_STATE, bool);
/* 164 */           TreeCell.this.pseudoClassStateChanged(TreeCell.COLLAPSED_PSEUDOCLASS_STATE, !bool);
/* 165 */           if (bool != TreeCell.this.oldIsExpanded) {
/* 166 */             TreeCell.this.notifyAccessibleAttributeChanged(AccessibleAttribute.EXPANDED);
/*     */           }
/* 168 */           TreeCell.this.oldIsExpanded = bool;
/*     */         }
/*     */       };
/*     */     
/* 172 */     this.rootPropertyListener = (paramObservable -> updateItem(-1));
/*     */ 
/*     */ 
/*     */     
/* 176 */     this.weakSelectedListener = new WeakListChangeListener<>(this.selectedListener);
/* 177 */     this.weakSelectionModelPropertyListener = new WeakChangeListener<>(this.selectionModelPropertyListener);
/* 178 */     this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
/* 179 */     this.weakFocusModelPropertyListener = new WeakChangeListener<>(this.focusModelPropertyListener);
/* 180 */     this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
/* 181 */     this.weakLeafListener = new WeakInvalidationListener(this.leafListener);
/* 182 */     this.weakTreeItemExpandedInvalidationListener = new WeakInvalidationListener(this.treeItemExpandedInvalidationListener);
/*     */     
/* 184 */     this.weakRootPropertyListener = new WeakInvalidationListener(this.rootPropertyListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     this.treeItem = (ReadOnlyObjectWrapper)new ReadOnlyObjectWrapper<TreeItem<TreeItem<T>>>(this, "treeItem")
/*     */       {
/*     */         
/* 199 */         TreeItem<T> oldValue = null;
/*     */         
/*     */         protected void invalidated() {
/* 202 */           if (this.oldValue != null) {
/* 203 */             this.oldValue.expandedProperty().removeListener(TreeCell.this.weakTreeItemExpandedInvalidationListener);
/*     */           }
/*     */           
/* 206 */           this.oldValue = get();
/*     */           
/* 208 */           if (this.oldValue != null) {
/* 209 */             TreeCell.this.oldIsExpanded = this.oldValue.isExpanded();
/* 210 */             this.oldValue.expandedProperty().addListener(TreeCell.this.weakTreeItemExpandedInvalidationListener);
/*     */             
/* 212 */             TreeCell.this.weakTreeItemExpandedInvalidationListener.invalidated(this.oldValue.expandedProperty());
/*     */           } 
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 237 */     this.disclosureNode = new SimpleObjectProperty<>(this, "disclosureNode");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     this.treeView = (ReadOnlyObjectWrapper)new ReadOnlyObjectWrapper<TreeView<TreeView<T>>>()
/*     */       {
/*     */         private WeakReference<TreeView<T>> weakTreeViewRef;
/*     */ 
/*     */         
/*     */         protected void invalidated() {
/* 271 */           if (this.weakTreeViewRef != null) {
/* 272 */             TreeView treeView1 = this.weakTreeViewRef.get();
/* 273 */             if (treeView1 != null) {
/*     */               
/* 275 */               MultipleSelectionModel multipleSelectionModel = treeView1.getSelectionModel();
/* 276 */               if (multipleSelectionModel != null) {
/* 277 */                 multipleSelectionModel.getSelectedIndices().removeListener(TreeCell.this.weakSelectedListener);
/*     */               }
/*     */               
/* 280 */               FocusModel focusModel = treeView1.getFocusModel();
/* 281 */               if (focusModel != null) {
/* 282 */                 focusModel.focusedIndexProperty().removeListener(TreeCell.this.weakFocusedListener);
/*     */               }
/*     */               
/* 285 */               treeView1.editingItemProperty().removeListener(TreeCell.this.weakEditingListener);
/* 286 */               treeView1.focusModelProperty().removeListener(TreeCell.this.weakFocusModelPropertyListener);
/* 287 */               treeView1.selectionModelProperty().removeListener(TreeCell.this.weakSelectionModelPropertyListener);
/* 288 */               treeView1.rootProperty().removeListener(TreeCell.this.weakRootPropertyListener);
/*     */             } 
/*     */             
/* 291 */             this.weakTreeViewRef = null;
/*     */           } 
/*     */           
/* 294 */           TreeView<T> treeView = get();
/* 295 */           if (treeView != null) {
/* 296 */             MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = treeView.getSelectionModel();
/* 297 */             if (multipleSelectionModel != null)
/*     */             {
/*     */               
/* 300 */               multipleSelectionModel.getSelectedIndices().addListener(TreeCell.this.weakSelectedListener);
/*     */             }
/*     */             
/* 303 */             FocusModel<TreeItem<T>> focusModel = treeView.getFocusModel();
/* 304 */             if (focusModel != null)
/*     */             {
/* 306 */               focusModel.focusedIndexProperty().addListener(TreeCell.this.weakFocusedListener);
/*     */             }
/*     */             
/* 309 */             treeView.editingItemProperty().addListener(TreeCell.this.weakEditingListener);
/* 310 */             treeView.focusModelProperty().addListener(TreeCell.this.weakFocusModelPropertyListener);
/* 311 */             treeView.selectionModelProperty().addListener(TreeCell.this.weakSelectionModelPropertyListener);
/* 312 */             treeView.rootProperty().addListener(TreeCell.this.weakRootPropertyListener);
/*     */             
/* 314 */             this.weakTreeViewRef = new WeakReference<>(treeView);
/*     */           } 
/*     */           
/* 317 */           TreeCell.this.updateItem(-1);
/* 318 */           TreeCell.this.requestLayout();
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 323 */           return TreeCell.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 328 */           return "treeView";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 487 */     this.isFirstRun = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 567 */     this.updateEditingIndex = true; getStyleClass().addAll(new String[] { "tree-cell" }); setAccessibleRole(AccessibleRole.TREE_ITEM);
/*     */   } private void setTreeItem(TreeItem<T> paramTreeItem) { this.treeItem.set(paramTreeItem); } public final TreeItem<T> getTreeItem() { return this.treeItem.get(); } public final ReadOnlyObjectProperty<TreeItem<T>> treeItemProperty() { return this.treeItem.getReadOnlyProperty(); } public final void setDisclosureNode(Node paramNode) { disclosureNodeProperty().set(paramNode); } public final Node getDisclosureNode() { return this.disclosureNode.get(); } public final ObjectProperty<Node> disclosureNodeProperty() { return this.disclosureNode; } private void setTreeView(TreeView<T> paramTreeView) { this.treeView.set(paramTreeView); } public final TreeView<T> getTreeView() { return this.treeView.get(); }
/* 569 */   private void updateEditing() { int i = getIndex();
/* 570 */     TreeView<T> treeView = getTreeView();
/* 571 */     TreeItem<T> treeItem1 = getTreeItem();
/* 572 */     TreeItem<T> treeItem2 = (treeView == null) ? null : treeView.getEditingItem();
/* 573 */     boolean bool1 = isEditing();
/*     */     
/* 575 */     if (i == -1 || treeView == null || treeItem1 == null)
/*     */       return; 
/* 577 */     boolean bool2 = treeItem1.equals(treeItem2);
/*     */ 
/*     */ 
/*     */     
/* 581 */     if (bool2 && !bool1) {
/* 582 */       startEdit();
/* 583 */     } else if (!bool2 && bool1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 590 */       this.updateEditingIndex = false;
/* 591 */       cancelEdit();
/* 592 */       this.updateEditingIndex = true;
/*     */     }  } public final ReadOnlyObjectProperty<TreeView<T>> treeViewProperty() { return this.treeView.getReadOnlyProperty(); }
/*     */   public void startEdit() { if (isEditing())
/*     */       return;  TreeView<T> treeView = getTreeView(); if (!isEditable() || (treeView != null && !treeView.isEditable()))
/*     */       return;  updateItem(-1); super.startEdit(); if (treeView != null) {
/*     */       treeView.fireEvent(new TreeView.EditEvent<>(treeView, (EventType)TreeView.editStartEvent(), getTreeItem(), getItem(), null)); treeView.requestFocus();
/*     */     }  }
/*     */   public void commitEdit(T paramT) { if (!isEditing())
/*     */       return;  TreeItem<T> treeItem = getTreeItem(); TreeView<T> treeView = getTreeView(); if (treeView != null)
/*     */       treeView.fireEvent(new TreeView.EditEvent<>(treeView, (EventType)TreeView.editCommitEvent(), treeItem, getItem(), paramT));  super.commitEdit(paramT); if (treeItem != null) {
/*     */       treeItem.setValue(paramT); updateTreeItem(treeItem); updateItem(paramT, false);
/*     */     }  if (treeView != null) {
/*     */       treeView.edit((TreeItem<T>)null); ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(treeView);
/*     */     }  }
/*     */   public void cancelEdit() { if (!isEditing())
/*     */       return;  TreeView<T> treeView = getTreeView();
/*     */     super.cancelEdit();
/*     */     if (treeView != null) {
/*     */       if (this.updateEditingIndex)
/*     */         treeView.edit((TreeItem<T>)null); 
/*     */       ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(treeView);
/*     */       treeView.fireEvent(new TreeView.EditEvent<>(treeView, (EventType)TreeView.editCancelEvent(), getTreeItem(), getItem(), null));
/*     */     }  }
/* 615 */   public final void updateTreeView(TreeView<T> paramTreeView) { setTreeView(paramTreeView); }
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/*     */     return (Skin<?>)new TreeCellSkin(this);
/*     */   }
/*     */   void indexChanged(int paramInt1, int paramInt2) {
/*     */     super.indexChanged(paramInt1, paramInt2);
/*     */     if (!isEditing() || paramInt2 != paramInt1) {
/*     */       updateItem(paramInt1);
/*     */       updateSelection();
/*     */       updateFocus();
/*     */     } 
/*     */   }
/* 628 */   public final void updateTreeItem(TreeItem<T> paramTreeItem) { TreeItem<T> treeItem = getTreeItem();
/* 629 */     if (treeItem != null) {
/* 630 */       treeItem.leafProperty().removeListener(this.weakLeafListener);
/*     */     }
/* 632 */     setTreeItem(paramTreeItem);
/* 633 */     if (paramTreeItem != null)
/* 634 */       paramTreeItem.leafProperty().addListener(this.weakLeafListener);  }
/*     */   private void updateItem(int paramInt) { TreeView<T> treeView = getTreeView(); if (treeView == null)
/*     */       return;  int i = getIndex(); boolean bool = (i >= 0 && i < treeView.getExpandedItemCount()) ? true : false; boolean bool1 = isEmpty(); TreeItem<T> treeItem = getTreeItem(); if (bool) {
/*     */       TreeItem<T> treeItem1 = treeView.getTreeItem(i);
/*     */       T t1 = (treeItem1 == null) ? null : treeItem1.getValue();
/*     */       T t2 = (treeItem == null) ? null : treeItem.getValue();
/*     */       if (paramInt != i || isItemChanged(t2, t1)) {
/*     */         updateTreeItem(treeItem1);
/*     */         updateItem(t1, false);
/*     */       } 
/*     */     } else if ((!bool1 && treeItem != null) || this.isFirstRun) {
/*     */       updateTreeItem((TreeItem<T>)null);
/*     */       updateItem((T)null, true);
/*     */       this.isFirstRun = false;
/* 648 */     }  } private static final PseudoClass EXPANDED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("expanded");
/* 649 */   private void updateSelection() { if (isEmpty()) return;  if (getIndex() == -1 || getTreeView() == null) return;  MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getTreeView().getSelectionModel(); if (multipleSelectionModel == null) { updateSelected(false); return; }  boolean bool = multipleSelectionModel.isSelected(getIndex()); if (isSelected() == bool) return;  updateSelected(bool); } private void updateFocus() { if (getIndex() == -1 || getTreeView() == null) return;  FocusModel<TreeItem<T>> focusModel = getTreeView().getFocusModel(); if (focusModel == null) { setFocused(false); return; }  setFocused(focusModel.isFocused(getIndex())); } private static final PseudoClass COLLAPSED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("collapsed");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*     */     TreeItem<T> treeItem2;
/*     */     int i, j;
/*     */     TreeItem<T> treeItem3;
/*     */     int k;
/* 661 */     TreeItem<T> treeItem1 = getTreeItem();
/* 662 */     TreeView<T> treeView = getTreeView();
/* 663 */     switch (paramAccessibleAttribute) {
/*     */       case EXPAND:
/* 665 */         if (treeView == null) return null; 
/* 666 */         if (treeItem1 == null) return null; 
/* 667 */         treeItem2 = treeItem1.getParent();
/* 668 */         if (treeItem2 == null) return null; 
/* 669 */         j = treeView.getRow(treeItem2);
/* 670 */         return treeView.queryAccessibleAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { Integer.valueOf(j) });
/*     */       
/*     */       case COLLAPSE:
/* 673 */         if (treeItem1 == null) return Integer.valueOf(0); 
/* 674 */         if (!treeItem1.isExpanded()) return Integer.valueOf(0); 
/* 675 */         return Integer.valueOf(treeItem1.getChildren().size());
/*     */       
/*     */       case REQUEST_FOCUS:
/* 678 */         if (treeItem1 == null) return null; 
/* 679 */         if (!treeItem1.isExpanded()) return null; 
/* 680 */         i = ((Integer)paramVarArgs[0]).intValue();
/* 681 */         if (i >= treeItem1.getChildren().size()) return null; 
/* 682 */         treeItem3 = treeItem1.getChildren().get(i);
/* 683 */         if (treeItem3 == null) return null; 
/* 684 */         k = treeView.getRow(treeItem3);
/* 685 */         return treeView.queryAccessibleAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { Integer.valueOf(k) });
/*     */       case null:
/* 687 */         return Boolean.valueOf((treeItem1 == null) ? true : treeItem1.isLeaf());
/* 688 */       case null: return Boolean.valueOf((treeItem1 == null) ? false : treeItem1.isExpanded());
/* 689 */       case null: return Integer.valueOf(getIndex());
/* 690 */       case null: return Boolean.valueOf(isSelected());
/*     */       case null:
/* 692 */         return Integer.valueOf((treeView == null) ? 0 : treeView.getTreeItemLevel(treeItem1));
/*     */     } 
/* 694 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     TreeItem<T> treeItem;
/*     */     TreeView<T> treeView;
/* 701 */     switch (paramAccessibleAction) {
/*     */       case EXPAND:
/* 703 */         treeItem = getTreeItem();
/* 704 */         if (treeItem != null) treeItem.setExpanded(true);
/*     */         
/*     */         return;
/*     */       case COLLAPSE:
/* 708 */         treeItem = getTreeItem();
/* 709 */         if (treeItem != null) treeItem.setExpanded(false);
/*     */         
/*     */         return;
/*     */       case REQUEST_FOCUS:
/* 713 */         treeView = getTreeView();
/* 714 */         if (treeView != null) {
/* 715 */           FocusModel<TreeItem<T>> focusModel = treeView.getFocusModel();
/* 716 */           if (focusModel != null) {
/* 717 */             focusModel.focus(getIndex());
/*     */           }
/*     */         } 
/*     */         return;
/*     */     } 
/* 722 */     super.executeAccessibleAction(paramAccessibleAction, new Object[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TreeCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */