/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.DoublePropertyBase;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.ProgressIndicatorSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProgressIndicator
/*     */   extends Control
/*     */ {
/*     */   public static final double INDETERMINATE_PROGRESS = -1.0D;
/*     */   private ReadOnlyBooleanWrapper indeterminate;
/*     */   private DoubleProperty progress;
/*     */   private static final String DEFAULT_STYLE_CLASS = "progress-indicator";
/*     */   
/*     */   public ProgressIndicator() {
/*  88 */     this(-1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProgressIndicator(double paramDouble) {
/* 100 */     ((StyleableProperty<Boolean>)focusTraversableProperty()).applyStyle(null, Boolean.FALSE);
/* 101 */     setProgress(paramDouble);
/* 102 */     getStyleClass().setAll(new String[] { "progress-indicator" });
/* 103 */     setAccessibleRole(AccessibleRole.PROGRESS_INDICATOR);
/*     */ 
/*     */     
/* 106 */     int i = Double.compare(-1.0D, paramDouble);
/* 107 */     pseudoClassStateChanged(PSEUDO_CLASS_INDETERMINATE, (i == 0));
/* 108 */     pseudoClassStateChanged(PSEUDO_CLASS_DETERMINATE, (i != 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setIndeterminate(boolean paramBoolean) {
/* 123 */     indeterminatePropertyImpl().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isIndeterminate() {
/* 127 */     return (this.indeterminate == null) ? true : this.indeterminate.get();
/*     */   }
/*     */   
/*     */   public final ReadOnlyBooleanProperty indeterminateProperty() {
/* 131 */     return indeterminatePropertyImpl().getReadOnlyProperty();
/*     */   }
/*     */   
/*     */   private ReadOnlyBooleanWrapper indeterminatePropertyImpl() {
/* 135 */     if (this.indeterminate == null) {
/* 136 */       this.indeterminate = new ReadOnlyBooleanWrapper(true) {
/*     */           protected void invalidated() {
/* 138 */             boolean bool = get();
/* 139 */             ProgressIndicator.this.pseudoClassStateChanged(ProgressIndicator.PSEUDO_CLASS_INDETERMINATE, bool);
/* 140 */             ProgressIndicator.this.pseudoClassStateChanged(ProgressIndicator.PSEUDO_CLASS_DETERMINATE, !bool);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 145 */             return ProgressIndicator.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 150 */             return "indeterminate";
/*     */           }
/*     */         };
/*     */     }
/* 154 */     return this.indeterminate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setProgress(double paramDouble) {
/* 164 */     progressProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getProgress() {
/* 168 */     return (this.progress == null) ? -1.0D : this.progress.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty progressProperty() {
/* 172 */     if (this.progress == null) {
/* 173 */       this.progress = new DoublePropertyBase(-1.0D) {
/*     */           protected void invalidated() {
/* 175 */             ProgressIndicator.this.setIndeterminate((ProgressIndicator.this.getProgress() < 0.0D));
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 180 */             return ProgressIndicator.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 185 */             return "progress";
/*     */           }
/*     */         };
/*     */     }
/* 189 */     return this.progress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 200 */     return (Skin<?>)new ProgressIndicatorSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 222 */   private static final PseudoClass PSEUDO_CLASS_DETERMINATE = PseudoClass.getPseudoClass("determinate");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 229 */   private static final PseudoClass PSEUDO_CLASS_INDETERMINATE = PseudoClass.getPseudoClass("indeterminate");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean getInitialFocusTraversable() {
/* 240 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 253 */     switch (paramAccessibleAttribute) { case VALUE:
/* 254 */         return Double.valueOf(getProgress());
/* 255 */       case MAX_VALUE: return Double.valueOf(1.0D);
/* 256 */       case MIN_VALUE: return Double.valueOf(0.0D);
/* 257 */       case INDETERMINATE: return Boolean.valueOf(isIndeterminate()); }
/* 258 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ProgressIndicator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */