/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckMenuItem
/*     */   extends MenuItem
/*     */ {
/*     */   private BooleanProperty selected;
/*     */   private static final String DEFAULT_STYLE_CLASS = "check-menu-item";
/*     */   private static final String STYLE_CLASS_SELECTED = "selected";
/*     */   
/*     */   public CheckMenuItem() {
/*  97 */     this(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckMenuItem(String paramString) {
/* 105 */     this(paramString, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckMenuItem(String paramString, Node paramNode) {
/* 115 */     super(paramString, paramNode);
/* 116 */     getStyleClass().add("check-menu-item");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSelected(boolean paramBoolean) {
/* 135 */     selectedProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isSelected() {
/* 139 */     return (this.selected == null) ? false : this.selected.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty selectedProperty() {
/* 143 */     if (this.selected == null) {
/* 144 */       this.selected = new BooleanPropertyBase()
/*     */         {
/*     */           protected void invalidated() {
/* 147 */             get();
/*     */ 
/*     */             
/* 150 */             if (CheckMenuItem.this.isSelected()) {
/* 151 */               CheckMenuItem.this.getStyleClass().add("selected");
/*     */             } else {
/* 153 */               CheckMenuItem.this.getStyleClass().remove("selected");
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 159 */             return CheckMenuItem.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 164 */             return "selected";
/*     */           }
/*     */         };
/*     */     }
/* 168 */     return this.selected;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\CheckMenuItem.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */