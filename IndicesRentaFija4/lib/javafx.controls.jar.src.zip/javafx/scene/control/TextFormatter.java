/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.control.FormatterAccessor;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.UnaryOperator;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextFormatter<V>
/*     */ {
/*     */   private final StringConverter<V> valueConverter;
/*     */   private final UnaryOperator<Change> filter;
/*     */   private Consumer<TextFormatter<?>> textUpdater;
/*     */   
/*  65 */   public static final StringConverter<String> IDENTITY_STRING_CONVERTER = new StringConverter<String>()
/*     */     {
/*     */       public String toString(String param1String) {
/*  68 */         return (param1String == null) ? "" : param1String;
/*     */       }
/*     */       
/*     */       public String fromString(String param1String) {
/*  72 */         return param1String;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private final ObjectProperty<V> value;
/*     */ 
/*     */   
/*     */   public TextFormatter(@NamedArg("filter") UnaryOperator<Change> paramUnaryOperator) {
/*  82 */     this(null, null, paramUnaryOperator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextFormatter(@NamedArg("valueConverter") StringConverter<V> paramStringConverter, @NamedArg("defaultValue") V paramV, @NamedArg("filter") UnaryOperator<Change> paramUnaryOperator) {
/* 147 */     this.value = new ObjectPropertyBase<V>()
/*     */       {
/*     */         public Object getBean()
/*     */         {
/* 151 */           return TextFormatter.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 156 */           return "value";
/*     */         }
/*     */         
/*     */         protected void invalidated()
/*     */         {
/* 161 */           if (TextFormatter.this.valueConverter == null && get() != null) {
/* 162 */             if (isBound()) {
/* 163 */               unbind();
/*     */             }
/* 165 */             throw new IllegalStateException("Value changes are not supported when valueConverter is not set");
/*     */           } 
/* 167 */           TextFormatter.this.updateText(); } };
/*     */     this.filter = paramUnaryOperator;
/*     */     this.valueConverter = paramStringConverter;
/*     */     setValue(paramV);
/*     */   }
/* 172 */   public TextFormatter(@NamedArg("valueConverter") StringConverter<V> paramStringConverter, @NamedArg("defaultValue") V paramV) { this(paramStringConverter, paramV, null); } public TextFormatter(@NamedArg("valueConverter") StringConverter<V> paramStringConverter) { this(paramStringConverter, null, null); } public final ObjectProperty<V> valueProperty() { return this.value; }
/*     */   public final StringConverter<V> getValueConverter() { return this.valueConverter; }
/*     */   public final UnaryOperator<Change> getFilter() { return this.filter; } public final void setValue(V paramV) {
/* 175 */     if (this.valueConverter == null && paramV != null) {
/* 176 */       throw new IllegalStateException("Value changes are not supported when valueConverter is not set");
/*     */     }
/* 178 */     this.value.set(paramV);
/*     */   }
/*     */   public final V getValue() {
/* 181 */     return this.value.get();
/*     */   }
/*     */   
/*     */   private void updateText() {
/* 185 */     if (this.textUpdater != null) {
/* 186 */       this.textUpdater.accept(this);
/*     */     }
/*     */   }
/*     */   
/*     */   void bindToControl(Consumer<TextFormatter<?>> paramConsumer) {
/* 191 */     if (this.textUpdater != null) {
/* 192 */       throw new IllegalStateException("Formatter is already used in other control");
/*     */     }
/* 194 */     this.textUpdater = paramConsumer;
/*     */   }
/*     */   
/*     */   void unbindFromControl() {
/* 198 */     this.textUpdater = null;
/*     */   }
/*     */   
/*     */   void updateValue(String paramString) {
/* 202 */     if (!this.value.isBound()) {
/*     */       try {
/* 204 */         V v = this.valueConverter.fromString(paramString);
/* 205 */         setValue(v);
/* 206 */       } catch (Exception exception) {
/* 207 */         updateText();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Change
/*     */     implements Cloneable
/*     */   {
/*     */     private final FormatterAccessor accessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Control control;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int start;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int end;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String text;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int anchor;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int caret;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Change(Control param1Control, FormatterAccessor param1FormatterAccessor, int param1Int1, int param1Int2) {
/* 258 */       this(param1Control, param1FormatterAccessor, param1Int2, param1Int2, "", param1Int1, param1Int2);
/*     */     }
/*     */     
/*     */     Change(Control param1Control, FormatterAccessor param1FormatterAccessor, int param1Int1, int param1Int2, String param1String) {
/* 262 */       this(param1Control, param1FormatterAccessor, param1Int1, param1Int2, param1String, param1Int1 + param1String.length(), param1Int1 + param1String.length());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Change(Control param1Control, FormatterAccessor param1FormatterAccessor, int param1Int1, int param1Int2, String param1String, int param1Int3, int param1Int4) {
/* 269 */       this.control = param1Control;
/* 270 */       this.accessor = param1FormatterAccessor;
/* 271 */       this.start = param1Int1;
/* 272 */       this.end = param1Int2;
/* 273 */       this.text = param1String;
/* 274 */       this.anchor = param1Int3;
/* 275 */       this.caret = param1Int4;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Control getControl() {
/* 282 */       return this.control;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getRangeStart() {
/* 291 */       return this.start;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getRangeEnd() {
/* 300 */       return this.end;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setRange(int param1Int1, int param1Int2) {
/* 311 */       int i = this.accessor.getTextLength();
/* 312 */       if (param1Int1 < 0 || param1Int1 > i || param1Int2 < 0 || param1Int2 > i) {
/* 313 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 315 */       this.start = param1Int1;
/* 316 */       this.end = param1Int2;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCaretPosition() {
/* 326 */       return this.caret;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getAnchor() {
/* 334 */       return this.anchor;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getControlCaretPosition() {
/* 340 */       return this.accessor.getCaret();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getControlAnchor() {
/* 346 */       return this.accessor.getAnchor();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void selectRange(int param1Int1, int param1Int2) {
/* 358 */       if (param1Int1 < 0 || param1Int1 > this.accessor.getTextLength() - this.end - this.start + this.text.length() || param1Int2 < 0 || param1Int2 > this.accessor
/* 359 */         .getTextLength() - this.end - this.start + this.text.length()) {
/* 360 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 362 */       this.anchor = param1Int1;
/* 363 */       this.caret = param1Int2;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final IndexRange getSelection() {
/* 372 */       return IndexRange.normalize(this.anchor, this.caret);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setAnchor(int param1Int) {
/* 385 */       if (param1Int < 0 || param1Int > this.accessor.getTextLength() - this.end - this.start + this.text.length()) {
/* 386 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 388 */       this.anchor = param1Int;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setCaretPosition(int param1Int) {
/* 400 */       if (param1Int < 0 || param1Int > this.accessor.getTextLength() - this.end - this.start + this.text.length()) {
/* 401 */         throw new IndexOutOfBoundsException();
/*     */       }
/* 403 */       this.caret = param1Int;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getText() {
/* 414 */       return this.text;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setText(String param1String) {
/* 424 */       if (param1String == null) throw new NullPointerException(); 
/* 425 */       this.text = param1String;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getControlText() {
/* 434 */       return this.accessor.getText(0, this.accessor.getTextLength());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getControlNewText() {
/* 452 */       return this.accessor.getText(0, this.start) + this.accessor.getText(0, this.start) + this.text;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isAdded() {
/* 464 */       return !this.text.isEmpty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isDeleted() {
/* 475 */       return (this.start != this.end);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isReplaced() {
/* 487 */       return (isAdded() && isDeleted());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isContentChange() {
/* 496 */       return (isAdded() || isDeleted());
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 501 */       StringBuilder stringBuilder = new StringBuilder("TextInputControl.Change [");
/* 502 */       if (isReplaced()) {
/* 503 */         stringBuilder.append(" replaced \"").append(this.accessor.getText(this.start, this.end)).append("\" with \"").append(this.text)
/* 504 */           .append("\" at (").append(this.start).append(", ").append(this.end).append(")");
/* 505 */       } else if (isDeleted()) {
/* 506 */         stringBuilder.append(" deleted \"").append(this.accessor.getText(this.start, this.end))
/* 507 */           .append("\" at (").append(this.start).append(", ").append(this.end).append(")");
/* 508 */       } else if (isAdded()) {
/* 509 */         stringBuilder.append(" added \"").append(this.text).append("\" at ").append(this.start);
/*     */       } 
/* 511 */       if (isAdded() || isDeleted()) {
/* 512 */         stringBuilder.append("; ");
/*     */       } else {
/* 514 */         stringBuilder.append(" ");
/*     */       } 
/* 516 */       stringBuilder.append("new selection (anchor, caret): [").append(this.anchor).append(", ").append(this.caret).append("]");
/* 517 */       stringBuilder.append(" ]");
/* 518 */       return stringBuilder.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public Change clone() {
/*     */       try {
/* 524 */         return (Change)super.clone();
/* 525 */       } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */         
/* 527 */         throw new RuntimeException(cloneNotSupportedException);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TextFormatter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */