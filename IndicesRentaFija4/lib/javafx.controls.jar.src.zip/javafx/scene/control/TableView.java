/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.collections.MappingChange;
/*      */ import com.sun.javafx.collections.NonIterableChange;
/*      */ import com.sun.javafx.logging.PlatformLogger;
/*      */ import com.sun.javafx.scene.control.Logging;
/*      */ import com.sun.javafx.scene.control.ReadOnlyUnbackedObservableList;
/*      */ import com.sun.javafx.scene.control.SelectedCellsMap;
/*      */ import com.sun.javafx.scene.control.SelectedItemsReadOnlyObservableList;
/*      */ import com.sun.javafx.scene.control.TableColumnComparatorBase;
/*      */ import com.sun.javafx.scene.control.behavior.TableCellBehavior;
/*      */ import com.sun.javafx.scene.control.behavior.TableCellBehaviorBase;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.WeakHashMap;
/*      */ import javafx.beans.DefaultProperty;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.WeakInvalidationListener;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.Property;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.MapChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.collections.WeakListChangeListener;
/*      */ import javafx.collections.transformation.SortedList;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.EventType;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.skin.TableViewSkin;
/*      */ import javafx.util.Callback;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @DefaultProperty("items")
/*      */ public class TableView<S>
/*      */   extends Control
/*      */ {
/*      */   static final String SET_CONTENT_WIDTH = "TableView.contentWidth";
/*      */   
/*  390 */   public static final Callback<ResizeFeatures, Boolean> UNCONSTRAINED_RESIZE_POLICY = new Callback<ResizeFeatures, Boolean>() {
/*      */       public String toString() {
/*  392 */         return "unconstrained-resize";
/*      */       }
/*      */       
/*      */       public Boolean call(TableView.ResizeFeatures param1ResizeFeatures) {
/*  396 */         double d = TableUtil.resize(param1ResizeFeatures.getColumn(), param1ResizeFeatures.getDelta().doubleValue());
/*  397 */         return Boolean.valueOf((Double.compare(d, 0.0D) == 0));
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  413 */   public static final Callback<ResizeFeatures, Boolean> CONSTRAINED_RESIZE_POLICY = new Callback<ResizeFeatures, Boolean>()
/*      */     {
/*      */       private boolean isFirstRun = true;
/*      */       
/*      */       public String toString() {
/*  418 */         return "constrained-resize";
/*      */       }
/*      */       
/*      */       public Boolean call(TableView.ResizeFeatures param1ResizeFeatures) {
/*  422 */         TableView tableView = param1ResizeFeatures.getTable();
/*  423 */         ObservableList<? extends TableColumnBase<?, ?>> observableList = tableView.getVisibleLeafColumns();
/*  424 */         Boolean bool = Boolean.valueOf(TableUtil.constrainedResize(param1ResizeFeatures, this.isFirstRun, tableView
/*      */               
/*  426 */               .contentWidth, observableList));
/*      */         
/*  428 */         this.isFirstRun = !this.isFirstRun ? false : (!bool.booleanValue());
/*  429 */         return bool;
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  442 */   public static final Callback<TableView, Boolean> DEFAULT_SORT_POLICY = new Callback<TableView, Boolean>() {
/*      */       public Boolean call(TableView param1TableView) {
/*      */         try {
/*  445 */           ObservableList<?> observableList = param1TableView.getItems();
/*  446 */           if (observableList instanceof SortedList) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  453 */             SortedList sortedList = (SortedList)observableList;
/*      */             
/*  455 */             boolean bool = sortedList.comparatorProperty().isEqualTo(param1TableView.comparatorProperty()).get();
/*      */             
/*  457 */             if (!bool)
/*      */             {
/*      */               
/*  460 */               if (Logging.getControlsLogger().isLoggable(PlatformLogger.Level.INFO)) {
/*  461 */                 String str = "TableView items list is a SortedList, but the SortedList comparator should be bound to the TableView comparator for sorting to be enabled (e.g. sortedList.comparatorProperty().bind(tableView.comparatorProperty());).";
/*      */ 
/*      */ 
/*      */                 
/*  465 */                 Logging.getControlsLogger().info(str);
/*      */               } 
/*      */             }
/*  468 */             return Boolean.valueOf(bool);
/*      */           } 
/*  470 */           if (observableList == null || observableList.isEmpty())
/*      */           {
/*  472 */             return Boolean.valueOf(true);
/*      */           }
/*      */           
/*  475 */           Comparator<?> comparator = param1TableView.getComparator();
/*  476 */           if (comparator == null) {
/*  477 */             return Boolean.valueOf(true);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  482 */           FXCollections.sort(observableList, comparator);
/*  483 */           return Boolean.valueOf(true);
/*      */         }
/*  485 */         catch (UnsupportedOperationException unsupportedOperationException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  495 */           return Boolean.valueOf(false);
/*      */         } 
/*      */       }
/*      */     };
/*      */   private final ObservableList<TableColumn<S, ?>> columns; private final ObservableList<TableColumn<S, ?>> visibleLeafColumns; private final ObservableList<TableColumn<S, ?>> unmodifiableVisibleLeafColumns; private ObservableList<TableColumn<S, ?>> sortOrder; private double contentWidth; private boolean isInited; private final ListChangeListener<TableColumn<S, ?>> columnsObserver; private final WeakHashMap<TableColumn<S, ?>, Integer> lastKnownColumnIndex; private final InvalidationListener columnVisibleObserver; private final InvalidationListener columnSortableObserver; private final InvalidationListener columnSortTypeObserver; private final InvalidationListener columnComparatorObserver; private final InvalidationListener cellSelectionModelInvalidationListener; private final WeakInvalidationListener weakColumnVisibleObserver; private final WeakInvalidationListener weakColumnSortableObserver; private final WeakInvalidationListener weakColumnSortTypeObserver; private final WeakInvalidationListener weakColumnComparatorObserver; private final WeakListChangeListener<TableColumn<S, ?>> weakColumnsObserver; private final WeakInvalidationListener weakCellSelectionModelInvalidationListener; private ObjectProperty<ObservableList<S>> items; private BooleanProperty tableMenuButtonVisible; private ObjectProperty<Callback<ResizeFeatures, Boolean>> columnResizePolicy; private ObjectProperty<Callback<TableView<S>, TableRow<S>>> rowFactory; private ObjectProperty<Node> placeholder; private ObjectProperty<TableViewSelectionModel<S>> selectionModel;
/*      */   private ObjectProperty<TableViewFocusModel<S>> focusModel;
/*      */   private BooleanProperty editable;
/*      */   private DoubleProperty fixedCellSize;
/*      */   private ReadOnlyObjectWrapper<TablePosition<S, ?>> editingCell;
/*      */   private ReadOnlyObjectWrapper<Comparator<S>> comparator;
/*      */   private ObjectProperty<Callback<TableView<S>, Boolean>> sortPolicy;
/*      */   private ObjectProperty<EventHandler<SortEvent<TableView<S>>>> onSort;
/*      */   private ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollTo;
/*      */   private ObjectProperty<EventHandler<ScrollToEvent<TableColumn<S, ?>>>> onScrollToColumn;
/*      */   private boolean sortLock;
/*      */   private TableUtil.SortEventType lastSortEventType;
/*      */   private Object[] lastSortEventSupportInfo;
/*      */   private static final String DEFAULT_STYLE_CLASS = "table-view";
/*      */   
/*      */   public TableView() {
/*  515 */     this(FXCollections.observableArrayList());
/*      */   } public final ObjectProperty<ObservableList<S>> itemsProperty() {
/*      */     return this.items;
/*      */   } public final void setItems(ObservableList<S> paramObservableList) {
/*      */     itemsProperty().set(paramObservableList);
/*      */   } public final ObservableList<S> getItems() {
/*      */     return this.items.get();
/*      */   } public final BooleanProperty tableMenuButtonVisibleProperty() {
/*      */     if (this.tableMenuButtonVisible == null)
/*      */       this.tableMenuButtonVisible = new SimpleBooleanProperty(this, "tableMenuButtonVisible"); 
/*      */     return this.tableMenuButtonVisible;
/*      */   } public final void setTableMenuButtonVisible(boolean paramBoolean) {
/*      */     tableMenuButtonVisibleProperty().set(paramBoolean);
/*      */   } public final boolean isTableMenuButtonVisible() {
/*      */     return (this.tableMenuButtonVisible == null) ? false : this.tableMenuButtonVisible.get();
/*      */   }
/*      */   public final void setColumnResizePolicy(Callback<ResizeFeatures, Boolean> paramCallback) {
/*      */     columnResizePolicyProperty().set(paramCallback);
/*      */   }
/*      */   public final Callback<ResizeFeatures, Boolean> getColumnResizePolicy() {
/*      */     return (this.columnResizePolicy == null) ? UNCONSTRAINED_RESIZE_POLICY : this.columnResizePolicy.get();
/*      */   }
/*      */   public final ObjectProperty<Callback<ResizeFeatures, Boolean>> columnResizePolicyProperty() {
/*      */     if (this.columnResizePolicy == null)
/*      */       this.columnResizePolicy = new SimpleObjectProperty<Callback<ResizeFeatures, Boolean>>(this, "columnResizePolicy", UNCONSTRAINED_RESIZE_POLICY) { private Callback<TableView.ResizeFeatures, Boolean> oldPolicy;
/*      */           protected void invalidated() {
/*      */             if (TableView.this.isInited) {
/*      */               get().call(new TableView.ResizeFeatures(TableView.this, null, Double.valueOf(0.0D)));
/*      */               if (this.oldPolicy != null) {
/*      */                 PseudoClass pseudoClass = PseudoClass.getPseudoClass(this.oldPolicy.toString());
/*      */                 TableView.this.pseudoClassStateChanged(pseudoClass, false);
/*      */               } 
/*      */               if (get() != null) {
/*      */                 PseudoClass pseudoClass = PseudoClass.getPseudoClass(get().toString());
/*      */                 TableView.this.pseudoClassStateChanged(pseudoClass, true);
/*      */               } 
/*      */               this.oldPolicy = get();
/*      */             } 
/*      */           } }
/*      */         ; 
/*      */     return this.columnResizePolicy;
/*      */   }
/*      */   public final ObjectProperty<Callback<TableView<S>, TableRow<S>>> rowFactoryProperty() {
/*      */     if (this.rowFactory == null)
/*      */       this.rowFactory = new SimpleObjectProperty<>(this, "rowFactory"); 
/*      */     return this.rowFactory;
/*      */   }
/*      */   public final void setRowFactory(Callback<TableView<S>, TableRow<S>> paramCallback) {
/*      */     rowFactoryProperty().set(paramCallback);
/*      */   }
/*      */   public final Callback<TableView<S>, TableRow<S>> getRowFactory() {
/*      */     return (this.rowFactory == null) ? null : this.rowFactory.get();
/*      */   }
/*      */   public final ObjectProperty<Node> placeholderProperty() {
/*      */     if (this.placeholder == null)
/*      */       this.placeholder = new SimpleObjectProperty<>(this, "placeholder"); 
/*      */     return this.placeholder;
/*      */   }
/*      */   public final void setPlaceholder(Node paramNode) {
/*      */     placeholderProperty().set(paramNode);
/*      */   }
/*      */   public final Node getPlaceholder() {
/*      */     return (this.placeholder == null) ? null : this.placeholder.get();
/*      */   }
/*  579 */   public TableView(ObservableList<S> paramObservableList) { this.columns = FXCollections.observableArrayList();
/*      */ 
/*      */ 
/*      */     
/*  583 */     this.visibleLeafColumns = FXCollections.observableArrayList();
/*  584 */     this.unmodifiableVisibleLeafColumns = FXCollections.unmodifiableObservableList(this.visibleLeafColumns);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  590 */     this.sortOrder = FXCollections.observableArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  598 */     this.isInited = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  608 */     this.columnsObserver = new ListChangeListener<TableColumn<S, ?>>() {
/*      */         public void onChanged(ListChangeListener.Change<? extends TableColumn<S, ?>> param1Change) {
/*  610 */           ObservableList observableList = TableView.this.getColumns();
/*      */ 
/*      */           
/*  613 */           while (param1Change.next()) {
/*  614 */             if (param1Change.wasAdded()) {
/*  615 */               ArrayList<TableColumn> arrayList3 = new ArrayList();
/*  616 */               for (TableColumn<S, ?> tableColumn : param1Change.getAddedSubList()) {
/*  617 */                 if (tableColumn == null)
/*      */                   continue; 
/*  619 */                 byte b = 0;
/*  620 */                 for (TableColumn tableColumn1 : observableList) {
/*  621 */                   if (tableColumn == tableColumn1) {
/*  622 */                     b++;
/*      */                   }
/*      */                 } 
/*      */                 
/*  626 */                 if (b > 1) {
/*  627 */                   arrayList3.add(tableColumn);
/*      */                 }
/*      */               } 
/*      */               
/*  631 */               if (!arrayList3.isEmpty()) {
/*  632 */                 String str = "";
/*  633 */                 for (TableColumn tableColumn : arrayList3) {
/*  634 */                   str = str + "'" + str + "', ";
/*      */                 }
/*  636 */                 throw new IllegalStateException("Duplicate TableColumns detected in TableView columns list with titles " + str);
/*      */               } 
/*      */             } 
/*      */           } 
/*  640 */           param1Change.reset();
/*      */ 
/*      */ 
/*      */           
/*  644 */           ArrayList<TableColumn<S, ?>> arrayList = new ArrayList();
/*  645 */           while (param1Change.next()) {
/*  646 */             List<? extends TableColumn<S, ?>> list1 = param1Change.getRemoved();
/*  647 */             List<? extends TableColumn<S, ?>> list2 = param1Change.getAddedSubList();
/*      */             
/*  649 */             if (param1Change.wasRemoved()) {
/*  650 */               arrayList.addAll(list1);
/*  651 */               for (TableColumn<S, ?> tableColumn : list1) {
/*  652 */                 tableColumn.setTableView((TableView)null);
/*      */               }
/*      */             } 
/*      */             
/*  656 */             if (param1Change.wasAdded()) {
/*  657 */               arrayList.removeAll(list2);
/*  658 */               for (TableColumn<S, ?> tableColumn : list2) {
/*  659 */                 tableColumn.setTableView(TableView.this);
/*      */               }
/*      */             } 
/*      */ 
/*      */             
/*  664 */             TableUtil.removeColumnsListener((List)list1, TableView.this.weakColumnsObserver);
/*  665 */             TableUtil.addColumnsListener((List)list2, TableView.this.weakColumnsObserver);
/*      */             
/*  667 */             TableUtil.removeTableColumnListener(param1Change.getRemoved(), TableView.this
/*  668 */                 .weakColumnVisibleObserver, TableView.this
/*  669 */                 .weakColumnSortableObserver, TableView.this
/*  670 */                 .weakColumnSortTypeObserver, TableView.this
/*  671 */                 .weakColumnComparatorObserver);
/*  672 */             TableUtil.addTableColumnListener(param1Change.getAddedSubList(), TableView.this
/*  673 */                 .weakColumnVisibleObserver, TableView.this
/*  674 */                 .weakColumnSortableObserver, TableView.this
/*  675 */                 .weakColumnSortTypeObserver, TableView.this
/*  676 */                 .weakColumnComparatorObserver);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  681 */           TableView.this.updateVisibleLeafColumns();
/*      */           
/*  683 */           TableView.this.sortOrder.removeAll(arrayList);
/*      */ 
/*      */           
/*  686 */           TableView.TableViewFocusModel tableViewFocusModel = TableView.this.getFocusModel();
/*  687 */           TableView.TableViewSelectionModel tableViewSelectionModel = TableView.this.getSelectionModel();
/*  688 */           param1Change.reset();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  694 */           ArrayList arrayList1 = new ArrayList();
/*  695 */           ArrayList<?> arrayList2 = new ArrayList();
/*  696 */           while (param1Change.next()) {
/*  697 */             if (param1Change.wasRemoved()) {
/*  698 */               arrayList1.addAll(param1Change.getRemoved());
/*      */             }
/*  700 */             if (param1Change.wasAdded()) {
/*  701 */               arrayList2.addAll(param1Change.getAddedSubList());
/*      */             }
/*      */           } 
/*  704 */           arrayList1.removeAll(arrayList2);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  709 */           if (tableViewFocusModel != null) {
/*  710 */             TablePosition<S, T> tablePosition = tableViewFocusModel.getFocusedCell();
/*  711 */             boolean bool = false;
/*  712 */             for (TableColumn<S, T> tableColumn : (Iterable<TableColumn<S, T>>)arrayList1) {
/*  713 */               bool = (tablePosition != null && tablePosition.getTableColumn() == tableColumn) ? true : false;
/*  714 */               if (bool) {
/*      */                 break;
/*      */               }
/*      */             } 
/*      */             
/*  719 */             if (bool) {
/*  720 */               int i = ((Integer)TableView.this.lastKnownColumnIndex.getOrDefault(tablePosition.getTableColumn(), Integer.valueOf(0))).intValue();
/*      */ 
/*      */               
/*  723 */               boolean bool1 = (i == 0) ? false : Math.min(TableView.this.getVisibleLeafColumns().size() - 1, i - 1);
/*  724 */               tableViewFocusModel.focus(tablePosition.getRow(), TableView.this.getVisibleLeafColumn(bool1));
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  730 */           if (tableViewSelectionModel != null) {
/*  731 */             ArrayList<TablePosition> arrayList3 = new ArrayList<>(tableViewSelectionModel.getSelectedCells());
/*  732 */             for (TablePosition<S, T> tablePosition : arrayList3) {
/*  733 */               boolean bool = false;
/*  734 */               for (TableColumn<S, T> tableColumn : (Iterable<TableColumn<S, T>>)arrayList1) {
/*  735 */                 bool = (tablePosition != null && tablePosition.getTableColumn() == tableColumn) ? true : false;
/*  736 */                 if (bool)
/*      */                   break; 
/*      */               } 
/*  739 */               if (bool) {
/*      */ 
/*      */                 
/*  742 */                 int i = ((Integer)TableView.this.lastKnownColumnIndex.getOrDefault(tablePosition.getTableColumn(), Integer.valueOf(-1))).intValue();
/*  743 */                 if (i == -1)
/*      */                   continue; 
/*  745 */                 if (tableViewSelectionModel instanceof TableView.TableViewArrayListSelectionModel) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  755 */                   TablePosition<Object, Object> tablePosition1 = new TablePosition<>(TableView.this, tablePosition.getRow(), tablePosition.getTableColumn());
/*  756 */                   tablePosition1.fixedColumnIndex = i;
/*      */                   
/*  758 */                   ((TableView.TableViewArrayListSelectionModel)tableViewSelectionModel).clearSelection((TablePosition)tablePosition1); continue;
/*      */                 } 
/*  760 */                 tableViewSelectionModel.clearSelection(tablePosition.getRow(), tablePosition.getTableColumn());
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  768 */           TableView.this.lastKnownColumnIndex.clear();
/*  769 */           for (TableColumn tableColumn : TableView.this.getColumns()) {
/*  770 */             int i = TableView.this.getVisibleLeafIndex(tableColumn);
/*  771 */             if (i > -1) {
/*  772 */               TableView.this.lastKnownColumnIndex.put(tableColumn, Integer.valueOf(i));
/*      */             }
/*      */           } 
/*      */         }
/*      */       };
/*      */     
/*  778 */     this.lastKnownColumnIndex = new WeakHashMap<>();
/*      */     
/*  780 */     this.columnVisibleObserver = (paramObservable -> updateVisibleLeafColumns());
/*      */ 
/*      */ 
/*      */     
/*  784 */     this.columnSortableObserver = (paramObservable -> {
/*      */         Object object = ((Property)paramObservable).getBean();
/*      */         if (!getSortOrder().contains(object))
/*      */           return; 
/*      */         doSort(TableUtil.SortEventType.COLUMN_SORTABLE_CHANGE, new Object[] { object });
/*      */       });
/*  790 */     this.columnSortTypeObserver = (paramObservable -> {
/*      */         Object object = ((Property)paramObservable).getBean();
/*      */         if (!getSortOrder().contains(object))
/*      */           return; 
/*      */         doSort(TableUtil.SortEventType.COLUMN_SORT_TYPE_CHANGE, new Object[] { object });
/*      */       });
/*  796 */     this.columnComparatorObserver = (paramObservable -> {
/*      */         Object object = ((Property)paramObservable).getBean();
/*      */         if (!getSortOrder().contains(object)) {
/*      */           return;
/*      */         }
/*      */         doSort(TableUtil.SortEventType.COLUMN_COMPARATOR_CHANGE, new Object[] { object });
/*      */       });
/*  803 */     this.cellSelectionModelInvalidationListener = (paramObservable -> {
/*      */         boolean bool = ((BooleanProperty)paramObservable).get();
/*      */         
/*      */         pseudoClassStateChanged(PSEUDO_CLASS_CELL_SELECTION, bool);
/*      */         
/*      */         pseudoClassStateChanged(PSEUDO_CLASS_ROW_SELECTION, !bool);
/*      */       });
/*  810 */     this.weakColumnVisibleObserver = new WeakInvalidationListener(this.columnVisibleObserver);
/*      */ 
/*      */     
/*  813 */     this.weakColumnSortableObserver = new WeakInvalidationListener(this.columnSortableObserver);
/*      */ 
/*      */     
/*  816 */     this.weakColumnSortTypeObserver = new WeakInvalidationListener(this.columnSortTypeObserver);
/*      */ 
/*      */     
/*  819 */     this.weakColumnComparatorObserver = new WeakInvalidationListener(this.columnComparatorObserver);
/*      */ 
/*      */     
/*  822 */     this.weakColumnsObserver = new WeakListChangeListener<>(this.columnsObserver);
/*      */ 
/*      */     
/*  825 */     this.weakCellSelectionModelInvalidationListener = new WeakInvalidationListener(this.cellSelectionModelInvalidationListener);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  844 */     this.items = new SimpleObjectProperty<ObservableList<S>>(this, "items")
/*      */       {
/*      */         WeakReference<ObservableList<S>> oldItemsRef;
/*      */         
/*      */         protected void invalidated() {
/*  849 */           ObservableList observableList = (this.oldItemsRef == null) ? null : this.oldItemsRef.get();
/*  850 */           ObservableList<S> observableList1 = TableView.this.getItems();
/*      */ 
/*      */           
/*  853 */           if (observableList1 != null && observableList1 == observableList) {
/*      */             return;
/*      */           }
/*      */ 
/*      */           
/*  858 */           if (!(observableList1 instanceof SortedList)) {
/*  859 */             TableView.this.getSortOrder().clear();
/*      */           }
/*      */           
/*  862 */           this.oldItemsRef = new WeakReference<>(observableList1);
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  992 */     this.selectionModel = new SimpleObjectProperty<TableViewSelectionModel<S>>(this, "selectionModel")
/*      */       {
/*      */         
/*  995 */         TableView.TableViewSelectionModel<S> oldValue = null;
/*      */ 
/*      */         
/*      */         protected void invalidated() {
/*  999 */           if (this.oldValue != null) {
/* 1000 */             this.oldValue.cellSelectionEnabledProperty().removeListener(TableView.this.weakCellSelectionModelInvalidationListener);
/*      */             
/* 1002 */             if (this.oldValue instanceof TableView.TableViewArrayListSelectionModel) {
/* 1003 */               ((TableView.TableViewArrayListSelectionModel)this.oldValue).dispose();
/*      */             }
/*      */           } 
/*      */           
/* 1007 */           this.oldValue = get();
/*      */           
/* 1009 */           if (this.oldValue != null) {
/* 1010 */             this.oldValue.cellSelectionEnabledProperty().addListener(TableView.this.weakCellSelectionModelInvalidationListener);
/*      */             
/* 1012 */             TableView.this.weakCellSelectionModelInvalidationListener.invalidated(this.oldValue.cellSelectionEnabledProperty());
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1644 */     this.sortLock = false;
/* 1645 */     this.lastSortEventType = null;
/* 1646 */     this.lastSortEventSupportInfo = null; getStyleClass().setAll(new String[] { "table-view" }); setAccessibleRole(AccessibleRole.TABLE_VIEW); setItems(paramObservableList); setSelectionModel(new TableViewArrayListSelectionModel<>(this)); setFocusModel(new TableViewFocusModel<>(this)); getColumns().addListener(this.weakColumnsObserver); getSortOrder().addListener(paramChange -> doSort(TableUtil.SortEventType.SORT_ORDER_CHANGE, new Object[] { paramChange })); getProperties().addListener(new MapChangeListener<Object, Object>() { public void onChanged(MapChangeListener.Change<? extends Object, ? extends Object> param1Change) { if (param1Change.wasAdded() && "TableView.contentWidth".equals(param1Change.getKey())) { if (param1Change.getValueAdded() instanceof Number) TableView.this.setContentWidth(((Double)param1Change.getValueAdded()).doubleValue());  TableView.this.getProperties().remove("TableView.contentWidth"); }  } }
/*      */       ); this.isInited = true; } public final ObjectProperty<TableViewSelectionModel<S>> selectionModelProperty() { return this.selectionModel; } public final void setSelectionModel(TableViewSelectionModel<S> paramTableViewSelectionModel) { selectionModelProperty().set(paramTableViewSelectionModel); } public final TableViewSelectionModel<S> getSelectionModel() { return this.selectionModel.get(); } public final void setFocusModel(TableViewFocusModel<S> paramTableViewFocusModel) { focusModelProperty().set(paramTableViewFocusModel); } public final TableViewFocusModel<S> getFocusModel() { return (this.focusModel == null) ? null : this.focusModel.get(); } public final ObjectProperty<TableViewFocusModel<S>> focusModelProperty() { if (this.focusModel == null) this.focusModel = new SimpleObjectProperty<>(this, "focusModel");  return this.focusModel; } public final void setEditable(boolean paramBoolean) { editableProperty().set(paramBoolean); } public final boolean isEditable() { return (this.editable == null) ? false : this.editable.get(); } public final BooleanProperty editableProperty() { if (this.editable == null) this.editable = new SimpleBooleanProperty(this, "editable", false);  return this.editable; } public final void setFixedCellSize(double paramDouble) { fixedCellSizeProperty().set(paramDouble); } public final double getFixedCellSize() { return (this.fixedCellSize == null) ? -1.0D : this.fixedCellSize.get(); } public final DoubleProperty fixedCellSizeProperty() { if (this.fixedCellSize == null) this.fixedCellSize = new StyleableDoubleProperty(-1.0D) { public CssMetaData<TableView<?>, Number> getCssMetaData() { return TableView.StyleableProperties.FIXED_CELL_SIZE; } public Object getBean() { return TableView.this; } public String getName() { return "fixedCellSize"; } }
/*      */         ;  return this.fixedCellSize; } private void setEditingCell(TablePosition<S, ?> paramTablePosition) { editingCellPropertyImpl().set(paramTablePosition); } public final TablePosition<S, ?> getEditingCell() { return (this.editingCell == null) ? null : this.editingCell.get(); } public final ReadOnlyObjectProperty<TablePosition<S, ?>> editingCellProperty() { return editingCellPropertyImpl().getReadOnlyProperty(); }
/* 1649 */   private void doSort(TableUtil.SortEventType paramSortEventType, Object... paramVarArgs) { if (this.sortLock) {
/*      */       return;
/*      */     }
/*      */     
/* 1653 */     this.lastSortEventType = paramSortEventType;
/* 1654 */     this.lastSortEventSupportInfo = paramVarArgs;
/* 1655 */     sort();
/* 1656 */     this.lastSortEventType = null;
/* 1657 */     this.lastSortEventSupportInfo = null; } private ReadOnlyObjectWrapper<TablePosition<S, ?>> editingCellPropertyImpl() { if (this.editingCell == null) this.editingCell = new ReadOnlyObjectWrapper<>(this, "editingCell");  return this.editingCell; } private void setComparator(Comparator<S> paramComparator) { comparatorPropertyImpl().set(paramComparator); } public final Comparator<S> getComparator() { return (this.comparator == null) ? null : this.comparator.get(); } public final ReadOnlyObjectProperty<Comparator<S>> comparatorProperty() { return comparatorPropertyImpl().getReadOnlyProperty(); } private ReadOnlyObjectWrapper<Comparator<S>> comparatorPropertyImpl() { if (this.comparator == null) this.comparator = new ReadOnlyObjectWrapper<>(this, "comparator");  return this.comparator; } public final void setSortPolicy(Callback<TableView<S>, Boolean> paramCallback) { sortPolicyProperty().set(paramCallback); } public final Callback<TableView<S>, Boolean> getSortPolicy() { return (this.sortPolicy == null) ? (Callback)DEFAULT_SORT_POLICY : this.sortPolicy.get(); } public final ObjectProperty<Callback<TableView<S>, Boolean>> sortPolicyProperty() { if (this.sortPolicy == null) this.sortPolicy = new SimpleObjectProperty<Callback<TableView<S>, Boolean>>(this, "sortPolicy", DEFAULT_SORT_POLICY) { protected void invalidated() { TableView.this.sort(); } }
/*      */         ;  return this.sortPolicy; } public void setOnSort(EventHandler<SortEvent<TableView<S>>> paramEventHandler) { onSortProperty().set(paramEventHandler); } public EventHandler<SortEvent<TableView<S>>> getOnSort() { if (this.onSort != null) return this.onSort.get();  return null; } public ObjectProperty<EventHandler<SortEvent<TableView<S>>>> onSortProperty() { if (this.onSort == null) this.onSort = new ObjectPropertyBase<EventHandler<SortEvent<TableView<S>>>>() { protected void invalidated() { EventType<SortEvent<?>> eventType = SortEvent.sortEvent(); EventHandler<SortEvent<TableView<S>>> eventHandler = get(); TableView.this.setEventHandler((EventType)eventType, (EventHandler)eventHandler); } public Object getBean() { return TableView.this; } public String getName() { return "onSort"; } }
/*      */         ;  return this.onSort; } public final ObservableList<TableColumn<S, ?>> getColumns() { return this.columns; }
/*      */   public final ObservableList<TableColumn<S, ?>> getSortOrder() { return this.sortOrder; }
/*      */   public void scrollTo(int paramInt) { ControlUtils.scrollToIndex(this, paramInt); }
/*      */   public void scrollTo(S paramS) { if (getItems() != null) { int i = getItems().indexOf(paramS); if (i >= 0) ControlUtils.scrollToIndex(this, i);  }  }
/* 1663 */   private void setContentWidth(double paramDouble) { this.contentWidth = paramDouble;
/* 1664 */     if (this.isInited)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1670 */       getColumnResizePolicy().call(new ResizeFeatures(this, null, Double.valueOf(0.0D))); }  }
/*      */   public void setOnScrollTo(EventHandler<ScrollToEvent<Integer>> paramEventHandler) { onScrollToProperty().set(paramEventHandler); }
/*      */   public EventHandler<ScrollToEvent<Integer>> getOnScrollTo() { if (this.onScrollTo != null) return this.onScrollTo.get();  return null; }
/*      */   public ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollToProperty() { if (this.onScrollTo == null) this.onScrollTo = new ObjectPropertyBase<EventHandler<ScrollToEvent<Integer>>>() {
/*      */           protected void invalidated() { TableView.this.setEventHandler((EventType)ScrollToEvent.scrollToTopIndex(), (EventHandler)get()); }
/*      */           public Object getBean() { return TableView.this; }
/*      */           public String getName() { return "onScrollTo"; }
/*      */         };  return this.onScrollTo; } public void scrollToColumn(TableColumn<S, ?> paramTableColumn) { ControlUtils.scrollToColumn(this, paramTableColumn); } public void scrollToColumnIndex(int paramInt) { if (getColumns() != null) ControlUtils.scrollToColumn(this, getColumns().get(paramInt));  } public void setOnScrollToColumn(EventHandler<ScrollToEvent<TableColumn<S, ?>>> paramEventHandler) { onScrollToColumnProperty().set(paramEventHandler); } public EventHandler<ScrollToEvent<TableColumn<S, ?>>> getOnScrollToColumn() { if (this.onScrollToColumn != null) return this.onScrollToColumn.get();  return null; } public ObjectProperty<EventHandler<ScrollToEvent<TableColumn<S, ?>>>> onScrollToColumnProperty() { if (this.onScrollToColumn == null) this.onScrollToColumn = new ObjectPropertyBase<EventHandler<ScrollToEvent<TableColumn<S, ?>>>>() {
/*      */           protected void invalidated() { EventType<ScrollToEvent<TableColumnBase<?, ?>>> eventType = ScrollToEvent.scrollToColumn(); TableView.this.setEventHandler((EventType)eventType, (EventHandler)get()); } public Object getBean() { return TableView.this; } public String getName() { return "onScrollToColumn"; }
/* 1679 */         };  return this.onScrollToColumn; } private void updateVisibleLeafColumns() { ArrayList<TableColumn<S, ?>> arrayList = new ArrayList();
/* 1680 */     buildVisibleLeafColumns(getColumns(), arrayList);
/* 1681 */     this.visibleLeafColumns.setAll(arrayList);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1688 */     getColumnResizePolicy().call(new ResizeFeatures(this, null, Double.valueOf(0.0D))); }
/*      */   public boolean resizeColumn(TableColumn<S, ?> paramTableColumn, double paramDouble) { if (paramTableColumn == null || Double.compare(paramDouble, 0.0D) == 0) return false;  boolean bool = ((Boolean)getColumnResizePolicy().call(new ResizeFeatures<>(this, paramTableColumn, Double.valueOf(paramDouble)))).booleanValue(); if (!bool) return false;  return true; }
/*      */   public void edit(int paramInt, TableColumn<S, ?> paramTableColumn) { if (!isEditable() || (paramTableColumn != null && !paramTableColumn.isEditable())) return;  if (paramInt < 0 && paramTableColumn == null) { setEditingCell((TablePosition<S, ?>)null); } else { setEditingCell(new TablePosition<>(this, paramInt, paramTableColumn)); }  }
/*      */   public ObservableList<TableColumn<S, ?>> getVisibleLeafColumns() { return this.unmodifiableVisibleLeafColumns; }
/* 1692 */   public int getVisibleLeafIndex(TableColumn<S, ?> paramTableColumn) { return this.visibleLeafColumns.indexOf(paramTableColumn); } public TableColumn<S, ?> getVisibleLeafColumn(int paramInt) { if (paramInt < 0 || paramInt >= this.visibleLeafColumns.size()) return null;  return this.visibleLeafColumns.get(paramInt); } protected Skin<?> createDefaultSkin() { return (Skin<?>)new TableViewSkin(this); } public void sort() { ObservableList<TableColumn<S, ?>> observableList = getSortOrder(); Comparator<S> comparator = getComparator(); setComparator(observableList.isEmpty() ? null : new TableColumnComparatorBase.TableColumnComparator<>(observableList)); SortEvent<TableView> sortEvent = new SortEvent<>(this, this); fireEvent(sortEvent); if (sortEvent.isConsumed()) return;  ArrayList<TablePosition> arrayList = new ArrayList<>(getSelectionModel().getSelectedCells()); int i = arrayList.size(); getSelectionModel().startAtomic(); Callback<TableView<S>, Boolean> callback = getSortPolicy(); if (callback == null) return;  Boolean bool = callback.call(this); getSelectionModel().stopAtomic(); if (bool == null || !bool.booleanValue()) { this.sortLock = true; TableUtil.handleSortFailure((ObservableList)observableList, this.lastSortEventType, this.lastSortEventSupportInfo); setComparator(comparator); this.sortLock = false; } else if (getSelectionModel() instanceof TableViewArrayListSelectionModel) { TableViewArrayListSelectionModel tableViewArrayListSelectionModel = (TableViewArrayListSelectionModel)getSelectionModel(); ObservableList<TablePosition> observableList1 = tableViewArrayListSelectionModel.getSelectedCells(); ArrayList<TablePosition> arrayList1 = new ArrayList(); for (byte b = 0; b < i; b++) { TablePosition tablePosition = arrayList.get(b); if (!observableList1.contains(tablePosition)) arrayList1.add(tablePosition);  }  if (!arrayList1.isEmpty()) { NonIterableChange.GenericAddRemoveChange<TablePosition> genericAddRemoveChange = new NonIterableChange.GenericAddRemoveChange<>(0, i, arrayList1, observableList1); tableViewArrayListSelectionModel.fireCustomSelectedCellsListChangeEvent((ListChangeListener.Change)genericAddRemoveChange); }  }  } public void refresh() { getProperties().put("recreateKey", Boolean.TRUE); } private void buildVisibleLeafColumns(List<TableColumn<S, ?>> paramList1, List<TableColumn<S, ?>> paramList2) { for (TableColumn<S, ?> tableColumn : paramList1) {
/* 1693 */       if (tableColumn == null)
/*      */         continue; 
/* 1695 */       boolean bool = !tableColumn.getColumns().isEmpty() ? true : false;
/*      */       
/* 1697 */       if (bool) {
/* 1698 */         buildVisibleLeafColumns(tableColumn.getColumns(), paramList2); continue;
/* 1699 */       }  if (tableColumn.isVisible()) {
/* 1700 */         paramList2.add(tableColumn);
/*      */       }
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1716 */   private static final PseudoClass PSEUDO_CLASS_CELL_SELECTION = PseudoClass.getPseudoClass("cell-selection");
/*      */   
/* 1718 */   private static final PseudoClass PSEUDO_CLASS_ROW_SELECTION = PseudoClass.getPseudoClass("row-selection");
/*      */   
/*      */   private static class StyleableProperties {
/* 1721 */     private static final CssMetaData<TableView<?>, Number> FIXED_CELL_SIZE = new CssMetaData<TableView<?>, Number>("-fx-fixed-cell-size", 
/*      */         
/* 1723 */         SizeConverter.getInstance(), 
/* 1724 */         Double.valueOf(-1.0D))
/*      */       {
/*      */         public Double getInitialValue(TableView<?> param2TableView) {
/* 1727 */           return Double.valueOf(param2TableView.getFixedCellSize());
/*      */         }
/*      */         
/*      */         public boolean isSettable(TableView<?> param2TableView) {
/* 1731 */           return (param2TableView.fixedCellSize == null || !param2TableView.fixedCellSize.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(TableView<?> param2TableView) {
/* 1735 */           return (StyleableProperty<Number>)param2TableView.fixedCellSizeProperty();
/*      */         }
/*      */       };
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1742 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 1743 */       arrayList.add(FIXED_CELL_SIZE);
/* 1744 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1754 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 1763 */     return getClassCssMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*      */     ObservableList observableList;
/*      */     Node node1;
/*      */     TableViewSelectionModel<S> tableViewSelectionModel;
/*      */     ArrayList<?> arrayList;
/*      */     Node node2;
/* 1777 */     switch (paramAccessibleAttribute) { case COLUMN_COUNT:
/* 1778 */         return Integer.valueOf(getVisibleLeafColumns().size());
/* 1779 */       case ROW_COUNT: return Integer.valueOf(getItems().size());
/*      */ 
/*      */ 
/*      */       
/*      */       case SELECTED_ITEMS:
/* 1784 */         observableList = (ObservableList)super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 1785 */         arrayList = new ArrayList();
/* 1786 */         for (TableRow tableRow : observableList) {
/*      */           
/* 1788 */           ObservableList observableList1 = (ObservableList)tableRow.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 1789 */           if (observableList1 != null) arrayList.addAll(observableList1); 
/*      */         } 
/* 1791 */         return FXCollections.observableArrayList(arrayList);
/*      */       
/*      */       case FOCUS_ITEM:
/* 1794 */         node1 = (Node)super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 1795 */         if (node1 == null) return null; 
/* 1796 */         node2 = (Node)node1.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */         
/* 1798 */         return (node2 != null) ? node2 : node1;
/*      */ 
/*      */       
/*      */       case CELL_AT_ROW_COLUMN:
/* 1802 */         node1 = (TableRow)super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 1803 */         return (node1 != null) ? node1.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs) : null;
/*      */       
/*      */       case MULTIPLE_SELECTION:
/* 1806 */         tableViewSelectionModel = getSelectionModel();
/* 1807 */         return Boolean.valueOf((tableViewSelectionModel != null && tableViewSelectionModel.getSelectionMode() == SelectionMode.MULTIPLE)); }
/*      */     
/* 1809 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ResizeFeatures<S>
/*      */     extends ResizeFeaturesBase<S>
/*      */   {
/*      */     private TableView<S> table;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResizeFeatures(TableView<S> param1TableView, TableColumn<S, ?> param1TableColumn, Double param1Double) {
/* 1841 */       super(param1TableColumn, param1Double);
/* 1842 */       this.table = param1TableView;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TableColumn<S, ?> getColumn() {
/* 1851 */       return (TableColumn<S, ?>)super.getColumn();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TableView<S> getTable() {
/* 1859 */       return this.table;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class TableViewSelectionModel<S>
/*      */     extends TableSelectionModel<S>
/*      */   {
/*      */     private final TableView<S> tableView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean blockFocusCall = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TableViewSelectionModel(TableView<S> param1TableView) {
/* 1905 */       if (param1TableView == null) {
/* 1906 */         throw new NullPointerException("TableView can not be null");
/*      */       }
/*      */       
/* 1909 */       this.tableView = param1TableView;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract ObservableList<TablePosition> getSelectedCells();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSelected(int param1Int, TableColumnBase<S, ?> param1TableColumnBase) {
/* 1939 */       return isSelected(param1Int, (TableColumn<S, ?>)param1TableColumnBase);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract boolean isSelected(int param1Int, TableColumn<S, ?> param1TableColumn);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void select(int param1Int, TableColumnBase<S, ?> param1TableColumnBase) {
/* 1955 */       select(param1Int, (TableColumn<S, ?>)param1TableColumnBase);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract void select(int param1Int, TableColumn<S, ?> param1TableColumn);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void clearAndSelect(int param1Int, TableColumnBase<S, ?> param1TableColumnBase) {
/* 1969 */       clearAndSelect(param1Int, (TableColumn<S, ?>)param1TableColumnBase);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract void clearAndSelect(int param1Int, TableColumn<S, ?> param1TableColumn);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void clearSelection(int param1Int, TableColumnBase<S, ?> param1TableColumnBase) {
/* 1984 */       clearSelection(param1Int, (TableColumn<S, ?>)param1TableColumnBase);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract void clearSelection(int param1Int, TableColumn<S, ?> param1TableColumn);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void selectRange(int param1Int1, TableColumnBase<S, ?> param1TableColumnBase1, int param1Int2, TableColumnBase<S, ?> param1TableColumnBase2) {
/* 1999 */       int i = this.tableView.getVisibleLeafIndex((TableColumn<S, ?>)param1TableColumnBase1);
/* 2000 */       int j = this.tableView.getVisibleLeafIndex((TableColumn<S, ?>)param1TableColumnBase2);
/* 2001 */       for (int k = param1Int1; k <= param1Int2; k++) {
/* 2002 */         for (int m = i; m <= j; m++) {
/* 2003 */           select(k, this.tableView.getVisibleLeafColumn(m));
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TableView<S> getTableView() {
/* 2021 */       return this.tableView;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected List<S> getTableModel() {
/* 2029 */       return this.tableView.getItems();
/*      */     }
/*      */ 
/*      */     
/*      */     protected S getModelItem(int param1Int) {
/* 2034 */       if (param1Int < 0 || param1Int >= getItemCount()) return null; 
/* 2035 */       return this.tableView.getItems().get(param1Int);
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getItemCount() {
/* 2040 */       return getTableModel().size();
/*      */     }
/*      */ 
/*      */     
/*      */     public void focus(int param1Int) {
/* 2045 */       focus(param1Int, (TableColumn<S, ?>)null);
/*      */     }
/*      */ 
/*      */     
/*      */     public int getFocusedIndex() {
/* 2050 */       return getFocusedCell().getRow();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void focus(int param1Int, TableColumn<S, ?> param1TableColumn) {
/* 2062 */       focus(new TablePosition<>(getTableView(), param1Int, param1TableColumn));
/* 2063 */       getTableView().notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
/*      */     }
/*      */     
/*      */     void focus(TablePosition<S, ?> param1TablePosition) {
/* 2067 */       if (this.blockFocusCall)
/* 2068 */         return;  if (getTableView().getFocusModel() == null)
/*      */         return; 
/* 2070 */       getTableView().getFocusModel().focus(param1TablePosition.getRow(), param1TablePosition.getTableColumn());
/*      */     }
/*      */     
/*      */     TablePosition<S, ?> getFocusedCell() {
/* 2074 */       if (getTableView().getFocusModel() == null) {
/* 2075 */         return new TablePosition<>(getTableView(), -1, null);
/*      */       }
/* 2077 */       return getTableView().getFocusModel().getFocusedCell();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class TableViewArrayListSelectionModel<S>
/*      */     extends TableViewSelectionModel<S>
/*      */   {
/* 2090 */     private int itemCount = 0;
/*      */     private final MappingChange.Map<TablePosition<S, ?>, Integer> cellToIndicesMap;
/*      */     private final TableView<S> tableView;
/*      */     final InvalidationListener itemsPropertyListener;
/*      */     final ListChangeListener<S> itemsContentListener;
/*      */     final WeakListChangeListener<S> weakItemsContentListener;
/*      */     private final SelectedCellsMap<TablePosition<S, ?>> selectedCellsMap;
/*      */     private final ReadOnlyUnbackedObservableList<TablePosition<S, ?>> selectedCellsSeq;
/*      */     private int previousModelSize;
/*      */     
/*      */     public TableViewArrayListSelectionModel(final TableView<S> tableView) {
/* 2101 */       super(tableView);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       this.cellToIndicesMap = (param1TablePosition -> Integer.valueOf(param1TablePosition.getRow()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2177 */       this.itemsContentListener = (param1Change -> {
/*      */           updateItemCount();
/*      */           
/*      */           List<S> list = getTableModel();
/*      */           
/*      */           boolean bool = true;
/*      */           
/*      */           while (param1Change.next()) {
/*      */             if (param1Change.wasReplaced() || param1Change.getAddedSize() == getItemCount()) {
/*      */               this.selectedItemChange = param1Change;
/*      */               
/*      */               updateDefaultSelection();
/*      */               
/*      */               this.selectedItemChange = null;
/*      */               
/*      */               return;
/*      */             } 
/*      */             
/*      */             S s = getSelectedItem();
/*      */             int i = getSelectedIndex();
/*      */             if (list == null || list.isEmpty()) {
/*      */               clearSelection();
/*      */               continue;
/*      */             } 
/*      */             if (getSelectedIndex() == -1 && getSelectedItem() != null) {
/*      */               int j = list.indexOf(getSelectedItem());
/*      */               if (j != -1) {
/*      */                 setSelectedIndex(j);
/*      */                 bool = false;
/*      */               } 
/*      */               continue;
/*      */             } 
/*      */             if (param1Change.wasRemoved() && param1Change.getRemovedSize() == 1 && !param1Change.wasAdded() && s != null && s.equals(param1Change.getRemoved().get(0))) {
/*      */               if (getSelectedIndex() < getItemCount()) {
/*      */                 boolean bool1 = (i == 0) ? false : (i - 1);
/*      */                 S s1 = getModelItem(bool1);
/*      */                 if (!s.equals(s1)) {
/*      */                   clearAndSelect(bool1);
/*      */                 }
/*      */               } 
/*      */             }
/*      */           } 
/*      */           if (bool) {
/*      */             updateSelection(param1Change);
/*      */           }
/*      */         });
/* 2223 */       this.weakItemsContentListener = new WeakListChangeListener<>(this.itemsContentListener);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2253 */       this.previousModelSize = 0; this.tableView = tableView; this.itemsPropertyListener = new InvalidationListener() { private WeakReference<ObservableList<S>> weakItemsRef = new WeakReference<>(tableView.getItems()); public void invalidated(Observable param2Observable) { ObservableList observableList = this.weakItemsRef.get(); this.weakItemsRef = new WeakReference<>(tableView.getItems()); TableView.TableViewArrayListSelectionModel.this.updateItemsObserver(observableList, tableView.getItems()); ((SelectedItemsReadOnlyObservableList)TableView.TableViewArrayListSelectionModel.this.getSelectedItems()).setItemsList(tableView.getItems()); } }
/*      */         ; this.tableView.itemsProperty().addListener(this.itemsPropertyListener); this.selectedCellsMap = new SelectedCellsMap<TablePosition<S, ?>>(this::fireCustomSelectedCellsListChangeEvent) { public boolean isCellSelectionEnabled() { return TableView.TableViewArrayListSelectionModel.this.isCellSelectionEnabled(); } }
/*      */         ; this.selectedCellsSeq = new ReadOnlyUnbackedObservableList<TablePosition<S, ?>>() { public TablePosition<S, ?> get(int param2Int) { return TableView.TableViewArrayListSelectionModel.this.selectedCellsMap.get(param2Int); } public int size() { return TableView.TableViewArrayListSelectionModel.this.selectedCellsMap.size(); } }
/*      */         ; ObservableList<S> observableList = getTableView().getItems(); if (observableList != null) { ((SelectedItemsReadOnlyObservableList)getSelectedItems()).setItemsList(observableList); observableList.addListener(this.weakItemsContentListener); }  updateItemCount(); updateDefaultSelection(); cellSelectionEnabledProperty().addListener(param1Observable -> { updateDefaultSelection(); TableCellBehaviorBase.setAnchor(param1TableView, (C)getFocusedCell(), true); });
/*      */     } private void dispose() { this.tableView.itemsProperty().removeListener(this.itemsPropertyListener); ObservableList<S> observableList = getTableView().getItems(); if (observableList != null) observableList.removeListener(this.weakItemsContentListener);  }
/*      */     public ObservableList<TablePosition> getSelectedCells() { return (ObservableList)this.selectedCellsSeq; }
/* 2259 */     private void updateSelection(ListChangeListener.Change<? extends S> param1Change) { param1Change.reset();
/*      */       
/* 2261 */       int i = 0;
/* 2262 */       int j = -1;
/* 2263 */       while (param1Change.next()) {
/* 2264 */         if (param1Change.wasReplaced()) {
/* 2265 */           if (param1Change.getList().isEmpty()) {
/*      */             
/* 2267 */             clearSelection(); continue;
/*      */           } 
/* 2269 */           int k = getSelectedIndex();
/*      */           
/* 2271 */           if (this.previousModelSize == param1Change.getRemovedSize()) {
/*      */             
/* 2273 */             clearSelection(); continue;
/* 2274 */           }  if (k < getItemCount() && k >= 0) {
/*      */ 
/*      */             
/* 2277 */             startAtomic();
/* 2278 */             clearSelection(k);
/* 2279 */             stopAtomic();
/* 2280 */             select(k);
/*      */             continue;
/*      */           } 
/* 2283 */           clearSelection();
/*      */           continue;
/*      */         } 
/* 2286 */         if (param1Change.wasAdded() || param1Change.wasRemoved()) {
/* 2287 */           j = param1Change.getFrom();
/* 2288 */           i += param1Change.wasAdded() ? param1Change.getAddedSize() : -param1Change.getRemovedSize(); continue;
/* 2289 */         }  if (param1Change.wasPermutated()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2300 */           startAtomic();
/*      */           
/* 2302 */           int k = getSelectedIndex();
/*      */ 
/*      */           
/* 2305 */           int m = param1Change.getTo() - param1Change.getFrom();
/* 2306 */           HashMap<Object, Object> hashMap = new HashMap<>(m);
/* 2307 */           for (int n = param1Change.getFrom(); n < param1Change.getTo(); n++) {
/* 2308 */             hashMap.put(Integer.valueOf(n), Integer.valueOf(param1Change.getPermutation(n)));
/*      */           }
/*      */ 
/*      */           
/* 2312 */           ArrayList<TablePosition> arrayList = new ArrayList<>(getSelectedCells());
/*      */ 
/*      */           
/* 2315 */           ArrayList<TablePosition<S, ?>> arrayList1 = new ArrayList(arrayList.size());
/*      */ 
/*      */           
/* 2318 */           boolean bool = false; int i1;
/* 2319 */           for (i1 = 0; i1 < arrayList.size(); i1++) {
/* 2320 */             TablePosition<?, ?> tablePosition1 = arrayList.get(i1);
/* 2321 */             int i2 = tablePosition1.getRow();
/*      */             
/* 2323 */             if (hashMap.containsKey(Integer.valueOf(i2))) {
/* 2324 */               int i3 = ((Integer)hashMap.get(Integer.valueOf(i2))).intValue();
/*      */               
/* 2326 */               bool = (bool || i3 != i2) ? true : false;
/*      */               
/* 2328 */               arrayList1.add(new TablePosition<>(tablePosition1.getTableView(), i3, tablePosition1.getTableColumn()));
/*      */             } 
/*      */           } 
/*      */           
/* 2332 */           if (bool) {
/*      */             
/* 2334 */             quietClearSelection();
/* 2335 */             stopAtomic();
/*      */             
/* 2337 */             this.selectedCellsMap.setAll(arrayList1);
/*      */             
/* 2339 */             if (k >= 0 && k < this.itemCount) {
/* 2340 */               i1 = param1Change.getPermutation(k);
/* 2341 */               setSelectedIndex(i1);
/* 2342 */               focus(i1);
/*      */             }  continue;
/*      */           } 
/* 2345 */           stopAtomic();
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 2350 */       TablePosition<S, ?> tablePosition = (TablePosition)TableCellBehavior.getAnchor(this.tableView, null);
/* 2351 */       if (i != 0 && j >= 0 && tablePosition != null && (param1Change.wasRemoved() || param1Change.wasAdded()) && 
/* 2352 */         isSelected(tablePosition.getRow(), tablePosition.getTableColumn())) {
/* 2353 */         TablePosition<S, Object> tablePosition1 = new TablePosition<>(this.tableView, tablePosition.getRow() + i, tablePosition.getTableColumn());
/* 2354 */         TableCellBehavior.setAnchor(this.tableView, (TableCell)tablePosition1, false);
/*      */       } 
/*      */ 
/*      */       
/* 2358 */       shiftSelection(j, i, new Callback<MultipleSelectionModelBase.ShiftParams, Void>()
/*      */           {
/*      */ 
/*      */ 
/*      */             
/*      */             public Void call(MultipleSelectionModelBase.ShiftParams param2ShiftParams)
/*      */             {
/* 2365 */               TableView.TableViewArrayListSelectionModel.this.startAtomic();
/*      */               
/* 2367 */               int i = param2ShiftParams.getClearIndex();
/* 2368 */               int j = param2ShiftParams.getSetIndex();
/* 2369 */               TablePosition<?, ?> tablePosition = null;
/* 2370 */               if (i > -1) {
/* 2371 */                 for (byte b = 0; b < TableView.TableViewArrayListSelectionModel.this.selectedCellsMap.size(); b++) {
/* 2372 */                   TablePosition<?, ?> tablePosition1 = TableView.TableViewArrayListSelectionModel.this.selectedCellsMap.get(b);
/* 2373 */                   if (tablePosition1.getRow() == i) {
/* 2374 */                     tablePosition = tablePosition1;
/* 2375 */                     TableView.TableViewArrayListSelectionModel.this.selectedCellsMap.remove(tablePosition1);
/* 2376 */                   } else if (tablePosition1.getRow() == j && !param2ShiftParams.isSelected()) {
/* 2377 */                     TableView.TableViewArrayListSelectionModel.this.selectedCellsMap.remove(tablePosition1);
/*      */                   } 
/*      */                 } 
/*      */               }
/*      */               
/* 2382 */               if (tablePosition != null && param2ShiftParams.isSelected()) {
/*      */                 
/* 2384 */                 TablePosition<Object, Object> tablePosition1 = new TablePosition<>(TableView.TableViewArrayListSelectionModel.this.tableView, param2ShiftParams.getSetIndex(), tablePosition.getTableColumn());
/*      */                 
/* 2386 */                 TableView.TableViewArrayListSelectionModel.this.selectedCellsMap.add(tablePosition1);
/*      */               } 
/*      */               
/* 2389 */               TableView.TableViewArrayListSelectionModel.this.stopAtomic();
/*      */               
/* 2391 */               return null;
/*      */             }
/*      */           });
/*      */       
/* 2395 */       this.previousModelSize = getItemCount(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void clearAndSelect(int param1Int) {
/* 2405 */       clearAndSelect(param1Int, (TableColumn<S, ?>)null);
/*      */     }
/*      */     public void clearAndSelect(int param1Int, TableColumn<S, ?> param1TableColumn) {
/*      */       ListChangeListener.Change<TablePosition<S, ?>> change;
/* 2409 */       if (param1Int < 0 || param1Int >= getItemCount())
/*      */         return; 
/* 2411 */       TablePosition<S, Object> tablePosition = new TablePosition<>(getTableView(), param1Int, param1TableColumn);
/* 2412 */       boolean bool1 = isCellSelectionEnabled();
/*      */ 
/*      */       
/* 2415 */       TableCellBehavior.setAnchor(this.tableView, (TableCell)tablePosition, false);
/*      */ 
/*      */ 
/*      */       
/* 2419 */       ArrayList<TablePosition<S, ?>> arrayList = new ArrayList(this.selectedCellsMap.getSelectedCells());
/*      */ 
/*      */ 
/*      */       
/* 2423 */       boolean bool2 = isSelected(param1Int, param1TableColumn);
/* 2424 */       if (bool2 && arrayList.size() == 1) {
/*      */ 
/*      */         
/* 2427 */         TablePosition<S, ?> tablePosition1 = getSelectedCells().get(0);
/* 2428 */         if (getSelectedItem() == getModelItem(param1Int) && 
/* 2429 */           tablePosition1.getRow() == param1Int && tablePosition1.getTableColumn() == param1TableColumn) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2439 */       startAtomic();
/*      */ 
/*      */       
/* 2442 */       clearSelection();
/*      */ 
/*      */       
/* 2445 */       select(param1Int, param1TableColumn);
/*      */       
/* 2447 */       stopAtomic();
/*      */ 
/*      */ 
/*      */       
/* 2451 */       if (bool1) {
/* 2452 */         arrayList.remove(tablePosition);
/*      */       } else {
/* 2454 */         for (TablePosition tablePosition1 : arrayList) {
/* 2455 */           if (tablePosition1.getRow() == param1Int) {
/* 2456 */             arrayList.remove(tablePosition1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2473 */       if (bool2) {
/* 2474 */         change = ControlUtils.buildClearAndSelectChange(this.selectedCellsSeq, arrayList, param1Int);
/*      */       } else {
/* 2476 */         byte b1 = bool1 ? 0 : Math.max(0, this.selectedCellsSeq.indexOf(tablePosition));
/* 2477 */         byte b2 = bool1 ? getSelectedCells().size() : 1;
/* 2478 */         change = new NonIterableChange.GenericAddRemoveChange<>(b1, b1 + b2, arrayList, this.selectedCellsSeq);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2485 */       fireCustomSelectedCellsListChangeEvent(change);
/*      */     }
/*      */     
/*      */     public void select(int param1Int) {
/* 2489 */       select(param1Int, (TableColumn<S, ?>)null);
/*      */     }
/*      */ 
/*      */     
/*      */     public void select(int param1Int, TableColumn<S, ?> param1TableColumn) {
/* 2494 */       if (param1Int < 0 || param1Int >= getItemCount()) {
/*      */         return;
/*      */       }
/*      */       
/* 2498 */       if (isCellSelectionEnabled() && param1TableColumn == null) {
/* 2499 */         ObservableList<TableColumn<S, ?>> observableList = getTableView().getVisibleLeafColumns();
/* 2500 */         for (byte b = 0; b < observableList.size(); b++) {
/* 2501 */           select(param1Int, observableList.get(b));
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/* 2506 */       if (TableCellBehavior.hasDefaultAnchor(this.tableView)) {
/* 2507 */         TableCellBehavior.removeAnchor(this.tableView);
/*      */       }
/*      */       
/* 2510 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 2511 */         quietClearSelection();
/*      */       }
/* 2513 */       this.selectedCellsMap.add(new TablePosition<>(getTableView(), param1Int, param1TableColumn));
/*      */       
/* 2515 */       updateSelectedIndex(param1Int);
/* 2516 */       focus(param1Int, param1TableColumn);
/*      */     }
/*      */     
/*      */     public void select(S param1S) {
/* 2520 */       if (param1S == null && getSelectionMode() == SelectionMode.SINGLE) {
/* 2521 */         clearSelection();
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/* 2528 */       S s = null;
/* 2529 */       for (byte b = 0; b < getItemCount(); b++) {
/* 2530 */         s = getModelItem(b);
/* 2531 */         if (s != null)
/*      */         {
/* 2533 */           if (s.equals(param1S)) {
/* 2534 */             if (isSelected(b)) {
/*      */               return;
/*      */             }
/*      */             
/* 2538 */             if (getSelectionMode() == SelectionMode.SINGLE) {
/* 2539 */               quietClearSelection();
/*      */             }
/*      */             
/* 2542 */             select(b);
/*      */ 
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 2552 */       setSelectedIndex(-1);
/* 2553 */       setSelectedItem(param1S);
/*      */     }
/*      */     
/*      */     public void selectIndices(int param1Int, int... param1VarArgs) {
/* 2557 */       if (param1VarArgs == null) {
/* 2558 */         select(param1Int);
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/* 2566 */       int i = getItemCount();
/*      */       
/* 2568 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 2569 */         quietClearSelection();
/*      */         
/* 2571 */         for (int j = param1VarArgs.length - 1; j >= 0; j--) {
/* 2572 */           int k = param1VarArgs[j];
/* 2573 */           if (k >= 0 && k < i) {
/* 2574 */             select(k);
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/* 2579 */         if (this.selectedCellsMap.isEmpty() && 
/* 2580 */           param1Int > 0 && param1Int < i) {
/* 2581 */           select(param1Int);
/*      */         }
/*      */       } else {
/*      */         
/* 2585 */         int j = -1;
/* 2586 */         LinkedHashSet<TablePosition<S, ?>> linkedHashSet = new LinkedHashSet();
/*      */ 
/*      */         
/* 2589 */         if (param1Int >= 0 && param1Int < i) {
/*      */ 
/*      */           
/* 2592 */           if (isCellSelectionEnabled()) {
/* 2593 */             ObservableList<TableColumn<S, ?>> observableList = getTableView().getVisibleLeafColumns();
/* 2594 */             for (byte b1 = 0; b1 < observableList.size(); b1++) {
/* 2595 */               if (!this.selectedCellsMap.isSelected(param1Int, b1)) {
/* 2596 */                 linkedHashSet.add(new TablePosition<>(getTableView(), param1Int, observableList.get(b1)));
/* 2597 */                 j = param1Int;
/*      */               } 
/*      */             } 
/*      */           } else {
/* 2601 */             boolean bool = this.selectedCellsMap.isSelected(param1Int, -1);
/* 2602 */             if (!bool) {
/* 2603 */               linkedHashSet.add(new TablePosition<>(getTableView(), param1Int, null));
/*      */             }
/*      */           } 
/*      */           
/* 2607 */           j = param1Int;
/*      */         } 
/*      */ 
/*      */         
/* 2611 */         for (byte b = 0; b < param1VarArgs.length; b++) {
/* 2612 */           int k = param1VarArgs[b];
/* 2613 */           if (k >= 0 && k < i) {
/* 2614 */             j = k;
/*      */             
/* 2616 */             if (isCellSelectionEnabled()) {
/* 2617 */               ObservableList<TableColumn<S, ?>> observableList = getTableView().getVisibleLeafColumns();
/* 2618 */               for (byte b1 = 0; b1 < observableList.size(); b1++) {
/* 2619 */                 if (!this.selectedCellsMap.isSelected(k, b1)) {
/* 2620 */                   linkedHashSet.add(new TablePosition<>(getTableView(), k, observableList.get(b1)));
/* 2621 */                   j = k;
/*      */                 }
/*      */               
/*      */               } 
/* 2625 */             } else if (!this.selectedCellsMap.isSelected(k, -1)) {
/*      */               
/* 2627 */               linkedHashSet.add(new TablePosition<>(getTableView(), k, null));
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 2632 */         this.selectedCellsMap.addAll(linkedHashSet);
/*      */         
/* 2634 */         if (j != -1) {
/* 2635 */           select(j);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectAll() {
/* 2641 */       if (getSelectionMode() == SelectionMode.SINGLE)
/*      */         return; 
/* 2643 */       if (isCellSelectionEnabled()) {
/* 2644 */         ArrayList<TablePosition<S, Object>> arrayList = new ArrayList();
/*      */         
/* 2646 */         TablePosition<S, Object> tablePosition = null;
/* 2647 */         for (byte b = 0; b < getTableView().getVisibleLeafColumns().size(); b++) {
/* 2648 */           TableColumn<S, ?> tableColumn = getTableView().getVisibleLeafColumns().get(b);
/* 2649 */           for (byte b1 = 0; b1 < getItemCount(); b1++) {
/* 2650 */             tablePosition = new TablePosition<>(getTableView(), b1, tableColumn);
/* 2651 */             arrayList.add(tablePosition);
/*      */           } 
/*      */         } 
/* 2654 */         this.selectedCellsMap.setAll(arrayList);
/*      */         
/* 2656 */         if (tablePosition != null) {
/* 2657 */           select(tablePosition.getRow(), tablePosition.getTableColumn());
/* 2658 */           focus(tablePosition.getRow(), tablePosition.getTableColumn());
/*      */         } 
/*      */       } else {
/* 2661 */         ArrayList<TablePosition<S, ?>> arrayList = new ArrayList(); int i;
/* 2662 */         for (i = 0; i < getItemCount(); i++) {
/* 2663 */           arrayList.add(new TablePosition<>(getTableView(), i, null));
/*      */         }
/* 2665 */         this.selectedCellsMap.setAll(arrayList);
/*      */         
/* 2667 */         i = getFocusedIndex();
/* 2668 */         if (i == -1) {
/* 2669 */           int j = getItemCount();
/* 2670 */           if (j > 0) {
/* 2671 */             select(j - 1);
/* 2672 */             focus(arrayList.get(arrayList.size() - 1));
/*      */           } 
/*      */         } else {
/* 2675 */           select(i);
/* 2676 */           focus(i);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void selectRange(int param1Int1, TableColumnBase<S, ?> param1TableColumnBase1, int param1Int2, TableColumnBase<S, ?> param1TableColumnBase2) {
/* 2683 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 2684 */         quietClearSelection();
/* 2685 */         select(param1Int2, param1TableColumnBase2);
/*      */         
/*      */         return;
/*      */       } 
/* 2689 */       startAtomic();
/*      */       
/* 2691 */       int i = getItemCount();
/* 2692 */       boolean bool = isCellSelectionEnabled();
/*      */       
/* 2694 */       int j = this.tableView.getVisibleLeafIndex((TableColumn<S, ?>)param1TableColumnBase1);
/* 2695 */       int k = this.tableView.getVisibleLeafIndex((TableColumn<S, ?>)param1TableColumnBase2);
/* 2696 */       int m = Math.min(j, k);
/* 2697 */       int n = Math.max(j, k);
/*      */       
/* 2699 */       int i1 = Math.min(param1Int1, param1Int2);
/* 2700 */       int i2 = Math.max(param1Int1, param1Int2);
/*      */       
/* 2702 */       ArrayList<TablePosition<S, ?>> arrayList = new ArrayList();
/*      */       
/* 2704 */       for (int i3 = i1; i3 <= i2; i3++) {
/*      */ 
/*      */         
/* 2707 */         if (i3 >= 0 && i3 < i)
/*      */         {
/* 2709 */           if (!bool) {
/* 2710 */             arrayList.add(new TablePosition<>(this.tableView, i3, (TableColumn<S, ?>)param1TableColumnBase1));
/*      */           } else {
/* 2712 */             for (int i6 = m; i6 <= n; i6++) {
/* 2713 */               TableColumn<S, ?> tableColumn = this.tableView.getVisibleLeafColumn(i6);
/*      */ 
/*      */ 
/*      */               
/* 2717 */               if (tableColumn != null || !bool)
/*      */               {
/* 2719 */                 arrayList.add(new TablePosition<>(this.tableView, i3, tableColumn));
/*      */               }
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 2727 */       arrayList.removeAll(getSelectedCells());
/*      */       
/* 2729 */       this.selectedCellsMap.addAll(arrayList);
/* 2730 */       stopAtomic();
/*      */ 
/*      */ 
/*      */       
/* 2734 */       updateSelectedIndex(param1Int2);
/* 2735 */       focus(param1Int2, (TableColumn<S, ?>)param1TableColumnBase2);
/*      */       
/* 2737 */       TableColumn<S, ?> tableColumn1 = (TableColumn)param1TableColumnBase1;
/* 2738 */       TableColumn<S, ?> tableColumn2 = bool ? (TableColumn)param1TableColumnBase2 : tableColumn1;
/* 2739 */       int i4 = this.selectedCellsMap.indexOf(new TablePosition<>(this.tableView, param1Int1, tableColumn1));
/* 2740 */       int i5 = this.selectedCellsMap.indexOf(new TablePosition<>(this.tableView, param1Int2, tableColumn2));
/*      */       
/* 2742 */       if (i4 > -1 && i5 > -1) {
/* 2743 */         int i6 = Math.min(i4, i5);
/* 2744 */         int i7 = Math.max(i4, i5);
/*      */         
/* 2746 */         NonIterableChange.SimpleAddChange<TablePosition<S, ?>> simpleAddChange = new NonIterableChange.SimpleAddChange<>(i6, i7 + 1, this.selectedCellsSeq);
/* 2747 */         fireCustomSelectedCellsListChangeEvent(simpleAddChange);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void clearSelection(int param1Int) {
/* 2753 */       clearSelection(param1Int, (TableColumn<S, ?>)null);
/*      */     }
/*      */ 
/*      */     
/*      */     public void clearSelection(int param1Int, TableColumn<S, ?> param1TableColumn) {
/* 2758 */       clearSelection(new TablePosition<>(getTableView(), param1Int, param1TableColumn));
/*      */     }
/*      */     
/*      */     private void clearSelection(TablePosition<S, ?> param1TablePosition) {
/* 2762 */       boolean bool = isCellSelectionEnabled();
/* 2763 */       int i = param1TablePosition.getRow();
/* 2764 */       boolean bool1 = (param1TablePosition.getTableColumn() == null) ? true : false;
/*      */       
/* 2766 */       ArrayList<TablePosition> arrayList = new ArrayList();
/* 2767 */       for (TablePosition tablePosition : getSelectedCells()) {
/* 2768 */         if (!bool) {
/* 2769 */           if (tablePosition.getRow() == i) {
/* 2770 */             arrayList.add(tablePosition); break;
/*      */           } 
/*      */           continue;
/*      */         } 
/* 2774 */         if (bool1 && tablePosition.getRow() == i) {
/*      */ 
/*      */           
/* 2777 */           arrayList.add(tablePosition); continue;
/* 2778 */         }  if (tablePosition.equals(param1TablePosition)) {
/* 2779 */           arrayList.add(param1TablePosition);
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/* 2784 */       Objects.requireNonNull(this.selectedCellsMap); arrayList.stream().forEach(this.selectedCellsMap::remove);
/*      */       
/* 2786 */       if (isEmpty() && !isAtomic()) {
/* 2787 */         updateSelectedIndex(-1);
/* 2788 */         this.selectedCellsMap.clear();
/*      */       } 
/*      */     }
/*      */     
/*      */     public void clearSelection() {
/* 2793 */       final ArrayList<TablePosition> removed = new ArrayList<>(getSelectedCells());
/*      */       
/* 2795 */       quietClearSelection();
/*      */       
/* 2797 */       if (!isAtomic()) {
/* 2798 */         updateSelectedIndex(-1);
/* 2799 */         focus(-1);
/*      */         
/* 2801 */         if (!arrayList.isEmpty()) {
/* 2802 */           NonIterableChange<TablePosition<S, ?>> nonIterableChange = new NonIterableChange<TablePosition<S, ?>>(0, 0, this.selectedCellsSeq) {
/*      */               public List<TablePosition<S, ?>> getRemoved() {
/* 2804 */                 return removed;
/*      */               }
/*      */             };
/* 2807 */           fireCustomSelectedCellsListChangeEvent(nonIterableChange);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void quietClearSelection() {
/* 2814 */       startAtomic();
/* 2815 */       this.selectedCellsMap.clear();
/* 2816 */       stopAtomic();
/*      */     }
/*      */     
/*      */     public boolean isSelected(int param1Int) {
/* 2820 */       return isSelected(param1Int, (TableColumn<S, ?>)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSelected(int param1Int, TableColumn<S, ?> param1TableColumn) {
/* 2828 */       boolean bool = isCellSelectionEnabled();
/* 2829 */       if (bool && param1TableColumn == null) {
/* 2830 */         int i = this.tableView.getVisibleLeafColumns().size();
/* 2831 */         for (byte b = 0; b < i; b++) {
/* 2832 */           if (!this.selectedCellsMap.isSelected(param1Int, b)) {
/* 2833 */             return false;
/*      */           }
/*      */         } 
/* 2836 */         return true;
/*      */       } 
/* 2838 */       boolean bool1 = (!bool || param1TableColumn == null) ? true : this.tableView.getVisibleLeafIndex(param1TableColumn);
/* 2839 */       return this.selectedCellsMap.isSelected(param1Int, bool1);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 2844 */       return this.selectedCellsMap.isEmpty();
/*      */     }
/*      */     
/*      */     public void selectPrevious() {
/* 2848 */       if (isCellSelectionEnabled()) {
/*      */ 
/*      */         
/* 2851 */         TablePosition<S, ?> tablePosition = getFocusedCell();
/* 2852 */         if (tablePosition.getColumn() - 1 >= 0) {
/*      */           
/* 2854 */           select(tablePosition.getRow(), getTableColumn(tablePosition.getTableColumn(), -1));
/* 2855 */         } else if (tablePosition.getRow() < getItemCount() - 1) {
/*      */           
/* 2857 */           select(tablePosition.getRow() - 1, getTableColumn(getTableView().getVisibleLeafColumns().size() - 1));
/*      */         } 
/*      */       } else {
/* 2860 */         int i = getFocusedIndex();
/* 2861 */         if (i == -1) {
/* 2862 */           select(getItemCount() - 1);
/* 2863 */         } else if (i > 0) {
/* 2864 */           select(i - 1);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectNext() {
/* 2870 */       if (isCellSelectionEnabled()) {
/*      */ 
/*      */         
/* 2873 */         TablePosition<S, ?> tablePosition = getFocusedCell();
/* 2874 */         if (tablePosition.getColumn() + 1 < getTableView().getVisibleLeafColumns().size()) {
/*      */           
/* 2876 */           select(tablePosition.getRow(), getTableColumn(tablePosition.getTableColumn(), 1));
/* 2877 */         } else if (tablePosition.getRow() < getItemCount() - 1) {
/*      */           
/* 2879 */           select(tablePosition.getRow() + 1, getTableColumn(0));
/*      */         } 
/*      */       } else {
/* 2882 */         int i = getFocusedIndex();
/* 2883 */         if (i == -1) {
/* 2884 */           select(0);
/* 2885 */         } else if (i < getItemCount() - 1) {
/* 2886 */           select(i + 1);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectAboveCell() {
/* 2892 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/* 2893 */       if (tablePosition.getRow() == -1) {
/* 2894 */         select(getItemCount() - 1);
/* 2895 */       } else if (tablePosition.getRow() > 0) {
/* 2896 */         select(tablePosition.getRow() - 1, tablePosition.getTableColumn());
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectBelowCell() {
/* 2901 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/*      */       
/* 2903 */       if (tablePosition.getRow() == -1) {
/* 2904 */         select(0);
/* 2905 */       } else if (tablePosition.getRow() < getItemCount() - 1) {
/* 2906 */         select(tablePosition.getRow() + 1, tablePosition.getTableColumn());
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectFirst() {
/* 2911 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/*      */       
/* 2913 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 2914 */         quietClearSelection();
/*      */       }
/*      */       
/* 2917 */       if (getItemCount() > 0) {
/* 2918 */         if (isCellSelectionEnabled()) {
/* 2919 */           select(0, tablePosition.getTableColumn());
/*      */         } else {
/* 2921 */           select(0);
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     public void selectLast() {
/* 2927 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/*      */       
/* 2929 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 2930 */         quietClearSelection();
/*      */       }
/*      */       
/* 2933 */       int i = getItemCount();
/* 2934 */       if (i > 0 && getSelectedIndex() < i - 1) {
/* 2935 */         if (isCellSelectionEnabled()) {
/* 2936 */           select(i - 1, tablePosition.getTableColumn());
/*      */         } else {
/* 2938 */           select(i - 1);
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void selectLeftCell() {
/* 2945 */       if (!isCellSelectionEnabled())
/*      */         return; 
/* 2947 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/* 2948 */       if (tablePosition.getColumn() - 1 >= 0) {
/* 2949 */         select(tablePosition.getRow(), getTableColumn(tablePosition.getTableColumn(), -1));
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void selectRightCell() {
/* 2955 */       if (!isCellSelectionEnabled())
/*      */         return; 
/* 2957 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/* 2958 */       if (tablePosition.getColumn() + 1 < getTableView().getVisibleLeafColumns().size()) {
/* 2959 */         select(tablePosition.getRow(), getTableColumn(tablePosition.getTableColumn(), 1));
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateItemsObserver(ObservableList<S> param1ObservableList1, ObservableList<S> param1ObservableList2) {
/* 2974 */       if (param1ObservableList1 != null) {
/* 2975 */         param1ObservableList1.removeListener(this.weakItemsContentListener);
/*      */       }
/* 2977 */       if (param1ObservableList2 != null) {
/* 2978 */         param1ObservableList2.addListener(this.weakItemsContentListener);
/*      */       }
/*      */       
/* 2981 */       updateItemCount();
/* 2982 */       updateDefaultSelection();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateDefaultSelection() {
/* 2988 */       int i = -1;
/* 2989 */       if (this.tableView.getItems() != null) {
/* 2990 */         S s = getSelectedItem();
/* 2991 */         if (s != null) {
/* 2992 */           i = this.tableView.getItems().indexOf(s);
/*      */         }
/*      */       } 
/*      */       
/* 2996 */       clearSelection();
/* 2997 */       select(i, isCellSelectionEnabled() ? getTableColumn(0) : null);
/*      */     }
/*      */     
/*      */     private TableColumn<S, ?> getTableColumn(int param1Int) {
/* 3001 */       return getTableView().getVisibleLeafColumn(param1Int);
/*      */     }
/*      */ 
/*      */     
/*      */     private TableColumn<S, ?> getTableColumn(TableColumn<S, ?> param1TableColumn, int param1Int) {
/* 3006 */       int i = getTableView().getVisibleLeafIndex(param1TableColumn);
/* 3007 */       int j = i + param1Int;
/* 3008 */       return getTableView().getVisibleLeafColumn(j);
/*      */     }
/*      */     
/*      */     private void updateSelectedIndex(int param1Int) {
/* 3012 */       setSelectedIndex(param1Int);
/* 3013 */       setSelectedItem(getModelItem(param1Int));
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getItemCount() {
/* 3018 */       return this.itemCount;
/*      */     }
/*      */     
/*      */     private void updateItemCount() {
/* 3022 */       if (this.tableView == null) {
/* 3023 */         this.itemCount = -1;
/*      */       } else {
/* 3025 */         List<S> list = getTableModel();
/* 3026 */         this.itemCount = (list == null) ? -1 : list.size();
/*      */       } 
/*      */     }
/*      */     
/*      */     private void fireCustomSelectedCellsListChangeEvent(ListChangeListener.Change<? extends TablePosition<S, ?>> param1Change) {
/* 3031 */       ControlUtils.updateSelectedIndices(this, (ListChangeListener.Change)param1Change);
/*      */       
/* 3033 */       if (isAtomic()) {
/*      */         return;
/*      */       }
/*      */       
/* 3037 */       this.selectedCellsSeq.callObservers(new MappingChange<>(param1Change, MappingChange.NOOP_MAP, this.selectedCellsSeq));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class TableViewFocusModel<S>
/*      */     extends TableFocusModel<S, TableColumn<S, ?>>
/*      */   {
/*      */     private final TableView<S> tableView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TablePosition<S, ?> EMPTY_CELL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final InvalidationListener itemsObserver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ListChangeListener<S> itemsContentListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private WeakListChangeListener<S> weakItemsContentListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ReadOnlyObjectWrapper<TablePosition> focusedCell;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TableViewFocusModel(final TableView<S> tableView) {
/* 3097 */       this.itemsContentListener = (param1Change -> {
/*      */           param1Change.next();
/*      */           
/*      */           if (param1Change.wasReplaced() || param1Change.getAddedSize() == getItemCount()) {
/*      */             updateDefaultFocus();
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*      */           TablePosition<S, ?> tablePosition = getFocusedCell();
/*      */           
/*      */           int i = tablePosition.getRow();
/*      */           
/*      */           if (i == -1 || param1Change.getFrom() > i) {
/*      */             return;
/*      */           }
/*      */           
/*      */           param1Change.reset();
/*      */           boolean bool1 = false;
/*      */           boolean bool2 = false;
/*      */           int j = 0;
/*      */           int k;
/*      */           for (k = 0; param1Change.next(); k += param1Change.getRemovedSize()) {
/*      */             bool1 |= param1Change.wasAdded();
/*      */             bool2 |= param1Change.wasRemoved();
/*      */             j += param1Change.getAddedSize();
/*      */           } 
/*      */           if (bool1 && !bool2) {
/*      */             if (j < param1Change.getList().size()) {
/*      */               int m = Math.min(getItemCount() - 1, getFocusedIndex() + j);
/*      */               focus(m, tablePosition.getTableColumn());
/*      */             } 
/*      */           } else if (!bool1 && bool2) {
/*      */             int m = Math.max(0, getFocusedIndex() - k);
/*      */             if (m < 0) {
/*      */               focus(0, tablePosition.getTableColumn());
/*      */             } else {
/*      */               focus(m, tablePosition.getTableColumn());
/*      */             } 
/*      */           } 
/*      */         });
/* 3138 */       this.weakItemsContentListener = new WeakListChangeListener<>(this.itemsContentListener); if (tableView == null)
/*      */         throw new NullPointerException("TableView can not be null");  this.tableView = tableView; this.EMPTY_CELL = new TablePosition<>(tableView, -1, null); this.itemsObserver = new InvalidationListener() { private WeakReference<ObservableList<S>> weakItemsRef = new WeakReference<>(tableView.getItems()); public void invalidated(Observable param2Observable) { ObservableList observableList = this.weakItemsRef.get(); this.weakItemsRef = new WeakReference<>(tableView.getItems()); TableView.TableViewFocusModel.this.updateItemsObserver(observableList, tableView.getItems()); } }; this.tableView.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver));
/*      */       if (tableView.getItems() != null)
/*      */         this.tableView.getItems().addListener(this.weakItemsContentListener); 
/*      */       updateDefaultFocus();
/*      */       focusedCellProperty().addListener(param1Observable -> param1TableView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM));
/* 3144 */     } private void updateItemsObserver(ObservableList<S> param1ObservableList1, ObservableList<S> param1ObservableList2) { if (param1ObservableList1 != null) param1ObservableList1.removeListener(this.weakItemsContentListener); 
/* 3145 */       if (param1ObservableList2 != null) param1ObservableList2.addListener(this.weakItemsContentListener);
/*      */       
/* 3147 */       updateDefaultFocus(); }
/*      */ 
/*      */ 
/*      */     
/*      */     protected int getItemCount() {
/* 3152 */       if (this.tableView.getItems() == null) return -1; 
/* 3153 */       return this.tableView.getItems().size();
/*      */     }
/*      */ 
/*      */     
/*      */     protected S getModelItem(int param1Int) {
/* 3158 */       if (this.tableView.getItems() == null) return null;
/*      */       
/* 3160 */       if (param1Int < 0 || param1Int >= getItemCount()) return null;
/*      */       
/* 3162 */       return this.tableView.getItems().get(param1Int);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final ReadOnlyObjectProperty<TablePosition> focusedCellProperty() {
/* 3170 */       return focusedCellPropertyImpl().getReadOnlyProperty();
/*      */     }
/* 3172 */     private void setFocusedCell(TablePosition param1TablePosition) { focusedCellPropertyImpl().set(param1TablePosition); } public final TablePosition getFocusedCell() {
/* 3173 */       return (this.focusedCell == null) ? this.EMPTY_CELL : this.focusedCell.get();
/*      */     }
/*      */     private ReadOnlyObjectWrapper<TablePosition> focusedCellPropertyImpl() {
/* 3176 */       if (this.focusedCell == null) {
/* 3177 */         this.focusedCell = new ReadOnlyObjectWrapper<TablePosition>(this.EMPTY_CELL) { private TablePosition old;
/*      */             
/*      */             protected void invalidated() {
/* 3180 */               if (get() == null)
/*      */                 return; 
/* 3182 */               if (this.old == null || !this.old.equals(get())) {
/* 3183 */                 TableView.TableViewFocusModel.this.setFocusedIndex(get().getRow());
/* 3184 */                 TableView.TableViewFocusModel.this.setFocusedItem(TableView.TableViewFocusModel.this.getModelItem(getValue().getRow()));
/*      */                 
/* 3186 */                 this.old = get();
/*      */               } 
/*      */             }
/*      */ 
/*      */             
/*      */             public Object getBean() {
/* 3192 */               return TableView.TableViewFocusModel.this;
/*      */             }
/*      */ 
/*      */             
/*      */             public String getName() {
/* 3197 */               return "focusedCell";
/*      */             } }
/*      */           ;
/*      */       }
/* 3201 */       return this.focusedCell;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focus(int param1Int, TableColumn<S, ?> param1TableColumn) {
/* 3212 */       if (param1Int < 0 || param1Int >= getItemCount()) {
/* 3213 */         setFocusedCell(this.EMPTY_CELL);
/*      */       } else {
/* 3215 */         TablePosition tablePosition = getFocusedCell();
/* 3216 */         TablePosition<S, Object> tablePosition1 = new TablePosition<>(this.tableView, param1Int, param1TableColumn);
/* 3217 */         setFocusedCell(tablePosition1);
/*      */         
/* 3219 */         if (tablePosition1.equals(tablePosition)) {
/*      */           
/* 3221 */           setFocusedIndex(param1Int);
/* 3222 */           setFocusedItem(getModelItem(param1Int));
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focus(TablePosition<S, ?> param1TablePosition) {
/* 3234 */       if (param1TablePosition == null)
/* 3235 */         return;  focus(param1TablePosition.getRow(), param1TablePosition.getTableColumn());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isFocused(int param1Int, TableColumn<S, ?> param1TableColumn) {
/* 3250 */       if (param1Int < 0 || param1Int >= getItemCount()) return false;
/*      */       
/* 3252 */       TablePosition tablePosition = getFocusedCell();
/* 3253 */       boolean bool = (param1TableColumn == null || param1TableColumn.equals(tablePosition.getTableColumn())) ? true : false;
/*      */       
/* 3255 */       return (tablePosition.getRow() == param1Int && bool);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focus(int param1Int) {
/* 3267 */       if (param1Int < 0 || param1Int >= getItemCount()) {
/* 3268 */         setFocusedCell(this.EMPTY_CELL);
/*      */       } else {
/* 3270 */         setFocusedCell(new TablePosition<>(this.tableView, param1Int, null));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focusAboveCell() {
/* 3278 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/*      */       
/* 3280 */       if (getFocusedIndex() == -1) {
/* 3281 */         focus(getItemCount() - 1, tablePosition.getTableColumn());
/* 3282 */       } else if (getFocusedIndex() > 0) {
/* 3283 */         focus(getFocusedIndex() - 1, tablePosition.getTableColumn());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focusBelowCell() {
/* 3291 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/* 3292 */       if (getFocusedIndex() == -1) {
/* 3293 */         focus(0, tablePosition.getTableColumn());
/* 3294 */       } else if (getFocusedIndex() != getItemCount() - 1) {
/* 3295 */         focus(getFocusedIndex() + 1, tablePosition.getTableColumn());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focusLeftCell() {
/* 3303 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/* 3304 */       if (tablePosition.getColumn() <= 0)
/* 3305 */         return;  focus(tablePosition.getRow(), getTableColumn(tablePosition.getTableColumn(), -1));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focusRightCell() {
/* 3312 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/* 3313 */       if (tablePosition.getColumn() == getColumnCount() - 1)
/* 3314 */         return;  focus(tablePosition.getRow(), getTableColumn(tablePosition.getTableColumn(), 1));
/*      */     }
/*      */ 
/*      */     
/*      */     public void focusPrevious() {
/* 3319 */       if (getFocusedIndex() == -1) {
/* 3320 */         focus(0);
/* 3321 */       } else if (getFocusedIndex() > 0) {
/* 3322 */         focusAboveCell();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void focusNext() {
/* 3328 */       if (getFocusedIndex() == -1) {
/* 3329 */         focus(0);
/* 3330 */       } else if (getFocusedIndex() != getItemCount() - 1) {
/* 3331 */         focusBelowCell();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateDefaultFocus() {
/* 3344 */       int i = -1;
/* 3345 */       if (this.tableView.getItems() != null) {
/* 3346 */         S s = getFocusedItem();
/* 3347 */         if (s != null) {
/* 3348 */           i = this.tableView.getItems().indexOf(s);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 3353 */         if (i == -1) {
/* 3354 */           i = (this.tableView.getItems().size() > 0) ? 0 : -1;
/*      */         }
/*      */       } 
/*      */       
/* 3358 */       TablePosition<S, ?> tablePosition = getFocusedCell();
/*      */       
/* 3360 */       TableColumn<S, ?> tableColumn = (tablePosition != null && !this.EMPTY_CELL.equals(tablePosition)) ? tablePosition.getTableColumn() : this.tableView.getVisibleLeafColumn(0);
/*      */       
/* 3362 */       focus(i, tableColumn);
/*      */     }
/*      */     
/*      */     private int getColumnCount() {
/* 3366 */       return this.tableView.getVisibleLeafColumns().size();
/*      */     }
/*      */ 
/*      */     
/*      */     private TableColumn<S, ?> getTableColumn(TableColumn<S, ?> param1TableColumn, int param1Int) {
/* 3371 */       int i = this.tableView.getVisibleLeafIndex(param1TableColumn);
/* 3372 */       int j = i + param1Int;
/* 3373 */       return this.tableView.getVisibleLeafColumn(j);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TableView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */