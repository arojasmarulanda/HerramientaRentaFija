/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TableSelectionModel<T>
/*     */   extends MultipleSelectionModelBase<T>
/*     */ {
/* 124 */   private BooleanProperty cellSelectionEnabled = new SimpleBooleanProperty(this, "cellSelectionEnabled");
/*     */   
/*     */   public final BooleanProperty cellSelectionEnabledProperty() {
/* 127 */     return this.cellSelectionEnabled;
/*     */   }
/*     */   public final void setCellSelectionEnabled(boolean paramBoolean) {
/* 130 */     cellSelectionEnabledProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isCellSelectionEnabled() {
/* 133 */     return (this.cellSelectionEnabled == null) ? false : this.cellSelectionEnabled.get();
/*     */   }
/*     */   
/*     */   public abstract boolean isSelected(int paramInt, TableColumnBase<T, ?> paramTableColumnBase);
/*     */   
/*     */   public abstract void select(int paramInt, TableColumnBase<T, ?> paramTableColumnBase);
/*     */   
/*     */   public abstract void clearAndSelect(int paramInt, TableColumnBase<T, ?> paramTableColumnBase);
/*     */   
/*     */   public abstract void clearSelection(int paramInt, TableColumnBase<T, ?> paramTableColumnBase);
/*     */   
/*     */   public abstract void selectLeftCell();
/*     */   
/*     */   public abstract void selectRightCell();
/*     */   
/*     */   public abstract void selectAboveCell();
/*     */   
/*     */   public abstract void selectBelowCell();
/*     */   
/*     */   public abstract void selectRange(int paramInt1, TableColumnBase<T, ?> paramTableColumnBase1, int paramInt2, TableColumnBase<T, ?> paramTableColumnBase2);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TableSelectionModel.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */