/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.MenuButtonSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MenuButton
/*     */   extends ButtonBase
/*     */ {
/*  94 */   public static final EventType<Event> ON_SHOWING = new EventType<>(Event.ANY, "MENU_BUTTON_ON_SHOWING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public static final EventType<Event> ON_SHOWN = new EventType<>(Event.ANY, "MENU_BUTTON_ON_SHOWN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public static final EventType<Event> ON_HIDING = new EventType<>(Event.ANY, "MENU_BUTTON_ON_HIDING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public static final EventType<Event> ON_HIDDEN = new EventType<>(Event.ANY, "MENU_BUTTON_ON_HIDDEN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuButton() {
/* 130 */     this((String)null, (Node)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuButton(String paramString) {
/* 141 */     this(paramString, (Node)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuButton(String paramString, Node paramNode) {
/* 152 */     this(paramString, paramNode, (MenuItem[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuButton(String paramString, Node paramNode, MenuItem... paramVarArgs) {
/* 166 */     if (paramString != null) {
/* 167 */       setText(paramString);
/*     */     }
/* 169 */     if (paramNode != null) {
/* 170 */       setGraphic(paramNode);
/*     */     }
/* 172 */     if (paramVarArgs != null) {
/* 173 */       getItems().addAll(paramVarArgs);
/*     */     }
/*     */     
/* 176 */     getStyleClass().setAll(new String[] { "menu-button" });
/* 177 */     setAccessibleRole(AccessibleRole.MENU_BUTTON);
/* 178 */     setMnemonicParsing(true);
/*     */ 
/*     */     
/* 181 */     pseudoClassStateChanged(PSEUDO_CLASS_OPENVERTICALLY, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   private final ObservableList<MenuItem> items = FXCollections.observableArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<MenuItem> getItems() {
/* 203 */     return this.items;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   private ReadOnlyBooleanWrapper showing = new ReadOnlyBooleanWrapper(this, "showing", false) {
/*     */       protected void invalidated() {
/* 212 */         MenuButton.this.pseudoClassStateChanged(MenuButton.PSEUDO_CLASS_SHOWING, get());
/* 213 */         super.invalidated();
/*     */       }
/*     */     };
/*     */   private ObjectProperty<Side> popupSide;
/*     */   private void setShowing(boolean paramBoolean) {
/* 218 */     Event.fireEvent(this, paramBoolean ? new Event(ON_SHOWING) : 
/* 219 */         new Event(ON_HIDING));
/* 220 */     this.showing.set(paramBoolean);
/* 221 */     Event.fireEvent(this, paramBoolean ? new Event(ON_SHOWN) : 
/* 222 */         new Event(ON_HIDDEN));
/*     */   }
/* 224 */   public final boolean isShowing() { return this.showing.get(); } public final ReadOnlyBooleanProperty showingProperty() {
/* 225 */     return this.showing.getReadOnlyProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setPopupSide(Side paramSide) {
/* 243 */     popupSideProperty().set(paramSide);
/*     */   }
/*     */   
/*     */   public final Side getPopupSide() {
/* 247 */     return (this.popupSide == null) ? Side.BOTTOM : this.popupSide.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<Side> popupSideProperty() {
/* 251 */     if (this.popupSide == null) {
/* 252 */       this.popupSide = new ObjectPropertyBase<Side>(Side.BOTTOM) {
/*     */           protected void invalidated() {
/* 254 */             Side side = get();
/* 255 */             boolean bool = (side == Side.TOP || side == Side.BOTTOM) ? true : false;
/* 256 */             MenuButton.this.pseudoClassStateChanged(MenuButton.PSEUDO_CLASS_OPENVERTICALLY, bool);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 261 */             return MenuButton.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 266 */             return "popupSide";
/*     */           }
/*     */         };
/*     */     }
/* 270 */     return this.popupSide;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<EventHandler<Event>> onShowingProperty() {
/* 278 */     return this.onShowing;
/* 279 */   } public final void setOnShowing(EventHandler<Event> paramEventHandler) { onShowingProperty().set(paramEventHandler); } public final EventHandler<Event> getOnShowing() {
/* 280 */     return onShowingProperty().get();
/* 281 */   } private ObjectProperty<EventHandler<Event>> onShowing = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */       protected void invalidated() {
/* 283 */         MenuButton.this.setEventHandler((EventType)MenuButton.ON_SHOWING, (EventHandler)get());
/*     */       }
/*     */       
/*     */       public Object getBean() {
/* 287 */         return MenuButton.this;
/*     */       }
/*     */       
/*     */       public String getName() {
/* 291 */         return "onShowing";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<EventHandler<Event>> onShownProperty() {
/* 300 */     return this.onShown;
/* 301 */   } public final void setOnShown(EventHandler<Event> paramEventHandler) { onShownProperty().set(paramEventHandler); } public final EventHandler<Event> getOnShown() {
/* 302 */     return onShownProperty().get();
/* 303 */   } private ObjectProperty<EventHandler<Event>> onShown = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */       protected void invalidated() {
/* 305 */         MenuButton.this.setEventHandler((EventType)MenuButton.ON_SHOWN, (EventHandler)get());
/*     */       }
/*     */       
/*     */       public Object getBean() {
/* 309 */         return MenuButton.this;
/*     */       }
/*     */       
/*     */       public String getName() {
/* 313 */         return "onShown";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<EventHandler<Event>> onHidingProperty() {
/* 322 */     return this.onHiding;
/* 323 */   } public final void setOnHiding(EventHandler<Event> paramEventHandler) { onHidingProperty().set(paramEventHandler); } public final EventHandler<Event> getOnHiding() {
/* 324 */     return onHidingProperty().get();
/* 325 */   } private ObjectProperty<EventHandler<Event>> onHiding = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */       protected void invalidated() {
/* 327 */         MenuButton.this.setEventHandler((EventType)MenuButton.ON_HIDING, (EventHandler)get());
/*     */       }
/*     */       
/*     */       public Object getBean() {
/* 331 */         return MenuButton.this;
/*     */       }
/*     */       
/*     */       public String getName() {
/* 335 */         return "onHiding";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<EventHandler<Event>> onHiddenProperty() {
/* 344 */     return this.onHidden;
/* 345 */   } public final void setOnHidden(EventHandler<Event> paramEventHandler) { onHiddenProperty().set(paramEventHandler); } public final EventHandler<Event> getOnHidden() {
/* 346 */     return onHiddenProperty().get();
/* 347 */   } private ObjectProperty<EventHandler<Event>> onHidden = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */       protected void invalidated() {
/* 349 */         MenuButton.this.setEventHandler((EventType)MenuButton.ON_HIDDEN, (EventHandler)get());
/*     */       }
/*     */       
/*     */       public Object getBean() {
/* 353 */         return MenuButton.this;
/*     */       }
/*     */       
/*     */       public String getName() {
/* 357 */         return "onHidden";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_STYLE_CLASS = "menu-button";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void show() {
/* 376 */     if (!isDisabled() && !this.showing.isBound()) {
/* 377 */       setShowing(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hide() {
/* 388 */     if (!this.showing.isBound()) {
/* 389 */       setShowing(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fire() {
/* 398 */     if (!isDisabled()) {
/* 399 */       fireEvent(new ActionEvent());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 405 */     return (Skin<?>)new MenuButtonSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 416 */   private static final PseudoClass PSEUDO_CLASS_OPENVERTICALLY = PseudoClass.getPseudoClass("openvertically");
/*     */   
/* 418 */   private static final PseudoClass PSEUDO_CLASS_SHOWING = PseudoClass.getPseudoClass("showing");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/* 429 */     switch (paramAccessibleAction) {
/*     */       case FIRE:
/* 431 */         if (isShowing()) {
/* 432 */           hide();
/*     */         } else {
/* 434 */           show();
/*     */         }  return;
/*     */     } 
/* 437 */     super.executeAccessibleAction(paramAccessibleAction, new Object[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\MenuButton.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */