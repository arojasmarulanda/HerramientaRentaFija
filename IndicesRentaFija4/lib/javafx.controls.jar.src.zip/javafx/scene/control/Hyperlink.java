/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Cursor;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.HyperlinkSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Hyperlink
/*     */   extends ButtonBase
/*     */ {
/*     */   private BooleanProperty visited;
/*     */   private static final String DEFAULT_STYLE_CLASS = "hyperlink";
/*     */   
/*     */   public Hyperlink() {
/*  66 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hyperlink(String paramString) {
/*  75 */     super(paramString);
/*  76 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hyperlink(String paramString, Node paramNode) {
/*  86 */     super(paramString, paramNode);
/*  87 */     initialize();
/*     */   }
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  92 */     getStyleClass().setAll(new String[] { "hyperlink" });
/*  93 */     setAccessibleRole(AccessibleRole.HYPERLINK);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     ((StyleableProperty<Cursor>)cursorProperty()).applyStyle(null, Cursor.HAND);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BooleanProperty visitedProperty() {
/* 111 */     if (this.visited == null) {
/* 112 */       this.visited = new BooleanPropertyBase() {
/*     */           protected void invalidated() {
/* 114 */             Hyperlink.this.pseudoClassStateChanged(Hyperlink.PSEUDO_CLASS_VISITED, get());
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 119 */             return Hyperlink.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 124 */             return "visited";
/*     */           }
/*     */         };
/*     */     }
/* 128 */     return this.visited;
/*     */   }
/*     */   
/*     */   public final void setVisited(boolean paramBoolean) {
/* 132 */     visitedProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isVisited() {
/* 135 */     return (this.visited == null) ? false : this.visited.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fire() {
/* 149 */     if (!isDisabled()) {
/*     */       
/* 151 */       if (this.visited == null || !this.visited.isBound()) {
/* 152 */         setVisited(true);
/*     */       }
/* 154 */       fireEvent(new ActionEvent());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 160 */     return (Skin<?>)new HyperlinkSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   private static final PseudoClass PSEUDO_CLASS_VISITED = PseudoClass.getPseudoClass("visited");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Cursor getInitialCursor() {
/* 182 */     return Cursor.HAND;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 195 */     switch (paramAccessibleAttribute) { case VISITED:
/* 196 */         return Boolean.valueOf(isVisited()); }
/* 197 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Hyperlink.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */