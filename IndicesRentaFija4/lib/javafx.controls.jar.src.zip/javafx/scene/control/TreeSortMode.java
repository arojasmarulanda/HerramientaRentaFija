/*    */ package javafx.scene.control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TreeSortMode
/*    */ {
/* 36 */   ALL_DESCENDANTS,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   ONLY_FIRST_LEVEL;
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TreeSortMode.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */