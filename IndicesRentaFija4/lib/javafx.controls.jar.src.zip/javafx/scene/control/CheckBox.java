/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.CheckBoxSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckBox
/*     */   extends ButtonBase
/*     */ {
/*     */   private BooleanProperty indeterminate;
/*     */   private BooleanProperty selected;
/*     */   private BooleanProperty allowIndeterminate;
/*     */   private static final String DEFAULT_STYLE_CLASS = "check-box";
/*     */   
/*     */   public CheckBox() {
/*  88 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBox(String paramString) {
/*  97 */     setText(paramString);
/*  98 */     initialize();
/*     */   }
/*     */   
/*     */   private void initialize() {
/* 102 */     getStyleClass().setAll(new String[] { "check-box" });
/* 103 */     setAccessibleRole(AccessibleRole.CHECK_BOX);
/* 104 */     setAlignment(Pos.CENTER_LEFT);
/* 105 */     setMnemonicParsing(true);
/*     */ 
/*     */     
/* 108 */     pseudoClassStateChanged(PSEUDO_CLASS_DETERMINATE, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setIndeterminate(boolean paramBoolean) {
/* 121 */     indeterminateProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isIndeterminate() {
/* 125 */     return (this.indeterminate == null) ? false : this.indeterminate.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty indeterminateProperty() {
/* 129 */     if (this.indeterminate == null) {
/* 130 */       this.indeterminate = new BooleanPropertyBase(false) {
/*     */           protected void invalidated() {
/* 132 */             boolean bool = get();
/* 133 */             CheckBox.this.pseudoClassStateChanged(CheckBox.PSEUDO_CLASS_DETERMINATE, !bool);
/* 134 */             CheckBox.this.pseudoClassStateChanged(CheckBox.PSEUDO_CLASS_INDETERMINATE, bool);
/* 135 */             CheckBox.this.notifyAccessibleAttributeChanged(AccessibleAttribute.INDETERMINATE);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 140 */             return CheckBox.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 145 */             return "indeterminate";
/*     */           }
/*     */         };
/*     */     }
/* 149 */     return this.indeterminate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSelected(boolean paramBoolean) {
/* 156 */     selectedProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isSelected() {
/* 160 */     return (this.selected == null) ? false : this.selected.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty selectedProperty() {
/* 164 */     if (this.selected == null) {
/* 165 */       this.selected = new BooleanPropertyBase() {
/*     */           protected void invalidated() {
/* 167 */             Boolean bool = Boolean.valueOf(get());
/* 168 */             CheckBox.this.pseudoClassStateChanged(CheckBox.PSEUDO_CLASS_SELECTED, bool.booleanValue());
/* 169 */             CheckBox.this.notifyAccessibleAttributeChanged(AccessibleAttribute.SELECTED);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 174 */             return CheckBox.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 179 */             return "selected";
/*     */           }
/*     */         };
/*     */     }
/* 183 */     return this.selected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setAllowIndeterminate(boolean paramBoolean) {
/* 195 */     allowIndeterminateProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isAllowIndeterminate() {
/* 199 */     return (this.allowIndeterminate == null) ? false : this.allowIndeterminate.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty allowIndeterminateProperty() {
/* 203 */     if (this.allowIndeterminate == null) {
/* 204 */       this.allowIndeterminate = new SimpleBooleanProperty(this, "allowIndeterminate");
/*     */     }
/*     */     
/* 207 */     return this.allowIndeterminate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fire() {
/* 225 */     if (!isDisabled()) {
/* 226 */       if (isAllowIndeterminate()) {
/* 227 */         if (!isSelected() && !isIndeterminate()) {
/* 228 */           setIndeterminate(true);
/* 229 */         } else if (isSelected() && !isIndeterminate()) {
/* 230 */           setSelected(false);
/* 231 */         } else if (isIndeterminate()) {
/* 232 */           setSelected(true);
/* 233 */           setIndeterminate(false);
/*     */         } 
/*     */       } else {
/* 236 */         setSelected(!isSelected());
/* 237 */         setIndeterminate(false);
/*     */       } 
/* 239 */       fireEvent(new ActionEvent());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 245 */     return (Skin<?>)new CheckBoxSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   private static final PseudoClass PSEUDO_CLASS_DETERMINATE = PseudoClass.getPseudoClass("determinate");
/*     */   
/* 259 */   private static final PseudoClass PSEUDO_CLASS_INDETERMINATE = PseudoClass.getPseudoClass("indeterminate");
/*     */   
/* 261 */   private static final PseudoClass PSEUDO_CLASS_SELECTED = PseudoClass.getPseudoClass("selected");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 273 */     switch (paramAccessibleAttribute) { case SELECTED:
/* 274 */         return Boolean.valueOf(isSelected());
/* 275 */       case INDETERMINATE: return Boolean.valueOf(isIndeterminate()); }
/* 276 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\CheckBox.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */