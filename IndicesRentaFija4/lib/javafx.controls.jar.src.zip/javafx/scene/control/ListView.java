/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.scene.control.SelectedItemsReadOnlyObservableList;
/*      */ import com.sun.javafx.scene.control.behavior.ListCellBehavior;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import javafx.beans.DefaultProperty;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.WeakInvalidationListener;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*      */ import javafx.beans.property.ReadOnlyIntegerWrapper;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.MapChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.collections.WeakListChangeListener;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.EnumConverter;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.EventType;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.skin.ListViewSkin;
/*      */ import javafx.util.Callback;
/*      */ import javafx.util.Pair;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @DefaultProperty("items")
/*      */ public class ListView<T>
/*      */   extends Control
/*      */ {
/*      */   public static <T> EventType<EditEvent<T>> editAnyEvent() {
/*  248 */     return (EventType)EDIT_ANY_EVENT;
/*      */   }
/*  250 */   private static final EventType<?> EDIT_ANY_EVENT = new EventType(Event.ANY, "LIST_VIEW_EDIT");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<EditEvent<T>> editStartEvent() {
/*  261 */     return (EventType)EDIT_START_EVENT;
/*      */   }
/*  263 */   private static final EventType<?> EDIT_START_EVENT = new EventType(
/*  264 */       editAnyEvent(), "EDIT_START");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<EditEvent<T>> editCancelEvent() {
/*  274 */     return (EventType)EDIT_CANCEL_EVENT;
/*      */   }
/*  276 */   private static final EventType<?> EDIT_CANCEL_EVENT = new EventType(
/*  277 */       editAnyEvent(), "EDIT_CANCEL");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<EditEvent<T>> editCommitEvent() {
/*  287 */     return (EventType)EDIT_COMMIT_EVENT;
/*      */   }
/*  289 */   private static final EventType<?> EDIT_COMMIT_EVENT = new EventType(
/*  290 */       editAnyEvent(), "EDIT_COMMIT");
/*      */   
/*      */   private boolean selectFirstRowByDefault = true;
/*      */   
/*      */   private EventHandler<EditEvent<T>> DEFAULT_EDIT_COMMIT_HANDLER;
/*      */   
/*      */   private ObjectProperty<ObservableList<T>> items;
/*      */   
/*      */   private ObjectProperty<Node> placeholder;
/*      */   
/*      */   private ObjectProperty<MultipleSelectionModel<T>> selectionModel;
/*      */   
/*      */   private ObjectProperty<FocusModel<T>> focusModel;
/*      */   
/*      */   private ObjectProperty<Orientation> orientation;
/*      */   
/*      */   private ObjectProperty<Callback<ListView<T>, ListCell<T>>> cellFactory;
/*      */   
/*      */   private DoubleProperty fixedCellSize;
/*      */   
/*      */   private BooleanProperty editable;
/*      */   
/*      */   private ReadOnlyIntegerWrapper editingIndex;
/*      */   
/*      */   private ObjectProperty<EventHandler<EditEvent<T>>> onEditStart;
/*      */   
/*      */   private ObjectProperty<EventHandler<EditEvent<T>>> onEditCommit;
/*      */   
/*      */   private ObjectProperty<EventHandler<EditEvent<T>>> onEditCancel;
/*      */   
/*      */   private ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollTo;
/*      */   
/*      */   private static final String DEFAULT_STYLE_CLASS = "list-view";
/*      */   
/*      */   public ListView() {
/*  325 */     this(FXCollections.observableArrayList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setItems(ObservableList<T> paramObservableList) {
/*      */     itemsProperty().set(paramObservableList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObservableList<T> getItems() {
/*      */     return (this.items == null) ? null : this.items.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ListView(ObservableList<T> paramObservableList) {
/*  376 */     this.DEFAULT_EDIT_COMMIT_HANDLER = (paramEditEvent -> {
/*      */         int i = paramEditEvent.getIndex();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         ObservableList<T> observableList = getItems();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         if (i < 0 || i >= observableList.size()) {
/*      */           return;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         observableList.set(i, paramEditEvent.getNewValue());
/*      */       });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  454 */     this.selectionModel = new SimpleObjectProperty<>(this, "selectionModel"); getStyleClass().setAll(new String[] { "list-view" }); setAccessibleRole(AccessibleRole.LIST_VIEW); setItems(paramObservableList); setSelectionModel(new ListViewBitSetSelectionModel<>(this)); setFocusModel(new ListViewFocusModel<>(this)); setOnEditCommit(this.DEFAULT_EDIT_COMMIT_HANDLER);
/*      */     getProperties().addListener(paramChange -> {
/*      */           if (paramChange.wasAdded() && "selectFirstRowByDefault".equals(paramChange.getKey())) {
/*      */             Boolean bool = (Boolean)paramChange.getValueAdded();
/*      */             if (bool == null)
/*      */               return; 
/*      */             this.selectFirstRowByDefault = bool.booleanValue();
/*      */           } 
/*      */         });
/*      */   } public final ObjectProperty<ObservableList<T>> itemsProperty() { if (this.items == null)
/*      */       this.items = new SimpleObjectProperty<>(this, "items"); 
/*  465 */     return this.items; } public final void setSelectionModel(MultipleSelectionModel<T> paramMultipleSelectionModel) { selectionModelProperty().set(paramMultipleSelectionModel); } public final ObjectProperty<Node> placeholderProperty() { if (this.placeholder == null)
/*      */       this.placeholder = new SimpleObjectProperty<>(this, "placeholder"); 
/*      */     return this.placeholder; } public final void setPlaceholder(Node paramNode) {
/*      */     placeholderProperty().set(paramNode);
/*      */   } public final Node getPlaceholder() {
/*      */     return (this.placeholder == null) ? null : this.placeholder.get();
/*      */   }
/*      */   public final MultipleSelectionModel<T> getSelectionModel() {
/*  473 */     return (this.selectionModel == null) ? null : this.selectionModel.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<MultipleSelectionModel<T>> selectionModelProperty() {
/*  484 */     return this.selectionModel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFocusModel(FocusModel<T> paramFocusModel) {
/*  496 */     focusModelProperty().set(paramFocusModel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final FocusModel<T> getFocusModel() {
/*  504 */     return (this.focusModel == null) ? null : this.focusModel.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<FocusModel<T>> focusModelProperty() {
/*  514 */     if (this.focusModel == null) {
/*  515 */       this.focusModel = new SimpleObjectProperty<>(this, "focusModel");
/*      */     }
/*  517 */     return this.focusModel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOrientation(Orientation paramOrientation) {
/*  530 */     orientationProperty().set(paramOrientation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Orientation getOrientation() {
/*  539 */     return (this.orientation == null) ? Orientation.VERTICAL : this.orientation.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<Orientation> orientationProperty() {
/*  548 */     if (this.orientation == null) {
/*  549 */       this.orientation = new StyleableObjectProperty<Orientation>(Orientation.VERTICAL) {
/*      */           public void invalidated() {
/*  551 */             boolean bool = (get() == Orientation.VERTICAL) ? true : false;
/*  552 */             ListView.this.pseudoClassStateChanged(ListView.PSEUDO_CLASS_VERTICAL, bool);
/*  553 */             ListView.this.pseudoClassStateChanged(ListView.PSEUDO_CLASS_HORIZONTAL, !bool);
/*      */           }
/*      */ 
/*      */           
/*      */           public CssMetaData<ListView<?>, Orientation> getCssMetaData() {
/*  558 */             return ListView.StyleableProperties.ORIENTATION;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  563 */             return ListView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  568 */             return "orientation";
/*      */           }
/*      */         };
/*      */     }
/*  572 */     return this.orientation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCellFactory(Callback<ListView<T>, ListCell<T>> paramCallback) {
/*  588 */     cellFactoryProperty().set(paramCallback);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Callback<ListView<T>, ListCell<T>> getCellFactory() {
/*  596 */     return (this.cellFactory == null) ? null : this.cellFactory.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<Callback<ListView<T>, ListCell<T>>> cellFactoryProperty() {
/*  610 */     if (this.cellFactory == null) {
/*  611 */       this.cellFactory = new SimpleObjectProperty<>(this, "cellFactory");
/*      */     }
/*  613 */     return this.cellFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFixedCellSize(double paramDouble) {
/*  631 */     fixedCellSizeProperty().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getFixedCellSize() {
/*  644 */     return (this.fixedCellSize == null) ? -1.0D : this.fixedCellSize.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DoubleProperty fixedCellSizeProperty() {
/*  669 */     if (this.fixedCellSize == null) {
/*  670 */       this.fixedCellSize = new StyleableDoubleProperty(-1.0D) {
/*      */           public CssMetaData<ListView<?>, Number> getCssMetaData() {
/*  672 */             return ListView.StyleableProperties.FIXED_CELL_SIZE;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  676 */             return ListView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  680 */             return "fixedCellSize";
/*      */           }
/*      */         };
/*      */     }
/*  684 */     return this.fixedCellSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setEditable(boolean paramBoolean) {
/*  691 */     editableProperty().set(paramBoolean);
/*      */   }
/*      */   public final boolean isEditable() {
/*  694 */     return (this.editable == null) ? false : this.editable.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final BooleanProperty editableProperty() {
/*  703 */     if (this.editable == null) {
/*  704 */       this.editable = new SimpleBooleanProperty(this, "editable", false);
/*      */     }
/*  706 */     return this.editable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setEditingIndex(int paramInt) {
/*  714 */     editingIndexPropertyImpl().set(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getEditingIndex() {
/*  723 */     return (this.editingIndex == null) ? -1 : this.editingIndex.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ReadOnlyIntegerProperty editingIndexProperty() {
/*  735 */     return editingIndexPropertyImpl().getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   private ReadOnlyIntegerWrapper editingIndexPropertyImpl() {
/*  739 */     if (this.editingIndex == null) {
/*  740 */       this.editingIndex = new ReadOnlyIntegerWrapper(this, "editingIndex", -1);
/*      */     }
/*  742 */     return this.editingIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnEditStart(EventHandler<EditEvent<T>> paramEventHandler) {
/*  760 */     onEditStartProperty().set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EventHandler<EditEvent<T>> getOnEditStart() {
/*  769 */     return (this.onEditStart == null) ? null : this.onEditStart.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<EventHandler<EditEvent<T>>> onEditStartProperty() {
/*  778 */     if (this.onEditStart == null) {
/*  779 */       this.onEditStart = (ObjectProperty)new ObjectPropertyBase<EventHandler<EditEvent<EventHandler<EditEvent<T>>>>>() {
/*      */           protected void invalidated() {
/*  781 */             ListView.this.setEventHandler((EventType)ListView.editStartEvent(), (EventHandler)get());
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  786 */             return ListView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  791 */             return "onEditStart";
/*      */           }
/*      */         };
/*      */     }
/*  795 */     return this.onEditStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnEditCommit(EventHandler<EditEvent<T>> paramEventHandler) {
/*  814 */     onEditCommitProperty().set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EventHandler<EditEvent<T>> getOnEditCommit() {
/*  823 */     return (this.onEditCommit == null) ? null : this.onEditCommit.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<EventHandler<EditEvent<T>>> onEditCommitProperty() {
/*  837 */     if (this.onEditCommit == null) {
/*  838 */       this.onEditCommit = (ObjectProperty)new ObjectPropertyBase<EventHandler<EditEvent<EventHandler<EditEvent<T>>>>>() {
/*      */           protected void invalidated() {
/*  840 */             ListView.this.setEventHandler((EventType)ListView.editCommitEvent(), (EventHandler)get());
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  845 */             return ListView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  850 */             return "onEditCommit";
/*      */           }
/*      */         };
/*      */     }
/*  854 */     return this.onEditCommit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnEditCancel(EventHandler<EditEvent<T>> paramEventHandler) {
/*  868 */     onEditCancelProperty().set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EventHandler<EditEvent<T>> getOnEditCancel() {
/*  877 */     return (this.onEditCancel == null) ? null : this.onEditCancel.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<EventHandler<EditEvent<T>>> onEditCancelProperty() {
/*  885 */     if (this.onEditCancel == null) {
/*  886 */       this.onEditCancel = (ObjectProperty)new ObjectPropertyBase<EventHandler<EditEvent<EventHandler<EditEvent<T>>>>>() {
/*      */           protected void invalidated() {
/*  888 */             ListView.this.setEventHandler((EventType)ListView.editCancelEvent(), (EventHandler)get());
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  893 */             return ListView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  898 */             return "onEditCancel";
/*      */           }
/*      */         };
/*      */     }
/*  902 */     return this.onEditCancel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void edit(int paramInt) {
/*  925 */     if (!isEditable())
/*  926 */       return;  setEditingIndex(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void scrollTo(int paramInt) {
/*  938 */     ControlUtils.scrollToIndex(this, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void scrollTo(T paramT) {
/*  947 */     if (getItems() != null) {
/*  948 */       int i = getItems().indexOf(paramT);
/*  949 */       if (i >= 0) {
/*  950 */         ControlUtils.scrollToIndex(this, i);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOnScrollTo(EventHandler<ScrollToEvent<Integer>> paramEventHandler) {
/*  963 */     onScrollToProperty().set(paramEventHandler);
/*      */   }
/*      */   
/*      */   public EventHandler<ScrollToEvent<Integer>> getOnScrollTo() {
/*  967 */     if (this.onScrollTo != null) {
/*  968 */       return this.onScrollTo.get();
/*      */     }
/*  970 */     return null;
/*      */   }
/*      */   
/*      */   public ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollToProperty() {
/*  974 */     if (this.onScrollTo == null) {
/*  975 */       this.onScrollTo = new ObjectPropertyBase<EventHandler<ScrollToEvent<Integer>>>() {
/*      */           protected void invalidated() {
/*  977 */             ListView.this.setEventHandler((EventType)ScrollToEvent.scrollToTopIndex(), (EventHandler)get());
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  981 */             return ListView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  985 */             return "onScrollTo";
/*      */           }
/*      */         };
/*      */     }
/*  989 */     return this.onScrollTo;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Skin<?> createDefaultSkin() {
/*  994 */     return (Skin<?>)new ListViewSkin(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refresh() {
/* 1007 */     getProperties().put("recreateKey", Boolean.TRUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class StyleableProperties
/*      */   {
/* 1029 */     private static final CssMetaData<ListView<?>, Orientation> ORIENTATION = new CssMetaData<ListView<?>, Orientation>("-fx-orientation", (StyleConverter)new EnumConverter(Orientation.class), Orientation.VERTICAL)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Orientation getInitialValue(ListView<?> param2ListView)
/*      */         {
/* 1037 */           return param2ListView.getOrientation();
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean isSettable(ListView<?> param2ListView) {
/* 1042 */           return (param2ListView.orientation == null || !param2ListView.orientation.isBound());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public StyleableProperty<Orientation> getStyleableProperty(ListView<?> param2ListView) {
/* 1048 */           return (StyleableProperty<Orientation>)param2ListView.orientationProperty();
/*      */         }
/*      */       };
/*      */     
/* 1052 */     private static final CssMetaData<ListView<?>, Number> FIXED_CELL_SIZE = new CssMetaData<ListView<?>, Number>("-fx-fixed-cell-size", 
/*      */         
/* 1054 */         SizeConverter.getInstance(), 
/* 1055 */         Double.valueOf(-1.0D))
/*      */       {
/*      */         public Double getInitialValue(ListView<?> param2ListView) {
/* 1058 */           return Double.valueOf(param2ListView.getFixedCellSize());
/*      */         }
/*      */         
/*      */         public boolean isSettable(ListView<?> param2ListView) {
/* 1062 */           return (param2ListView.fixedCellSize == null || !param2ListView.fixedCellSize.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(ListView<?> param2ListView) {
/* 1066 */           return (StyleableProperty<Number>)param2ListView.fixedCellSizeProperty();
/*      */         }
/*      */       };
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1073 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 1074 */       arrayList.add(ORIENTATION);
/* 1075 */       arrayList.add(FIXED_CELL_SIZE);
/* 1076 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1086 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 1095 */     return getClassCssMetaData();
/*      */   }
/*      */ 
/*      */   
/* 1099 */   private static final PseudoClass PSEUDO_CLASS_VERTICAL = PseudoClass.getPseudoClass("vertical");
/*      */   
/* 1101 */   private static final PseudoClass PSEUDO_CLASS_HORIZONTAL = PseudoClass.getPseudoClass("horizontal");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*      */     MultipleSelectionModel<T> multipleSelectionModel;
/* 1114 */     switch (paramAccessibleAttribute) {
/*      */       case MULTIPLE_SELECTION:
/* 1116 */         multipleSelectionModel = getSelectionModel();
/* 1117 */         return Boolean.valueOf((multipleSelectionModel != null && multipleSelectionModel.getSelectionMode() == SelectionMode.MULTIPLE));
/*      */     } 
/* 1119 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EditEvent<T>
/*      */     extends Event
/*      */   {
/*      */     private final T newValue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int editIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ListView<T> source;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final long serialVersionUID = 20130724L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1159 */     public static final EventType<?> ANY = ListView.EDIT_ANY_EVENT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public EditEvent(ListView<T> param1ListView, EventType<? extends EditEvent<T>> param1EventType, T param1T, int param1Int) {
/* 1174 */       super(param1ListView, Event.NULL_SOURCE_TARGET, (EventType)param1EventType);
/* 1175 */       this.source = param1ListView;
/* 1176 */       this.editIndex = param1Int;
/* 1177 */       this.newValue = param1T;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ListView<T> getSource() {
/* 1184 */       return this.source;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getIndex() {
/* 1192 */       return this.editIndex;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public T getNewValue() {
/* 1200 */       return this.newValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1208 */       return "ListViewEditEvent [ newValue: " + getNewValue() + ", ListView: " + getSource() + " ]";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ListViewBitSetSelectionModel<T>
/*      */     extends MultipleSelectionModelBase<T>
/*      */   {
/*      */     public ListViewBitSetSelectionModel(final ListView<T> listView) {
/* 1224 */       if (listView == null) {
/* 1225 */         throw new IllegalArgumentException("ListView can not be null");
/*      */       }
/*      */       
/* 1228 */       this.listView = listView;
/*      */       
/* 1230 */       ((SelectedItemsReadOnlyObservableList)getSelectedItems()).setItemsList(listView.getItems());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1241 */       this.itemsObserver = new InvalidationListener() {
/* 1242 */           private WeakReference<ObservableList<T>> weakItemsRef = new WeakReference<>(listView.getItems());
/*      */           
/*      */           public void invalidated(Observable param2Observable) {
/* 1245 */             ObservableList observableList = this.weakItemsRef.get();
/* 1246 */             this.weakItemsRef = new WeakReference<>(listView.getItems());
/* 1247 */             ((SelectedItemsReadOnlyObservableList)ListView.ListViewBitSetSelectionModel.this.getSelectedItems()).setItemsList(listView.getItems());
/* 1248 */             ListView.ListViewBitSetSelectionModel.this.updateItemsObserver(observableList, listView.getItems());
/*      */           }
/*      */         };
/*      */       
/* 1252 */       this.listView.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver));
/* 1253 */       if (listView.getItems() != null) {
/* 1254 */         this.listView.getItems().addListener(this.weakItemsContentObserver);
/*      */       }
/*      */       
/* 1257 */       updateItemCount();
/*      */       
/* 1259 */       updateDefaultSelection();
/*      */     }
/*      */ 
/*      */     
/* 1263 */     private final ListChangeListener<T> itemsContentObserver = new ListChangeListener<T>() {
/*      */         public void onChanged(ListChangeListener.Change<? extends T> param2Change) {
/* 1265 */           ListView.ListViewBitSetSelectionModel.this.updateItemCount();
/*      */           
/* 1267 */           boolean bool = true;
/*      */           
/* 1269 */           while (param2Change.next()) {
/* 1270 */             Object object = ListView.ListViewBitSetSelectionModel.this.getSelectedItem();
/* 1271 */             int i = ListView.ListViewBitSetSelectionModel.this.getSelectedIndex();
/*      */             
/* 1273 */             if (ListView.ListViewBitSetSelectionModel.this.listView.getItems() == null || ListView.ListViewBitSetSelectionModel.this.listView.getItems().isEmpty()) {
/* 1274 */               ListView.ListViewBitSetSelectionModel.this.selectedItemChange = param2Change;
/* 1275 */               ListView.ListViewBitSetSelectionModel.this.clearSelection();
/* 1276 */               ListView.ListViewBitSetSelectionModel.this.selectedItemChange = null; continue;
/* 1277 */             }  if (i == -1 && object != null) {
/* 1278 */               int j = ListView.ListViewBitSetSelectionModel.this.listView.getItems().indexOf(object);
/* 1279 */               if (j != -1) {
/* 1280 */                 ListView.ListViewBitSetSelectionModel.this.setSelectedIndex(j);
/* 1281 */                 bool = false;
/*      */               }  continue;
/* 1283 */             }  if (param2Change.wasRemoved() && param2Change
/* 1284 */               .getRemovedSize() == 1 && 
/* 1285 */               !param2Change.wasAdded() && object != null && object
/*      */               
/* 1287 */               .equals(param2Change.getRemoved().get(0)))
/*      */             {
/* 1289 */               if (ListView.ListViewBitSetSelectionModel.this.getSelectedIndex() < ListView.ListViewBitSetSelectionModel.this.getItemCount()) {
/* 1290 */                 boolean bool1 = (i == 0) ? false : (i - 1);
/* 1291 */                 Object object1 = ListView.ListViewBitSetSelectionModel.this.getModelItem(bool1);
/* 1292 */                 if (!object.equals(object1)) {
/* 1293 */                   ListView.ListViewBitSetSelectionModel.this.startAtomic();
/* 1294 */                   ListView.ListViewBitSetSelectionModel.this.clearSelection(i);
/* 1295 */                   ListView.ListViewBitSetSelectionModel.this.stopAtomic();
/* 1296 */                   ListView.ListViewBitSetSelectionModel.this.select(object1);
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/* 1302 */           if (bool) {
/* 1303 */             ListView.ListViewBitSetSelectionModel.this.updateSelection(param2Change);
/*      */           }
/*      */         }
/*      */       };
/*      */ 
/*      */     
/*      */     private final InvalidationListener itemsObserver;
/*      */     
/* 1311 */     private WeakListChangeListener<T> weakItemsContentObserver = new WeakListChangeListener<>(this.itemsContentObserver);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ListView<T> listView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1325 */     private int itemCount = 0;
/*      */     
/* 1327 */     private int previousModelSize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateSelection(ListChangeListener.Change<? extends T> param1Change) {
/* 1349 */       param1Change.reset();
/*      */       
/* 1351 */       ArrayList<Pair<Integer, Integer>> arrayList = new ArrayList();
/* 1352 */       while (param1Change.next()) {
/* 1353 */         if (param1Change.wasReplaced()) {
/* 1354 */           if (param1Change.getList().isEmpty()) {
/*      */             
/* 1356 */             clearSelection(); continue;
/*      */           } 
/* 1358 */           int i = getSelectedIndex();
/*      */           
/* 1360 */           if (this.previousModelSize == param1Change.getRemovedSize()) {
/*      */             
/* 1362 */             clearSelection(); continue;
/* 1363 */           }  if (i < getItemCount() && i >= 0) {
/*      */ 
/*      */             
/* 1366 */             startAtomic();
/* 1367 */             clearSelection(i);
/* 1368 */             stopAtomic();
/* 1369 */             select(i);
/*      */             continue;
/*      */           } 
/* 1372 */           clearSelection();
/*      */           continue;
/*      */         } 
/* 1375 */         if (param1Change.wasAdded() || param1Change.wasRemoved()) {
/* 1376 */           int i = param1Change.wasAdded() ? param1Change.getAddedSize() : -param1Change.getRemovedSize();
/* 1377 */           arrayList.add(new Pair<>(Integer.valueOf(param1Change.getFrom()), Integer.valueOf(i))); continue;
/* 1378 */         }  if (param1Change.wasPermutated()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1392 */           int i = param1Change.getTo() - param1Change.getFrom();
/* 1393 */           HashMap<Object, Object> hashMap = new HashMap<>(i);
/* 1394 */           for (int j = param1Change.getFrom(); j < param1Change.getTo(); j++) {
/* 1395 */             hashMap.put(Integer.valueOf(j), Integer.valueOf(param1Change.getPermutation(j)));
/*      */           }
/*      */ 
/*      */           
/* 1399 */           ArrayList<Integer> arrayList1 = new ArrayList<>(getSelectedIndices());
/*      */ 
/*      */ 
/*      */           
/* 1403 */           clearSelection();
/*      */ 
/*      */           
/* 1406 */           ArrayList<Integer> arrayList2 = new ArrayList(getSelectedIndices().size());
/*      */ 
/*      */           
/* 1409 */           for (byte b = 0; b < arrayList1.size(); b++) {
/* 1410 */             int k = ((Integer)arrayList1.get(b)).intValue();
/*      */             
/* 1412 */             if (hashMap.containsKey(Integer.valueOf(k))) {
/* 1413 */               Integer integer = (Integer)hashMap.get(Integer.valueOf(k));
/* 1414 */               arrayList2.add(integer);
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/* 1419 */           if (!arrayList2.isEmpty()) {
/* 1420 */             if (arrayList2.size() == 1) {
/* 1421 */               select(((Integer)arrayList2.get(0)).intValue()); continue;
/*      */             } 
/* 1423 */             int[] arrayOfInt = new int[arrayList2.size() - 1];
/* 1424 */             for (byte b1 = 0; b1 < arrayList2.size() - 1; b1++) {
/* 1425 */               arrayOfInt[b1] = ((Integer)arrayList2.get(b1 + 1)).intValue();
/*      */             }
/* 1427 */             selectIndices(((Integer)arrayList2.get(0)).intValue(), arrayOfInt);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1433 */       if (!arrayList.isEmpty()) {
/* 1434 */         shiftSelection(arrayList, (Callback<MultipleSelectionModelBase.ShiftParams, Void>)null);
/*      */       }
/*      */       
/* 1437 */       this.previousModelSize = getItemCount();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void selectAll() {
/* 1452 */       int i = ((Integer)ListCellBehavior.getAnchor(this.listView, (ListCell<T>)Integer.valueOf(-1))).intValue();
/* 1453 */       super.selectAll();
/* 1454 */       ListCellBehavior.setAnchor(this.listView, (ListCell<T>)Integer.valueOf(i), false);
/*      */     }
/*      */ 
/*      */     
/*      */     public void clearAndSelect(int param1Int) {
/* 1459 */       ListCellBehavior.setAnchor(this.listView, (ListCell<T>)Integer.valueOf(param1Int), false);
/* 1460 */       super.clearAndSelect(param1Int);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void focus(int param1Int) {
/* 1465 */       if (this.listView.getFocusModel() == null)
/* 1466 */         return;  this.listView.getFocusModel().focus(param1Int);
/*      */       
/* 1468 */       this.listView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getFocusedIndex() {
/* 1473 */       if (this.listView.getFocusModel() == null) return -1; 
/* 1474 */       return this.listView.getFocusModel().getFocusedIndex();
/*      */     }
/*      */     
/*      */     protected int getItemCount() {
/* 1478 */       return this.itemCount;
/*      */     }
/*      */     
/*      */     protected T getModelItem(int param1Int) {
/* 1482 */       ObservableList<T> observableList = this.listView.getItems();
/* 1483 */       if (observableList == null) return null; 
/* 1484 */       if (param1Int < 0 || param1Int >= this.itemCount) return null;
/*      */       
/* 1486 */       return observableList.get(param1Int);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateItemCount() {
/* 1498 */       if (this.listView == null) {
/* 1499 */         this.itemCount = -1;
/*      */       } else {
/* 1501 */         ObservableList<T> observableList = this.listView.getItems();
/* 1502 */         this.itemCount = (observableList == null) ? -1 : observableList.size();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void updateItemsObserver(ObservableList<T> param1ObservableList1, ObservableList<T> param1ObservableList2) {
/* 1508 */       if (param1ObservableList1 != null) {
/* 1509 */         param1ObservableList1.removeListener(this.weakItemsContentObserver);
/*      */       }
/* 1511 */       if (param1ObservableList2 != null) {
/* 1512 */         param1ObservableList2.addListener(this.weakItemsContentObserver);
/*      */       }
/*      */       
/* 1515 */       updateItemCount();
/* 1516 */       updateDefaultSelection();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateDefaultSelection() {
/* 1522 */       int i = -1;
/* 1523 */       int j = -1;
/* 1524 */       if (this.listView.getItems() != null) {
/* 1525 */         T t = getSelectedItem();
/* 1526 */         if (t != null) {
/* 1527 */           i = this.listView.getItems().indexOf(t);
/* 1528 */           j = i;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1533 */         if (this.listView.selectFirstRowByDefault && j == -1) {
/* 1534 */           j = (this.listView.getItems().size() > 0) ? 0 : -1;
/*      */         }
/*      */       } 
/*      */       
/* 1538 */       clearSelection();
/* 1539 */       select(i);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class ListViewFocusModel<T>
/*      */     extends FocusModel<T>
/*      */   {
/*      */     private final ListView<T> listView;
/*      */     
/* 1550 */     private int itemCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final InvalidationListener itemsObserver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ListChangeListener<T> itemsContentListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private WeakListChangeListener<T> weakItemsContentListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateItemsObserver(ObservableList<T> param1ObservableList1, ObservableList<T> param1ObservableList2) {
/* 1585 */       if (param1ObservableList1 != null) param1ObservableList1.removeListener(this.weakItemsContentListener); 
/* 1586 */       if (param1ObservableList2 != null) param1ObservableList2.addListener(this.weakItemsContentListener);
/*      */       
/* 1588 */       updateItemCount();
/* 1589 */       updateDefaultFocus();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ListViewFocusModel(final ListView<T> listView) {
/* 1596 */       this.itemsContentListener = (param1Change -> {
/*      */           updateItemCount();
/*      */           
/*      */           while (param1Change.next()) {
/*      */             int i = param1Change.getFrom();
/*      */             
/*      */             if (param1Change.wasReplaced() || param1Change.getAddedSize() == getItemCount()) {
/*      */               updateDefaultFocus();
/*      */               
/*      */               return;
/*      */             } 
/*      */             
/*      */             if (getFocusedIndex() == -1 || i > getFocusedIndex()) {
/*      */               return;
/*      */             }
/*      */             
/*      */             param1Change.reset();
/*      */             
/*      */             boolean bool1 = false;
/*      */             boolean bool2 = false;
/*      */             int j = 0;
/*      */             int k;
/*      */             for (k = 0; param1Change.next(); k += param1Change.getRemovedSize()) {
/*      */               bool1 |= param1Change.wasAdded();
/*      */               bool2 |= param1Change.wasRemoved();
/*      */               j += param1Change.getAddedSize();
/*      */             } 
/*      */             if (bool1 && !bool2) {
/*      */               focus(Math.min(getItemCount() - 1, getFocusedIndex() + j));
/*      */               continue;
/*      */             } 
/*      */             if (!bool1 && bool2) {
/*      */               focus(Math.max(0, getFocusedIndex() - k));
/*      */             }
/*      */           } 
/*      */         });
/* 1632 */       this.weakItemsContentListener = new WeakListChangeListener<>(this.itemsContentListener); if (listView == null)
/*      */         throw new IllegalArgumentException("ListView can not be null");  this.listView = listView; this.itemsObserver = new InvalidationListener() { private WeakReference<ObservableList<T>> weakItemsRef = new WeakReference<>(listView.getItems()); public void invalidated(Observable param2Observable) { ObservableList observableList = this.weakItemsRef.get(); this.weakItemsRef = new WeakReference<>(listView.getItems()); ListView.ListViewFocusModel.this.updateItemsObserver(observableList, listView.getItems()); } }; this.listView.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver)); if (listView.getItems() != null)
/*      */         this.listView.getItems().addListener(this.weakItemsContentListener);  updateItemCount(); updateDefaultFocus();
/*      */       focusedIndexProperty().addListener(param1Observable -> param1ListView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM));
/* 1636 */     } protected int getItemCount() { return this.itemCount; }
/*      */ 
/*      */     
/*      */     protected T getModelItem(int param1Int) {
/* 1640 */       if (isEmpty()) return null; 
/* 1641 */       if (param1Int < 0 || param1Int >= this.itemCount) return null;
/*      */       
/* 1643 */       return this.listView.getItems().get(param1Int);
/*      */     }
/*      */     
/*      */     private boolean isEmpty() {
/* 1647 */       return (this.itemCount == -1);
/*      */     }
/*      */     
/*      */     private void updateItemCount() {
/* 1651 */       if (this.listView == null) {
/* 1652 */         this.itemCount = -1;
/*      */       } else {
/* 1654 */         ObservableList<T> observableList = this.listView.getItems();
/* 1655 */         this.itemCount = (observableList == null) ? -1 : observableList.size();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateDefaultFocus() {
/* 1662 */       int i = -1;
/* 1663 */       if (this.listView.getItems() != null) {
/* 1664 */         T t = getFocusedItem();
/* 1665 */         if (t != null) {
/* 1666 */           i = this.listView.getItems().indexOf(t);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1671 */         if (i == -1) {
/* 1672 */           i = (this.listView.getItems().size() > 0) ? 0 : -1;
/*      */         }
/*      */       } 
/*      */       
/* 1676 */       focus(i);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ListView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */