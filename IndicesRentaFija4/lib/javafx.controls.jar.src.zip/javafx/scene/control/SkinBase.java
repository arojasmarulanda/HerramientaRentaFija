/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.control.LambdaMultiplePropertyChangeListenerHandler;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.Insets;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SkinBase<C extends Control>
/*     */   implements Skin<C>
/*     */ {
/*     */   private C control;
/*     */   private ObservableList<Node> children;
/*     */   private LambdaMultiplePropertyChangeListenerHandler lambdaChangeListenerHandler;
/*     */   private static final EventHandler<MouseEvent> mouseEventConsumer;
/*     */   
/*     */   static {
/*  96 */     mouseEventConsumer = (paramMouseEvent -> paramMouseEvent.consume());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SkinBase(C paramC) {
/* 119 */     if (paramC == null) {
/* 120 */       throw new IllegalArgumentException("Cannot pass null for control");
/*     */     }
/*     */ 
/*     */     
/* 124 */     this.control = paramC;
/* 125 */     this.children = paramC.getControlChildren();
/*     */ 
/*     */     
/* 128 */     consumeMouseEvents(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final C getSkinnable() {
/* 141 */     return this.control;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Node getNode() {
/* 146 */     return (Node)this.control;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 154 */     if (this.lambdaChangeListenerHandler != null) {
/* 155 */       this.lambdaChangeListenerHandler.dispose();
/*     */     }
/*     */     
/* 158 */     this.control = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<Node> getChildren() {
/* 174 */     return this.children;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*     */     byte b;
/*     */     int i;
/* 187 */     for (b = 0, i = this.children.size(); b < i; b++) {
/* 188 */       Node node = this.children.get(b);
/* 189 */       if (node.isManaged()) {
/* 190 */         layoutInArea(node, paramDouble1, paramDouble2, paramDouble3, paramDouble4, -1.0D, HPos.CENTER, VPos.CENTER);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void consumeMouseEvents(boolean paramBoolean) {
/* 200 */     if (paramBoolean) {
/* 201 */       this.control.addEventHandler(MouseEvent.ANY, mouseEventConsumer);
/*     */     } else {
/* 203 */       this.control.removeEventHandler(MouseEvent.ANY, mouseEventConsumer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void registerChangeListener(ObservableValue<?> paramObservableValue, Consumer<ObservableValue<?>> paramConsumer) {
/* 216 */     if (this.lambdaChangeListenerHandler == null) {
/* 217 */       this.lambdaChangeListenerHandler = new LambdaMultiplePropertyChangeListenerHandler();
/*     */     }
/* 219 */     this.lambdaChangeListenerHandler.registerChangeListener(paramObservableValue, paramConsumer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Consumer<ObservableValue<?>> unregisterChangeListeners(ObservableValue<?> paramObservableValue) {
/* 235 */     if (this.lambdaChangeListenerHandler == null) {
/* 236 */       return null;
/*     */     }
/* 238 */     return this.lambdaChangeListenerHandler.unregisterChangeListeners(paramObservableValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 264 */     double d1 = 0.0D;
/* 265 */     double d2 = 0.0D;
/* 266 */     boolean bool = true;
/* 267 */     for (byte b = 0; b < this.children.size(); b++) {
/* 268 */       Node node = this.children.get(b);
/* 269 */       if (node.isManaged()) {
/* 270 */         double d = node.getLayoutBounds().getMinX() + node.getLayoutX();
/* 271 */         if (!bool) {
/* 272 */           d1 = Math.min(d1, d);
/* 273 */           d2 = Math.max(d2, d + node.minWidth(-1.0D));
/*     */         } else {
/* 275 */           d1 = d;
/* 276 */           d2 = d + node.minWidth(-1.0D);
/* 277 */           bool = false;
/*     */         } 
/*     */       } 
/*     */     } 
/* 281 */     double d3 = d2 - d1;
/* 282 */     return paramDouble5 + d3 + paramDouble3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 299 */     double d1 = 0.0D;
/* 300 */     double d2 = 0.0D;
/* 301 */     boolean bool = true;
/* 302 */     for (byte b = 0; b < this.children.size(); b++) {
/* 303 */       Node node = this.children.get(b);
/* 304 */       if (node.isManaged()) {
/* 305 */         double d = node.getLayoutBounds().getMinY() + node.getLayoutY();
/* 306 */         if (!bool) {
/* 307 */           d1 = Math.min(d1, d);
/* 308 */           d2 = Math.max(d2, d + node.minHeight(-1.0D));
/*     */         } else {
/* 310 */           d1 = d;
/* 311 */           d2 = d + node.minHeight(-1.0D);
/* 312 */           bool = false;
/*     */         } 
/*     */       } 
/*     */     } 
/* 316 */     double d3 = d2 - d1;
/* 317 */     return paramDouble2 + d3 + paramDouble4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 333 */     return Double.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 349 */     return Double.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 368 */     double d1 = 0.0D;
/* 369 */     double d2 = 0.0D;
/* 370 */     boolean bool = true;
/* 371 */     for (byte b = 0; b < this.children.size(); b++) {
/* 372 */       Node node = this.children.get(b);
/* 373 */       if (node.isManaged()) {
/* 374 */         double d = node.getLayoutBounds().getMinX() + node.getLayoutX();
/* 375 */         if (!bool) {
/* 376 */           d1 = Math.min(d1, d);
/* 377 */           d2 = Math.max(d2, d + node.prefWidth(-1.0D));
/*     */         } else {
/* 379 */           d1 = d;
/* 380 */           d2 = d + node.prefWidth(-1.0D);
/* 381 */           bool = false;
/*     */         } 
/*     */       } 
/*     */     } 
/* 385 */     return d2 - d1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 404 */     double d1 = 0.0D;
/* 405 */     double d2 = 0.0D;
/* 406 */     boolean bool = true;
/* 407 */     for (byte b = 0; b < this.children.size(); b++) {
/* 408 */       Node node = this.children.get(b);
/* 409 */       if (node.isManaged()) {
/* 410 */         double d = node.getLayoutBounds().getMinY() + node.getLayoutY();
/* 411 */         if (!bool) {
/* 412 */           d1 = Math.min(d1, d);
/* 413 */           d2 = Math.max(d2, d + node.prefHeight(-1.0D));
/*     */         } else {
/* 415 */           d1 = d;
/* 416 */           d2 = d + node.prefHeight(-1.0D);
/* 417 */           bool = false;
/*     */         } 
/*     */       } 
/*     */     } 
/* 421 */     return d2 - d1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeBaselineOffset(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 435 */     int i = this.children.size();
/* 436 */     for (byte b = 0; b < i; b++) {
/* 437 */       Node node = this.children.get(b);
/* 438 */       if (node.isManaged()) {
/* 439 */         double d = node.getBaselineOffset();
/* 440 */         if (d != Double.NEGATIVE_INFINITY)
/*     */         {
/*     */           
/* 443 */           return node.getLayoutBounds().getMinY() + node.getLayoutY() + d; } 
/*     */       } 
/*     */     } 
/* 446 */     return Double.NEGATIVE_INFINITY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double snappedTopInset() {
/* 463 */     return this.control.snappedTopInset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double snappedBottomInset() {
/* 473 */     return this.control.snappedBottomInset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double snappedLeftInset() {
/* 483 */     return this.control.snappedLeftInset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double snappedRightInset() {
/* 493 */     return this.control.snappedRightInset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "9")
/*     */   protected double snapSpace(double paramDouble) {
/* 509 */     return this.control.snapSpaceX(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double snapSpaceX(double paramDouble) {
/* 524 */     return this.control.snapSpaceX(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double snapSpaceY(double paramDouble) {
/* 539 */     return this.control.snapSpaceY(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "9")
/*     */   protected double snapSize(double paramDouble) {
/* 555 */     return this.control.snapSizeX(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double snapSizeX(double paramDouble) {
/* 570 */     return this.control.snapSizeX(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double snapSizeY(double paramDouble) {
/* 585 */     return this.control.snapSizeY(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "9")
/*     */   protected double snapPosition(double paramDouble) {
/* 601 */     return this.control.snapPositionX(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double snapPositionX(double paramDouble) {
/* 616 */     return this.control.snapPositionX(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double snapPositionY(double paramDouble) {
/* 631 */     return this.control.snapPositionY(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void positionInArea(Node paramNode, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, HPos paramHPos, VPos paramVPos) {
/* 662 */     positionInArea(paramNode, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, Insets.EMPTY, paramHPos, paramVPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void positionInArea(Node paramNode, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, Insets paramInsets, HPos paramHPos, VPos paramVPos) {
/* 699 */     Region.positionInArea(paramNode, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramInsets, paramHPos, paramVPos, this.control
/*     */         
/* 701 */         .isSnapToPixel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutInArea(Node paramNode, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, HPos paramHPos, VPos paramVPos) {
/* 752 */     layoutInArea(paramNode, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, Insets.EMPTY, true, true, paramHPos, paramVPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutInArea(Node paramNode, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, Insets paramInsets, HPos paramHPos, VPos paramVPos) {
/* 808 */     layoutInArea(paramNode, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramInsets, true, true, paramHPos, paramVPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutInArea(Node paramNode, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, Insets paramInsets, boolean paramBoolean1, boolean paramBoolean2, HPos paramHPos, VPos paramVPos) {
/* 867 */     Region.layoutInArea(paramNode, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramInsets, paramBoolean1, paramBoolean2, paramHPos, paramVPos, this.control
/*     */         
/* 869 */         .isSnapToPixel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 892 */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES = Collections.unmodifiableList(Control.getClassCssMetaData());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 903 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 913 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void pseudoClassStateChanged(PseudoClass paramPseudoClass, boolean paramBoolean) {
/* 947 */     C c = getSkinnable();
/* 948 */     if (c != null) {
/* 949 */       c.pseudoClassStateChanged(paramPseudoClass, paramBoolean);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 980 */     return null;
/*     */   }
/*     */   
/*     */   protected void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {}
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\SkinBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */