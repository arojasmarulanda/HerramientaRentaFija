/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.DefaultProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.ChoiceBoxSkin;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @DefaultProperty("items")
/*     */ public class ChoiceBox<T>
/*     */   extends Control
/*     */ {
/*  97 */   public static final EventType<Event> ON_SHOWING = new EventType<>(Event.ANY, "CHOICE_BOX_ON_SHOWING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public static final EventType<Event> ON_SHOWN = new EventType<>(Event.ANY, "CHOICE_BOX_ON_SHOWN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public static final EventType<Event> ON_HIDING = new EventType<>(Event.ANY, "CHOICE_BOX_ON_HIDING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public static final EventType<Event> ON_HIDDEN = new EventType<>(Event.ANY, "CHOICE_BOX_ON_HIDDEN");
/*     */   private ObjectProperty<SingleSelectionModel<T>> selectionModel;
/*     */   private ChangeListener<T> selectedItemListener;
/*     */   private ReadOnlyBooleanWrapper showing;
/*     */   private ObjectProperty<ObservableList<T>> items;
/*     */   private final ListChangeListener<T> itemsListener;
/*     */   private ObjectProperty<StringConverter<T>> converter;
/*     */   private ObjectProperty<T> value;
/*     */   private ObjectProperty<EventHandler<ActionEvent>> onAction;
/*     */   private ObjectProperty<EventHandler<Event>> onShowing;
/*     */   private ObjectProperty<EventHandler<Event>> onShown;
/*     */   private ObjectProperty<EventHandler<Event>> onHiding;
/*     */   private ObjectProperty<EventHandler<Event>> onHidden;
/*     */   
/*     */   public ChoiceBox() {
/* 133 */     this(FXCollections.observableArrayList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBox(ObservableList<T> paramObservableList) {
/* 173 */     this.selectionModel = (ObjectProperty)new SimpleObjectProperty<SingleSelectionModel<SingleSelectionModel<T>>>(this, "selectionModel")
/*     */       {
/* 175 */         private SelectionModel<T> oldSM = null;
/*     */         protected void invalidated() {
/* 177 */           if (this.oldSM != null) {
/* 178 */             this.oldSM.selectedItemProperty().removeListener(ChoiceBox.this.selectedItemListener);
/*     */           }
/* 180 */           SingleSelectionModel<T> singleSelectionModel = get();
/* 181 */           this.oldSM = singleSelectionModel;
/* 182 */           if (singleSelectionModel != null) {
/* 183 */             singleSelectionModel.selectedItemProperty().addListener(ChoiceBox.this.selectedItemListener);
/* 184 */             if (singleSelectionModel.getSelectedItem() != null && !ChoiceBox.this.valueProperty().isBound()) {
/* 185 */               ChoiceBox.this.setValue(singleSelectionModel.getSelectedItem());
/*     */             }
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 191 */     this.selectedItemListener = ((paramObservableValue, paramObject1, paramObject2) -> {
/*     */         if (!valueProperty().isBound()) {
/*     */           setValue((T)paramObject2);
/*     */         }
/*     */       });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     this.showing = new ReadOnlyBooleanWrapper() {
/*     */         protected void invalidated() {
/* 210 */           ChoiceBox.this.pseudoClassStateChanged(ChoiceBox.SHOWING_PSEUDOCLASS_STATE, get());
/* 211 */           ChoiceBox.this.notifyAccessibleAttributeChanged(AccessibleAttribute.EXPANDED);
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 216 */           return ChoiceBox.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 221 */           return "showing";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     this.items = (ObjectProperty)new ObjectPropertyBase<ObservableList<ObservableList<T>>>() { ObservableList<T> old;
/*     */         
/*     */         protected void invalidated() {
/* 242 */           ObservableList<T> observableList = get();
/* 243 */           if (this.old != observableList) {
/*     */             
/* 245 */             if (this.old != null) this.old.removeListener(ChoiceBox.this.itemsListener); 
/* 246 */             if (observableList != null) observableList.addListener(ChoiceBox.this.itemsListener);
/*     */             
/* 248 */             SingleSelectionModel singleSelectionModel = ChoiceBox.this.getSelectionModel();
/* 249 */             if (singleSelectionModel != null) {
/* 250 */               if (observableList != null && observableList.isEmpty()) {
/*     */                 
/* 252 */                 singleSelectionModel.clearSelection();
/* 253 */               } else if (singleSelectionModel.getSelectedIndex() == -1 && singleSelectionModel.getSelectedItem() != null) {
/* 254 */                 int i = ChoiceBox.this.getItems().indexOf(singleSelectionModel.getSelectedItem());
/* 255 */                 if (i != -1)
/* 256 */                   singleSelectionModel.setSelectedIndex(i); 
/*     */               } else {
/* 258 */                 singleSelectionModel.clearSelection();
/*     */               } 
/*     */             }
/*     */             
/* 262 */             this.old = observableList;
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 268 */           return ChoiceBox.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 273 */           return "items";
/*     */         } }
/*     */       ;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 280 */     this.itemsListener = (paramChange -> {
/*     */         SingleSelectionModel<T> singleSelectionModel = getSelectionModel();
/*     */ 
/*     */ 
/*     */         
/*     */         if (singleSelectionModel != null) {
/*     */           if (getItems() == null || getItems().isEmpty()) {
/*     */             singleSelectionModel.clearSelection();
/*     */           } else {
/*     */             int i = getItems().indexOf(singleSelectionModel.getSelectedItem());
/*     */ 
/*     */ 
/*     */             
/*     */             singleSelectionModel.setSelectedIndex(i);
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         if (singleSelectionModel != null) {
/*     */           T t = singleSelectionModel.getSelectedItem();
/*     */ 
/*     */           
/*     */           while (paramChange.next()) {
/*     */             if (t != null && paramChange.getRemoved().contains(t)) {
/*     */               singleSelectionModel.clearSelection();
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       });
/*     */ 
/*     */     
/* 315 */     this.converter = new SimpleObjectProperty<>(this, "converter", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     this.value = new SimpleObjectProperty<T>(this, "value") {
/*     */         protected void invalidated() {
/* 331 */           super.invalidated();
/* 332 */           ChoiceBox.this.fireEvent(new ActionEvent());
/*     */           
/* 334 */           SingleSelectionModel<T> singleSelectionModel = ChoiceBox.this.getSelectionModel();
/* 335 */           if (singleSelectionModel != null) {
/* 336 */             singleSelectionModel.select(getValue());
/*     */           }
/* 338 */           ChoiceBox.this.notifyAccessibleAttributeChanged(AccessibleAttribute.TEXT);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 358 */     this.onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
/*     */         protected void invalidated() {
/* 360 */           ChoiceBox.this.setEventHandler((EventType)ActionEvent.ACTION, (EventHandler)get());
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 365 */           return ChoiceBox.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 370 */           return "onAction";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 384 */     this.onShowing = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 386 */           ChoiceBox.this.setEventHandler((EventType)ChoiceBox.ON_SHOWING, (EventHandler)get());
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 390 */           return ChoiceBox.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 394 */           return "onShowing";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 408 */     this.onShown = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 410 */           ChoiceBox.this.setEventHandler((EventType)ChoiceBox.ON_SHOWN, (EventHandler)get());
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 414 */           return ChoiceBox.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 418 */           return "onShown";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 432 */     this.onHiding = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 434 */           ChoiceBox.this.setEventHandler((EventType)ChoiceBox.ON_HIDING, (EventHandler)get());
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 438 */           return ChoiceBox.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 442 */           return "onHiding";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 456 */     this.onHidden = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 458 */           ChoiceBox.this.setEventHandler((EventType)ChoiceBox.ON_HIDDEN, (EventHandler)get());
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 462 */           return ChoiceBox.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 466 */           return "onHidden";
/*     */         }
/*     */       }; getStyleClass().setAll(new String[] { "choice-box" }); setAccessibleRole(AccessibleRole.COMBO_BOX); setItems(paramObservableList); setSelectionModel(new ChoiceBoxSelectionModel<>(this)); valueProperty().addListener((paramObservableValue, paramObject1, paramObject2) -> {
/*     */           if (getItems() == null)
/*     */             return;  int i = getItems().indexOf(paramObject2);
/*     */           if (i > -1)
/*     */             getSelectionModel().select(i); 
/*     */         });
/*     */   }
/*     */   public final void setSelectionModel(SingleSelectionModel<T> paramSingleSelectionModel) { this.selectionModel.set(paramSingleSelectionModel); }
/*     */   public final SingleSelectionModel<T> getSelectionModel() { return this.selectionModel.get(); }
/*     */   public final ObjectProperty<SingleSelectionModel<T>> selectionModelProperty() { return this.selectionModel; }
/*     */   public final boolean isShowing() { return this.showing.get(); } public final ReadOnlyBooleanProperty showingProperty() { return this.showing.getReadOnlyProperty(); } private void setShowing(boolean paramBoolean) { Event.fireEvent(this, paramBoolean ? new Event(ON_SHOWING) : new Event(ON_HIDING));
/*     */     this.showing.set(paramBoolean);
/* 480 */     Event.fireEvent(this, paramBoolean ? new Event(ON_SHOWN) : new Event(ON_HIDDEN)); } public final void setItems(ObservableList<T> paramObservableList) { this.items.set(paramObservableList); } public void show() { if (!isDisabled()) setShowing(true);  }
/*     */   public final ObservableList<T> getItems() { return this.items.get(); }
/*     */   public final ObjectProperty<ObservableList<T>> itemsProperty() { return this.items; }
/*     */   public ObjectProperty<StringConverter<T>> converterProperty() { return this.converter; }
/*     */   public final void setConverter(StringConverter<T> paramStringConverter) { converterProperty().set(paramStringConverter); }
/*     */   public final StringConverter<T> getConverter() { return converterProperty().get(); }
/*     */   public ObjectProperty<T> valueProperty() { return this.value; }
/* 487 */   public final void setValue(T paramT) { valueProperty().set(paramT); } public final T getValue() { return valueProperty().get(); } public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() { return this.onAction; } public final void setOnAction(EventHandler<ActionEvent> paramEventHandler) { onActionProperty().set(paramEventHandler); } public final EventHandler<ActionEvent> getOnAction() { return onActionProperty().get(); } public final ObjectProperty<EventHandler<Event>> onShowingProperty() { return this.onShowing; } public final void setOnShowing(EventHandler<Event> paramEventHandler) { onShowingProperty().set(paramEventHandler); } public final EventHandler<Event> getOnShowing() { return onShowingProperty().get(); } public final ObjectProperty<EventHandler<Event>> onShownProperty() { return this.onShown; } public final void setOnShown(EventHandler<Event> paramEventHandler) { onShownProperty().set(paramEventHandler); } public final EventHandler<Event> getOnShown() { return onShownProperty().get(); } public final ObjectProperty<EventHandler<Event>> onHidingProperty() { return this.onHiding; } public final void setOnHiding(EventHandler<Event> paramEventHandler) { onHidingProperty().set(paramEventHandler); } public final EventHandler<Event> getOnHiding() { return onHidingProperty().get(); } public final ObjectProperty<EventHandler<Event>> onHiddenProperty() { return this.onHidden; } public final void setOnHidden(EventHandler<Event> paramEventHandler) { onHiddenProperty().set(paramEventHandler); } public final EventHandler<Event> getOnHidden() { return onHiddenProperty().get(); } public void hide() { setShowing(false); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 492 */     return (Skin<?>)new ChoiceBoxSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 502 */   private static final PseudoClass SHOWING_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("showing");
/*     */   
/*     */   static class ChoiceBoxSelectionModel<T>
/*     */     extends SingleSelectionModel<T> {
/*     */     private final ChoiceBox<T> choiceBox;
/*     */     
/*     */     public ChoiceBoxSelectionModel(ChoiceBox<T> param1ChoiceBox) {
/* 509 */       if (param1ChoiceBox == null) {
/* 510 */         throw new NullPointerException("ChoiceBox can not be null");
/*     */       }
/* 512 */       this.choiceBox = param1ChoiceBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 524 */       ListChangeListener listChangeListener = param1Change -> {
/*     */           if (this.choiceBox.getItems() == null || this.choiceBox.getItems().isEmpty()) {
/*     */             setSelectedIndex(-1);
/*     */           } else if (getSelectedIndex() == -1 && getSelectedItem() != null) {
/*     */             int i = this.choiceBox.getItems().indexOf(getSelectedItem());
/*     */             if (i != -1) {
/*     */               setSelectedIndex(i);
/*     */             }
/*     */           } 
/*     */         };
/* 534 */       if (this.choiceBox.getItems() != null) {
/* 535 */         this.choiceBox.getItems().addListener(listChangeListener);
/*     */       }
/*     */ 
/*     */       
/* 539 */       ChangeListener changeListener = (param1ObservableValue, param1ObservableList1, param1ObservableList2) -> {
/*     */           if (param1ObservableList1 != null) {
/*     */             param1ObservableList1.removeListener(param1ListChangeListener);
/*     */           }
/*     */           if (param1ObservableList2 != null) {
/*     */             param1ObservableList2.addListener(param1ListChangeListener);
/*     */           }
/*     */           setSelectedIndex(-1);
/*     */           if (getSelectedItem() != null) {
/*     */             int i = this.choiceBox.getItems().indexOf(getSelectedItem());
/*     */             if (i != -1) {
/*     */               setSelectedIndex(i);
/*     */             }
/*     */           } 
/*     */         };
/* 554 */       this.choiceBox.itemsProperty().addListener(changeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected T getModelItem(int param1Int) {
/* 559 */       ObservableList<T> observableList = this.choiceBox.getItems();
/* 560 */       if (observableList == null) return null; 
/* 561 */       if (param1Int < 0 || param1Int >= observableList.size()) return null; 
/* 562 */       return observableList.get(param1Int);
/*     */     }
/*     */     
/*     */     protected int getItemCount() {
/* 566 */       ObservableList<T> observableList = this.choiceBox.getItems();
/* 567 */       return (observableList == null) ? 0 : observableList.size();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void select(int param1Int) {
/* 579 */       super.select(param1Int);
/*     */       
/* 581 */       if (this.choiceBox.isShowing()) {
/* 582 */         this.choiceBox.hide();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void selectPrevious() {
/* 589 */       int i = getSelectedIndex() - 1;
/* 590 */       while (i >= 0) {
/* 591 */         T t = getModelItem(i);
/* 592 */         if (t instanceof Separator) {
/* 593 */           i--; continue;
/*     */         } 
/* 595 */         select(i);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void selectNext() {
/* 604 */       int i = getSelectedIndex() + 1;
/* 605 */       while (i < getItemCount()) {
/* 606 */         T t = getModelItem(i);
/* 607 */         if (t instanceof Separator) {
/* 608 */           i++; continue;
/*     */         } 
/* 610 */         select(i);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*     */     String str;
/*     */     Object object;
/*     */     StringConverter<T> stringConverter;
/* 626 */     switch (paramAccessibleAttribute) {
/*     */       case COLLAPSE:
/* 628 */         str = getAccessibleText();
/* 629 */         if (str != null && !str.isEmpty()) return str;
/*     */ 
/*     */         
/* 632 */         object = super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 633 */         if (object != null) return object; 
/* 634 */         stringConverter = getConverter();
/* 635 */         if (stringConverter == null) {
/* 636 */           return (getValue() != null) ? getValue().toString() : "";
/*     */         }
/* 638 */         return stringConverter.toString(getValue());
/* 639 */       case EXPAND: return Boolean.valueOf(isShowing());
/* 640 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/* 647 */     switch (paramAccessibleAction) { case COLLAPSE:
/* 648 */         hide(); return;
/* 649 */       case EXPAND: show(); return; }
/* 650 */      super.executeAccessibleAction(paramAccessibleAction, new Object[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ChoiceBox.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */