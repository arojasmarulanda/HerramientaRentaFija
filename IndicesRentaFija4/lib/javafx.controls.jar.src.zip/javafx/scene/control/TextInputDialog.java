/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.layout.GridPane;
/*     */ import javafx.scene.layout.Priority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextInputDialog
/*     */   extends Dialog<String>
/*     */ {
/*     */   private final GridPane grid;
/*     */   private final Label label;
/*     */   private final TextField textField;
/*     */   private final String defaultValue;
/*     */   
/*     */   public TextInputDialog() {
/*  68 */     this("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextInputDialog(@NamedArg("defaultValue") String paramString) {
/*  77 */     DialogPane dialogPane = getDialogPane();
/*     */ 
/*     */     
/*  80 */     this.textField = new TextField(paramString);
/*  81 */     this.textField.setMaxWidth(Double.MAX_VALUE);
/*  82 */     GridPane.setHgrow(this.textField, Priority.ALWAYS);
/*  83 */     GridPane.setFillWidth(this.textField, Boolean.valueOf(true));
/*     */ 
/*     */     
/*  86 */     this.label = DialogPane.createContentLabel(dialogPane.getContentText());
/*  87 */     this.label.setPrefWidth(-1.0D);
/*  88 */     this.label.textProperty().bind(dialogPane.contentTextProperty());
/*     */     
/*  90 */     this.defaultValue = paramString;
/*     */     
/*  92 */     this.grid = new GridPane();
/*  93 */     this.grid.setHgap(10.0D);
/*  94 */     this.grid.setMaxWidth(Double.MAX_VALUE);
/*  95 */     this.grid.setAlignment(Pos.CENTER_LEFT);
/*     */     
/*  97 */     dialogPane.contentTextProperty().addListener(paramObservable -> updateGrid());
/*     */     
/*  99 */     setTitle(ControlResources.getString("Dialog.confirm.title"));
/* 100 */     dialogPane.setHeaderText(ControlResources.getString("Dialog.confirm.header"));
/* 101 */     dialogPane.getStyleClass().add("text-input-dialog");
/* 102 */     dialogPane.getButtonTypes().addAll(new ButtonType[] { ButtonType.OK, ButtonType.CANCEL });
/*     */     
/* 104 */     updateGrid();
/*     */     
/* 106 */     setResultConverter(paramButtonType -> {
/*     */           ButtonBar.ButtonData buttonData = (paramButtonType == null) ? null : paramButtonType.getButtonData();
/*     */           return (buttonData == ButtonBar.ButtonData.OK_DONE) ? this.textField.getText() : null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextField getEditor() {
/* 125 */     return this.textField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getDefaultValue() {
/* 133 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateGrid() {
/* 145 */     this.grid.getChildren().clear();
/*     */     
/* 147 */     this.grid.add(this.label, 0, 0);
/* 148 */     this.grid.add(this.textField, 1, 0);
/* 149 */     getDialogPane().setContent(this.grid);
/*     */     
/* 151 */     Platform.runLater(() -> this.textField.requestFocus());
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TextInputDialog.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */