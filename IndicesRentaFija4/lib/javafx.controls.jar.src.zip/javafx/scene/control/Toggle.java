package javafx.scene.control;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.collections.ObservableMap;

public interface Toggle {
  ToggleGroup getToggleGroup();
  
  void setToggleGroup(ToggleGroup paramToggleGroup);
  
  ObjectProperty<ToggleGroup> toggleGroupProperty();
  
  boolean isSelected();
  
  void setSelected(boolean paramBoolean);
  
  BooleanProperty selectedProperty();
  
  Object getUserData();
  
  void setUserData(Object paramObject);
  
  ObservableMap<Object, Object> getProperties();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Toggle.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */