/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.application.PlatformImpl;
/*     */ import com.sun.javafx.css.CssError;
/*     */ import com.sun.javafx.css.StyleManager;
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.control.ControlAcceleratorSupport;
/*     */ import com.sun.javafx.scene.control.ControlHelper;
/*     */ import com.sun.javafx.scene.control.Logging;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import javafx.application.Application;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.CssParser;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.StyleableStringProperty;
/*     */ import javafx.css.converter.StringConverter;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.input.ContextMenuEvent;
/*     */ import javafx.scene.layout.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Control
/*     */   extends Region
/*     */   implements Skinnable
/*     */ {
/*     */   private List<CssMetaData<? extends Styleable, ?>> styleableProperties;
/*     */   private SkinBase<?> skinBase;
/*     */   private static final EventHandler<ContextMenuEvent> contextMenuHandler;
/*     */   
/*     */   static {
/*  86 */     ControlHelper.setControlAccessor(new ControlHelper.ControlAccessor()
/*     */         {
/*     */           public void doProcessCSS(Node param1Node) {
/*  89 */             ((Control)param1Node).doProcessCSS();
/*     */           }
/*     */           
/*     */           public StringProperty skinClassNameProperty(Control param1Control) {
/*  93 */             return param1Control.skinClassNameProperty();
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*  98 */     if (Application.getUserAgentStylesheet() == null) {
/*  99 */       PlatformImpl.setDefaultPlatformUserAgentStylesheet();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     contextMenuHandler = (paramContextMenuEvent -> {
/*     */         if (paramContextMenuEvent.isConsumed())
/*     */           return; 
/*     */         Object object = paramContextMenuEvent.getSource();
/*     */         if (object instanceof Control) {
/*     */           Control control = (Control)object;
/*     */           if (control.getContextMenu() != null) {
/*     */             control.getContextMenu().show(control, paramContextMenuEvent.getScreenX(), paramContextMenuEvent.getScreenY());
/*     */             paramContextMenuEvent.consume();
/*     */           } 
/*     */         } 
/*     */       });
/*     */   }
/*     */   private static Class<?> loadClass(String paramString, Object paramObject) throws ClassNotFoundException {
/*     */     try {
/*     */       return Class.forName(paramString, false, Control.class.getClassLoader());
/*     */     } catch (ClassNotFoundException classNotFoundException) {
/*     */       if (Thread.currentThread().getContextClassLoader() != null)
/*     */         try {
/*     */           ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */           return Class.forName(paramString, false, classLoader);
/*     */         } catch (ClassNotFoundException classNotFoundException1) {} 
/*     */       if (paramObject != null) {
/*     */         Class<?> clazz = paramObject.getClass();
/*     */         while (clazz != null) {
/*     */           try {
/*     */             ClassLoader classLoader = clazz.getClassLoader();
/*     */             return Class.forName(paramString, false, classLoader);
/*     */           } catch (ClassNotFoundException classNotFoundException1) {
/*     */             clazz = clazz.getSuperclass();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       throw classNotFoundException;
/*     */     } 
/*     */   }
/*     */   public final ObjectProperty<Skin<?>> skinProperty() {
/* 228 */     return this.skin;
/*     */   } public final void setSkin(Skin<?> paramSkin) {
/* 230 */     skinProperty().set(paramSkin);
/*     */   } public final Skin<?> getSkin() {
/* 232 */     return skinProperty().getValue();
/* 233 */   } private ObjectProperty<Skin<?>> skin = new StyleableObjectProperty<Skin<?>>()
/*     */     {
/*     */       private Skin<?> oldValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void set(Skin<?> param1Skin) {
/* 245 */         if ((param1Skin == null) ? (this.oldValue == null) : (this.oldValue != null && param1Skin
/*     */           
/* 247 */           .getClass().equals(this.oldValue.getClass()))) {
/*     */           return;
/*     */         }
/* 250 */         super.set(param1Skin);
/*     */       }
/*     */       
/*     */       protected void invalidated() {
/* 254 */         Skin<?> skin = get();
/*     */ 
/*     */ 
/*     */         
/* 258 */         Control.this.currentSkinClassName = (skin == null) ? null : skin.getClass().getName();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 263 */         Control.this.skinClassNameProperty().set(Control.this.currentSkinClassName);
/*     */ 
/*     */ 
/*     */         
/* 267 */         if (this.oldValue != null) this.oldValue.dispose();
/*     */ 
/*     */         
/* 270 */         this.oldValue = skin;
/*     */ 
/*     */ 
/*     */         
/* 274 */         Control.this.skinBase = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 283 */         if (skin instanceof SkinBase) {
/*     */ 
/*     */           
/* 286 */           Control.this.skinBase = (SkinBase)skin;
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 296 */           Node node = Control.this.getSkinNode();
/* 297 */           if (node != null) {
/* 298 */             Control.this.getChildren().setAll(new Node[] { node });
/*     */           } else {
/* 300 */             Control.this.getChildren().clear();
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 306 */         Control.this.styleableProperties = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 313 */         NodeHelper.reapplyCSS(Control.this);
/*     */ 
/*     */         
/* 316 */         PlatformLogger platformLogger = Logging.getControlsLogger();
/* 317 */         if (platformLogger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 318 */           platformLogger.finest("Stored skin[" + getValue() + "] on " + this);
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public CssMetaData getCssMetaData() {
/* 328 */         return Control.StyleableProperties.SKIN;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 333 */         return Control.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 338 */         return "skin";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<Tooltip> tooltip;
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<Tooltip> tooltipProperty() {
/* 349 */     if (this.tooltip == null) {
/* 350 */       this.tooltip = new ObjectPropertyBase<Tooltip>() {
/* 351 */           private Tooltip old = null;
/*     */           protected void invalidated() {
/* 353 */             Tooltip tooltip = get();
/*     */             
/* 355 */             if (tooltip != this.old) {
/* 356 */               if (this.old != null) {
/* 357 */                 Tooltip.uninstall(Control.this, this.old);
/*     */               }
/* 359 */               if (tooltip != null) {
/* 360 */                 Tooltip.install(Control.this, tooltip);
/*     */               }
/* 362 */               this.old = tooltip;
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 368 */             return Control.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 373 */             return "tooltip";
/*     */           }
/*     */         };
/*     */     }
/* 377 */     return this.tooltip;
/*     */   }
/*     */   
/* 380 */   public final void setTooltip(Tooltip paramTooltip) { tooltipProperty().setValue(paramTooltip); } public final Tooltip getTooltip() {
/* 381 */     return (this.tooltip == null) ? null : this.tooltip.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 388 */   private ObjectProperty<ContextMenu> contextMenu = new SimpleObjectProperty<ContextMenu>(this, "contextMenu") {
/*     */       private WeakReference<ContextMenu> contextMenuRef;
/*     */       
/*     */       protected void invalidated() {
/* 392 */         ContextMenu contextMenu1 = (this.contextMenuRef == null) ? null : this.contextMenuRef.get();
/* 393 */         if (contextMenu1 != null) {
/* 394 */           ControlAcceleratorSupport.removeAcceleratorsFromScene(contextMenu1.getItems(), Control.this);
/*     */         }
/*     */         
/* 397 */         ContextMenu contextMenu2 = get();
/* 398 */         this.contextMenuRef = new WeakReference<>(contextMenu2);
/*     */         
/* 400 */         if (contextMenu2 != null) {
/*     */           
/* 402 */           contextMenu2.setShowRelativeToWindow(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 408 */           ControlAcceleratorSupport.addAcceleratorsIntoScene(contextMenu2.getItems(), Control.this);
/*     */         } 
/*     */       }
/*     */     }; private String currentSkinClassName; private StringProperty skinClassName; private boolean skinCreationLocked;
/* 412 */   public final ObjectProperty<ContextMenu> contextMenuProperty() { return this.contextMenu; }
/* 413 */   public final void setContextMenu(ContextMenu paramContextMenu) { this.contextMenu.setValue(paramContextMenu); } public final ContextMenu getContextMenu() {
/* 414 */     return (this.contextMenu == null) ? null : this.contextMenu.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Control() {
/* 426 */     ControlHelper.initHelper(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 661 */     this.currentSkinClassName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 883 */     this.skinCreationLocked = false; StyleableProperty<Boolean> styleableProperty = (StyleableProperty)focusTraversableProperty(); styleableProperty.applyStyle(null, Boolean.TRUE); addEventHandler(ContextMenuEvent.CONTEXT_MENU_REQUESTED, contextMenuHandler);
/*     */   } public boolean isResizable() { return true; } protected double computeMinWidth(double paramDouble) { if (this.skinBase != null) return this.skinBase.computeMinWidth(paramDouble, snappedTopInset(), snappedRightInset(), snappedBottomInset(), snappedLeftInset());  Node node = getSkinNode(); return (node == null) ? 0.0D : node.minWidth(paramDouble); } protected double computeMinHeight(double paramDouble) { if (this.skinBase != null) return this.skinBase.computeMinHeight(paramDouble, snappedTopInset(), snappedRightInset(), snappedBottomInset(), snappedLeftInset());  Node node = getSkinNode(); return (node == null) ? 0.0D : node.minHeight(paramDouble); } protected double computeMaxWidth(double paramDouble) { if (this.skinBase != null) return this.skinBase.computeMaxWidth(paramDouble, snappedTopInset(), snappedRightInset(), snappedBottomInset(), snappedLeftInset());  Node node = getSkinNode(); return (node == null) ? 0.0D : node.maxWidth(paramDouble); } protected double computeMaxHeight(double paramDouble) { if (this.skinBase != null) return this.skinBase.computeMaxHeight(paramDouble, snappedTopInset(), snappedRightInset(), snappedBottomInset(), snappedLeftInset());  Node node = getSkinNode(); return (node == null) ? 0.0D : node.maxHeight(paramDouble); } protected double computePrefWidth(double paramDouble) { if (this.skinBase != null) return this.skinBase.computePrefWidth(paramDouble, snappedTopInset(), snappedRightInset(), snappedBottomInset(), snappedLeftInset());  Node node = getSkinNode(); return (node == null) ? 0.0D : node.prefWidth(paramDouble); } protected double computePrefHeight(double paramDouble) { if (this.skinBase != null) return this.skinBase.computePrefHeight(paramDouble, snappedTopInset(), snappedRightInset(), snappedBottomInset(), snappedLeftInset());  Node node = getSkinNode(); return (node == null) ? 0.0D : node.prefHeight(paramDouble); } public double getBaselineOffset() { if (this.skinBase != null) return this.skinBase.computeBaselineOffset(snappedTopInset(), snappedRightInset(), snappedBottomInset(), snappedLeftInset());  Node node = getSkinNode(); return (node == null) ? 0.0D : node.getBaselineOffset(); }
/*     */   protected void layoutChildren() { if (this.skinBase != null) { double d1 = snappedLeftInset(); double d2 = snappedTopInset(); double d3 = snapSizeX(getWidth()) - d1 - snappedRightInset(); double d4 = snapSizeY(getHeight()) - d2 - snappedBottomInset(); this.skinBase.layoutChildren(d1, d2, d3, d4); } else { Node node = getSkinNode(); if (node != null) node.resizeRelocate(0.0D, 0.0D, getWidth(), getHeight());  }  }
/* 886 */   private void doProcessCSS() { ControlHelper.superProcessCSS(this);
/*     */     
/* 888 */     if (getSkin() == null) {
/* 889 */       if (this.skinCreationLocked) {
/*     */         return;
/*     */       }
/*     */       
/*     */       try {
/* 894 */         this.skinCreationLocked = true;
/*     */ 
/*     */         
/* 897 */         Skin<?> skin = createDefaultSkin();
/* 898 */         if (skin != null) {
/* 899 */           skinProperty().set(skin);
/* 900 */           ControlHelper.superProcessCSS(this);
/*     */         } else {
/* 902 */           String str = "The -fx-skin property has not been defined in CSS for " + this + " and createDefaultSkin() returned null.";
/*     */           
/* 904 */           ObservableList<CssError> observableList = StyleManager.getErrors();
/* 905 */           if (observableList != null) {
/* 906 */             CssParser.ParseError parseError = new CssParser.ParseError(str);
/* 907 */             observableList.add(parseError);
/*     */           } 
/* 909 */           Logging.getControlsLogger().severe(str);
/*     */         } 
/*     */       } finally {
/* 912 */         this.skinCreationLocked = false;
/*     */       } 
/*     */     }  } protected Skin<?> createDefaultSkin() { return null; }
/*     */   ObservableList<Node> getControlChildren() { return getChildren(); }
/*     */   private Node getSkinNode() { assert this.skinBase == null; Skin<?> skin = getSkin(); return (skin == null) ? null : skin.getNode(); }
/*     */   StringProperty skinClassNameProperty() { if (this.skinClassName == null)
/*     */       this.skinClassName = new StyleableStringProperty() { public void set(String param1String) { if (param1String == null || param1String.isEmpty() || param1String.equals(get()))
/*     */               return;  super.set(param1String); }
/*     */           public void invalidated() { if (get() != null && !get().equals(Control.this.currentSkinClassName))
/*     */               Control.loadSkinClass(Control.this, Control.this.skinClassName.get());  }
/*     */           public Object getBean() { return Control.this; }
/*     */           public String getName() { return "skinClassName"; }
/*     */           public CssMetaData<Control, String> getCssMetaData() { return Control.StyleableProperties.SKIN; } }
/*     */         ; 
/*     */     return this.skinClassName; }
/* 927 */   protected Boolean getInitialFocusTraversable() { return Boolean.TRUE; }
/*     */   static void loadSkinClass(Skinnable paramSkinnable, String paramString) { if (paramString == null || paramString.isEmpty()) { String str = "Empty -fx-skin property specified for control " + paramSkinnable; ObservableList<CssError> observableList = StyleManager.getErrors(); if (observableList != null) { CssParser.ParseError parseError = new CssParser.ParseError(str); observableList.add(parseError); }  Logging.getControlsLogger().severe(str); return; }  try { Class<?> clazz = loadClass(paramString, paramSkinnable); if (!Skin.class.isAssignableFrom(clazz)) { String str = "'" + paramString + "' is not a valid Skin class for control " + paramSkinnable; ObservableList<CssError> observableList = StyleManager.getErrors(); if (observableList != null) { CssParser.ParseError parseError = new CssParser.ParseError(str); observableList.add(parseError); }
/*     */          Logging.getControlsLogger().severe(str); return; }
/*     */        Constructor[] arrayOfConstructor = (Constructor[])clazz.getConstructors(); Constructor<Skin> constructor = null; for (Constructor constructor1 : arrayOfConstructor) { Class[] arrayOfClass = constructor1.getParameterTypes(); if (arrayOfClass.length == 1 && Skinnable.class.isAssignableFrom(arrayOfClass[0])) { constructor = constructor1; break; }
/*     */          }
/*     */        if (constructor == null) { String str = "No valid constructor defined in '" + paramString + "' for control " + paramSkinnable + ".\r\nYou must provide a constructor that accepts a single Skinnable (e.g. Control or PopupControl) parameter in " + paramString + "."; ObservableList<CssError> observableList = StyleManager.getErrors(); if (observableList != null) { CssParser.ParseError parseError = new CssParser.ParseError(str); observableList.add(parseError); }
/*     */          Logging.getControlsLogger().severe(str); }
/*     */       else { Skin<?> skin = constructor.newInstance(new Object[] { paramSkinnable }); paramSkinnable.skinProperty().set(skin); }
/*     */        }
/*     */     catch (InvocationTargetException invocationTargetException) { String str = "Failed to load skin '" + paramString + "' for control " + paramSkinnable; ObservableList<CssError> observableList = StyleManager.getErrors(); if (observableList != null) { CssParser.ParseError parseError = new CssParser.ParseError(str + " :" + str); observableList.add(parseError); }
/*     */        Logging.getControlsLogger().severe(str, invocationTargetException.getCause()); }
/*     */     catch (Exception exception) { String str = "Failed to load skin '" + paramString + "' for control " + paramSkinnable; ObservableList<CssError> observableList = StyleManager.getErrors(); if (observableList != null) { CssParser.ParseError parseError = new CssParser.ParseError(str + " :" + str); observableList.add(parseError); }
/*     */        Logging.getControlsLogger().severe(str, exception); }
/* 940 */      } public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) { String str; Tooltip tooltip; switch (paramAccessibleAttribute) {
/*     */       case HELP:
/* 942 */         str = getAccessibleHelp();
/* 943 */         if (str != null && !str.isEmpty()) return str; 
/* 944 */         tooltip = getTooltip();
/* 945 */         return (tooltip == null) ? "" : tooltip.getText();
/*     */     } 
/*     */     
/* 948 */     if (this.skinBase != null) {
/* 949 */       Object object = this.skinBase.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 950 */       if (object != null) return object; 
/*     */     } 
/* 952 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs); }
/*     */   private static class StyleableProperties {
/*     */     private static final CssMetaData<Control, String> SKIN = new CssMetaData<Control, String>("-fx-skin", StringConverter.getInstance()) { public boolean isSettable(Control param2Control) { return (param2Control.skin == null || !param2Control.skin.isBound()); }
/*     */         public StyleableProperty<String> getStyleableProperty(Control param2Control) { return (StyleableProperty<String>)param2Control.skinClassNameProperty(); } }
/*     */     ;
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES; static { ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Region.getClassCssMetaData()); arrayList.add(SKIN); STYLEABLES = Collections.unmodifiableList(arrayList); }
/* 958 */   } public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() { return StyleableProperties.STYLEABLES; } public final List<CssMetaData<? extends Styleable, ?>> getCssMetaData() { if (this.styleableProperties == null) { HashMap<Object, Object> hashMap = new HashMap<>(); List<CssMetaData<? extends Styleable, ?>> list = getControlCssMetaData(); byte b1, b2; for (b1 = 0, b2 = (list != null) ? list.size() : 0; b1 < b2; b1++) { CssMetaData cssMetaData = list.get(b1); if (cssMetaData != null) hashMap.put(cssMetaData.getProperty(), cssMetaData);  }  list = (this.skinBase != null) ? this.skinBase.getCssMetaData() : null; for (b1 = 0, b2 = (list != null) ? list.size() : 0; b1 < b2; b1++) { CssMetaData cssMetaData = list.get(b1); if (cssMetaData != null) hashMap.put(cssMetaData.getProperty(), cssMetaData);  }  this.styleableProperties = new ArrayList<>(); this.styleableProperties.addAll(hashMap.values()); }  return this.styleableProperties; } protected List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() { return getClassCssMetaData(); } public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) { if (this.skinBase != null) {
/* 959 */       this.skinBase.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */     }
/* 961 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs); }
/*     */ 
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Control.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */