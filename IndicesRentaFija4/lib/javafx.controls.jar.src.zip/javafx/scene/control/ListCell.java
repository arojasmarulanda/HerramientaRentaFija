/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.beans.value.WeakChangeListener;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.ListCellSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListCell<T>
/*     */   extends IndexedCell<T>
/*     */ {
/*     */   private final InvalidationListener editingListener;
/*     */   private boolean updateEditingIndex;
/*     */   private final ListChangeListener<Integer> selectedListener;
/*     */   private final ChangeListener<MultipleSelectionModel<T>> selectionModelPropertyListener;
/*     */   private final ListChangeListener<T> itemsListener;
/*     */   private final InvalidationListener itemsPropertyListener;
/*     */   private final InvalidationListener focusedListener;
/*     */   private final ChangeListener<FocusModel<T>> focusModelPropertyListener;
/*     */   private final WeakInvalidationListener weakEditingListener;
/*     */   private final WeakListChangeListener<Integer> weakSelectedListener;
/*     */   private final WeakChangeListener<MultipleSelectionModel<T>> weakSelectionModelPropertyListener;
/*     */   private final WeakListChangeListener<T> weakItemsListener;
/*     */   private final WeakInvalidationListener weakItemsPropertyListener;
/*     */   private final WeakInvalidationListener weakFocusedListener;
/*     */   private final WeakChangeListener<FocusModel<T>> weakFocusModelPropertyListener;
/*     */   private ReadOnlyObjectWrapper<ListView<T>> listView;
/*     */   private boolean firstRun;
/*     */   private static final String DEFAULT_STYLE_CLASS = "list-cell";
/*     */   
/*     */   public ListCell() {
/* 108 */     this.editingListener = (paramObservable -> updateEditing());
/*     */ 
/*     */     
/* 111 */     this.updateEditingIndex = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     this.selectedListener = (paramChange -> updateSelection());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     this.selectionModelPropertyListener = (ChangeListener)new ChangeListener<MultipleSelectionModel<MultipleSelectionModel<T>>>()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void changed(ObservableValue<? extends MultipleSelectionModel<T>> param1ObservableValue, MultipleSelectionModel<T> param1MultipleSelectionModel1, MultipleSelectionModel<T> param1MultipleSelectionModel2)
/*     */         {
/* 132 */           if (param1MultipleSelectionModel1 != null) {
/* 133 */             param1MultipleSelectionModel1.getSelectedIndices().removeListener(ListCell.this.weakSelectedListener);
/*     */           }
/*     */           
/* 136 */           if (param1MultipleSelectionModel2 != null) {
/* 137 */             param1MultipleSelectionModel2.getSelectedIndices().addListener(ListCell.this.weakSelectedListener);
/*     */           }
/*     */           
/* 140 */           ListCell.this.updateSelection();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     this.itemsListener = (paramChange -> {
/*     */         boolean bool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 164 */         for (bool = false; paramChange.next(); bool = (bool3 || (bool1 && !paramChange.wasReplaced() && (paramChange.wasRemoved() || paramChange.wasAdded()))) ? true : false) {
/*     */           int i = getIndex();
/*     */           ListView<T> listView = getListView();
/*     */           ObservableList<T> observableList = (listView == null) ? null : listView.getItems();
/*     */           byte b = (observableList == null) ? 0 : observableList.size();
/*     */           boolean bool1 = (i >= paramChange.getFrom()) ? true : false;
/*     */           boolean bool2 = (i < paramChange.getTo() || i == b) ? true : false;
/*     */           boolean bool3 = (bool1 && bool2) ? true : false;
/*     */         } 
/*     */         if (bool)
/*     */           updateItem(-1); 
/*     */       });
/* 176 */     this.itemsPropertyListener = new InvalidationListener() {
/* 177 */         private WeakReference<ObservableList<T>> weakItemsRef = new WeakReference<>(null);
/*     */         
/*     */         public void invalidated(Observable param1Observable) {
/* 180 */           ObservableList observableList = this.weakItemsRef.get();
/* 181 */           if (observableList != null) {
/* 182 */             observableList.removeListener(ListCell.this.weakItemsListener);
/*     */           }
/*     */           
/* 185 */           ListView<T> listView = ListCell.this.getListView();
/* 186 */           ObservableList<T> observableList1 = (listView == null) ? null : listView.getItems();
/* 187 */           this.weakItemsRef = new WeakReference<>(observableList1);
/*     */           
/* 189 */           if (observableList1 != null) {
/* 190 */             observableList1.addListener(ListCell.this.weakItemsListener);
/*     */           }
/* 192 */           ListCell.this.updateItem(-1);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     this.focusedListener = (paramObservable -> updateFocus());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     this.focusModelPropertyListener = (ChangeListener)new ChangeListener<FocusModel<FocusModel<T>>>()
/*     */       {
/*     */         public void changed(ObservableValue<? extends FocusModel<T>> param1ObservableValue, FocusModel<T> param1FocusModel1, FocusModel<T> param1FocusModel2)
/*     */         {
/* 212 */           if (param1FocusModel1 != null) {
/* 213 */             param1FocusModel1.focusedIndexProperty().removeListener(ListCell.this.weakFocusedListener);
/*     */           }
/* 215 */           if (param1FocusModel2 != null) {
/* 216 */             param1FocusModel2.focusedIndexProperty().addListener(ListCell.this.weakFocusedListener);
/*     */           }
/* 218 */           ListCell.this.updateFocus();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 223 */     this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
/* 224 */     this.weakSelectedListener = new WeakListChangeListener<>(this.selectedListener);
/* 225 */     this.weakSelectionModelPropertyListener = new WeakChangeListener<>(this.selectionModelPropertyListener);
/* 226 */     this.weakItemsListener = new WeakListChangeListener<>(this.itemsListener);
/* 227 */     this.weakItemsPropertyListener = new WeakInvalidationListener(this.itemsPropertyListener);
/* 228 */     this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
/* 229 */     this.weakFocusModelPropertyListener = new WeakChangeListener<>(this.focusModelPropertyListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 240 */     this.listView = (ReadOnlyObjectWrapper)new ReadOnlyObjectWrapper<ListView<ListView<T>>>(this, "listView")
/*     */       {
/*     */ 
/*     */         
/* 244 */         private WeakReference<ListView<T>> weakListViewRef = new WeakReference<>(null);
/*     */ 
/*     */         
/*     */         protected void invalidated() {
/* 248 */           ListView<T> listView1 = get();
/* 249 */           ListView<T> listView2 = this.weakListViewRef.get();
/*     */ 
/*     */ 
/*     */           
/* 253 */           if (listView1 == listView2) {
/*     */             return;
/*     */           }
/* 256 */           if (listView2 != null) {
/*     */             
/* 258 */             MultipleSelectionModel<T> multipleSelectionModel = listView2.getSelectionModel();
/* 259 */             if (multipleSelectionModel != null) {
/* 260 */               multipleSelectionModel.getSelectedIndices().removeListener(ListCell.this.weakSelectedListener);
/*     */             }
/*     */ 
/*     */             
/* 264 */             FocusModel<T> focusModel = listView2.getFocusModel();
/* 265 */             if (focusModel != null) {
/* 266 */               focusModel.focusedIndexProperty().removeListener(ListCell.this.weakFocusedListener);
/*     */             }
/*     */ 
/*     */             
/* 270 */             ObservableList<T> observableList = listView2.getItems();
/* 271 */             if (observableList != null) {
/* 272 */               observableList.removeListener(ListCell.this.weakItemsListener);
/*     */             }
/*     */ 
/*     */             
/* 276 */             listView2.editingIndexProperty().removeListener(ListCell.this.weakEditingListener);
/* 277 */             listView2.itemsProperty().removeListener(ListCell.this.weakItemsPropertyListener);
/* 278 */             listView2.focusModelProperty().removeListener(ListCell.this.weakFocusModelPropertyListener);
/* 279 */             listView2.selectionModelProperty().removeListener(ListCell.this.weakSelectionModelPropertyListener);
/*     */           } 
/*     */           
/* 282 */           if (listView1 != null) {
/* 283 */             MultipleSelectionModel<T> multipleSelectionModel = listView1.getSelectionModel();
/* 284 */             if (multipleSelectionModel != null) {
/* 285 */               multipleSelectionModel.getSelectedIndices().addListener(ListCell.this.weakSelectedListener);
/*     */             }
/*     */             
/* 288 */             FocusModel<T> focusModel = listView1.getFocusModel();
/* 289 */             if (focusModel != null) {
/* 290 */               focusModel.focusedIndexProperty().addListener(ListCell.this.weakFocusedListener);
/*     */             }
/*     */             
/* 293 */             ObservableList<T> observableList = listView1.getItems();
/* 294 */             if (observableList != null) {
/* 295 */               observableList.addListener(ListCell.this.weakItemsListener);
/*     */             }
/*     */             
/* 298 */             listView1.editingIndexProperty().addListener(ListCell.this.weakEditingListener);
/* 299 */             listView1.itemsProperty().addListener(ListCell.this.weakItemsPropertyListener);
/* 300 */             listView1.focusModelProperty().addListener(ListCell.this.weakFocusModelPropertyListener);
/* 301 */             listView1.selectionModelProperty().addListener(ListCell.this.weakSelectionModelPropertyListener);
/*     */             
/* 303 */             this.weakListViewRef = new WeakReference<>(listView1);
/*     */           } 
/*     */           
/* 306 */           ListCell.this.updateItem(-1);
/* 307 */           ListCell.this.updateSelection();
/* 308 */           ListCell.this.updateFocus();
/* 309 */           ListCell.this.requestLayout();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 451 */     this.firstRun = true; getStyleClass().addAll(new String[] { "list-cell" }); setAccessibleRole(AccessibleRole.LIST_ITEM);
/*     */   } private void setListView(ListView<T> paramListView) { this.listView.set(paramListView); } public final ListView<T> getListView() { return this.listView.get(); } public final ReadOnlyObjectProperty<ListView<T>> listViewProperty() { return this.listView.getReadOnlyProperty(); } void indexChanged(int paramInt1, int paramInt2) { super.indexChanged(paramInt1, paramInt2); if (!isEditing() || paramInt2 != paramInt1) { updateItem(paramInt1); updateSelection(); updateFocus(); }  }
/* 453 */   private void updateItem(int paramInt) { ListView<T> listView = getListView();
/* 454 */     ObservableList<T> observableList = (listView == null) ? null : listView.getItems();
/* 455 */     int i = getIndex();
/* 456 */     byte b = (observableList == null) ? -1 : observableList.size();
/*     */ 
/*     */     
/* 459 */     boolean bool = (observableList != null && i >= 0 && i < b) ? true : false;
/*     */     
/* 461 */     T t = getItem();
/* 462 */     boolean bool1 = isEmpty();
/*     */ 
/*     */     
/* 465 */     if (bool) {
/* 466 */       T t1 = observableList.get(i);
/*     */ 
/*     */ 
/*     */       
/* 470 */       if (paramInt != i || 
/* 471 */         isItemChanged(t, t1))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 478 */         updateItem(t1, false);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 486 */     else if ((!bool1 && t != null) || this.firstRun) {
/* 487 */       updateItem((T)null, true);
/* 488 */       this.firstRun = false;
/*     */     }  }
/*     */   protected Skin<?> createDefaultSkin() {
/*     */     return (Skin<?>)new ListCellSkin(this);
/*     */   } public void startEdit() {
/*     */     ListView<T> listView = getListView();
/*     */     if (!isEditable() || (listView != null && !listView.isEditable()))
/*     */       return; 
/*     */     super.startEdit();
/*     */     if (listView != null) {
/*     */       listView.fireEvent(new ListView.EditEvent<>(listView, (EventType)ListView.editStartEvent(), null, getIndex()));
/*     */       listView.edit(getIndex());
/*     */       listView.requestFocus();
/*     */     } 
/* 502 */   } public final void updateListView(ListView<T> paramListView) { setListView(paramListView); }
/*     */   public void commitEdit(T paramT) { if (!isEditing()) return;  ListView<T> listView = getListView(); if (listView != null) listView.fireEvent(new ListView.EditEvent<>(listView, (EventType)ListView.editCommitEvent(), paramT, listView.getEditingIndex()));  super.commitEdit(paramT); updateItem(paramT, false); if (listView != null) { listView.edit(-1); ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(listView); }  }
/*     */   public void cancelEdit() { if (!isEditing())
/*     */       return;  ListView<T> listView = getListView(); super.cancelEdit(); if (listView != null) { int i = listView.getEditingIndex(); if (this.updateEditingIndex)
/* 506 */         listView.edit(-1);  ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(listView); listView.fireEvent(new ListView.EditEvent<>(listView, (EventType)ListView.editCancelEvent(), null, i)); }  } private void updateSelection() { if (isEmpty())
/* 507 */       return;  int i = getIndex();
/* 508 */     ListView<T> listView = getListView();
/* 509 */     if (i == -1 || listView == null)
/*     */       return; 
/* 511 */     MultipleSelectionModel<T> multipleSelectionModel = listView.getSelectionModel();
/* 512 */     if (multipleSelectionModel == null) {
/* 513 */       updateSelected(false);
/*     */       
/*     */       return;
/*     */     } 
/* 517 */     boolean bool = multipleSelectionModel.isSelected(i);
/* 518 */     if (isSelected() == bool)
/*     */       return; 
/* 520 */     updateSelected(bool); }
/*     */ 
/*     */   
/*     */   private void updateFocus() {
/* 524 */     int i = getIndex();
/* 525 */     ListView<T> listView = getListView();
/* 526 */     if (i == -1 || listView == null)
/*     */       return; 
/* 528 */     FocusModel<T> focusModel = listView.getFocusModel();
/* 529 */     if (focusModel == null) {
/* 530 */       setFocused(false);
/*     */       
/*     */       return;
/*     */     } 
/* 534 */     setFocused(focusModel.isFocused(i));
/*     */   }
/*     */   
/*     */   private void updateEditing() {
/* 538 */     int i = getIndex();
/* 539 */     ListView<T> listView = getListView();
/* 540 */     byte b = (listView == null) ? -1 : listView.getEditingIndex();
/* 541 */     boolean bool = isEditing();
/*     */ 
/*     */     
/* 544 */     if (i != -1 && listView != null)
/*     */     {
/*     */       
/* 547 */       if (i == b && !bool) {
/* 548 */         startEdit();
/* 549 */       } else if (i != b && bool) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 556 */         this.updateEditingIndex = false;
/* 557 */         cancelEdit();
/* 558 */         this.updateEditingIndex = true;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 584 */     switch (paramAccessibleAttribute) { case REQUEST_FOCUS:
/* 585 */         return Integer.valueOf(getIndex());
/* 586 */       case null: return Boolean.valueOf(isSelected()); }
/* 587 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     ListView<T> listView;
/* 594 */     switch (paramAccessibleAction) {
/*     */       case REQUEST_FOCUS:
/* 596 */         listView = getListView();
/* 597 */         if (listView != null) {
/* 598 */           FocusModel<T> focusModel = listView.getFocusModel();
/* 599 */           if (focusModel != null) {
/* 600 */             focusModel.focus(getIndex());
/*     */           }
/*     */         } 
/*     */         return;
/*     */     } 
/* 605 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ListCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */