/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.property.SimpleStringProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ComboBoxBase<T>
/*     */   extends Control
/*     */ {
/*  85 */   public static final EventType<Event> ON_SHOWING = new EventType<>(Event.ANY, "COMBO_BOX_BASE_ON_SHOWING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public static final EventType<Event> ON_SHOWN = new EventType<>(Event.ANY, "COMBO_BOX_BASE_ON_SHOWN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static final EventType<Event> ON_HIDING = new EventType<>(Event.ANY, "COMBO_BOX_BASE_ON_HIDING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public static final EventType<Event> ON_HIDDEN = new EventType<>(Event.ANY, "COMBO_BOX_BASE_ON_HIDDEN");
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectProperty<T> value;
/*     */ 
/*     */ 
/*     */   
/*     */   private BooleanProperty editable;
/*     */ 
/*     */ 
/*     */   
/*     */   private ReadOnlyBooleanWrapper showing;
/*     */ 
/*     */ 
/*     */   
/*     */   private StringProperty promptText;
/*     */ 
/*     */ 
/*     */   
/*     */   private BooleanProperty armed;
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<ActionEvent>> onAction;
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<Event>> onShowing;
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<Event>> onShown;
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<Event>> onHiding;
/*     */ 
/*     */   
/*     */   private ObjectProperty<EventHandler<Event>> onHidden;
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_STYLE_CLASS = "combo-box-base";
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxBase() {
/* 149 */     this.value = new SimpleObjectProperty<>(this, "value");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     this.editable = new SimpleBooleanProperty(this, "editable", false) {
/*     */         protected void invalidated() {
/* 170 */           ComboBoxBase.this.pseudoClassStateChanged(ComboBoxBase.PSEUDO_CLASS_EDITABLE, get());
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     this.promptText = new SimpleStringProperty(this, "promptText", null)
/*     */       {
/*     */         protected void invalidated() {
/* 226 */           String str = get();
/* 227 */           if (str != null && str.contains("\n")) {
/* 228 */             str = str.replace("\n", "");
/* 229 */             set(str);
/*     */           } 
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 251 */     this.armed = new SimpleBooleanProperty(this, "armed", false) {
/*     */         protected void invalidated() {
/* 253 */           ComboBoxBase.this.pseudoClassStateChanged(ComboBoxBase.PSEUDO_CLASS_ARMED, get());
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 272 */     this.onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
/*     */         protected void invalidated() {
/* 274 */           ComboBoxBase.this.setEventHandler((EventType)ActionEvent.ACTION, (EventHandler)get());
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 279 */           return ComboBoxBase.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 284 */           return "onAction";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 297 */     this.onShowing = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 299 */           ComboBoxBase.this.setEventHandler((EventType)ComboBoxBase.ON_SHOWING, (EventHandler)get());
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 303 */           return ComboBoxBase.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 307 */           return "onShowing";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     this.onShown = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 322 */           ComboBoxBase.this.setEventHandler((EventType)ComboBoxBase.ON_SHOWN, (EventHandler)get());
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 326 */           return ComboBoxBase.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 330 */           return "onShown";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 343 */     this.onHiding = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 345 */           ComboBoxBase.this.setEventHandler((EventType)ComboBoxBase.ON_HIDING, (EventHandler)get());
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 349 */           return ComboBoxBase.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 353 */           return "onHiding";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 366 */     this.onHidden = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 368 */           ComboBoxBase.this.setEventHandler((EventType)ComboBoxBase.ON_HIDDEN, (EventHandler)get());
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 372 */           return ComboBoxBase.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 376 */           return "onHidden";
/*     */         }
/*     */       };
/*     */     getStyleClass().add("combo-box-base");
/*     */     getProperties().addListener(paramChange -> {
/*     */           if (paramChange.wasAdded() && paramChange.getKey() == "FOCUSED") {
/*     */             setFocused(((Boolean)paramChange.getValueAdded()).booleanValue());
/*     */             getProperties().remove("FOCUSED");
/*     */           } 
/*     */         });
/*     */   }
/*     */   public ObjectProperty<T> valueProperty() { return this.value; }
/*     */   public final void setValue(T paramT) { valueProperty().set(paramT); }
/*     */   public final T getValue() { return valueProperty().get(); }
/*     */   public BooleanProperty editableProperty() { return this.editable; } public final void setEditable(boolean paramBoolean) { editableProperty().set(paramBoolean); } public final boolean isEditable() {
/*     */     return editableProperty().get();
/*     */   } public ReadOnlyBooleanProperty showingProperty() {
/*     */     return showingPropertyImpl().getReadOnlyProperty();
/* 394 */   } public void show() { if (!isDisabled())
/* 395 */       setShowing(true);  }
/*     */   public final boolean isShowing() { return showingPropertyImpl().get(); }
/*     */   private void setShowing(boolean paramBoolean) { Event.fireEvent(this, paramBoolean ? new Event(ON_SHOWING) : new Event(ON_HIDING)); showingPropertyImpl().set(paramBoolean); Event.fireEvent(this, paramBoolean ? new Event(ON_SHOWN) : new Event(ON_HIDDEN)); }
/*     */   private ReadOnlyBooleanWrapper showingPropertyImpl() { if (this.showing == null) this.showing = new ReadOnlyBooleanWrapper(false) {
/*     */           protected void invalidated() { ComboBoxBase.this.pseudoClassStateChanged(ComboBoxBase.PSEUDO_CLASS_SHOWING, get()); ComboBoxBase.this.notifyAccessibleAttributeChanged(AccessibleAttribute.EXPANDED); }
/*     */           public Object getBean() { return ComboBoxBase.this; }
/*     */           public String getName() { return "showing"; }
/*     */         };  return this.showing; }
/* 403 */   public final StringProperty promptTextProperty() { return this.promptText; } public final String getPromptText() { return this.promptText.get(); } public final void setPromptText(String paramString) { this.promptText.set(paramString); } public BooleanProperty armedProperty() { return this.armed; } private final void setArmed(boolean paramBoolean) { armedProperty().set(paramBoolean); } public final boolean isArmed() { return armedProperty().get(); } public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() { return this.onAction; } public final void setOnAction(EventHandler<ActionEvent> paramEventHandler) { onActionProperty().set(paramEventHandler); } public final EventHandler<ActionEvent> getOnAction() { return onActionProperty().get(); } public final ObjectProperty<EventHandler<Event>> onShowingProperty() { return this.onShowing; } public final void setOnShowing(EventHandler<Event> paramEventHandler) { onShowingProperty().set(paramEventHandler); } public final EventHandler<Event> getOnShowing() { return onShowingProperty().get(); } public final ObjectProperty<EventHandler<Event>> onShownProperty() { return this.onShown; } public final void setOnShown(EventHandler<Event> paramEventHandler) { onShownProperty().set(paramEventHandler); } public final EventHandler<Event> getOnShown() { return onShownProperty().get(); } public final ObjectProperty<EventHandler<Event>> onHidingProperty() { return this.onHiding; } public final void setOnHiding(EventHandler<Event> paramEventHandler) { onHidingProperty().set(paramEventHandler); } public final EventHandler<Event> getOnHiding() { return onHidingProperty().get(); } public final ObjectProperty<EventHandler<Event>> onHiddenProperty() { return this.onHidden; } public final void setOnHidden(EventHandler<Event> paramEventHandler) { onHiddenProperty().set(paramEventHandler); } public final EventHandler<Event> getOnHidden() { return onHiddenProperty().get(); } public void hide() { if (isShowing()) {
/* 404 */       setShowing(false);
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void arm() {
/* 417 */     if (!armedProperty().isBound()) {
/* 418 */       setArmed(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disarm() {
/* 430 */     if (!armedProperty().isBound()) {
/* 431 */       setArmed(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 445 */   private static final PseudoClass PSEUDO_CLASS_EDITABLE = PseudoClass.getPseudoClass("editable");
/*     */   
/* 447 */   private static final PseudoClass PSEUDO_CLASS_SHOWING = PseudoClass.getPseudoClass("showing");
/*     */   
/* 449 */   private static final PseudoClass PSEUDO_CLASS_ARMED = PseudoClass.getPseudoClass("armed");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 461 */     switch (paramAccessibleAttribute) { case EXPAND:
/* 462 */         return Boolean.valueOf(isShowing());
/* 463 */       case COLLAPSE: return Boolean.valueOf(isEditable()); }
/* 464 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/* 471 */     switch (paramAccessibleAction) { case EXPAND:
/* 472 */         show(); return;
/* 473 */       case COLLAPSE: hide(); return; }
/* 474 */      super.executeAccessibleAction(paramAccessibleAction, new Object[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ComboBoxBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */