/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ButtonBase
/*     */   extends Labeled
/*     */ {
/*     */   public ButtonBase(String paramString) {
/*  68 */     super(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ButtonBase(String paramString, Node paramNode) {
/*  77 */     super(paramString, paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ReadOnlyBooleanProperty armedProperty() {
/*  96 */     return this.armed.getReadOnlyProperty();
/*  97 */   } private void setArmed(boolean paramBoolean) { this.armed.set(paramBoolean); } public final boolean isArmed() {
/*  98 */     return armedProperty().get();
/*  99 */   } private ReadOnlyBooleanWrapper armed = new ReadOnlyBooleanWrapper() {
/*     */       protected void invalidated() {
/* 101 */         ButtonBase.this.pseudoClassStateChanged(ButtonBase.ARMED_PSEUDOCLASS_STATE, get());
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 106 */         return ButtonBase.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 111 */         return "armed";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() {
/* 123 */     return this.onAction;
/* 124 */   } public final void setOnAction(EventHandler<ActionEvent> paramEventHandler) { onActionProperty().set(paramEventHandler); } public final EventHandler<ActionEvent> getOnAction() {
/* 125 */     return onActionProperty().get();
/* 126 */   } private ObjectProperty<EventHandler<ActionEvent>> onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
/*     */       protected void invalidated() {
/* 128 */         ButtonBase.this.setEventHandler((EventType)ActionEvent.ACTION, (EventHandler)get());
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getBean() {
/* 133 */         return ButtonBase.this;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getName() {
/* 138 */         return "onAction";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void arm() {
/* 160 */     setArmed(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disarm() {
/* 171 */     setArmed(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   private static final PseudoClass ARMED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("armed");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/* 202 */     switch (paramAccessibleAction) {
/*     */       case FIRE:
/* 204 */         fire(); return;
/*     */     } 
/* 206 */     super.executeAccessibleAction(paramAccessibleAction, new Object[0]);
/*     */   }
/*     */   
/*     */   public ButtonBase() {}
/*     */   
/*     */   public abstract void fire();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ButtonBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */