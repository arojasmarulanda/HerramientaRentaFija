/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.control.FakeFocusTextField;
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.LocalDate;
/*     */ import java.time.chrono.Chronology;
/*     */ import java.time.chrono.IsoChronology;
/*     */ import java.time.format.FormatStyle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.DatePickerSkin;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ import javafx.util.converter.LocalDateStringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatePicker
/*     */   extends ComboBoxBase<LocalDate>
/*     */ {
/* 107 */   private LocalDate lastValidDate = null;
/* 108 */   private Chronology lastValidChronology = IsoChronology.INSTANCE; private ObjectProperty<Callback<DatePicker, DateCell>> dayCellFactory; private ObjectProperty<Chronology> chronology; private BooleanProperty showWeekNumbers; private ObjectProperty<StringConverter<LocalDate>> converter;
/*     */   private StringConverter<LocalDate> defaultConverter;
/*     */   private ReadOnlyObjectWrapper<TextField> editor;
/*     */   private static final String DEFAULT_STYLE_CLASS = "date-picker";
/*     */   
/*     */   public DatePicker() {
/* 114 */     this((LocalDate)null);
/*     */     
/* 116 */     valueProperty().addListener(paramObservable -> {
/*     */           LocalDate localDate = getValue();
/*     */           
/*     */           Chronology chronology = getChronology();
/*     */           
/*     */           if (validateDate(chronology, localDate)) {
/*     */             this.lastValidDate = localDate;
/*     */           } else {
/*     */             System.err.println("Restoring value to " + ((this.lastValidDate == null) ? "null" : getConverter().toString(this.lastValidDate)));
/*     */             
/*     */             setValue(this.lastValidDate);
/*     */           } 
/*     */         });
/* 129 */     chronologyProperty().addListener(paramObservable -> {
/*     */           LocalDate localDate = getValue();
/*     */           Chronology chronology = getChronology();
/*     */           if (validateDate(chronology, localDate)) {
/*     */             this.lastValidChronology = chronology;
/*     */             this.defaultConverter = new LocalDateStringConverter(FormatStyle.SHORT, null, chronology);
/*     */           } else {
/*     */             System.err.println("Restoring value to " + this.lastValidChronology);
/*     */             setChronology(this.lastValidChronology);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean validateDate(Chronology paramChronology, LocalDate paramLocalDate) {
/*     */     try {
/* 145 */       if (paramLocalDate != null) {
/* 146 */         paramChronology.date(paramLocalDate);
/*     */       }
/* 148 */       return true;
/* 149 */     } catch (DateTimeException dateTimeException) {
/* 150 */       System.err.println(dateTimeException);
/* 151 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setDayCellFactory(Callback<DatePicker, DateCell> paramCallback) {
/* 208 */     dayCellFactoryProperty().set(paramCallback);
/*     */   }
/*     */   public final Callback<DatePicker, DateCell> getDayCellFactory() {
/* 211 */     return (this.dayCellFactory != null) ? this.dayCellFactory.get() : null;
/*     */   }
/*     */   public final ObjectProperty<Callback<DatePicker, DateCell>> dayCellFactoryProperty() {
/* 214 */     if (this.dayCellFactory == null) {
/* 215 */       this.dayCellFactory = new SimpleObjectProperty<>(this, "dayCellFactory");
/*     */     }
/* 217 */     return this.dayCellFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<Chronology> chronologyProperty() {
/* 237 */     return this.chronology;
/*     */   }
/* 239 */   public DatePicker(LocalDate paramLocalDate) { this.chronology = new SimpleObjectProperty<>(this, "chronology", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 394 */     this.converter = new SimpleObjectProperty<>(this, "converter", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 407 */     this
/* 408 */       .defaultConverter = new LocalDateStringConverter(FormatStyle.SHORT, null, getChronology()); setValue(paramLocalDate); getStyleClass().add("date-picker"); setAccessibleRole(AccessibleRole.DATE_PICKER); setEditable(true); }
/*     */   public final Chronology getChronology() { Chronology chronology = this.chronology.get(); if (chronology == null) { try { chronology = Chronology.ofLocale(Locale.getDefault(Locale.Category.FORMAT)); } catch (Exception exception) { System.err.println(exception); }
/*     */        if (chronology == null)
/*     */         chronology = IsoChronology.INSTANCE;  }
/*     */      return chronology; }
/*     */   public final void setChronology(Chronology paramChronology) { this.chronology.setValue(paramChronology); }
/*     */   public final BooleanProperty showWeekNumbersProperty() { if (this.showWeekNumbers == null) { String str = Locale.getDefault(Locale.Category.FORMAT).getCountry(); boolean bool = (!str.isEmpty() && ControlResources.getNonTranslatableString("DatePicker.showWeekNumbers").contains(str)) ? true : false; this.showWeekNumbers = new StyleableBooleanProperty(bool) {
/*     */           public CssMetaData<DatePicker, Boolean> getCssMetaData() { return DatePicker.StyleableProperties.SHOW_WEEK_NUMBERS; }
/*     */           public Object getBean() { return DatePicker.this; }
/*     */           public String getName() { return "showWeekNumbers"; }
/*     */         }; }
/* 419 */      return this.showWeekNumbers; } public final void setShowWeekNumbers(boolean paramBoolean) { showWeekNumbersProperty().setValue(Boolean.valueOf(paramBoolean)); } public final TextField getEditor() { return editorProperty().get(); }
/*     */   public final boolean isShowWeekNumbers() { return showWeekNumbersProperty().getValue().booleanValue(); }
/*     */   public final ObjectProperty<StringConverter<LocalDate>> converterProperty() { return this.converter; }
/* 422 */   public final void setConverter(StringConverter<LocalDate> paramStringConverter) { converterProperty().set(paramStringConverter); } public final StringConverter<LocalDate> getConverter() { StringConverter<LocalDate> stringConverter = converterProperty().get(); if (stringConverter != null) return stringConverter;  return this.defaultConverter; } public final ReadOnlyObjectProperty<TextField> editorProperty() { if (this.editor == null) {
/* 423 */       this.editor = new ReadOnlyObjectWrapper<>(this, "editor");
/* 424 */       this.editor.set(new FakeFocusTextField());
/*     */     } 
/* 426 */     return this.editor.getReadOnlyProperty(); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 431 */     return (Skin<?>)new DatePickerSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 445 */     private static final String country = Locale.getDefault(Locale.Category.FORMAT).getCountry();
/* 446 */     private static final CssMetaData<DatePicker, Boolean> SHOW_WEEK_NUMBERS = new CssMetaData<DatePicker, Boolean>("-fx-show-week-numbers", 
/*     */         
/* 448 */         BooleanConverter.getInstance(), 
/* 449 */         Boolean.valueOf((!country.isEmpty() && 
/* 450 */           ControlResources.getNonTranslatableString("DatePicker.showWeekNumbers").contains(country)))) {
/*     */         public boolean isSettable(DatePicker param2DatePicker) {
/* 452 */           return (param2DatePicker.showWeekNumbers == null || !param2DatePicker.showWeekNumbers.isBound());
/*     */         }
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(DatePicker param2DatePicker) {
/* 456 */           return (StyleableProperty<Boolean>)param2DatePicker.showWeekNumbersProperty();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 464 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 465 */       Collections.addAll(arrayList, (CssMetaData<? extends Styleable, ?>[])new CssMetaData[] { SHOW_WEEK_NUMBERS });
/*     */ 
/*     */       
/* 468 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 477 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 486 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*     */     String str;
/*     */     LocalDate localDate;
/*     */     StringConverter<LocalDate> stringConverter;
/* 498 */     switch (paramAccessibleAttribute) { case DATE:
/* 499 */         return getValue();
/*     */       case TEXT:
/* 501 */         str = getAccessibleText();
/* 502 */         if (str != null && !str.isEmpty()) return str;
/*     */         
/* 504 */         localDate = getValue();
/* 505 */         stringConverter = getConverter();
/* 506 */         if (localDate != null && stringConverter != null) {
/* 507 */           return stringConverter.toString(localDate);
/*     */         }
/* 509 */         return ""; }
/*     */     
/* 511 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\DatePicker.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */