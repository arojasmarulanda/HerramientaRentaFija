/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.beans.IDProperty;
/*     */ import com.sun.javafx.collections.TrackableObservableList;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.skin.ContextMenuSkin;
/*     */ import javafx.stage.Window;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @IDProperty("id")
/*     */ public class ContextMenu
/*     */   extends PopupControl
/*     */ {
/*     */   private boolean showRelativeToWindow = false;
/*     */   private ObjectProperty<EventHandler<ActionEvent>> onAction;
/*     */   private final ObservableList<MenuItem> items;
/*     */   private static final String DEFAULT_STYLE_CLASS = "context-menu";
/*     */   
/*     */   public ContextMenu(MenuItem... paramVarArgs) {
/* 154 */     this();
/* 155 */     this.items.addAll(paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextMenu() {
/* 172 */     this.onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
/*     */         protected void invalidated() {
/* 174 */           ContextMenu.this.setEventHandler((EventType)ActionEvent.ACTION, (EventHandler)get());
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 179 */           return ContextMenu.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 184 */           return "onAction";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     this.items = new TrackableObservableList<MenuItem>() {
/*     */         protected void onChanged(ListChangeListener.Change<MenuItem> param1Change) {
/* 193 */           while (param1Change.next()) {
/* 194 */             for (MenuItem menuItem : param1Change.getRemoved()) {
/* 195 */               menuItem.setParentPopup(null);
/*     */             }
/* 197 */             for (MenuItem menuItem : param1Change.getAddedSubList()) {
/* 198 */               if (menuItem.getParentPopup() != null)
/*     */               {
/*     */ 
/*     */                 
/* 202 */                 menuItem.getParentPopup().getItems().remove(menuItem);
/*     */               }
/* 204 */               menuItem.setParentPopup(ContextMenu.this);
/*     */             } 
/*     */           } 
/*     */         }
/*     */       };
/*     */     getStyleClass().setAll(new String[] { "context-menu" });
/*     */     setAutoHide(true);
/*     */     setConsumeAutoHidingEvents(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOnAction(EventHandler<ActionEvent> paramEventHandler) {
/*     */     onActionProperty().set(paramEventHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<MenuItem> getItems() {
/* 224 */     return this.items;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final EventHandler<ActionEvent> getOnAction() {
/*     */     return onActionProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() {
/*     */     return this.onAction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void show(Node paramNode, Side paramSide, double paramDouble1, double paramDouble2) {
/* 250 */     if (paramNode == null)
/* 251 */       return;  if (getItems().size() == 0)
/*     */       return; 
/* 253 */     getScene().setNodeOrientation(paramNode.getEffectiveNodeOrientation());
/*     */ 
/*     */ 
/*     */     
/* 257 */     HPos hPos = (paramSide == Side.LEFT) ? HPos.LEFT : ((paramSide == Side.RIGHT) ? HPos.RIGHT : HPos.CENTER);
/* 258 */     VPos vPos = (paramSide == Side.TOP) ? VPos.TOP : ((paramSide == Side.BOTTOM) ? VPos.BOTTOM : VPos.CENTER);
/*     */ 
/*     */     
/* 261 */     Point2D point2D = Utils.pointRelativeTo(paramNode, 
/* 262 */         prefWidth(-1.0D), prefHeight(-1.0D), hPos, vPos, paramDouble1, paramDouble2, true);
/*     */     
/* 264 */     doShow(paramNode, point2D.getX(), point2D.getY());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void show(Node paramNode, double paramDouble1, double paramDouble2) {
/* 279 */     if (paramNode == null)
/* 280 */       return;  if (getItems().size() == 0)
/* 281 */       return;  getScene().setNodeOrientation(paramNode.getEffectiveNodeOrientation());
/* 282 */     doShow(paramNode, paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hide() {
/* 292 */     if (!isShowing())
/* 293 */       return;  Event.fireEvent(this, new Event(Menu.ON_HIDING));
/* 294 */     super.hide();
/* 295 */     Event.fireEvent(this, new Event(Menu.ON_HIDDEN));
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 300 */     return (Skin<?>)new ContextMenuSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isShowRelativeToWindow()
/*     */   {
/* 311 */     return this.showRelativeToWindow; } final void setShowRelativeToWindow(boolean paramBoolean) {
/* 312 */     this.showRelativeToWindow = paramBoolean;
/*     */   }
/*     */   private void doShow(Node paramNode, double paramDouble1, double paramDouble2) {
/* 315 */     Event.fireEvent(this, new Event(Menu.ON_SHOWING));
/* 316 */     if (isShowRelativeToWindow()) {
/* 317 */       Scene scene = (paramNode == null) ? null : paramNode.getScene();
/* 318 */       Window window = (scene == null) ? null : scene.getWindow();
/* 319 */       if (window == null)
/* 320 */         return;  show(window, paramDouble1, paramDouble2);
/*     */     } else {
/* 322 */       super.show(paramNode, paramDouble1, paramDouble2);
/*     */     } 
/* 324 */     Event.fireEvent(this, new Event(Menu.ON_SHOWN));
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ContextMenu.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */