/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.beans.IDProperty;
/*     */ import com.sun.javafx.event.EventHandlerManager;
/*     */ import com.sun.javafx.scene.control.ControlAcceleratorSupport;
/*     */ import com.sun.javafx.scene.control.TableColumnBaseHelper;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.text.Collator;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyDoubleProperty;
/*     */ import javafx.beans.property.ReadOnlyDoubleWrapper;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.property.SimpleStringProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.collections.ObservableSet;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.event.EventDispatchChain;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @IDProperty("id")
/*     */ public abstract class TableColumnBase<S, T>
/*     */   implements EventTarget, Styleable
/*     */ {
/*     */   static final double DEFAULT_WIDTH = 80.0D;
/*     */   static final double DEFAULT_MIN_WIDTH = 10.0D;
/*     */   static final double DEFAULT_MAX_WIDTH = 5000.0D;
/*     */   public static final Comparator DEFAULT_COMPARATOR;
/*     */   final EventHandlerManager eventHandlerManager;
/*     */   private StringProperty text;
/*     */   private BooleanProperty visible;
/*     */   private ReadOnlyObjectWrapper<TableColumnBase<S, ?>> parentColumn;
/*     */   private ObjectProperty<ContextMenu> contextMenu;
/*     */   private StringProperty id;
/*     */   private StringProperty style;
/*     */   private final ObservableList<String> styleClass;
/*     */   private ObjectProperty<Node> graphic;
/*     */   private ObjectProperty<Node> sortNode;
/*     */   private ReadOnlyDoubleWrapper width;
/*     */   private DoubleProperty minWidth;
/*     */   private final DoubleProperty prefWidth;
/*     */   private DoubleProperty maxWidth;
/*     */   private BooleanProperty resizable;
/*     */   private BooleanProperty sortable;
/*     */   private BooleanProperty reorderable;
/*     */   private ObjectProperty<Comparator<T>> comparator;
/*     */   private BooleanProperty editable;
/*     */   
/*     */   static {
/* 103 */     TableColumnBaseHelper.setTableColumnBaseAccessor(new TableColumnBaseHelper.TableColumnBaseAccessor()
/*     */         {
/*     */           
/*     */           public void setWidth(TableColumnBase param1TableColumnBase, double param1Double)
/*     */           {
/* 108 */             param1TableColumnBase.doSetWidth(param1Double);
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     DEFAULT_COMPARATOR = ((paramObject1, paramObject2) -> 
/* 133 */       (paramObject1 == null && paramObject2 == null) ? 0 : ((paramObject1 == null) ? -1 : ((paramObject2 == null) ? 1 : (
/*     */ 
/*     */ 
/*     */       
/* 137 */       (paramObject1 instanceof Comparable && (paramObject1.getClass() == paramObject2.getClass() || paramObject1.getClass().isAssignableFrom(paramObject2.getClass()))) ? ((paramObject1 instanceof String) ? Collator.getInstance().compare(paramObject1, paramObject2) : ((Comparable<Object>)paramObject1).compareTo(paramObject2)) : Collator.getInstance().compare(paramObject1.toString(), paramObject2.toString())))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TableColumnBase() {
/* 157 */     this("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TableColumnBase(String paramString) {
/* 185 */     this.eventHandlerManager = new EventHandlerManager(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     this.text = new SimpleStringProperty(this, "text", "");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     this.visible = new SimpleBooleanProperty(this, "visible", true)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         protected void invalidated()
/*     */         {
/* 225 */           for (TableColumnBase tableColumnBase : TableColumnBase.this.getColumns()) {
/* 226 */             tableColumnBase.setVisible(TableColumnBase.this.isVisible());
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 344 */     this.styleClass = FXCollections.observableArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 394 */     this.sortNode = new SimpleObjectProperty<>(this, "sortNode");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 412 */     this.width = new ReadOnlyDoubleWrapper(this, "width", 80.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 446 */     this.prefWidth = new SimpleDoubleProperty(this, "prefWidth", 80.0D) {
/*     */         protected void invalidated() {
/* 448 */           TableColumnBase.this.doSetWidth(TableColumnBase.this.getPrefWidth());
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 463 */     this.maxWidth = new SimpleDoubleProperty(this, "maxWidth", 5000.0D)
/*     */       {
/* 465 */         protected void invalidated() { TableColumnBase.this.doSetWidth(TableColumnBase.this.getWidth()); }
/*     */       }; setText(paramString);
/*     */   }
/*     */   public final StringProperty textProperty() { return this.text; }
/*     */   public final void setText(String paramString) { this.text.set(paramString); }
/*     */   public final String getText() { return this.text.get(); }
/*     */   public final void setVisible(boolean paramBoolean) { visibleProperty().set(paramBoolean); }
/*     */   public final boolean isVisible() { return this.visible.get(); }
/*     */   public final BooleanProperty visibleProperty() { return this.visible; }
/*     */   void setParentColumn(TableColumnBase<S, ?> paramTableColumnBase) { parentColumnPropertyImpl().set(paramTableColumnBase); }
/*     */   public final TableColumnBase<S, ?> getParentColumn() { return (this.parentColumn == null) ? null : this.parentColumn.get(); } public final ReadOnlyObjectProperty<TableColumnBase<S, ?>> parentColumnProperty() { return parentColumnPropertyImpl().getReadOnlyProperty(); } private ReadOnlyObjectWrapper<TableColumnBase<S, ?>> parentColumnPropertyImpl() { if (this.parentColumn == null) this.parentColumn = new ReadOnlyObjectWrapper<>(this, "parentColumn");  return this.parentColumn; } public final void setContextMenu(ContextMenu paramContextMenu) { contextMenuProperty().set(paramContextMenu); } public final ContextMenu getContextMenu() { return (this.contextMenu == null) ? null : this.contextMenu.get(); } public final ObjectProperty<ContextMenu> contextMenuProperty() { if (this.contextMenu == null) this.contextMenu = new SimpleObjectProperty<ContextMenu>(this, "contextMenu") {
/*     */           private WeakReference<ContextMenu> contextMenuRef; protected void invalidated() { ContextMenu contextMenu1 = (this.contextMenuRef == null) ? null : this.contextMenuRef.get(); if (contextMenu1 != null) ControlAcceleratorSupport.removeAcceleratorsFromScene(contextMenu1.getItems(), TableColumnBase.this);  ContextMenu contextMenu2 = get(); this.contextMenuRef = new WeakReference<>(contextMenu2); if (contextMenu2 != null) ControlAcceleratorSupport.addAcceleratorsIntoScene(contextMenu2.getItems(), TableColumnBase.this);  }
/* 477 */         };  return this.contextMenu; } public final void setId(String paramString) { idProperty().set(paramString); } public final String getId() { return (this.id == null) ? null : this.id.get(); } public final StringProperty idProperty() { if (this.id == null) this.id = new SimpleStringProperty(this, "id");  return this.id; } public final void setStyle(String paramString) { styleProperty().set(paramString); } public final String getStyle() { return (this.style == null) ? "" : this.style.get(); } public final StringProperty styleProperty() { if (this.style == null) this.style = new SimpleStringProperty(this, "style");  return this.style; } public final BooleanProperty resizableProperty() { if (this.resizable == null) {
/* 478 */       this.resizable = new SimpleBooleanProperty(this, "resizable", true);
/*     */     }
/* 480 */     return this.resizable; }
/*     */   public ObservableList<String> getStyleClass() { return this.styleClass; } public final void setGraphic(Node paramNode) { graphicProperty().set(paramNode); } public final Node getGraphic() { return (this.graphic == null) ? null : this.graphic.get(); } public final ObjectProperty<Node> graphicProperty() { if (this.graphic == null) this.graphic = new SimpleObjectProperty<>(this, "graphic");  return this.graphic; } public final void setSortNode(Node paramNode) { sortNodeProperty().set(paramNode); } public final Node getSortNode() { return this.sortNode.get(); } public final ObjectProperty<Node> sortNodeProperty() { return this.sortNode; } public final ReadOnlyDoubleProperty widthProperty() { return this.width.getReadOnlyProperty(); } public final double getWidth() { return this.width.get(); } void setWidth(double paramDouble) { this.width.set(paramDouble); } public final void setMinWidth(double paramDouble) { minWidthProperty().set(paramDouble); } public final double getMinWidth() { return (this.minWidth == null) ? 10.0D : this.minWidth.get(); } public final DoubleProperty minWidthProperty() { if (this.minWidth == null) this.minWidth = new SimpleDoubleProperty(this, "minWidth", 10.0D) {
/*     */           protected void invalidated() { if (TableColumnBase.this.getMinWidth() < 0.0D) TableColumnBase.this.setMinWidth(0.0D);  TableColumnBase.this.doSetWidth(TableColumnBase.this.getWidth()); }
/* 483 */         };  return this.minWidth; } public final DoubleProperty prefWidthProperty() { return this.prefWidth; } public final void setPrefWidth(double paramDouble) { prefWidthProperty().set(paramDouble); } public final double getPrefWidth() { return this.prefWidth.get(); } public final DoubleProperty maxWidthProperty() { return this.maxWidth; } public final void setMaxWidth(double paramDouble) { maxWidthProperty().set(paramDouble); } public final double getMaxWidth() { return this.maxWidth.get(); } public final void setResizable(boolean paramBoolean) { resizableProperty().set(paramBoolean); }
/*     */   
/*     */   public final boolean isResizable() {
/* 486 */     return (this.resizable == null) ? true : this.resizable.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BooleanProperty sortableProperty() {
/* 506 */     if (this.sortable == null) {
/* 507 */       this.sortable = new SimpleBooleanProperty(this, "sortable", true);
/*     */     }
/* 509 */     return this.sortable;
/*     */   }
/*     */   public final void setSortable(boolean paramBoolean) {
/* 512 */     sortableProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isSortable() {
/* 515 */     return (this.sortable == null) ? true : this.sortable.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BooleanProperty reorderableProperty() {
/* 532 */     if (this.reorderable == null) {
/* 533 */       this.reorderable = new SimpleBooleanProperty(this, "reorderable", true);
/*     */     }
/* 535 */     return this.reorderable;
/*     */   }
/*     */   public final void setReorderable(boolean paramBoolean) {
/* 538 */     reorderableProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isReorderable() {
/* 541 */     return (this.reorderable == null) ? true : this.reorderable.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<Comparator<T>> comparatorProperty() {
/* 553 */     if (this.comparator == null) {
/* 554 */       this.comparator = new SimpleObjectProperty<>(this, "comparator", DEFAULT_COMPARATOR);
/*     */     }
/* 556 */     return this.comparator;
/*     */   }
/*     */   public final void setComparator(Comparator<T> paramComparator) {
/* 559 */     comparatorProperty().set(paramComparator);
/*     */   }
/*     */   public final Comparator<T> getComparator() {
/* 562 */     return (this.comparator == null) ? DEFAULT_COMPARATOR : this.comparator.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setEditable(boolean paramBoolean) {
/* 574 */     editableProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isEditable() {
/* 577 */     return (this.editable == null) ? true : this.editable.get();
/*     */   }
/*     */   public final BooleanProperty editableProperty() {
/* 580 */     if (this.editable == null) {
/* 581 */       this.editable = new SimpleBooleanProperty(this, "editable", true);
/*     */     }
/* 583 */     return this.editable;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 588 */   private static final Object USER_DATA_KEY = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObservableMap<Object, Object> properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableMap<Object, Object> getProperties() {
/* 601 */     if (this.properties == null) {
/* 602 */       this.properties = FXCollections.observableMap(new HashMap<>());
/*     */     }
/* 604 */     return this.properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProperties() {
/* 612 */     return (this.properties != null && !this.properties.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserData(Object paramObject) {
/* 627 */     getProperties().put(USER_DATA_KEY, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getUserData() {
/* 638 */     return getProperties().get(USER_DATA_KEY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T getCellData(int paramInt) {
/* 673 */     ObservableValue<T> observableValue = getCellObservableValue(paramInt);
/* 674 */     return (observableValue == null) ? null : observableValue.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T getCellData(S paramS) {
/* 685 */     ObservableValue<T> observableValue = getCellObservableValue(paramS);
/* 686 */     return (observableValue == null) ? null : observableValue.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventDispatchChain buildEventDispatchChain(EventDispatchChain paramEventDispatchChain) {
/* 731 */     return paramEventDispatchChain.prepend(this.eventHandlerManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends javafx.event.Event> void addEventHandler(EventType<E> paramEventType, EventHandler<E> paramEventHandler) {
/* 746 */     this.eventHandlerManager.addEventHandler(paramEventType, paramEventHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends javafx.event.Event> void removeEventHandler(EventType<E> paramEventType, EventHandler<E> paramEventHandler) {
/* 761 */     this.eventHandlerManager.removeEventHandler(paramEventType, paramEventHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doSetWidth(double paramDouble) {
/* 773 */     setWidth(Utils.boundedSize(paramDouble, getMinWidth(), getMaxWidth()));
/*     */   }
/*     */   
/*     */   void updateColumnWidths() {
/* 777 */     if (!getColumns().isEmpty()) {
/*     */ 
/*     */ 
/*     */       
/* 781 */       double d1 = 0.0D;
/* 782 */       double d2 = 0.0D;
/* 783 */       double d3 = 0.0D;
/*     */       
/* 785 */       for (TableColumnBase<S, ?> tableColumnBase : getColumns()) {
/* 786 */         tableColumnBase.setParentColumn(this);
/*     */         
/* 788 */         d1 += tableColumnBase.getMinWidth();
/* 789 */         d2 += tableColumnBase.getPrefWidth();
/* 790 */         d3 += tableColumnBase.getMaxWidth();
/*     */       } 
/*     */       
/* 793 */       setMinWidth(d1);
/* 794 */       setPrefWidth(d2);
/* 795 */       setMaxWidth(d3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableSet<PseudoClass> getPseudoClassStates() {
/* 810 */     return FXCollections.emptyObservableSet();
/*     */   }
/*     */   
/*     */   public abstract ObservableList<? extends TableColumnBase<S, ?>> getColumns();
/*     */   
/*     */   public abstract ObservableValue<T> getCellObservableValue(int paramInt);
/*     */   
/*     */   public abstract ObservableValue<T> getCellObservableValue(S paramS);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TableColumnBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */