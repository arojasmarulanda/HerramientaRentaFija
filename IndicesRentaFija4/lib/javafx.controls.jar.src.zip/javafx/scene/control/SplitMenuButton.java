/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.SplitMenuButtonSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SplitMenuButton
/*     */   extends MenuButton
/*     */ {
/*     */   private static final String DEFAULT_STYLE_CLASS = "split-menu-button";
/*     */   
/*     */   public SplitMenuButton() {
/*  86 */     this((MenuItem[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SplitMenuButton(MenuItem... paramVarArgs) {
/*  95 */     if (paramVarArgs != null) {
/*  96 */       getItems().addAll(paramVarArgs);
/*     */     }
/*     */     
/*  99 */     getStyleClass().setAll(new String[] { "split-menu-button" });
/* 100 */     setAccessibleRole(AccessibleRole.SPLIT_MENU_BUTTON);
/* 101 */     setMnemonicParsing(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fire() {
/* 113 */     if (!isDisabled()) {
/* 114 */       fireEvent(new ActionEvent());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 126 */     return (Skin<?>)new SplitMenuButtonSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 148 */     switch (paramAccessibleAttribute) { case FIRE:
/* 149 */         return Boolean.valueOf(isShowing()); }
/* 150 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/* 157 */     switch (paramAccessibleAction) {
/*     */       case FIRE:
/* 159 */         fire();
/*     */         return;
/*     */       case EXPAND:
/* 162 */         show();
/*     */         return;
/*     */       case COLLAPSE:
/* 165 */         hide(); return;
/*     */     } 
/* 167 */     super.executeAccessibleAction(paramAccessibleAction, new Object[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\SplitMenuButton.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */