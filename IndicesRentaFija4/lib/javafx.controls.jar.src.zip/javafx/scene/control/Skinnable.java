package javafx.scene.control;

import javafx.beans.property.ObjectProperty;

public interface Skinnable {
  ObjectProperty<Skin<?>> skinProperty();
  
  void setSkin(Skin<?> paramSkin);
  
  Skin<?> getSkin();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Skinnable.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */