/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.ParentHelper;
/*     */ import com.sun.javafx.scene.traversal.ParentTraversalEngine;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.ToggleButtonSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToggleButton
/*     */   extends ButtonBase
/*     */   implements Toggle
/*     */ {
/*     */   private BooleanProperty selected;
/*     */   private ObjectProperty<ToggleGroup> toggleGroup;
/*     */   private static final String DEFAULT_STYLE_CLASS = "toggle-button";
/*     */   
/*     */   public ToggleButton() {
/* 104 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ToggleButton(String paramString) {
/* 113 */     setText(paramString);
/* 114 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ToggleButton(String paramString, Node paramNode) {
/* 124 */     setText(paramString);
/* 125 */     setGraphic(paramNode);
/* 126 */     initialize();
/*     */   }
/*     */   
/*     */   private void initialize() {
/* 130 */     getStyleClass().setAll(new String[] { "toggle-button" });
/* 131 */     setAccessibleRole(AccessibleRole.TOGGLE_BUTTON);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     ((StyleableProperty<Pos>)alignmentProperty()).applyStyle(null, Pos.CENTER);
/* 137 */     setMnemonicParsing(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSelected(boolean paramBoolean) {
/* 150 */     selectedProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isSelected() {
/* 154 */     return (this.selected == null) ? false : this.selected.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty selectedProperty() {
/* 158 */     if (this.selected == null) {
/* 159 */       this.selected = new BooleanPropertyBase() {
/*     */           protected void invalidated() {
/* 161 */             boolean bool = get();
/* 162 */             ToggleGroup toggleGroup = ToggleButton.this.getToggleGroup();
/*     */ 
/*     */             
/* 165 */             ToggleButton.this.pseudoClassStateChanged(ToggleButton.PSEUDO_CLASS_SELECTED, bool);
/* 166 */             ToggleButton.this.notifyAccessibleAttributeChanged(AccessibleAttribute.SELECTED);
/* 167 */             if (toggleGroup != null) {
/* 168 */               if (bool) {
/* 169 */                 toggleGroup.selectToggle(ToggleButton.this);
/* 170 */               } else if (toggleGroup.getSelectedToggle() == ToggleButton.this) {
/* 171 */                 toggleGroup.clearSelectedToggle();
/*     */               } 
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 178 */             return ToggleButton.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 183 */             return "selected";
/*     */           }
/*     */         };
/*     */     }
/* 187 */     return this.selected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setToggleGroup(ToggleGroup paramToggleGroup) {
/* 197 */     toggleGroupProperty().set(paramToggleGroup);
/*     */   }
/*     */   
/*     */   public final ToggleGroup getToggleGroup() {
/* 201 */     return (this.toggleGroup == null) ? null : this.toggleGroup.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<ToggleGroup> toggleGroupProperty() {
/* 205 */     if (this.toggleGroup == null) {
/* 206 */       this.toggleGroup = new ObjectPropertyBase<ToggleGroup>()
/*     */         {
/*     */           private ToggleGroup old;
/*     */           private ChangeListener<Toggle> listener;
/*     */           
/*     */           protected void invalidated() {
/* 212 */             ToggleGroup toggleGroup = get();
/* 213 */             if (toggleGroup != null && !toggleGroup.getToggles().contains(ToggleButton.this)) {
/* 214 */               if (this.old != null) {
/* 215 */                 this.old.getToggles().remove(ToggleButton.this);
/*     */               }
/* 217 */               toggleGroup.getToggles().add(ToggleButton.this);
/* 218 */               ParentTraversalEngine parentTraversalEngine = new ParentTraversalEngine(ToggleButton.this);
/* 219 */               ParentHelper.setTraversalEngine(ToggleButton.this, parentTraversalEngine);
/*     */               
/* 221 */               parentTraversalEngine.setOverriddenFocusTraversability((toggleGroup.getSelectedToggle() != null) ? Boolean.valueOf(ToggleButton.this.isSelected()) : null);
/* 222 */               toggleGroup.selectedToggleProperty().addListener(this.listener);
/* 223 */             } else if (toggleGroup == null) {
/* 224 */               this.old.selectedToggleProperty().removeListener(this.listener);
/* 225 */               this.old.getToggles().remove(ToggleButton.this);
/* 226 */               ParentHelper.setTraversalEngine(ToggleButton.this, null);
/*     */             } 
/*     */             
/* 229 */             this.old = toggleGroup;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 234 */             return ToggleButton.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 239 */             return "toggleGroup";
/*     */           }
/*     */         };
/*     */     }
/* 243 */     return this.toggleGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fire() {
/* 255 */     if (!isDisabled()) {
/* 256 */       setSelected(!isSelected());
/* 257 */       fireEvent(new ActionEvent());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 263 */     return (Skin<?>)new ToggleButtonSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 275 */   private static final PseudoClass PSEUDO_CLASS_SELECTED = PseudoClass.getPseudoClass("selected");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Pos getInitialAlignment() {
/* 285 */     return Pos.CENTER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 298 */     switch (paramAccessibleAttribute) { case SELECTED:
/* 299 */         return Boolean.valueOf(isSelected()); }
/* 300 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ToggleButton.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */