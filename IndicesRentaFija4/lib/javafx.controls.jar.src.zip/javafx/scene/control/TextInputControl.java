/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.binding.ExpressionHelper;
/*      */ import com.sun.javafx.scene.NodeHelper;
/*      */ import com.sun.javafx.scene.control.FormatterAccessor;
/*      */ import com.sun.javafx.util.Utils;
/*      */ import java.text.BreakIterator;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import javafx.beans.DefaultProperty;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.binding.IntegerBinding;
/*      */ import javafx.beans.binding.StringBinding;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*      */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*      */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*      */ import javafx.beans.property.ReadOnlyIntegerWrapper;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*      */ import javafx.beans.property.ReadOnlyStringProperty;
/*      */ import javafx.beans.property.ReadOnlyStringWrapper;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.property.SimpleStringProperty;
/*      */ import javafx.beans.property.StringProperty;
/*      */ import javafx.beans.value.ChangeListener;
/*      */ import javafx.beans.value.ObservableStringValue;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.FontCssMetaData;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.StyleOrigin;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.scene.AccessibleAction;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.input.Clipboard;
/*      */ import javafx.scene.input.ClipboardContent;
/*      */ import javafx.scene.text.Font;
/*      */ import javafx.util.StringConverter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @DefaultProperty("text")
/*      */ public abstract class TextInputControl
/*      */   extends Control
/*      */ {
/*      */   private ObjectProperty<Font> font;
/*      */   private StringProperty promptText;
/*      */   private final ObjectProperty<TextFormatter<?>> textFormatter;
/*      */   private final Content content;
/*      */   private TextProperty text;
/*      */   private ReadOnlyIntegerWrapper length;
/*      */   private BooleanProperty editable;
/*      */   private ReadOnlyObjectWrapper<IndexRange> selection;
/*      */   private ReadOnlyStringWrapper selectedText;
/*      */   private ReadOnlyIntegerWrapper anchor;
/*      */   private ReadOnlyIntegerWrapper caretPosition;
/*      */   private UndoRedoChange undoChangeHead;
/*      */   private UndoRedoChange undoChange;
/*      */   private boolean createNewUndoRecord;
/*      */   private final ReadOnlyBooleanWrapper undoable;
/*      */   private final ReadOnlyBooleanWrapper redoable;
/*      */   private BreakIterator charIterator;
/*      */   private BreakIterator wordIterator;
/*      */   private FormatterAccessor accessor;
/*      */   
/*      */   public final ObjectProperty<Font> fontProperty() {
/*      */     if (this.font == null)
/*      */       this.font = new StyleableObjectProperty<Font>(Font.getDefault())
/*      */         {
/*      */           private boolean fontSetByCss = false;
/*      */           
/*      */           public void applyStyle(StyleOrigin param1StyleOrigin, Font param1Font) {
/*      */             try {
/*      */               this.fontSetByCss = true;
/*      */               super.applyStyle(param1StyleOrigin, param1Font);
/*      */             } catch (Exception exception) {
/*      */               throw exception;
/*      */             } finally {
/*      */               this.fontSetByCss = false;
/*      */             } 
/*      */           }
/*      */           
/*      */           public void set(Font param1Font) {
/*      */             Font font = get();
/*      */             if ((param1Font == null) ? (font == null) : param1Font.equals(font))
/*      */               return; 
/*      */             super.set(param1Font);
/*      */           }
/*      */           
/*      */           protected void invalidated() {
/*      */             if (!this.fontSetByCss)
/*      */               NodeHelper.reapplyCSS(TextInputControl.this); 
/*      */           }
/*      */           
/*      */           public CssMetaData<TextInputControl, Font> getCssMetaData() {
/*      */             return TextInputControl.StyleableProperties.FONT;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*      */             return TextInputControl.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*      */             return "font";
/*      */           }
/*      */         }; 
/*      */     return this.font;
/*      */   }
/*      */   
/*      */   public final void setFont(Font paramFont) {
/*      */     fontProperty().setValue(paramFont);
/*      */   }
/*      */   
/*      */   public final Font getFont() {
/*      */     return (this.font == null) ? Font.getDefault() : this.font.getValue();
/*      */   }
/*      */   
/*      */   public final StringProperty promptTextProperty() {
/*      */     return this.promptText;
/*      */   }
/*      */   
/*      */   public final String getPromptText() {
/*      */     return this.promptText.get();
/*      */   }
/*      */   
/*      */   public final void setPromptText(String paramString) {
/*      */     this.promptText.set(paramString);
/*      */   }
/*      */   
/*      */   public final ObjectProperty<TextFormatter<?>> textFormatterProperty() {
/*      */     return this.textFormatter;
/*      */   }
/*      */   
/*      */   public final TextFormatter<?> getTextFormatter() {
/*      */     return this.textFormatter.get();
/*      */   }
/*      */   
/*      */   public final void setTextFormatter(TextFormatter<?> paramTextFormatter) {
/*      */     this.textFormatter.set(paramTextFormatter);
/*      */   }
/*      */   
/*      */   protected final Content getContent() {
/*      */     return this.content;
/*      */   }
/*      */   
/*      */   public final String getText() {
/*      */     return this.text.get();
/*      */   }
/*      */   
/*      */   public final void setText(String paramString) {
/*      */     this.text.set(paramString);
/*      */   }
/*      */   
/*      */   public final StringProperty textProperty() {
/*      */     return this.text;
/*      */   }
/*      */   
/*      */   public final int getLength() {
/*      */     return this.length.get();
/*      */   }
/*      */   
/*      */   public final ReadOnlyIntegerProperty lengthProperty() {
/*      */     return this.length.getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   public final boolean isEditable() {
/*      */     return this.editable.getValue().booleanValue();
/*      */   }
/*      */   
/*      */   public final void setEditable(boolean paramBoolean) {
/*      */     this.editable.setValue(Boolean.valueOf(paramBoolean));
/*      */   }
/*      */   
/*      */   public final BooleanProperty editableProperty() {
/*      */     return this.editable;
/*      */   }
/*      */   
/*      */   public final IndexRange getSelection() {
/*      */     return this.selection.getValue();
/*      */   }
/*      */   
/*      */   public final ReadOnlyObjectProperty<IndexRange> selectionProperty() {
/*      */     return this.selection.getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   public final String getSelectedText() {
/*      */     return this.selectedText.get();
/*      */   }
/*      */   
/*      */   public final ReadOnlyStringProperty selectedTextProperty() {
/*      */     return this.selectedText.getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   public final int getAnchor() {
/*      */     return this.anchor.get();
/*      */   }
/*      */   
/*      */   public final ReadOnlyIntegerProperty anchorProperty() {
/*      */     return this.anchor.getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   public final int getCaretPosition() {
/*      */     return this.caretPosition.get();
/*      */   }
/*      */   
/*      */   public final ReadOnlyIntegerProperty caretPositionProperty() {
/*      */     return this.caretPosition.getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   public final boolean isUndoable() {
/*      */     return this.undoable.get();
/*      */   }
/*      */   
/*      */   public final ReadOnlyBooleanProperty undoableProperty() {
/*      */     return this.undoable.getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   protected TextInputControl(Content paramContent) {
/*  277 */     this.promptText = new SimpleStringProperty(this, "promptText", "")
/*      */       {
/*      */         protected void invalidated() {
/*  280 */           String str = get();
/*  281 */           if (str != null && str.contains("\n")) {
/*  282 */             str = str.replace("\n", "");
/*  283 */             set(str);
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  299 */     this.textFormatter = new ObjectPropertyBase<TextFormatter<?>>()
/*      */       {
/*  301 */         private TextFormatter<?> oldFormatter = null;
/*      */ 
/*      */         
/*      */         public Object getBean() {
/*  305 */           return TextInputControl.this;
/*      */         }
/*      */ 
/*      */         
/*      */         public String getName() {
/*  310 */           return "textFormatter";
/*      */         }
/*      */ 
/*      */         
/*      */         protected void invalidated() {
/*  315 */           TextFormatter<?> textFormatter = get();
/*      */           try {
/*  317 */             if (textFormatter != null) {
/*      */               try {
/*  319 */                 textFormatter.bindToControl(param1TextFormatter -> TextInputControl.this.updateText(param1TextFormatter));
/*  320 */               } catch (IllegalStateException illegalStateException) {
/*  321 */                 if (isBound()) {
/*  322 */                   unbind();
/*      */                 }
/*  324 */                 set((TextFormatter<?>)null);
/*  325 */                 throw illegalStateException;
/*      */               } 
/*  327 */               if (!TextInputControl.this.isFocused()) {
/*  328 */                 TextInputControl.this.updateText((TextFormatter)get());
/*      */               }
/*      */             } 
/*      */             
/*  332 */             if (this.oldFormatter != null) {
/*  333 */               this.oldFormatter.unbindFromControl();
/*      */             }
/*      */           } finally {
/*  336 */             this.oldFormatter = textFormatter;
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  356 */     this.text = new TextProperty();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  364 */     this.length = new ReadOnlyIntegerWrapper(this, "length");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  371 */     this.editable = new SimpleBooleanProperty(this, "editable", true) {
/*      */         protected void invalidated() {
/*  373 */           TextInputControl.this.pseudoClassStateChanged(TextInputControl.PSEUDO_CLASS_READONLY, !get());
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  383 */     this.selection = new ReadOnlyObjectWrapper<>(this, "selection", new IndexRange(0, 0));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  390 */     this.selectedText = new ReadOnlyStringWrapper(this, "selectedText");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  402 */     this.anchor = new ReadOnlyIntegerWrapper(this, "anchor", 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  414 */     this.caretPosition = new ReadOnlyIntegerWrapper(this, "caretPosition", 0);
/*      */ 
/*      */ 
/*      */     
/*  418 */     this.undoChangeHead = new UndoRedoChange();
/*  419 */     this.undoChange = this.undoChangeHead;
/*  420 */     this.createNewUndoRecord = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  427 */     this.undoable = new ReadOnlyBooleanWrapper(this, "undoable", false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  437 */     this.redoable = new ReadOnlyBooleanWrapper(this, "redoable", false); this.content = paramContent; paramContent.addListener(paramObservable -> { if (paramContent.length() > 0) this.text.textIsNull = false;  this.text.controlContentHasChanged(); }); this.length.bind(new IntegerBinding() { protected int computeValue() { String str = TextInputControl.this.text.get(); return (str == null) ? 0 : str.length(); } }); this.selectedText.bind(new StringBinding() { protected String computeValue() { String str = TextInputControl.this.text.get(); IndexRange indexRange = TextInputControl.this.selection.get(); if (str == null || indexRange == null) return "";  int i = indexRange.getStart(); int j = indexRange.getEnd(); int k = str.length(); if (j > i + k) j = k;  if (i > k - 1) i = j = 0;  return str.substring(i, j); } }); focusedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> { if (paramBoolean2.booleanValue()) { if (getTextFormatter() != null) updateText(getTextFormatter());  } else { commitValue(); }  }); getStyleClass().add("text-input");
/*  438 */   } public final boolean isRedoable() { return this.redoable.get(); } public final ReadOnlyBooleanProperty redoableProperty() {
/*  439 */     return this.redoable.getReadOnlyProperty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText(int paramInt1, int paramInt2) {
/*  455 */     if (paramInt1 > paramInt2) {
/*  456 */       throw new IllegalArgumentException("The start must be <= the end");
/*      */     }
/*      */     
/*  459 */     if (paramInt1 < 0 || paramInt2 > 
/*  460 */       getLength()) {
/*  461 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */     
/*  464 */     return getContent().get(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void appendText(String paramString) {
/*  473 */     insertText(getLength(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertText(int paramInt, String paramString) {
/*  483 */     replaceText(paramInt, paramInt, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteText(IndexRange paramIndexRange) {
/*  494 */     replaceText(paramIndexRange, "");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteText(int paramInt1, int paramInt2) {
/*  506 */     replaceText(paramInt1, paramInt2, "");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceText(IndexRange paramIndexRange, String paramString) {
/*  518 */     int i = paramIndexRange.getStart();
/*  519 */     int j = i + paramIndexRange.getLength();
/*  520 */     replaceText(i, j, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceText(int paramInt1, int paramInt2, String paramString) {
/*  533 */     if (paramInt1 > paramInt2) {
/*  534 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*  537 */     if (paramString == null) {
/*  538 */       throw new NullPointerException();
/*      */     }
/*      */     
/*  541 */     if (paramInt1 < 0 || paramInt2 > 
/*  542 */       getLength()) {
/*  543 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */     
/*  546 */     if (!this.text.isBound()) {
/*  547 */       int i = getLength();
/*  548 */       TextFormatter<?> textFormatter = getTextFormatter();
/*  549 */       TextFormatter.Change change = new TextFormatter.Change(this, getFormatterAccessor(), paramInt1, paramInt2, paramString);
/*  550 */       if (textFormatter != null && textFormatter.getFilter() != null) {
/*  551 */         change = textFormatter.getFilter().apply(change);
/*  552 */         if (change == null) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  558 */       updateContent(change, (i == 0));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateContent(TextFormatter.Change paramChange, boolean paramBoolean) {
/*  564 */     boolean bool1 = (getSelection().getLength() > 0) ? true : false;
/*  565 */     String str1 = getText(paramChange.start, paramChange.end);
/*  566 */     int i = replaceText(paramChange.start, paramChange.end, paramChange.text, paramChange.getAnchor(), paramChange.getCaretPosition());
/*  567 */     String str2 = getText(paramChange.start, paramChange.start + paramChange.text.length() - i);
/*  568 */     if (str2.equals(str1)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  586 */     boolean bool2 = (this.undoChange == this.undoChangeHead) ? true : (this.undoChange.start + this.undoChange.newText.length());
/*  587 */     boolean bool3 = false;
/*  588 */     if (str2.equals(" ")) {
/*  589 */       if (!UndoRedoChange.isSpaceCharSequence()) {
/*  590 */         bool3 = true;
/*  591 */         UndoRedoChange.setSpaceCharSequence(true);
/*      */       } 
/*      */     } else {
/*  594 */       UndoRedoChange.setSpaceCharSequence(false);
/*      */     } 
/*  596 */     if (this.createNewUndoRecord || bool1 || bool2 == -1 || paramBoolean || bool3 || 
/*  597 */       UndoRedoChange.hasChangeDurationElapsed() || (bool2 != paramChange.start && bool2 != paramChange.end) || paramChange.end - paramChange.start > 0) {
/*      */       
/*  599 */       this.undoChange = this.undoChange.add(paramChange.start, str1, str2);
/*  600 */     } else if (paramChange.start != paramChange.end && paramChange.text.isEmpty()) {
/*      */       
/*  602 */       if (this.undoChange.newText.length() > 0) {
/*  603 */         this.undoChange.newText = this.undoChange.newText.substring(0, paramChange.start - this.undoChange.start);
/*  604 */         if (this.undoChange.newText.isEmpty())
/*      */         {
/*  606 */           this.undoChange = this.undoChange.discard();
/*      */         }
/*      */       }
/*  609 */       else if (paramChange.start == bool2) {
/*  610 */         this.undoChange.oldText += this.undoChange.oldText;
/*      */       } else {
/*  612 */         this.undoChange.oldText = str1 + str1;
/*  613 */         this.undoChange.start--;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  618 */       this.undoChange.newText += this.undoChange.newText;
/*      */     } 
/*  620 */     updateUndoRedoState();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cut() {
/*  628 */     copy();
/*  629 */     IndexRange indexRange = getSelection();
/*  630 */     deleteText(indexRange.getStart(), indexRange.getEnd());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copy() {
/*  638 */     String str = getSelectedText();
/*  639 */     if (str.length() > 0) {
/*  640 */       ClipboardContent clipboardContent = new ClipboardContent();
/*  641 */       clipboardContent.putString(str);
/*  642 */       Clipboard.getSystemClipboard().setContent(clipboardContent);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void paste() {
/*  652 */     Clipboard clipboard = Clipboard.getSystemClipboard();
/*  653 */     if (clipboard.hasString()) {
/*  654 */       String str = clipboard.getString();
/*  655 */       if (str != null) {
/*  656 */         this.createNewUndoRecord = true;
/*      */         try {
/*  658 */           replaceSelection(str);
/*      */         } finally {
/*  660 */           this.createNewUndoRecord = false;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectBackward() {
/*  672 */     if (getCaretPosition() > 0 && getLength() > 0) {
/*      */ 
/*      */       
/*  675 */       if (this.charIterator == null) {
/*  676 */         this.charIterator = BreakIterator.getCharacterInstance();
/*      */       }
/*  678 */       this.charIterator.setText(getText());
/*  679 */       selectRange(getAnchor(), this.charIterator.preceding(getCaretPosition()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectForward() {
/*  689 */     int i = getLength();
/*  690 */     if (i > 0 && getCaretPosition() < i) {
/*  691 */       if (this.charIterator == null) {
/*  692 */         this.charIterator = BreakIterator.getCharacterInstance();
/*      */       }
/*  694 */       this.charIterator.setText(getText());
/*  695 */       selectRange(getAnchor(), this.charIterator.following(getCaretPosition()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void previousWord() {
/*  710 */     previousWord(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void nextWord() {
/*  718 */     nextWord(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endOfNextWord() {
/*  726 */     endOfNextWord(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectPreviousWord() {
/*  735 */     previousWord(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectNextWord() {
/*  744 */     nextWord(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectEndOfNextWord() {
/*  752 */     endOfNextWord(true);
/*      */   }
/*      */   
/*      */   private void previousWord(boolean paramBoolean) {
/*  756 */     int i = getLength();
/*  757 */     String str = getText();
/*  758 */     if (i <= 0) {
/*      */       return;
/*      */     }
/*      */     
/*  762 */     if (this.wordIterator == null) {
/*  763 */       this.wordIterator = BreakIterator.getWordInstance();
/*      */     }
/*  765 */     this.wordIterator.setText(str);
/*      */     
/*  767 */     int j = this.wordIterator.preceding(Utils.clamp(0, getCaretPosition(), i));
/*      */ 
/*      */     
/*  770 */     while (j != -1 && 
/*  771 */       !Character.isLetterOrDigit(str.charAt(Utils.clamp(0, j, i - 1)))) {
/*  772 */       j = this.wordIterator.preceding(Utils.clamp(0, j, i));
/*      */     }
/*      */ 
/*      */     
/*  776 */     selectRange(paramBoolean ? getAnchor() : j, j);
/*      */   }
/*      */   
/*      */   private void nextWord(boolean paramBoolean) {
/*  780 */     int i = getLength();
/*  781 */     String str = getText();
/*  782 */     if (i <= 0) {
/*      */       return;
/*      */     }
/*      */     
/*  786 */     if (this.wordIterator == null) {
/*  787 */       this.wordIterator = BreakIterator.getWordInstance();
/*      */     }
/*  789 */     this.wordIterator.setText(str);
/*      */     
/*  791 */     int j = this.wordIterator.following(Utils.clamp(0, getCaretPosition(), i - 1));
/*  792 */     int k = this.wordIterator.next();
/*      */ 
/*      */ 
/*      */     
/*  796 */     while (k != -1) {
/*  797 */       for (int m = j; m <= k; m++) {
/*  798 */         char c = str.charAt(Utils.clamp(0, m, i - 1));
/*      */ 
/*      */         
/*  801 */         if (c != ' ' && c != '\t') {
/*  802 */           if (paramBoolean) {
/*  803 */             selectRange(getAnchor(), m);
/*      */           } else {
/*  805 */             selectRange(m, m);
/*      */           } 
/*      */           return;
/*      */         } 
/*      */       } 
/*  810 */       j = k;
/*  811 */       k = this.wordIterator.next();
/*      */     } 
/*      */ 
/*      */     
/*  815 */     if (paramBoolean) {
/*  816 */       selectRange(getAnchor(), i);
/*      */     } else {
/*  818 */       end();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endOfNextWord(boolean paramBoolean) {
/*  823 */     int i = getLength();
/*  824 */     String str = getText();
/*  825 */     if (i <= 0) {
/*      */       return;
/*      */     }
/*      */     
/*  829 */     if (this.wordIterator == null) {
/*  830 */       this.wordIterator = BreakIterator.getWordInstance();
/*      */     }
/*  832 */     this.wordIterator.setText(str);
/*      */     
/*  834 */     int j = this.wordIterator.following(Utils.clamp(0, getCaretPosition(), i));
/*  835 */     int k = this.wordIterator.next();
/*      */ 
/*      */     
/*  838 */     while (k != -1) {
/*  839 */       for (int m = j; m <= k; m++) {
/*  840 */         if (!Character.isLetterOrDigit(str.charAt(Utils.clamp(0, m, i - 1)))) {
/*  841 */           if (paramBoolean) {
/*  842 */             selectRange(getAnchor(), m);
/*      */           } else {
/*  844 */             selectRange(m, m);
/*      */           } 
/*      */           return;
/*      */         } 
/*      */       } 
/*  849 */       j = k;
/*  850 */       k = this.wordIterator.next();
/*      */     } 
/*      */ 
/*      */     
/*  854 */     if (paramBoolean) {
/*  855 */       selectRange(getAnchor(), i);
/*      */     } else {
/*  857 */       end();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectAll() {
/*  865 */     selectRange(0, getLength());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void home() {
/*  874 */     selectRange(0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void end() {
/*  883 */     int i = getLength();
/*  884 */     if (i > 0) {
/*  885 */       selectRange(i, i);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectHome() {
/*  895 */     selectRange(getAnchor(), 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectEnd() {
/*  904 */     int i = getLength();
/*  905 */     if (i > 0) selectRange(getAnchor(), i);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean deletePreviousChar() {
/*  915 */     boolean bool = true;
/*  916 */     if (isEditable() && !isDisabled()) {
/*  917 */       String str = getText();
/*  918 */       int i = getCaretPosition();
/*  919 */       int j = getAnchor();
/*  920 */       if (i != j) {
/*      */         
/*  922 */         replaceSelection("");
/*  923 */         bool = false;
/*  924 */       } else if (i > 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  931 */         int k = Character.offsetByCodePoints(str, i, -1);
/*  932 */         deleteText(k, i);
/*  933 */         bool = false;
/*      */       } 
/*      */     } 
/*  936 */     return !bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean deleteNextChar() {
/*  946 */     boolean bool = true;
/*  947 */     if (isEditable() && !isDisabled()) {
/*  948 */       int i = getLength();
/*  949 */       String str = getText();
/*  950 */       int j = getCaretPosition();
/*  951 */       int k = getAnchor();
/*  952 */       if (j != k) {
/*      */         
/*  954 */         replaceSelection("");
/*  955 */         bool = false;
/*  956 */       } else if (i > 0 && j < i) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  961 */         if (this.charIterator == null) {
/*  962 */           this.charIterator = BreakIterator.getCharacterInstance();
/*      */         }
/*  964 */         this.charIterator.setText(str);
/*  965 */         int m = this.charIterator.following(j);
/*  966 */         deleteText(j, m);
/*  967 */         bool = false;
/*      */       } 
/*      */     } 
/*  970 */     return !bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void forward() {
/*  981 */     int i = getLength();
/*  982 */     int j = getCaretPosition();
/*  983 */     int k = getAnchor();
/*  984 */     if (j != k) {
/*  985 */       int m = Math.max(j, k);
/*  986 */       selectRange(m, m);
/*  987 */     } else if (j < i && i > 0) {
/*  988 */       if (this.charIterator == null) {
/*  989 */         this.charIterator = BreakIterator.getCharacterInstance();
/*      */       }
/*  991 */       this.charIterator.setText(getText());
/*  992 */       int m = this.charIterator.following(j);
/*  993 */       selectRange(m, m);
/*      */     } 
/*  995 */     deselect();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void backward() {
/* 1010 */     int i = getLength();
/* 1011 */     int j = getCaretPosition();
/* 1012 */     int k = getAnchor();
/* 1013 */     if (j != k) {
/* 1014 */       int m = Math.min(j, k);
/* 1015 */       selectRange(m, m);
/* 1016 */     } else if (j > 0 && i > 0) {
/* 1017 */       if (this.charIterator == null) {
/* 1018 */         this.charIterator = BreakIterator.getCharacterInstance();
/*      */       }
/* 1020 */       this.charIterator.setText(getText());
/* 1021 */       int m = this.charIterator.preceding(j);
/* 1022 */       selectRange(m, m);
/*      */     } 
/* 1024 */     deselect();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void positionCaret(int paramInt) {
/* 1033 */     int i = Utils.clamp(0, paramInt, getLength());
/* 1034 */     selectRange(i, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectPositionCaret(int paramInt) {
/* 1045 */     selectRange(getAnchor(), Utils.clamp(0, paramInt, getLength()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void selectRange(int paramInt1, int paramInt2) {
/* 1054 */     paramInt2 = Utils.clamp(0, paramInt2, getLength());
/* 1055 */     paramInt1 = Utils.clamp(0, paramInt1, getLength());
/*      */     
/* 1057 */     TextFormatter.Change change = new TextFormatter.Change(this, getFormatterAccessor(), paramInt1, paramInt2);
/* 1058 */     TextFormatter<?> textFormatter = getTextFormatter();
/* 1059 */     if (textFormatter != null && textFormatter.getFilter() != null) {
/* 1060 */       change = textFormatter.getFilter().apply(change);
/* 1061 */       if (change == null) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */     
/* 1066 */     updateContent(change, false);
/*      */   }
/*      */   
/*      */   private void doSelectRange(int paramInt1, int paramInt2) {
/* 1070 */     this.caretPosition.set(Utils.clamp(0, paramInt2, getLength()));
/* 1071 */     this.anchor.set(Utils.clamp(0, paramInt1, getLength()));
/* 1072 */     this.selection.set(IndexRange.normalize(getAnchor(), getCaretPosition()));
/* 1073 */     notifyAccessibleAttributeChanged(AccessibleAttribute.SELECTION_START);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void extendSelection(int paramInt) {
/* 1085 */     int i = Utils.clamp(0, paramInt, getLength());
/* 1086 */     int j = getCaretPosition();
/* 1087 */     int k = getAnchor();
/* 1088 */     int m = Math.min(j, k);
/* 1089 */     int n = Math.max(j, k);
/* 1090 */     if (i < m) {
/* 1091 */       selectRange(n, i);
/*      */     } else {
/* 1093 */       selectRange(m, i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/* 1101 */     deselect();
/* 1102 */     if (!this.text.isBound()) {
/* 1103 */       setText("");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deselect() {
/* 1113 */     selectRange(getCaretPosition(), getCaretPosition());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceSelection(String paramString) {
/* 1124 */     replaceText(getSelection(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void undo() {
/* 1133 */     if (isUndoable()) {
/*      */       
/* 1135 */       int i = this.undoChange.start;
/* 1136 */       String str1 = this.undoChange.newText;
/* 1137 */       String str2 = this.undoChange.oldText;
/*      */       
/* 1139 */       if (str1 != null) {
/* 1140 */         getContent().delete(i, i + str1.length(), str2.isEmpty());
/*      */       }
/*      */       
/* 1143 */       if (str2 != null) {
/* 1144 */         getContent().insert(i, str2, true);
/* 1145 */         doSelectRange(i, i + str2.length());
/*      */       } else {
/* 1147 */         doSelectRange(i, i + str1.length());
/*      */       } 
/*      */       
/* 1150 */       this.undoChange = this.undoChange.prev;
/*      */     } 
/* 1152 */     updateUndoRedoState();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void redo() {
/* 1161 */     if (isRedoable()) {
/*      */       
/* 1163 */       this.undoChange = this.undoChange.next;
/* 1164 */       int i = this.undoChange.start;
/* 1165 */       String str1 = this.undoChange.newText;
/* 1166 */       String str2 = this.undoChange.oldText;
/*      */       
/* 1168 */       if (str2 != null) {
/* 1169 */         getContent().delete(i, i + str2.length(), str1.isEmpty());
/*      */       }
/*      */       
/* 1172 */       if (str1 != null) {
/* 1173 */         getContent().insert(i, str1, true);
/* 1174 */         doSelectRange(i + str1.length(), i + str1.length());
/*      */       } else {
/* 1176 */         doSelectRange(i, i);
/*      */       } 
/*      */     } 
/* 1179 */     updateUndoRedoState();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void textUpdated() {}
/*      */ 
/*      */   
/*      */   private void resetUndoRedoState() {
/* 1188 */     this.undoChange = this.undoChangeHead;
/* 1189 */     this.undoChange.next = null;
/* 1190 */     updateUndoRedoState();
/*      */   }
/*      */   
/*      */   private void updateUndoRedoState() {
/* 1194 */     this.undoable.set((this.undoChange != this.undoChangeHead));
/* 1195 */     this.redoable.set((this.undoChange.next != null));
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean filterAndSet(String paramString) {
/* 1200 */     TextFormatter<?> textFormatter = getTextFormatter();
/* 1201 */     int i = this.content.length();
/* 1202 */     if (textFormatter != null && textFormatter.getFilter() != null && !this.text.isBound()) {
/*      */       
/* 1204 */       TextFormatter.Change change = new TextFormatter.Change(this, getFormatterAccessor(), 0, i, paramString, 0, 0);
/* 1205 */       change = textFormatter.getFilter().apply(change);
/* 1206 */       if (change == null) {
/* 1207 */         return false;
/*      */       }
/* 1209 */       replaceText(change.start, change.end, change.text, change.getAnchor(), change.getCaretPosition());
/*      */     } else {
/* 1211 */       replaceText(0, i, paramString, 0, 0);
/*      */     } 
/* 1213 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int replaceText(int paramInt1, int paramInt2, String paramString, int paramInt3, int paramInt4) {
/* 1237 */     int i = getLength();
/* 1238 */     int j = 0;
/* 1239 */     if (paramInt2 != paramInt1) {
/* 1240 */       getContent().delete(paramInt1, paramInt2, paramString.isEmpty());
/* 1241 */       i -= paramInt2 - paramInt1;
/*      */     } 
/* 1243 */     if (paramString != null) {
/* 1244 */       getContent().insert(paramInt1, paramString, true);
/* 1245 */       j = paramString.length() - getLength() - i;
/* 1246 */       paramInt3 -= j;
/* 1247 */       paramInt4 -= j;
/*      */     } 
/* 1249 */     doSelectRange(paramInt3, paramInt4);
/* 1250 */     return j;
/*      */   }
/*      */   
/*      */   private <T> void updateText(TextFormatter<T> paramTextFormatter) {
/* 1254 */     T t = paramTextFormatter.getValue();
/* 1255 */     StringConverter<T> stringConverter = paramTextFormatter.getValueConverter();
/* 1256 */     if (stringConverter != null) {
/* 1257 */       String str = stringConverter.toString(t);
/* 1258 */       if (str == null) str = ""; 
/* 1259 */       replaceText(0, getLength(), str, str.length(), str.length());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void commitValue() {
/* 1268 */     if (getTextFormatter() != null) {
/* 1269 */       getTextFormatter().updateValue(getText());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void cancelEdit() {
/* 1278 */     if (getTextFormatter() != null) {
/* 1279 */       updateText(getTextFormatter());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private FormatterAccessor getFormatterAccessor() {
/* 1286 */     if (this.accessor == null) {
/* 1287 */       this.accessor = new TextInputControlFromatterAccessor();
/*      */     }
/* 1289 */     return this.accessor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String filterInput(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 1307 */     if (containsInvalidCharacters(paramString, paramBoolean1, paramBoolean2)) {
/* 1308 */       StringBuilder stringBuilder = new StringBuilder(paramString.length());
/* 1309 */       for (byte b = 0; b < paramString.length(); b++) {
/* 1310 */         char c = paramString.charAt(b);
/* 1311 */         if (!isInvalidCharacter(c, paramBoolean1, paramBoolean2)) {
/* 1312 */           stringBuilder.append(c);
/*      */         }
/*      */       } 
/* 1315 */       paramString = stringBuilder.toString();
/*      */     } 
/* 1317 */     return paramString;
/*      */   }
/*      */   
/*      */   static boolean containsInvalidCharacters(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 1321 */     for (byte b = 0; b < paramString.length(); b++) {
/* 1322 */       char c = paramString.charAt(b);
/* 1323 */       if (isInvalidCharacter(c, paramBoolean1, paramBoolean2)) return true; 
/*      */     } 
/* 1325 */     return false;
/*      */   }
/*      */   
/*      */   private static boolean isInvalidCharacter(char paramChar, boolean paramBoolean1, boolean paramBoolean2) {
/* 1329 */     if (paramChar == '') return true; 
/* 1330 */     if (paramChar == '\n') return paramBoolean1; 
/* 1331 */     if (paramChar == '\t') return paramBoolean2; 
/* 1332 */     if (paramChar < ' ') return true; 
/* 1333 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class TextProperty
/*      */     extends StringProperty
/*      */   {
/* 1343 */     private ObservableValue<? extends String> observable = null;
/*      */     
/* 1345 */     private InvalidationListener listener = null;
/*      */     
/* 1347 */     private ExpressionHelper<String> helper = null;
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean textIsNull = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String get() {
/* 1357 */       return this.textIsNull ? null : TextInputControl.this.content.get();
/*      */     }
/*      */     
/*      */     public void set(String param1String) {
/* 1361 */       if (isBound()) {
/* 1362 */         throw new RuntimeException("A bound value cannot be set.");
/*      */       }
/* 1364 */       doSet(param1String);
/* 1365 */       markInvalid();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void controlContentHasChanged() {
/* 1373 */       markInvalid();
/* 1374 */       TextInputControl.this.notifyAccessibleAttributeChanged(AccessibleAttribute.TEXT);
/*      */     }
/*      */     
/*      */     public void bind(ObservableValue<? extends String> param1ObservableValue) {
/* 1378 */       if (param1ObservableValue == null) {
/* 1379 */         throw new NullPointerException("Cannot bind to null");
/*      */       }
/* 1381 */       if (!param1ObservableValue.equals(this.observable)) {
/* 1382 */         unbind();
/* 1383 */         this.observable = param1ObservableValue;
/* 1384 */         if (this.listener == null) {
/* 1385 */           this.listener = new Listener();
/*      */         }
/* 1387 */         this.observable.addListener(this.listener);
/* 1388 */         markInvalid();
/* 1389 */         doSet(param1ObservableValue.getValue());
/*      */       } 
/*      */     }
/*      */     
/*      */     public void unbind() {
/* 1394 */       if (this.observable != null) {
/* 1395 */         doSet(this.observable.getValue());
/* 1396 */         this.observable.removeListener(this.listener);
/* 1397 */         this.observable = null;
/*      */       } 
/*      */     }
/*      */     
/*      */     public boolean isBound() {
/* 1402 */       return (this.observable != null);
/*      */     }
/*      */     
/*      */     public void addListener(InvalidationListener param1InvalidationListener) {
/* 1406 */       this.helper = ExpressionHelper.addListener(this.helper, this, param1InvalidationListener);
/*      */     }
/*      */     
/*      */     public void removeListener(InvalidationListener param1InvalidationListener) {
/* 1410 */       this.helper = ExpressionHelper.removeListener(this.helper, param1InvalidationListener);
/*      */     }
/*      */     
/*      */     public void addListener(ChangeListener<? super String> param1ChangeListener) {
/* 1414 */       this.helper = ExpressionHelper.addListener(this.helper, this, param1ChangeListener);
/*      */     }
/*      */     
/*      */     public void removeListener(ChangeListener<? super String> param1ChangeListener) {
/* 1418 */       this.helper = ExpressionHelper.removeListener(this.helper, param1ChangeListener);
/*      */     }
/*      */     
/*      */     public Object getBean() {
/* 1422 */       return TextInputControl.this;
/*      */     }
/*      */     
/*      */     public String getName() {
/* 1426 */       return "text";
/*      */     }
/*      */     
/*      */     private void fireValueChangedEvent() {
/* 1430 */       ExpressionHelper.fireValueChangedEvent(this.helper);
/*      */     }
/*      */     
/*      */     private void markInvalid() {
/* 1434 */       fireValueChangedEvent();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void doSet(String param1String) {
/* 1448 */       this.textIsNull = (param1String == null);
/* 1449 */       if (param1String == null) param1String = "";
/*      */       
/* 1451 */       if (!TextInputControl.this.filterAndSet(param1String))
/*      */         return; 
/* 1453 */       if (TextInputControl.this.getTextFormatter() != null) {
/* 1454 */         TextInputControl.this.getTextFormatter().updateValue(TextInputControl.this.getText());
/*      */       }
/*      */       
/* 1457 */       TextInputControl.this.textUpdated();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1463 */       TextInputControl.this.resetUndoRedoState();
/*      */     }
/*      */     
/*      */     private TextProperty() {}
/*      */     
/*      */     private class Listener
/*      */       implements InvalidationListener
/*      */     {
/*      */       private Listener() {}
/*      */       
/*      */       public void invalidated(Observable param2Observable) {
/* 1474 */         TextInputControl.TextProperty.this.doSet(TextInputControl.TextProperty.this.observable.getValue());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class UndoRedoChange
/*      */   {
/*      */     static long prevRecordTime;
/*      */     
/*      */     static final long CHANGE_DURATION = 2500L;
/*      */     
/*      */     static boolean spaceCharSequence = false;
/*      */     
/*      */     int start;
/*      */     
/*      */     String oldText;
/*      */     
/*      */     String newText;
/*      */     
/*      */     UndoRedoChange prev;
/*      */     
/*      */     UndoRedoChange next;
/*      */ 
/*      */     
/*      */     public UndoRedoChange add(int param1Int, String param1String1, String param1String2) {
/* 1500 */       UndoRedoChange undoRedoChange = new UndoRedoChange();
/* 1501 */       undoRedoChange.start = param1Int;
/* 1502 */       undoRedoChange.oldText = param1String1;
/* 1503 */       undoRedoChange.newText = param1String2;
/* 1504 */       undoRedoChange.prev = this;
/* 1505 */       this.next = undoRedoChange;
/* 1506 */       prevRecordTime = System.currentTimeMillis();
/* 1507 */       return undoRedoChange;
/*      */     }
/*      */     
/*      */     static boolean hasChangeDurationElapsed() {
/* 1511 */       return (System.currentTimeMillis() - prevRecordTime > 2500L);
/*      */     }
/*      */     
/*      */     static void setSpaceCharSequence(boolean param1Boolean) {
/* 1515 */       spaceCharSequence = param1Boolean;
/*      */     }
/*      */     static boolean isSpaceCharSequence() {
/* 1518 */       return spaceCharSequence;
/*      */     }
/*      */     
/*      */     public UndoRedoChange discard() {
/* 1522 */       this.prev.next = this.next;
/* 1523 */       return this.prev;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void debugPrint() {
/* 1530 */       UndoRedoChange undoRedoChange = this;
/* 1531 */       System.out.print("[");
/* 1532 */       while (undoRedoChange != null) {
/* 1533 */         System.out.print(undoRedoChange.toString());
/* 1534 */         if (undoRedoChange.next != null) System.out.print(", "); 
/* 1535 */         undoRedoChange = undoRedoChange.next;
/*      */       } 
/* 1537 */       System.out.println("]");
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1541 */       if (this.oldText == null && this.newText == null) {
/* 1542 */         return "head";
/*      */       }
/* 1544 */       return (this.oldText.isEmpty() && !this.newText.isEmpty()) ? ("added '" + 
/* 1545 */         this.newText + "' at index " + this.start) : (
/* 1546 */         (!this.oldText.isEmpty() && !this.newText.isEmpty()) ? ("replaced '" + 
/* 1547 */         this.oldText + "' with '" + this.newText + "' at index " + this.start) : ("deleted '" + 
/*      */         
/* 1549 */         this.oldText + "' at index " + this.start));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1562 */   private static final PseudoClass PSEUDO_CLASS_READONLY = PseudoClass.getPseudoClass("readonly");
/*      */   
/*      */   private static class StyleableProperties {
/* 1565 */     private static final FontCssMetaData<TextInputControl> FONT = new FontCssMetaData<TextInputControl>("-fx-font", 
/* 1566 */         Font.getDefault())
/*      */       {
/*      */         public boolean isSettable(TextInputControl param2TextInputControl)
/*      */         {
/* 1570 */           return (param2TextInputControl.font == null || !param2TextInputControl.font.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Font> getStyleableProperty(TextInputControl param2TextInputControl) {
/* 1575 */           return (StyleableProperty<Font>)param2TextInputControl.fontProperty();
/*      */         }
/*      */       };
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1582 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 1583 */       arrayList.add(FONT);
/* 1584 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1594 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 1603 */     return getClassCssMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*      */     String str1;
/*      */     String str2;
/* 1616 */     switch (paramAccessibleAttribute) {
/*      */       case SET_TEXT:
/* 1618 */         str1 = getAccessibleText();
/* 1619 */         if (str1 != null && !str1.isEmpty()) return str1;
/*      */         
/* 1621 */         str2 = getText();
/* 1622 */         if (str2 == null || str2.isEmpty()) {
/* 1623 */           str2 = getPromptText();
/*      */         }
/* 1625 */         return str2;
/*      */       case SET_TEXT_SELECTION:
/* 1627 */         return Boolean.valueOf(isEditable());
/* 1628 */       case null: return Integer.valueOf(getSelection().getStart());
/* 1629 */       case null: return Integer.valueOf(getSelection().getEnd());
/* 1630 */       case null: return Integer.valueOf(getCaretPosition());
/* 1631 */       case null: return getFont();
/* 1632 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ 
/*      */   
/*      */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*      */     String str;
/*      */     Integer integer1, integer2;
/* 1639 */     switch (paramAccessibleAction) {
/*      */       case SET_TEXT:
/* 1641 */         str = (String)paramVarArgs[0];
/* 1642 */         if (str != null) setText(str);
/*      */         
/*      */         return;
/*      */       case SET_TEXT_SELECTION:
/* 1646 */         integer1 = (Integer)paramVarArgs[0];
/* 1647 */         integer2 = (Integer)paramVarArgs[1];
/* 1648 */         if (integer1 != null && integer2 != null) {
/* 1649 */           selectRange(integer1.intValue(), integer2.intValue());
/*      */         }
/*      */         return;
/*      */     } 
/* 1653 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*      */   }
/*      */   
/*      */   private class TextInputControlFromatterAccessor implements FormatterAccessor {
/*      */     private TextInputControlFromatterAccessor() {}
/*      */     
/*      */     public int getTextLength() {
/* 1660 */       return TextInputControl.this.getLength();
/*      */     }
/*      */ 
/*      */     
/*      */     public String getText(int param1Int1, int param1Int2) {
/* 1665 */       return TextInputControl.this.getText(param1Int1, param1Int2);
/*      */     }
/*      */ 
/*      */     
/*      */     public int getCaret() {
/* 1670 */       return TextInputControl.this.getCaretPosition();
/*      */     }
/*      */ 
/*      */     
/*      */     public int getAnchor() {
/* 1675 */       return TextInputControl.this.getAnchor();
/*      */     }
/*      */   }
/*      */   
/*      */   protected static interface Content extends ObservableStringValue {
/*      */     String get(int param1Int1, int param1Int2);
/*      */     
/*      */     void insert(int param1Int, String param1String, boolean param1Boolean);
/*      */     
/*      */     void delete(int param1Int1, int param1Int2, boolean param1Boolean);
/*      */     
/*      */     int length();
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TextInputControl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */