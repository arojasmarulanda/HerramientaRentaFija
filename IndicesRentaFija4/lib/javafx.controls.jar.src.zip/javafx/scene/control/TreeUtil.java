/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TreeUtil
/*     */ {
/*     */   static <T> int getExpandedDescendantCount(TreeItem<T> paramTreeItem, boolean paramBoolean) {
/*  37 */     if (paramTreeItem == null) return 0; 
/*  38 */     if (paramTreeItem.isLeaf()) return 1;
/*     */     
/*  40 */     return paramTreeItem.getExpandedDescendentCount(paramBoolean);
/*     */   }
/*     */   
/*     */   static int updateExpandedItemCount(TreeItem<?> paramTreeItem, boolean paramBoolean1, boolean paramBoolean2) {
/*  44 */     if (paramTreeItem == null)
/*  45 */       return 0; 
/*  46 */     if (!paramTreeItem.isExpanded()) {
/*  47 */       return 1;
/*     */     }
/*  49 */     int i = getExpandedDescendantCount(paramTreeItem, paramBoolean1);
/*  50 */     if (!paramBoolean2) i--;
/*     */     
/*  52 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   static <T> TreeItem<T> getItem(TreeItem<T> paramTreeItem, int paramInt, boolean paramBoolean) {
/*  57 */     if (paramTreeItem == null) return null;
/*     */ 
/*     */     
/*  60 */     if (paramInt == 0) return paramTreeItem;
/*     */ 
/*     */     
/*  63 */     if (paramInt >= getExpandedDescendantCount(paramTreeItem, paramBoolean)) return null;
/*     */ 
/*     */     
/*  66 */     ObservableList<TreeItem<T>> observableList = paramTreeItem.getChildren();
/*  67 */     if (observableList == null) return null;
/*     */     
/*  69 */     int i = paramInt - 1;
/*     */     byte b;
/*     */     int j;
/*  72 */     for (b = 0, j = observableList.size(); b < j; b++) {
/*  73 */       TreeItem<T> treeItem = observableList.get(b);
/*  74 */       if (i == 0) return treeItem;
/*     */       
/*  76 */       if (treeItem.isLeaf() || !treeItem.isExpanded()) {
/*  77 */         i--;
/*     */       }
/*     */       else {
/*     */         
/*  81 */         int k = getExpandedDescendantCount(treeItem, paramBoolean);
/*  82 */         if (i >= k) {
/*  83 */           i -= k;
/*     */         }
/*     */         else {
/*     */           
/*  87 */           TreeItem<T> treeItem1 = getItem(treeItem, i, paramBoolean);
/*  88 */           if (treeItem1 != null) return treeItem1; 
/*  89 */           i--;
/*     */         } 
/*     */       } 
/*     */     } 
/*  93 */     return null;
/*     */   }
/*     */   
/*     */   static <T> int getRow(TreeItem<T> paramTreeItem1, TreeItem<T> paramTreeItem2, boolean paramBoolean1, boolean paramBoolean2) {
/*  97 */     if (paramTreeItem1 == null)
/*  98 */       return -1; 
/*  99 */     if (paramBoolean2 && paramTreeItem1.equals(paramTreeItem2)) {
/* 100 */       return 0;
/*     */     }
/*     */     
/* 103 */     int i = 0;
/* 104 */     TreeItem<T> treeItem1 = paramTreeItem1;
/* 105 */     TreeItem<T> treeItem2 = paramTreeItem1.getParent();
/*     */ 
/*     */ 
/*     */     
/* 109 */     boolean bool = false;
/*     */     
/* 111 */     while (!treeItem1.equals(paramTreeItem2) && treeItem2 != null) {
/* 112 */       if (!treeItem2.isExpanded()) {
/* 113 */         bool = true;
/*     */         
/*     */         break;
/*     */       } 
/* 117 */       ObservableList<TreeItem<T>> observableList = treeItem2.children;
/*     */ 
/*     */       
/* 120 */       int j = observableList.indexOf(treeItem1);
/* 121 */       for (int k = j - 1; k > -1; k--) {
/* 122 */         TreeItem<?> treeItem = observableList.get(k);
/* 123 */         if (treeItem != null) {
/*     */           
/* 125 */           i += getExpandedDescendantCount(treeItem, paramBoolean1);
/*     */           
/* 127 */           if (treeItem.equals(paramTreeItem2)) {
/* 128 */             if (!paramBoolean2)
/*     */             {
/*     */ 
/*     */               
/* 132 */               return -1;
/*     */             }
/* 134 */             return i;
/*     */           } 
/*     */         } 
/*     */       } 
/* 138 */       treeItem1 = treeItem2;
/* 139 */       treeItem2 = treeItem2.getParent();
/*     */ 
/*     */ 
/*     */       
/* 143 */       if (treeItem2 == null && !treeItem1.equals(paramTreeItem2)) {
/* 144 */         return -1;
/*     */       }
/*     */       
/* 147 */       i++;
/*     */     } 
/*     */     
/* 150 */     return ((treeItem2 == null && i == 0) || bool) ? -1 : (paramBoolean2 ? i : (i - 1));
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TreeUtil.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */