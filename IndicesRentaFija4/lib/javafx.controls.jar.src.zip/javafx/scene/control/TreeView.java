/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.scene.control.behavior.TreeCellBehavior;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.DefaultProperty;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*      */ import javafx.beans.property.ReadOnlyIntegerWrapper;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.beans.value.ChangeListener;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.beans.value.WeakChangeListener;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.EventType;
/*      */ import javafx.event.WeakEventHandler;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.control.skin.TreeViewSkin;
/*      */ import javafx.util.Callback;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @DefaultProperty("root")
/*      */ public class TreeView<T>
/*      */   extends Control
/*      */ {
/*      */   public static <T> EventType<EditEvent<T>> editAnyEvent() {
/*  217 */     return (EventType)EDIT_ANY_EVENT;
/*      */   }
/*  219 */   private static final EventType<?> EDIT_ANY_EVENT = new EventType(Event.ANY, "TREE_VIEW_EDIT");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<EditEvent<T>> editStartEvent() {
/*  231 */     return (EventType)EDIT_START_EVENT;
/*      */   }
/*  233 */   private static final EventType<?> EDIT_START_EVENT = new EventType(
/*  234 */       editAnyEvent(), "EDIT_START");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<EditEvent<T>> editCancelEvent() {
/*  246 */     return (EventType)EDIT_CANCEL_EVENT;
/*      */   }
/*  248 */   private static final EventType<?> EDIT_CANCEL_EVENT = new EventType(
/*  249 */       editAnyEvent(), "EDIT_CANCEL");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<EditEvent<T>> editCommitEvent() {
/*  262 */     return (EventType)EDIT_COMMIT_EVENT;
/*      */   }
/*  264 */   private static final EventType<?> EDIT_COMMIT_EVENT = new EventType(
/*  265 */       editAnyEvent(), "EDIT_COMMIT");
/*      */   
/*      */   private boolean expandedItemCountDirty;
/*      */   
/*      */   private Map<Integer, SoftReference<TreeItem<T>>> treeItemCacheMap;
/*      */   
/*      */   private final EventHandler<TreeItem.TreeModificationEvent<T>> rootEvent;
/*      */   private WeakEventHandler<TreeItem.TreeModificationEvent<T>> weakRootEventListener;
/*      */   private ObjectProperty<Callback<TreeView<T>, TreeCell<T>>> cellFactory;
/*      */   private ObjectProperty<TreeItem<T>> root;
/*      */   private BooleanProperty showRoot;
/*      */   private ObjectProperty<MultipleSelectionModel<TreeItem<T>>> selectionModel;
/*      */   private ObjectProperty<FocusModel<TreeItem<T>>> focusModel;
/*      */   private ReadOnlyIntegerWrapper expandedItemCount;
/*      */   private DoubleProperty fixedCellSize;
/*      */   private BooleanProperty editable;
/*      */   private ReadOnlyObjectWrapper<TreeItem<T>> editingItem;
/*      */   private ObjectProperty<EventHandler<EditEvent<T>>> onEditStart;
/*      */   private ObjectProperty<EventHandler<EditEvent<T>>> onEditCommit;
/*      */   private ObjectProperty<EventHandler<EditEvent<T>>> onEditCancel;
/*      */   private ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollTo;
/*      */   private static final String DEFAULT_STYLE_CLASS = "tree-view";
/*      */   
/*      */   @Deprecated(since = "8u20")
/*      */   public static int getNodeLevel(TreeItem<?> paramTreeItem) {
/*  290 */     if (paramTreeItem == null) return -1;
/*      */     
/*  292 */     byte b = 0;
/*  293 */     TreeItem<?> treeItem = paramTreeItem.getParent();
/*  294 */     while (treeItem != null) {
/*  295 */       b++;
/*  296 */       treeItem = treeItem.getParent();
/*      */     } 
/*      */     
/*  299 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TreeView() {
/*  316 */     this((TreeItem<T>)null);
/*      */   }
/*      */   public final void setCellFactory(Callback<TreeView<T>, TreeCell<T>> paramCallback) {
/*      */     cellFactoryProperty().set(paramCallback);
/*      */   }
/*      */   
/*      */   public final Callback<TreeView<T>, TreeCell<T>> getCellFactory() {
/*      */     return (this.cellFactory == null) ? null : this.cellFactory.get();
/*      */   }
/*      */   
/*      */   public final ObjectProperty<Callback<TreeView<T>, TreeCell<T>>> cellFactoryProperty() {
/*      */     if (this.cellFactory == null)
/*      */       this.cellFactory = new SimpleObjectProperty<>(this, "cellFactory"); 
/*      */     return this.cellFactory;
/*      */   }
/*      */   
/*      */   public final void setRoot(TreeItem<T> paramTreeItem) {
/*      */     rootProperty().set(paramTreeItem);
/*      */   }
/*      */   
/*      */   public final TreeItem<T> getRoot() {
/*      */     return (this.root == null) ? null : this.root.get();
/*      */   }
/*      */   
/*      */   public final ObjectProperty<TreeItem<T>> rootProperty() {
/*      */     return this.root;
/*      */   }
/*      */   
/*      */   public final void setShowRoot(boolean paramBoolean) {
/*      */     showRootProperty().set(paramBoolean);
/*      */   }
/*      */   
/*      */   public final boolean isShowRoot() {
/*      */     return (this.showRoot == null) ? true : this.showRoot.get();
/*      */   }
/*      */   
/*  352 */   public TreeView(TreeItem<T> paramTreeItem) { this.expandedItemCountDirty = true;
/*      */ 
/*      */ 
/*      */     
/*  356 */     this.treeItemCacheMap = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  368 */     this.rootEvent = (paramTreeModificationEvent -> {
/*      */         EventType<? extends Event> eventType = paramTreeModificationEvent.getEventType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         boolean bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         while (eventType != null) {
/*      */           if (eventType.equals(TreeItem.expandedItemCountChangeEvent())) {
/*      */             bool = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           eventType = (EventType)eventType.getSuperType();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         if (bool) {
/*      */           this.expandedItemCountDirty = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           requestLayout();
/*      */         } 
/*      */       });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  443 */     this.root = (ObjectProperty)new SimpleObjectProperty<TreeItem<TreeItem<T>>>(this, "root") {
/*      */         private WeakReference<TreeItem<T>> weakOldItem;
/*      */         
/*      */         protected void invalidated() {
/*  447 */           TreeItem treeItem = (this.weakOldItem == null) ? null : this.weakOldItem.get();
/*  448 */           if (treeItem != null && TreeView.this.weakRootEventListener != null) {
/*  449 */             treeItem.removeEventHandler(TreeItem.treeNotificationEvent(), TreeView.this.weakRootEventListener);
/*      */           }
/*      */           
/*  452 */           TreeItem<T> treeItem1 = TreeView.this.getRoot();
/*  453 */           if (treeItem1 != null) {
/*  454 */             TreeView.this.weakRootEventListener = new WeakEventHandler<>(TreeView.this.rootEvent);
/*  455 */             TreeView.this.getRoot().addEventHandler(TreeItem.treeNotificationEvent(), TreeView.this.weakRootEventListener);
/*  456 */             this.weakOldItem = new WeakReference<>(treeItem1);
/*      */           } 
/*      */ 
/*      */           
/*  460 */           TreeView.this.edit((TreeItem)null);
/*      */           
/*  462 */           TreeView.this.expandedItemCountDirty = true;
/*  463 */           TreeView.this.updateRootExpanded();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  619 */     this.expandedItemCount = new ReadOnlyIntegerWrapper(this, "expandedItemCount", 0); getStyleClass().setAll(new String[] { "tree-view" }); setAccessibleRole(AccessibleRole.TREE_VIEW); setRoot(paramTreeItem); updateExpandedItemCount(paramTreeItem); TreeViewBitSetSelectionModel<TreeItem<T>> treeViewBitSetSelectionModel = new TreeViewBitSetSelectionModel(this); setSelectionModel((MultipleSelectionModel<TreeItem<T>>)treeViewBitSetSelectionModel); setFocusModel(new TreeViewFocusModel<>(this)); } public final BooleanProperty showRootProperty() { if (this.showRoot == null) this.showRoot = new SimpleBooleanProperty(this, "showRoot", true) {
/*      */           protected void invalidated() { TreeView.this.updateRootExpanded(); TreeView.this.updateExpandedItemCount(TreeView.this.getRoot()); }
/*  621 */         };  return this.showRoot; } public final void setSelectionModel(MultipleSelectionModel<TreeItem<T>> paramMultipleSelectionModel) { selectionModelProperty().set(paramMultipleSelectionModel); } public final MultipleSelectionModel<TreeItem<T>> getSelectionModel() { return (this.selectionModel == null) ? null : this.selectionModel.get(); } public final ReadOnlyIntegerProperty expandedItemCountProperty() { return this.expandedItemCount.getReadOnlyProperty(); }
/*      */   public final ObjectProperty<MultipleSelectionModel<TreeItem<T>>> selectionModelProperty() { if (this.selectionModel == null) this.selectionModel = new SimpleObjectProperty<>(this, "selectionModel");  return this.selectionModel; }
/*      */   public final void setFocusModel(FocusModel<TreeItem<T>> paramFocusModel) { focusModelProperty().set(paramFocusModel); }
/*  624 */   public final FocusModel<TreeItem<T>> getFocusModel() { return (this.focusModel == null) ? null : this.focusModel.get(); } public final ObjectProperty<FocusModel<TreeItem<T>>> focusModelProperty() { if (this.focusModel == null) this.focusModel = new SimpleObjectProperty<>(this, "focusModel");  return this.focusModel; } private void setExpandedItemCount(int paramInt) { this.expandedItemCount.set(paramInt); }
/*      */   
/*      */   public final int getExpandedItemCount() {
/*  627 */     if (this.expandedItemCountDirty) {
/*  628 */       updateExpandedItemCount(getRoot());
/*      */     }
/*  630 */     return this.expandedItemCount.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFixedCellSize(double paramDouble) {
/*  648 */     fixedCellSizeProperty().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getFixedCellSize() {
/*  661 */     return (this.fixedCellSize == null) ? -1.0D : this.fixedCellSize.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DoubleProperty fixedCellSizeProperty() {
/*  686 */     if (this.fixedCellSize == null) {
/*  687 */       this.fixedCellSize = new StyleableDoubleProperty(-1.0D) {
/*      */           public CssMetaData<TreeView<?>, Number> getCssMetaData() {
/*  689 */             return TreeView.StyleableProperties.FIXED_CELL_SIZE;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  693 */             return TreeView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  697 */             return "fixedCellSize";
/*      */           }
/*      */         };
/*      */     }
/*  701 */     return this.fixedCellSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setEditable(boolean paramBoolean) {
/*  708 */     editableProperty().set(paramBoolean);
/*      */   }
/*      */   public final boolean isEditable() {
/*  711 */     return (this.editable == null) ? false : this.editable.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final BooleanProperty editableProperty() {
/*  720 */     if (this.editable == null) {
/*  721 */       this.editable = new SimpleBooleanProperty(this, "editable", false);
/*      */     }
/*  723 */     return this.editable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setEditingItem(TreeItem<T> paramTreeItem) {
/*  731 */     editingItemPropertyImpl().set(paramTreeItem);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final TreeItem<T> getEditingItem() {
/*  740 */     return (this.editingItem == null) ? null : this.editingItem.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ReadOnlyObjectProperty<TreeItem<T>> editingItemProperty() {
/*  752 */     return editingItemPropertyImpl().getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   private ReadOnlyObjectWrapper<TreeItem<T>> editingItemPropertyImpl() {
/*  756 */     if (this.editingItem == null) {
/*  757 */       this.editingItem = new ReadOnlyObjectWrapper<>(this, "editingItem");
/*      */     }
/*  759 */     return this.editingItem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnEditStart(EventHandler<EditEvent<T>> paramEventHandler) {
/*  773 */     onEditStartProperty().set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EventHandler<EditEvent<T>> getOnEditStart() {
/*  782 */     return (this.onEditStart == null) ? null : this.onEditStart.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<EventHandler<EditEvent<T>>> onEditStartProperty() {
/*  791 */     if (this.onEditStart == null) {
/*  792 */       this.onEditStart = (ObjectProperty)new SimpleObjectProperty<EventHandler<EditEvent<EventHandler<EditEvent<T>>>>>(this, "onEditStart") {
/*      */           protected void invalidated() {
/*  794 */             TreeView.this.setEventHandler((EventType)TreeView.editStartEvent(), (EventHandler)get());
/*      */           }
/*      */         };
/*      */     }
/*  798 */     return this.onEditStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnEditCommit(EventHandler<EditEvent<T>> paramEventHandler) {
/*  812 */     onEditCommitProperty().set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EventHandler<EditEvent<T>> getOnEditCommit() {
/*  822 */     return (this.onEditCommit == null) ? null : this.onEditCommit.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<EventHandler<EditEvent<T>>> onEditCommitProperty() {
/*  837 */     if (this.onEditCommit == null) {
/*  838 */       this.onEditCommit = (ObjectProperty)new SimpleObjectProperty<EventHandler<EditEvent<EventHandler<EditEvent<T>>>>>(this, "onEditCommit") {
/*      */           protected void invalidated() {
/*  840 */             TreeView.this.setEventHandler((EventType)TreeView.editCommitEvent(), (EventHandler)get());
/*      */           }
/*      */         };
/*      */     }
/*  844 */     return this.onEditCommit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnEditCancel(EventHandler<EditEvent<T>> paramEventHandler) {
/*  858 */     onEditCancelProperty().set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EventHandler<EditEvent<T>> getOnEditCancel() {
/*  868 */     return (this.onEditCancel == null) ? null : this.onEditCancel.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<EventHandler<EditEvent<T>>> onEditCancelProperty() {
/*  877 */     if (this.onEditCancel == null) {
/*  878 */       this.onEditCancel = (ObjectProperty)new SimpleObjectProperty<EventHandler<EditEvent<EventHandler<EditEvent<T>>>>>(this, "onEditCancel") {
/*      */           protected void invalidated() {
/*  880 */             TreeView.this.setEventHandler((EventType)TreeView.editCancelEvent(), (EventHandler)get());
/*      */           }
/*      */         };
/*      */     }
/*  884 */     return this.onEditCancel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutChildren() {
/*  898 */     if (this.expandedItemCountDirty) {
/*  899 */       updateExpandedItemCount(getRoot());
/*      */     }
/*      */     
/*  902 */     super.layoutChildren();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void edit(TreeItem<T> paramTreeItem) {
/*  916 */     if (!isEditable())
/*  917 */       return;  setEditingItem(paramTreeItem);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void scrollTo(int paramInt) {
/*  930 */     ControlUtils.scrollToIndex(this, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOnScrollTo(EventHandler<ScrollToEvent<Integer>> paramEventHandler) {
/*  940 */     onScrollToProperty().set(paramEventHandler);
/*      */   }
/*      */   
/*      */   public EventHandler<ScrollToEvent<Integer>> getOnScrollTo() {
/*  944 */     if (this.onScrollTo != null) {
/*  945 */       return this.onScrollTo.get();
/*      */     }
/*  947 */     return null;
/*      */   }
/*      */   
/*      */   public ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollToProperty() {
/*  951 */     if (this.onScrollTo == null) {
/*  952 */       this.onScrollTo = new ObjectPropertyBase<EventHandler<ScrollToEvent<Integer>>>()
/*      */         {
/*      */           protected void invalidated() {
/*  955 */             TreeView.this.setEventHandler((EventType)ScrollToEvent.scrollToTopIndex(), (EventHandler)get());
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  959 */             return TreeView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  964 */             return "onScrollTo";
/*      */           }
/*      */         };
/*      */     }
/*  968 */     return this.onScrollTo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow(TreeItem<T> paramTreeItem) {
/*  985 */     return TreeUtil.getRow(paramTreeItem, getRoot(), this.expandedItemCountDirty, isShowRoot());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TreeItem<T> getTreeItem(int paramInt) {
/*  995 */     if (paramInt < 0) return null;
/*      */ 
/*      */     
/*  998 */     int i = isShowRoot() ? paramInt : (paramInt + 1);
/*      */     
/* 1000 */     if (this.expandedItemCountDirty) {
/* 1001 */       updateExpandedItemCount(getRoot());
/*      */     }
/* 1003 */     else if (this.treeItemCacheMap.containsKey(Integer.valueOf(i))) {
/* 1004 */       SoftReference<TreeItem> softReference = (SoftReference)this.treeItemCacheMap.get(Integer.valueOf(i));
/* 1005 */       TreeItem<T> treeItem1 = softReference.get();
/* 1006 */       if (treeItem1 != null) {
/* 1007 */         return treeItem1;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1012 */     TreeItem<T> treeItem = TreeUtil.getItem(getRoot(), i, this.expandedItemCountDirty);
/* 1013 */     this.treeItemCacheMap.put(Integer.valueOf(i), new SoftReference<>(treeItem));
/* 1014 */     return treeItem;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTreeItemLevel(TreeItem<?> paramTreeItem) {
/* 1029 */     TreeItem<T> treeItem = getRoot();
/*      */     
/* 1031 */     if (paramTreeItem == null) return -1; 
/* 1032 */     if (paramTreeItem == treeItem) return 0;
/*      */     
/* 1034 */     byte b = 0;
/* 1035 */     TreeItem<?> treeItem1 = paramTreeItem.getParent();
/* 1036 */     while (treeItem1 != null) {
/* 1037 */       b++;
/*      */       
/* 1039 */       if (treeItem1 == treeItem) {
/*      */         break;
/*      */       }
/*      */       
/* 1043 */       treeItem1 = treeItem1.getParent();
/*      */     } 
/*      */     
/* 1046 */     return b;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Skin<?> createDefaultSkin() {
/* 1051 */     return (Skin<?>)new TreeViewSkin(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refresh() {
/* 1064 */     getProperties().put("recreateKey", Boolean.TRUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateExpandedItemCount(TreeItem<T> paramTreeItem) {
/* 1076 */     setExpandedItemCount(TreeUtil.updateExpandedItemCount(paramTreeItem, this.expandedItemCountDirty, isShowRoot()));
/*      */     
/* 1078 */     if (this.expandedItemCountDirty)
/*      */     {
/*      */       
/* 1081 */       this.treeItemCacheMap.clear();
/*      */     }
/*      */     
/* 1084 */     this.expandedItemCountDirty = false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateRootExpanded() {
/* 1090 */     if (!isShowRoot() && getRoot() != null && !getRoot().isExpanded()) {
/* 1091 */       getRoot().setExpanded(true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class StyleableProperties
/*      */   {
/* 1106 */     private static final CssMetaData<TreeView<?>, Number> FIXED_CELL_SIZE = new CssMetaData<TreeView<?>, Number>("-fx-fixed-cell-size", 
/*      */         
/* 1108 */         SizeConverter.getInstance(), 
/* 1109 */         Double.valueOf(-1.0D))
/*      */       {
/*      */         public Double getInitialValue(TreeView<?> param2TreeView) {
/* 1112 */           return Double.valueOf(param2TreeView.getFixedCellSize());
/*      */         }
/*      */         
/*      */         public boolean isSettable(TreeView<?> param2TreeView) {
/* 1116 */           return (param2TreeView.fixedCellSize == null || !param2TreeView.fixedCellSize.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(TreeView<?> param2TreeView) {
/* 1120 */           return (StyleableProperty<Number>)param2TreeView.fixedCellSizeProperty();
/*      */         }
/*      */       };
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1127 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 1128 */       arrayList.add(FIXED_CELL_SIZE);
/* 1129 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1139 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 1148 */     return getClassCssMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*      */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel;
/* 1162 */     switch (paramAccessibleAttribute) {
/*      */       case MULTIPLE_SELECTION:
/* 1164 */         multipleSelectionModel = getSelectionModel();
/* 1165 */         return Boolean.valueOf((multipleSelectionModel != null && multipleSelectionModel.getSelectionMode() == SelectionMode.MULTIPLE));
/*      */       case ROW_COUNT:
/* 1167 */         return Integer.valueOf(getExpandedItemCount());
/* 1168 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EditEvent<T>
/*      */     extends Event
/*      */   {
/*      */     private static final long serialVersionUID = -4437033058917528976L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1206 */     public static final EventType<?> ANY = TreeView.EDIT_ANY_EVENT;
/*      */ 
/*      */ 
/*      */     
/*      */     private final TreeView<T> source;
/*      */ 
/*      */ 
/*      */     
/*      */     private final T oldValue;
/*      */ 
/*      */ 
/*      */     
/*      */     private final T newValue;
/*      */ 
/*      */     
/*      */     private final transient TreeItem<T> treeItem;
/*      */ 
/*      */ 
/*      */     
/*      */     public EditEvent(TreeView<T> param1TreeView, EventType<? extends EditEvent> param1EventType, TreeItem<T> param1TreeItem, T param1T1, T param1T2) {
/* 1226 */       super(param1TreeView, Event.NULL_SOURCE_TARGET, (EventType)param1EventType);
/* 1227 */       this.source = param1TreeView;
/* 1228 */       this.oldValue = param1T1;
/* 1229 */       this.newValue = param1T2;
/* 1230 */       this.treeItem = param1TreeItem;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeView<T> getSource() {
/* 1237 */       return this.source;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeItem<T> getTreeItem() {
/* 1245 */       return this.treeItem;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public T getNewValue() {
/* 1253 */       return this.newValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public T getOldValue() {
/* 1263 */       return this.oldValue;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class TreeViewBitSetSelectionModel<T>
/*      */     extends MultipleSelectionModelBase<TreeItem<T>>
/*      */   {
/* 1282 */     private TreeView<T> treeView = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ChangeListener<TreeItem<T>> rootPropertyListener;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private EventHandler<TreeItem.TreeModificationEvent<T>> treeItemListener;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private WeakChangeListener<TreeItem<T>> weakRootPropertyListener;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private WeakEventHandler<TreeItem.TreeModificationEvent<T>> weakTreeItemListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateTreeEventListener(TreeItem<T> param1TreeItem1, TreeItem<T> param1TreeItem2) {
/* 1309 */       if (param1TreeItem1 != null && this.weakTreeItemListener != null) {
/* 1310 */         param1TreeItem1.removeEventHandler(TreeItem.expandedItemCountChangeEvent(), this.weakTreeItemListener);
/*      */       }
/*      */       
/* 1313 */       if (param1TreeItem2 != null) {
/* 1314 */         this.weakTreeItemListener = new WeakEventHandler<>(this.treeItemListener);
/* 1315 */         param1TreeItem2.addEventHandler(TreeItem.expandedItemCountChangeEvent(), this.weakTreeItemListener);
/*      */       } 
/*      */     }
/*      */     public TreeViewBitSetSelectionModel(TreeView<T> param1TreeView) {
/* 1319 */       this.rootPropertyListener = ((param1ObservableValue, param1TreeItem1, param1TreeItem2) -> {
/*      */           updateDefaultSelection();
/*      */           
/*      */           updateTreeEventListener(param1TreeItem1, param1TreeItem2);
/*      */         });
/* 1324 */       this.treeItemListener = (param1TreeModificationEvent -> {
/*      */           if (getSelectedIndex() == -1 && getSelectedItem() == null) {
/*      */             return;
/*      */           }
/*      */           
/*      */           TreeItem<T> treeItem = param1TreeModificationEvent.getTreeItem();
/*      */           
/*      */           if (treeItem == null) {
/*      */             return;
/*      */           }
/*      */           
/*      */           this.treeView.expandedItemCountDirty = true;
/*      */           
/*      */           int i = this.treeView.getRow(treeItem);
/*      */           
/*      */           int j = 0;
/*      */           
/*      */           ListChangeListener.Change change = param1TreeModificationEvent.getChange();
/*      */           
/*      */           if (change != null) {
/*      */             change.next();
/*      */           }
/*      */           
/*      */           do {
/*      */             boolean bool = (change == null) ? false : change.getAddedSize();
/*      */             
/*      */             byte b = (change == null) ? 0 : change.getRemovedSize();
/*      */             if (param1TreeModificationEvent.wasExpanded()) {
/*      */               j += treeItem.getExpandedDescendentCount(false) - 1;
/*      */               i++;
/*      */             } else if (param1TreeModificationEvent.wasCollapsed()) {
/*      */               treeItem.getExpandedDescendentCount(false);
/*      */               int k = treeItem.previousExpandedDescendentCount;
/*      */               int m = getSelectedIndex();
/* 1358 */               boolean bool1 = (m >= i + 1 && m < i + k) ? true : false;
/*      */               
/*      */               boolean bool2 = false;
/*      */               
/*      */               this.selectedIndices._beginChange();
/*      */               
/*      */               int n = i + 1;
/*      */               
/*      */               int i1 = i + k;
/*      */               
/*      */               ArrayList<Integer> arrayList = new ArrayList();
/*      */               
/*      */               for (int i2 = n; i2 < i1; i2++) {
/*      */                 if (isSelected(i2)) {
/*      */                   bool2 = true;
/*      */                   
/*      */                   arrayList.add(Integer.valueOf(i2));
/*      */                 } 
/*      */               } 
/*      */               
/*      */               ControlUtils.reducingChange(this.selectedIndices, arrayList);
/*      */               
/*      */               Iterator<Integer> iterator = arrayList.iterator();
/*      */               
/*      */               while (iterator.hasNext()) {
/*      */                 int i3 = ((Integer)iterator.next()).intValue();
/*      */                 
/*      */                 startAtomic();
/*      */                 
/*      */                 clearSelection(i3);
/*      */                 
/*      */                 stopAtomic();
/*      */               } 
/*      */               
/*      */               this.selectedIndices._endChange();
/*      */               
/*      */               if (bool1 && bool2) {
/*      */                 select(i);
/*      */               }
/*      */               
/*      */               j += -k + 1;
/*      */               
/*      */               i++;
/*      */             } else if (!param1TreeModificationEvent.wasPermutated()) {
/*      */               if (param1TreeModificationEvent.wasAdded()) {
/*      */                 j += treeItem.isExpanded() ? bool : 0;
/*      */                 
/*      */                 i = this.treeView.getRow(param1TreeModificationEvent.getChange().getAddedSubList().get(0));
/*      */               } else if (param1TreeModificationEvent.wasRemoved()) {
/*      */                 j += treeItem.isExpanded() ? -b : 0;
/*      */                 
/*      */                 i += param1TreeModificationEvent.getFrom() + 1;
/*      */                 
/*      */                 ObservableList<Integer> observableList = getSelectedIndices();
/*      */                 
/*      */                 int k = getSelectedIndex();
/*      */                 
/*      */                 ObservableList<TreeItem<T>> observableList1 = getSelectedItems();
/*      */                 
/*      */                 TreeItem<T> treeItem1 = getSelectedItem();
/*      */                 
/*      */                 List list = param1TreeModificationEvent.getChange().getRemoved();
/*      */                 
/*      */                 byte b1 = 0;
/*      */                 
/*      */                 while (b1 < observableList.size() && !observableList1.isEmpty()) {
/*      */                   int m = ((Integer)observableList.get(b1)).intValue();
/*      */                   
/*      */                   if (m > observableList1.size()) {
/*      */                     break;
/*      */                   }
/*      */                   
/*      */                   if (list.size() == 1 && observableList1.size() == 1 && treeItem1 != null && treeItem1.equals(list.get(0))) {
/*      */                     if (k < getItemCount()) {
/*      */                       boolean bool1 = (k == 0) ? false : (k - 1);
/*      */                       
/*      */                       TreeItem<T> treeItem2 = getModelItem(bool1);
/*      */                       
/*      */                       if (!treeItem1.equals(treeItem2)) {
/*      */                         select(treeItem2);
/*      */                       }
/*      */                     } 
/*      */                   }
/*      */                   
/*      */                   b1++;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } while (param1TreeModificationEvent.getChange() != null && param1TreeModificationEvent.getChange().next());
/*      */           shiftSelection(i, j, (Callback<MultipleSelectionModelBase.ShiftParams, Void>)null);
/*      */           if (param1TreeModificationEvent.wasAdded() || param1TreeModificationEvent.wasRemoved()) {
/*      */             Integer integer = (Integer)TreeCellBehavior.getAnchor(this.treeView, null);
/*      */             if (integer != null && isSelected(integer.intValue() + j)) {
/*      */               TreeCellBehavior.setAnchor(this.treeView, (TreeCell<T>)Integer.valueOf(integer.intValue() + j), false);
/*      */             }
/*      */           } 
/*      */         });
/* 1455 */       this.weakRootPropertyListener = new WeakChangeListener<>(this.rootPropertyListener);
/*      */       if (param1TreeView == null) {
/*      */         throw new IllegalArgumentException("TreeView can not be null");
/*      */       }
/*      */       this.treeView = param1TreeView;
/*      */       this.treeView.rootProperty().addListener(this.weakRootPropertyListener);
/*      */       this.treeView.showRootProperty().addListener(param1Observable -> shiftSelection(0, param1TreeView.isShowRoot() ? 1 : -1, (Callback<MultipleSelectionModelBase.ShiftParams, Void>)null));
/*      */       updateTreeEventListener((TreeItem<T>)null, param1TreeView.getRoot());
/*      */       updateDefaultSelection();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void selectAll() {
/* 1472 */       int i = ((Integer)TreeCellBehavior.getAnchor(this.treeView, (TreeCell<T>)Integer.valueOf(-1))).intValue();
/* 1473 */       super.selectAll();
/* 1474 */       TreeCellBehavior.setAnchor(this.treeView, (TreeCell<T>)Integer.valueOf(i), false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void select(TreeItem<T> param1TreeItem) {
/* 1481 */       if (param1TreeItem == null && getSelectionMode() == SelectionMode.SINGLE) {
/* 1482 */         clearSelection();
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/* 1490 */       if (param1TreeItem != null) {
/* 1491 */         TreeItem<T> treeItem = param1TreeItem.getParent();
/* 1492 */         while (treeItem != null) {
/* 1493 */           treeItem.setExpanded(true);
/* 1494 */           treeItem = treeItem.getParent();
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1500 */       this.treeView.updateExpandedItemCount(this.treeView.getRoot());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1505 */       int i = this.treeView.getRow(param1TreeItem);
/*      */       
/* 1507 */       if (i == -1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1513 */         setSelectedIndex(-1);
/* 1514 */         setSelectedItem(param1TreeItem);
/*      */       } else {
/* 1516 */         select(i);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void clearAndSelect(int param1Int) {
/* 1522 */       TreeCellBehavior.setAnchor(this.treeView, (TreeCell<T>)Integer.valueOf(param1Int), false);
/* 1523 */       super.clearAndSelect(param1Int);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void focus(int param1Int) {
/* 1535 */       if (this.treeView.getFocusModel() != null) {
/* 1536 */         this.treeView.getFocusModel().focus(param1Int);
/*      */       }
/*      */ 
/*      */       
/* 1540 */       this.treeView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getFocusedIndex() {
/* 1545 */       if (this.treeView.getFocusModel() == null) return -1; 
/* 1546 */       return this.treeView.getFocusModel().getFocusedIndex();
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getItemCount() {
/* 1551 */       return (this.treeView == null) ? 0 : this.treeView.getExpandedItemCount();
/*      */     }
/*      */ 
/*      */     
/*      */     public TreeItem<T> getModelItem(int param1Int) {
/* 1556 */       if (this.treeView == null) return null;
/*      */       
/* 1558 */       if (param1Int < 0 || param1Int >= this.treeView.getExpandedItemCount()) return null;
/*      */       
/* 1560 */       return this.treeView.getTreeItem(param1Int);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateDefaultSelection() {
/* 1572 */       clearSelection();
/*      */ 
/*      */ 
/*      */       
/* 1576 */       focus((getItemCount() > 0) ? 0 : -1);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class TreeViewFocusModel<T>
/*      */     extends FocusModel<TreeItem<T>>
/*      */   {
/*      */     private final TreeView<T> treeView;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ChangeListener<TreeItem<T>> rootPropertyListener;
/*      */ 
/*      */ 
/*      */     
/*      */     private final WeakChangeListener<TreeItem<T>> weakRootPropertyListener;
/*      */ 
/*      */ 
/*      */     
/*      */     private EventHandler<TreeItem.TreeModificationEvent<T>> treeItemListener;
/*      */ 
/*      */ 
/*      */     
/*      */     private WeakEventHandler<TreeItem.TreeModificationEvent<T>> weakTreeItemListener;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeViewFocusModel(TreeView<T> param1TreeView)
/*      */     {
/* 1611 */       this.rootPropertyListener = ((param1ObservableValue, param1TreeItem1, param1TreeItem2) -> updateTreeEventListener(param1TreeItem1, param1TreeItem2));
/*      */ 
/*      */ 
/*      */       
/* 1615 */       this.weakRootPropertyListener = new WeakChangeListener<>(this.rootPropertyListener);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1629 */       this.treeItemListener = (EventHandler)new EventHandler<TreeItem.TreeModificationEvent<TreeItem.TreeModificationEvent<T>>>()
/*      */         {
/*      */           public void handle(TreeItem.TreeModificationEvent<T> param2TreeModificationEvent)
/*      */           {
/* 1633 */             if (TreeView.TreeViewFocusModel.this.getFocusedIndex() == -1)
/*      */               return; 
/* 1635 */             int i = TreeView.TreeViewFocusModel.this.treeView.getRow(param2TreeModificationEvent.getTreeItem());
/*      */             
/* 1637 */             int j = 0;
/* 1638 */             if (param2TreeModificationEvent.getChange() != null) {
/* 1639 */               param2TreeModificationEvent.getChange().next();
/*      */             }
/*      */             
/*      */             do {
/* 1643 */               if (param2TreeModificationEvent.wasExpanded()) {
/* 1644 */                 if (i < TreeView.TreeViewFocusModel.this.getFocusedIndex())
/*      */                 {
/* 1646 */                   j += param2TreeModificationEvent.getTreeItem().getExpandedDescendentCount(false) - 1;
/*      */                 }
/* 1648 */               } else if (param2TreeModificationEvent.wasCollapsed()) {
/* 1649 */                 if (i < TreeView.TreeViewFocusModel.this.getFocusedIndex())
/*      */                 {
/*      */                   
/* 1652 */                   j += -(param2TreeModificationEvent.getTreeItem()).previousExpandedDescendentCount + 1;
/*      */                 }
/* 1654 */               } else if (param2TreeModificationEvent.wasAdded()) {
/*      */ 
/*      */                 
/* 1657 */                 TreeItem<T> treeItem = param2TreeModificationEvent.getTreeItem();
/* 1658 */                 if (treeItem.isExpanded()) {
/* 1659 */                   for (byte b = 0; b < param2TreeModificationEvent.getAddedChildren().size(); b++) {
/*      */                     
/* 1661 */                     TreeItem treeItem1 = param2TreeModificationEvent.getAddedChildren().get(b);
/* 1662 */                     i = TreeView.TreeViewFocusModel.this.treeView.getRow(treeItem1);
/*      */                     
/* 1664 */                     if (treeItem1 != null && i <= j + TreeView.TreeViewFocusModel.this.getFocusedIndex()) {
/* 1665 */                       j += treeItem1.getExpandedDescendentCount(false);
/*      */                     }
/*      */                   } 
/*      */                 }
/* 1669 */               } else if (param2TreeModificationEvent.wasRemoved()) {
/* 1670 */                 i += param2TreeModificationEvent.getFrom() + 1;
/*      */                 
/* 1672 */                 for (byte b = 0; b < param2TreeModificationEvent.getRemovedChildren().size(); b++) {
/* 1673 */                   TreeItem treeItem = param2TreeModificationEvent.getRemovedChildren().get(b);
/* 1674 */                   if (treeItem != null && treeItem.equals(TreeView.TreeViewFocusModel.this.getFocusedItem())) {
/* 1675 */                     TreeView.TreeViewFocusModel.this.focus(Math.max(0, TreeView.TreeViewFocusModel.this.getFocusedIndex() - 1));
/*      */                     
/*      */                     return;
/*      */                   } 
/*      */                 } 
/* 1680 */                 if (i <= TreeView.TreeViewFocusModel.this.getFocusedIndex())
/*      */                 {
/* 1682 */                   j += param2TreeModificationEvent.getTreeItem().isExpanded() ? -param2TreeModificationEvent.getRemovedSize() : 0;
/*      */                 }
/*      */               } 
/* 1685 */             } while (param2TreeModificationEvent.getChange() != null && param2TreeModificationEvent.getChange().next());
/*      */             
/* 1687 */             if (j != 0) {
/* 1688 */               int k = TreeView.TreeViewFocusModel.this.getFocusedIndex() + j;
/* 1689 */               if (k >= 0)
/* 1690 */                 Platform.runLater(() -> TreeView.TreeViewFocusModel.this.focus(param2Int)); 
/*      */             }  }
/*      */         }; this.treeView = param1TreeView; this.treeView.rootProperty().addListener(this.weakRootPropertyListener); updateTreeEventListener((TreeItem<T>)null, param1TreeView.getRoot()); if (param1TreeView.getExpandedItemCount() > 0)
/*      */         focus(0);  param1TreeView.showRootProperty().addListener(param1Observable -> { if (isFocused(0)) {
/*      */               focus(-1); focus(0);
/*      */             } 
/*      */           }); focusedIndexProperty().addListener(param1Observable -> param1TreeView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM)); } private void updateTreeEventListener(TreeItem<T> param1TreeItem1, TreeItem<T> param1TreeItem2) { if (param1TreeItem1 != null && this.weakTreeItemListener != null)
/*      */         param1TreeItem1.removeEventHandler(TreeItem.expandedItemCountChangeEvent(), this.weakTreeItemListener);  if (param1TreeItem2 != null) {
/*      */         this.weakTreeItemListener = new WeakEventHandler<>(this.treeItemListener); param1TreeItem2.addEventHandler(TreeItem.expandedItemCountChangeEvent(), this.weakTreeItemListener);
/* 1699 */       }  } protected int getItemCount() { return (this.treeView == null) ? -1 : this.treeView.getExpandedItemCount(); }
/*      */ 
/*      */     
/*      */     protected TreeItem<T> getModelItem(int param1Int) {
/* 1703 */       if (this.treeView == null) return null;
/*      */       
/* 1705 */       if (param1Int < 0 || param1Int >= this.treeView.getExpandedItemCount()) return null;
/*      */       
/* 1707 */       return this.treeView.getTreeItem(param1Int);
/*      */     }
/*      */ 
/*      */     
/*      */     public void focus(int param1Int) {
/* 1712 */       if (this.treeView.expandedItemCountDirty) {
/* 1713 */         this.treeView.updateExpandedItemCount(this.treeView.getRoot());
/*      */       }
/*      */       
/* 1716 */       super.focus(param1Int);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TreeView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */