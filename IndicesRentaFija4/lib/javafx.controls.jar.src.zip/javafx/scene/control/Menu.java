/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.collections.TrackableObservableList;
/*     */ import com.sun.javafx.scene.control.Logging;
/*     */ import javafx.beans.DefaultProperty;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventDispatchChain;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @DefaultProperty("items")
/*     */ public class Menu
/*     */   extends MenuItem
/*     */ {
/*  91 */   public static final EventType<Event> ON_SHOWING = new EventType<>(Event.ANY, "MENU_ON_SHOWING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static final EventType<Event> ON_SHOWN = new EventType<>(Event.ANY, "MENU_ON_SHOWN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public static final EventType<Event> ON_HIDING = new EventType<>(Event.ANY, "MENU_ON_HIDING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public static final EventType<Event> ON_HIDDEN = new EventType<>(Event.ANY, "MENU_ON_HIDDEN");
/*     */   
/*     */   private ReadOnlyBooleanWrapper showing;
/*     */   
/*     */   private ObjectProperty<EventHandler<Event>> onShowing;
/*     */   
/*     */   private ObjectProperty<EventHandler<Event>> onShown;
/*     */   private ObjectProperty<EventHandler<Event>> onHiding;
/*     */   private ObjectProperty<EventHandler<Event>> onHidden;
/*     */   private final ObservableList<MenuItem> items;
/*     */   private static final String DEFAULT_STYLE_CLASS = "menu";
/*     */   private static final String STYLE_CLASS_SHOWING = "showing";
/*     */   
/*     */   public Menu() {
/* 129 */     this("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Menu(String paramString) {
/* 138 */     this(paramString, (Node)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Menu(String paramString, Node paramNode) {
/* 149 */     this(paramString, paramNode, (MenuItem[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Menu(String paramString, Node paramNode, MenuItem... paramVarArgs) {
/* 163 */     super(paramString, paramNode);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     this.onShowing = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 265 */           Menu.this.eventHandlerManager.setEventHandler(Menu.ON_SHOWING, get());
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 270 */           return Menu.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 275 */           return "onShowing";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 288 */     this.onShown = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 290 */           Menu.this.eventHandlerManager.setEventHandler(Menu.ON_SHOWN, get());
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 295 */           return Menu.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 300 */           return "onShown";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     this.onHiding = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 315 */           Menu.this.eventHandlerManager.setEventHandler(Menu.ON_HIDING, get());
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 320 */           return Menu.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 325 */           return "onHiding";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 338 */     this.onHidden = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */         protected void invalidated() {
/* 340 */           Menu.this.eventHandlerManager.setEventHandler(Menu.ON_HIDDEN, get());
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 345 */           return Menu.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 350 */           return "onHidden";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 362 */     this.items = new TrackableObservableList<MenuItem>()
/*     */       {
/* 364 */         protected void onChanged(ListChangeListener.Change<MenuItem> param1Change) { while (param1Change.next()) {
/*     */             
/* 366 */             for (MenuItem menuItem : param1Change.getRemoved()) {
/* 367 */               menuItem.setParentMenu(null);
/* 368 */               menuItem.setParentPopup(null);
/*     */             } 
/*     */ 
/*     */             
/* 372 */             for (MenuItem menuItem : param1Change.getAddedSubList()) {
/* 373 */               if (menuItem.getParentMenu() != null) {
/* 374 */                 Logging.getControlsLogger().warning("Adding MenuItem " + menuItem
/* 375 */                     .getText() + " that has already been added to " + menuItem
/* 376 */                     .getParentMenu().getText());
/* 377 */                 menuItem.getParentMenu().getItems().remove(menuItem);
/*     */               } 
/*     */               
/* 380 */               menuItem.setParentMenu(Menu.this);
/* 381 */               menuItem.setParentPopup(Menu.this.getParentPopup());
/*     */             } 
/*     */           } 
/* 384 */           if (Menu.this.getItems().size() == 0 && Menu.this.isShowing())
/* 385 */             Menu.this.showingPropertyImpl().set(false);  }
/*     */       }; getStyleClass().add("menu"); if (paramVarArgs != null)
/*     */       getItems().addAll(paramVarArgs);  parentPopupProperty().addListener(paramObservable -> { for (byte b = 0; b < getItems().size(); b++) { MenuItem menuItem = getItems().get(b); menuItem.setParentPopup(getParentPopup()); }
/*     */         
/*     */         });
/*     */   }
/*     */   private void setShowing(boolean paramBoolean) { if (getItems().size() == 0 || (paramBoolean && isShowing()))
/*     */       return;  if (paramBoolean) { if (getOnMenuValidation() != null) { Event.fireEvent(this, new Event(MENU_VALIDATION_EVENT)); for (MenuItem menuItem : getItems()) { if (!(menuItem instanceof Menu) && menuItem.getOnMenuValidation() != null)
/*     */             Event.fireEvent(menuItem, new Event(MenuItem.MENU_VALIDATION_EVENT));  }
/*     */          }
/*     */        Event.fireEvent(this, new Event(ON_SHOWING)); }
/*     */     else { Event.fireEvent(this, new Event(ON_HIDING)); }
/*     */      showingPropertyImpl().set(paramBoolean); Event.fireEvent(this, paramBoolean ? new Event(ON_SHOWN) : new Event(ON_HIDDEN)); }
/*     */   public final boolean isShowing() { return (this.showing == null) ? false : this.showing.get(); }
/*     */   public final ReadOnlyBooleanProperty showingProperty() { return showingPropertyImpl().getReadOnlyProperty(); } private ReadOnlyBooleanWrapper showingPropertyImpl() { if (this.showing == null)
/*     */       this.showing = new ReadOnlyBooleanWrapper() {
/*     */           protected void invalidated() { get(); if (Menu.this.isShowing()) { Menu.this.getStyleClass().add("showing"); }
/*     */             else { Menu.this.getStyleClass().remove("showing"); }
/*     */              } public Object getBean() { return Menu.this; } public String getName() { return "showing"; }
/* 404 */         };  return this.showing; } public final ObservableList<MenuItem> getItems() { return this.items; }
/*     */   public final ObjectProperty<EventHandler<Event>> onShowingProperty() { return this.onShowing; }
/*     */   public final void setOnShowing(EventHandler<Event> paramEventHandler) { onShowingProperty().set(paramEventHandler); }
/*     */   public final EventHandler<Event> getOnShowing() { return onShowingProperty().get(); }
/*     */   public final ObjectProperty<EventHandler<Event>> onShownProperty() { return this.onShown; }
/*     */   public final void setOnShown(EventHandler<Event> paramEventHandler) { onShownProperty().set(paramEventHandler); }
/*     */   public final EventHandler<Event> getOnShown() { return onShownProperty().get(); }
/*     */   public final ObjectProperty<EventHandler<Event>> onHidingProperty() { return this.onHiding; }
/* 412 */   public final void setOnHiding(EventHandler<Event> paramEventHandler) { onHidingProperty().set(paramEventHandler); } public final EventHandler<Event> getOnHiding() { return onHidingProperty().get(); } public final ObjectProperty<EventHandler<Event>> onHiddenProperty() { return this.onHidden; } public final void setOnHidden(EventHandler<Event> paramEventHandler) { onHiddenProperty().set(paramEventHandler); } public final EventHandler<Event> getOnHidden() { return onHiddenProperty().get(); } public void show() { if (isDisable())
/* 413 */       return;  setShowing(true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hide() {
/* 422 */     if (!isShowing())
/*     */       return; 
/* 424 */     for (MenuItem menuItem : getItems()) {
/* 425 */       if (menuItem instanceof Menu) {
/* 426 */         Menu menu = (Menu)menuItem;
/* 427 */         menu.hide();
/*     */       } 
/*     */     } 
/* 430 */     setShowing(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Event> void addEventHandler(EventType<E> paramEventType, EventHandler<E> paramEventHandler) {
/* 435 */     this.eventHandlerManager.addEventHandler(paramEventType, paramEventHandler);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Event> void removeEventHandler(EventType<E> paramEventType, EventHandler<E> paramEventHandler) {
/* 440 */     this.eventHandlerManager.removeEventHandler(paramEventType, paramEventHandler);
/*     */   }
/*     */ 
/*     */   
/*     */   public EventDispatchChain buildEventDispatchChain(EventDispatchChain paramEventDispatchChain) {
/* 445 */     return paramEventDispatchChain.prepend(this.eventHandlerManager);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Menu.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */