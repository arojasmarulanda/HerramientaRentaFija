/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import javafx.beans.NamedArg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ButtonType
/*     */ {
/*  50 */   public static final ButtonType APPLY = new ButtonType("Dialog.apply.button", null, ButtonBar.ButtonData.APPLY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public static final ButtonType OK = new ButtonType("Dialog.ok.button", null, ButtonBar.ButtonData.OK_DONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final ButtonType CANCEL = new ButtonType("Dialog.cancel.button", null, ButtonBar.ButtonData.CANCEL_CLOSE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public static final ButtonType CLOSE = new ButtonType("Dialog.close.button", null, ButtonBar.ButtonData.CANCEL_CLOSE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final ButtonType YES = new ButtonType("Dialog.yes.button", null, ButtonBar.ButtonData.YES);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public static final ButtonType NO = new ButtonType("Dialog.no.button", null, ButtonBar.ButtonData.NO);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public static final ButtonType FINISH = new ButtonType("Dialog.finish.button", null, ButtonBar.ButtonData.FINISH);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static final ButtonType NEXT = new ButtonType("Dialog.next.button", null, ButtonBar.ButtonData.NEXT_FORWARD);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public static final ButtonType PREVIOUS = new ButtonType("Dialog.previous.button", null, ButtonBar.ButtonData.BACK_PREVIOUS);
/*     */ 
/*     */ 
/*     */   
/*     */   private final String key;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String text;
/*     */ 
/*     */   
/*     */   private final ButtonBar.ButtonData buttonData;
/*     */ 
/*     */ 
/*     */   
/*     */   public ButtonType(@NamedArg("text") String paramString) {
/* 122 */     this(paramString, ButtonBar.ButtonData.OTHER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ButtonType(@NamedArg("text") String paramString, @NamedArg("buttonData") ButtonBar.ButtonData paramButtonData) {
/* 135 */     this(null, paramString, paramButtonData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ButtonType(String paramString1, String paramString2, ButtonBar.ButtonData paramButtonData) {
/* 142 */     this.key = paramString1;
/* 143 */     this.text = paramString2;
/* 144 */     this.buttonData = paramButtonData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ButtonBar.ButtonData getButtonData() {
/* 151 */     return this.buttonData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getText() {
/* 158 */     if (this.text == null && this.key != null) {
/* 159 */       return ControlResources.getString(this.key);
/*     */     }
/* 161 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 167 */     return "ButtonType [text=" + getText() + ", buttonData=" + getButtonData() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ButtonType.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */