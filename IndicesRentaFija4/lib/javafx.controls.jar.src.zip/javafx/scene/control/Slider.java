/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.DoublePropertyBase;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableIntegerProperty;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.css.converter.EnumConverter;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.SliderSkin;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Slider
/*     */   extends Control
/*     */ {
/*     */   private DoubleProperty max;
/*     */   private DoubleProperty min;
/*     */   private DoubleProperty value;
/*     */   private BooleanProperty valueChanging;
/*     */   private ObjectProperty<Orientation> orientation;
/*     */   private BooleanProperty showTickLabels;
/*     */   private BooleanProperty showTickMarks;
/*     */   private DoubleProperty majorTickUnit;
/*     */   private IntegerProperty minorTickCount;
/*     */   private BooleanProperty snapToTicks;
/*     */   private ObjectProperty<StringConverter<Double>> labelFormatter;
/*     */   private DoubleProperty blockIncrement;
/*     */   private static final String DEFAULT_STYLE_CLASS = "slider";
/*     */   
/*     */   public Slider() {
/* 108 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Slider(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 118 */     setMax(paramDouble2);
/* 119 */     setMin(paramDouble1);
/* 120 */     setValue(paramDouble3);
/* 121 */     adjustValues();
/* 122 */     initialize();
/*     */   }
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 127 */     getStyleClass().setAll(new String[] { "slider" });
/* 128 */     setAccessibleRole(AccessibleRole.SLIDER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMax(double paramDouble) {
/* 136 */     maxProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getMax() {
/* 140 */     return (this.max == null) ? 100.0D : this.max.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty maxProperty() {
/* 144 */     if (this.max == null) {
/* 145 */       this.max = new DoublePropertyBase(100.0D) {
/*     */           protected void invalidated() {
/* 147 */             if (get() < Slider.this.getMin()) {
/* 148 */               Slider.this.setMin(get());
/*     */             }
/* 150 */             Slider.this.adjustValues();
/* 151 */             Slider.this.notifyAccessibleAttributeChanged(AccessibleAttribute.MAX_VALUE);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 156 */             return Slider.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 161 */             return "max";
/*     */           }
/*     */         };
/*     */     }
/* 165 */     return this.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMin(double paramDouble) {
/* 173 */     minProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getMin() {
/* 177 */     return (this.min == null) ? 0.0D : this.min.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty minProperty() {
/* 181 */     if (this.min == null) {
/* 182 */       this.min = new DoublePropertyBase(0.0D) {
/*     */           protected void invalidated() {
/* 184 */             if (get() > Slider.this.getMax()) {
/* 185 */               Slider.this.setMax(get());
/*     */             }
/* 187 */             Slider.this.adjustValues();
/* 188 */             Slider.this.notifyAccessibleAttributeChanged(AccessibleAttribute.MIN_VALUE);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 193 */             return Slider.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 198 */             return "min";
/*     */           }
/*     */         };
/*     */     }
/* 202 */     return this.min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setValue(double paramDouble) {
/* 213 */     if (!valueProperty().isBound()) valueProperty().set(paramDouble); 
/*     */   }
/*     */   
/*     */   public final double getValue() {
/* 217 */     return (this.value == null) ? 0.0D : this.value.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty valueProperty() {
/* 221 */     if (this.value == null) {
/* 222 */       this.value = new DoublePropertyBase(0.0D) {
/*     */           protected void invalidated() {
/* 224 */             Slider.this.adjustValues();
/* 225 */             Slider.this.notifyAccessibleAttributeChanged(AccessibleAttribute.VALUE);
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 230 */             return Slider.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 235 */             return "value";
/*     */           }
/*     */         };
/*     */     }
/* 239 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setValueChanging(boolean paramBoolean) {
/* 249 */     valueChangingProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isValueChanging() {
/* 253 */     return (this.valueChanging == null) ? false : this.valueChanging.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty valueChangingProperty() {
/* 257 */     if (this.valueChanging == null) {
/* 258 */       this.valueChanging = new SimpleBooleanProperty(this, "valueChanging", false);
/*     */     }
/* 260 */     return this.valueChanging;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOrientation(Orientation paramOrientation) {
/* 275 */     orientationProperty().set(paramOrientation);
/*     */   }
/*     */   
/*     */   public final Orientation getOrientation() {
/* 279 */     return (this.orientation == null) ? Orientation.HORIZONTAL : this.orientation.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<Orientation> orientationProperty() {
/* 283 */     if (this.orientation == null) {
/* 284 */       this.orientation = new StyleableObjectProperty<Orientation>(Orientation.HORIZONTAL) {
/*     */           protected void invalidated() {
/* 286 */             boolean bool = (get() == Orientation.VERTICAL) ? true : false;
/* 287 */             Slider.this.pseudoClassStateChanged(Slider.VERTICAL_PSEUDOCLASS_STATE, bool);
/* 288 */             Slider.this.pseudoClassStateChanged(Slider.HORIZONTAL_PSEUDOCLASS_STATE, !bool);
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<Slider, Orientation> getCssMetaData() {
/* 293 */             return Slider.StyleableProperties.ORIENTATION;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 298 */             return Slider.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 303 */             return "orientation";
/*     */           }
/*     */         };
/*     */     }
/* 307 */     return this.orientation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setShowTickLabels(boolean paramBoolean) {
/* 318 */     showTickLabelsProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isShowTickLabels() {
/* 322 */     return (this.showTickLabels == null) ? false : this.showTickLabels.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty showTickLabelsProperty() {
/* 326 */     if (this.showTickLabels == null) {
/* 327 */       this.showTickLabels = new StyleableBooleanProperty(false)
/*     */         {
/*     */           
/*     */           public CssMetaData<Slider, Boolean> getCssMetaData()
/*     */           {
/* 332 */             return Slider.StyleableProperties.SHOW_TICK_LABELS;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 337 */             return Slider.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 342 */             return "showTickLabels";
/*     */           }
/*     */         };
/*     */     }
/* 346 */     return this.showTickLabels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setShowTickMarks(boolean paramBoolean) {
/* 353 */     showTickMarksProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isShowTickMarks() {
/* 357 */     return (this.showTickMarks == null) ? false : this.showTickMarks.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty showTickMarksProperty() {
/* 361 */     if (this.showTickMarks == null) {
/* 362 */       this.showTickMarks = new StyleableBooleanProperty(false)
/*     */         {
/*     */           
/*     */           public CssMetaData<Slider, Boolean> getCssMetaData()
/*     */           {
/* 367 */             return Slider.StyleableProperties.SHOW_TICK_MARKS;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 372 */             return Slider.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 377 */             return "showTickMarks";
/*     */           }
/*     */         };
/*     */     }
/* 381 */     return this.showTickMarks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMajorTickUnit(double paramDouble) {
/* 396 */     if (paramDouble <= 0.0D) {
/* 397 */       throw new IllegalArgumentException("MajorTickUnit cannot be less than or equal to 0.");
/*     */     }
/* 399 */     majorTickUnitProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getMajorTickUnit() {
/* 403 */     return (this.majorTickUnit == null) ? 25.0D : this.majorTickUnit.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty majorTickUnitProperty() {
/* 407 */     if (this.majorTickUnit == null) {
/* 408 */       this.majorTickUnit = new StyleableDoubleProperty(25.0D)
/*     */         {
/*     */           public void invalidated() {
/* 411 */             if (get() <= 0.0D) {
/* 412 */               throw new IllegalArgumentException("MajorTickUnit cannot be less than or equal to 0.");
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<Slider, Number> getCssMetaData() {
/* 418 */             return Slider.StyleableProperties.MAJOR_TICK_UNIT;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 423 */             return Slider.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 428 */             return "majorTickUnit";
/*     */           }
/*     */         };
/*     */     }
/* 432 */     return this.majorTickUnit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMinorTickCount(int paramInt) {
/* 441 */     minorTickCountProperty().set(paramInt);
/*     */   }
/*     */   
/*     */   public final int getMinorTickCount() {
/* 445 */     return (this.minorTickCount == null) ? 3 : this.minorTickCount.get();
/*     */   }
/*     */   
/*     */   public final IntegerProperty minorTickCountProperty() {
/* 449 */     if (this.minorTickCount == null) {
/* 450 */       this.minorTickCount = new StyleableIntegerProperty(3)
/*     */         {
/*     */           
/*     */           public CssMetaData<Slider, Number> getCssMetaData()
/*     */           {
/* 455 */             return Slider.StyleableProperties.MINOR_TICK_COUNT;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 460 */             return Slider.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 465 */             return "minorTickCount";
/*     */           }
/*     */         };
/*     */     }
/* 469 */     return this.minorTickCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSnapToTicks(boolean paramBoolean) {
/* 478 */     snapToTicksProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isSnapToTicks() {
/* 482 */     return (this.snapToTicks == null) ? false : this.snapToTicks.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty snapToTicksProperty() {
/* 486 */     if (this.snapToTicks == null) {
/* 487 */       this.snapToTicks = new StyleableBooleanProperty(false)
/*     */         {
/*     */           public CssMetaData<Slider, Boolean> getCssMetaData()
/*     */           {
/* 491 */             return Slider.StyleableProperties.SNAP_TO_TICKS;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 496 */             return Slider.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 501 */             return "snapToTicks";
/*     */           }
/*     */         };
/*     */     }
/* 505 */     return this.snapToTicks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setLabelFormatter(StringConverter<Double> paramStringConverter) {
/* 516 */     labelFormatterProperty().set(paramStringConverter);
/*     */   }
/*     */   
/*     */   public final StringConverter<Double> getLabelFormatter() {
/* 520 */     return (this.labelFormatter == null) ? null : this.labelFormatter.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<StringConverter<Double>> labelFormatterProperty() {
/* 524 */     if (this.labelFormatter == null) {
/* 525 */       this.labelFormatter = new SimpleObjectProperty<>(this, "labelFormatter");
/*     */     }
/* 527 */     return this.labelFormatter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBlockIncrement(double paramDouble) {
/* 537 */     blockIncrementProperty().set(paramDouble);
/*     */   }
/*     */   
/*     */   public final double getBlockIncrement() {
/* 541 */     return (this.blockIncrement == null) ? 10.0D : this.blockIncrement.get();
/*     */   }
/*     */   
/*     */   public final DoubleProperty blockIncrementProperty() {
/* 545 */     if (this.blockIncrement == null) {
/* 546 */       this.blockIncrement = new StyleableDoubleProperty(10.0D)
/*     */         {
/*     */           public CssMetaData<Slider, Number> getCssMetaData()
/*     */           {
/* 550 */             return Slider.StyleableProperties.BLOCK_INCREMENT;
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 555 */             return Slider.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 560 */             return "blockIncrement";
/*     */           }
/*     */         };
/*     */     }
/* 564 */     return this.blockIncrement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustValue(double paramDouble) {
/* 582 */     double d1 = getMin();
/* 583 */     double d2 = getMax();
/* 584 */     if (d2 <= d1)
/* 585 */       return;  paramDouble = (paramDouble < d1) ? d1 : paramDouble;
/* 586 */     paramDouble = (paramDouble > d2) ? d2 : paramDouble;
/*     */     
/* 588 */     setValue(snapValueToTicks(paramDouble));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void increment() {
/* 596 */     adjustValue(getValue() + getBlockIncrement());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decrement() {
/* 604 */     adjustValue(getValue() - getBlockIncrement());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void adjustValues() {
/* 613 */     if (getValue() < getMin() || getValue() > getMax()) {
/* 614 */       setValue(Utils.clamp(getMin(), getValue(), getMax()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double snapValueToTicks(double paramDouble) {
/* 627 */     double d = paramDouble;
/* 628 */     if (isSnapToTicks()) {
/* 629 */       double d1 = 0.0D;
/*     */       
/* 631 */       if (getMinorTickCount() != 0) {
/* 632 */         d1 = getMajorTickUnit() / (Math.max(getMinorTickCount(), 0) + 1);
/*     */       } else {
/* 634 */         d1 = getMajorTickUnit();
/*     */       } 
/* 636 */       int i = (int)((d - getMin()) / d1);
/* 637 */       double d2 = i * d1 + getMin();
/* 638 */       double d3 = (i + 1) * d1 + getMin();
/* 639 */       d = Utils.nearest(d2, d, d3);
/*     */     } 
/* 641 */     return Utils.clamp(getMin(), d, getMax());
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 646 */     return (Skin<?>)new SliderSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 658 */     private static final CssMetaData<Slider, Number> BLOCK_INCREMENT = new CssMetaData<Slider, Number>("-fx-block-increment", 
/*     */         
/* 660 */         SizeConverter.getInstance(), Double.valueOf(10.0D))
/*     */       {
/*     */         public boolean isSettable(Slider param2Slider)
/*     */         {
/* 664 */           return (param2Slider.blockIncrement == null || !param2Slider.blockIncrement.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(Slider param2Slider) {
/* 669 */           return (StyleableProperty<Number>)param2Slider.blockIncrementProperty();
/*     */         }
/*     */       };
/*     */     
/* 673 */     private static final CssMetaData<Slider, Boolean> SHOW_TICK_LABELS = new CssMetaData<Slider, Boolean>("-fx-show-tick-labels", 
/*     */         
/* 675 */         BooleanConverter.getInstance(), Boolean.FALSE)
/*     */       {
/*     */         public boolean isSettable(Slider param2Slider)
/*     */         {
/* 679 */           return (param2Slider.showTickLabels == null || !param2Slider.showTickLabels.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(Slider param2Slider) {
/* 684 */           return (StyleableProperty<Boolean>)param2Slider.showTickLabelsProperty();
/*     */         }
/*     */       };
/*     */     
/* 688 */     private static final CssMetaData<Slider, Boolean> SHOW_TICK_MARKS = new CssMetaData<Slider, Boolean>("-fx-show-tick-marks", 
/*     */         
/* 690 */         BooleanConverter.getInstance(), Boolean.FALSE)
/*     */       {
/*     */         public boolean isSettable(Slider param2Slider)
/*     */         {
/* 694 */           return (param2Slider.showTickMarks == null || !param2Slider.showTickMarks.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(Slider param2Slider) {
/* 699 */           return (StyleableProperty<Boolean>)param2Slider.showTickMarksProperty();
/*     */         }
/*     */       };
/*     */     
/* 703 */     private static final CssMetaData<Slider, Boolean> SNAP_TO_TICKS = new CssMetaData<Slider, Boolean>("-fx-snap-to-ticks", 
/*     */         
/* 705 */         BooleanConverter.getInstance(), Boolean.FALSE)
/*     */       {
/*     */         public boolean isSettable(Slider param2Slider)
/*     */         {
/* 709 */           return (param2Slider.snapToTicks == null || !param2Slider.snapToTicks.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(Slider param2Slider) {
/* 714 */           return (StyleableProperty<Boolean>)param2Slider.snapToTicksProperty();
/*     */         }
/*     */       };
/*     */     
/* 718 */     private static final CssMetaData<Slider, Number> MAJOR_TICK_UNIT = new CssMetaData<Slider, Number>("-fx-major-tick-unit", 
/*     */         
/* 720 */         SizeConverter.getInstance(), Double.valueOf(25.0D))
/*     */       {
/*     */         public boolean isSettable(Slider param2Slider)
/*     */         {
/* 724 */           return (param2Slider.majorTickUnit == null || !param2Slider.majorTickUnit.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(Slider param2Slider) {
/* 729 */           return (StyleableProperty<Number>)param2Slider.majorTickUnitProperty();
/*     */         }
/*     */       };
/*     */     
/* 733 */     private static final CssMetaData<Slider, Number> MINOR_TICK_COUNT = new CssMetaData<Slider, Number>("-fx-minor-tick-count", 
/*     */         
/* 735 */         SizeConverter.getInstance(), Double.valueOf(3.0D))
/*     */       {
/*     */         public boolean isSettable(Slider param2Slider)
/*     */         {
/* 739 */           return (param2Slider.minorTickCount == null || !param2Slider.minorTickCount.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(Slider param2Slider) {
/* 744 */           return (StyleableProperty<Number>)param2Slider.minorTickCountProperty();
/*     */         }
/*     */       };
/*     */     
/* 748 */     private static final CssMetaData<Slider, Orientation> ORIENTATION = new CssMetaData<Slider, Orientation>("-fx-orientation", (StyleConverter)new EnumConverter(Orientation.class), Orientation.HORIZONTAL)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Orientation getInitialValue(Slider param2Slider)
/*     */         {
/* 756 */           return param2Slider.getOrientation();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isSettable(Slider param2Slider) {
/* 761 */           return (param2Slider.orientation == null || !param2Slider.orientation.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Orientation> getStyleableProperty(Slider param2Slider) {
/* 766 */           return (StyleableProperty<Orientation>)param2Slider.orientationProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 773 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 774 */       arrayList.add(BLOCK_INCREMENT);
/* 775 */       arrayList.add(SHOW_TICK_LABELS);
/* 776 */       arrayList.add(SHOW_TICK_MARKS);
/* 777 */       arrayList.add(SNAP_TO_TICKS);
/* 778 */       arrayList.add(MAJOR_TICK_UNIT);
/* 779 */       arrayList.add(MINOR_TICK_COUNT);
/* 780 */       arrayList.add(ORIENTATION);
/*     */       
/* 782 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 792 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 800 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */   
/* 804 */   private static final PseudoClass VERTICAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("vertical");
/*     */   
/* 806 */   private static final PseudoClass HORIZONTAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("horizontal");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 819 */     switch (paramAccessibleAttribute) { case INCREMENT:
/* 820 */         return Double.valueOf(getValue());
/* 821 */       case DECREMENT: return Double.valueOf(getMax());
/* 822 */       case SET_VALUE: return Double.valueOf(getMin());
/* 823 */       case null: return getOrientation(); }
/* 824 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     Double double_;
/* 831 */     switch (paramAccessibleAction) { case INCREMENT:
/* 832 */         increment(); return;
/* 833 */       case DECREMENT: decrement(); return;
/*     */       case SET_VALUE:
/* 835 */         double_ = (Double)paramVarArgs[0];
/* 836 */         if (double_ != null) setValue(double_.doubleValue()); 
/*     */         return; }
/*     */     
/* 839 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Slider.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */