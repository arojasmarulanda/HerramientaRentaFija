/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.TableRowSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableRow<T>
/*     */   extends IndexedCell<T>
/*     */ {
/*     */   private ListChangeListener<Integer> selectedListener;
/*     */   private final InvalidationListener focusedListener;
/*     */   private final InvalidationListener editingListener;
/*     */   private final WeakListChangeListener<Integer> weakSelectedListener;
/*     */   private final WeakInvalidationListener weakFocusedListener;
/*     */   private final WeakInvalidationListener weakEditingListener;
/*     */   private ReadOnlyObjectWrapper<TableView<T>> tableView;
/*     */   private boolean isFirstRun;
/*     */   private static final String DEFAULT_STYLE_CLASS = "table-row-cell";
/*     */   
/*     */   public TableRow() {
/* 100 */     this.selectedListener = (paramChange -> updateSelection());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     this.focusedListener = (paramObservable -> updateFocus());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     this.editingListener = (paramObservable -> updateEditing());
/*     */ 
/*     */ 
/*     */     
/* 114 */     this.weakSelectedListener = new WeakListChangeListener<>(this.selectedListener);
/* 115 */     this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
/* 116 */     this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     this.isFirstRun = true; getStyleClass().addAll(new String[] { "table-row-cell" }); setAccessibleRole(AccessibleRole.TABLE_ROW);
/*     */   } private void setTableView(TableView<T> paramTableView) { tableViewPropertyImpl().set(paramTableView); } public final TableView<T> getTableView() { return (this.tableView == null) ? null : this.tableView.get(); } public final ReadOnlyObjectProperty<TableView<T>> tableViewProperty() { return tableViewPropertyImpl().getReadOnlyProperty(); }
/* 233 */   private void updateItem(int paramInt) { TableView<T> tableView = getTableView();
/* 234 */     if (tableView == null || tableView.getItems() == null)
/*     */       return; 
/* 236 */     ObservableList<T> observableList = tableView.getItems();
/* 237 */     byte b = (observableList == null) ? -1 : observableList.size();
/*     */ 
/*     */     
/* 240 */     int i = getIndex();
/* 241 */     boolean bool = (i >= 0 && i < b) ? true : false;
/*     */     
/* 243 */     T t = getItem();
/* 244 */     boolean bool1 = isEmpty();
/*     */ 
/*     */     
/* 247 */     if (bool) {
/* 248 */       T t1 = observableList.get(i);
/*     */ 
/*     */ 
/*     */       
/* 252 */       if (paramInt != i || 
/* 253 */         isItemChanged(t, t1))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 260 */         updateItem(t1, false);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 268 */     else if ((!bool1 && t != null) || this.isFirstRun) {
/* 269 */       updateItem((T)null, true);
/* 270 */       this.isFirstRun = false;
/*     */     }  }
/*     */   private ReadOnlyObjectWrapper<TableView<T>> tableViewPropertyImpl() { if (this.tableView == null)
/*     */       this.tableView = (ReadOnlyObjectWrapper)new ReadOnlyObjectWrapper<TableView<TableView<T>>>() {
/*     */           private WeakReference<TableView<T>> weakTableViewRef;
/*     */           protected void invalidated() { if (this.weakTableViewRef != null) { TableView tableView1 = this.weakTableViewRef.get(); if (tableView1 != null) { TableView.TableViewSelectionModel tableViewSelectionModel = tableView1.getSelectionModel(); if (tableViewSelectionModel != null)
/*     */                   tableViewSelectionModel.getSelectedIndices().removeListener(TableRow.this.weakSelectedListener);  TableView.TableViewFocusModel tableViewFocusModel = tableView1.getFocusModel(); if (tableViewFocusModel != null)
/*     */                   tableViewFocusModel.focusedCellProperty().removeListener(TableRow.this.weakFocusedListener);  tableView1.editingCellProperty().removeListener(TableRow.this.weakEditingListener); }
/*     */                this.weakTableViewRef = null; }
/*     */              TableView tableView = TableRow.this.getTableView(); if (tableView != null) {
/*     */               TableView.TableViewSelectionModel tableViewSelectionModel = tableView.getSelectionModel(); if (tableViewSelectionModel != null)
/*     */                 tableViewSelectionModel.getSelectedIndices().addListener(TableRow.this.weakSelectedListener);  TableView.TableViewFocusModel tableViewFocusModel = tableView.getFocusModel(); if (tableViewFocusModel != null)
/*     */                 tableViewFocusModel.focusedCellProperty().addListener(TableRow.this.weakFocusedListener);  tableView.editingCellProperty().addListener(TableRow.this.weakEditingListener); this.weakTableViewRef = new WeakReference<>(get());
/*     */             }  } public Object getBean() { return TableRow.this; } public String getName() { return "tableView"; }
/* 284 */         };  return this.tableView; } private void updateSelection() { if (getIndex() == -1)
/*     */       return; 
/* 286 */     TableView<T> tableView = getTableView();
/*     */ 
/*     */ 
/*     */     
/* 290 */     boolean bool = (tableView != null && tableView.getSelectionModel() != null && !tableView.getSelectionModel().isCellSelectionEnabled() && tableView.getSelectionModel().isSelected(getIndex())) ? true : false;
/*     */     
/* 292 */     updateSelected(bool); }
/*     */   protected Skin<?> createDefaultSkin() { return (Skin<?>)new TableRowSkin(this); }
/*     */   void indexChanged(int paramInt1, int paramInt2) { super.indexChanged(paramInt1, paramInt2); updateItem(paramInt1);
/*     */     updateSelection();
/* 296 */     updateFocus(); } private void updateFocus() { if (getIndex() == -1)
/*     */       return; 
/* 298 */     TableView<T> tableView = getTableView();
/* 299 */     if (tableView == null)
/*     */       return; 
/* 301 */     TableView.TableViewSelectionModel<T> tableViewSelectionModel = tableView.getSelectionModel();
/* 302 */     TableView.TableViewFocusModel<T> tableViewFocusModel = tableView.getFocusModel();
/* 303 */     if (tableViewSelectionModel == null || tableViewFocusModel == null)
/*     */       return; 
/* 305 */     boolean bool = (!tableViewSelectionModel.isCellSelectionEnabled() && tableViewFocusModel.isFocused(getIndex())) ? true : false;
/* 306 */     setFocused(bool); }
/*     */ 
/*     */   
/*     */   private void updateEditing() {
/* 310 */     if (getIndex() == -1)
/*     */       return; 
/* 312 */     TableView<T> tableView = getTableView();
/* 313 */     if (tableView == null)
/*     */       return; 
/* 315 */     TableView.TableViewSelectionModel<T> tableViewSelectionModel = tableView.getSelectionModel();
/* 316 */     if (tableViewSelectionModel == null || tableViewSelectionModel.isCellSelectionEnabled())
/*     */       return; 
/* 318 */     TablePosition<T, ?> tablePosition = tableView.getEditingCell();
/* 319 */     if (tablePosition != null && tablePosition.getTableColumn() != null) {
/*     */       return;
/*     */     }
/*     */     
/* 323 */     boolean bool = (tablePosition == null) ? false : ((tablePosition.getRow() == getIndex()) ? true : false);
/*     */     
/* 325 */     if (!isEditing() && bool) {
/* 326 */       startEdit();
/* 327 */     } else if (isEditing() && !bool) {
/* 328 */       cancelEdit();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void updateTableView(TableView<T> paramTableView) {
/* 350 */     setTableView(paramTableView);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 372 */     switch (paramAccessibleAttribute) { case INDEX:
/* 373 */         return Integer.valueOf(getIndex()); }
/* 374 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TableRow.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */