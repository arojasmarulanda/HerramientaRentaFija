/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TablePositionBase<TC extends TableColumnBase>
/*     */ {
/*     */   private final int row;
/*     */   private final WeakReference<TC> tableColumnRef;
/*     */   
/*     */   protected TablePositionBase(int paramInt, TC paramTC) {
/*  67 */     this.row = paramInt;
/*  68 */     this.tableColumnRef = new WeakReference<>(paramTC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRow() {
/*  95 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getColumn();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TC getTableColumn() {
/* 111 */     return this.tableColumnRef.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 120 */     if (paramObject == null) {
/* 121 */       return false;
/*     */     }
/* 123 */     if (getClass() != paramObject.getClass()) {
/* 124 */       return false;
/*     */     }
/*     */     
/* 127 */     TablePositionBase<Object> tablePositionBase = (TablePositionBase)paramObject;
/* 128 */     if (this.row != tablePositionBase.row) {
/* 129 */       return false;
/*     */     }
/* 131 */     TC tC1 = getTableColumn();
/* 132 */     TC tC2 = (TC)tablePositionBase.getTableColumn();
/* 133 */     if (tC1 != tC2 && (tC1 == null || !tC1.equals(tC2))) {
/* 134 */       return false;
/*     */     }
/* 136 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 144 */     int i = 5;
/* 145 */     i = 79 * i + this.row;
/* 146 */     TC tC = getTableColumn();
/* 147 */     i = 79 * i + ((tC != null) ? tC.hashCode() : 0);
/* 148 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TablePositionBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */