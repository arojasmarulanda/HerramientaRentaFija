/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RadioMenuItem
/*     */   extends MenuItem
/*     */   implements Toggle
/*     */ {
/*     */   private ObjectProperty<ToggleGroup> toggleGroup;
/*     */   private BooleanProperty selected;
/*     */   private static final String DEFAULT_STYLE_CLASS = "radio-menu-item";
/*     */   private static final String STYLE_CLASS_SELECTED = "selected";
/*     */   
/*     */   public RadioMenuItem() {
/* 107 */     this(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RadioMenuItem(String paramString) {
/* 115 */     this(paramString, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RadioMenuItem(String paramString, Node paramNode) {
/* 125 */     super(paramString, paramNode);
/* 126 */     getStyleClass().add("radio-menu-item");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setToggleGroup(ToggleGroup paramToggleGroup) {
/* 143 */     toggleGroupProperty().set(paramToggleGroup);
/*     */   }
/*     */   
/*     */   public final ToggleGroup getToggleGroup() {
/* 147 */     return (this.toggleGroup == null) ? null : this.toggleGroup.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<ToggleGroup> toggleGroupProperty() {
/* 151 */     if (this.toggleGroup == null) {
/* 152 */       this.toggleGroup = new ObjectPropertyBase<ToggleGroup>()
/*     */         {
/*     */           protected void invalidated() {
/* 155 */             if (this.old != null) {
/* 156 */               this.old.getToggles().remove(RadioMenuItem.this);
/*     */             }
/* 158 */             this.old = get();
/* 159 */             if (get() != null && !get().getToggles().contains(RadioMenuItem.this))
/* 160 */               get().getToggles().add(RadioMenuItem.this); 
/*     */           }
/*     */           
/*     */           private ToggleGroup old;
/*     */           
/*     */           public Object getBean() {
/* 166 */             return RadioMenuItem.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 171 */             return "toggleGroup";
/*     */           }
/*     */         };
/*     */     }
/* 175 */     return this.toggleGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSelected(boolean paramBoolean) {
/* 182 */     selectedProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isSelected() {
/* 186 */     return (this.selected == null) ? false : this.selected.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty selectedProperty() {
/* 190 */     if (this.selected == null) {
/* 191 */       this.selected = new BooleanPropertyBase() {
/*     */           protected void invalidated() {
/* 193 */             if (RadioMenuItem.this.getToggleGroup() != null) {
/* 194 */               if (get()) {
/* 195 */                 RadioMenuItem.this.getToggleGroup().selectToggle(RadioMenuItem.this);
/* 196 */               } else if (RadioMenuItem.this.getToggleGroup().getSelectedToggle() == RadioMenuItem.this) {
/* 197 */                 RadioMenuItem.this.getToggleGroup().clearSelectedToggle();
/*     */               } 
/*     */             }
/*     */             
/* 201 */             if (RadioMenuItem.this.isSelected()) {
/* 202 */               RadioMenuItem.this.getStyleClass().add("selected");
/*     */             } else {
/* 204 */               RadioMenuItem.this.getStyleClass().remove("selected");
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 210 */             return RadioMenuItem.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 215 */             return "selected";
/*     */           }
/*     */         };
/*     */     }
/* 219 */     return this.selected;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\RadioMenuItem.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */