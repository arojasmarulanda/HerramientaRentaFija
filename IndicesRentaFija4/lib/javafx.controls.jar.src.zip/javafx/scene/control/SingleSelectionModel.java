/*     */ package javafx.scene.control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SingleSelectionModel<T>
/*     */   extends SelectionModel<T>
/*     */ {
/*     */   public void clearSelection() {
/*  68 */     updateSelectedIndex(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSelection(int paramInt) {
/*  75 */     if (getSelectedIndex() == paramInt) {
/*  76 */       clearSelection();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  82 */     return (getItemCount() == 0 || getSelectedIndex() == -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelected(int paramInt) {
/*  94 */     return (getSelectedIndex() == paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearAndSelect(int paramInt) {
/* 103 */     select(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void select(T paramT) {
/* 113 */     if (paramT == null) {
/* 114 */       setSelectedIndex(-1);
/* 115 */       setSelectedItem(null);
/*     */       
/*     */       return;
/*     */     } 
/* 119 */     int i = getItemCount();
/*     */     
/* 121 */     for (byte b = 0; b < i; b++) {
/* 122 */       T t = getModelItem(b);
/* 123 */       if (t != null && t.equals(paramT)) {
/* 124 */         select(b);
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 134 */     setSelectedItem(paramT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void select(int paramInt) {
/* 143 */     if (paramInt == -1) {
/* 144 */       clearSelection();
/*     */       return;
/*     */     } 
/* 147 */     int i = getItemCount();
/* 148 */     if (i == 0 || paramInt < 0 || paramInt >= i)
/* 149 */       return;  updateSelectedIndex(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectPrevious() {
/* 158 */     if (getSelectedIndex() == 0)
/* 159 */       return;  select(getSelectedIndex() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectNext() {
/* 168 */     select(getSelectedIndex() + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectFirst() {
/* 177 */     if (getItemCount() > 0) {
/* 178 */       select(0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectLast() {
/* 188 */     int i = getItemCount();
/* 189 */     if (i > 0 && getSelectedIndex() < i - 1) {
/* 190 */       select(i - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T getModelItem(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int getItemCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateSelectedIndex(int paramInt) {
/* 212 */     int i = getSelectedIndex();
/* 213 */     T t = getSelectedItem();
/*     */     
/* 215 */     setSelectedIndex(paramInt);
/*     */     
/* 217 */     if (i != -1 || t == null || paramInt != -1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 223 */       setSelectedItem(getModelItem(getSelectedIndex()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\SingleSelectionModel.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */