/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.beans.IDProperty;
/*     */ import com.sun.javafx.event.EventHandlerManager;
/*     */ import com.sun.javafx.scene.control.ContextMenuContent;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.property.SimpleStringProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.collections.ObservableSet;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventDispatchChain;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.ContextMenuSkin;
/*     */ import javafx.scene.input.KeyCombination;
/*     */ import javafx.scene.layout.VBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @IDProperty("id")
/*     */ public class MenuItem
/*     */   implements EventTarget, Styleable
/*     */ {
/*     */   private final ObservableList<String> styleClass;
/*     */   final EventHandlerManager eventHandlerManager;
/*     */   private Object userData;
/*     */   private ObservableMap<Object, Object> properties;
/*     */   private StringProperty id;
/*     */   private StringProperty style;
/*     */   private ReadOnlyObjectWrapper<Menu> parentMenu;
/*     */   private ReadOnlyObjectWrapper<ContextMenu> parentPopup;
/*     */   private StringProperty text;
/*     */   private ObjectProperty<Node> graphic;
/*     */   private ObjectProperty<EventHandler<ActionEvent>> onAction;
/*     */   
/*     */   public MenuItem() {
/* 115 */     this(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuItem(String paramString) {
/* 124 */     this(paramString, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuItem(String paramString, Node paramNode) {
/* 149 */     this.styleClass = FXCollections.observableArrayList();
/*     */     
/* 151 */     this.eventHandlerManager = new EventHandlerManager(this);
/*     */     setText(paramString);
/*     */     setGraphic(paramNode);
/*     */     this.styleClass.add("menu-item");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setId(String paramString) {
/* 168 */     idProperty().set(paramString); } public final String getId() {
/* 169 */     return (this.id == null) ? null : this.id.get();
/*     */   } public final StringProperty idProperty() {
/* 171 */     if (this.id == null) {
/* 172 */       this.id = new SimpleStringProperty(this, "id");
/*     */     }
/* 174 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setStyle(String paramString) {
/* 184 */     styleProperty().set(paramString); } public final String getStyle() {
/* 185 */     return (this.style == null) ? null : this.style.get();
/*     */   } public final StringProperty styleProperty() {
/* 187 */     if (this.style == null) {
/* 188 */       this.style = new SimpleStringProperty(this, "style");
/*     */     }
/* 190 */     return this.style;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setParentMenu(Menu paramMenu) {
/* 208 */     parentMenuPropertyImpl().set(paramMenu);
/*     */   }
/*     */   
/*     */   public final Menu getParentMenu() {
/* 212 */     return (this.parentMenu == null) ? null : this.parentMenu.get();
/*     */   }
/*     */   
/*     */   public final ReadOnlyObjectProperty<Menu> parentMenuProperty() {
/* 216 */     return parentMenuPropertyImpl().getReadOnlyProperty();
/*     */   }
/*     */   
/*     */   private ReadOnlyObjectWrapper<Menu> parentMenuPropertyImpl() {
/* 220 */     if (this.parentMenu == null) {
/* 221 */       this.parentMenu = new ReadOnlyObjectWrapper<>(this, "parentMenu");
/*     */     }
/* 223 */     return this.parentMenu;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setParentPopup(ContextMenu paramContextMenu) {
/* 234 */     parentPopupPropertyImpl().set(paramContextMenu);
/*     */   }
/*     */   
/*     */   public final ContextMenu getParentPopup() {
/* 238 */     return (this.parentPopup == null) ? null : this.parentPopup.get();
/*     */   }
/*     */   
/*     */   public final ReadOnlyObjectProperty<ContextMenu> parentPopupProperty() {
/* 242 */     return parentPopupPropertyImpl().getReadOnlyProperty();
/*     */   }
/*     */   
/*     */   private ReadOnlyObjectWrapper<ContextMenu> parentPopupPropertyImpl() {
/* 246 */     if (this.parentPopup == null) {
/* 247 */       this.parentPopup = new ReadOnlyObjectWrapper<>(this, "parentPopup");
/*     */     }
/* 249 */     return this.parentPopup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setText(String paramString) {
/* 260 */     textProperty().set(paramString);
/*     */   }
/*     */   
/*     */   public final String getText() {
/* 264 */     return (this.text == null) ? null : this.text.get();
/*     */   }
/*     */   
/*     */   public final StringProperty textProperty() {
/* 268 */     if (this.text == null) {
/* 269 */       this.text = new SimpleStringProperty(this, "text");
/*     */     }
/* 271 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setGraphic(Node paramNode) {
/* 284 */     graphicProperty().set(paramNode);
/*     */   }
/*     */   
/*     */   public final Node getGraphic() {
/* 288 */     return (this.graphic == null) ? null : this.graphic.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<Node> graphicProperty() {
/* 292 */     if (this.graphic == null) {
/* 293 */       this.graphic = new SimpleObjectProperty<>(this, "graphic");
/*     */     }
/* 295 */     return this.graphic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOnAction(EventHandler<ActionEvent> paramEventHandler) {
/* 309 */     onActionProperty().set(paramEventHandler);
/*     */   }
/*     */   
/*     */   public final EventHandler<ActionEvent> getOnAction() {
/* 313 */     return (this.onAction == null) ? null : this.onAction.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() {
/* 317 */     if (this.onAction == null) {
/* 318 */       this.onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
/*     */           protected void invalidated() {
/* 320 */             MenuItem.this.eventHandlerManager.setEventHandler(ActionEvent.ACTION, get());
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 325 */             return MenuItem.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 330 */             return "onAction";
/*     */           }
/*     */         };
/*     */     }
/* 334 */     return this.onAction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 341 */   public static final EventType<Event> MENU_VALIDATION_EVENT = new EventType<>(Event.ANY, "MENU_VALIDATION_EVENT");
/*     */   
/*     */   private ObjectProperty<EventHandler<Event>> onMenuValidation;
/*     */   
/*     */   private BooleanProperty disable;
/*     */   
/*     */   private BooleanProperty visible;
/*     */   private ObjectProperty<KeyCombination> accelerator;
/*     */   private BooleanProperty mnemonicParsing;
/*     */   private static final String DEFAULT_STYLE_CLASS = "menu-item";
/*     */   
/*     */   public final void setOnMenuValidation(EventHandler<Event> paramEventHandler) {
/* 353 */     onMenuValidationProperty().set(paramEventHandler);
/*     */   }
/*     */   
/*     */   public final EventHandler<Event> getOnMenuValidation() {
/* 357 */     return (this.onMenuValidation == null) ? null : this.onMenuValidation.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<EventHandler<Event>> onMenuValidationProperty() {
/* 361 */     if (this.onMenuValidation == null) {
/* 362 */       this.onMenuValidation = new ObjectPropertyBase<EventHandler<Event>>() {
/*     */           protected void invalidated() {
/* 364 */             MenuItem.this.eventHandlerManager.setEventHandler(MenuItem.MENU_VALIDATION_EVENT, get());
/*     */           }
/*     */           public Object getBean() {
/* 367 */             return MenuItem.this;
/*     */           }
/*     */           public String getName() {
/* 370 */             return "onMenuValidation";
/*     */           }
/*     */         };
/*     */     }
/* 374 */     return this.onMenuValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setDisable(boolean paramBoolean) {
/* 383 */     disableProperty().set(paramBoolean); } public final boolean isDisable() {
/* 384 */     return (this.disable == null) ? false : this.disable.get();
/*     */   } public final BooleanProperty disableProperty() {
/* 386 */     if (this.disable == null) {
/* 387 */       this.disable = new SimpleBooleanProperty(this, "disable");
/*     */     }
/* 389 */     return this.disable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setVisible(boolean paramBoolean) {
/* 398 */     visibleProperty().set(paramBoolean); } public final boolean isVisible() {
/* 399 */     return (this.visible == null) ? true : this.visible.get();
/*     */   } public final BooleanProperty visibleProperty() {
/* 401 */     if (this.visible == null) {
/* 402 */       this.visible = new SimpleBooleanProperty(this, "visible", true);
/*     */     }
/* 404 */     return this.visible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setAccelerator(KeyCombination paramKeyCombination) {
/* 413 */     acceleratorProperty().set(paramKeyCombination);
/*     */   }
/*     */   public final KeyCombination getAccelerator() {
/* 416 */     return (this.accelerator == null) ? null : this.accelerator.get();
/*     */   }
/*     */   public final ObjectProperty<KeyCombination> acceleratorProperty() {
/* 419 */     if (this.accelerator == null) {
/* 420 */       this.accelerator = new SimpleObjectProperty<>(this, "accelerator");
/*     */     }
/* 422 */     return this.accelerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMnemonicParsing(boolean paramBoolean) {
/* 439 */     mnemonicParsingProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isMnemonicParsing() {
/* 442 */     return (this.mnemonicParsing == null) ? true : this.mnemonicParsing.get();
/*     */   }
/*     */   public final BooleanProperty mnemonicParsingProperty() {
/* 445 */     if (this.mnemonicParsing == null) {
/* 446 */       this.mnemonicParsing = new SimpleBooleanProperty(this, "mnemonicParsing", true);
/*     */     }
/* 448 */     return this.mnemonicParsing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<String> getStyleClass() {
/* 458 */     return this.styleClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fire() {
/* 465 */     Event.fireEvent(this, new ActionEvent(this, this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends Event> void addEventHandler(EventType<E> paramEventType, EventHandler<E> paramEventHandler) {
/* 479 */     this.eventHandlerManager.addEventHandler(paramEventType, paramEventHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends Event> void removeEventHandler(EventType<E> paramEventType, EventHandler<E> paramEventHandler) {
/* 494 */     this.eventHandlerManager.removeEventHandler(paramEventType, paramEventHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EventDispatchChain buildEventDispatchChain(EventDispatchChain paramEventDispatchChain) {
/* 500 */     if (getParentPopup() != null) {
/* 501 */       getParentPopup().buildEventDispatchChain(paramEventDispatchChain);
/*     */     }
/*     */     
/* 504 */     if (getParentMenu() != null) {
/* 505 */       getParentMenu().buildEventDispatchChain(paramEventDispatchChain);
/*     */     }
/*     */     
/* 508 */     return paramEventDispatchChain.prepend(this.eventHandlerManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getUserData() {
/* 519 */     return this.userData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserData(Object paramObject) {
/* 532 */     this.userData = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableMap<Object, Object> getProperties() {
/* 543 */     if (this.properties == null) {
/* 544 */       this.properties = FXCollections.observableMap(new HashMap<>());
/*     */     }
/* 546 */     return this.properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTypeSelector() {
/* 564 */     return "MenuItem";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Styleable getStyleableParent() {
/* 576 */     if (getParentMenu() == null) {
/* 577 */       return getParentPopup();
/*     */     }
/* 579 */     return getParentMenu();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableSet<PseudoClass> getPseudoClassStates() {
/* 589 */     return FXCollections.emptyObservableSet();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 594 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getStyleableNode() {
/* 601 */     ContextMenu contextMenu = getParentPopup();
/* 602 */     if (contextMenu == null || !(contextMenu.getSkin() instanceof ContextMenuSkin)) return null;
/*     */     
/* 604 */     ContextMenuSkin contextMenuSkin = (ContextMenuSkin)contextMenu.getSkin();
/* 605 */     if (!(contextMenuSkin.getNode() instanceof ContextMenuContent)) return null;
/*     */     
/* 607 */     ContextMenuContent contextMenuContent = (ContextMenuContent)contextMenuSkin.getNode();
/* 608 */     VBox vBox = contextMenuContent.getItemsContainer();
/*     */     
/* 610 */     MenuItem menuItem = this;
/* 611 */     ObservableList<Node> observableList = vBox.getChildrenUnmodifiable();
/* 612 */     for (byte b = 0; b < observableList.size(); b++) {
/* 613 */       if (observableList.get(b) instanceof ContextMenuContent.MenuItemContainer) {
/*     */ 
/*     */         
/* 616 */         ContextMenuContent.MenuItemContainer menuItemContainer = (ContextMenuContent.MenuItemContainer)observableList.get(b);
/*     */         
/* 618 */         if (menuItem.equals(menuItemContainer.getItem())) {
/* 619 */           return (Node)menuItemContainer;
/*     */         }
/*     */       } 
/*     */     } 
/* 623 */     return null;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 627 */     StringBuilder stringBuilder = new StringBuilder(getClass().getSimpleName());
/*     */     
/* 629 */     boolean bool1 = (this.id != null && !"".equals(getId())) ? true : false;
/* 630 */     boolean bool2 = !getStyleClass().isEmpty() ? true : false;
/*     */     
/* 632 */     if (!bool1) {
/* 633 */       stringBuilder.append('@');
/* 634 */       stringBuilder.append(Integer.toHexString(hashCode()));
/*     */     } else {
/* 636 */       stringBuilder.append("[id=");
/* 637 */       stringBuilder.append(getId());
/* 638 */       if (!bool2) stringBuilder.append("]");
/*     */     
/*     */     } 
/* 641 */     if (bool2) {
/* 642 */       if (!bool1) { stringBuilder.append('['); }
/* 643 */       else { stringBuilder.append(", "); }
/* 644 */        stringBuilder.append("styleClass=");
/* 645 */       stringBuilder.append(getStyleClass());
/* 646 */       stringBuilder.append("]");
/*     */     } 
/* 648 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\MenuItem.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */