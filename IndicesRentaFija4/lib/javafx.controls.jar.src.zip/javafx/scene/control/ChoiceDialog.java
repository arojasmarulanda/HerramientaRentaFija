/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.layout.GridPane;
/*     */ import javafx.scene.layout.Priority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChoiceDialog<T>
/*     */   extends Dialog<T>
/*     */ {
/*     */   private final GridPane grid;
/*     */   private final Label label;
/*     */   private final ComboBox<T> comboBox;
/*     */   private final T defaultChoice;
/*     */   
/*     */   public ChoiceDialog() {
/*  77 */     this((T)null, (T[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceDialog(T paramT, T... paramVarArgs) {
/*  94 */     this(paramT, 
/*  95 */         (paramVarArgs == null) ? Collections.<T>emptyList() : Arrays.<T>asList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceDialog(T paramT, Collection<T> paramCollection) {
/* 112 */     DialogPane dialogPane = getDialogPane();
/*     */ 
/*     */     
/* 115 */     this.grid = new GridPane();
/* 116 */     this.grid.setHgap(10.0D);
/* 117 */     this.grid.setMaxWidth(Double.MAX_VALUE);
/* 118 */     this.grid.setAlignment(Pos.CENTER_LEFT);
/*     */ 
/*     */     
/* 121 */     this.label = DialogPane.createContentLabel(dialogPane.getContentText());
/* 122 */     this.label.setPrefWidth(-1.0D);
/* 123 */     this.label.textProperty().bind(dialogPane.contentTextProperty());
/*     */     
/* 125 */     dialogPane.contentTextProperty().addListener(paramObservable -> updateGrid());
/*     */     
/* 127 */     setTitle(ControlResources.getString("Dialog.confirm.title"));
/* 128 */     dialogPane.setHeaderText(ControlResources.getString("Dialog.confirm.header"));
/* 129 */     dialogPane.getStyleClass().add("choice-dialog");
/* 130 */     dialogPane.getButtonTypes().addAll(new ButtonType[] { ButtonType.OK, ButtonType.CANCEL });
/*     */ 
/*     */ 
/*     */     
/* 134 */     this.comboBox = new ComboBox<>();
/* 135 */     this.comboBox.setMinWidth(150.0D);
/* 136 */     if (paramCollection != null) {
/* 137 */       this.comboBox.getItems().addAll(paramCollection);
/*     */     }
/* 139 */     this.comboBox.setMaxWidth(Double.MAX_VALUE);
/* 140 */     GridPane.setHgrow(this.comboBox, Priority.ALWAYS);
/* 141 */     GridPane.setFillWidth(this.comboBox, Boolean.valueOf(true));
/*     */     
/* 143 */     this.defaultChoice = this.comboBox.getItems().contains(paramT) ? paramT : null;
/*     */     
/* 145 */     if (paramT == null) {
/* 146 */       this.comboBox.getSelectionModel().selectFirst();
/*     */     } else {
/* 148 */       this.comboBox.getSelectionModel().select(paramT);
/*     */     } 
/*     */     
/* 151 */     updateGrid();
/*     */     
/* 153 */     setResultConverter(paramButtonType -> {
/*     */           ButtonBar.ButtonData buttonData = (paramButtonType == null) ? null : paramButtonType.getButtonData();
/*     */           return (buttonData == ButtonBar.ButtonData.OK_DONE) ? getSelectedItem() : null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T getSelectedItem() {
/* 172 */     return this.comboBox.getSelectionModel().getSelectedItem();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ReadOnlyObjectProperty<T> selectedItemProperty() {
/* 180 */     return this.comboBox.getSelectionModel().selectedItemProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setSelectedItem(T paramT) {
/* 188 */     this.comboBox.getSelectionModel().select(paramT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<T> getItems() {
/* 198 */     return this.comboBox.getItems();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T getDefaultChoice() {
/* 206 */     return this.defaultChoice;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateGrid() {
/* 218 */     this.grid.getChildren().clear();
/*     */     
/* 220 */     this.grid.add(this.label, 0, 0);
/* 221 */     this.grid.add(this.comboBox, 1, 0);
/* 222 */     getDialogPane().setContent(this.grid);
/*     */     
/* 224 */     Platform.runLater(() -> this.comboBox.requestFocus());
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ChoiceDialog.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */