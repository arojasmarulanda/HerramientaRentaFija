/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.event.EventHandlerManager;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.List;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.BooleanPropertyBase;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*      */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventDispatchChain;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.EventTarget;
/*      */ import javafx.event.EventType;
/*      */ import javafx.scene.Node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TreeItem<T>
/*      */   implements EventTarget
/*      */ {
/*      */   public static <T> EventType<TreeModificationEvent<T>> treeNotificationEvent() {
/*  230 */     return (EventType)TREE_NOTIFICATION_EVENT;
/*      */   }
/*  232 */   private static final EventType<?> TREE_NOTIFICATION_EVENT = new EventType(Event.ANY, "TreeNotificationEvent");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<TreeModificationEvent<T>> expandedItemCountChangeEvent() {
/*  249 */     return (EventType)EXPANDED_ITEM_COUNT_CHANGE_EVENT;
/*      */   }
/*  251 */   private static final EventType<?> EXPANDED_ITEM_COUNT_CHANGE_EVENT = new EventType(
/*  252 */       treeNotificationEvent(), "ExpandedItemCountChangeEvent");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<TreeModificationEvent<T>> branchExpandedEvent() {
/*  263 */     return (EventType)BRANCH_EXPANDED_EVENT;
/*      */   }
/*  265 */   private static final EventType<?> BRANCH_EXPANDED_EVENT = new EventType(
/*  266 */       expandedItemCountChangeEvent(), "BranchExpandedEvent");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<TreeModificationEvent<T>> branchCollapsedEvent() {
/*  277 */     return (EventType)BRANCH_COLLAPSED_EVENT;
/*      */   }
/*  279 */   private static final EventType<?> BRANCH_COLLAPSED_EVENT = new EventType(
/*  280 */       expandedItemCountChangeEvent(), "BranchCollapsedEvent");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<TreeModificationEvent<T>> childrenModificationEvent() {
/*  292 */     return (EventType)CHILDREN_MODIFICATION_EVENT;
/*      */   }
/*  294 */   private static final EventType<?> CHILDREN_MODIFICATION_EVENT = new EventType(
/*  295 */       expandedItemCountChangeEvent(), "ChildrenModificationEvent");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<TreeModificationEvent<T>> valueChangedEvent() {
/*  307 */     return (EventType)VALUE_CHANGED_EVENT;
/*      */   }
/*  309 */   private static final EventType<?> VALUE_CHANGED_EVENT = new EventType(
/*  310 */       treeNotificationEvent(), "ValueChangedEvent");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> EventType<TreeModificationEvent<T>> graphicChangedEvent() {
/*  322 */     return (EventType)GRAPHIC_CHANGED_EVENT;
/*      */   }
/*  324 */   private static final EventType<?> GRAPHIC_CHANGED_EVENT = new EventType(
/*  325 */       treeNotificationEvent(), "GraphicChangedEvent"); private final EventHandler<TreeModificationEvent<Object>> itemListener; private boolean ignoreSortUpdate; private boolean expandedDescendentCountDirty; ObservableList<TreeItem<T>> children; private final EventHandlerManager eventHandlerManager;
/*      */   private int expandedDescendentCount;
/*      */   int previousExpandedDescendentCount;
/*      */   Comparator<TreeItem<T>> lastComparator;
/*      */   TreeSortMode lastSortMode;
/*      */   private int parentLinkCount;
/*      */   private ListChangeListener<TreeItem<T>> childrenListener;
/*      */   private ObjectProperty<T> value;
/*      */   private ObjectProperty<Node> graphic;
/*      */   private BooleanProperty expanded;
/*      */   private ReadOnlyBooleanWrapper leaf;
/*      */   private ReadOnlyObjectWrapper<TreeItem<T>> parent;
/*      */   
/*      */   public TreeItem() {
/*  339 */     this(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TreeItem(T paramT) {
/*  348 */     this(paramT, (Node)null);
/*      */   }
/*      */   public final void setValue(T paramT) { valueProperty().setValue(paramT); } public final T getValue() { return (this.value == null) ? null : this.value.getValue(); } public final ObjectProperty<T> valueProperty() {
/*      */     if (this.value == null)
/*      */       this.value = new ObjectPropertyBase<T>()
/*      */         {
/*      */           protected void invalidated() { TreeItem.this.fireEvent(new TreeItem.TreeModificationEvent<>((EventType)TreeItem.VALUE_CHANGED_EVENT, TreeItem.this, get())); } public Object getBean() {
/*      */             return TreeItem.this;
/*      */           } public String getName() {
/*      */             return "value";
/*      */           }
/*      */         }; 
/*      */     return this.value;
/*      */   } public final void setGraphic(Node paramNode) {
/*      */     graphicProperty().setValue(paramNode);
/*      */   } public final Node getGraphic() {
/*      */     return (this.graphic == null) ? null : this.graphic.getValue();
/*  365 */   } public TreeItem(T paramT, Node paramNode) { this.itemListener = new EventHandler<TreeModificationEvent<Object>>()
/*      */       {
/*      */         public void handle(TreeItem.TreeModificationEvent<Object> param1TreeModificationEvent) {
/*  368 */           TreeItem.this.expandedDescendentCountDirty = true;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  379 */     this.ignoreSortUpdate = false;
/*      */     
/*  381 */     this.expandedDescendentCountDirty = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  391 */     this.eventHandlerManager = new EventHandlerManager(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  398 */     this.expandedDescendentCount = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  405 */     this.previousExpandedDescendentCount = 1;
/*      */     
/*  407 */     this.lastComparator = null;
/*  408 */     this.lastSortMode = null;
/*      */ 
/*      */ 
/*      */     
/*  412 */     this.parentLinkCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  423 */     this.childrenListener = (paramChange -> {
/*      */         this.expandedDescendentCountDirty = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         updateChildren(paramChange);
/*      */       });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  615 */     this.parent = new ReadOnlyObjectWrapper<>(this, "parent"); setValue(paramT); setGraphic(paramNode); addEventHandler(expandedItemCountChangeEvent(), this.itemListener); } public final ObjectProperty<Node> graphicProperty() { if (this.graphic == null) this.graphic = new ObjectPropertyBase<Node>() { protected void invalidated() { TreeItem.this.fireEvent(new TreeItem.TreeModificationEvent((EventType)TreeItem.GRAPHIC_CHANGED_EVENT, TreeItem.this)); } public Object getBean() { return TreeItem.this; } public String getName() { return "graphic"; } }
/*  616 */         ;  return this.graphic; } private void setParent(TreeItem<T> paramTreeItem) { this.parent.setValue(paramTreeItem); } public final void setExpanded(boolean paramBoolean) { if (!paramBoolean && this.expanded == null) return;  expandedProperty().setValue(Boolean.valueOf(paramBoolean)); }
/*      */   public final boolean isExpanded() { return (this.expanded == null) ? false : this.expanded.getValue().booleanValue(); }
/*      */   public final BooleanProperty expandedProperty() { if (this.expanded == null)
/*      */       this.expanded = new BooleanPropertyBase() { protected void invalidated() { if (TreeItem.this.isLeaf())
/*      */               return;  EventType<? extends Event> eventType = TreeItem.this.isExpanded() ? TreeItem.BRANCH_EXPANDED_EVENT : TreeItem.BRANCH_COLLAPSED_EVENT; TreeItem.this.fireEvent(new TreeItem.TreeModificationEvent(eventType, TreeItem.this, TreeItem.this.isExpanded())); }
/*      */           public Object getBean() { return TreeItem.this; }
/*      */           public String getName() { return "expanded"; } }
/*      */         ;  return this.expanded; }
/*  624 */   public final TreeItem<T> getParent() { return (this.parent == null) ? null : this.parent.getValue(); } private void setLeaf(boolean paramBoolean) { if (paramBoolean && this.leaf == null)
/*      */       return;  if (this.leaf == null)
/*      */       this.leaf = new ReadOnlyBooleanWrapper(this, "leaf", true);  this.leaf.setValue(Boolean.valueOf(paramBoolean)); }
/*      */   public boolean isLeaf() { return (this.leaf == null) ? true : this.leaf.getValue().booleanValue(); }
/*      */   public final ReadOnlyBooleanProperty leafProperty() { if (this.leaf == null)
/*      */       this.leaf = new ReadOnlyBooleanWrapper(this, "leaf", true);  return this.leaf.getReadOnlyProperty(); }
/*  630 */   public final ReadOnlyObjectProperty<TreeItem<T>> parentProperty() { return this.parent.getReadOnlyProperty(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObservableList<TreeItem<T>> getChildren() {
/*  648 */     if (this.children == null) {
/*  649 */       this.children = FXCollections.observableArrayList();
/*  650 */       this.children.addListener(this.childrenListener);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  655 */     if (this.children.isEmpty()) return this.children;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  662 */     if (!this.ignoreSortUpdate) {
/*  663 */       checkSortState();
/*      */     }
/*      */     
/*  666 */     return this.children;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TreeItem<T> previousSibling() {
/*  686 */     return previousSibling(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TreeItem<T> previousSibling(TreeItem<T> paramTreeItem) {
/*  700 */     if (getParent() == null || paramTreeItem == null) {
/*  701 */       return null;
/*      */     }
/*      */     
/*  704 */     ObservableList<TreeItem<T>> observableList = getParent().getChildren();
/*  705 */     int i = observableList.size();
/*  706 */     int j = -1;
/*  707 */     for (byte b = 0; b < i; b++) {
/*  708 */       if (paramTreeItem.equals(observableList.get(b))) {
/*  709 */         j = b - 1;
/*  710 */         return (j < 0) ? null : observableList.get(j);
/*      */       } 
/*      */     } 
/*  713 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TreeItem<T> nextSibling() {
/*  725 */     return nextSibling(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TreeItem<T> nextSibling(TreeItem<T> paramTreeItem) {
/*  739 */     if (getParent() == null || paramTreeItem == null) {
/*  740 */       return null;
/*      */     }
/*      */     
/*  743 */     ObservableList<TreeItem<T>> observableList = getParent().getChildren();
/*  744 */     int i = observableList.size();
/*  745 */     int j = -1;
/*  746 */     for (byte b = 0; b < i; b++) {
/*  747 */       if (paramTreeItem.equals(observableList.get(b))) {
/*  748 */         j = b + 1;
/*  749 */         return (j >= i) ? null : observableList.get(j);
/*      */       } 
/*      */     } 
/*  752 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  760 */     return "TreeItem [ value: " + getValue() + " ]";
/*      */   }
/*      */   
/*      */   private void fireEvent(TreeModificationEvent<T> paramTreeModificationEvent) {
/*  764 */     Event.fireEvent(this, paramTreeModificationEvent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EventDispatchChain buildEventDispatchChain(EventDispatchChain paramEventDispatchChain) {
/*  781 */     if (getParent() != null) {
/*  782 */       getParent().buildEventDispatchChain(paramEventDispatchChain);
/*      */     }
/*  784 */     return paramEventDispatchChain.append(this.eventHandlerManager);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <E extends Event> void addEventHandler(EventType<E> paramEventType, EventHandler<E> paramEventHandler) {
/*  802 */     this.eventHandlerManager.addEventHandler(paramEventType, paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <E extends Event> void removeEventHandler(EventType<E> paramEventType, EventHandler<E> paramEventHandler) {
/*  817 */     this.eventHandlerManager.removeEventHandler(paramEventType, paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void sort() {
/*  829 */     sort(this.children, this.lastComparator, this.lastSortMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sort(ObservableList<TreeItem<T>> paramObservableList, Comparator<TreeItem<T>> paramComparator, TreeSortMode paramTreeSortMode) {
/*  836 */     if (paramComparator == null)
/*      */       return; 
/*  838 */     runSort(paramObservableList, paramComparator, paramTreeSortMode);
/*      */ 
/*      */ 
/*      */     
/*  842 */     if (getParent() == null) {
/*  843 */       TreeModificationEvent<T> treeModificationEvent = new TreeModificationEvent((EventType)childrenModificationEvent(), this);
/*  844 */       treeModificationEvent.wasPermutated = true;
/*  845 */       fireEvent(treeModificationEvent);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void checkSortState() {
/*  850 */     TreeItem<T> treeItem = getRoot();
/*      */     
/*  852 */     TreeSortMode treeSortMode = treeItem.lastSortMode;
/*  853 */     Comparator<TreeItem<T>> comparator = treeItem.lastComparator;
/*      */     
/*  855 */     if (comparator != null && comparator != this.lastComparator) {
/*  856 */       this.lastComparator = comparator;
/*  857 */       runSort(this.children, comparator, treeSortMode);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void runSort(ObservableList<TreeItem<T>> paramObservableList, Comparator<TreeItem<T>> paramComparator, TreeSortMode paramTreeSortMode) {
/*  862 */     if (paramTreeSortMode == TreeSortMode.ALL_DESCENDANTS) {
/*  863 */       doSort(paramObservableList, paramComparator);
/*  864 */     } else if (paramTreeSortMode == TreeSortMode.ONLY_FIRST_LEVEL) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  869 */       if (getParent() == null) {
/*  870 */         doSort(paramObservableList, paramComparator);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TreeItem<T> getRoot() {
/*  884 */     TreeItem<T> treeItem = getParent();
/*  885 */     if (treeItem == null) return this;
/*      */     
/*      */     while (true) {
/*  888 */       TreeItem<T> treeItem1 = treeItem.getParent();
/*  889 */       if (treeItem1 == null) return treeItem; 
/*  890 */       treeItem = treeItem1;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void doSort(ObservableList<TreeItem<T>> paramObservableList, Comparator<TreeItem<T>> paramComparator) {
/*  895 */     if (!isLeaf() && isExpanded()) {
/*  896 */       FXCollections.sort(paramObservableList, paramComparator);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   int getExpandedDescendentCount(boolean paramBoolean) {
/*  902 */     if (paramBoolean || this.expandedDescendentCountDirty) {
/*  903 */       updateExpandedDescendentCount(paramBoolean);
/*  904 */       this.expandedDescendentCountDirty = false;
/*      */     } 
/*  906 */     return this.expandedDescendentCount;
/*      */   }
/*      */   
/*      */   private void updateExpandedDescendentCount(boolean paramBoolean) {
/*  910 */     this.previousExpandedDescendentCount = this.expandedDescendentCount;
/*  911 */     this.expandedDescendentCount = 1;
/*      */     
/*  913 */     this.ignoreSortUpdate = true;
/*  914 */     if (!isLeaf() && isExpanded()) {
/*  915 */       for (TreeItem<T> treeItem : getChildren()) {
/*  916 */         if (treeItem == null)
/*  917 */           continue;  this.expandedDescendentCount += treeItem.isExpanded() ? treeItem.getExpandedDescendentCount(paramBoolean) : 1;
/*      */       } 
/*      */     }
/*  920 */     this.ignoreSortUpdate = false;
/*      */   }
/*      */   
/*      */   private void updateChildren(ListChangeListener.Change<? extends TreeItem<T>> paramChange) {
/*  924 */     setLeaf(this.children.isEmpty());
/*      */     
/*  926 */     ArrayList<? extends TreeItem<?>> arrayList1 = new ArrayList();
/*  927 */     ArrayList<? extends TreeItem<?>> arrayList2 = new ArrayList();
/*      */     
/*  929 */     while (paramChange.next()) {
/*  930 */       arrayList1.addAll(paramChange.getAddedSubList());
/*  931 */       arrayList2.addAll(paramChange.getRemoved());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  936 */     updateChildrenParent(arrayList2, null);
/*  937 */     updateChildrenParent(arrayList1, this);
/*      */     
/*  939 */     paramChange.reset();
/*      */ 
/*      */ 
/*      */     
/*  943 */     fireEvent(new TreeModificationEvent<>(CHILDREN_MODIFICATION_EVENT, this, arrayList1, arrayList2, paramChange));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T> void updateChildrenParent(List<? extends TreeItem<T>> paramList, TreeItem<T> paramTreeItem) {
/*  950 */     if (paramList == null)
/*  951 */       return;  for (TreeItem<T> treeItem : paramList) {
/*  952 */       if (treeItem == null)
/*      */         continue; 
/*  954 */       TreeItem treeItem1 = treeItem.getParent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  967 */       if (treeItem.parentLinkCount == 0) {
/*  968 */         treeItem.setParent(paramTreeItem);
/*      */       }
/*      */       
/*  971 */       boolean bool = (treeItem1 != null && treeItem1.equals(paramTreeItem)) ? true : false;
/*  972 */       if (bool) {
/*  973 */         if (paramTreeItem == null) {
/*  974 */           treeItem.parentLinkCount--; continue;
/*      */         } 
/*  976 */         treeItem.parentLinkCount++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class TreeModificationEvent<T>
/*      */     extends Event
/*      */   {
/*      */     private static final long serialVersionUID = 4741889985221719579L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  995 */     public static final EventType<?> ANY = TreeItem.TREE_NOTIFICATION_EVENT;
/*      */ 
/*      */     
/*      */     private final transient TreeItem<T> treeItem;
/*      */ 
/*      */     
/*      */     private final T newValue;
/*      */ 
/*      */     
/*      */     private final List<? extends TreeItem<T>> added;
/*      */ 
/*      */     
/*      */     private final List<? extends TreeItem<T>> removed;
/*      */     
/*      */     private final ListChangeListener.Change<? extends TreeItem<T>> change;
/*      */     
/*      */     private final boolean wasExpanded;
/*      */     
/*      */     private final boolean wasCollapsed;
/*      */     
/*      */     private boolean wasPermutated;
/*      */ 
/*      */     
/*      */     public TreeModificationEvent(EventType<? extends Event> param1EventType, TreeItem<T> param1TreeItem) {
/* 1019 */       this(param1EventType, param1TreeItem, (T)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeModificationEvent(EventType<? extends Event> param1EventType, TreeItem<T> param1TreeItem, T param1T) {
/* 1033 */       super(param1EventType);
/* 1034 */       this.treeItem = param1TreeItem;
/* 1035 */       this.newValue = param1T;
/* 1036 */       this.added = null;
/* 1037 */       this.removed = null;
/* 1038 */       this.change = null;
/* 1039 */       this.wasExpanded = false;
/* 1040 */       this.wasCollapsed = false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeModificationEvent(EventType<? extends Event> param1EventType, TreeItem<T> param1TreeItem, boolean param1Boolean) {
/* 1054 */       super(param1EventType);
/* 1055 */       this.treeItem = param1TreeItem;
/* 1056 */       this.newValue = null;
/* 1057 */       this.added = null;
/* 1058 */       this.removed = null;
/* 1059 */       this.change = null;
/* 1060 */       this.wasExpanded = param1Boolean;
/* 1061 */       this.wasCollapsed = !param1Boolean;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeModificationEvent(EventType<? extends Event> param1EventType, TreeItem<T> param1TreeItem, List<? extends TreeItem<T>> param1List1, List<? extends TreeItem<T>> param1List2) {
/* 1079 */       this(param1EventType, param1TreeItem, param1List1, param1List2, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private TreeModificationEvent(EventType<? extends Event> param1EventType, TreeItem<T> param1TreeItem, List<? extends TreeItem<T>> param1List1, List<? extends TreeItem<T>> param1List2, ListChangeListener.Change<? extends TreeItem<T>> param1Change) {
/* 1100 */       super(param1EventType);
/* 1101 */       this.treeItem = param1TreeItem;
/* 1102 */       this.newValue = null;
/* 1103 */       this.added = param1List1;
/* 1104 */       this.removed = param1List2;
/* 1105 */       this.change = param1Change;
/* 1106 */       this.wasExpanded = false;
/* 1107 */       this.wasCollapsed = false;
/*      */       
/* 1109 */       this
/*      */         
/* 1111 */         .wasPermutated = (param1List1 != null && param1List2 != null && param1List1.size() == param1List2.size() && param1List1.containsAll(param1List2));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeItem<T> getSource() {
/* 1119 */       return this.treeItem;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeItem<T> getTreeItem() {
/* 1127 */       return this.treeItem;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public T getNewValue() {
/* 1136 */       return this.newValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<? extends TreeItem<T>> getAddedChildren() {
/* 1146 */       return (this.added == null) ? Collections.<TreeItem<T>>emptyList() : this.added;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<? extends TreeItem<T>> getRemovedChildren() {
/* 1156 */       return (this.removed == null) ? Collections.<TreeItem<T>>emptyList() : this.removed;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getRemovedSize() {
/* 1166 */       return getRemovedChildren().size();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getAddedSize() {
/* 1176 */       return getAddedChildren().size();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean wasExpanded() {
/* 1185 */       return this.wasExpanded;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean wasCollapsed() {
/* 1193 */       return this.wasCollapsed;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean wasAdded() {
/* 1201 */       return (getAddedSize() > 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean wasRemoved() {
/* 1209 */       return (getRemovedSize() > 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean wasPermutated() {
/* 1217 */       return this.wasPermutated;
/*      */     }
/* 1219 */     int getFrom() { return (this.change == null) ? -1 : this.change.getFrom(); }
/* 1220 */     int getTo() { return (this.change == null) ? -1 : this.change.getTo(); } ListChangeListener.Change<? extends TreeItem<T>> getChange() {
/* 1221 */       return this.change;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TreeItem.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */