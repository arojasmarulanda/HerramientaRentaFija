/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.binding.ExpressionHelper;
/*     */ import com.sun.javafx.collections.ListListenerHelper;
/*     */ import com.sun.javafx.collections.NonIterableChange;
/*     */ import java.util.AbstractList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableIntegerProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.TextAreaSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextArea
/*     */   extends TextInputControl
/*     */ {
/*     */   public static final int DEFAULT_PREF_COLUMN_COUNT = 40;
/*     */   public static final int DEFAULT_PREF_ROW_COUNT = 10;
/*     */   private static final int DEFAULT_PARAGRAPH_CAPACITY = 32;
/*     */   private BooleanProperty wrapText;
/*     */   private IntegerProperty prefColumnCount;
/*     */   private IntegerProperty prefRowCount;
/*     */   private DoubleProperty scrollTop;
/*     */   private DoubleProperty scrollLeft;
/*     */   
/*     */   private static final class TextAreaContent
/*     */     implements TextInputControl.Content
/*     */   {
/*  78 */     private ExpressionHelper<String> helper = null;
/*  79 */     private ArrayList<StringBuilder> paragraphs = new ArrayList<>();
/*  80 */     private int contentLength = 0;
/*  81 */     private TextArea.ParagraphList paragraphList = new TextArea.ParagraphList();
/*     */     private ListListenerHelper<CharSequence> listenerHelper;
/*     */     
/*     */     private TextAreaContent() {
/*  85 */       this.paragraphs.add(new StringBuilder(32));
/*  86 */       this.paragraphList.content = this;
/*     */     }
/*     */     
/*     */     public String get(int param1Int1, int param1Int2) {
/*  90 */       int i = param1Int2 - param1Int1;
/*  91 */       StringBuilder stringBuilder1 = new StringBuilder(i);
/*     */       
/*  93 */       int j = this.paragraphs.size();
/*     */       
/*  95 */       byte b1 = 0;
/*  96 */       int k = param1Int1;
/*     */       
/*  98 */       while (b1 < j) {
/*  99 */         StringBuilder stringBuilder = this.paragraphs.get(b1);
/* 100 */         int m = stringBuilder.length() + 1;
/*     */         
/* 102 */         if (k < m) {
/*     */           break;
/*     */         }
/*     */         
/* 106 */         k -= m;
/* 107 */         b1++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 112 */       StringBuilder stringBuilder2 = this.paragraphs.get(b1);
/*     */       
/* 114 */       byte b2 = 0;
/* 115 */       while (b2 < i) {
/* 116 */         if (k == stringBuilder2.length() && b2 < this.contentLength) {
/*     */           
/* 118 */           stringBuilder1.append('\n');
/* 119 */           stringBuilder2 = this.paragraphs.get(++b1);
/* 120 */           k = 0;
/*     */         } else {
/* 122 */           stringBuilder1.append(stringBuilder2.charAt(k++));
/*     */         } 
/*     */         
/* 125 */         b2++;
/*     */       } 
/*     */       
/* 128 */       return stringBuilder1.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void insert(int param1Int, String param1String, boolean param1Boolean) {
/* 134 */       if (param1Int < 0 || param1Int > this.contentLength)
/*     */       {
/* 136 */         throw new IndexOutOfBoundsException();
/*     */       }
/*     */       
/* 139 */       if (param1String == null) {
/* 140 */         throw new IllegalArgumentException();
/*     */       }
/* 142 */       param1String = TextInputControl.filterInput(param1String, false, false);
/* 143 */       int i = param1String.length();
/* 144 */       if (i > 0) {
/*     */         
/* 146 */         ArrayList<StringBuilder> arrayList = new ArrayList();
/*     */         
/* 148 */         StringBuilder stringBuilder1 = new StringBuilder(32); int j;
/* 149 */         for (j = 0; j < i; j++) {
/* 150 */           char c = param1String.charAt(j);
/*     */           
/* 152 */           if (c == '\n') {
/* 153 */             arrayList.add(stringBuilder1);
/* 154 */             stringBuilder1 = new StringBuilder(32);
/*     */           } else {
/* 156 */             stringBuilder1.append(c);
/*     */           } 
/*     */         } 
/*     */         
/* 160 */         arrayList.add(stringBuilder1);
/*     */ 
/*     */ 
/*     */         
/* 164 */         j = this.paragraphs.size();
/* 165 */         int k = this.contentLength + 1;
/*     */         
/* 167 */         StringBuilder stringBuilder2 = null;
/*     */         
/*     */         do {
/* 170 */           stringBuilder2 = this.paragraphs.get(--j);
/* 171 */           k -= stringBuilder2.length() + 1;
/* 172 */         } while (param1Int < k);
/*     */         
/* 174 */         int m = param1Int - k;
/*     */         
/* 176 */         int n = arrayList.size();
/* 177 */         if (n == 1) {
/*     */ 
/*     */           
/* 180 */           stringBuilder2.insert(m, stringBuilder1);
/* 181 */           fireParagraphListChangeEvent(j, j + 1, 
/* 182 */               Collections.singletonList(stringBuilder2));
/*     */         }
/*     */         else {
/*     */           
/* 186 */           int i1 = stringBuilder2.length();
/* 187 */           CharSequence charSequence = stringBuilder2.subSequence(m, i1);
/* 188 */           stringBuilder2.delete(m, i1);
/*     */ 
/*     */ 
/*     */           
/* 192 */           StringBuilder stringBuilder = arrayList.get(0);
/* 193 */           stringBuilder2.insert(m, stringBuilder);
/* 194 */           stringBuilder1.append(charSequence);
/* 195 */           fireParagraphListChangeEvent(j, j + 1, 
/* 196 */               Collections.singletonList(stringBuilder2));
/*     */ 
/*     */           
/* 199 */           this.paragraphs.addAll(j + 1, arrayList.subList(1, n));
/* 200 */           fireParagraphListChangeEvent(j + 1, j + n, Collections.EMPTY_LIST);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 205 */         this.contentLength += i;
/* 206 */         if (param1Boolean) {
/* 207 */           ExpressionHelper.fireValueChangedEvent(this.helper);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public void delete(int param1Int1, int param1Int2, boolean param1Boolean) {
/* 213 */       if (param1Int1 > param1Int2) {
/* 214 */         throw new IllegalArgumentException();
/*     */       }
/*     */       
/* 217 */       if (param1Int1 < 0 || param1Int2 > this.contentLength)
/*     */       {
/* 219 */         throw new IndexOutOfBoundsException();
/*     */       }
/*     */       
/* 222 */       int i = param1Int2 - param1Int1;
/*     */       
/* 224 */       if (i > 0) {
/*     */         
/* 226 */         int j = this.paragraphs.size();
/* 227 */         int k = this.contentLength + 1;
/*     */         
/* 229 */         StringBuilder stringBuilder1 = null;
/*     */         
/*     */         do {
/* 232 */           stringBuilder1 = this.paragraphs.get(--j);
/* 233 */           k -= stringBuilder1.length() + 1;
/* 234 */         } while (param1Int2 < k);
/*     */         
/* 236 */         int m = j;
/* 237 */         int n = k;
/* 238 */         StringBuilder stringBuilder2 = stringBuilder1;
/*     */ 
/*     */         
/* 241 */         j++;
/* 242 */         k += stringBuilder1.length() + 1;
/*     */         
/*     */         do {
/* 245 */           stringBuilder1 = this.paragraphs.get(--j);
/* 246 */           k -= stringBuilder1.length() + 1;
/* 247 */         } while (param1Int1 < k);
/*     */         
/* 249 */         int i1 = j;
/* 250 */         int i2 = k;
/* 251 */         StringBuilder stringBuilder3 = stringBuilder1;
/*     */ 
/*     */         
/* 254 */         if (i1 == m) {
/*     */           
/* 256 */           stringBuilder3.delete(param1Int1 - i2, param1Int2 - i2);
/*     */ 
/*     */           
/* 259 */           fireParagraphListChangeEvent(i1, i1 + 1, 
/* 260 */               Collections.singletonList(stringBuilder3));
/*     */         }
/*     */         else {
/*     */           
/* 264 */           CharSequence charSequence = stringBuilder3.subSequence(0, param1Int1 - i2);
/*     */           
/* 266 */           int i3 = param1Int1 + i - n;
/*     */           
/* 268 */           stringBuilder2.delete(0, i3);
/* 269 */           fireParagraphListChangeEvent(m, m + 1, 
/* 270 */               Collections.singletonList(stringBuilder2));
/*     */           
/* 272 */           if (m - i1 > 0) {
/* 273 */             ArrayList<CharSequence> arrayList = new ArrayList(this.paragraphs.subList(i1, m));
/*     */             
/* 275 */             this.paragraphs.subList(i1, m)
/* 276 */               .clear();
/* 277 */             fireParagraphListChangeEvent(i1, i1, arrayList);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 282 */           stringBuilder2.insert(0, charSequence);
/* 283 */           fireParagraphListChangeEvent(i1, i1 + 1, 
/* 284 */               Collections.singletonList(stringBuilder3));
/*     */         } 
/*     */ 
/*     */         
/* 288 */         this.contentLength -= i;
/* 289 */         if (param1Boolean) {
/* 290 */           ExpressionHelper.fireValueChangedEvent(this.helper);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public int length() {
/* 296 */       return this.contentLength;
/*     */     }
/*     */     
/*     */     public String get() {
/* 300 */       return get(0, length());
/*     */     }
/*     */     
/*     */     public void addListener(ChangeListener<? super String> param1ChangeListener) {
/* 304 */       this.helper = ExpressionHelper.addListener(this.helper, this, param1ChangeListener);
/*     */     }
/*     */     
/*     */     public void removeListener(ChangeListener<? super String> param1ChangeListener) {
/* 308 */       this.helper = ExpressionHelper.removeListener(this.helper, param1ChangeListener);
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 312 */       return get();
/*     */     }
/*     */     
/*     */     public void addListener(InvalidationListener param1InvalidationListener) {
/* 316 */       this.helper = ExpressionHelper.addListener(this.helper, this, param1InvalidationListener);
/*     */     }
/*     */     
/*     */     public void removeListener(InvalidationListener param1InvalidationListener) {
/* 320 */       this.helper = ExpressionHelper.removeListener(this.helper, param1InvalidationListener);
/*     */     }
/*     */     
/*     */     private void fireParagraphListChangeEvent(int param1Int1, int param1Int2, List<CharSequence> param1List) {
/* 324 */       TextArea.ParagraphListChange paragraphListChange = new TextArea.ParagraphListChange(this.paragraphList, param1Int1, param1Int2, param1List);
/* 325 */       ListListenerHelper.fireValueChangedEvent(this.listenerHelper, paragraphListChange);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ParagraphList
/*     */     extends AbstractList<CharSequence>
/*     */     implements ObservableList<CharSequence> {
/*     */     private TextArea.TextAreaContent content;
/*     */     
/*     */     private ParagraphList() {}
/*     */     
/*     */     public CharSequence get(int param1Int) {
/* 337 */       return this.content.paragraphs.get(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends CharSequence> param1Collection) {
/* 342 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(CharSequence... param1VarArgs) {
/* 347 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean setAll(Collection<? extends CharSequence> param1Collection) {
/* 352 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean setAll(CharSequence... param1VarArgs) {
/* 357 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 362 */       return this.content.paragraphs.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public void addListener(ListChangeListener<? super CharSequence> param1ListChangeListener) {
/* 367 */       this.content.listenerHelper = ListListenerHelper.addListener(this.content.listenerHelper, param1ListChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     public void removeListener(ListChangeListener<? super CharSequence> param1ListChangeListener) {
/* 372 */       this.content.listenerHelper = ListListenerHelper.removeListener(this.content.listenerHelper, param1ListChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(CharSequence... param1VarArgs) {
/* 377 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(CharSequence... param1VarArgs) {
/* 382 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove(int param1Int1, int param1Int2) {
/* 387 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public void addListener(InvalidationListener param1InvalidationListener) {
/* 392 */       this.content.listenerHelper = ListListenerHelper.addListener(this.content.listenerHelper, param1InvalidationListener);
/*     */     }
/*     */ 
/*     */     
/*     */     public void removeListener(InvalidationListener param1InvalidationListener) {
/* 397 */       this.content.listenerHelper = ListListenerHelper.removeListener(this.content.listenerHelper, param1InvalidationListener);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ParagraphListChange
/*     */     extends NonIterableChange<CharSequence>
/*     */   {
/*     */     private List<CharSequence> removed;
/*     */     
/*     */     protected ParagraphListChange(ObservableList<CharSequence> param1ObservableList, int param1Int1, int param1Int2, List<CharSequence> param1List) {
/* 407 */       super(param1Int1, param1Int2, param1ObservableList);
/*     */       
/* 409 */       this.removed = param1List;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<CharSequence> getRemoved() {
/* 414 */       return this.removed;
/*     */     }
/*     */ 
/*     */     
/*     */     protected int[] getPermutation() {
/* 419 */       return new int[0];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextArea() {
/* 439 */     this("");
/*     */   } final void textUpdated() { setScrollTop(0.0D);
/*     */     setScrollLeft(0.0D); }
/*     */   public ObservableList<CharSequence> getParagraphs() { return ((TextAreaContent)getContent()).paragraphList; }
/*     */   public final BooleanProperty wrapTextProperty() { return this.wrapText; }
/*     */   public final boolean isWrapText() { return this.wrapText.getValue().booleanValue(); }
/*     */   public final void setWrapText(boolean paramBoolean) { this.wrapText.setValue(Boolean.valueOf(paramBoolean)); }
/*     */   public final IntegerProperty prefColumnCountProperty() { return this.prefColumnCount; }
/*     */   public final int getPrefColumnCount() { return this.prefColumnCount.getValue().intValue(); }
/* 448 */   public TextArea(String paramString) { super(new TextAreaContent(null));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 482 */     this.wrapText = new StyleableBooleanProperty(false) {
/*     */         public Object getBean() {
/* 484 */           return TextArea.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 488 */           return "wrapText";
/*     */         }
/*     */         
/*     */         public CssMetaData<TextArea, Boolean> getCssMetaData() {
/* 492 */           return TextArea.StyleableProperties.WRAP_TEXT;
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 504 */     this.prefColumnCount = new StyleableIntegerProperty(40)
/*     */       {
/* 506 */         private int oldValue = get();
/*     */ 
/*     */         
/*     */         protected void invalidated() {
/* 510 */           int i = get();
/* 511 */           if (i < 0) {
/* 512 */             if (isBound()) {
/* 513 */               unbind();
/*     */             }
/* 515 */             set(this.oldValue);
/* 516 */             throw new IllegalArgumentException("value cannot be negative.");
/*     */           } 
/* 518 */           this.oldValue = i;
/*     */         }
/*     */         
/*     */         public CssMetaData<TextArea, Number> getCssMetaData() {
/* 522 */           return TextArea.StyleableProperties.PREF_COLUMN_COUNT;
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 527 */           return TextArea.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 532 */           return "prefColumnCount";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 544 */     this.prefRowCount = new StyleableIntegerProperty(10)
/*     */       {
/* 546 */         private int oldValue = get();
/*     */ 
/*     */         
/*     */         protected void invalidated() {
/* 550 */           int i = get();
/* 551 */           if (i < 0) {
/* 552 */             if (isBound()) {
/* 553 */               unbind();
/*     */             }
/* 555 */             set(this.oldValue);
/* 556 */             throw new IllegalArgumentException("value cannot be negative.");
/*     */           } 
/*     */           
/* 559 */           this.oldValue = i;
/*     */         }
/*     */         
/*     */         public CssMetaData<TextArea, Number> getCssMetaData() {
/* 563 */           return TextArea.StyleableProperties.PREF_ROW_COUNT;
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 568 */           return TextArea.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 573 */           return "prefRowCount";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 585 */     this.scrollTop = new SimpleDoubleProperty(this, "scrollTop", 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 595 */     this.scrollLeft = new SimpleDoubleProperty(this, "scrollLeft", 0.0D); getStyleClass().add("text-area"); setAccessibleRole(AccessibleRole.TEXT_AREA); setText(paramString); }
/* 596 */   public final void setPrefColumnCount(int paramInt) { this.prefColumnCount.setValue(Integer.valueOf(paramInt)); } public final IntegerProperty prefRowCountProperty() { return this.prefRowCount; } public final int getPrefRowCount() { return this.prefRowCount.getValue().intValue(); } public final DoubleProperty scrollLeftProperty() { return this.scrollLeft; }
/* 597 */   public final void setPrefRowCount(int paramInt) { this.prefRowCount.setValue(Integer.valueOf(paramInt)); } public final DoubleProperty scrollTopProperty() { return this.scrollTop; } public final double getScrollTop() { return this.scrollTop.getValue().doubleValue(); } public final void setScrollTop(double paramDouble) { this.scrollTop.setValue(Double.valueOf(paramDouble)); } public final double getScrollLeft() { return this.scrollLeft.getValue().doubleValue(); } public final void setScrollLeft(double paramDouble) {
/* 598 */     this.scrollLeft.setValue(Double.valueOf(paramDouble));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 609 */     return (Skin<?>)new TextAreaSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 620 */     private static final CssMetaData<TextArea, Number> PREF_COLUMN_COUNT = new CssMetaData<TextArea, Number>("-fx-pref-column-count", 
/*     */         
/* 622 */         SizeConverter.getInstance(), Integer.valueOf(40))
/*     */       {
/*     */         public boolean isSettable(TextArea param2TextArea)
/*     */         {
/* 626 */           return !param2TextArea.prefColumnCount.isBound();
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(TextArea param2TextArea) {
/* 631 */           return (StyleableProperty<Number>)param2TextArea.prefColumnCountProperty();
/*     */         }
/*     */       };
/*     */     
/* 635 */     private static final CssMetaData<TextArea, Number> PREF_ROW_COUNT = new CssMetaData<TextArea, Number>("-fx-pref-row-count", 
/*     */         
/* 637 */         SizeConverter.getInstance(), Integer.valueOf(10))
/*     */       {
/*     */         public boolean isSettable(TextArea param2TextArea)
/*     */         {
/* 641 */           return !param2TextArea.prefRowCount.isBound();
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(TextArea param2TextArea) {
/* 646 */           return (StyleableProperty<Number>)param2TextArea.prefRowCountProperty();
/*     */         }
/*     */       };
/*     */     
/* 650 */     private static final CssMetaData<TextArea, Boolean> WRAP_TEXT = new CssMetaData<TextArea, Boolean>("-fx-wrap-text", 
/*     */         
/* 652 */         StyleConverter.getBooleanConverter(), Boolean.valueOf(false))
/*     */       {
/*     */         public boolean isSettable(TextArea param2TextArea)
/*     */         {
/* 656 */           return !param2TextArea.wrapText.isBound();
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(TextArea param2TextArea) {
/* 661 */           return (StyleableProperty<Boolean>)param2TextArea.wrapTextProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 668 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(TextInputControl.getClassCssMetaData());
/* 669 */       arrayList.add(PREF_COLUMN_COUNT);
/* 670 */       arrayList.add(PREF_ROW_COUNT);
/* 671 */       arrayList.add(WRAP_TEXT);
/* 672 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 682 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 691 */     return getClassCssMetaData();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TextArea.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */