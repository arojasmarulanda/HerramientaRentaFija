/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TableUtil
/*     */ {
/*     */   static void removeTableColumnListener(List<? extends TableColumnBase> paramList, InvalidationListener paramInvalidationListener1, InvalidationListener paramInvalidationListener2, InvalidationListener paramInvalidationListener3, InvalidationListener paramInvalidationListener4) {
/*  51 */     if (paramList == null)
/*  52 */       return;  for (TableColumnBase tableColumnBase : paramList) {
/*  53 */       tableColumnBase.visibleProperty().removeListener(paramInvalidationListener1);
/*  54 */       tableColumnBase.sortableProperty().removeListener(paramInvalidationListener2);
/*  55 */       tableColumnBase.comparatorProperty().removeListener(paramInvalidationListener4);
/*     */ 
/*     */       
/*  58 */       if (tableColumnBase instanceof TableColumn) {
/*  59 */         ((TableColumn)tableColumnBase).sortTypeProperty().removeListener(paramInvalidationListener3);
/*  60 */       } else if (tableColumnBase instanceof TreeTableColumn) {
/*  61 */         ((TreeTableColumn)tableColumnBase).sortTypeProperty().removeListener(paramInvalidationListener3);
/*     */       } 
/*     */       
/*  64 */       removeTableColumnListener(tableColumnBase.getColumns(), paramInvalidationListener1, paramInvalidationListener2, paramInvalidationListener3, paramInvalidationListener4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void addTableColumnListener(List<? extends TableColumnBase> paramList, InvalidationListener paramInvalidationListener1, InvalidationListener paramInvalidationListener2, InvalidationListener paramInvalidationListener3, InvalidationListener paramInvalidationListener4) {
/*  78 */     if (paramList == null)
/*  79 */       return;  for (TableColumnBase tableColumnBase : paramList) {
/*  80 */       tableColumnBase.visibleProperty().addListener(paramInvalidationListener1);
/*  81 */       tableColumnBase.sortableProperty().addListener(paramInvalidationListener2);
/*  82 */       tableColumnBase.comparatorProperty().addListener(paramInvalidationListener4);
/*     */       
/*  84 */       if (tableColumnBase instanceof TableColumn) {
/*  85 */         ((TableColumn)tableColumnBase).sortTypeProperty().addListener(paramInvalidationListener3);
/*  86 */       } else if (tableColumnBase instanceof TreeTableColumn) {
/*  87 */         ((TreeTableColumn)tableColumnBase).sortTypeProperty().addListener(paramInvalidationListener3);
/*     */       } 
/*     */       
/*  90 */       addTableColumnListener(tableColumnBase.getColumns(), paramInvalidationListener1, paramInvalidationListener2, paramInvalidationListener3, paramInvalidationListener4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void removeColumnsListener(List<? extends TableColumnBase> paramList, ListChangeListener paramListChangeListener) {
/*  99 */     if (paramList == null)
/*     */       return; 
/* 101 */     for (TableColumnBase tableColumnBase : paramList) {
/* 102 */       tableColumnBase.getColumns().removeListener(paramListChangeListener);
/* 103 */       removeColumnsListener(tableColumnBase.getColumns(), paramListChangeListener);
/*     */     } 
/*     */   }
/*     */   
/*     */   static void addColumnsListener(List<? extends TableColumnBase> paramList, ListChangeListener paramListChangeListener) {
/* 108 */     if (paramList == null)
/*     */       return; 
/* 110 */     for (TableColumnBase tableColumnBase : paramList) {
/* 111 */       tableColumnBase.getColumns().addListener(paramListChangeListener);
/* 112 */       addColumnsListener(tableColumnBase.getColumns(), paramListChangeListener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void handleSortFailure(ObservableList<? extends TableColumnBase> paramObservableList, SortEventType paramSortEventType, Object... paramVarArgs) {
/* 120 */     if (paramSortEventType == SortEventType.COLUMN_SORT_TYPE_CHANGE) {
/*     */       
/* 122 */       TableColumnBase tableColumnBase = (TableColumnBase)paramVarArgs[0];
/* 123 */       revertSortType(tableColumnBase);
/* 124 */     } else if (paramSortEventType == SortEventType.SORT_ORDER_CHANGE) {
/*     */       
/* 126 */       ListChangeListener.Change change = (ListChangeListener.Change)paramVarArgs[0];
/*     */       
/* 128 */       ArrayList<?> arrayList = new ArrayList();
/* 129 */       ArrayList<? extends TableColumnBase> arrayList1 = new ArrayList();
/* 130 */       while (change.next()) {
/* 131 */         if (change.wasAdded()) {
/* 132 */           arrayList.addAll(change.getAddedSubList());
/*     */         }
/*     */         
/* 135 */         if (change.wasRemoved()) {
/* 136 */           arrayList1.addAll(change.getRemoved());
/*     */         }
/*     */       } 
/*     */       
/* 140 */       paramObservableList.removeAll(arrayList);
/* 141 */       paramObservableList.addAll(arrayList1);
/* 142 */     } else if (paramSortEventType != SortEventType.COLUMN_SORTABLE_CHANGE) {
/*     */       
/* 144 */       if (paramSortEventType == SortEventType.COLUMN_COMPARATOR_CHANGE);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void revertSortType(TableColumnBase paramTableColumnBase) {
/* 150 */     if (paramTableColumnBase instanceof TableColumn) {
/* 151 */       TableColumn tableColumn = (TableColumn)paramTableColumnBase;
/* 152 */       TableColumn.SortType sortType = tableColumn.getSortType();
/* 153 */       if (sortType == TableColumn.SortType.ASCENDING) {
/* 154 */         tableColumn.setSortType(null);
/* 155 */       } else if (sortType == TableColumn.SortType.DESCENDING) {
/* 156 */         tableColumn.setSortType(TableColumn.SortType.ASCENDING);
/* 157 */       } else if (sortType == null) {
/* 158 */         tableColumn.setSortType(TableColumn.SortType.DESCENDING);
/*     */       } 
/* 160 */     } else if (paramTableColumnBase instanceof TreeTableColumn) {
/* 161 */       TreeTableColumn treeTableColumn = (TreeTableColumn)paramTableColumnBase;
/* 162 */       TreeTableColumn.SortType sortType = treeTableColumn.getSortType();
/* 163 */       if (sortType == TreeTableColumn.SortType.ASCENDING) {
/* 164 */         treeTableColumn.setSortType(null);
/* 165 */       } else if (sortType == TreeTableColumn.SortType.DESCENDING) {
/* 166 */         treeTableColumn.setSortType(TreeTableColumn.SortType.ASCENDING);
/* 167 */       } else if (sortType == null) {
/* 168 */         treeTableColumn.setSortType(TreeTableColumn.SortType.DESCENDING);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   enum SortEventType {
/* 174 */     SORT_ORDER_CHANGE,
/* 175 */     COLUMN_SORT_TYPE_CHANGE,
/* 176 */     COLUMN_SORTABLE_CHANGE,
/* 177 */     COLUMN_COMPARATOR_CHANGE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean constrainedResize(ResizeFeaturesBase paramResizeFeaturesBase, boolean paramBoolean, double paramDouble, List<? extends TableColumnBase<?, ?>> paramList) {
/* 196 */     TableColumnBase tableColumnBase1 = paramResizeFeaturesBase.getColumn();
/* 197 */     double d1 = paramResizeFeaturesBase.getDelta().doubleValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     double d2 = 0.0D;
/* 212 */     double d3 = 0.0D;
/*     */     
/* 214 */     if (paramDouble == 0.0D) return false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 221 */     double d4 = 0.0D;
/* 222 */     for (TableColumnBase<?, ?> tableColumnBase : paramList) {
/* 223 */       d4 += tableColumnBase.getWidth();
/*     */     }
/*     */     
/* 226 */     if (Math.abs(d4 - paramDouble) > 1.0D) {
/* 227 */       boolean bool1 = (d4 > paramDouble) ? true : false;
/* 228 */       double d = paramDouble;
/*     */       
/* 230 */       if (paramBoolean) {
/*     */ 
/*     */         
/* 233 */         for (TableColumnBase<?, ?> tableColumnBase : paramList) {
/* 234 */           d2 += tableColumnBase.getMinWidth();
/* 235 */           d3 += tableColumnBase.getMaxWidth();
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 241 */         d3 = (d3 == Double.POSITIVE_INFINITY) ? Double.MAX_VALUE : ((d3 == Double.NEGATIVE_INFINITY) ? Double.MIN_VALUE : d3);
/*     */         
/* 243 */         for (TableColumnBase<?, ?> tableColumnBase : paramList) {
/* 244 */           double d8, d6 = tableColumnBase.getMinWidth();
/* 245 */           double d7 = tableColumnBase.getMaxWidth();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 251 */           if (Math.abs(d2 - d3) < 1.0E-7D) {
/* 252 */             d8 = d6;
/*     */           } else {
/* 254 */             double d10 = (d - d2) / (d3 - d2);
/* 255 */             d8 = Math.round(d6 + d10 * (d7 - d6));
/*     */           } 
/*     */           
/* 258 */           double d9 = resize(tableColumnBase, d8 - tableColumnBase.getWidth());
/*     */           
/* 260 */           d -= d8 + d9;
/* 261 */           d2 -= d6;
/* 262 */           d3 -= d7;
/*     */         } 
/*     */         
/* 265 */         paramBoolean = false;
/*     */       } else {
/* 267 */         double d6 = paramDouble - d4;
/* 268 */         List<? extends TableColumnBase<?, ?>> list = paramList;
/* 269 */         resizeColumns(list, d6);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 281 */     if (tableColumnBase1 == null) {
/* 282 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 290 */     boolean bool = (d1 < 0.0D) ? true : false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 295 */     TableColumnBase tableColumnBase2 = tableColumnBase1;
/* 296 */     while (tableColumnBase2.getColumns().size() > 0) {
/* 297 */       tableColumnBase2 = tableColumnBase2.getColumns().get(tableColumnBase2.getColumns().size() - 1);
/*     */     }
/*     */     
/* 300 */     int i = paramList.indexOf(tableColumnBase2);
/* 301 */     int j = paramList.size() - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     double d5 = d1;
/* 314 */     while (j > i && d5 != 0.0D) {
/* 315 */       TableColumnBase tableColumnBase3 = paramList.get(j);
/* 316 */       j--;
/*     */ 
/*     */       
/* 319 */       if (!tableColumnBase3.isResizable()) {
/*     */         continue;
/*     */       }
/* 322 */       TableColumnBase tableColumnBase4 = bool ? tableColumnBase2 : tableColumnBase3;
/* 323 */       TableColumnBase tableColumnBase5 = !bool ? tableColumnBase2 : tableColumnBase3;
/*     */ 
/*     */ 
/*     */       
/* 327 */       if (tableColumnBase5.getWidth() > tableColumnBase5.getPrefWidth()) {
/*     */ 
/*     */         
/* 330 */         List<? extends TableColumnBase<?, ?>> list = paramList.subList(i + 1, j + 1);
/* 331 */         for (int k = list.size() - 1; k >= 0; k--) {
/* 332 */           TableColumnBase tableColumnBase = list.get(k);
/* 333 */           if (tableColumnBase.getWidth() < tableColumnBase.getPrefWidth()) {
/* 334 */             tableColumnBase5 = tableColumnBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 351 */       double d6 = Math.min(Math.abs(d5), tableColumnBase4.getWidth() - tableColumnBase4.getMinWidth());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 356 */       double d7 = resize(tableColumnBase4, -d6);
/* 357 */       double d8 = resize(tableColumnBase5, d6);
/* 358 */       d5 += bool ? d6 : -d6;
/*     */     } 
/* 360 */     return (d5 == 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static double resize(TableColumnBase<?, ?> paramTableColumnBase, double paramDouble) {
/* 367 */     if (paramDouble == 0.0D) return 0.0D; 
/* 368 */     if (!paramTableColumnBase.isResizable()) return paramDouble;
/*     */     
/* 370 */     boolean bool = (paramDouble < 0.0D) ? true : false;
/* 371 */     List<TableColumnBase<?, ?>> list = getResizableChildren(paramTableColumnBase, bool);
/*     */     
/* 373 */     if (list.size() > 0) {
/* 374 */       return resizeColumns(list, paramDouble);
/*     */     }
/* 376 */     double d = paramTableColumnBase.getWidth() + paramDouble;
/*     */     
/* 378 */     if (d > paramTableColumnBase.getMaxWidth()) {
/* 379 */       paramTableColumnBase.doSetWidth(paramTableColumnBase.getMaxWidth());
/* 380 */       return d - paramTableColumnBase.getMaxWidth();
/* 381 */     }  if (d < paramTableColumnBase.getMinWidth()) {
/* 382 */       paramTableColumnBase.doSetWidth(paramTableColumnBase.getMinWidth());
/* 383 */       return d - paramTableColumnBase.getMinWidth();
/*     */     } 
/* 385 */     paramTableColumnBase.doSetWidth(d);
/* 386 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<TableColumnBase<?, ?>> getResizableChildren(TableColumnBase<?, ?> paramTableColumnBase, boolean paramBoolean) {
/* 395 */     if (paramTableColumnBase == null || paramTableColumnBase.getColumns().isEmpty()) {
/* 396 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 399 */     ArrayList<TableColumnBase> arrayList = new ArrayList();
/* 400 */     for (TableColumnBase<?, ?> tableColumnBase : paramTableColumnBase.getColumns()) {
/* 401 */       if (!tableColumnBase.isVisible() || 
/* 402 */         !tableColumnBase.isResizable())
/*     */         continue; 
/* 404 */       if (paramBoolean && tableColumnBase.getWidth() > tableColumnBase.getMinWidth()) {
/* 405 */         arrayList.add(tableColumnBase); continue;
/* 406 */       }  if (!paramBoolean && tableColumnBase.getWidth() < tableColumnBase.getMaxWidth()) {
/* 407 */         arrayList.add(tableColumnBase);
/*     */       }
/*     */     } 
/* 410 */     return (List)arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double resizeColumns(List<? extends TableColumnBase<?, ?>> paramList, double paramDouble) {
/* 419 */     int i = paramList.size();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 424 */     double d1 = paramDouble / i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 430 */     double d2 = paramDouble;
/*     */ 
/*     */ 
/*     */     
/* 434 */     byte b = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 439 */     boolean bool = true;
/* 440 */     for (TableColumnBase<?, ?> tableColumnBase : paramList) {
/* 441 */       b++;
/*     */ 
/*     */       
/* 444 */       double d = resize(tableColumnBase, d1);
/*     */ 
/*     */ 
/*     */       
/* 448 */       d2 = d2 - d1 + d;
/*     */ 
/*     */ 
/*     */       
/* 452 */       if (d != 0.0D) {
/* 453 */         bool = false;
/*     */ 
/*     */         
/* 456 */         d1 = d2 / (i - b);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 461 */     return bool ? 0.0D : d2;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TableUtil.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */