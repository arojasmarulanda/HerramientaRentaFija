/*    */ package javafx.scene.control;
/*    */ 
/*    */ import javafx.beans.NamedArg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResizeFeaturesBase<S>
/*    */ {
/*    */   private final TableColumnBase<S, ?> column;
/*    */   private final Double delta;
/*    */   
/*    */   public ResizeFeaturesBase(@NamedArg("column") TableColumnBase<S, ?> paramTableColumnBase, @NamedArg("delta") Double paramDouble) {
/* 51 */     this.column = paramTableColumnBase;
/* 52 */     this.delta = paramDouble;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TableColumnBase<S, ?> getColumn() {
/* 61 */     return this.column;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Double getDelta() {
/* 69 */     return this.delta;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\ResizeFeaturesBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */