/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.collections.MappingChange;
/*      */ import com.sun.javafx.collections.NonIterableChange;
/*      */ import com.sun.javafx.scene.control.ReadOnlyUnbackedObservableList;
/*      */ import com.sun.javafx.scene.control.SelectedCellsMap;
/*      */ import com.sun.javafx.scene.control.TableColumnComparatorBase;
/*      */ import com.sun.javafx.scene.control.behavior.TableCellBehavior;
/*      */ import com.sun.javafx.scene.control.behavior.TableCellBehaviorBase;
/*      */ import com.sun.javafx.scene.control.behavior.TreeTableCellBehavior;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.WeakHashMap;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.DefaultProperty;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.WeakInvalidationListener;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*      */ import javafx.beans.property.ReadOnlyIntegerWrapper;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.beans.value.ChangeListener;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.beans.value.WeakChangeListener;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.MapChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.collections.WeakListChangeListener;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.EventType;
/*      */ import javafx.event.WeakEventHandler;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.skin.TreeTableViewSkin;
/*      */ import javafx.util.Callback;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @DefaultProperty("root")
/*      */ public class TreeTableView<S>
/*      */   extends Control
/*      */ {
/*      */   public TreeTableView() {
/*  361 */     this((TreeItem<S>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TreeTableView(TreeItem<S> paramTreeItem) {
/*  607 */     this.expandedItemCountDirty = true;
/*      */ 
/*      */ 
/*      */     
/*  611 */     this.treeItemCacheMap = new HashMap<>();
/*      */ 
/*      */ 
/*      */     
/*  615 */     this.columns = FXCollections.observableArrayList();
/*      */ 
/*      */ 
/*      */     
/*  619 */     this.visibleLeafColumns = FXCollections.observableArrayList();
/*  620 */     this.unmodifiableVisibleLeafColumns = FXCollections.unmodifiableObservableList(this.visibleLeafColumns);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  625 */     this.sortOrder = FXCollections.observableArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  634 */     this.isInited = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  647 */     this.rootEvent = (paramTreeModificationEvent -> {
/*      */         EventType<? extends Event> eventType = paramTreeModificationEvent.getEventType();
/*      */         
/*      */         boolean bool = false;
/*      */         
/*      */         while (eventType != null) {
/*      */           if (eventType.equals(TreeItem.expandedItemCountChangeEvent())) {
/*      */             bool = true;
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/*      */           eventType = (EventType)eventType.getSuperType();
/*      */         } 
/*      */         if (bool) {
/*      */           this.expandedItemCountDirty = true;
/*      */           requestLayout();
/*      */         } 
/*      */       });
/*  666 */     this.columnsObserver = new ListChangeListener<TreeTableColumn<S, ?>>() {
/*      */         public void onChanged(ListChangeListener.Change<? extends TreeTableColumn<S, ?>> param1Change) {
/*  668 */           ObservableList observableList = TreeTableView.this.getColumns();
/*      */ 
/*      */           
/*  671 */           while (param1Change.next()) {
/*  672 */             if (param1Change.wasAdded()) {
/*  673 */               ArrayList<TreeTableColumn> arrayList3 = new ArrayList();
/*  674 */               for (TreeTableColumn<S, ?> treeTableColumn : param1Change.getAddedSubList()) {
/*  675 */                 if (treeTableColumn == null)
/*      */                   continue; 
/*  677 */                 byte b = 0;
/*  678 */                 for (TreeTableColumn treeTableColumn1 : observableList) {
/*  679 */                   if (treeTableColumn == treeTableColumn1) {
/*  680 */                     b++;
/*      */                   }
/*      */                 } 
/*      */                 
/*  684 */                 if (b > 1) {
/*  685 */                   arrayList3.add(treeTableColumn);
/*      */                 }
/*      */               } 
/*      */               
/*  689 */               if (!arrayList3.isEmpty()) {
/*  690 */                 String str = "";
/*  691 */                 for (TreeTableColumn treeTableColumn : arrayList3) {
/*  692 */                   str = str + "'" + str + "', ";
/*      */                 }
/*  694 */                 throw new IllegalStateException("Duplicate TreeTableColumns detected in TreeTableView columns list with titles " + str);
/*      */               } 
/*      */             } 
/*      */           } 
/*  698 */           param1Change.reset();
/*      */ 
/*      */ 
/*      */           
/*  702 */           ArrayList<TreeTableColumn<S, ?>> arrayList = new ArrayList();
/*  703 */           while (param1Change.next()) {
/*  704 */             List<? extends TreeTableColumn<S, ?>> list1 = param1Change.getRemoved();
/*  705 */             List<? extends TreeTableColumn<S, ?>> list2 = param1Change.getAddedSubList();
/*      */             
/*  707 */             if (param1Change.wasRemoved()) {
/*  708 */               arrayList.addAll(list1);
/*  709 */               for (TreeTableColumn<S, ?> treeTableColumn : list1) {
/*  710 */                 treeTableColumn.setTreeTableView((TreeTableView)null);
/*      */               }
/*      */             } 
/*      */             
/*  714 */             if (param1Change.wasAdded()) {
/*  715 */               arrayList.removeAll(list2);
/*  716 */               for (TreeTableColumn<S, ?> treeTableColumn : list2) {
/*  717 */                 treeTableColumn.setTreeTableView(TreeTableView.this);
/*      */               }
/*      */             } 
/*      */ 
/*      */             
/*  722 */             TableUtil.removeColumnsListener((List)list1, TreeTableView.this.weakColumnsObserver);
/*  723 */             TableUtil.addColumnsListener((List)list2, TreeTableView.this.weakColumnsObserver);
/*      */             
/*  725 */             TableUtil.removeTableColumnListener(param1Change.getRemoved(), TreeTableView.this
/*  726 */                 .weakColumnVisibleObserver, TreeTableView.this
/*  727 */                 .weakColumnSortableObserver, TreeTableView.this
/*  728 */                 .weakColumnSortTypeObserver, TreeTableView.this
/*  729 */                 .weakColumnComparatorObserver);
/*  730 */             TableUtil.addTableColumnListener(param1Change.getAddedSubList(), TreeTableView.this
/*  731 */                 .weakColumnVisibleObserver, TreeTableView.this
/*  732 */                 .weakColumnSortableObserver, TreeTableView.this
/*  733 */                 .weakColumnSortTypeObserver, TreeTableView.this
/*  734 */                 .weakColumnComparatorObserver);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  739 */           TreeTableView.this.updateVisibleLeafColumns();
/*      */           
/*  741 */           TreeTableView.this.sortOrder.removeAll(arrayList);
/*      */ 
/*      */           
/*  744 */           TreeTableView.TreeTableViewFocusModel treeTableViewFocusModel = TreeTableView.this.getFocusModel();
/*  745 */           TreeTableView.TreeTableViewSelectionModel treeTableViewSelectionModel = TreeTableView.this.getSelectionModel();
/*  746 */           param1Change.reset();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  752 */           ArrayList arrayList1 = new ArrayList();
/*  753 */           ArrayList<?> arrayList2 = new ArrayList();
/*  754 */           while (param1Change.next()) {
/*  755 */             if (param1Change.wasRemoved()) {
/*  756 */               arrayList1.addAll(param1Change.getRemoved());
/*      */             }
/*  758 */             if (param1Change.wasAdded()) {
/*  759 */               arrayList2.addAll(param1Change.getAddedSubList());
/*      */             }
/*      */           } 
/*  762 */           arrayList1.removeAll(arrayList2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  768 */           if (treeTableViewFocusModel != null) {
/*  769 */             TreeTablePosition<S, T> treeTablePosition = treeTableViewFocusModel.getFocusedCell();
/*  770 */             boolean bool = false;
/*  771 */             for (TreeTableColumn<S, T> treeTableColumn : (Iterable<TreeTableColumn<S, T>>)arrayList1) {
/*  772 */               bool = (treeTablePosition != null && treeTablePosition.getTableColumn() == treeTableColumn) ? true : false;
/*  773 */               if (bool) {
/*      */                 break;
/*      */               }
/*      */             } 
/*      */             
/*  778 */             if (bool) {
/*  779 */               int i = ((Integer)TreeTableView.this.lastKnownColumnIndex.getOrDefault(treeTablePosition.getTableColumn(), Integer.valueOf(0))).intValue();
/*      */ 
/*      */               
/*  782 */               boolean bool1 = (i == 0) ? false : Math.min(TreeTableView.this.getVisibleLeafColumns().size() - 1, i - 1);
/*  783 */               treeTableViewFocusModel.focus(treeTablePosition.getRow(), TreeTableView.this.getVisibleLeafColumn(bool1));
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  789 */           if (treeTableViewSelectionModel != null) {
/*  790 */             ArrayList arrayList3 = new ArrayList(treeTableViewSelectionModel.getSelectedCells());
/*  791 */             for (TreeTablePosition<S, T> treeTablePosition : (Iterable<TreeTablePosition<S, T>>)arrayList3) {
/*  792 */               boolean bool = false;
/*  793 */               for (TreeTableColumn<S, T> treeTableColumn : (Iterable<TreeTableColumn<S, T>>)arrayList1) {
/*  794 */                 bool = (treeTablePosition != null && treeTablePosition.getTableColumn() == treeTableColumn) ? true : false;
/*  795 */                 if (bool)
/*      */                   break; 
/*      */               } 
/*  798 */               if (bool) {
/*      */ 
/*      */                 
/*  801 */                 int i = ((Integer)TreeTableView.this.lastKnownColumnIndex.getOrDefault(treeTablePosition.getTableColumn(), Integer.valueOf(-1))).intValue();
/*  802 */                 if (i == -1)
/*      */                   continue; 
/*  804 */                 if (treeTableViewSelectionModel instanceof TreeTableView.TreeTableViewArrayListSelectionModel) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  814 */                   TreeTablePosition<Object, Object> treeTablePosition1 = new TreeTablePosition<>(TreeTableView.this, treeTablePosition.getRow(), treeTablePosition.getTableColumn());
/*  815 */                   treeTablePosition1.fixedColumnIndex = i;
/*      */                   
/*  817 */                   ((TreeTableView.TreeTableViewArrayListSelectionModel)treeTableViewSelectionModel).clearSelection((TreeTablePosition)treeTablePosition1); continue;
/*      */                 } 
/*  819 */                 treeTableViewSelectionModel.clearSelection(treeTablePosition.getRow(), treeTablePosition.getTableColumn());
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  827 */           TreeTableView.this.lastKnownColumnIndex.clear();
/*  828 */           for (TreeTableColumn treeTableColumn : TreeTableView.this.getColumns()) {
/*  829 */             int i = TreeTableView.this.getVisibleLeafIndex(treeTableColumn);
/*  830 */             if (i > -1) {
/*  831 */               TreeTableView.this.lastKnownColumnIndex.put(treeTableColumn, Integer.valueOf(i));
/*      */             }
/*      */           } 
/*      */         }
/*      */       };
/*      */     
/*  837 */     this.lastKnownColumnIndex = new WeakHashMap<>();
/*      */     
/*  839 */     this.columnVisibleObserver = (paramObservable -> updateVisibleLeafColumns());
/*      */ 
/*      */ 
/*      */     
/*  843 */     this.columnSortableObserver = (paramObservable -> {
/*      */         TreeTableColumn treeTableColumn = (TreeTableColumn)((BooleanProperty)paramObservable).getBean();
/*      */         if (!getSortOrder().contains(treeTableColumn))
/*      */           return; 
/*      */         doSort(TableUtil.SortEventType.COLUMN_SORTABLE_CHANGE, new Object[] { treeTableColumn });
/*      */       });
/*  849 */     this.columnSortTypeObserver = (paramObservable -> {
/*      */         TreeTableColumn treeTableColumn = (TreeTableColumn)((ObjectProperty)paramObservable).getBean();
/*      */         if (!getSortOrder().contains(treeTableColumn))
/*      */           return; 
/*      */         doSort(TableUtil.SortEventType.COLUMN_SORT_TYPE_CHANGE, new Object[] { treeTableColumn });
/*      */       });
/*  855 */     this.columnComparatorObserver = (paramObservable -> {
/*      */         TreeTableColumn treeTableColumn = (TreeTableColumn)((SimpleObjectProperty)paramObservable).getBean();
/*      */         if (!getSortOrder().contains(treeTableColumn)) {
/*      */           return;
/*      */         }
/*      */         doSort(TableUtil.SortEventType.COLUMN_COMPARATOR_CHANGE, new Object[] { treeTableColumn });
/*      */       });
/*  862 */     this.cellSelectionModelInvalidationListener = (paramObservable -> {
/*      */         boolean bool = ((BooleanProperty)paramObservable).get();
/*      */         
/*      */         pseudoClassStateChanged(PSEUDO_CLASS_CELL_SELECTION, bool);
/*      */         
/*      */         pseudoClassStateChanged(PSEUDO_CLASS_ROW_SELECTION, !bool);
/*      */       });
/*      */     
/*  870 */     this.weakColumnVisibleObserver = new WeakInvalidationListener(this.columnVisibleObserver);
/*      */ 
/*      */     
/*  873 */     this.weakColumnSortableObserver = new WeakInvalidationListener(this.columnSortableObserver);
/*      */ 
/*      */     
/*  876 */     this.weakColumnSortTypeObserver = new WeakInvalidationListener(this.columnSortTypeObserver);
/*      */ 
/*      */     
/*  879 */     this.weakColumnComparatorObserver = new WeakInvalidationListener(this.columnComparatorObserver);
/*      */ 
/*      */     
/*  882 */     this.weakColumnsObserver = new WeakListChangeListener<>(this.columnsObserver);
/*      */ 
/*      */     
/*  885 */     this.weakCellSelectionModelInvalidationListener = new WeakInvalidationListener(this.cellSelectionModelInvalidationListener);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  897 */     this.root = new SimpleObjectProperty<TreeItem<S>>(this, "root") {
/*      */         private WeakReference<TreeItem<S>> weakOldItem;
/*      */         
/*      */         protected void invalidated() {
/*  901 */           TreeItem treeItem = (this.weakOldItem == null) ? null : this.weakOldItem.get();
/*  902 */           if (treeItem != null && TreeTableView.this.weakRootEventListener != null) {
/*  903 */             treeItem.removeEventHandler(TreeItem.treeNotificationEvent(), TreeTableView.this.weakRootEventListener);
/*      */           }
/*      */           
/*  906 */           TreeItem<S> treeItem1 = TreeTableView.this.getRoot();
/*  907 */           if (treeItem1 != null) {
/*  908 */             TreeTableView.this.weakRootEventListener = new WeakEventHandler<>(TreeTableView.this.rootEvent);
/*  909 */             TreeTableView.this.getRoot().addEventHandler(TreeItem.treeNotificationEvent(), TreeTableView.this.weakRootEventListener);
/*  910 */             this.weakOldItem = new WeakReference<>(treeItem1);
/*      */           } 
/*      */ 
/*      */           
/*  914 */           TreeTableView.this.getSortOrder().clear();
/*      */           
/*  916 */           TreeTableView.this.expandedItemCountDirty = true;
/*  917 */           TreeTableView.this.updateRootExpanded();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1121 */     this.expandedItemCount = new ReadOnlyIntegerWrapper(this, "expandedItemCount", 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1901 */     this.sortLock = false;
/* 1902 */     this.lastSortEventType = null;
/* 1903 */     this.lastSortEventSupportInfo = null; getStyleClass().setAll(new String[] { "tree-table-view" }); setAccessibleRole(AccessibleRole.TREE_TABLE_VIEW); setRoot(paramTreeItem); updateExpandedItemCount(paramTreeItem); setSelectionModel(new TreeTableViewArrayListSelectionModel<>(this)); setFocusModel(new TreeTableViewFocusModel<>(this)); getColumns().addListener(this.weakColumnsObserver); getSortOrder().addListener(paramChange -> doSort(TableUtil.SortEventType.SORT_ORDER_CHANGE, new Object[] { paramChange })); getProperties().addListener(paramChange -> { if (paramChange.wasAdded() && "TableView.contentWidth".equals(paramChange.getKey())) { if (paramChange.getValueAdded() instanceof Number) setContentWidth(((Double)paramChange.getValueAdded()).doubleValue());  getProperties().remove("TableView.contentWidth"); }  }); this.isInited = true;
/*      */   } public static <S> EventType<EditEvent<S>> editAnyEvent() { return (EventType)EDIT_ANY_EVENT; } private static final EventType<?> EDIT_ANY_EVENT = new EventType(Event.ANY, "TREE_TABLE_VIEW_EDIT"); public static <S> EventType<EditEvent<S>> editStartEvent() { return (EventType)EDIT_START_EVENT; } private static final EventType<?> EDIT_START_EVENT = new EventType(editAnyEvent(), "EDIT_START"); public static <S> EventType<EditEvent<S>> editCancelEvent() { return (EventType)EDIT_CANCEL_EVENT; } private static final EventType<?> EDIT_CANCEL_EVENT = new EventType(editAnyEvent(), "EDIT_CANCEL"); public static <S> EventType<EditEvent<S>> editCommitEvent() { return (EventType)EDIT_COMMIT_EVENT; } private static final EventType<?> EDIT_COMMIT_EVENT = new EventType(editAnyEvent(), "EDIT_COMMIT"); @Deprecated(since = "8u20") public static int getNodeLevel(TreeItem<?> paramTreeItem) { return TreeView.getNodeLevel(paramTreeItem); } public static final Callback<ResizeFeatures, Boolean> UNCONSTRAINED_RESIZE_POLICY = new Callback<ResizeFeatures, Boolean>() { public String toString() { return "unconstrained-resize"; } public Boolean call(TreeTableView.ResizeFeatures param1ResizeFeatures) { double d = TableUtil.resize(param1ResizeFeatures.getColumn(), param1ResizeFeatures.getDelta().doubleValue()); return Boolean.valueOf((Double.compare(d, 0.0D) == 0)); } }
/*      */   ; public static final Callback<ResizeFeatures, Boolean> CONSTRAINED_RESIZE_POLICY = new Callback<ResizeFeatures, Boolean>() { private boolean isFirstRun = true; public String toString() { return "constrained-resize"; } public Boolean call(TreeTableView.ResizeFeatures param1ResizeFeatures) { TreeTableView treeTableView = param1ResizeFeatures.getTable(); ObservableList<? extends TableColumnBase<?, ?>> observableList = treeTableView.getVisibleLeafColumns(); Boolean bool = Boolean.valueOf(TableUtil.constrainedResize(param1ResizeFeatures, this.isFirstRun, treeTableView.contentWidth, observableList)); this.isFirstRun = !this.isFirstRun ? false : (!bool.booleanValue()); return bool; } }
/* 1906 */   ; public static final Callback<TreeTableView, Boolean> DEFAULT_SORT_POLICY = new Callback<TreeTableView, Boolean>() { public Boolean call(TreeTableView param1TreeTableView) { try { TreeItem treeItem = param1TreeTableView.getRoot(); if (treeItem == null) return Boolean.valueOf(false);  TreeSortMode treeSortMode = param1TreeTableView.getSortMode(); if (treeSortMode == null) return Boolean.valueOf(false);  treeItem.lastSortMode = treeSortMode; treeItem.lastComparator = param1TreeTableView.getComparator(); treeItem.sort(); return Boolean.valueOf(true); } catch (UnsupportedOperationException unsupportedOperationException) { return Boolean.valueOf(false); }  } }; private boolean expandedItemCountDirty; private Map<Integer, SoftReference<TreeItem<S>>> treeItemCacheMap; private final ObservableList<TreeTableColumn<S, ?>> columns; private final ObservableList<TreeTableColumn<S, ?>> visibleLeafColumns; private final ObservableList<TreeTableColumn<S, ?>> unmodifiableVisibleLeafColumns; private ObservableList<TreeTableColumn<S, ?>> sortOrder; double contentWidth; private boolean isInited; private final EventHandler<TreeItem.TreeModificationEvent<S>> rootEvent; private final ListChangeListener<TreeTableColumn<S, ?>> columnsObserver; private final WeakHashMap<TreeTableColumn<S, ?>, Integer> lastKnownColumnIndex; private final InvalidationListener columnVisibleObserver; private final InvalidationListener columnSortableObserver; private final InvalidationListener columnSortTypeObserver; private final InvalidationListener columnComparatorObserver; private final InvalidationListener cellSelectionModelInvalidationListener; private WeakEventHandler<TreeItem.TreeModificationEvent<S>> weakRootEventListener; private final WeakInvalidationListener weakColumnVisibleObserver; private final WeakInvalidationListener weakColumnSortableObserver; private final WeakInvalidationListener weakColumnSortTypeObserver; private final WeakInvalidationListener weakColumnComparatorObserver; private final WeakListChangeListener<TreeTableColumn<S, ?>> weakColumnsObserver; private final WeakInvalidationListener weakCellSelectionModelInvalidationListener; private ObjectProperty<TreeItem<S>> root; private BooleanProperty showRoot; private ObjectProperty<TreeTableColumn<S, ?>> treeColumn; private ObjectProperty<TreeTableViewSelectionModel<S>> selectionModel; private ObjectProperty<TreeTableViewFocusModel<S>> focusModel; private ReadOnlyIntegerWrapper expandedItemCount; private BooleanProperty editable; private ReadOnlyObjectWrapper<TreeTablePosition<S, ?>> editingCell; private BooleanProperty tableMenuButtonVisible; private ObjectProperty<Callback<ResizeFeatures, Boolean>> columnResizePolicy; private ObjectProperty<Callback<TreeTableView<S>, TreeTableRow<S>>> rowFactory; private ObjectProperty<Node> placeholder; private DoubleProperty fixedCellSize; private ObjectProperty<TreeSortMode> sortMode; private ReadOnlyObjectWrapper<Comparator<TreeItem<S>>> comparator; private ObjectProperty<Callback<TreeTableView<S>, Boolean>> sortPolicy; private ObjectProperty<EventHandler<SortEvent<TreeTableView<S>>>> onSort; private ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollTo; private ObjectProperty<EventHandler<ScrollToEvent<TreeTableColumn<S, ?>>>> onScrollToColumn; private boolean sortLock; private TableUtil.SortEventType lastSortEventType; private Object[] lastSortEventSupportInfo; private static final String DEFAULT_STYLE_CLASS = "tree-table-view"; public final void setRoot(TreeItem<S> paramTreeItem) { rootProperty().set(paramTreeItem); } public final TreeItem<S> getRoot() { return (this.root == null) ? null : this.root.get(); } public final ObjectProperty<TreeItem<S>> rootProperty() { return this.root; } public final void setShowRoot(boolean paramBoolean) { showRootProperty().set(paramBoolean); } public final boolean isShowRoot() { return (this.showRoot == null) ? true : this.showRoot.get(); } public final BooleanProperty showRootProperty() { if (this.showRoot == null) this.showRoot = new SimpleBooleanProperty(this, "showRoot", true) { protected void invalidated() { TreeTableView.this.updateRootExpanded(); TreeTableView.this.updateExpandedItemCount(TreeTableView.this.getRoot()); } };  return this.showRoot; } public final ObjectProperty<TreeTableColumn<S, ?>> treeColumnProperty() { if (this.treeColumn == null) this.treeColumn = new SimpleObjectProperty<>(this, "treeColumn", null);  return this.treeColumn; } public final void setTreeColumn(TreeTableColumn<S, ?> paramTreeTableColumn) { treeColumnProperty().set(paramTreeTableColumn); } private void doSort(TableUtil.SortEventType paramSortEventType, Object... paramVarArgs) { if (this.sortLock) {
/*      */       return;
/*      */     }
/*      */     
/* 1910 */     this.lastSortEventType = paramSortEventType;
/* 1911 */     this.lastSortEventSupportInfo = paramVarArgs;
/* 1912 */     sort();
/* 1913 */     this.lastSortEventType = null;
/* 1914 */     this.lastSortEventSupportInfo = null; } public final TreeTableColumn<S, ?> getTreeColumn() { return (this.treeColumn == null) ? null : this.treeColumn.get(); } public final void setSelectionModel(TreeTableViewSelectionModel<S> paramTreeTableViewSelectionModel) { selectionModelProperty().set(paramTreeTableViewSelectionModel); } public final TreeTableViewSelectionModel<S> getSelectionModel() { return (this.selectionModel == null) ? null : this.selectionModel.get(); } public final ObjectProperty<TreeTableViewSelectionModel<S>> selectionModelProperty() { if (this.selectionModel == null) this.selectionModel = new SimpleObjectProperty<TreeTableViewSelectionModel<S>>(this, "selectionModel") { TreeTableView.TreeTableViewSelectionModel<S> oldValue = null; protected void invalidated() { if (this.oldValue != null) { this.oldValue.cellSelectionEnabledProperty().removeListener(TreeTableView.this.weakCellSelectionModelInvalidationListener); if (this.oldValue instanceof TreeTableView.TreeTableViewArrayListSelectionModel) ((TreeTableView.TreeTableViewArrayListSelectionModel)this.oldValue).dispose();  }  this.oldValue = get(); if (this.oldValue != null) { this.oldValue.cellSelectionEnabledProperty().addListener(TreeTableView.this.weakCellSelectionModelInvalidationListener); TreeTableView.this.weakCellSelectionModelInvalidationListener.invalidated(this.oldValue.cellSelectionEnabledProperty()); }  } }
/*      */         ;  return this.selectionModel; } public final void setFocusModel(TreeTableViewFocusModel<S> paramTreeTableViewFocusModel) { focusModelProperty().set(paramTreeTableViewFocusModel); } public final TreeTableViewFocusModel<S> getFocusModel() { return (this.focusModel == null) ? null : this.focusModel.get(); } public final ObjectProperty<TreeTableViewFocusModel<S>> focusModelProperty() { if (this.focusModel == null) this.focusModel = new SimpleObjectProperty<>(this, "focusModel");  return this.focusModel; } public final ReadOnlyIntegerProperty expandedItemCountProperty() { return this.expandedItemCount.getReadOnlyProperty(); } private void setExpandedItemCount(int paramInt) { this.expandedItemCount.set(paramInt); } public final int getExpandedItemCount() { if (this.expandedItemCountDirty) updateExpandedItemCount(getRoot());  return this.expandedItemCount.get(); } public final void setEditable(boolean paramBoolean) { editableProperty().set(paramBoolean); } public final boolean isEditable() { return (this.editable == null) ? false : this.editable.get(); } public final BooleanProperty editableProperty() { if (this.editable == null) this.editable = new SimpleBooleanProperty(this, "editable", false);  return this.editable; } private void setEditingCell(TreeTablePosition<S, ?> paramTreeTablePosition) { editingCellPropertyImpl().set(paramTreeTablePosition); } public final TreeTablePosition<S, ?> getEditingCell() { return (this.editingCell == null) ? null : this.editingCell.get(); } public final ReadOnlyObjectProperty<TreeTablePosition<S, ?>> editingCellProperty() { return editingCellPropertyImpl().getReadOnlyProperty(); } private ReadOnlyObjectWrapper<TreeTablePosition<S, ?>> editingCellPropertyImpl() { if (this.editingCell == null) this.editingCell = new ReadOnlyObjectWrapper<>(this, "editingCell");  return this.editingCell; } public final BooleanProperty tableMenuButtonVisibleProperty() { if (this.tableMenuButtonVisible == null) this.tableMenuButtonVisible = new SimpleBooleanProperty(this, "tableMenuButtonVisible");  return this.tableMenuButtonVisible; } public final void setTableMenuButtonVisible(boolean paramBoolean) { tableMenuButtonVisibleProperty().set(paramBoolean); } public final boolean isTableMenuButtonVisible() { return (this.tableMenuButtonVisible == null) ? false : this.tableMenuButtonVisible.get(); } public final void setColumnResizePolicy(Callback<ResizeFeatures, Boolean> paramCallback) { columnResizePolicyProperty().set(paramCallback); } public final Callback<ResizeFeatures, Boolean> getColumnResizePolicy() { return (this.columnResizePolicy == null) ? UNCONSTRAINED_RESIZE_POLICY : this.columnResizePolicy.get(); } public final ObjectProperty<Callback<ResizeFeatures, Boolean>> columnResizePolicyProperty() { if (this.columnResizePolicy == null) this.columnResizePolicy = new SimpleObjectProperty<Callback<ResizeFeatures, Boolean>>(this, "columnResizePolicy", UNCONSTRAINED_RESIZE_POLICY) { private Callback<TreeTableView.ResizeFeatures, Boolean> oldPolicy; protected void invalidated() { if (TreeTableView.this.isInited) { get().call(new TreeTableView.ResizeFeatures(TreeTableView.this, null, Double.valueOf(0.0D))); if (this.oldPolicy != null) { PseudoClass pseudoClass = PseudoClass.getPseudoClass(this.oldPolicy.toString()); TreeTableView.this.pseudoClassStateChanged(pseudoClass, false); }  if (get() != null) { PseudoClass pseudoClass = PseudoClass.getPseudoClass(get().toString()); TreeTableView.this.pseudoClassStateChanged(pseudoClass, true); }  this.oldPolicy = get(); }  } }
/*      */         ;  return this.columnResizePolicy; } public final ObjectProperty<Callback<TreeTableView<S>, TreeTableRow<S>>> rowFactoryProperty() { if (this.rowFactory == null) this.rowFactory = new SimpleObjectProperty<>(this, "rowFactory");  return this.rowFactory; } public final void setRowFactory(Callback<TreeTableView<S>, TreeTableRow<S>> paramCallback) { rowFactoryProperty().set(paramCallback); } public final Callback<TreeTableView<S>, TreeTableRow<S>> getRowFactory() { return (this.rowFactory == null) ? null : this.rowFactory.get(); } public final ObjectProperty<Node> placeholderProperty() { if (this.placeholder == null) this.placeholder = new SimpleObjectProperty<>(this, "placeholder");  return this.placeholder; } public final void setPlaceholder(Node paramNode) { placeholderProperty().set(paramNode); } public final Node getPlaceholder() { return (this.placeholder == null) ? null : this.placeholder.get(); } public final void setFixedCellSize(double paramDouble) { fixedCellSizeProperty().set(paramDouble); } public final double getFixedCellSize() { return (this.fixedCellSize == null) ? -1.0D : this.fixedCellSize.get(); } public final DoubleProperty fixedCellSizeProperty() { if (this.fixedCellSize == null) this.fixedCellSize = new StyleableDoubleProperty(-1.0D) { public CssMetaData<TreeTableView<?>, Number> getCssMetaData() { return TreeTableView.StyleableProperties.FIXED_CELL_SIZE; } public Object getBean() { return TreeTableView.this; } public String getName() { return "fixedCellSize"; } }
/*      */         ;  return this.fixedCellSize; } public final ObjectProperty<TreeSortMode> sortModeProperty() { if (this.sortMode == null) this.sortMode = new SimpleObjectProperty<>(this, "sortMode", TreeSortMode.ALL_DESCENDANTS);  return this.sortMode; } public final void setSortMode(TreeSortMode paramTreeSortMode) { sortModeProperty().set(paramTreeSortMode); } public final TreeSortMode getSortMode() { return (this.sortMode == null) ? TreeSortMode.ALL_DESCENDANTS : this.sortMode.get(); } private void setComparator(Comparator<TreeItem<S>> paramComparator) { comparatorPropertyImpl().set(paramComparator); } public final Comparator<TreeItem<S>> getComparator() { return (this.comparator == null) ? null : this.comparator.get(); } public final ReadOnlyObjectProperty<Comparator<TreeItem<S>>> comparatorProperty() { return comparatorPropertyImpl().getReadOnlyProperty(); } private ReadOnlyObjectWrapper<Comparator<TreeItem<S>>> comparatorPropertyImpl() { if (this.comparator == null) this.comparator = new ReadOnlyObjectWrapper<>(this, "comparator");  return this.comparator; } public final void setSortPolicy(Callback<TreeTableView<S>, Boolean> paramCallback) { sortPolicyProperty().set(paramCallback); } public final Callback<TreeTableView<S>, Boolean> getSortPolicy() { return (this.sortPolicy == null) ? (Callback)DEFAULT_SORT_POLICY : this.sortPolicy.get(); } public final ObjectProperty<Callback<TreeTableView<S>, Boolean>> sortPolicyProperty() { if (this.sortPolicy == null) this.sortPolicy = new SimpleObjectProperty<Callback<TreeTableView<S>, Boolean>>(this, "sortPolicy", DEFAULT_SORT_POLICY) { protected void invalidated() { TreeTableView.this.sort(); } }
/* 1918 */         ;  return this.sortPolicy; } public void setOnSort(EventHandler<SortEvent<TreeTableView<S>>> paramEventHandler) { onSortProperty().set(paramEventHandler); } public EventHandler<SortEvent<TreeTableView<S>>> getOnSort() { if (this.onSort != null) return this.onSort.get();  return null; } public ObjectProperty<EventHandler<SortEvent<TreeTableView<S>>>> onSortProperty() { if (this.onSort == null) this.onSort = new ObjectPropertyBase<EventHandler<SortEvent<TreeTableView<S>>>>() { protected void invalidated() { EventType<SortEvent<?>> eventType = SortEvent.sortEvent(); EventHandler<SortEvent<TreeTableView<S>>> eventHandler = get(); TreeTableView.this.setEventHandler((EventType)eventType, (EventHandler)eventHandler); } public Object getBean() { return TreeTableView.this; } public String getName() { return "onSort"; } };  return this.onSort; } protected void layoutChildren() { if (this.expandedItemCountDirty) updateExpandedItemCount(getRoot());  super.layoutChildren(); } public void scrollTo(int paramInt) { ControlUtils.scrollToIndex(this, paramInt); } public void setOnScrollTo(EventHandler<ScrollToEvent<Integer>> paramEventHandler) { onScrollToProperty().set(paramEventHandler); } public EventHandler<ScrollToEvent<Integer>> getOnScrollTo() { if (this.onScrollTo != null) return this.onScrollTo.get();  return null; } public ObjectProperty<EventHandler<ScrollToEvent<Integer>>> onScrollToProperty() { if (this.onScrollTo == null) this.onScrollTo = new ObjectPropertyBase<EventHandler<ScrollToEvent<Integer>>>() { protected void invalidated() { TreeTableView.this.setEventHandler((EventType)ScrollToEvent.scrollToTopIndex(), (EventHandler)get()); } public Object getBean() { return TreeTableView.this; } public String getName() { return "onScrollTo"; } };  return this.onScrollTo; } public void scrollToColumn(TreeTableColumn<S, ?> paramTreeTableColumn) { ControlUtils.scrollToColumn(this, paramTreeTableColumn); } public void scrollToColumnIndex(int paramInt) { if (getColumns() != null) ControlUtils.scrollToColumn(this, getColumns().get(paramInt));  } public void setOnScrollToColumn(EventHandler<ScrollToEvent<TreeTableColumn<S, ?>>> paramEventHandler) { onScrollToColumnProperty().set(paramEventHandler); } public EventHandler<ScrollToEvent<TreeTableColumn<S, ?>>> getOnScrollToColumn() { if (this.onScrollToColumn != null) return this.onScrollToColumn.get();  return null; } public ObjectProperty<EventHandler<ScrollToEvent<TreeTableColumn<S, ?>>>> onScrollToColumnProperty() { if (this.onScrollToColumn == null) this.onScrollToColumn = new ObjectPropertyBase<EventHandler<ScrollToEvent<TreeTableColumn<S, ?>>>>() { protected void invalidated() { EventType<ScrollToEvent<TableColumnBase<?, ?>>> eventType = ScrollToEvent.scrollToColumn(); TreeTableView.this.setEventHandler((EventType)eventType, (EventHandler)get()); } public Object getBean() { return TreeTableView.this; } public String getName() { return "onScrollToColumn"; } };  return this.onScrollToColumn; } public int getRow(TreeItem<S> paramTreeItem) { return TreeUtil.getRow(paramTreeItem, getRoot(), this.expandedItemCountDirty, isShowRoot()); } public TreeItem<S> getTreeItem(int paramInt) { if (paramInt < 0) return null;  int i = isShowRoot() ? paramInt : (paramInt + 1); if (this.expandedItemCountDirty) { updateExpandedItemCount(getRoot()); } else if (this.treeItemCacheMap.containsKey(Integer.valueOf(i))) { SoftReference<TreeItem> softReference = (SoftReference)this.treeItemCacheMap.get(Integer.valueOf(i)); TreeItem<S> treeItem1 = softReference.get(); if (treeItem1 != null) return treeItem1;  }  TreeItem<S> treeItem = TreeUtil.getItem(getRoot(), i, this.expandedItemCountDirty); this.treeItemCacheMap.put(Integer.valueOf(i), new SoftReference<>(treeItem)); return treeItem; } public int getTreeItemLevel(TreeItem<?> paramTreeItem) { TreeItem<S> treeItem = getRoot(); if (paramTreeItem == null) return -1;  if (paramTreeItem == treeItem) return 0;  byte b = 0; TreeItem<?> treeItem1 = paramTreeItem.getParent(); while (treeItem1 != null) { b++; if (treeItem1 == treeItem) break;  treeItem1 = treeItem1.getParent(); }  return b; } public final ObservableList<TreeTableColumn<S, ?>> getColumns() { return this.columns; } public final ObservableList<TreeTableColumn<S, ?>> getSortOrder() { return this.sortOrder; } public boolean resizeColumn(TreeTableColumn<S, ?> paramTreeTableColumn, double paramDouble) { if (paramTreeTableColumn == null || Double.compare(paramDouble, 0.0D) == 0) return false;  boolean bool = ((Boolean)getColumnResizePolicy().call(new ResizeFeatures<>(this, paramTreeTableColumn, Double.valueOf(paramDouble)))).booleanValue(); if (!bool) return false;  return true; } public void edit(int paramInt, TreeTableColumn<S, ?> paramTreeTableColumn) { if (!isEditable() || (paramTreeTableColumn != null && !paramTreeTableColumn.isEditable())) return;  if (paramInt < 0 && paramTreeTableColumn == null) { setEditingCell((TreeTablePosition<S, ?>)null); } else { setEditingCell(new TreeTablePosition<>(this, paramInt, paramTreeTableColumn)); }  } public ObservableList<TreeTableColumn<S, ?>> getVisibleLeafColumns() { return this.unmodifiableVisibleLeafColumns; } public int getVisibleLeafIndex(TreeTableColumn<S, ?> paramTreeTableColumn) { return getVisibleLeafColumns().indexOf(paramTreeTableColumn); } public TreeTableColumn<S, ?> getVisibleLeafColumn(int paramInt) { if (paramInt < 0 || paramInt >= this.visibleLeafColumns.size()) return null;  return this.visibleLeafColumns.get(paramInt); } public void sort() { ObservableList<TreeTableColumn<S, ?>> observableList = getSortOrder(); Comparator<TreeItem<S>> comparator = getComparator(); setComparator(observableList.isEmpty() ? null : new TableColumnComparatorBase.TreeTableColumnComparator<>((List)observableList)); SortEvent<TreeTableView> sortEvent = new SortEvent<>(this, this); fireEvent(sortEvent); if (sortEvent.isConsumed()) return;  ArrayList<TreeTablePosition> arrayList = new ArrayList(getSelectionModel().getSelectedCells()); int i = arrayList.size(); getSelectionModel().startAtomic(); Callback<TreeTableView<S>, Boolean> callback = getSortPolicy(); if (callback == null) return;  Boolean bool = callback.call(this); getSelectionModel().stopAtomic(); if (bool == null || !bool.booleanValue()) { this.sortLock = true; TableUtil.handleSortFailure((ObservableList)observableList, this.lastSortEventType, this.lastSortEventSupportInfo); setComparator(comparator); this.sortLock = false; } else if (getSelectionModel() instanceof TreeTableViewArrayListSelectionModel) { TreeTableViewArrayListSelectionModel treeTableViewArrayListSelectionModel = (TreeTableViewArrayListSelectionModel)getSelectionModel(); ObservableList<TreeTablePosition> observableList1 = treeTableViewArrayListSelectionModel.getSelectedCells(); ArrayList<TreeTablePosition> arrayList1 = new ArrayList(); for (byte b = 0; b < i; b++) { TreeTablePosition treeTablePosition = arrayList.get(b); if (!observableList1.contains(treeTablePosition)) arrayList1.add(treeTablePosition);  }  if (!arrayList1.isEmpty()) { NonIterableChange.GenericAddRemoveChange<TreeTablePosition> genericAddRemoveChange = new NonIterableChange.GenericAddRemoveChange<>(0, i, arrayList1, observableList1); treeTableViewArrayListSelectionModel.fireCustomSelectedCellsListChangeEvent((ListChangeListener.Change)genericAddRemoveChange); }  }  } public void refresh() { getProperties().put("recreateKey", Boolean.TRUE); } private void updateExpandedItemCount(TreeItem<S> paramTreeItem) { setExpandedItemCount(TreeUtil.updateExpandedItemCount(paramTreeItem, this.expandedItemCountDirty, isShowRoot()));
/*      */     
/* 1920 */     if (this.expandedItemCountDirty)
/*      */     {
/*      */       
/* 1923 */       this.treeItemCacheMap.clear();
/*      */     }
/*      */     
/* 1926 */     this.expandedItemCountDirty = false; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateRootExpanded() {
/* 1932 */     if (!isShowRoot() && getRoot() != null && !getRoot().isExpanded()) {
/* 1933 */       getRoot().setExpanded(true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void setContentWidth(double paramDouble) {
/* 1940 */     this.contentWidth = paramDouble;
/* 1941 */     if (this.isInited)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1947 */       getColumnResizePolicy().call(new ResizeFeatures(this, null, Double.valueOf(0.0D)));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateVisibleLeafColumns() {
/* 1956 */     ArrayList<TreeTableColumn<S, ?>> arrayList = new ArrayList();
/* 1957 */     buildVisibleLeafColumns(getColumns(), arrayList);
/* 1958 */     this.visibleLeafColumns.setAll(arrayList);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1965 */     getColumnResizePolicy().call(new ResizeFeatures(this, null, Double.valueOf(0.0D)));
/*      */   }
/*      */   
/*      */   private void buildVisibleLeafColumns(List<TreeTableColumn<S, ?>> paramList1, List<TreeTableColumn<S, ?>> paramList2) {
/* 1969 */     for (TreeTableColumn<S, ?> treeTableColumn : paramList1) {
/* 1970 */       if (treeTableColumn == null)
/*      */         continue; 
/* 1972 */       boolean bool = !treeTableColumn.getColumns().isEmpty() ? true : false;
/*      */       
/* 1974 */       if (bool) {
/* 1975 */         buildVisibleLeafColumns(treeTableColumn.getColumns(), paramList2); continue;
/* 1976 */       }  if (treeTableColumn.isVisible()) {
/* 1977 */         paramList2.add(treeTableColumn);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1993 */   private static final PseudoClass PSEUDO_CLASS_CELL_SELECTION = PseudoClass.getPseudoClass("cell-selection");
/*      */   
/* 1995 */   private static final PseudoClass PSEUDO_CLASS_ROW_SELECTION = PseudoClass.getPseudoClass("row-selection");
/*      */   
/*      */   private static class StyleableProperties {
/* 1998 */     private static final CssMetaData<TreeTableView<?>, Number> FIXED_CELL_SIZE = new CssMetaData<TreeTableView<?>, Number>("-fx-fixed-cell-size", 
/*      */         
/* 2000 */         SizeConverter.getInstance(), 
/* 2001 */         Double.valueOf(-1.0D))
/*      */       {
/*      */         public Double getInitialValue(TreeTableView<?> param2TreeTableView) {
/* 2004 */           return Double.valueOf(param2TreeTableView.getFixedCellSize());
/*      */         }
/*      */         
/*      */         public boolean isSettable(TreeTableView<?> param2TreeTableView) {
/* 2008 */           return (param2TreeTableView.fixedCellSize == null || !param2TreeTableView.fixedCellSize.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(TreeTableView<?> param2TreeTableView) {
/* 2012 */           return (StyleableProperty<Number>)param2TreeTableView.fixedCellSizeProperty();
/*      */         }
/*      */       };
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 2019 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Control.getClassCssMetaData());
/* 2020 */       arrayList.add(FIXED_CELL_SIZE);
/* 2021 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 2030 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 2039 */     return getClassCssMetaData();
/*      */   }
/*      */ 
/*      */   
/*      */   protected Skin<?> createDefaultSkin() {
/* 2044 */     return (Skin<?>)new TreeTableViewSkin(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*      */     ObservableList observableList;
/*      */     Node node1;
/*      */     TreeTableViewSelectionModel<S> treeTableViewSelectionModel;
/*      */     ArrayList<?> arrayList;
/*      */     Node node2;
/* 2058 */     switch (paramAccessibleAttribute) { case ROW_COUNT:
/* 2059 */         return Integer.valueOf(getExpandedItemCount());
/* 2060 */       case COLUMN_COUNT: return Integer.valueOf(getVisibleLeafColumns().size());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case SELECTED_ITEMS:
/* 2068 */         observableList = (ObservableList)super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 2069 */         arrayList = new ArrayList();
/* 2070 */         for (TreeTableRow treeTableRow : observableList) {
/*      */           
/* 2072 */           ObservableList observableList1 = (ObservableList)treeTableRow.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 2073 */           if (observableList1 != null) arrayList.addAll(observableList1); 
/*      */         } 
/* 2075 */         return FXCollections.observableArrayList(arrayList);
/*      */       
/*      */       case FOCUS_ITEM:
/* 2078 */         node1 = (Node)super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 2079 */         if (node1 == null) return null; 
/* 2080 */         node2 = (Node)node1.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */         
/* 2082 */         return (node2 != null) ? node2 : node1;
/*      */ 
/*      */       
/*      */       case CELL_AT_ROW_COLUMN:
/* 2086 */         node1 = (TreeTableRow)super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 2087 */         return (node1 != null) ? node1.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs) : null;
/*      */       
/*      */       case MULTIPLE_SELECTION:
/* 2090 */         treeTableViewSelectionModel = getSelectionModel();
/* 2091 */         return Boolean.valueOf((treeTableViewSelectionModel != null && treeTableViewSelectionModel.getSelectionMode() == SelectionMode.MULTIPLE)); }
/*      */     
/* 2093 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ResizeFeatures<S>
/*      */     extends ResizeFeaturesBase<TreeItem<S>>
/*      */   {
/*      */     private TreeTableView<S> treeTable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResizeFeatures(TreeTableView<S> param1TreeTableView, TreeTableColumn<S, ?> param1TreeTableColumn, Double param1Double) {
/* 2124 */       super(param1TreeTableColumn, param1Double);
/* 2125 */       this.treeTable = param1TreeTableView;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeTableColumn<S, ?> getColumn() {
/* 2134 */       return (TreeTableColumn<S, ?>)super.getColumn();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeTableView<S> getTable() {
/* 2141 */       return this.treeTable;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EditEvent<S>
/*      */     extends Event
/*      */   {
/*      */     private static final long serialVersionUID = -4437033058917528976L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2162 */     public static final EventType<?> ANY = TreeTableView.EDIT_ANY_EVENT;
/*      */ 
/*      */ 
/*      */     
/*      */     private final TreeTableView<S> source;
/*      */ 
/*      */ 
/*      */     
/*      */     private final S oldValue;
/*      */ 
/*      */ 
/*      */     
/*      */     private final S newValue;
/*      */ 
/*      */     
/*      */     private final transient TreeItem<S> treeItem;
/*      */ 
/*      */ 
/*      */     
/*      */     public EditEvent(TreeTableView<S> param1TreeTableView, EventType<? extends EditEvent> param1EventType, TreeItem<S> param1TreeItem, S param1S1, S param1S2) {
/* 2182 */       super(param1TreeTableView, Event.NULL_SOURCE_TARGET, (EventType)param1EventType);
/* 2183 */       this.source = param1TreeTableView;
/* 2184 */       this.oldValue = param1S1;
/* 2185 */       this.newValue = param1S2;
/* 2186 */       this.treeItem = param1TreeItem;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeTableView<S> getSource() {
/* 2194 */       return this.source;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeItem<S> getTreeItem() {
/* 2202 */       return this.treeItem;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public S getNewValue() {
/* 2210 */       return this.newValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public S getOldValue() {
/* 2220 */       return this.oldValue;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class TreeTableViewSelectionModel<S>
/*      */     extends TableSelectionModel<TreeItem<S>>
/*      */   {
/*      */     private final TreeTableView<S> treeTableView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeTableViewSelectionModel(TreeTableView<S> param1TreeTableView) {
/* 2258 */       if (param1TreeTableView == null) {
/* 2259 */         throw new NullPointerException("TreeTableView can not be null");
/*      */       }
/*      */       
/* 2262 */       this.treeTableView = param1TreeTableView;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeTableView<S> getTreeTableView() {
/* 2294 */       return this.treeTableView;
/*      */     }
/*      */ 
/*      */     
/*      */     public TreeItem<S> getModelItem(int param1Int) {
/* 2299 */       return this.treeTableView.getTreeItem(param1Int);
/*      */     }
/*      */ 
/*      */     
/*      */     protected int getItemCount() {
/* 2304 */       return this.treeTableView.getExpandedItemCount();
/*      */     }
/*      */ 
/*      */     
/*      */     public void focus(int param1Int) {
/* 2309 */       focus(param1Int, (TreeTableColumn<S, ?>)null);
/*      */     }
/*      */ 
/*      */     
/*      */     public int getFocusedIndex() {
/* 2314 */       return getFocusedCell().getRow();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void selectRange(int param1Int1, TableColumnBase<TreeItem<S>, ?> param1TableColumnBase1, int param1Int2, TableColumnBase<TreeItem<S>, ?> param1TableColumnBase2) {
/* 2320 */       int i = this.treeTableView.getVisibleLeafIndex((TreeTableColumn)param1TableColumnBase1);
/* 2321 */       int j = this.treeTableView.getVisibleLeafIndex((TreeTableColumn)param1TableColumnBase2);
/* 2322 */       for (int k = param1Int1; k <= param1Int2; k++) {
/* 2323 */         for (int m = i; m <= j; m++) {
/* 2324 */           select(k, this.treeTableView.getVisibleLeafColumn(m));
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void focus(int param1Int, TreeTableColumn<S, ?> param1TreeTableColumn) {
/* 2338 */       focus(new TreeTablePosition<>(getTreeTableView(), param1Int, param1TreeTableColumn));
/*      */     }
/*      */     
/*      */     private void focus(TreeTablePosition<S, ?> param1TreeTablePosition) {
/* 2342 */       if (getTreeTableView().getFocusModel() == null)
/*      */         return; 
/* 2344 */       getTreeTableView().getFocusModel().focus(param1TreeTablePosition.getRow(), param1TreeTablePosition.getTableColumn());
/*      */     }
/*      */     
/*      */     private TreeTablePosition<S, ?> getFocusedCell() {
/* 2348 */       if (this.treeTableView.getFocusModel() == null) {
/* 2349 */         return new TreeTablePosition<>(this.treeTableView, -1, null);
/*      */       }
/* 2351 */       return this.treeTableView.getFocusModel().getFocusedCell();
/*      */     }
/*      */ 
/*      */     
/*      */     public abstract ObservableList<TreeTablePosition<S, ?>> getSelectedCells();
/*      */   }
/*      */ 
/*      */   
/*      */   static class TreeTableViewArrayListSelectionModel<S>
/*      */     extends TreeTableViewSelectionModel<S>
/*      */   {
/*      */     private final MappingChange.Map<TreeTablePosition<S, ?>, Integer> cellToIndicesMap;
/*      */     
/*      */     private TreeTableView<S> treeTableView;
/*      */     
/*      */     private ChangeListener<TreeItem<S>> rootPropertyListener;
/*      */     private InvalidationListener showRootPropertyListener;
/*      */     private EventHandler<TreeItem.TreeModificationEvent<S>> treeItemListener;
/*      */     private WeakChangeListener<TreeItem<S>> weakRootPropertyListener;
/*      */     private WeakEventHandler<TreeItem.TreeModificationEvent<S>> weakTreeItemListener;
/*      */     private final SelectedCellsMap<TreeTablePosition<S, ?>> selectedCellsMap;
/*      */     private final ReadOnlyUnbackedObservableList<TreeTablePosition<S, ?>> selectedCellsSeq;
/*      */     
/*      */     public TreeTableViewArrayListSelectionModel(TreeTableView<S> param1TreeTableView) {
/* 2375 */       super(param1TreeTableView);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       this.cellToIndicesMap = (param1TreeTablePosition -> Integer.valueOf(param1TreeTablePosition.getRow()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       this.treeTableView = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2430 */       this.rootPropertyListener = ((param1ObservableValue, param1TreeItem1, param1TreeItem2) -> {
/*      */           updateDefaultSelection();
/*      */           
/*      */           updateTreeEventListener(param1TreeItem1, param1TreeItem2);
/*      */         });
/*      */       
/* 2436 */       this.showRootPropertyListener = (param1Observable -> shiftSelection(0, this.treeTableView.isShowRoot() ? 1 : -1, (Callback<MultipleSelectionModelBase.ShiftParams, Void>)null));
/*      */ 
/*      */ 
/*      */       
/* 2440 */       this.treeItemListener = new EventHandler<TreeItem.TreeModificationEvent<S>>()
/*      */         {
/*      */           public void handle(TreeItem.TreeModificationEvent<S> param2TreeModificationEvent) {
/* 2443 */             if (TreeTableView.TreeTableViewArrayListSelectionModel.this.getSelectedIndex() == -1 && TreeTableView.TreeTableViewArrayListSelectionModel.this.getSelectedItem() == null)
/*      */               return; 
/* 2445 */             TreeItem<S> treeItem = param2TreeModificationEvent.getTreeItem();
/* 2446 */             if (treeItem == null)
/*      */               return; 
/* 2448 */             int i = TreeTableView.TreeTableViewArrayListSelectionModel.this.getSelectedIndex();
/*      */             
/* 2450 */             TreeTableView.TreeTableViewArrayListSelectionModel.this.treeTableView.expandedItemCountDirty = true;
/*      */ 
/*      */ 
/*      */             
/* 2454 */             int j = TreeTableView.TreeTableViewArrayListSelectionModel.this.treeTableView.getRow(treeItem);
/*      */             
/* 2456 */             int k = 0;
/* 2457 */             ListChangeListener.Change<? extends TreeItem<S>> change = param2TreeModificationEvent.getChange();
/* 2458 */             if (change != null) {
/* 2459 */               change.next();
/*      */             }
/*      */             
/*      */             do {
/* 2463 */               boolean bool = (change == null) ? false : change.getAddedSize();
/* 2464 */               byte b = (change == null) ? 0 : change.getRemovedSize();
/*      */               
/* 2466 */               if (param2TreeModificationEvent.wasExpanded()) {
/*      */                 
/* 2468 */                 k += treeItem.getExpandedDescendentCount(false) - 1;
/* 2469 */                 j++;
/* 2470 */               } else if (param2TreeModificationEvent.wasCollapsed()) {
/*      */ 
/*      */ 
/*      */                 
/* 2474 */                 treeItem.getExpandedDescendentCount(false);
/* 2475 */                 int m = treeItem.previousExpandedDescendentCount;
/*      */                 
/* 2477 */                 int n = TreeTableView.TreeTableViewArrayListSelectionModel.this.getSelectedIndex();
/* 2478 */                 boolean bool1 = (n >= j + 1 && n < j + m) ? true : false;
/*      */ 
/*      */ 
/*      */                 
/* 2482 */                 boolean bool2 = false;
/* 2483 */                 boolean bool3 = TreeTableView.TreeTableViewArrayListSelectionModel.this.isCellSelectionEnabled();
/* 2484 */                 ObservableList<TreeTableColumn> observableList = TreeTableView.TreeTableViewArrayListSelectionModel.this.getTreeTableView().getVisibleLeafColumns();
/*      */                 
/* 2486 */                 TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedIndices._beginChange();
/* 2487 */                 int i1 = j + 1;
/* 2488 */                 int i2 = j + m;
/* 2489 */                 ArrayList<Integer> arrayList = new ArrayList();
/* 2490 */                 TreeTableColumn treeTableColumn = null;
/* 2491 */                 for (int i3 = i1; i3 < i2; i3++) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 2498 */                   if (bool3) {
/* 2499 */                     for (byte b1 = 0; b1 < observableList.size(); b1++) {
/* 2500 */                       TreeTableColumn treeTableColumn1 = observableList.get(b1);
/* 2501 */                       if (TreeTableView.TreeTableViewArrayListSelectionModel.this.isSelected(i3, treeTableColumn1)) {
/* 2502 */                         bool2 = true;
/* 2503 */                         TreeTableView.TreeTableViewArrayListSelectionModel.this.clearSelection(i3, treeTableColumn1);
/* 2504 */                         treeTableColumn = treeTableColumn1;
/*      */                       }
/*      */                     
/*      */                     } 
/* 2508 */                   } else if (TreeTableView.TreeTableViewArrayListSelectionModel.this.isSelected(i3)) {
/* 2509 */                     bool2 = true;
/* 2510 */                     arrayList.add(Integer.valueOf(i3));
/*      */                   } 
/*      */                 } 
/*      */ 
/*      */                 
/* 2515 */                 ControlUtils.reducingChange(TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedIndices, arrayList);
/*      */                 
/* 2517 */                 for (Iterator<Integer> iterator = arrayList.iterator(); iterator.hasNext(); ) { int i4 = ((Integer)iterator.next()).intValue();
/* 2518 */                   TreeTableView.TreeTableViewArrayListSelectionModel.this.startAtomic();
/*      */ 
/*      */                   
/* 2521 */                   TreeTableView.TreeTableViewArrayListSelectionModel.this.clearSelection((TreeTablePosition)new TreeTablePosition<>(TreeTableView.TreeTableViewArrayListSelectionModel.this.treeTableView, i4, null, false));
/* 2522 */                   TreeTableView.TreeTableViewArrayListSelectionModel.this.stopAtomic(); }
/*      */                 
/* 2524 */                 TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedIndices._endChange();
/*      */ 
/*      */                 
/* 2527 */                 if (bool1 && bool2) {
/* 2528 */                   TreeTableView.TreeTableViewArrayListSelectionModel.this.select(j, treeTableColumn);
/*      */                 }
/*      */                 
/* 2531 */                 k += -m + 1;
/* 2532 */                 j++;
/* 2533 */               } else if (param2TreeModificationEvent.wasPermutated()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 2544 */                 TreeTableView.TreeTableViewArrayListSelectionModel.this.startAtomic();
/*      */                 
/* 2546 */                 int m = j + 1;
/*      */ 
/*      */                 
/* 2549 */                 int n = param2TreeModificationEvent.getTo() - param2TreeModificationEvent.getFrom();
/* 2550 */                 HashMap<Object, Object> hashMap = new HashMap<>(n);
/* 2551 */                 for (int i1 = param2TreeModificationEvent.getFrom(); i1 < param2TreeModificationEvent.getTo(); i1++) {
/* 2552 */                   hashMap.put(Integer.valueOf(i1), Integer.valueOf(param2TreeModificationEvent.getChange().getPermutation(i1)));
/*      */                 }
/*      */ 
/*      */                 
/* 2556 */                 ArrayList<TreeTablePosition> arrayList = new ArrayList(TreeTableView.TreeTableViewArrayListSelectionModel.this.getSelectedCells());
/*      */ 
/*      */                 
/* 2559 */                 ArrayList arrayList1 = new ArrayList(arrayList.size());
/*      */ 
/*      */                 
/* 2562 */                 boolean bool1 = false; int i2;
/* 2563 */                 for (i2 = 0; i2 < arrayList.size(); i2++) {
/* 2564 */                   TreeTablePosition<?, ?> treeTablePosition = arrayList.get(i2);
/* 2565 */                   int i3 = treeTablePosition.getRow() - m;
/*      */                   
/* 2567 */                   if (hashMap.containsKey(Integer.valueOf(i3))) {
/* 2568 */                     int i4 = ((Integer)hashMap.get(Integer.valueOf(i3))).intValue() + m;
/*      */                     
/* 2570 */                     bool1 = (bool1 || i4 != i3) ? true : false;
/*      */                     
/* 2572 */                     arrayList1.add(new TreeTablePosition<>(treeTablePosition.getTreeTableView(), i4, treeTablePosition.getTableColumn()));
/*      */                   } 
/*      */ 
/*      */                   
/* 2576 */                   if (treeTablePosition.getRow() == j) {
/* 2577 */                     arrayList1.add(new TreeTablePosition<>(treeTablePosition.getTreeTableView(), treeTablePosition.getRow(), treeTablePosition.getTableColumn()));
/*      */                   }
/*      */                 } 
/*      */                 
/* 2581 */                 if (bool1) {
/*      */                   
/* 2583 */                   TreeTableView.TreeTableViewArrayListSelectionModel.this.quietClearSelection();
/* 2584 */                   TreeTableView.TreeTableViewArrayListSelectionModel.this.stopAtomic();
/*      */                   
/* 2586 */                   TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedCellsMap.setAll(arrayList1);
/*      */                   
/* 2588 */                   i2 = i - m;
/* 2589 */                   if (i2 >= 0 && i2 < TreeTableView.TreeTableViewArrayListSelectionModel.this.getItemCount()) {
/* 2590 */                     int i3 = param2TreeModificationEvent.getChange().getPermutation(i2);
/* 2591 */                     TreeTableView.TreeTableViewArrayListSelectionModel.this.setSelectedIndex(i3 + m);
/* 2592 */                     TreeTableView.TreeTableViewArrayListSelectionModel.this.focus(i3 + m);
/*      */                   } 
/*      */                 } else {
/* 2595 */                   TreeTableView.TreeTableViewArrayListSelectionModel.this.stopAtomic();
/*      */                 } 
/* 2597 */               } else if (param2TreeModificationEvent.wasAdded()) {
/*      */                 
/* 2599 */                 k += treeItem.isExpanded() ? bool : 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 2607 */                 j = TreeTableView.TreeTableViewArrayListSelectionModel.this.treeTableView.getRow(param2TreeModificationEvent.getChange().getAddedSubList().get(0));
/*      */                 
/* 2609 */                 TreeTablePosition<?, ?> treeTablePosition = (TreeTablePosition)TreeTableCellBehavior.getAnchor(TreeTableView.TreeTableViewArrayListSelectionModel.this.treeTableView, null);
/* 2610 */                 if (treeTablePosition != null) {
/* 2611 */                   boolean bool1 = TreeTableView.TreeTableViewArrayListSelectionModel.this.isSelected(treeTablePosition.getRow(), treeTablePosition.getTableColumn());
/* 2612 */                   if (bool1) {
/* 2613 */                     TreeTablePosition<Object, Object> treeTablePosition1 = new TreeTablePosition<>(TreeTableView.TreeTableViewArrayListSelectionModel.this.treeTableView, treeTablePosition.getRow() + k, treeTablePosition.getTableColumn());
/* 2614 */                     TreeTableCellBehavior.setAnchor(TreeTableView.TreeTableViewArrayListSelectionModel.this.treeTableView, (TreeTableCell)treeTablePosition1, false);
/*      */                   } 
/*      */                 } 
/* 2617 */               } else if (param2TreeModificationEvent.wasRemoved()) {
/*      */                 
/* 2619 */                 k += treeItem.isExpanded() ? -b : 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 2626 */                 j += param2TreeModificationEvent.getFrom() + 1;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 2631 */                 ObservableList<Integer> observableList = TreeTableView.TreeTableViewArrayListSelectionModel.this.getSelectedIndices();
/* 2632 */                 ObservableList observableList1 = TreeTableView.TreeTableViewArrayListSelectionModel.this.getSelectedItems();
/* 2633 */                 TreeItem treeItem1 = TreeTableView.TreeTableViewArrayListSelectionModel.this.getSelectedItem();
/* 2634 */                 List list = param2TreeModificationEvent.getChange().getRemoved();
/*      */                 
/* 2636 */                 for (byte b1 = 0; b1 < observableList.size() && !observableList1.isEmpty(); b1++) {
/* 2637 */                   int m = ((Integer)observableList.get(b1)).intValue();
/* 2638 */                   if (m > observableList1.size())
/*      */                     break; 
/* 2640 */                   if (list.size() == 1 && observableList1
/* 2641 */                     .size() == 1 && treeItem1 != null && treeItem1
/*      */                     
/* 2643 */                     .equals(list.get(0)))
/*      */                   {
/* 2645 */                     if (i < TreeTableView.TreeTableViewArrayListSelectionModel.this.getItemCount()) {
/* 2646 */                       boolean bool1 = (i == 0) ? false : (i - 1);
/* 2647 */                       TreeItem treeItem2 = TreeTableView.TreeTableViewArrayListSelectionModel.this.getModelItem(bool1);
/* 2648 */                       if (!treeItem1.equals(treeItem2)) {
/* 2649 */                         TreeTableView.TreeTableViewArrayListSelectionModel.this.clearAndSelect(bool1);
/*      */                       }
/*      */                     } 
/*      */                   }
/*      */                 } 
/*      */               } 
/* 2655 */             } while (param2TreeModificationEvent.getChange() != null && param2TreeModificationEvent.getChange().next());
/*      */             
/* 2657 */             TreeTableView.TreeTableViewArrayListSelectionModel.this.shiftSelection(j, k, new Callback<MultipleSelectionModelBase.ShiftParams, Void>()
/*      */                 {
/*      */ 
/*      */ 
/*      */                   
/*      */                   public Void call(MultipleSelectionModelBase.ShiftParams param3ShiftParams)
/*      */                   {
/* 2664 */                     TreeTableView.TreeTableViewArrayListSelectionModel.this.startAtomic();
/*      */                     
/* 2666 */                     int i = param3ShiftParams.getClearIndex();
/* 2667 */                     int j = param3ShiftParams.getSetIndex();
/* 2668 */                     TreeTablePosition<?, ?> treeTablePosition = null;
/* 2669 */                     if (i > -1) {
/* 2670 */                       for (byte b = 0; b < TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedCellsMap.size(); b++) {
/* 2671 */                         TreeTablePosition<?, ?> treeTablePosition1 = TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedCellsMap.get(b);
/* 2672 */                         if (treeTablePosition1.getRow() == i) {
/* 2673 */                           treeTablePosition = treeTablePosition1;
/* 2674 */                           TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedCellsMap.remove(treeTablePosition1);
/* 2675 */                         } else if (treeTablePosition1.getRow() == j && !param3ShiftParams.isSelected()) {
/* 2676 */                           TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedCellsMap.remove(treeTablePosition1);
/*      */                         } 
/*      */                       } 
/*      */                     }
/*      */                     
/* 2681 */                     if (treeTablePosition != null && param3ShiftParams.isSelected()) {
/*      */                       
/* 2683 */                       TreeTablePosition<Object, Object> treeTablePosition1 = new TreeTablePosition<>(TreeTableView.TreeTableViewArrayListSelectionModel.this.treeTableView, param3ShiftParams.getSetIndex(), treeTablePosition.getTableColumn());
/*      */                       
/* 2685 */                       TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedCellsMap.add(treeTablePosition1);
/*      */                     } 
/*      */                     
/* 2688 */                     TreeTableView.TreeTableViewArrayListSelectionModel.this.stopAtomic();
/*      */                     
/* 2690 */                     return null;
/*      */                   }
/*      */                 });
/*      */           }
/*      */         };
/*      */       
/* 2696 */       this.weakRootPropertyListener = new WeakChangeListener<>(this.rootPropertyListener); this.treeTableView = param1TreeTableView; this.treeTableView.rootProperty().addListener(this.weakRootPropertyListener); this.treeTableView.showRootProperty().addListener(this.showRootPropertyListener); updateTreeEventListener((TreeItem<S>)null, param1TreeTableView.getRoot()); this.selectedCellsMap = new SelectedCellsMap<TreeTablePosition<S, ?>>(this::fireCustomSelectedCellsListChangeEvent) { public boolean isCellSelectionEnabled() { return TreeTableView.TreeTableViewArrayListSelectionModel.this.isCellSelectionEnabled(); } }
/*      */         ; this.selectedCellsSeq = new ReadOnlyUnbackedObservableList<TreeTablePosition<S, ?>>() { public TreeTablePosition<S, ?> get(int param2Int) { return TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedCellsMap.get(param2Int); } public int size() { return TreeTableView.TreeTableViewArrayListSelectionModel.this.selectedCellsMap.size(); } }
/*      */         ;
/*      */       updateDefaultSelection();
/*      */       cellSelectionEnabledProperty().addListener(param1Observable -> {
/*      */             updateDefaultSelection();
/*      */             TableCellBehaviorBase.setAnchor(param1TreeTableView, (C)getFocusedCell(), true);
/*      */           });
/*      */     } private void dispose() { this.treeTableView.rootProperty().removeListener(this.weakRootPropertyListener);
/*      */       this.treeTableView.showRootProperty().removeListener(this.showRootPropertyListener);
/*      */       TreeItem<S> treeItem = this.treeTableView.getRoot();
/*      */       if (treeItem != null)
/*      */         treeItem.removeEventHandler(TreeItem.expandedItemCountChangeEvent(), this.weakTreeItemListener);  }
/*      */     private void updateTreeEventListener(TreeItem<S> param1TreeItem1, TreeItem<S> param1TreeItem2) { if (param1TreeItem1 != null && this.weakTreeItemListener != null)
/*      */         param1TreeItem1.removeEventHandler(TreeItem.expandedItemCountChangeEvent(), this.weakTreeItemListener); 
/*      */       if (param1TreeItem2 != null) {
/*      */         this.weakTreeItemListener = new WeakEventHandler<>(this.treeItemListener);
/*      */         param1TreeItem2.addEventHandler(TreeItem.expandedItemCountChangeEvent(), this.weakTreeItemListener);
/*      */       }  }
/* 2715 */     public ObservableList<TreeTablePosition<S, ?>> getSelectedCells() { return this.selectedCellsSeq; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void clearAndSelect(int param1Int) {
/* 2734 */       clearAndSelect(param1Int, (TableColumnBase<TreeItem<S>, ?>)null);
/*      */     }
/*      */     public void clearAndSelect(int param1Int, TableColumnBase<TreeItem<S>, ?> param1TableColumnBase) {
/*      */       ListChangeListener.Change<TreeTablePosition<S, ?>> change;
/* 2738 */       if (param1Int < 0 || param1Int >= getItemCount())
/*      */         return; 
/* 2740 */       TreeTablePosition<S, Object> treeTablePosition = new TreeTablePosition<>(getTreeTableView(), param1Int, (TreeTableColumn)param1TableColumnBase);
/* 2741 */       boolean bool1 = isCellSelectionEnabled();
/*      */ 
/*      */       
/* 2744 */       TreeTableCellBehavior.setAnchor(this.treeTableView, (TreeTableCell)treeTablePosition, false);
/*      */ 
/*      */ 
/*      */       
/* 2748 */       ArrayList<TreeTablePosition<S, ?>> arrayList = new ArrayList(this.selectedCellsMap.getSelectedCells());
/*      */ 
/*      */ 
/*      */       
/* 2752 */       boolean bool2 = isSelected(param1Int, param1TableColumnBase);
/* 2753 */       if (bool2 && arrayList.size() == 1) {
/*      */ 
/*      */         
/* 2756 */         TreeTablePosition<S, ?> treeTablePosition1 = getSelectedCells().get(0);
/* 2757 */         if (getSelectedItem() == getModelItem(param1Int) && 
/* 2758 */           treeTablePosition1.getRow() == param1Int && treeTablePosition1.getTableColumn() == param1TableColumnBase) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2768 */       startAtomic();
/*      */ 
/*      */       
/* 2771 */       clearSelection();
/*      */ 
/*      */       
/* 2774 */       select(param1Int, param1TableColumnBase);
/*      */       
/* 2776 */       stopAtomic();
/*      */ 
/*      */       
/* 2779 */       if (bool1) {
/* 2780 */         arrayList.remove(treeTablePosition);
/*      */       } else {
/* 2782 */         for (TreeTablePosition treeTablePosition1 : arrayList) {
/* 2783 */           if (treeTablePosition1.getRow() == param1Int) {
/* 2784 */             arrayList.remove(treeTablePosition1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2801 */       if (bool2) {
/* 2802 */         change = ControlUtils.buildClearAndSelectChange(this.selectedCellsSeq, arrayList, param1Int);
/*      */       } else {
/* 2804 */         byte b1 = bool1 ? 0 : Math.max(0, this.selectedCellsSeq.indexOf(treeTablePosition));
/* 2805 */         byte b2 = bool1 ? getSelectedCells().size() : 1;
/* 2806 */         change = new NonIterableChange.GenericAddRemoveChange<>(b1, b1 + b2, arrayList, this.selectedCellsSeq);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2814 */       fireCustomSelectedCellsListChangeEvent(change);
/*      */     }
/*      */     
/*      */     public void select(int param1Int) {
/* 2818 */       select(param1Int, (TableColumnBase<TreeItem<S>, ?>)null);
/*      */     }
/*      */ 
/*      */     
/*      */     public void select(int param1Int, TableColumnBase<TreeItem<S>, ?> param1TableColumnBase) {
/* 2823 */       if (param1Int < 0 || param1Int >= getRowCount()) {
/*      */         return;
/*      */       }
/*      */       
/* 2827 */       if (isCellSelectionEnabled() && param1TableColumnBase == null) {
/* 2828 */         ObservableList<TreeTableColumn<S, ?>> observableList = getTreeTableView().getVisibleLeafColumns();
/* 2829 */         for (byte b = 0; b < observableList.size(); b++) {
/* 2830 */           select(param1Int, observableList.get(b));
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/* 2835 */       if (TableCellBehavior.hasDefaultAnchor(this.treeTableView)) {
/* 2836 */         TableCellBehavior.removeAnchor(this.treeTableView);
/*      */       }
/*      */       
/* 2839 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 2840 */         quietClearSelection();
/*      */       }
/* 2842 */       this.selectedCellsMap.add(new TreeTablePosition<>(getTreeTableView(), param1Int, (TreeTableColumn)param1TableColumnBase));
/*      */       
/* 2844 */       updateSelectedIndex(param1Int);
/* 2845 */       focus(param1Int, (TreeTableColumn)param1TableColumnBase);
/*      */     }
/*      */     
/*      */     public void select(TreeItem<S> param1TreeItem) {
/* 2849 */       if (param1TreeItem == null && getSelectionMode() == SelectionMode.SINGLE) {
/* 2850 */         clearSelection();
/*      */         
/*      */         return;
/*      */       } 
/* 2854 */       int i = this.treeTableView.getRow(param1TreeItem);
/* 2855 */       if (i > -1) {
/* 2856 */         if (isSelected(i)) {
/*      */           return;
/*      */         }
/*      */         
/* 2860 */         if (getSelectionMode() == SelectionMode.SINGLE) {
/* 2861 */           quietClearSelection();
/*      */         }
/*      */         
/* 2864 */         select(i);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 2871 */         setSelectedIndex(-1);
/* 2872 */         setSelectedItem(param1TreeItem);
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectIndices(int param1Int, int... param1VarArgs) {
/* 2877 */       if (param1VarArgs == null) {
/* 2878 */         select(param1Int);
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/* 2886 */       int i = getRowCount();
/*      */       
/* 2888 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 2889 */         quietClearSelection();
/*      */         
/* 2891 */         for (int j = param1VarArgs.length - 1; j >= 0; j--) {
/* 2892 */           int k = param1VarArgs[j];
/* 2893 */           if (k >= 0 && k < i) {
/* 2894 */             select(k);
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/* 2899 */         if (this.selectedCellsMap.isEmpty() && 
/* 2900 */           param1Int > 0 && param1Int < i) {
/* 2901 */           select(param1Int);
/*      */         }
/*      */       } else {
/*      */         
/* 2905 */         int j = -1;
/* 2906 */         LinkedHashSet<TreeTablePosition<S, ?>> linkedHashSet = new LinkedHashSet();
/*      */ 
/*      */         
/* 2909 */         if (param1Int >= 0 && param1Int < i) {
/*      */ 
/*      */           
/* 2912 */           if (isCellSelectionEnabled()) {
/* 2913 */             ObservableList<TreeTableColumn<S, ?>> observableList = getTreeTableView().getVisibleLeafColumns();
/* 2914 */             for (byte b1 = 0; b1 < observableList.size(); b1++) {
/* 2915 */               if (!this.selectedCellsMap.isSelected(param1Int, b1)) {
/* 2916 */                 linkedHashSet.add(new TreeTablePosition<>(getTreeTableView(), param1Int, observableList.get(b1)));
/*      */               }
/*      */             } 
/*      */           } else {
/* 2920 */             boolean bool = this.selectedCellsMap.isSelected(param1Int, -1);
/* 2921 */             if (!bool) {
/* 2922 */               linkedHashSet.add(new TreeTablePosition<>(getTreeTableView(), param1Int, null));
/*      */             }
/*      */           } 
/*      */           
/* 2926 */           j = param1Int;
/*      */         } 
/*      */ 
/*      */         
/* 2930 */         for (byte b = 0; b < param1VarArgs.length; b++) {
/* 2931 */           int k = param1VarArgs[b];
/* 2932 */           if (k >= 0 && k < i) {
/* 2933 */             j = k;
/*      */             
/* 2935 */             if (isCellSelectionEnabled()) {
/* 2936 */               ObservableList<TreeTableColumn<S, ?>> observableList = getTreeTableView().getVisibleLeafColumns();
/* 2937 */               for (byte b1 = 0; b1 < observableList.size(); b1++) {
/* 2938 */                 if (!this.selectedCellsMap.isSelected(k, b1)) {
/* 2939 */                   linkedHashSet.add(new TreeTablePosition<>(getTreeTableView(), k, observableList.get(b1)));
/* 2940 */                   j = k;
/*      */                 }
/*      */               
/*      */               } 
/* 2944 */             } else if (!this.selectedCellsMap.isSelected(k, -1)) {
/*      */               
/* 2946 */               linkedHashSet.add(new TreeTablePosition<>(getTreeTableView(), k, null));
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 2951 */         this.selectedCellsMap.addAll(linkedHashSet);
/*      */         
/* 2953 */         if (j != -1) {
/* 2954 */           select(j);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectAll() {
/* 2960 */       if (getSelectionMode() == SelectionMode.SINGLE)
/*      */         return; 
/* 2962 */       if (isCellSelectionEnabled()) {
/* 2963 */         ArrayList<TreeTablePosition<S, Object>> arrayList = new ArrayList();
/*      */         
/* 2965 */         TreeTablePosition<S, Object> treeTablePosition = null;
/* 2966 */         for (byte b = 0; b < getTreeTableView().getVisibleLeafColumns().size(); b++) {
/* 2967 */           TreeTableColumn<S, ?> treeTableColumn = getTreeTableView().getVisibleLeafColumns().get(b);
/* 2968 */           for (byte b1 = 0; b1 < getRowCount(); b1++) {
/* 2969 */             treeTablePosition = new TreeTablePosition<>(getTreeTableView(), b1, treeTableColumn);
/* 2970 */             arrayList.add(treeTablePosition);
/*      */           } 
/*      */         } 
/* 2973 */         this.selectedCellsMap.setAll(arrayList);
/*      */         
/* 2975 */         if (treeTablePosition != null) {
/* 2976 */           select(treeTablePosition.getRow(), treeTablePosition.getTableColumn());
/* 2977 */           focus(treeTablePosition.getRow(), treeTablePosition.getTableColumn());
/*      */         } 
/*      */       } else {
/* 2980 */         ArrayList<TreeTablePosition<S, ?>> arrayList = new ArrayList(); int i;
/* 2981 */         for (i = 0; i < getRowCount(); i++) {
/* 2982 */           arrayList.add(new TreeTablePosition<>(getTreeTableView(), i, null));
/*      */         }
/* 2984 */         this.selectedCellsMap.setAll(arrayList);
/*      */         
/* 2986 */         i = getFocusedIndex();
/* 2987 */         if (i == -1) {
/* 2988 */           int j = getItemCount();
/* 2989 */           if (j > 0) {
/* 2990 */             select(j - 1);
/* 2991 */             focus(arrayList.get(arrayList.size() - 1));
/*      */           } 
/*      */         } else {
/* 2994 */           select(i);
/* 2995 */           focus(i);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void selectRange(int param1Int1, TableColumnBase<TreeItem<S>, ?> param1TableColumnBase1, int param1Int2, TableColumnBase<TreeItem<S>, ?> param1TableColumnBase2) {
/* 3002 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 3003 */         quietClearSelection();
/* 3004 */         select(param1Int2, param1TableColumnBase2);
/*      */         
/*      */         return;
/*      */       } 
/* 3008 */       startAtomic();
/*      */       
/* 3010 */       int i = getItemCount();
/* 3011 */       boolean bool = isCellSelectionEnabled();
/*      */       
/* 3013 */       int j = this.treeTableView.getVisibleLeafIndex((TreeTableColumn)param1TableColumnBase1);
/* 3014 */       int k = this.treeTableView.getVisibleLeafIndex((TreeTableColumn)param1TableColumnBase2);
/* 3015 */       int m = Math.min(j, k);
/* 3016 */       int n = Math.max(j, k);
/*      */       
/* 3018 */       int i1 = Math.min(param1Int1, param1Int2);
/* 3019 */       int i2 = Math.max(param1Int1, param1Int2);
/*      */       
/* 3021 */       ArrayList<TreeTablePosition<S, ?>> arrayList = new ArrayList();
/*      */       
/* 3023 */       for (int i3 = i1; i3 <= i2; i3++) {
/*      */ 
/*      */         
/* 3026 */         if (i3 >= 0 && i3 < i)
/*      */         {
/* 3028 */           if (!bool) {
/* 3029 */             arrayList.add(new TreeTablePosition<>(this.treeTableView, i3, (TreeTableColumn)param1TableColumnBase1));
/*      */           } else {
/* 3031 */             for (int i6 = m; i6 <= n; i6++) {
/* 3032 */               TreeTableColumn<S, ?> treeTableColumn = this.treeTableView.getVisibleLeafColumn(i6);
/*      */ 
/*      */ 
/*      */               
/* 3036 */               if (treeTableColumn != null || !bool)
/*      */               {
/* 3038 */                 arrayList.add(new TreeTablePosition<>(this.treeTableView, i3, treeTableColumn));
/*      */               }
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 3046 */       arrayList.removeAll(getSelectedCells());
/*      */       
/* 3048 */       this.selectedCellsMap.addAll(arrayList);
/* 3049 */       stopAtomic();
/*      */ 
/*      */ 
/*      */       
/* 3053 */       updateSelectedIndex(param1Int2);
/* 3054 */       focus(param1Int2, (TreeTableColumn)param1TableColumnBase2);
/*      */       
/* 3056 */       TreeTableColumn<S, ?> treeTableColumn1 = (TreeTableColumn)param1TableColumnBase1;
/* 3057 */       TreeTableColumn<S, ?> treeTableColumn2 = bool ? (TreeTableColumn)param1TableColumnBase2 : treeTableColumn1;
/* 3058 */       int i4 = this.selectedCellsMap.indexOf(new TreeTablePosition<>(this.treeTableView, param1Int1, treeTableColumn1));
/* 3059 */       int i5 = this.selectedCellsMap.indexOf(new TreeTablePosition<>(this.treeTableView, param1Int2, treeTableColumn2));
/*      */       
/* 3061 */       if (i4 > -1 && i5 > -1) {
/* 3062 */         int i6 = Math.min(i4, i5);
/* 3063 */         int i7 = Math.max(i4, i5);
/*      */         
/* 3065 */         NonIterableChange.SimpleAddChange<TreeTablePosition<S, ?>> simpleAddChange = new NonIterableChange.SimpleAddChange<>(i6, i7 + 1, this.selectedCellsSeq);
/* 3066 */         fireCustomSelectedCellsListChangeEvent(simpleAddChange);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void clearSelection(int param1Int) {
/* 3072 */       clearSelection(param1Int, (TableColumnBase<TreeItem<S>, ?>)null);
/*      */     }
/*      */ 
/*      */     
/*      */     public void clearSelection(int param1Int, TableColumnBase<TreeItem<S>, ?> param1TableColumnBase) {
/* 3077 */       clearSelection(new TreeTablePosition<>(getTreeTableView(), param1Int, (TreeTableColumn)param1TableColumnBase));
/*      */     }
/*      */     
/*      */     private void clearSelection(TreeTablePosition<S, ?> param1TreeTablePosition) {
/* 3081 */       boolean bool = isCellSelectionEnabled();
/* 3082 */       int i = param1TreeTablePosition.getRow();
/* 3083 */       boolean bool1 = (param1TreeTablePosition.getTableColumn() == null) ? true : false;
/*      */       
/* 3085 */       ArrayList<TreeTablePosition> arrayList = new ArrayList();
/* 3086 */       for (TreeTablePosition<S, ?> treeTablePosition : getSelectedCells()) {
/* 3087 */         if (!bool) {
/* 3088 */           if (treeTablePosition.getRow() == i) {
/* 3089 */             arrayList.add(treeTablePosition); break;
/*      */           } 
/*      */           continue;
/*      */         } 
/* 3093 */         if (bool1 && treeTablePosition.getRow() == i) {
/*      */ 
/*      */           
/* 3096 */           arrayList.add(treeTablePosition); continue;
/* 3097 */         }  if (treeTablePosition.equals(param1TreeTablePosition)) {
/* 3098 */           arrayList.add(param1TreeTablePosition);
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/* 3103 */       Objects.requireNonNull(this.selectedCellsMap); arrayList.stream().forEach(this.selectedCellsMap::remove);
/*      */       
/* 3105 */       if (isEmpty() && !isAtomic()) {
/* 3106 */         updateSelectedIndex(-1);
/* 3107 */         this.selectedCellsMap.clear();
/*      */       } 
/*      */     }
/*      */     
/*      */     public void clearSelection() {
/* 3112 */       final ArrayList<TreeTablePosition<S, ?>> removed = new ArrayList<>(getSelectedCells());
/*      */       
/* 3114 */       quietClearSelection();
/*      */       
/* 3116 */       if (!isAtomic()) {
/* 3117 */         updateSelectedIndex(-1);
/* 3118 */         focus(-1);
/*      */         
/* 3120 */         if (!arrayList.isEmpty()) {
/*      */           
/* 3122 */           NonIterableChange<TreeTablePosition<S, ?>> nonIterableChange = new NonIterableChange<TreeTablePosition<S, ?>>(0, 0, this.selectedCellsSeq) {
/*      */               public List<TreeTablePosition<S, ?>> getRemoved() {
/* 3124 */                 return removed;
/*      */               }
/*      */             };
/* 3127 */           fireCustomSelectedCellsListChangeEvent(nonIterableChange);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void quietClearSelection() {
/* 3133 */       startAtomic();
/* 3134 */       this.selectedCellsMap.clear();
/* 3135 */       stopAtomic();
/*      */     }
/*      */     
/*      */     public boolean isSelected(int param1Int) {
/* 3139 */       return isSelected(param1Int, (TableColumnBase<TreeItem<S>, ?>)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSelected(int param1Int, TableColumnBase<TreeItem<S>, ?> param1TableColumnBase) {
/* 3146 */       boolean bool = isCellSelectionEnabled();
/* 3147 */       if (bool && param1TableColumnBase == null) {
/* 3148 */         int i = this.treeTableView.getVisibleLeafColumns().size();
/* 3149 */         for (byte b = 0; b < i; b++) {
/* 3150 */           if (!this.selectedCellsMap.isSelected(param1Int, b)) {
/* 3151 */             return false;
/*      */           }
/*      */         } 
/* 3154 */         return true;
/*      */       } 
/* 3156 */       boolean bool1 = (!bool || param1TableColumnBase == null) ? true : this.treeTableView.getVisibleLeafIndex((TreeTableColumn)param1TableColumnBase);
/* 3157 */       return this.selectedCellsMap.isSelected(param1Int, bool1);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 3162 */       return this.selectedCellsMap.isEmpty();
/*      */     }
/*      */     
/*      */     public void selectPrevious() {
/* 3166 */       if (isCellSelectionEnabled()) {
/*      */ 
/*      */         
/* 3169 */         TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/* 3170 */         if (treeTablePosition.getColumn() - 1 >= 0) {
/*      */           
/* 3172 */           select(treeTablePosition.getRow(), getTableColumn(treeTablePosition.getTableColumn(), -1));
/* 3173 */         } else if (treeTablePosition.getRow() < getRowCount() - 1) {
/*      */           
/* 3175 */           select(treeTablePosition.getRow() - 1, getTableColumn(getTreeTableView().getVisibleLeafColumns().size() - 1));
/*      */         } 
/*      */       } else {
/* 3178 */         int i = getFocusedIndex();
/* 3179 */         if (i == -1) {
/* 3180 */           select(getRowCount() - 1);
/* 3181 */         } else if (i > 0) {
/* 3182 */           select(i - 1);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectNext() {
/* 3188 */       if (isCellSelectionEnabled()) {
/*      */ 
/*      */         
/* 3191 */         TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/* 3192 */         if (treeTablePosition.getColumn() + 1 < getTreeTableView().getVisibleLeafColumns().size()) {
/*      */           
/* 3194 */           select(treeTablePosition.getRow(), getTableColumn(treeTablePosition.getTableColumn(), 1));
/* 3195 */         } else if (treeTablePosition.getRow() < getRowCount() - 1) {
/*      */           
/* 3197 */           select(treeTablePosition.getRow() + 1, getTableColumn(0));
/*      */         } 
/*      */       } else {
/* 3200 */         int i = getFocusedIndex();
/* 3201 */         if (i == -1) {
/* 3202 */           select(0);
/* 3203 */         } else if (i < getRowCount() - 1) {
/* 3204 */           select(i + 1);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectAboveCell() {
/* 3210 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/* 3211 */       if (treeTablePosition.getRow() == -1) {
/* 3212 */         select(getRowCount() - 1);
/* 3213 */       } else if (treeTablePosition.getRow() > 0) {
/* 3214 */         select(treeTablePosition.getRow() - 1, treeTablePosition.getTableColumn());
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectBelowCell() {
/* 3219 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/*      */       
/* 3221 */       if (treeTablePosition.getRow() == -1) {
/* 3222 */         select(0);
/* 3223 */       } else if (treeTablePosition.getRow() < getRowCount() - 1) {
/* 3224 */         select(treeTablePosition.getRow() + 1, treeTablePosition.getTableColumn());
/*      */       } 
/*      */     }
/*      */     
/*      */     public void selectFirst() {
/* 3229 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/*      */       
/* 3231 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 3232 */         quietClearSelection();
/*      */       }
/*      */       
/* 3235 */       if (getRowCount() > 0) {
/* 3236 */         if (isCellSelectionEnabled()) {
/* 3237 */           select(0, treeTablePosition.getTableColumn());
/*      */         } else {
/* 3239 */           select(0);
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     public void selectLast() {
/* 3245 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/*      */       
/* 3247 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 3248 */         quietClearSelection();
/*      */       }
/*      */       
/* 3251 */       int i = getRowCount();
/* 3252 */       if (i > 0 && getSelectedIndex() < i - 1) {
/* 3253 */         if (isCellSelectionEnabled()) {
/* 3254 */           select(i - 1, treeTablePosition.getTableColumn());
/*      */         } else {
/* 3256 */           select(i - 1);
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     public void selectLeftCell() {
/* 3262 */       if (!isCellSelectionEnabled())
/*      */         return; 
/* 3264 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/* 3265 */       if (treeTablePosition.getColumn() - 1 >= 0) {
/* 3266 */         select(treeTablePosition.getRow(), getTableColumn(treeTablePosition.getTableColumn(), -1));
/*      */       }
/*      */     }
/*      */     
/*      */     public void selectRightCell() {
/* 3271 */       if (!isCellSelectionEnabled())
/*      */         return; 
/* 3273 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/* 3274 */       if (treeTablePosition.getColumn() + 1 < getTreeTableView().getVisibleLeafColumns().size()) {
/* 3275 */         select(treeTablePosition.getRow(), getTableColumn(treeTablePosition.getTableColumn(), 1));
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateDefaultSelection() {
/* 3290 */       int i = -1;
/* 3291 */       TreeItem<S> treeItem = getSelectedItem();
/* 3292 */       if (treeItem != null) {
/* 3293 */         i = this.treeTableView.getRow(treeItem);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3298 */       boolean bool = (i != -1) ? i : ((this.treeTableView.getExpandedItemCount() > 0) ? false : true);
/*      */       
/* 3300 */       clearSelection();
/* 3301 */       select(i, isCellSelectionEnabled() ? getTableColumn(0) : null);
/* 3302 */       focus(bool, isCellSelectionEnabled() ? getTableColumn(0) : null);
/*      */     }
/*      */     
/*      */     private TreeTableColumn<S, ?> getTableColumn(int param1Int) {
/* 3306 */       return getTreeTableView().getVisibleLeafColumn(param1Int);
/*      */     }
/*      */ 
/*      */     
/*      */     private TreeTableColumn<S, ?> getTableColumn(TreeTableColumn<S, ?> param1TreeTableColumn, int param1Int) {
/* 3311 */       int i = getTreeTableView().getVisibleLeafIndex(param1TreeTableColumn);
/* 3312 */       int j = i + param1Int;
/* 3313 */       return getTreeTableView().getVisibleLeafColumn(j);
/*      */     }
/*      */     
/*      */     private void updateSelectedIndex(int param1Int) {
/* 3317 */       setSelectedIndex(param1Int);
/* 3318 */       setSelectedItem(getModelItem(param1Int));
/*      */     }
/*      */     
/*      */     public void focus(int param1Int) {
/* 3322 */       focus(param1Int, (TreeTableColumn<S, ?>)null);
/*      */     }
/*      */     
/*      */     private void focus(int param1Int, TreeTableColumn<S, ?> param1TreeTableColumn) {
/* 3326 */       focus(new TreeTablePosition<>(getTreeTableView(), param1Int, param1TreeTableColumn));
/*      */     }
/*      */     
/*      */     private void focus(TreeTablePosition<S, ?> param1TreeTablePosition) {
/* 3330 */       if (getTreeTableView().getFocusModel() == null)
/*      */         return; 
/* 3332 */       getTreeTableView().getFocusModel().focus(param1TreeTablePosition.getRow(), param1TreeTablePosition.getTableColumn());
/* 3333 */       getTreeTableView().notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
/*      */     }
/*      */     
/*      */     public int getFocusedIndex() {
/* 3337 */       return getFocusedCell().getRow();
/*      */     }
/*      */     
/*      */     private TreeTablePosition<S, ?> getFocusedCell() {
/* 3341 */       if (this.treeTableView.getFocusModel() == null) {
/* 3342 */         return new TreeTablePosition<>(this.treeTableView, -1, null);
/*      */       }
/* 3344 */       return this.treeTableView.getFocusModel().getFocusedCell();
/*      */     }
/*      */     
/*      */     private int getRowCount() {
/* 3348 */       return this.treeTableView.getExpandedItemCount();
/*      */     }
/*      */     
/*      */     private void fireCustomSelectedCellsListChangeEvent(ListChangeListener.Change<? extends TreeTablePosition<S, ?>> param1Change) {
/* 3352 */       ControlUtils.updateSelectedIndices(this, (ListChangeListener.Change)param1Change);
/*      */       
/* 3354 */       if (isAtomic()) {
/*      */         return;
/*      */       }
/*      */       
/* 3358 */       this.selectedCellsSeq.callObservers(new MappingChange<>(param1Change, MappingChange.NOOP_MAP, this.selectedCellsSeq));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class TreeTableViewFocusModel<S>
/*      */     extends TableFocusModel<TreeItem<S>, TreeTableColumn<S, ?>>
/*      */   {
/*      */     private final TreeTableView<S> treeTableView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TreeTablePosition EMPTY_CELL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ChangeListener<TreeItem<S>> rootPropertyListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final WeakChangeListener<TreeItem<S>> weakRootPropertyListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private EventHandler<TreeItem.TreeModificationEvent<S>> treeItemListener;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private WeakEventHandler<TreeItem.TreeModificationEvent<S>> weakTreeItemListener;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ReadOnlyObjectWrapper<TreeTablePosition<S, ?>> focusedCell;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TreeTableViewFocusModel(TreeTableView<S> param1TreeTableView)
/*      */     {
/* 3412 */       this.rootPropertyListener = ((param1ObservableValue, param1TreeItem1, param1TreeItem2) -> updateTreeEventListener(param1TreeItem1, param1TreeItem2));
/*      */ 
/*      */ 
/*      */       
/* 3416 */       this.weakRootPropertyListener = new WeakChangeListener<>(this.rootPropertyListener);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3430 */       this.treeItemListener = new EventHandler<TreeItem.TreeModificationEvent<S>>()
/*      */         {
/*      */           public void handle(TreeItem.TreeModificationEvent<S> param2TreeModificationEvent)
/*      */           {
/* 3434 */             if (TreeTableView.TreeTableViewFocusModel.this.getFocusedIndex() == -1)
/*      */               return; 
/* 3436 */             int i = 0;
/* 3437 */             if (param2TreeModificationEvent.getChange() != null) {
/* 3438 */               param2TreeModificationEvent.getChange().next();
/*      */             }
/*      */             
/*      */             do {
/* 3442 */               int j = TreeTableView.TreeTableViewFocusModel.this.treeTableView.getRow(param2TreeModificationEvent.getTreeItem());
/*      */               
/* 3444 */               if (param2TreeModificationEvent.wasExpanded()) {
/* 3445 */                 if (j < TreeTableView.TreeTableViewFocusModel.this.getFocusedIndex())
/*      */                 {
/* 3447 */                   i += param2TreeModificationEvent.getTreeItem().getExpandedDescendentCount(false) - 1;
/*      */                 }
/* 3449 */               } else if (param2TreeModificationEvent.wasCollapsed()) {
/* 3450 */                 if (j < TreeTableView.TreeTableViewFocusModel.this.getFocusedIndex())
/*      */                 {
/*      */                   
/* 3453 */                   i += -(param2TreeModificationEvent.getTreeItem()).previousExpandedDescendentCount + 1;
/*      */                 }
/* 3455 */               } else if (param2TreeModificationEvent.wasAdded()) {
/*      */ 
/*      */                 
/* 3458 */                 TreeItem<S> treeItem = param2TreeModificationEvent.getTreeItem();
/* 3459 */                 if (treeItem.isExpanded()) {
/* 3460 */                   for (byte b = 0; b < param2TreeModificationEvent.getAddedChildren().size(); b++) {
/*      */                     
/* 3462 */                     TreeItem treeItem1 = param2TreeModificationEvent.getAddedChildren().get(b);
/* 3463 */                     j = TreeTableView.TreeTableViewFocusModel.this.treeTableView.getRow(treeItem1);
/*      */                     
/* 3465 */                     if (treeItem1 != null && j <= i + TreeTableView.TreeTableViewFocusModel.this.getFocusedIndex()) {
/* 3466 */                       i += treeItem1.getExpandedDescendentCount(false);
/*      */                     }
/*      */                   } 
/*      */                 }
/* 3470 */               } else if (param2TreeModificationEvent.wasRemoved()) {
/* 3471 */                 j += param2TreeModificationEvent.getFrom() + 1;
/*      */                 
/* 3473 */                 for (byte b = 0; b < param2TreeModificationEvent.getRemovedChildren().size(); b++) {
/* 3474 */                   TreeItem treeItem = param2TreeModificationEvent.getRemovedChildren().get(b);
/* 3475 */                   if (treeItem != null && treeItem.equals(TreeTableView.TreeTableViewFocusModel.this.getFocusedItem())) {
/* 3476 */                     TreeTableView.TreeTableViewFocusModel.this.focus(Math.max(0, TreeTableView.TreeTableViewFocusModel.this.getFocusedIndex() - 1));
/*      */                     
/*      */                     return;
/*      */                   } 
/*      */                 } 
/* 3481 */                 if (j <= TreeTableView.TreeTableViewFocusModel.this.getFocusedIndex())
/*      */                 {
/* 3483 */                   i += param2TreeModificationEvent.getTreeItem().isExpanded() ? -param2TreeModificationEvent.getRemovedSize() : 0;
/*      */                 }
/*      */               } 
/* 3486 */             } while (param2TreeModificationEvent.getChange() != null && param2TreeModificationEvent.getChange().next());
/*      */             
/* 3488 */             if (i != 0) {
/* 3489 */               TreeTablePosition treeTablePosition = TreeTableView.TreeTableViewFocusModel.this.getFocusedCell();
/* 3490 */               int j = treeTablePosition.getRow() + i;
/* 3491 */               if (j >= 0)
/* 3492 */                 Platform.runLater(() -> TreeTableView.TreeTableViewFocusModel.this.focus(param2Int, param2TreeTablePosition.getTableColumn())); 
/*      */             }  }
/*      */         }; if (param1TreeTableView == null)
/*      */         throw new NullPointerException("TableView can not be null");  this.treeTableView = param1TreeTableView; this.EMPTY_CELL = new TreeTablePosition<>(param1TreeTableView, -1, null); this.treeTableView.rootProperty().addListener(this.weakRootPropertyListener); updateTreeEventListener((TreeItem<S>)null, param1TreeTableView.getRoot()); boolean bool = (getItemCount() > 0) ? false : true; TreeTablePosition<S, Object> treeTablePosition = new TreeTablePosition<>(param1TreeTableView, bool, null); setFocusedCell(treeTablePosition); param1TreeTableView.showRootProperty().addListener(param1Observable -> {
/*      */             if (isFocused(0)) {
/*      */               focus(-1); focus(0);
/*      */             } 
/*      */           }); focusedCellProperty().addListener(param1Observable -> param1TreeTableView.notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM)); } private void updateTreeEventListener(TreeItem<S> param1TreeItem1, TreeItem<S> param1TreeItem2) { if (param1TreeItem1 != null && this.weakTreeItemListener != null)
/*      */         param1TreeItem1.removeEventHandler(TreeItem.expandedItemCountChangeEvent(), this.weakTreeItemListener); 
/*      */       if (param1TreeItem2 != null) {
/*      */         this.weakTreeItemListener = new WeakEventHandler<>(this.treeItemListener);
/*      */         param1TreeItem2.addEventHandler(TreeItem.expandedItemCountChangeEvent(), this.weakTreeItemListener);
/* 3504 */       }  } protected int getItemCount() { return this.treeTableView.getExpandedItemCount(); }
/*      */ 
/*      */ 
/*      */     
/*      */     protected TreeItem<S> getModelItem(int param1Int) {
/* 3509 */       if (param1Int < 0 || param1Int >= getItemCount()) return null; 
/* 3510 */       return this.treeTableView.getTreeItem(param1Int);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final ReadOnlyObjectProperty<TreeTablePosition<S, ?>> focusedCellProperty() {
/* 3518 */       return focusedCellPropertyImpl().getReadOnlyProperty();
/*      */     }
/* 3520 */     private void setFocusedCell(TreeTablePosition<S, ?> param1TreeTablePosition) { focusedCellPropertyImpl().set(param1TreeTablePosition); } public final TreeTablePosition<S, ?> getFocusedCell() {
/* 3521 */       return (this.focusedCell == null) ? this.EMPTY_CELL : this.focusedCell.get();
/*      */     }
/*      */     private ReadOnlyObjectWrapper<TreeTablePosition<S, ?>> focusedCellPropertyImpl() {
/* 3524 */       if (this.focusedCell == null) {
/* 3525 */         this.focusedCell = new ReadOnlyObjectWrapper<TreeTablePosition<S, ?>>(this.EMPTY_CELL) { private TreeTablePosition<S, ?> old;
/*      */             
/*      */             protected void invalidated() {
/* 3528 */               if (get() == null)
/*      */                 return; 
/* 3530 */               if (this.old == null || !this.old.equals(get())) {
/* 3531 */                 TreeTableView.TreeTableViewFocusModel.this.setFocusedIndex(get().getRow());
/* 3532 */                 TreeTableView.TreeTableViewFocusModel.this.setFocusedItem(TreeTableView.TreeTableViewFocusModel.this.getModelItem(getValue().getRow()));
/*      */                 
/* 3534 */                 this.old = get();
/*      */               } 
/*      */             }
/*      */ 
/*      */             
/*      */             public Object getBean() {
/* 3540 */               return TreeTableView.TreeTableViewFocusModel.this;
/*      */             }
/*      */ 
/*      */             
/*      */             public String getName() {
/* 3545 */               return "focusedCell";
/*      */             } }
/*      */           ;
/*      */       }
/* 3549 */       return this.focusedCell;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focus(int param1Int, TreeTableColumn<S, ?> param1TreeTableColumn) {
/* 3560 */       if (param1Int < 0 || param1Int >= getItemCount()) {
/* 3561 */         setFocusedCell(this.EMPTY_CELL);
/*      */       } else {
/* 3563 */         TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/* 3564 */         TreeTablePosition<S, Object> treeTablePosition1 = new TreeTablePosition<>(this.treeTableView, param1Int, param1TreeTableColumn);
/* 3565 */         setFocusedCell(treeTablePosition1);
/*      */         
/* 3567 */         if (treeTablePosition1.equals(treeTablePosition)) {
/*      */           
/* 3569 */           setFocusedIndex(param1Int);
/* 3570 */           setFocusedItem(getModelItem(param1Int));
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focus(TreeTablePosition<S, ?> param1TreeTablePosition) {
/* 3582 */       if (param1TreeTablePosition == null)
/* 3583 */         return;  focus(param1TreeTablePosition.getRow(), param1TreeTablePosition.getTableColumn());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isFocused(int param1Int, TreeTableColumn<S, ?> param1TreeTableColumn) {
/* 3598 */       if (param1Int < 0 || param1Int >= getItemCount()) return false;
/*      */       
/* 3600 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/* 3601 */       boolean bool = (param1TreeTableColumn == null || param1TreeTableColumn.equals(treeTablePosition.getTableColumn())) ? true : false;
/*      */       
/* 3603 */       return (treeTablePosition.getRow() == param1Int && bool);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focus(int param1Int) {
/* 3615 */       if (this.treeTableView.expandedItemCountDirty) {
/* 3616 */         this.treeTableView.updateExpandedItemCount(this.treeTableView.getRoot());
/*      */       }
/*      */       
/* 3619 */       if (param1Int < 0 || param1Int >= getItemCount()) {
/* 3620 */         setFocusedCell(this.EMPTY_CELL);
/*      */       } else {
/* 3622 */         setFocusedCell(new TreeTablePosition<>(this.treeTableView, param1Int, null));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focusAboveCell() {
/* 3630 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/*      */       
/* 3632 */       if (getFocusedIndex() == -1) {
/* 3633 */         focus(getItemCount() - 1, treeTablePosition.getTableColumn());
/* 3634 */       } else if (getFocusedIndex() > 0) {
/* 3635 */         focus(getFocusedIndex() - 1, treeTablePosition.getTableColumn());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focusBelowCell() {
/* 3643 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/* 3644 */       if (getFocusedIndex() == -1) {
/* 3645 */         focus(0, treeTablePosition.getTableColumn());
/* 3646 */       } else if (getFocusedIndex() != getItemCount() - 1) {
/* 3647 */         focus(getFocusedIndex() + 1, treeTablePosition.getTableColumn());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focusLeftCell() {
/* 3655 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/* 3656 */       if (treeTablePosition.getColumn() <= 0)
/* 3657 */         return;  focus(treeTablePosition.getRow(), getTableColumn(treeTablePosition.getTableColumn(), -1));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void focusRightCell() {
/* 3664 */       TreeTablePosition<S, ?> treeTablePosition = getFocusedCell();
/* 3665 */       if (treeTablePosition.getColumn() == getColumnCount() - 1)
/* 3666 */         return;  focus(treeTablePosition.getRow(), getTableColumn(treeTablePosition.getTableColumn(), 1));
/*      */     }
/*      */ 
/*      */     
/*      */     public void focusPrevious() {
/* 3671 */       if (getFocusedIndex() == -1) {
/* 3672 */         focus(0);
/* 3673 */       } else if (getFocusedIndex() > 0) {
/* 3674 */         focusAboveCell();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void focusNext() {
/* 3680 */       if (getFocusedIndex() == -1) {
/* 3681 */         focus(0);
/* 3682 */       } else if (getFocusedIndex() != getItemCount() - 1) {
/* 3683 */         focusBelowCell();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int getColumnCount() {
/* 3696 */       return this.treeTableView.getVisibleLeafColumns().size();
/*      */     }
/*      */ 
/*      */     
/*      */     private TreeTableColumn<S, ?> getTableColumn(TreeTableColumn<S, ?> param1TreeTableColumn, int param1Int) {
/* 3701 */       int i = this.treeTableView.getVisibleLeafIndex(param1TreeTableColumn);
/* 3702 */       int j = i + param1Int;
/* 3703 */       return this.treeTableView.getVisibleLeafColumn(j);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TreeTableView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */