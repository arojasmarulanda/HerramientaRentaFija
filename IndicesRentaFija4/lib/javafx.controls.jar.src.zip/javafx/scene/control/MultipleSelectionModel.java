/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MultipleSelectionModel<T>
/*     */   extends SelectionModel<T>
/*     */ {
/*     */   private ObjectProperty<SelectionMode> selectionMode;
/*     */   
/*     */   public final void setSelectionMode(SelectionMode paramSelectionMode) {
/*  59 */     selectionModeProperty().set(paramSelectionMode);
/*     */   }
/*     */   
/*     */   public final SelectionMode getSelectionMode() {
/*  63 */     return (this.selectionMode == null) ? SelectionMode.SINGLE : this.selectionMode.get();
/*     */   }
/*     */   
/*     */   public final ObjectProperty<SelectionMode> selectionModeProperty() {
/*  67 */     if (this.selectionMode == null) {
/*  68 */       this.selectionMode = new ObjectPropertyBase<SelectionMode>(SelectionMode.SINGLE) {
/*     */           protected void invalidated() {
/*  70 */             if (MultipleSelectionModel.this.getSelectionMode() == SelectionMode.SINGLE)
/*     */             {
/*     */               
/*  73 */               if (!MultipleSelectionModel.this.isEmpty()) {
/*  74 */                 int i = MultipleSelectionModel.this.getSelectedIndex();
/*  75 */                 MultipleSelectionModel.this.clearSelection();
/*  76 */                 MultipleSelectionModel.this.select(i);
/*     */               } 
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/*  83 */             return MultipleSelectionModel.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/*  88 */             return "selectionMode";
/*     */           }
/*     */         };
/*     */     }
/*  92 */     return this.selectionMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ObservableList<Integer> getSelectedIndices();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ObservableList<T> getSelectedItems();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void selectIndices(int paramInt, int... paramVarArgs);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectRange(int paramInt1, int paramInt2) {
/* 166 */     if (paramInt1 == paramInt2)
/*     */       return; 
/* 168 */     boolean bool = (paramInt1 < paramInt2) ? true : false;
/* 169 */     int i = bool ? paramInt1 : paramInt2;
/* 170 */     int j = bool ? paramInt2 : paramInt1;
/* 171 */     int k = j - i - 1;
/*     */     
/* 173 */     int[] arrayOfInt = new int[k];
/*     */     
/* 175 */     int m = bool ? i : j;
/* 176 */     int n = bool ? m++ : m--;
/* 177 */     for (byte b = 0; b < k; b++) {
/* 178 */       arrayOfInt[b] = bool ? m++ : m--;
/*     */     }
/* 180 */     selectIndices(n, arrayOfInt);
/*     */   }
/*     */   
/*     */   public abstract void selectAll();
/*     */   
/*     */   public abstract void selectFirst();
/*     */   
/*     */   public abstract void selectLast();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\MultipleSelectionModel.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */