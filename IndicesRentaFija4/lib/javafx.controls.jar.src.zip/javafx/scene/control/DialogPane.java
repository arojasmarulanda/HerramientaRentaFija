/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.css.StyleManager;
/*      */ import com.sun.javafx.scene.control.skin.Utils;
/*      */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.WeakHashMap;
/*      */ import javafx.beans.DefaultProperty;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.beans.property.SimpleStringProperty;
/*      */ import javafx.beans.property.StringProperty;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.StyleOrigin;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.StyleableStringProperty;
/*      */ import javafx.css.converter.StringConverter;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.geometry.Pos;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.image.Image;
/*      */ import javafx.scene.image.ImageView;
/*      */ import javafx.scene.layout.ColumnConstraints;
/*      */ import javafx.scene.layout.GridPane;
/*      */ import javafx.scene.layout.Pane;
/*      */ import javafx.scene.layout.Priority;
/*      */ import javafx.scene.layout.Region;
/*      */ import javafx.scene.layout.StackPane;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @DefaultProperty("buttonTypes")
/*      */ public class DialogPane
/*      */   extends Pane
/*      */ {
/*      */   private final GridPane headerTextPanel;
/*      */   private final Label contentLabel;
/*      */   private final StackPane graphicContainer;
/*      */   private final Node buttonBar;
/*      */   
/*      */   static Label createContentLabel(String paramString) {
/*  167 */     Label label = new Label(paramString);
/*  168 */     label.setMaxWidth(Double.MAX_VALUE);
/*  169 */     label.setMaxHeight(Double.MAX_VALUE);
/*  170 */     label.getStyleClass().add("content");
/*  171 */     label.setWrapText(true);
/*  172 */     label.setPrefWidth(360.0D);
/*  173 */     return label;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  189 */   private final ObservableList<ButtonType> buttons = FXCollections.observableArrayList();
/*      */   
/*  191 */   private final Map<ButtonType, Node> buttonNodes = new WeakHashMap<>(); private Node detailsButton; private Dialog<?> dialog; private final ObjectProperty<Node> graphicProperty; private StyleableStringProperty imageUrl; private final ObjectProperty<Node> header; private final StringProperty headerText; private final ObjectProperty<Node> content; private final StringProperty contentText; private final ObjectProperty<Node> expandableContentProperty; private final BooleanProperty expandedProperty; private double oldHeight; public final ObjectProperty<Node> graphicProperty() {
/*      */     return this.graphicProperty;
/*      */   } public final Node getGraphic() {
/*      */     return this.graphicProperty.get();
/*      */   } public final void setGraphic(Node paramNode) {
/*      */     this.graphicProperty.set(paramNode);
/*      */   } private StyleableStringProperty imageUrlProperty() {
/*      */     if (this.imageUrl == null)
/*      */       this.imageUrl = new StyleableStringProperty() { StyleOrigin origin = StyleOrigin.USER; public void applyStyle(StyleOrigin param1StyleOrigin, String param1String) {
/*      */             this.origin = param1StyleOrigin;
/*      */             if (DialogPane.this.graphicProperty == null || !DialogPane.this.graphicProperty.isBound())
/*      */               super.applyStyle(param1StyleOrigin, param1String); 
/*      */             this.origin = StyleOrigin.USER;
/*      */           } protected void invalidated() {
/*      */             String str = super.get();
/*      */             if (str == null) {
/*      */               ((StyleableProperty)DialogPane.this.graphicProperty()).applyStyle(this.origin, null);
/*      */             } else {
/*      */               Node node = DialogPane.this.getGraphic();
/*      */               if (node instanceof ImageView) {
/*      */                 ImageView imageView = (ImageView)node;
/*      */                 Image image1 = imageView.getImage();
/*      */                 if (image1 != null) {
/*      */                   String str1 = image1.getUrl();
/*      */                   if (str.equals(str1))
/*      */                     return; 
/*      */                 } 
/*      */               } 
/*      */               Image image = StyleManager.getInstance().getCachedImage(str);
/*      */               if (image != null)
/*      */                 ((StyleableProperty)DialogPane.this.graphicProperty()).applyStyle(this.origin, new ImageView(image)); 
/*      */             } 
/*      */           } public String get() {
/*      */             Node node = DialogPane.this.getGraphic();
/*      */             if (node instanceof ImageView) {
/*      */               Image image = ((ImageView)node).getImage();
/*      */               if (image != null)
/*      */                 return image.getUrl(); 
/*      */             } 
/*      */             return null;
/*      */           } public StyleOrigin getStyleOrigin() {
/*      */             return (DialogPane.this.graphicProperty != null) ? ((StyleableProperty)DialogPane.this.graphicProperty).getStyleOrigin() : null;
/*      */           } public Object getBean() {
/*      */             return DialogPane.this;
/*      */           } public String getName() {
/*      */             return "imageUrl";
/*      */           }
/*      */           public CssMetaData<DialogPane, String> getCssMetaData() {
/*      */             return DialogPane.StyleableProperties.GRAPHIC;
/*      */           } }
/*      */         ; 
/*      */     return this.imageUrl;
/*      */   }
/*      */   public final Node getHeader() {
/*      */     return this.header.get();
/*      */   }
/*      */   public final void setHeader(Node paramNode) {
/*      */     this.header.setValue(paramNode);
/*      */   }
/*      */   public final ObjectProperty<Node> headerProperty() {
/*      */     return this.header;
/*      */   }
/*  253 */   public DialogPane() { this.graphicProperty = new StyleableObjectProperty<Node>()
/*      */       {
/*      */         public CssMetaData getCssMetaData()
/*      */         {
/*  257 */           return DialogPane.StyleableProperties.GRAPHIC;
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  261 */           return DialogPane.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  265 */           return "graphic";
/*      */         }
/*      */         
/*  268 */         WeakReference<Node> graphicRef = new WeakReference<>(null);
/*      */         
/*      */         protected void invalidated() {
/*  271 */           Node node1 = this.graphicRef.get();
/*  272 */           if (node1 != null) {
/*  273 */             DialogPane.this.getChildren().remove(node1);
/*      */           }
/*      */           
/*  276 */           Node node2 = DialogPane.this.getGraphic();
/*  277 */           this.graphicRef = new WeakReference<>(node2);
/*  278 */           DialogPane.this.updateHeaderArea();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  310 */     this.imageUrl = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  431 */     this.header = new SimpleObjectProperty<Node>(null) {
/*  432 */         WeakReference<Node> headerRef = new WeakReference<>(null);
/*      */         protected void invalidated() {
/*  434 */           Node node1 = this.headerRef.get();
/*  435 */           if (node1 != null) {
/*  436 */             DialogPane.this.getChildren().remove(node1);
/*      */           }
/*      */           
/*  439 */           Node node2 = DialogPane.this.getHeader();
/*  440 */           this.headerRef = new WeakReference<>(node2);
/*  441 */           DialogPane.this.updateHeaderArea();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  478 */     this.headerText = new SimpleStringProperty(this, "headerText") {
/*      */         protected void invalidated() {
/*  480 */           DialogPane.this.updateHeaderArea();
/*  481 */           DialogPane.this.requestLayout();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  525 */     this.content = new SimpleObjectProperty<Node>(null) {
/*  526 */         WeakReference<Node> contentRef = new WeakReference<>(null);
/*      */         protected void invalidated() {
/*  528 */           Node node1 = this.contentRef.get();
/*  529 */           if (node1 != null) {
/*  530 */             DialogPane.this.getChildren().remove(node1);
/*      */           }
/*      */           
/*  533 */           Node node2 = DialogPane.this.getContent();
/*  534 */           this.contentRef = new WeakReference<>(node2);
/*  535 */           DialogPane.this.updateContentArea();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  570 */     this.contentText = new SimpleStringProperty(this, "contentText") {
/*      */         protected void invalidated() {
/*  572 */           DialogPane.this.updateContentArea();
/*  573 */           DialogPane.this.requestLayout();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  609 */     this.expandableContentProperty = new SimpleObjectProperty<Node>(null) {
/*  610 */         WeakReference<Node> expandableContentRef = new WeakReference<>(null);
/*      */         protected void invalidated() {
/*  612 */           Node node1 = this.expandableContentRef.get();
/*  613 */           if (node1 != null) {
/*  614 */             DialogPane.this.getChildren().remove(node1);
/*      */           }
/*      */           
/*  617 */           Node node2 = DialogPane.this.getExpandableContent();
/*  618 */           this.expandableContentRef = new WeakReference<>(node2);
/*  619 */           if (node2 != null) {
/*  620 */             node2.setVisible(DialogPane.this.isExpanded());
/*  621 */             node2.setManaged(DialogPane.this.isExpanded());
/*      */             
/*  623 */             if (!node2.getStyleClass().contains("expandable-content")) {
/*  624 */               node2.getStyleClass().add("expandable-content");
/*      */             }
/*      */             
/*  627 */             DialogPane.this.getChildren().add(node2);
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  663 */     this.expandedProperty = new SimpleBooleanProperty(this, "expanded", false) {
/*      */         protected void invalidated() {
/*  665 */           Node node = DialogPane.this.getExpandableContent();
/*      */           
/*  667 */           if (node != null) {
/*  668 */             node.setVisible(DialogPane.this.isExpanded());
/*      */           }
/*      */           
/*  671 */           DialogPane.this.requestLayout();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  831 */     this.oldHeight = -1.0D; getStyleClass().add("dialog-pane"); this.headerTextPanel = new GridPane(); getChildren().add(this.headerTextPanel); this.graphicContainer = new StackPane(); this.contentLabel = createContentLabel(""); getChildren().add(this.contentLabel); this.buttonBar = createButtonBar(); if (this.buttonBar != null) getChildren().add(this.buttonBar);  this.buttons.addListener(paramChange -> { while (paramChange.next()) { if (paramChange.wasRemoved()) for (ButtonType buttonType : paramChange.getRemoved()) this.buttonNodes.remove(buttonType);   if (paramChange.wasAdded()) for (ButtonType buttonType : paramChange.getAddedSubList()) { if (!this.buttonNodes.containsKey(buttonType))
/*      */                   this.buttonNodes.put(buttonType, createButton(buttonType));  }   }  }); }
/*      */   public final void setHeaderText(String paramString) { this.headerText.set(paramString); }
/*      */   public final String getHeaderText() { return this.headerText.get(); }
/*  835 */   public final StringProperty headerTextProperty() { return this.headerText; } protected void layoutChildren() { double d7, d15, d16, d17; boolean bool = hasHeader();
/*      */ 
/*      */     
/*  838 */     double d1 = Math.max(minWidth(-1.0D), getWidth());
/*      */     
/*  840 */     double d2 = minHeight(d1);
/*  841 */     double d3 = prefHeight(d1);
/*  842 */     double d4 = maxHeight(d1);
/*  843 */     double d5 = getHeight();
/*  844 */     double d6 = (this.dialog == null) ? 0.0D : this.dialog.dialog.getSceneHeight();
/*      */ 
/*      */     
/*  847 */     if (d3 > d5 && d3 > d2 && (d3 <= d6 || d6 == 0.0D)) {
/*  848 */       d7 = d3;
/*  849 */       resize(d1, d7);
/*      */     } else {
/*  851 */       boolean bool1 = (d5 > this.oldHeight) ? true : false;
/*      */       
/*  853 */       if (bool1) {
/*      */         
/*  855 */         double d = (d5 < d3) ? Math.min(d3, d5) : Math.max(d3, d6);
/*  856 */         d7 = Utils.boundedSize(d, d2, d4);
/*      */       } else {
/*  858 */         d7 = Utils.boundedSize(Math.min(d5, d6), d2, d4);
/*      */       } 
/*  860 */       resize(d1, d7);
/*      */     } 
/*      */     
/*  863 */     d7 -= snappedTopInset() + snappedBottomInset();
/*      */     
/*  865 */     this.oldHeight = d7;
/*      */     
/*  867 */     double d8 = snappedLeftInset();
/*  868 */     double d9 = snappedTopInset();
/*  869 */     double d10 = snappedRightInset();
/*      */ 
/*      */     
/*  872 */     Node node1 = getActualHeader();
/*  873 */     Node node2 = getActualContent();
/*  874 */     Node node3 = getActualGraphic();
/*  875 */     Node node4 = getExpandableContent();
/*      */     
/*  877 */     double d11 = (bool || node3 == null) ? 0.0D : node3.prefWidth(-1.0D);
/*  878 */     double d12 = bool ? node1.prefHeight(d1) : 0.0D;
/*  879 */     double d13 = (this.buttonBar == null) ? 0.0D : this.buttonBar.prefHeight(d1);
/*  880 */     double d14 = (bool || node3 == null) ? 0.0D : node3.prefHeight(-1.0D);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  886 */     double d18 = d1 - d11 - d8 - d10;
/*      */     
/*  888 */     if (isExpanded()) {
/*      */       
/*  890 */       d16 = isExpanded() ? node2.prefHeight(d18) : 0.0D;
/*  891 */       d17 = bool ? d16 : Math.max(d14, d16);
/*  892 */       d15 = d7 - d12 + d17 + d13;
/*      */     } else {
/*      */       
/*  895 */       d15 = isExpanded() ? node4.prefHeight(d1) : 0.0D;
/*  896 */       d16 = d7 - d12 + d15 + d13;
/*  897 */       d17 = bool ? d16 : Math.max(d14, d16);
/*      */     } 
/*      */     
/*  900 */     double d19 = d8;
/*  901 */     double d20 = d9;
/*      */     
/*  903 */     if (!bool) {
/*  904 */       if (node3 != null) {
/*  905 */         node3.resizeRelocate(d19, d20, d11, d14);
/*  906 */         d19 += d11;
/*      */       } 
/*      */     } else {
/*  909 */       node1.resizeRelocate(d19, d20, d1 - d8 + d10, d12);
/*  910 */       d20 += d12;
/*      */     } 
/*      */     
/*  913 */     node2.resizeRelocate(d19, d20, d18, d16);
/*  914 */     d20 += bool ? d16 : d17;
/*      */     
/*  916 */     if (node4 != null) {
/*  917 */       node4.resizeRelocate(d8, d20, d1 - d10, d15);
/*  918 */       d20 += d15;
/*      */     } 
/*      */     
/*  921 */     if (this.buttonBar != null)
/*  922 */       this.buttonBar.resizeRelocate(d8, d20, d1 - d8 + d10, d13);  }
/*      */   public final Node getContent() { return this.content.get(); }
/*      */   public final void setContent(Node paramNode) { this.content.setValue(paramNode); }
/*      */   public final ObjectProperty<Node> contentProperty() { return this.content; }
/*      */   public final void setContentText(String paramString) { this.contentText.set(paramString); }
/*      */   public final String getContentText() { return this.contentText.get(); }
/*      */   public final StringProperty contentTextProperty() { return this.contentText; }
/*      */   public final ObjectProperty<Node> expandableContentProperty() { return this.expandableContentProperty; }
/*      */   public final Node getExpandableContent() { return this.expandableContentProperty.get(); }
/*  931 */   public final void setExpandableContent(Node paramNode) { this.expandableContentProperty.set(paramNode); } public final BooleanProperty expandedProperty() { return this.expandedProperty; } protected double computeMinWidth(double paramDouble) { double d1 = hasHeader() ? (getActualHeader().minWidth(paramDouble) + 10.0D) : 0.0D;
/*  932 */     double d2 = getActualContent().minWidth(paramDouble);
/*  933 */     double d3 = (this.buttonBar == null) ? 0.0D : this.buttonBar.minWidth(paramDouble);
/*  934 */     double d4 = getActualGraphic().minWidth(paramDouble);
/*      */     
/*  936 */     double d5 = 0.0D;
/*  937 */     Node node = getExpandableContent();
/*  938 */     if (isExpanded() && node != null) {
/*  939 */       d5 = node.minWidth(paramDouble);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  945 */     double d6 = snappedLeftInset() + (hasHeader() ? 0.0D : d4) + Math.max(Math.max(d1, d5), Math.max(d2, d3)) + snappedRightInset();
/*      */     
/*  947 */     return snapSizeX(d6); } public final boolean isExpanded() { return expandedProperty().get(); }
/*      */   public final void setExpanded(boolean paramBoolean) { expandedProperty().set(paramBoolean); }
/*      */   public final ObservableList<ButtonType> getButtonTypes() {
/*      */     return this.buttons;
/*      */   }
/*  952 */   protected double computeMinHeight(double paramDouble) { boolean bool = hasHeader();
/*      */     
/*  954 */     double d1 = bool ? getActualHeader().minHeight(paramDouble) : 0.0D;
/*  955 */     double d2 = (this.buttonBar == null) ? 0.0D : this.buttonBar.minHeight(paramDouble);
/*      */     
/*  957 */     Node node1 = getActualGraphic();
/*  958 */     double d3 = bool ? 0.0D : node1.minWidth(-1.0D);
/*  959 */     double d4 = bool ? 0.0D : node1.minHeight(paramDouble);
/*      */ 
/*      */     
/*  962 */     Node node2 = getActualContent();
/*      */     
/*  964 */     double d5 = (paramDouble == -1.0D) ? -1.0D : (bool ? paramDouble : (paramDouble - d3));
/*  965 */     double d6 = node2.minHeight(d5);
/*      */     
/*  967 */     double d7 = 0.0D;
/*  968 */     Node node3 = getExpandableContent();
/*  969 */     if (isExpanded() && node3 != null) {
/*  970 */       d7 = node3.minHeight(paramDouble);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  978 */     double d8 = snappedTopInset() + d1 + Math.max(d4, d6) + d7 + d2 + snappedBottomInset();
/*      */     
/*  980 */     return snapSizeY(d8); } public final Node lookupButton(ButtonType paramButtonType) { return this.buttonNodes.get(paramButtonType); }
/*      */   protected Node createButtonBar() { ButtonBar buttonBar = new ButtonBar(); buttonBar.setMaxWidth(Double.MAX_VALUE); updateButtons(buttonBar); getButtonTypes().addListener(paramChange -> updateButtons(paramButtonBar)); expandableContentProperty().addListener(paramObservable -> updateButtons(paramButtonBar)); return buttonBar; }
/*      */   protected Node createButton(ButtonType paramButtonType) { Button button = new Button(paramButtonType.getText()); ButtonBar.ButtonData buttonData = paramButtonType.getButtonData(); ButtonBar.setButtonData(button, buttonData); button.setDefaultButton(buttonData.isDefaultButton()); button.setCancelButton(buttonData.isCancelButton()); button.addEventHandler(ActionEvent.ACTION, paramActionEvent -> { if (paramActionEvent.isConsumed()) return;  if (this.dialog != null)
/*      */             this.dialog.setResultAndClose(paramButtonType, true);  }); return button; }
/*      */   protected Node createDetailsButton() { Hyperlink hyperlink = new Hyperlink(); String str1 = ControlResources.getString("Dialog.detail.button.more"); String str2 = ControlResources.getString("Dialog.detail.button.less"); InvalidationListener invalidationListener = paramObservable -> { boolean bool = isExpanded(); paramHyperlink.setText(bool ? paramString1 : paramString2); paramHyperlink.getStyleClass().setAll(new String[] { "details-button", bool ? "less" : "more" }); }; invalidationListener.invalidated(null); expandedProperty().addListener(invalidationListener); hyperlink.setOnAction(paramActionEvent -> setExpanded(!isExpanded())); return hyperlink; }
/*  985 */   protected double computePrefWidth(double paramDouble) { double d1 = hasHeader() ? (getActualHeader().prefWidth(paramDouble) + 10.0D) : 0.0D;
/*  986 */     double d2 = getActualContent().prefWidth(paramDouble);
/*  987 */     double d3 = (this.buttonBar == null) ? 0.0D : this.buttonBar.prefWidth(paramDouble);
/*  988 */     double d4 = getActualGraphic().prefWidth(paramDouble);
/*      */     
/*  990 */     double d5 = 0.0D;
/*  991 */     Node node = getExpandableContent();
/*  992 */     if (isExpanded() && node != null) {
/*  993 */       d5 = node.prefWidth(paramDouble);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  999 */     double d6 = snappedLeftInset() + (hasHeader() ? 0.0D : d4) + Math.max(Math.max(d1, d5), Math.max(d2, d3)) + snappedRightInset();
/*      */     
/* 1001 */     return snapSizeX(d6); }
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computePrefHeight(double paramDouble) {
/* 1006 */     boolean bool = hasHeader();
/*      */     
/* 1008 */     double d1 = bool ? getActualHeader().prefHeight(paramDouble) : 0.0D;
/* 1009 */     double d2 = (this.buttonBar == null) ? 0.0D : this.buttonBar.prefHeight(paramDouble);
/*      */     
/* 1011 */     Node node1 = getActualGraphic();
/* 1012 */     double d3 = bool ? 0.0D : node1.prefWidth(-1.0D);
/* 1013 */     double d4 = bool ? 0.0D : node1.prefHeight(paramDouble);
/*      */     
/* 1015 */     Node node2 = getActualContent();
/*      */     
/* 1017 */     double d5 = (paramDouble == -1.0D) ? -1.0D : (bool ? paramDouble : (paramDouble - d3));
/* 1018 */     double d6 = node2.prefHeight(d5);
/*      */     
/* 1020 */     double d7 = 0.0D;
/* 1021 */     Node node3 = getExpandableContent();
/* 1022 */     if (isExpanded() && node3 != null) {
/* 1023 */       d7 = node3.prefHeight(paramDouble);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1031 */     double d8 = snappedTopInset() + d1 + Math.max(d4, d6) + d7 + d2 + snappedBottomInset();
/*      */     
/* 1033 */     return snapSizeY(d8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateButtons(ButtonBar paramButtonBar) {
/* 1046 */     paramButtonBar.getButtons().clear();
/*      */ 
/*      */     
/* 1049 */     if (hasExpandableContent()) {
/* 1050 */       if (this.detailsButton == null) {
/* 1051 */         this.detailsButton = createDetailsButton();
/*      */       }
/* 1053 */       ButtonBar.setButtonData(this.detailsButton, ButtonBar.ButtonData.HELP_2);
/* 1054 */       paramButtonBar.getButtons().add(this.detailsButton);
/* 1055 */       ButtonBar.setButtonUniformSize(this.detailsButton, false);
/*      */     } 
/*      */     
/* 1058 */     int i = 0;
/* 1059 */     for (ButtonType buttonType : getButtonTypes()) {
/* 1060 */       Node node = this.buttonNodes.computeIfAbsent(buttonType, paramButtonType2 -> createButton(paramButtonType1));
/*      */ 
/*      */       
/* 1063 */       if (node instanceof Button) {
/* 1064 */         ButtonBar.ButtonData buttonData = buttonType.getButtonData();
/*      */         
/* 1066 */         ((Button)node).setDefaultButton((!i && buttonData != null && buttonData.isDefaultButton()));
/* 1067 */         ((Button)node).setCancelButton((buttonData != null && buttonData.isCancelButton()));
/*      */         
/* 1069 */         i |= (buttonData != null && buttonData.isDefaultButton()) ? 1 : 0;
/*      */       } 
/* 1071 */       paramButtonBar.getButtons().add(node);
/*      */     } 
/*      */   }
/*      */   
/*      */   private Node getActualContent() {
/* 1076 */     Node node = getContent();
/* 1077 */     return (node == null) ? this.contentLabel : node;
/*      */   }
/*      */   
/*      */   private Node getActualHeader() {
/* 1081 */     Node node = getHeader();
/* 1082 */     return (node == null) ? this.headerTextPanel : node;
/*      */   }
/*      */   
/*      */   private Node getActualGraphic() {
/* 1086 */     return this.headerTextPanel;
/*      */   }
/*      */   
/*      */   private void updateHeaderArea() {
/* 1090 */     Node node = getHeader();
/* 1091 */     if (node != null) {
/* 1092 */       if (!getChildren().contains(node)) {
/* 1093 */         getChildren().add(node);
/*      */       }
/*      */       
/* 1096 */       this.headerTextPanel.setVisible(false);
/* 1097 */       this.headerTextPanel.setManaged(false);
/*      */     } else {
/* 1099 */       String str = getHeaderText();
/*      */       
/* 1101 */       this.headerTextPanel.getChildren().clear();
/* 1102 */       this.headerTextPanel.getStyleClass().clear();
/*      */ 
/*      */       
/* 1105 */       this.headerTextPanel.setMaxWidth(Double.MAX_VALUE);
/*      */       
/* 1107 */       if (str != null && !str.isEmpty()) {
/* 1108 */         this.headerTextPanel.getStyleClass().add("header-panel");
/*      */       }
/*      */ 
/*      */       
/* 1112 */       Label label = new Label(str);
/* 1113 */       label.setWrapText(true);
/* 1114 */       label.setAlignment(Pos.CENTER_LEFT);
/* 1115 */       label.setMaxWidth(Double.MAX_VALUE);
/* 1116 */       label.setMaxHeight(Double.MAX_VALUE);
/* 1117 */       this.headerTextPanel.add(label, 0, 0);
/*      */ 
/*      */       
/* 1120 */       this.graphicContainer.getChildren().clear();
/*      */       
/* 1122 */       if (!this.graphicContainer.getStyleClass().contains("graphic-container")) {
/* 1123 */         this.graphicContainer.getStyleClass().add("graphic-container");
/*      */       }
/*      */       
/* 1126 */       Node node1 = getGraphic();
/* 1127 */       if (node1 != null) {
/* 1128 */         this.graphicContainer.getChildren().add(node1);
/*      */       }
/* 1130 */       this.headerTextPanel.add(this.graphicContainer, 1, 0);
/*      */ 
/*      */       
/* 1133 */       ColumnConstraints columnConstraints1 = new ColumnConstraints();
/* 1134 */       columnConstraints1.setFillWidth(true);
/* 1135 */       columnConstraints1.setHgrow(Priority.ALWAYS);
/* 1136 */       ColumnConstraints columnConstraints2 = new ColumnConstraints();
/* 1137 */       columnConstraints2.setFillWidth(false);
/* 1138 */       columnConstraints2.setHgrow(Priority.NEVER);
/* 1139 */       this.headerTextPanel.getColumnConstraints().setAll(new ColumnConstraints[] { columnConstraints1, columnConstraints2 });
/*      */       
/* 1141 */       this.headerTextPanel.setVisible(true);
/* 1142 */       this.headerTextPanel.setManaged(true);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void updateContentArea() {
/* 1147 */     Node node = getContent();
/* 1148 */     if (node != null) {
/* 1149 */       if (!getChildren().contains(node)) {
/* 1150 */         getChildren().add(node);
/*      */       }
/*      */       
/* 1153 */       if (!node.getStyleClass().contains("content")) {
/* 1154 */         node.getStyleClass().add("content");
/*      */       }
/*      */       
/* 1157 */       this.contentLabel.setVisible(false);
/* 1158 */       this.contentLabel.setManaged(false);
/*      */     } else {
/* 1160 */       String str = getContentText();
/* 1161 */       boolean bool = (str != null && !str.isEmpty()) ? true : false;
/* 1162 */       this.contentLabel.setText(bool ? str : "");
/* 1163 */       this.contentLabel.setVisible(bool);
/* 1164 */       this.contentLabel.setManaged(bool);
/*      */     } 
/*      */   }
/*      */   
/*      */   boolean hasHeader() {
/* 1169 */     return (getHeader() != null || isTextHeader());
/*      */   }
/*      */   
/*      */   private boolean isTextHeader() {
/* 1173 */     String str = getHeaderText();
/* 1174 */     return (str != null && !str.isEmpty());
/*      */   }
/*      */   
/*      */   boolean hasExpandableContent() {
/* 1178 */     return (getExpandableContent() != null);
/*      */   }
/*      */   
/*      */   void setDialog(Dialog<?> paramDialog) {
/* 1182 */     this.dialog = paramDialog;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class StyleableProperties
/*      */   {
/* 1195 */     private static final CssMetaData<DialogPane, String> GRAPHIC = new CssMetaData<DialogPane, String>("-fx-graphic", 
/*      */         
/* 1197 */         StringConverter.getInstance())
/*      */       {
/*      */         
/*      */         public boolean isSettable(DialogPane param2DialogPane)
/*      */         {
/* 1202 */           return (param2DialogPane.graphicProperty == null || !param2DialogPane.graphicProperty.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<String> getStyleableProperty(DialogPane param2DialogPane) {
/* 1207 */           return param2DialogPane.imageUrlProperty();
/*      */         }
/*      */       };
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1213 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Region.getClassCssMetaData());
/* 1214 */       Collections.addAll(arrayList, (CssMetaData<? extends Styleable, ?>[])new CssMetaData[] { GRAPHIC });
/*      */ 
/*      */       
/* 1217 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1226 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 1231 */     return getClassCssMetaData();
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\DialogPane.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */