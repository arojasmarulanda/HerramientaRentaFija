/*      */ package javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.event.EventHandlerManager;
/*      */ import com.sun.javafx.tk.Toolkit;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.Optional;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*      */ import javafx.beans.property.ReadOnlyDoubleProperty;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.beans.property.StringProperty;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventDispatchChain;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.EventTarget;
/*      */ import javafx.event.EventType;
/*      */ import javafx.scene.Node;
/*      */ import javafx.stage.Modality;
/*      */ import javafx.stage.StageStyle;
/*      */ import javafx.stage.Window;
/*      */ import javafx.util.Callback;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Dialog<R>
/*      */   implements EventTarget
/*      */ {
/*      */   final FXDialog dialog;
/*      */   private boolean isClosing;
/*      */   private ObjectProperty<DialogPane> dialogPane;
/*      */   private final ObjectProperty<R> resultProperty;
/*      */   private final ObjectProperty<Callback<ButtonType, R>> resultConverterProperty;
/*      */   private final EventHandlerManager eventHandlerManager;
/*      */   private ObjectProperty<EventHandler<DialogEvent>> onShowing;
/*      */   private ObjectProperty<EventHandler<DialogEvent>> onShown;
/*      */   private ObjectProperty<EventHandler<DialogEvent>> onHiding;
/*      */   private ObjectProperty<EventHandler<DialogEvent>> onHidden;
/*      */   private ObjectProperty<EventHandler<DialogEvent>> onCloseRequest;
/*      */   
/*      */   public final void show() {
/*      */     Toolkit.getToolkit().checkFxUserThread();
/*      */     Event.fireEvent(this, new DialogEvent(this, (EventType)DialogEvent.DIALOG_SHOWING));
/*      */     if (Double.isNaN(getWidth()) && Double.isNaN(getHeight()))
/*      */       this.dialog.sizeToScene(); 
/*      */     this.dialog.show();
/*      */     Event.fireEvent(this, new DialogEvent(this, (EventType)DialogEvent.DIALOG_SHOWN));
/*      */   }
/*      */   
/*      */   public final Optional<R> showAndWait() {
/*      */     Toolkit.getToolkit().checkFxUserThread();
/*      */     if (!Toolkit.getToolkit().canStartNestedEventLoop())
/*      */       throw new IllegalStateException("showAndWait is not allowed during animation or layout processing"); 
/*      */     Event.fireEvent(this, new DialogEvent(this, (EventType)DialogEvent.DIALOG_SHOWING));
/*      */     if (Double.isNaN(getWidth()) && Double.isNaN(getHeight()))
/*      */       this.dialog.sizeToScene(); 
/*      */     Event.fireEvent(this, new DialogEvent(this, (EventType)DialogEvent.DIALOG_SHOWN));
/*      */     this.dialog.showAndWait();
/*      */     return Optional.ofNullable(getResult());
/*      */   }
/*      */   
/*      */   public final void close() {
/*      */     if (this.isClosing)
/*      */       return; 
/*      */     this.isClosing = true;
/*      */     R r = getResult();
/*      */     if (r == null && !this.dialog.requestPermissionToClose(this)) {
/*      */       this.isClosing = false;
/*      */       return;
/*      */     } 
/*      */     if (r == null) {
/*      */       ButtonType buttonType = null;
/*      */       for (ButtonType buttonType1 : getDialogPane().getButtonTypes()) {
/*      */         ButtonBar.ButtonData buttonData = buttonType1.getButtonData();
/*      */         if (buttonData == null)
/*      */           continue; 
/*      */         if (buttonData == ButtonBar.ButtonData.CANCEL_CLOSE) {
/*      */           buttonType = buttonType1;
/*      */           break;
/*      */         } 
/*      */         if (buttonData.isCancelButton())
/*      */           buttonType = buttonType1; 
/*      */       } 
/*      */       setResultAndClose(buttonType, false);
/*      */     } 
/*      */     Event.fireEvent(this, new DialogEvent(this, (EventType)DialogEvent.DIALOG_HIDING));
/*      */     DialogEvent dialogEvent = new DialogEvent(this, (EventType)DialogEvent.DIALOG_CLOSE_REQUEST);
/*      */     Event.fireEvent(this, dialogEvent);
/*      */     if (dialogEvent.isConsumed()) {
/*      */       this.isClosing = false;
/*      */       return;
/*      */     } 
/*      */     this.dialog.close();
/*      */     Event.fireEvent(this, new DialogEvent(this, (EventType)DialogEvent.DIALOG_HIDDEN));
/*      */     this.isClosing = false;
/*      */   }
/*      */   
/*      */   public final void hide() {
/*      */     close();
/*      */   }
/*      */   
/*      */   public final void initModality(Modality paramModality) {
/*      */     this.dialog.initModality(paramModality);
/*      */   }
/*      */   
/*      */   public final Modality getModality() {
/*      */     return this.dialog.getModality();
/*      */   }
/*      */   
/*      */   public final void initStyle(StageStyle paramStageStyle) {
/*      */     this.dialog.initStyle(paramStageStyle);
/*      */   }
/*      */   
/*      */   public final void initOwner(Window paramWindow) {
/*      */     this.dialog.initOwner(paramWindow);
/*      */   }
/*      */   
/*      */   public final Window getOwner() {
/*      */     return this.dialog.getOwner();
/*      */   }
/*      */   
/*      */   public final ObjectProperty<DialogPane> dialogPaneProperty() {
/*      */     return this.dialogPane;
/*      */   }
/*      */   
/*      */   public final DialogPane getDialogPane() {
/*      */     return this.dialogPane.get();
/*      */   }
/*      */   
/*      */   public final void setDialogPane(DialogPane paramDialogPane) {
/*      */     this.dialogPane.set(paramDialogPane);
/*      */   }
/*      */   
/*      */   public Dialog() {
/*  511 */     this.dialogPane = new SimpleObjectProperty<DialogPane>(this, "dialogPane", new DialogPane())
/*      */       {
/*      */         final InvalidationListener expandedListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         final InvalidationListener headerListener;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         WeakReference<DialogPane> dialogPaneRef;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected void invalidated() {
/*  531 */           DialogPane dialogPane1 = this.dialogPaneRef.get();
/*  532 */           if (dialogPane1 != null) {
/*      */             
/*  534 */             dialogPane1.expandedProperty().removeListener(this.expandedListener);
/*  535 */             dialogPane1.headerProperty().removeListener(this.headerListener);
/*  536 */             dialogPane1.headerTextProperty().removeListener(this.headerListener);
/*  537 */             dialogPane1.setDialog((Dialog<?>)null);
/*      */           } 
/*      */           
/*  540 */           DialogPane dialogPane2 = Dialog.this.getDialogPane();
/*      */           
/*  542 */           if (dialogPane2 != null) {
/*  543 */             dialogPane2.setDialog(Dialog.this);
/*      */ 
/*      */             
/*  546 */             dialogPane2.getButtonTypes().addListener(param1Change -> param1DialogPane.requestLayout());
/*      */ 
/*      */             
/*  549 */             dialogPane2.expandedProperty().addListener(this.expandedListener);
/*  550 */             dialogPane2.headerProperty().addListener(this.headerListener);
/*  551 */             dialogPane2.headerTextProperty().addListener(this.headerListener);
/*      */             
/*  553 */             Dialog.this.updatePseudoClassState();
/*  554 */             dialogPane2.requestLayout();
/*      */           } 
/*      */ 
/*      */           
/*  558 */           Dialog.this.dialog.setDialogPane(dialogPane2);
/*      */           
/*  560 */           this.dialogPaneRef = new WeakReference<>(dialogPane2);
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  669 */     this.resultProperty = new SimpleObjectProperty<R>() {
/*      */         protected void invalidated() {
/*  671 */           Dialog.this.close();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  697 */     this.resultConverterProperty = new SimpleObjectProperty<>(this, "resultConverter");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  895 */     this.eventHandlerManager = new EventHandlerManager(this); this.dialog = new HeavyweightDialog(this); setDialogPane(new DialogPane()); initModality(Modality.APPLICATION_MODAL);
/*      */   } public final StringProperty contentTextProperty() { return getDialogPane().contentTextProperty(); } public final String getContentText() { return getDialogPane().getContentText(); } public final void setContentText(String paramString) { getDialogPane().setContentText(paramString); } public final StringProperty headerTextProperty() { return getDialogPane().headerTextProperty(); } public final String getHeaderText() { return getDialogPane().getHeaderText(); } public final void setHeaderText(String paramString) { getDialogPane().setHeaderText(paramString); } public final ObjectProperty<Node> graphicProperty() { return getDialogPane().graphicProperty(); } public final Node getGraphic() { return getDialogPane().getGraphic(); } public final void setGraphic(Node paramNode) { getDialogPane().setGraphic(paramNode); }
/*      */   public final ObjectProperty<R> resultProperty() { return this.resultProperty; }
/*      */   public final R getResult() { return resultProperty().get(); }
/*  899 */   public EventDispatchChain buildEventDispatchChain(EventDispatchChain paramEventDispatchChain) { return paramEventDispatchChain.prepend(this.eventHandlerManager); }
/*      */   public final void setResult(R paramR) { resultProperty().set(paramR); }
/*      */   public final ObjectProperty<Callback<ButtonType, R>> resultConverterProperty() { return this.resultConverterProperty; }
/*      */   public final Callback<ButtonType, R> getResultConverter() { return resultConverterProperty().get(); }
/*      */   public final void setResultConverter(Callback<ButtonType, R> paramCallback) { resultConverterProperty().set(paramCallback); }
/*      */   public final ReadOnlyBooleanProperty showingProperty() { return this.dialog.showingProperty(); }
/*      */   public final boolean isShowing() { return showingProperty().get(); }
/*  906 */   public final BooleanProperty resizableProperty() { return this.dialog.resizableProperty(); } public final boolean isResizable() { return resizableProperty().get(); } public final void setResizable(boolean paramBoolean) { resizableProperty().set(paramBoolean); } public final ReadOnlyDoubleProperty widthProperty() { return this.dialog.widthProperty(); } public final double getWidth() { return widthProperty().get(); } public final void setWidth(double paramDouble) { this.dialog.setWidth(paramDouble); } public final void setOnShowing(EventHandler<DialogEvent> paramEventHandler) { onShowingProperty().set(paramEventHandler); }
/*      */   public final ReadOnlyDoubleProperty heightProperty() { return this.dialog.heightProperty(); }
/*  908 */   public final double getHeight() { return heightProperty().get(); } public final void setHeight(double paramDouble) { this.dialog.setHeight(paramDouble); } public final StringProperty titleProperty() { return this.dialog.titleProperty(); } public final String getTitle() { return this.dialog.titleProperty().get(); } public final void setTitle(String paramString) { this.dialog.titleProperty().set(paramString); } public final double getX() { return this.dialog.getX(); } public final void setX(double paramDouble) { this.dialog.setX(paramDouble); } public final ReadOnlyDoubleProperty xProperty() { return this.dialog.xProperty(); } public final double getY() { return this.dialog.getY(); } public final void setY(double paramDouble) { this.dialog.setY(paramDouble); } public final ReadOnlyDoubleProperty yProperty() { return this.dialog.yProperty(); } public final EventHandler<DialogEvent> getOnShowing() { return (this.onShowing == null) ? null : this.onShowing.get(); }
/*      */   
/*      */   public final ObjectProperty<EventHandler<DialogEvent>> onShowingProperty() {
/*  911 */     if (this.onShowing == null) {
/*  912 */       this.onShowing = new SimpleObjectProperty<EventHandler<DialogEvent>>(this, "onShowing") {
/*      */           protected void invalidated() {
/*  914 */             Dialog.this.eventHandlerManager.setEventHandler(DialogEvent.DIALOG_SHOWING, get());
/*      */           }
/*      */         };
/*      */     }
/*  918 */     return this.onShowing;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnShown(EventHandler<DialogEvent> paramEventHandler) {
/*  925 */     onShownProperty().set(paramEventHandler);
/*      */   } public final EventHandler<DialogEvent> getOnShown() {
/*  927 */     return (this.onShown == null) ? null : this.onShown.get();
/*      */   }
/*      */   public final ObjectProperty<EventHandler<DialogEvent>> onShownProperty() {
/*  930 */     if (this.onShown == null) {
/*  931 */       this.onShown = new SimpleObjectProperty<EventHandler<DialogEvent>>(this, "onShown") {
/*      */           protected void invalidated() {
/*  933 */             Dialog.this.eventHandlerManager.setEventHandler(DialogEvent.DIALOG_SHOWN, get());
/*      */           }
/*      */         };
/*      */     }
/*  937 */     return this.onShown;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnHiding(EventHandler<DialogEvent> paramEventHandler) {
/*  944 */     onHidingProperty().set(paramEventHandler);
/*      */   } public final EventHandler<DialogEvent> getOnHiding() {
/*  946 */     return (this.onHiding == null) ? null : this.onHiding.get();
/*      */   }
/*      */   public final ObjectProperty<EventHandler<DialogEvent>> onHidingProperty() {
/*  949 */     if (this.onHiding == null) {
/*  950 */       this.onHiding = new SimpleObjectProperty<EventHandler<DialogEvent>>(this, "onHiding") {
/*      */           protected void invalidated() {
/*  952 */             Dialog.this.eventHandlerManager.setEventHandler(DialogEvent.DIALOG_HIDING, get());
/*      */           }
/*      */         };
/*      */     }
/*  956 */     return this.onHiding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnHidden(EventHandler<DialogEvent> paramEventHandler) {
/*  966 */     onHiddenProperty().set(paramEventHandler);
/*      */   } public final EventHandler<DialogEvent> getOnHidden() {
/*  968 */     return (this.onHidden == null) ? null : this.onHidden.get();
/*      */   }
/*      */   public final ObjectProperty<EventHandler<DialogEvent>> onHiddenProperty() {
/*  971 */     if (this.onHidden == null) {
/*  972 */       this.onHidden = new SimpleObjectProperty<EventHandler<DialogEvent>>(this, "onHidden") {
/*      */           protected void invalidated() {
/*  974 */             Dialog.this.eventHandlerManager.setEventHandler(DialogEvent.DIALOG_HIDDEN, get());
/*      */           }
/*      */         };
/*      */     }
/*  978 */     return this.onHidden;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnCloseRequest(EventHandler<DialogEvent> paramEventHandler) {
/*  988 */     onCloseRequestProperty().set(paramEventHandler);
/*      */   }
/*      */   public final EventHandler<DialogEvent> getOnCloseRequest() {
/*  991 */     return (this.onCloseRequest != null) ? this.onCloseRequest.get() : null;
/*      */   }
/*      */   
/*      */   public final ObjectProperty<EventHandler<DialogEvent>> onCloseRequestProperty() {
/*  995 */     if (this.onCloseRequest == null) {
/*  996 */       this.onCloseRequest = new SimpleObjectProperty<EventHandler<DialogEvent>>(this, "onCloseRequest") {
/*      */           protected void invalidated() {
/*  998 */             Dialog.this.eventHandlerManager.setEventHandler(DialogEvent.DIALOG_CLOSE_REQUEST, get());
/*      */           }
/*      */         };
/*      */     }
/* 1002 */     return this.onCloseRequest;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setResultAndClose(ButtonType paramButtonType, boolean paramBoolean) {
/* 1018 */     Callback<ButtonType, R> callback = getResultConverter();
/*      */     
/* 1020 */     R r = getResult();
/* 1021 */     ButtonType buttonType = null;
/*      */     
/* 1023 */     if (callback == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1050 */       buttonType = paramButtonType;
/*      */     } else {
/* 1052 */       buttonType = (ButtonType)callback.call(paramButtonType);
/*      */     } 
/*      */     
/* 1055 */     setResult((R)buttonType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1061 */     if (paramBoolean && r == buttonType) {
/* 1062 */       close();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1075 */   private static final PseudoClass HEADER_PSEUDO_CLASS = PseudoClass.getPseudoClass("header");
/*      */   
/* 1077 */   private static final PseudoClass NO_HEADER_PSEUDO_CLASS = PseudoClass.getPseudoClass("no-header");
/*      */   
/*      */   private void updatePseudoClassState() {
/* 1080 */     DialogPane dialogPane = getDialogPane();
/* 1081 */     if (dialogPane != null) {
/* 1082 */       boolean bool = getDialogPane().hasHeader();
/* 1083 */       dialogPane.pseudoClassStateChanged(HEADER_PSEUDO_CLASS, bool);
/* 1084 */       dialogPane.pseudoClassStateChanged(NO_HEADER_PSEUDO_CLASS, !bool);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Dialog.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */