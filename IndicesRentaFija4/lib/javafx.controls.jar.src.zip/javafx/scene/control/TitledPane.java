/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.DefaultProperty;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.TitledPaneSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @DefaultProperty("content")
/*     */ public class TitledPane
/*     */   extends Labeled
/*     */ {
/*     */   private ObjectProperty<Node> content;
/*     */   private BooleanProperty expanded;
/*     */   private BooleanProperty animated;
/*     */   private BooleanProperty collapsible;
/*     */   private static final String DEFAULT_STYLE_CLASS = "titled-pane";
/*     */   
/*     */   public TitledPane() {
/* 152 */     this.expanded = new BooleanPropertyBase(true) {
/*     */         protected void invalidated() {
/* 154 */           boolean bool = get();
/* 155 */           TitledPane.this.pseudoClassStateChanged(TitledPane.PSEUDO_CLASS_EXPANDED, bool);
/* 156 */           TitledPane.this.pseudoClassStateChanged(TitledPane.PSEUDO_CLASS_COLLAPSED, !bool);
/* 157 */           TitledPane.this.notifyAccessibleAttributeChanged(AccessibleAttribute.EXPANDED);
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 162 */           return TitledPane.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 167 */           return "expanded";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     this.animated = new StyleableBooleanProperty(true)
/*     */       {
/*     */         public Object getBean()
/*     */         {
/* 197 */           return TitledPane.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 202 */           return "animated";
/*     */         }
/*     */ 
/*     */         
/*     */         public CssMetaData<TitledPane, Boolean> getCssMetaData() {
/* 207 */           return TitledPane.StyleableProperties.ANIMATED;
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     this.collapsible = new StyleableBooleanProperty(true)
/*     */       {
/*     */         public Object getBean()
/*     */         {
/* 239 */           return TitledPane.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 244 */           return "collapsible";
/*     */         }
/*     */         
/*     */         public CssMetaData<TitledPane, Boolean> getCssMetaData()
/*     */         {
/* 249 */           return TitledPane.StyleableProperties.COLLAPSIBLE; }
/*     */       };
/*     */     getStyleClass().setAll(new String[] { "titled-pane" });
/*     */     setAccessibleRole(AccessibleRole.TITLED_PANE);
/*     */     pseudoClassStateChanged(PSEUDO_CLASS_EXPANDED, true);
/*     */   }
/*     */   public TitledPane(String paramString, Node paramNode) { this();
/*     */     setText(paramString);
/*     */     setContent(paramNode); } public final void setContent(Node paramNode) {
/*     */     contentProperty().set(paramNode);
/* 259 */   } public final void setCollapsible(boolean paramBoolean) { collapsibleProperty().set(paramBoolean); }
/*     */   public final Node getContent() { return (this.content == null) ? null : this.content.get(); }
/*     */   public final ObjectProperty<Node> contentProperty() { if (this.content == null) this.content = new SimpleObjectProperty<>(this, "content");  return this.content; }
/*     */   public final void setExpanded(boolean paramBoolean) { expandedProperty().set(paramBoolean); }
/*     */   public final boolean isExpanded() { return this.expanded.get(); }
/*     */   public final BooleanProperty expandedProperty() { return this.expanded; }
/*     */   public final void setAnimated(boolean paramBoolean) { animatedProperty().set(paramBoolean); }
/* 266 */   public final boolean isAnimated() { return this.animated.get(); } public final BooleanProperty animatedProperty() { return this.animated; } public final boolean isCollapsible() { return this.collapsible.get(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BooleanProperty collapsibleProperty() {
/* 272 */     return this.collapsible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 282 */     return (Skin<?>)new TitledPaneSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 294 */   private static final PseudoClass PSEUDO_CLASS_EXPANDED = PseudoClass.getPseudoClass("expanded");
/*     */   
/* 296 */   private static final PseudoClass PSEUDO_CLASS_COLLAPSED = PseudoClass.getPseudoClass("collapsed");
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 301 */     private static final CssMetaData<TitledPane, Boolean> COLLAPSIBLE = new CssMetaData<TitledPane, Boolean>("-fx-collapsible", 
/*     */         
/* 303 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(TitledPane param2TitledPane)
/*     */         {
/* 307 */           return (param2TitledPane.collapsible == null || !param2TitledPane.collapsible.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(TitledPane param2TitledPane) {
/* 312 */           return (StyleableProperty<Boolean>)param2TitledPane.collapsibleProperty();
/*     */         }
/*     */       };
/*     */     
/* 316 */     private static final CssMetaData<TitledPane, Boolean> ANIMATED = new CssMetaData<TitledPane, Boolean>("-fx-animated", 
/*     */         
/* 318 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(TitledPane param2TitledPane)
/*     */         {
/* 322 */           return (param2TitledPane.animated == null || !param2TitledPane.animated.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(TitledPane param2TitledPane) {
/* 327 */           return (StyleableProperty<Boolean>)param2TitledPane.animatedProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 334 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Labeled.getClassCssMetaData());
/* 335 */       arrayList.add(COLLAPSIBLE);
/* 336 */       arrayList.add(ANIMATED);
/* 337 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 347 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 356 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */   
/*     */   public Orientation getContentBias() {
/* 361 */     Node node = getContent();
/* 362 */     return (node == null) ? super.getContentBias() : node.getContentBias();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*     */     String str;
/* 375 */     switch (paramAccessibleAttribute) {
/*     */       case EXPAND:
/* 377 */         str = getAccessibleText();
/* 378 */         if (str != null && !str.isEmpty()) return str; 
/* 379 */         return getText();
/*     */       case COLLAPSE:
/* 381 */         return Boolean.valueOf(isExpanded());
/* 382 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/* 389 */     switch (paramAccessibleAction) { case EXPAND:
/* 390 */         setExpanded(true); return;
/* 391 */       case COLLAPSE: setExpanded(false); return; }
/* 392 */      super.executeAccessibleAction(paramAccessibleAction, new Object[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TitledPane.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */