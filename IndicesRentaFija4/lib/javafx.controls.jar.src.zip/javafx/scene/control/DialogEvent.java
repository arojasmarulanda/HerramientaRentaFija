/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.event.EventType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DialogEvent
/*     */   extends Event
/*     */ {
/*     */   private static final long serialVersionUID = 20140716L;
/*  54 */   public static final EventType<DialogEvent> ANY = (EventType)new EventType<>(Event.ANY, "DIALOG");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final EventType<DialogEvent> DIALOG_SHOWING = new EventType<>(ANY, "DIALOG_SHOWING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final EventType<DialogEvent> DIALOG_SHOWN = new EventType<>(ANY, "DIALOG_SHOWN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static final EventType<DialogEvent> DIALOG_HIDING = new EventType<>(ANY, "DIALOG_HIDING");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final EventType<DialogEvent> DIALOG_HIDDEN = new EventType<>(ANY, "DIALOG_HIDDEN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public static final EventType<DialogEvent> DIALOG_CLOSE_REQUEST = new EventType<>(ANY, "DIALOG_CLOSE_REQUEST");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DialogEvent(@NamedArg("source") Dialog<?> paramDialog, @NamedArg("eventType") EventType<? extends Event> paramEventType) {
/*  99 */     super(paramDialog, paramDialog, paramEventType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 107 */     StringBuilder stringBuilder = new StringBuilder("DialogEvent [");
/*     */     
/* 109 */     stringBuilder.append("source = ").append(getSource());
/* 110 */     stringBuilder.append(", target = ").append(getTarget());
/* 111 */     stringBuilder.append(", eventType = ").append(getEventType());
/* 112 */     stringBuilder.append(", consumed = ").append(isConsumed());
/*     */     
/* 114 */     return stringBuilder.append("]").toString();
/*     */   }
/*     */   
/*     */   public DialogEvent copyFor(Object paramObject, EventTarget paramEventTarget) {
/* 118 */     return (DialogEvent)super.copyFor(paramObject, paramEventTarget);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DialogEvent copyFor(Object paramObject, EventTarget paramEventTarget, EventType<DialogEvent> paramEventType) {
/* 129 */     DialogEvent dialogEvent = copyFor(paramObject, paramEventTarget);
/* 130 */     dialogEvent.eventType = (EventType)paramEventType;
/* 131 */     return dialogEvent;
/*     */   }
/*     */ 
/*     */   
/*     */   public EventType<DialogEvent> getEventType() {
/* 136 */     return (EventType)super.getEventType();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\DialogEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */