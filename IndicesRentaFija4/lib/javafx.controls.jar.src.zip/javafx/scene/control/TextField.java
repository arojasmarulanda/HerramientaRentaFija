/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.binding.ExpressionHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableIntegerProperty;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.EnumConverter;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.TextFieldSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextField
/*     */   extends TextInputControl
/*     */ {
/*     */   public static final int DEFAULT_PREF_COLUMN_COUNT = 12;
/*     */   private IntegerProperty prefColumnCount;
/*     */   private ObjectProperty<EventHandler<ActionEvent>> onAction;
/*     */   private ObjectProperty<Pos> alignment;
/*     */   
/*     */   private static final class TextFieldContent
/*     */     implements TextInputControl.Content
/*     */   {
/*  75 */     private ExpressionHelper<String> helper = null;
/*  76 */     private StringBuilder characters = new StringBuilder();
/*     */     
/*     */     public String get(int param1Int1, int param1Int2) {
/*  79 */       return this.characters.substring(param1Int1, param1Int2);
/*     */     }
/*     */     
/*     */     public void insert(int param1Int, String param1String, boolean param1Boolean) {
/*  83 */       param1String = TextInputControl.filterInput(param1String, true, true);
/*  84 */       if (!param1String.isEmpty()) {
/*  85 */         this.characters.insert(param1Int, param1String);
/*  86 */         if (param1Boolean) {
/*  87 */           ExpressionHelper.fireValueChangedEvent(this.helper);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public void delete(int param1Int1, int param1Int2, boolean param1Boolean) {
/*  93 */       if (param1Int2 > param1Int1) {
/*  94 */         this.characters.delete(param1Int1, param1Int2);
/*  95 */         if (param1Boolean) {
/*  96 */           ExpressionHelper.fireValueChangedEvent(this.helper);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public int length() {
/* 102 */       return this.characters.length();
/*     */     }
/*     */     
/*     */     public String get() {
/* 106 */       return this.characters.toString();
/*     */     }
/*     */     
/*     */     public void addListener(ChangeListener<? super String> param1ChangeListener) {
/* 110 */       this.helper = ExpressionHelper.addListener(this.helper, this, param1ChangeListener);
/*     */     }
/*     */     
/*     */     public void removeListener(ChangeListener<? super String> param1ChangeListener) {
/* 114 */       this.helper = ExpressionHelper.removeListener(this.helper, param1ChangeListener);
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 118 */       return get();
/*     */     }
/*     */     
/*     */     public void addListener(InvalidationListener param1InvalidationListener) {
/* 122 */       this.helper = ExpressionHelper.addListener(this.helper, this, param1InvalidationListener);
/*     */     }
/*     */     
/*     */     public void removeListener(InvalidationListener param1InvalidationListener) {
/* 126 */       this.helper = ExpressionHelper.removeListener(this.helper, param1InvalidationListener);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private TextFieldContent() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextField() {
/* 139 */     this("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextField(String paramString) {
/* 148 */     super(new TextFieldContent(null));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     this.prefColumnCount = new StyleableIntegerProperty(12)
/*     */       {
/* 175 */         private int oldValue = get();
/*     */ 
/*     */         
/*     */         protected void invalidated() {
/* 179 */           int i = get();
/* 180 */           if (i < 0) {
/* 181 */             if (isBound()) {
/* 182 */               unbind();
/*     */             }
/* 184 */             set(this.oldValue);
/* 185 */             throw new IllegalArgumentException("value cannot be negative.");
/*     */           } 
/* 187 */           this.oldValue = i;
/*     */         }
/*     */         
/*     */         public CssMetaData<TextField, Number> getCssMetaData() {
/* 191 */           return TextField.StyleableProperties.PREF_COLUMN_COUNT;
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 196 */           return TextField.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 201 */           return "prefColumnCount";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     this.onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>()
/*     */       {
/*     */         protected void invalidated() {
/* 218 */           TextField.this.setEventHandler((EventType)ActionEvent.ACTION, (EventHandler)get());
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 223 */           return TextField.this;
/*     */         }
/*     */         
/*     */         public String getName()
/*     */         {
/* 228 */           return "onAction"; }
/*     */       }; getStyleClass().add("text-field"); setAccessibleRole(AccessibleRole.TEXT_FIELD);
/*     */     setText(paramString);
/* 231 */   } public CharSequence getCharacters() { return ((TextFieldContent)getContent()).characters; } public final IntegerProperty prefColumnCountProperty() { return this.prefColumnCount; } public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() { return this.onAction; }
/* 232 */   public final int getPrefColumnCount() { return this.prefColumnCount.getValue().intValue(); } public final void setPrefColumnCount(int paramInt) { this.prefColumnCount.setValue(Integer.valueOf(paramInt)); } public final EventHandler<ActionEvent> getOnAction() { return onActionProperty().get(); } public final void setOnAction(EventHandler<ActionEvent> paramEventHandler) {
/* 233 */     onActionProperty().set(paramEventHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectProperty<Pos> alignmentProperty() {
/* 242 */     if (this.alignment == null) {
/* 243 */       this.alignment = new StyleableObjectProperty<Pos>(Pos.CENTER_LEFT)
/*     */         {
/*     */           public CssMetaData<TextField, Pos> getCssMetaData() {
/* 246 */             return TextField.StyleableProperties.ALIGNMENT;
/*     */           }
/*     */           
/*     */           public Object getBean() {
/* 250 */             return TextField.this;
/*     */           }
/*     */           
/*     */           public String getName() {
/* 254 */             return "alignment";
/*     */           }
/*     */         };
/*     */     }
/* 258 */     return this.alignment;
/*     */   }
/*     */   
/* 261 */   public final void setAlignment(Pos paramPos) { alignmentProperty().set(paramPos); } public final Pos getAlignment() {
/* 262 */     return (this.alignment == null) ? Pos.CENTER_LEFT : this.alignment.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 272 */     return (Skin<?>)new TextFieldSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 282 */     private static final CssMetaData<TextField, Pos> ALIGNMENT = new CssMetaData<TextField, Pos>("-fx-alignment", (StyleConverter)new EnumConverter(Pos.class), Pos.CENTER_LEFT)
/*     */       {
/*     */         
/*     */         public boolean isSettable(TextField param2TextField)
/*     */         {
/* 287 */           return (param2TextField.alignment == null || !param2TextField.alignment.isBound());
/*     */         }
/*     */         
/*     */         public StyleableProperty<Pos> getStyleableProperty(TextField param2TextField) {
/* 291 */           return (StyleableProperty<Pos>)param2TextField.alignmentProperty();
/*     */         }
/*     */       };
/*     */     
/* 295 */     private static final CssMetaData<TextField, Number> PREF_COLUMN_COUNT = new CssMetaData<TextField, Number>("-fx-pref-column-count", 
/*     */         
/* 297 */         SizeConverter.getInstance(), Integer.valueOf(12))
/*     */       {
/*     */         public boolean isSettable(TextField param2TextField)
/*     */         {
/* 301 */           return (param2TextField.prefColumnCount == null || !param2TextField.prefColumnCount.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(TextField param2TextField) {
/* 306 */           return (StyleableProperty<Number>)param2TextField.prefColumnCountProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 313 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(TextInputControl.getClassCssMetaData());
/* 314 */       arrayList.add(ALIGNMENT);
/* 315 */       arrayList.add(PREF_COLUMN_COUNT);
/* 316 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 326 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getControlCssMetaData() {
/* 335 */     return getClassCssMetaData();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TextField.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */