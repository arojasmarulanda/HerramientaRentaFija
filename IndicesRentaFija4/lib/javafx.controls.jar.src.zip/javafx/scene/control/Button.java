/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.ButtonSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Button
/*     */   extends ButtonBase
/*     */ {
/*     */   private BooleanProperty defaultButton;
/*     */   private BooleanProperty cancelButton;
/*     */   private static final String DEFAULT_STYLE_CLASS = "button";
/*     */   
/*     */   public Button() {
/*  87 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Button(String paramString) {
/*  96 */     super(paramString);
/*  97 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Button(String paramString, Node paramNode) {
/* 107 */     super(paramString, paramNode);
/* 108 */     initialize();
/*     */   }
/*     */   
/*     */   private void initialize() {
/* 112 */     getStyleClass().setAll(new String[] { "button" });
/* 113 */     setAccessibleRole(AccessibleRole.BUTTON);
/* 114 */     setMnemonicParsing(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setDefaultButton(boolean paramBoolean) {
/* 129 */     defaultButtonProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isDefaultButton() {
/* 132 */     return (this.defaultButton == null) ? false : this.defaultButton.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty defaultButtonProperty() {
/* 136 */     if (this.defaultButton == null) {
/* 137 */       this.defaultButton = new BooleanPropertyBase(false) {
/*     */           protected void invalidated() {
/* 139 */             Button.this.pseudoClassStateChanged(Button.PSEUDO_CLASS_DEFAULT, get());
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 144 */             return Button.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 149 */             return "defaultButton";
/*     */           }
/*     */         };
/*     */     }
/* 153 */     return this.defaultButton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCancelButton(boolean paramBoolean) {
/* 163 */     cancelButtonProperty().set(paramBoolean);
/*     */   }
/*     */   public final boolean isCancelButton() {
/* 166 */     return (this.cancelButton == null) ? false : this.cancelButton.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty cancelButtonProperty() {
/* 170 */     if (this.cancelButton == null) {
/* 171 */       this.cancelButton = new BooleanPropertyBase(false) {
/*     */           protected void invalidated() {
/* 173 */             Button.this.pseudoClassStateChanged(Button.PSEUDO_CLASS_CANCEL, get());
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 178 */             return Button.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 183 */             return "cancelButton";
/*     */           }
/*     */         };
/*     */     }
/* 187 */     return this.cancelButton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fire() {
/* 199 */     if (!isDisabled()) {
/* 200 */       fireEvent(new ActionEvent());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 206 */     return (Skin<?>)new ButtonSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   private static final PseudoClass PSEUDO_CLASS_DEFAULT = PseudoClass.getPseudoClass("default");
/*     */   
/* 227 */   private static final PseudoClass PSEUDO_CLASS_CANCEL = PseudoClass.getPseudoClass("cancel");
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\Button.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */