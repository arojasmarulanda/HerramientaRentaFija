/*    */ package javafx.scene.control;
/*    */ 
/*    */ import javafx.scene.AccessibleAttribute;
/*    */ import javafx.scene.AccessibleRole;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PasswordField
/*    */   extends TextField
/*    */ {
/*    */   public PasswordField() {
/* 41 */     getStyleClass().add("password-field");
/* 42 */     setAccessibleRole(AccessibleRole.PASSWORD_FIELD);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void cut() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void copy() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 75 */     switch (paramAccessibleAttribute) { case TEXT:
/* 76 */         return null; }
/* 77 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\PasswordField.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */