/*     */ package javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerWrapper;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FocusModel<T>
/*     */ {
/*     */   private ReadOnlyIntegerWrapper focusedIndex;
/*     */   private ReadOnlyObjectWrapper<T> focusedItem;
/*     */   
/*     */   public final ReadOnlyIntegerProperty focusedIndexProperty() {
/*     */     return this.focusedIndex.getReadOnlyProperty();
/*     */   }
/*     */   
/*     */   public final int getFocusedIndex() {
/*     */     return this.focusedIndex.get();
/*     */   }
/*     */   
/*     */   final void setFocusedIndex(int paramInt) {
/*     */     this.focusedIndex.set(paramInt);
/*     */   }
/*     */   
/*     */   public FocusModel() {
/*  71 */     this.focusedIndex = new ReadOnlyIntegerWrapper(this, "focusedIndex", -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.focusedItem = new ReadOnlyObjectWrapper<>(this, "focusedItem");
/*  86 */     focusedIndexProperty().addListener(paramObservable -> setFocusedItem(getModelItem(getFocusedIndex()))); } public final ReadOnlyObjectProperty<T> focusedItemProperty() { return this.focusedItem.getReadOnlyProperty(); }
/*  87 */   public final T getFocusedItem() { return focusedItemProperty().get(); } final void setFocusedItem(T paramT) {
/*  88 */     this.focusedItem.set(paramT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFocused(int paramInt) {
/* 129 */     if (paramInt < 0 || paramInt >= getItemCount()) return false;
/*     */     
/* 131 */     return (getFocusedIndex() == paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focus(int paramInt) {
/* 143 */     if (paramInt < 0 || paramInt >= getItemCount()) {
/* 144 */       setFocusedIndex(-1);
/*     */     } else {
/* 146 */       int i = getFocusedIndex();
/* 147 */       setFocusedIndex(paramInt);
/*     */       
/* 149 */       if (i == paramInt)
/*     */       {
/* 151 */         setFocusedItem(getModelItem(paramInt));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusPrevious() {
/* 162 */     if (getFocusedIndex() == -1) {
/* 163 */       focus(0);
/* 164 */     } else if (getFocusedIndex() > 0) {
/* 165 */       focus(getFocusedIndex() - 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusNext() {
/* 175 */     if (getFocusedIndex() == -1) {
/* 176 */       focus(0);
/* 177 */     } else if (getFocusedIndex() != getItemCount() - 1) {
/* 178 */       focus(getFocusedIndex() + 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract int getItemCount();
/*     */   
/*     */   protected abstract T getModelItem(int paramInt);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\FocusModel.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */