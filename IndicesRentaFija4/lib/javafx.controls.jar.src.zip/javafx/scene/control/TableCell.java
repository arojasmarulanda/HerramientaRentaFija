/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Collection;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.Event;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.control.skin.TableCellSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableCell<S, T>
/*     */   extends IndexedCell<T>
/*     */ {
/*     */   boolean lockItemOnEdit;
/*     */   private boolean itemDirty;
/*     */   private ListChangeListener<TablePosition> selectedListener;
/*     */   private final InvalidationListener focusedListener;
/*     */   private final InvalidationListener tableRowUpdateObserver;
/*     */   private final InvalidationListener editingListener;
/*     */   private ListChangeListener<TableColumn<S, ?>> visibleLeafColumnsListener;
/*     */   private ListChangeListener<String> columnStyleClassListener;
/*     */   private final InvalidationListener columnStyleListener;
/*     */   private final InvalidationListener columnIdListener;
/*     */   private final WeakListChangeListener<TablePosition> weakSelectedListener;
/*     */   private final WeakInvalidationListener weakFocusedListener;
/*     */   private final WeakInvalidationListener weaktableRowUpdateObserver;
/*     */   private final WeakInvalidationListener weakEditingListener;
/*     */   private final WeakInvalidationListener weakColumnStyleListener;
/*     */   private final WeakInvalidationListener weakColumnIdListener;
/*     */   private final WeakListChangeListener<TableColumn<S, ?>> weakVisibleLeafColumnsListener;
/*     */   private final WeakListChangeListener<String> weakColumnStyleClassListener;
/*     */   private ReadOnlyObjectWrapper<TableColumn<S, T>> tableColumn;
/*     */   private ReadOnlyObjectWrapper<TableView<S>> tableView;
/*     */   private ReadOnlyObjectWrapper<TableRow<S>> tableRow;
/*     */   private boolean isLastVisibleColumn;
/*     */   private int columnIndex;
/*     */   private boolean updateEditingIndex;
/*     */   private ObservableValue<T> currentObservableValue;
/*     */   private boolean isFirstRun;
/*     */   private WeakReference<S> oldRowItemRef;
/*     */   private static final String DEFAULT_STYLE_CLASS = "table-cell";
/*     */   
/*     */   public TableCell() {
/* 104 */     this.lockItemOnEdit = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     this.itemDirty = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     this.selectedListener = (paramChange -> {
/*     */         while (paramChange.next()) {
/*     */           if (paramChange.wasAdded() || paramChange.wasRemoved()) {
/*     */             updateSelection();
/*     */           }
/*     */         } 
/*     */       });
/*     */ 
/*     */     
/* 130 */     this.focusedListener = (paramObservable -> updateFocus());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     this.tableRowUpdateObserver = (paramObservable -> {
/*     */         this.itemDirty = true;
/*     */         
/*     */         requestLayout();
/*     */       });
/* 140 */     this.editingListener = (paramObservable -> updateEditing());
/*     */ 
/*     */ 
/*     */     
/* 144 */     this.visibleLeafColumnsListener = (paramChange -> updateColumnIndex());
/*     */ 
/*     */ 
/*     */     
/* 148 */     this.columnStyleClassListener = (paramChange -> {
/*     */         while (paramChange.next()) {
/*     */           if (paramChange.wasRemoved()) {
/*     */             getStyleClass().removeAll(paramChange.getRemoved());
/*     */           }
/*     */           
/*     */           if (paramChange.wasAdded()) {
/*     */             getStyleClass().addAll((Collection)paramChange.getAddedSubList());
/*     */           }
/*     */         } 
/*     */       });
/*     */     
/* 160 */     this.columnStyleListener = (paramObservable -> {
/*     */         if (getTableColumn() != null) {
/*     */           possiblySetStyle(getTableColumn().getStyle());
/*     */         }
/*     */       });
/*     */     
/* 166 */     this.columnIdListener = (paramObservable -> {
/*     */         if (getTableColumn() != null) {
/*     */           possiblySetId(getTableColumn().getId());
/*     */         }
/*     */       });
/*     */     
/* 172 */     this.weakSelectedListener = new WeakListChangeListener<>(this.selectedListener);
/*     */     
/* 174 */     this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
/*     */     
/* 176 */     this.weaktableRowUpdateObserver = new WeakInvalidationListener(this.tableRowUpdateObserver);
/*     */     
/* 178 */     this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
/*     */     
/* 180 */     this.weakColumnStyleListener = new WeakInvalidationListener(this.columnStyleListener);
/*     */     
/* 182 */     this.weakColumnIdListener = new WeakInvalidationListener(this.columnIdListener);
/*     */     
/* 184 */     this.weakVisibleLeafColumnsListener = new WeakListChangeListener<>(this.visibleLeafColumnsListener);
/*     */     
/* 186 */     this.weakColumnStyleClassListener = new WeakListChangeListener<>(this.columnStyleClassListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     this.tableColumn = (ReadOnlyObjectWrapper)new ReadOnlyObjectWrapper<TableColumn<S, TableColumn<S, T>>>() {
/*     */         protected void invalidated() {
/* 199 */           TableCell.this.updateColumnIndex();
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 203 */           return TableCell.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 207 */           return "tableColumn";
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 289 */     this.tableRow = new ReadOnlyObjectWrapper<>(this, "tableRow");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 477 */     this.isLastVisibleColumn = false;
/* 478 */     this.columnIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 571 */     this.updateEditingIndex = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 591 */     this.currentObservableValue = null;
/*     */     
/* 593 */     this.isFirstRun = true;
/*     */     getStyleClass().addAll(new String[] { "table-cell" });
/*     */     setAccessibleRole(AccessibleRole.TABLE_CELL);
/*     */     updateColumnIndex();
/*     */   } public final ReadOnlyObjectProperty<TableColumn<S, T>> tableColumnProperty() {
/*     */     return this.tableColumn.getReadOnlyProperty();
/*     */   } private void setTableColumn(TableColumn<S, T> paramTableColumn) {
/*     */     this.tableColumn.set(paramTableColumn);
/*     */   }
/*     */   public final TableColumn<S, T> getTableColumn() {
/*     */     return this.tableColumn.get();
/*     */   }
/*     */   private void setTableView(TableView<S> paramTableView) {
/*     */     tableViewPropertyImpl().set(paramTableView);
/*     */   }
/*     */   public final TableView<S> getTableView() {
/*     */     return (this.tableView == null) ? null : this.tableView.get();
/*     */   }
/*     */   public final ReadOnlyObjectProperty<TableView<S>> tableViewProperty() {
/*     */     return tableViewPropertyImpl().getReadOnlyProperty();
/*     */   }
/*     */   private ReadOnlyObjectWrapper<TableView<S>> tableViewPropertyImpl() {
/*     */     if (this.tableView == null)
/*     */       this.tableView = new ReadOnlyObjectWrapper<TableView<S>>() { private WeakReference<TableView<S>> weakTableViewRef;
/*     */           protected void invalidated() {
/*     */             if (this.weakTableViewRef != null)
/*     */               TableCell.this.cleanUpTableViewListeners(this.weakTableViewRef.get()); 
/*     */             if (get() != null) {
/*     */               TableView.TableViewSelectionModel<S> tableViewSelectionModel = get().getSelectionModel();
/*     */               if (tableViewSelectionModel != null)
/*     */                 tableViewSelectionModel.getSelectedCells().addListener(TableCell.this.weakSelectedListener); 
/*     */               TableView.TableViewFocusModel<S> tableViewFocusModel = get().getFocusModel();
/*     */               if (tableViewFocusModel != null)
/*     */                 tableViewFocusModel.focusedCellProperty().addListener(TableCell.this.weakFocusedListener); 
/*     */               get().editingCellProperty().addListener(TableCell.this.weakEditingListener);
/*     */               get().getVisibleLeafColumns().addListener(TableCell.this.weakVisibleLeafColumnsListener);
/*     */               this.weakTableViewRef = new WeakReference<>(get());
/*     */             } 
/*     */             TableCell.this.updateColumnIndex();
/*     */           }
/*     */           public Object getBean() {
/*     */             return TableCell.this;
/*     */           }
/*     */           public String getName() {
/*     */             return "tableView";
/*     */           } }
/*     */         ; 
/*     */     return this.tableView;
/*     */   }
/*     */   private void setTableRow(TableRow<S> paramTableRow) {
/*     */     this.tableRow.set(paramTableRow);
/*     */   }
/*     */   public final TableRow<S> getTableRow() {
/*     */     return this.tableRow.get();
/*     */   }
/*     */   public final ReadOnlyObjectProperty<TableRow<S>> tableRowProperty() {
/*     */     return this.tableRow;
/*     */   }
/*     */   public void startEdit() {
/*     */     TableView<S> tableView = getTableView();
/*     */     TableColumn<S, T> tableColumn = getTableColumn();
/*     */     if (!isEditable() || (tableView != null && !tableView.isEditable()) || (tableColumn != null && !getTableColumn().isEditable()))
/*     */       return; 
/*     */     if (!this.lockItemOnEdit)
/*     */       updateItem(-1); 
/*     */     super.startEdit();
/*     */     if (tableColumn != null) {
/*     */       TableColumn.CellEditEvent<S, Object> cellEditEvent = new TableColumn.CellEditEvent<>(tableView, tableView.getEditingCell(), TableColumn.editStartEvent(), null);
/*     */       Event.fireEvent(tableColumn, cellEditEvent);
/*     */     } 
/*     */   }
/*     */   public void commitEdit(T paramT) {
/*     */     if (!isEditing())
/*     */       return; 
/*     */     TableView<S> tableView = getTableView();
/*     */     if (tableView != null) {
/*     */       TableColumn.CellEditEvent<S, T> cellEditEvent = new TableColumn.CellEditEvent<>(tableView, (TablePosition)tableView.getEditingCell(), TableColumn.editCommitEvent(), paramT);
/*     */       Event.fireEvent(getTableColumn(), cellEditEvent);
/*     */     } 
/*     */     super.commitEdit(paramT);
/*     */     updateItem(paramT, false);
/*     */     if (tableView != null) {
/*     */       tableView.edit(-1, null);
/*     */       ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(tableView);
/*     */     } 
/*     */   }
/* 679 */   protected void layoutChildren() { if (this.itemDirty) {
/* 680 */       updateItem(-1);
/* 681 */       this.itemDirty = false;
/*     */     } 
/* 683 */     super.layoutChildren(); } public void cancelEdit() { if (!isEditing())
/*     */       return;  TableView<S> tableView = getTableView(); super.cancelEdit(); if (tableView != null) {
/*     */       TablePosition<S, ?> tablePosition = tableView.getEditingCell(); if (this.updateEditingIndex)
/*     */         tableView.edit(-1, null);  ControlUtils.requestFocusOnControlOnlyIfCurrentFocusOwnerIsChild(tableView); TableColumn.CellEditEvent<S, Object> cellEditEvent = new TableColumn.CellEditEvent<>(tableView, tablePosition, TableColumn.editCancelEvent(), null); Event.fireEvent(getTableColumn(), cellEditEvent);
/*     */     }  }
/*     */   public void updateSelected(boolean paramBoolean) { if (getTableRow() == null || getTableRow().isEmpty())
/*     */       return;  setSelected(paramBoolean); }
/*     */   protected Skin<?> createDefaultSkin() { return (Skin<?>)new TableCellSkin(this); }
/*     */   private void cleanUpTableViewListeners(TableView<S> paramTableView) { if (paramTableView != null) {
/*     */       TableView.TableViewSelectionModel<S> tableViewSelectionModel = paramTableView.getSelectionModel(); if (tableViewSelectionModel != null)
/*     */         tableViewSelectionModel.getSelectedCells().removeListener(this.weakSelectedListener);  TableView.TableViewFocusModel<S> tableViewFocusModel = paramTableView.getFocusModel(); if (tableViewFocusModel != null)
/*     */         tableViewFocusModel.focusedCellProperty().removeListener(this.weakFocusedListener);  paramTableView.editingCellProperty().removeListener(this.weakEditingListener); paramTableView.getVisibleLeafColumns().removeListener(this.weakVisibleLeafColumnsListener);
/*     */     }  }
/*     */   void indexChanged(int paramInt1, int paramInt2) { super.indexChanged(paramInt1, paramInt2); updateItem(paramInt1);
/*     */     updateSelection();
/*     */     updateFocus();
/*     */     updateEditing(); }
/*     */   private void updateColumnIndex() { TableView<S> tableView = getTableView();
/*     */     TableColumn<S, T> tableColumn = getTableColumn();
/*     */     this.columnIndex = (tableView == null || tableColumn == null) ? -1 : tableView.getVisibleLeafIndex(tableColumn);
/*     */     this.isLastVisibleColumn = (getTableColumn() != null && this.columnIndex != -1 && this.columnIndex == getTableView().getVisibleLeafColumns().size() - 1);
/*     */     pseudoClassStateChanged(PSEUDO_CLASS_LAST_VISIBLE, this.isLastVisibleColumn); }
/* 705 */   public final void updateTableView(TableView<S> paramTableView) { setTableView(paramTableView); }
/*     */   private void updateSelection() { if (isEmpty())
/*     */       return;  boolean bool1 = isSelected(); if (!isInCellSelectionMode()) {
/*     */       if (bool1)
/*     */         updateSelected(false);  return;
/*     */     }  TableView<S> tableView = getTableView(); if (getIndex() == -1 || tableView == null)
/*     */       return;  TableView.TableViewSelectionModel<S> tableViewSelectionModel = tableView.getSelectionModel(); if (tableViewSelectionModel == null) {
/*     */       updateSelected(false); return;
/*     */     } 
/*     */     boolean bool2 = tableViewSelectionModel.isSelected(getIndex(), getTableColumn());
/*     */     if (bool1 == bool2)
/*     */       return; 
/* 717 */     updateSelected(bool2); } public final void updateTableRow(TableRow<S> paramTableRow) { setTableRow(paramTableRow); }
/*     */   private void updateFocus() { boolean bool = isFocused(); if (!isInCellSelectionMode()) { if (bool)
/*     */         setFocused(false);  return; }
/*     */      TableView<S> tableView = getTableView(); TableRow<S> tableRow = getTableRow(); int i = getIndex(); if (i == -1 || tableView == null || tableRow == null)
/*     */       return;  TableView.TableViewFocusModel<S> tableViewFocusModel = tableView.getFocusModel(); if (tableViewFocusModel == null) { setFocused(false); return; }
/*     */      setFocused(tableViewFocusModel.isFocused(i, getTableColumn())); }
/*     */   private void updateEditing() { if (getIndex() == -1 || getTableView() == null)
/*     */       return;  TablePosition<S, ?> tablePosition = getTableView().getEditingCell(); boolean bool = match(tablePosition); if (bool && !isEditing()) { startEdit(); }
/*     */     else if (!bool && isEditing()) { this.updateEditingIndex = false; cancelEdit(); this.updateEditingIndex = true; }
/*     */      }
/*     */   private boolean match(TablePosition<S, ?> paramTablePosition) { return (paramTablePosition != null && paramTablePosition.getRow() == getIndex() && paramTablePosition.getTableColumn() == getTableColumn()); }
/*     */   private boolean isInCellSelectionMode() { TableView<S> tableView = getTableView(); if (tableView == null)
/*     */       return false;  TableView.TableViewSelectionModel<S> tableViewSelectionModel = tableView.getSelectionModel(); return (tableViewSelectionModel != null && tableViewSelectionModel.isCellSelectionEnabled()); }
/*     */   private void updateItem(int paramInt) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   4: ifnull -> 20
/*     */     //   7: aload_0
/*     */     //   8: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   11: aload_0
/*     */     //   12: getfield weaktableRowUpdateObserver : Ljavafx/beans/WeakInvalidationListener;
/*     */     //   15: invokeinterface removeListener : (Ljavafx/beans/InvalidationListener;)V
/*     */     //   20: aload_0
/*     */     //   21: invokevirtual getTableView : ()Ljavafx/scene/control/TableView;
/*     */     //   24: astore_2
/*     */     //   25: aload_2
/*     */     //   26: ifnonnull -> 35
/*     */     //   29: invokestatic emptyObservableList : ()Ljavafx/collections/ObservableList;
/*     */     //   32: goto -> 39
/*     */     //   35: aload_2
/*     */     //   36: invokevirtual getItems : ()Ljavafx/collections/ObservableList;
/*     */     //   39: astore_3
/*     */     //   40: aload_0
/*     */     //   41: invokevirtual getTableColumn : ()Ljavafx/scene/control/TableColumn;
/*     */     //   44: astore #4
/*     */     //   46: aload_3
/*     */     //   47: ifnonnull -> 54
/*     */     //   50: iconst_m1
/*     */     //   51: goto -> 60
/*     */     //   54: aload_3
/*     */     //   55: invokeinterface size : ()I
/*     */     //   60: istore #5
/*     */     //   62: aload_0
/*     */     //   63: invokevirtual getIndex : ()I
/*     */     //   66: istore #6
/*     */     //   68: aload_0
/*     */     //   69: invokevirtual isEmpty : ()Z
/*     */     //   72: istore #7
/*     */     //   74: aload_0
/*     */     //   75: invokevirtual getItem : ()Ljava/lang/Object;
/*     */     //   78: astore #8
/*     */     //   80: aload_0
/*     */     //   81: invokevirtual getTableRow : ()Ljavafx/scene/control/TableRow;
/*     */     //   84: astore #9
/*     */     //   86: aload #9
/*     */     //   88: ifnonnull -> 95
/*     */     //   91: aconst_null
/*     */     //   92: goto -> 100
/*     */     //   95: aload #9
/*     */     //   97: invokevirtual getItem : ()Ljava/lang/Object;
/*     */     //   100: astore #10
/*     */     //   102: iload #6
/*     */     //   104: iload #5
/*     */     //   106: if_icmplt -> 113
/*     */     //   109: iconst_1
/*     */     //   110: goto -> 114
/*     */     //   113: iconst_0
/*     */     //   114: istore #11
/*     */     //   116: iload #11
/*     */     //   118: ifne -> 153
/*     */     //   121: iload #6
/*     */     //   123: iflt -> 153
/*     */     //   126: aload_0
/*     */     //   127: getfield columnIndex : I
/*     */     //   130: iflt -> 153
/*     */     //   133: aload_0
/*     */     //   134: invokevirtual isVisible : ()Z
/*     */     //   137: ifeq -> 153
/*     */     //   140: aload #4
/*     */     //   142: ifnull -> 153
/*     */     //   145: aload #4
/*     */     //   147: invokevirtual isVisible : ()Z
/*     */     //   150: ifne -> 187
/*     */     //   153: iload #7
/*     */     //   155: ifne -> 163
/*     */     //   158: aload #8
/*     */     //   160: ifnonnull -> 175
/*     */     //   163: aload_0
/*     */     //   164: getfield isFirstRun : Z
/*     */     //   167: ifne -> 175
/*     */     //   170: iload #11
/*     */     //   172: ifeq -> 186
/*     */     //   175: aload_0
/*     */     //   176: aconst_null
/*     */     //   177: iconst_1
/*     */     //   178: invokevirtual updateItem : (Ljava/lang/Object;Z)V
/*     */     //   181: aload_0
/*     */     //   182: iconst_0
/*     */     //   183: putfield isFirstRun : Z
/*     */     //   186: return
/*     */     //   187: aload_0
/*     */     //   188: aload #4
/*     */     //   190: iload #6
/*     */     //   192: invokevirtual getCellObservableValue : (I)Ljavafx/beans/value/ObservableValue;
/*     */     //   195: putfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   198: aload_0
/*     */     //   199: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   202: ifnonnull -> 209
/*     */     //   205: aconst_null
/*     */     //   206: goto -> 218
/*     */     //   209: aload_0
/*     */     //   210: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   213: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   218: astore #12
/*     */     //   220: iload_1
/*     */     //   221: iload #6
/*     */     //   223: if_icmpne -> 275
/*     */     //   226: aload_0
/*     */     //   227: aload #8
/*     */     //   229: aload #12
/*     */     //   231: invokevirtual isItemChanged : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   234: ifne -> 275
/*     */     //   237: aload_0
/*     */     //   238: getfield oldRowItemRef : Ljava/lang/ref/WeakReference;
/*     */     //   241: ifnull -> 254
/*     */     //   244: aload_0
/*     */     //   245: getfield oldRowItemRef : Ljava/lang/ref/WeakReference;
/*     */     //   248: invokevirtual get : ()Ljava/lang/Object;
/*     */     //   251: goto -> 255
/*     */     //   254: aconst_null
/*     */     //   255: astore #13
/*     */     //   257: aload #13
/*     */     //   259: ifnull -> 275
/*     */     //   262: aload #13
/*     */     //   264: aload #10
/*     */     //   266: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   269: ifeq -> 275
/*     */     //   272: goto -> 282
/*     */     //   275: aload_0
/*     */     //   276: aload #12
/*     */     //   278: iconst_0
/*     */     //   279: invokevirtual updateItem : (Ljava/lang/Object;Z)V
/*     */     //   282: aload_0
/*     */     //   283: new java/lang/ref/WeakReference
/*     */     //   286: dup
/*     */     //   287: aload #10
/*     */     //   289: invokespecial <init> : (Ljava/lang/Object;)V
/*     */     //   292: putfield oldRowItemRef : Ljava/lang/ref/WeakReference;
/*     */     //   295: aload_0
/*     */     //   296: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   299: ifnonnull -> 303
/*     */     //   302: return
/*     */     //   303: aload_0
/*     */     //   304: getfield currentObservableValue : Ljavafx/beans/value/ObservableValue;
/*     */     //   307: aload_0
/*     */     //   308: getfield weaktableRowUpdateObserver : Ljavafx/beans/WeakInvalidationListener;
/*     */     //   311: invokeinterface addListener : (Ljavafx/beans/InvalidationListener;)V
/*     */     //   316: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #603	-> 0
/*     */     //   #604	-> 7
/*     */     //   #608	-> 20
/*     */     //   #609	-> 25
/*     */     //   #610	-> 40
/*     */     //   #611	-> 46
/*     */     //   #612	-> 62
/*     */     //   #613	-> 68
/*     */     //   #614	-> 74
/*     */     //   #616	-> 80
/*     */     //   #617	-> 86
/*     */     //   #619	-> 102
/*     */     //   #622	-> 116
/*     */     //   #625	-> 134
/*     */     //   #627	-> 147
/*     */     //   #640	-> 153
/*     */     //   #641	-> 175
/*     */     //   #642	-> 181
/*     */     //   #644	-> 186
/*     */     //   #646	-> 187
/*     */     //   #647	-> 198
/*     */     //   #651	-> 220
/*     */     //   #652	-> 226
/*     */     //   #656	-> 237
/*     */     //   #657	-> 257
/*     */     //   #661	-> 272
/*     */     //   #665	-> 275
/*     */     //   #668	-> 282
/*     */     //   #670	-> 295
/*     */     //   #671	-> 302
/*     */     //   #675	-> 303
/* 730 */     //   #676	-> 316 } public final void updateTableColumn(TableColumn<S, T> paramTableColumn) { TableColumn<S, T> tableColumn = getTableColumn();
/* 731 */     if (tableColumn != null) {
/* 732 */       tableColumn.getStyleClass().removeListener(this.weakColumnStyleClassListener);
/* 733 */       getStyleClass().removeAll(tableColumn.getStyleClass());
/*     */       
/* 735 */       tableColumn.idProperty().removeListener(this.weakColumnIdListener);
/* 736 */       tableColumn.styleProperty().removeListener(this.weakColumnStyleListener);
/*     */       
/* 738 */       String str1 = getId();
/* 739 */       String str2 = getStyle();
/* 740 */       if (str1 != null && str1.equals(tableColumn.getId())) {
/* 741 */         setId(null);
/*     */       }
/* 743 */       if (str2 != null && str2.equals(tableColumn.getStyle())) {
/* 744 */         setStyle("");
/*     */       }
/*     */     } 
/*     */     
/* 748 */     setTableColumn(paramTableColumn);
/*     */     
/* 750 */     if (paramTableColumn != null) {
/* 751 */       getStyleClass().addAll(paramTableColumn.getStyleClass());
/* 752 */       paramTableColumn.getStyleClass().addListener(this.weakColumnStyleClassListener);
/*     */       
/* 754 */       paramTableColumn.idProperty().addListener(this.weakColumnIdListener);
/* 755 */       paramTableColumn.styleProperty().addListener(this.weakColumnStyleListener);
/*     */       
/* 757 */       possiblySetId(paramTableColumn.getId());
/* 758 */       possiblySetStyle(paramTableColumn.getStyle());
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 772 */   private static final PseudoClass PSEUDO_CLASS_LAST_VISIBLE = PseudoClass.getPseudoClass("last-visible");
/*     */   
/*     */   private void possiblySetId(String paramString) {
/* 775 */     if (getId() == null || getId().isEmpty()) {
/* 776 */       setId(paramString);
/*     */     }
/*     */   }
/*     */   
/*     */   private void possiblySetStyle(String paramString) {
/* 781 */     if (getStyle() == null || getStyle().isEmpty()) {
/* 782 */       setStyle(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 797 */     switch (paramAccessibleAttribute) { case REQUEST_FOCUS:
/* 798 */         return Integer.valueOf(getIndex());
/* 799 */       case null: return Integer.valueOf(this.columnIndex);
/* 800 */       case null: return Boolean.valueOf(isInCellSelectionMode() ? isSelected() : getTableRow().isSelected()); }
/* 801 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     TableView<S> tableView;
/* 808 */     switch (paramAccessibleAction) {
/*     */       case REQUEST_FOCUS:
/* 810 */         tableView = getTableView();
/* 811 */         if (tableView != null) {
/* 812 */           TableView.TableViewFocusModel<S> tableViewFocusModel = tableView.getFocusModel();
/* 813 */           if (tableViewFocusModel != null) {
/* 814 */             tableViewFocusModel.focus(getIndex(), getTableColumn());
/*     */           }
/*     */         } 
/*     */         return;
/*     */     } 
/* 819 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TableCell.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */