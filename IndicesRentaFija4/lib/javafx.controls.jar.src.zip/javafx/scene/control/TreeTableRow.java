/*     */ package javafx.scene.control;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.skin.TreeTableRowSkin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeTableRow<T>
/*     */   extends IndexedCell<T>
/*     */ {
/*     */   private final ListChangeListener<Integer> selectedListener;
/*     */   private final InvalidationListener focusedListener;
/*     */   private final InvalidationListener editingListener;
/*     */   private final InvalidationListener leafListener;
/*     */   private boolean oldExpanded;
/*     */   private final InvalidationListener treeItemExpandedInvalidationListener;
/*     */   private final WeakListChangeListener<Integer> weakSelectedListener;
/*     */   private final WeakInvalidationListener weakFocusedListener;
/*     */   private final WeakInvalidationListener weakEditingListener;
/*     */   private final WeakInvalidationListener weakLeafListener;
/*     */   private final WeakInvalidationListener weakTreeItemExpandedInvalidationListener;
/*     */   private ReadOnlyObjectWrapper<TreeItem<T>> treeItem;
/*     */   private ObjectProperty<Node> disclosureNode;
/*     */   private ReadOnlyObjectWrapper<TreeTableView<T>> treeTableView;
/*     */   private int index;
/*     */   private boolean isFirstRun;
/*     */   private static final String DEFAULT_STYLE_CLASS = "tree-table-row-cell";
/*     */   
/*     */   public TreeTableRow() {
/*  94 */     this.selectedListener = (paramChange -> updateSelection());
/*     */ 
/*     */ 
/*     */     
/*  98 */     this.focusedListener = (paramObservable -> updateFocus());
/*     */ 
/*     */ 
/*     */     
/* 102 */     this.editingListener = (paramObservable -> updateEditing());
/*     */ 
/*     */ 
/*     */     
/* 106 */     this.leafListener = new InvalidationListener()
/*     */       {
/*     */         public void invalidated(Observable param1Observable)
/*     */         {
/* 110 */           TreeItem treeItem = TreeTableRow.this.getTreeItem();
/* 111 */           if (treeItem != null) {
/* 112 */             TreeTableRow.this.requestLayout();
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 118 */     this.treeItemExpandedInvalidationListener = (paramObservable -> {
/*     */         boolean bool = ((BooleanProperty)paramObservable).get();
/*     */         
/*     */         pseudoClassStateChanged(EXPANDED_PSEUDOCLASS_STATE, bool);
/*     */         pseudoClassStateChanged(COLLAPSED_PSEUDOCLASS_STATE, !bool);
/*     */         if (bool != this.oldExpanded) {
/*     */           notifyAccessibleAttributeChanged(AccessibleAttribute.EXPANDED);
/*     */         }
/*     */         this.oldExpanded = bool;
/*     */       });
/* 128 */     this.weakSelectedListener = new WeakListChangeListener<>(this.selectedListener);
/*     */     
/* 130 */     this.weakFocusedListener = new WeakInvalidationListener(this.focusedListener);
/*     */     
/* 132 */     this.weakEditingListener = new WeakInvalidationListener(this.editingListener);
/*     */     
/* 134 */     this.weakLeafListener = new WeakInvalidationListener(this.leafListener);
/*     */     
/* 136 */     this.weakTreeItemExpandedInvalidationListener = new WeakInvalidationListener(this.treeItemExpandedInvalidationListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     this.treeItem = (ReadOnlyObjectWrapper)new ReadOnlyObjectWrapper<TreeItem<TreeItem<T>>>(this, "treeItem")
/*     */       {
/*     */         
/* 151 */         TreeItem<T> oldValue = null;
/*     */         
/*     */         protected void invalidated() {
/* 154 */           if (this.oldValue != null) {
/* 155 */             this.oldValue.expandedProperty().removeListener(TreeTableRow.this.weakTreeItemExpandedInvalidationListener);
/*     */           }
/*     */           
/* 158 */           this.oldValue = get();
/*     */           
/* 160 */           if (this.oldValue != null) {
/* 161 */             TreeTableRow.this.oldExpanded = this.oldValue.isExpanded();
/* 162 */             this.oldValue.expandedProperty().addListener(TreeTableRow.this.weakTreeItemExpandedInvalidationListener);
/*     */             
/* 164 */             TreeTableRow.this.weakTreeItemExpandedInvalidationListener.invalidated(this.oldValue.expandedProperty());
/*     */           } 
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     this.disclosureNode = new SimpleObjectProperty<>(this, "disclosureNode");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     this.treeTableView = (ReadOnlyObjectWrapper)new ReadOnlyObjectWrapper<TreeTableView<TreeTableView<T>>>(this, "treeTableView")
/*     */       {
/*     */         private WeakReference<TreeTableView<T>> weakTreeTableViewRef;
/*     */ 
/*     */         
/*     */         protected void invalidated() {
/* 222 */           if (this.weakTreeTableViewRef != null) {
/* 223 */             TreeTableView treeTableView = this.weakTreeTableViewRef.get();
/* 224 */             if (treeTableView != null) {
/*     */               
/* 226 */               TreeTableView.TreeTableViewSelectionModel treeTableViewSelectionModel = treeTableView.getSelectionModel();
/* 227 */               if (treeTableViewSelectionModel != null) {
/* 228 */                 treeTableViewSelectionModel.getSelectedIndices().removeListener(TreeTableRow.this.weakSelectedListener);
/*     */               }
/*     */               
/* 231 */               TreeTableView.TreeTableViewFocusModel treeTableViewFocusModel = treeTableView.getFocusModel();
/* 232 */               if (treeTableViewFocusModel != null) {
/* 233 */                 treeTableViewFocusModel.focusedIndexProperty().removeListener(TreeTableRow.this.weakFocusedListener);
/*     */               }
/*     */               
/* 236 */               treeTableView.editingCellProperty().removeListener(TreeTableRow.this.weakEditingListener);
/*     */             } 
/*     */             
/* 239 */             this.weakTreeTableViewRef = null;
/*     */           } 
/*     */           
/* 242 */           if (get() != null) {
/* 243 */             TreeTableView.TreeTableViewSelectionModel<T> treeTableViewSelectionModel = get().getSelectionModel();
/* 244 */             if (treeTableViewSelectionModel != null)
/*     */             {
/*     */               
/* 247 */               treeTableViewSelectionModel.getSelectedIndices().addListener(TreeTableRow.this.weakSelectedListener);
/*     */             }
/*     */             
/* 250 */             TreeTableView.TreeTableViewFocusModel<T> treeTableViewFocusModel = get().getFocusModel();
/* 251 */             if (treeTableViewFocusModel != null)
/*     */             {
/* 253 */               treeTableViewFocusModel.focusedIndexProperty().addListener(TreeTableRow.this.weakFocusedListener);
/*     */             }
/*     */             
/* 256 */             get().editingCellProperty().addListener(TreeTableRow.this.weakEditingListener);
/*     */             
/* 258 */             this.weakTreeTableViewRef = new WeakReference<>(get());
/*     */           } 
/*     */           
/* 261 */           TreeTableRow.this.updateItem();
/* 262 */           TreeTableRow.this.requestLayout();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 391 */     this.index = -1;
/* 392 */     this.isFirstRun = true; getStyleClass().addAll(new String[] { "tree-table-row-cell" }); setAccessibleRole(AccessibleRole.TREE_TABLE_ROW);
/*     */   } private void setTreeItem(TreeItem<T> paramTreeItem) { this.treeItem.set(paramTreeItem); } public final TreeItem<T> getTreeItem() { return this.treeItem.get(); } public final ReadOnlyObjectProperty<TreeItem<T>> treeItemProperty() { return this.treeItem.getReadOnlyProperty(); } public final void setDisclosureNode(Node paramNode) { disclosureNodeProperty().set(paramNode); } public final Node getDisclosureNode() { return this.disclosureNode.get(); }
/*     */   public final ObjectProperty<Node> disclosureNodeProperty() { return this.disclosureNode; }
/* 395 */   private void updateItem() { TreeTableView<T> treeTableView = getTreeTableView();
/* 396 */     if (treeTableView == null) {
/*     */       return;
/*     */     }
/* 399 */     boolean bool = (this.index >= 0 && this.index < treeTableView.getExpandedItemCount()) ? true : false;
/*     */     
/* 401 */     TreeItem<T> treeItem = getTreeItem();
/* 402 */     boolean bool1 = isEmpty();
/*     */ 
/*     */     
/* 405 */     if (bool) {
/*     */ 
/*     */       
/* 408 */       TreeItem<T> treeItem1 = treeTableView.getTreeItem(this.index);
/* 409 */       T t = (treeItem1 == null) ? null : treeItem1.getValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 422 */       updateTreeItem(treeItem1);
/* 423 */       updateItem(t, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 431 */     else if ((!bool1 && treeItem != null) || this.isFirstRun) {
/* 432 */       updateTreeItem((TreeItem<T>)null);
/* 433 */       updateItem((T)null, true);
/* 434 */       this.isFirstRun = false;
/*     */     }  }
/*     */   private void setTreeTableView(TreeTableView<T> paramTreeTableView) { this.treeTableView.set(paramTreeTableView); }
/*     */   public final TreeTableView<T> getTreeTableView() { return this.treeTableView.get(); }
/*     */   public final ReadOnlyObjectProperty<TreeTableView<T>> treeTableViewProperty() {
/*     */     return this.treeTableView.getReadOnlyProperty();
/* 440 */   } private void updateSelection() { if (isEmpty())
/* 441 */       return;  if (this.index == -1 || getTreeTableView() == null)
/* 442 */       return;  if (getTreeTableView().getSelectionModel() == null)
/*     */       return; 
/* 444 */     boolean bool = getTreeTableView().getSelectionModel().isSelected(this.index);
/* 445 */     if (isSelected() == bool)
/*     */       return; 
/* 447 */     updateSelected(bool); }
/*     */   void indexChanged(int paramInt1, int paramInt2) { this.index = getIndex(); updateItem(); updateSelection(); updateFocus(); }
/*     */   public void startEdit() { TreeTableView<T> treeTableView = getTreeTableView(); if (!isEditable() || (treeTableView != null && !treeTableView.isEditable())) return;  super.startEdit(); if (treeTableView != null) { treeTableView.fireEvent(new TreeTableView.EditEvent<>(treeTableView, (EventType)TreeTableView.editStartEvent(), getTreeItem(), getItem(), null)); treeTableView.requestFocus(); }  }
/*     */   public void commitEdit(T paramT) { if (!isEditing()) return;  TreeItem<T> treeItem = getTreeItem(); TreeTableView<T> treeTableView = getTreeTableView(); if (treeTableView != null) treeTableView.fireEvent(new TreeTableView.EditEvent<>(treeTableView, (EventType)TreeTableView.editCommitEvent(), treeItem, getItem(), paramT));  if (treeItem != null) { treeItem.setValue(paramT); updateTreeItem(treeItem); updateItem(paramT, false); }  super.commitEdit(paramT); if (treeTableView != null) { treeTableView.edit(-1, (TreeTableColumn<T, ?>)null); treeTableView.requestFocus(); }  }
/* 451 */   public void cancelEdit() { if (!isEditing()) return;  TreeTableView<T> treeTableView = getTreeTableView(); if (treeTableView != null) treeTableView.fireEvent(new TreeTableView.EditEvent<>(treeTableView, (EventType)TreeTableView.editCancelEvent(), getTreeItem(), getItem(), null));  super.cancelEdit(); if (treeTableView != null) { treeTableView.edit(-1, (TreeTableColumn<T, ?>)null); treeTableView.requestFocus(); }  } private void updateFocus() { if (getIndex() == -1 || getTreeTableView() == null)
/* 452 */       return;  if (getTreeTableView().getFocusModel() == null)
/*     */       return; 
/* 454 */     setFocused(getTreeTableView().getFocusModel().isFocused(getIndex())); }
/*     */ 
/*     */   
/*     */   private void updateEditing() {
/* 458 */     if (getIndex() == -1 || getTreeTableView() == null || getTreeItem() == null)
/*     */       return; 
/* 460 */     TreeTablePosition<T, ?> treeTablePosition = getTreeTableView().getEditingCell();
/* 461 */     if (treeTablePosition != null && treeTablePosition.getTableColumn() != null) {
/*     */       return;
/*     */     }
/*     */     
/* 465 */     TreeItem<S> treeItem = (treeTablePosition == null) ? null : treeTablePosition.getTreeItem();
/* 466 */     if (!isEditing() && getTreeItem().equals(treeItem)) {
/* 467 */       startEdit();
/* 468 */     } else if (isEditing() && !getTreeItem().equals(treeItem)) {
/* 469 */       cancelEdit();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void updateTreeTableView(TreeTableView<T> paramTreeTableView) {
/* 491 */     setTreeTableView(paramTreeTableView);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void updateTreeItem(TreeItem<T> paramTreeItem) {
/* 504 */     TreeItem<T> treeItem = getTreeItem();
/* 505 */     if (treeItem != null) {
/* 506 */       treeItem.leafProperty().removeListener(this.weakLeafListener);
/*     */     }
/* 508 */     setTreeItem(paramTreeItem);
/* 509 */     if (paramTreeItem != null) {
/* 510 */       paramTreeItem.leafProperty().addListener(this.weakLeafListener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 524 */   private static final PseudoClass EXPANDED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("expanded");
/* 525 */   private static final PseudoClass COLLAPSED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("collapsed");
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 529 */     return (Skin<?>)new TreeTableRowSkin(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*     */     TreeItem<T> treeItem2;
/*     */     int i, j;
/*     */     TreeItem<T> treeItem3;
/*     */     int k;
/* 542 */     TreeItem<T> treeItem1 = getTreeItem();
/* 543 */     TreeTableView<T> treeTableView = getTreeTableView();
/*     */     
/* 545 */     switch (paramAccessibleAttribute) {
/*     */       case EXPAND:
/* 547 */         if (treeItem1 == null) return null; 
/* 548 */         treeItem2 = treeItem1.getParent();
/* 549 */         if (treeItem2 == null) return null; 
/* 550 */         j = treeTableView.getRow(treeItem2);
/* 551 */         return treeTableView.queryAccessibleAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { Integer.valueOf(j) });
/*     */       
/*     */       case COLLAPSE:
/* 554 */         if (treeItem1 == null) return Integer.valueOf(0); 
/* 555 */         if (!treeItem1.isExpanded()) return Integer.valueOf(0); 
/* 556 */         return Integer.valueOf(treeItem1.getChildren().size());
/*     */       
/*     */       case null:
/* 559 */         if (treeItem1 == null) return null; 
/* 560 */         if (!treeItem1.isExpanded()) return null; 
/* 561 */         i = ((Integer)paramVarArgs[0]).intValue();
/* 562 */         if (i >= treeItem1.getChildren().size()) return null; 
/* 563 */         treeItem3 = treeItem1.getChildren().get(i);
/* 564 */         if (treeItem3 == null) return null; 
/* 565 */         k = treeTableView.getRow(treeItem3);
/* 566 */         return treeTableView.queryAccessibleAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { Integer.valueOf(k) });
/*     */       case null:
/* 568 */         return Boolean.valueOf((treeItem1 == null) ? true : treeItem1.isLeaf());
/* 569 */       case null: return Boolean.valueOf((treeItem1 == null) ? false : treeItem1.isExpanded());
/* 570 */       case null: return Integer.valueOf(getIndex());
/*     */       case null:
/* 572 */         return Integer.valueOf((treeTableView == null) ? 0 : treeTableView.getTreeItemLevel(treeItem1));
/*     */     } 
/* 574 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     TreeItem<T> treeItem;
/* 581 */     switch (paramAccessibleAction) {
/*     */       case EXPAND:
/* 583 */         treeItem = getTreeItem();
/* 584 */         if (treeItem != null) treeItem.setExpanded(true);
/*     */         
/*     */         return;
/*     */       case COLLAPSE:
/* 588 */         treeItem = getTreeItem();
/* 589 */         if (treeItem != null) treeItem.setExpanded(false); 
/*     */         return;
/*     */     } 
/* 592 */     super.executeAccessibleAction(paramAccessibleAction, new Object[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\TreeTableRow.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */