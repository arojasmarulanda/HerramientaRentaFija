/*     */ package javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.collections.NonIterableChange;
/*     */ import com.sun.javafx.scene.control.MultipleAdditionAndRemovedChange;
/*     */ import com.sun.javafx.scene.control.ReadOnlyUnbackedObservableList;
/*     */ import com.sun.javafx.scene.control.SelectedItemsReadOnlyObservableList;
/*     */ import java.util.Arrays;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collector;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.IntStream;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableListBase;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MultipleSelectionModelBase<T>
/*     */   extends MultipleSelectionModel<T>
/*     */ {
/*     */   final SelectedIndicesList selectedIndices;
/*     */   private final ObservableListBase<T> selectedItems;
/*     */   ListChangeListener.Change selectedItemChange;
/*     */   
/*     */   public MultipleSelectionModelBase() {
/*  62 */     selectedIndexProperty().addListener(paramObservable -> setSelectedItem(getModelItem(getSelectedIndex())));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     this.selectedIndices = new SelectedIndicesList();
/*     */     
/*  72 */     this.selectedItems = (ObservableListBase<T>)new SelectedItemsReadOnlyObservableList<T>(this.selectedIndices, () -> Integer.valueOf(getItemCount())) {
/*     */         protected T getModelItem(int param1Int) {
/*  74 */           return MultipleSelectionModelBase.this.getModelItem(param1Int);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<Integer> getSelectedIndices() {
/* 112 */     return this.selectedIndices;
/*     */   }
/*     */ 
/*     */   
/*     */   public ObservableList<T> getSelectedItems() {
/* 117 */     return this.selectedItems;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ShiftParams
/*     */   {
/*     */     private final int clearIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int setIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean selected;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ShiftParams(int param1Int1, int param1Int2, boolean param1Boolean) {
/* 166 */       this.clearIndex = param1Int1;
/* 167 */       this.setIndex = param1Int2;
/* 168 */       this.selected = param1Boolean;
/*     */     }
/*     */     
/*     */     public final int getClearIndex() {
/* 172 */       return this.clearIndex;
/*     */     }
/*     */     
/*     */     public final int getSetIndex() {
/* 176 */       return this.setIndex;
/*     */     }
/*     */     
/*     */     public final boolean isSelected() {
/* 180 */       return this.selected;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void shiftSelection(int paramInt1, int paramInt2, Callback<ShiftParams, Void> paramCallback) {
/* 186 */     shiftSelection(Arrays.asList((Pair<Integer, Integer>[])new Pair[] { new Pair<>(Integer.valueOf(paramInt1), Integer.valueOf(paramInt2)) }), paramCallback);
/*     */   }
/*     */   
/*     */   void shiftSelection(List<Pair<Integer, Integer>> paramList, Callback<ShiftParams, Void> paramCallback) {
/* 190 */     int i = this.selectedIndices.size();
/* 191 */     if (i == 0)
/*     */       return; 
/* 193 */     int j = this.selectedIndices.bitsetSize();
/*     */     
/* 195 */     int[] arrayOfInt1 = new int[j];
/* 196 */     Arrays.fill(arrayOfInt1, -1);
/*     */ 
/*     */     
/* 199 */     Collections.sort(paramList, (paramPair1, paramPair2) -> Integer.compare(((Integer)paramPair2.getKey()).intValue(), ((Integer)paramPair1.getKey()).intValue()));
/* 200 */     int k = ((Integer)((Pair)paramList.get(paramList.size() - 1)).getKey()).intValue();
/*     */ 
/*     */     
/* 203 */     BitSet bitSet = (BitSet)this.selectedIndices.bitset.clone();
/*     */     
/* 205 */     startAtomic();
/* 206 */     for (Pair<Integer, Integer> pair : paramList) {
/* 207 */       doShift(pair, paramCallback, arrayOfInt1);
/*     */     }
/* 209 */     stopAtomic();
/*     */ 
/*     */     
/* 212 */     int[] arrayOfInt2 = Arrays.stream(arrayOfInt1).filter(paramInt -> (paramInt > -1)).toArray();
/* 213 */     boolean bool = (arrayOfInt2.length > 0) ? true : false;
/*     */ 
/*     */     
/* 216 */     int m = getSelectedIndex();
/* 217 */     if (m >= k && m > -1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 223 */       int n = paramList.stream().filter(paramPair -> (((Integer)paramPair.getKey()).intValue() <= paramInt)).mapToInt(paramPair -> ((Integer)paramPair.getValue()).intValue()).sum();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 229 */       int i1 = Math.max(0, m + n);
/*     */       
/* 231 */       setSelectedIndex(i1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 237 */       if (bool) {
/* 238 */         this.selectedIndices.set(i1, true);
/*     */       } else {
/* 240 */         select(i1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     if (bool) {
/*     */       
/* 249 */       BitSet bitSet1 = (BitSet)bitSet.clone();
/* 250 */       bitSet1.andNot(this.selectedIndices.bitset);
/*     */       
/* 252 */       BitSet bitSet2 = (BitSet)this.selectedIndices.bitset.clone();
/* 253 */       bitSet2.andNot(bitSet);
/*     */       
/* 255 */       this.selectedIndices.reset();
/* 256 */       this.selectedIndices.callObservers((ListChangeListener.Change<Integer>)new MultipleAdditionAndRemovedChange(bitSet2
/* 257 */             .stream().boxed().collect((Collector)Collectors.toList()), bitSet1
/* 258 */             .stream().boxed().collect((Collector)Collectors.toList()), this.selectedIndices));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void doShift(Pair<Integer, Integer> paramPair, Callback<ShiftParams, Void> paramCallback, int[] paramArrayOfint) {
/* 265 */     int i = ((Integer)paramPair.getKey()).intValue();
/* 266 */     int j = ((Integer)paramPair.getValue()).intValue();
/*     */ 
/*     */     
/* 269 */     if (i < 0)
/* 270 */       return;  if (j == 0)
/*     */       return; 
/* 272 */     int k = (int)Arrays.stream(paramArrayOfint).filter(paramInt -> (paramInt > -1)).count();
/*     */     
/* 274 */     int m = this.selectedIndices.bitsetSize() - k;
/*     */     
/* 276 */     if (j > 0) {
/* 277 */       for (int n = m - 1; n >= i && n >= 0; n--) {
/* 278 */         boolean bool = this.selectedIndices.isSelected(n);
/*     */         
/* 280 */         if (paramCallback == null) {
/* 281 */           this.selectedIndices.clear(n);
/* 282 */           this.selectedIndices.set(n + j, bool);
/*     */         } else {
/* 284 */           paramCallback.call(new ShiftParams(n, n + j, bool));
/*     */         } 
/*     */         
/* 287 */         if (bool) {
/* 288 */           paramArrayOfint[k++] = n + 1;
/*     */         }
/*     */       } 
/* 291 */       this.selectedIndices.clear(i);
/* 292 */     } else if (j < 0) {
/* 293 */       for (int n = i; n < m; n++) {
/* 294 */         if (n + j >= 0 && 
/* 295 */           n + 1 + j >= i) {
/* 296 */           boolean bool = this.selectedIndices.isSelected(n + 1);
/*     */           
/* 298 */           if (paramCallback == null) {
/* 299 */             this.selectedIndices.clear(n + 1);
/* 300 */             this.selectedIndices.set(n + 1 + j, bool);
/*     */           } else {
/* 302 */             paramCallback.call(new ShiftParams(n + 1, n + 1 + j, bool));
/*     */           } 
/*     */           
/* 305 */           if (bool)
/* 306 */             paramArrayOfint[k++] = n; 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void startAtomic() {
/* 313 */     this.selectedIndices.startAtomic();
/*     */   }
/*     */   
/*     */   void stopAtomic() {
/* 317 */     this.selectedIndices.stopAtomic();
/*     */   }
/*     */   
/*     */   boolean isAtomic() {
/* 321 */     return this.selectedIndices.isAtomic();
/*     */   }
/*     */   public void clearAndSelect(int paramInt) {
/*     */     ListChangeListener.Change<?> change;
/* 325 */     if (paramInt < 0 || paramInt >= getItemCount()) {
/* 326 */       clearSelection();
/*     */       
/*     */       return;
/*     */     } 
/* 330 */     boolean bool = isSelected(paramInt);
/*     */ 
/*     */ 
/*     */     
/* 334 */     if (bool && getSelectedIndices().size() == 1)
/*     */     {
/*     */       
/* 337 */       if (getSelectedItem() == getModelItem(paramInt)) {
/*     */         return;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 345 */     BitSet bitSet = new BitSet();
/* 346 */     bitSet.or(this.selectedIndices.bitset);
/* 347 */     bitSet.clear(paramInt);
/* 348 */     SelectedIndicesList selectedIndicesList = new SelectedIndicesList(bitSet);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 354 */     startAtomic();
/*     */ 
/*     */     
/* 357 */     clearSelection();
/*     */ 
/*     */     
/* 360 */     select(paramInt);
/* 361 */     stopAtomic();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 374 */     if (bool) {
/* 375 */       change = ControlUtils.buildClearAndSelectChange(this.selectedIndices, selectedIndicesList, paramInt);
/*     */     } else {
/* 377 */       int i = Math.max(0, this.selectedIndices.indexOf(Integer.valueOf(paramInt)));
/* 378 */       change = new NonIterableChange.GenericAddRemoveChange(i, i + 1, selectedIndicesList, this.selectedIndices);
/*     */     } 
/*     */ 
/*     */     
/* 382 */     this.selectedIndices.callObservers((ListChangeListener.Change)change);
/*     */   }
/*     */   
/*     */   public void select(int paramInt) {
/* 386 */     if (paramInt == -1) {
/* 387 */       clearSelection();
/*     */       return;
/*     */     } 
/* 390 */     if (paramInt < 0 || paramInt >= getItemCount()) {
/*     */       return;
/*     */     }
/*     */     
/* 394 */     boolean bool1 = (paramInt == getSelectedIndex()) ? true : false;
/* 395 */     T t1 = getSelectedItem();
/* 396 */     T t2 = getModelItem(paramInt);
/* 397 */     boolean bool2 = (t2 != null && t2.equals(t1)) ? true : false;
/* 398 */     boolean bool3 = (bool1 && !bool2) ? true : false;
/*     */ 
/*     */     
/* 401 */     focus(paramInt);
/*     */     
/* 403 */     if (!this.selectedIndices.isSelected(paramInt)) {
/* 404 */       if (getSelectionMode() == SelectionMode.SINGLE) {
/* 405 */         startAtomic();
/* 406 */         quietClearSelection();
/* 407 */         stopAtomic();
/*     */       } 
/* 409 */       this.selectedIndices.set(paramInt);
/*     */     } 
/*     */     
/* 412 */     setSelectedIndex(paramInt);
/*     */     
/* 414 */     if (bool3) {
/* 415 */       setSelectedItem(t2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void select(T paramT) {
/* 422 */     if (paramT == null && getSelectionMode() == SelectionMode.SINGLE) {
/* 423 */       clearSelection();
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 430 */     T t = null; byte b; int i;
/* 431 */     for (b = 0, i = getItemCount(); b < i; b++) {
/* 432 */       t = getModelItem(b);
/* 433 */       if (t != null)
/*     */       {
/* 435 */         if (t.equals(paramT)) {
/* 436 */           if (isSelected(b)) {
/*     */             return;
/*     */           }
/*     */           
/* 440 */           if (getSelectionMode() == SelectionMode.SINGLE) {
/* 441 */             quietClearSelection();
/*     */           }
/*     */           
/* 444 */           select(b);
/*     */ 
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 454 */     setSelectedIndex(-1);
/* 455 */     setSelectedItem(paramT);
/*     */   }
/*     */   
/*     */   public void selectIndices(int paramInt, int... paramVarArgs) {
/* 459 */     if (paramVarArgs == null || paramVarArgs.length == 0) {
/* 460 */       select(paramInt);
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 469 */     int i = getItemCount();
/*     */     
/* 471 */     if (getSelectionMode() == SelectionMode.SINGLE) {
/* 472 */       quietClearSelection();
/*     */       
/* 474 */       for (int j = paramVarArgs.length - 1; j >= 0; j--) {
/* 475 */         int k = paramVarArgs[j];
/* 476 */         if (k >= 0 && k < i) {
/* 477 */           this.selectedIndices.set(k);
/* 478 */           select(k);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 483 */       if (this.selectedIndices.isEmpty() && 
/* 484 */         paramInt > 0 && paramInt < i) {
/* 485 */         this.selectedIndices.set(paramInt);
/* 486 */         select(paramInt);
/*     */       } 
/*     */     } else {
/*     */       
/* 490 */       this.selectedIndices.set(paramInt, paramVarArgs);
/*     */       
/* 492 */       IntStream.concat(IntStream.of(paramInt), IntStream.of(paramVarArgs))
/* 493 */         .filter(paramInt2 -> (paramInt2 >= 0 && paramInt2 < paramInt1))
/* 494 */         .reduce((paramInt1, paramInt2) -> paramInt2)
/* 495 */         .ifPresent(paramInt -> {
/*     */             setSelectedIndex(paramInt);
/*     */             focus(paramInt);
/*     */             setSelectedItem(getModelItem(paramInt));
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   public void selectAll() {
/* 504 */     if (getSelectionMode() == SelectionMode.SINGLE)
/*     */       return; 
/* 506 */     if (getItemCount() <= 0)
/*     */       return; 
/* 508 */     int i = getItemCount();
/* 509 */     int j = getFocusedIndex();
/*     */ 
/*     */     
/* 512 */     clearSelection();
/* 513 */     this.selectedIndices.set(0, i, true);
/*     */     
/* 515 */     if (j == -1) {
/* 516 */       setSelectedIndex(i - 1);
/* 517 */       focus(i - 1);
/*     */     } else {
/* 519 */       setSelectedIndex(j);
/* 520 */       focus(j);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void selectFirst() {
/* 525 */     if (getSelectionMode() == SelectionMode.SINGLE) {
/* 526 */       quietClearSelection();
/*     */     }
/*     */     
/* 529 */     if (getItemCount() > 0) {
/* 530 */       select(0);
/*     */     }
/*     */   }
/*     */   
/*     */   public void selectLast() {
/* 535 */     if (getSelectionMode() == SelectionMode.SINGLE) {
/* 536 */       quietClearSelection();
/*     */     }
/*     */     
/* 539 */     int i = getItemCount();
/* 540 */     if (i > 0 && getSelectedIndex() < i - 1) {
/* 541 */       select(i - 1);
/*     */     }
/*     */   }
/*     */   
/*     */   public void clearSelection(int paramInt) {
/* 546 */     if (paramInt < 0) {
/*     */       return;
/*     */     }
/*     */     
/* 550 */     boolean bool = this.selectedIndices.isEmpty();
/* 551 */     this.selectedIndices.clear(paramInt);
/*     */     
/* 553 */     if (!bool && this.selectedIndices.isEmpty()) {
/* 554 */       clearSelection();
/*     */     }
/*     */   }
/*     */   
/*     */   public void clearSelection() {
/* 559 */     quietClearSelection();
/*     */     
/* 561 */     if (!isAtomic()) {
/* 562 */       setSelectedIndex(-1);
/* 563 */       focus(-1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void quietClearSelection() {
/* 568 */     this.selectedIndices.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelected(int paramInt) {
/* 579 */     if (paramInt >= 0 && paramInt < this.selectedIndices.bitsetSize()) {
/* 580 */       return this.selectedIndices.isSelected(paramInt);
/*     */     }
/*     */     
/* 583 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 587 */     return this.selectedIndices.isEmpty();
/*     */   }
/*     */   
/*     */   public void selectPrevious() {
/* 591 */     int i = getFocusedIndex();
/*     */     
/* 593 */     if (getSelectionMode() == SelectionMode.SINGLE) {
/* 594 */       quietClearSelection();
/*     */     }
/*     */     
/* 597 */     if (i == -1) {
/* 598 */       select(getItemCount() - 1);
/* 599 */     } else if (i > 0) {
/* 600 */       select(i - 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void selectNext() {
/* 605 */     int i = getFocusedIndex();
/*     */     
/* 607 */     if (getSelectionMode() == SelectionMode.SINGLE) {
/* 608 */       quietClearSelection();
/*     */     }
/*     */     
/* 611 */     if (i == -1) {
/* 612 */       select(0);
/* 613 */     } else if (i != getItemCount() - 1) {
/* 614 */       select(i + 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract int getItemCount();
/*     */   
/*     */   protected abstract T getModelItem(int paramInt);
/*     */   
/*     */   protected abstract void focus(int paramInt);
/*     */   
/*     */   protected abstract int getFocusedIndex();
/*     */   
/*     */   class SelectedIndicesList
/*     */     extends ReadOnlyUnbackedObservableList<Integer> {
/*     */     private final BitSet bitset;
/* 629 */     private int lastGetIndex = -1;
/* 630 */     private int lastGetValue = -1;
/*     */ 
/*     */     
/* 633 */     private int atomicityCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SelectedIndicesList() {
/* 641 */       this(new BitSet());
/*     */     }
/*     */     
/*     */     public SelectedIndicesList(BitSet param1BitSet) {
/* 645 */       this.bitset = param1BitSet;
/*     */     }
/*     */     
/*     */     boolean isAtomic() {
/* 649 */       return (this.atomicityCount > 0);
/*     */     }
/*     */     void startAtomic() {
/* 652 */       this.atomicityCount++;
/*     */     }
/*     */     void stopAtomic() {
/* 655 */       this.atomicityCount = Math.max(0, this.atomicityCount - 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Integer get(int param1Int) {
/* 661 */       int i = size();
/* 662 */       if (param1Int < 0 || param1Int >= i) {
/* 663 */         throw new IndexOutOfBoundsException("" + param1Int + " >= " + param1Int);
/*     */       }
/*     */       
/* 666 */       if (param1Int == this.lastGetIndex + 1 && this.lastGetValue < i) {
/*     */ 
/*     */         
/* 669 */         this.lastGetIndex++;
/* 670 */         this.lastGetValue = this.bitset.nextSetBit(this.lastGetValue + 1);
/* 671 */         return Integer.valueOf(this.lastGetValue);
/* 672 */       }  if (param1Int == this.lastGetIndex - 1 && this.lastGetValue > 0) {
/*     */ 
/*     */         
/* 675 */         this.lastGetIndex--;
/* 676 */         this.lastGetValue = this.bitset.previousSetBit(this.lastGetValue - 1);
/* 677 */         return Integer.valueOf(this.lastGetValue);
/*     */       } 
/* 679 */       this.lastGetIndex = 0; this.lastGetValue = this.bitset.nextSetBit(0);
/* 680 */       for (; this.lastGetValue >= 0 || this.lastGetIndex == param1Int; 
/* 681 */         this.lastGetIndex++, this.lastGetValue = this.bitset.nextSetBit(this.lastGetValue + 1)) {
/* 682 */         if (this.lastGetIndex == param1Int) {
/* 683 */           return Integer.valueOf(this.lastGetValue);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 688 */       return Integer.valueOf(-1);
/*     */     }
/*     */     
/*     */     public void set(int param1Int) {
/* 692 */       if (!isValidIndex(param1Int) || isSelected(param1Int)) {
/*     */         return;
/*     */       }
/*     */       
/* 696 */       _beginChange();
/* 697 */       this.bitset.set(param1Int);
/* 698 */       int i = indexOf(Integer.valueOf(param1Int));
/* 699 */       _nextAdd(i, i + 1);
/* 700 */       _endChange();
/*     */     }
/*     */     
/*     */     private boolean isValidIndex(int param1Int) {
/* 704 */       return (param1Int >= 0 && param1Int < MultipleSelectionModelBase.this.getItemCount());
/*     */     }
/*     */     
/*     */     public void set(int param1Int, boolean param1Boolean) {
/* 708 */       if (param1Boolean) {
/* 709 */         set(param1Int);
/*     */       } else {
/* 711 */         clear(param1Int);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void set(int param1Int1, int param1Int2, boolean param1Boolean) {
/* 716 */       _beginChange();
/* 717 */       if (param1Boolean) {
/* 718 */         this.bitset.set(param1Int1, param1Int2, param1Boolean);
/* 719 */         int i = indexOf(Integer.valueOf(param1Int1));
/* 720 */         int j = param1Int2 - param1Int1;
/* 721 */         _nextAdd(i, i + j);
/*     */       } else {
/*     */         
/* 724 */         this.bitset.set(param1Int1, param1Int2, param1Boolean);
/*     */       } 
/* 726 */       _endChange();
/*     */     }
/*     */     
/*     */     public void set(int param1Int, int... param1VarArgs) {
/* 730 */       if (param1VarArgs == null || param1VarArgs.length == 0) {
/* 731 */         set(param1Int);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 736 */         startAtomic();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 745 */         List<Integer> list = (List)IntStream.concat(IntStream.of(param1Int), IntStream.of(param1VarArgs)).distinct().filter(this::isValidIndex).filter(this::isNotSelected).sorted().boxed().peek(this::set).collect(Collectors.toList());
/* 746 */         stopAtomic();
/*     */         
/* 748 */         int i = list.size();
/* 749 */         if (i != 0)
/*     */         {
/* 751 */           if (i == 1) {
/* 752 */             _beginChange();
/* 753 */             int j = ((Integer)list.get(0)).intValue();
/* 754 */             int k = indexOf(Integer.valueOf(j));
/* 755 */             _nextAdd(k, k + 1);
/* 756 */             _endChange();
/*     */           } else {
/* 758 */             _beginChange();
/* 759 */             byte b = 0;
/* 760 */             int j = 0;
/* 761 */             int k = 0;
/*     */ 
/*     */ 
/*     */             
/* 765 */             int m = ((Integer)list.get(b++)).intValue();
/* 766 */             j = indexOf(Integer.valueOf(m));
/* 767 */             k = j + 1;
/* 768 */             int n = m;
/* 769 */             while (b < i) {
/* 770 */               int i1 = n;
/* 771 */               n = ((Integer)list.get(b++)).intValue();
/* 772 */               k++;
/* 773 */               if (i1 != n - 1) {
/* 774 */                 _nextAdd(j, k);
/* 775 */                 j = k;
/*     */ 
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */               
/* 781 */               if (b == i) {
/* 782 */                 _nextAdd(j, j + b);
/*     */               }
/*     */             } 
/*     */             
/* 786 */             _endChange();
/*     */           }  } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void clear() {
/* 792 */       _beginChange();
/* 793 */       List<? extends Integer> list = this.bitset.stream().boxed().collect((Collector)Collectors.toList());
/* 794 */       this.bitset.clear();
/* 795 */       _nextRemove(0, list);
/* 796 */       _endChange();
/*     */     }
/*     */     
/*     */     public void clear(int param1Int) {
/* 800 */       if (!this.bitset.get(param1Int))
/*     */         return; 
/* 802 */       _beginChange();
/* 803 */       this.bitset.clear(param1Int);
/* 804 */       _nextRemove(param1Int, Integer.valueOf(param1Int));
/* 805 */       _endChange();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isSelected(int param1Int) {
/* 849 */       return this.bitset.get(param1Int);
/*     */     }
/*     */     
/*     */     public boolean isNotSelected(int param1Int) {
/* 853 */       return !isSelected(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 858 */       return this.bitset.cardinality();
/*     */     }
/*     */ 
/*     */     
/*     */     public int bitsetSize() {
/* 863 */       return this.bitset.size();
/*     */     }
/*     */     
/*     */     public int indexOf(Object param1Object) {
/* 867 */       reset();
/* 868 */       return super.indexOf(param1Object);
/*     */     }
/*     */     
/*     */     public boolean contains(Object param1Object) {
/* 872 */       if (param1Object instanceof Number) {
/* 873 */         Number number = (Number)param1Object;
/* 874 */         int i = number.intValue();
/*     */         
/* 876 */         return (i >= 0 && i < this.bitset.length() && this.bitset
/* 877 */           .get(i));
/*     */       } 
/*     */       
/* 880 */       return false;
/*     */     }
/*     */     
/*     */     public void reset() {
/* 884 */       this.lastGetIndex = -1;
/* 885 */       this.lastGetValue = -1;
/*     */     }
/*     */     
/*     */     public void _beginChange() {
/* 889 */       if (!isAtomic()) {
/* 890 */         super._beginChange();
/*     */       }
/*     */     }
/*     */     
/*     */     public void _endChange() {
/* 895 */       if (!isAtomic()) {
/* 896 */         super._endChange();
/*     */       }
/*     */     }
/*     */     
/*     */     public final void _nextUpdate(int param1Int) {
/* 901 */       if (!isAtomic()) {
/* 902 */         nextUpdate(param1Int);
/*     */       }
/*     */     }
/*     */     
/*     */     public final void _nextSet(int param1Int, Integer param1Integer) {
/* 907 */       if (!isAtomic()) {
/* 908 */         nextSet(param1Int, param1Integer);
/*     */       }
/*     */     }
/*     */     
/*     */     public final void _nextReplace(int param1Int1, int param1Int2, List<? extends Integer> param1List) {
/* 913 */       if (!isAtomic()) {
/* 914 */         nextReplace(param1Int1, param1Int2, param1List);
/*     */       }
/*     */     }
/*     */     
/*     */     public final void _nextRemove(int param1Int, List<? extends Integer> param1List) {
/* 919 */       if (!isAtomic()) {
/* 920 */         nextRemove(param1Int, param1List);
/*     */       }
/*     */     }
/*     */     
/*     */     public final void _nextRemove(int param1Int, Integer param1Integer) {
/* 925 */       if (!isAtomic()) {
/* 926 */         nextRemove(param1Int, param1Integer);
/*     */       }
/*     */     }
/*     */     
/*     */     public final void _nextPermutation(int param1Int1, int param1Int2, int[] param1ArrayOfint) {
/* 931 */       if (!isAtomic()) {
/* 932 */         nextPermutation(param1Int1, param1Int2, param1ArrayOfint);
/*     */       }
/*     */     }
/*     */     
/*     */     public final void _nextAdd(int param1Int1, int param1Int2) {
/* 937 */       if (!isAtomic())
/* 938 */         nextAdd(param1Int1, param1Int2); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\MultipleSelectionModelBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */