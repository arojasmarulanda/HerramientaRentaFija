/*      */ package javafx.scene.control.skin;
/*      */ 
/*      */ import com.sun.javafx.PlatformUtil;
/*      */ import com.sun.javafx.scene.control.Properties;
/*      */ import com.sun.javafx.scene.control.behavior.TextInputControlBehavior;
/*      */ import com.sun.javafx.scene.control.skin.FXVK;
/*      */ import com.sun.javafx.scene.input.ExtendedInputMethodRequests;
/*      */ import com.sun.javafx.tk.FontMetrics;
/*      */ import com.sun.javafx.tk.Toolkit;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.security.AccessController;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.Timeline;
/*      */ import javafx.application.ConditionalFeature;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.binding.BooleanBinding;
/*      */ import javafx.beans.binding.ObjectBinding;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.value.ObservableBooleanValue;
/*      */ import javafx.beans.value.ObservableObjectValue;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableBooleanProperty;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.BooleanConverter;
/*      */ import javafx.css.converter.PaintConverter;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.geometry.Point2D;
/*      */ import javafx.geometry.Rectangle2D;
/*      */ import javafx.scene.AccessibleAction;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.control.IndexRange;
/*      */ import javafx.scene.control.SkinBase;
/*      */ import javafx.scene.control.TextInputControl;
/*      */ import javafx.scene.input.InputMethodEvent;
/*      */ import javafx.scene.input.InputMethodHighlight;
/*      */ import javafx.scene.input.InputMethodTextRun;
/*      */ import javafx.scene.layout.StackPane;
/*      */ import javafx.scene.paint.Color;
/*      */ import javafx.scene.paint.Paint;
/*      */ import javafx.scene.shape.HLineTo;
/*      */ import javafx.scene.shape.Line;
/*      */ import javafx.scene.shape.LineTo;
/*      */ import javafx.scene.shape.MoveTo;
/*      */ import javafx.scene.shape.Path;
/*      */ import javafx.scene.shape.PathElement;
/*      */ import javafx.scene.shape.Shape;
/*      */ import javafx.scene.shape.VLineTo;
/*      */ import javafx.stage.Window;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class TextInputControlSkin<T extends TextInputControl>
/*      */   extends SkinBase<T>
/*      */ {
/*      */   public enum TextUnit
/*      */   {
/*  109 */     CHARACTER, WORD, LINE, PARAGRAPH, PAGE;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Direction
/*      */   {
/*  116 */     LEFT, RIGHT, UP, DOWN, BEGINNING, END; }
/*      */   static boolean preload = false;
/*      */   
/*      */   static {
/*  120 */     AccessController.doPrivileged(() -> {
/*      */           String str = System.getProperty("com.sun.javafx.virtualKeyboard.preload");
/*      */           if (str != null && str.equalsIgnoreCase("PRERENDER")) {
/*      */             preload = true;
/*      */           }
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   static final boolean SHOW_HANDLES = (Properties.IS_TOUCH_SUPPORTED && !PlatformUtil.isIOS());
/*      */   
/*  137 */   private static final boolean IS_FXVK_SUPPORTED = Platform.isSupported(ConditionalFeature.VIRTUAL_KEYBOARD);
/*      */ 
/*      */ 
/*      */   
/*      */   final ObservableObjectValue<FontMetrics> fontMetrics;
/*      */ 
/*      */   
/*      */   private ObservableBooleanValue caretVisible;
/*      */ 
/*      */   
/*  147 */   private CaretBlinking caretBlinking = new CaretBlinking(blinkProperty());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  155 */   final Path caretPath = new Path();
/*      */   
/*  157 */   StackPane caretHandle = null;
/*  158 */   StackPane selectionHandle1 = null;
/*  159 */   StackPane selectionHandle2 = null;
/*      */   
/*      */   private int imstart;
/*      */   
/*      */   private int imlength;
/*      */   
/*  165 */   private List<Shape> imattrs = new ArrayList<>();
/*      */   
/*      */   private BooleanProperty blink;
/*      */   
/*      */   private final ObjectProperty<Paint> textFill;
/*      */   
/*      */   private final ObjectProperty<Paint> promptTextFill;
/*      */   
/*      */   private final ObjectProperty<Paint> highlightFill;
/*      */   
/*      */   private final ObjectProperty<Paint> highlightTextFill;
/*      */   
/*      */   private final BooleanProperty displayCaret;
/*      */   
/*      */   private BooleanProperty forwardBias;
/*      */ 
/*      */   
/*      */   public TextInputControlSkin(final T control) {
/*  183 */     super(control);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  381 */     this.textFill = new StyleableObjectProperty<Paint>(Color.BLACK) {
/*      */         protected void invalidated() {
/*  383 */           TextInputControlSkin.this.updateTextFill();
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  387 */           return TextInputControlSkin.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  391 */           return "textFill";
/*      */         }
/*      */         
/*      */         public CssMetaData<TextInputControl, Paint> getCssMetaData() {
/*  395 */           return TextInputControlSkin.StyleableProperties.TEXT_FILL;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  414 */     this.promptTextFill = new StyleableObjectProperty<Paint>(Color.GRAY) {
/*      */         public Object getBean() {
/*  416 */           return TextInputControlSkin.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  420 */           return "promptTextFill";
/*      */         }
/*      */         
/*      */         public CssMetaData<TextInputControl, Paint> getCssMetaData() {
/*  424 */           return TextInputControlSkin.StyleableProperties.PROMPT_TEXT_FILL;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  446 */     this.highlightFill = new StyleableObjectProperty<Paint>(Color.DODGERBLUE) {
/*      */         protected void invalidated() {
/*  448 */           TextInputControlSkin.this.updateHighlightFill();
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  452 */           return TextInputControlSkin.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  456 */           return "highlightFill";
/*      */         }
/*      */         
/*      */         public CssMetaData<TextInputControl, Paint> getCssMetaData() {
/*  460 */           return TextInputControlSkin.StyleableProperties.HIGHLIGHT_FILL;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  479 */     this.highlightTextFill = new StyleableObjectProperty<Paint>(Color.WHITE) {
/*      */         protected void invalidated() {
/*  481 */           TextInputControlSkin.this.updateHighlightTextFill();
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  485 */           return TextInputControlSkin.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  489 */           return "highlightTextFill";
/*      */         }
/*      */         
/*      */         public CssMetaData<TextInputControl, Paint> getCssMetaData() {
/*  493 */           return TextInputControlSkin.StyleableProperties.HIGHLIGHT_TEXT_FILL;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  512 */     this.displayCaret = new StyleableBooleanProperty(true) {
/*      */         public Object getBean() {
/*  514 */           return TextInputControlSkin.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  518 */           return "displayCaret";
/*      */         }
/*      */         
/*      */         public CssMetaData<TextInputControl, Boolean> getCssMetaData() {
/*  522 */           return TextInputControlSkin.StyleableProperties.DISPLAY_CARET;
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  541 */     this.forwardBias = new SimpleBooleanProperty(this, "forwardBias", true); this.fontMetrics = new ObjectBinding<FontMetrics>() { protected FontMetrics computeValue() { TextInputControlSkin.this.invalidateMetrics(); return Toolkit.getToolkit().getFontLoader().getFontMetrics(control.getFont()); } }
/*      */       ; this.caretVisible = new BooleanBinding() { protected boolean computeValue() { return (!TextInputControlSkin.this.blinkProperty().get() && TextInputControlSkin.this.displayCaret.get() && control.isFocused() && (PlatformUtil.isWindows() || control.getCaretPosition() == control.getAnchor()) && !control.isDisabled() && control.isEditable()); } }; if (SHOW_HANDLES) { this.caretHandle = new StackPane(); this.selectionHandle1 = new StackPane(); this.selectionHandle2 = new StackPane(); this.caretHandle.setManaged(false); this.selectionHandle1.setManaged(false); this.selectionHandle2.setManaged(false); this.caretHandle.visibleProperty().bind(new BooleanBinding() { protected boolean computeValue() { return (TextInputControlSkin.this.displayCaret.get() && control.isFocused() && control.getCaretPosition() == control.getAnchor() && !control.isDisabled() && control.isEditable() && control.getLength() > 0); } }); this.selectionHandle1.visibleProperty().bind(new BooleanBinding() { protected boolean computeValue() { return (TextInputControlSkin.this.displayCaret.get() && control.isFocused() && control.getCaretPosition() != control.getAnchor() && !control.isDisabled()); } }); this.selectionHandle2.visibleProperty().bind(new BooleanBinding() { protected boolean computeValue() { return (TextInputControlSkin.this.displayCaret.get() && control.isFocused() && control.getCaretPosition() != control.getAnchor() && !control.isDisabled()); } }); this.caretHandle.getStyleClass().setAll(new String[] { "caret-handle" }); this.selectionHandle1.getStyleClass().setAll(new String[] { "selection-handle" }); this.selectionHandle2.getStyleClass().setAll(new String[] { "selection-handle" }); this.selectionHandle1.setId("selection-handle-1"); this.selectionHandle2.setId("selection-handle-2"); }  if (IS_FXVK_SUPPORTED) { if (preload) { Scene scene = control.getScene(); if (scene != null) { Window window = scene.getWindow(); if (window != null) FXVK.init((Node)control);  }  }  control.focusedProperty().addListener(paramObservable -> { if (FXVK.useFXVK()) { Scene scene = ((TextInputControl)getSkinnable()).getScene(); if (paramTextInputControl.isEditable() && paramTextInputControl.isFocused()) { FXVK.attach(paramTextInputControl); } else if (scene == null || scene.getWindow() == null || !scene.getWindow().isFocused() || !(scene.getFocusOwner() instanceof TextInputControl) || !((TextInputControl)scene.getFocusOwner()).isEditable()) { FXVK.detach(); }  }  }); }  if (control.getOnInputMethodTextChanged() == null) control.setOnInputMethodTextChanged(paramInputMethodEvent -> handleInputMethodEvent(paramInputMethodEvent));  control.setInputMethodRequests(new ExtendedInputMethodRequests() { public Point2D getTextLocation(int param1Int) { Scene scene = ((TextInputControl)TextInputControlSkin.this.getSkinnable()).getScene(); Window window = scene.getWindow(); Rectangle2D rectangle2D = TextInputControlSkin.this.getCharacterBounds(control.getSelection().getStart() + param1Int); Point2D point2D = ((TextInputControl)TextInputControlSkin.this.getSkinnable()).localToScene(rectangle2D.getMinX(), rectangle2D.getMaxY()); return new Point2D(window.getX() + scene.getX() + point2D.getX(), window.getY() + scene.getY() + point2D.getY()); } public int getLocationOffset(int param1Int1, int param1Int2) { return TextInputControlSkin.this.getInsertionPoint(param1Int1, param1Int2); } public void cancelLatestCommittedText() {} public String getSelectedText() { TextInputControl textInputControl = TextInputControlSkin.this.getSkinnable(); IndexRange indexRange = textInputControl.getSelection(); return textInputControl.getText(indexRange.getStart(), indexRange.getEnd()); } public int getInsertPositionOffset() { int i = ((TextInputControl)TextInputControlSkin.this.getSkinnable()).getCaretPosition(); if (i < TextInputControlSkin.this.imstart) return i;  if (i < TextInputControlSkin.this.imstart + TextInputControlSkin.this.imlength) return TextInputControlSkin.this.imstart;  return i - TextInputControlSkin.this.imlength; } public String getCommittedText(int param1Int1, int param1Int2) { TextInputControl textInputControl = TextInputControlSkin.this.getSkinnable(); if (param1Int1 < TextInputControlSkin.this.imstart) { if (param1Int2 <= TextInputControlSkin.this.imstart) return textInputControl.getText(param1Int1, param1Int2);  return textInputControl.getText(param1Int1, TextInputControlSkin.this.imstart) + textInputControl.getText(param1Int1, TextInputControlSkin.this.imstart); }  return textInputControl.getText(param1Int1 + TextInputControlSkin.this.imlength, param1Int2 + TextInputControlSkin.this.imlength); } public int getCommittedTextLength() { return ((TextInputControl)TextInputControlSkin.this.getSkinnable()).getText().length() - TextInputControlSkin.this.imlength; } });
/*  543 */   } private final void setBlink(boolean paramBoolean) { blinkProperty().set(paramBoolean); } private final boolean isBlink() { return blinkProperty().get(); } private final BooleanProperty blinkProperty() { if (this.blink == null) this.blink = new SimpleBooleanProperty(this, "blink", true);  return this.blink; } protected final void setTextFill(Paint paramPaint) { this.textFill.set(paramPaint); } protected final Paint getTextFill() { return this.textFill.get(); } protected final ObjectProperty<Paint> textFillProperty() { return this.textFill; } protected final void setPromptTextFill(Paint paramPaint) { this.promptTextFill.set(paramPaint); } protected final Paint getPromptTextFill() { return this.promptTextFill.get(); } protected final ObjectProperty<Paint> promptTextFillProperty() { return this.promptTextFill; } protected final BooleanProperty forwardBiasProperty() { return this.forwardBias; }
/*      */   protected final void setHighlightFill(Paint paramPaint) { this.highlightFill.set(paramPaint); }
/*      */   protected final Paint getHighlightFill() { return this.highlightFill.get(); }
/*      */   protected final ObjectProperty<Paint> highlightFillProperty() { return this.highlightFill; }
/*  547 */   protected final void setHighlightTextFill(Paint paramPaint) { this.highlightTextFill.set(paramPaint); } protected final Paint getHighlightTextFill() { return this.highlightTextFill.get(); } protected final ObjectProperty<Paint> highlightTextFillProperty() { return this.highlightTextFill; } private final void setDisplayCaret(boolean paramBoolean) { this.displayCaret.set(paramBoolean); } private final boolean isDisplayCaret() { return this.displayCaret.get(); } private final BooleanProperty displayCaretProperty() { return this.displayCaret; } public final void setForwardBias(boolean paramBoolean) { this.forwardBias.set(paramBoolean); }
/*      */   
/*      */   protected final boolean isForwardBias() {
/*  550 */     return this.forwardBias.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Point2D getMenuPosition() {
/*  612 */     if (SHOW_HANDLES) {
/*  613 */       if (this.caretHandle.isVisible())
/*  614 */         return new Point2D(this.caretHandle.getLayoutX() + this.caretHandle.getWidth() / 2.0D, this.caretHandle
/*  615 */             .getLayoutY()); 
/*  616 */       if (this.selectionHandle1.isVisible() && this.selectionHandle2.isVisible()) {
/*  617 */         return new Point2D((this.selectionHandle1.getLayoutX() + this.selectionHandle1.getWidth() / 2.0D + this.selectionHandle2
/*  618 */             .getLayoutX() + this.selectionHandle2.getWidth() / 2.0D) / 2.0D, this.selectionHandle2
/*  619 */             .getLayoutY() + this.selectionHandle2.getHeight() / 2.0D);
/*      */       }
/*  621 */       return null;
/*      */     } 
/*      */     
/*  624 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String maskText(String paramString) {
/*  638 */     return paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getInsertionPoint(double paramDouble1, double paramDouble2) {
/*  648 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Rectangle2D getCharacterBounds(int paramInt) {
/*  656 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void scrollCharacterToVisible(int paramInt) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void invalidateMetrics() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateTextFill() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateHighlightFill() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateHighlightTextFill() {}
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleInputMethodEvent(InputMethodEvent paramInputMethodEvent) {
/*  687 */     TextInputControl textInputControl = (TextInputControl)getSkinnable();
/*  688 */     if (textInputControl.isEditable() && !textInputControl.textProperty().isBound() && !textInputControl.isDisabled()) {
/*      */ 
/*      */       
/*  691 */       if (PlatformUtil.isIOS()) {
/*  692 */         textInputControl.setText(paramInputMethodEvent.getCommitted());
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  697 */       if (this.imlength != 0) {
/*  698 */         removeHighlight((List)this.imattrs);
/*  699 */         this.imattrs.clear();
/*  700 */         textInputControl.selectRange(this.imstart, this.imstart + this.imlength);
/*      */       } 
/*      */ 
/*      */       
/*  704 */       if (paramInputMethodEvent.getCommitted().length() != 0) {
/*  705 */         String str = paramInputMethodEvent.getCommitted();
/*  706 */         textInputControl.replaceText(textInputControl.getSelection(), str);
/*      */       } 
/*      */ 
/*      */       
/*  710 */       this.imstart = textInputControl.getSelection().getStart();
/*  711 */       StringBuilder stringBuilder = new StringBuilder();
/*  712 */       for (InputMethodTextRun inputMethodTextRun : paramInputMethodEvent.getComposed()) {
/*  713 */         stringBuilder.append(inputMethodTextRun.getText());
/*      */       }
/*  715 */       textInputControl.replaceText(textInputControl.getSelection(), stringBuilder.toString());
/*  716 */       this.imlength = stringBuilder.length();
/*  717 */       if (this.imlength != 0) {
/*  718 */         int i = this.imstart;
/*  719 */         for (InputMethodTextRun inputMethodTextRun : paramInputMethodEvent.getComposed()) {
/*  720 */           int k = i + inputMethodTextRun.getText().length();
/*  721 */           createInputMethodAttributes(inputMethodTextRun.getHighlight(), i, k);
/*  722 */           i = k;
/*      */         } 
/*  724 */         addHighlight((List)this.imattrs, this.imstart);
/*      */ 
/*      */         
/*  727 */         int j = paramInputMethodEvent.getCaretPosition();
/*  728 */         if (j >= 0 && j < this.imlength) {
/*  729 */           textInputControl.selectRange(this.imstart + j, this.imstart + j);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCaretAnimating(boolean paramBoolean) {
/*  743 */     if (paramBoolean) {
/*  744 */       this.caretBlinking.start();
/*      */     } else {
/*  746 */       this.caretBlinking.stop();
/*  747 */       blinkProperty().set(true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TextInputControlBehavior getBehavior() {
/*  760 */     return null;
/*      */   }
/*      */   
/*      */   ObservableBooleanValue caretVisibleProperty() {
/*  764 */     return this.caretVisible;
/*      */   }
/*      */   
/*      */   boolean isRTL() {
/*  768 */     return (((TextInputControl)getSkinnable()).getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT);
/*      */   }
/*      */   
/*      */   private void createInputMethodAttributes(InputMethodHighlight paramInputMethodHighlight, int paramInt1, int paramInt2) {
/*  772 */     double d1 = 0.0D;
/*  773 */     double d2 = 0.0D;
/*  774 */     double d3 = 0.0D;
/*  775 */     double d4 = 0.0D;
/*      */     
/*  777 */     PathElement[] arrayOfPathElement = getUnderlineShape(paramInt1, paramInt2);
/*  778 */     for (byte b = 0; b < arrayOfPathElement.length; b++) {
/*  779 */       PathElement pathElement = arrayOfPathElement[b];
/*      */       
/*  781 */       d1 = d2 = ((MoveTo)pathElement).getX();
/*  782 */       d3 = d4 = ((MoveTo)pathElement).getY();
/*  783 */       if (pathElement instanceof LineTo) {
/*  784 */         d1 = (d1 < ((LineTo)pathElement).getX()) ? d1 : ((LineTo)pathElement).getX();
/*  785 */         d2 = (d2 > ((LineTo)pathElement).getX()) ? d2 : ((LineTo)pathElement).getX();
/*  786 */         d3 = (d3 < ((LineTo)pathElement).getY()) ? d3 : ((LineTo)pathElement).getY();
/*  787 */         d4 = (d4 > ((LineTo)pathElement).getY()) ? d4 : ((LineTo)pathElement).getY();
/*  788 */       } else if (pathElement instanceof HLineTo) {
/*  789 */         d1 = (d1 < ((HLineTo)pathElement).getX()) ? d1 : ((HLineTo)pathElement).getX();
/*  790 */         d2 = (d2 > ((HLineTo)pathElement).getX()) ? d2 : ((HLineTo)pathElement).getX();
/*  791 */       } else if (pathElement instanceof VLineTo) {
/*  792 */         d3 = (d3 < ((VLineTo)pathElement).getY()) ? d3 : ((VLineTo)pathElement).getY();
/*  793 */         d4 = (d4 > ((VLineTo)pathElement).getY()) ? d4 : ((VLineTo)pathElement).getY();
/*      */       } 
/*      */       
/*  796 */       if (pathElement instanceof javafx.scene.shape.ClosePath || b == arrayOfPathElement.length - 1 || (b < arrayOfPathElement.length - 1 && arrayOfPathElement[b + 1] instanceof MoveTo)) {
/*      */         Line line;
/*      */ 
/*      */         
/*  800 */         Path path = null;
/*  801 */         if (paramInputMethodHighlight == InputMethodHighlight.SELECTED_RAW) {
/*      */           
/*  803 */           path = new Path();
/*  804 */           path.getElements().addAll(getRangeShape(paramInt1, paramInt2));
/*  805 */           path.setFill(Color.BLUE);
/*  806 */           path.setOpacity(0.30000001192092896D);
/*  807 */         } else if (paramInputMethodHighlight == InputMethodHighlight.UNSELECTED_RAW) {
/*      */           
/*  809 */           line = new Line(d1 + 2.0D, d4 + 1.0D, d2 - 2.0D, d4 + 1.0D);
/*  810 */           line.setStroke(this.textFill.get());
/*  811 */           line.setStrokeWidth(d4 - d3);
/*  812 */           ObservableList<Double> observableList = line.getStrokeDashArray();
/*  813 */           observableList.add(Double.valueOf(2.0D));
/*  814 */           observableList.add(Double.valueOf(2.0D));
/*  815 */         } else if (paramInputMethodHighlight == InputMethodHighlight.SELECTED_CONVERTED) {
/*      */           
/*  817 */           line = new Line(d1 + 2.0D, d4 + 1.0D, d2 - 2.0D, d4 + 1.0D);
/*  818 */           line.setStroke(this.textFill.get());
/*  819 */           line.setStrokeWidth((d4 - d3) * 3.0D);
/*  820 */         } else if (paramInputMethodHighlight == InputMethodHighlight.UNSELECTED_CONVERTED) {
/*      */           
/*  822 */           line = new Line(d1 + 2.0D, d4 + 1.0D, d2 - 2.0D, d4 + 1.0D);
/*  823 */           line.setStroke(this.textFill.get());
/*  824 */           line.setStrokeWidth(d4 - d3);
/*      */         } 
/*      */         
/*  827 */         if (line != null) {
/*  828 */           line.setManaged(false);
/*  829 */           this.imattrs.add(line);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class CaretBlinking
/*      */   {
/*      */     private final Timeline caretTimeline;
/*      */ 
/*      */     
/*      */     private final WeakReference<BooleanProperty> blinkPropertyRef;
/*      */ 
/*      */ 
/*      */     
/*      */     public CaretBlinking(BooleanProperty param1BooleanProperty) {
/*  848 */       this.blinkPropertyRef = new WeakReference<>(param1BooleanProperty);
/*      */       
/*  850 */       this.caretTimeline = new Timeline();
/*  851 */       this.caretTimeline.setCycleCount(-1);
/*  852 */       this.caretTimeline.getKeyFrames().addAll(new KeyFrame[] { new KeyFrame(Duration.ZERO, param1ActionEvent -> setBlink(false), new javafx.animation.KeyValue[0]), new KeyFrame(
/*      */               
/*  854 */               Duration.seconds(0.5D), param1ActionEvent -> setBlink(true), new javafx.animation.KeyValue[0]), new KeyFrame(
/*  855 */               Duration.seconds(1.0D), new javafx.animation.KeyValue[0]) });
/*      */     }
/*      */     
/*      */     public void start() {
/*  859 */       this.caretTimeline.play();
/*      */     }
/*      */     
/*      */     public void stop() {
/*  863 */       this.caretTimeline.stop();
/*      */     }
/*      */     
/*      */     private void setBlink(boolean param1Boolean) {
/*  867 */       BooleanProperty booleanProperty = this.blinkPropertyRef.get();
/*  868 */       if (booleanProperty == null) {
/*  869 */         this.caretTimeline.stop();
/*      */         
/*      */         return;
/*      */       } 
/*  873 */       booleanProperty.set(param1Boolean);
/*      */     }
/*      */   }
/*      */   
/*      */   private static class StyleableProperties
/*      */   {
/*  879 */     private static final CssMetaData<TextInputControl, Paint> TEXT_FILL = new CssMetaData<TextInputControl, Paint>("-fx-text-fill", 
/*      */         
/*  881 */         PaintConverter.getInstance(), Color.BLACK)
/*      */       {
/*      */         public boolean isSettable(TextInputControl param2TextInputControl) {
/*  884 */           TextInputControlSkin textInputControlSkin = (TextInputControlSkin)param2TextInputControl.getSkin();
/*  885 */           return (textInputControlSkin.textFill == null || !textInputControlSkin.textFill.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Paint> getStyleableProperty(TextInputControl param2TextInputControl) {
/*  890 */           TextInputControlSkin textInputControlSkin = (TextInputControlSkin)param2TextInputControl.getSkin();
/*  891 */           return (StyleableProperty<Paint>)textInputControlSkin.textFill;
/*      */         }
/*      */       };
/*      */     
/*  895 */     private static final CssMetaData<TextInputControl, Paint> PROMPT_TEXT_FILL = new CssMetaData<TextInputControl, Paint>("-fx-prompt-text-fill", 
/*      */         
/*  897 */         PaintConverter.getInstance(), Color.GRAY)
/*      */       {
/*      */         public boolean isSettable(TextInputControl param2TextInputControl) {
/*  900 */           TextInputControlSkin textInputControlSkin = (TextInputControlSkin)param2TextInputControl.getSkin();
/*  901 */           return (textInputControlSkin.promptTextFill == null || !textInputControlSkin.promptTextFill.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Paint> getStyleableProperty(TextInputControl param2TextInputControl) {
/*  906 */           TextInputControlSkin textInputControlSkin = (TextInputControlSkin)param2TextInputControl.getSkin();
/*  907 */           return (StyleableProperty<Paint>)textInputControlSkin.promptTextFill;
/*      */         }
/*      */       };
/*      */     
/*  911 */     private static final CssMetaData<TextInputControl, Paint> HIGHLIGHT_FILL = new CssMetaData<TextInputControl, Paint>("-fx-highlight-fill", 
/*      */         
/*  913 */         PaintConverter.getInstance(), Color.DODGERBLUE)
/*      */       {
/*      */         public boolean isSettable(TextInputControl param2TextInputControl) {
/*  916 */           TextInputControlSkin textInputControlSkin = (TextInputControlSkin)param2TextInputControl.getSkin();
/*  917 */           return (textInputControlSkin.highlightFill == null || !textInputControlSkin.highlightFill.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Paint> getStyleableProperty(TextInputControl param2TextInputControl) {
/*  922 */           TextInputControlSkin textInputControlSkin = (TextInputControlSkin)param2TextInputControl.getSkin();
/*  923 */           return (StyleableProperty<Paint>)textInputControlSkin.highlightFill;
/*      */         }
/*      */       };
/*      */     
/*  927 */     private static final CssMetaData<TextInputControl, Paint> HIGHLIGHT_TEXT_FILL = new CssMetaData<TextInputControl, Paint>("-fx-highlight-text-fill", 
/*      */         
/*  929 */         PaintConverter.getInstance(), Color.WHITE)
/*      */       {
/*      */         public boolean isSettable(TextInputControl param2TextInputControl) {
/*  932 */           TextInputControlSkin textInputControlSkin = (TextInputControlSkin)param2TextInputControl.getSkin();
/*  933 */           return (textInputControlSkin.highlightTextFill == null || !textInputControlSkin.highlightTextFill.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Paint> getStyleableProperty(TextInputControl param2TextInputControl) {
/*  938 */           TextInputControlSkin textInputControlSkin = (TextInputControlSkin)param2TextInputControl.getSkin();
/*  939 */           return (StyleableProperty<Paint>)textInputControlSkin.highlightTextFill;
/*      */         }
/*      */       };
/*      */     
/*  943 */     private static final CssMetaData<TextInputControl, Boolean> DISPLAY_CARET = new CssMetaData<TextInputControl, Boolean>("-fx-display-caret", 
/*      */         
/*  945 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*      */       {
/*      */         public boolean isSettable(TextInputControl param2TextInputControl) {
/*  948 */           TextInputControlSkin textInputControlSkin = (TextInputControlSkin)param2TextInputControl.getSkin();
/*  949 */           return (textInputControlSkin.displayCaret == null || !textInputControlSkin.displayCaret.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(TextInputControl param2TextInputControl) {
/*  954 */           TextInputControlSkin textInputControlSkin = (TextInputControlSkin)param2TextInputControl.getSkin();
/*  955 */           return (StyleableProperty<Boolean>)textInputControlSkin.displayCaret;
/*      */         }
/*      */       };
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/*  962 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(SkinBase.getClassCssMetaData());
/*  963 */       arrayList.add(TEXT_FILL);
/*  964 */       arrayList.add(PROMPT_TEXT_FILL);
/*  965 */       arrayList.add(HIGHLIGHT_FILL);
/*  966 */       arrayList.add(HIGHLIGHT_TEXT_FILL);
/*  967 */       arrayList.add(DISPLAY_CARET);
/*      */       
/*  969 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/*  980 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/*  987 */     return getClassCssMetaData();
/*      */   }
/*      */   protected void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*      */     Integer integer1, integer2;
/*  991 */     switch (paramAccessibleAction) {
/*      */       case SHOW_TEXT_RANGE:
/*  993 */         integer1 = (Integer)paramVarArgs[0];
/*  994 */         integer2 = (Integer)paramVarArgs[1];
/*  995 */         if (integer1 != null && integer2 != null) {
/*  996 */           scrollCharacterToVisible(integer2.intValue());
/*  997 */           scrollCharacterToVisible(integer1.intValue());
/*  998 */           scrollCharacterToVisible(integer2.intValue());
/*      */         } 
/*      */         return;
/*      */     } 
/* 1002 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*      */   }
/*      */   
/*      */   protected abstract PathElement[] getUnderlineShape(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract PathElement[] getRangeShape(int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void addHighlight(List<? extends Node> paramList, int paramInt);
/*      */   
/*      */   protected abstract void removeHighlight(List<? extends Node> paramList);
/*      */   
/*      */   public abstract void moveCaret(TextUnit paramTextUnit, Direction paramDirection, boolean paramBoolean);
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TextInputControlSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */