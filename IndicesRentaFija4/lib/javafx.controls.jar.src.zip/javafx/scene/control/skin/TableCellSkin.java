/*    */ package javafx.scene.control.skin;
/*    */ 
/*    */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*    */ import com.sun.javafx.scene.control.behavior.TableCellBehavior;
/*    */ import javafx.beans.property.ReadOnlyObjectProperty;
/*    */ import javafx.scene.control.TableCell;
/*    */ import javafx.scene.control.TableColumn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableCellSkin<S, T>
/*    */   extends TableCellSkinBase<S, T, TableCell<S, T>>
/*    */ {
/*    */   private final BehaviorBase<TableCell<S, T>> behavior;
/*    */   
/*    */   public TableCellSkin(TableCell<S, T> paramTableCell) {
/* 71 */     super(paramTableCell);
/*    */ 
/*    */     
/* 74 */     this.behavior = new TableCellBehavior<>(paramTableCell);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void dispose() {
/* 88 */     super.dispose();
/*    */     
/* 90 */     if (this.behavior != null) {
/* 91 */       this.behavior.dispose();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public ReadOnlyObjectProperty<TableColumn<S, T>> tableColumnProperty() {
/* 97 */     return getSkinnable().tableColumnProperty();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TableCellSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */