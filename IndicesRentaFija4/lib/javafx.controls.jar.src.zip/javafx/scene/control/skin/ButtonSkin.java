/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.ButtonBehavior;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.Button;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyCodeCombination;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ButtonSkin
/*     */   extends LabeledSkinBase<Button>
/*     */ {
/*     */   private KeyCodeCombination defaultAcceleratorKeyCodeCombination;
/*     */   private KeyCodeCombination cancelAcceleratorKeyCodeCombination;
/*     */   private final BehaviorBase<Button> behavior;
/*     */   Runnable defaultButtonRunnable = () -> {
/*     */       if (getSkinnable().getScene() != null && NodeHelper.isTreeVisible(getSkinnable()) && !getSkinnable().isDisabled())
/*     */         getSkinnable().fire(); 
/*     */     };
/*     */   Runnable cancelButtonRunnable = () -> {
/*     */       if (getSkinnable().getScene() != null && NodeHelper.isTreeVisible(getSkinnable()) && !getSkinnable().isDisabled())
/*     */         getSkinnable().fire(); 
/*     */     };
/*     */   
/*     */   public ButtonSkin(Button paramButton) {
/*  97 */     super(paramButton);
/*     */ 
/*     */     
/* 100 */     this.behavior = new ButtonBehavior<>(paramButton);
/*     */ 
/*     */ 
/*     */     
/* 104 */     registerChangeListener(paramButton.defaultButtonProperty(), paramObservableValue -> setDefaultButton(getSkinnable().isDefaultButton()));
/* 105 */     registerChangeListener(paramButton.cancelButtonProperty(), paramObservableValue -> setCancelButton(getSkinnable().isCancelButton()));
/* 106 */     registerChangeListener(paramButton.focusedProperty(), paramObservableValue -> {
/*     */           if (!getSkinnable().isFocused()) {
/*     */             ContextMenu contextMenu = getSkinnable().getContextMenu();
/*     */             
/*     */             if (contextMenu != null && contextMenu.isShowing()) {
/*     */               contextMenu.hide();
/*     */               
/*     */               Utils.removeMnemonics(contextMenu, getSkinnable().getScene());
/*     */             } 
/*     */           } 
/*     */         });
/* 117 */     registerChangeListener(paramButton.parentProperty(), paramObservableValue -> {
/*     */           if (getSkinnable().getParent() == null && getSkinnable().getScene() != null) {
/*     */             if (getSkinnable().isDefaultButton()) {
/*     */               getSkinnable().getScene().getAccelerators().remove(this.defaultAcceleratorKeyCodeCombination);
/*     */             }
/*     */             
/*     */             if (getSkinnable().isCancelButton()) {
/*     */               getSkinnable().getScene().getAccelerators().remove(this.cancelAcceleratorKeyCodeCombination);
/*     */             }
/*     */           } 
/*     */         });
/*     */     
/* 129 */     if (getSkinnable().isDefaultButton())
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 134 */       setDefaultButton(true);
/*     */     }
/*     */     
/* 137 */     if (getSkinnable().isCancelButton())
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 142 */       setCancelButton(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 156 */     super.dispose();
/*     */     
/* 158 */     if (this.behavior != null) {
/* 159 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setDefaultButton(boolean paramBoolean) {
/* 172 */     Scene scene = getSkinnable().getScene();
/* 173 */     if (scene != null) {
/* 174 */       KeyCode keyCode = KeyCode.ENTER;
/* 175 */       this.defaultAcceleratorKeyCodeCombination = new KeyCodeCombination(keyCode, new javafx.scene.input.KeyCombination.Modifier[0]);
/*     */       
/* 177 */       Runnable runnable = scene.getAccelerators().get(this.defaultAcceleratorKeyCodeCombination);
/* 178 */       if (!paramBoolean) {
/*     */ 
/*     */ 
/*     */         
/* 182 */         if (this.defaultButtonRunnable.equals(runnable))
/*     */         {
/*     */ 
/*     */           
/* 186 */           scene.getAccelerators().remove(this.defaultAcceleratorKeyCodeCombination);
/*     */         
/*     */         }
/*     */       }
/* 190 */       else if (!this.defaultButtonRunnable.equals(runnable)) {
/* 191 */         scene.getAccelerators().remove(this.defaultAcceleratorKeyCodeCombination);
/* 192 */         scene.getAccelerators().put(this.defaultAcceleratorKeyCodeCombination, this.defaultButtonRunnable);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void setCancelButton(boolean paramBoolean) {
/* 199 */     Scene scene = getSkinnable().getScene();
/* 200 */     if (scene != null) {
/* 201 */       KeyCode keyCode = KeyCode.ESCAPE;
/* 202 */       this.cancelAcceleratorKeyCodeCombination = new KeyCodeCombination(keyCode, new javafx.scene.input.KeyCombination.Modifier[0]);
/*     */       
/* 204 */       Runnable runnable = scene.getAccelerators().get(this.cancelAcceleratorKeyCodeCombination);
/* 205 */       if (!paramBoolean) {
/*     */ 
/*     */ 
/*     */         
/* 209 */         if (this.cancelButtonRunnable.equals(runnable))
/*     */         {
/*     */ 
/*     */           
/* 213 */           scene.getAccelerators().remove(this.cancelAcceleratorKeyCodeCombination);
/*     */         
/*     */         }
/*     */       }
/* 217 */       else if (!this.cancelButtonRunnable.equals(runnable)) {
/* 218 */         scene.getAccelerators().remove(this.cancelAcceleratorKeyCodeCombination);
/* 219 */         scene.getAccelerators().put(this.cancelAcceleratorKeyCodeCombination, this.cancelButtonRunnable);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ButtonSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */