/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ReadOnlyDoubleProperty;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.StyleOrigin;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.scene.control.Cell;
/*     */ import javafx.scene.control.SkinBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CellSkinBase<C extends Cell>
/*     */   extends LabeledSkinBase<C>
/*     */ {
/*     */   private DoubleProperty cellSize;
/*     */   static final double DEFAULT_CELL_SIZE = 24.0D;
/*     */   
/*     */   public CellSkinBase(C paramC) {
/*  72 */     super(paramC);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     consumeMouseEvents(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getCellSize() {
/*  98 */     return (this.cellSize == null) ? 24.0D : this.cellSize.get();
/*     */   }
/*     */   
/*     */   public final ReadOnlyDoubleProperty cellSizeProperty() {
/* 102 */     return cellSizePropertyImpl();
/*     */   }
/*     */   
/*     */   private DoubleProperty cellSizePropertyImpl() {
/* 106 */     if (this.cellSize == null) {
/* 107 */       this.cellSize = new StyleableDoubleProperty(24.0D)
/*     */         {
/*     */           public void applyStyle(StyleOrigin param1StyleOrigin, Number param1Number)
/*     */           {
/* 111 */             double d = (param1Number == null) ? 24.0D : param1Number.doubleValue();
/*     */             
/* 113 */             super.applyStyle(param1StyleOrigin, Double.valueOf((d <= 0.0D) ? 24.0D : d));
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void set(double param1Double) {
/* 125 */             super.set(param1Double);
/* 126 */             ((Cell)CellSkinBase.this.getSkinnable()).requestLayout();
/*     */           }
/*     */           
/*     */           public Object getBean() {
/* 130 */             return CellSkinBase.this;
/*     */           }
/*     */           
/*     */           public String getName() {
/* 134 */             return "cellSize";
/*     */           }
/*     */           
/*     */           public CssMetaData<Cell<?>, Number> getCssMetaData() {
/* 138 */             return CellSkinBase.StyleableProperties.CELL_SIZE;
/*     */           }
/*     */         };
/*     */     }
/* 142 */     return this.cellSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 159 */     private static final CssMetaData<Cell<?>, Number> CELL_SIZE = new CssMetaData<Cell<?>, Number>("-fx-cell-size", 
/*     */         
/* 161 */         SizeConverter.getInstance(), Double.valueOf(24.0D))
/*     */       {
/*     */         public boolean isSettable(Cell<?> param2Cell)
/*     */         {
/* 165 */           CellSkinBase cellSkinBase = (CellSkinBase)param2Cell.getSkin();
/* 166 */           return (cellSkinBase.cellSize == null || !cellSkinBase.cellSize.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(Cell<?> param2Cell) {
/* 171 */           CellSkinBase cellSkinBase = (CellSkinBase)param2Cell.getSkin();
/* 172 */           return (StyleableProperty<Number>)cellSkinBase.cellSizePropertyImpl();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 180 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(SkinBase.getClassCssMetaData());
/* 181 */       arrayList.add(CELL_SIZE);
/* 182 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 194 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 199 */     return getClassCssMetaData();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\CellSkinBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */