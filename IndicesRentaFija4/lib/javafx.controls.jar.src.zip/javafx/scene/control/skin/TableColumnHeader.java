/*      */ package javafx.scene.control.skin;
/*      */ 
/*      */ import com.sun.javafx.scene.control.LambdaMultiplePropertyChangeListenerHandler;
/*      */ import com.sun.javafx.scene.control.Properties;
/*      */ import com.sun.javafx.scene.control.TableColumnBaseHelper;
/*      */ import com.sun.javafx.scene.control.TableColumnSortTypeWrapper;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.collections.WeakListChangeListener;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.geometry.HPos;
/*      */ import javafx.geometry.Insets;
/*      */ import javafx.geometry.Pos;
/*      */ import javafx.geometry.VPos;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.ContextMenu;
/*      */ import javafx.scene.control.Label;
/*      */ import javafx.scene.control.TableColumn;
/*      */ import javafx.scene.control.TableColumnBase;
/*      */ import javafx.scene.input.ContextMenuEvent;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.layout.GridPane;
/*      */ import javafx.scene.layout.HBox;
/*      */ import javafx.scene.layout.Priority;
/*      */ import javafx.scene.layout.Region;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TableColumnHeader
/*      */   extends Region
/*      */ {
/*      */   static final String DEFAULT_STYLE_CLASS = "column-header";
/*      */   static final double DEFAULT_COLUMN_WIDTH = 80.0D;
/*      */   private boolean autoSizeComplete = false;
/*      */   private double dragOffset;
/*      */   private NestedTableColumnHeader nestedColumnHeader;
/*      */   private TableHeaderRow tableHeaderRow;
/*      */   private NestedTableColumnHeader parentHeader;
/*      */   Label label;
/*  115 */   int sortPos = -1;
/*      */   
/*      */   private Region arrow;
/*      */   
/*      */   private Label sortOrderLabel;
/*      */   
/*      */   private HBox sortOrderDots;
/*      */   
/*      */   private Node sortArrow;
/*      */   private boolean isSortColumn;
/*      */   private boolean isSizeDirty = false;
/*      */   boolean isLastVisibleColumn = false;
/*  127 */   int columnIndex = -1; private int newColumnPos; Region columnReorderLine; final LambdaMultiplePropertyChangeListenerHandler changeListenerHandler; private ListChangeListener<TableColumnBase<?, ?>> sortOrderListener; private ListChangeListener<TableColumnBase<?, ?>> visibleLeafColumnsListener; private ListChangeListener<String> styleClassListener; private WeakListChangeListener<TableColumnBase<?, ?>> weakSortOrderListener; private final WeakListChangeListener<TableColumnBase<?, ?>> weakVisibleLeafColumnsListener; private final WeakListChangeListener<String> weakStyleClassListener; private static final EventHandler<MouseEvent> mousePressedHandler; private static final EventHandler<MouseEvent> mouseDraggedHandler; private static final EventHandler<MouseEvent> mouseReleasedHandler; private static final EventHandler<ContextMenuEvent> contextMenuRequestedHandler; private DoubleProperty size; private ReadOnlyObjectWrapper<TableColumnBase<?, ?>> tableColumn; static {
/*      */     mousePressedHandler = (paramMouseEvent -> {
/*      */         TableColumnHeader tableColumnHeader = (TableColumnHeader)paramMouseEvent.getSource();
/*      */         TableColumnBase<?, ?> tableColumnBase = tableColumnHeader.getTableColumn();
/*      */         ContextMenu contextMenu = tableColumnBase.getContextMenu();
/*      */         if (contextMenu != null && contextMenu.isShowing())
/*      */           contextMenu.hide(); 
/*      */         if (paramMouseEvent.isConsumed())
/*      */           return; 
/*      */         paramMouseEvent.consume();
/*      */         (tableColumnHeader.getTableHeaderRow()).columnDragLock = true;
/*      */         tableColumnHeader.getTableSkin().getSkinnable().requestFocus();
/*      */         if (paramMouseEvent.isPrimaryButtonDown() && tableColumnHeader.isColumnReorderingEnabled())
/*      */           tableColumnHeader.columnReorderingStarted(paramMouseEvent.getX()); 
/*      */       });
/*      */     mouseDraggedHandler = (paramMouseEvent -> {
/*      */         if (paramMouseEvent.isConsumed())
/*      */           return; 
/*      */         paramMouseEvent.consume();
/*      */         TableColumnHeader tableColumnHeader = (TableColumnHeader)paramMouseEvent.getSource();
/*      */         if (paramMouseEvent.isPrimaryButtonDown() && tableColumnHeader.isColumnReorderingEnabled())
/*      */           tableColumnHeader.columnReordering(paramMouseEvent.getSceneX(), paramMouseEvent.getSceneY()); 
/*      */       });
/*      */     mouseReleasedHandler = (paramMouseEvent -> {
/*      */         if (paramMouseEvent.isPopupTrigger())
/*      */           return; 
/*      */         if (paramMouseEvent.isConsumed())
/*      */           return; 
/*      */         paramMouseEvent.consume();
/*      */         TableColumnHeader tableColumnHeader = (TableColumnHeader)paramMouseEvent.getSource();
/*      */         (tableColumnHeader.getTableHeaderRow()).columnDragLock = false;
/*      */         if (tableColumnHeader.getTableHeaderRow().isReordering() && tableColumnHeader.isColumnReorderingEnabled()) {
/*      */           tableColumnHeader.columnReorderingComplete();
/*      */         } else if (paramMouseEvent.isStillSincePress()) {
/*      */           tableColumnHeader.sortColumn(paramMouseEvent.isShiftDown());
/*      */         } 
/*      */       });
/*      */     contextMenuRequestedHandler = (paramContextMenuEvent -> {
/*      */         TableColumnHeader tableColumnHeader = (TableColumnHeader)paramContextMenuEvent.getSource();
/*      */         TableColumnBase<?, ?> tableColumnBase = tableColumnHeader.getTableColumn();
/*      */         ContextMenu contextMenu = tableColumnBase.getContextMenu();
/*      */         if (contextMenu != null) {
/*      */           contextMenu.show(tableColumnHeader, paramContextMenuEvent.getScreenX(), paramContextMenuEvent.getScreenY());
/*      */           paramContextMenuEvent.consume();
/*      */         } 
/*      */       });
/*      */   } private final double getSize() {
/*      */     return (this.size == null) ? 20.0D : this.size.doubleValue();
/*      */   }
/*      */   private final DoubleProperty sizeProperty() {
/*      */     if (this.size == null)
/*      */       this.size = new StyleableDoubleProperty(20.0D) {
/*      */           protected void invalidated() {
/*      */             double d = get();
/*      */             if (d <= 0.0D) {
/*      */               if (isBound())
/*      */                 unbind(); 
/*      */               set(20.0D);
/*      */               throw new IllegalArgumentException("Size cannot be 0 or negative");
/*      */             } 
/*      */           }
/*      */           public Object getBean() {
/*      */             return TableColumnHeader.this;
/*      */           }
/*      */           public String getName() {
/*      */             return "size";
/*      */           }
/*      */           public CssMetaData<TableColumnHeader, Number> getCssMetaData() {
/*      */             return TableColumnHeader.StyleableProperties.SIZE;
/*      */           }
/*      */         }; 
/*      */     return this.size;
/*      */   }
/*  200 */   public TableColumnHeader(TableColumnBase<?, ?> paramTableColumnBase) { this.sortOrderListener = (paramChange -> updateSortPosition());
/*      */ 
/*      */ 
/*      */     
/*  204 */     this.visibleLeafColumnsListener = (paramChange -> {
/*      */         updateColumnIndex();
/*      */         
/*      */         updateSortPosition();
/*      */       });
/*  209 */     this.styleClassListener = (paramChange -> {
/*      */         while (paramChange.next()) {
/*      */           if (paramChange.wasRemoved()) {
/*      */             getStyleClass().removeAll(paramChange.getRemoved());
/*      */           }
/*      */           
/*      */           if (paramChange.wasAdded()) {
/*      */             getStyleClass().addAll((Collection)paramChange.getAddedSubList());
/*      */           }
/*      */         } 
/*      */       });
/*  220 */     this.weakSortOrderListener = new WeakListChangeListener<>(this.sortOrderListener);
/*      */     
/*  222 */     this.weakVisibleLeafColumnsListener = new WeakListChangeListener<>(this.visibleLeafColumnsListener);
/*      */     
/*  224 */     this.weakStyleClassListener = new WeakListChangeListener<>(this.styleClassListener);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  339 */     this.tableColumn = new ReadOnlyObjectWrapper<>(this, "tableColumn"); setTableColumn(paramTableColumnBase); setFocusTraversable(false); initStyleClasses(); initUI(); this.changeListenerHandler = new LambdaMultiplePropertyChangeListenerHandler(); this.changeListenerHandler.registerChangeListener(sceneProperty(), paramObservableValue -> updateScene()); if (getTableColumn() != null) { this.changeListenerHandler.registerChangeListener(paramTableColumnBase.idProperty(), paramObservableValue -> setId(paramTableColumnBase.getId())); this.changeListenerHandler.registerChangeListener(paramTableColumnBase.styleProperty(), paramObservableValue -> setStyle(paramTableColumnBase.getStyle())); this.changeListenerHandler.registerChangeListener(paramTableColumnBase.widthProperty(), paramObservableValue -> { this.isSizeDirty = true; requestLayout(); }); this.changeListenerHandler.registerChangeListener(paramTableColumnBase.visibleProperty(), paramObservableValue -> setVisible(getTableColumn().isVisible())); this.changeListenerHandler.registerChangeListener(paramTableColumnBase.sortNodeProperty(), paramObservableValue -> updateSortGrid()); this.changeListenerHandler.registerChangeListener(paramTableColumnBase.sortableProperty(), paramObservableValue -> { if (TableSkinUtils.getSortOrder(getTableSkin()).contains(getTableColumn())) { NestedTableColumnHeader nestedTableColumnHeader = getTableHeaderRow().getRootHeader(); updateAllHeaders(nestedTableColumnHeader); } 
/*      */           }); this.changeListenerHandler.registerChangeListener(paramTableColumnBase.textProperty(), paramObservableValue -> this.label.setText(paramTableColumnBase.getText())); this.changeListenerHandler.registerChangeListener(paramTableColumnBase.graphicProperty(), paramObservableValue -> this.label.setGraphic(paramTableColumnBase.getGraphic())); setId(paramTableColumnBase.getId()); setStyle(paramTableColumnBase.getStyle()); setAccessibleRole(AccessibleRole.TABLE_COLUMN); }
/*  341 */      } private final void setTableColumn(TableColumnBase<?, ?> paramTableColumnBase) { this.tableColumn.set(paramTableColumnBase); }
/*      */   
/*      */   public final TableColumnBase<?, ?> getTableColumn() {
/*  344 */     return this.tableColumn.get();
/*      */   }
/*      */   public final ReadOnlyObjectProperty<TableColumnBase<?, ?>> tableColumnProperty() {
/*  347 */     return this.tableColumn.getReadOnlyProperty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutChildren() {
/*  360 */     if (this.isSizeDirty) {
/*  361 */       resize(getTableColumn().getWidth(), getHeight());
/*  362 */       this.isSizeDirty = false;
/*      */     } 
/*      */     
/*  365 */     double d1 = 0.0D;
/*  366 */     double d2 = snapSizeX(getWidth()) - snappedLeftInset() + snappedRightInset();
/*  367 */     double d3 = getHeight() - snappedTopInset() + snappedBottomInset();
/*  368 */     double d4 = d2;
/*      */ 
/*      */ 
/*      */     
/*  372 */     if (this.arrow != null) {
/*  373 */       this.arrow.setMaxSize(this.arrow.prefWidth(-1.0D), this.arrow.prefHeight(-1.0D));
/*      */     }
/*      */     
/*  376 */     if (this.sortArrow != null && this.sortArrow.isVisible()) {
/*  377 */       d1 = this.sortArrow.prefWidth(-1.0D);
/*  378 */       d4 -= d1;
/*  379 */       this.sortArrow.resize(d1, this.sortArrow.prefHeight(-1.0D));
/*  380 */       positionInArea(this.sortArrow, d4, snappedTopInset(), d1, d3, 0.0D, HPos.CENTER, VPos.CENTER);
/*      */     } 
/*      */ 
/*      */     
/*  384 */     if (this.label != null) {
/*  385 */       double d = d2 - d1;
/*  386 */       this.label.resizeRelocate(snappedLeftInset(), 0.0D, d, getHeight());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computePrefWidth(double paramDouble) {
/*  392 */     if (getNestedColumnHeader() != null) {
/*  393 */       double d = getNestedColumnHeader().prefWidth(paramDouble);
/*      */       
/*  395 */       if (getTableColumn() != null) {
/*  396 */         TableColumnBaseHelper.setWidth(getTableColumn(), d);
/*      */       }
/*      */       
/*  399 */       return d;
/*  400 */     }  if (getTableColumn() != null && getTableColumn().isVisible()) {
/*  401 */       return snapSizeX(getTableColumn().getWidth());
/*      */     }
/*      */     
/*  404 */     return 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computeMinHeight(double paramDouble) {
/*  409 */     return (this.label == null) ? 0.0D : this.label.minHeight(paramDouble);
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computePrefHeight(double paramDouble) {
/*  414 */     if (getTableColumn() == null) return 0.0D; 
/*  415 */     return Math.max(getSize(), this.label.prefHeight(-1.0D));
/*      */   }
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/*  420 */     return getClassCssMetaData();
/*      */   }
/*      */ 
/*      */   
/*      */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*  425 */     switch (paramAccessibleAttribute) { case INDEX:
/*  426 */         return Integer.valueOf(getIndex(getTableColumn()));
/*  427 */       case TEXT: return (getTableColumn() != null) ? getTableColumn().getText() : null; }
/*  428 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initStyleClasses() {
/*  441 */     getStyleClass().setAll(new String[] { "column-header" });
/*  442 */     installTableColumnStyleClassListener();
/*      */   }
/*      */   
/*      */   void installTableColumnStyleClassListener() {
/*  446 */     TableColumnBase<?, ?> tableColumnBase = getTableColumn();
/*  447 */     if (tableColumnBase != null) {
/*      */ 
/*      */       
/*  450 */       getStyleClass().addAll(tableColumnBase.getStyleClass());
/*  451 */       tableColumnBase.getStyleClass().addListener(this.weakStyleClassListener);
/*      */     } 
/*      */   }
/*      */   
/*  455 */   NestedTableColumnHeader getNestedColumnHeader() { return this.nestedColumnHeader; } void setNestedColumnHeader(NestedTableColumnHeader paramNestedTableColumnHeader) {
/*  456 */     this.nestedColumnHeader = paramNestedTableColumnHeader;
/*      */   } TableHeaderRow getTableHeaderRow() {
/*  458 */     return this.tableHeaderRow;
/*      */   } void setTableHeaderRow(TableHeaderRow paramTableHeaderRow) {
/*  460 */     this.tableHeaderRow = paramTableHeaderRow;
/*  461 */     updateTableSkin();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateTableSkin() {
/*  467 */     TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase = getTableSkin();
/*  468 */     if (tableViewSkinBase == null)
/*      */       return; 
/*  470 */     updateColumnIndex();
/*  471 */     this.columnReorderLine = tableViewSkinBase.getColumnReorderLine();
/*      */     
/*  473 */     if (getTableColumn() != null) {
/*  474 */       updateSortPosition();
/*  475 */       TableSkinUtils.getSortOrder(tableViewSkinBase).addListener(this.weakSortOrderListener);
/*  476 */       TableSkinUtils.getVisibleLeafColumns(tableViewSkinBase).addListener(this.weakVisibleLeafColumnsListener);
/*      */     } 
/*      */   }
/*      */   
/*      */   TableViewSkinBase<?, ?, ?, ?, ?> getTableSkin() {
/*  481 */     return (this.tableHeaderRow == null) ? null : this.tableHeaderRow.tableSkin;
/*      */   }
/*      */   
/*  484 */   NestedTableColumnHeader getParentHeader() { return this.parentHeader; } void setParentHeader(NestedTableColumnHeader paramNestedTableColumnHeader) {
/*  485 */     this.parentHeader = paramNestedTableColumnHeader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateAllHeaders(TableColumnHeader paramTableColumnHeader) {
/*  494 */     if (paramTableColumnHeader instanceof NestedTableColumnHeader) {
/*  495 */       ObservableList<TableColumnHeader> observableList = ((NestedTableColumnHeader)paramTableColumnHeader).getColumnHeaders();
/*  496 */       for (byte b = 0; b < observableList.size(); b++) {
/*  497 */         updateAllHeaders(observableList.get(b));
/*      */       }
/*      */     } else {
/*  500 */       paramTableColumnHeader.updateSortPosition();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateScene() {
/*  512 */     if (!this.autoSizeComplete) {
/*  513 */       if (getTableColumn() == null || getTableColumn().getWidth() != 80.0D || getScene() == null) {
/*      */         return;
/*      */       }
/*  516 */       doColumnAutoSize(getTableColumn(), 30);
/*  517 */       this.autoSizeComplete = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   void dispose() {
/*  522 */     TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase = getTableSkin();
/*  523 */     if (tableViewSkinBase != null) {
/*  524 */       TableSkinUtils.getVisibleLeafColumns(tableViewSkinBase).removeListener(this.weakVisibleLeafColumnsListener);
/*  525 */       TableSkinUtils.getSortOrder(tableViewSkinBase).removeListener(this.weakSortOrderListener);
/*      */     } 
/*      */     
/*  528 */     this.changeListenerHandler.dispose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isSortingEnabled() {
/*  535 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isColumnReorderingEnabled() {
/*  540 */     return (!Properties.IS_TOUCH_SUPPORTED && TableSkinUtils.getVisibleLeafColumns((TableViewSkinBase)getTableSkin()).size() > 1);
/*      */   }
/*      */ 
/*      */   
/*      */   private void initUI() {
/*  545 */     if (getTableColumn() == null) {
/*      */       return;
/*      */     }
/*  548 */     setOnMousePressed(mousePressedHandler);
/*  549 */     setOnMouseDragged(mouseDraggedHandler);
/*  550 */     setOnDragDetected(paramMouseEvent -> paramMouseEvent.consume());
/*  551 */     setOnContextMenuRequested(contextMenuRequestedHandler);
/*  552 */     setOnMouseReleased(mouseReleasedHandler);
/*      */ 
/*      */     
/*  555 */     this.label = new Label();
/*  556 */     this.label.setText(getTableColumn().getText());
/*  557 */     this.label.setGraphic(getTableColumn().getGraphic());
/*  558 */     this.label.setVisible(getTableColumn().isVisible());
/*      */ 
/*      */ 
/*      */     
/*  562 */     if (isSortingEnabled())
/*      */     {
/*  564 */       updateSortGrid();
/*      */     }
/*      */   }
/*      */   
/*      */   private void doColumnAutoSize(TableColumnBase<?, ?> paramTableColumnBase, int paramInt) {
/*  569 */     double d = paramTableColumnBase.getPrefWidth();
/*      */ 
/*      */     
/*  572 */     if (d == 80.0D) {
/*  573 */       TableSkinUtils.resizeColumnToFitContent(getTableSkin(), paramTableColumnBase, paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateSortPosition() {
/*  579 */     this.sortPos = !getTableColumn().isSortable() ? -1 : getSortPosition();
/*  580 */     updateSortGrid();
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateSortGrid() {
/*  585 */     if (this instanceof NestedTableColumnHeader)
/*      */       return; 
/*  587 */     getChildren().clear();
/*  588 */     getChildren().add(this.label);
/*      */ 
/*      */     
/*  591 */     if (!isSortingEnabled())
/*      */       return; 
/*  593 */     this.isSortColumn = (this.sortPos != -1);
/*  594 */     if (!this.isSortColumn) {
/*  595 */       if (this.sortArrow != null) {
/*  596 */         this.sortArrow.setVisible(false);
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  602 */     int i = TableSkinUtils.getVisibleLeafIndex(getTableSkin(), getTableColumn());
/*  603 */     if (i == -1)
/*      */       return; 
/*  605 */     int j = getVisibleSortOrderColumnCount();
/*  606 */     boolean bool = (this.sortPos <= 3 && j > 1) ? true : false;
/*      */     
/*  608 */     Node node = null;
/*  609 */     if (getTableColumn().getSortNode() != null) {
/*  610 */       node = getTableColumn().getSortNode();
/*  611 */       getChildren().add(node);
/*      */     } else {
/*  613 */       GridPane gridPane = new GridPane();
/*  614 */       node = gridPane;
/*  615 */       gridPane.setPadding(new Insets(0.0D, 3.0D, 0.0D, 0.0D));
/*  616 */       getChildren().add(gridPane);
/*      */ 
/*      */       
/*  619 */       if (this.arrow == null) {
/*  620 */         this.arrow = new Region();
/*  621 */         this.arrow.getStyleClass().setAll(new String[] { "arrow" });
/*  622 */         this.arrow.setVisible(true);
/*  623 */         this.arrow.setRotate(TableColumnSortTypeWrapper.isAscending(getTableColumn()) ? 180.0D : 0.0D);
/*  624 */         this.changeListenerHandler.registerChangeListener(TableColumnSortTypeWrapper.getSortTypeProperty(getTableColumn()), paramObservableValue -> {
/*      */               updateSortGrid();
/*      */               
/*      */               if (this.arrow != null) {
/*      */                 this.arrow.setRotate(TableColumnSortTypeWrapper.isAscending(getTableColumn()) ? 180.0D : 0.0D);
/*      */               }
/*      */             });
/*      */       } 
/*  632 */       this.arrow.setVisible(this.isSortColumn);
/*      */       
/*  634 */       if (this.sortPos > 2) {
/*  635 */         if (this.sortOrderLabel == null) {
/*      */           
/*  637 */           this.sortOrderLabel = new Label();
/*  638 */           this.sortOrderLabel.getStyleClass().add("sort-order");
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  643 */         this.sortOrderLabel.setText("" + this.sortPos + 1);
/*  644 */         this.sortOrderLabel.setVisible((j > 1));
/*      */ 
/*      */         
/*  647 */         gridPane.add(this.arrow, 1, 1);
/*  648 */         GridPane.setHgrow(this.arrow, Priority.NEVER);
/*  649 */         GridPane.setVgrow(this.arrow, Priority.NEVER);
/*  650 */         gridPane.add(this.sortOrderLabel, 2, 1);
/*  651 */       } else if (bool) {
/*  652 */         if (this.sortOrderDots == null) {
/*  653 */           this.sortOrderDots = new HBox(0.0D);
/*  654 */           this.sortOrderDots.getStyleClass().add("sort-order-dots-container");
/*      */         } 
/*      */ 
/*      */         
/*  658 */         boolean bool1 = TableColumnSortTypeWrapper.isAscending(getTableColumn());
/*  659 */         boolean bool2 = bool1 ? true : true;
/*  660 */         boolean bool3 = bool1 ? true : true;
/*      */         
/*  662 */         gridPane.add(this.arrow, 1, bool2);
/*  663 */         GridPane.setHalignment(this.arrow, HPos.CENTER);
/*  664 */         gridPane.add(this.sortOrderDots, 1, bool3);
/*      */         
/*  666 */         updateSortOrderDots(this.sortPos);
/*      */       } else {
/*      */         
/*  669 */         gridPane.add(this.arrow, 1, 1);
/*  670 */         GridPane.setHgrow(this.arrow, Priority.NEVER);
/*  671 */         GridPane.setVgrow(this.arrow, Priority.ALWAYS);
/*      */       } 
/*      */     } 
/*      */     
/*  675 */     this.sortArrow = node;
/*  676 */     if (this.sortArrow != null) {
/*  677 */       this.sortArrow.setVisible(this.isSortColumn);
/*      */     }
/*      */     
/*  680 */     requestLayout();
/*      */   }
/*      */   
/*      */   private void updateSortOrderDots(int paramInt) {
/*  684 */     double d = this.arrow.prefWidth(-1.0D);
/*      */     
/*  686 */     this.sortOrderDots.getChildren().clear();
/*      */     
/*  688 */     for (byte b = 0; b <= paramInt; b++) {
/*  689 */       Region region = new Region();
/*  690 */       region.getStyleClass().add("sort-order-dot");
/*      */       
/*  692 */       String str = TableColumnSortTypeWrapper.getSortTypeName(getTableColumn());
/*  693 */       if (str != null && !str.isEmpty()) {
/*  694 */         region.getStyleClass().add(str.toLowerCase(Locale.ROOT));
/*      */       }
/*      */       
/*  697 */       this.sortOrderDots.getChildren().add(region);
/*      */ 
/*      */ 
/*      */       
/*  701 */       if (b < paramInt) {
/*  702 */         Region region1 = new Region();
/*  703 */         double d1 = (paramInt == 1) ? 1.0D : 0.0D;
/*  704 */         region1.setPadding(new Insets(0.0D, 1.0D, 0.0D, d1));
/*  705 */         this.sortOrderDots.getChildren().add(region1);
/*      */       } 
/*      */     } 
/*      */     
/*  709 */     this.sortOrderDots.setAlignment(Pos.TOP_CENTER);
/*  710 */     this.sortOrderDots.setMaxWidth(d);
/*      */   }
/*      */ 
/*      */   
/*      */   void moveColumn(TableColumnBase<?, ?> paramTableColumnBase, int paramInt) {
/*  715 */     if (paramTableColumnBase == null || paramInt < 0)
/*      */       return; 
/*  717 */     ObservableList<TableColumnBase<?, ?>> observableList = getColumns(paramTableColumnBase);
/*      */     
/*  719 */     int i = observableList.size();
/*  720 */     int j = observableList.indexOf(paramTableColumnBase);
/*      */     
/*  722 */     int k = paramInt;
/*      */ 
/*      */ 
/*      */     
/*  726 */     int m = k;
/*  727 */     byte b1 = 0;
/*  728 */     for (byte b2 = 0; b2 < i && 
/*  729 */       b1 != m + 1; b2++) {
/*      */ 
/*      */ 
/*      */       
/*  733 */       if (((TableColumnBase)observableList.get(b2)).isVisible()) {
/*  734 */         b1++;
/*      */       } else {
/*  736 */         k++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  741 */     if (k >= i) {
/*  742 */       k = i - 1;
/*  743 */     } else if (k < 0) {
/*  744 */       k = 0;
/*      */     } 
/*      */     
/*  747 */     if (k == j)
/*      */       return; 
/*  749 */     ArrayList<TableColumnBase<?, ?>> arrayList = new ArrayList<>(observableList);
/*  750 */     arrayList.remove(paramTableColumnBase);
/*  751 */     arrayList.add(k, paramTableColumnBase);
/*      */     
/*  753 */     observableList.setAll(arrayList);
/*      */   }
/*      */   
/*      */   private ObservableList<TableColumnBase<?, ?>> getColumns(TableColumnBase paramTableColumnBase) {
/*  757 */     return (paramTableColumnBase.getParentColumn() == null) ? 
/*  758 */       TableSkinUtils.getColumns(getTableSkin()) : 
/*  759 */       paramTableColumnBase.getParentColumn().getColumns();
/*      */   }
/*      */   
/*      */   private int getIndex(TableColumnBase<?, ?> paramTableColumnBase) {
/*  763 */     if (paramTableColumnBase == null) return -1;
/*      */     
/*  765 */     ObservableList<TableColumnBase<?, ?>> observableList = getColumns(paramTableColumnBase);
/*      */     
/*  767 */     byte b = -1;
/*  768 */     for (byte b1 = 0; b1 < observableList.size(); b1++) {
/*  769 */       TableColumnBase tableColumnBase = observableList.get(b1);
/*  770 */       if (tableColumnBase.isVisible()) {
/*      */         
/*  772 */         b++;
/*  773 */         if (paramTableColumnBase.equals(tableColumnBase))
/*      */           break; 
/*      */       } 
/*  776 */     }  return b;
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateColumnIndex() {
/*  781 */     TableColumnBase<?, ?> tableColumnBase = getTableColumn();
/*  782 */     TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase = getTableSkin();
/*  783 */     this.columnIndex = (tableViewSkinBase == null || tableColumnBase == null) ? -1 : TableSkinUtils.getVisibleLeafIndex(tableViewSkinBase, tableColumnBase);
/*      */ 
/*      */ 
/*      */     
/*  787 */     this
/*      */       
/*  789 */       .isLastVisibleColumn = (getTableColumn() != null && this.columnIndex != -1 && this.columnIndex == TableSkinUtils.getVisibleLeafColumns(tableViewSkinBase).size() - 1);
/*  790 */     pseudoClassStateChanged(PSEUDO_CLASS_LAST_VISIBLE, this.isLastVisibleColumn);
/*      */   }
/*      */   
/*      */   private void sortColumn(boolean paramBoolean) {
/*  794 */     if (!isSortingEnabled()) {
/*      */       return;
/*      */     }
/*      */     
/*  798 */     if (getTableColumn() == null || getTableColumn().getColumns().size() != 0 || getTableColumn().getComparator() == null || !getTableColumn().isSortable()) {
/*      */       return;
/*      */     }
/*      */     
/*  802 */     ObservableList<TableColumnBase<?, ?>> observableList = TableSkinUtils.getSortOrder(getTableSkin());
/*      */ 
/*      */     
/*  805 */     if (paramBoolean) {
/*  806 */       if (!this.isSortColumn) {
/*  807 */         TableColumnSortTypeWrapper.setSortType(getTableColumn(), TableColumn.SortType.ASCENDING);
/*  808 */         observableList.add(getTableColumn());
/*  809 */       } else if (TableColumnSortTypeWrapper.isAscending(getTableColumn())) {
/*  810 */         TableColumnSortTypeWrapper.setSortType(getTableColumn(), TableColumn.SortType.DESCENDING);
/*      */       } else {
/*  812 */         int i = observableList.indexOf(getTableColumn());
/*  813 */         if (i != -1) {
/*  814 */           observableList.remove(i);
/*      */         
/*      */         }
/*      */       }
/*      */     
/*      */     }
/*  820 */     else if (this.isSortColumn && observableList.size() == 1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  826 */       if (TableColumnSortTypeWrapper.isAscending(getTableColumn())) {
/*  827 */         TableColumnSortTypeWrapper.setSortType(getTableColumn(), TableColumn.SortType.DESCENDING);
/*      */       } else {
/*      */         
/*  830 */         observableList.remove(getTableColumn());
/*      */       } 
/*  832 */     } else if (this.isSortColumn) {
/*      */ 
/*      */ 
/*      */       
/*  836 */       if (TableColumnSortTypeWrapper.isAscending(getTableColumn())) {
/*  837 */         TableColumnSortTypeWrapper.setSortType(getTableColumn(), TableColumn.SortType.DESCENDING);
/*  838 */       } else if (TableColumnSortTypeWrapper.isDescending(getTableColumn())) {
/*  839 */         TableColumnSortTypeWrapper.setSortType(getTableColumn(), TableColumn.SortType.ASCENDING);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  845 */       ArrayList<TableColumnBase<?, ?>> arrayList = new ArrayList<>(observableList);
/*  846 */       arrayList.remove(getTableColumn());
/*  847 */       arrayList.add(0, getTableColumn());
/*  848 */       observableList.setAll((TableColumnBase<?, ?>[])new TableColumnBase[] { getTableColumn() });
/*      */     } else {
/*      */       
/*  851 */       TableColumnSortTypeWrapper.setSortType(getTableColumn(), TableColumn.SortType.ASCENDING);
/*  852 */       observableList.setAll((TableColumnBase<?, ?>[])new TableColumnBase[] { getTableColumn() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getSortPosition() {
/*  862 */     if (getTableColumn() == null) {
/*  863 */       return -1;
/*      */     }
/*      */     
/*  866 */     List<TableColumnBase> list = getVisibleSortOrderColumns();
/*  867 */     byte b1 = 0;
/*  868 */     for (byte b2 = 0; b2 < list.size(); b2++) {
/*  869 */       TableColumnBase tableColumnBase = list.get(b2);
/*      */       
/*  871 */       if (getTableColumn().equals(tableColumnBase)) {
/*  872 */         return b1;
/*      */       }
/*      */       
/*  875 */       b1++;
/*      */     } 
/*      */     
/*  878 */     return -1;
/*      */   }
/*      */   
/*      */   private List<TableColumnBase> getVisibleSortOrderColumns() {
/*  882 */     ObservableList<TableColumnBase<?, ?>> observableList = TableSkinUtils.getSortOrder(getTableSkin());
/*      */     
/*  884 */     ArrayList<TableColumnBase> arrayList = new ArrayList();
/*  885 */     for (byte b = 0; b < observableList.size(); b++) {
/*  886 */       TableColumnBase tableColumnBase = observableList.get(b);
/*  887 */       if (tableColumnBase != null && tableColumnBase.isSortable() && tableColumnBase.isVisible())
/*      */       {
/*      */ 
/*      */         
/*  891 */         arrayList.add(tableColumnBase);
/*      */       }
/*      */     } 
/*  894 */     return arrayList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getVisibleSortOrderColumnCount() {
/*  901 */     return getVisibleSortOrderColumns().size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void columnReorderingStarted(double paramDouble) {
/*  914 */     if (!getTableColumn().isReorderable()) {
/*      */       return;
/*      */     }
/*      */     
/*  918 */     this.dragOffset = paramDouble;
/*      */ 
/*      */     
/*  921 */     getTableHeaderRow().setReorderingColumn(getTableColumn());
/*  922 */     getTableHeaderRow().setReorderingRegion(this);
/*      */   }
/*      */ 
/*      */   
/*      */   void columnReordering(double paramDouble1, double paramDouble2) {
/*  927 */     if (!getTableColumn().isReorderable()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  934 */     getTableHeaderRow().setReordering(true);
/*      */ 
/*      */ 
/*      */     
/*  938 */     TableColumnHeader tableColumnHeader = null;
/*      */ 
/*      */ 
/*      */     
/*  942 */     double d1 = getParentHeader().sceneToLocal(paramDouble1, paramDouble2).getX();
/*      */ 
/*      */     
/*  945 */     double d2 = getTableSkin().getSkinnable().sceneToLocal(paramDouble1, paramDouble2).getX() - this.dragOffset;
/*  946 */     getTableHeaderRow().setDragHeaderX(d2);
/*      */     
/*  948 */     double d3 = 0.0D;
/*  949 */     double d4 = 0.0D;
/*  950 */     double d5 = 0.0D;
/*  951 */     this.newColumnPos = 0;
/*  952 */     for (TableColumnHeader tableColumnHeader1 : getParentHeader().getColumnHeaders()) {
/*  953 */       if (!tableColumnHeader1.isVisible())
/*      */         continue; 
/*  955 */       double d = tableColumnHeader1.prefWidth(-1.0D);
/*  956 */       d5 += d;
/*      */       
/*  958 */       d3 = tableColumnHeader1.getBoundsInParent().getMinX();
/*  959 */       d4 = d3 + d;
/*      */       
/*  961 */       if (d1 >= d3 && d1 < d4) {
/*  962 */         tableColumnHeader = tableColumnHeader1;
/*      */         break;
/*      */       } 
/*  965 */       this.newColumnPos++;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  973 */     if (tableColumnHeader == null) {
/*  974 */       this.newColumnPos = (d1 > d5) ? (getParentHeader().getColumns().size() - 1) : 0;
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  981 */     double d6 = d3 + (d4 - d3) / 2.0D;
/*  982 */     boolean bool = (d1 <= d6) ? true : false;
/*      */ 
/*      */ 
/*      */     
/*  986 */     int i = getIndex(getTableColumn());
/*  987 */     this.newColumnPos += (this.newColumnPos > i && bool) ? 
/*  988 */       -1 : ((this.newColumnPos < i && !bool) ? 1 : 0);
/*      */     
/*  990 */     double d7 = getTableHeaderRow().sceneToLocal(tableColumnHeader.localToScene(tableColumnHeader.getBoundsInLocal())).getMinX();
/*  991 */     d7 += bool ? 0.0D : tableColumnHeader.getWidth();
/*      */     
/*  993 */     if (d7 >= -0.5D && d7 <= getTableSkin().getSkinnable().getWidth()) {
/*  994 */       this.columnReorderLine.setTranslateX(d7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1000 */       this.columnReorderLine.setVisible(true);
/*      */     } 
/*      */     
/* 1003 */     getTableHeaderRow().setReordering(true);
/*      */   }
/*      */ 
/*      */   
/*      */   void columnReorderingComplete() {
/* 1008 */     if (!getTableColumn().isReorderable()) {
/*      */       return;
/*      */     }
/* 1011 */     moveColumn(getTableColumn(), this.newColumnPos);
/*      */ 
/*      */     
/* 1014 */     this.columnReorderLine.setTranslateX(0.0D);
/* 1015 */     this.columnReorderLine.setLayoutX(0.0D);
/* 1016 */     this.newColumnPos = 0;
/*      */     
/* 1018 */     getTableHeaderRow().setReordering(false);
/* 1019 */     this.columnReorderLine.setVisible(false);
/* 1020 */     getTableHeaderRow().setReorderingColumn((TableColumnBase)null);
/* 1021 */     getTableHeaderRow().setReorderingRegion((TableColumnHeader)null);
/* 1022 */     this.dragOffset = 0.0D;
/*      */   }
/*      */   
/*      */   double getDragRectHeight() {
/* 1026 */     return getHeight();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   boolean represents(TableColumnBase<?, ?> paramTableColumnBase) {
/* 1032 */     if (!paramTableColumnBase.getColumns().isEmpty())
/*      */     {
/*      */       
/* 1035 */       return false;
/*      */     }
/* 1037 */     return (paramTableColumnBase == getTableColumn());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1049 */   private static final PseudoClass PSEUDO_CLASS_LAST_VISIBLE = PseudoClass.getPseudoClass("last-visible");
/*      */ 
/*      */ 
/*      */   
/*      */   private static class StyleableProperties
/*      */   {
/* 1055 */     private static final CssMetaData<TableColumnHeader, Number> SIZE = new CssMetaData<TableColumnHeader, Number>("-fx-size", 
/*      */         
/* 1057 */         SizeConverter.getInstance(), Double.valueOf(20.0D))
/*      */       {
/*      */         public boolean isSettable(TableColumnHeader param2TableColumnHeader)
/*      */         {
/* 1061 */           return (param2TableColumnHeader.size == null || !param2TableColumnHeader.size.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(TableColumnHeader param2TableColumnHeader) {
/* 1066 */           return (StyleableProperty<Number>)param2TableColumnHeader.sizeProperty();
/*      */         }
/*      */       };
/*      */ 
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1074 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Region.getClassCssMetaData());
/* 1075 */       arrayList.add(SIZE);
/* 1076 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1088 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TableColumnHeader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */