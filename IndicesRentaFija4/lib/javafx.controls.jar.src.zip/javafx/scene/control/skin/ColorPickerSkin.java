/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.css.StyleManager;
/*     */ import com.sun.javafx.scene.control.Properties;
/*     */ import com.sun.javafx.scene.control.behavior.ColorPickerBehavior;
/*     */ import com.sun.javafx.scene.control.behavior.ComboBoxBaseBehavior;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.StyleOrigin;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.StyleableStringProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.css.converter.StringConverter;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ColorPicker;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.image.ImageView;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.shape.Rectangle;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorPickerSkin
/*     */   extends ComboBoxPopupControl<Color>
/*     */ {
/*     */   private Label displayNode;
/*     */   private StackPane pickerColorBox;
/*     */   private Rectangle colorRect;
/*     */   private ColorPalette popupContent;
/*     */   private final ColorPickerBehavior behavior;
/*     */   BooleanProperty colorLabelVisible;
/*     */   private final StyleableStringProperty imageUrl;
/*     */   private final StyleableDoubleProperty colorRectWidth;
/*     */   private final StyleableDoubleProperty colorRectHeight;
/*     */   private final StyleableDoubleProperty colorRectX;
/*     */   private final StyleableDoubleProperty colorRectY;
/*     */   
/*     */   public ColorPickerSkin(ColorPicker paramColorPicker) {
/* 108 */     super(paramColorPicker);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     this.colorLabelVisible = new StyleableBooleanProperty(true) {
/*     */         public void invalidated() {
/* 149 */           if (ColorPickerSkin.this.displayNode != null)
/* 150 */             if (ColorPickerSkin.this.colorLabelVisible.get()) {
/* 151 */               ColorPickerSkin.this.displayNode.setText(ColorPickerSkin.colorDisplayName(((ColorPicker)ColorPickerSkin.this.getSkinnable()).getValue()));
/*     */             } else {
/* 153 */               ColorPickerSkin.this.displayNode.setText("");
/*     */             }  
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 158 */           return ColorPickerSkin.this;
/*     */         }
/*     */         public String getName() {
/* 161 */           return "colorLabelVisible";
/*     */         }
/*     */         public CssMetaData<ColorPicker, Boolean> getCssMetaData() {
/* 164 */           return ColorPickerSkin.StyleableProperties.COLOR_LABEL_VISIBLE;
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */     
/* 170 */     this.imageUrl = new StyleableStringProperty() {
/*     */         public void applyStyle(StyleOrigin param1StyleOrigin, String param1String) {
/* 172 */           super.applyStyle(param1StyleOrigin, param1String);
/* 173 */           if (param1String == null) {
/*     */             
/* 175 */             if (ColorPickerSkin.this.pickerColorBox.getChildren().size() == 2) ColorPickerSkin.this.pickerColorBox.getChildren().remove(1);
/*     */           
/* 177 */           } else if (ColorPickerSkin.this.pickerColorBox.getChildren().size() == 2) {
/* 178 */             ImageView imageView = (ImageView)ColorPickerSkin.this.pickerColorBox.getChildren().get(1);
/* 179 */             imageView.setImage(StyleManager.getInstance().getCachedImage(param1String));
/*     */           } else {
/* 181 */             ColorPickerSkin.this.pickerColorBox.getChildren().add(new ImageView(StyleManager.getInstance().getCachedImage(param1String)));
/*     */           } 
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 186 */           return ColorPickerSkin.this;
/*     */         }
/*     */         public String getName() {
/* 189 */           return "imageUrl";
/*     */         }
/*     */         public CssMetaData<ColorPicker, String> getCssMetaData() {
/* 192 */           return ColorPickerSkin.StyleableProperties.GRAPHIC;
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 197 */     this.colorRectWidth = new StyleableDoubleProperty(12.0D) {
/*     */         protected void invalidated() {
/* 199 */           if (ColorPickerSkin.this.pickerColorBox != null) ColorPickerSkin.this.pickerColorBox.requestLayout(); 
/*     */         }
/*     */         public CssMetaData<ColorPicker, Number> getCssMetaData() {
/* 202 */           return ColorPickerSkin.StyleableProperties.COLOR_RECT_WIDTH;
/*     */         }
/*     */         public Object getBean() {
/* 205 */           return ColorPickerSkin.this;
/*     */         }
/*     */         public String getName() {
/* 208 */           return "colorRectWidth";
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 213 */     this.colorRectHeight = new StyleableDoubleProperty(12.0D) {
/*     */         protected void invalidated() {
/* 215 */           if (ColorPickerSkin.this.pickerColorBox != null) ColorPickerSkin.this.pickerColorBox.requestLayout(); 
/*     */         }
/*     */         public CssMetaData<ColorPicker, Number> getCssMetaData() {
/* 218 */           return ColorPickerSkin.StyleableProperties.COLOR_RECT_HEIGHT;
/*     */         }
/*     */         public Object getBean() {
/* 221 */           return ColorPickerSkin.this;
/*     */         }
/*     */         public String getName() {
/* 224 */           return "colorRectHeight";
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 229 */     this.colorRectX = new StyleableDoubleProperty(0.0D) {
/*     */         protected void invalidated() {
/* 231 */           if (ColorPickerSkin.this.pickerColorBox != null) ColorPickerSkin.this.pickerColorBox.requestLayout(); 
/*     */         }
/*     */         public CssMetaData<ColorPicker, Number> getCssMetaData() {
/* 234 */           return ColorPickerSkin.StyleableProperties.COLOR_RECT_X;
/*     */         }
/*     */         public Object getBean() {
/* 237 */           return ColorPickerSkin.this;
/*     */         }
/*     */         public String getName() {
/* 240 */           return "colorRectX";
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 245 */     this.colorRectY = new StyleableDoubleProperty(0.0D) {
/*     */         protected void invalidated() {
/* 247 */           if (ColorPickerSkin.this.pickerColorBox != null) ColorPickerSkin.this.pickerColorBox.requestLayout(); 
/*     */         }
/*     */         public CssMetaData<ColorPicker, Number> getCssMetaData() {
/* 250 */           return ColorPickerSkin.StyleableProperties.COLOR_RECT_Y;
/*     */         }
/*     */         public Object getBean() {
/* 253 */           return ColorPickerSkin.this;
/*     */         }
/*     */         
/* 256 */         public String getName() { return "colorRectY"; } }; this.behavior = new ColorPickerBehavior(paramColorPicker);
/*     */     updateComboBoxMode();
/*     */     registerChangeListener(paramColorPicker.valueProperty(), paramObservableValue -> updateColor());
/*     */     this.displayNode = new Label();
/*     */     this.displayNode.getStyleClass().add("color-picker-label");
/*     */     this.displayNode.setManaged(false);
/*     */     this.pickerColorBox = new PickerColorBox();
/*     */     this.pickerColorBox.getStyleClass().add("picker-color");
/*     */     this.colorRect = new Rectangle(12.0D, 12.0D);
/*     */     this.colorRect.getStyleClass().add("picker-color-rect");
/*     */     updateColor();
/*     */     this.pickerColorBox.getChildren().add(this.colorRect);
/*     */     this.displayNode.setGraphic(this.pickerColorBox);
/*     */     if (paramColorPicker.isShowing())
/* 270 */       show();  } public void dispose() { super.dispose();
/*     */     
/* 272 */     if (this.behavior != null)
/* 273 */       this.behavior.dispose();  }
/*     */   
/*     */   private final StringProperty imageUrlProperty() {
/*     */     return this.imageUrl;
/*     */   }
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 279 */     if (!this.colorLabelVisible.get()) {
/* 280 */       return super.computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */     }
/* 282 */     String str = this.displayNode.getText();
/* 283 */     double d = 0.0D;
/* 284 */     for (String str1 : colorNameMap.values()) {
/* 285 */       this.displayNode.setText(str1);
/* 286 */       d = Math.max(d, super.computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5));
/*     */     } 
/* 288 */     this.displayNode.setText(Utils.formatHexString(Color.BLACK));
/* 289 */     d = Math.max(d, super.computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5));
/* 290 */     this.displayNode.setText(str);
/* 291 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Node getPopupContent() {
/* 296 */     if (this.popupContent == null) {
/*     */       
/* 298 */       this.popupContent = new ColorPalette((ColorPicker)getSkinnable());
/* 299 */       this.popupContent.setPopupControl(getPopup());
/*     */     } 
/* 301 */     return this.popupContent;
/*     */   }
/*     */ 
/*     */   
/*     */   public void show() {
/* 306 */     super.show();
/* 307 */     ColorPicker colorPicker = (ColorPicker)getSkinnable();
/* 308 */     this.popupContent.updateSelection(colorPicker.getValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getDisplayNode() {
/* 313 */     return this.displayNode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 319 */     updateComboBoxMode();
/* 320 */     super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void focusLost() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ComboBoxBaseBehavior getBehavior() {
/* 338 */     return this.behavior;
/*     */   }
/*     */   
/*     */   private void updateComboBoxMode() {
/* 342 */     ObservableList<String> observableList = getSkinnable().getStyleClass();
/* 343 */     if (observableList.contains("button")) {
/* 344 */       setMode(ComboBoxMode.BUTTON);
/* 345 */     } else if (observableList.contains("split-button")) {
/* 346 */       setMode(ComboBoxMode.SPLITBUTTON);
/*     */     } 
/*     */   }
/*     */   
/* 350 */   private static final Map<Color, String> colorNameMap = new HashMap<>(30);
/* 351 */   private static final Map<Color, String> cssNameMap = new HashMap<>(139);
/*     */   
/*     */   static {
/* 354 */     colorNameMap.put(Color.TRANSPARENT, Properties.getColorPickerString("colorName.transparent"));
/* 355 */     colorNameMap.put(Color.BLACK, Properties.getColorPickerString("colorName.black"));
/* 356 */     colorNameMap.put(Color.BLUE, Properties.getColorPickerString("colorName.blue"));
/* 357 */     colorNameMap.put(Color.CYAN, Properties.getColorPickerString("colorName.cyan"));
/* 358 */     colorNameMap.put(Color.DARKBLUE, Properties.getColorPickerString("colorName.darkblue"));
/* 359 */     colorNameMap.put(Color.DARKCYAN, Properties.getColorPickerString("colorName.darkcyan"));
/* 360 */     colorNameMap.put(Color.DARKGRAY, Properties.getColorPickerString("colorName.darkgray"));
/* 361 */     colorNameMap.put(Color.DARKGREEN, Properties.getColorPickerString("colorName.darkgreen"));
/* 362 */     colorNameMap.put(Color.DARKMAGENTA, Properties.getColorPickerString("colorName.darkmagenta"));
/* 363 */     colorNameMap.put(Color.DARKRED, Properties.getColorPickerString("colorName.darkred"));
/* 364 */     colorNameMap.put(Color.GRAY, Properties.getColorPickerString("colorName.gray"));
/* 365 */     colorNameMap.put(Color.GREEN, Properties.getColorPickerString("colorName.green"));
/* 366 */     colorNameMap.put(Color.LIGHTBLUE, Properties.getColorPickerString("colorName.lightblue"));
/* 367 */     colorNameMap.put(Color.LIGHTCYAN, Properties.getColorPickerString("colorName.lightcyan"));
/* 368 */     colorNameMap.put(Color.LIGHTGRAY, Properties.getColorPickerString("colorName.lightgray"));
/* 369 */     colorNameMap.put(Color.LIGHTGREEN, Properties.getColorPickerString("colorName.lightgreen"));
/* 370 */     colorNameMap.put(Color.LIGHTYELLOW, Properties.getColorPickerString("colorName.lightyellow"));
/* 371 */     colorNameMap.put(Color.LIME, Properties.getColorPickerString("colorName.lime"));
/* 372 */     colorNameMap.put(Color.MAGENTA, Properties.getColorPickerString("colorName.magenta"));
/* 373 */     colorNameMap.put(Color.MAROON, Properties.getColorPickerString("colorName.maroon"));
/* 374 */     colorNameMap.put(Color.MEDIUMBLUE, Properties.getColorPickerString("colorName.mediumblue"));
/* 375 */     colorNameMap.put(Color.NAVY, Properties.getColorPickerString("colorName.navy"));
/* 376 */     colorNameMap.put(Color.OLIVE, Properties.getColorPickerString("colorName.olive"));
/* 377 */     colorNameMap.put(Color.ORANGE, Properties.getColorPickerString("colorName.orange"));
/* 378 */     colorNameMap.put(Color.PINK, Properties.getColorPickerString("colorName.pink"));
/* 379 */     colorNameMap.put(Color.PURPLE, Properties.getColorPickerString("colorName.purple"));
/* 380 */     colorNameMap.put(Color.RED, Properties.getColorPickerString("colorName.red"));
/* 381 */     colorNameMap.put(Color.TEAL, Properties.getColorPickerString("colorName.teal"));
/* 382 */     colorNameMap.put(Color.WHITE, Properties.getColorPickerString("colorName.white"));
/* 383 */     colorNameMap.put(Color.YELLOW, Properties.getColorPickerString("colorName.yellow"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 391 */     cssNameMap.put(Color.ALICEBLUE, "aliceblue");
/* 392 */     cssNameMap.put(Color.ANTIQUEWHITE, "antiquewhite");
/* 393 */     cssNameMap.put(Color.AQUAMARINE, "aquamarine");
/* 394 */     cssNameMap.put(Color.AZURE, "azure");
/* 395 */     cssNameMap.put(Color.BEIGE, "beige");
/* 396 */     cssNameMap.put(Color.BISQUE, "bisque");
/* 397 */     cssNameMap.put(Color.BLACK, "black");
/* 398 */     cssNameMap.put(Color.BLANCHEDALMOND, "blanchedalmond");
/* 399 */     cssNameMap.put(Color.BLUE, "blue");
/* 400 */     cssNameMap.put(Color.BLUEVIOLET, "blueviolet");
/* 401 */     cssNameMap.put(Color.BROWN, "brown");
/* 402 */     cssNameMap.put(Color.BURLYWOOD, "burlywood");
/* 403 */     cssNameMap.put(Color.CADETBLUE, "cadetblue");
/* 404 */     cssNameMap.put(Color.CHARTREUSE, "chartreuse");
/* 405 */     cssNameMap.put(Color.CHOCOLATE, "chocolate");
/* 406 */     cssNameMap.put(Color.CORAL, "coral");
/* 407 */     cssNameMap.put(Color.CORNFLOWERBLUE, "cornflowerblue");
/* 408 */     cssNameMap.put(Color.CORNSILK, "cornsilk");
/* 409 */     cssNameMap.put(Color.CRIMSON, "crimson");
/* 410 */     cssNameMap.put(Color.CYAN, "cyan");
/* 411 */     cssNameMap.put(Color.DARKBLUE, "darkblue");
/* 412 */     cssNameMap.put(Color.DARKCYAN, "darkcyan");
/* 413 */     cssNameMap.put(Color.DARKGOLDENROD, "darkgoldenrod");
/* 414 */     cssNameMap.put(Color.DARKGRAY, "darkgray");
/* 415 */     cssNameMap.put(Color.DARKGREEN, "darkgreen");
/* 416 */     cssNameMap.put(Color.DARKKHAKI, "darkkhaki");
/* 417 */     cssNameMap.put(Color.DARKMAGENTA, "darkmagenta");
/* 418 */     cssNameMap.put(Color.DARKOLIVEGREEN, "darkolivegreen");
/* 419 */     cssNameMap.put(Color.DARKORANGE, "darkorange");
/* 420 */     cssNameMap.put(Color.DARKORCHID, "darkorchid");
/* 421 */     cssNameMap.put(Color.DARKRED, "darkred");
/* 422 */     cssNameMap.put(Color.DARKSALMON, "darksalmon");
/* 423 */     cssNameMap.put(Color.DARKSEAGREEN, "darkseagreen");
/* 424 */     cssNameMap.put(Color.DARKSLATEBLUE, "darkslateblue");
/* 425 */     cssNameMap.put(Color.DARKSLATEGRAY, "darkslategray");
/* 426 */     cssNameMap.put(Color.DARKTURQUOISE, "darkturquoise");
/* 427 */     cssNameMap.put(Color.DARKVIOLET, "darkviolet");
/* 428 */     cssNameMap.put(Color.DEEPPINK, "deeppink");
/* 429 */     cssNameMap.put(Color.DEEPSKYBLUE, "deepskyblue");
/* 430 */     cssNameMap.put(Color.DIMGRAY, "dimgray");
/* 431 */     cssNameMap.put(Color.DODGERBLUE, "dodgerblue");
/* 432 */     cssNameMap.put(Color.FIREBRICK, "firebrick");
/* 433 */     cssNameMap.put(Color.FLORALWHITE, "floralwhite");
/* 434 */     cssNameMap.put(Color.FORESTGREEN, "forestgreen");
/* 435 */     cssNameMap.put(Color.GAINSBORO, "gainsboro");
/* 436 */     cssNameMap.put(Color.GHOSTWHITE, "ghostwhite");
/* 437 */     cssNameMap.put(Color.GOLD, "gold");
/* 438 */     cssNameMap.put(Color.GOLDENROD, "goldenrod");
/* 439 */     cssNameMap.put(Color.GRAY, "gray");
/* 440 */     cssNameMap.put(Color.GREEN, "green");
/* 441 */     cssNameMap.put(Color.GREENYELLOW, "greenyellow");
/* 442 */     cssNameMap.put(Color.HONEYDEW, "honeydew");
/* 443 */     cssNameMap.put(Color.HOTPINK, "hotpink");
/* 444 */     cssNameMap.put(Color.INDIANRED, "indianred");
/* 445 */     cssNameMap.put(Color.INDIGO, "indigo");
/* 446 */     cssNameMap.put(Color.IVORY, "ivory");
/* 447 */     cssNameMap.put(Color.KHAKI, "khaki");
/* 448 */     cssNameMap.put(Color.LAVENDER, "lavender");
/* 449 */     cssNameMap.put(Color.LAVENDERBLUSH, "lavenderblush");
/* 450 */     cssNameMap.put(Color.LAWNGREEN, "lawngreen");
/* 451 */     cssNameMap.put(Color.LEMONCHIFFON, "lemonchiffon");
/* 452 */     cssNameMap.put(Color.LIGHTBLUE, "lightblue");
/* 453 */     cssNameMap.put(Color.LIGHTCORAL, "lightcoral");
/* 454 */     cssNameMap.put(Color.LIGHTCYAN, "lightcyan");
/* 455 */     cssNameMap.put(Color.LIGHTGOLDENRODYELLOW, "lightgoldenrodyellow");
/* 456 */     cssNameMap.put(Color.LIGHTGRAY, "lightgray");
/* 457 */     cssNameMap.put(Color.LIGHTGREEN, "lightgreen");
/* 458 */     cssNameMap.put(Color.LIGHTPINK, "lightpink");
/* 459 */     cssNameMap.put(Color.LIGHTSALMON, "lightsalmon");
/* 460 */     cssNameMap.put(Color.LIGHTSEAGREEN, "lightseagreen");
/* 461 */     cssNameMap.put(Color.LIGHTSKYBLUE, "lightskyblue");
/* 462 */     cssNameMap.put(Color.LIGHTSLATEGRAY, "lightslategray");
/* 463 */     cssNameMap.put(Color.LIGHTSTEELBLUE, "lightsteelblue");
/* 464 */     cssNameMap.put(Color.LIGHTYELLOW, "lightyellow");
/* 465 */     cssNameMap.put(Color.LIME, "lime");
/* 466 */     cssNameMap.put(Color.LIMEGREEN, "limegreen");
/* 467 */     cssNameMap.put(Color.LINEN, "linen");
/* 468 */     cssNameMap.put(Color.MAGENTA, "magenta");
/* 469 */     cssNameMap.put(Color.MAROON, "maroon");
/* 470 */     cssNameMap.put(Color.MEDIUMAQUAMARINE, "mediumaquamarine");
/* 471 */     cssNameMap.put(Color.MEDIUMBLUE, "mediumblue");
/* 472 */     cssNameMap.put(Color.MEDIUMORCHID, "mediumorchid");
/* 473 */     cssNameMap.put(Color.MEDIUMPURPLE, "mediumpurple");
/* 474 */     cssNameMap.put(Color.MEDIUMSEAGREEN, "mediumseagreen");
/* 475 */     cssNameMap.put(Color.MEDIUMSLATEBLUE, "mediumslateblue");
/* 476 */     cssNameMap.put(Color.MEDIUMSPRINGGREEN, "mediumspringgreen");
/* 477 */     cssNameMap.put(Color.MEDIUMTURQUOISE, "mediumturquoise");
/* 478 */     cssNameMap.put(Color.MEDIUMVIOLETRED, "mediumvioletred");
/* 479 */     cssNameMap.put(Color.MIDNIGHTBLUE, "midnightblue");
/* 480 */     cssNameMap.put(Color.MINTCREAM, "mintcream");
/* 481 */     cssNameMap.put(Color.MISTYROSE, "mistyrose");
/* 482 */     cssNameMap.put(Color.MOCCASIN, "moccasin");
/* 483 */     cssNameMap.put(Color.NAVAJOWHITE, "navajowhite");
/* 484 */     cssNameMap.put(Color.NAVY, "navy");
/* 485 */     cssNameMap.put(Color.OLDLACE, "oldlace");
/* 486 */     cssNameMap.put(Color.OLIVE, "olive");
/* 487 */     cssNameMap.put(Color.OLIVEDRAB, "olivedrab");
/* 488 */     cssNameMap.put(Color.ORANGE, "orange");
/* 489 */     cssNameMap.put(Color.ORANGERED, "orangered");
/* 490 */     cssNameMap.put(Color.ORCHID, "orchid");
/* 491 */     cssNameMap.put(Color.PALEGOLDENROD, "palegoldenrod");
/* 492 */     cssNameMap.put(Color.PALEGREEN, "palegreen");
/* 493 */     cssNameMap.put(Color.PALETURQUOISE, "paleturquoise");
/* 494 */     cssNameMap.put(Color.PALEVIOLETRED, "palevioletred");
/* 495 */     cssNameMap.put(Color.PAPAYAWHIP, "papayawhip");
/* 496 */     cssNameMap.put(Color.PEACHPUFF, "peachpuff");
/* 497 */     cssNameMap.put(Color.PERU, "peru");
/* 498 */     cssNameMap.put(Color.PINK, "pink");
/* 499 */     cssNameMap.put(Color.PLUM, "plum");
/* 500 */     cssNameMap.put(Color.POWDERBLUE, "powderblue");
/* 501 */     cssNameMap.put(Color.PURPLE, "purple");
/* 502 */     cssNameMap.put(Color.RED, "red");
/* 503 */     cssNameMap.put(Color.ROSYBROWN, "rosybrown");
/* 504 */     cssNameMap.put(Color.ROYALBLUE, "royalblue");
/* 505 */     cssNameMap.put(Color.SADDLEBROWN, "saddlebrown");
/* 506 */     cssNameMap.put(Color.SALMON, "salmon");
/* 507 */     cssNameMap.put(Color.SANDYBROWN, "sandybrown");
/* 508 */     cssNameMap.put(Color.SEAGREEN, "seagreen");
/* 509 */     cssNameMap.put(Color.SEASHELL, "seashell");
/* 510 */     cssNameMap.put(Color.SIENNA, "sienna");
/* 511 */     cssNameMap.put(Color.SILVER, "silver");
/* 512 */     cssNameMap.put(Color.SKYBLUE, "skyblue");
/* 513 */     cssNameMap.put(Color.SLATEBLUE, "slateblue");
/* 514 */     cssNameMap.put(Color.SLATEGRAY, "slategray");
/* 515 */     cssNameMap.put(Color.SNOW, "snow");
/* 516 */     cssNameMap.put(Color.SPRINGGREEN, "springgreen");
/* 517 */     cssNameMap.put(Color.STEELBLUE, "steelblue");
/* 518 */     cssNameMap.put(Color.TAN, "tan");
/* 519 */     cssNameMap.put(Color.TEAL, "teal");
/* 520 */     cssNameMap.put(Color.THISTLE, "thistle");
/* 521 */     cssNameMap.put(Color.TOMATO, "tomato");
/* 522 */     cssNameMap.put(Color.TRANSPARENT, "transparent");
/* 523 */     cssNameMap.put(Color.TURQUOISE, "turquoise");
/* 524 */     cssNameMap.put(Color.VIOLET, "violet");
/* 525 */     cssNameMap.put(Color.WHEAT, "wheat");
/* 526 */     cssNameMap.put(Color.WHITE, "white");
/* 527 */     cssNameMap.put(Color.WHITESMOKE, "whitesmoke");
/* 528 */     cssNameMap.put(Color.YELLOW, "yellow");
/* 529 */     cssNameMap.put(Color.YELLOWGREEN, "yellowgreen");
/*     */   }
/*     */   
/*     */   static String colorDisplayName(Color paramColor) {
/* 533 */     if (paramColor != null) {
/* 534 */       String str = colorNameMap.get(paramColor);
/* 535 */       if (str == null) {
/* 536 */         str = Utils.formatHexString(paramColor);
/*     */       }
/* 538 */       return str;
/*     */     } 
/* 540 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static String tooltipString(Color paramColor) {
/* 545 */     if (paramColor != null) {
/* 546 */       String str1 = "";
/* 547 */       String str2 = colorNameMap.get(paramColor);
/* 548 */       if (str2 != null) {
/* 549 */         str1 = str1 + str1 + " ";
/*     */       }
/*     */       
/* 552 */       str1 = str1 + str1;
/*     */       
/* 554 */       String str3 = cssNameMap.get(paramColor);
/* 555 */       if (str3 != null) {
/* 556 */         str1 = str1 + " (css: " + str1 + ")";
/*     */       }
/* 558 */       return str1;
/*     */     } 
/* 560 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateColor() {
/* 565 */     ColorPicker colorPicker = (ColorPicker)getSkinnable();
/* 566 */     this.colorRect.setFill(colorPicker.getValue());
/* 567 */     if (this.colorLabelVisible.get()) {
/* 568 */       this.displayNode.setText(colorDisplayName(colorPicker.getValue()));
/*     */     } else {
/* 570 */       this.displayNode.setText("");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class PickerColorBox
/*     */     extends StackPane
/*     */   {
/*     */     private PickerColorBox() {}
/*     */ 
/*     */ 
/*     */     
/*     */     protected void layoutChildren() {
/* 584 */       double d1 = snappedTopInset();
/* 585 */       double d2 = snappedLeftInset();
/* 586 */       double d3 = getWidth();
/* 587 */       double d4 = getHeight();
/* 588 */       double d5 = snappedRightInset();
/* 589 */       double d6 = snappedBottomInset();
/* 590 */       ColorPickerSkin.this.colorRect.setX(snapPosition(ColorPickerSkin.this.colorRectX.get()));
/* 591 */       ColorPickerSkin.this.colorRect.setY(snapPosition(ColorPickerSkin.this.colorRectY.get()));
/* 592 */       ColorPickerSkin.this.colorRect.setWidth(snapSize(ColorPickerSkin.this.colorRectWidth.get()));
/* 593 */       ColorPickerSkin.this.colorRect.setHeight(snapSize(ColorPickerSkin.this.colorRectHeight.get()));
/* 594 */       if (getChildren().size() == 2) {
/* 595 */         ImageView imageView = (ImageView)getChildren().get(1);
/* 596 */         Pos pos = StackPane.getAlignment(imageView);
/* 597 */         layoutInArea(imageView, d2, d1, d3 - d2 - d5, d4 - d1 - d6, 0.0D, 
/*     */             
/* 599 */             getMargin(imageView), 
/* 600 */             (pos != null) ? pos.getHpos() : getAlignment().getHpos(), 
/* 601 */             (pos != null) ? pos.getVpos() : getAlignment().getVpos());
/* 602 */         ColorPickerSkin.this.colorRect.setLayoutX(imageView.getLayoutX());
/* 603 */         ColorPickerSkin.this.colorRect.setLayoutY(imageView.getLayoutY());
/*     */       } else {
/* 605 */         Pos pos = StackPane.getAlignment(ColorPickerSkin.this.colorRect);
/* 606 */         layoutInArea(ColorPickerSkin.this.colorRect, d2, d1, d3 - d2 - d5, d4 - d1 - d6, 0.0D, 
/*     */             
/* 608 */             getMargin(ColorPickerSkin.this.colorRect), 
/* 609 */             (pos != null) ? pos.getHpos() : getAlignment().getHpos(), 
/* 610 */             (pos != null) ? pos.getVpos() : getAlignment().getVpos());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 622 */     private static final CssMetaData<ColorPicker, Boolean> COLOR_LABEL_VISIBLE = new CssMetaData<ColorPicker, Boolean>("-fx-color-label-visible", 
/*     */         
/* 624 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(ColorPicker param2ColorPicker) {
/* 627 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 628 */           return (colorPickerSkin.colorLabelVisible == null || !colorPickerSkin.colorLabelVisible.isBound());
/*     */         }
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(ColorPicker param2ColorPicker) {
/* 632 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 633 */           return (StyleableProperty<Boolean>)colorPickerSkin.colorLabelVisible;
/*     */         }
/*     */       };
/* 636 */     private static final CssMetaData<ColorPicker, Number> COLOR_RECT_WIDTH = new CssMetaData<ColorPicker, Number>("-fx-color-rect-width", 
/* 637 */         SizeConverter.getInstance(), Double.valueOf(12.0D)) {
/*     */         public boolean isSettable(ColorPicker param2ColorPicker) {
/* 639 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 640 */           return !colorPickerSkin.colorRectWidth.isBound();
/*     */         }
/*     */         public StyleableProperty<Number> getStyleableProperty(ColorPicker param2ColorPicker) {
/* 643 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 644 */           return colorPickerSkin.colorRectWidth;
/*     */         }
/*     */       };
/* 647 */     private static final CssMetaData<ColorPicker, Number> COLOR_RECT_HEIGHT = new CssMetaData<ColorPicker, Number>("-fx-color-rect-height", 
/* 648 */         SizeConverter.getInstance(), Double.valueOf(12.0D)) {
/*     */         public boolean isSettable(ColorPicker param2ColorPicker) {
/* 650 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 651 */           return !colorPickerSkin.colorRectHeight.isBound();
/*     */         }
/*     */         public StyleableProperty<Number> getStyleableProperty(ColorPicker param2ColorPicker) {
/* 654 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 655 */           return colorPickerSkin.colorRectHeight;
/*     */         }
/*     */       };
/* 658 */     private static final CssMetaData<ColorPicker, Number> COLOR_RECT_X = new CssMetaData<ColorPicker, Number>("-fx-color-rect-x", 
/* 659 */         SizeConverter.getInstance(), Integer.valueOf(0)) {
/*     */         public boolean isSettable(ColorPicker param2ColorPicker) {
/* 661 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 662 */           return !colorPickerSkin.colorRectX.isBound();
/*     */         }
/*     */         public StyleableProperty<Number> getStyleableProperty(ColorPicker param2ColorPicker) {
/* 665 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 666 */           return colorPickerSkin.colorRectX;
/*     */         }
/*     */       };
/* 669 */     private static final CssMetaData<ColorPicker, Number> COLOR_RECT_Y = new CssMetaData<ColorPicker, Number>("-fx-color-rect-y", 
/* 670 */         SizeConverter.getInstance(), Integer.valueOf(0)) {
/*     */         public boolean isSettable(ColorPicker param2ColorPicker) {
/* 672 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 673 */           return !colorPickerSkin.colorRectY.isBound();
/*     */         }
/*     */         public StyleableProperty<Number> getStyleableProperty(ColorPicker param2ColorPicker) {
/* 676 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 677 */           return colorPickerSkin.colorRectY;
/*     */         }
/*     */       };
/* 680 */     private static final CssMetaData<ColorPicker, String> GRAPHIC = new CssMetaData<ColorPicker, String>("-fx-graphic", 
/* 681 */         StringConverter.getInstance()) {
/*     */         public boolean isSettable(ColorPicker param2ColorPicker) {
/* 683 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 684 */           return !colorPickerSkin.imageUrl.isBound();
/*     */         }
/*     */         public StyleableProperty<String> getStyleableProperty(ColorPicker param2ColorPicker) {
/* 687 */           ColorPickerSkin colorPickerSkin = (ColorPickerSkin)param2ColorPicker.getSkin();
/* 688 */           return colorPickerSkin.imageUrl;
/*     */         }
/*     */       };
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 694 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(ComboBoxBaseSkin.getClassCssMetaData());
/* 695 */       arrayList.add(COLOR_LABEL_VISIBLE);
/* 696 */       arrayList.add(COLOR_RECT_WIDTH);
/* 697 */       arrayList.add(COLOR_RECT_HEIGHT);
/* 698 */       arrayList.add(COLOR_RECT_X);
/* 699 */       arrayList.add(COLOR_RECT_Y);
/* 700 */       arrayList.add(GRAPHIC);
/* 701 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 712 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 720 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringConverter<Color> getConverter() {
/* 725 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TextField getEditor() {
/* 733 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ColorPickerSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */