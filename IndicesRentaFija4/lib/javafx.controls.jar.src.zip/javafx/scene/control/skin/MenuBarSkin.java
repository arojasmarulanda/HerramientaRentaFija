/*      */ package javafx.scene.control.skin;
/*      */ 
/*      */ import com.sun.javafx.FXPermissions;
/*      */ import com.sun.javafx.menu.MenuBase;
/*      */ import com.sun.javafx.scene.ParentHelper;
/*      */ import com.sun.javafx.scene.SceneHelper;
/*      */ import com.sun.javafx.scene.control.GlobalMenuAdapter;
/*      */ import com.sun.javafx.scene.control.MenuBarButton;
/*      */ import com.sun.javafx.scene.control.skin.Utils;
/*      */ import com.sun.javafx.scene.traversal.Direction;
/*      */ import com.sun.javafx.scene.traversal.ParentTraversalEngine;
/*      */ import com.sun.javafx.tk.Toolkit;
/*      */ import com.sun.javafx.util.Utils;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessController;
/*      */ import java.security.Permission;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.WeakHashMap;
/*      */ import java.util.function.Predicate;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyProperty;
/*      */ import javafx.beans.value.ChangeListener;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.beans.value.WeakChangeListener;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.MapChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.EnumConverter;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.WeakEventHandler;
/*      */ import javafx.geometry.Bounds;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.geometry.Pos;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.control.CustomMenuItem;
/*      */ import javafx.scene.control.Menu;
/*      */ import javafx.scene.control.MenuBar;
/*      */ import javafx.scene.control.MenuButton;
/*      */ import javafx.scene.control.MenuItem;
/*      */ import javafx.scene.control.Skin;
/*      */ import javafx.scene.control.SkinBase;
/*      */ import javafx.scene.input.KeyCode;
/*      */ import javafx.scene.input.KeyCombination;
/*      */ import javafx.scene.input.KeyEvent;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.layout.HBox;
/*      */ import javafx.stage.Stage;
/*      */ import javafx.stage.Window;
/*      */ import javafx.util.Pair;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MenuBarSkin
/*      */   extends SkinBase<MenuBar>
/*      */ {
/*      */   private static final ObservableList<Window> stages;
/*      */   private final HBox container;
/*      */   private Menu openMenu;
/*      */   private MenuBarButton openMenuButton;
/*      */   private Menu focusedMenu;
/*      */   private int focusedMenuIndex;
/*      */   private static WeakHashMap<Stage, Reference<MenuBarSkin>> systemMenuMap;
/*      */   
/*      */   static {
/*  112 */     Predicate<Window> predicate = paramWindow -> paramWindow instanceof Stage;
/*  113 */     ObservableList<Window> observableList = AccessController.<ObservableList>doPrivileged(() -> Window.getWindows(), (AccessControlContext)null, new Permission[] { (Permission)FXPermissions.ACCESS_WINDOW_LIST_PERMISSION });
/*      */ 
/*      */ 
/*      */     
/*  117 */     stages = observableList.filtered(predicate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private static List<MenuBase> wrappedDefaultMenus = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Stage currentMenuBarStage;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<MenuBase> wrappedMenus;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WeakEventHandler<KeyEvent> weakSceneKeyEventHandler;
/*      */ 
/*      */ 
/*      */   
/*      */   private WeakEventHandler<MouseEvent> weakSceneMouseEventHandler;
/*      */ 
/*      */ 
/*      */   
/*      */   private WeakEventHandler<KeyEvent> weakSceneAltKeyEventHandler;
/*      */ 
/*      */ 
/*      */   
/*      */   private WeakChangeListener<Boolean> weakWindowFocusListener;
/*      */ 
/*      */ 
/*      */   
/*      */   private WeakChangeListener<Window> weakWindowSceneListener;
/*      */ 
/*      */ 
/*      */   
/*      */   private EventHandler<KeyEvent> keyEventHandler;
/*      */ 
/*      */ 
/*      */   
/*      */   private EventHandler<KeyEvent> altKeyEventHandler;
/*      */ 
/*      */ 
/*      */   
/*      */   private EventHandler<MouseEvent> mouseEventHandler;
/*      */ 
/*      */ 
/*      */   
/*      */   private ChangeListener<Boolean> menuBarFocusedPropertyListener;
/*      */ 
/*      */ 
/*      */   
/*      */   private ChangeListener<Scene> sceneChangeListener;
/*      */ 
/*      */ 
/*      */   
/*      */   private ChangeListener<Boolean> menuVisibilityChangeListener;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean pendingDismiss;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean altKeyPressed;
/*      */ 
/*      */ 
/*      */   
/*      */   private EventHandler<ActionEvent> menuActionEventHandler;
/*      */ 
/*      */ 
/*      */   
/*      */   private ListChangeListener<MenuItem> menuItemListener;
/*      */ 
/*      */ 
/*      */   
/*      */   Runnable firstMenuRunnable;
/*      */ 
/*      */ 
/*      */   
/*      */   private DoubleProperty spacing;
/*      */ 
/*      */ 
/*      */   
/*      */   private ObjectProperty<Pos> containerAlignment;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MenuBarSkin(MenuBar paramMenuBar) {
/*  227 */     super(paramMenuBar); KeyCombination keyCombination; this.focusedMenuIndex = -1; this.pendingDismiss = false; this.altKeyPressed = false; this.menuActionEventHandler = (paramActionEvent -> { if (paramActionEvent.getSource() instanceof CustomMenuItem) { CustomMenuItem customMenuItem = (CustomMenuItem)paramActionEvent.getSource(); if (!customMenuItem.isHideOnClick()) return;  }  unSelectMenus(); }); this.menuItemListener = (paramChange -> { while (paramChange.next()) { for (MenuItem menuItem : paramChange.getAddedSubList()) updateActionListeners(menuItem, true);  for (MenuItem menuItem : paramChange.getRemoved()) updateActionListeners(menuItem, false);  }  }); this.firstMenuRunnable = new Runnable() { public void run() { if (MenuBarSkin.this.container.getChildren().size() > 0 && MenuBarSkin.this.container.getChildren().get(0) instanceof MenuButton)
/*      */             if (MenuBarSkin.this.focusedMenuIndex != 0) { MenuBarSkin.this.unSelectMenus(); MenuBarSkin.this.menuModeStart(0); MenuBarSkin.this.openMenuButton = (MenuBarButton)MenuBarSkin.this.container.getChildren().get(0); MenuBarSkin.this.openMenuButton.setHover(); } else { MenuBarSkin.this.unSelectMenus(); }   } }
/*  229 */       ; this.container = new HBox();
/*  230 */     this.container.getStyleClass().add("container");
/*  231 */     getChildren().add(this.container);
/*      */ 
/*      */     
/*  234 */     this.keyEventHandler = (paramKeyEvent -> {
/*      */         if (this.focusedMenu != null) {
/*      */           boolean bool;
/*      */           switch (paramKeyEvent.getCode()) {
/*      */             case LEFT:
/*      */               bool = (paramMenuBar.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) ? true : false;
/*      */               if (paramMenuBar.getScene().getWindow().isFocused()) {
/*      */                 if (this.openMenu != null && !this.openMenu.isShowing()) {
/*      */                   if (bool) {
/*      */                     moveToMenu(Direction.NEXT, false);
/*      */                   } else {
/*      */                     moveToMenu(Direction.PREVIOUS, false);
/*      */                   } 
/*      */                   paramKeyEvent.consume();
/*      */                   return;
/*      */                 } 
/*      */                 if (bool) {
/*      */                   moveToMenu(Direction.NEXT, true);
/*      */                 } else {
/*      */                   moveToMenu(Direction.PREVIOUS, true);
/*      */                 } 
/*      */               } 
/*      */               paramKeyEvent.consume();
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case RIGHT:
/*      */               bool = (paramMenuBar.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) ? true : false;
/*      */               if (paramMenuBar.getScene().getWindow().isFocused()) {
/*      */                 if (this.openMenu != null && !this.openMenu.isShowing()) {
/*      */                   if (bool) {
/*      */                     moveToMenu(Direction.PREVIOUS, false);
/*      */                   } else {
/*      */                     moveToMenu(Direction.NEXT, false);
/*      */                   } 
/*      */                   paramKeyEvent.consume();
/*      */                   return;
/*      */                 } 
/*      */                 if (bool) {
/*      */                   moveToMenu(Direction.PREVIOUS, true);
/*      */                 } else {
/*      */                   moveToMenu(Direction.NEXT, true);
/*      */                 } 
/*      */               } 
/*      */               paramKeyEvent.consume();
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case DOWN:
/*      */               if (paramMenuBar.getScene().getWindow().isFocused() && this.focusedMenuIndex != -1) {
/*      */                 Menu menu = getSkinnable().getMenus().get(this.focusedMenuIndex);
/*      */                 showMenu(menu, true);
/*      */                 paramKeyEvent.consume();
/*      */               } 
/*      */               break;
/*      */ 
/*      */             
/*      */             case ESCAPE:
/*      */               unSelectMenus();
/*      */               paramKeyEvent.consume();
/*      */               break;
/*      */           } 
/*      */ 
/*      */         
/*      */         } 
/*      */       });
/*  302 */     this.menuBarFocusedPropertyListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*      */         if (paramBoolean2.booleanValue()) {
/*      */           unSelectMenus();
/*      */           
/*      */           menuModeStart(0);
/*      */           
/*      */           this.openMenuButton = (MenuBarButton)this.container.getChildren().get(0);
/*      */           setFocusedMenuIndex(0);
/*      */           this.openMenuButton.setHover();
/*      */         } else {
/*      */           unSelectMenus();
/*      */         } 
/*      */       });
/*  315 */     this.weakSceneKeyEventHandler = new WeakEventHandler<>(this.keyEventHandler);
/*  316 */     Utils.executeOnceWhenPropertyIsNonNull(paramMenuBar.sceneProperty(), paramScene -> paramScene.addEventFilter(KeyEvent.KEY_PRESSED, this.weakSceneKeyEventHandler));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  321 */     this.mouseEventHandler = (paramMouseEvent -> {
/*      */         Bounds bounds = this.container.localToScreen(this.container.getLayoutBounds());
/*      */         if (bounds == null || !bounds.contains(paramMouseEvent.getScreenX(), paramMouseEvent.getScreenY())) {
/*      */           unSelectMenus();
/*      */         }
/*      */       });
/*  327 */     this.weakSceneMouseEventHandler = new WeakEventHandler<>(this.mouseEventHandler);
/*  328 */     Utils.executeOnceWhenPropertyIsNonNull(paramMenuBar.sceneProperty(), paramScene -> paramScene.addEventFilter(MouseEvent.MOUSE_CLICKED, this.weakSceneMouseEventHandler));
/*      */ 
/*      */ 
/*      */     
/*  332 */     this.weakWindowFocusListener = new WeakChangeListener<>((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*      */           if (!paramBoolean2.booleanValue()) {
/*      */             unSelectMenus();
/*      */           }
/*      */         });
/*      */     
/*  338 */     Utils.executeOnceWhenPropertyIsNonNull(paramMenuBar.sceneProperty(), paramScene -> {
/*      */           if (paramScene.getWindow() != null) {
/*      */             paramScene.getWindow().focusedProperty().addListener(this.weakWindowFocusListener);
/*      */           } else {
/*      */             ChangeListener<Window> changeListener = ();
/*      */ 
/*      */             
/*      */             this.weakWindowSceneListener = new WeakChangeListener<>(changeListener);
/*      */ 
/*      */             
/*      */             paramScene.windowProperty().addListener(this.weakWindowSceneListener);
/*      */           } 
/*      */         });
/*      */ 
/*      */     
/*  353 */     this.menuVisibilityChangeListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> rebuildUI());
/*      */ 
/*      */ 
/*      */     
/*  357 */     rebuildUI();
/*  358 */     paramMenuBar.getMenus().addListener(paramChange -> rebuildUI());
/*      */ 
/*      */ 
/*      */     
/*  362 */     if (Toolkit.getToolkit().getSystemMenu().isSupported()) {
/*  363 */       paramMenuBar.useSystemMenuBarProperty().addListener(paramObservable -> rebuildUI());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  384 */     if (Utils.isMac()) {
/*  385 */       keyCombination = KeyCombination.keyCombination("ctrl+F10");
/*      */     } else {
/*  387 */       keyCombination = KeyCombination.keyCombination("F10");
/*      */     } 
/*      */     
/*  390 */     this.altKeyEventHandler = (paramKeyEvent -> {
/*      */         if (paramKeyEvent.getEventType() == KeyEvent.KEY_PRESSED) {
/*      */           this.altKeyPressed = false;
/*      */           
/*      */           if (paramKeyEvent.getCode() == KeyCode.ALT && !paramKeyEvent.isConsumed()) {
/*      */             if (this.focusedMenuIndex == -1) {
/*      */               this.altKeyPressed = true;
/*      */             }
/*      */             
/*      */             unSelectMenus();
/*      */           } 
/*      */         } else if (paramKeyEvent.getEventType() == KeyEvent.KEY_RELEASED) {
/*      */           if (this.altKeyPressed && paramKeyEvent.getCode() == KeyCode.ALT && !paramKeyEvent.isConsumed()) {
/*      */             this.firstMenuRunnable.run();
/*      */           }
/*      */           
/*      */           this.altKeyPressed = false;
/*      */         } 
/*      */       });
/*  409 */     this.weakSceneAltKeyEventHandler = new WeakEventHandler<>(this.altKeyEventHandler);
/*      */     
/*  411 */     Utils.executeOnceWhenPropertyIsNonNull(paramMenuBar.sceneProperty(), paramScene -> {
/*      */           paramScene.getAccelerators().put(paramKeyCombination, this.firstMenuRunnable);
/*      */           
/*      */           paramScene.addEventHandler(KeyEvent.ANY, this.weakSceneAltKeyEventHandler);
/*      */         });
/*  416 */     ParentTraversalEngine parentTraversalEngine = new ParentTraversalEngine(getSkinnable());
/*  417 */     parentTraversalEngine.addTraverseListener((paramNode, paramBounds) -> {
/*      */           if (this.openMenu != null)
/*      */             this.openMenu.hide();  setFocusedMenuIndex(0);
/*      */         });
/*  421 */     ParentHelper.setTraversalEngine(getSkinnable(), parentTraversalEngine);
/*      */     
/*  423 */     paramMenuBar.sceneProperty().addListener((paramObservableValue, paramScene1, paramScene2) -> {
/*      */           if (paramScene1 != null) {
/*      */             if (this.weakSceneKeyEventHandler != null) {
/*      */               paramScene1.removeEventFilter(KeyEvent.KEY_PRESSED, this.weakSceneKeyEventHandler);
/*      */             }
/*      */             if (this.weakSceneMouseEventHandler != null) {
/*      */               paramScene1.removeEventFilter(MouseEvent.MOUSE_CLICKED, this.weakSceneMouseEventHandler);
/*      */             }
/*      */             if (this.weakSceneAltKeyEventHandler != null) {
/*      */               paramScene1.removeEventHandler(KeyEvent.ANY, this.weakSceneAltKeyEventHandler);
/*      */             }
/*      */           } 
/*      */           if (paramScene1 != null) {
/*      */             paramScene1.getAccelerators().remove(paramKeyCombination);
/*      */           }
/*      */           if (paramScene2 != null) {
/*      */             paramScene2.getAccelerators().put(paramKeyCombination, this.firstMenuRunnable);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void showMenu(Menu paramMenu) {
/*  451 */     showMenu(paramMenu, false);
/*      */   }
/*      */ 
/*      */   
/*      */   private void showMenu(Menu paramMenu, boolean paramBoolean) {
/*  456 */     if (this.openMenu == paramMenu)
/*  457 */       return;  if (this.openMenu != null) {
/*  458 */       this.openMenu.hide();
/*      */     }
/*      */     
/*  461 */     this.openMenu = paramMenu;
/*  462 */     if (!paramMenu.isShowing() && !isMenuEmpty(paramMenu)) {
/*  463 */       if (paramBoolean) {
/*      */         
/*  465 */         MenuButton menuButton = getNodeForMenu(this.focusedMenuIndex);
/*  466 */         Skin<?> skin = menuButton.getSkin();
/*  467 */         if (skin instanceof MenuButtonSkinBase) {
/*  468 */           ((MenuButtonSkinBase)skin).requestFocusOnFirstMenuItem();
/*      */         }
/*      */       } 
/*      */       
/*  472 */       this.openMenu.show();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setFocusedMenuIndex(int paramInt) {
/*  477 */     this.focusedMenuIndex = paramInt;
/*  478 */     this.focusedMenu = (paramInt == -1) ? null : getSkinnable().getMenus().get(paramInt);
/*      */     
/*  480 */     if (this.focusedMenu != null && this.focusedMenuIndex != -1) {
/*  481 */       this.openMenuButton = (MenuBarButton)this.container.getChildren().get(this.focusedMenuIndex);
/*  482 */       this.openMenuButton.setHover();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDefaultSystemMenuBar(MenuBar paramMenuBar) {
/*  503 */     if (Toolkit.getToolkit().getSystemMenu().isSupported()) {
/*  504 */       wrappedDefaultMenus.clear();
/*  505 */       for (Menu menu : paramMenuBar.getMenus()) {
/*  506 */         wrappedDefaultMenus.add(GlobalMenuAdapter.adapt(menu));
/*      */       }
/*  508 */       paramMenuBar.getMenus().addListener(paramChange -> {
/*      */             wrappedDefaultMenus.clear();
/*      */             for (Menu menu : paramMenuBar.getMenus()) {
/*      */               wrappedDefaultMenus.add(GlobalMenuAdapter.adapt(menu));
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private static MenuBarSkin getMenuBarSkin(Stage paramStage) {
/*  518 */     if (systemMenuMap == null) return null; 
/*  519 */     Reference<MenuBarSkin> reference = systemMenuMap.get(paramStage);
/*  520 */     return (reference == null) ? null : reference.get();
/*      */   }
/*      */   
/*      */   private static void setSystemMenu(Stage paramStage) {
/*  524 */     if (paramStage != null && paramStage.isFocused()) {
/*  525 */       while (paramStage != null && paramStage.getOwner() instanceof Stage) {
/*  526 */         MenuBarSkin menuBarSkin = getMenuBarSkin(paramStage);
/*  527 */         if (menuBarSkin != null && menuBarSkin.wrappedMenus != null) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  534 */         paramStage = (Stage)paramStage.getOwner();
/*      */       } 
/*      */     } else {
/*      */       
/*  538 */       paramStage = null;
/*      */     } 
/*      */     
/*  541 */     if (paramStage != currentMenuBarStage) {
/*  542 */       List<MenuBase> list = null;
/*  543 */       if (paramStage != null) {
/*  544 */         MenuBarSkin menuBarSkin = getMenuBarSkin(paramStage);
/*  545 */         if (menuBarSkin != null) {
/*  546 */           list = menuBarSkin.wrappedMenus;
/*      */         }
/*      */       } 
/*  549 */       if (list == null) {
/*  550 */         list = wrappedDefaultMenus;
/*      */       }
/*  552 */       Toolkit.getToolkit().getSystemMenu().setMenus(list);
/*  553 */       currentMenuBarStage = paramStage;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void initSystemMenuBar() {
/*  558 */     systemMenuMap = new WeakHashMap<>();
/*      */     
/*  560 */     InvalidationListener invalidationListener = paramObservable -> setSystemMenu((Stage)((ReadOnlyProperty)paramObservable).getBean());
/*      */ 
/*      */ 
/*      */     
/*  564 */     for (Window window : stages) {
/*  565 */       window.focusedProperty().addListener(invalidationListener);
/*      */     }
/*  567 */     stages.addListener(paramChange -> {
/*      */           while (paramChange.next()) {
/*      */             for (Window window : paramChange.getRemoved()) {
/*      */               window.focusedProperty().removeListener(paramInvalidationListener);
/*      */             }
/*      */             for (Window window : paramChange.getAddedSubList()) {
/*      */               window.focusedProperty().addListener(paramInvalidationListener);
/*      */               setSystemMenu((Stage)window);
/*      */             } 
/*      */           } 
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setSpacing(double paramDouble) {
/*  594 */     spacingProperty().set(snapSpaceX(paramDouble));
/*      */   }
/*      */   
/*      */   public final double getSpacing() {
/*  598 */     return (this.spacing == null) ? 0.0D : snapSpaceX(this.spacing.get());
/*      */   }
/*      */   
/*      */   public final DoubleProperty spacingProperty() {
/*  602 */     if (this.spacing == null) {
/*  603 */       this.spacing = new StyleableDoubleProperty()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  607 */             double d = get();
/*  608 */             MenuBarSkin.this.container.setSpacing(d);
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  613 */             return MenuBarSkin.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  618 */             return "spacing";
/*      */           }
/*      */ 
/*      */           
/*      */           public CssMetaData<MenuBar, Number> getCssMetaData() {
/*  623 */             return MenuBarSkin.SPACING;
/*      */           }
/*      */         };
/*      */     }
/*  627 */     return this.spacing;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setContainerAlignment(Pos paramPos) {
/*  637 */     containerAlignmentProperty().set(paramPos);
/*      */   }
/*      */   
/*      */   public final Pos getContainerAlignment() {
/*  641 */     return (this.containerAlignment == null) ? Pos.TOP_LEFT : this.containerAlignment.get();
/*      */   }
/*      */   
/*      */   public final ObjectProperty<Pos> containerAlignmentProperty() {
/*  645 */     if (this.containerAlignment == null) {
/*  646 */       this.containerAlignment = new StyleableObjectProperty<Pos>(Pos.TOP_LEFT)
/*      */         {
/*      */           public void invalidated()
/*      */           {
/*  650 */             Pos pos = get();
/*  651 */             MenuBarSkin.this.container.setAlignment(pos);
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  656 */             return MenuBarSkin.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  661 */             return "containerAlignment";
/*      */           }
/*      */ 
/*      */           
/*      */           public CssMetaData<MenuBar, Pos> getCssMetaData() {
/*  666 */             return MenuBarSkin.ALIGNMENT;
/*      */           }
/*      */         };
/*      */     }
/*  670 */     return this.containerAlignment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  683 */     cleanUpSystemMenu();
/*      */     
/*  685 */     super.dispose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double snappedTopInset() {
/*  693 */     return this.container.getChildren().isEmpty() ? 0.0D : super.snappedTopInset();
/*      */   }
/*      */   
/*      */   protected double snappedBottomInset() {
/*  697 */     return this.container.getChildren().isEmpty() ? 0.0D : super.snappedBottomInset();
/*      */   }
/*      */   
/*      */   protected double snappedLeftInset() {
/*  701 */     return this.container.getChildren().isEmpty() ? 0.0D : super.snappedLeftInset();
/*      */   }
/*      */   
/*      */   protected double snappedRightInset() {
/*  705 */     return this.container.getChildren().isEmpty() ? 0.0D : super.snappedRightInset();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  716 */     this.container.resizeRelocate(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  721 */     return this.container.minWidth(paramDouble1) + snappedLeftInset() + snappedRightInset();
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  726 */     return this.container.prefWidth(paramDouble1) + snappedLeftInset() + snappedRightInset();
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  731 */     return this.container.minHeight(paramDouble1) + snappedTopInset() + snappedBottomInset();
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  736 */     return this.container.prefHeight(paramDouble1) + snappedTopInset() + snappedBottomInset();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  742 */     return getSkinnable().prefHeight(-1.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MenuButton getNodeForMenu(int paramInt) {
/*  755 */     if (paramInt < this.container.getChildren().size()) {
/*  756 */       return (MenuButton)this.container.getChildren().get(paramInt);
/*      */     }
/*  758 */     return null;
/*      */   }
/*      */   
/*      */   int getFocusedMenuIndex() {
/*  762 */     return this.focusedMenuIndex;
/*      */   }
/*      */   
/*      */   private boolean menusContainCustomMenuItem() {
/*  766 */     for (Menu menu : getSkinnable().getMenus()) {
/*  767 */       if (menuContainsCustomMenuItem(menu)) {
/*  768 */         System.err.println("Warning: MenuBar ignored property useSystemMenuBar because menus contain CustomMenuItem");
/*  769 */         return true;
/*      */       } 
/*      */     } 
/*  772 */     return false;
/*      */   }
/*      */   
/*      */   private boolean menuContainsCustomMenuItem(Menu paramMenu) {
/*  776 */     for (MenuItem menuItem : paramMenu.getItems()) {
/*  777 */       if (menuItem instanceof CustomMenuItem && !(menuItem instanceof javafx.scene.control.SeparatorMenuItem))
/*  778 */         return true; 
/*  779 */       if (menuItem instanceof Menu && 
/*  780 */         menuContainsCustomMenuItem((Menu)menuItem)) {
/*  781 */         return true;
/*      */       }
/*      */     } 
/*      */     
/*  785 */     return false;
/*      */   }
/*      */   
/*      */   private int getMenuBarButtonIndex(MenuBarButton paramMenuBarButton) {
/*  789 */     for (byte b = 0; b < this.container.getChildren().size(); b++) {
/*  790 */       MenuBarButton menuBarButton = (MenuBarButton)this.container.getChildren().get(b);
/*  791 */       if (paramMenuBarButton == menuBarButton) {
/*  792 */         return b;
/*      */       }
/*      */     } 
/*  795 */     return -1;
/*      */   }
/*      */   
/*      */   private void updateActionListeners(MenuItem paramMenuItem, boolean paramBoolean) {
/*  799 */     if (paramMenuItem instanceof Menu) {
/*  800 */       Menu menu = (Menu)paramMenuItem;
/*      */       
/*  802 */       if (paramBoolean) {
/*  803 */         menu.getItems().addListener(this.menuItemListener);
/*      */       } else {
/*  805 */         menu.getItems().removeListener(this.menuItemListener);
/*      */       } 
/*      */       
/*  808 */       for (MenuItem menuItem : menu.getItems()) {
/*  809 */         updateActionListeners(menuItem, paramBoolean);
/*      */       }
/*      */     }
/*  812 */     else if (paramBoolean) {
/*  813 */       paramMenuItem.addEventHandler(ActionEvent.ACTION, this.menuActionEventHandler);
/*      */     } else {
/*  815 */       paramMenuItem.removeEventHandler(ActionEvent.ACTION, this.menuActionEventHandler);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void rebuildUI() {
/*  821 */     getSkinnable().focusedProperty().removeListener(this.menuBarFocusedPropertyListener);
/*  822 */     for (Menu menu : getSkinnable().getMenus()) {
/*      */       
/*  824 */       updateActionListeners(menu, false);
/*      */       
/*  826 */       menu.visibleProperty().removeListener(this.menuVisibilityChangeListener);
/*      */     } 
/*  828 */     for (Node node : this.container.getChildren()) {
/*      */ 
/*      */       
/*  831 */       MenuBarButton menuBarButton = (MenuBarButton)node;
/*  832 */       menuBarButton.hide();
/*  833 */       menuBarButton.menu.showingProperty().removeListener(menuBarButton.menuListener);
/*  834 */       menuBarButton.disableProperty().unbind();
/*  835 */       menuBarButton.textProperty().unbind();
/*  836 */       menuBarButton.graphicProperty().unbind();
/*  837 */       menuBarButton.styleProperty().unbind();
/*      */       
/*  839 */       menuBarButton.dispose();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  845 */       menuBarButton.setSkin(null);
/*  846 */       menuBarButton = null;
/*      */     } 
/*  848 */     this.container.getChildren().clear();
/*      */     
/*  850 */     if (Toolkit.getToolkit().getSystemMenu().isSupported()) {
/*  851 */       Scene scene = getSkinnable().getScene();
/*  852 */       if (scene != null) {
/*      */         
/*  854 */         if (this.sceneChangeListener == null) {
/*  855 */           this.sceneChangeListener = ((paramObservableValue, paramScene1, paramScene2) -> {
/*      */               if (paramScene1 != null && paramScene1.getWindow() instanceof Stage) {
/*      */                 Stage stage = (Stage)paramScene1.getWindow();
/*      */                 
/*      */                 MenuBarSkin menuBarSkin = getMenuBarSkin(stage);
/*      */                 
/*      */                 if (menuBarSkin == this) {
/*      */                   menuBarSkin.wrappedMenus = null;
/*      */                   
/*      */                   systemMenuMap.remove(stage);
/*      */                   
/*      */                   if (currentMenuBarStage == stage) {
/*      */                     currentMenuBarStage = null;
/*      */                     
/*      */                     setSystemMenu(stage);
/*      */                   } 
/*      */                 } else if (menuBarSkin != null && menuBarSkin.getSkinnable() != null && menuBarSkin.getSkinnable().isUseSystemMenuBar()) {
/*      */                   menuBarSkin.getSkinnable().setUseSystemMenuBar(false);
/*      */                 } 
/*      */               } 
/*      */               
/*      */               if (paramScene2 != null && getSkinnable().isUseSystemMenuBar() && !menusContainCustomMenuItem() && paramScene2.getWindow() instanceof Stage) {
/*      */                 Stage stage = (Stage)paramScene2.getWindow();
/*      */                 
/*      */                 if (systemMenuMap == null) {
/*      */                   initSystemMenuBar();
/*      */                 }
/*      */                 
/*      */                 this.wrappedMenus = new ArrayList<>();
/*      */                 
/*      */                 systemMenuMap.put(stage, new WeakReference<>(this));
/*      */                 
/*      */                 for (Menu menu : getSkinnable().getMenus()) {
/*      */                   this.wrappedMenus.add(GlobalMenuAdapter.adapt(menu));
/*      */                 }
/*      */                 
/*      */                 currentMenuBarStage = null;
/*      */                 
/*      */                 setSystemMenu(stage);
/*      */                 
/*      */                 getSkinnable().requestLayout();
/*      */                 Platform.runLater(());
/*      */               } 
/*      */             });
/*  899 */           getSkinnable().sceneProperty().addListener(this.sceneChangeListener);
/*      */         } 
/*      */ 
/*      */         
/*  903 */         this.sceneChangeListener.changed(getSkinnable().sceneProperty(), scene, scene);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  910 */         if ((currentMenuBarStage != null) ? (getMenuBarSkin(currentMenuBarStage) == this) : getSkinnable().isUseSystemMenuBar())
/*      */         {
/*      */           return;
/*      */         
/*      */         }
/*      */       }
/*  916 */       else if (currentMenuBarStage != null) {
/*  917 */         MenuBarSkin menuBarSkin = getMenuBarSkin(currentMenuBarStage);
/*  918 */         if (menuBarSkin == this) {
/*  919 */           setSystemMenu((Stage)null);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  925 */     getSkinnable().focusedProperty().addListener(this.menuBarFocusedPropertyListener);
/*  926 */     for (Iterator<Menu> iterator = getSkinnable().getMenus().iterator(); iterator.hasNext(); ) { Menu menu = iterator.next();
/*      */       
/*  928 */       menu.visibleProperty().addListener(this.menuVisibilityChangeListener);
/*      */       
/*  930 */       if (!menu.isVisible())
/*  931 */         continue;  MenuBarButton menuBarButton = new MenuBarButton(this, menu);
/*  932 */       menuBarButton.setFocusTraversable(false);
/*  933 */       menuBarButton.getStyleClass().add("menu");
/*  934 */       menuBarButton.setStyle(menu.getStyle());
/*      */       
/*  936 */       menuBarButton.getItems().setAll(menu.getItems());
/*  937 */       this.container.getChildren().add(menuBarButton);
/*      */       
/*  939 */       menuBarButton.menuListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*      */           if (paramMenu.isShowing()) {
/*      */             paramMenuBarButton.show();
/*      */             menuModeStart(this.container.getChildren().indexOf(paramMenuBarButton));
/*      */           } else {
/*      */             paramMenuBarButton.hide();
/*      */           } 
/*      */         });
/*  947 */       menuBarButton.menu = menu;
/*  948 */       menu.showingProperty().addListener(menuBarButton.menuListener);
/*  949 */       menuBarButton.disableProperty().bindBidirectional(menu.disableProperty());
/*  950 */       menuBarButton.textProperty().bind(menu.textProperty());
/*  951 */       menuBarButton.graphicProperty().bind(menu.graphicProperty());
/*  952 */       menuBarButton.styleProperty().bind(menu.styleProperty());
/*  953 */       menuBarButton.getProperties().addListener(paramChange -> {
/*      */             if (paramChange.wasAdded() && "autoHide".equals(paramChange.getKey())) {
/*      */               paramMenuBarButton.getProperties().remove("autoHide");
/*      */               paramMenu.hide();
/*      */             } 
/*      */           });
/*  959 */       menuBarButton.showingProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*      */             if (paramBoolean2.booleanValue()) {
/*      */               if (this.openMenuButton == null && this.focusedMenuIndex != -1) {
/*      */                 this.openMenuButton = (MenuBarButton)this.container.getChildren().get(this.focusedMenuIndex);
/*      */               }
/*      */               
/*      */               if (this.openMenuButton != null && this.openMenuButton != paramMenuBarButton) {
/*      */                 this.openMenuButton.clearHover();
/*      */               }
/*      */               
/*      */               this.openMenuButton = paramMenuBarButton;
/*      */               
/*      */               showMenu(paramMenu);
/*      */             } else {
/*      */               this.openMenu = null;
/*      */               
/*      */               this.openMenuButton = null;
/*      */             } 
/*      */           });
/*  978 */       menuBarButton.setOnMousePressed(paramMouseEvent -> {
/*      */             this.pendingDismiss = paramMenuBarButton.isShowing();
/*      */ 
/*      */             
/*      */             if (paramMenuBarButton.getScene().getWindow().isFocused()) {
/*      */               showMenu(paramMenu);
/*      */               
/*      */               menuModeStart(getMenuBarButtonIndex(paramMenuBarButton));
/*      */             } 
/*      */           });
/*      */       
/*  989 */       menuBarButton.setOnMouseReleased(paramMouseEvent -> {
/*      */             if (paramMenuBarButton.getScene().getWindow().isFocused() && this.pendingDismiss) {
/*      */               resetOpenMenu();
/*      */             }
/*      */ 
/*      */             
/*      */             this.pendingDismiss = false;
/*      */           });
/*      */ 
/*      */       
/*  999 */       menuBarButton.setOnMouseEntered(paramMouseEvent -> {
/*      */             if (paramMenuBarButton.getScene() != null && paramMenuBarButton.getScene().getWindow() != null && paramMenuBarButton.getScene().getWindow().isFocused()) {
/*      */               if (this.openMenuButton != null && this.openMenuButton != paramMenuBarButton) {
/*      */                 this.openMenuButton.clearHover();
/*      */                 
/*      */                 this.openMenuButton = null;
/*      */                 
/*      */                 this.openMenuButton = paramMenuBarButton;
/*      */               } 
/*      */               updateFocusedIndex();
/*      */               if (this.openMenu != null && this.openMenu != paramMenu) {
/*      */                 showMenu(paramMenu);
/*      */               }
/*      */             } 
/*      */           });
/* 1014 */       updateActionListeners(menu, true); }
/*      */     
/* 1016 */     getSkinnable().requestLayout();
/*      */   }
/*      */   
/*      */   private void cleanUpSystemMenu() {
/* 1020 */     if (this.sceneChangeListener != null && getSkinnable() != null) {
/* 1021 */       getSkinnable().sceneProperty().removeListener(this.sceneChangeListener);
/*      */ 
/*      */ 
/*      */       
/* 1025 */       this.sceneChangeListener = null;
/*      */     } 
/*      */     
/* 1028 */     if (currentMenuBarStage != null && getMenuBarSkin(currentMenuBarStage) == this) {
/* 1029 */       setSystemMenu((Stage)null);
/*      */     }
/*      */     
/* 1032 */     if (systemMenuMap != null) {
/* 1033 */       Iterator<Map.Entry> iterator = systemMenuMap.entrySet().iterator();
/* 1034 */       while (iterator.hasNext()) {
/* 1035 */         Map.Entry entry = iterator.next();
/* 1036 */         Reference<MenuBarSkin> reference = (Reference)entry.getValue();
/* 1037 */         MenuBarSkin menuBarSkin = (reference != null) ? reference.get() : null;
/* 1038 */         if (menuBarSkin == null || menuBarSkin == this) {
/* 1039 */           iterator.remove();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isMenuEmpty(Menu paramMenu) {
/* 1046 */     boolean bool = true;
/* 1047 */     if (paramMenu != null)
/* 1048 */       for (MenuItem menuItem : paramMenu.getItems()) {
/* 1049 */         if (menuItem != null && menuItem.isVisible()) bool = false;
/*      */       
/*      */       }  
/* 1052 */     return bool;
/*      */   }
/*      */   
/*      */   private void resetOpenMenu() {
/* 1056 */     if (this.openMenu != null) {
/* 1057 */       this.openMenu.hide();
/* 1058 */       this.openMenu = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void unSelectMenus() {
/* 1063 */     clearMenuButtonHover();
/* 1064 */     if (this.focusedMenuIndex == -1)
/* 1065 */       return;  if (this.openMenu != null) {
/* 1066 */       this.openMenu.hide();
/* 1067 */       this.openMenu = null;
/*      */     } 
/* 1069 */     if (this.openMenuButton != null) {
/* 1070 */       this.openMenuButton.clearHover();
/* 1071 */       this.openMenuButton = null;
/*      */     } 
/* 1073 */     menuModeEnd();
/*      */   }
/*      */   
/*      */   private void menuModeStart(int paramInt) {
/* 1077 */     if (this.focusedMenuIndex == -1) {
/* 1078 */       SceneHelper.getSceneAccessor().setTransientFocusContainer(getSkinnable().getScene(), getSkinnable());
/*      */     }
/* 1080 */     setFocusedMenuIndex(paramInt);
/*      */   }
/*      */   
/*      */   private void menuModeEnd() {
/* 1084 */     if (this.focusedMenuIndex != -1) {
/* 1085 */       SceneHelper.getSceneAccessor().setTransientFocusContainer(getSkinnable().getScene(), null);
/*      */ 
/*      */       
/* 1088 */       getSkinnable().notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_NODE);
/*      */     } 
/* 1090 */     setFocusedMenuIndex(-1);
/*      */   }
/*      */   
/*      */   private void moveToMenu(Direction paramDirection, boolean paramBoolean) {
/* 1094 */     boolean bool = (paramBoolean && this.focusedMenu.isShowing()) ? true : false;
/* 1095 */     findSibling(paramDirection, this.focusedMenuIndex).ifPresent(paramPair -> {
/*      */           setFocusedMenuIndex(((Integer)paramPair.getValue()).intValue());
/*      */           if (paramBoolean) {
/*      */             showMenu((Menu)paramPair.getKey(), false);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Optional<Pair<Menu, Integer>> findSibling(Direction paramDirection, int paramInt) {
/* 1106 */     if (paramInt == -1) {
/* 1107 */       return Optional.empty();
/*      */     }
/*      */     
/* 1110 */     int i = getSkinnable().getMenus().size();
/* 1111 */     byte b = 0;
/* 1112 */     int j = 0;
/*      */ 
/*      */     
/* 1115 */     while (b < i) {
/* 1116 */       b++;
/*      */       
/* 1118 */       j = (paramInt + (paramDirection.isForward() ? 1 : -1)) % i;
/*      */       
/* 1120 */       if (j == -1)
/*      */       {
/* 1122 */         j = i - 1;
/*      */       }
/*      */ 
/*      */       
/* 1126 */       if (((Menu)getSkinnable().getMenus().get(j)).isDisable())
/*      */       {
/* 1128 */         paramInt = j;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1135 */     clearMenuButtonHover();
/* 1136 */     return Optional.of(new Pair<>(getSkinnable().getMenus().get(j), Integer.valueOf(j)));
/*      */   }
/*      */   
/*      */   private void updateFocusedIndex() {
/* 1140 */     byte b = 0;
/* 1141 */     for (Node node : this.container.getChildren()) {
/* 1142 */       if (node.isHover()) {
/* 1143 */         setFocusedMenuIndex(b);
/*      */         return;
/*      */       } 
/* 1146 */       b++;
/*      */     } 
/* 1148 */     menuModeEnd();
/*      */   }
/*      */   
/*      */   private void clearMenuButtonHover() {
/* 1152 */     for (Node node : this.container.getChildren()) {
/* 1153 */       if (node.isHover()) {
/* 1154 */         ((MenuBarButton)node).clearHover();
/* 1155 */         ((MenuBarButton)node).disarm();
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1169 */   private static final CssMetaData<MenuBar, Number> SPACING = new CssMetaData<MenuBar, Number>("-fx-spacing", 
/*      */       
/* 1171 */       SizeConverter.getInstance(), Double.valueOf(0.0D))
/*      */     {
/*      */       public boolean isSettable(MenuBar param1MenuBar)
/*      */       {
/* 1175 */         MenuBarSkin menuBarSkin = (MenuBarSkin)param1MenuBar.getSkin();
/* 1176 */         return (menuBarSkin.spacing == null || !menuBarSkin.spacing.isBound());
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<Number> getStyleableProperty(MenuBar param1MenuBar) {
/* 1181 */         MenuBarSkin menuBarSkin = (MenuBarSkin)param1MenuBar.getSkin();
/* 1182 */         return (StyleableProperty<Number>)menuBarSkin.spacingProperty();
/*      */       }
/*      */     };
/*      */   
/* 1186 */   private static final CssMetaData<MenuBar, Pos> ALIGNMENT = new CssMetaData<MenuBar, Pos>("-fx-alignment", (StyleConverter)new EnumConverter(Pos.class), Pos.TOP_LEFT)
/*      */     {
/*      */ 
/*      */       
/*      */       public boolean isSettable(MenuBar param1MenuBar)
/*      */       {
/* 1192 */         MenuBarSkin menuBarSkin = (MenuBarSkin)param1MenuBar.getSkin();
/* 1193 */         return (menuBarSkin.containerAlignment == null || !menuBarSkin.containerAlignment.isBound());
/*      */       }
/*      */ 
/*      */       
/*      */       public StyleableProperty<Pos> getStyleableProperty(MenuBar param1MenuBar) {
/* 1198 */         MenuBarSkin menuBarSkin = (MenuBarSkin)param1MenuBar.getSkin();
/* 1199 */         return (StyleableProperty<Pos>)menuBarSkin.containerAlignmentProperty();
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*      */   private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */ 
/*      */   
/*      */   static {
/* 1208 */     ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(SkinBase.getClassCssMetaData());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1213 */     String str = ALIGNMENT.getProperty(); byte b; int i;
/* 1214 */     for (b = 0, i = arrayList.size(); b < i; b++) {
/* 1215 */       CssMetaData cssMetaData = arrayList.get(b);
/* 1216 */       if (str.equals(cssMetaData.getProperty())) arrayList.remove(cssMetaData);
/*      */     
/*      */     } 
/* 1219 */     arrayList.add(SPACING);
/* 1220 */     arrayList.add(ALIGNMENT);
/* 1221 */     STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1232 */     return STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 1240 */     return getClassCssMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 1251 */     switch (paramAccessibleAttribute) { case LEFT:
/* 1252 */         return this.openMenuButton; }
/* 1253 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\MenuBarSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */