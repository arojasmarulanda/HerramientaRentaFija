/*      */ package javafx.scene.control.skin;
/*      */ 
/*      */ import com.sun.javafx.PlatformUtil;
/*      */ import com.sun.javafx.scene.control.LabeledText;
/*      */ import com.sun.javafx.scene.control.behavior.TextBinding;
/*      */ import com.sun.javafx.scene.control.skin.Utils;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.geometry.HPos;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.geometry.Point2D;
/*      */ import javafx.geometry.Pos;
/*      */ import javafx.geometry.VPos;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.control.ContentDisplay;
/*      */ import javafx.scene.control.Label;
/*      */ import javafx.scene.control.Labeled;
/*      */ import javafx.scene.control.OverrunStyle;
/*      */ import javafx.scene.control.SkinBase;
/*      */ import javafx.scene.input.KeyCombination;
/*      */ import javafx.scene.input.Mnemonic;
/*      */ import javafx.scene.shape.Line;
/*      */ import javafx.scene.shape.Rectangle;
/*      */ import javafx.scene.text.Font;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class LabeledSkinBase<C extends Labeled>
/*      */   extends SkinBase<C>
/*      */ {
/*      */   LabeledText text;
/*      */   boolean invalidText = true;
/*      */   Node graphic;
/*   99 */   double textWidth = Double.NEGATIVE_INFINITY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  106 */   double ellipsisWidth = Double.NEGATIVE_INFINITY;
/*      */ 
/*      */   
/*      */   final InvalidationListener graphicPropertyChangedListener = paramObservable -> {
/*      */       this.invalidText = true;
/*      */       if (getSkinnable() != null) {
/*      */         ((Labeled)getSkinnable()).requestLayout();
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*      */   private Rectangle textClip;
/*      */ 
/*      */   
/*      */   private double wrapWidth;
/*      */ 
/*      */   
/*      */   private double wrapHeight;
/*      */ 
/*      */   
/*      */   private TextBinding bindings;
/*      */   
/*      */   private Line mnemonic_underscore;
/*      */   
/*      */   private boolean containsMnemonic = false;
/*      */   
/*  132 */   private Scene mnemonicScene = null;
/*      */   
/*      */   private KeyCombination mnemonicCode;
/*  135 */   private Node labeledNode = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LabeledSkinBase(C paramC) {
/*  155 */     super(paramC);
/*      */ 
/*      */ 
/*      */     
/*  159 */     this.text = new LabeledText((Labeled)paramC);
/*      */     
/*  161 */     updateChildren();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  175 */     registerChangeListener(paramC.ellipsisStringProperty(), paramObservableValue -> {
/*      */           textMetricsChanged();
/*      */           invalidateWidths();
/*      */           this.ellipsisWidth = Double.NEGATIVE_INFINITY;
/*      */         });
/*  180 */     registerChangeListener(paramC.widthProperty(), paramObservableValue -> {
/*      */           updateWrappingWidth();
/*      */           
/*      */           this.invalidText = true;
/*      */         });
/*  185 */     registerChangeListener(paramC.heightProperty(), paramObservableValue -> this.invalidText = true);
/*      */ 
/*      */ 
/*      */     
/*  189 */     registerChangeListener(paramC.fontProperty(), paramObservableValue -> {
/*      */           textMetricsChanged();
/*      */           invalidateWidths();
/*      */           this.ellipsisWidth = Double.NEGATIVE_INFINITY;
/*      */         });
/*  194 */     registerChangeListener(paramC.graphicProperty(), paramObservableValue -> {
/*      */           updateChildren();
/*      */           textMetricsChanged();
/*      */         });
/*  198 */     registerChangeListener(paramC.contentDisplayProperty(), paramObservableValue -> {
/*      */           updateChildren();
/*      */           textMetricsChanged();
/*      */         });
/*  202 */     registerChangeListener(paramC.labelPaddingProperty(), paramObservableValue -> textMetricsChanged());
/*  203 */     registerChangeListener(paramC.graphicTextGapProperty(), paramObservableValue -> textMetricsChanged());
/*  204 */     registerChangeListener(paramC.alignmentProperty(), paramObservableValue -> ((Labeled)getSkinnable()).requestLayout());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  215 */     registerChangeListener(paramC.mnemonicParsingProperty(), paramObservableValue -> {
/*      */           this.containsMnemonic = false;
/*      */           textMetricsChanged();
/*      */         });
/*  219 */     registerChangeListener(paramC.textProperty(), paramObservableValue -> {
/*      */           updateChildren();
/*      */           textMetricsChanged();
/*      */           invalidateWidths();
/*      */         });
/*  224 */     registerChangeListener(paramC.textAlignmentProperty(), paramObservableValue -> { 
/*  225 */         }); registerChangeListener(paramC.textOverrunProperty(), paramObservableValue -> textMetricsChanged());
/*  226 */     registerChangeListener(paramC.wrapTextProperty(), paramObservableValue -> {
/*      */           updateWrappingWidth();
/*      */           textMetricsChanged();
/*      */         });
/*  230 */     registerChangeListener(paramC.underlineProperty(), paramObservableValue -> textMetricsChanged());
/*  231 */     registerChangeListener(paramC.lineSpacingProperty(), paramObservableValue -> textMetricsChanged());
/*  232 */     registerChangeListener(paramC.sceneProperty(), paramObservableValue -> sceneChanged());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateChildren() {
/*  251 */     Labeled labeled = (Labeled)getSkinnable();
/*      */ 
/*      */ 
/*      */     
/*  255 */     if (this.graphic != null) {
/*  256 */       this.graphic.layoutBoundsProperty().removeListener(this.graphicPropertyChangedListener);
/*      */     }
/*      */     
/*  259 */     this.graphic = labeled.getGraphic();
/*      */ 
/*      */ 
/*      */     
/*  263 */     if (this.graphic instanceof javafx.scene.image.ImageView) {
/*  264 */       this.graphic.setMouseTransparent(true);
/*      */     }
/*      */ 
/*      */     
/*  268 */     if (isIgnoreGraphic()) {
/*  269 */       if (labeled.getContentDisplay() == ContentDisplay.GRAPHIC_ONLY) {
/*  270 */         getChildren().clear();
/*      */       } else {
/*  272 */         getChildren().setAll(new Node[] { (Node)this.text });
/*      */       } 
/*      */     } else {
/*  275 */       this.graphic.layoutBoundsProperty().addListener(this.graphicPropertyChangedListener);
/*  276 */       if (isIgnoreText()) {
/*  277 */         getChildren().setAll(new Node[] { this.graphic });
/*      */       } else {
/*  279 */         getChildren().setAll(new Node[] { this.graphic, (Node)this.text });
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  296 */     return computeMinLabeledPartWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  301 */     return computeMinLabeledPartHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  307 */     Labeled labeled = (Labeled)getSkinnable();
/*  308 */     Font font = this.text.getFont();
/*  309 */     String str = labeled.getText();
/*  310 */     boolean bool = (str == null || str.isEmpty()) ? true : false;
/*  311 */     double d1 = paramDouble5 + paramDouble3;
/*      */     
/*  313 */     if (!isIgnoreText()) {
/*  314 */       d1 += leftLabelPadding() + rightLabelPadding();
/*      */     }
/*      */     
/*  317 */     double d2 = 0.0D;
/*  318 */     if (!bool) {
/*  319 */       if (labeled.isMnemonicParsing() && 
/*  320 */         str.contains("_") && str.indexOf("_") != str.length() - 1) {
/*  321 */         str = str.replaceFirst("_", "");
/*      */       }
/*      */       
/*  324 */       d2 = Utils.computeTextWidth(font, str, 0.0D);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  329 */     double d3 = (this.graphic == null) ? 0.0D : Utils.boundedSize(this.graphic.prefWidth(-1.0D), this.graphic.minWidth(-1.0D), this.graphic.maxWidth(-1.0D));
/*      */ 
/*      */     
/*  332 */     if (isIgnoreGraphic())
/*  333 */       return d2 + d1; 
/*  334 */     if (isIgnoreText())
/*  335 */       return d3 + d1; 
/*  336 */     if (labeled.getContentDisplay() == ContentDisplay.LEFT || labeled
/*  337 */       .getContentDisplay() == ContentDisplay.RIGHT) {
/*  338 */       return d2 + labeled.getGraphicTextGap() + d3 + d1;
/*      */     }
/*  340 */     return Math.max(d2, d3) + d1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  346 */     Labeled labeled = (Labeled)getSkinnable();
/*  347 */     Font font = this.text.getFont();
/*  348 */     ContentDisplay contentDisplay = labeled.getContentDisplay();
/*  349 */     double d1 = labeled.getGraphicTextGap();
/*      */     
/*  351 */     paramDouble1 -= paramDouble5 + paramDouble3;
/*      */     
/*  353 */     if (!isIgnoreText()) {
/*  354 */       paramDouble1 -= leftLabelPadding() + rightLabelPadding();
/*      */     }
/*      */     
/*  357 */     String str = labeled.getText();
/*  358 */     if (str != null && str.endsWith("\n"))
/*      */     {
/*  360 */       str = str.substring(0, str.length() - 1);
/*      */     }
/*      */     
/*  363 */     double d2 = paramDouble1;
/*  364 */     if (!isIgnoreGraphic() && (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT))
/*      */     {
/*  366 */       d2 -= this.graphic.prefWidth(-1.0D) + d1;
/*      */     }
/*      */ 
/*      */     
/*  370 */     double d3 = Utils.computeTextHeight(font, str, 
/*  371 */         labeled.isWrapText() ? d2 : 0.0D, labeled
/*  372 */         .getLineSpacing(), this.text.getBoundsType());
/*      */ 
/*      */     
/*  375 */     double d4 = d3;
/*  376 */     if (!isIgnoreGraphic()) {
/*  377 */       Node node = labeled.getGraphic();
/*  378 */       if (contentDisplay == ContentDisplay.TOP || contentDisplay == ContentDisplay.BOTTOM) {
/*  379 */         d4 = node.prefHeight(paramDouble1) + d1 + d3;
/*      */       } else {
/*  381 */         d4 = Math.max(d3, node.prefHeight(paramDouble1));
/*      */       } 
/*      */     } 
/*      */     
/*  385 */     double d5 = paramDouble2 + paramDouble4;
/*      */     
/*  387 */     if (!isIgnoreText()) {
/*  388 */       d5 += topLabelPadding() + bottomLabelPadding();
/*      */     }
/*      */     
/*  391 */     return d4 + d5;
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  396 */     return ((Labeled)getSkinnable()).prefWidth(paramDouble1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  401 */     return ((Labeled)getSkinnable()).prefHeight(paramDouble1);
/*      */   }
/*      */ 
/*      */   
/*      */   public double computeBaselineOffset(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  406 */     double d1 = this.text.getBaselineOffset();
/*  407 */     double d2 = d1;
/*  408 */     Labeled labeled = (Labeled)getSkinnable();
/*  409 */     Node node = labeled.getGraphic();
/*  410 */     if (!isIgnoreGraphic()) {
/*  411 */       ContentDisplay contentDisplay = labeled.getContentDisplay();
/*  412 */       if (contentDisplay == ContentDisplay.TOP) {
/*  413 */         d2 = node.prefHeight(-1.0D) + labeled.getGraphicTextGap() + d1;
/*  414 */       } else if (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT) {
/*  415 */         d2 = d1 + (node.prefHeight(-1.0D) - this.text.prefHeight(-1.0D)) / 2.0D;
/*      */       } 
/*      */     } 
/*      */     
/*  419 */     double d3 = paramDouble1 + d2;
/*  420 */     if (!isIgnoreText()) {
/*  421 */       d3 += topLabelPadding();
/*      */     }
/*  423 */     return d3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  440 */     layoutLabelInArea(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutLabelInArea(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  456 */     layoutLabelInArea(paramDouble1, paramDouble2, paramDouble3, paramDouble4, (Pos)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutLabelInArea(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, Pos paramPos) {
/*      */     double d8, d9;
/*  475 */     Labeled labeled = (Labeled)getSkinnable();
/*  476 */     ContentDisplay contentDisplay = labeled.getContentDisplay();
/*      */     
/*  478 */     if (paramPos == null) {
/*  479 */       paramPos = labeled.getAlignment();
/*      */     }
/*      */     
/*  482 */     HPos hPos = (paramPos == null) ? HPos.LEFT : paramPos.getHpos();
/*  483 */     VPos vPos = (paramPos == null) ? VPos.CENTER : paramPos.getVpos();
/*      */ 
/*      */ 
/*      */     
/*  487 */     boolean bool1 = isIgnoreGraphic();
/*  488 */     boolean bool2 = isIgnoreText();
/*      */     
/*  490 */     if (!bool2) {
/*  491 */       paramDouble1 += leftLabelPadding();
/*  492 */       paramDouble2 += topLabelPadding();
/*  493 */       paramDouble3 -= leftLabelPadding() + rightLabelPadding();
/*  494 */       paramDouble4 -= topLabelPadding() + bottomLabelPadding();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  504 */     double d2 = 0.0D, d1 = d2;
/*  505 */     if (bool2) {
/*  506 */       if (this.graphic.isResizable()) {
/*  507 */         Orientation orientation = this.graphic.getContentBias();
/*  508 */         if (orientation == Orientation.HORIZONTAL) {
/*  509 */           d1 = Utils.boundedSize(paramDouble3, this.graphic.minWidth(-1.0D), this.graphic.maxWidth(-1.0D));
/*  510 */           d2 = Utils.boundedSize(paramDouble4, this.graphic.minHeight(d1), this.graphic.maxHeight(d1));
/*  511 */         } else if (orientation == Orientation.VERTICAL) {
/*  512 */           d2 = Utils.boundedSize(paramDouble4, this.graphic.minHeight(-1.0D), this.graphic.maxHeight(-1.0D));
/*  513 */           d1 = Utils.boundedSize(paramDouble3, this.graphic.minWidth(d2), this.graphic.maxWidth(d2));
/*      */         } else {
/*  515 */           d1 = Utils.boundedSize(paramDouble3, this.graphic.minWidth(-1.0D), this.graphic.maxWidth(-1.0D));
/*  516 */           d2 = Utils.boundedSize(paramDouble4, this.graphic.minHeight(-1.0D), this.graphic.maxHeight(-1.0D));
/*      */         } 
/*  518 */         this.graphic.resize(d1, d2);
/*      */       } else {
/*  520 */         d1 = this.graphic.getLayoutBounds().getWidth();
/*  521 */         d2 = this.graphic.getLayoutBounds().getHeight();
/*      */       } 
/*      */     } else {
/*  524 */       this.graphic.autosize();
/*  525 */       d1 = this.graphic.getLayoutBounds().getWidth();
/*  526 */       d2 = this.graphic.getLayoutBounds().getHeight();
/*      */     } 
/*      */ 
/*      */     
/*  530 */     double d4 = 0.0D, d3 = d4;
/*  531 */     this.text.setText("");
/*      */     
/*  533 */     updateDisplayedText(paramDouble3, paramDouble4);
/*  534 */     d3 = snapSizeX(Math.min(this.text.getLayoutBounds().getWidth(), this.wrapWidth));
/*  535 */     d4 = snapSizeY(Math.min(this.text.getLayoutBounds().getHeight(), this.wrapHeight));
/*      */ 
/*      */     
/*  538 */     double d5 = (bool2 || bool1) ? 0.0D : labeled.getGraphicTextGap();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  543 */     double d6 = Math.max(d1, d3);
/*  544 */     double d7 = Math.max(d2, d4);
/*  545 */     if (contentDisplay == ContentDisplay.TOP || contentDisplay == ContentDisplay.BOTTOM) {
/*  546 */       d7 = d2 + d5 + d4;
/*  547 */     } else if (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT) {
/*  548 */       d6 = d1 + d5 + d3;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  555 */     if (hPos == HPos.LEFT) {
/*  556 */       d8 = paramDouble1;
/*  557 */     } else if (hPos == HPos.RIGHT) {
/*  558 */       d8 = paramDouble1 + paramDouble3 - d6;
/*      */     }
/*      */     else {
/*      */       
/*  562 */       d8 = paramDouble1 + (paramDouble3 - d6) / 2.0D;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  567 */     if (vPos == VPos.TOP) {
/*  568 */       d9 = paramDouble2;
/*  569 */     } else if (vPos == VPos.BOTTOM) {
/*  570 */       d9 = paramDouble2 + paramDouble4 - d7;
/*      */     }
/*      */     else {
/*      */       
/*  574 */       d9 = paramDouble2 + (paramDouble4 - d7) / 2.0D;
/*      */     } 
/*      */     
/*  577 */     Point2D point2D = null;
/*  578 */     double d10 = 0.0D;
/*  579 */     double d11 = 0.0D;
/*  580 */     if (this.containsMnemonic) {
/*  581 */       Font font = this.text.getFont();
/*  582 */       String str = this.bindings.getText();
/*  583 */       point2D = Utils.computeMnemonicPosition(font, str, this.bindings.getMnemonicIndex(), this.wrapWidth, labeled.getLineSpacing());
/*  584 */       d10 = Utils.computeTextWidth(font, str.substring(this.bindings.getMnemonicIndex(), this.bindings.getMnemonicIndex() + 1), 0.0D);
/*  585 */       d11 = Utils.computeTextHeight(font, "_", 0.0D, this.text.getBoundsType());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  594 */     if ((!bool1 || !bool2) && !this.text.isManaged()) {
/*  595 */       this.text.setManaged(true);
/*      */     }
/*      */     
/*  598 */     if (bool1 && bool2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  606 */       if (this.text.isManaged()) {
/*  607 */         this.text.setManaged(false);
/*      */       }
/*  609 */       this.text.relocate(snapPositionX(d8), snapPositionY(d9));
/*  610 */     } else if (bool1) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  615 */       this.text.relocate(snapPositionX(d8), snapPositionY(d9));
/*  616 */       if (this.containsMnemonic && point2D != null) {
/*  617 */         this.mnemonic_underscore.setEndX(d10 - 2.0D);
/*  618 */         this.mnemonic_underscore.relocate(snapPositionX(d8 + point2D.getX()), 
/*  619 */             snapPositionY(d9 + point2D.getY()));
/*      */       }
/*      */     
/*  622 */     } else if (bool2) {
/*      */ 
/*      */ 
/*      */       
/*  626 */       this.text.relocate(snapPositionX(d8), snapPositionY(d9));
/*  627 */       this.graphic.relocate(snapPositionX(d8), snapPositionY(d9));
/*  628 */       if (this.containsMnemonic && point2D != null) {
/*  629 */         this.mnemonic_underscore.setEndX(d10);
/*  630 */         this.mnemonic_underscore.setStrokeWidth(d11 / 10.0D);
/*  631 */         this.mnemonic_underscore.relocate(snapPositionX(d8 + point2D.getX()), 
/*  632 */             snapPositionY(d9 + point2D.getY()));
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  637 */       double d12 = 0.0D;
/*  638 */       double d13 = 0.0D;
/*  639 */       double d14 = 0.0D;
/*  640 */       double d15 = 0.0D;
/*      */       
/*  642 */       if (contentDisplay == ContentDisplay.TOP) {
/*  643 */         d12 = d8 + (d6 - d1) / 2.0D;
/*  644 */         d14 = d8 + (d6 - d3) / 2.0D;
/*      */ 
/*      */         
/*  647 */         d13 = d9;
/*  648 */         d15 = d13 + d2 + d5;
/*  649 */       } else if (contentDisplay == ContentDisplay.RIGHT) {
/*      */         
/*  651 */         d14 = d8;
/*  652 */         d12 = d14 + d3 + d5;
/*  653 */         d13 = d9 + (d7 - d2) / 2.0D;
/*  654 */         d15 = d9 + (d7 - d4) / 2.0D;
/*  655 */       } else if (contentDisplay == ContentDisplay.BOTTOM) {
/*  656 */         d12 = d8 + (d6 - d1) / 2.0D;
/*  657 */         d14 = d8 + (d6 - d3) / 2.0D;
/*      */         
/*  659 */         d15 = d9;
/*  660 */         d13 = d15 + d4 + d5;
/*  661 */       } else if (contentDisplay == ContentDisplay.LEFT) {
/*      */ 
/*      */         
/*  664 */         d12 = d8;
/*  665 */         d14 = d12 + d1 + d5;
/*  666 */         d13 = d9 + (d7 - d2) / 2.0D;
/*  667 */         d15 = d9 + (d7 - d4) / 2.0D;
/*  668 */       } else if (contentDisplay == ContentDisplay.CENTER) {
/*  669 */         d12 = d8 + (d6 - d1) / 2.0D;
/*  670 */         d14 = d8 + (d6 - d3) / 2.0D;
/*  671 */         d13 = d9 + (d7 - d2) / 2.0D;
/*  672 */         d15 = d9 + (d7 - d4) / 2.0D;
/*      */       } 
/*  674 */       this.text.relocate(snapPositionX(d14), snapPositionY(d15));
/*  675 */       if (this.containsMnemonic && point2D != null) {
/*  676 */         this.mnemonic_underscore.setEndX(d10);
/*  677 */         this.mnemonic_underscore.setStrokeWidth(d11 / 10.0D);
/*  678 */         this.mnemonic_underscore.relocate(snapPositionX(d14 + point2D.getX()), 
/*  679 */             snapPositionY(d15 + point2D.getY()));
/*      */       } 
/*  681 */       this.graphic.relocate(snapPositionX(d12), snapPositionY(d13));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  691 */     if (this.text != null && (this.text
/*  692 */       .getLayoutBounds().getHeight() > this.wrapHeight || this.text
/*  693 */       .getLayoutBounds().getWidth() > this.wrapWidth)) {
/*      */       
/*  695 */       if (this.textClip == null) {
/*  696 */         this.textClip = new Rectangle();
/*      */       }
/*      */       
/*  699 */       if (labeled.getEffectiveNodeOrientation() == NodeOrientation.LEFT_TO_RIGHT) {
/*  700 */         this.textClip.setX(this.text.getLayoutBounds().getMinX());
/*      */       } else {
/*  702 */         this.textClip.setX(this.text.getLayoutBounds().getMaxX() - this.wrapWidth);
/*      */       } 
/*  704 */       this.textClip.setY(this.text.getLayoutBounds().getMinY());
/*  705 */       this.textClip.setWidth(this.wrapWidth);
/*  706 */       this.textClip.setHeight(this.wrapHeight);
/*  707 */       if (this.text.getClip() == null) {
/*  708 */         this.text.setClip(this.textClip);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  716 */     else if (this.text.getClip() != null) {
/*  717 */       this.text.setClip(null);
/*      */     } 
/*      */   }
/*      */   protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*      */     Labeled labeled;
/*      */     String str1;
/*      */     String str2;
/*  724 */     switch (paramAccessibleAttribute) {
/*      */       case TEXT:
/*  726 */         labeled = (Labeled)getSkinnable();
/*  727 */         str1 = labeled.getAccessibleText();
/*  728 */         if (str1 != null && !str1.isEmpty()) return str1;
/*      */ 
/*      */         
/*  731 */         if (this.bindings != null) {
/*  732 */           String str = this.bindings.getText();
/*  733 */           if (str != null && !str.isEmpty()) return str;
/*      */         
/*      */         } 
/*      */ 
/*      */         
/*  738 */         str2 = labeled.getText();
/*  739 */         if (str2 != null && !str2.isEmpty()) return str2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  745 */         if (this.graphic != null) {
/*  746 */           Object object = this.graphic.queryAccessibleAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*  747 */           if (object != null) return object; 
/*      */         } 
/*  749 */         return null;
/*      */       
/*      */       case MNEMONIC:
/*  752 */         if (this.bindings != null) {
/*  753 */           return this.bindings.getMnemonic();
/*      */         }
/*  755 */         return null;
/*      */     } 
/*  757 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double computeMinLabeledPartWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*      */     double d3;
/*  773 */     Labeled labeled = (Labeled)getSkinnable();
/*  774 */     ContentDisplay contentDisplay = labeled.getContentDisplay();
/*  775 */     double d1 = labeled.getGraphicTextGap();
/*  776 */     double d2 = 0.0D;
/*      */     
/*  778 */     Font font = this.text.getFont();
/*  779 */     OverrunStyle overrunStyle = labeled.getTextOverrun();
/*  780 */     String str1 = labeled.getEllipsisString();
/*  781 */     String str2 = labeled.getText();
/*  782 */     boolean bool = (str2 == null || str2.isEmpty()) ? true : false;
/*      */     
/*  784 */     if (!bool)
/*      */     {
/*  786 */       if (overrunStyle == OverrunStyle.CLIP) {
/*  787 */         if (this.textWidth == Double.NEGATIVE_INFINITY)
/*      */         {
/*  789 */           this.textWidth = Utils.computeTextWidth(font, str2.substring(0, 1), 0.0D);
/*      */         }
/*  791 */         d2 = this.textWidth;
/*      */       } else {
/*  793 */         if (this.textWidth == Double.NEGATIVE_INFINITY) {
/*  794 */           this.textWidth = Utils.computeTextWidth(font, str2, 0.0D);
/*      */         }
/*      */         
/*  797 */         if (this.ellipsisWidth == Double.NEGATIVE_INFINITY) {
/*  798 */           this.ellipsisWidth = Utils.computeTextWidth(font, str1, 0.0D);
/*      */         }
/*  800 */         d2 = Math.min(this.textWidth, this.ellipsisWidth);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  805 */     Node node = labeled.getGraphic();
/*      */     
/*  807 */     if (isIgnoreGraphic()) {
/*  808 */       d3 = d2;
/*  809 */     } else if (isIgnoreText()) {
/*  810 */       d3 = node.minWidth(-1.0D);
/*  811 */     } else if (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT) {
/*  812 */       d3 = d2 + node.minWidth(-1.0D) + d1;
/*      */     } else {
/*  814 */       d3 = Math.max(d2, node.minWidth(-1.0D));
/*      */     } 
/*      */     
/*  817 */     double d4 = paramDouble5 + paramDouble3;
/*  818 */     if (!isIgnoreText()) {
/*  819 */       d4 += leftLabelPadding() + rightLabelPadding();
/*      */     }
/*      */     
/*  822 */     return d3 + d4;
/*      */   }
/*      */   
/*      */   private double computeMinLabeledPartHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  826 */     Labeled labeled = (Labeled)getSkinnable();
/*  827 */     Font font = this.text.getFont();
/*      */     
/*  829 */     String str = labeled.getText();
/*  830 */     if (str != null && str.length() > 0) {
/*  831 */       int i = str.indexOf('\n');
/*  832 */       if (i >= 0) {
/*  833 */         str = str.substring(0, i);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  839 */     double d1 = labeled.getLineSpacing();
/*  840 */     double d2 = Utils.computeTextHeight(font, str, 0.0D, d1, this.text.getBoundsType());
/*      */     
/*  842 */     double d3 = d2;
/*      */ 
/*      */     
/*  845 */     if (!isIgnoreGraphic()) {
/*  846 */       Node node = labeled.getGraphic();
/*  847 */       if (labeled.getContentDisplay() == ContentDisplay.TOP || labeled
/*  848 */         .getContentDisplay() == ContentDisplay.BOTTOM) {
/*  849 */         d3 = node.minHeight(paramDouble1) + labeled.getGraphicTextGap() + d2;
/*      */       } else {
/*  851 */         d3 = Math.max(d2, node.minHeight(paramDouble1));
/*      */       } 
/*      */     } 
/*      */     
/*  855 */     double d4 = paramDouble2 + paramDouble4;
/*  856 */     if (!isIgnoreText()) {
/*  857 */       d4 += topLabelPadding() - bottomLabelPadding();
/*      */     }
/*  859 */     return d3 + d4;
/*      */   }
/*      */   
/*      */   double topLabelPadding() {
/*  863 */     return snapSizeY(((Labeled)getSkinnable()).getLabelPadding().getTop());
/*      */   }
/*      */   
/*      */   double bottomLabelPadding() {
/*  867 */     return snapSizeY(((Labeled)getSkinnable()).getLabelPadding().getBottom());
/*      */   }
/*      */   
/*      */   double leftLabelPadding() {
/*  871 */     return snapSizeX(((Labeled)getSkinnable()).getLabelPadding().getLeft());
/*      */   }
/*      */   
/*      */   double rightLabelPadding() {
/*  875 */     return snapSizeX(((Labeled)getSkinnable()).getLabelPadding().getRight());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void textMetricsChanged() {
/*  885 */     this.invalidText = true;
/*  886 */     ((Labeled)getSkinnable()).requestLayout();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void mnemonicTargetChanged() {
/*  895 */     if (this.containsMnemonic == true) {
/*      */ 
/*      */ 
/*      */       
/*  899 */       removeMnemonic();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  904 */       C c = getSkinnable();
/*  905 */       if (c instanceof Label) {
/*  906 */         this.labeledNode = ((Label)c).getLabelFor();
/*  907 */         addMnemonic();
/*      */       } else {
/*      */         
/*  910 */         this.labeledNode = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void sceneChanged() {
/*  916 */     Labeled labeled = (Labeled)getSkinnable();
/*  917 */     Scene scene = labeled.getScene();
/*      */     
/*  919 */     if (scene != null && this.containsMnemonic) {
/*  920 */       addMnemonic();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invalidateWidths() {
/*  929 */     this.textWidth = Double.NEGATIVE_INFINITY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateDisplayedText() {
/*  940 */     updateDisplayedText(-1.0D, -1.0D);
/*      */   }
/*      */   
/*      */   private void updateDisplayedText(double paramDouble1, double paramDouble2) {
/*  944 */     if (this.invalidText) {
/*  945 */       String str2; Labeled labeled = (Labeled)getSkinnable();
/*  946 */       String str1 = labeled.getText();
/*      */       
/*  948 */       int i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  953 */       if (str1 != null && str1.length() > 0) {
/*  954 */         this.bindings = new TextBinding(str1);
/*      */         
/*  956 */         if (!PlatformUtil.isMac() && ((Labeled)getSkinnable()).isMnemonicParsing() == true) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  962 */           if (labeled instanceof Label) {
/*      */             
/*  964 */             this.labeledNode = ((Label)labeled).getLabelFor();
/*      */           } else {
/*  966 */             this.labeledNode = labeled;
/*      */           } 
/*      */           
/*  969 */           if (this.labeledNode == null) {
/*  970 */             this.labeledNode = labeled;
/*      */           }
/*  972 */           i = this.bindings.getMnemonicIndex();
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  979 */       if (this.containsMnemonic) {
/*      */ 
/*      */ 
/*      */         
/*  983 */         if (this.mnemonicScene != null && (
/*  984 */           i == -1 || (this.bindings != null && 
/*  985 */           !this.bindings.getMnemonicKeyCombination().equals(this.mnemonicCode)))) {
/*  986 */           removeMnemonic();
/*  987 */           this.containsMnemonic = false;
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  996 */         removeMnemonic();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1002 */       if (str1 != null && str1.length() > 0 && 
/* 1003 */         i >= 0 && !this.containsMnemonic) {
/* 1004 */         this.containsMnemonic = true;
/* 1005 */         this.mnemonicCode = this.bindings.getMnemonicKeyCombination();
/* 1006 */         addMnemonic();
/*      */       } 
/*      */ 
/*      */       
/* 1010 */       if (this.containsMnemonic == true) {
/* 1011 */         str1 = this.bindings.getText();
/* 1012 */         if (this.mnemonic_underscore == null) {
/* 1013 */           this.mnemonic_underscore = new Line();
/* 1014 */           this.mnemonic_underscore.setStartX(0.0D);
/* 1015 */           this.mnemonic_underscore.setStartY(0.0D);
/* 1016 */           this.mnemonic_underscore.setEndY(0.0D);
/* 1017 */           this.mnemonic_underscore.getStyleClass().clear();
/* 1018 */           this.mnemonic_underscore.getStyleClass().setAll(new String[] { "mnemonic-underline" });
/*      */         } 
/* 1020 */         if (!getChildren().contains(this.mnemonic_underscore)) {
/* 1021 */           getChildren().add(this.mnemonic_underscore);
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1027 */         if (((Labeled)getSkinnable()).isMnemonicParsing() == true && PlatformUtil.isMac() && this.bindings != null) {
/* 1028 */           str1 = this.bindings.getText();
/*      */         } else {
/*      */           
/* 1031 */           str1 = labeled.getText();
/*      */         } 
/* 1033 */         if (this.mnemonic_underscore != null && 
/* 1034 */           getChildren().contains(this.mnemonic_underscore)) {
/* 1035 */           Platform.runLater(() -> {
/*      */                 getChildren().remove(this.mnemonic_underscore);
/*      */                 
/*      */                 this.mnemonic_underscore = null;
/*      */               });
/*      */         }
/*      */       } 
/*      */       
/* 1043 */       byte b = (str1 != null) ? str1.length() : 0;
/* 1044 */       boolean bool1 = false;
/*      */       
/* 1046 */       if (str1 != null && b) {
/* 1047 */         int j = str1.indexOf('\n');
/* 1048 */         if (j > -1 && j < b - 1)
/*      */         {
/*      */           
/* 1051 */           bool1 = true;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1058 */       boolean bool2 = (labeled.getContentDisplay() == ContentDisplay.LEFT || labeled.getContentDisplay() == ContentDisplay.RIGHT) ? true : false;
/*      */ 
/*      */       
/* 1061 */       double d1 = labeled.getWidth() - snappedLeftInset() - snappedRightInset();
/*      */       
/* 1063 */       if (!isIgnoreText()) {
/* 1064 */         d1 -= leftLabelPadding() + rightLabelPadding();
/*      */       }
/* 1066 */       d1 = Math.max(d1, 0.0D);
/*      */       
/* 1068 */       if (paramDouble1 == -1.0D) {
/* 1069 */         paramDouble1 = d1;
/*      */       }
/* 1071 */       double d2 = Math.min(computeMinLabeledPartWidth(-1.0D, snappedTopInset(), snappedRightInset(), snappedBottomInset(), snappedLeftInset()), d1);
/* 1072 */       if (bool2 && !isIgnoreGraphic()) {
/* 1073 */         double d = labeled.getGraphic().getLayoutBounds().getWidth() + labeled.getGraphicTextGap();
/* 1074 */         paramDouble1 -= d;
/* 1075 */         d2 -= d;
/*      */       } 
/* 1077 */       this.wrapWidth = Math.max(d2, paramDouble1);
/*      */ 
/*      */ 
/*      */       
/* 1081 */       boolean bool3 = (labeled.getContentDisplay() == ContentDisplay.TOP || labeled.getContentDisplay() == ContentDisplay.BOTTOM) ? true : false;
/*      */ 
/*      */       
/* 1084 */       double d3 = labeled.getHeight() - snappedTopInset() - snappedBottomInset();
/*      */       
/* 1086 */       if (!isIgnoreText()) {
/* 1087 */         d3 -= topLabelPadding() + bottomLabelPadding();
/*      */       }
/* 1089 */       d3 = Math.max(d3, 0.0D);
/*      */       
/* 1091 */       if (paramDouble2 == -1.0D) {
/* 1092 */         paramDouble2 = d3;
/*      */       }
/* 1094 */       double d4 = Math.min(computeMinLabeledPartHeight(this.wrapWidth, snappedTopInset(), snappedRightInset(), snappedBottomInset(), snappedLeftInset()), d3);
/* 1095 */       if (bool3 && labeled.getGraphic() != null) {
/* 1096 */         double d = labeled.getGraphic().getLayoutBounds().getHeight() + labeled.getGraphicTextGap();
/* 1097 */         paramDouble2 -= d;
/* 1098 */         d4 -= d;
/*      */       } 
/* 1100 */       this.wrapHeight = Math.max(d4, paramDouble2);
/*      */       
/* 1102 */       updateWrappingWidth();
/*      */       
/* 1104 */       Font font = this.text.getFont();
/* 1105 */       OverrunStyle overrunStyle = labeled.getTextOverrun();
/* 1106 */       String str3 = labeled.getEllipsisString();
/*      */       
/* 1108 */       if (labeled.isWrapText()) {
/* 1109 */         str2 = Utils.computeClippedWrappedText(font, str1, this.wrapWidth, this.wrapHeight, overrunStyle, str3, this.text.getBoundsType());
/* 1110 */       } else if (bool1) {
/* 1111 */         StringBuilder stringBuilder = new StringBuilder();
/*      */         
/* 1113 */         String[] arrayOfString = str1.split("\n");
/* 1114 */         for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/* 1115 */           stringBuilder.append(Utils.computeClippedText(font, arrayOfString[b1], this.wrapWidth, overrunStyle, str3));
/* 1116 */           if (b1 < arrayOfString.length - 1) {
/* 1117 */             stringBuilder.append('\n');
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1139 */         str2 = stringBuilder.toString();
/*      */       } else {
/* 1141 */         str2 = Utils.computeClippedText(font, str1, this.wrapWidth, overrunStyle, str3);
/*      */       } 
/*      */       
/* 1144 */       if (str2 != null && str2.endsWith("\n"))
/*      */       {
/* 1146 */         str2 = str2.substring(0, str2.length() - 1);
/*      */       }
/*      */       
/* 1149 */       this.text.setText(str2);
/* 1150 */       updateWrappingWidth();
/* 1151 */       this.invalidText = false;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addMnemonic() {
/* 1156 */     if (this.labeledNode != null) {
/* 1157 */       this.mnemonicScene = this.labeledNode.getScene();
/* 1158 */       if (this.mnemonicScene != null) {
/* 1159 */         this.mnemonicScene.addMnemonic(new Mnemonic(this.labeledNode, this.mnemonicCode));
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void removeMnemonic() {
/* 1166 */     if (this.mnemonicScene != null && this.labeledNode != null) {
/* 1167 */       this.mnemonicScene.removeMnemonic(new Mnemonic(this.labeledNode, this.mnemonicCode));
/* 1168 */       this.mnemonicScene = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateWrappingWidth() {
/* 1179 */     Labeled labeled = (Labeled)getSkinnable();
/* 1180 */     this.text.setWrappingWidth(0.0D);
/* 1181 */     if (labeled.isWrapText()) {
/*      */ 
/*      */       
/* 1184 */       double d = Math.min(this.text.prefWidth(-1.0D), this.wrapWidth);
/* 1185 */       this.text.setWrappingWidth(d);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isIgnoreGraphic() {
/* 1195 */     return (this.graphic == null || 
/* 1196 */       !this.graphic.isManaged() || ((Labeled)
/* 1197 */       getSkinnable()).getContentDisplay() == ContentDisplay.TEXT_ONLY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isIgnoreText() {
/* 1205 */     Labeled labeled = (Labeled)getSkinnable();
/* 1206 */     String str = labeled.getText();
/* 1207 */     return (str == null || str
/* 1208 */       .equals("") || labeled
/* 1209 */       .getContentDisplay() == ContentDisplay.GRAPHIC_ONLY);
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\LabeledSkinBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */