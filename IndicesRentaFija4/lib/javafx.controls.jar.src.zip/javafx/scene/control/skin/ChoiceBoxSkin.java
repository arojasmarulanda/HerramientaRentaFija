/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.ContextMenuContent;
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.ChoiceBoxBehavior;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ChoiceBox;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.RadioMenuItem;
/*     */ import javafx.scene.control.SelectionModel;
/*     */ import javafx.scene.control.SeparatorMenuItem;
/*     */ import javafx.scene.control.SingleSelectionModel;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.control.ToggleGroup;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.text.Text;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChoiceBoxSkin<T>
/*     */   extends SkinBase<ChoiceBox<T>>
/*     */ {
/*     */   private ObservableList<T> choiceBoxItems;
/*     */   private ContextMenu popup;
/*     */   private StackPane openButton;
/*  80 */   private final ToggleGroup toggleGroup = new ToggleGroup();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SelectionModel<T> selectionModel;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Label label;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final BehaviorBase<ChoiceBox<T>> behavior;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private final ListChangeListener<T> choiceBoxItemsListener = new ListChangeListener<T>() {
/*     */       public void onChanged(ListChangeListener.Change<? extends T> param1Change) {
/* 102 */         while (param1Change.next()) {
/* 103 */           if (param1Change.getRemovedSize() > 0 || param1Change.wasPermutated()) {
/* 104 */             ChoiceBoxSkin.this.toggleGroup.getToggles().clear();
/* 105 */             ChoiceBoxSkin.this.popup.getItems().clear();
/* 106 */             byte b = 0;
/* 107 */             for (T t : param1Change.getList()) {
/* 108 */               ChoiceBoxSkin.this.addPopupItem(t, b);
/* 109 */               b++;
/*     */             }  continue;
/*     */           } 
/* 112 */           for (int i = param1Change.getFrom(); i < param1Change.getTo(); i++) {
/* 113 */             Object object = param1Change.getList().get(i);
/* 114 */             ChoiceBoxSkin.this.addPopupItem((T)object, i);
/*     */           } 
/*     */         } 
/*     */         
/* 118 */         ChoiceBoxSkin.this.updateSelection();
/* 119 */         ChoiceBoxSkin.this.getSkinnable().requestLayout();
/*     */       }
/*     */     };
/*     */   
/* 123 */   private final WeakListChangeListener<T> weakChoiceBoxItemsListener = new WeakListChangeListener<>(this.choiceBoxItemsListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final InvalidationListener itemsObserver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InvalidationListener selectionChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChoiceBoxSkin(ChoiceBox<T> paramChoiceBox) {
/* 144 */     super(paramChoiceBox);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 413 */     this.selectionChangeListener = (paramObservable -> updateSelection()); this.behavior = new ChoiceBoxBehavior<>(paramChoiceBox); initialize(); this.itemsObserver = (paramObservable -> updateChoiceBoxItems()); paramChoiceBox.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver)); paramChoiceBox.requestLayout(); registerChangeListener(paramChoiceBox.selectionModelProperty(), paramObservableValue -> updateSelectionModel()); registerChangeListener(paramChoiceBox.showingProperty(), paramObservableValue -> { if (getSkinnable().isShowing()) { MenuItem menuItem = null; SingleSelectionModel<T> singleSelectionModel = getSkinnable().getSelectionModel(); if (singleSelectionModel == null)
/*     */               return;  long l = singleSelectionModel.getSelectedIndex(); int i = this.choiceBoxItems.size(); boolean bool = (l >= 0L && l < i) ? true : false; if (bool) { menuItem = this.popup.getItems().get((int)l); if (menuItem != null && menuItem instanceof RadioMenuItem)
/*     */                 ((RadioMenuItem)menuItem).setSelected(true);  } else if (i > 0) { menuItem = this.popup.getItems().get(0); }  getSkinnable().autosize(); double d = 0.0D; if (this.popup.getSkin() != null) { ContextMenuContent contextMenuContent = (ContextMenuContent)this.popup.getSkin().getNode(); if (contextMenuContent != null && l != -1L)
/*     */                 d = -contextMenuContent.getMenuYOffset((int)l);  }  this.popup.show(getSkinnable(), Side.BOTTOM, 2.0D, d); } else { this.popup.hide(); }  }); registerChangeListener(paramChoiceBox.itemsProperty(), paramObservableValue -> { updateChoiceBoxItems(); updatePopupItems(); updateSelectionModel(); updateSelection(); if (this.selectionModel != null && this.selectionModel.getSelectedIndex() == -1)
/*     */             this.label.setText("");  }); registerChangeListener(paramChoiceBox.getSelectionModel().selectedItemProperty(), paramObservableValue -> { if (getSkinnable().getSelectionModel() != null) { int i = getSkinnable().getSelectionModel().getSelectedIndex(); if (i != -1) { MenuItem menuItem = this.popup.getItems().get(i); if (menuItem instanceof RadioMenuItem)
/* 418 */                 ((RadioMenuItem)menuItem).setSelected(true);  }  }  }); registerChangeListener(paramChoiceBox.converterProperty(), paramObservableValue -> { updateChoiceBoxItems(); updatePopupItems(); }); } private void updateSelection() { if (this.selectionModel == null || this.selectionModel.isEmpty()) {
/* 419 */       this.toggleGroup.selectToggle(null);
/* 420 */       this.label.setText("");
/*     */     } else {
/* 422 */       int i = this.selectionModel.getSelectedIndex();
/* 423 */       if (i == -1 || i > this.popup.getItems().size()) {
/* 424 */         this.label.setText("");
/*     */         return;
/*     */       } 
/* 427 */       if (i < this.popup.getItems().size()) {
/* 428 */         MenuItem menuItem = this.popup.getItems().get(i);
/* 429 */         if (menuItem instanceof RadioMenuItem) {
/* 430 */           ((RadioMenuItem)menuItem).setSelected(true);
/* 431 */           this.toggleGroup.selectToggle(null);
/*     */         } 
/*     */         
/* 434 */         this.label.setText(((MenuItem)this.popup.getItems().get(i)).getText());
/*     */       } 
/*     */     }  }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*     */     super.dispose();
/*     */     if (this.behavior != null)
/*     */       this.behavior.dispose(); 
/*     */   }
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*     */     double d = this.openButton.prefWidth(-1.0D);
/*     */     this.label.resizeRelocate(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */     this.openButton.resize(d, this.openButton.prefHeight(-1.0D));
/*     */     positionInArea(this.openButton, paramDouble1 + paramDouble3 - d, paramDouble2, d, paramDouble4, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */   }
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*     */     double d1 = this.label.minWidth(-1.0D) + this.openButton.minWidth(-1.0D);
/*     */     double d2 = this.popup.minWidth(-1.0D);
/*     */     return paramDouble5 + Math.max(d1, d2) + paramDouble3;
/*     */   }
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*     */     double d1 = this.label.minHeight(-1.0D);
/*     */     double d2 = this.openButton.minHeight(-1.0D);
/*     */     return paramDouble2 + Math.max(d1, d2) + paramDouble4;
/*     */   }
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*     */     double d1 = this.label.prefWidth(-1.0D) + this.openButton.prefWidth(-1.0D);
/*     */     double d2 = this.popup.prefWidth(-1.0D);
/*     */     if (d2 <= 0.0D && this.popup.getItems().size() > 0)
/*     */       d2 = (new Text(((MenuItem)this.popup.getItems().get(0)).getText())).prefWidth(-1.0D); 
/*     */     return (this.popup.getItems().size() == 0) ? 50.0D : (paramDouble5 + Math.max(d1, d2) + paramDouble3);
/*     */   }
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*     */     double d1 = this.label.prefHeight(-1.0D);
/*     */     double d2 = this.openButton.prefHeight(-1.0D);
/*     */     return paramDouble2 + Math.max(d1, d2) + paramDouble4;
/*     */   }
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*     */     return getSkinnable().prefHeight(paramDouble1);
/*     */   }
/*     */   
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*     */     return getSkinnable().prefWidth(paramDouble1);
/*     */   }
/*     */   
/*     */   private void initialize() {
/*     */     updateChoiceBoxItems();
/*     */     this.label = new Label();
/*     */     this.label.setMnemonicParsing(false);
/*     */     this.openButton = new StackPane();
/*     */     this.openButton.getStyleClass().setAll(new String[] { "open-button" });
/*     */     StackPane stackPane = new StackPane();
/*     */     stackPane.getStyleClass().setAll(new String[] { "arrow" });
/*     */     this.openButton.getChildren().clear();
/*     */     this.openButton.getChildren().addAll(new Node[] { stackPane });
/*     */     this.popup = new ContextMenu();
/*     */     this.popup.showingProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*     */           if (!paramBoolean2.booleanValue())
/*     */             getSkinnable().hide(); 
/*     */         });
/*     */     this.popup.setId("choice-box-popup-menu");
/*     */     getChildren().setAll(new Node[] { this.label, this.openButton });
/*     */     updatePopupItems();
/*     */     updateSelectionModel();
/*     */     updateSelection();
/*     */     if (this.selectionModel != null && this.selectionModel.getSelectedIndex() == -1)
/*     */       this.label.setText(""); 
/*     */   }
/*     */   
/*     */   private void updateChoiceBoxItems() {
/*     */     if (this.choiceBoxItems != null)
/*     */       this.choiceBoxItems.removeListener(this.weakChoiceBoxItemsListener); 
/*     */     this.choiceBoxItems = getSkinnable().getItems();
/*     */     if (this.choiceBoxItems != null)
/*     */       this.choiceBoxItems.addListener(this.weakChoiceBoxItemsListener); 
/*     */   }
/*     */   
/*     */   String getChoiceBoxSelectedText() {
/*     */     return this.label.getText();
/*     */   }
/*     */   
/*     */   private void addPopupItem(T paramT, int paramInt) {
/*     */     RadioMenuItem radioMenuItem;
/*     */     SeparatorMenuItem separatorMenuItem = null;
/*     */     if (paramT instanceof javafx.scene.control.Separator) {
/*     */       separatorMenuItem = new SeparatorMenuItem();
/*     */     } else if (paramT instanceof SeparatorMenuItem) {
/*     */       separatorMenuItem = (SeparatorMenuItem)paramT;
/*     */     } else {
/*     */       StringConverter<T> stringConverter = getSkinnable().getConverter();
/*     */       String str = (stringConverter == null) ? ((paramT == null) ? "" : paramT.toString()) : stringConverter.toString(paramT);
/*     */       RadioMenuItem radioMenuItem1 = new RadioMenuItem(str);
/*     */       radioMenuItem1.setId("choice-box-menu-item");
/*     */       radioMenuItem1.setToggleGroup(this.toggleGroup);
/*     */       radioMenuItem1.setOnAction(paramActionEvent -> {
/*     */             if (this.selectionModel == null)
/*     */               return; 
/*     */             int i = getSkinnable().getItems().indexOf(paramObject);
/*     */             this.selectionModel.select(i);
/*     */             paramRadioMenuItem.setSelected(true);
/*     */           });
/*     */       radioMenuItem = radioMenuItem1;
/*     */     } 
/*     */     radioMenuItem.setMnemonicParsing(false);
/*     */     this.popup.getItems().add(paramInt, radioMenuItem);
/*     */   }
/*     */   
/*     */   private void updatePopupItems() {
/*     */     this.toggleGroup.getToggles().clear();
/*     */     this.popup.getItems().clear();
/*     */     this.toggleGroup.selectToggle(null);
/*     */     for (byte b = 0; b < this.choiceBoxItems.size(); b++) {
/*     */       T t = this.choiceBoxItems.get(b);
/*     */       addPopupItem(t, b);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateSelectionModel() {
/*     */     if (this.selectionModel != null)
/*     */       this.selectionModel.selectedIndexProperty().removeListener(this.selectionChangeListener); 
/*     */     this.selectionModel = getSkinnable().getSelectionModel();
/*     */     if (this.selectionModel != null)
/*     */       this.selectionModel.selectedIndexProperty().addListener(this.selectionChangeListener); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ChoiceBoxSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */