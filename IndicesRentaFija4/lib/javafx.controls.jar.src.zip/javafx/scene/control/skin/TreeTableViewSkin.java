/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.TreeTableViewBackingList;
/*     */ import com.sun.javafx.scene.control.behavior.TreeTableViewBehavior;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.event.WeakEventHandler;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeTableCell;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ import javafx.scene.control.TreeTablePosition;
/*     */ import javafx.scene.control.TreeTableRow;
/*     */ import javafx.scene.control.TreeTableView;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.StackPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeTableViewSkin<T>
/*     */   extends TableViewSkinBase<T, TreeItem<T>, TreeTableView<T>, TreeTableRow<T>, TreeTableColumn<T, ?>>
/*     */ {
/*     */   TreeTableViewBackingList<T> tableBackingList;
/*     */   ObjectProperty<ObservableList<TreeItem<T>>> tableBackingListProperty;
/*     */   private WeakReference<TreeItem<T>> weakRootRef;
/*     */   private final TreeTableViewBehavior<T> behavior;
/*     */   private EventHandler<TreeItem.TreeModificationEvent<T>> rootListener;
/*     */   private WeakEventHandler<TreeItem.TreeModificationEvent<T>> weakRootListener;
/*     */   
/*     */   public TreeTableViewSkin(TreeTableView<T> paramTreeTableView) {
/* 135 */     super(paramTreeTableView); this.rootListener = (paramTreeModificationEvent -> { if (paramTreeModificationEvent.wasAdded() && paramTreeModificationEvent.wasRemoved() && paramTreeModificationEvent.getAddedSize() == paramTreeModificationEvent.getRemovedSize()) { markItemCountDirty(); getSkinnable().requestLayout(); } else if (paramTreeModificationEvent.getEventType().equals(TreeItem.valueChangedEvent())) { requestRebuildCells(); } else { for (EventType<? extends Event> eventType = paramTreeModificationEvent.getEventType(); eventType != null; eventType = (EventType)eventType.getSuperType()) { if (eventType.equals(TreeItem.expandedItemCountChangeEvent())) { markItemCountDirty(); getSkinnable().requestLayout(); break; }  }
/*     */            }
/*     */          getSkinnable().edit(-1, (TreeTableColumn<T, ?>)null);
/* 138 */       }); this.behavior = new TreeTableViewBehavior<>(paramTreeTableView);
/*     */ 
/*     */     
/* 141 */     this.flow.setFixedCellSize(paramTreeTableView.getFixedCellSize());
/* 142 */     this.flow.setCellFactory(paramVirtualFlow -> createCell());
/*     */     
/* 144 */     setRoot(getSkinnable().getRoot());
/*     */     
/* 146 */     EventHandler eventHandler = paramMouseEvent -> {
/*     */         if (paramTreeTableView.getEditingCell() != null) {
/*     */           paramTreeTableView.edit(-1, (TreeTableColumn)null);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         if (paramTreeTableView.isFocusTraversable()) {
/*     */           paramTreeTableView.requestFocus();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     this.flow.getVbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
/* 164 */     this.flow.getHbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
/*     */ 
/*     */     
/* 167 */     this.behavior.setOnFocusPreviousRow(() -> onFocusPreviousCell());
/* 168 */     this.behavior.setOnFocusNextRow(() -> onFocusNextCell());
/* 169 */     this.behavior.setOnMoveToFirstCell(() -> onMoveToFirstCell());
/* 170 */     this.behavior.setOnMoveToLastCell(() -> onMoveToLastCell());
/* 171 */     this.behavior.setOnScrollPageDown(paramBoolean -> Integer.valueOf(onScrollPageDown(paramBoolean.booleanValue())));
/* 172 */     this.behavior.setOnScrollPageUp(paramBoolean -> Integer.valueOf(onScrollPageUp(paramBoolean.booleanValue())));
/* 173 */     this.behavior.setOnSelectPreviousRow(() -> onSelectPreviousCell());
/* 174 */     this.behavior.setOnSelectNextRow(() -> onSelectNextCell());
/* 175 */     this.behavior.setOnSelectLeftCell(() -> onSelectLeftCell());
/* 176 */     this.behavior.setOnSelectRightCell(() -> onSelectRightCell());
/*     */     
/* 178 */     registerChangeListener(paramTreeTableView.rootProperty(), paramObservableValue -> {
/*     */           getSkinnable().edit(-1, (TreeTableColumn<T, ?>)null);
/*     */           
/*     */           setRoot(getSkinnable().getRoot());
/*     */         });
/*     */     
/* 184 */     registerChangeListener(paramTreeTableView.showRootProperty(), paramObservableValue -> {
/*     */           if (!getSkinnable().isShowRoot() && getRoot() != null) {
/*     */             getRoot().setExpanded(true);
/*     */           }
/*     */ 
/*     */           
/*     */           updateItemCount();
/*     */         });
/*     */ 
/*     */     
/* 194 */     registerChangeListener(paramTreeTableView.rowFactoryProperty(), paramObservableValue -> this.flow.recreateCells());
/* 195 */     registerChangeListener(paramTreeTableView.expandedItemCountProperty(), paramObservableValue -> markItemCountDirty());
/* 196 */     registerChangeListener(paramTreeTableView.fixedCellSizeProperty(), paramObservableValue -> this.flow.setFixedCellSize(getSkinnable().getFixedCellSize()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 209 */     super.dispose();
/*     */     
/* 211 */     if (this.behavior != null)
/* 212 */       this.behavior.dispose(); 
/*     */   }
/*     */   protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*     */     int i;
/*     */     ArrayList<TreeTableRow> arrayList;
/*     */     TreeTableView.TreeTableViewSelectionModel<T> treeTableViewSelectionModel;
/* 218 */     switch (paramAccessibleAttribute) {
/*     */       case SHOW_ITEM:
/* 220 */         i = ((Integer)paramVarArgs[0]).intValue();
/* 221 */         return (i < 0) ? null : this.flow.getPrivateCell(i);
/*     */       
/*     */       case SET_SELECTED_ITEMS:
/* 224 */         arrayList = new ArrayList();
/* 225 */         treeTableViewSelectionModel = getSkinnable().getSelectionModel();
/* 226 */         for (TreeTablePosition<T, ?> treeTablePosition : treeTableViewSelectionModel.getSelectedCells()) {
/* 227 */           TreeTableRow treeTableRow = this.flow.getPrivateCell(treeTablePosition.getRow());
/* 228 */           if (treeTableRow != null) arrayList.add(treeTableRow); 
/*     */         } 
/* 230 */         return FXCollections.observableArrayList(arrayList);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 238 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */   
/*     */   protected void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     Node node;
/*     */     ObservableList observableList;
/* 244 */     switch (paramAccessibleAction) {
/*     */       case SHOW_ITEM:
/* 246 */         node = (Node)paramVarArgs[0];
/* 247 */         if (node instanceof TreeTableCell) {
/*     */           
/* 249 */           TreeTableCell treeTableCell = (TreeTableCell)node;
/* 250 */           this.flow.scrollTo(treeTableCell.getIndex());
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case SET_SELECTED_ITEMS:
/* 256 */         observableList = (ObservableList)paramVarArgs[0];
/* 257 */         if (observableList != null) {
/* 258 */           TreeTableView.TreeTableViewSelectionModel<T> treeTableViewSelectionModel = getSkinnable().getSelectionModel();
/* 259 */           if (treeTableViewSelectionModel != null) {
/* 260 */             treeTableViewSelectionModel.clearSelection();
/* 261 */             for (Node node1 : observableList) {
/* 262 */               if (node1 instanceof TreeTableCell) {
/*     */                 
/* 264 */                 TreeTableCell<T, ?> treeTableCell = (TreeTableCell)node1;
/* 265 */                 treeTableViewSelectionModel.select(treeTableCell.getIndex(), treeTableCell.getTableColumn());
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         return;
/*     */     } 
/* 272 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TreeTableRow<T> createCell() {
/*     */     TreeTableRow<T> treeTableRow;
/* 288 */     TreeTableView<T> treeTableView = getSkinnable();
/* 289 */     if (treeTableView.getRowFactory() != null) {
/* 290 */       treeTableRow = treeTableView.getRowFactory().call(treeTableView);
/*     */     } else {
/* 292 */       treeTableRow = new TreeTableRow();
/*     */     } 
/*     */ 
/*     */     
/* 296 */     if (treeTableRow.getDisclosureNode() == null) {
/* 297 */       StackPane stackPane1 = new StackPane();
/* 298 */       stackPane1.getStyleClass().setAll(new String[] { "tree-disclosure-node" });
/* 299 */       stackPane1.setMouseTransparent(true);
/*     */       
/* 301 */       StackPane stackPane2 = new StackPane();
/* 302 */       stackPane2.getStyleClass().setAll(new String[] { "arrow" });
/* 303 */       stackPane1.getChildren().add(stackPane2);
/*     */       
/* 305 */       treeTableRow.setDisclosureNode(stackPane1);
/*     */     } 
/*     */     
/* 308 */     treeTableRow.updateTreeTableView(treeTableView);
/* 309 */     return treeTableRow;
/*     */   }
/*     */   
/*     */   private TreeItem<T> getRoot() {
/* 313 */     return (this.weakRootRef == null) ? null : this.weakRootRef.get();
/*     */   }
/*     */   private void setRoot(TreeItem<T> paramTreeItem) {
/* 316 */     if (getRoot() != null && this.weakRootListener != null) {
/* 317 */       getRoot().removeEventHandler(TreeItem.treeNotificationEvent(), this.weakRootListener);
/*     */     }
/* 319 */     this.weakRootRef = new WeakReference<>(paramTreeItem);
/* 320 */     if (getRoot() != null) {
/* 321 */       this.weakRootListener = new WeakEventHandler<>(this.rootListener);
/* 322 */       getRoot().addEventHandler(TreeItem.treeNotificationEvent(), this.weakRootListener);
/*     */     } 
/*     */     
/* 325 */     updateItemCount();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getItemCount() {
/* 330 */     return getSkinnable().getExpandedItemCount();
/*     */   }
/*     */ 
/*     */   
/*     */   void horizontalScroll() {
/* 335 */     super.horizontalScroll();
/* 336 */     if (getSkinnable().getFixedCellSize() > 0.0D) {
/* 337 */       this.flow.requestCellLayout();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateItemCount() {
/* 343 */     updatePlaceholderRegionVisibility();
/*     */     
/* 345 */     this.tableBackingList.resetSize();
/*     */     
/* 347 */     int i = this.flow.getCellCount();
/* 348 */     int j = getItemCount();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 353 */     this.flow.setCellCount(j);
/*     */     
/* 355 */     if (j == i)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 362 */       this.needCellsReconfigured = true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TreeTableViewSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */