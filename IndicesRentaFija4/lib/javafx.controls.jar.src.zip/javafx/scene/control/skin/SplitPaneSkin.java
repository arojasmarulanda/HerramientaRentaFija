/*      */ package javafx.scene.control.skin;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import javafx.beans.value.ChangeListener;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.geometry.HPos;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.geometry.VPos;
/*      */ import javafx.scene.Cursor;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.SkinBase;
/*      */ import javafx.scene.control.SplitPane;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.layout.StackPane;
/*      */ import javafx.scene.shape.Rectangle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SplitPaneSkin
/*      */   extends SkinBase<SplitPane>
/*      */ {
/*      */   private ObservableList<Content> contentRegions;
/*      */   private ObservableList<ContentDivider> contentDividers;
/*      */   private boolean horizontal;
/*      */   private double previousSize;
/*      */   private int lastDividerUpdate;
/*      */   private boolean resize;
/*      */   
/*      */   public SplitPaneSkin(SplitPane paramSplitPane) {
/*   85 */     super(paramSplitPane);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  925 */     this.previousSize = -1.0D;
/*  926 */     this.lastDividerUpdate = 0;
/*  927 */     this.resize = false;
/*  928 */     this.checkDividerPos = true; this.horizontal = (getSkinnable().getOrientation() == Orientation.HORIZONTAL); this.contentRegions = FXCollections.observableArrayList(); this.contentDividers = FXCollections.observableArrayList(); byte b = 0; for (Node node : getSkinnable().getItems()) addContent(b++, node);  initializeContentListener(); for (SplitPane.Divider divider : getSkinnable().getDividers()) addDivider(divider);  registerChangeListener(paramSplitPane.orientationProperty(), paramObservableValue -> { this.horizontal = (getSkinnable().getOrientation() == Orientation.HORIZONTAL); this.previousSize = -1.0D; for (ContentDivider contentDivider : this.contentDividers) contentDivider.setGrabberStyle(this.horizontal);  getSkinnable().requestLayout(); }); registerChangeListener(paramSplitPane.widthProperty(), paramObservableValue -> getSkinnable().requestLayout()); registerChangeListener(paramSplitPane.heightProperty(), paramObservableValue -> getSkinnable().requestLayout());
/*      */   }
/*      */   private boolean checkDividerPos;
/*  931 */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { SplitPane splitPane = getSkinnable(); double d1 = splitPane.getWidth(); double d2 = splitPane.getHeight(); if (this.horizontal ? (d1 == 0.0D) : (d2 == 0.0D)) if (!this.contentRegions.isEmpty()) { double d3 = this.contentDividers.isEmpty() ? 0.0D : ((ContentDivider)this.contentDividers.get(0)).prefWidth(-1.0D); if (this.contentDividers.size() > 0 && this.previousSize != -1.0D && this.previousSize != (this.horizontal ? d1 : d2)) { ArrayList<Content> arrayList = new ArrayList(); for (Content content : this.contentRegions) { if (content.isResizableWithParent()) arrayList.add(content);  }  double d = (this.horizontal ? splitPane.getWidth() : splitPane.getHeight()) - this.previousSize; boolean bool = (d > 0.0D) ? true : false; d = Math.abs(d); if (d != 0.0D && !arrayList.isEmpty()) { int i = (int)d / arrayList.size(); int j = (int)d % arrayList.size(); int k = 0; if (i == 0) { i = j; k = j; j = 0; } else { k = i * arrayList.size(); }  while (k > 0 && !arrayList.isEmpty()) { if (bool) { this.lastDividerUpdate++; } else { this.lastDividerUpdate--; if (this.lastDividerUpdate < 0) this.lastDividerUpdate = this.contentRegions.size() - 1;  }  int m = this.lastDividerUpdate % this.contentRegions.size(); Content content = this.contentRegions.get(m); if (content.isResizableWithParent() && arrayList.contains(content)) { double d5 = content.getArea(); if (bool) { double d6 = this.horizontal ? content.maxWidth(-1.0D) : content.maxHeight(-1.0D); if (d5 + i <= d6) { d5 += i; } else { arrayList.remove(content); continue; }  } else { double d6 = this.horizontal ? content.minWidth(-1.0D) : content.minHeight(-1.0D); if (d5 - i >= d6) { d5 -= i; } else { arrayList.remove(content); continue; }  }  content.setArea(d5); k -= i; if (k == 0 && j != 0) { i = j; k = j; j = 0; continue; }  if (k == 0) break;  }  }  for (Content content : this.contentRegions) { content.setResizableWithParentArea(content.getArea()); content.setAvailable(0.0D); }  this.resize = true; }  this.previousSize = this.horizontal ? d1 : d2; } else { this.previousSize = this.horizontal ? d1 : d2; }  double d4 = totalMinSize(); if (d4 > (this.horizontal ? paramDouble3 : paramDouble4)) { double d = 0.0D; for (byte b1 = 0; b1 < this.contentRegions.size(); b1++) { Content content = this.contentRegions.get(b1); double d5 = this.horizontal ? content.minWidth(-1.0D) : content.minHeight(-1.0D); d = d5 / d4; if (this.horizontal) { content.setArea(snapSpaceX(d * paramDouble3)); } else { content.setArea(snapSpaceY(d * paramDouble4)); }  content.setAvailable(0.0D); }  setupContentAndDividerForLayout(); layoutDividersAndContent(paramDouble3, paramDouble4); this.resize = false; return; }  for (byte b = 0; b < 10; b++) { ContentDivider contentDivider1 = null; ContentDivider contentDivider2 = null; for (byte b1 = 0; b1 < this.contentRegions.size(); b1++) { double d = 0.0D; if (b1 < this.contentDividers.size()) { contentDivider2 = this.contentDividers.get(b1); if (contentDivider2.posExplicit) checkDividerPosition(contentDivider2, posToDividerPos(contentDivider2, contentDivider2.d.getPosition()), contentDivider2.getDividerPos());  if (b1 == 0) { d = getAbsoluteDividerPos(contentDivider2); } else { double d8 = getAbsoluteDividerPos(contentDivider1) + d3; if (getAbsoluteDividerPos(contentDivider2) <= getAbsoluteDividerPos(contentDivider1)) setAndCheckAbsoluteDividerPos(contentDivider2, d8);  d = getAbsoluteDividerPos(contentDivider2) - d8; }  } else if (b1 == this.contentDividers.size()) { d = (this.horizontal ? paramDouble3 : paramDouble4) - ((contentDivider1 != null) ? (getAbsoluteDividerPos(contentDivider1) + d3) : 0.0D); }  if (!this.resize || contentDivider2.posExplicit) ((Content)this.contentRegions.get(b1)).setArea(d);  contentDivider1 = contentDivider2; }  double d5 = 0.0D; double d6 = 0.0D; for (Content content : this.contentRegions) { if (content == null) continue;  double d8 = this.horizontal ? content.maxWidth(-1.0D) : content.maxHeight(-1.0D); double d9 = this.horizontal ? content.minWidth(-1.0D) : content.minHeight(-1.0D); if (content.getArea() >= d8) { d6 += content.getArea() - d8; content.setArea(d8); }  content.setAvailable(content.getArea() - d9); if (content.getAvailable() < 0.0D) d5 += content.getAvailable();  }  d5 = Math.abs(d5); ArrayList<Content> arrayList1 = new ArrayList(); ArrayList<Content> arrayList2 = new ArrayList(); ArrayList<Content> arrayList3 = new ArrayList(); double d7 = 0.0D; for (Content content : this.contentRegions) { if (content.getAvailable() >= 0.0D) { d7 += content.getAvailable(); arrayList1.add(content); }  if (this.resize && !content.isResizableWithParent()) { if (content.getArea() >= content.getResizableWithParentArea()) { d6 += content.getArea() - content.getResizableWithParentArea(); } else { d5 += content.getResizableWithParentArea() - content.getArea(); }  content.setAvailable(0.0D); }  if (this.resize) { if (content.isResizableWithParent()) arrayList2.add(content);  } else { arrayList2.add(content); }  if (content.getAvailable() < 0.0D) arrayList3.add(content);  }  if (d6 > 0.0D) { d6 = distributeTo(arrayList2, d6); d5 = 0.0D; arrayList3.clear(); d7 = 0.0D; arrayList1.clear(); for (Content content : this.contentRegions) { if (content.getAvailable() < 0.0D) { d5 += content.getAvailable(); arrayList3.add(content); continue; }  d7 += content.getAvailable(); arrayList1.add(content); }  d5 = Math.abs(d5); }  if (d7 >= d5) { for (Content content : arrayList3) { double d = this.horizontal ? content.minWidth(-1.0D) : content.minHeight(-1.0D); content.setArea(d); content.setAvailable(0.0D); }  if (d5 > 0.0D && !arrayList3.isEmpty()) distributeFrom(d5, arrayList1);  if (this.resize) { double d = 0.0D; for (Content content : this.contentRegions) { if (content.isResizableWithParent()) { d += content.getArea(); continue; }  d += content.getResizableWithParentArea(); }  d += d3 * this.contentDividers.size(); if (d < (this.horizontal ? paramDouble3 : paramDouble4)) { d6 += (this.horizontal ? paramDouble3 : paramDouble4) - d; distributeTo(arrayList2, d6); } else { d5 += d - (this.horizontal ? paramDouble3 : paramDouble4); distributeFrom(d5, arrayList2); }  }  }  setupContentAndDividerForLayout(); boolean bool = true; for (Content content : this.contentRegions) { double d8 = this.horizontal ? content.maxWidth(-1.0D) : content.maxHeight(-1.0D); double d9 = this.horizontal ? content.minWidth(-1.0D) : content.minHeight(-1.0D); if (content.getArea() < d9 || content.getArea() > d8) { bool = false; break; }  }  if (bool) break;  }  layoutDividersAndContent(paramDouble3, paramDouble4); this.resize = false; return; }   } protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { double d1 = 0.0D; double d2 = 0.0D; for (Content content : this.contentRegions) { d1 += content.minWidth(-1.0D); d2 = Math.max(d2, content.minWidth(-1.0D)); }  for (ContentDivider contentDivider : this.contentDividers) d1 += contentDivider.prefWidth(-1.0D);  if (this.horizontal) return d1 + paramDouble5 + paramDouble3;  return d2 + paramDouble5 + paramDouble3; } protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { double d1 = 0.0D; double d2 = 0.0D; for (Content content : this.contentRegions) { d1 += content.minHeight(-1.0D); d2 = Math.max(d2, content.minHeight(-1.0D)); }  for (ContentDivider contentDivider : this.contentDividers) d1 += contentDivider.prefWidth(-1.0D);  if (this.horizontal) return d2 + paramDouble2 + paramDouble4;  return d1 + paramDouble2 + paramDouble4; } protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { double d1 = 0.0D; double d2 = 0.0D; for (Content content : this.contentRegions) { d1 += content.prefWidth(-1.0D); d2 = Math.max(d2, content.prefWidth(-1.0D)); }  for (ContentDivider contentDivider : this.contentDividers) d1 += contentDivider.prefWidth(-1.0D);  if (this.horizontal) return d1 + paramDouble5 + paramDouble3;  return d2 + paramDouble5 + paramDouble3; } protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { double d1 = 0.0D; double d2 = 0.0D; for (Content content : this.contentRegions) { d1 += content.prefHeight(-1.0D); d2 = Math.max(d2, content.prefHeight(-1.0D)); }  for (ContentDivider contentDivider : this.contentDividers) d1 += contentDivider.prefWidth(-1.0D);  if (this.horizontal) return d2 + paramDouble2 + paramDouble4;  return d1 + paramDouble2 + paramDouble4; } private void addContent(int paramInt, Node paramNode) { Content content = new Content(paramNode); this.contentRegions.add(paramInt, content); getChildren().add(paramInt, content); } private void removeContent(Node paramNode) { for (Content content : this.contentRegions) { if (content.getContent().equals(paramNode)) { content.dispose(); getChildren().remove(content); this.contentRegions.remove(content); break; }  }  } private void initializeContentListener() { getSkinnable().getItems().addListener(paramChange -> { while (paramChange.next()) { if (paramChange.wasPermutated() || paramChange.wasUpdated()) { getChildren().clear(); this.contentRegions.clear(); byte b = 0; for (Node node : paramChange.getList()) addContent(b++, node);  continue; }  for (Node node : paramChange.getRemoved()) removeContent(node);  int i = paramChange.getFrom(); for (Node node : paramChange.getAddedSubList()) addContent(i++, node);  }  removeAllDividers(); for (SplitPane.Divider divider : getSkinnable().getDividers()) addDivider(divider);  }); } private void checkDividerPosition(ContentDivider paramContentDivider, double paramDouble1, double paramDouble2) { double d1 = paramContentDivider.prefWidth(-1.0D); Content content1 = getLeft(paramContentDivider); Content content2 = getRight(paramContentDivider); double d2 = (content1 == null) ? 0.0D : (this.horizontal ? content1.minWidth(-1.0D) : content1.minHeight(-1.0D)); double d3 = (content2 == null) ? 0.0D : (this.horizontal ? content2.minWidth(-1.0D) : content2.minHeight(-1.0D)); double d4 = (content1 == null) ? 0.0D : ((content1.getContent() != null) ? (this.horizontal ? content1.getContent().maxWidth(-1.0D) : content1.getContent().maxHeight(-1.0D)) : 0.0D); double d5 = (content2 == null) ? 0.0D : ((content2.getContent() != null) ? (this.horizontal ? content2.getContent().maxWidth(-1.0D) : content2.getContent().maxHeight(-1.0D)) : 0.0D); double d6 = 0.0D; double d7 = getSize(); int i = this.contentDividers.indexOf(paramContentDivider); if (i - 1 >= 0) { d6 = ((ContentDivider)this.contentDividers.get(i - 1)).getDividerPos(); if (d6 == -1.0D) d6 = getAbsoluteDividerPos(this.contentDividers.get(i - 1));  }  if (i + 1 < this.contentDividers.size()) { d7 = ((ContentDivider)this.contentDividers.get(i + 1)).getDividerPos(); if (d7 == -1.0D) d7 = getAbsoluteDividerPos(this.contentDividers.get(i + 1));  }  this.checkDividerPos = false; if (paramDouble1 > paramDouble2) { double d8 = (d6 == 0.0D) ? d4 : (d6 + d1 + d4); double d9 = d7 - d3 - d1; double d10 = Math.min(d8, d9); if (paramDouble1 >= d10) { setAbsoluteDividerPos(paramContentDivider, d10); } else { double d = d7 - d5 - d1; if (paramDouble1 <= d) { setAbsoluteDividerPos(paramContentDivider, d); } else { setAbsoluteDividerPos(paramContentDivider, paramDouble1); }  }  } else { double d8 = d7 - d5 - d1; double d9 = (d6 == 0.0D) ? d2 : (d6 + d2 + d1); double d10 = Math.max(d8, d9); if (paramDouble1 <= d10) { setAbsoluteDividerPos(paramContentDivider, d10); } else { double d = d6 + d4 + d1; if (paramDouble1 >= d) { setAbsoluteDividerPos(paramContentDivider, d); } else { setAbsoluteDividerPos(paramContentDivider, paramDouble1); }  }  }  this.checkDividerPos = true; } private void addDivider(SplitPane.Divider paramDivider) { ContentDivider contentDivider = new ContentDivider(paramDivider); contentDivider.setInitialPos(paramDivider.getPosition()); contentDivider.setDividerPos(-1.0D); PosPropertyListener posPropertyListener = new PosPropertyListener(contentDivider); contentDivider.setPosPropertyListener(posPropertyListener); paramDivider.positionProperty().addListener(posPropertyListener); initializeDivderEventHandlers(contentDivider); this.contentDividers.add(contentDivider); getChildren().add(contentDivider); } private void removeAllDividers() { ListIterator<ContentDivider> listIterator = this.contentDividers.listIterator(); while (listIterator.hasNext()) { ContentDivider contentDivider = listIterator.next(); getChildren().remove(contentDivider); contentDivider.getDivider().positionProperty().removeListener(contentDivider.getPosPropertyListener()); listIterator.remove(); }  this.lastDividerUpdate = 0; } private void setAndCheckAbsoluteDividerPos(ContentDivider paramContentDivider, double paramDouble) { double d = paramContentDivider.getDividerPos();
/*  932 */     setAbsoluteDividerPos(paramContentDivider, paramDouble);
/*  933 */     checkDividerPosition(paramContentDivider, paramDouble, d); } private void initializeDivderEventHandlers(ContentDivider paramContentDivider) { paramContentDivider.addEventHandler(MouseEvent.ANY, paramMouseEvent -> paramMouseEvent.consume()); paramContentDivider.setOnMousePressed(paramMouseEvent -> { if (this.horizontal) { paramContentDivider.setInitialPos(paramContentDivider.getDividerPos()); paramContentDivider.setPressPos(paramMouseEvent.getSceneX()); paramContentDivider.setPressPos((getSkinnable().getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) ? (getSkinnable().getWidth() - paramMouseEvent.getSceneX()) : paramMouseEvent.getSceneX()); } else { paramContentDivider.setInitialPos(paramContentDivider.getDividerPos()); paramContentDivider.setPressPos(paramMouseEvent.getSceneY()); }  paramMouseEvent.consume(); }); paramContentDivider.setOnMouseDragged(paramMouseEvent -> { double d = 0.0D; if (this.horizontal) { d = (getSkinnable().getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) ? (getSkinnable().getWidth() - paramMouseEvent.getSceneX()) : paramMouseEvent.getSceneX(); } else { d = paramMouseEvent.getSceneY(); }  d -= paramContentDivider.getPressPos(); setAndCheckAbsoluteDividerPos(paramContentDivider, Math.ceil(paramContentDivider.getInitialPos() + d)); paramMouseEvent.consume(); }); } private Content getLeft(ContentDivider paramContentDivider) { int i = this.contentDividers.indexOf(paramContentDivider); if (i != -1) return this.contentRegions.get(i);  return null; }
/*      */   private Content getRight(ContentDivider paramContentDivider) { int i = this.contentDividers.indexOf(paramContentDivider); if (i != -1) return this.contentRegions.get(i + 1);  return null; }
/*      */   private void setAbsoluteDividerPos(ContentDivider paramContentDivider, double paramDouble) { if (getSkinnable().getWidth() > 0.0D && getSkinnable().getHeight() > 0.0D && paramContentDivider != null) { SplitPane.Divider divider = paramContentDivider.getDivider(); paramContentDivider.setDividerPos(paramDouble); double d = getSize(); if (d != 0.0D) { double d1 = paramDouble + paramContentDivider.prefWidth(-1.0D) / 2.0D; divider.setPosition(d1 / d); } else { divider.setPosition(0.0D); }  }  }
/*      */   private double getAbsoluteDividerPos(ContentDivider paramContentDivider) { if (getSkinnable().getWidth() > 0.0D && getSkinnable().getHeight() > 0.0D && paramContentDivider != null) { SplitPane.Divider divider = paramContentDivider.getDivider(); double d = posToDividerPos(paramContentDivider, divider.getPosition()); paramContentDivider.setDividerPos(d); return d; }  return 0.0D; }
/*      */   private double posToDividerPos(ContentDivider paramContentDivider, double paramDouble) { double d = getSize() * paramDouble; if (paramDouble == 1.0D) { d -= paramContentDivider.prefWidth(-1.0D); } else { d -= paramContentDivider.prefWidth(-1.0D) / 2.0D; }  return Math.round(d); }
/*      */   private double totalMinSize() { double d1 = !this.contentDividers.isEmpty() ? (this.contentDividers.size() * ((ContentDivider)this.contentDividers.get(0)).prefWidth(-1.0D)) : 0.0D; double d2 = 0.0D; for (Content content : this.contentRegions) { if (this.horizontal) { d2 += content.minWidth(-1.0D); continue; }  d2 += content.minHeight(-1.0D); }  return d2 + d1; }
/*      */   private double getSize() { SplitPane splitPane = getSkinnable(); double d = totalMinSize(); if (this.horizontal) { if (splitPane.getWidth() > d) d = splitPane.getWidth() - snappedLeftInset() - snappedRightInset();  } else if (splitPane.getHeight() > d) { d = splitPane.getHeight() - snappedTopInset() - snappedBottomInset(); }  return d; }
/*      */   private double distributeTo(List<Content> paramList, double paramDouble) { if (paramList.isEmpty()) return paramDouble;  paramDouble = this.horizontal ? snapSizeX(paramDouble) : snapSizeY(paramDouble); int i = (int)paramDouble / paramList.size(); while (paramDouble > 0.0D && !paramList.isEmpty()) { Iterator<Content> iterator = paramList.iterator(); while (iterator.hasNext()) { Content content = iterator.next(); double d1 = Math.min(this.horizontal ? content.maxWidth(-1.0D) : content.maxHeight(-1.0D), Double.MAX_VALUE); double d2 = this.horizontal ? content.minWidth(-1.0D) : content.minHeight(-1.0D); if (content.getArea() >= d1) { content.setAvailable(content.getArea() - d2); iterator.remove(); continue; }  if (i >= d1 - content.getArea()) { paramDouble -= d1 - content.getArea(); content.setArea(d1); content.setAvailable(d1 - d2); iterator.remove(); } else { content.setArea(content.getArea() + i); content.setAvailable(content.getArea() - d2); paramDouble -= i; }  if ((int)paramDouble == 0) return paramDouble;  }  if (paramList.isEmpty()) return paramDouble;  i = (int)paramDouble / paramList.size(); int j = (int)paramDouble % paramList.size(); if (i == 0 && j != 0) { i = j; j = 0; }  }  return paramDouble; }
/*      */   private double distributeFrom(double paramDouble, List<Content> paramList) { if (paramList.isEmpty())
/*      */       return paramDouble;  paramDouble = this.horizontal ? snapSizeX(paramDouble) : snapSizeY(paramDouble); int i = (int)paramDouble / paramList.size(); while (paramDouble > 0.0D && !paramList.isEmpty()) { Iterator<Content> iterator = paramList.iterator(); while (iterator.hasNext()) { Content content = iterator.next(); if (i >= content.getAvailable()) { content.setArea(content.getArea() - content.getAvailable()); paramDouble -= content.getAvailable(); content.setAvailable(0.0D); iterator.remove(); } else { content.setArea(content.getArea() - i); content.setAvailable(content.getAvailable() - i); paramDouble -= i; }  if ((int)paramDouble == 0)
/*      */           return paramDouble;  }  if (paramList.isEmpty())
/*      */         return paramDouble;  i = (int)paramDouble / paramList.size(); int j = (int)paramDouble % paramList.size(); if (i == 0 && j != 0) { i = j; j = 0; }  }  return paramDouble; }
/*      */   private void setupContentAndDividerForLayout() { double d1 = this.contentDividers.isEmpty() ? 0.0D : ((ContentDivider)this.contentDividers.get(0)).prefWidth(-1.0D); double d2 = 0.0D; double d3 = 0.0D; for (Content content : this.contentRegions) { if (this.resize && !content.isResizableWithParent())
/*      */         content.setArea(content.getResizableWithParentArea());  content.setX(d2); content.setY(d3); if (this.horizontal) { d2 += content.getArea() + d1; continue; }  d3 += content.getArea() + d1; }  d2 = 0.0D; d3 = 0.0D; this.checkDividerPos = false; for (byte b = 0; b < this.contentDividers.size(); b++) { ContentDivider contentDivider = this.contentDividers.get(b); if (this.horizontal) { d2 += getLeft(contentDivider).getArea() + ((b == 0) ? 0.0D : d1); } else { d3 += getLeft(contentDivider).getArea() + ((b == 0) ? 0.0D : d1); }  contentDivider.setX(d2); contentDivider.setY(d3); setAbsoluteDividerPos(contentDivider, this.horizontal ? contentDivider.getX() : contentDivider.getY()); contentDivider.posExplicit = false; }  this.checkDividerPos = true; }
/*      */   private void layoutDividersAndContent(double paramDouble1, double paramDouble2) { double d1 = snappedLeftInset(); double d2 = snappedTopInset(); double d3 = this.contentDividers.isEmpty() ? 0.0D : ((ContentDivider)this.contentDividers.get(0)).prefWidth(-1.0D); for (Content content : this.contentRegions) { if (this.horizontal) { content.setClipSize(content.getArea(), paramDouble2); layoutInArea(content, content.getX() + d1, content.getY() + d2, content.getArea(), paramDouble2, 0.0D, HPos.CENTER, VPos.CENTER); continue; }  content.setClipSize(paramDouble1, content.getArea()); layoutInArea(content, content.getX() + d1, content.getY() + d2, paramDouble1, content.getArea(), 0.0D, HPos.CENTER, VPos.CENTER); }  for (ContentDivider contentDivider : this.contentDividers) { if (this.horizontal) { contentDivider.resize(d3, paramDouble2); positionInArea(contentDivider, contentDivider.getX() + d1, contentDivider.getY() + d2, d3, paramDouble2, 0.0D, HPos.CENTER, VPos.CENTER); continue; }  contentDivider.resize(paramDouble1, d3); positionInArea(contentDivider, contentDivider.getX() + d1, contentDivider.getY() + d2, paramDouble1, d3, 0.0D, HPos.CENTER, VPos.CENTER); }  }
/*      */   class PosPropertyListener implements ChangeListener<Number> { SplitPaneSkin.ContentDivider divider;
/*  949 */     public PosPropertyListener(SplitPaneSkin.ContentDivider param1ContentDivider) { this.divider = param1ContentDivider; }
/*      */ 
/*      */     
/*      */     public void changed(ObservableValue<? extends Number> param1ObservableValue, Number param1Number1, Number param1Number2) {
/*  953 */       if (SplitPaneSkin.this.checkDividerPos)
/*      */       {
/*  955 */         this.divider.posExplicit = true;
/*      */       }
/*  957 */       SplitPaneSkin.this.getSkinnable().requestLayout();
/*      */     } }
/*      */ 
/*      */   
/*      */   class ContentDivider
/*      */     extends StackPane {
/*      */     private double initialPos;
/*      */     private double dividerPos;
/*      */     private double pressPos;
/*      */     private SplitPane.Divider d;
/*      */     private StackPane grabber;
/*      */     private double x;
/*      */     private double y;
/*      */     private boolean posExplicit;
/*      */     private ChangeListener<Number> listener;
/*      */     
/*      */     public ContentDivider(SplitPane.Divider param1Divider) {
/*  974 */       getStyleClass().setAll(new String[] { "split-pane-divider" });
/*      */       
/*  976 */       this.d = param1Divider;
/*  977 */       this.initialPos = 0.0D;
/*  978 */       this.dividerPos = 0.0D;
/*  979 */       this.pressPos = 0.0D;
/*      */       
/*  981 */       this.grabber = new StackPane() {
/*      */           protected double computeMinWidth(double param2Double) {
/*  983 */             return 0.0D;
/*      */           }
/*      */           
/*      */           protected double computeMinHeight(double param2Double) {
/*  987 */             return 0.0D;
/*      */           }
/*      */           
/*      */           protected double computePrefWidth(double param2Double) {
/*  991 */             return snappedLeftInset() + snappedRightInset();
/*      */           }
/*      */           
/*      */           protected double computePrefHeight(double param2Double) {
/*  995 */             return snappedTopInset() + snappedBottomInset();
/*      */           }
/*      */           
/*      */           protected double computeMaxWidth(double param2Double) {
/*  999 */             return computePrefWidth(-1.0D);
/*      */           }
/*      */           
/*      */           protected double computeMaxHeight(double param2Double) {
/* 1003 */             return computePrefHeight(-1.0D);
/*      */           }
/*      */         };
/* 1006 */       setGrabberStyle(SplitPaneSkin.this.horizontal);
/* 1007 */       getChildren().add(this.grabber);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public SplitPane.Divider getDivider() {
/* 1013 */       return this.d;
/*      */     }
/*      */     
/*      */     public final void setGrabberStyle(boolean param1Boolean) {
/* 1017 */       this.grabber.getStyleClass().clear();
/* 1018 */       this.grabber.getStyleClass().setAll(new String[] { "vertical-grabber" });
/* 1019 */       setCursor(Cursor.V_RESIZE);
/* 1020 */       if (param1Boolean) {
/* 1021 */         this.grabber.getStyleClass().setAll(new String[] { "horizontal-grabber" });
/* 1022 */         setCursor(Cursor.H_RESIZE);
/*      */       } 
/*      */     }
/*      */     
/*      */     public double getInitialPos() {
/* 1027 */       return this.initialPos;
/*      */     }
/*      */     
/*      */     public void setInitialPos(double param1Double) {
/* 1031 */       this.initialPos = param1Double;
/*      */     }
/*      */     
/*      */     public double getDividerPos() {
/* 1035 */       return this.dividerPos;
/*      */     }
/*      */     
/*      */     public void setDividerPos(double param1Double) {
/* 1039 */       this.dividerPos = param1Double;
/*      */     }
/*      */     
/*      */     public double getPressPos() {
/* 1043 */       return this.pressPos;
/*      */     }
/*      */     
/*      */     public void setPressPos(double param1Double) {
/* 1047 */       this.pressPos = param1Double;
/*      */     }
/*      */ 
/*      */     
/*      */     public double getX() {
/* 1052 */       return this.x;
/*      */     }
/*      */     
/*      */     public void setX(double param1Double) {
/* 1056 */       this.x = param1Double;
/*      */     }
/*      */     
/*      */     public double getY() {
/* 1060 */       return this.y;
/*      */     }
/*      */     
/*      */     public void setY(double param1Double) {
/* 1064 */       this.y = param1Double;
/*      */     }
/*      */     
/*      */     public ChangeListener<Number> getPosPropertyListener() {
/* 1068 */       return this.listener;
/*      */     }
/*      */     
/*      */     public void setPosPropertyListener(ChangeListener<Number> param1ChangeListener) {
/* 1072 */       this.listener = param1ChangeListener;
/*      */     }
/*      */     
/*      */     protected double computeMinWidth(double param1Double) {
/* 1076 */       return computePrefWidth(param1Double);
/*      */     }
/*      */     
/*      */     protected double computeMinHeight(double param1Double) {
/* 1080 */       return computePrefHeight(param1Double);
/*      */     }
/*      */     
/*      */     protected double computePrefWidth(double param1Double) {
/* 1084 */       return snappedLeftInset() + snappedRightInset();
/*      */     }
/*      */     
/*      */     protected double computePrefHeight(double param1Double) {
/* 1088 */       return snappedTopInset() + snappedBottomInset();
/*      */     }
/*      */     
/*      */     protected double computeMaxWidth(double param1Double) {
/* 1092 */       return computePrefWidth(param1Double);
/*      */     }
/*      */     
/*      */     protected double computeMaxHeight(double param1Double) {
/* 1096 */       return computePrefHeight(param1Double);
/*      */     }
/*      */     
/*      */     protected void layoutChildren() {
/* 1100 */       double d1 = this.grabber.prefWidth(-1.0D);
/* 1101 */       double d2 = this.grabber.prefHeight(-1.0D);
/* 1102 */       double d3 = (getWidth() - d1) / 2.0D;
/* 1103 */       double d4 = (getHeight() - d2) / 2.0D;
/* 1104 */       this.grabber.resize(d1, d2);
/* 1105 */       positionInArea(this.grabber, d3, d4, d1, d2, 0.0D, HPos.CENTER, VPos.CENTER);
/*      */     }
/*      */   }
/*      */   
/*      */   static class Content
/*      */     extends StackPane {
/*      */     private Node content;
/*      */     private Rectangle clipRect;
/*      */     private double x;
/*      */     private double y;
/*      */     private double area;
/*      */     private double resizableWithParentArea;
/*      */     private double available;
/*      */     
/*      */     public Content(Node param1Node) {
/* 1120 */       this.clipRect = new Rectangle();
/* 1121 */       setClip(this.clipRect);
/* 1122 */       this.content = param1Node;
/* 1123 */       if (param1Node != null) {
/* 1124 */         getChildren().add(param1Node);
/*      */       }
/* 1126 */       this.x = 0.0D;
/* 1127 */       this.y = 0.0D;
/*      */     }
/*      */     
/*      */     public Node getContent() {
/* 1131 */       return this.content;
/*      */     }
/*      */     
/*      */     public double getX() {
/* 1135 */       return this.x;
/*      */     }
/*      */     
/*      */     public void setX(double param1Double) {
/* 1139 */       this.x = param1Double;
/*      */     }
/*      */     
/*      */     public double getY() {
/* 1143 */       return this.y;
/*      */     }
/*      */     
/*      */     public void setY(double param1Double) {
/* 1147 */       this.y = param1Double;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public double getArea() {
/* 1153 */       return this.area;
/*      */     }
/*      */     
/*      */     public void setArea(double param1Double) {
/* 1157 */       this.area = param1Double;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public double getAvailable() {
/* 1163 */       return this.available;
/*      */     }
/*      */     
/*      */     public void setAvailable(double param1Double) {
/* 1167 */       this.available = param1Double;
/*      */     }
/*      */     
/*      */     public boolean isResizableWithParent() {
/* 1171 */       return SplitPane.isResizableWithParent(this.content).booleanValue();
/*      */     }
/*      */     
/*      */     public double getResizableWithParentArea() {
/* 1175 */       return this.resizableWithParentArea;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void setResizableWithParentArea(double param1Double) {
/* 1181 */       if (!isResizableWithParent()) {
/* 1182 */         this.resizableWithParentArea = param1Double;
/*      */       } else {
/* 1184 */         this.resizableWithParentArea = 0.0D;
/*      */       } 
/*      */     }
/*      */     
/*      */     protected void setClipSize(double param1Double1, double param1Double2) {
/* 1189 */       this.clipRect.setWidth(param1Double1);
/* 1190 */       this.clipRect.setHeight(param1Double2);
/*      */     }
/*      */     
/*      */     private void dispose() {
/* 1194 */       getChildren().remove(this.content);
/*      */     }
/*      */     
/*      */     protected double computeMaxWidth(double param1Double) {
/* 1198 */       return snapSizeX(this.content.maxWidth(param1Double));
/*      */     }
/*      */     
/*      */     protected double computeMaxHeight(double param1Double) {
/* 1202 */       return snapSizeY(this.content.maxHeight(param1Double));
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\SplitPaneSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */