/*      */ package javafx.scene.control.skin;
/*      */ 
/*      */ import com.sun.javafx.logging.PlatformLogger;
/*      */ import com.sun.javafx.scene.ParentHelper;
/*      */ import com.sun.javafx.scene.control.Logging;
/*      */ import com.sun.javafx.scene.control.Properties;
/*      */ import com.sun.javafx.scene.control.VirtualScrollBar;
/*      */ import com.sun.javafx.scene.control.skin.Utils;
/*      */ import com.sun.javafx.scene.traversal.Algorithm;
/*      */ import com.sun.javafx.scene.traversal.Direction;
/*      */ import com.sun.javafx.scene.traversal.ParentTraversalEngine;
/*      */ import com.sun.javafx.scene.traversal.TraversalContext;
/*      */ import com.sun.javafx.util.Utils;
/*      */ import java.util.AbstractList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.BitSet;
/*      */ import java.util.List;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.Timeline;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.BooleanPropertyBase;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.IntegerProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.beans.property.SimpleDoubleProperty;
/*      */ import javafx.beans.property.SimpleIntegerProperty;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.beans.value.ChangeListener;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventDispatchChain;
/*      */ import javafx.event.EventDispatcher;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Group;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Parent;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.control.Cell;
/*      */ import javafx.scene.control.IndexedCell;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.input.ScrollEvent;
/*      */ import javafx.scene.input.TouchEvent;
/*      */ import javafx.scene.layout.Region;
/*      */ import javafx.scene.layout.StackPane;
/*      */ import javafx.scene.shape.Rectangle;
/*      */ import javafx.util.Callback;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class VirtualFlow<T extends IndexedCell>
/*      */   extends Region
/*      */ {
/*      */   private static final int MIN_SCROLLING_LINES_PER_PAGE = 8;
/*      */   private static final String NEW_CELL = "newcell";
/*      */   private static final double GOLDEN_RATIO_MULTIPLIER = 0.618033987D;
/*      */   private boolean touchDetected = false;
/*      */   private boolean mouseDown = false;
/*  128 */   double lastWidth = -1.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  134 */   double lastHeight = -1.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  141 */   int lastCellCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean lastVertical;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   double lastPosition;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   double lastCellBreadth = -1.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  167 */   double lastCellLength = -1.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  178 */   final ArrayLinkedList<T> cells = new ArrayLinkedList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  187 */   final ArrayLinkedList<T> pile = new ArrayLinkedList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T accumCell;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Group accumCellParent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Group sheet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ObservableList<Node> sheetChildren;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  215 */   private VirtualScrollBar hbar = new VirtualScrollBar(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  221 */   private VirtualScrollBar vbar = new VirtualScrollBar(this);
/*      */ 
/*      */   
/*      */   ClippedContainer clipView;
/*      */ 
/*      */   
/*      */   StackPane corner;
/*      */ 
/*      */   
/*      */   private double lastX;
/*      */ 
/*      */   
/*      */   private double lastY;
/*      */ 
/*      */   
/*      */   private boolean isPanning = false;
/*      */   
/*      */   private boolean fixedCellSizeEnabled = false;
/*      */   
/*      */   private boolean needsReconfigureCells = false;
/*      */   
/*      */   private boolean needsRecreateCells = false;
/*      */   
/*      */   private boolean needsRebuildCells = false;
/*      */   
/*      */   private boolean needsCellsLayout = false;
/*      */   
/*      */   private boolean sizeChanged = false;
/*      */   
/*  250 */   private final BitSet dirtyCells = new BitSet();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Timeline sbTouchTimeline;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   KeyFrame sbTouchKF1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   KeyFrame sbTouchKF2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean needBreadthBar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean needLengthBar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean tempVisibility = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BooleanProperty vertical;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BooleanProperty pannable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IntegerProperty cellCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DoubleProperty position;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DoubleProperty fixedCellSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ObjectProperty<Callback<VirtualFlow<T>, T>> cellFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double maxPrefBreadth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double viewportBreadth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double viewportLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final List<T> privateCells;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setVertical(boolean paramBoolean) {
/*  746 */     verticalProperty().set(paramBoolean);
/*      */   }
/*      */   
/*      */   public final boolean isVertical() {
/*  750 */     return (this.vertical == null) ? true : this.vertical.get();
/*      */   }
/*      */   
/*      */   public final BooleanProperty verticalProperty() {
/*  754 */     if (this.vertical == null) {
/*  755 */       this.vertical = new BooleanPropertyBase(true) {
/*      */           protected void invalidated() {
/*  757 */             VirtualFlow.this.pile.clear();
/*  758 */             VirtualFlow.this.sheetChildren.clear();
/*  759 */             VirtualFlow.this.cells.clear();
/*  760 */             VirtualFlow.this.lastWidth = VirtualFlow.this.lastHeight = -1.0D;
/*  761 */             VirtualFlow.this.setMaxPrefBreadth(-1.0D);
/*  762 */             VirtualFlow.this.setViewportBreadth(0.0D);
/*  763 */             VirtualFlow.this.setViewportLength(0.0D);
/*  764 */             VirtualFlow.this.lastPosition = 0.0D;
/*  765 */             VirtualFlow.this.hbar.setValue(0.0D);
/*  766 */             VirtualFlow.this.vbar.setValue(0.0D);
/*  767 */             VirtualFlow.this.setPosition(0.0D);
/*  768 */             VirtualFlow.this.setNeedsLayout(true);
/*  769 */             VirtualFlow.this.requestLayout();
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  774 */             return VirtualFlow.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  779 */             return "vertical";
/*      */           }
/*      */         };
/*      */     }
/*  783 */     return this.vertical;
/*      */   }
/*      */   public final boolean isPannable() { return this.pannable.get(); }
/*      */   public final void setPannable(boolean paramBoolean) { this.pannable.set(paramBoolean); }
/*      */   public final BooleanProperty pannableProperty() { return this.pannable; }
/*      */   public final int getCellCount() { return this.cellCount.get(); }
/*      */   public final void setCellCount(int paramInt) { this.cellCount.set(paramInt); } public final IntegerProperty cellCountProperty() { return this.cellCount; } public final double getPosition() { return this.position.get(); } public final void setPosition(double paramDouble) { this.position.set(paramDouble); } public final DoubleProperty positionProperty() { return this.position; } public final void setFixedCellSize(double paramDouble) { this.fixedCellSize.set(paramDouble); } public final double getFixedCellSize() { return this.fixedCellSize.get(); } public final DoubleProperty fixedCellSizeProperty() { return this.fixedCellSize; } public final void setCellFactory(Callback<VirtualFlow<T>, T> paramCallback) { cellFactoryProperty().set(paramCallback); } public final Callback<VirtualFlow<T>, T> getCellFactory() { return (this.cellFactory == null) ? null : this.cellFactory.get(); } public final ObjectProperty<Callback<VirtualFlow<T>, T>> cellFactoryProperty() { if (this.cellFactory == null) this.cellFactory = (ObjectProperty)new SimpleObjectProperty<Callback<VirtualFlow<Callback<VirtualFlow<T>, T>>, Callback<VirtualFlow<T>, T>>>(this, "cellFactory") {
/*      */           protected void invalidated() { if (get() != null) { VirtualFlow.this.accumCell = null; VirtualFlow.this.setNeedsLayout(true); VirtualFlow.this.recreateCells(); if (VirtualFlow.this.getParent() != null) VirtualFlow.this.getParent().requestLayout();  }  }
/*  791 */         };  return this.cellFactory; } public void requestLayout() { super.requestLayout(); } protected void layoutChildren() { if (this.needsRecreateCells) { this.lastWidth = -1.0D; this.lastHeight = -1.0D; releaseCell(this.accumCell); this.sheet.getChildren().clear(); byte b; int k; for (b = 0, k = this.cells.size(); b < k; b++) ((IndexedCell)this.cells.get(b)).updateIndex(-1);  this.cells.clear(); this.pile.clear(); releaseAllPrivateCells(); } else if (this.needsRebuildCells) { this.lastWidth = -1.0D; this.lastHeight = -1.0D; releaseCell(this.accumCell); byte b; int k; for (b = 0, k = this.cells.size(); b < k; b++) ((IndexedCell)this.cells.get(b)).updateIndex(-1);  addAllToPile(); releaseAllPrivateCells(); } else if (this.needsReconfigureCells) { setMaxPrefBreadth(-1.0D); this.lastWidth = -1.0D; this.lastHeight = -1.0D; }  if (!this.dirtyCells.isEmpty()) { int m = this.cells.size(); int k; while ((k = this.dirtyCells.nextSetBit(0)) != -1 && k < m) { IndexedCell indexedCell = (IndexedCell)this.cells.get(k); if (indexedCell != null) indexedCell.requestLayout();  this.dirtyCells.clear(k); }  setMaxPrefBreadth(-1.0D); this.lastWidth = -1.0D; this.lastHeight = -1.0D; }  boolean bool1 = this.sizeChanged; boolean bool2 = (this.needsRebuildCells || this.needsRecreateCells || this.sizeChanged) ? true : false; this.needsRecreateCells = false; this.needsReconfigureCells = false; this.needsRebuildCells = false; this.sizeChanged = false; if (this.needsCellsLayout) { byte b; int k; for (b = 0, k = this.cells.size(); b < k; b++) { Cell cell = (Cell)this.cells.get(b); if (cell != null) cell.requestLayout();  }  this.needsCellsLayout = false; return; }  double d1 = getWidth(); double d2 = getHeight(); boolean bool3 = isVertical(); double d3 = getPosition(); if (d1 <= 0.0D || d2 <= 0.0D) { addAllToPile(); this.lastWidth = d1; this.lastHeight = d2; this.hbar.setVisible(false); this.vbar.setVisible(false); this.corner.setVisible(false); return; }  boolean bool4 = false; boolean bool5 = false; if (Properties.IS_TOUCH_SUPPORTED && ((this.tempVisibility == true && (!this.hbar.isVisible() || !this.vbar.isVisible())) || (!this.tempVisibility && (this.hbar.isVisible() == true || this.vbar.isVisible() == true)))) bool5 = true;  if (!bool4) for (byte b = 0; b < this.cells.size(); b++) { Cell cell = (Cell)this.cells.get(b); bool4 = cell.isNeedsLayout(); if (bool4) break;  }   int i = getCellCount(); T t = getFirstVisibleCell(); if (!bool4 && !bool5) { boolean bool = false; if (t != null) { double d4 = getCellBreadth((Cell)t); double d5 = getCellLength(t); bool = (d4 != this.lastCellBreadth || d5 != this.lastCellLength) ? true : false; this.lastCellBreadth = d4; this.lastCellLength = d5; }  if (d1 == this.lastWidth && d2 == this.lastHeight && i == this.lastCellCount && bool3 == this.lastVertical && d3 == this.lastPosition && !bool) return;  }  boolean bool6 = false; boolean bool7 = (bool4 || bool3 != this.lastVertical || this.cells.isEmpty() || getMaxPrefBreadth() == -1.0D || d3 != this.lastPosition || i != this.lastCellCount || bool1 || (bool3 && d2 < this.lastHeight) || (!bool3 && d1 < this.lastWidth)) ? true : false; if (!bool7) { double d = getMaxPrefBreadth(); boolean bool = false; for (byte b = 0; b < this.cells.size(); b++) { double d4 = getCellBreadth((Cell)this.cells.get(b)); if (d == d4) { bool = true; } else if (d4 > d) { bool7 = true; break; }  }  if (!bool) bool7 = true;  }  if (!bool7 && ((bool3 && d2 > this.lastHeight) || (!bool3 && d1 > this.lastWidth))) bool6 = true;  initViewport(); int j = computeCurrentIndex(); if (this.lastCellCount != i) { if (d3 != 0.0D && d3 != 1.0D) if (j >= i) { setPosition(1.0D); } else if (t != null) { double d4 = getCellPosition(t); int k = getCellIndex(t); adjustPositionToIndex(k); double d5 = -computeOffsetForCell(k); adjustByPixelAmount(d5 - d4); }   j = computeCurrentIndex(); }  if (bool7) { setMaxPrefBreadth(-1.0D); addAllToPile(); double d = -computeViewportOffset(getPosition()); addLeadingCells(j, d); addTrailingCells(true); } else if (bool6) { addTrailingCells(true); }  computeBarVisiblity(); bool2 = (bool2 || bool7) ? true : false; updateScrollBarsAndCells(bool2); this.lastWidth = getWidth(); this.lastHeight = getHeight(); this.lastCellCount = getCellCount(); this.lastVertical = isVertical(); this.lastPosition = getPosition(); cleanPile(); } protected void setWidth(double paramDouble) { if (paramDouble != this.lastWidth) { super.setWidth(paramDouble); this.sizeChanged = true; setNeedsLayout(true); requestLayout(); }  } protected void setHeight(double paramDouble) { if (paramDouble != this.lastHeight) { super.setHeight(paramDouble); this.sizeChanged = true; setNeedsLayout(true); requestLayout(); }  } protected T getAvailableCell(int paramInt) { IndexedCell indexedCell = null; byte b; int i; for (b = 0, i = this.pile.size(); b < i; b++) { IndexedCell indexedCell1 = (IndexedCell)this.pile.get(b); assert indexedCell1 != null; if (getCellIndex((T)indexedCell1) == paramInt) { indexedCell = indexedCell1; this.pile.remove(b); break; }  }  if (indexedCell == null && !this.pile.isEmpty()) indexedCell = (IndexedCell)this.pile.removeLast();  if (indexedCell == null) { indexedCell = (IndexedCell)getCellFactory().call(this); indexedCell.getProperties().put("newcell", null); }  if (indexedCell.getParent() == null) this.sheetChildren.add(indexedCell);  return (T)indexedCell; } protected void addAllToPile() { byte b; int i; for (b = 0, i = this.cells.size(); b < i; b++) addToPile(this.cells.removeFirst());  } public T getVisibleCell(int paramInt) { if (this.cells.isEmpty()) return null;  IndexedCell indexedCell1 = (IndexedCell)this.cells.getLast(); int i = getCellIndex((T)indexedCell1); if (paramInt == i) return (T)indexedCell1;  IndexedCell indexedCell2 = (IndexedCell)this.cells.getFirst(); int j = getCellIndex((T)indexedCell2); if (paramInt == j) return (T)indexedCell2;  if (paramInt > j && paramInt < i) { IndexedCell indexedCell = (IndexedCell)this.cells.get(paramInt - j); if (getCellIndex((T)indexedCell) == paramInt) return (T)indexedCell;  }  return null; } public T getLastVisibleCell() { if (this.cells.isEmpty() || getViewportLength() <= 0.0D) return null;  for (int i = this.cells.size() - 1; i >= 0; i--) { IndexedCell indexedCell = (IndexedCell)this.cells.get(i); if (!indexedCell.isEmpty()) return (T)indexedCell;  }  return null; } public T getFirstVisibleCell() { if (this.cells.isEmpty() || getViewportLength() <= 0.0D) return null;  IndexedCell indexedCell = (IndexedCell)this.cells.getFirst(); return indexedCell.isEmpty() ? null : (T)indexedCell; } public void scrollToTop(T paramT) { if (paramT != null) scrollPixels(getCellPosition(paramT));  } public void scrollToBottom(T paramT) { if (paramT != null) scrollPixels(getCellPosition(paramT) + getCellLength(paramT) - getViewportLength());  } public void scrollTo(T paramT) { if (paramT != null) { double d1 = getCellPosition(paramT); double d2 = getCellLength(paramT); double d3 = d1 + d2; double d4 = getViewportLength(); if (d1 < 0.0D) { scrollPixels(d1); } else if (d3 > d4) { scrollPixels(d3 - d4); }  }  } public VirtualFlow() { this.pannable = new SimpleBooleanProperty(this, "pannable", true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  804 */     this.cellCount = new SimpleIntegerProperty(this, "cellCount", 0) {
/*  805 */         private int oldCount = 0;
/*      */         
/*      */         protected void invalidated() {
/*  808 */           int i = get();
/*      */           
/*  810 */           boolean bool = (this.oldCount != i) ? true : false;
/*  811 */           this.oldCount = i;
/*      */ 
/*      */ 
/*      */           
/*  815 */           if (bool) {
/*  816 */             VirtualScrollBar virtualScrollBar = VirtualFlow.this.isVertical() ? VirtualFlow.this.vbar : VirtualFlow.this.hbar;
/*  817 */             virtualScrollBar.setMax(i);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  836 */           if (bool) {
/*  837 */             VirtualFlow.this.layoutChildren();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  843 */             VirtualFlow.this.sheetChildren.clear();
/*      */             
/*  845 */             Parent parent = VirtualFlow.this.getParent();
/*  846 */             if (parent != null) parent.requestLayout();
/*      */           
/*      */           } 
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  864 */     this.position = new SimpleDoubleProperty(this, "position") {
/*      */         public void setValue(Number param1Number) {
/*  866 */           super.setValue(Double.valueOf(Utils.clamp(0.0D, get(), 1.0D)));
/*      */         }
/*      */         
/*      */         protected void invalidated() {
/*  870 */           super.invalidated();
/*  871 */           VirtualFlow.this.requestLayout();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  884 */     this.fixedCellSize = new SimpleDoubleProperty(this, "fixedCellSize") {
/*      */         protected void invalidated() {
/*  886 */           VirtualFlow.this.fixedCellSizeEnabled = (get() > 0.0D);
/*  887 */           VirtualFlow.this.needsCellsLayout = true;
/*  888 */           VirtualFlow.this.layoutChildren();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2537 */     this.privateCells = new ArrayList<>(); getStyleClass().add("virtual-flow"); setId("virtual-flow"); this.sheet = new Group(); this.sheet.getStyleClass().add("sheet"); this.sheet.setAutoSizeChildren(false); this.sheetChildren = this.sheet.getChildren(); this.clipView = new ClippedContainer(this); this.clipView.setNode(this.sheet); getChildren().add(this.clipView); this.accumCellParent = new Group(); this.accumCellParent.setVisible(false); getChildren().add(this.accumCellParent); EventDispatcher eventDispatcher1 = (paramEvent, paramEventDispatchChain) -> paramEvent; EventDispatcher eventDispatcher2 = this.hbar.getEventDispatcher(); this.hbar.setEventDispatcher((paramEvent, paramEventDispatchChain) -> { if (paramEvent.getEventType() == ScrollEvent.SCROLL && !((ScrollEvent)paramEvent).isDirect()) { paramEventDispatchChain = paramEventDispatchChain.prepend(paramEventDispatcher1); paramEventDispatchChain = paramEventDispatchChain.prepend(paramEventDispatcher2); return (EventDispatcher)paramEventDispatchChain.dispatchEvent(paramEvent); }  return (EventDispatcher)paramEventDispatcher2.dispatchEvent(paramEvent, paramEventDispatchChain); }); EventDispatcher eventDispatcher3 = this.vbar.getEventDispatcher(); this.vbar.setEventDispatcher((paramEvent, paramEventDispatchChain) -> { if (paramEvent.getEventType() == ScrollEvent.SCROLL && !((ScrollEvent)paramEvent).isDirect()) { paramEventDispatchChain = paramEventDispatchChain.prepend(paramEventDispatcher1); paramEventDispatchChain = paramEventDispatchChain.prepend(paramEventDispatcher2); return (EventDispatcher)paramEventDispatchChain.dispatchEvent(paramEvent); }  return (EventDispatcher)paramEventDispatcher2.dispatchEvent(paramEvent, paramEventDispatchChain); }); setOnScroll(new EventHandler<ScrollEvent>() { public void handle(ScrollEvent param1ScrollEvent) { if (Properties.IS_TOUCH_SUPPORTED && !VirtualFlow.this.touchDetected && !VirtualFlow.this.mouseDown) VirtualFlow.this.startSBReleasedAnimation();  double d = 0.0D; if (VirtualFlow.this.isVertical()) { double d1; switch (param1ScrollEvent.getTextDeltaYUnits()) { case PREVIOUS: d = param1ScrollEvent.getTextDeltaY() * VirtualFlow.this.lastHeight; break;case NEXT: if (VirtualFlow.this.fixedCellSizeEnabled) { d1 = VirtualFlow.this.getFixedCellSize(); } else { IndexedCell indexedCell = VirtualFlow.this.cells.getLast(); d1 = (VirtualFlow.this.getCellPosition(indexedCell) + VirtualFlow.this.getCellLength(indexedCell) - VirtualFlow.this.getCellPosition(VirtualFlow.this.cells.getFirst())) / VirtualFlow.this.cells.size(); }  if (VirtualFlow.this.lastHeight / d1 < 8.0D) d1 = VirtualFlow.this.lastHeight / 8.0D;  d = param1ScrollEvent.getTextDeltaY() * d1; break;case NEXT_IN_LINE: d = param1ScrollEvent.getDeltaY(); break; }  } else { double d1; double d2; switch (param1ScrollEvent.getTextDeltaXUnits()) { case PREVIOUS: case NEXT: d1 = param1ScrollEvent.getDeltaX(); d2 = param1ScrollEvent.getDeltaY(); d = (Math.abs(d1) > Math.abs(d2)) ? d1 : d2; break; }  }  if (d != 0.0D) { double d1 = VirtualFlow.this.scrollPixels(-d); if (d1 != 0.0D) param1ScrollEvent.consume();  }  VirtualScrollBar virtualScrollBar = VirtualFlow.this.isVertical() ? VirtualFlow.this.hbar : VirtualFlow.this.vbar; if (VirtualFlow.this.needBreadthBar) { double d1 = VirtualFlow.this.isVertical() ? param1ScrollEvent.getDeltaX() : param1ScrollEvent.getDeltaY(); if (d1 != 0.0D) { double d2 = virtualScrollBar.getValue() - d1; if (d2 < virtualScrollBar.getMin()) { virtualScrollBar.setValue(virtualScrollBar.getMin()); } else if (d2 > virtualScrollBar.getMax()) { virtualScrollBar.setValue(virtualScrollBar.getMax()); } else { virtualScrollBar.setValue(d2); }  param1ScrollEvent.consume(); }  }  } }
/*      */       ); addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>() { public void handle(MouseEvent param1MouseEvent) { VirtualFlow.this.mouseDown = true; if (Properties.IS_TOUCH_SUPPORTED) VirtualFlow.this.scrollBarOn();  if (VirtualFlow.this.isFocusTraversable()) { boolean bool = true; Node node = VirtualFlow.this.getScene().getFocusOwner(); if (node != null) { Parent parent = node.getParent(); while (parent != null) { if (parent.equals(VirtualFlow.this)) { bool = false; break; }  parent = parent.getParent(); }  }  if (bool) VirtualFlow.this.requestFocus();  }  VirtualFlow.this.lastX = param1MouseEvent.getX(); VirtualFlow.this.lastY = param1MouseEvent.getY(); VirtualFlow.this.isPanning = (!VirtualFlow.this.vbar.getBoundsInParent().contains(param1MouseEvent.getX(), param1MouseEvent.getY()) && !VirtualFlow.this.hbar.getBoundsInParent().contains(param1MouseEvent.getX(), param1MouseEvent.getY())); } }
/*      */       ); addEventFilter(MouseEvent.MOUSE_RELEASED, paramMouseEvent -> { this.mouseDown = false; if (Properties.IS_TOUCH_SUPPORTED) startSBReleasedAnimation();  }); addEventFilter(MouseEvent.MOUSE_DRAGGED, paramMouseEvent -> { if (Properties.IS_TOUCH_SUPPORTED) scrollBarOn();  if (!this.isPanning || !isPannable()) return;  double d1 = this.lastX - paramMouseEvent.getX(); double d2 = this.lastY - paramMouseEvent.getY(); double d3 = isVertical() ? d2 : d1; double d4 = scrollPixels(d3); if (d4 != 0.0D) if (isVertical()) { this.lastY = paramMouseEvent.getY(); } else { this.lastX = paramMouseEvent.getX(); }   double d5 = isVertical() ? d1 : d2; VirtualScrollBar virtualScrollBar = isVertical() ? this.hbar : this.vbar; if (virtualScrollBar.isVisible()) { double d = virtualScrollBar.getValue() + d5; if (d < virtualScrollBar.getMin()) { virtualScrollBar.setValue(virtualScrollBar.getMin()); } else if (d > virtualScrollBar.getMax()) { virtualScrollBar.setValue(virtualScrollBar.getMax()); } else { virtualScrollBar.setValue(d); if (isVertical()) { this.lastX = paramMouseEvent.getX(); } else { this.lastY = paramMouseEvent.getY(); }  }  }  }); this.vbar.setOrientation(Orientation.VERTICAL); this.vbar.addEventHandler(MouseEvent.ANY, paramMouseEvent -> paramMouseEvent.consume()); getChildren().add(this.vbar); this.hbar.setOrientation(Orientation.HORIZONTAL); this.hbar.addEventHandler(MouseEvent.ANY, paramMouseEvent -> paramMouseEvent.consume()); getChildren().add(this.hbar); this.corner = new StackPane(); this.corner.getStyleClass().setAll(new String[] { "corner" }); getChildren().add(this.corner); InvalidationListener invalidationListener = paramObservable -> updateHbar(); verticalProperty().addListener(invalidationListener); this.hbar.valueProperty().addListener(invalidationListener); this.hbar.visibleProperty().addListener(invalidationListener); ChangeListener<? super Number> changeListener = (paramObservableValue, paramNumber1, paramNumber2) -> this.clipView.setClipY(isVertical() ? 0.0D : this.vbar.getValue()); this.vbar.valueProperty().addListener(changeListener); heightProperty().addListener((paramObservableValue, paramNumber1, paramNumber2) -> { if (paramNumber1.doubleValue() == 0.0D && paramNumber2.doubleValue() > 0.0D) recreateCells();  }); setOnTouchPressed(paramTouchEvent -> { this.touchDetected = true; scrollBarOn(); }); setOnTouchReleased(paramTouchEvent -> { this.touchDetected = false; startSBReleasedAnimation(); }); ParentHelper.setTraversalEngine(this, new ParentTraversalEngine(this, new Algorithm() { Node selectNextAfterIndex(int param1Int, TraversalContext param1TraversalContext) { IndexedCell indexedCell; while ((indexedCell = (IndexedCell)VirtualFlow.this.getVisibleCell(++param1Int)) != null) { if (indexedCell.isFocusTraversable()) return indexedCell;  Node node = param1TraversalContext.selectFirstInParent(indexedCell); if (node != null) return node;  }  return null; } Node selectPreviousBeforeIndex(int param1Int, TraversalContext param1TraversalContext) { Parent parent; while ((parent = (Parent)VirtualFlow.this.getVisibleCell(--param1Int)) != null) { Node node = param1TraversalContext.selectLastInParent(parent); if (node != null) return node;  if (parent.isFocusTraversable()) return parent;  }  return null; } public Node select(Node param1Node, Direction param1Direction, TraversalContext param1TraversalContext) { T t; Node node; if (VirtualFlow.this.cells.isEmpty()) return null;  if (VirtualFlow.this.cells.contains(param1Node)) { IndexedCell indexedCell = (IndexedCell)param1Node; } else { t = findOwnerCell(param1Node); Node node1 = param1TraversalContext.selectInSubtree((Parent)t, param1Node, param1Direction); if (node1 != null) return node1;  if (param1Direction == Direction.NEXT) param1Direction = Direction.NEXT_IN_LINE;  }  int i = t.getIndex(); switch (param1Direction) { case PREVIOUS: return selectPreviousBeforeIndex(i, param1TraversalContext);case NEXT: node = param1TraversalContext.selectFirstInParent((Parent)t); if (node != null) return node; case NEXT_IN_LINE: return selectNextAfterIndex(i, param1TraversalContext); }  return null; } private T findOwnerCell(Node param1Node) { Parent parent = param1Node.getParent(); while (!VirtualFlow.this.cells.contains(parent)) parent = parent.getParent();  return (T)parent; } public Node selectFirst(TraversalContext param1TraversalContext) { IndexedCell indexedCell = VirtualFlow.this.cells.getFirst(); if (indexedCell == null) return null;  if (indexedCell.isFocusTraversable()) return indexedCell;  Node node = param1TraversalContext.selectFirstInParent(indexedCell); if (node != null) return node;  return selectNextAfterIndex(indexedCell.getIndex(), param1TraversalContext); } public Node selectLast(TraversalContext param1TraversalContext) { IndexedCell indexedCell = VirtualFlow.this.cells.getLast(); if (indexedCell == null) return null;  Node node = param1TraversalContext.selectLastInParent(indexedCell); if (node != null) return node;  if (indexedCell.isFocusTraversable()) return indexedCell;  return selectPreviousBeforeIndex(indexedCell.getIndex(), param1TraversalContext); } }
/* 2540 */         )); } public void scrollTo(int paramInt) { T t = getVisibleCell(paramInt); if (t != null) { scrollTo(t); } else { adjustPositionToIndex(paramInt); addAllToPile(); requestLayout(); }  } public void scrollToTop(int paramInt) { boolean bool = false; if (paramInt >= getCellCount() - 1) { setPosition(1.0D); bool = true; } else if (paramInt < 0) { setPosition(0.0D); bool = true; }  if (!bool) { adjustPositionToIndex(paramInt); double d = -computeOffsetForCell(paramInt); adjustByPixelAmount(d); }  requestLayout(); } public double scrollPixels(double paramDouble) { if (paramDouble == 0.0D) return 0.0D;  boolean bool = isVertical(); if ((bool && (this.tempVisibility ? !this.needLengthBar : !this.vbar.isVisible())) || (!bool && (this.tempVisibility ? !this.needLengthBar : !this.hbar.isVisible()))) return 0.0D;  double d = getPosition(); if (d == 0.0D && paramDouble < 0.0D) return 0.0D;  if (d == 1.0D && paramDouble > 0.0D) return 0.0D;  adjustByPixelAmount(paramDouble); if (d == getPosition()) return 0.0D;  if (this.cells.size() > 0) { for (byte b = 0; b < this.cells.size(); b++) { IndexedCell indexedCell1 = (IndexedCell)this.cells.get(b); assert indexedCell1 != null; positionCell((T)indexedCell1, getCellPosition((T)indexedCell1) - paramDouble); }  IndexedCell indexedCell = (IndexedCell)this.cells.getFirst(); double d1 = (indexedCell == null) ? 0.0D : getCellPosition((T)indexedCell); int i; for (i = 0; i < this.cells.size(); i++) { IndexedCell indexedCell1 = (IndexedCell)this.cells.get(i); assert indexedCell1 != null; double d2 = getCellPosition((T)indexedCell1); if (Math.abs(d2 - d1) > 0.001D) positionCell((T)indexedCell1, d1);  d1 += getCellLength((T)indexedCell1); }  cull(); indexedCell = (IndexedCell)this.cells.getFirst(); if (indexedCell != null) { i = getCellIndex((T)indexedCell); double d2 = getCellLength(i - 1); addLeadingCells(i - 1, getCellPosition((T)indexedCell) - d2); } else { i = computeCurrentIndex(); double d2 = -computeViewportOffset(getPosition()); addLeadingCells(i, d2); }  if (!addTrailingCells(false)) { i = getLastVisibleCell(); double d2 = getCellLength(i); double d3 = getCellPosition(i) + d2; double d4 = getViewportLength(); if (d3 < d4) { double d5 = d4 - d3; int j; for (j = 0; j < this.cells.size(); j++) { IndexedCell indexedCell1 = (IndexedCell)this.cells.get(j); positionCell((T)indexedCell1, getCellPosition((T)indexedCell1) + d5); }  setPosition(1.0D); indexedCell = (IndexedCell)this.cells.getFirst(); j = getCellIndex((T)indexedCell); double d6 = getCellLength(j - 1); addLeadingCells(j - 1, getCellPosition((T)indexedCell) - d6); }  }  }  cull(); updateScrollBarsAndCells(false); this.lastPosition = getPosition(); return paramDouble; } protected double computePrefWidth(double paramDouble) { double d = isVertical() ? getPrefBreadth(paramDouble) : getPrefLength(); return d + this.vbar.prefWidth(-1.0D); } protected double computePrefHeight(double paramDouble) { double d = isVertical() ? getPrefLength() : getPrefBreadth(paramDouble); return d + this.hbar.prefHeight(-1.0D); } public T getCell(int paramInt) { if (!this.cells.isEmpty()) { T t = getVisibleCell(paramInt); if (t != null) return t;  }  for (byte b = 0; b < this.pile.size(); b++) { IndexedCell indexedCell = (IndexedCell)this.pile.get(b); if (getCellIndex((T)indexedCell) == paramInt) return (T)indexedCell;  }  if (this.pile.size() > 0) return this.pile.get(0);  if (this.accumCell == null) { Callback<VirtualFlow<T>, T> callback = getCellFactory(); if (callback != null) { this.accumCell = callback.call(this); this.accumCell.getProperties().put("newcell", null); this.accumCellParent.getChildren().setAll(new Node[] { (Node)this.accumCell }); this.accumCell.setAccessibleRole(AccessibleRole.NODE); this.accumCell.getChildrenUnmodifiable().addListener(paramObservable -> { for (Node node : this.accumCell.getChildrenUnmodifiable()) node.setAccessibleRole(AccessibleRole.NODE);  }); }  }  setCellIndex(this.accumCell, paramInt); resizeCellSize(this.accumCell); return this.accumCell; } protected void setCellIndex(T paramT, int paramInt) { assert paramT != null; paramT.updateIndex(paramInt); if ((paramT.isNeedsLayout() && paramT.getScene() != null) || paramT.getProperties().containsKey("newcell")) { paramT.applyCss(); paramT.getProperties().remove("newcell"); }  } protected int getCellIndex(T paramT) { return paramT.getIndex(); } private void releaseAllPrivateCells() { this.sheetChildren.removeAll(this.privateCells);
/* 2541 */     this.privateCells.clear(); } final VirtualScrollBar getHbar() { return this.hbar; } final VirtualScrollBar getVbar() { return this.vbar; } private final void setMaxPrefBreadth(double paramDouble) { this.maxPrefBreadth = paramDouble; } final double getMaxPrefBreadth() { return this.maxPrefBreadth; } private final void setViewportBreadth(double paramDouble) { this.viewportBreadth = paramDouble; } private final double getViewportBreadth() { return this.viewportBreadth; } void setViewportLength(double paramDouble) { this.viewportLength = paramDouble; } double getViewportLength() { return this.viewportLength; } double getCellLength(int paramInt) { if (this.fixedCellSizeEnabled) return getFixedCellSize();  T t = getCell(paramInt); double d = getCellLength(t); releaseCell(t); return d; } double getCellBreadth(int paramInt) { T t = getCell(paramInt); double d = getCellBreadth((Cell)t); releaseCell(t); return d; } double getCellLength(T paramT) { if (paramT == null) return 0.0D;  if (this.fixedCellSizeEnabled) return getFixedCellSize();  return isVertical() ? paramT.getLayoutBounds().getHeight() : paramT.getLayoutBounds().getWidth(); } double getCellBreadth(Cell paramCell) { return isVertical() ? paramCell.prefWidth(-1.0D) : paramCell.prefHeight(-1.0D); } double getCellPosition(T paramT) { if (paramT == null) return 0.0D;  return isVertical() ? paramT.getLayoutY() : paramT.getLayoutX(); } private void positionCell(T paramT, double paramDouble) { if (isVertical()) { paramT.setLayoutX(0.0D); paramT.setLayoutY(snapSizeY(paramDouble)); } else { paramT.setLayoutX(snapSizeX(paramDouble)); paramT.setLayoutY(0.0D); }  } private void resizeCellSize(T paramT) { if (paramT == null) return;  if (isVertical()) { double d = Math.max(getMaxPrefBreadth(), getViewportBreadth()); paramT.resize(d, this.fixedCellSizeEnabled ? getFixedCellSize() : Utils.boundedSize(paramT.prefHeight(d), paramT.minHeight(d), paramT.maxHeight(d))); } else { double d = Math.max(getMaxPrefBreadth(), getViewportBreadth()); paramT.resize(this.fixedCellSizeEnabled ? getFixedCellSize() : Utils.boundedSize(paramT.prefWidth(d), paramT.minWidth(d), paramT.maxWidth(d)), d); }  } private List<T> getCells() { return this.cells; } T getLastVisibleCellWithinViewPort() { if (this.cells.isEmpty() || getViewportLength() <= 0.0D) return null;  double d = getViewportLength(); for (int i = this.cells.size() - 1; i >= 0; i--) { IndexedCell indexedCell = (IndexedCell)this.cells.get(i); if (!indexedCell.isEmpty()) { double d1 = getCellPosition((T)indexedCell); double d2 = d1 + getCellLength((T)indexedCell); if (d2 <= d + 2.0D) return (T)indexedCell;  }  }  return null; } T getFirstVisibleCellWithinViewPort() { if (this.cells.isEmpty() || getViewportLength() <= 0.0D) return null;  for (byte b = 0; b < this.cells.size(); b++) { IndexedCell indexedCell = (IndexedCell)this.cells.get(b); if (!indexedCell.isEmpty()) { double d = getCellPosition((T)indexedCell); if (d >= 0.0D) return (T)indexedCell;  }  }  return null; } void addLeadingCells(int paramInt, double paramDouble) { double d = paramDouble; int i = paramInt; boolean bool = true; T t = null; if (i == getCellCount() && d == getViewportLength()) { i--; bool = false; }  while (i >= 0 && (d > 0.0D || bool)) { t = getAvailableCell(i); setCellIndex(t, i); resizeCellSize(t); this.cells.addFirst(t); if (bool) { bool = false; } else { d -= getCellLength(t); }  positionCell(t, d); setMaxPrefBreadth(Math.max(getMaxPrefBreadth(), getCellBreadth((Cell)t))); t.setVisible(true); i--; }  if (this.cells.size() > 0) { IndexedCell indexedCell = (IndexedCell)this.cells.getFirst(); int j = getCellIndex((T)indexedCell); double d1 = getCellPosition((T)indexedCell); if (j == 0 && d1 > 0.0D) { setPosition(0.0D); d = 0.0D; for (byte b = 0; b < this.cells.size(); b++) { indexedCell = (IndexedCell)this.cells.get(b); positionCell((T)indexedCell, d); d += getCellLength((T)indexedCell); }  }  } else { this.vbar.setValue(0.0D); this.hbar.setValue(0.0D); }  } boolean addTrailingCells(boolean paramBoolean) { if (this.cells.isEmpty()) return false;  IndexedCell indexedCell1 = (IndexedCell)this.cells.getLast(); double d1 = getCellPosition((T)indexedCell1) + getCellLength((T)indexedCell1); int i = getCellIndex((T)indexedCell1) + 1; int j = getCellCount(); boolean bool = (i <= j) ? true : false; double d2 = getViewportLength(); if (d1 < 0.0D && !paramBoolean) return false;  double d3 = d2; while (d1 < d2) { if (i >= j) { if (d1 < d2) bool = false;  if (!paramBoolean) return bool;  if (i > d3) { PlatformLogger platformLogger = Logging.getControlsLogger(); if (platformLogger.isLoggable(PlatformLogger.Level.INFO)) platformLogger.info("index exceeds maxCellCount. Check size calculations for " + indexedCell1.getClass());  return bool; }  }  T t1 = getAvailableCell(i); setCellIndex(t1, i); resizeCellSize(t1); this.cells.addLast(t1); positionCell(t1, d1); setMaxPrefBreadth(Math.max(getMaxPrefBreadth(), getCellBreadth((Cell)t1))); d1 += getCellLength(t1); t1.setVisible(true); i++; }  IndexedCell indexedCell2 = (IndexedCell)this.cells.getFirst(); i = getCellIndex((T)indexedCell2); T t = getLastVisibleCell(); double d4 = getCellPosition((T)indexedCell2); double d5 = getCellPosition(t) + getCellLength(t); if ((i != 0 || (i == 0 && d4 < 0.0D)) && paramBoolean && t != null && getCellIndex(t) == j - 1 && d5 < d2) { double d6 = d5; double d7 = d2 - d5; while (d6 < d2 && i != 0 && -d4 < d7) { i--; T t1 = getAvailableCell(i); setCellIndex(t1, i); resizeCellSize(t1); this.cells.addFirst(t1); double d = getCellLength(t1); d4 -= d; d6 += d; positionCell(t1, d4); setMaxPrefBreadth(Math.max(getMaxPrefBreadth(), getCellBreadth((Cell)t1))); t1.setVisible(true); }  indexedCell2 = (IndexedCell)this.cells.getFirst(); d4 = getCellPosition((T)indexedCell2); double d8 = d2 - d5; if (getCellIndex((T)indexedCell2) == 0 && d8 > -d4) d8 = -d4;  for (byte b = 0; b < this.cells.size(); b++) { IndexedCell indexedCell = (IndexedCell)this.cells.get(b); positionCell((T)indexedCell, getCellPosition((T)indexedCell) + d8); }  d4 = getCellPosition((T)indexedCell2); if (getCellIndex((T)indexedCell2) == 0 && d4 == 0.0D) { setPosition(0.0D); } else if (getPosition() != 1.0D) { setPosition(1.0D); }  }  return bool; } void reconfigureCells() { this.needsReconfigureCells = true; requestLayout(); } void recreateCells() { this.needsRecreateCells = true; requestLayout(); } void rebuildCells() { this.needsRebuildCells = true; requestLayout(); } void requestCellLayout() { this.needsCellsLayout = true; requestLayout(); } void setCellDirty(int paramInt) { this.dirtyCells.set(paramInt); requestLayout(); } private void startSBReleasedAnimation() { if (this.sbTouchTimeline == null) { this.sbTouchTimeline = new Timeline(); this.sbTouchKF1 = new KeyFrame(Duration.millis(0.0D), paramActionEvent -> { this.tempVisibility = true; requestLayout(); }new javafx.animation.KeyValue[0]); this.sbTouchKF2 = new KeyFrame(Duration.millis(1000.0D), paramActionEvent -> { if (!this.touchDetected && !this.mouseDown) { this.tempVisibility = false; requestLayout(); }  }new javafx.animation.KeyValue[0]); this.sbTouchTimeline.getKeyFrames().addAll(new KeyFrame[] { this.sbTouchKF1, this.sbTouchKF2 }); }  this.sbTouchTimeline.playFromStart(); } private void scrollBarOn() { this.tempVisibility = true; requestLayout(); } void updateHbar() { if (!isVisible() || getScene() == null) return;  if (isVertical()) if (this.hbar.isVisible()) { this.clipView.setClipX(this.hbar.getValue()); } else { this.clipView.setClipX(0.0D); this.hbar.setValue(0.0D); }   } private boolean computeBarVisiblity() { if (this.cells.isEmpty()) { this.needLengthBar = false; this.needBreadthBar = false; return true; }  boolean bool = isVertical(); boolean bool1 = false; VirtualScrollBar virtualScrollBar1 = bool ? this.hbar : this.vbar; VirtualScrollBar virtualScrollBar2 = bool ? this.vbar : this.hbar; double d = getViewportBreadth(); int i = this.cells.size(); int j = getCellCount(); for (byte b = 0; b < 2; b++) { boolean bool2 = (getPosition() > 0.0D || j > i || (j == i && getCellPosition(this.cells.getLast()) + getCellLength(this.cells.getLast()) > getViewportLength()) || (j == i - 1 && bool1 && this.needBreadthBar)); if (bool2 ^ this.needLengthBar) { this.needLengthBar = bool2; bool1 = true; }  boolean bool3 = (this.maxPrefBreadth > d); if (bool3 ^ this.needBreadthBar) { this.needBreadthBar = bool3; bool1 = true; }  }  if (!Properties.IS_TOUCH_SUPPORTED) { updateViewportDimensions(); virtualScrollBar1.setVisible(this.needBreadthBar); virtualScrollBar2.setVisible(this.needLengthBar); } else { virtualScrollBar1.setVisible((this.needBreadthBar && this.tempVisibility)); virtualScrollBar2.setVisible((this.needLengthBar && this.tempVisibility)); }  return bool1; }
/*      */   private void updateViewportDimensions() { boolean bool = isVertical(); double d1 = bool ? snapSizeY(this.hbar.prefHeight(-1.0D)) : snapSizeX(this.vbar.prefWidth(-1.0D)); double d2 = bool ? snapSizeX(this.vbar.prefWidth(-1.0D)) : snapSizeY(this.hbar.prefHeight(-1.0D)); setViewportBreadth((bool ? getWidth() : getHeight()) - (this.needLengthBar ? d2 : 0.0D)); setViewportLength((bool ? getHeight() : getWidth()) - (this.needBreadthBar ? d1 : 0.0D)); }
/*      */   private void initViewport() { boolean bool = isVertical(); updateViewportDimensions(); VirtualScrollBar virtualScrollBar1 = bool ? this.hbar : this.vbar; VirtualScrollBar virtualScrollBar2 = bool ? this.vbar : this.hbar; virtualScrollBar1.setVirtual(false); virtualScrollBar2.setVirtual(true); }
/*      */   private void updateScrollBarsAndCells(boolean paramBoolean) { boolean bool = isVertical(); VirtualScrollBar virtualScrollBar1 = bool ? this.hbar : this.vbar; VirtualScrollBar virtualScrollBar2 = bool ? this.vbar : this.hbar; fitCells(); if (!this.cells.isEmpty()) { double d5 = -computeViewportOffset(getPosition()); int i = computeCurrentIndex() - ((IndexedCell)this.cells.getFirst()).getIndex(); int j = this.cells.size(); double d6 = d5; int k; for (k = i - 1; k >= 0 && k < j; k--) { IndexedCell indexedCell = (IndexedCell)this.cells.get(k); d6 -= getCellLength((T)indexedCell); positionCell((T)indexedCell, d6); }  d6 = d5; for (k = i; k >= 0 && k < j; k++) { IndexedCell indexedCell = (IndexedCell)this.cells.get(k); positionCell((T)indexedCell, d6); d6 += getCellLength((T)indexedCell); }  }  this.corner.setVisible((virtualScrollBar1.isVisible() && virtualScrollBar2.isVisible())); double d1 = 0.0D; double d2 = (bool ? getHeight() : getWidth()) - (virtualScrollBar1.isVisible() ? virtualScrollBar1.prefHeight(-1.0D) : 0.0D); double d3 = getViewportBreadth(); double d4 = getViewportLength(); if (virtualScrollBar1.isVisible()) { if (!Properties.IS_TOUCH_SUPPORTED) { if (bool) { this.hbar.resizeRelocate(0.0D, d4, d3, this.hbar.prefHeight(d3)); } else { this.vbar.resizeRelocate(d4, 0.0D, this.vbar.prefWidth(d3), d3); }  } else if (bool) { this.hbar.resizeRelocate(0.0D, d4 - this.hbar.getHeight(), d3, this.hbar.prefHeight(d3)); } else { this.vbar.resizeRelocate(d4 - this.vbar.getWidth(), 0.0D, this.vbar.prefWidth(d3), d3); }  if (getMaxPrefBreadth() != -1.0D) { double d = Math.max(1.0D, getMaxPrefBreadth() - d3); if (d != virtualScrollBar1.getMax()) { virtualScrollBar1.setMax(d); double d5 = virtualScrollBar1.getValue(); boolean bool1 = (d5 != 0.0D && d == d5) ? true : false; if (bool1 || d5 > d) virtualScrollBar1.setValue(d);  virtualScrollBar1.setVisibleAmount(d3 / getMaxPrefBreadth() * d); }  }  }  if (paramBoolean && (virtualScrollBar2.isVisible() || Properties.IS_TOUCH_SUPPORTED)) { int i = getCellCount(); byte b1 = 0; byte b2; int j; for (b2 = 0, j = this.cells.size(); b2 < j; b2++) { IndexedCell indexedCell = (IndexedCell)this.cells.get(b2); if (indexedCell != null && !indexedCell.isEmpty()) { d1 += bool ? indexedCell.getHeight() : indexedCell.getWidth(); if (d1 > d2) break;  b1++; }  }  virtualScrollBar2.setMax(1.0D); if (b1 == 0 && i == 1) { virtualScrollBar2.setVisibleAmount(d2 / d1); } else { virtualScrollBar2.setVisibleAmount((b1 / i)); }  }  if (virtualScrollBar2.isVisible()) if (!Properties.IS_TOUCH_SUPPORTED) { if (bool) { this.vbar.resizeRelocate(d3, 0.0D, this.vbar.prefWidth(d4), d4); } else { this.hbar.resizeRelocate(0.0D, d3, d4, this.hbar.prefHeight(-1.0D)); }  } else if (bool) { this.vbar.resizeRelocate(d3 - this.vbar.getWidth(), 0.0D, this.vbar.prefWidth(d4), d4); } else { this.hbar.resizeRelocate(0.0D, d3 - this.hbar.getHeight(), d4, this.hbar.prefHeight(-1.0D)); }   if (this.corner.isVisible()) if (!Properties.IS_TOUCH_SUPPORTED) { this.corner.resize(this.vbar.getWidth(), this.hbar.getHeight()); this.corner.relocate(this.hbar.getLayoutX() + this.hbar.getWidth(), this.vbar.getLayoutY() + this.vbar.getHeight()); } else { this.corner.resize(this.vbar.getWidth(), this.hbar.getHeight()); this.corner.relocate(this.hbar.getLayoutX() + this.hbar.getWidth() - this.vbar.getWidth(), this.vbar.getLayoutY() + this.vbar.getHeight() - this.hbar.getHeight()); this.hbar.resize(this.hbar.getWidth() - this.vbar.getWidth(), this.hbar.getHeight()); this.vbar.resize(this.vbar.getWidth(), this.vbar.getHeight() - this.hbar.getHeight()); }   this.clipView.resize(snapSizeX(bool ? d3 : d4), snapSizeY(bool ? d4 : d3)); if (getPosition() != virtualScrollBar2.getValue()) virtualScrollBar2.setValue(getPosition());  }
/*      */   private void fitCells() { double d = Math.max(getMaxPrefBreadth(), getViewportBreadth()); boolean bool = isVertical(); for (byte b = 0; b < this.cells.size(); b++) { Cell cell = (Cell)this.cells.get(b); if (bool) { cell.resize(d, cell.prefHeight(d)); } else { cell.resize(cell.prefWidth(d), d); }  }  }
/*      */   private void cull() { double d = getViewportLength(); for (int i = this.cells.size() - 1; i >= 0; i--) { IndexedCell indexedCell = (IndexedCell)this.cells.get(i); double d1 = getCellLength((T)indexedCell); double d2 = getCellPosition((T)indexedCell); double d3 = d2 + d1; if (d2 >= d || d3 < 0.0D) addToPile(this.cells.remove(i));  }  }
/*      */   private void releaseCell(T paramT) { if (this.accumCell != null && paramT == this.accumCell) this.accumCell.updateIndex(-1);  }
/*      */   T getPrivateCell(int paramInt) { IndexedCell indexedCell; T t = null; if (!this.cells.isEmpty()) { t = getVisibleCell(paramInt); if (t != null) { t.layout(); return t; }  }  if (t == null) for (byte b = 0; b < this.sheetChildren.size(); b++) { IndexedCell indexedCell1 = (IndexedCell)this.sheetChildren.get(b); if (getCellIndex((T)indexedCell1) == paramInt) return (T)indexedCell1;  }   Callback<VirtualFlow<T>, T> callback = getCellFactory(); if (callback != null) indexedCell = (IndexedCell)callback.call(this);  if (indexedCell != null) { setCellIndex((T)indexedCell, paramInt); resizeCellSize((T)indexedCell); indexedCell.setVisible(false); this.sheetChildren.add(indexedCell); this.privateCells.add((T)indexedCell); }  return (T)indexedCell; }
/* 2549 */   private void addToPile(T paramT) { assert paramT != null;
/* 2550 */     this.pile.addLast(paramT); }
/*      */ 
/*      */   
/*      */   private void cleanPile() {
/* 2554 */     boolean bool = false; byte b;
/*      */     int i;
/* 2556 */     for (b = 0, i = this.pile.size(); b < i; b++) {
/* 2557 */       IndexedCell<?> indexedCell = (IndexedCell)this.pile.get(b);
/* 2558 */       bool = (bool || doesCellContainFocus(indexedCell)) ? true : false;
/* 2559 */       indexedCell.setVisible(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2565 */     if (bool) {
/* 2566 */       requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean doesCellContainFocus(Cell<?> paramCell) {
/* 2571 */     Scene scene = paramCell.getScene();
/* 2572 */     Node node = (scene == null) ? null : scene.getFocusOwner();
/*      */     
/* 2574 */     if (node != null) {
/* 2575 */       if (paramCell.equals(node)) {
/* 2576 */         return true;
/*      */       }
/*      */       
/* 2579 */       Parent parent = node.getParent();
/* 2580 */       while (parent != null && !(parent instanceof VirtualFlow)) {
/* 2581 */         if (paramCell.equals(parent)) {
/* 2582 */           return true;
/*      */         }
/* 2584 */         parent = parent.getParent();
/*      */       } 
/*      */     } 
/*      */     
/* 2588 */     return false;
/*      */   }
/*      */   
/*      */   private double getPrefBreadth(double paramDouble) {
/* 2592 */     double d = getMaxCellWidth(10);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2598 */     if (paramDouble > -1.0D) {
/* 2599 */       double d1 = getPrefLength();
/* 2600 */       d = Math.max(d, d1 * 0.618033987D);
/*      */     } 
/*      */     
/* 2603 */     return d;
/*      */   }
/*      */   
/*      */   private double getPrefLength() {
/* 2607 */     double d = 0.0D;
/* 2608 */     int i = Math.min(10, getCellCount());
/* 2609 */     for (byte b = 0; b < i; b++) {
/* 2610 */       d += getCellLength(b);
/*      */     }
/* 2612 */     return d;
/*      */   }
/*      */   
/*      */   double getMaxCellWidth(int paramInt) {
/* 2616 */     double d = 0.0D;
/*      */ 
/*      */     
/* 2619 */     int i = Math.max(1, (paramInt == -1) ? getCellCount() : paramInt);
/* 2620 */     for (byte b = 0; b < i; b++) {
/* 2621 */       d = Math.max(d, getCellBreadth(b));
/*      */     }
/* 2623 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double computeViewportOffset(double paramDouble) {
/* 2635 */     double d1 = Utils.clamp(0.0D, paramDouble, 1.0D);
/* 2636 */     double d2 = d1 * getCellCount();
/* 2637 */     int i = (int)d2;
/* 2638 */     double d3 = d2 - i;
/* 2639 */     double d4 = getCellLength(i);
/* 2640 */     double d5 = d4 * d3;
/* 2641 */     double d6 = getViewportLength() * d1;
/* 2642 */     return d5 - d6;
/*      */   }
/*      */   
/*      */   private void adjustPositionToIndex(int paramInt) {
/* 2646 */     int i = getCellCount();
/* 2647 */     if (i <= 0) {
/* 2648 */       setPosition(0.0D);
/*      */     } else {
/* 2650 */       setPosition(paramInt / i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void adjustByPixelAmount(double paramDouble) {
/* 2662 */     if (paramDouble == 0.0D) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2672 */     boolean bool = (paramDouble > 0.0D) ? true : false;
/* 2673 */     int i = getCellCount();
/* 2674 */     double d1 = getPosition() * i;
/* 2675 */     int j = (int)d1;
/* 2676 */     if (bool && j == i)
/* 2677 */       return;  double d2 = getCellLength(j);
/* 2678 */     double d3 = d1 - j;
/* 2679 */     double d4 = d2 * d3;
/*      */ 
/*      */     
/* 2682 */     double d5 = 1.0D / i;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2688 */     double d6 = computeOffsetForCell(j);
/* 2689 */     double d7 = d2 + computeOffsetForCell(j + 1);
/*      */ 
/*      */ 
/*      */     
/* 2693 */     double d8 = d7 - d6;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2698 */     double d9 = bool ? (paramDouble + d4 - getViewportLength() * getPosition() - d6) : (-paramDouble + d7 - d4 - getViewportLength() * getPosition());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2704 */     double d10 = d5 * j;
/*      */ 
/*      */ 
/*      */     
/* 2708 */     while (d9 > d8 && ((bool && j < i - 1) || (!bool && j > 0))) {
/* 2709 */       if (bool) { j++; } else { j--; }
/* 2710 */        d9 -= d8;
/* 2711 */       d2 = getCellLength(j);
/* 2712 */       d6 = computeOffsetForCell(j);
/* 2713 */       d7 = d2 + computeOffsetForCell(j + 1);
/* 2714 */       d8 = d7 - d6;
/* 2715 */       d10 = d5 * j;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2721 */     if (d9 > d8) {
/* 2722 */       setPosition(bool ? 1.0D : 0.0D);
/* 2723 */     } else if (bool) {
/* 2724 */       double d = d5 / Math.abs(d7 - d6);
/* 2725 */       setPosition(d10 + d * d9);
/*      */     } else {
/* 2727 */       double d = d5 / Math.abs(d7 - d6);
/* 2728 */       setPosition(d10 + d5 - d * d9);
/*      */     } 
/*      */   }
/*      */   
/*      */   private int computeCurrentIndex() {
/* 2733 */     return (int)(getPosition() * getCellCount());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double computeOffsetForCell(int paramInt) {
/* 2744 */     double d1 = getCellCount();
/* 2745 */     double d2 = Utils.clamp(0.0D, paramInt, d1) / d1;
/* 2746 */     return -(getViewportLength() * d2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ClippedContainer
/*      */     extends Region
/*      */   {
/*      */     private Node node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Rectangle clipRect;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Node getNode() {
/* 2778 */       return this.node;
/*      */     } public void setNode(Node param1Node) {
/* 2780 */       this.node = param1Node;
/*      */       
/* 2782 */       getChildren().clear();
/* 2783 */       getChildren().add(this.node);
/*      */     }
/*      */     
/*      */     public void setClipX(double param1Double) {
/* 2787 */       setLayoutX(-param1Double);
/* 2788 */       this.clipRect.setLayoutX(param1Double);
/*      */     }
/*      */     
/*      */     public void setClipY(double param1Double) {
/* 2792 */       setLayoutY(-param1Double);
/* 2793 */       this.clipRect.setLayoutY(param1Double);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public ClippedContainer(VirtualFlow<?> param1VirtualFlow) {
/* 2799 */       if (param1VirtualFlow == null) {
/* 2800 */         throw new IllegalArgumentException("VirtualFlow can not be null");
/*      */       }
/*      */       
/* 2803 */       getStyleClass().add("clipped-container");
/*      */ 
/*      */       
/* 2806 */       this.clipRect = new Rectangle();
/* 2807 */       this.clipRect.setSmooth(false);
/* 2808 */       setClip(this.clipRect);
/*      */ 
/*      */       
/* 2811 */       widthProperty().addListener(param1Observable -> this.clipRect.setWidth(getWidth()));
/*      */ 
/*      */       
/* 2814 */       heightProperty().addListener(param1Observable -> this.clipRect.setHeight(getHeight()));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ArrayLinkedList<T>
/*      */     extends AbstractList<T>
/*      */   {
/*      */     private final ArrayList<T> array;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2846 */     private int firstIndex = -1;
/* 2847 */     private int lastIndex = -1;
/*      */     
/*      */     public ArrayLinkedList() {
/* 2850 */       this.array = new ArrayList<>(50);
/*      */       
/* 2852 */       for (byte b = 0; b < 50; b++) {
/* 2853 */         this.array.add(null);
/*      */       }
/*      */     }
/*      */     
/*      */     public T getFirst() {
/* 2858 */       return (this.firstIndex == -1) ? null : this.array.get(this.firstIndex);
/*      */     }
/*      */     
/*      */     public T getLast() {
/* 2862 */       return (this.lastIndex == -1) ? null : this.array.get(this.lastIndex);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void addFirst(T param1T) {
/* 2868 */       if (this.firstIndex == -1) {
/* 2869 */         this.firstIndex = this.lastIndex = this.array.size() / 2;
/* 2870 */         this.array.set(this.firstIndex, param1T);
/* 2871 */       } else if (this.firstIndex == 0) {
/*      */ 
/*      */         
/* 2874 */         this.array.add(0, param1T);
/* 2875 */         this.lastIndex++;
/*      */       }
/*      */       else {
/*      */         
/* 2879 */         this.array.set(--this.firstIndex, param1T);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void addLast(T param1T) {
/* 2886 */       if (this.firstIndex == -1) {
/* 2887 */         this.firstIndex = this.lastIndex = this.array.size() / 2;
/* 2888 */         this.array.set(this.lastIndex, param1T);
/* 2889 */       } else if (this.lastIndex == this.array.size() - 1) {
/*      */ 
/*      */         
/* 2892 */         this.array.add(++this.lastIndex, param1T);
/*      */       } else {
/* 2894 */         this.array.set(++this.lastIndex, param1T);
/*      */       } 
/*      */     }
/*      */     
/*      */     public int size() {
/* 2899 */       return (this.firstIndex == -1) ? 0 : (this.lastIndex - this.firstIndex + 1);
/*      */     }
/*      */     
/*      */     public boolean isEmpty() {
/* 2903 */       return (this.firstIndex == -1);
/*      */     }
/*      */     
/*      */     public T get(int param1Int) {
/* 2907 */       if (param1Int > this.lastIndex - this.firstIndex || param1Int < 0)
/*      */       {
/*      */         
/* 2910 */         return null;
/*      */       }
/*      */       
/* 2913 */       return this.array.get(this.firstIndex + param1Int);
/*      */     }
/*      */     
/*      */     public void clear() {
/* 2917 */       for (byte b = 0; b < this.array.size(); b++) {
/* 2918 */         this.array.set(b, null);
/*      */       }
/*      */       
/* 2921 */       this.firstIndex = this.lastIndex = -1;
/*      */     }
/*      */     
/*      */     public T removeFirst() {
/* 2925 */       if (isEmpty()) return null; 
/* 2926 */       return remove(0);
/*      */     }
/*      */     
/*      */     public T removeLast() {
/* 2930 */       if (isEmpty()) return null; 
/* 2931 */       return remove(this.lastIndex - this.firstIndex);
/*      */     }
/*      */     
/*      */     public T remove(int param1Int) {
/* 2935 */       if (param1Int > this.lastIndex - this.firstIndex || param1Int < 0) {
/* 2936 */         throw new ArrayIndexOutOfBoundsException();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2943 */       if (param1Int == 0) {
/* 2944 */         T t1 = this.array.get(this.firstIndex);
/* 2945 */         this.array.set(this.firstIndex, null);
/* 2946 */         if (this.firstIndex == this.lastIndex) {
/* 2947 */           this.firstIndex = this.lastIndex = -1;
/*      */         } else {
/* 2949 */           this.firstIndex++;
/*      */         } 
/* 2951 */         return t1;
/* 2952 */       }  if (param1Int == this.lastIndex - this.firstIndex) {
/*      */ 
/*      */ 
/*      */         
/* 2956 */         T t1 = this.array.get(this.lastIndex);
/* 2957 */         this.array.set(this.lastIndex--, null);
/* 2958 */         return t1;
/*      */       } 
/*      */ 
/*      */       
/* 2962 */       T t = this.array.get(this.firstIndex + param1Int);
/* 2963 */       this.array.set(this.firstIndex + param1Int, null);
/* 2964 */       for (int i = this.firstIndex + param1Int + 1; i <= this.lastIndex; i++) {
/* 2965 */         this.array.set(i - 1, this.array.get(i));
/*      */       }
/* 2967 */       this.array.set(this.lastIndex--, null);
/* 2968 */       return t;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\VirtualFlow.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */