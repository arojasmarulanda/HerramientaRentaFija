/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.TreeCellBehavior;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.TreeCell;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeCellSkin<T>
/*     */   extends CellSkinBase<TreeCell<T>>
/*     */ {
/*  85 */   private static final Map<TreeView<?>, Double> maxDisclosureWidthMap = new WeakHashMap<>();
/*     */   
/*     */   private boolean disclosureNodeDirty = true;
/*     */   
/*     */   private TreeItem<?> treeItem;
/*     */   
/*     */   private final BehaviorBase<TreeCell<T>> behavior;
/*     */   
/*     */   private double fixedCellSize;
/*     */   private boolean fixedCellSizeEnabled;
/*     */   private DoubleProperty indent;
/*     */   
/*     */   private void setupTreeViewListeners() {
/*     */     TreeView<T> treeView = getSkinnable().getTreeView();
/*     */     if (treeView == null) {
/*     */       getSkinnable().treeViewProperty().addListener(new InvalidationListener()
/*     */           {
/*     */             public void invalidated(Observable param1Observable) {
/*     */               TreeCellSkin.this.getSkinnable().treeViewProperty().removeListener(this);
/*     */               TreeCellSkin.this.setupTreeViewListeners();
/*     */             }
/*     */           });
/*     */     } else {
/*     */       this.fixedCellSize = treeView.getFixedCellSize();
/*     */       this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0D);
/*     */       registerChangeListener(treeView.fixedCellSizeProperty(), paramObservableValue -> {
/*     */             this.fixedCellSize = getSkinnable().getTreeView().getFixedCellSize();
/*     */             this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0D);
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   public TreeCellSkin(TreeCell<T> paramTreeCell) {
/* 118 */     super(paramTreeCell);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     this.indent = null; this.behavior = new TreeCellBehavior<>(paramTreeCell); updateTreeItem(); registerChangeListener(paramTreeCell.treeItemProperty(), paramObservableValue -> { updateTreeItem(); this.disclosureNodeDirty = true; getSkinnable().requestLayout();
/* 168 */         }); registerChangeListener(paramTreeCell.textProperty(), paramObservableValue -> getSkinnable().requestLayout()); setupTreeViewListeners(); } public final void setIndent(double paramDouble) { indentProperty().set(paramDouble); } public final double getIndent() {
/* 169 */     return (this.indent == null) ? 10.0D : this.indent.get();
/*     */   } public final DoubleProperty indentProperty() {
/* 171 */     if (this.indent == null) {
/* 172 */       this.indent = new StyleableDoubleProperty(10.0D) {
/*     */           public Object getBean() {
/* 174 */             return TreeCellSkin.this;
/*     */           }
/*     */           
/*     */           public String getName() {
/* 178 */             return "indent";
/*     */           }
/*     */           
/*     */           public CssMetaData<TreeCell<?>, Number> getCssMetaData() {
/* 182 */             return TreeCellSkin.StyleableProperties.INDENT;
/*     */           }
/*     */         };
/*     */     }
/* 186 */     return this.indent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 199 */     super.dispose();
/*     */     
/* 201 */     if (this.behavior != null) {
/* 202 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateChildren() {
/* 208 */     super.updateChildren();
/* 209 */     updateDisclosureNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 219 */     TreeView<T> treeView = getSkinnable().getTreeView();
/* 220 */     if (treeView == null)
/*     */       return; 
/* 222 */     if (this.disclosureNodeDirty) {
/* 223 */       updateDisclosureNode();
/* 224 */       this.disclosureNodeDirty = false;
/*     */     } 
/*     */     
/* 227 */     Node node1 = getSkinnable().getDisclosureNode();
/*     */     
/* 229 */     int i = treeView.getTreeItemLevel(this.treeItem);
/* 230 */     if (!treeView.isShowRoot()) i--; 
/* 231 */     double d1 = getIndent() * i;
/*     */     
/* 233 */     paramDouble1 += d1;
/*     */ 
/*     */     
/* 236 */     boolean bool1 = (node1 != null && this.treeItem != null && !this.treeItem.isLeaf()) ? true : false;
/*     */ 
/*     */     
/* 239 */     double d2 = maxDisclosureWidthMap.containsKey(treeView) ? ((Double)maxDisclosureWidthMap.get(treeView)).doubleValue() : 18.0D;
/* 240 */     double d3 = d2;
/*     */     
/* 242 */     if (bool1) {
/* 243 */       if (node1 == null || node1.getScene() == null) {
/* 244 */         updateChildren();
/*     */       }
/*     */       
/* 247 */       if (node1 != null) {
/* 248 */         d3 = node1.prefWidth(paramDouble4);
/* 249 */         if (d3 > d2) {
/* 250 */           maxDisclosureWidthMap.put(treeView, Double.valueOf(d3));
/*     */         }
/*     */         
/* 253 */         double d = node1.prefHeight(d3);
/*     */         
/* 255 */         node1.resize(d3, d);
/* 256 */         positionInArea(node1, paramDouble1, paramDouble2, d3, d, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 264 */     boolean bool2 = (this.treeItem != null && this.treeItem.getGraphic() == null) ? false : true;
/* 265 */     paramDouble1 += d3 + bool2;
/* 266 */     paramDouble3 -= d1 + d3 + bool2;
/*     */ 
/*     */ 
/*     */     
/* 270 */     Node node2 = getSkinnable().getGraphic();
/* 271 */     if (node2 != null && !getChildren().contains(node2)) {
/* 272 */       getChildren().add(node2);
/*     */     }
/*     */     
/* 275 */     layoutLabelInArea(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 280 */     if (this.fixedCellSizeEnabled) {
/* 281 */       return this.fixedCellSize;
/*     */     }
/*     */     
/* 284 */     double d = super.computeMinHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/* 285 */     Node node = getSkinnable().getDisclosureNode();
/* 286 */     return (node == null) ? d : Math.max(node.minHeight(-1.0D), d);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 291 */     if (this.fixedCellSizeEnabled) {
/* 292 */       return this.fixedCellSize;
/*     */     }
/*     */     
/* 295 */     TreeCell<T> treeCell = getSkinnable();
/*     */     
/* 297 */     double d1 = super.computePrefHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/* 298 */     Node node = treeCell.getDisclosureNode();
/* 299 */     double d2 = (node == null) ? d1 : Math.max(node.prefHeight(-1.0D), d1);
/*     */ 
/*     */ 
/*     */     
/* 303 */     return snapSizeY(Math.max(treeCell.getMinHeight(), d2));
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 308 */     if (this.fixedCellSizeEnabled) {
/* 309 */       return this.fixedCellSize;
/*     */     }
/*     */     
/* 312 */     return super.computeMaxHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 317 */     double d1 = super.computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */     
/* 319 */     double d2 = snappedLeftInset() + snappedRightInset();
/*     */     
/* 321 */     TreeView<T> treeView = getSkinnable().getTreeView();
/* 322 */     if (treeView == null) return d2;
/*     */     
/* 324 */     if (this.treeItem == null) return d2;
/*     */     
/* 326 */     d2 = d1;
/*     */ 
/*     */     
/* 329 */     int i = treeView.getTreeItemLevel(this.treeItem);
/* 330 */     if (!treeView.isShowRoot()) i--; 
/* 331 */     d2 += getIndent() * i;
/*     */ 
/*     */     
/* 334 */     Node node = getSkinnable().getDisclosureNode();
/* 335 */     double d3 = (node == null) ? 0.0D : node.prefWidth(-1.0D);
/*     */     
/* 337 */     double d4 = maxDisclosureWidthMap.containsKey(treeView) ? ((Double)maxDisclosureWidthMap.get(treeView)).doubleValue() : 0.0D;
/* 338 */     d2 += Math.max(d4, d3);
/*     */     
/* 340 */     return d2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateTreeItem() {
/* 352 */     this.treeItem = getSkinnable().getTreeItem();
/*     */   }
/*     */   
/*     */   private void updateDisclosureNode() {
/* 356 */     if (getSkinnable().isEmpty())
/*     */       return; 
/* 358 */     Node node = getSkinnable().getDisclosureNode();
/* 359 */     if (node == null)
/*     */       return; 
/* 361 */     boolean bool = (this.treeItem != null && !this.treeItem.isLeaf()) ? true : false;
/* 362 */     node.setVisible(bool);
/*     */     
/* 364 */     if (!bool) {
/* 365 */       getChildren().remove(node);
/* 366 */     } else if (node.getParent() == null) {
/* 367 */       getChildren().add(node);
/* 368 */       node.toFront();
/*     */     } else {
/* 370 */       node.toBack();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 375 */     if (node.getScene() != null) {
/* 376 */       node.applyCss();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 390 */     private static final CssMetaData<TreeCell<?>, Number> INDENT = new CssMetaData<TreeCell<?>, Number>("-fx-indent", 
/*     */         
/* 392 */         SizeConverter.getInstance(), Double.valueOf(10.0D))
/*     */       {
/*     */         public boolean isSettable(TreeCell<?> param2TreeCell) {
/* 395 */           DoubleProperty doubleProperty = ((TreeCellSkin)param2TreeCell.getSkin()).indentProperty();
/* 396 */           return (doubleProperty == null || !doubleProperty.isBound());
/*     */         }
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(TreeCell<?> param2TreeCell) {
/* 400 */           TreeCellSkin treeCellSkin = (TreeCellSkin)param2TreeCell.getSkin();
/* 401 */           return (StyleableProperty<Number>)treeCellSkin.indentProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 408 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(CellSkinBase.getClassCssMetaData());
/* 409 */       arrayList.add(INDENT);
/* 410 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 421 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 429 */     return getClassCssMetaData();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TreeCellSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */