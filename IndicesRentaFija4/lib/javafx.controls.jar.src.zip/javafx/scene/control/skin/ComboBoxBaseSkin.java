/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.ComboBoxBaseBehavior;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ComboBoxBase;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.StackPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ComboBoxBaseSkin<T>
/*     */   extends SkinBase<ComboBoxBase<T>>
/*     */ {
/*     */   private Node displayNode;
/*     */   StackPane arrowButton;
/*     */   Region arrow;
/*  66 */   private ComboBoxMode mode = ComboBoxMode.COMBOBOX;
/*  67 */   private final EventHandler<MouseEvent> mouseEnteredEventHandler; private final EventHandler<MouseEvent> mousePressedEventHandler; private final EventHandler<MouseEvent> mouseReleasedEventHandler; private final EventHandler<MouseEvent> mouseExitedEventHandler; final ComboBoxMode getMode() { return this.mode; } final void setMode(ComboBoxMode paramComboBoxMode) {
/*  68 */     this.mode = paramComboBoxMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxBaseSkin(ComboBoxBase<T> paramComboBoxBase) {
/*  92 */     super(paramComboBoxBase); this.mouseEnteredEventHandler = (paramMouseEvent -> getBehavior().mouseEntered(paramMouseEvent)); this.mousePressedEventHandler = (paramMouseEvent -> { getBehavior().mousePressed(paramMouseEvent); paramMouseEvent.consume();
/*     */       }); this.mouseReleasedEventHandler = (paramMouseEvent -> { getBehavior().mouseReleased(paramMouseEvent); paramMouseEvent.consume();
/*  94 */       }); this.mouseExitedEventHandler = (paramMouseEvent -> getBehavior().mouseExited(paramMouseEvent)); getChildren().clear();
/*     */ 
/*     */     
/*  97 */     this.arrow = new Region();
/*  98 */     this.arrow.setFocusTraversable(false);
/*  99 */     this.arrow.getStyleClass().setAll(new String[] { "arrow" });
/* 100 */     this.arrow.setId("arrow");
/* 101 */     this.arrow.setMaxWidth(Double.NEGATIVE_INFINITY);
/* 102 */     this.arrow.setMaxHeight(Double.NEGATIVE_INFINITY);
/* 103 */     this.arrow.setMouseTransparent(true);
/*     */     
/* 105 */     this.arrowButton = new StackPane();
/* 106 */     this.arrowButton.setFocusTraversable(false);
/* 107 */     this.arrowButton.setId("arrow-button");
/* 108 */     this.arrowButton.getStyleClass().setAll(new String[] { "arrow-button" });
/* 109 */     this.arrowButton.getChildren().add(this.arrow);
/*     */     
/* 111 */     getChildren().add(this.arrowButton);
/*     */ 
/*     */     
/* 114 */     getSkinnable().focusedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*     */           if (!paramBoolean2.booleanValue()) {
/*     */             focusLost();
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 121 */     updateArrowButtonListeners();
/* 122 */     registerChangeListener(paramComboBoxBase.editableProperty(), paramObservableValue -> {
/*     */           updateArrowButtonListeners();
/*     */           updateDisplayArea();
/*     */         });
/* 126 */     registerChangeListener(paramComboBoxBase.showingProperty(), paramObservableValue -> {
/*     */           if (getSkinnable().isShowing()) {
/*     */             show();
/*     */           } else {
/*     */             hide();
/*     */           } 
/*     */         });
/* 133 */     registerChangeListener(paramComboBoxBase.valueProperty(), paramObservableValue -> updateDisplayArea());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 166 */     if (this.displayNode == null) {
/* 167 */       updateDisplayArea();
/*     */     }
/*     */     
/* 170 */     double d1 = snapSizeX(this.arrow.prefWidth(-1.0D));
/*     */ 
/*     */     
/* 173 */     double d2 = isButton() ? 0.0D : (this.arrowButton.snappedLeftInset() + d1 + this.arrowButton.snappedRightInset());
/*     */     
/* 175 */     if (this.displayNode != null) {
/* 176 */       this.displayNode.resizeRelocate(paramDouble1, paramDouble2, paramDouble3 - d2, paramDouble4);
/*     */     }
/*     */     
/* 179 */     this.arrowButton.setVisible(!isButton());
/* 180 */     if (!isButton()) {
/* 181 */       this.arrowButton.resize(d2, paramDouble4);
/* 182 */       positionInArea(this.arrowButton, paramDouble1 + paramDouble3 - d2, paramDouble2, d2, paramDouble4, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 189 */     if (this.displayNode == null) {
/* 190 */       updateDisplayArea();
/*     */     }
/*     */     
/* 193 */     double d1 = snapSizeX(this.arrow.prefWidth(-1.0D));
/*     */ 
/*     */ 
/*     */     
/* 197 */     double d2 = isButton() ? 0.0D : (this.arrowButton.snappedLeftInset() + d1 + this.arrowButton.snappedRightInset());
/* 198 */     double d3 = (this.displayNode == null) ? 0.0D : this.displayNode.prefWidth(paramDouble1);
/*     */     
/* 200 */     double d4 = d3 + d2;
/* 201 */     return paramDouble5 + d4 + paramDouble3;
/*     */   }
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*     */     double d;
/* 206 */     if (this.displayNode == null) {
/* 207 */       updateDisplayArea();
/*     */     }
/*     */ 
/*     */     
/* 211 */     if (this.displayNode == null) {
/*     */ 
/*     */       
/* 214 */       double d1 = isButton() ? 0.0D : (this.arrowButton.snappedTopInset() + this.arrow.prefHeight(-1.0D) + this.arrowButton.snappedBottomInset());
/* 215 */       d = Math.max(21.0D, d1);
/*     */     } else {
/* 217 */       d = this.displayNode.prefHeight(paramDouble1);
/*     */     } 
/*     */     
/* 220 */     return paramDouble2 + d + paramDouble4;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 225 */     return getSkinnable().prefWidth(paramDouble1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 230 */     return getSkinnable().prefHeight(paramDouble1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeBaselineOffset(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 237 */     if (this.displayNode == null) {
/* 238 */       updateDisplayArea();
/*     */     }
/*     */     
/* 241 */     if (this.displayNode != null) {
/* 242 */       return this.displayNode.getLayoutBounds().getMinY() + this.displayNode.getLayoutY() + this.displayNode.getBaselineOffset();
/*     */     }
/*     */     
/* 245 */     return super.computeBaselineOffset(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ComboBoxBaseBehavior getBehavior() {
/* 257 */     return null;
/*     */   }
/*     */   
/*     */   void focusLost() {
/* 261 */     getSkinnable().hide();
/*     */   }
/*     */   
/*     */   private boolean isButton() {
/* 265 */     return (getMode() == ComboBoxMode.BUTTON);
/*     */   }
/*     */   
/*     */   private void updateArrowButtonListeners() {
/* 269 */     if (getSkinnable().isEditable()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 274 */       this.arrowButton.addEventHandler(MouseEvent.MOUSE_ENTERED, this.mouseEnteredEventHandler);
/* 275 */       this.arrowButton.addEventHandler(MouseEvent.MOUSE_PRESSED, this.mousePressedEventHandler);
/* 276 */       this.arrowButton.addEventHandler(MouseEvent.MOUSE_RELEASED, this.mouseReleasedEventHandler);
/* 277 */       this.arrowButton.addEventHandler(MouseEvent.MOUSE_EXITED, this.mouseExitedEventHandler);
/*     */     } else {
/* 279 */       this.arrowButton.removeEventHandler(MouseEvent.MOUSE_ENTERED, this.mouseEnteredEventHandler);
/* 280 */       this.arrowButton.removeEventHandler(MouseEvent.MOUSE_PRESSED, this.mousePressedEventHandler);
/* 281 */       this.arrowButton.removeEventHandler(MouseEvent.MOUSE_RELEASED, this.mouseReleasedEventHandler);
/* 282 */       this.arrowButton.removeEventHandler(MouseEvent.MOUSE_EXITED, this.mouseExitedEventHandler);
/*     */     } 
/*     */   }
/*     */   
/*     */   void updateDisplayArea() {
/* 287 */     ObservableList<Node> observableList = getChildren();
/* 288 */     Node node = this.displayNode;
/* 289 */     this.displayNode = getDisplayNode();
/*     */ 
/*     */     
/* 292 */     if (node != null && node != this.displayNode) {
/* 293 */       observableList.remove(node);
/*     */     }
/*     */     
/* 296 */     if (this.displayNode != null && !observableList.contains(this.displayNode)) {
/* 297 */       observableList.add(this.displayNode);
/* 298 */       this.displayNode.applyCss();
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract Node getDisplayNode();
/*     */   
/*     */   public abstract void show();
/*     */   
/*     */   public abstract void hide();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ComboBoxBaseSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */