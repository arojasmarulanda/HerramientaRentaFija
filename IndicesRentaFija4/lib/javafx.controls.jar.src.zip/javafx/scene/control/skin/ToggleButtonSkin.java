/*    */ package javafx.scene.control.skin;
/*    */ 
/*    */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*    */ import com.sun.javafx.scene.control.behavior.ToggleButtonBehavior;
/*    */ import javafx.scene.control.ToggleButton;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ToggleButtonSkin
/*    */   extends LabeledSkinBase<ToggleButton>
/*    */ {
/*    */   private final BehaviorBase<ToggleButton> behavior;
/*    */   
/*    */   public ToggleButtonSkin(ToggleButton paramToggleButton) {
/* 68 */     super(paramToggleButton);
/*    */ 
/*    */     
/* 71 */     this.behavior = new ToggleButtonBehavior<>(paramToggleButton);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void dispose() {
/* 85 */     super.dispose();
/*    */     
/* 87 */     if (this.behavior != null)
/* 88 */       this.behavior.dispose(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ToggleButtonSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */