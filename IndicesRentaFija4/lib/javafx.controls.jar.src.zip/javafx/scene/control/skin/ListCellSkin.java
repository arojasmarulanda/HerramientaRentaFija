/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.ListCellBehavior;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.control.ListCell;
/*     */ import javafx.scene.control.ListView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListCellSkin<T>
/*     */   extends CellSkinBase<ListCell<T>>
/*     */ {
/*     */   private double fixedCellSize;
/*     */   private boolean fixedCellSizeEnabled;
/*     */   private final BehaviorBase<ListCell<T>> behavior;
/*     */   
/*     */   public ListCellSkin(ListCell<T> paramListCell) {
/*  75 */     super(paramListCell);
/*     */ 
/*     */     
/*  78 */     this.behavior = new ListCellBehavior<>(paramListCell);
/*     */ 
/*     */     
/*  81 */     setupListeners();
/*     */   }
/*     */   
/*     */   private void setupListeners() {
/*  85 */     ListView<T> listView = getSkinnable().getListView();
/*  86 */     if (listView == null) {
/*  87 */       getSkinnable().listViewProperty().addListener(new InvalidationListener() {
/*     */             public void invalidated(Observable param1Observable) {
/*  89 */               ListCellSkin.this.getSkinnable().listViewProperty().removeListener(this);
/*  90 */               ListCellSkin.this.setupListeners();
/*     */             }
/*     */           });
/*     */     } else {
/*  94 */       this.fixedCellSize = listView.getFixedCellSize();
/*  95 */       this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0D);
/*  96 */       registerChangeListener(listView.fixedCellSizeProperty(), paramObservableValue -> {
/*     */             this.fixedCellSize = getSkinnable().getListView().getFixedCellSize();
/*     */             this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0D);
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 113 */     super.dispose();
/*     */     
/* 115 */     if (this.behavior != null) {
/* 116 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 122 */     double d = super.computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/* 123 */     ListView<T> listView = getSkinnable().getListView();
/* 124 */     return (listView == null) ? 0.0D : (
/* 125 */       (listView.getOrientation() == Orientation.VERTICAL) ? d : Math.max(d, getCellSize()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 130 */     if (this.fixedCellSizeEnabled) {
/* 131 */       return this.fixedCellSize;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 136 */     double d = getCellSize();
/* 137 */     return (d == 24.0D) ? super.computePrefHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5) : d;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 143 */     if (this.fixedCellSizeEnabled) {
/* 144 */       return this.fixedCellSize;
/*     */     }
/*     */     
/* 147 */     return super.computeMinHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 152 */     if (this.fixedCellSizeEnabled) {
/* 153 */       return this.fixedCellSize;
/*     */     }
/*     */     
/* 156 */     return super.computeMaxHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ListCellSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */