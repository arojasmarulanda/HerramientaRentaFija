/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.ParentHelper;
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.ToolBarBehavior;
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import com.sun.javafx.scene.traversal.Algorithm;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import com.sun.javafx.scene.traversal.ParentTraversalEngine;
/*     */ import com.sun.javafx.scene.traversal.TraversalContext;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.EnumConverter;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Parent;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.CustomMenuItem;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.SeparatorMenuItem;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.control.ToolBar;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.scene.layout.Pane;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.layout.VBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToolBarSkin
/*     */   extends SkinBase<ToolBar>
/*     */ {
/*     */   private Pane box;
/*     */   private ToolBarOverflowMenu overflowMenu;
/*     */   private boolean overflow = false;
/*  99 */   private double previousWidth = 0.0D;
/* 100 */   private double previousHeight = 0.0D;
/* 101 */   private double savedPrefWidth = 0.0D;
/* 102 */   private double savedPrefHeight = 0.0D;
/*     */ 
/*     */   
/*     */   private ObservableList<MenuItem> overflowMenuItems;
/*     */ 
/*     */   
/*     */   private boolean needsUpdate = false;
/*     */ 
/*     */   
/*     */   private final ParentTraversalEngine engine;
/*     */ 
/*     */   
/*     */   private final BehaviorBase<ToolBar> behavior;
/*     */ 
/*     */   
/*     */   private DoubleProperty spacing;
/*     */ 
/*     */   
/*     */   private ObjectProperty<Pos> boxAlignment;
/*     */ 
/*     */   
/*     */   public ToolBarSkin(ToolBar paramToolBar) {
/* 124 */     super(paramToolBar);
/*     */ 
/*     */     
/* 127 */     this.behavior = new ToolBarBehavior(paramToolBar);
/*     */ 
/*     */     
/* 130 */     this.overflowMenuItems = FXCollections.observableArrayList();
/* 131 */     initialize();
/* 132 */     registerChangeListener(paramToolBar.orientationProperty(), paramObservableValue -> initialize());
/*     */     
/* 134 */     this.engine = new ParentTraversalEngine(getSkinnable(), new Algorithm()
/*     */         {
/*     */           private Node selectPrev(int param1Int, TraversalContext param1TraversalContext) {
/* 137 */             for (int i = param1Int; i >= 0; i--) {
/* 138 */               Node node = ToolBarSkin.this.box.getChildren().get(i);
/* 139 */               if (!node.isDisabled() && NodeHelper.isTreeShowing(node)) {
/* 140 */                 if (node instanceof Parent) {
/* 141 */                   Node node1 = param1TraversalContext.selectLastInParent((Parent)node);
/* 142 */                   if (node1 != null) return node1; 
/*     */                 } 
/* 144 */                 if (node.isFocusTraversable())
/* 145 */                   return node; 
/*     */               } 
/*     */             } 
/* 148 */             return null;
/*     */           }
/*     */           
/*     */           private Node selectNext(int param1Int, TraversalContext param1TraversalContext) {
/* 152 */             for (int i = param1Int, j = ToolBarSkin.this.box.getChildren().size(); i < j; i++) {
/* 153 */               Node node = ToolBarSkin.this.box.getChildren().get(i);
/* 154 */               if (!node.isDisabled() && NodeHelper.isTreeShowing(node)) {
/* 155 */                 if (node.isFocusTraversable()) {
/* 156 */                   return node;
/*     */                 }
/* 158 */                 if (node instanceof Parent) {
/* 159 */                   Node node1 = param1TraversalContext.selectFirstInParent((Parent)node);
/* 160 */                   if (node1 != null) return node1; 
/*     */                 } 
/*     */               } 
/* 163 */             }  return null;
/*     */           }
/*     */ 
/*     */           
/*     */           public Node select(Node param1Node, Direction param1Direction, TraversalContext param1TraversalContext) {
/* 168 */             ObservableList<Node> observableList = ToolBarSkin.this.box.getChildren();
/* 169 */             if (param1Node == ToolBarSkin.this.overflowMenu) {
/* 170 */               if (param1Direction.isForward()) {
/* 171 */                 return null;
/*     */               }
/* 173 */               Node node = selectPrev(observableList.size() - 1, param1TraversalContext);
/* 174 */               if (node != null) return node;
/*     */             
/*     */             } 
/*     */             
/* 178 */             int i = observableList.indexOf(param1Node);
/*     */             
/* 180 */             if (i < 0) {
/*     */               
/* 182 */               Parent parent = param1Node.getParent();
/* 183 */               while (!observableList.contains(parent)) {
/* 184 */                 parent = parent.getParent();
/*     */               }
/* 186 */               Node node = param1TraversalContext.selectInSubtree(parent, param1Node, param1Direction);
/* 187 */               if (node != null) return node; 
/* 188 */               i = observableList.indexOf(parent);
/* 189 */               if (param1Direction == Direction.NEXT) param1Direction = Direction.NEXT_IN_LINE;
/*     */             
/*     */             } 
/* 192 */             if (i >= 0)
/* 193 */               if (param1Direction.isForward()) {
/* 194 */                 Node node = selectNext(i + 1, param1TraversalContext);
/* 195 */                 if (node != null) return node; 
/* 196 */                 if (ToolBarSkin.this.overflow) {
/* 197 */                   ToolBarSkin.this.overflowMenu.requestFocus();
/* 198 */                   return ToolBarSkin.this.overflowMenu;
/*     */                 } 
/*     */               } else {
/* 201 */                 Node node = selectPrev(i - 1, param1TraversalContext);
/* 202 */                 if (node != null) return node;
/*     */               
/*     */               }  
/* 205 */             return null;
/*     */           }
/*     */ 
/*     */           
/*     */           public Node selectFirst(TraversalContext param1TraversalContext) {
/* 210 */             Node node = selectNext(0, param1TraversalContext);
/* 211 */             if (node != null) return node; 
/* 212 */             if (ToolBarSkin.this.overflow) {
/* 213 */               return ToolBarSkin.this.overflowMenu;
/*     */             }
/* 215 */             return null;
/*     */           }
/*     */ 
/*     */           
/*     */           public Node selectLast(TraversalContext param1TraversalContext) {
/* 220 */             if (ToolBarSkin.this.overflow) {
/* 221 */               return ToolBarSkin.this.overflowMenu;
/*     */             }
/* 223 */             return selectPrev(ToolBarSkin.this.box.getChildren().size() - 1, param1TraversalContext);
/*     */           }
/*     */         });
/* 226 */     ParentHelper.setTraversalEngine(getSkinnable(), this.engine);
/*     */     
/* 228 */     paramToolBar.focusedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*     */           if (paramBoolean2.booleanValue()) {
/*     */             if (!this.box.getChildren().isEmpty()) {
/*     */               ((Node)this.box.getChildren().get(0)).requestFocus();
/*     */             } else {
/*     */               this.overflowMenu.requestFocus();
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     paramToolBar.getItems().addListener(paramChange -> {
/*     */           while (paramChange.next()) {
/*     */             for (Node node : paramChange.getRemoved()) {
/*     */               this.box.getChildren().remove(node);
/*     */             }
/*     */             this.box.getChildren().addAll(paramChange.getAddedSubList());
/*     */           } 
/*     */           this.needsUpdate = true;
/*     */           getSkinnable().requestLayout();
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double snapSpacing(double paramDouble) {
/* 262 */     if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 263 */       return snapSpaceY(paramDouble);
/*     */     }
/* 265 */     return snapSpaceX(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void setSpacing(double paramDouble) {
/* 272 */     spacingProperty().set(snapSpacing(paramDouble));
/*     */   }
/*     */   
/*     */   private final double getSpacing() {
/* 276 */     return (this.spacing == null) ? 0.0D : snapSpacing(this.spacing.get());
/*     */   }
/*     */   
/*     */   private final DoubleProperty spacingProperty() {
/* 280 */     if (this.spacing == null) {
/* 281 */       this.spacing = new StyleableDoubleProperty()
/*     */         {
/*     */           protected void invalidated()
/*     */           {
/* 285 */             double d = get();
/* 286 */             if (ToolBarSkin.this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 287 */               ((VBox)ToolBarSkin.this.box).setSpacing(d);
/*     */             } else {
/* 289 */               ((HBox)ToolBarSkin.this.box).setSpacing(d);
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 295 */             return ToolBarSkin.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 300 */             return "spacing";
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<ToolBar, Number> getCssMetaData() {
/* 305 */             return ToolBarSkin.StyleableProperties.SPACING;
/*     */           }
/*     */         };
/*     */     }
/* 309 */     return this.spacing;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final void setBoxAlignment(Pos paramPos) {
/* 315 */     boxAlignmentProperty().set(paramPos);
/*     */   }
/*     */   
/*     */   private final Pos getBoxAlignment() {
/* 319 */     return (this.boxAlignment == null) ? Pos.TOP_LEFT : this.boxAlignment.get();
/*     */   }
/*     */   
/*     */   private final ObjectProperty<Pos> boxAlignmentProperty() {
/* 323 */     if (this.boxAlignment == null) {
/* 324 */       this.boxAlignment = new StyleableObjectProperty<Pos>(Pos.TOP_LEFT)
/*     */         {
/*     */           public void invalidated()
/*     */           {
/* 328 */             Pos pos = get();
/* 329 */             if (ToolBarSkin.this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 330 */               ((VBox)ToolBarSkin.this.box).setAlignment(pos);
/*     */             } else {
/* 332 */               ((HBox)ToolBarSkin.this.box).setAlignment(pos);
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 338 */             return ToolBarSkin.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 343 */             return "boxAlignment";
/*     */           }
/*     */ 
/*     */           
/*     */           public CssMetaData<ToolBar, Pos> getCssMetaData() {
/* 348 */             return ToolBarSkin.StyleableProperties.ALIGNMENT;
/*     */           }
/*     */         };
/*     */     }
/* 352 */     return this.boxAlignment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 365 */     super.dispose();
/*     */     
/* 367 */     if (this.behavior != null) {
/* 368 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 374 */     ToolBar toolBar = getSkinnable();
/* 375 */     return (toolBar.getOrientation() == Orientation.VERTICAL) ? 
/* 376 */       computePrefWidth(-1.0D, paramDouble2, paramDouble3, paramDouble4, paramDouble5) : (
/* 377 */       snapSizeX(this.overflowMenu.prefWidth(-1.0D)) + paramDouble5 + paramDouble3);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 382 */     ToolBar toolBar = getSkinnable();
/* 383 */     return (toolBar.getOrientation() == Orientation.VERTICAL) ? (
/* 384 */       snapSizeY(this.overflowMenu.prefHeight(-1.0D)) + paramDouble2 + paramDouble4) : 
/* 385 */       computePrefHeight(-1.0D, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 390 */     double d = 0.0D;
/* 391 */     ToolBar toolBar = getSkinnable();
/*     */     
/* 393 */     if (toolBar.getOrientation() == Orientation.HORIZONTAL) {
/* 394 */       for (Node node : toolBar.getItems()) {
/* 395 */         if (!node.isManaged())
/* 396 */           continue;  d += snapSizeX(node.prefWidth(-1.0D)) + getSpacing();
/*     */       } 
/* 398 */       d -= getSpacing();
/*     */     } else {
/* 400 */       for (Node node : toolBar.getItems()) {
/* 401 */         if (!node.isManaged())
/* 402 */           continue;  d = Math.max(d, snapSizeX(node.prefWidth(-1.0D)));
/*     */       } 
/* 404 */       if (toolBar.getItems().size() > 0) {
/* 405 */         this.savedPrefWidth = d;
/*     */       } else {
/* 407 */         d = this.savedPrefWidth;
/*     */       } 
/*     */     } 
/* 410 */     return paramDouble5 + d + paramDouble3;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 415 */     double d = 0.0D;
/* 416 */     ToolBar toolBar = getSkinnable();
/*     */     
/* 418 */     if (toolBar.getOrientation() == Orientation.VERTICAL) {
/* 419 */       for (Node node : toolBar.getItems()) {
/* 420 */         if (!node.isManaged())
/* 421 */           continue;  d += snapSizeY(node.prefHeight(-1.0D)) + getSpacing();
/*     */       } 
/* 423 */       d -= getSpacing();
/*     */     } else {
/* 425 */       for (Node node : toolBar.getItems()) {
/* 426 */         if (!node.isManaged())
/* 427 */           continue;  d = Math.max(d, snapSizeY(node.prefHeight(-1.0D)));
/*     */       } 
/* 429 */       if (toolBar.getItems().size() > 0) {
/* 430 */         this.savedPrefHeight = d;
/*     */       } else {
/* 432 */         d = this.savedPrefHeight;
/*     */       } 
/*     */     } 
/* 435 */     return paramDouble2 + d + paramDouble4;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 440 */     return (getSkinnable().getOrientation() == Orientation.VERTICAL) ? 
/* 441 */       snapSizeX(getSkinnable().prefWidth(-1.0D)) : Double.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 446 */     return (getSkinnable().getOrientation() == Orientation.VERTICAL) ? 
/* 447 */       Double.MAX_VALUE : snapSizeY(getSkinnable().prefHeight(-1.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 454 */     ToolBar toolBar = getSkinnable();
/*     */     
/* 456 */     if (toolBar.getOrientation() == Orientation.VERTICAL) {
/* 457 */       if (snapSizeY(toolBar.getHeight()) != this.previousHeight || this.needsUpdate) {
/* 458 */         ((VBox)this.box).setSpacing(getSpacing());
/* 459 */         ((VBox)this.box).setAlignment(getBoxAlignment());
/* 460 */         this.previousHeight = snapSizeY(toolBar.getHeight());
/* 461 */         addNodesToToolBar();
/*     */       }
/*     */     
/* 464 */     } else if (snapSizeX(toolBar.getWidth()) != this.previousWidth || this.needsUpdate) {
/* 465 */       ((HBox)this.box).setSpacing(getSpacing());
/* 466 */       ((HBox)this.box).setAlignment(getBoxAlignment());
/* 467 */       this.previousWidth = snapSizeX(toolBar.getWidth());
/* 468 */       addNodesToToolBar();
/*     */     } 
/*     */     
/* 471 */     this.needsUpdate = false;
/*     */     
/* 473 */     double d1 = paramDouble3;
/* 474 */     double d2 = paramDouble4;
/*     */     
/* 476 */     if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 477 */       d2 -= this.overflow ? snapSizeY(this.overflowMenu.prefHeight(-1.0D)) : 0.0D;
/*     */     } else {
/* 479 */       d1 -= this.overflow ? snapSizeX(this.overflowMenu.prefWidth(-1.0D)) : 0.0D;
/*     */     } 
/*     */     
/* 482 */     this.box.resize(d1, d2);
/* 483 */     positionInArea(this.box, paramDouble1, paramDouble2, d1, d2, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */ 
/*     */ 
/*     */     
/* 487 */     if (this.overflow) {
/* 488 */       double d3 = snapSizeX(this.overflowMenu.prefWidth(-1.0D));
/* 489 */       double d4 = snapSizeY(this.overflowMenu.prefHeight(-1.0D));
/* 490 */       double d5 = paramDouble1;
/* 491 */       double d6 = paramDouble1;
/* 492 */       if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/*     */ 
/*     */         
/* 495 */         if (d1 == 0.0D) {
/* 496 */           d1 = this.savedPrefWidth;
/*     */         }
/* 498 */         HPos hPos = ((VBox)this.box).getAlignment().getHpos();
/* 499 */         if (HPos.LEFT.equals(hPos)) {
/* 500 */           d5 = paramDouble1 + Math.abs((d1 - d3) / 2.0D);
/* 501 */         } else if (HPos.RIGHT.equals(hPos)) {
/*     */           
/* 503 */           d5 = snapSizeX(toolBar.getWidth()) - snappedRightInset() - d1 + Math.abs((d1 - d3) / 2.0D);
/*     */         } else {
/*     */           
/* 506 */           d5 = paramDouble1 + Math.abs((snapSizeX(toolBar.getWidth()) - paramDouble1 + 
/* 507 */               snappedRightInset() - d3) / 2.0D);
/*     */         } 
/* 509 */         d6 = snapSizeY(toolBar.getHeight()) - d4 - paramDouble2;
/*     */       }
/*     */       else {
/*     */         
/* 513 */         if (d2 == 0.0D) {
/* 514 */           d2 = this.savedPrefHeight;
/*     */         }
/* 516 */         VPos vPos = ((HBox)this.box).getAlignment().getVpos();
/* 517 */         if (VPos.TOP.equals(vPos)) {
/*     */           
/* 519 */           d6 = paramDouble2 + Math.abs((d2 - d4) / 2.0D);
/* 520 */         } else if (VPos.BOTTOM.equals(vPos)) {
/*     */           
/* 522 */           d6 = snapSizeY(toolBar.getHeight()) - snappedBottomInset() - d2 + Math.abs((d2 - d4) / 2.0D);
/*     */         } else {
/* 524 */           d6 = paramDouble2 + Math.abs((d2 - d4) / 2.0D);
/*     */         } 
/* 526 */         d5 = snapSizeX(toolBar.getWidth()) - d3 - snappedRightInset();
/*     */       } 
/* 528 */       this.overflowMenu.resize(d3, d4);
/* 529 */       positionInArea(this.overflowMenu, d5, d6, d3, d4, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 543 */     if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 544 */       this.box = new VBox();
/*     */     } else {
/* 546 */       this.box = new HBox();
/*     */     } 
/* 548 */     this.box.getStyleClass().add("container");
/* 549 */     this.box.getChildren().addAll(getSkinnable().getItems());
/* 550 */     this.overflowMenu = new ToolBarOverflowMenu(this.overflowMenuItems);
/* 551 */     this.overflowMenu.setVisible(false);
/* 552 */     this.overflowMenu.setManaged(false);
/*     */     
/* 554 */     getChildren().clear();
/* 555 */     getChildren().add(this.box);
/* 556 */     getChildren().add(this.overflowMenu);
/*     */     
/* 558 */     this.previousWidth = 0.0D;
/* 559 */     this.previousHeight = 0.0D;
/* 560 */     this.savedPrefWidth = 0.0D;
/* 561 */     this.savedPrefHeight = 0.0D;
/* 562 */     this.needsUpdate = true;
/* 563 */     getSkinnable().requestLayout();
/*     */   }
/*     */   
/*     */   private void addNodesToToolBar() {
/* 567 */     ToolBar toolBar = getSkinnable();
/* 568 */     double d1 = 0.0D;
/* 569 */     if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 570 */       d1 = snapSizeY(toolBar.getHeight()) - snappedTopInset() - snappedBottomInset() + getSpacing();
/*     */     } else {
/* 572 */       d1 = snapSizeX(toolBar.getWidth()) - snappedLeftInset() - snappedRightInset() + getSpacing();
/*     */     } 
/*     */ 
/*     */     
/* 576 */     double d2 = 0.0D;
/* 577 */     boolean bool = false;
/* 578 */     for (Node node : getSkinnable().getItems()) {
/* 579 */       if (!node.isManaged())
/*     */         continue; 
/* 581 */       if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 582 */         d2 += snapSizeY(node.prefHeight(-1.0D)) + getSpacing();
/*     */       } else {
/* 584 */         d2 += snapSizeX(node.prefWidth(-1.0D)) + getSpacing();
/*     */       } 
/* 586 */       if (d2 > d1) {
/* 587 */         bool = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 592 */     if (bool) {
/* 593 */       if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 594 */         d1 -= snapSizeY(this.overflowMenu.prefHeight(-1.0D));
/*     */       } else {
/* 596 */         d1 -= snapSizeX(this.overflowMenu.prefWidth(-1.0D));
/*     */       } 
/* 598 */       d1 -= getSpacing();
/*     */     } 
/*     */ 
/*     */     
/* 602 */     d2 = 0.0D;
/* 603 */     this.overflowMenuItems.clear();
/* 604 */     this.box.getChildren().clear();
/* 605 */     for (Node node : getSkinnable().getItems()) {
/* 606 */       node.getStyleClass().remove("menu-item");
/* 607 */       node.getStyleClass().remove("custom-menu-item");
/*     */       
/* 609 */       if (node.isManaged()) {
/* 610 */         if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 611 */           d2 += snapSizeY(node.prefHeight(-1.0D)) + getSpacing();
/*     */         } else {
/* 613 */           d2 += snapSizeX(node.prefWidth(-1.0D)) + getSpacing();
/*     */         } 
/*     */       }
/*     */       
/* 617 */       if (d2 <= d1) {
/* 618 */         this.box.getChildren().add(node); continue;
/*     */       } 
/* 620 */       if (node.isFocused()) {
/* 621 */         if (!this.box.getChildren().isEmpty()) {
/* 622 */           Node node1 = this.engine.selectLast();
/* 623 */           if (node1 != null) {
/* 624 */             node1.requestFocus();
/*     */           }
/*     */         } else {
/* 627 */           this.overflowMenu.requestFocus();
/*     */         } 
/*     */       }
/* 630 */       if (node instanceof javafx.scene.control.Separator) {
/* 631 */         this.overflowMenuItems.add(new SeparatorMenuItem()); continue;
/*     */       } 
/* 633 */       CustomMenuItem customMenuItem = new CustomMenuItem(node);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 644 */       String str = node.getTypeSelector();
/* 645 */       switch (str) {
/*     */         case "Button":
/*     */         case "Hyperlink":
/*     */         case "Label":
/* 649 */           customMenuItem.setHideOnClick(true);
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 669 */           customMenuItem.setHideOnClick(false);
/*     */           break;
/*     */       } 
/*     */       
/* 673 */       this.overflowMenuItems.add(customMenuItem);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 679 */     this.overflow = (this.overflowMenuItems.size() > 0);
/* 680 */     if (!this.overflow && this.overflowMenu.isFocused()) {
/* 681 */       Node node = this.engine.selectLast();
/* 682 */       if (node != null) {
/* 683 */         node.requestFocus();
/*     */       }
/*     */     } 
/* 686 */     this.overflowMenu.setVisible(this.overflow);
/* 687 */     this.overflowMenu.setManaged(this.overflow);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class ToolBarOverflowMenu
/*     */     extends StackPane
/*     */   {
/*     */     private StackPane downArrow;
/*     */ 
/*     */     
/*     */     private ContextMenu popup;
/*     */     
/*     */     private ObservableList<MenuItem> menuItems;
/*     */ 
/*     */     
/*     */     public ToolBarOverflowMenu(ObservableList<MenuItem> param1ObservableList) {
/* 704 */       getStyleClass().setAll(new String[] { "tool-bar-overflow-button" });
/* 705 */       setAccessibleRole(AccessibleRole.BUTTON);
/* 706 */       setAccessibleText(ControlResources.getString("Accessibility.title.ToolBar.OverflowButton"));
/* 707 */       setFocusTraversable(true);
/* 708 */       this.menuItems = param1ObservableList;
/* 709 */       this.downArrow = new StackPane();
/* 710 */       this.downArrow.getStyleClass().setAll(new String[] { "arrow" });
/* 711 */       this.downArrow.setOnMousePressed(param1MouseEvent -> fire());
/*     */ 
/*     */ 
/*     */       
/* 715 */       setOnKeyPressed(param1KeyEvent -> {
/*     */             if (KeyCode.SPACE.equals(param1KeyEvent.getCode())) {
/*     */               if (!this.popup.isShowing()) {
/*     */                 this.popup.getItems().clear();
/*     */                 
/*     */                 this.popup.getItems().addAll(this.menuItems);
/*     */                 this.popup.show(this.downArrow, Side.BOTTOM, 0.0D, 0.0D);
/*     */               } 
/*     */               param1KeyEvent.consume();
/*     */             } else if (KeyCode.ESCAPE.equals(param1KeyEvent.getCode())) {
/*     */               if (this.popup.isShowing()) {
/*     */                 this.popup.hide();
/*     */               }
/*     */               param1KeyEvent.consume();
/*     */             } else if (KeyCode.ENTER.equals(param1KeyEvent.getCode())) {
/*     */               fire();
/*     */               param1KeyEvent.consume();
/*     */             } 
/*     */           });
/* 734 */       visibleProperty().addListener((param1ObservableValue, param1Boolean1, param1Boolean2) -> {
/*     */             if (param1Boolean2.booleanValue() && ToolBarSkin.this.box.getChildren().isEmpty()) {
/*     */               setFocusTraversable(true);
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 741 */       this.popup = new ContextMenu();
/* 742 */       setVisible(false);
/* 743 */       setManaged(false);
/* 744 */       getChildren().add(this.downArrow);
/*     */     }
/*     */     
/*     */     private void fire() {
/* 748 */       if (this.popup.isShowing()) {
/* 749 */         this.popup.hide();
/*     */       } else {
/* 751 */         this.popup.getItems().clear();
/* 752 */         this.popup.getItems().addAll(this.menuItems);
/* 753 */         this.popup.show(this.downArrow, Side.BOTTOM, 0.0D, 0.0D);
/*     */       } 
/*     */     }
/*     */     
/*     */     protected double computePrefWidth(double param1Double) {
/* 758 */       return snappedLeftInset() + snappedRightInset();
/*     */     }
/*     */     
/*     */     protected double computePrefHeight(double param1Double) {
/* 762 */       return snappedTopInset() + snappedBottomInset();
/*     */     }
/*     */     
/*     */     protected void layoutChildren() {
/* 766 */       double d1 = snapSize(this.downArrow.prefWidth(-1.0D));
/* 767 */       double d2 = snapSize(this.downArrow.prefHeight(-1.0D));
/* 768 */       double d3 = (snapSize(getWidth()) - d1) / 2.0D;
/* 769 */       double d4 = (snapSize(getHeight()) - d2) / 2.0D;
/*     */ 
/*     */ 
/*     */       
/* 773 */       if (ToolBarSkin.this.getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 774 */         this.downArrow.setRotate(0.0D);
/*     */       }
/*     */       
/* 777 */       this.downArrow.resize(d1, d2);
/* 778 */       positionInArea(this.downArrow, d3, d4, d1, d2, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void executeAccessibleAction(AccessibleAction param1AccessibleAction, Object... param1VarArgs) {
/* 785 */       switch (param1AccessibleAction) { case OVERFLOW_BUTTON:
/* 786 */           fire(); return; }
/* 787 */        super.executeAccessibleAction(param1AccessibleAction, new Object[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 802 */     private static final CssMetaData<ToolBar, Number> SPACING = new CssMetaData<ToolBar, Number>("-fx-spacing", 
/*     */         
/* 804 */         SizeConverter.getInstance(), Double.valueOf(0.0D))
/*     */       {
/*     */         public boolean isSettable(ToolBar param2ToolBar)
/*     */         {
/* 808 */           ToolBarSkin toolBarSkin = (ToolBarSkin)param2ToolBar.getSkin();
/* 809 */           return (toolBarSkin.spacing == null || !toolBarSkin.spacing.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(ToolBar param2ToolBar) {
/* 814 */           ToolBarSkin toolBarSkin = (ToolBarSkin)param2ToolBar.getSkin();
/* 815 */           return (StyleableProperty<Number>)toolBarSkin.spacingProperty();
/*     */         }
/*     */       };
/*     */     
/* 819 */     private static final CssMetaData<ToolBar, Pos> ALIGNMENT = new CssMetaData<ToolBar, Pos>("-fx-alignment", (StyleConverter)new EnumConverter(Pos.class), Pos.TOP_LEFT)
/*     */       {
/*     */ 
/*     */         
/*     */         public boolean isSettable(ToolBar param2ToolBar)
/*     */         {
/* 825 */           ToolBarSkin toolBarSkin = (ToolBarSkin)param2ToolBar.getSkin();
/* 826 */           return (toolBarSkin.boxAlignment == null || !toolBarSkin.boxAlignment.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Pos> getStyleableProperty(ToolBar param2ToolBar) {
/* 831 */           ToolBarSkin toolBarSkin = (ToolBarSkin)param2ToolBar.getSkin();
/* 832 */           return (StyleableProperty<Pos>)toolBarSkin.boxAlignmentProperty();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */ 
/*     */     
/*     */     static {
/* 841 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(SkinBase.getClassCssMetaData());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 846 */       String str = ALIGNMENT.getProperty(); byte b; int i;
/* 847 */       for (b = 0, i = arrayList.size(); b < i; b++) {
/* 848 */         CssMetaData cssMetaData = arrayList.get(b);
/* 849 */         if (str.equals(cssMetaData.getProperty())) arrayList.remove(cssMetaData);
/*     */       
/*     */       } 
/* 852 */       arrayList.add(SPACING);
/* 853 */       arrayList.add(ALIGNMENT);
/* 854 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 866 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 874 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 879 */     switch (paramAccessibleAttribute) { case OVERFLOW_BUTTON:
/* 880 */         return this.overflowMenu; }
/* 881 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/* 887 */     switch (paramAccessibleAction) {
/*     */       case null:
/* 889 */         this.overflowMenu.fire(); return;
/*     */     } 
/* 891 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ToolBarSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */