/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.AccessController;
/*     */ import java.util.List;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.event.EventType;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.IndexedCell;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.ScrollToEvent;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TableFocusModel;
/*     */ import javafx.scene.control.TablePositionBase;
/*     */ import javafx.scene.control.TableSelectionModel;
/*     */ import javafx.scene.control.TableView;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TableViewSkinBase<M, S, C extends Control, I extends IndexedCell<M>, TC extends TableColumnBase<S, ?>>
/*     */   extends VirtualContainerBase<C, I>
/*     */ {
/*     */   private static final double GOLDEN_RATIO_MULTIPLIER = 0.618033987D;
/*  98 */   private static final boolean IS_PANNABLE = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.scene.control.skin.TableViewSkin.pannable")))).booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private final String EMPTY_TABLE_TEXT = ControlResources.getString("TableView.noContent");
/* 111 */   private final String NO_COLUMNS_TEXT = ControlResources.getString("TableView.noColumns");
/*     */ 
/*     */ 
/*     */   
/*     */   VirtualFlow<I> flow;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean contentWidthDirty = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private Region columnReorderLine;
/*     */ 
/*     */ 
/*     */   
/*     */   private Region columnReorderOverlay;
/*     */ 
/*     */ 
/*     */   
/*     */   private TableHeaderRow tableHeaderRow;
/*     */ 
/*     */ 
/*     */   
/*     */   private Callback<C, I> rowFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private StackPane placeholderRegion;
/*     */ 
/*     */ 
/*     */   
/*     */   private Label placeholderLabel;
/*     */ 
/*     */   
/*     */   private int visibleColCount;
/*     */ 
/*     */   
/*     */   boolean needCellsRecreated = true;
/*     */ 
/*     */   
/*     */   boolean needCellsReconfigured = false;
/*     */ 
/*     */   
/* 155 */   private int itemCount = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MapChangeListener<Object, Object> propertiesMapListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ListChangeListener<S> rowCountListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ListChangeListener<TC> visibleLeafColumnsListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InvalidationListener widthListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InvalidationListener itemsChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WeakListChangeListener<S> weakRowCountListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WeakListChangeListener<TC> weakVisibleLeafColumnsListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WeakInvalidationListener weakWidthListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WeakInvalidationListener weakItemsChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableViewSkinBase(C paramC) {
/* 257 */     super(paramC); this.propertiesMapListener = (paramChange -> { if (!paramChange.wasAdded()) return;  if ("refreshKey".equals(paramChange.getKey())) { refreshView(); getSkinnable().getProperties().remove("refreshKey"); } else if ("recreateKey".equals(paramChange.getKey())) { this.needCellsRecreated = true; refreshView(); getSkinnable().getProperties().remove("recreateKey"); }  }); this.rowCountListener = (paramChange -> { while (paramChange.next()) { if (paramChange.wasReplaced()) { this.itemCount = 0; break; }  if (paramChange.getRemovedSize() == this.itemCount) { this.itemCount = 0; break; }  }  if (getSkinnable() instanceof TableView)
/*     */           ((TableView)getSkinnable()).edit(-1, null);  markItemCountDirty(); getSkinnable().requestLayout(); }); this.visibleLeafColumnsListener = (paramChange -> { updateVisibleColumnCount(); while (paramChange.next())
/*     */           updateVisibleLeafColumnWidthListeners(paramChange.getAddedSubList(), paramChange.getRemoved());  }); this.widthListener = (paramObservable -> { this.needCellsReconfigured = true; if (getSkinnable() != null)
/* 260 */           getSkinnable().requestLayout();  }); this.weakRowCountListener = new WeakListChangeListener<>(this.rowCountListener); this.weakVisibleLeafColumnsListener = new WeakListChangeListener<>(this.visibleLeafColumnsListener); this.weakWidthListener = new WeakInvalidationListener(this.widthListener); this.flow = getVirtualFlow();
/* 261 */     this.flow.setPannable(IS_PANNABLE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     this.flow.getHbar().valueProperty().addListener(paramObservable -> horizontalScroll());
/*     */ 
/*     */     
/* 271 */     this.flow.getHbar().setUnitIncrement(15.0D);
/* 272 */     this.flow.getHbar().setBlockIncrement(80.0D);
/*     */     
/* 274 */     this.columnReorderLine = new Region();
/* 275 */     this.columnReorderLine.getStyleClass().setAll(new String[] { "column-resize-line" });
/* 276 */     this.columnReorderLine.setManaged(false);
/* 277 */     this.columnReorderLine.setVisible(false);
/*     */     
/* 279 */     this.columnReorderOverlay = new Region();
/* 280 */     this.columnReorderOverlay.getStyleClass().setAll(new String[] { "column-overlay" });
/* 281 */     this.columnReorderOverlay.setVisible(false);
/* 282 */     this.columnReorderOverlay.setManaged(false);
/*     */     
/* 284 */     this.tableHeaderRow = createTableHeaderRow();
/*     */     
/* 286 */     this.tableHeaderRow.setFocusTraversable(false);
/*     */     
/* 288 */     getChildren().addAll(new Node[] { this.tableHeaderRow, this.flow, this.columnReorderOverlay, this.columnReorderLine });
/*     */     
/* 290 */     updateVisibleColumnCount();
/* 291 */     updateVisibleLeafColumnWidthListeners(getVisibleLeafColumns(), FXCollections.emptyObservableList());
/*     */     
/* 293 */     this.tableHeaderRow.reorderingProperty().addListener(paramObservable -> getSkinnable().requestLayout());
/*     */ 
/*     */ 
/*     */     
/* 297 */     getVisibleLeafColumns().addListener(this.weakVisibleLeafColumnsListener);
/*     */     
/* 299 */     final ObjectProperty<ObservableList<?>> itemsProperty = TableSkinUtils.itemsProperty(this);
/* 300 */     updateTableItems((ObservableList<S>)null, (ObservableList<S>)objectProperty.get());
/* 301 */     this.itemsChangeListener = new InvalidationListener() {
/* 302 */         private WeakReference<ObservableList<S>> weakItemsRef = new WeakReference<>(itemsProperty.get());
/*     */         
/*     */         public void invalidated(Observable param1Observable) {
/* 305 */           ObservableList observableList = this.weakItemsRef.get();
/* 306 */           this.weakItemsRef = new WeakReference<>(itemsProperty.get());
/* 307 */           TableViewSkinBase.this.updateTableItems(observableList, itemsProperty.get());
/*     */         }
/*     */       };
/* 310 */     this.weakItemsChangeListener = new WeakInvalidationListener(this.itemsChangeListener);
/* 311 */     objectProperty.addListener(this.weakItemsChangeListener);
/*     */     
/* 313 */     ObservableMap<Object, Object> observableMap = paramC.getProperties();
/* 314 */     observableMap.remove("refreshKey");
/* 315 */     observableMap.remove("recreateKey");
/* 316 */     observableMap.addListener(this.propertiesMapListener);
/*     */     
/* 318 */     paramC.addEventHandler((EventType)ScrollToEvent.scrollToColumn(), paramScrollToEvent -> scrollHorizontally((TC)paramScrollToEvent.getScrollTarget()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 323 */     InvalidationListener invalidationListener = paramObservable -> {
/*     */         this.contentWidthDirty = true;
/*     */         getSkinnable().requestLayout();
/*     */       };
/* 327 */     this.flow.widthProperty().addListener(invalidationListener);
/* 328 */     this.flow.getVbar().widthProperty().addListener(invalidationListener);
/*     */     
/* 330 */     ObjectProperty<Callback<Control, IndexedCell<?>>> objectProperty1 = TableSkinUtils.rowFactoryProperty(this);
/* 331 */     registerChangeListener(objectProperty1, paramObservableValue -> {
/*     */           Callback<C, I> callback = this.rowFactory;
/*     */           this.rowFactory = paramObjectProperty.get();
/*     */           if (callback != this.rowFactory) {
/*     */             requestRebuildCells();
/*     */           }
/*     */         });
/* 338 */     registerChangeListener(TableSkinUtils.placeholderProperty(this), paramObservableValue -> updatePlaceholderRegionVisibility());
/* 339 */     registerChangeListener(this.flow.getVbar().visibleProperty(), paramObservableValue -> updateContentWidth());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 362 */     ObjectProperty<ObservableList<?>> objectProperty = TableSkinUtils.itemsProperty(this);
/*     */     
/* 364 */     getVisibleLeafColumns().removeListener(this.weakVisibleLeafColumnsListener);
/* 365 */     objectProperty.removeListener(this.weakItemsChangeListener);
/* 366 */     getSkinnable().getProperties().removeListener(this.propertiesMapListener);
/* 367 */     updateTableItems((ObservableList<S>)objectProperty.get(), (ObservableList<S>)null);
/*     */     
/* 369 */     super.dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 374 */     return 400.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 379 */     double d1 = computePrefHeight(-1.0D, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */     
/* 381 */     ObservableList<? extends TC> observableList = getVisibleLeafColumns();
/* 382 */     if (observableList == null || observableList.isEmpty()) {
/* 383 */       return d1 * 0.618033987D;
/*     */     }
/*     */     
/* 386 */     double d2 = paramDouble5 + paramDouble3; byte b; int i;
/* 387 */     for (b = 0, i = observableList.size(); b < i; b++) {
/* 388 */       TableColumnBase tableColumnBase = (TableColumnBase)observableList.get(b);
/* 389 */       d2 += Math.max(tableColumnBase.getPrefWidth(), tableColumnBase.getMinWidth());
/*     */     } 
/*     */     
/* 392 */     return Math.max(d2, d1 * 0.618033987D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 399 */     C c = getSkinnable();
/*     */ 
/*     */ 
/*     */     
/* 403 */     if (c == null) {
/*     */       return;
/*     */     }
/*     */     
/* 407 */     super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */     
/* 409 */     if (this.needCellsRecreated) {
/* 410 */       this.flow.recreateCells();
/* 411 */     } else if (this.needCellsReconfigured) {
/* 412 */       this.flow.reconfigureCells();
/*     */     } 
/*     */     
/* 415 */     this.needCellsRecreated = false;
/* 416 */     this.needCellsReconfigured = false;
/*     */     
/* 418 */     double d1 = c.getLayoutBounds().getHeight() / 2.0D;
/*     */ 
/*     */     
/* 421 */     double d2 = this.tableHeaderRow.prefHeight(-1.0D);
/* 422 */     layoutInArea(this.tableHeaderRow, paramDouble1, paramDouble2, paramDouble3, d2, d1, HPos.CENTER, VPos.CENTER);
/*     */     
/* 424 */     paramDouble2 += d2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 430 */     double d3 = Math.floor(paramDouble4 - d2);
/* 431 */     if (getItemCount() == 0 || this.visibleColCount == 0) {
/*     */       
/* 433 */       layoutInArea(this.placeholderRegion, paramDouble1, paramDouble2, paramDouble3, d3, d1, HPos.CENTER, VPos.CENTER);
/*     */     }
/*     */     else {
/*     */       
/* 437 */       layoutInArea(this.flow, paramDouble1, paramDouble2, paramDouble3, d3, d1, HPos.CENTER, VPos.CENTER);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 443 */     if (this.tableHeaderRow.getReorderingRegion() != null) {
/* 444 */       TableColumnHeader tableColumnHeader = this.tableHeaderRow.getReorderingRegion();
/* 445 */       TableColumnBase<?, ?> tableColumnBase = tableColumnHeader.getTableColumn();
/* 446 */       if (tableColumnBase != null) {
/* 447 */         TableColumnHeader tableColumnHeader1 = this.tableHeaderRow.getReorderingRegion();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 453 */         double d6 = this.tableHeaderRow.sceneToLocal(tableColumnHeader1.localToScene(tableColumnHeader1.getBoundsInLocal())).getMinX();
/* 454 */         double d7 = tableColumnHeader.getWidth();
/* 455 */         if (d6 < 0.0D) {
/* 456 */           d7 += d6;
/*     */         }
/* 458 */         d6 = (d6 < 0.0D) ? 0.0D : d6;
/*     */ 
/*     */ 
/*     */         
/* 462 */         if (d6 + d7 > paramDouble3) {
/* 463 */           d7 = paramDouble3 - d6;
/*     */           
/* 465 */           if (this.flow.getVbar().isVisible()) {
/* 466 */             d7 -= this.flow.getVbar().getWidth() - 1.0D;
/*     */           }
/*     */         } 
/*     */         
/* 470 */         double d8 = d3;
/* 471 */         if (this.flow.getHbar().isVisible()) {
/* 472 */           d8 -= this.flow.getHbar().getHeight();
/*     */         }
/*     */         
/* 475 */         this.columnReorderOverlay.resize(d7, d8);
/*     */         
/* 477 */         this.columnReorderOverlay.setLayoutX(d6);
/* 478 */         this.columnReorderOverlay.setLayoutY(this.tableHeaderRow.getHeight());
/*     */       } 
/*     */ 
/*     */       
/* 482 */       double d4 = this.columnReorderLine.snappedLeftInset() + this.columnReorderLine.snappedRightInset();
/* 483 */       double d5 = paramDouble4 - (this.flow.getHbar().isVisible() ? (this.flow.getHbar().getHeight() - 1.0D) : 0.0D);
/* 484 */       this.columnReorderLine.resizeRelocate(0.0D, this.columnReorderLine.snappedTopInset(), d4, d5);
/*     */     } 
/*     */     
/* 487 */     this.columnReorderLine.setVisible(this.tableHeaderRow.isReordering());
/* 488 */     this.columnReorderOverlay.setVisible(this.tableHeaderRow.isReordering());
/*     */     
/* 490 */     checkContentWidthState();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TableHeaderRow createTableHeaderRow() {
/* 500 */     return new TableHeaderRow(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final TableHeaderRow getTableHeaderRow() {
/* 512 */     return this.tableHeaderRow;
/*     */   }
/*     */   
/*     */   private TableSelectionModel<S> getSelectionModel() {
/* 516 */     return TableSkinUtils.getSelectionModel(this);
/*     */   }
/*     */   
/*     */   private TableFocusModel<M, ?> getFocusModel() {
/* 520 */     return TableSkinUtils.getFocusModel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   private TablePositionBase<? extends TC> getFocusedCell() {
/* 525 */     return (TablePositionBase)TableSkinUtils.getFocusedCell(this);
/*     */   }
/*     */ 
/*     */   
/*     */   private ObservableList<? extends TC> getVisibleLeafColumns() {
/* 530 */     return TableSkinUtils.getVisibleLeafColumns(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateItemCount() {
/* 535 */     updatePlaceholderRegionVisibility();
/*     */     
/* 537 */     int i = this.itemCount;
/* 538 */     int j = getItemCount();
/*     */     
/* 540 */     this.itemCount = j;
/*     */     
/* 542 */     if (this.itemCount == 0) {
/* 543 */       this.flow.getHbar().setValue(0.0D);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 549 */     this.flow.setCellCount(j);
/*     */     
/* 551 */     if (j != i) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 556 */       requestRebuildCells();
/*     */     } else {
/* 558 */       this.needCellsReconfigured = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkContentWidthState() {
/* 566 */     if (this.contentWidthDirty || getItemCount() == 0) {
/* 567 */       updateContentWidth();
/* 568 */       this.contentWidthDirty = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   void horizontalScroll() {
/* 573 */     this.tableHeaderRow.updateScrollX();
/*     */   }
/*     */   
/*     */   void onFocusPreviousCell() {
/* 577 */     TableFocusModel<M, ?> tableFocusModel = getFocusModel();
/* 578 */     if (tableFocusModel == null)
/*     */       return; 
/* 580 */     this.flow.scrollTo(tableFocusModel.getFocusedIndex());
/*     */   }
/*     */   
/*     */   void onFocusNextCell() {
/* 584 */     TableFocusModel<M, ?> tableFocusModel = getFocusModel();
/* 585 */     if (tableFocusModel == null)
/*     */       return; 
/* 587 */     this.flow.scrollTo(tableFocusModel.getFocusedIndex());
/*     */   }
/*     */   
/*     */   void onSelectPreviousCell() {
/* 591 */     TableSelectionModel<S> tableSelectionModel = getSelectionModel();
/* 592 */     if (tableSelectionModel == null)
/*     */       return; 
/* 594 */     this.flow.scrollTo(tableSelectionModel.getSelectedIndex());
/*     */   }
/*     */   
/*     */   void onSelectNextCell() {
/* 598 */     TableSelectionModel<S> tableSelectionModel = getSelectionModel();
/* 599 */     if (tableSelectionModel == null)
/*     */       return; 
/* 601 */     this.flow.scrollTo(tableSelectionModel.getSelectedIndex());
/*     */   }
/*     */   
/*     */   void onSelectLeftCell() {
/* 605 */     scrollHorizontally();
/*     */   }
/*     */   
/*     */   void onSelectRightCell() {
/* 609 */     scrollHorizontally();
/*     */   }
/*     */   
/*     */   void onMoveToFirstCell() {
/* 613 */     this.flow.scrollTo(0);
/* 614 */     this.flow.setPosition(0.0D);
/*     */   }
/*     */   
/*     */   void onMoveToLastCell() {
/* 618 */     int i = getItemCount();
/* 619 */     this.flow.scrollTo(i);
/* 620 */     this.flow.setPosition(1.0D);
/*     */   }
/*     */   
/*     */   private void updateTableItems(ObservableList<S> paramObservableList1, ObservableList<S> paramObservableList2) {
/* 624 */     if (paramObservableList1 != null) {
/* 625 */       paramObservableList1.removeListener(this.weakRowCountListener);
/*     */     }
/*     */     
/* 628 */     if (paramObservableList2 != null) {
/* 629 */       paramObservableList2.addListener(this.weakRowCountListener);
/*     */     }
/*     */     
/* 632 */     markItemCountDirty();
/* 633 */     getSkinnable().requestLayout();
/*     */   }
/*     */   
/*     */   Region getColumnReorderLine() {
/* 637 */     return this.columnReorderLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int onScrollPageDown(boolean paramBoolean) {
/*     */     boolean bool;
/* 645 */     TableSelectionModel<S> tableSelectionModel = getSelectionModel();
/* 646 */     if (tableSelectionModel == null) return -1;
/*     */     
/* 648 */     int i = getItemCount();
/*     */     
/* 650 */     I i1 = this.flow.getLastVisibleCellWithinViewPort();
/* 651 */     if (i1 == null) return -1;
/*     */     
/* 653 */     int j = i1.getIndex();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 658 */     j = (j >= i) ? (i - 1) : j;
/*     */ 
/*     */ 
/*     */     
/* 662 */     if (paramBoolean) {
/* 663 */       bool = (i1.isFocused() || isCellFocused(j)) ? true : false;
/*     */     } else {
/* 665 */       bool = (i1.isSelected() || isCellSelected(j)) ? true : false;
/*     */     } 
/*     */     
/* 668 */     if (bool) {
/* 669 */       boolean bool1 = isLeadIndex(paramBoolean, j);
/*     */       
/* 671 */       if (bool1) {
/*     */ 
/*     */         
/* 674 */         this.flow.scrollToTop(i1);
/*     */         
/* 676 */         I i2 = this.flow.getLastVisibleCellWithinViewPort();
/* 677 */         i1 = (i2 == null) ? i1 : i2;
/*     */       } 
/*     */     } 
/*     */     
/* 681 */     int k = i1.getIndex();
/* 682 */     k = (k >= i) ? (i - 1) : k;
/* 683 */     this.flow.scrollTo(k);
/* 684 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int onScrollPageUp(boolean paramBoolean) {
/* 692 */     I i = this.flow.getFirstVisibleCellWithinViewPort();
/* 693 */     if (i == null) return -1;
/*     */     
/* 695 */     int j = i.getIndex();
/*     */ 
/*     */     
/* 698 */     boolean bool = false;
/* 699 */     if (paramBoolean) {
/* 700 */       bool = (i.isFocused() || isCellFocused(j)) ? true : false;
/*     */     } else {
/* 702 */       bool = (i.isSelected() || isCellSelected(j)) ? true : false;
/*     */     } 
/*     */     
/* 705 */     if (bool) {
/* 706 */       boolean bool1 = isLeadIndex(paramBoolean, j);
/*     */       
/* 708 */       if (bool1) {
/*     */ 
/*     */         
/* 711 */         this.flow.scrollToBottom(i);
/*     */         
/* 713 */         I i1 = this.flow.getFirstVisibleCellWithinViewPort();
/* 714 */         i = (i1 == null) ? i : i1;
/*     */       } 
/*     */     } 
/*     */     
/* 718 */     int k = i.getIndex();
/* 719 */     this.flow.scrollTo(k);
/* 720 */     return k;
/*     */   }
/*     */   
/*     */   private boolean isLeadIndex(boolean paramBoolean, int paramInt) {
/* 724 */     TableSelectionModel<S> tableSelectionModel = getSelectionModel();
/* 725 */     TableFocusModel<M, ?> tableFocusModel = getFocusModel();
/*     */     
/* 727 */     return ((paramBoolean && tableFocusModel.getFocusedIndex() == paramInt) || (!paramBoolean && tableSelectionModel
/* 728 */       .getSelectedIndex() == paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateVisibleColumnCount() {
/* 735 */     this.visibleColCount = getVisibleLeafColumns().size();
/*     */     
/* 737 */     updatePlaceholderRegionVisibility();
/* 738 */     requestRebuildCells();
/*     */   }
/*     */   
/*     */   private void updateVisibleLeafColumnWidthListeners(List<? extends TC> paramList1, List<? extends TC> paramList2) {
/*     */     byte b;
/*     */     int i;
/* 744 */     for (b = 0, i = paramList2.size(); b < i; b++) {
/* 745 */       TableColumnBase tableColumnBase = (TableColumnBase)paramList2.get(b);
/* 746 */       tableColumnBase.widthProperty().removeListener(this.weakWidthListener);
/*     */     } 
/* 748 */     for (b = 0, i = paramList1.size(); b < i; b++) {
/* 749 */       TableColumnBase tableColumnBase = (TableColumnBase)paramList1.get(b);
/* 750 */       tableColumnBase.widthProperty().addListener(this.weakWidthListener);
/*     */     } 
/* 752 */     requestRebuildCells();
/*     */   }
/*     */   
/*     */   final void updatePlaceholderRegionVisibility() {
/* 756 */     boolean bool = (this.visibleColCount == 0 || getItemCount() == 0) ? true : false;
/*     */     
/* 758 */     if (bool) {
/* 759 */       if (this.placeholderRegion == null) {
/* 760 */         this.placeholderRegion = new StackPane();
/* 761 */         this.placeholderRegion.getStyleClass().setAll(new String[] { "placeholder" });
/* 762 */         getChildren().add(this.placeholderRegion);
/*     */       } 
/*     */       
/* 765 */       Node node = TableSkinUtils.placeholderProperty(this).get();
/*     */       
/* 767 */       if (node == null) {
/* 768 */         if (this.placeholderLabel == null) {
/* 769 */           this.placeholderLabel = new Label();
/*     */         }
/* 771 */         String str = (this.visibleColCount == 0) ? this.NO_COLUMNS_TEXT : this.EMPTY_TABLE_TEXT;
/* 772 */         this.placeholderLabel.setText(str);
/*     */         
/* 774 */         this.placeholderRegion.getChildren().setAll(new Node[] { this.placeholderLabel });
/*     */       } else {
/* 776 */         this.placeholderRegion.getChildren().setAll(new Node[] { node });
/*     */       } 
/*     */     } 
/*     */     
/* 780 */     this.flow.setVisible(!bool);
/* 781 */     if (this.placeholderRegion != null) {
/* 782 */       this.placeholderRegion.setVisible(bool);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateContentWidth() {
/* 792 */     double d = this.flow.getWidth();
/*     */     
/* 794 */     if (this.flow.getVbar().isVisible()) {
/* 795 */       d -= this.flow.getVbar().getWidth();
/*     */     }
/*     */     
/* 798 */     if (d <= 0.0D) {
/*     */       
/* 800 */       C c = getSkinnable();
/* 801 */       d = c.getWidth() - snappedLeftInset() + snappedRightInset();
/*     */     } 
/*     */     
/* 804 */     d = Math.max(0.0D, d);
/*     */ 
/*     */ 
/*     */     
/* 808 */     getSkinnable().getProperties().put("TableView.contentWidth", Double.valueOf(Math.floor(d)));
/*     */   }
/*     */   
/*     */   private void refreshView() {
/* 812 */     markItemCountDirty();
/* 813 */     C c = getSkinnable();
/* 814 */     if (c != null) {
/* 815 */       c.requestLayout();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void scrollHorizontally() {
/* 823 */     TableFocusModel<M, ?> tableFocusModel = getFocusModel();
/* 824 */     if (tableFocusModel == null)
/*     */       return; 
/* 826 */     TC tC = getFocusedCell().getTableColumn();
/* 827 */     scrollHorizontally(tC);
/*     */   }
/*     */   void scrollHorizontally(TC paramTC) {
/*     */     double d6;
/* 831 */     if (paramTC == null || !paramTC.isVisible())
/*     */       return; 
/* 833 */     C c = getSkinnable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 840 */     TableColumnHeader tableColumnHeader = this.tableHeaderRow.getColumnHeaderFor((TableColumnBase<?, ?>)paramTC);
/* 841 */     if (tableColumnHeader == null || tableColumnHeader.getWidth() <= 0.0D) {
/* 842 */       Platform.runLater(() -> scrollHorizontally((TC)paramTableColumnBase));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 847 */     double d1 = 0.0D;
/* 848 */     for (TableColumnBase tableColumnBase : getVisibleLeafColumns()) {
/* 849 */       if (tableColumnBase.equals(paramTC))
/* 850 */         break;  d1 += tableColumnBase.getWidth();
/*     */     } 
/* 852 */     double d2 = d1 + paramTC.getWidth();
/*     */ 
/*     */     
/* 855 */     double d3 = c.getWidth() - snappedLeftInset() - snappedRightInset();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 861 */     double d4 = this.flow.getHbar().getValue();
/* 862 */     double d5 = this.flow.getHbar().getMax();
/*     */ 
/*     */     
/* 865 */     if (d1 < d4 && d1 >= 0.0D) {
/* 866 */       d6 = d1;
/*     */     } else {
/* 868 */       double d = (d1 < 0.0D || d2 > d3) ? (d1 - d4) : 0.0D;
/* 869 */       d6 = (d4 + d > d5) ? d5 : (d4 + d);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 876 */     this.flow.getHbar().setValue(d6);
/*     */   }
/*     */   
/*     */   private boolean isCellSelected(int paramInt) {
/* 880 */     TableSelectionModel<S> tableSelectionModel = getSelectionModel();
/* 881 */     if (tableSelectionModel == null) return false; 
/* 882 */     if (!tableSelectionModel.isCellSelectionEnabled()) return false;
/*     */     
/* 884 */     int i = getVisibleLeafColumns().size();
/* 885 */     for (byte b = 0; b < i; b++) {
/* 886 */       if (tableSelectionModel.isSelected(paramInt, TableSkinUtils.getVisibleLeafColumn(this, b))) {
/* 887 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 891 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isCellFocused(int paramInt) {
/* 895 */     TableFocusModel<M, ?> tableFocusModel = getFocusModel();
/* 896 */     if (tableFocusModel == null) return false;
/*     */     
/* 898 */     int i = getVisibleLeafColumns().size();
/* 899 */     for (byte b = 0; b < i; b++) {
/* 900 */       if (tableFocusModel.isFocused(paramInt, TableSkinUtils.getVisibleLeafColumn(this, b))) {
/* 901 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 905 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*     */     TableFocusModel<M, ?> tableFocusModel;
/*     */     int i;
/*     */     int j;
/* 918 */     switch (paramAccessibleAttribute) {
/*     */       case FOCUS_ITEM:
/* 920 */         tableFocusModel = getFocusModel();
/* 921 */         j = tableFocusModel.getFocusedIndex();
/* 922 */         if (j == -1) {
/* 923 */           if (this.placeholderRegion != null && this.placeholderRegion.isVisible()) {
/* 924 */             return this.placeholderRegion.getChildren().get(0);
/*     */           }
/* 926 */           if (getItemCount() > 0) {
/* 927 */             j = 0;
/*     */           } else {
/* 929 */             return null;
/*     */           } 
/*     */         } 
/* 932 */         return this.flow.getPrivateCell(j);
/*     */       
/*     */       case CELL_AT_ROW_COLUMN:
/* 935 */         i = ((Integer)paramVarArgs[0]).intValue();
/* 936 */         return this.flow.getPrivateCell(i);
/*     */       
/*     */       case COLUMN_AT_INDEX:
/* 939 */         i = ((Integer)paramVarArgs[0]).intValue();
/* 940 */         j = TableSkinUtils.getVisibleLeafColumn(this, i);
/* 941 */         return getTableHeaderRow().getColumnHeaderFor(j);
/*     */ 
/*     */ 
/*     */       
/*     */       case HEADER:
/* 946 */         return getTableHeaderRow();
/*     */       case VERTICAL_SCROLLBAR:
/* 948 */         return this.flow.getVbar();
/* 949 */       case HORIZONTAL_SCROLLBAR: return this.flow.getHbar();
/* 950 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TableViewSkinBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */