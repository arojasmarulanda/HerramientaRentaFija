/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.NodeOrientation;
/*     */ import javafx.scene.Cursor;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TableView;
/*     */ import javafx.scene.control.TreeTableView;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.shape.Rectangle;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NestedTableColumnHeader
/*     */   extends TableColumnHeader
/*     */ {
/*     */   static final String DEFAULT_STYLE_CLASS = "nested-column-header";
/*     */   private static final int DRAG_RECT_WIDTH = 4;
/*     */   private static final String TABLE_COLUMN_KEY = "TableColumn";
/*     */   private static final String TABLE_COLUMN_HEADER_KEY = "TableColumnHeader";
/*     */   private ObservableList<? extends TableColumnBase> columns;
/*     */   private TableColumnHeader label;
/*     */   private ObservableList<TableColumnHeader> columnHeaders;
/*     */   private ObservableList<TableColumnHeader> unmodifiableColumnHeaders;
/*  97 */   private double lastX = 0.0D;
/*  98 */   private double dragAnchorX = 0.0D;
/*     */ 
/*     */   
/* 101 */   private Map<TableColumnBase<?, ?>, Rectangle> dragRects = new WeakHashMap<>();
/*     */ 
/*     */   
/*     */   boolean updateColumns = true;
/*     */   
/*     */   private final ListChangeListener<TableColumnBase> columnsListener;
/*     */   
/*     */   private final WeakListChangeListener weakColumnsListener;
/*     */   
/*     */   private static final EventHandler<MouseEvent> rectMousePressed;
/*     */   
/*     */   private static final EventHandler<MouseEvent> rectMouseDragged;
/*     */   
/*     */   private static final EventHandler<MouseEvent> rectMouseReleased;
/*     */   
/*     */   private static final EventHandler<MouseEvent> rectCursorChangeListener;
/*     */ 
/*     */   
/*     */   public NestedTableColumnHeader(TableColumnBase paramTableColumnBase) {
/* 120 */     super(paramTableColumnBase);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     this.columnsListener = (paramChange -> setHeadersNeedUpdate());
/*     */ 
/*     */ 
/*     */     
/* 148 */     this.weakColumnsListener = new WeakListChangeListener<>(this.columnsListener); setFocusTraversable(false); this.label = createTableColumnHeader(getTableColumn()); this.label.setTableHeaderRow(getTableHeaderRow()); this.label.setParentHeader(getParentHeader());
/*     */     this.label.setNestedColumnHeader(this);
/*     */     if (getTableColumn() != null)
/* 151 */       this.changeListenerHandler.registerChangeListener(getTableColumn().textProperty(), paramObservableValue -> this.label.setVisible((getTableColumn().getText() != null && !getTableColumn().getText().isEmpty())));  } static { rectMousePressed = (paramMouseEvent -> {
/*     */         Rectangle rectangle = (Rectangle)paramMouseEvent.getSource();
/*     */         
/*     */         TableColumnBase<?, ?> tableColumnBase = (TableColumnBase)rectangle.getProperties().get("TableColumn");
/*     */         
/*     */         NestedTableColumnHeader nestedTableColumnHeader = (NestedTableColumnHeader)rectangle.getProperties().get("TableColumnHeader");
/*     */         
/*     */         if (!nestedTableColumnHeader.isColumnResizingEnabled()) {
/*     */           return;
/*     */         }
/*     */         
/*     */         if ((nestedTableColumnHeader.getTableHeaderRow()).columnDragLock) {
/*     */           return;
/*     */         }
/*     */         
/*     */         if (paramMouseEvent.isConsumed()) {
/*     */           return;
/*     */         }
/*     */         paramMouseEvent.consume();
/*     */         if (paramMouseEvent.getClickCount() == 2 && paramMouseEvent.isPrimaryButtonDown()) {
/*     */           TableSkinUtils.resizeColumnToFitContent(nestedTableColumnHeader.getTableSkin(), tableColumnBase, -1);
/*     */         } else {
/*     */           Rectangle rectangle1 = (Rectangle)paramMouseEvent.getSource();
/*     */           double d = nestedTableColumnHeader.getTableHeaderRow().sceneToLocal(rectangle1.localToScene(rectangle1.getBoundsInLocal())).getMinX() + 2.0D;
/*     */           nestedTableColumnHeader.dragAnchorX = paramMouseEvent.getSceneX();
/*     */           nestedTableColumnHeader.columnResizingStarted(d);
/*     */         } 
/*     */       });
/* 179 */     rectMouseDragged = (paramMouseEvent -> {
/*     */         Rectangle rectangle = (Rectangle)paramMouseEvent.getSource();
/*     */         
/*     */         TableColumnBase tableColumnBase = (TableColumnBase)rectangle.getProperties().get("TableColumn");
/*     */         NestedTableColumnHeader nestedTableColumnHeader = (NestedTableColumnHeader)rectangle.getProperties().get("TableColumnHeader");
/*     */         if (!nestedTableColumnHeader.isColumnResizingEnabled()) {
/*     */           return;
/*     */         }
/*     */         if ((nestedTableColumnHeader.getTableHeaderRow()).columnDragLock) {
/*     */           return;
/*     */         }
/*     */         if (paramMouseEvent.isConsumed()) {
/*     */           return;
/*     */         }
/*     */         paramMouseEvent.consume();
/*     */         nestedTableColumnHeader.columnResizing(tableColumnBase, paramMouseEvent);
/*     */       });
/* 196 */     rectMouseReleased = (paramMouseEvent -> {
/*     */         Rectangle rectangle = (Rectangle)paramMouseEvent.getSource();
/*     */         
/*     */         TableColumnBase tableColumnBase = (TableColumnBase)rectangle.getProperties().get("TableColumn");
/*     */         NestedTableColumnHeader nestedTableColumnHeader = (NestedTableColumnHeader)rectangle.getProperties().get("TableColumnHeader");
/*     */         if (!nestedTableColumnHeader.isColumnResizingEnabled()) {
/*     */           return;
/*     */         }
/*     */         if ((nestedTableColumnHeader.getTableHeaderRow()).columnDragLock) {
/*     */           return;
/*     */         }
/*     */         if (paramMouseEvent.isConsumed()) {
/*     */           return;
/*     */         }
/*     */         paramMouseEvent.consume();
/*     */         nestedTableColumnHeader.columnResizingComplete(tableColumnBase, paramMouseEvent);
/*     */       });
/* 213 */     rectCursorChangeListener = (paramMouseEvent -> {
/*     */         Rectangle rectangle = (Rectangle)paramMouseEvent.getSource();
/*     */         
/*     */         TableColumnBase tableColumnBase = (TableColumnBase)rectangle.getProperties().get("TableColumn");
/*     */         
/*     */         NestedTableColumnHeader nestedTableColumnHeader = (NestedTableColumnHeader)rectangle.getProperties().get("TableColumnHeader");
/*     */         if ((nestedTableColumnHeader.getTableHeaderRow()).columnDragLock) {
/*     */           return;
/*     */         }
/*     */         if (nestedTableColumnHeader.getCursor() == null) {
/* 223 */           rectangle.setCursor((nestedTableColumnHeader.isColumnResizingEnabled() && rectangle.isHover() && tableColumnBase.isResizable()) ? Cursor.H_RESIZE : null);
/*     */         }
/*     */       }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {
/* 238 */     super.dispose();
/*     */     
/* 240 */     if (this.label != null) {
/* 241 */       this.label.dispose();
/*     */     }
/*     */     
/* 244 */     if (getColumns() != null) {
/* 245 */       getColumns().removeListener(this.weakColumnsListener);
/*     */     }
/*     */     
/* 248 */     for (byte b = 0; b < getColumnHeaders().size(); b++) {
/* 249 */       TableColumnHeader tableColumnHeader = getColumnHeaders().get(b);
/* 250 */       tableColumnHeader.dispose();
/*     */     } 
/*     */     
/* 253 */     for (Rectangle rectangle : this.dragRects.values()) {
/* 254 */       if (rectangle != null) {
/* 255 */         rectangle.visibleProperty().unbind();
/*     */       }
/*     */     } 
/* 258 */     this.dragRects.clear();
/* 259 */     getChildren().clear();
/*     */     
/* 261 */     this.changeListenerHandler.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<TableColumnHeader> getColumnHeaders() {
/* 270 */     if (this.columnHeaders == null) {
/* 271 */       this.columnHeaders = FXCollections.observableArrayList();
/* 272 */       this.unmodifiableColumnHeaders = FXCollections.unmodifiableObservableList(this.columnHeaders);
/*     */     } 
/* 274 */     return this.unmodifiableColumnHeaders;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void layoutChildren() {
/* 279 */     double d1 = getWidth() - snappedLeftInset() - snappedRightInset();
/* 280 */     double d2 = getHeight() - snappedTopInset() - snappedBottomInset();
/*     */     
/* 282 */     int i = 0;
/*     */     
/* 284 */     if (this.label.isVisible() && getTableColumn() != null) {
/* 285 */       i = (int)this.label.prefHeight(-1.0D);
/*     */       
/* 287 */       this.label.resize(d1, i);
/* 288 */       this.label.relocate(snappedLeftInset(), snappedTopInset());
/*     */     } 
/*     */ 
/*     */     
/* 292 */     double d3 = snappedLeftInset();
/* 293 */     double d4 = snapSizeY(d2 - i); byte b; int j;
/* 294 */     for (b = 0, j = getColumnHeaders().size(); b < j; b++) {
/* 295 */       TableColumnHeader tableColumnHeader = getColumnHeaders().get(b);
/* 296 */       if (tableColumnHeader.isVisible()) {
/*     */         
/* 298 */         double d = tableColumnHeader.prefWidth(d4);
/*     */ 
/*     */         
/* 301 */         tableColumnHeader.resize(d, d4);
/* 302 */         tableColumnHeader.relocate(d3, i + snappedTopInset());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 314 */         d3 += d;
/*     */ 
/*     */         
/* 317 */         Rectangle rectangle = this.dragRects.get(tableColumnHeader.getTableColumn());
/* 318 */         if (rectangle != null) {
/* 319 */           rectangle.setHeight(tableColumnHeader.getDragRectHeight());
/* 320 */           rectangle.relocate(d3 - 2.0D, snappedTopInset() + i);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble) {
/* 328 */     checkState();
/*     */     
/* 330 */     double d = 0.0D;
/*     */     
/* 332 */     if (getColumns() != null) {
/* 333 */       for (TableColumnHeader tableColumnHeader : getColumnHeaders()) {
/* 334 */         if (tableColumnHeader.isVisible()) {
/* 335 */           d += tableColumnHeader.computePrefWidth(paramDouble);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 340 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble) {
/* 345 */     checkState();
/*     */     
/* 347 */     double d1 = 0.0D;
/*     */     
/* 349 */     if (getColumnHeaders() != null) {
/* 350 */       for (TableColumnHeader tableColumnHeader : getColumnHeaders()) {
/* 351 */         d1 = Math.max(d1, tableColumnHeader.prefHeight(-1.0D));
/*     */       }
/*     */     }
/*     */     
/* 355 */     double d2 = 0.0D;
/* 356 */     if (this.label.isVisible() && getTableColumn() != null) {
/* 357 */       d2 = this.label.prefHeight(-1.0D);
/*     */     }
/*     */     
/* 360 */     return d1 + d2 + snappedTopInset() + snappedBottomInset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TableColumnHeader createTableColumnHeader(TableColumnBase<?, ?> paramTableColumnBase) {
/* 382 */     return (paramTableColumnBase == null || paramTableColumnBase.getColumns().isEmpty() || paramTableColumnBase == getTableColumn()) ? 
/* 383 */       new TableColumnHeader(paramTableColumnBase) : 
/* 384 */       new NestedTableColumnHeader(paramTableColumnBase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initStyleClasses() {
/* 396 */     getStyleClass().setAll(new String[] { "nested-column-header" });
/* 397 */     installTableColumnStyleClassListener();
/*     */   }
/*     */   
/*     */   void setTableHeaderRow(TableHeaderRow paramTableHeaderRow) {
/* 401 */     super.setTableHeaderRow(paramTableHeaderRow);
/*     */ 
/*     */     
/* 404 */     if (getTableSkin() != null) {
/* 405 */       this.changeListenerHandler.registerChangeListener(TableSkinUtils.columnResizePolicyProperty(getTableSkin()), paramObservableValue -> updateContent());
/*     */     }
/*     */     
/* 408 */     this.label.setTableHeaderRow(paramTableHeaderRow);
/*     */ 
/*     */     
/* 411 */     for (TableColumnHeader tableColumnHeader : getColumnHeaders()) {
/* 412 */       tableColumnHeader.setTableHeaderRow(paramTableHeaderRow);
/*     */     }
/*     */   }
/*     */   
/*     */   void setParentHeader(NestedTableColumnHeader paramNestedTableColumnHeader) {
/* 417 */     super.setParentHeader(paramNestedTableColumnHeader);
/* 418 */     this.label.setParentHeader(paramNestedTableColumnHeader);
/*     */   }
/*     */   
/*     */   ObservableList<? extends TableColumnBase> getColumns() {
/* 422 */     return this.columns;
/*     */   }
/*     */   
/*     */   void setColumns(ObservableList<? extends TableColumnBase> paramObservableList) {
/* 426 */     if (this.columns != null) {
/* 427 */       this.columns.removeListener(this.weakColumnsListener);
/*     */     }
/*     */     
/* 430 */     this.columns = paramObservableList;
/*     */     
/* 432 */     if (this.columns != null) {
/* 433 */       this.columns.addListener(this.weakColumnsListener);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void updateTableColumnHeaders() {
/* 439 */     if (getTableColumn() == null && getTableSkin() != null) {
/* 440 */       setColumns((ObservableList)TableSkinUtils.getColumns(getTableSkin()));
/* 441 */     } else if (getTableColumn() != null) {
/* 442 */       setColumns((ObservableList)getTableColumn().getColumns());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 450 */     if (getColumns().isEmpty()) {
/*     */       
/* 452 */       for (byte b = 0; b < getColumnHeaders().size(); b++) {
/* 453 */         TableColumnHeader tableColumnHeader = getColumnHeaders().get(b);
/* 454 */         tableColumnHeader.dispose();
/*     */       } 
/*     */ 
/*     */       
/* 458 */       NestedTableColumnHeader nestedTableColumnHeader = getParentHeader();
/* 459 */       if (nestedTableColumnHeader != null) {
/* 460 */         ObservableList<TableColumnHeader> observableList = nestedTableColumnHeader.getColumnHeaders();
/* 461 */         int i = observableList.indexOf(this);
/* 462 */         if (i >= 0 && i < observableList.size()) {
/* 463 */           observableList.set(i, createColumnHeader(getTableColumn()));
/*     */         }
/*     */       } else {
/*     */         
/* 467 */         this.columnHeaders.clear();
/*     */       } 
/*     */     } else {
/* 470 */       ArrayList<TableColumnHeader> arrayList1 = new ArrayList<>(getColumnHeaders());
/* 471 */       ArrayList<TableColumnHeader> arrayList2 = new ArrayList();
/*     */       byte b;
/* 473 */       for (b = 0; b < getColumns().size(); b++) {
/* 474 */         TableColumnBase<?, ?> tableColumnBase = getColumns().get(b);
/* 475 */         if (tableColumnBase != null && tableColumnBase.isVisible()) {
/*     */ 
/*     */           
/* 478 */           boolean bool = false;
/* 479 */           for (byte b1 = 0; b1 < arrayList1.size(); b1++) {
/* 480 */             TableColumnHeader tableColumnHeader = arrayList1.get(b1);
/* 481 */             if (tableColumnHeader.represents(tableColumnBase)) {
/* 482 */               arrayList2.add(tableColumnHeader);
/* 483 */               bool = true;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */           
/* 489 */           if (!bool) {
/* 490 */             arrayList2.add(createColumnHeader(tableColumnBase));
/*     */           }
/*     */         } 
/*     */       } 
/* 494 */       this.columnHeaders.setAll(arrayList2);
/*     */ 
/*     */       
/* 497 */       arrayList1.removeAll(arrayList2);
/* 498 */       for (b = 0; b < arrayList1.size(); b++) {
/* 499 */         ((TableColumnHeader)arrayList1.get(b)).dispose();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 504 */     updateContent();
/*     */ 
/*     */     
/* 507 */     for (TableColumnHeader tableColumnHeader : getColumnHeaders()) {
/* 508 */       tableColumnHeader.applyCss();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean represents(TableColumnBase<?, ?> paramTableColumnBase) {
/* 515 */     if (paramTableColumnBase.getColumns().isEmpty())
/*     */     {
/*     */       
/* 518 */       return false;
/*     */     }
/*     */     
/* 521 */     if (paramTableColumnBase != getTableColumn()) {
/* 522 */       return false;
/*     */     }
/*     */     
/* 525 */     int i = paramTableColumnBase.getColumns().size();
/* 526 */     int j = getColumnHeaders().size();
/* 527 */     if (i != j) {
/* 528 */       return false;
/*     */     }
/*     */     
/* 531 */     for (byte b = 0; b < i; b++) {
/*     */       
/* 533 */       TableColumnBase<?, ?> tableColumnBase = paramTableColumnBase.getColumns().get(b);
/* 534 */       TableColumnHeader tableColumnHeader = getColumnHeaders().get(b);
/* 535 */       if (!tableColumnHeader.represents(tableColumnBase)) {
/* 536 */         return false;
/*     */       }
/*     */     } 
/* 539 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   double getDragRectHeight() {
/* 544 */     return this.label.prefHeight(-1.0D);
/*     */   }
/*     */   
/*     */   void setHeadersNeedUpdate() {
/* 548 */     this.updateColumns = true;
/*     */ 
/*     */     
/* 551 */     for (byte b = 0; b < getColumnHeaders().size(); b++) {
/* 552 */       TableColumnHeader tableColumnHeader = getColumnHeaders().get(b);
/* 553 */       if (tableColumnHeader instanceof NestedTableColumnHeader) {
/* 554 */         ((NestedTableColumnHeader)tableColumnHeader).setHeadersNeedUpdate();
/*     */       }
/*     */     } 
/* 557 */     requestLayout();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateContent() {
/* 563 */     ArrayList<TableColumnHeader> arrayList = new ArrayList();
/*     */ 
/*     */     
/* 566 */     arrayList.add(this.label);
/*     */ 
/*     */     
/* 569 */     arrayList.addAll(getColumnHeaders());
/*     */ 
/*     */ 
/*     */     
/* 573 */     if (isColumnResizingEnabled()) {
/* 574 */       rebuildDragRects();
/* 575 */       arrayList.addAll((Collection)this.dragRects.values());
/*     */     } 
/*     */     
/* 578 */     getChildren().setAll((Collection)arrayList);
/*     */   }
/*     */   
/*     */   private void rebuildDragRects() {
/* 582 */     if (!isColumnResizingEnabled())
/*     */       return; 
/* 584 */     getChildren().removeAll(this.dragRects.values());
/*     */     
/* 586 */     for (Rectangle rectangle : this.dragRects.values()) {
/* 587 */       rectangle.visibleProperty().unbind();
/*     */     }
/* 589 */     this.dragRects.clear();
/*     */     
/* 591 */     ObservableList<? extends TableColumnBase> observableList = getColumns();
/*     */     
/* 593 */     if (observableList == null) {
/*     */       return;
/*     */     }
/*     */     
/* 597 */     boolean bool = false;
/* 598 */     TableViewSkinBase<?, ?, ?, ?, ?> tableViewSkinBase = getTableSkin();
/* 599 */     Callback callback = TableSkinUtils.columnResizePolicyProperty(tableViewSkinBase).get();
/* 600 */     if (callback != null)
/*     */     {
/*     */ 
/*     */       
/* 604 */       bool = (tableViewSkinBase instanceof TableViewSkin) ? TableView.CONSTRAINED_RESIZE_POLICY.equals(callback) : ((tableViewSkinBase instanceof TreeTableViewSkin) ? TreeTableView.CONSTRAINED_RESIZE_POLICY.equals(callback) : false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 609 */     if (bool && TableSkinUtils.getVisibleLeafColumns(tableViewSkinBase).size() == 1) {
/*     */       return;
/*     */     }
/*     */     
/* 613 */     for (byte b = 0; b < observableList.size() && (
/* 614 */       !bool || b != getColumns().size() - 1); b++) {
/*     */ 
/*     */ 
/*     */       
/* 618 */       TableColumnBase<?, ?> tableColumnBase = observableList.get(b);
/* 619 */       Rectangle rectangle = new Rectangle();
/* 620 */       rectangle.getProperties().put("TableColumn", tableColumnBase);
/* 621 */       rectangle.getProperties().put("TableColumnHeader", this);
/* 622 */       rectangle.setWidth(4.0D);
/* 623 */       rectangle.setHeight(getHeight() - this.label.getHeight());
/* 624 */       rectangle.setFill(Color.TRANSPARENT);
/* 625 */       rectangle.visibleProperty().bind(tableColumnBase.visibleProperty().and(tableColumnBase.resizableProperty()));
/* 626 */       rectangle.setOnMousePressed(rectMousePressed);
/* 627 */       rectangle.setOnMouseDragged(rectMouseDragged);
/* 628 */       rectangle.setOnMouseReleased(rectMouseReleased);
/* 629 */       rectangle.setOnMouseEntered(rectCursorChangeListener);
/* 630 */       rectangle.setOnMouseExited(rectCursorChangeListener);
/*     */       
/* 632 */       this.dragRects.put(tableColumnBase, rectangle);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkState() {
/* 637 */     if (this.updateColumns) {
/* 638 */       updateTableColumnHeaders();
/* 639 */       this.updateColumns = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private TableColumnHeader createColumnHeader(TableColumnBase paramTableColumnBase) {
/* 644 */     TableColumnHeader tableColumnHeader = createTableColumnHeader(paramTableColumnBase);
/* 645 */     tableColumnHeader.setTableHeaderRow(getTableHeaderRow());
/* 646 */     tableColumnHeader.setParentHeader(this);
/* 647 */     return tableColumnHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isColumnResizingEnabled() {
/* 662 */     return true;
/*     */   }
/*     */   
/*     */   private void columnResizingStarted(double paramDouble) {
/* 666 */     setCursor(Cursor.H_RESIZE);
/* 667 */     this.columnReorderLine.setLayoutX(paramDouble);
/*     */   }
/*     */   
/*     */   private void columnResizing(TableColumnBase<?, ?> paramTableColumnBase, MouseEvent paramMouseEvent) {
/* 671 */     double d1 = paramMouseEvent.getSceneX() - this.dragAnchorX;
/* 672 */     if (getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) {
/* 673 */       d1 = -d1;
/*     */     }
/* 675 */     double d2 = d1 - this.lastX;
/* 676 */     boolean bool = TableSkinUtils.resizeColumn(getTableSkin(), paramTableColumnBase, d2);
/* 677 */     if (bool) {
/* 678 */       this.lastX = d1;
/*     */     }
/*     */   }
/*     */   
/*     */   private void columnResizingComplete(TableColumnBase paramTableColumnBase, MouseEvent paramMouseEvent) {
/* 683 */     setCursor((Cursor)null);
/* 684 */     this.columnReorderLine.setTranslateX(0.0D);
/* 685 */     this.columnReorderLine.setLayoutX(0.0D);
/* 686 */     this.lastX = 0.0D;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\NestedTableColumnHeader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */