/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.ParentHelper;
/*     */ import com.sun.javafx.scene.control.FakeFocusTextField;
/*     */ import com.sun.javafx.scene.input.ExtendedInputMethodRequests;
/*     */ import com.sun.javafx.scene.traversal.Algorithm;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import com.sun.javafx.scene.traversal.ParentTraversalEngine;
/*     */ import com.sun.javafx.scene.traversal.TraversalContext;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ComboBoxBase;
/*     */ import javafx.scene.control.PopupControl;
/*     */ import javafx.scene.control.Skin;
/*     */ import javafx.scene.control.Skinnable;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.input.DragEvent;
/*     */ import javafx.scene.input.InputMethodEvent;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.stage.WindowEvent;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ComboBoxPopupControl<T>
/*     */   extends ComboBoxBaseSkin<T>
/*     */ {
/*     */   PopupControl popup;
/*     */   private boolean popupNeedsReconfiguring = true;
/*     */   private final ComboBoxBase<T> comboBoxBase;
/*     */   private TextField textField;
/*  82 */   private String initialTextFieldValue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EventHandler<MouseEvent> textFieldMouseEventHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EventHandler<DragEvent> textFieldDragEventHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxPopupControl(ComboBoxBase<T> paramComboBoxBase) {
/* 123 */     super(paramComboBoxBase); this.textFieldMouseEventHandler = (paramMouseEvent -> { ComboBoxBase<T> comboBoxBase = getSkinnable(); if (!paramMouseEvent.getTarget().equals(comboBoxBase)) { comboBoxBase.fireEvent(paramMouseEvent.copyFor(comboBoxBase, comboBoxBase)); paramMouseEvent.consume(); }  }); this.textFieldDragEventHandler = (paramDragEvent -> { ComboBoxBase<T> comboBoxBase = getSkinnable(); if (!paramDragEvent.getTarget().equals(comboBoxBase)) { comboBoxBase.fireEvent(paramDragEvent.copyFor(comboBoxBase, comboBoxBase)); paramDragEvent.consume(); } 
/* 124 */       }); this.comboBoxBase = paramComboBoxBase;
/*     */ 
/*     */     
/* 127 */     this.textField = (getEditor() != null) ? getEditableInputNode() : null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     if (this.textField != null) {
/* 133 */       getChildren().add(this.textField);
/*     */     }
/*     */ 
/*     */     
/* 137 */     this.comboBoxBase.focusedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*     */           if (getEditor() != null) {
/*     */             ((FakeFocusTextField)this.textField).setFakeFocus(paramBoolean2.booleanValue());
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 144 */     this.comboBoxBase.addEventFilter(KeyEvent.ANY, paramKeyEvent -> {
/*     */           if (this.textField == null || getEditor() == null) {
/*     */             handleKeyEvent(paramKeyEvent, false);
/*     */           }
/*     */           if (paramKeyEvent.getTarget().equals(this.textField)) {
/*     */             return;
/*     */           }
/*     */           switch (paramKeyEvent.getCode()) {
/*     */             case ESCAPE:
/*     */             case F10:
/*     */               return;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             case ENTER:
/*     */               handleKeyEvent(paramKeyEvent, true);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.textField.fireEvent(paramKeyEvent.copyFor(this.textField, this.textField));
/*     */           paramKeyEvent.consume();
/*     */         });
/* 174 */     if (this.comboBoxBase.getOnInputMethodTextChanged() == null) {
/* 175 */       this.comboBoxBase.setOnInputMethodTextChanged(paramInputMethodEvent -> {
/*     */             if (this.textField != null && getEditor() != null && this.comboBoxBase.getScene().getFocusOwner() == this.comboBoxBase && this.textField.getOnInputMethodTextChanged() != null) {
/*     */               this.textField.getOnInputMethodTextChanged().handle(paramInputMethodEvent);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     ParentHelper.setTraversalEngine(this.comboBoxBase, new ParentTraversalEngine(this.comboBoxBase, new Algorithm()
/*     */           {
/*     */             public Node select(Node param1Node, Direction param1Direction, TraversalContext param1TraversalContext)
/*     */             {
/* 189 */               return null;
/*     */             }
/*     */             
/*     */             public Node selectFirst(TraversalContext param1TraversalContext) {
/* 193 */               return null;
/*     */             }
/*     */             
/*     */             public Node selectLast(TraversalContext param1TraversalContext) {
/* 197 */               return null;
/*     */             }
/*     */           }));
/*     */     
/* 201 */     updateEditable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void show() {
/* 241 */     if (getSkinnable() == null) {
/* 242 */       throw new IllegalStateException("ComboBox is null");
/*     */     }
/*     */     
/* 245 */     Node node = getPopupContent();
/* 246 */     if (node == null) {
/* 247 */       throw new IllegalStateException("Popup node is null");
/*     */     }
/*     */     
/* 250 */     if (getPopup().isShowing())
/*     */       return; 
/* 252 */     positionAndShowPopup();
/*     */   }
/*     */ 
/*     */   
/*     */   public void hide() {
/* 257 */     if (this.popup != null && this.popup.isShowing()) {
/* 258 */       this.popup.hide();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PopupControl getPopup() {
/* 271 */     if (this.popup == null) {
/* 272 */       createPopup();
/*     */     }
/* 274 */     return this.popup;
/*     */   }
/*     */   
/*     */   TextField getEditableInputNode() {
/* 278 */     if (this.textField == null && getEditor() != null) {
/* 279 */       this.textField = getEditor();
/* 280 */       this.textField.setFocusTraversable(false);
/* 281 */       this.textField.promptTextProperty().bind(this.comboBoxBase.promptTextProperty());
/* 282 */       this.textField.tooltipProperty().bind(this.comboBoxBase.tooltipProperty());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 287 */       this.textField.getProperties().put("TextInputControlBehavior.disableForwardToParent", Boolean.valueOf(true));
/*     */ 
/*     */       
/* 290 */       this.initialTextFieldValue = this.textField.getText();
/*     */     } 
/*     */ 
/*     */     
/* 294 */     return this.textField;
/*     */   }
/*     */   
/*     */   void setTextFromTextFieldIntoComboBoxValue() {
/* 298 */     if (getEditor() != null) {
/* 299 */       StringConverter<T> stringConverter = getConverter();
/* 300 */       if (stringConverter != null) {
/* 301 */         T t1 = this.comboBoxBase.getValue();
/* 302 */         T t2 = t1;
/* 303 */         String str = this.textField.getText();
/*     */ 
/*     */         
/* 306 */         if (t1 == null && (str == null || str.isEmpty())) {
/* 307 */           t2 = null;
/*     */         } else {
/*     */           try {
/* 310 */             t2 = stringConverter.fromString(str);
/* 311 */           } catch (Exception exception) {}
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 316 */         if ((t2 != null || t1 != null) && (t2 == null || !t2.equals(t1)))
/*     */         {
/* 318 */           this.comboBoxBase.setValue(t2);
/*     */         }
/*     */         
/* 321 */         updateDisplayNode();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void updateDisplayNode() {
/* 327 */     if (this.textField != null && getEditor() != null) {
/* 328 */       T t = this.comboBoxBase.getValue();
/* 329 */       StringConverter<T> stringConverter = getConverter();
/*     */       
/* 331 */       if (this.initialTextFieldValue != null && !this.initialTextFieldValue.isEmpty()) {
/*     */         
/* 333 */         this.textField.setText(this.initialTextFieldValue);
/* 334 */         this.initialTextFieldValue = null;
/*     */       } else {
/*     */         
/* 337 */         String str = stringConverter.toString(t);
/* 338 */         if (t == null || str == null) {
/* 339 */           this.textField.setText("");
/* 340 */         } else if (!str.equals(this.textField.getText())) {
/* 341 */           this.textField.setText(str);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void updateEditable() {
/* 348 */     final TextField newTextField = getEditor();
/*     */     
/* 350 */     if (getEditor() == null) {
/*     */       
/* 352 */       if (this.textField != null) {
/* 353 */         this.textField.removeEventFilter(MouseEvent.DRAG_DETECTED, this.textFieldMouseEventHandler);
/* 354 */         this.textField.removeEventFilter(DragEvent.ANY, this.textFieldDragEventHandler);
/*     */         
/* 356 */         this.comboBoxBase.setInputMethodRequests(null);
/*     */       } 
/* 358 */     } else if (textField != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 363 */       textField.addEventFilter(MouseEvent.DRAG_DETECTED, this.textFieldMouseEventHandler);
/* 364 */       textField.addEventFilter(DragEvent.ANY, this.textFieldDragEventHandler);
/*     */ 
/*     */       
/* 367 */       this.comboBoxBase.setInputMethodRequests(new ExtendedInputMethodRequests() {
/*     */             public Point2D getTextLocation(int param1Int) {
/* 369 */               return newTextField.getInputMethodRequests().getTextLocation(param1Int);
/*     */             }
/*     */             
/*     */             public int getLocationOffset(int param1Int1, int param1Int2) {
/* 373 */               return newTextField.getInputMethodRequests().getLocationOffset(param1Int1, param1Int2);
/*     */             }
/*     */             
/*     */             public void cancelLatestCommittedText() {
/* 377 */               newTextField.getInputMethodRequests().cancelLatestCommittedText();
/*     */             }
/*     */             
/*     */             public String getSelectedText() {
/* 381 */               return newTextField.getInputMethodRequests().getSelectedText();
/*     */             }
/*     */             
/*     */             public int getInsertPositionOffset() {
/* 385 */               return ((ExtendedInputMethodRequests)newTextField.getInputMethodRequests()).getInsertPositionOffset();
/*     */             }
/*     */             
/*     */             public String getCommittedText(int param1Int1, int param1Int2) {
/* 389 */               return ((ExtendedInputMethodRequests)newTextField.getInputMethodRequests()).getCommittedText(param1Int1, param1Int2);
/*     */             }
/*     */             
/*     */             public int getCommittedTextLength() {
/* 393 */               return ((ExtendedInputMethodRequests)newTextField.getInputMethodRequests()).getCommittedTextLength();
/*     */             }
/*     */           });
/*     */     } 
/*     */     
/* 398 */     this.textField = textField;
/*     */   }
/*     */   
/*     */   private Point2D getPrefPopupPosition() {
/* 402 */     return Utils.pointRelativeTo(getSkinnable(), getPopupContent(), HPos.CENTER, VPos.BOTTOM, 0.0D, 0.0D, true);
/*     */   }
/*     */   
/*     */   private void positionAndShowPopup() {
/* 406 */     ComboBoxBase<T> comboBoxBase = getSkinnable();
/* 407 */     if (comboBoxBase.getScene() == null) {
/*     */       return;
/*     */     }
/*     */     
/* 411 */     PopupControl popupControl = getPopup();
/* 412 */     popupControl.getScene().setNodeOrientation(getSkinnable().getEffectiveNodeOrientation());
/*     */ 
/*     */     
/* 415 */     Node node = getPopupContent();
/* 416 */     sizePopup();
/*     */     
/* 418 */     Point2D point2D = getPrefPopupPosition();
/*     */     
/* 420 */     this.popupNeedsReconfiguring = true;
/* 421 */     reconfigurePopup();
/*     */     
/* 423 */     popupControl.show(comboBoxBase.getScene().getWindow(), 
/* 424 */         snapPositionX(point2D.getX()), 
/* 425 */         snapPositionY(point2D.getY()));
/*     */     
/* 427 */     node.requestFocus();
/*     */ 
/*     */ 
/*     */     
/* 431 */     sizePopup();
/*     */   }
/*     */   
/*     */   private void sizePopup() {
/* 435 */     Node node = getPopupContent();
/*     */     
/* 437 */     if (node instanceof Region) {
/*     */       
/* 439 */       Region region = (Region)node;
/*     */ 
/*     */       
/* 442 */       double d1 = snapSizeY(region.prefHeight(0.0D));
/* 443 */       double d2 = snapSizeY(region.minHeight(0.0D));
/* 444 */       double d3 = snapSizeY(region.maxHeight(0.0D));
/* 445 */       double d4 = snapSizeY(Math.min(Math.max(d1, d2), Math.max(d2, d3)));
/*     */       
/* 447 */       double d5 = snapSizeX(region.prefWidth(d4));
/* 448 */       double d6 = snapSizeX(region.minWidth(d4));
/* 449 */       double d7 = snapSizeX(region.maxWidth(d4));
/* 450 */       double d8 = snapSizeX(Math.min(Math.max(d5, d6), Math.max(d6, d7)));
/*     */       
/* 452 */       node.resize(d8, d4);
/*     */     } else {
/* 454 */       node.autosize();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void createPopup() {
/* 459 */     this.popup = new PopupControl() {
/*     */         public Styleable getStyleableParent() {
/* 461 */           return ComboBoxPopupControl.this.getSkinnable();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 471 */     this.popup.getStyleClass().add("combo-box-popup");
/* 472 */     this.popup.setConsumeAutoHidingEvents(false);
/* 473 */     this.popup.setAutoHide(true);
/* 474 */     this.popup.setAutoFix(true);
/* 475 */     this.popup.setHideOnEscape(true);
/* 476 */     this.popup.setOnAutoHide(paramEvent -> getBehavior().onAutoHide(this.popup));
/* 477 */     this.popup.addEventHandler(MouseEvent.MOUSE_CLICKED, paramMouseEvent -> getBehavior().onAutoHide(this.popup));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 484 */     this.popup.addEventHandler(WindowEvent.WINDOW_HIDDEN, paramWindowEvent -> getSkinnable().notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_NODE));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 491 */     InvalidationListener invalidationListener = paramObservable -> {
/*     */         this.popupNeedsReconfiguring = true;
/*     */         reconfigurePopup();
/*     */       };
/* 495 */     getSkinnable().layoutXProperty().addListener(invalidationListener);
/* 496 */     getSkinnable().layoutYProperty().addListener(invalidationListener);
/* 497 */     getSkinnable().widthProperty().addListener(invalidationListener);
/* 498 */     getSkinnable().heightProperty().addListener(invalidationListener);
/*     */ 
/*     */     
/* 501 */     getSkinnable().sceneProperty().addListener(paramObservable -> {
/*     */           if (((ObservableValue)paramObservable).getValue() == null) {
/*     */             hide();
/*     */           } else if (getSkinnable().isShowing()) {
/*     */             show();
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void reconfigurePopup() {
/* 515 */     if (this.popup == null)
/*     */       return; 
/* 517 */     boolean bool = this.popup.isShowing();
/* 518 */     if (!bool)
/*     */       return; 
/* 520 */     if (!this.popupNeedsReconfiguring)
/* 521 */       return;  this.popupNeedsReconfiguring = false;
/*     */     
/* 523 */     Point2D point2D = getPrefPopupPosition();
/*     */     
/* 525 */     Node node = getPopupContent();
/* 526 */     double d1 = node.prefWidth(-1.0D);
/* 527 */     double d2 = node.prefHeight(-1.0D);
/*     */     
/* 529 */     if (point2D.getX() > -1.0D) this.popup.setAnchorX(point2D.getX()); 
/* 530 */     if (point2D.getY() > -1.0D) this.popup.setAnchorY(point2D.getY()); 
/* 531 */     if (d1 > -1.0D) this.popup.setMinWidth(d1); 
/* 532 */     if (d2 > -1.0D) this.popup.setMinHeight(d2);
/*     */     
/* 534 */     Bounds bounds = node.getLayoutBounds();
/* 535 */     double d3 = bounds.getWidth();
/* 536 */     double d4 = bounds.getHeight();
/* 537 */     double d5 = (d3 < d1) ? d1 : d3;
/* 538 */     double d6 = (d4 < d2) ? d2 : d4;
/*     */     
/* 540 */     if (d5 != d3 || d6 != d4) {
/*     */ 
/*     */       
/* 543 */       node.resize(d5, d6);
/* 544 */       if (node instanceof Region) {
/* 545 */         ((Region)node).setMinSize(d5, d6);
/* 546 */         ((Region)node).setPrefSize(d5, d6);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleKeyEvent(KeyEvent paramKeyEvent, boolean paramBoolean) {
/* 554 */     if (paramKeyEvent.getCode() == KeyCode.ENTER) {
/* 555 */       if (paramKeyEvent.isConsumed() || paramKeyEvent.getEventType() != KeyEvent.KEY_RELEASED) {
/*     */         return;
/*     */       }
/* 558 */       setTextFromTextFieldIntoComboBoxValue();
/*     */       
/* 560 */       if (paramBoolean && this.comboBoxBase.getOnAction() != null) {
/* 561 */         paramKeyEvent.consume();
/* 562 */       } else if (this.textField != null) {
/* 563 */         this.textField.fireEvent(paramKeyEvent);
/*     */       } 
/* 565 */     } else if (paramKeyEvent.getCode() == KeyCode.F4) {
/* 566 */       if (paramKeyEvent.getEventType() == KeyEvent.KEY_RELEASED)
/* 567 */         if (this.comboBoxBase.isShowing()) { this.comboBoxBase.hide(); }
/* 568 */         else { this.comboBoxBase.show(); }
/*     */          
/* 570 */       paramKeyEvent.consume();
/* 571 */     } else if (paramKeyEvent.getCode() == KeyCode.F10 || paramKeyEvent.getCode() == KeyCode.ESCAPE) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 577 */       if (paramBoolean) paramKeyEvent.consume(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract Node getPopupContent();
/*     */   
/*     */   protected abstract TextField getEditor();
/*     */   
/*     */   protected abstract StringConverter<T> getConverter();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ComboBoxPopupControl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */