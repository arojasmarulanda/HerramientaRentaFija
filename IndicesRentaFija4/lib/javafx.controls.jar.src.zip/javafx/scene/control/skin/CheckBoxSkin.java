/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.ButtonBehavior;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.geometry.NodeOrientation;
/*     */ import javafx.scene.control.CheckBox;
/*     */ import javafx.scene.layout.StackPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckBoxSkin
/*     */   extends LabeledSkinBase<CheckBox>
/*     */ {
/*  53 */   private final StackPane box = new StackPane();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StackPane innerbox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final BehaviorBase<CheckBox> behavior;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CheckBoxSkin(CheckBox paramCheckBox) {
/*  73 */     super(paramCheckBox);
/*     */ 
/*     */     
/*  76 */     this.behavior = new ButtonBehavior<>(paramCheckBox);
/*     */ 
/*     */     
/*  79 */     this.box.getStyleClass().setAll(new String[] { "box" });
/*  80 */     this.innerbox = new StackPane();
/*  81 */     this.innerbox.getStyleClass().setAll(new String[] { "mark" });
/*  82 */     this.innerbox.setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
/*  83 */     this.box.getChildren().add(this.innerbox);
/*  84 */     updateChildren();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  97 */     super.dispose();
/*     */     
/*  99 */     if (this.behavior != null) {
/* 100 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateChildren() {
/* 106 */     super.updateChildren();
/* 107 */     if (this.box != null) {
/* 108 */       getChildren().add(this.box);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 114 */     return super.computeMinWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5) + snapSizeX(this.box.minWidth(-1.0D));
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 119 */     return Math.max(super.computeMinHeight(paramDouble1 - this.box.minWidth(-1.0D), paramDouble2, paramDouble3, paramDouble4, paramDouble5), paramDouble2 + this.box
/* 120 */         .minHeight(-1.0D) + paramDouble4);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 125 */     return super.computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5) + snapSizeX(this.box.prefWidth(-1.0D));
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 130 */     return Math.max(super.computePrefHeight(paramDouble1 - this.box.prefWidth(-1.0D), paramDouble2, paramDouble3, paramDouble4, paramDouble5), paramDouble2 + this.box
/* 131 */         .prefHeight(-1.0D) + paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 137 */     CheckBox checkBox = getSkinnable();
/* 138 */     double d1 = snapSizeX(this.box.prefWidth(-1.0D));
/* 139 */     double d2 = snapSizeY(this.box.prefHeight(-1.0D));
/* 140 */     double d3 = Math.max(checkBox.prefWidth(-1.0D), checkBox.minWidth(-1.0D));
/* 141 */     double d4 = Math.min(d3 - d1, paramDouble3 - snapSizeX(d1));
/* 142 */     double d5 = Math.min(checkBox.prefHeight(d4), paramDouble4);
/* 143 */     double d6 = Math.max(d2, d5);
/* 144 */     double d7 = Utils.computeXOffset(paramDouble3, d4 + d1, checkBox.getAlignment().getHpos()) + paramDouble1;
/* 145 */     double d8 = Utils.computeYOffset(paramDouble4, d6, checkBox.getAlignment().getVpos()) + paramDouble2;
/*     */     
/* 147 */     layoutLabelInArea(d7 + d1, d8, d4, d6, checkBox.getAlignment());
/* 148 */     this.box.resize(d1, d2);
/* 149 */     positionInArea(this.box, d7, d8, d1, d6, 0.0D, checkBox.getAlignment().getHpos(), checkBox.getAlignment().getVpos());
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\CheckBoxSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */