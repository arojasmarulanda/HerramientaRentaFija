/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import javafx.animation.Animation;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.KeyValue;
/*     */ import javafx.animation.Timeline;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableIntegerProperty;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.css.converter.PaintConverter;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.geometry.NodeOrientation;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ProgressIndicator;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.layout.Pane;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.paint.Paint;
/*     */ import javafx.scene.shape.Arc;
/*     */ import javafx.scene.shape.ArcType;
/*     */ import javafx.scene.shape.Circle;
/*     */ import javafx.scene.text.Text;
/*     */ import javafx.scene.text.TextBoundsType;
/*     */ import javafx.scene.transform.Scale;
/*     */ import javafx.scene.transform.Transform;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProgressIndicatorSkin
/*     */   extends SkinBase<ProgressIndicator>
/*     */ {
/*  99 */   private final String DONE = ControlResources.getString("ProgressIndicator.doneString");
/*     */   
/* 101 */   final Duration CLIPPED_DELAY = new Duration(300.0D);
/* 102 */   final Duration UNCLIPPED_DELAY = new Duration(0.0D);
/*     */ 
/*     */   
/*     */   private IndeterminateSpinner spinner;
/*     */ 
/*     */   
/*     */   private DeterminateIndicator determinateIndicator;
/*     */ 
/*     */   
/*     */   private ProgressIndicator control;
/*     */ 
/*     */   
/*     */   Animation indeterminateTransition;
/*     */ 
/*     */   
/*     */   private ObjectProperty<Paint> progressColor;
/*     */   
/*     */   private IntegerProperty indeterminateSegmentCount;
/*     */   
/*     */   private final BooleanProperty spinEnabled;
/*     */ 
/*     */   
/*     */   public ProgressIndicatorSkin(ProgressIndicator paramProgressIndicator) {
/* 125 */     super(paramProgressIndicator);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     this.progressColor = new StyleableObjectProperty<Paint>(null) {
/*     */         protected void invalidated() {
/* 152 */           Paint paint = get();
/* 153 */           if (paint != null && !(paint instanceof Color)) {
/* 154 */             if (isBound()) {
/* 155 */               unbind();
/*     */             }
/* 157 */             set((Paint)null);
/* 158 */             throw new IllegalArgumentException("Only Color objects are supported");
/*     */           } 
/* 160 */           if (ProgressIndicatorSkin.this.spinner != null) ProgressIndicatorSkin.this.spinner.setFillOverride(paint); 
/* 161 */           if (ProgressIndicatorSkin.this.determinateIndicator != null) ProgressIndicatorSkin.this.determinateIndicator.setFillOverride(paint); 
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 165 */           return ProgressIndicatorSkin.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 169 */           return "progressColorProperty";
/*     */         }
/*     */         
/*     */         public CssMetaData<ProgressIndicator, Paint> getCssMetaData() {
/* 173 */           return ProgressIndicatorSkin.PROGRESS_COLOR;
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     this.indeterminateSegmentCount = new StyleableIntegerProperty(8) {
/*     */         protected void invalidated() {
/* 186 */           if (ProgressIndicatorSkin.this.spinner != null) ProgressIndicatorSkin.this.spinner.rebuild(); 
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 190 */           return ProgressIndicatorSkin.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 194 */           return "indeterminateSegmentCount";
/*     */         }
/*     */         
/*     */         public CssMetaData<ProgressIndicator, Number> getCssMetaData() {
/* 198 */           return ProgressIndicatorSkin.INDETERMINATE_SEGMENT_COUNT;
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     this.spinEnabled = new StyleableBooleanProperty(false) {
/*     */         protected void invalidated() {
/* 207 */           if (ProgressIndicatorSkin.this.spinner != null) ProgressIndicatorSkin.this.spinner.setSpinEnabled(get()); 
/*     */         }
/*     */         
/*     */         public CssMetaData<ProgressIndicator, Boolean> getCssMetaData() {
/* 211 */           return ProgressIndicatorSkin.SPIN_ENABLED;
/*     */         }
/*     */         
/*     */         public Object getBean() {
/* 215 */           return ProgressIndicatorSkin.this;
/*     */         }
/*     */         
/*     */         public String getName() {
/* 219 */           return "spinEnabled";
/*     */         }
/*     */       };
/*     */     this.control = paramProgressIndicator;
/*     */     registerChangeListener(paramProgressIndicator.indeterminateProperty(), paramObservableValue -> initialize());
/*     */     registerChangeListener(paramProgressIndicator.progressProperty(), paramObservableValue -> updateProgress());
/*     */     registerChangeListener(NodeHelper.treeShowingProperty(paramProgressIndicator), paramObservableValue -> updateAnimation());
/*     */     registerChangeListener(paramProgressIndicator.sceneProperty(), paramObservableValue -> updateAnimation());
/*     */     initialize();
/*     */     updateAnimation();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 233 */     super.dispose();
/*     */     
/* 235 */     if (this.indeterminateTransition != null) {
/* 236 */       this.indeterminateTransition.stop();
/* 237 */       this.indeterminateTransition = null;
/*     */     } 
/*     */     
/* 240 */     if (this.spinner != null) {
/* 241 */       this.spinner = null;
/*     */     }
/*     */     
/* 244 */     this.control = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 250 */     if (this.spinner != null && this.control.isIndeterminate()) {
/* 251 */       this.spinner.layoutChildren();
/* 252 */       this.spinner.resizeRelocate(0.0D, 0.0D, paramDouble3, paramDouble4);
/* 253 */     } else if (this.determinateIndicator != null) {
/* 254 */       this.determinateIndicator.layoutChildren();
/* 255 */       this.determinateIndicator.resizeRelocate(0.0D, 0.0D, paramDouble3, paramDouble4);
/*     */     } 
/*     */   } Paint getProgressColor() {
/*     */     return this.progressColor.get();
/*     */   }
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 261 */     double d = 0.0D;
/*     */     
/* 263 */     if (this.spinner != null && this.control.isIndeterminate()) {
/* 264 */       d = this.spinner.minWidth(-1.0D);
/* 265 */     } else if (this.determinateIndicator != null) {
/* 266 */       d = this.determinateIndicator.minWidth(-1.0D);
/*     */     } 
/* 268 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 273 */     double d = 0.0D;
/*     */     
/* 275 */     if (this.spinner != null && this.control.isIndeterminate()) {
/* 276 */       d = this.spinner.minHeight(-1.0D);
/* 277 */     } else if (this.determinateIndicator != null) {
/* 278 */       d = this.determinateIndicator.minHeight(-1.0D);
/*     */     } 
/* 280 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 285 */     double d = 0.0D;
/*     */     
/* 287 */     if (this.spinner != null && this.control.isIndeterminate()) {
/* 288 */       d = this.spinner.prefWidth(paramDouble1);
/* 289 */     } else if (this.determinateIndicator != null) {
/* 290 */       d = this.determinateIndicator.prefWidth(paramDouble1);
/*     */     } 
/* 292 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 297 */     double d = 0.0D;
/*     */     
/* 299 */     if (this.spinner != null && this.control.isIndeterminate()) {
/* 300 */       d = this.spinner.prefHeight(paramDouble1);
/* 301 */     } else if (this.determinateIndicator != null) {
/* 302 */       d = this.determinateIndicator.prefHeight(paramDouble1);
/*     */     } 
/* 304 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 309 */     return computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 314 */     return computePrefHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initialize() {
/* 325 */     boolean bool = this.control.isIndeterminate();
/* 326 */     if (bool) {
/*     */       
/* 328 */       this.determinateIndicator = null;
/*     */ 
/*     */       
/* 331 */       this.spinner = new IndeterminateSpinner(this.spinEnabled.get(), this.progressColor.get());
/* 332 */       getChildren().setAll(new Node[] { this.spinner });
/* 333 */       if (NodeHelper.isTreeShowing(this.control) && 
/* 334 */         this.indeterminateTransition != null) {
/* 335 */         this.indeterminateTransition.play();
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 340 */       if (this.spinner != null) {
/* 341 */         if (this.indeterminateTransition != null) {
/* 342 */           this.indeterminateTransition.stop();
/*     */         }
/* 344 */         this.spinner = null;
/*     */       } 
/*     */ 
/*     */       
/* 348 */       this.determinateIndicator = new DeterminateIndicator(this.control, this, this.progressColor.get());
/* 349 */       getChildren().setAll(new Node[] { this.determinateIndicator });
/*     */     } 
/*     */   }
/*     */   
/*     */   void updateProgress() {
/* 354 */     if (this.determinateIndicator != null) {
/* 355 */       this.determinateIndicator.updateProgress(this.control.getProgress());
/*     */     }
/*     */   }
/*     */   
/*     */   void createIndeterminateTimeline() {
/* 360 */     if (this.spinner != null) {
/* 361 */       this.spinner.rebuildTimeline();
/*     */     }
/*     */   }
/*     */   
/*     */   void pauseTimeline(boolean paramBoolean) {
/* 366 */     if (getSkinnable().isIndeterminate()) {
/* 367 */       if (this.indeterminateTransition == null) {
/* 368 */         createIndeterminateTimeline();
/*     */       }
/* 370 */       if (paramBoolean) {
/* 371 */         this.indeterminateTransition.pause();
/*     */       } else {
/* 373 */         this.indeterminateTransition.play();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void updateAnimation() {
/* 379 */     ProgressIndicator progressIndicator = getSkinnable();
/*     */     
/* 381 */     boolean bool = (NodeHelper.isTreeShowing(progressIndicator) && progressIndicator.getScene() != null) ? true : false;
/* 382 */     if (this.indeterminateTransition != null) {
/* 383 */       pauseTimeline(!bool);
/* 384 */     } else if (bool) {
/* 385 */       createIndeterminateTimeline();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 397 */   private static final CssMetaData<ProgressIndicator, Paint> PROGRESS_COLOR = new CssMetaData<ProgressIndicator, Paint>("-fx-progress-color", 
/*     */       
/* 399 */       PaintConverter.getInstance(), null)
/*     */     {
/*     */       public boolean isSettable(ProgressIndicator param1ProgressIndicator)
/*     */       {
/* 403 */         ProgressIndicatorSkin progressIndicatorSkin = (ProgressIndicatorSkin)param1ProgressIndicator.getSkin();
/* 404 */         return (progressIndicatorSkin.progressColor == null || 
/* 405 */           !progressIndicatorSkin.progressColor.isBound());
/*     */       }
/*     */ 
/*     */       
/*     */       public StyleableProperty<Paint> getStyleableProperty(ProgressIndicator param1ProgressIndicator) {
/* 410 */         ProgressIndicatorSkin progressIndicatorSkin = (ProgressIndicatorSkin)param1ProgressIndicator.getSkin();
/* 411 */         return (StyleableProperty<Paint>)progressIndicatorSkin.progressColor;
/*     */       }
/*     */     };
/* 414 */   private static final CssMetaData<ProgressIndicator, Number> INDETERMINATE_SEGMENT_COUNT = new CssMetaData<ProgressIndicator, Number>("-fx-indeterminate-segment-count", 
/*     */       
/* 416 */       SizeConverter.getInstance(), Integer.valueOf(8))
/*     */     {
/*     */       public boolean isSettable(ProgressIndicator param1ProgressIndicator) {
/* 419 */         ProgressIndicatorSkin progressIndicatorSkin = (ProgressIndicatorSkin)param1ProgressIndicator.getSkin();
/* 420 */         return (progressIndicatorSkin.indeterminateSegmentCount == null || 
/* 421 */           !progressIndicatorSkin.indeterminateSegmentCount.isBound());
/*     */       }
/*     */       
/*     */       public StyleableProperty<Number> getStyleableProperty(ProgressIndicator param1ProgressIndicator) {
/* 425 */         ProgressIndicatorSkin progressIndicatorSkin = (ProgressIndicatorSkin)param1ProgressIndicator.getSkin();
/* 426 */         return (StyleableProperty<Number>)progressIndicatorSkin.indeterminateSegmentCount;
/*     */       }
/*     */     };
/* 429 */   private static final CssMetaData<ProgressIndicator, Boolean> SPIN_ENABLED = new CssMetaData<ProgressIndicator, Boolean>("-fx-spin-enabled", 
/* 430 */       BooleanConverter.getInstance(), Boolean.FALSE)
/*     */     {
/*     */       public boolean isSettable(ProgressIndicator param1ProgressIndicator) {
/* 433 */         ProgressIndicatorSkin progressIndicatorSkin = (ProgressIndicatorSkin)param1ProgressIndicator.getSkin();
/* 434 */         return (progressIndicatorSkin.spinEnabled == null || !progressIndicatorSkin.spinEnabled.isBound());
/*     */       }
/*     */       
/*     */       public StyleableProperty<Boolean> getStyleableProperty(ProgressIndicator param1ProgressIndicator) {
/* 438 */         ProgressIndicatorSkin progressIndicatorSkin = (ProgressIndicatorSkin)param1ProgressIndicator.getSkin();
/* 439 */         return (StyleableProperty<Boolean>)progressIndicatorSkin.spinEnabled;
/*     */       }
/*     */     };
/*     */   
/*     */   private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */   
/*     */   static {
/* 446 */     ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(SkinBase.getClassCssMetaData());
/* 447 */     arrayList.add(PROGRESS_COLOR);
/* 448 */     arrayList.add(INDETERMINATE_SEGMENT_COUNT);
/* 449 */     arrayList.add(SPIN_ENABLED);
/* 450 */     STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 460 */     return STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 468 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class DeterminateIndicator
/*     */     extends Region
/*     */   {
/* 480 */     private double textGap = 2.0D;
/*     */     
/*     */     private int intProgress;
/*     */     
/*     */     private int degProgress;
/*     */     
/*     */     private Text text;
/*     */     
/*     */     private StackPane indicator;
/*     */     
/*     */     private StackPane progress;
/*     */     private StackPane tick;
/*     */     private Arc arcShape;
/*     */     private Circle indicatorCircle;
/*     */     private double doneTextWidth;
/*     */     private double doneTextHeight;
/*     */     
/*     */     public DeterminateIndicator(ProgressIndicator param1ProgressIndicator, ProgressIndicatorSkin param1ProgressIndicatorSkin1, Paint param1Paint) {
/* 498 */       getStyleClass().add("determinate-indicator");
/*     */       
/* 500 */       this.intProgress = (int)Math.round(param1ProgressIndicator.getProgress() * 100.0D);
/* 501 */       this.degProgress = (int)(360.0D * param1ProgressIndicator.getProgress());
/*     */       
/* 503 */       getChildren().clear();
/*     */       
/* 505 */       this.text = new Text((param1ProgressIndicator.getProgress() >= 1.0D) ? ProgressIndicatorSkin.this.DONE : ("" + this.intProgress + "%"));
/* 506 */       this.text.setTextOrigin(VPos.TOP);
/* 507 */       this.text.getStyleClass().setAll(new String[] { "text", "percentage" });
/*     */       
/* 509 */       ProgressIndicatorSkin.this.registerChangeListener(this.text.fontProperty(), param1ObservableValue -> {
/*     */             this.doneTextWidth = Utils.computeTextWidth(this.text.getFont(), ProgressIndicatorSkin.this.DONE, 0.0D);
/*     */             
/*     */             this.doneTextHeight = Utils.computeTextHeight(this.text.getFont(), ProgressIndicatorSkin.this.DONE, 0.0D, TextBoundsType.LOGICAL_VERTICAL_CENTER);
/*     */           });
/*     */       
/* 515 */       this.indicator = new StackPane();
/* 516 */       this.indicator.setScaleShape(false);
/* 517 */       this.indicator.setCenterShape(false);
/* 518 */       this.indicator.getStyleClass().setAll(new String[] { "indicator" });
/* 519 */       this.indicatorCircle = new Circle();
/* 520 */       this.indicator.setShape(this.indicatorCircle);
/*     */ 
/*     */       
/* 523 */       this.arcShape = new Arc();
/* 524 */       this.arcShape.setType(ArcType.ROUND);
/* 525 */       this.arcShape.setStartAngle(90.0D);
/*     */ 
/*     */       
/* 528 */       this.progress = new StackPane();
/* 529 */       this.progress.getStyleClass().setAll(new String[] { "progress" });
/* 530 */       this.progress.setScaleShape(false);
/* 531 */       this.progress.setCenterShape(false);
/* 532 */       this.progress.setShape(this.arcShape);
/* 533 */       this.progress.getChildren().clear();
/* 534 */       setFillOverride(param1Paint);
/*     */ 
/*     */       
/* 537 */       this.tick = new StackPane();
/* 538 */       this.tick.getStyleClass().setAll(new String[] { "tick" });
/*     */       
/* 540 */       getChildren().setAll(new Node[] { this.indicator, this.progress, this.text, this.tick });
/* 541 */       updateProgress(param1ProgressIndicator.getProgress());
/*     */     }
/*     */     
/*     */     private void setFillOverride(Paint param1Paint) {
/* 545 */       if (param1Paint instanceof Color) {
/* 546 */         Color color = (Color)param1Paint;
/* 547 */         this.progress.setStyle("-fx-background-color: rgba(" + (int)(255.0D * color.getRed()) + "," + (int)(255.0D * color.getGreen()) + "," + (int)(255.0D * color.getBlue()) + "," + color.getOpacity() + ");");
/*     */       } else {
/* 549 */         this.progress.setStyle(null);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean usesMirroring() {
/* 557 */       return false;
/*     */     }
/*     */     
/*     */     private void updateProgress(double param1Double) {
/* 561 */       this.intProgress = (int)Math.round(param1Double * 100.0D);
/* 562 */       this.text.setText((param1Double >= 1.0D) ? ProgressIndicatorSkin.this.DONE : ("" + this.intProgress + "%"));
/*     */       
/* 564 */       this.degProgress = (int)(360.0D * param1Double);
/* 565 */       this.arcShape.setLength(-this.degProgress);
/* 566 */       requestLayout();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void layoutChildren() {
/* 571 */       double d1 = ProgressIndicatorSkin.this.control.snappedLeftInset();
/* 572 */       double d2 = ProgressIndicatorSkin.this.control.snappedRightInset();
/* 573 */       double d3 = ProgressIndicatorSkin.this.control.snappedTopInset();
/* 574 */       double d4 = ProgressIndicatorSkin.this.control.snappedBottomInset();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 579 */       double d5 = ProgressIndicatorSkin.this.control.getWidth() - d1 - d2;
/* 580 */       double d6 = ProgressIndicatorSkin.this.control.getHeight() - d3 - d4 - this.textGap - this.doneTextHeight;
/* 581 */       double d7 = d5 / 2.0D;
/* 582 */       double d8 = d6 / 2.0D;
/* 583 */       double d9 = Math.floor(Math.min(d7, d8));
/* 584 */       double d10 = snapPosition(d1 + d7);
/* 585 */       double d11 = snapPosition(d3 + d9);
/*     */ 
/*     */       
/* 588 */       double d12 = this.indicator.snappedLeftInset();
/* 589 */       double d13 = this.indicator.snappedRightInset();
/* 590 */       double d14 = this.indicator.snappedTopInset();
/* 591 */       double d15 = this.indicator.snappedBottomInset();
/* 592 */       double d16 = snapSize(Math.min(
/* 593 */             Math.min(d9 - d12, d9 - d13), 
/* 594 */             Math.min(d9 - d14, d9 - d15)));
/*     */       
/* 596 */       this.indicatorCircle.setRadius(d9);
/* 597 */       this.indicator.setLayoutX(d10);
/* 598 */       this.indicator.setLayoutY(d11);
/*     */       
/* 600 */       this.arcShape.setRadiusX(d16);
/* 601 */       this.arcShape.setRadiusY(d16);
/* 602 */       this.progress.setLayoutX(d10);
/* 603 */       this.progress.setLayoutY(d11);
/*     */ 
/*     */       
/* 606 */       double d17 = this.progress.snappedLeftInset();
/* 607 */       double d18 = this.progress.snappedRightInset();
/* 608 */       double d19 = this.progress.snappedTopInset();
/* 609 */       double d20 = this.progress.snappedBottomInset();
/* 610 */       double d21 = snapSize(Math.min(
/* 611 */             Math.min(d16 - d17, d16 - d18), 
/* 612 */             Math.min(d16 - d19, d16 - d20)));
/*     */ 
/*     */       
/* 615 */       double d22 = Math.ceil(Math.sqrt(d21 * d21 / 2.0D));
/*     */       
/* 617 */       this.tick.setLayoutX(d10 - d22);
/* 618 */       this.tick.setLayoutY(d11 - d22);
/* 619 */       this.tick.resize(d22 + d22, d22 + d22);
/* 620 */       this.tick.setVisible((ProgressIndicatorSkin.this.control.getProgress() >= 1.0D));
/*     */ 
/*     */       
/* 623 */       double d23 = this.text.getLayoutBounds().getWidth();
/* 624 */       double d24 = this.text.getLayoutBounds().getHeight();
/* 625 */       if (ProgressIndicatorSkin.this.control.getWidth() >= d23 && ProgressIndicatorSkin.this.control.getHeight() >= d24)
/* 626 */       { if (!this.text.isVisible()) this.text.setVisible(true); 
/* 627 */         this.text.setLayoutY(snapPosition(d11 + d9 + this.textGap));
/* 628 */         this.text.setLayoutX(snapPosition(d10 - d23 / 2.0D)); }
/*     */       
/* 630 */       else if (this.text.isVisible()) { this.text.setVisible(false); }
/*     */     
/*     */     }
/*     */     
/*     */     protected double computePrefWidth(double param1Double) {
/* 635 */       double d1 = ProgressIndicatorSkin.this.control.snappedLeftInset();
/* 636 */       double d2 = ProgressIndicatorSkin.this.control.snappedRightInset();
/* 637 */       double d3 = this.indicator.snappedLeftInset();
/* 638 */       double d4 = this.indicator.snappedRightInset();
/* 639 */       double d5 = this.indicator.snappedTopInset();
/* 640 */       double d6 = this.indicator.snappedBottomInset();
/* 641 */       double d7 = snapSize(Math.max(Math.max(d3, d4), Math.max(d5, d6)));
/* 642 */       double d8 = this.progress.snappedLeftInset();
/* 643 */       double d9 = this.progress.snappedRightInset();
/* 644 */       double d10 = this.progress.snappedTopInset();
/* 645 */       double d11 = this.progress.snappedBottomInset();
/* 646 */       double d12 = snapSize(Math.max(Math.max(d8, d9), Math.max(d10, d11)));
/* 647 */       double d13 = this.tick.snappedLeftInset();
/* 648 */       double d14 = this.tick.snappedRightInset();
/* 649 */       double d15 = d7 + d12 + d13 + d14 + d12 + d7;
/* 650 */       return d1 + Math.max(d15, this.doneTextWidth) + d2;
/*     */     }
/*     */     
/*     */     protected double computePrefHeight(double param1Double) {
/* 654 */       double d1 = ProgressIndicatorSkin.this.control.snappedTopInset();
/* 655 */       double d2 = ProgressIndicatorSkin.this.control.snappedBottomInset();
/* 656 */       double d3 = this.indicator.snappedLeftInset();
/* 657 */       double d4 = this.indicator.snappedRightInset();
/* 658 */       double d5 = this.indicator.snappedTopInset();
/* 659 */       double d6 = this.indicator.snappedBottomInset();
/* 660 */       double d7 = snapSize(Math.max(Math.max(d3, d4), Math.max(d5, d6)));
/* 661 */       double d8 = this.progress.snappedLeftInset();
/* 662 */       double d9 = this.progress.snappedRightInset();
/* 663 */       double d10 = this.progress.snappedTopInset();
/* 664 */       double d11 = this.progress.snappedBottomInset();
/* 665 */       double d12 = snapSize(Math.max(Math.max(d8, d9), Math.max(d10, d11)));
/* 666 */       double d13 = this.tick.snappedTopInset();
/* 667 */       double d14 = this.tick.snappedBottomInset();
/* 668 */       double d15 = d7 + d12 + d13 + d14 + d12 + d7;
/* 669 */       return d1 + d15 + this.textGap + this.doneTextHeight + d2;
/*     */     }
/*     */     
/*     */     protected double computeMaxWidth(double param1Double) {
/* 673 */       return computePrefWidth(param1Double);
/*     */     }
/*     */     
/*     */     protected double computeMaxHeight(double param1Double) {
/* 677 */       return computePrefHeight(param1Double);
/*     */     }
/*     */   }
/*     */   
/*     */   private final class IndeterminateSpinner
/*     */     extends Region {
/*     */     private IndicatorPaths pathsG;
/* 684 */     private final List<Double> opacities = new ArrayList<>();
/*     */     private boolean spinEnabled = false;
/* 686 */     private Paint fillOverride = null;
/*     */     
/*     */     private IndeterminateSpinner(boolean param1Boolean, Paint param1Paint) {
/* 689 */       this.spinEnabled = param1Boolean;
/* 690 */       this.fillOverride = param1Paint;
/*     */       
/* 692 */       setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
/* 693 */       getStyleClass().setAll(new String[] { "spinner" });
/*     */       
/* 695 */       this.pathsG = new IndicatorPaths();
/* 696 */       getChildren().add(this.pathsG);
/* 697 */       rebuild();
/*     */       
/* 699 */       rebuildTimeline();
/*     */     }
/*     */ 
/*     */     
/*     */     public void setFillOverride(Paint param1Paint) {
/* 704 */       this.fillOverride = param1Paint;
/* 705 */       rebuild();
/*     */     }
/*     */     
/*     */     public void setSpinEnabled(boolean param1Boolean) {
/* 709 */       this.spinEnabled = param1Boolean;
/* 710 */       rebuildTimeline();
/*     */     }
/*     */     
/*     */     private void rebuildTimeline() {
/* 714 */       if (this.spinEnabled) {
/* 715 */         if (ProgressIndicatorSkin.this.indeterminateTransition == null) {
/* 716 */           ProgressIndicatorSkin.this.indeterminateTransition = new Timeline();
/* 717 */           ProgressIndicatorSkin.this.indeterminateTransition.setCycleCount(-1);
/* 718 */           ProgressIndicatorSkin.this.indeterminateTransition.setDelay(ProgressIndicatorSkin.this.UNCLIPPED_DELAY);
/*     */         } else {
/* 720 */           ProgressIndicatorSkin.this.indeterminateTransition.stop();
/* 721 */           ((Timeline)ProgressIndicatorSkin.this.indeterminateTransition).getKeyFrames().clear();
/*     */         } 
/* 723 */         ObservableList<?> observableList = FXCollections.observableArrayList();
/*     */         
/* 725 */         observableList.add(new KeyFrame(Duration.millis(1.0D), new KeyValue[] { new KeyValue(this.pathsG.rotateProperty(), (T)Integer.valueOf(360)) }));
/* 726 */         observableList.add(new KeyFrame(Duration.millis(3900.0D), new KeyValue[] { new KeyValue(this.pathsG.rotateProperty(), (T)Integer.valueOf(0)) }));
/*     */         
/* 728 */         for (byte b = 100; b <= '༼'; b += 100) {
/* 729 */           observableList.add(new KeyFrame(Duration.millis(b), param1ActionEvent -> shiftColors(), new KeyValue[0]));
/*     */         }
/*     */         
/* 732 */         ((Timeline)ProgressIndicatorSkin.this.indeterminateTransition).getKeyFrames().setAll(observableList);
/* 733 */         ProgressIndicatorSkin.this.indeterminateTransition.playFromStart();
/*     */       }
/* 735 */       else if (ProgressIndicatorSkin.this.indeterminateTransition != null) {
/* 736 */         ProgressIndicatorSkin.this.indeterminateTransition.stop();
/* 737 */         ((Timeline)ProgressIndicatorSkin.this.indeterminateTransition).getKeyFrames().clear();
/* 738 */         ProgressIndicatorSkin.this.indeterminateTransition = null;
/*     */       } 
/*     */     }
/*     */     
/*     */     private class IndicatorPaths extends Pane { private IndicatorPaths() {}
/*     */       
/*     */       protected double computePrefWidth(double param2Double) {
/* 745 */         double d = 0.0D;
/* 746 */         for (Node node : getChildren()) {
/* 747 */           if (node instanceof Region) {
/* 748 */             Region region = (Region)node;
/* 749 */             if (region.getShape() != null) {
/* 750 */               d = Math.max(d, region.getShape().getLayoutBounds().getMaxX()); continue;
/*     */             } 
/* 752 */             d = Math.max(d, region.prefWidth(param2Double));
/*     */           } 
/*     */         } 
/*     */         
/* 756 */         return d;
/*     */       }
/*     */       
/*     */       protected double computePrefHeight(double param2Double) {
/* 760 */         double d = 0.0D;
/* 761 */         for (Node node : getChildren()) {
/* 762 */           if (node instanceof Region) {
/* 763 */             Region region = (Region)node;
/* 764 */             if (region.getShape() != null) {
/* 765 */               d = Math.max(d, region.getShape().getLayoutBounds().getMaxY()); continue;
/*     */             } 
/* 767 */             d = Math.max(d, region.prefHeight(param2Double));
/*     */           } 
/*     */         } 
/*     */         
/* 771 */         return d;
/*     */       }
/*     */ 
/*     */       
/*     */       protected void layoutChildren() {
/* 776 */         double d = getWidth() / computePrefWidth(-1.0D);
/* 777 */         for (Node node : getChildren()) {
/* 778 */           if (node instanceof Region) {
/* 779 */             Region region = (Region)node;
/* 780 */             if (region.getShape() != null) {
/* 781 */               region.resize(region
/* 782 */                   .getShape().getLayoutBounds().getMaxX(), region
/* 783 */                   .getShape().getLayoutBounds().getMaxY());
/*     */               
/* 785 */               region.getTransforms().setAll(new Transform[] { new Scale(d, d, 0.0D, 0.0D) }); continue;
/*     */             } 
/* 787 */             region.autosize();
/*     */           } 
/*     */         } 
/*     */       } }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void layoutChildren() {
/* 795 */       double d1 = ProgressIndicatorSkin.this.control.getWidth() - ProgressIndicatorSkin.this.control.snappedLeftInset() - ProgressIndicatorSkin.this.control.snappedRightInset();
/* 796 */       double d2 = ProgressIndicatorSkin.this.control.getHeight() - ProgressIndicatorSkin.this.control.snappedTopInset() - ProgressIndicatorSkin.this.control.snappedBottomInset();
/* 797 */       double d3 = this.pathsG.prefWidth(-1.0D);
/* 798 */       double d4 = this.pathsG.prefHeight(-1.0D);
/* 799 */       double d5 = d1 / d3;
/* 800 */       double d6 = d5;
/* 801 */       if (d5 * d4 > d2) {
/* 802 */         d6 = d2 / d4;
/*     */       }
/* 804 */       double d7 = d3 * d6;
/* 805 */       double d8 = d4 * d6;
/* 806 */       this.pathsG.resizeRelocate((d1 - d7) / 2.0D, (d2 - d8) / 2.0D, d7, d8);
/*     */     }
/*     */ 
/*     */     
/*     */     private void rebuild() {
/* 811 */       int i = ProgressIndicatorSkin.this.indeterminateSegmentCount.get();
/* 812 */       this.opacities.clear();
/* 813 */       this.pathsG.getChildren().clear();
/* 814 */       double d = 0.8D / (i - 1);
/* 815 */       for (byte b = 0; b < i; b++) {
/* 816 */         Region region = new Region();
/* 817 */         region.setScaleShape(false);
/* 818 */         region.setCenterShape(false);
/* 819 */         region.getStyleClass().addAll(new String[] { "segment", "segment" + b });
/* 820 */         if (this.fillOverride instanceof Color) {
/* 821 */           Color color = (Color)this.fillOverride;
/* 822 */           region.setStyle("-fx-background-color: rgba(" + (int)(255.0D * color.getRed()) + "," + (int)(255.0D * color.getGreen()) + "," + (int)(255.0D * color.getBlue()) + "," + color.getOpacity() + ");");
/*     */         } else {
/* 824 */           region.setStyle(null);
/*     */         } 
/* 826 */         this.pathsG.getChildren().add(region);
/* 827 */         this.opacities.add(Double.valueOf(Math.max(0.1D, 1.0D - d * b)));
/*     */       } 
/*     */     }
/*     */     
/*     */     private void shiftColors() {
/* 832 */       if (this.opacities.size() <= 0)
/* 833 */         return;  int i = ProgressIndicatorSkin.this.indeterminateSegmentCount.get();
/* 834 */       Collections.rotate(this.opacities, -1);
/* 835 */       for (byte b = 0; b < i; b++)
/* 836 */         ((Node)this.pathsG.getChildren().get(b)).setOpacity(((Double)this.opacities.get(b)).doubleValue()); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ProgressIndicatorSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */