/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.TreeTableCellBehavior;
/*     */ import java.util.Map;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeTableCell;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ import javafx.scene.control.TreeTableRow;
/*     */ import javafx.scene.control.TreeTableView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeTableCellSkin<S, T>
/*     */   extends TableCellSkinBase<TreeItem<S>, T, TreeTableCell<S, T>>
/*     */ {
/*     */   private final BehaviorBase<TreeTableCell<S, T>> behavior;
/*     */   
/*     */   public TreeTableCellSkin(TreeTableCell<S, T> paramTreeTableCell) {
/*  69 */     super(paramTreeTableCell);
/*     */ 
/*     */     
/*  72 */     this.behavior = new TreeTableCellBehavior<>(paramTreeTableCell);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  86 */     super.dispose();
/*     */     
/*  88 */     if (this.behavior != null) {
/*  89 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyObjectProperty<TreeTableColumn<S, T>> tableColumnProperty() {
/* 103 */     return getSkinnable().tableColumnProperty();
/*     */   }
/*     */ 
/*     */   
/*     */   double leftLabelPadding() {
/* 108 */     double d1 = super.leftLabelPadding();
/*     */ 
/*     */ 
/*     */     
/* 112 */     double d2 = getCellSize();
/*     */     
/* 114 */     TreeTableCell<S, T> treeTableCell = getSkinnable();
/*     */     
/* 116 */     TreeTableColumn<S, T> treeTableColumn = treeTableCell.getTableColumn();
/* 117 */     if (treeTableColumn == null) return d1;
/*     */ 
/*     */ 
/*     */     
/* 121 */     TreeTableView<S> treeTableView = treeTableCell.getTreeTableView();
/* 122 */     if (treeTableView == null) return d1;
/*     */     
/* 124 */     int i = treeTableView.getVisibleLeafIndex(treeTableColumn);
/*     */     
/* 126 */     TreeTableColumn<S, ?> treeTableColumn1 = treeTableView.getTreeColumn();
/* 127 */     if ((treeTableColumn1 == null && i != 0) || (treeTableColumn1 != null && !treeTableColumn.equals(treeTableColumn1))) {
/* 128 */       return d1;
/*     */     }
/*     */     
/* 131 */     TreeTableRow<S> treeTableRow = treeTableCell.getTreeTableRow();
/* 132 */     if (treeTableRow == null) return d1;
/*     */     
/* 134 */     TreeItem<S> treeItem = treeTableRow.getTreeItem();
/* 135 */     if (treeItem == null) return d1;
/*     */     
/* 137 */     int j = treeTableView.getTreeItemLevel(treeItem);
/* 138 */     if (!treeTableView.isShowRoot()) j--;
/*     */     
/* 140 */     double d3 = 10.0D;
/* 141 */     if (treeTableRow.getSkin() instanceof TreeTableRowSkin) {
/* 142 */       d3 = ((TreeTableRowSkin)treeTableRow.getSkin()).getIndentationPerLevel();
/*     */     }
/* 144 */     d1 += j * d3;
/*     */ 
/*     */     
/* 147 */     Map<TableColumnBase<?, ?>, Double> map = TableRowSkinBase.maxDisclosureWidthMap;
/* 148 */     d1 += map.containsKey(treeTableColumn1) ? ((Double)map.get(treeTableColumn1)).doubleValue() : 0.0D;
/*     */ 
/*     */     
/* 151 */     Node node = treeItem.getGraphic();
/* 152 */     d1 += (node == null) ? 0.0D : node.prefWidth(d2);
/*     */     
/* 154 */     return d1;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TreeTableCellSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */