/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.TableRowBehavior;
/*     */ import java.lang.ref.Reference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.IndexedCell;
/*     */ import javafx.scene.control.TableCell;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TablePosition;
/*     */ import javafx.scene.control.TableRow;
/*     */ import javafx.scene.control.TableView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableRowSkin<T>
/*     */   extends TableRowSkinBase<T, TableRow<T>, TableCell<T, ?>>
/*     */ {
/*     */   private TableViewSkin<T> tableViewSkin;
/*     */   private final BehaviorBase<TableRow<T>> behavior;
/*     */   
/*     */   public TableRowSkin(TableRow<T> paramTableRow) {
/*  89 */     super(paramTableRow);
/*     */ 
/*     */     
/*  92 */     this.behavior = new TableRowBehavior<>(paramTableRow);
/*     */ 
/*     */     
/*  95 */     updateTableViewSkin();
/*     */     
/*  97 */     registerChangeListener(paramTableRow.tableViewProperty(), paramObservableValue -> {
/*     */           updateTableViewSkin();
/*     */           byte b = 0;
/*     */           int i = this.cells.size();
/*     */           while (b < i) {
/*     */             Node node = this.cells.get(b);
/*     */             if (node instanceof TableCell)
/*     */               ((TableCell)node).updateTableView(getSkinnable().getTableView()); 
/*     */             b++;
/*     */           } 
/*     */         });
/* 108 */     setupTreeTableViewListeners();
/*     */   }
/*     */   
/*     */   private void setupTreeTableViewListeners() {
/* 112 */     TableView<T> tableView = getSkinnable().getTableView();
/* 113 */     if (tableView == null) {
/* 114 */       getSkinnable().tableViewProperty().addListener(new InvalidationListener() {
/*     */             public void invalidated(Observable param1Observable) {
/* 116 */               TableRowSkin.this.getSkinnable().tableViewProperty().removeListener(this);
/* 117 */               TableRowSkin.this.setupTreeTableViewListeners();
/*     */             }
/*     */           });
/*     */     } else {
/* 121 */       DoubleProperty doubleProperty = tableView.fixedCellSizeProperty();
/* 122 */       if (doubleProperty != null) {
/* 123 */         registerChangeListener(doubleProperty, paramObservableValue -> {
/*     */               this.fixedCellSize = paramDoubleProperty.get();
/*     */               this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0D);
/*     */             });
/* 127 */         this.fixedCellSize = doubleProperty.get();
/* 128 */         this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 134 */         registerChangeListener(getVirtualFlow().widthProperty(), paramObservableValue -> paramTableView.requestLayout());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 149 */     super.dispose();
/*     */     
/* 151 */     if (this.behavior != null)
/* 152 */       this.behavior.dispose();  } protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) { ArrayList<TableCell> arrayList; int i; TableView.TableViewFocusModel<T> tableViewFocusModel;
/*     */     int j;
/*     */     TableColumn<T, ?> tableColumn1;
/*     */     TablePosition tablePosition;
/*     */     Iterator<TablePosition> iterator;
/*     */     TableColumn<T, ?> tableColumn2;
/* 158 */     switch (paramAccessibleAttribute) {
/*     */ 
/*     */       
/*     */       case SELECTED_ITEMS:
/* 162 */         arrayList = new ArrayList();
/* 163 */         j = getSkinnable().getIndex();
/* 164 */         iterator = getTableView().getSelectionModel().getSelectedCells().iterator(); if (iterator.hasNext()) { TablePosition tablePosition1 = iterator.next();
/* 165 */           if (tablePosition1.getRow() == j) {
/* 166 */             TableColumn<T, ?> tableColumn = tablePosition1.getTableColumn();
/* 167 */             if (tableColumn == null)
/*     */             {
/* 169 */               tableColumn = getTableView().getVisibleLeafColumn(0);
/*     */             }
/* 171 */             TableCell tableCell = ((Reference<TableCell>)this.cellsMap.get(tableColumn)).get();
/* 172 */             if (tableCell != null) arrayList.add(tableCell); 
/*     */           } 
/* 174 */           return FXCollections.observableArrayList(arrayList); }
/*     */       
/*     */       
/*     */       case CELL_AT_ROW_COLUMN:
/* 178 */         i = ((Integer)paramVarArgs[1]).intValue();
/* 179 */         tableColumn1 = getTableView().getVisibleLeafColumn(i);
/* 180 */         if (this.cellsMap.containsKey(tableColumn1)) {
/* 181 */           return ((Reference)this.cellsMap.get(tableColumn1)).get();
/*     */         }
/* 183 */         return null;
/*     */       
/*     */       case FOCUS_ITEM:
/* 186 */         tableViewFocusModel = getTableView().getFocusModel();
/* 187 */         tablePosition = tableViewFocusModel.getFocusedCell();
/* 188 */         tableColumn2 = tablePosition.getTableColumn();
/* 189 */         if (tableColumn2 == null)
/*     */         {
/* 191 */           tableColumn2 = getTableView().getVisibleLeafColumn(0);
/*     */         }
/* 193 */         if (this.cellsMap.containsKey(tableColumn2)) {
/* 194 */           return ((Reference)this.cellsMap.get(tableColumn2)).get();
/*     */         }
/* 196 */         return null;
/*     */     } 
/* 198 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TableCell<T, ?> createCell(TableColumnBase paramTableColumnBase) {
/* 212 */     TableColumn tableColumn = (TableColumn)paramTableColumnBase;
/* 213 */     TableCell<T, ?> tableCell = tableColumn.getCellFactory().call(tableColumn);
/*     */ 
/*     */     
/* 216 */     tableCell.updateTableColumn(tableColumn);
/* 217 */     tableCell.updateTableView(tableColumn.getTableView());
/* 218 */     tableCell.updateTableRow(getSkinnable());
/*     */     
/* 220 */     return tableCell;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ObservableList<TableColumn<T, ?>> getVisibleLeafColumns() {
/* 225 */     return (getTableView() == null) ? FXCollections.<TableColumn<T, ?>>emptyObservableList() : getTableView().getVisibleLeafColumns();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateCell(TableCell<T, ?> paramTableCell, TableRow<T> paramTableRow) {
/* 230 */     paramTableCell.updateTableRow(paramTableRow);
/*     */   }
/*     */ 
/*     */   
/*     */   protected TableColumn<T, ?> getTableColumn(TableCell<T, ?> paramTableCell) {
/* 235 */     return paramTableCell.getTableColumn();
/*     */   }
/*     */   
/*     */   private TableView<T> getTableView() {
/* 239 */     return getSkinnable().getTableView();
/*     */   }
/*     */   
/*     */   private void updateTableViewSkin() {
/* 243 */     TableView<T> tableView = getSkinnable().getTableView();
/* 244 */     if (tableView != null && tableView.getSkin() instanceof TableViewSkin)
/* 245 */       this.tableViewSkin = (TableViewSkin)tableView.getSkin(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TableRowSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */