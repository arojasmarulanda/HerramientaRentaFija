/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.scene.control.IndexedCell;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.shape.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TableCellSkinBase<S, T, C extends IndexedCell<T>>
/*     */   extends CellSkinBase<C>
/*     */ {
/*     */   boolean isDeferToParentForPrefWidth = false;
/*     */   private InvalidationListener columnWidthListener;
/*     */   private WeakInvalidationListener weakColumnWidthListener;
/*     */   
/*     */   public TableCellSkinBase(C paramC) {
/*  77 */     super(paramC);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     this.columnWidthListener = (paramObservable -> ((IndexedCell)getSkinnable()).requestLayout());
/*     */     
/* 106 */     this.weakColumnWidthListener = new WeakInvalidationListener(this.columnWidthListener);
/*     */     Rectangle rectangle = new Rectangle();
/*     */     rectangle.widthProperty().bind(paramC.widthProperty());
/*     */     rectangle.heightProperty().bind(paramC.heightProperty());
/*     */     ((IndexedCell)getSkinnable()).setClip(rectangle);
/*     */     TableColumnBase<S, T> tableColumnBase = getTableColumn();
/*     */     if (tableColumnBase != null) {
/*     */       tableColumnBase.widthProperty().addListener(this.weakColumnWidthListener);
/*     */     }
/*     */     if (paramC.getProperties().containsKey("deferToParentPrefWidth")) {
/*     */       this.isDeferToParentForPrefWidth = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final TableColumnBase<S, T> getTableColumn() {
/* 123 */     return tableColumnProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 136 */     TableColumnBase<S, T> tableColumnBase = getTableColumn();
/* 137 */     if (tableColumnBase != null) {
/* 138 */       tableColumnBase.widthProperty().removeListener(this.weakColumnWidthListener);
/*     */     }
/*     */     
/* 141 */     super.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 150 */     layoutLabelInArea(paramDouble1, paramDouble2, paramDouble3, paramDouble4 - ((IndexedCell)getSkinnable()).getPadding().getBottom());
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 155 */     if (this.isDeferToParentForPrefWidth) {
/* 156 */       return super.computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */     }
/*     */     
/* 159 */     TableColumnBase<S, T> tableColumnBase = getTableColumn();
/* 160 */     return (tableColumnBase == null) ? 0.0D : snapSizeX(tableColumnBase.getWidth());
/*     */   }
/*     */   
/*     */   public abstract ReadOnlyObjectProperty<? extends TableColumnBase<S, T>> tableColumnProperty();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TableCellSkinBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */