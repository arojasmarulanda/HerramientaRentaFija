/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.TableViewBehavior;
/*     */ import java.util.ArrayList;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.TableCell;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TablePosition;
/*     */ import javafx.scene.control.TableRow;
/*     */ import javafx.scene.control.TableView;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableViewSkin<T>
/*     */   extends TableViewSkinBase<T, T, TableView<T>, TableRow<T>, TableColumn<T, ?>>
/*     */ {
/*     */   private final TableViewBehavior<T> behavior;
/*     */   
/*     */   public TableViewSkin(TableView<T> paramTableView) {
/*  91 */     super(paramTableView);
/*     */ 
/*     */     
/*  94 */     this.behavior = new TableViewBehavior<>(paramTableView);
/*     */ 
/*     */     
/*  97 */     this.flow.setFixedCellSize(paramTableView.getFixedCellSize());
/*  98 */     this.flow.setCellFactory(paramVirtualFlow -> createCell());
/*     */     
/* 100 */     EventHandler eventHandler = paramMouseEvent -> {
/*     */         if (paramTableView.getEditingCell() != null) {
/*     */           paramTableView.edit(-1, (TableColumn)null);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         if (paramTableView.isFocusTraversable()) {
/*     */           paramTableView.requestFocus();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     this.flow.getVbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
/* 118 */     this.flow.getHbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
/*     */ 
/*     */     
/* 121 */     this.behavior.setOnFocusPreviousRow(() -> onFocusPreviousCell());
/* 122 */     this.behavior.setOnFocusNextRow(() -> onFocusNextCell());
/* 123 */     this.behavior.setOnMoveToFirstCell(() -> onMoveToFirstCell());
/* 124 */     this.behavior.setOnMoveToLastCell(() -> onMoveToLastCell());
/* 125 */     this.behavior.setOnScrollPageDown(paramBoolean -> Integer.valueOf(onScrollPageDown(paramBoolean.booleanValue())));
/* 126 */     this.behavior.setOnScrollPageUp(paramBoolean -> Integer.valueOf(onScrollPageUp(paramBoolean.booleanValue())));
/* 127 */     this.behavior.setOnSelectPreviousRow(() -> onSelectPreviousCell());
/* 128 */     this.behavior.setOnSelectNextRow(() -> onSelectNextCell());
/* 129 */     this.behavior.setOnSelectLeftCell(() -> onSelectLeftCell());
/* 130 */     this.behavior.setOnSelectRightCell(() -> onSelectRightCell());
/*     */     
/* 132 */     registerChangeListener(paramTableView.fixedCellSizeProperty(), paramObservableValue -> this.flow.setFixedCellSize(getSkinnable().getFixedCellSize()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 146 */     super.dispose();
/*     */     
/* 148 */     if (this.behavior != null)
/* 149 */       this.behavior.dispose(); 
/*     */   }
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*     */     ArrayList<TableRow> arrayList;
/*     */     TableView.TableViewSelectionModel<T> tableViewSelectionModel;
/* 155 */     switch (paramAccessibleAttribute) {
/*     */       case SHOW_ITEM:
/* 157 */         arrayList = new ArrayList();
/* 158 */         tableViewSelectionModel = getSkinnable().getSelectionModel();
/* 159 */         for (TablePosition tablePosition : tableViewSelectionModel.getSelectedCells()) {
/* 160 */           TableRow tableRow = this.flow.getPrivateCell(tablePosition.getRow());
/* 161 */           if (tableRow != null) arrayList.add(tableRow); 
/*     */         } 
/* 163 */         return FXCollections.observableArrayList(arrayList);
/*     */     } 
/* 165 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */   
/*     */   protected void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     Node node;
/*     */     ObservableList observableList;
/* 171 */     switch (paramAccessibleAction) {
/*     */       case SHOW_ITEM:
/* 173 */         node = (Node)paramVarArgs[0];
/* 174 */         if (node instanceof TableCell) {
/*     */           
/* 176 */           TableCell tableCell = (TableCell)node;
/* 177 */           this.flow.scrollTo(tableCell.getIndex());
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case SET_SELECTED_ITEMS:
/* 183 */         observableList = (ObservableList)paramVarArgs[0];
/* 184 */         if (observableList != null) {
/* 185 */           TableView.TableViewSelectionModel<T> tableViewSelectionModel = getSkinnable().getSelectionModel();
/* 186 */           if (tableViewSelectionModel != null) {
/* 187 */             tableViewSelectionModel.clearSelection();
/* 188 */             for (Node node1 : observableList) {
/* 189 */               if (node1 instanceof TableCell) {
/*     */                 
/* 191 */                 TableCell<T, ?> tableCell = (TableCell)node1;
/* 192 */                 tableViewSelectionModel.select(tableCell.getIndex(), tableCell.getTableColumn());
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         return;
/*     */     } 
/* 199 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TableRow<T> createCell() {
/*     */     TableRow<T> tableRow;
/* 215 */     TableView<T> tableView = getSkinnable();
/* 216 */     if (tableView.getRowFactory() != null) {
/* 217 */       tableRow = tableView.getRowFactory().call(tableView);
/*     */     } else {
/* 219 */       tableRow = new TableRow();
/*     */     } 
/*     */     
/* 222 */     tableRow.updateTableView(tableView);
/* 223 */     return tableRow;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getItemCount() {
/* 228 */     TableView<T> tableView = getSkinnable();
/* 229 */     return (tableView.getItems() == null) ? 0 : tableView.getItems().size();
/*     */   }
/*     */ 
/*     */   
/*     */   void horizontalScroll() {
/* 234 */     super.horizontalScroll();
/* 235 */     if (getSkinnable().getFixedCellSize() > 0.0D)
/* 236 */       this.flow.requestCellLayout(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TableViewSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */