/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.DateCellBehavior;
/*     */ import javafx.scene.control.DateCell;
/*     */ import javafx.scene.text.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateCellSkin
/*     */   extends CellSkinBase<DateCell>
/*     */ {
/*     */   private final BehaviorBase<DateCell> behavior;
/*     */   
/*     */   public DateCellSkin(DateCell paramDateCell) {
/*  70 */     super(paramDateCell);
/*     */ 
/*     */     
/*  73 */     this.behavior = new DateCellBehavior(paramDateCell);
/*     */ 
/*     */     
/*  76 */     paramDateCell.setMaxWidth(Double.MAX_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  89 */     super.dispose();
/*     */     
/*  91 */     if (this.behavior != null) {
/*  92 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateChildren() {
/*  98 */     super.updateChildren();
/*     */     
/* 100 */     Text text = (Text)getSkinnable().getProperties().get("DateCell.secondaryText");
/* 101 */     if (text != null) {
/*     */ 
/*     */       
/* 104 */       text.setManaged(false);
/* 105 */       getChildren().add(text);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 112 */     super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */     
/* 114 */     Text text = (Text)getSkinnable().getProperties().get("DateCell.secondaryText");
/* 115 */     if (text != null) {
/*     */       
/* 117 */       double d1 = paramDouble1 + paramDouble3 - rightLabelPadding() - text.getLayoutBounds().getWidth();
/* 118 */       double d2 = paramDouble2 + paramDouble4 - bottomLabelPadding() - text.getLayoutBounds().getHeight();
/* 119 */       text.relocate(snapPositionX(d1), snapPositionY(d2));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 127 */     double d = super.computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/* 128 */     return snapSizeX(Math.max(d, cellSize()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 135 */     double d = super.computePrefHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/* 136 */     return snapSizeY(Math.max(d, cellSize()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double cellSize() {
/* 148 */     double d = getCellSize();
/* 149 */     Text text = (Text)getSkinnable().getProperties().get("DateCell.secondaryText");
/* 150 */     if (text != null && d == 24.0D)
/*     */     {
/* 152 */       d = 36.0D;
/*     */     }
/* 154 */     return d;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\DateCellSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */