/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.Skin;
/*     */ import javafx.scene.control.Skinnable;
/*     */ import javafx.scene.control.Tooltip;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TooltipSkin
/*     */   implements Skin<Tooltip>
/*     */ {
/*     */   private Label tipLabel;
/*     */   private Tooltip tooltip;
/*     */   
/*     */   public TooltipSkin(Tooltip paramTooltip) {
/*  65 */     this.tooltip = paramTooltip;
/*  66 */     this.tipLabel = new Label();
/*  67 */     this.tipLabel.contentDisplayProperty().bind(paramTooltip.contentDisplayProperty());
/*  68 */     this.tipLabel.fontProperty().bind(paramTooltip.fontProperty());
/*  69 */     this.tipLabel.graphicProperty().bind(paramTooltip.graphicProperty());
/*  70 */     this.tipLabel.graphicTextGapProperty().bind(paramTooltip.graphicTextGapProperty());
/*  71 */     this.tipLabel.textAlignmentProperty().bind(paramTooltip.textAlignmentProperty());
/*  72 */     this.tipLabel.textOverrunProperty().bind(paramTooltip.textOverrunProperty());
/*  73 */     this.tipLabel.textProperty().bind(paramTooltip.textProperty());
/*  74 */     this.tipLabel.wrapTextProperty().bind(paramTooltip.wrapTextProperty());
/*  75 */     this.tipLabel.minWidthProperty().bind(paramTooltip.minWidthProperty());
/*  76 */     this.tipLabel.prefWidthProperty().bind(paramTooltip.prefWidthProperty());
/*  77 */     this.tipLabel.maxWidthProperty().bind(paramTooltip.maxWidthProperty());
/*  78 */     this.tipLabel.minHeightProperty().bind(paramTooltip.minHeightProperty());
/*  79 */     this.tipLabel.prefHeightProperty().bind(paramTooltip.prefHeightProperty());
/*  80 */     this.tipLabel.maxHeightProperty().bind(paramTooltip.maxHeightProperty());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.tipLabel.getStyleClass().setAll(paramTooltip.getStyleClass());
/*  86 */     this.tipLabel.setStyle(paramTooltip.getStyle());
/*  87 */     this.tipLabel.setId(paramTooltip.getId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Tooltip getSkinnable() {
/* 100 */     return this.tooltip;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getNode() {
/* 105 */     return this.tipLabel;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 110 */     this.tooltip = null;
/* 111 */     this.tipLabel = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TooltipSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */