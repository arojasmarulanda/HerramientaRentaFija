/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.ListViewBehavior;
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.FocusModel;
/*     */ import javafx.scene.control.IndexedCell;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.ListCell;
/*     */ import javafx.scene.control.ListView;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.StackPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListViewSkin<T>
/*     */   extends VirtualContainerBase<ListView<T>, ListCell<T>>
/*     */ {
/*  82 */   private static final boolean IS_PANNABLE = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.scene.control.skin.ListViewSkin.pannable")))).booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private static final String EMPTY_LIST_TEXT = ControlResources.getString("ListView.noContent");
/*     */ 
/*     */   
/*     */   private final VirtualFlow<ListCell<T>> flow;
/*     */ 
/*     */   
/*     */   private StackPane placeholderRegion;
/*     */   
/*     */   private Node placeholderNode;
/*     */   
/*     */   private ObservableList<T> listViewItems;
/*     */   
/*     */   private final InvalidationListener itemsChangeListener = paramObservable -> updateListViewItems();
/*     */   
/*     */   private boolean needCellsRebuilt = true;
/*     */   
/*     */   private boolean needCellsReconfigured = false;
/*     */   
/* 112 */   private int itemCount = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ListViewBehavior<T> behavior;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MapChangeListener<Object, Object> propertiesMapListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ListChangeListener<T> listViewItemsListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final WeakListChangeListener<T> weakListViewItemsListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListViewSkin(ListView<T> paramListView) {
/* 184 */     super(paramListView); this.propertiesMapListener = (paramChange -> { if (!paramChange.wasAdded())
/*     */           return;  if ("recreateKey".equals(paramChange.getKey())) { this.needCellsRebuilt = true; getSkinnable().requestLayout(); getSkinnable().getProperties().remove("recreateKey"); }  }); this.listViewItemsListener = new ListChangeListener<T>() { public void onChanged(ListChangeListener.Change<? extends T> param1Change) { while (param1Change.next()) { if (param1Change.wasReplaced()) { for (int i = param1Change.getFrom(); i < param1Change.getTo(); i++)
/*     */                 ListViewSkin.this.flow.setCellDirty(i);  break; }  if (param1Change.getRemovedSize() == ListViewSkin.this.itemCount) { ListViewSkin.this.itemCount = 0; break; }  }  ListViewSkin.this.getSkinnable().edit(-1); ListViewSkin.this.markItemCountDirty(); ListViewSkin.this.getSkinnable().requestLayout(); } }
/* 187 */       ; this.weakListViewItemsListener = new WeakListChangeListener<>(this.listViewItemsListener); this.behavior = new ListViewBehavior<>(paramListView);
/*     */ 
/*     */ 
/*     */     
/* 191 */     this.behavior.setOnFocusPreviousRow(() -> onFocusPreviousCell());
/* 192 */     this.behavior.setOnFocusNextRow(() -> onFocusNextCell());
/* 193 */     this.behavior.setOnMoveToFirstCell(() -> onMoveToFirstCell());
/* 194 */     this.behavior.setOnMoveToLastCell(() -> onMoveToLastCell());
/* 195 */     this.behavior.setOnSelectPreviousRow(() -> onSelectPreviousCell());
/* 196 */     this.behavior.setOnSelectNextRow(() -> onSelectNextCell());
/* 197 */     this.behavior.setOnScrollPageDown(this::onScrollPageDown);
/* 198 */     this.behavior.setOnScrollPageUp(this::onScrollPageUp);
/*     */     
/* 200 */     updateListViewItems();
/*     */ 
/*     */     
/* 203 */     this.flow = getVirtualFlow();
/* 204 */     this.flow.setId("virtual-flow");
/* 205 */     this.flow.setPannable(IS_PANNABLE);
/* 206 */     this.flow.setVertical((paramListView.getOrientation() == Orientation.VERTICAL));
/* 207 */     this.flow.setCellFactory(paramVirtualFlow -> createCell());
/* 208 */     this.flow.setFixedCellSize(paramListView.getFixedCellSize());
/* 209 */     getChildren().add(this.flow);
/*     */     
/* 211 */     EventHandler eventHandler = paramMouseEvent -> {
/*     */         if (paramListView.getEditingIndex() > -1) {
/*     */           paramListView.edit(-1);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         if (paramListView.isFocusTraversable()) {
/*     */           paramListView.requestFocus();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     this.flow.getVbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
/* 229 */     this.flow.getHbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
/*     */     
/* 231 */     updateItemCount();
/*     */     
/* 233 */     paramListView.itemsProperty().addListener(new WeakInvalidationListener(this.itemsChangeListener));
/*     */     
/* 235 */     ObservableMap<Object, Object> observableMap = paramListView.getProperties();
/* 236 */     observableMap.remove("recreateKey");
/* 237 */     observableMap.addListener(this.propertiesMapListener);
/*     */ 
/*     */     
/* 240 */     registerChangeListener(paramListView.itemsProperty(), paramObservableValue -> updateListViewItems());
/* 241 */     registerChangeListener(paramListView.orientationProperty(), paramObservableValue -> this.flow.setVertical((paramListView.getOrientation() == Orientation.VERTICAL)));
/*     */ 
/*     */     
/* 244 */     registerChangeListener(paramListView.cellFactoryProperty(), paramObservableValue -> this.flow.recreateCells());
/* 245 */     registerChangeListener(paramListView.parentProperty(), paramObservableValue -> {
/*     */           if (paramListView.getParent() != null && paramListView.isVisible()) {
/*     */             paramListView.requestLayout();
/*     */           }
/*     */         });
/* 250 */     registerChangeListener(paramListView.placeholderProperty(), paramObservableValue -> updatePlaceholderRegionVisibility());
/* 251 */     registerChangeListener(paramListView.fixedCellSizeProperty(), paramObservableValue -> this.flow.setFixedCellSize(paramListView.getFixedCellSize()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 266 */     super.dispose();
/*     */     
/* 268 */     if (this.behavior != null) {
/* 269 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 276 */     super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */     
/* 278 */     if (this.needCellsRebuilt) {
/* 279 */       this.flow.rebuildCells();
/* 280 */     } else if (this.needCellsReconfigured) {
/* 281 */       this.flow.reconfigureCells();
/*     */     } 
/*     */     
/* 284 */     this.needCellsRebuilt = false;
/* 285 */     this.needCellsReconfigured = false;
/*     */     
/* 287 */     if (getItemCount() == 0) {
/*     */       
/* 289 */       if (this.placeholderRegion != null) {
/* 290 */         this.placeholderRegion.setVisible((paramDouble3 > 0.0D && paramDouble4 > 0.0D));
/* 291 */         this.placeholderRegion.resizeRelocate(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */       } 
/*     */     } else {
/* 294 */       this.flow.resizeRelocate(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 300 */     checkState();
/*     */     
/* 302 */     if (getItemCount() == 0) {
/* 303 */       if (this.placeholderRegion == null) {
/* 304 */         updatePlaceholderRegionVisibility();
/*     */       }
/* 306 */       if (this.placeholderRegion != null) {
/* 307 */         return this.placeholderRegion.prefWidth(paramDouble1) + paramDouble5 + paramDouble3;
/*     */       }
/*     */     } 
/*     */     
/* 311 */     return computePrefHeight(-1.0D, paramDouble2, paramDouble3, paramDouble4, paramDouble5) * 0.618033987D;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 316 */     return 400.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getItemCount() {
/* 321 */     return this.itemCount;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateItemCount() {
/* 326 */     if (this.flow == null)
/*     */       return; 
/* 328 */     int i = this.itemCount;
/* 329 */     int j = (this.listViewItems == null) ? 0 : this.listViewItems.size();
/*     */     
/* 331 */     this.itemCount = j;
/*     */     
/* 333 */     this.flow.setCellCount(j);
/*     */     
/* 335 */     updatePlaceholderRegionVisibility();
/* 336 */     if (j != i) {
/* 337 */       requestRebuildCells();
/*     */     } else {
/* 339 */       this.needCellsReconfigured = true;
/*     */     }  } protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) { FocusModel<T> focusModel; Integer integer; MultipleSelectionModel<T> multipleSelectionModel;
/*     */     int i;
/*     */     ObservableList<Integer> observableList;
/*     */     ArrayList<ListCell> arrayList;
/*     */     Iterator<Integer> iterator;
/* 345 */     switch (paramAccessibleAttribute) {
/*     */       case SHOW_ITEM:
/* 347 */         focusModel = getSkinnable().getFocusModel();
/* 348 */         i = focusModel.getFocusedIndex();
/* 349 */         if (i == -1) {
/* 350 */           if (this.placeholderRegion != null && this.placeholderRegion.isVisible()) {
/* 351 */             return this.placeholderRegion.getChildren().get(0);
/*     */           }
/* 353 */           if (getItemCount() > 0) {
/* 354 */             i = 0;
/*     */           } else {
/* 356 */             return null;
/*     */           } 
/*     */         } 
/* 359 */         return this.flow.getPrivateCell(i);
/*     */       case SET_SELECTED_ITEMS:
/* 361 */         return Integer.valueOf(getItemCount());
/*     */       case null:
/* 363 */         integer = (Integer)paramVarArgs[0];
/* 364 */         if (integer == null) return null; 
/* 365 */         if (0 <= integer.intValue() && integer.intValue() < getItemCount()) {
/* 366 */           return this.flow.getPrivateCell(integer.intValue());
/*     */         }
/* 368 */         return null;
/*     */       
/*     */       case null:
/* 371 */         multipleSelectionModel = getSkinnable().getSelectionModel();
/* 372 */         observableList = multipleSelectionModel.getSelectedIndices();
/* 373 */         arrayList = new ArrayList(observableList.size());
/* 374 */         for (iterator = observableList.iterator(); iterator.hasNext(); ) { int j = ((Integer)iterator.next()).intValue();
/* 375 */           ListCell listCell = this.flow.getPrivateCell(j);
/* 376 */           if (listCell != null) arrayList.add(listCell);  }
/*     */         
/* 378 */         return FXCollections.observableArrayList(arrayList);
/*     */       case null:
/* 380 */         return this.flow.getVbar();
/* 381 */       case null: return this.flow.getHbar();
/* 382 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs); }
/*     */ 
/*     */   
/*     */   protected void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     Node node;
/*     */     ObservableList observableList;
/* 388 */     switch (paramAccessibleAction) {
/*     */       case SHOW_ITEM:
/* 390 */         node = (Node)paramVarArgs[0];
/* 391 */         if (node instanceof ListCell) {
/*     */           
/* 393 */           ListCell listCell = (ListCell)node;
/* 394 */           this.flow.scrollTo(listCell.getIndex());
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case SET_SELECTED_ITEMS:
/* 400 */         observableList = (ObservableList)paramVarArgs[0];
/* 401 */         if (observableList != null) {
/* 402 */           MultipleSelectionModel<T> multipleSelectionModel = getSkinnable().getSelectionModel();
/* 403 */           if (multipleSelectionModel != null) {
/* 404 */             multipleSelectionModel.clearSelection();
/* 405 */             for (Node node1 : observableList) {
/* 406 */               if (node1 instanceof ListCell) {
/*     */                 
/* 408 */                 ListCell listCell = (ListCell)node1;
/* 409 */                 multipleSelectionModel.select(listCell.getIndex());
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         return;
/*     */     } 
/* 416 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ListCell<T> createCell() {
/*     */     ListCell<?> listCell;
/* 431 */     if (getSkinnable().getCellFactory() != null) {
/* 432 */       listCell = getSkinnable().getCellFactory().call(getSkinnable());
/*     */     } else {
/* 434 */       listCell = createDefaultCellImpl();
/*     */     } 
/*     */     
/* 437 */     listCell.updateListView(getSkinnable());
/*     */     
/* 439 */     return (ListCell)listCell;
/*     */   }
/*     */   
/*     */   private void updateListViewItems() {
/* 443 */     if (this.listViewItems != null) {
/* 444 */       this.listViewItems.removeListener(this.weakListViewItemsListener);
/*     */     }
/*     */     
/* 447 */     this.listViewItems = getSkinnable().getItems();
/*     */     
/* 449 */     if (this.listViewItems != null) {
/* 450 */       this.listViewItems.addListener(this.weakListViewItemsListener);
/*     */     }
/*     */     
/* 453 */     markItemCountDirty();
/* 454 */     getSkinnable().requestLayout();
/*     */   }
/*     */   
/*     */   private final void updatePlaceholderRegionVisibility() {
/* 458 */     boolean bool = (getItemCount() == 0) ? true : false;
/*     */     
/* 460 */     if (bool) {
/* 461 */       this.placeholderNode = getSkinnable().getPlaceholder();
/* 462 */       if (this.placeholderNode == null && EMPTY_LIST_TEXT != null && !EMPTY_LIST_TEXT.isEmpty()) {
/* 463 */         this.placeholderNode = new Label();
/* 464 */         ((Label)this.placeholderNode).setText(EMPTY_LIST_TEXT);
/*     */       } 
/*     */       
/* 467 */       if (this.placeholderNode != null) {
/* 468 */         if (this.placeholderRegion == null) {
/* 469 */           this.placeholderRegion = new StackPane();
/* 470 */           this.placeholderRegion.getStyleClass().setAll(new String[] { "placeholder" });
/* 471 */           getChildren().add(this.placeholderRegion);
/*     */         } 
/*     */         
/* 474 */         this.placeholderRegion.getChildren().setAll(new Node[] { this.placeholderNode });
/*     */       } 
/*     */     } 
/*     */     
/* 478 */     this.flow.setVisible(!bool);
/* 479 */     if (this.placeholderRegion != null) {
/* 480 */       this.placeholderRegion.setVisible(bool);
/*     */     }
/*     */   }
/*     */   
/*     */   private static <T> ListCell<T> createDefaultCellImpl() {
/* 485 */     return new ListCell<T>() {
/*     */         public void updateItem(T param1T, boolean param1Boolean) {
/* 487 */           super.updateItem(param1T, param1Boolean);
/*     */           
/* 489 */           if (param1Boolean) {
/* 490 */             setText((String)null);
/* 491 */             setGraphic((Node)null);
/* 492 */           } else if (param1T instanceof Node) {
/* 493 */             setText((String)null);
/* 494 */             Node node1 = getGraphic();
/* 495 */             Node node2 = (Node)param1T;
/* 496 */             if (node1 == null || !node1.equals(node2)) {
/* 497 */               setGraphic(node2);
/*     */ 
/*     */             
/*     */             }
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 506 */             setText((param1T == null) ? "null" : param1T.toString());
/* 507 */             setGraphic((Node)null);
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private void onFocusPreviousCell() {
/* 514 */     FocusModel<T> focusModel = getSkinnable().getFocusModel();
/* 515 */     if (focusModel == null)
/* 516 */       return;  this.flow.scrollTo(focusModel.getFocusedIndex());
/*     */   }
/*     */   
/*     */   private void onFocusNextCell() {
/* 520 */     FocusModel<T> focusModel = getSkinnable().getFocusModel();
/* 521 */     if (focusModel == null)
/* 522 */       return;  this.flow.scrollTo(focusModel.getFocusedIndex());
/*     */   }
/*     */   
/*     */   private void onSelectPreviousCell() {
/* 526 */     MultipleSelectionModel<T> multipleSelectionModel = getSkinnable().getSelectionModel();
/* 527 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 529 */     int i = multipleSelectionModel.getSelectedIndex();
/* 530 */     this.flow.scrollTo(i);
/*     */ 
/*     */     
/* 533 */     IndexedCell indexedCell = (IndexedCell)this.flow.getFirstVisibleCell();
/* 534 */     if (indexedCell == null || i < indexedCell.getIndex()) {
/* 535 */       this.flow.setPosition(i / getItemCount());
/*     */     }
/*     */   }
/*     */   
/*     */   private void onSelectNextCell() {
/* 540 */     MultipleSelectionModel<T> multipleSelectionModel = getSkinnable().getSelectionModel();
/* 541 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 543 */     int i = multipleSelectionModel.getSelectedIndex();
/* 544 */     this.flow.scrollTo(i);
/*     */ 
/*     */     
/* 547 */     ListCell listCell = this.flow.getLastVisibleCell();
/* 548 */     if (listCell == null || listCell.getIndex() < i) {
/* 549 */       this.flow.setPosition(i / getItemCount());
/*     */     }
/*     */   }
/*     */   
/*     */   private void onMoveToFirstCell() {
/* 554 */     this.flow.scrollTo(0);
/* 555 */     this.flow.setPosition(0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void onMoveToLastCell() {
/* 562 */     int i = getItemCount() - 1;
/*     */     
/* 564 */     this.flow.scrollTo(i);
/* 565 */     this.flow.setPosition(1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int onScrollPageDown(boolean paramBoolean) {
/* 573 */     ListCell<T> listCell = this.flow.getLastVisibleCellWithinViewPort();
/* 574 */     if (listCell == null) return -1;
/*     */     
/* 576 */     MultipleSelectionModel<T> multipleSelectionModel = getSkinnable().getSelectionModel();
/* 577 */     FocusModel<T> focusModel = getSkinnable().getFocusModel();
/* 578 */     if (multipleSelectionModel == null || focusModel == null) return -1;
/*     */     
/* 580 */     int i = listCell.getIndex();
/*     */ 
/*     */ 
/*     */     
/* 584 */     boolean bool = false;
/* 585 */     if (paramBoolean) {
/* 586 */       bool = (listCell.isFocused() || focusModel.isFocused(i)) ? true : false;
/*     */     } else {
/* 588 */       bool = (listCell.isSelected() || multipleSelectionModel.isSelected(i)) ? true : false;
/*     */     } 
/*     */     
/* 591 */     if (bool) {
/*     */       
/* 593 */       boolean bool1 = ((paramBoolean && focusModel.getFocusedIndex() == i) || (!paramBoolean && multipleSelectionModel.getSelectedIndex() == i)) ? true : false;
/*     */       
/* 595 */       if (bool1) {
/*     */ 
/*     */         
/* 598 */         this.flow.scrollToTop(listCell);
/*     */         
/* 600 */         ListCell<T> listCell1 = this.flow.getLastVisibleCellWithinViewPort();
/* 601 */         listCell = (listCell1 == null) ? listCell : listCell1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 609 */     int j = listCell.getIndex();
/* 610 */     this.flow.scrollTo(listCell);
/* 611 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int onScrollPageUp(boolean paramBoolean) {
/* 619 */     ListCell<T> listCell = this.flow.getFirstVisibleCellWithinViewPort();
/* 620 */     if (listCell == null) return -1;
/*     */     
/* 622 */     MultipleSelectionModel<T> multipleSelectionModel = getSkinnable().getSelectionModel();
/* 623 */     FocusModel<T> focusModel = getSkinnable().getFocusModel();
/* 624 */     if (multipleSelectionModel == null || focusModel == null) return -1;
/*     */     
/* 626 */     int i = listCell.getIndex();
/*     */ 
/*     */     
/* 629 */     boolean bool = false;
/* 630 */     if (paramBoolean) {
/* 631 */       bool = (listCell.isFocused() || focusModel.isFocused(i)) ? true : false;
/*     */     } else {
/* 633 */       bool = (listCell.isSelected() || multipleSelectionModel.isSelected(i)) ? true : false;
/*     */     } 
/*     */     
/* 636 */     if (bool) {
/*     */       
/* 638 */       boolean bool1 = ((paramBoolean && focusModel.getFocusedIndex() == i) || (!paramBoolean && multipleSelectionModel.getSelectedIndex() == i)) ? true : false;
/*     */       
/* 640 */       if (bool1) {
/*     */ 
/*     */         
/* 643 */         this.flow.scrollToBottom(listCell);
/*     */         
/* 645 */         ListCell<T> listCell1 = this.flow.getFirstVisibleCellWithinViewPort();
/* 646 */         listCell = (listCell1 == null) ? listCell : listCell1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 654 */     int j = listCell.getIndex();
/* 655 */     this.flow.scrollTo(listCell);
/* 656 */     return j;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ListViewSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */