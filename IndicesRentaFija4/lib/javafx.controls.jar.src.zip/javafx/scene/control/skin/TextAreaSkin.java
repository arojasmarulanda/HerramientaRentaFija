/*      */ package javafx.scene.control.skin;
/*      */ 
/*      */ import com.sun.javafx.PlatformUtil;
/*      */ import com.sun.javafx.scene.control.behavior.TextAreaBehavior;
/*      */ import com.sun.javafx.scene.control.behavior.TextInputControlBehavior;
/*      */ import com.sun.javafx.scene.control.skin.Utils;
/*      */ import com.sun.javafx.tk.FontMetrics;
/*      */ import java.util.List;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.Timeline;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.binding.BooleanBinding;
/*      */ import javafx.beans.binding.DoubleBinding;
/*      */ import javafx.beans.binding.IntegerBinding;
/*      */ import javafx.beans.value.ObservableBooleanValue;
/*      */ import javafx.beans.value.ObservableIntegerValue;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.geometry.Bounds;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.geometry.Point2D;
/*      */ import javafx.geometry.Rectangle2D;
/*      */ import javafx.geometry.VPos;
/*      */ import javafx.geometry.VerticalDirection;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.Group;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.IndexRange;
/*      */ import javafx.scene.control.ScrollPane;
/*      */ import javafx.scene.control.TextArea;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.input.ScrollEvent;
/*      */ import javafx.scene.layout.Region;
/*      */ import javafx.scene.paint.Paint;
/*      */ import javafx.scene.shape.Path;
/*      */ import javafx.scene.shape.PathElement;
/*      */ import javafx.scene.text.HitInfo;
/*      */ import javafx.scene.text.Text;
/*      */ import javafx.scene.text.TextBoundsType;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TextAreaSkin
/*      */   extends TextInputControlSkin<TextArea>
/*      */ {
/*   88 */   private static final Path tmpCaretPath = new Path();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final TextArea textArea;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean USE_MULTIPLE_NODES = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private final TextAreaBehavior behavior;
/*      */ 
/*      */ 
/*      */   
/*  105 */   private double computedMinWidth = Double.NEGATIVE_INFINITY;
/*  106 */   private double computedMinHeight = Double.NEGATIVE_INFINITY;
/*  107 */   private double computedPrefWidth = Double.NEGATIVE_INFINITY;
/*  108 */   private double computedPrefHeight = Double.NEGATIVE_INFINITY;
/*  109 */   private double widthForComputedPrefHeight = Double.NEGATIVE_INFINITY;
/*      */   
/*      */   private double characterWidth;
/*      */   private double lineHeight;
/*  113 */   private ContentView contentView = new ContentView();
/*  114 */   private Group paragraphNodes = new Group();
/*      */   
/*      */   private Text promptNode;
/*      */   
/*      */   private ObservableBooleanValue usePromptText;
/*      */   private ObservableIntegerValue caretPosition;
/*  120 */   private Group selectionHighlightGroup = new Group();
/*      */   
/*      */   private ScrollPane scrollPane;
/*      */   
/*      */   private Bounds oldViewportBounds;
/*  125 */   private VerticalDirection scrollDirection = null;
/*      */   
/*  127 */   private Path characterBoundingPath = new Path();
/*      */   
/*  129 */   private Timeline scrollSelectionTimeline = new Timeline();
/*      */ 
/*      */ 
/*      */   
/*      */   private EventHandler<ActionEvent> scrollSelectionHandler = paramActionEvent -> {
/*      */       switch (this.scrollDirection) {
/*      */       
/*      */       } 
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*      */   private double pressX;
/*      */ 
/*      */   
/*      */   private double pressY;
/*      */ 
/*      */   
/*      */   private boolean handlePressed;
/*      */ 
/*      */   
/*  150 */   double targetCaretX = -1.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TextAreaSkin(final TextArea control) {
/*  168 */     super(control);
/*      */ 
/*      */     
/*  171 */     this.behavior = new TextAreaBehavior(control);
/*  172 */     this.behavior.setTextAreaSkin(this);
/*      */ 
/*      */     
/*  175 */     this.textArea = control;
/*      */     
/*  177 */     this.caretPosition = new IntegerBinding()
/*      */       {
/*      */         protected int computeValue() {
/*  180 */           return control.getCaretPosition();
/*      */         }
/*      */       };
/*  183 */     this.caretPosition.addListener((paramObservableValue, paramNumber1, paramNumber2) -> {
/*      */           this.targetCaretX = -1.0D;
/*      */           
/*      */           if (paramTextArea.getWidth() > 0.0D) {
/*      */             setForwardBias(true);
/*      */           }
/*      */         });
/*  190 */     forwardBiasProperty().addListener(paramObservable -> {
/*      */           if (paramTextArea.getWidth() > 0.0D) {
/*      */             updateTextNodeCaretPos(paramTextArea.getCaretPosition());
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  199 */     this.scrollPane = new ScrollPane();
/*  200 */     this.scrollPane.setFitToWidth(control.isWrapText());
/*  201 */     this.scrollPane.setContent(this.contentView);
/*  202 */     getChildren().add(this.scrollPane);
/*      */     
/*  204 */     getSkinnable().addEventFilter(ScrollEvent.ANY, paramScrollEvent -> {
/*      */           if (paramScrollEvent.isDirect() && this.handlePressed) {
/*      */             paramScrollEvent.consume();
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  211 */     this.selectionHighlightGroup.setManaged(false);
/*  212 */     this.selectionHighlightGroup.setVisible(false);
/*  213 */     this.contentView.getChildren().add(this.selectionHighlightGroup);
/*      */ 
/*      */     
/*  216 */     this.paragraphNodes.setManaged(false);
/*  217 */     this.contentView.getChildren().add(this.paragraphNodes);
/*      */ 
/*      */     
/*  220 */     this.caretPath.setManaged(false);
/*  221 */     this.caretPath.setStrokeWidth(1.0D);
/*  222 */     this.caretPath.fillProperty().bind(textFillProperty());
/*  223 */     this.caretPath.strokeProperty().bind(textFillProperty());
/*      */ 
/*      */     
/*  226 */     this.caretPath.opacityProperty().bind(new DoubleBinding()
/*      */         {
/*      */           protected double computeValue() {
/*  229 */             return TextAreaSkin.this.caretVisibleProperty().get() ? 1.0D : 0.0D;
/*      */           }
/*      */         });
/*  232 */     this.contentView.getChildren().add(this.caretPath);
/*      */     
/*  234 */     if (SHOW_HANDLES) {
/*  235 */       this.contentView.getChildren().addAll(new Node[] { this.caretHandle, this.selectionHandle1, this.selectionHandle2 });
/*      */     }
/*      */     
/*  238 */     this.scrollPane.hvalueProperty().addListener((paramObservableValue, paramNumber1, paramNumber2) -> getSkinnable().setScrollLeft(paramNumber2.doubleValue() * getScrollLeftMax()));
/*      */ 
/*      */ 
/*      */     
/*  242 */     this.scrollPane.vvalueProperty().addListener((paramObservableValue, paramNumber1, paramNumber2) -> getSkinnable().setScrollTop(paramNumber2.doubleValue() * getScrollTopMax()));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  247 */     this.scrollSelectionTimeline.setCycleCount(-1);
/*  248 */     ObservableList<KeyFrame> observableList = this.scrollSelectionTimeline.getKeyFrames();
/*  249 */     observableList.clear();
/*  250 */     observableList.add(new KeyFrame(Duration.millis(350.0D), this.scrollSelectionHandler, new javafx.animation.KeyValue[0]));
/*      */ 
/*      */     
/*  253 */     for (byte b1 = 0, b2 = 1; b1 < b2; b1++) {
/*  254 */       CharSequence charSequence = (b2 == 1) ? control.textProperty().getValueSafe() : control.getParagraphs().get(b1);
/*  255 */       addParagraphNode(b1, charSequence.toString());
/*      */     } 
/*      */     
/*  258 */     control.selectionProperty().addListener((paramObservableValue, paramIndexRange1, paramIndexRange2) -> {
/*      */           paramTextArea.requestLayout();
/*      */           
/*      */           this.contentView.requestLayout();
/*      */         });
/*      */     
/*  264 */     control.wrapTextProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*      */           invalidateMetrics();
/*      */           
/*      */           this.scrollPane.setFitToWidth(paramBoolean2.booleanValue());
/*      */         });
/*  269 */     control.prefColumnCountProperty().addListener((paramObservableValue, paramNumber1, paramNumber2) -> {
/*      */           invalidateMetrics();
/*      */           
/*      */           updatePrefViewportWidth();
/*      */         });
/*  274 */     control.prefRowCountProperty().addListener((paramObservableValue, paramNumber1, paramNumber2) -> {
/*      */           invalidateMetrics();
/*      */           
/*      */           updatePrefViewportHeight();
/*      */         });
/*  279 */     updateFontMetrics();
/*  280 */     this.fontMetrics.addListener(paramObservable -> updateFontMetrics());
/*      */ 
/*      */ 
/*      */     
/*  284 */     this.contentView.paddingProperty().addListener(paramObservable -> {
/*      */           updatePrefViewportWidth();
/*      */           
/*      */           updatePrefViewportHeight();
/*      */         });
/*  289 */     this.scrollPane.viewportBoundsProperty().addListener(paramObservable -> {
/*      */           if (this.scrollPane.getViewportBounds() != null) {
/*      */             Bounds bounds = this.scrollPane.getViewportBounds();
/*      */ 
/*      */             
/*      */             if (this.oldViewportBounds == null || this.oldViewportBounds.getWidth() != bounds.getWidth() || this.oldViewportBounds.getHeight() != bounds.getHeight()) {
/*      */               invalidateMetrics();
/*      */ 
/*      */               
/*      */               this.oldViewportBounds = bounds;
/*      */ 
/*      */               
/*      */               this.contentView.requestLayout();
/*      */             } 
/*      */           } 
/*      */         });
/*      */     
/*  306 */     control.scrollTopProperty().addListener((paramObservableValue, paramNumber1, paramNumber2) -> {
/*      */           double d = (paramNumber2.doubleValue() < getScrollTopMax()) ? (paramNumber2.doubleValue() / getScrollTopMax()) : 1.0D;
/*      */           
/*      */           this.scrollPane.setVvalue(d);
/*      */         });
/*      */     
/*  312 */     control.scrollLeftProperty().addListener((paramObservableValue, paramNumber1, paramNumber2) -> {
/*      */           double d = (paramNumber2.doubleValue() < getScrollLeftMax()) ? (paramNumber2.doubleValue() / getScrollLeftMax()) : 1.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           this.scrollPane.setHvalue(d);
/*      */         });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  346 */     control.textProperty().addListener(paramObservable -> {
/*      */           invalidateMetrics();
/*      */           
/*      */           ((Text)this.paragraphNodes.getChildren().get(0)).setText(paramTextArea.textProperty().getValueSafe());
/*      */           
/*      */           this.contentView.requestLayout();
/*      */         });
/*  353 */     this.usePromptText = new BooleanBinding()
/*      */       {
/*      */         protected boolean computeValue() {
/*  356 */           String str1 = control.getText();
/*  357 */           String str2 = control.getPromptText();
/*  358 */           return ((str1 == null || str1.isEmpty()) && str2 != null && 
/*  359 */             !str2.isEmpty());
/*      */         }
/*      */       };
/*      */     
/*  363 */     if (this.usePromptText.get()) {
/*  364 */       createPromptNode();
/*      */     }
/*      */     
/*  367 */     this.usePromptText.addListener(paramObservable -> {
/*      */           createPromptNode();
/*      */           
/*      */           paramTextArea.requestLayout();
/*      */         });
/*  372 */     updateHighlightFill();
/*  373 */     updatePrefViewportWidth();
/*  374 */     updatePrefViewportHeight();
/*  375 */     if (control.isFocused()) setCaretAnimating(true);
/*      */     
/*  377 */     if (SHOW_HANDLES) {
/*  378 */       this.selectionHandle1.setRotate(180.0D);
/*      */       
/*  380 */       EventHandler<? super MouseEvent> eventHandler1 = paramMouseEvent -> {
/*      */           this.pressX = paramMouseEvent.getX();
/*      */           
/*      */           this.pressY = paramMouseEvent.getY();
/*      */           this.handlePressed = true;
/*      */           paramMouseEvent.consume();
/*      */         };
/*  387 */       EventHandler<? super MouseEvent> eventHandler2 = paramMouseEvent -> this.handlePressed = false;
/*      */ 
/*      */ 
/*      */       
/*  391 */       this.caretHandle.setOnMousePressed(eventHandler1);
/*  392 */       this.selectionHandle1.setOnMousePressed(eventHandler1);
/*  393 */       this.selectionHandle2.setOnMousePressed(eventHandler1);
/*      */       
/*  395 */       this.caretHandle.setOnMouseReleased(eventHandler2);
/*  396 */       this.selectionHandle1.setOnMouseReleased(eventHandler2);
/*  397 */       this.selectionHandle2.setOnMouseReleased(eventHandler2);
/*      */       
/*  399 */       this.caretHandle.setOnMouseDragged(paramMouseEvent -> {
/*      */             Text text = getTextNode();
/*      */             
/*      */             Point2D point2D1 = text.localToScene(0.0D, 0.0D);
/*      */             
/*      */             Point2D point2D2 = new Point2D(paramMouseEvent.getSceneX() - point2D1.getX() - this.pressX + this.caretHandle.getWidth() / 2.0D, paramMouseEvent.getSceneY() - point2D1.getY() - this.pressY - 6.0D);
/*      */             HitInfo hitInfo = text.hitTest(translateCaretPosition(point2D2));
/*      */             positionCaret(hitInfo, false);
/*      */             paramMouseEvent.consume();
/*      */           });
/*  409 */       this.selectionHandle1.setOnMouseDragged(paramMouseEvent -> {
/*      */             TextArea textArea = getSkinnable();
/*      */             
/*      */             Text text = getTextNode();
/*      */             
/*      */             Point2D point2D1 = text.localToScene(0.0D, 0.0D);
/*      */             
/*      */             Point2D point2D2 = new Point2D(paramMouseEvent.getSceneX() - point2D1.getX() - this.pressX + this.selectionHandle1.getWidth() / 2.0D, paramMouseEvent.getSceneY() - point2D1.getY() - this.pressY + this.selectionHandle1.getHeight() + 5.0D);
/*      */             
/*      */             HitInfo hitInfo = text.hitTest(translateCaretPosition(point2D2));
/*      */             
/*      */             if (textArea.getAnchor() < textArea.getCaretPosition()) {
/*      */               textArea.selectRange(textArea.getCaretPosition(), textArea.getAnchor());
/*      */             }
/*      */             int i = hitInfo.getCharIndex();
/*      */             if (i > 0 && i >= textArea.getAnchor()) {
/*      */               i = textArea.getAnchor();
/*      */             }
/*      */             positionCaret(hitInfo, true);
/*      */             paramMouseEvent.consume();
/*      */           });
/*  430 */       this.selectionHandle2.setOnMouseDragged(paramMouseEvent -> {
/*      */             TextArea textArea = getSkinnable();
/*      */             Text text = getTextNode();
/*      */             Point2D point2D1 = text.localToScene(0.0D, 0.0D);
/*      */             Point2D point2D2 = new Point2D(paramMouseEvent.getSceneX() - point2D1.getX() - this.pressX + this.selectionHandle2.getWidth() / 2.0D, paramMouseEvent.getSceneY() - point2D1.getY() - this.pressY - 6.0D);
/*      */             HitInfo hitInfo = text.hitTest(translateCaretPosition(point2D2));
/*      */             if (textArea.getAnchor() > textArea.getCaretPosition()) {
/*      */               textArea.selectRange(textArea.getCaretPosition(), textArea.getAnchor());
/*      */             }
/*      */             int i = hitInfo.getCharIndex();
/*      */             if (i > 0) {
/*      */               if (i <= textArea.getAnchor() + 1) {
/*      */                 i = Math.min(textArea.getAnchor() + 2, textArea.getLength());
/*      */               }
/*      */               positionCaret(hitInfo, true);
/*      */             } 
/*      */             paramMouseEvent.consume();
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void invalidateMetrics() {
/*  463 */     this.computedMinWidth = Double.NEGATIVE_INFINITY;
/*  464 */     this.computedMinHeight = Double.NEGATIVE_INFINITY;
/*  465 */     this.computedPrefWidth = Double.NEGATIVE_INFINITY;
/*  466 */     this.computedPrefHeight = Double.NEGATIVE_INFINITY;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  471 */     this.scrollPane.resizeRelocate(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void updateHighlightFill() {
/*  476 */     for (Node node : this.selectionHighlightGroup.getChildren()) {
/*  477 */       Path path = (Path)node;
/*  478 */       path.setFill(highlightFillProperty().get());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HitInfo getIndex(double paramDouble1, double paramDouble2) {
/*  493 */     Text text = getTextNode();
/*  494 */     Point2D point2D = new Point2D(paramDouble1 - text.getLayoutX(), paramDouble2 - getTextTranslateY());
/*  495 */     return text.hitTest(translateCaretPosition(point2D));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveCaret(TextInputControlSkin.TextUnit paramTextUnit, TextInputControlSkin.Direction paramDirection, boolean paramBoolean) {
/*  501 */     switch (paramTextUnit) {
/*      */       case UP:
/*  503 */         switch (paramDirection) {
/*      */           case UP:
/*      */           case DOWN:
/*  506 */             nextCharacterVisually((paramDirection == TextInputControlSkin.Direction.RIGHT));
/*      */             return;
/*      */         } 
/*  509 */         throw new IllegalArgumentException("" + paramDirection);
/*      */ 
/*      */ 
/*      */       
/*      */       case DOWN:
/*  514 */         switch (paramDirection) {
/*      */           case null:
/*  516 */             previousLine(paramBoolean);
/*      */             return;
/*      */           case null:
/*  519 */             nextLine(paramBoolean);
/*      */             return;
/*      */           case null:
/*  522 */             lineStart(paramBoolean, (paramBoolean && PlatformUtil.isMac()));
/*      */             return;
/*      */           case null:
/*  525 */             lineEnd(paramBoolean, (paramBoolean && PlatformUtil.isMac()));
/*      */             return;
/*      */         } 
/*  528 */         throw new IllegalArgumentException("" + paramDirection);
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/*  533 */         switch (paramDirection) {
/*      */           case null:
/*  535 */             previousPage(paramBoolean);
/*      */             return;
/*      */           case null:
/*  538 */             nextPage(paramBoolean);
/*      */             return;
/*      */         } 
/*  541 */         throw new IllegalArgumentException("" + paramDirection);
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/*  546 */         switch (paramDirection) {
/*      */           case null:
/*  548 */             paragraphStart(true, paramBoolean);
/*      */             return;
/*      */           case null:
/*  551 */             paragraphEnd(true, paramBoolean);
/*      */             return;
/*      */           case null:
/*  554 */             paragraphStart(false, paramBoolean);
/*      */             return;
/*      */           case null:
/*  557 */             paragraphEnd(false, paramBoolean);
/*      */             return;
/*      */         } 
/*  560 */         throw new IllegalArgumentException("" + paramDirection);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  565 */     throw new IllegalArgumentException("" + paramTextUnit);
/*      */   }
/*      */ 
/*      */   
/*      */   private void nextCharacterVisually(boolean paramBoolean) {
/*  570 */     if (isRTL())
/*      */     {
/*  572 */       paramBoolean = !paramBoolean;
/*      */     }
/*      */     
/*  575 */     Text text = getTextNode();
/*  576 */     Bounds bounds = this.caretPath.getLayoutBounds();
/*  577 */     if (this.caretPath.getElements().size() == 4)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  582 */       bounds = (new Path(new PathElement[] { this.caretPath.getElements().get(0), this.caretPath.getElements().get(1) })).getLayoutBounds();
/*      */     }
/*  584 */     double d1 = paramBoolean ? bounds.getMaxX() : bounds.getMinX();
/*  585 */     double d2 = (bounds.getMinY() + bounds.getMaxY()) / 2.0D;
/*  586 */     HitInfo hitInfo = text.hitTest(new Point2D(d1, d2));
/*  587 */     boolean bool = hitInfo.isLeading();
/*  588 */     Path path = new Path(text.rangeShape(hitInfo.getCharIndex(), hitInfo.getCharIndex() + 1));
/*  589 */     if ((paramBoolean && path.getLayoutBounds().getMaxX() > bounds.getMaxX()) || (!paramBoolean && path
/*  590 */       .getLayoutBounds().getMinX() < bounds.getMinX())) {
/*  591 */       bool = !bool;
/*  592 */       positionCaret(hitInfo.getInsertionIndex(), bool, false, false);
/*      */     } else {
/*      */       
/*  595 */       int i = this.textArea.getCaretPosition();
/*  596 */       this.targetCaretX = paramBoolean ? 0.0D : Double.MAX_VALUE;
/*      */       
/*  598 */       downLines(paramBoolean ? 1 : -1, false, false);
/*  599 */       this.targetCaretX = -1.0D;
/*  600 */       if (i == this.textArea.getCaretPosition()) {
/*  601 */         if (paramBoolean) {
/*  602 */           this.textArea.forward();
/*      */         } else {
/*  604 */           this.textArea.backward();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void downLines(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/*  611 */     Text text = getTextNode();
/*  612 */     Bounds bounds1 = this.caretPath.getLayoutBounds();
/*      */ 
/*      */     
/*  615 */     double d1 = (bounds1.getMinY() + bounds1.getMaxY()) / 2.0D + paramInt * this.lineHeight;
/*  616 */     if (d1 < 0.0D) {
/*  617 */       d1 = 0.0D;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  622 */     double d2 = (this.targetCaretX >= 0.0D) ? this.targetCaretX : bounds1.getMaxX();
/*      */ 
/*      */     
/*  625 */     HitInfo hitInfo = text.hitTest(translateCaretPosition(new Point2D(d2, d1)));
/*  626 */     int i = hitInfo.getCharIndex();
/*      */ 
/*      */     
/*  629 */     int j = text.getCaretPosition();
/*  630 */     boolean bool = text.isCaretBias();
/*  631 */     text.setCaretBias(hitInfo.isLeading());
/*  632 */     text.setCaretPosition(i);
/*  633 */     tmpCaretPath.getElements().clear();
/*  634 */     tmpCaretPath.getElements().addAll(text.getCaretShape());
/*  635 */     tmpCaretPath.setLayoutX(text.getLayoutX());
/*  636 */     tmpCaretPath.setLayoutY(text.getLayoutY());
/*  637 */     Bounds bounds2 = tmpCaretPath.getLayoutBounds();
/*      */     
/*  639 */     double d3 = (bounds2.getMinY() + bounds2.getMaxY()) / 2.0D;
/*  640 */     text.setCaretBias(bool);
/*  641 */     text.setCaretPosition(j);
/*      */ 
/*      */ 
/*      */     
/*  645 */     if (paramInt == 0 || (paramInt > 0 && d3 > bounds1
/*  646 */       .getMaxY()) || (paramInt < 0 && d3 < bounds1
/*  647 */       .getMinY())) {
/*      */       
/*  649 */       positionCaret(hitInfo.getInsertionIndex(), hitInfo.isLeading(), paramBoolean1, paramBoolean2);
/*  650 */       this.targetCaretX = d2;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void previousLine(boolean paramBoolean) {
/*  655 */     downLines(-1, paramBoolean, false);
/*      */   }
/*      */   
/*      */   private void nextLine(boolean paramBoolean) {
/*  659 */     downLines(1, paramBoolean, false);
/*      */   }
/*      */   
/*      */   private void previousPage(boolean paramBoolean) {
/*  663 */     downLines(-((int)(this.scrollPane.getViewportBounds().getHeight() / this.lineHeight)), paramBoolean, false);
/*      */   }
/*      */ 
/*      */   
/*      */   private void nextPage(boolean paramBoolean) {
/*  668 */     downLines((int)(this.scrollPane.getViewportBounds().getHeight() / this.lineHeight), paramBoolean, false);
/*      */   }
/*      */ 
/*      */   
/*      */   private void lineStart(boolean paramBoolean1, boolean paramBoolean2) {
/*  673 */     this.targetCaretX = 0.0D;
/*  674 */     downLines(0, paramBoolean1, paramBoolean2);
/*  675 */     this.targetCaretX = -1.0D;
/*      */   }
/*      */   
/*      */   private void lineEnd(boolean paramBoolean1, boolean paramBoolean2) {
/*  679 */     this.targetCaretX = Double.MAX_VALUE;
/*  680 */     downLines(0, paramBoolean1, paramBoolean2);
/*  681 */     this.targetCaretX = -1.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   private void paragraphStart(boolean paramBoolean1, boolean paramBoolean2) {
/*  686 */     TextArea textArea = getSkinnable();
/*  687 */     String str = textArea.textProperty().getValueSafe();
/*  688 */     int i = textArea.getCaretPosition();
/*      */     
/*  690 */     if (i > 0) {
/*  691 */       if (paramBoolean1 && str.codePointAt(i - 1) == 10)
/*      */       {
/*      */         
/*  694 */         i--;
/*      */       }
/*      */       
/*  697 */       while (i > 0 && str.codePointAt(i - 1) != 10) {
/*  698 */         i--;
/*      */       }
/*  700 */       if (paramBoolean2) {
/*  701 */         textArea.selectPositionCaret(i);
/*      */       } else {
/*  703 */         textArea.positionCaret(i);
/*  704 */         setForwardBias(true);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void paragraphEnd(boolean paramBoolean1, boolean paramBoolean2) {
/*  710 */     TextArea textArea = getSkinnable();
/*  711 */     String str = textArea.textProperty().getValueSafe();
/*  712 */     int i = textArea.getCaretPosition();
/*  713 */     int j = str.length();
/*  714 */     boolean bool = false;
/*  715 */     boolean bool1 = PlatformUtil.isWindows();
/*      */     
/*  717 */     if (i < j) {
/*  718 */       if (paramBoolean1 && str.codePointAt(i) == 10) {
/*      */ 
/*      */         
/*  721 */         i++;
/*  722 */         bool = true;
/*      */       } 
/*  724 */       if (!bool1 || !bool) {
/*      */         
/*  726 */         while (i < j && str.codePointAt(i) != 10) {
/*  727 */           i++;
/*      */         }
/*  729 */         if (bool1 && i < j)
/*      */         {
/*      */           
/*  732 */           i++;
/*      */         }
/*      */       } 
/*  735 */       if (paramBoolean2) {
/*  736 */         textArea.selectPositionCaret(i);
/*      */       } else {
/*  738 */         textArea.positionCaret(i);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected PathElement[] getUnderlineShape(int paramInt1, int paramInt2) {
/*  745 */     int i = 0;
/*  746 */     for (Node node : this.paragraphNodes.getChildren()) {
/*  747 */       Text text = (Text)node;
/*  748 */       int j = i + text.textProperty().getValueSafe().length();
/*  749 */       if (j >= paramInt1) {
/*  750 */         return text.underlineShape(paramInt1 - i, paramInt2 - i);
/*      */       }
/*  752 */       i = j + 1;
/*      */     } 
/*  754 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected PathElement[] getRangeShape(int paramInt1, int paramInt2) {
/*  759 */     int i = 0;
/*  760 */     for (Node node : this.paragraphNodes.getChildren()) {
/*  761 */       Text text = (Text)node;
/*  762 */       int j = i + text.textProperty().getValueSafe().length();
/*  763 */       if (j >= paramInt1) {
/*  764 */         return text.rangeShape(paramInt1 - i, paramInt2 - i);
/*      */       }
/*  766 */       i = j + 1;
/*      */     } 
/*  768 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void addHighlight(List<? extends Node> paramList, int paramInt) {
/*  773 */     int i = 0;
/*  774 */     Text text = null;
/*  775 */     for (Node node : this.paragraphNodes.getChildren()) {
/*  776 */       Text text1 = (Text)node;
/*  777 */       int j = i + text1.textProperty().getValueSafe().length();
/*  778 */       if (j >= paramInt) {
/*  779 */         text = text1;
/*      */         break;
/*      */       } 
/*  782 */       i = j + 1;
/*      */     } 
/*      */     
/*  785 */     if (text != null) {
/*  786 */       for (Node node : paramList) {
/*  787 */         node.setLayoutX(text.getLayoutX());
/*  788 */         node.setLayoutY(text.getLayoutY());
/*      */       } 
/*      */     }
/*  791 */     this.contentView.getChildren().addAll(paramList);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void removeHighlight(List<? extends Node> paramList) {
/*  796 */     this.contentView.getChildren().removeAll(paramList);
/*      */   }
/*      */ 
/*      */   
/*      */   public Point2D getMenuPosition() {
/*  801 */     this.contentView.layoutChildren();
/*  802 */     Point2D point2D = super.getMenuPosition();
/*  803 */     if (point2D != null)
/*      */     {
/*  805 */       point2D = new Point2D(Math.max(0.0D, point2D.getX() - this.contentView.snappedLeftInset() - getSkinnable().getScrollLeft()), Math.max(0.0D, point2D.getY() - this.contentView.snappedTopInset() - getSkinnable().getScrollTop()));
/*      */     }
/*  807 */     return point2D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Bounds getCaretBounds() {
/*  816 */     return getSkinnable().sceneToLocal(this.caretPath.localToScene(this.caretPath.getBoundsInLocal()));
/*      */   }
/*      */   
/*      */   protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*      */     Text text;
/*  821 */     switch (paramAccessibleAttribute) {
/*      */       case UP:
/*      */       case DOWN:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  827 */         text = getTextNode();
/*  828 */         return text.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*  829 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  835 */     super.dispose();
/*      */     
/*  837 */     if (this.behavior != null) {
/*  838 */       this.behavior.dispose();
/*      */     }
/*      */ 
/*      */     
/*  842 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   public double computeBaselineOffset(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  847 */     Text text = (Text)this.paragraphNodes.getChildren().get(0);
/*  848 */     return Utils.getAscent(getSkinnable().getFont(), text.getBoundsType()) + this.contentView
/*  849 */       .snappedTopInset() + this.textArea.snappedTopInset();
/*      */   }
/*      */   
/*      */   private char getCharacter(int paramInt) {
/*  853 */     int i = this.paragraphNodes.getChildren().size();
/*      */     
/*  855 */     byte b = 0;
/*  856 */     int j = paramInt;
/*      */     
/*  858 */     String str = null;
/*  859 */     while (b < i) {
/*  860 */       Text text = (Text)this.paragraphNodes.getChildren().get(b);
/*  861 */       str = text.getText();
/*  862 */       int k = str.length() + 1;
/*      */       
/*  864 */       if (j < k) {
/*      */         break;
/*      */       }
/*      */       
/*  868 */       j -= k;
/*  869 */       b++;
/*      */     } 
/*      */     
/*  872 */     return (j == str.length()) ? '\n' : str.charAt(j);
/*      */   }
/*      */ 
/*      */   
/*      */   protected int getInsertionPoint(double paramDouble1, double paramDouble2) {
/*  877 */     TextArea textArea = getSkinnable();
/*      */     
/*  879 */     int i = this.paragraphNodes.getChildren().size();
/*  880 */     int j = -1;
/*      */     
/*  882 */     if (i > 0) {
/*  883 */       if (paramDouble2 < this.contentView.snappedTopInset()) {
/*      */         
/*  885 */         Text text = (Text)this.paragraphNodes.getChildren().get(0);
/*  886 */         j = getNextInsertionPoint(text, paramDouble1, -1, VerticalDirection.DOWN);
/*  887 */       } else if (paramDouble2 > this.contentView.snappedTopInset() + this.contentView.getHeight()) {
/*      */         
/*  889 */         int k = i - 1;
/*  890 */         Text text = (Text)this.paragraphNodes.getChildren().get(k);
/*      */ 
/*      */         
/*  893 */         j = getNextInsertionPoint(text, paramDouble1, -1, VerticalDirection.UP) + textArea.getLength() - text.getText().length();
/*      */       } else {
/*      */         
/*  896 */         int k = 0;
/*  897 */         for (byte b = 0; b < i; b++) {
/*  898 */           Text text = (Text)this.paragraphNodes.getChildren().get(b);
/*      */           
/*  900 */           Bounds bounds = text.getBoundsInLocal();
/*  901 */           double d = text.getLayoutY() + bounds.getMinY();
/*  902 */           if (paramDouble2 >= d && paramDouble2 < d + text
/*  903 */             .getBoundsInLocal().getHeight()) {
/*  904 */             j = getInsertionPoint(text, paramDouble1 - text
/*  905 */                 .getLayoutX(), paramDouble2 - text
/*  906 */                 .getLayoutY()) + k;
/*      */             
/*      */             break;
/*      */           } 
/*  910 */           k += text.getText().length() + 1;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  915 */     return j;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void positionCaret(HitInfo paramHitInfo, boolean paramBoolean) {
/*  926 */     positionCaret(paramHitInfo.getInsertionIndex(), paramHitInfo.isLeading(), paramBoolean, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void positionCaret(int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*  933 */     boolean bool = (paramInt > 0 && paramInt <= getSkinnable().getLength() && getSkinnable().getText().codePointAt(paramInt - 1) == 10) ? true : false;
/*      */ 
/*      */     
/*  936 */     if (!paramBoolean1 && bool) {
/*  937 */       paramBoolean1 = true;
/*  938 */       paramInt--;
/*      */     } 
/*      */     
/*  941 */     if (paramBoolean2) {
/*  942 */       if (paramBoolean3) {
/*  943 */         getSkinnable().extendSelection(paramInt);
/*      */       } else {
/*  945 */         getSkinnable().selectPositionCaret(paramInt);
/*      */       } 
/*      */     } else {
/*  948 */       getSkinnable().positionCaret(paramInt);
/*      */     } 
/*      */     
/*  951 */     setForwardBias(paramBoolean1);
/*      */   }
/*      */ 
/*      */   
/*      */   public Rectangle2D getCharacterBounds(int paramInt) {
/*  956 */     TextArea textArea = getSkinnable();
/*      */     
/*  958 */     int i = this.paragraphNodes.getChildren().size();
/*  959 */     int j = textArea.getLength() + 1;
/*      */     
/*  961 */     Text text = null;
/*      */     do {
/*  963 */       text = (Text)this.paragraphNodes.getChildren().get(--i);
/*  964 */       j -= text.getText().length() + 1;
/*  965 */     } while (paramInt < j);
/*      */     
/*  967 */     int k = paramInt - j;
/*  968 */     boolean bool = false;
/*      */     
/*  970 */     if (k == text.getText().length()) {
/*  971 */       k--;
/*  972 */       bool = true;
/*      */     } 
/*      */     
/*  975 */     this.characterBoundingPath.getElements().clear();
/*  976 */     this.characterBoundingPath.getElements().addAll(text.rangeShape(k, k + 1));
/*  977 */     this.characterBoundingPath.setLayoutX(text.getLayoutX());
/*  978 */     this.characterBoundingPath.setLayoutY(text.getLayoutY());
/*      */     
/*  980 */     Bounds bounds = this.characterBoundingPath.getBoundsInLocal();
/*      */     
/*  982 */     double d1 = bounds.getMinX() + text.getLayoutX() - textArea.getScrollLeft();
/*  983 */     double d2 = bounds.getMinY() + text.getLayoutY() - textArea.getScrollTop();
/*      */ 
/*      */     
/*  986 */     double d3 = bounds.isEmpty() ? 0.0D : bounds.getWidth();
/*  987 */     double d4 = bounds.isEmpty() ? 0.0D : bounds.getHeight();
/*      */     
/*  989 */     if (bool) {
/*  990 */       d1 += d3;
/*  991 */       d3 = 0.0D;
/*      */     } 
/*      */     
/*  994 */     return new Rectangle2D(d1, d2, d3, d4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void scrollCharacterToVisible(int paramInt) {
/* 1003 */     Platform.runLater(() -> {
/*      */           if (getSkinnable().getLength() == 0) {
/*      */             return;
/*      */           }
/*      */           Rectangle2D rectangle2D = getCharacterBounds(paramInt);
/*      */           scrollBoundsToVisible(rectangle2D);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TextAreaBehavior getBehavior() {
/* 1021 */     return this.behavior;
/*      */   }
/*      */   
/*      */   private void createPromptNode() {
/* 1025 */     if (this.promptNode == null && this.usePromptText.get()) {
/* 1026 */       this.promptNode = new Text();
/* 1027 */       this.contentView.getChildren().add(0, this.promptNode);
/* 1028 */       this.promptNode.setManaged(false);
/* 1029 */       this.promptNode.getStyleClass().add("text");
/* 1030 */       this.promptNode.visibleProperty().bind(this.usePromptText);
/* 1031 */       this.promptNode.fontProperty().bind(getSkinnable().fontProperty());
/* 1032 */       this.promptNode.textProperty().bind(getSkinnable().promptTextProperty());
/* 1033 */       this.promptNode.fillProperty().bind(promptTextFillProperty());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addParagraphNode(int paramInt, String paramString) {
/* 1038 */     TextArea textArea = getSkinnable();
/* 1039 */     Text text = new Text(paramString);
/* 1040 */     text.setTextOrigin(VPos.TOP);
/* 1041 */     text.setManaged(false);
/* 1042 */     text.getStyleClass().add("text");
/* 1043 */     text.boundsTypeProperty().addListener((paramObservableValue, paramTextBoundsType1, paramTextBoundsType2) -> {
/*      */           invalidateMetrics();
/*      */           updateFontMetrics();
/*      */         });
/* 1047 */     this.paragraphNodes.getChildren().add(paramInt, text);
/*      */     
/* 1049 */     text.fontProperty().bind(textArea.fontProperty());
/* 1050 */     text.fillProperty().bind(textFillProperty());
/* 1051 */     text.selectionFillProperty().bind(highlightTextFillProperty());
/*      */   }
/*      */   
/*      */   private double getScrollTopMax() {
/* 1055 */     return Math.max(0.0D, this.contentView.getHeight() - this.scrollPane.getViewportBounds().getHeight());
/*      */   }
/*      */   
/*      */   private double getScrollLeftMax() {
/* 1059 */     return Math.max(0.0D, this.contentView.getWidth() - this.scrollPane.getViewportBounds().getWidth());
/*      */   }
/*      */   
/*      */   private int getInsertionPoint(Text paramText, double paramDouble1, double paramDouble2) {
/* 1063 */     HitInfo hitInfo = paramText.hitTest(new Point2D(paramDouble1, paramDouble2));
/* 1064 */     return hitInfo.getInsertionIndex();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int getNextInsertionPoint(Text paramText, double paramDouble, int paramInt, VerticalDirection paramVerticalDirection) {
/* 1070 */     return 0;
/*      */   }
/*      */   
/*      */   private void scrollCaretToVisible() {
/* 1074 */     TextArea textArea = getSkinnable();
/* 1075 */     Bounds bounds = this.caretPath.getLayoutBounds();
/* 1076 */     double d1 = bounds.getMinX() - textArea.getScrollLeft();
/* 1077 */     double d2 = bounds.getMinY() - textArea.getScrollTop();
/* 1078 */     double d3 = bounds.getWidth();
/* 1079 */     double d4 = bounds.getHeight();
/*      */     
/* 1081 */     if (SHOW_HANDLES) {
/* 1082 */       if (this.caretHandle.isVisible()) {
/* 1083 */         d4 += this.caretHandle.getHeight();
/* 1084 */       } else if (this.selectionHandle1.isVisible() && this.selectionHandle2.isVisible()) {
/* 1085 */         d1 -= this.selectionHandle1.getWidth() / 2.0D;
/* 1086 */         d2 -= this.selectionHandle1.getHeight();
/* 1087 */         d3 += this.selectionHandle1.getWidth() / 2.0D + this.selectionHandle2.getWidth() / 2.0D;
/* 1088 */         d4 += this.selectionHandle1.getHeight() + this.selectionHandle2.getHeight();
/*      */       } 
/*      */     }
/*      */     
/* 1092 */     if (d3 > 0.0D && d4 > 0.0D) {
/* 1093 */       scrollBoundsToVisible(new Rectangle2D(d1, d2, d3, d4));
/*      */     }
/*      */   }
/*      */   
/*      */   private void scrollBoundsToVisible(Rectangle2D paramRectangle2D) {
/* 1098 */     TextArea textArea = getSkinnable();
/* 1099 */     Bounds bounds = this.scrollPane.getViewportBounds();
/*      */     
/* 1101 */     double d1 = bounds.getWidth();
/* 1102 */     double d2 = bounds.getHeight();
/* 1103 */     double d3 = textArea.getScrollTop();
/* 1104 */     double d4 = textArea.getScrollLeft();
/* 1105 */     double d5 = 6.0D;
/*      */     
/* 1107 */     if (paramRectangle2D.getMinY() < 0.0D) {
/* 1108 */       double d = d3 + paramRectangle2D.getMinY();
/* 1109 */       if (d <= this.contentView.snappedTopInset()) {
/* 1110 */         d = 0.0D;
/*      */       }
/* 1112 */       textArea.setScrollTop(d);
/* 1113 */     } else if (this.contentView.snappedTopInset() + paramRectangle2D.getMaxY() > d2) {
/* 1114 */       double d = d3 + this.contentView.snappedTopInset() + paramRectangle2D.getMaxY() - d2;
/* 1115 */       if (d >= getScrollTopMax() - this.contentView.snappedBottomInset()) {
/* 1116 */         d = getScrollTopMax();
/*      */       }
/* 1118 */       textArea.setScrollTop(d);
/*      */     } 
/*      */ 
/*      */     
/* 1122 */     if (paramRectangle2D.getMinX() < 0.0D) {
/* 1123 */       double d = d4 + paramRectangle2D.getMinX() - d5;
/* 1124 */       if (d <= this.contentView.snappedLeftInset() + d5) {
/* 1125 */         d = 0.0D;
/*      */       }
/* 1127 */       textArea.setScrollLeft(d);
/* 1128 */     } else if (this.contentView.snappedLeftInset() + paramRectangle2D.getMaxX() > d1) {
/* 1129 */       double d = d4 + this.contentView.snappedLeftInset() + paramRectangle2D.getMaxX() - d1 + d5;
/* 1130 */       if (d >= getScrollLeftMax() - this.contentView.snappedRightInset() - d5) {
/* 1131 */         d = getScrollLeftMax();
/*      */       }
/* 1133 */       textArea.setScrollLeft(d);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void updatePrefViewportWidth() {
/* 1138 */     int i = getSkinnable().getPrefColumnCount();
/* 1139 */     this.scrollPane.setPrefViewportWidth(i * this.characterWidth + this.contentView.snappedLeftInset() + this.contentView.snappedRightInset());
/* 1140 */     this.scrollPane.setMinViewportWidth(this.characterWidth + this.contentView.snappedLeftInset() + this.contentView.snappedRightInset());
/*      */   }
/*      */   
/*      */   private void updatePrefViewportHeight() {
/* 1144 */     int i = getSkinnable().getPrefRowCount();
/* 1145 */     this.scrollPane.setPrefViewportHeight(i * this.lineHeight + this.contentView.snappedTopInset() + this.contentView.snappedBottomInset());
/* 1146 */     this.scrollPane.setMinViewportHeight(this.lineHeight + this.contentView.snappedTopInset() + this.contentView.snappedBottomInset());
/*      */   }
/*      */   
/*      */   private void updateFontMetrics() {
/* 1150 */     Text text = (Text)this.paragraphNodes.getChildren().get(0);
/* 1151 */     this.lineHeight = Utils.getLineHeight(getSkinnable().getFont(), text.getBoundsType());
/* 1152 */     this.characterWidth = ((FontMetrics)this.fontMetrics.get()).getCharWidth('W');
/*      */   }
/*      */   
/*      */   private double getTextTranslateX() {
/* 1156 */     return this.contentView.snappedLeftInset();
/*      */   }
/*      */   
/*      */   private double getTextTranslateY() {
/* 1160 */     return this.contentView.snappedTopInset();
/*      */   }
/*      */   
/*      */   private double getTextLeft() {
/* 1164 */     return 0.0D;
/*      */   }
/*      */   
/*      */   private Point2D translateCaretPosition(Point2D paramPoint2D) {
/* 1168 */     return paramPoint2D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Text getTextNode() {
/* 1175 */     return (Text)this.paragraphNodes.getChildren().get(0);
/*      */   }
/*      */   
/*      */   private void updateTextNodeCaretPos(int paramInt) {
/* 1179 */     Text text = getTextNode();
/* 1180 */     if (isForwardBias()) {
/* 1181 */       text.setCaretPosition(paramInt);
/*      */     } else {
/* 1183 */       text.setCaretPosition(paramInt - 1);
/*      */     } 
/* 1185 */     text.caretBiasProperty().set(isForwardBias());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class ContentView
/*      */     extends Region
/*      */   {
/*      */     private ContentView() {
/* 1198 */       getStyleClass().add("content");
/*      */       
/* 1200 */       addEventHandler(MouseEvent.MOUSE_PRESSED, param1MouseEvent -> {
/*      */             TextAreaSkin.this.behavior.mousePressed(param1MouseEvent);
/*      */             
/*      */             param1MouseEvent.consume();
/*      */           });
/* 1205 */       addEventHandler(MouseEvent.MOUSE_RELEASED, param1MouseEvent -> {
/*      */             TextAreaSkin.this.behavior.mouseReleased(param1MouseEvent);
/*      */             
/*      */             param1MouseEvent.consume();
/*      */           });
/* 1210 */       addEventHandler(MouseEvent.MOUSE_DRAGGED, param1MouseEvent -> {
/*      */             TextAreaSkin.this.behavior.mouseDragged(param1MouseEvent);
/*      */             param1MouseEvent.consume();
/*      */           });
/*      */     }
/*      */     
/*      */     protected ObservableList<Node> getChildren() {
/* 1217 */       return super.getChildren();
/*      */     }
/*      */     
/*      */     public Orientation getContentBias() {
/* 1221 */       return Orientation.HORIZONTAL;
/*      */     }
/*      */     
/*      */     protected double computePrefWidth(double param1Double) {
/* 1225 */       if (TextAreaSkin.this.computedPrefWidth < 0.0D) {
/* 1226 */         double d = 0.0D;
/*      */         
/* 1228 */         for (Node node : TextAreaSkin.this.paragraphNodes.getChildren()) {
/* 1229 */           Text text = (Text)node;
/* 1230 */           d = Math.max(d, 
/* 1231 */               Utils.computeTextWidth(text.getFont(), text
/* 1232 */                 .getText(), 0.0D));
/*      */         } 
/*      */         
/* 1235 */         d += snappedLeftInset() + snappedRightInset();
/*      */         
/* 1237 */         Bounds bounds = TextAreaSkin.this.scrollPane.getViewportBounds();
/* 1238 */         TextAreaSkin.this.computedPrefWidth = Math.max(d, (bounds != null) ? bounds.getWidth() : 0.0D);
/*      */       } 
/* 1240 */       return TextAreaSkin.this.computedPrefWidth;
/*      */     }
/*      */     
/*      */     protected double computePrefHeight(double param1Double) {
/* 1244 */       if (param1Double != TextAreaSkin.this.widthForComputedPrefHeight) {
/* 1245 */         TextAreaSkin.this.invalidateMetrics();
/* 1246 */         TextAreaSkin.this.widthForComputedPrefHeight = param1Double;
/*      */       } 
/*      */       
/* 1249 */       if (TextAreaSkin.this.computedPrefHeight < 0.0D) {
/*      */         double d1;
/* 1251 */         if (param1Double == -1.0D) {
/* 1252 */           d1 = 0.0D;
/*      */         } else {
/* 1254 */           d1 = Math.max(param1Double - snappedLeftInset() + snappedRightInset(), 0.0D);
/*      */         } 
/*      */         
/* 1257 */         double d2 = 0.0D;
/*      */         
/* 1259 */         for (Node node : TextAreaSkin.this.paragraphNodes.getChildren()) {
/* 1260 */           Text text = (Text)node;
/* 1261 */           d2 += Utils.computeTextHeight(text
/* 1262 */               .getFont(), text
/* 1263 */               .getText(), d1, text
/*      */               
/* 1265 */               .getBoundsType());
/*      */         } 
/*      */         
/* 1268 */         d2 += snappedTopInset() + snappedBottomInset();
/*      */         
/* 1270 */         Bounds bounds = TextAreaSkin.this.scrollPane.getViewportBounds();
/* 1271 */         TextAreaSkin.this.computedPrefHeight = Math.max(d2, (bounds != null) ? bounds.getHeight() : 0.0D);
/*      */       } 
/* 1273 */       return TextAreaSkin.this.computedPrefHeight;
/*      */     }
/*      */     
/*      */     protected double computeMinWidth(double param1Double) {
/* 1277 */       if (TextAreaSkin.this.computedMinWidth < 0.0D) {
/* 1278 */         double d = snappedLeftInset() + snappedRightInset();
/* 1279 */         TextAreaSkin.this.computedMinWidth = Math.min(TextAreaSkin.this.characterWidth + d, computePrefWidth(param1Double));
/*      */       } 
/* 1281 */       return TextAreaSkin.this.computedMinWidth;
/*      */     }
/*      */     
/*      */     protected double computeMinHeight(double param1Double) {
/* 1285 */       if (TextAreaSkin.this.computedMinHeight < 0.0D) {
/* 1286 */         double d = snappedTopInset() + snappedBottomInset();
/* 1287 */         TextAreaSkin.this.computedMinHeight = Math.min(TextAreaSkin.this.lineHeight + d, computePrefHeight(param1Double));
/*      */       } 
/* 1289 */       return TextAreaSkin.this.computedMinHeight;
/*      */     }
/*      */     
/*      */     public void layoutChildren() {
/* 1293 */       TextArea textArea = TextAreaSkin.this.getSkinnable();
/* 1294 */       double d1 = getWidth();
/*      */ 
/*      */       
/* 1297 */       double d2 = snappedTopInset();
/* 1298 */       double d3 = snappedLeftInset();
/*      */       
/* 1300 */       double d4 = Math.max(d1 - d3 + snappedRightInset(), 0.0D);
/*      */       
/* 1302 */       double d5 = d2;
/*      */       
/* 1304 */       ObservableList<Node> observableList = TextAreaSkin.this.paragraphNodes.getChildren();
/*      */       
/* 1306 */       for (byte b1 = 0; b1 < observableList.size(); b1++) {
/* 1307 */         Node node = observableList.get(b1);
/* 1308 */         Text text1 = (Text)node;
/* 1309 */         text1.setWrappingWidth(d4);
/*      */         
/* 1311 */         Bounds bounds = text1.getBoundsInLocal();
/* 1312 */         text1.setLayoutX(d3);
/* 1313 */         text1.setLayoutY(d5);
/*      */         
/* 1315 */         d5 += bounds.getHeight();
/*      */       } 
/*      */       
/* 1318 */       if (TextAreaSkin.this.promptNode != null) {
/* 1319 */         TextAreaSkin.this.promptNode.setLayoutX(d3);
/* 1320 */         TextAreaSkin.this.promptNode.setLayoutY(d2 + TextAreaSkin.this.promptNode.getBaselineOffset());
/* 1321 */         TextAreaSkin.this.promptNode.setWrappingWidth(d4);
/*      */       } 
/*      */ 
/*      */       
/* 1325 */       IndexRange indexRange = textArea.getSelection();
/* 1326 */       Bounds bounds1 = TextAreaSkin.this.caretPath.getBoundsInParent();
/*      */       
/* 1328 */       TextAreaSkin.this.selectionHighlightGroup.getChildren().clear();
/*      */       
/* 1330 */       int i = textArea.getCaretPosition();
/* 1331 */       int j = textArea.getAnchor();
/*      */       
/* 1333 */       if (TextInputControlSkin.SHOW_HANDLES) {
/*      */         
/* 1335 */         if (indexRange.getLength() > 0) {
/* 1336 */           TextAreaSkin.this.selectionHandle1.resize(TextAreaSkin.this.selectionHandle1.prefWidth(-1.0D), TextAreaSkin.this.selectionHandle1
/* 1337 */               .prefHeight(-1.0D));
/* 1338 */           TextAreaSkin.this.selectionHandle2.resize(TextAreaSkin.this.selectionHandle2.prefWidth(-1.0D), TextAreaSkin.this.selectionHandle2
/* 1339 */               .prefHeight(-1.0D));
/*      */         } else {
/* 1341 */           TextAreaSkin.this.caretHandle.resize(TextAreaSkin.this.caretHandle.prefWidth(-1.0D), TextAreaSkin.this.caretHandle
/* 1342 */               .prefHeight(-1.0D));
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1347 */         if (indexRange.getLength() > 0) {
/* 1348 */           int i1 = observableList.size();
/* 1349 */           int i2 = textArea.getLength() + 1;
/* 1350 */           Text text1 = null;
/*      */           do {
/* 1352 */             text1 = (Text)observableList.get(--i1);
/* 1353 */             i2 -= text1.getText().length() + 1;
/* 1354 */           } while (j < i2);
/*      */           
/* 1356 */           TextAreaSkin.this.updateTextNodeCaretPos(j - i2);
/* 1357 */           TextAreaSkin.this.caretPath.getElements().clear();
/* 1358 */           TextAreaSkin.this.caretPath.getElements().addAll(text1.getCaretShape());
/* 1359 */           TextAreaSkin.this.caretPath.setLayoutX(text1.getLayoutX());
/* 1360 */           TextAreaSkin.this.caretPath.setLayoutY(text1.getLayoutY());
/*      */           
/* 1362 */           Bounds bounds = TextAreaSkin.this.caretPath.getBoundsInParent();
/* 1363 */           if (i < j) {
/* 1364 */             TextAreaSkin.this.selectionHandle2.setLayoutX(bounds.getMinX() - TextAreaSkin.this.selectionHandle2.getWidth() / 2.0D);
/* 1365 */             TextAreaSkin.this.selectionHandle2.setLayoutY(bounds.getMaxY() - 1.0D);
/*      */           } else {
/* 1367 */             TextAreaSkin.this.selectionHandle1.setLayoutX(bounds.getMinX() - TextAreaSkin.this.selectionHandle1.getWidth() / 2.0D);
/* 1368 */             TextAreaSkin.this.selectionHandle1.setLayoutY(bounds.getMinY() - TextAreaSkin.this.selectionHandle1.getHeight() + 1.0D);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1375 */       int k = observableList.size();
/* 1376 */       int m = textArea.getLength() + 1;
/*      */       
/* 1378 */       Text text = null;
/*      */       do {
/* 1380 */         text = (Text)observableList.get(--k);
/* 1381 */         m -= text.getText().length() + 1;
/* 1382 */       } while (i < m);
/*      */       
/* 1384 */       TextAreaSkin.this.updateTextNodeCaretPos(i - m);
/*      */       
/* 1386 */       TextAreaSkin.this.caretPath.getElements().clear();
/* 1387 */       TextAreaSkin.this.caretPath.getElements().addAll(text.getCaretShape());
/*      */       
/* 1389 */       TextAreaSkin.this.caretPath.setLayoutX(text.getLayoutX());
/*      */ 
/*      */       
/* 1392 */       text.setLayoutX(2.0D * text.getLayoutX() - text.getBoundsInParent().getMinX());
/*      */       
/* 1394 */       TextAreaSkin.this.caretPath.setLayoutY(text.getLayoutY());
/* 1395 */       if (bounds1 == null || !bounds1.equals(TextAreaSkin.this.caretPath.getBoundsInParent())) {
/* 1396 */         TextAreaSkin.this.scrollCaretToVisible();
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1401 */       k = indexRange.getStart();
/* 1402 */       m = indexRange.getEnd(); byte b2; int n;
/* 1403 */       for (b2 = 0, n = observableList.size(); b2 < n; b2++) {
/* 1404 */         Node node = observableList.get(b2);
/* 1405 */         Text text1 = (Text)node;
/* 1406 */         int i1 = text1.getText().length() + 1;
/* 1407 */         if (m > k && k < i1) {
/* 1408 */           text1.setSelectionStart(k);
/* 1409 */           text1.setSelectionEnd(Math.min(m, i1));
/*      */           
/* 1411 */           Path path = new Path();
/* 1412 */           path.setManaged(false);
/* 1413 */           path.setStroke((Paint)null);
/* 1414 */           PathElement[] arrayOfPathElement = text1.getSelectionShape();
/* 1415 */           if (arrayOfPathElement != null) {
/* 1416 */             path.getElements().addAll(arrayOfPathElement);
/*      */           }
/* 1418 */           TextAreaSkin.this.selectionHighlightGroup.getChildren().add(path);
/* 1419 */           TextAreaSkin.this.selectionHighlightGroup.setVisible(true);
/* 1420 */           path.setLayoutX(text1.getLayoutX());
/* 1421 */           path.setLayoutY(text1.getLayoutY());
/* 1422 */           TextAreaSkin.this.updateHighlightFill();
/*      */         } else {
/* 1424 */           text1.setSelectionStart(-1);
/* 1425 */           text1.setSelectionEnd(-1);
/* 1426 */           TextAreaSkin.this.selectionHighlightGroup.setVisible(false);
/*      */         } 
/* 1428 */         k = Math.max(0, k - i1);
/* 1429 */         m = Math.max(0, m - i1);
/*      */       } 
/*      */       
/* 1432 */       if (TextInputControlSkin.SHOW_HANDLES) {
/*      */ 
/*      */         
/* 1435 */         Bounds bounds = TextAreaSkin.this.caretPath.getBoundsInParent();
/* 1436 */         if (indexRange.getLength() > 0) {
/* 1437 */           if (i < j) {
/* 1438 */             TextAreaSkin.this.selectionHandle1.setLayoutX(bounds.getMinX() - TextAreaSkin.this.selectionHandle1.getWidth() / 2.0D);
/* 1439 */             TextAreaSkin.this.selectionHandle1.setLayoutY(bounds.getMinY() - TextAreaSkin.this.selectionHandle1.getHeight() + 1.0D);
/*      */           } else {
/* 1441 */             TextAreaSkin.this.selectionHandle2.setLayoutX(bounds.getMinX() - TextAreaSkin.this.selectionHandle2.getWidth() / 2.0D);
/* 1442 */             TextAreaSkin.this.selectionHandle2.setLayoutY(bounds.getMaxY() - 1.0D);
/*      */           } 
/*      */         } else {
/* 1445 */           TextAreaSkin.this.caretHandle.setLayoutX(bounds.getMinX() - TextAreaSkin.this.caretHandle.getWidth() / 2.0D + 1.0D);
/* 1446 */           TextAreaSkin.this.caretHandle.setLayoutY(bounds.getMaxY());
/*      */         } 
/*      */       } 
/*      */       
/* 1450 */       if (TextAreaSkin.this.scrollPane.getPrefViewportWidth() == 0.0D || TextAreaSkin.this
/* 1451 */         .scrollPane.getPrefViewportHeight() == 0.0D) {
/* 1452 */         TextAreaSkin.this.updatePrefViewportWidth();
/* 1453 */         TextAreaSkin.this.updatePrefViewportHeight();
/* 1454 */         if ((getParent() != null && TextAreaSkin.this.scrollPane.getPrefViewportWidth() > 0.0D) || TextAreaSkin.this
/* 1455 */           .scrollPane.getPrefViewportHeight() > 0.0D)
/*      */         {
/* 1457 */           getParent().requestLayout();
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1463 */       Bounds bounds2 = TextAreaSkin.this.scrollPane.getViewportBounds();
/* 1464 */       boolean bool1 = TextAreaSkin.this.scrollPane.isFitToWidth();
/* 1465 */       boolean bool2 = TextAreaSkin.this.scrollPane.isFitToHeight();
/* 1466 */       boolean bool3 = (textArea.isWrapText() || computePrefWidth(-1.0D) <= bounds2.getWidth());
/* 1467 */       boolean bool4 = (computePrefHeight(d1) <= bounds2.getHeight());
/* 1468 */       if (bool1 != bool3 || bool2 != bool4) {
/* 1469 */         Platform.runLater(() -> {
/*      */               TextAreaSkin.this.scrollPane.setFitToWidth(param1Boolean1);
/*      */               TextAreaSkin.this.scrollPane.setFitToHeight(param1Boolean2);
/*      */             });
/* 1473 */         getParent().requestLayout();
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TextAreaSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */