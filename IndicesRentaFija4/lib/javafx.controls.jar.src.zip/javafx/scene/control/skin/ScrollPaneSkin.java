/*      */ package javafx.scene.control.skin;
/*      */ 
/*      */ import com.sun.javafx.scene.ParentHelper;
/*      */ import com.sun.javafx.scene.control.Properties;
/*      */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*      */ import com.sun.javafx.scene.control.behavior.ScrollPaneBehavior;
/*      */ import com.sun.javafx.scene.control.skin.Utils;
/*      */ import com.sun.javafx.scene.traversal.ParentTraversalEngine;
/*      */ import com.sun.javafx.util.Utils;
/*      */ import java.util.function.Consumer;
/*      */ import javafx.animation.Animation;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.KeyValue;
/*      */ import javafx.animation.Timeline;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.DoublePropertyBase;
/*      */ import javafx.beans.value.ChangeListener;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventDispatchChain;
/*      */ import javafx.event.EventDispatcher;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.geometry.BoundingBox;
/*      */ import javafx.geometry.Bounds;
/*      */ import javafx.geometry.Insets;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.Cursor;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.ScrollBar;
/*      */ import javafx.scene.control.ScrollPane;
/*      */ import javafx.scene.control.SkinBase;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.input.ScrollEvent;
/*      */ import javafx.scene.input.TouchEvent;
/*      */ import javafx.scene.layout.StackPane;
/*      */ import javafx.scene.shape.Rectangle;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ScrollPaneSkin
/*      */   extends SkinBase<ScrollPane>
/*      */ {
/*      */   private static final double DEFAULT_PREF_SIZE = 100.0D;
/*      */   private static final double DEFAULT_MIN_SIZE = 36.0D;
/*      */   private static final double DEFAULT_SB_BREADTH = 12.0D;
/*      */   private static final double DEFAULT_EMBEDDED_SB_BREADTH = 8.0D;
/*      */   private static final double PAN_THRESHOLD = 0.5D;
/*      */   private Node scrollNode;
/*      */   private final BehaviorBase<ScrollPane> behavior;
/*      */   private double nodeWidth;
/*      */   private double nodeHeight;
/*      */   private boolean nodeSizeInvalid = true;
/*      */   private double posX;
/*      */   private double posY;
/*      */   private boolean hsbvis;
/*      */   private boolean vsbvis;
/*      */   private double hsbHeight;
/*      */   private double vsbWidth;
/*      */   private StackPane viewRect;
/*      */   private StackPane viewContent;
/*      */   private double contentWidth;
/*      */   private double contentHeight;
/*      */   private StackPane corner;
/*      */   ScrollBar hsb;
/*      */   ScrollBar vsb;
/*      */   double pressX;
/*      */   double pressY;
/*      */   double ohvalue;
/*      */   double ovvalue;
/*  132 */   private Cursor saveCursor = null;
/*      */   
/*      */   private boolean dragDetected = false;
/*      */   
/*      */   private boolean touchDetected = false;
/*      */   
/*      */   private boolean mouseDown = false;
/*      */   
/*      */   Rectangle clipRect;
/*      */   
/*      */   Timeline sbTouchTimeline;
/*      */   
/*      */   KeyFrame sbTouchKF1;
/*      */   
/*      */   KeyFrame sbTouchKF2;
/*      */   
/*      */   Timeline contentsToViewTimeline;
/*      */   
/*      */   KeyFrame contentsToViewKF1;
/*      */   
/*      */   KeyFrame contentsToViewKF2;
/*      */   
/*      */   KeyFrame contentsToViewKF3;
/*      */   private boolean tempVisibility;
/*      */   
/*  157 */   private final InvalidationListener nodeListener = new InvalidationListener() {
/*      */       public void invalidated(Observable param1Observable) {
/*  159 */         if (!ScrollPaneSkin.this.nodeSizeInvalid) {
/*  160 */           Bounds bounds = ScrollPaneSkin.this.scrollNode.getLayoutBounds();
/*  161 */           double d1 = bounds.getWidth();
/*  162 */           double d2 = bounds.getHeight();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  168 */           if (ScrollPaneSkin.this.vsbvis != ScrollPaneSkin.this.determineVerticalSBVisible() || ScrollPaneSkin.this.hsbvis != ScrollPaneSkin.this.determineHorizontalSBVisible() || (d1 != 0.0D && ScrollPaneSkin.this
/*  169 */             .nodeWidth != d1) || (d2 != 0.0D && ScrollPaneSkin.this
/*  170 */             .nodeHeight != d2)) {
/*  171 */             ScrollPaneSkin.this.getSkinnable().requestLayout();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  178 */           else if (!ScrollPaneSkin.this.dragDetected) {
/*  179 */             ScrollPaneSkin.this.updateVerticalSB();
/*  180 */             ScrollPaneSkin.this.updateHorizontalSB();
/*      */           } 
/*      */         } 
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  191 */   private final ChangeListener<Bounds> boundsChangeListener = new ChangeListener<Bounds>()
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public void changed(ObservableValue<? extends Bounds> param1ObservableValue, Bounds param1Bounds1, Bounds param1Bounds2)
/*      */       {
/*  200 */         double d1 = param1Bounds1.getHeight();
/*  201 */         double d2 = param1Bounds2.getHeight();
/*  202 */         if (d1 > 0.0D && d1 != d2) {
/*  203 */           double d5 = ScrollPaneSkin.this.snapPositionY(ScrollPaneSkin.this.snappedTopInset() - ScrollPaneSkin.this.posY / (ScrollPaneSkin.this.vsb.getMax() - ScrollPaneSkin.this.vsb.getMin()) * (d1 - ScrollPaneSkin.this.contentHeight));
/*  204 */           double d6 = ScrollPaneSkin.this.snapPositionY(ScrollPaneSkin.this.snappedTopInset() - ScrollPaneSkin.this.posY / (ScrollPaneSkin.this.vsb.getMax() - ScrollPaneSkin.this.vsb.getMin()) * (d2 - ScrollPaneSkin.this.contentHeight));
/*      */           
/*  206 */           double d7 = d5 / d6 * ScrollPaneSkin.this.vsb.getValue();
/*  207 */           if (d7 < 0.0D) {
/*  208 */             ScrollPaneSkin.this.vsb.setValue(0.0D);
/*      */           }
/*  210 */           else if (d7 < 1.0D) {
/*  211 */             ScrollPaneSkin.this.vsb.setValue(d7);
/*      */           }
/*  213 */           else if (d7 > 1.0D) {
/*  214 */             ScrollPaneSkin.this.vsb.setValue(1.0D);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  224 */         double d3 = param1Bounds1.getWidth();
/*  225 */         double d4 = param1Bounds2.getWidth();
/*  226 */         if (d3 > 0.0D && d3 != d4) {
/*  227 */           double d5 = ScrollPaneSkin.this.snapPositionX(ScrollPaneSkin.this.snappedLeftInset() - ScrollPaneSkin.this.posX / (ScrollPaneSkin.this.hsb.getMax() - ScrollPaneSkin.this.hsb.getMin()) * (d3 - ScrollPaneSkin.this.contentWidth));
/*  228 */           double d6 = ScrollPaneSkin.this.snapPositionX(ScrollPaneSkin.this.snappedLeftInset() - ScrollPaneSkin.this.posX / (ScrollPaneSkin.this.hsb.getMax() - ScrollPaneSkin.this.hsb.getMin()) * (d4 - ScrollPaneSkin.this.contentWidth));
/*      */           
/*  230 */           double d7 = d5 / d6 * ScrollPaneSkin.this.hsb.getValue();
/*  231 */           if (d7 < 0.0D) {
/*  232 */             ScrollPaneSkin.this.hsb.setValue(0.0D);
/*      */           }
/*  234 */           else if (d7 < 1.0D) {
/*  235 */             ScrollPaneSkin.this.hsb.setValue(d7);
/*      */           }
/*  237 */           else if (d7 > 1.0D) {
/*  238 */             ScrollPaneSkin.this.hsb.setValue(1.0D);
/*      */           } 
/*      */         } 
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DoubleProperty contentPosX;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DoubleProperty contentPosY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ScrollPaneSkin(ScrollPane paramScrollPane) {
/*  260 */     super(paramScrollPane);
/*      */ 
/*      */     
/*  263 */     this.behavior = new ScrollPaneBehavior(paramScrollPane);
/*      */ 
/*      */     
/*  266 */     initialize();
/*      */ 
/*      */     
/*  269 */     Consumer consumer = paramObservableValue -> getSkinnable().requestLayout();
/*      */ 
/*      */ 
/*      */     
/*  273 */     registerChangeListener(paramScrollPane.contentProperty(), paramObservableValue -> {
/*      */           if (this.scrollNode != getSkinnable().getContent()) {
/*      */             if (this.scrollNode != null) {
/*      */               this.scrollNode.layoutBoundsProperty().removeListener(this.nodeListener);
/*      */               this.scrollNode.layoutBoundsProperty().removeListener(this.boundsChangeListener);
/*      */               this.viewContent.getChildren().remove(this.scrollNode);
/*      */             } 
/*      */             this.scrollNode = getSkinnable().getContent();
/*      */             if (this.scrollNode != null) {
/*      */               this.nodeWidth = snapSizeX(this.scrollNode.getLayoutBounds().getWidth());
/*      */               this.nodeHeight = snapSizeY(this.scrollNode.getLayoutBounds().getHeight());
/*      */               this.viewContent.getChildren().setAll(new Node[] { this.scrollNode });
/*      */               this.scrollNode.layoutBoundsProperty().addListener(this.nodeListener);
/*      */               this.scrollNode.layoutBoundsProperty().addListener(this.boundsChangeListener);
/*      */             } 
/*      */           } 
/*      */           getSkinnable().requestLayout();
/*      */         });
/*  291 */     registerChangeListener(paramScrollPane.fitToWidthProperty(), paramObservableValue -> {
/*      */           getSkinnable().requestLayout();
/*      */           this.viewRect.requestLayout();
/*      */         });
/*  295 */     registerChangeListener(paramScrollPane.fitToHeightProperty(), paramObservableValue -> {
/*      */           getSkinnable().requestLayout();
/*      */           this.viewRect.requestLayout();
/*      */         });
/*  299 */     registerChangeListener(paramScrollPane.hbarPolicyProperty(), paramObservableValue -> getSkinnable().requestLayout());
/*      */ 
/*      */ 
/*      */     
/*  303 */     registerChangeListener(paramScrollPane.vbarPolicyProperty(), paramObservableValue -> getSkinnable().requestLayout());
/*      */ 
/*      */ 
/*      */     
/*  307 */     registerChangeListener(paramScrollPane.hvalueProperty(), paramObservableValue -> this.hsb.setValue(getSkinnable().getHvalue()));
/*  308 */     registerChangeListener(paramScrollPane.hmaxProperty(), paramObservableValue -> this.hsb.setMax(getSkinnable().getHmax()));
/*  309 */     registerChangeListener(paramScrollPane.hminProperty(), paramObservableValue -> this.hsb.setMin(getSkinnable().getHmin()));
/*  310 */     registerChangeListener(paramScrollPane.vvalueProperty(), paramObservableValue -> this.vsb.setValue(getSkinnable().getVvalue()));
/*  311 */     registerChangeListener(paramScrollPane.vmaxProperty(), paramObservableValue -> this.vsb.setMax(getSkinnable().getVmax()));
/*  312 */     registerChangeListener(paramScrollPane.vminProperty(), paramObservableValue -> this.vsb.setMin(getSkinnable().getVmin()));
/*  313 */     registerChangeListener(paramScrollPane.prefViewportWidthProperty(), consumer);
/*  314 */     registerChangeListener(paramScrollPane.prefViewportHeightProperty(), consumer);
/*  315 */     registerChangeListener(paramScrollPane.minViewportWidthProperty(), consumer);
/*  316 */     registerChangeListener(paramScrollPane.minViewportHeightProperty(), consumer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void setContentPosX(double paramDouble) {
/*  328 */     contentPosXProperty().set(paramDouble); } private final double getContentPosX() {
/*  329 */     return (this.contentPosX == null) ? 0.0D : this.contentPosX.get();
/*      */   } private final DoubleProperty contentPosXProperty() {
/*  331 */     if (this.contentPosX == null) {
/*  332 */       this.contentPosX = new DoublePropertyBase() {
/*      */           protected void invalidated() {
/*  334 */             ScrollPaneSkin.this.hsb.setValue(ScrollPaneSkin.this.getContentPosX());
/*  335 */             ScrollPaneSkin.this.getSkinnable().requestLayout();
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  340 */             return ScrollPaneSkin.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  345 */             return "contentPosX";
/*      */           }
/*      */         };
/*      */     }
/*  349 */     return this.contentPosX;
/*      */   }
/*      */   
/*      */   private final void setContentPosY(double paramDouble) {
/*  353 */     contentPosYProperty().set(paramDouble); } private final double getContentPosY() {
/*  354 */     return (this.contentPosY == null) ? 0.0D : this.contentPosY.get();
/*      */   } private final DoubleProperty contentPosYProperty() {
/*  356 */     if (this.contentPosY == null) {
/*  357 */       this.contentPosY = new DoublePropertyBase() {
/*      */           protected void invalidated() {
/*  359 */             ScrollPaneSkin.this.vsb.setValue(ScrollPaneSkin.this.getContentPosY());
/*  360 */             ScrollPaneSkin.this.getSkinnable().requestLayout();
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  365 */             return ScrollPaneSkin.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  370 */             return "contentPosY";
/*      */           }
/*      */         };
/*      */     }
/*  374 */     return this.contentPosY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  387 */     super.dispose();
/*      */     
/*  389 */     if (this.behavior != null) {
/*  390 */       this.behavior.dispose();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ScrollBar getHorizontalScrollBar() {
/*  400 */     return this.hsb;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ScrollBar getVerticalScrollBar() {
/*  409 */     return this.vsb;
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  414 */     ScrollPane scrollPane = getSkinnable();
/*      */     
/*  416 */     double d1 = computeVsbSizeHint(scrollPane);
/*  417 */     double d2 = d1 + snappedLeftInset() + snappedRightInset();
/*      */     
/*  419 */     if (scrollPane.getPrefViewportWidth() > 0.0D) {
/*  420 */       return scrollPane.getPrefViewportWidth() + d2;
/*      */     }
/*  422 */     if (scrollPane.getContent() != null) {
/*  423 */       return scrollPane.getContent().prefWidth(paramDouble1) + d2;
/*      */     }
/*      */     
/*  426 */     return Math.max(d2, 100.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  432 */     ScrollPane scrollPane = getSkinnable();
/*      */     
/*  434 */     double d1 = computeHsbSizeHint(scrollPane);
/*  435 */     double d2 = d1 + snappedTopInset() + snappedBottomInset();
/*      */     
/*  437 */     if (scrollPane.getPrefViewportHeight() > 0.0D) {
/*  438 */       return scrollPane.getPrefViewportHeight() + d2;
/*      */     }
/*  440 */     if (scrollPane.getContent() != null) {
/*  441 */       return scrollPane.getContent().prefHeight(paramDouble1) + d2;
/*      */     }
/*      */     
/*  444 */     return Math.max(d2, 100.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  450 */     ScrollPane scrollPane = getSkinnable();
/*      */     
/*  452 */     double d1 = computeVsbSizeHint(scrollPane);
/*  453 */     double d2 = d1 + snappedLeftInset() + snappedRightInset();
/*      */     
/*  455 */     if (scrollPane.getMinViewportWidth() > 0.0D) {
/*  456 */       return scrollPane.getMinViewportWidth() + d2;
/*      */     }
/*  458 */     double d3 = this.corner.minWidth(-1.0D);
/*  459 */     return (d3 > 0.0D) ? (3.0D * d3) : 36.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  466 */     ScrollPane scrollPane = getSkinnable();
/*      */     
/*  468 */     double d1 = computeHsbSizeHint(scrollPane);
/*  469 */     double d2 = d1 + snappedTopInset() + snappedBottomInset();
/*      */     
/*  471 */     if (scrollPane.getMinViewportHeight() > 0.0D) {
/*  472 */       return scrollPane.getMinViewportHeight() + d2;
/*      */     }
/*  474 */     double d3 = this.corner.minHeight(-1.0D);
/*  475 */     return (d3 > 0.0D) ? (3.0D * d3) : 36.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  481 */     ScrollPane scrollPane = getSkinnable();
/*  482 */     Insets insets = scrollPane.getPadding();
/*  483 */     double d1 = snapSizeX(insets.getRight());
/*  484 */     double d2 = snapSizeX(insets.getLeft());
/*  485 */     double d3 = snapSizeY(insets.getTop());
/*  486 */     double d4 = snapSizeY(insets.getBottom());
/*      */     
/*  488 */     this.vsb.setMin(scrollPane.getVmin());
/*  489 */     this.vsb.setMax(scrollPane.getVmax());
/*      */ 
/*      */     
/*  492 */     this.hsb.setMin(scrollPane.getHmin());
/*  493 */     this.hsb.setMax(scrollPane.getHmax());
/*      */     
/*  495 */     this.contentWidth = paramDouble3;
/*  496 */     this.contentHeight = paramDouble4;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  501 */     double d5 = 0.0D;
/*  502 */     double d6 = 0.0D;
/*      */     
/*  504 */     computeScrollNodeSize(this.contentWidth, this.contentHeight);
/*  505 */     computeScrollBarSize();
/*      */     
/*  507 */     for (byte b = 0; b < 2; b++) {
/*  508 */       this.vsbvis = determineVerticalSBVisible();
/*  509 */       this.hsbvis = determineHorizontalSBVisible();
/*      */       
/*  511 */       if (this.vsbvis && !Properties.IS_TOUCH_SUPPORTED) {
/*  512 */         this.contentWidth = paramDouble3 - this.vsbWidth;
/*      */       }
/*  514 */       d5 = paramDouble3 + d2 + d1 - (this.vsbvis ? this.vsbWidth : 0.0D);
/*  515 */       if (this.hsbvis && !Properties.IS_TOUCH_SUPPORTED) {
/*  516 */         this.contentHeight = paramDouble4 - this.hsbHeight;
/*      */       }
/*  518 */       d6 = paramDouble4 + d3 + d4 - (this.hsbvis ? this.hsbHeight : 0.0D);
/*      */     } 
/*      */ 
/*      */     
/*  522 */     if (this.scrollNode != null && this.scrollNode.isResizable())
/*      */     {
/*  524 */       if (this.vsbvis && this.hsbvis) {
/*      */         
/*  526 */         computeScrollNodeSize(this.contentWidth, this.contentHeight);
/*      */       }
/*  528 */       else if (this.hsbvis && !this.vsbvis) {
/*  529 */         computeScrollNodeSize(this.contentWidth, this.contentHeight);
/*  530 */         this.vsbvis = determineVerticalSBVisible();
/*  531 */         if (this.vsbvis) {
/*      */           
/*  533 */           this.contentWidth -= this.vsbWidth;
/*  534 */           d5 -= this.vsbWidth;
/*  535 */           computeScrollNodeSize(this.contentWidth, this.contentHeight);
/*      */         } 
/*  537 */       } else if (this.vsbvis && !this.hsbvis) {
/*  538 */         computeScrollNodeSize(this.contentWidth, this.contentHeight);
/*  539 */         this.hsbvis = determineHorizontalSBVisible();
/*  540 */         if (this.hsbvis) {
/*      */           
/*  542 */           this.contentHeight -= this.hsbHeight;
/*  543 */           d6 -= this.hsbHeight;
/*  544 */           computeScrollNodeSize(this.contentWidth, this.contentHeight);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  550 */     double d7 = snappedLeftInset() - d2;
/*  551 */     double d8 = snappedTopInset() - d3;
/*      */     
/*  553 */     this.vsb.setVisible(this.vsbvis);
/*  554 */     if (this.vsbvis)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  567 */       this.vsb.resizeRelocate(snappedLeftInset() + paramDouble3 - this.vsbWidth + ((d1 < 1.0D) ? 0.0D : (d1 - 1.0D)), d8, this.vsbWidth, d6);
/*      */     }
/*      */     
/*  570 */     updateVerticalSB();
/*      */     
/*  572 */     this.hsb.setVisible(this.hsbvis);
/*  573 */     if (this.hsbvis)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  586 */       this.hsb.resizeRelocate(d7, snappedTopInset() + paramDouble4 - this.hsbHeight + ((d4 < 1.0D) ? 0.0D : (d4 - 1.0D)), d5, this.hsbHeight);
/*      */     }
/*      */     
/*  589 */     updateHorizontalSB();
/*      */     
/*  591 */     this.viewRect.resizeRelocate(snappedLeftInset(), snappedTopInset(), snapSizeX(this.contentWidth), snapSizeY(this.contentHeight));
/*  592 */     resetClip();
/*      */     
/*  594 */     if (this.vsbvis && this.hsbvis) {
/*  595 */       this.corner.setVisible(true);
/*  596 */       double d9 = this.vsbWidth;
/*  597 */       double d10 = this.hsbHeight;
/*  598 */       this.corner.resizeRelocate(snapPositionX(this.vsb.getLayoutX()), snapPositionY(this.hsb.getLayoutY()), snapSizeX(d9), snapSizeY(d10));
/*      */     } else {
/*  600 */       this.corner.setVisible(false);
/*      */     } 
/*  602 */     scrollPane.setViewportBounds(new BoundingBox(snapPositionX(this.viewContent.getLayoutX()), snapPositionY(this.viewContent.getLayoutY()), snapSizeX(this.contentWidth), snapSizeY(this.contentHeight)));
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*  607 */     switch (paramAccessibleAttribute) { case VERTICAL_SCROLLBAR:
/*  608 */         return this.vsb;
/*  609 */       case HORIZONTAL_SCROLLBAR: return this.hsb; }
/*  610 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initialize() {
/*  626 */     ScrollPane scrollPane = getSkinnable();
/*  627 */     this.scrollNode = scrollPane.getContent();
/*      */     
/*  629 */     ParentTraversalEngine parentTraversalEngine = new ParentTraversalEngine(getSkinnable());
/*  630 */     parentTraversalEngine.addTraverseListener((paramNode, paramBounds) -> scrollBoundsIntoView(paramBounds));
/*      */ 
/*      */ 
/*      */     
/*  634 */     ParentHelper.setTraversalEngine(getSkinnable(), parentTraversalEngine);
/*      */     
/*  636 */     if (this.scrollNode != null) {
/*  637 */       this.scrollNode.layoutBoundsProperty().addListener(this.nodeListener);
/*  638 */       this.scrollNode.layoutBoundsProperty().addListener(this.boundsChangeListener);
/*      */     } 
/*      */     
/*  641 */     this.viewRect = new StackPane() {
/*      */         protected void layoutChildren() {
/*  643 */           ScrollPaneSkin.this.viewContent.resize(getWidth(), getHeight());
/*      */         }
/*      */       };
/*      */     
/*  647 */     this.viewRect.setManaged(false);
/*  648 */     this.viewRect.setCache(true);
/*  649 */     this.viewRect.getStyleClass().add("viewport");
/*      */     
/*  651 */     this.clipRect = new Rectangle();
/*  652 */     this.viewRect.setClip(this.clipRect);
/*      */     
/*  654 */     this.hsb = new ScrollBar();
/*      */     
/*  656 */     this.vsb = new ScrollBar();
/*  657 */     this.vsb.setOrientation(Orientation.VERTICAL);
/*      */     
/*  659 */     EventHandler<? super MouseEvent> eventHandler = paramMouseEvent -> {
/*      */         if (getSkinnable().isFocusTraversable()) {
/*      */           getSkinnable().requestFocus();
/*      */         }
/*      */       };
/*      */     
/*  665 */     this.hsb.addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
/*  666 */     this.vsb.addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
/*      */     
/*  668 */     this.corner = new StackPane();
/*  669 */     this.corner.getStyleClass().setAll(new String[] { "corner" });
/*      */     
/*  671 */     this.viewContent = new StackPane()
/*      */       {
/*      */         public void requestLayout() {
/*  674 */           ScrollPaneSkin.this.nodeSizeInvalid = true;
/*      */           
/*  676 */           super.requestLayout();
/*      */ 
/*      */ 
/*      */           
/*  680 */           ScrollPaneSkin.this.getSkinnable().requestLayout();
/*      */         }
/*      */         protected void layoutChildren() {
/*  683 */           if (ScrollPaneSkin.this.nodeSizeInvalid) {
/*  684 */             ScrollPaneSkin.this.computeScrollNodeSize(getWidth(), getHeight());
/*      */           }
/*  686 */           if (ScrollPaneSkin.this.scrollNode != null && ScrollPaneSkin.this.scrollNode.isResizable()) {
/*  687 */             ScrollPaneSkin.this.scrollNode.resize(snapSize(ScrollPaneSkin.this.nodeWidth), snapSize(ScrollPaneSkin.this.nodeHeight));
/*  688 */             if (ScrollPaneSkin.this.vsbvis != ScrollPaneSkin.this.determineVerticalSBVisible() || ScrollPaneSkin.this.hsbvis != ScrollPaneSkin.this.determineHorizontalSBVisible()) {
/*  689 */               ScrollPaneSkin.this.getSkinnable().requestLayout();
/*      */             }
/*      */           } 
/*  692 */           if (ScrollPaneSkin.this.scrollNode != null) {
/*  693 */             ScrollPaneSkin.this.scrollNode.relocate(0.0D, 0.0D);
/*      */           }
/*      */         }
/*      */       };
/*  697 */     this.viewRect.getChildren().add(this.viewContent);
/*      */     
/*  699 */     if (this.scrollNode != null) {
/*  700 */       this.viewContent.getChildren().add(this.scrollNode);
/*  701 */       this.viewRect.nodeOrientationProperty().bind(this.scrollNode.nodeOrientationProperty());
/*      */     } 
/*      */     
/*  704 */     getChildren().clear();
/*  705 */     getChildren().addAll(new Node[] { this.viewRect, this.vsb, this.hsb, this.corner });
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  710 */     InvalidationListener invalidationListener1 = paramObservable -> {
/*      */         if (!Properties.IS_TOUCH_SUPPORTED) {
/*      */           this.posY = Utils.clamp(getSkinnable().getVmin(), this.vsb.getValue(), getSkinnable().getVmax());
/*      */         } else {
/*      */           this.posY = this.vsb.getValue();
/*      */         } 
/*      */         
/*      */         updatePosY();
/*      */       };
/*  719 */     this.vsb.valueProperty().addListener(invalidationListener1);
/*      */     
/*  721 */     InvalidationListener invalidationListener2 = paramObservable -> {
/*      */         if (!Properties.IS_TOUCH_SUPPORTED) {
/*      */           this.posX = Utils.clamp(getSkinnable().getHmin(), this.hsb.getValue(), getSkinnable().getHmax());
/*      */         } else {
/*      */           this.posX = this.hsb.getValue();
/*      */         } 
/*      */         
/*      */         updatePosX();
/*      */       };
/*  730 */     this.hsb.valueProperty().addListener(invalidationListener2);
/*      */     
/*  732 */     this.viewRect.setOnMousePressed(paramMouseEvent -> {
/*      */           this.mouseDown = true;
/*      */           
/*      */           if (Properties.IS_TOUCH_SUPPORTED) {
/*      */             startSBReleasedAnimation();
/*      */           }
/*      */           
/*      */           this.pressX = paramMouseEvent.getX();
/*      */           this.pressY = paramMouseEvent.getY();
/*      */           this.ohvalue = this.hsb.getValue();
/*      */           this.ovvalue = this.vsb.getValue();
/*      */         });
/*  744 */     this.viewRect.setOnDragDetected(paramMouseEvent -> {
/*      */           if (Properties.IS_TOUCH_SUPPORTED) {
/*      */             startSBReleasedAnimation();
/*      */           }
/*      */           
/*      */           if (getSkinnable().isPannable()) {
/*      */             this.dragDetected = true;
/*      */             if (this.saveCursor == null) {
/*      */               this.saveCursor = getSkinnable().getCursor();
/*      */               if (this.saveCursor == null) {
/*      */                 this.saveCursor = Cursor.DEFAULT;
/*      */               }
/*      */               getSkinnable().setCursor(Cursor.MOVE);
/*      */               getSkinnable().requestLayout();
/*      */             } 
/*      */           } 
/*      */         });
/*  761 */     this.viewRect.addEventFilter(MouseEvent.MOUSE_RELEASED, paramMouseEvent -> {
/*      */           this.mouseDown = false;
/*      */           
/*      */           if (this.dragDetected == true) {
/*      */             if (this.saveCursor != null) {
/*      */               getSkinnable().setCursor(this.saveCursor);
/*      */               
/*      */               this.saveCursor = null;
/*      */               
/*      */               getSkinnable().requestLayout();
/*      */             } 
/*      */             
/*      */             this.dragDetected = false;
/*      */           } 
/*      */           
/*      */           if ((this.posY > getSkinnable().getVmax() || this.posY < getSkinnable().getVmin() || this.posX > getSkinnable().getHmax() || this.posX < getSkinnable().getHmin()) && !this.touchDetected) {
/*      */             startContentsToViewport();
/*      */           }
/*      */         });
/*      */     
/*  781 */     this.viewRect.setOnMouseDragged(paramMouseEvent -> {
/*      */           if (Properties.IS_TOUCH_SUPPORTED) {
/*      */             startSBReleasedAnimation();
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           if (getSkinnable().isPannable() || Properties.IS_TOUCH_SUPPORTED) {
/*      */             double d1 = this.pressX - paramMouseEvent.getX();
/*      */ 
/*      */ 
/*      */             
/*      */             double d2 = this.pressY - paramMouseEvent.getY();
/*      */ 
/*      */ 
/*      */             
/*      */             if (this.hsb.getVisibleAmount() > 0.0D && this.hsb.getVisibleAmount() < this.hsb.getMax() && Math.abs(d1) > 0.5D) {
/*      */               if (isReverseNodeOrientation()) {
/*      */                 d1 = -d1;
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               double d = this.ohvalue + d1 / (this.nodeWidth - this.viewRect.getWidth()) * (this.hsb.getMax() - this.hsb.getMin());
/*      */ 
/*      */ 
/*      */               
/*      */               if (!Properties.IS_TOUCH_SUPPORTED) {
/*      */                 if (d > this.hsb.getMax()) {
/*      */                   d = this.hsb.getMax();
/*      */                 } else if (d < this.hsb.getMin()) {
/*      */                   d = this.hsb.getMin();
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/*      */                 this.hsb.setValue(d);
/*      */               } else {
/*      */                 this.hsb.setValue(d);
/*      */               } 
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*      */             if (this.vsb.getVisibleAmount() > 0.0D && this.vsb.getVisibleAmount() < this.vsb.getMax() && Math.abs(d2) > 0.5D) {
/*      */               double d = this.ovvalue + d2 / (this.nodeHeight - this.viewRect.getHeight()) * (this.vsb.getMax() - this.vsb.getMin());
/*      */ 
/*      */               
/*      */               if (!Properties.IS_TOUCH_SUPPORTED) {
/*      */                 if (d > this.vsb.getMax()) {
/*      */                   d = this.vsb.getMax();
/*      */                 } else if (d < this.vsb.getMin()) {
/*      */                   d = this.vsb.getMin();
/*      */                 } 
/*      */ 
/*      */                 
/*      */                 this.vsb.setValue(d);
/*      */               } else {
/*      */                 this.vsb.setValue(d);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*      */           paramMouseEvent.consume();
/*      */         });
/*      */ 
/*      */     
/*  849 */     EventDispatcher eventDispatcher1 = (paramEvent, paramEventDispatchChain) -> paramEvent;
/*      */     
/*  851 */     EventDispatcher eventDispatcher2 = this.hsb.getEventDispatcher();
/*  852 */     this.hsb.setEventDispatcher((paramEvent, paramEventDispatchChain) -> {
/*      */           if (paramEvent.getEventType() == ScrollEvent.SCROLL && !((ScrollEvent)paramEvent).isDirect()) {
/*      */             paramEventDispatchChain = paramEventDispatchChain.prepend(paramEventDispatcher1);
/*      */             
/*      */             paramEventDispatchChain = paramEventDispatchChain.prepend(paramEventDispatcher2);
/*      */             
/*      */             return paramEventDispatchChain.dispatchEvent(paramEvent);
/*      */           } 
/*      */           return paramEventDispatcher2.dispatchEvent(paramEvent, paramEventDispatchChain);
/*      */         });
/*  862 */     EventDispatcher eventDispatcher3 = this.vsb.getEventDispatcher();
/*  863 */     this.vsb.setEventDispatcher((paramEvent, paramEventDispatchChain) -> {
/*      */           if (paramEvent.getEventType() == ScrollEvent.SCROLL && !((ScrollEvent)paramEvent).isDirect()) {
/*      */             paramEventDispatchChain = paramEventDispatchChain.prepend(paramEventDispatcher1);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             paramEventDispatchChain = paramEventDispatchChain.prepend(paramEventDispatcher2);
/*      */ 
/*      */ 
/*      */             
/*      */             return paramEventDispatchChain.dispatchEvent(paramEvent);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*      */           return paramEventDispatcher2.dispatchEvent(paramEvent, paramEventDispatchChain);
/*      */         });
/*      */ 
/*      */ 
/*      */     
/*  884 */     this.viewRect.addEventHandler(ScrollEvent.SCROLL, paramScrollEvent -> {
/*      */           if (Properties.IS_TOUCH_SUPPORTED) {
/*      */             startSBReleasedAnimation();
/*      */           }
/*      */ 
/*      */           
/*      */           if (this.vsb.getVisibleAmount() < this.vsb.getMax()) {
/*      */             double d2;
/*      */ 
/*      */             
/*      */             double d1 = getSkinnable().getVmax() - getSkinnable().getVmin();
/*      */ 
/*      */             
/*      */             if (this.nodeHeight > 0.0D) {
/*      */               d2 = d1 / this.nodeHeight;
/*      */             } else {
/*      */               d2 = 0.0D;
/*      */             } 
/*      */ 
/*      */             
/*      */             double d3 = this.vsb.getValue() + -paramScrollEvent.getDeltaY() * d2;
/*      */ 
/*      */             
/*      */             if (!Properties.IS_TOUCH_SUPPORTED) {
/*      */               if ((paramScrollEvent.getDeltaY() > 0.0D && this.vsb.getValue() > this.vsb.getMin()) || (paramScrollEvent.getDeltaY() < 0.0D && this.vsb.getValue() < this.vsb.getMax())) {
/*      */                 this.vsb.setValue(d3);
/*      */ 
/*      */                 
/*      */                 paramScrollEvent.consume();
/*      */               } 
/*      */             } else if (!paramScrollEvent.isInertia() || (paramScrollEvent.isInertia() && (this.contentsToViewTimeline == null || this.contentsToViewTimeline.getStatus() == Animation.Status.STOPPED))) {
/*      */               this.vsb.setValue(d3);
/*      */ 
/*      */               
/*      */               if ((d3 > this.vsb.getMax() || d3 < this.vsb.getMin()) && !this.mouseDown && !this.touchDetected) {
/*      */                 startContentsToViewport();
/*      */               }
/*      */ 
/*      */               
/*      */               paramScrollEvent.consume();
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*      */           if (this.hsb.getVisibleAmount() < this.hsb.getMax()) {
/*      */             double d2;
/*      */ 
/*      */             
/*      */             double d1 = getSkinnable().getHmax() - getSkinnable().getHmin();
/*      */ 
/*      */             
/*      */             if (this.nodeWidth > 0.0D) {
/*      */               d2 = d1 / this.nodeWidth;
/*      */             } else {
/*      */               d2 = 0.0D;
/*      */             } 
/*      */ 
/*      */             
/*      */             double d3 = this.hsb.getValue() + -paramScrollEvent.getDeltaX() * d2;
/*      */ 
/*      */             
/*      */             if (!Properties.IS_TOUCH_SUPPORTED) {
/*      */               if ((paramScrollEvent.getDeltaX() > 0.0D && this.hsb.getValue() > this.hsb.getMin()) || (paramScrollEvent.getDeltaX() < 0.0D && this.hsb.getValue() < this.hsb.getMax())) {
/*      */                 this.hsb.setValue(d3);
/*      */                 
/*      */                 paramScrollEvent.consume();
/*      */               } 
/*      */             } else if (!paramScrollEvent.isInertia() || (paramScrollEvent.isInertia() && (this.contentsToViewTimeline == null || this.contentsToViewTimeline.getStatus() == Animation.Status.STOPPED))) {
/*      */               this.hsb.setValue(d3);
/*      */               
/*      */               if ((d3 > this.hsb.getMax() || d3 < this.hsb.getMin()) && !this.mouseDown && !this.touchDetected) {
/*      */                 startContentsToViewport();
/*      */               }
/*      */               
/*      */               paramScrollEvent.consume();
/*      */             } 
/*      */           } 
/*      */         });
/*      */     
/*  963 */     getSkinnable().addEventHandler(TouchEvent.TOUCH_PRESSED, paramTouchEvent -> {
/*      */           this.touchDetected = true;
/*      */           
/*      */           startSBReleasedAnimation();
/*      */           paramTouchEvent.consume();
/*      */         });
/*  969 */     getSkinnable().addEventHandler(TouchEvent.TOUCH_RELEASED, paramTouchEvent -> {
/*      */           this.touchDetected = false;
/*      */           
/*      */           paramTouchEvent.consume();
/*      */         });
/*      */     
/*  975 */     consumeMouseEvents(false);
/*      */ 
/*      */     
/*  978 */     this.hsb.setValue(scrollPane.getHvalue());
/*  979 */     this.vsb.setValue(scrollPane.getVvalue());
/*      */   }
/*      */   
/*      */   void scrollBoundsIntoView(Bounds paramBounds) {
/*  983 */     double d1 = 0.0D;
/*  984 */     double d2 = 0.0D;
/*  985 */     if (paramBounds.getMaxX() > this.contentWidth) {
/*  986 */       d1 = paramBounds.getMinX() - snappedLeftInset();
/*      */     }
/*  988 */     if (paramBounds.getMinX() < snappedLeftInset()) {
/*  989 */       d1 = paramBounds.getMaxX() - this.contentWidth - snappedLeftInset();
/*      */     }
/*  991 */     if (paramBounds.getMaxY() > snappedTopInset() + this.contentHeight) {
/*  992 */       d2 = paramBounds.getMinY() - snappedTopInset();
/*      */     }
/*  994 */     if (paramBounds.getMinY() < snappedTopInset()) {
/*  995 */       d2 = paramBounds.getMaxY() - this.contentHeight - snappedTopInset();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1000 */     if (d1 != 0.0D) {
/* 1001 */       double d = d1 * (this.hsb.getMax() - this.hsb.getMin()) / (this.nodeWidth - this.contentWidth);
/*      */       
/* 1003 */       d += -1.0D * Math.signum(d) * this.hsb.getUnitIncrement() / 5.0D;
/* 1004 */       this.hsb.setValue(this.hsb.getValue() + d);
/* 1005 */       getSkinnable().requestLayout();
/*      */     } 
/* 1007 */     if (d2 != 0.0D) {
/* 1008 */       double d = d2 * (this.vsb.getMax() - this.vsb.getMin()) / (this.nodeHeight - this.contentHeight);
/*      */       
/* 1010 */       d += -1.0D * Math.signum(d) * this.vsb.getUnitIncrement() / 5.0D;
/* 1011 */       this.vsb.setValue(this.vsb.getValue() + d);
/* 1012 */       getSkinnable().requestLayout();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double computeHsbSizeHint(ScrollPane paramScrollPane) {
/* 1021 */     return (paramScrollPane.getHbarPolicy() == ScrollPane.ScrollBarPolicy.ALWAYS || (paramScrollPane
/* 1022 */       .getHbarPolicy() == ScrollPane.ScrollBarPolicy.AS_NEEDED && (paramScrollPane.getPrefViewportHeight() > 0.0D || paramScrollPane.getMinViewportHeight() > 0.0D))) ? 
/* 1023 */       this.hsb.prefHeight(-1.0D) : 
/* 1024 */       0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double computeVsbSizeHint(ScrollPane paramScrollPane) {
/* 1031 */     return (paramScrollPane.getVbarPolicy() == ScrollPane.ScrollBarPolicy.ALWAYS || (paramScrollPane
/* 1032 */       .getVbarPolicy() == ScrollPane.ScrollBarPolicy.AS_NEEDED && (paramScrollPane.getPrefViewportWidth() > 0.0D || paramScrollPane
/* 1033 */       .getMinViewportWidth() > 0.0D))) ? 
/* 1034 */       this.vsb.prefWidth(-1.0D) : 
/* 1035 */       0.0D;
/*      */   }
/*      */   
/*      */   private void computeScrollNodeSize(double paramDouble1, double paramDouble2) {
/* 1039 */     if (this.scrollNode != null) {
/* 1040 */       if (this.scrollNode.isResizable()) {
/* 1041 */         ScrollPane scrollPane = getSkinnable();
/* 1042 */         Orientation orientation = this.scrollNode.getContentBias();
/* 1043 */         if (orientation == null) {
/* 1044 */           this.nodeWidth = snapSizeX(Utils.boundedSize(scrollPane.isFitToWidth() ? paramDouble1 : this.scrollNode.prefWidth(-1.0D), this.scrollNode
/* 1045 */                 .minWidth(-1.0D), this.scrollNode.maxWidth(-1.0D)));
/* 1046 */           this.nodeHeight = snapSizeY(Utils.boundedSize(scrollPane.isFitToHeight() ? paramDouble2 : this.scrollNode.prefHeight(-1.0D), this.scrollNode
/* 1047 */                 .minHeight(-1.0D), this.scrollNode.maxHeight(-1.0D)));
/*      */         }
/* 1049 */         else if (orientation == Orientation.HORIZONTAL) {
/* 1050 */           this.nodeWidth = snapSizeX(Utils.boundedSize(scrollPane.isFitToWidth() ? paramDouble1 : this.scrollNode.prefWidth(-1.0D), this.scrollNode
/* 1051 */                 .minWidth(-1.0D), this.scrollNode.maxWidth(-1.0D)));
/* 1052 */           this.nodeHeight = snapSizeY(Utils.boundedSize(scrollPane.isFitToHeight() ? paramDouble2 : this.scrollNode.prefHeight(this.nodeWidth), this.scrollNode
/* 1053 */                 .minHeight(this.nodeWidth), this.scrollNode.maxHeight(this.nodeWidth)));
/*      */         } else {
/*      */           
/* 1056 */           this.nodeHeight = snapSizeY(Utils.boundedSize(scrollPane.isFitToHeight() ? paramDouble2 : this.scrollNode.prefHeight(-1.0D), this.scrollNode
/* 1057 */                 .minHeight(-1.0D), this.scrollNode.maxHeight(-1.0D)));
/* 1058 */           this.nodeWidth = snapSizeX(Utils.boundedSize(scrollPane.isFitToWidth() ? paramDouble1 : this.scrollNode.prefWidth(this.nodeHeight), this.scrollNode
/* 1059 */                 .minWidth(this.nodeHeight), this.scrollNode.maxWidth(this.nodeHeight)));
/*      */         } 
/*      */       } else {
/*      */         
/* 1063 */         this.nodeWidth = snapSizeX(this.scrollNode.getLayoutBounds().getWidth());
/* 1064 */         this.nodeHeight = snapSizeY(this.scrollNode.getLayoutBounds().getHeight());
/*      */       } 
/* 1066 */       this.nodeSizeInvalid = false;
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isReverseNodeOrientation() {
/* 1071 */     return (this.scrollNode != null && 
/* 1072 */       getSkinnable().getEffectiveNodeOrientation() != this.scrollNode
/* 1073 */       .getEffectiveNodeOrientation());
/*      */   }
/*      */   
/*      */   private boolean determineHorizontalSBVisible() {
/* 1077 */     ScrollPane scrollPane = getSkinnable();
/*      */     
/* 1079 */     if (Properties.IS_TOUCH_SUPPORTED) {
/* 1080 */       return (this.tempVisibility && this.nodeWidth > this.contentWidth);
/*      */     }
/*      */ 
/*      */     
/* 1084 */     ScrollPane.ScrollBarPolicy scrollBarPolicy = scrollPane.getHbarPolicy();
/* 1085 */     return (ScrollPane.ScrollBarPolicy.NEVER == scrollBarPolicy) ? false : (
/* 1086 */       (ScrollPane.ScrollBarPolicy.ALWAYS == scrollBarPolicy) ? true : (
/* 1087 */       (scrollPane.isFitToWidth() && this.scrollNode != null && this.scrollNode.isResizable()) ? (
/* 1088 */       (this.nodeWidth > this.contentWidth && this.scrollNode.minWidth(-1.0D) > this.contentWidth)) : ((this.nodeWidth > this.contentWidth))));
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean determineVerticalSBVisible() {
/* 1093 */     ScrollPane scrollPane = getSkinnable();
/*      */     
/* 1095 */     if (Properties.IS_TOUCH_SUPPORTED) {
/* 1096 */       return (this.tempVisibility && this.nodeHeight > this.contentHeight);
/*      */     }
/*      */ 
/*      */     
/* 1100 */     ScrollPane.ScrollBarPolicy scrollBarPolicy = scrollPane.getVbarPolicy();
/* 1101 */     return (ScrollPane.ScrollBarPolicy.NEVER == scrollBarPolicy) ? false : (
/* 1102 */       (ScrollPane.ScrollBarPolicy.ALWAYS == scrollBarPolicy) ? true : (
/* 1103 */       (scrollPane.isFitToHeight() && this.scrollNode != null && this.scrollNode.isResizable()) ? (
/* 1104 */       (this.nodeHeight > this.contentHeight && this.scrollNode.minHeight(-1.0D) > this.contentHeight)) : ((this.nodeHeight > this.contentHeight))));
/*      */   }
/*      */ 
/*      */   
/*      */   private void computeScrollBarSize() {
/* 1109 */     this.vsbWidth = snapSizeX(this.vsb.prefWidth(-1.0D));
/* 1110 */     if (this.vsbWidth == 0.0D)
/*      */     {
/* 1112 */       if (Properties.IS_TOUCH_SUPPORTED) {
/* 1113 */         this.vsbWidth = 8.0D;
/*      */       } else {
/*      */         
/* 1116 */         this.vsbWidth = 12.0D;
/*      */       } 
/*      */     }
/* 1119 */     this.hsbHeight = snapSizeY(this.hsb.prefHeight(-1.0D));
/* 1120 */     if (this.hsbHeight == 0.0D)
/*      */     {
/* 1122 */       if (Properties.IS_TOUCH_SUPPORTED) {
/* 1123 */         this.hsbHeight = 8.0D;
/*      */       } else {
/*      */         
/* 1126 */         this.hsbHeight = 12.0D;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateHorizontalSB() {
/* 1132 */     double d = this.nodeWidth * (this.hsb.getMax() - this.hsb.getMin());
/* 1133 */     if (d > 0.0D) {
/* 1134 */       this.hsb.setVisibleAmount(this.contentWidth / d);
/* 1135 */       this.hsb.setBlockIncrement(0.9D * this.hsb.getVisibleAmount());
/* 1136 */       this.hsb.setUnitIncrement(0.1D * this.hsb.getVisibleAmount());
/*      */     } else {
/*      */       
/* 1139 */       this.hsb.setVisibleAmount(0.0D);
/* 1140 */       this.hsb.setBlockIncrement(0.0D);
/* 1141 */       this.hsb.setUnitIncrement(0.0D);
/*      */     } 
/*      */     
/* 1144 */     if (this.hsb.isVisible()) {
/* 1145 */       updatePosX();
/*      */     }
/* 1147 */     else if (this.nodeWidth > this.contentWidth) {
/* 1148 */       updatePosX();
/*      */     } else {
/* 1150 */       this.viewContent.setLayoutX(0.0D);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateVerticalSB() {
/* 1156 */     double d = this.nodeHeight * (this.vsb.getMax() - this.vsb.getMin());
/* 1157 */     if (d > 0.0D) {
/* 1158 */       this.vsb.setVisibleAmount(this.contentHeight / d);
/* 1159 */       this.vsb.setBlockIncrement(0.9D * this.vsb.getVisibleAmount());
/* 1160 */       this.vsb.setUnitIncrement(0.1D * this.vsb.getVisibleAmount());
/*      */     } else {
/*      */       
/* 1163 */       this.vsb.setVisibleAmount(0.0D);
/* 1164 */       this.vsb.setBlockIncrement(0.0D);
/* 1165 */       this.vsb.setUnitIncrement(0.0D);
/*      */     } 
/*      */     
/* 1168 */     if (this.vsb.isVisible()) {
/* 1169 */       updatePosY();
/*      */     }
/* 1171 */     else if (this.nodeHeight > this.contentHeight) {
/* 1172 */       updatePosY();
/*      */     } else {
/* 1174 */       this.viewContent.setLayoutY(0.0D);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private double updatePosX() {
/* 1180 */     ScrollPane scrollPane = getSkinnable();
/* 1181 */     double d1 = isReverseNodeOrientation() ? (this.hsb.getMax() - this.posX - this.hsb.getMin()) : this.posX;
/* 1182 */     double d2 = Math.min(-d1 / (this.hsb.getMax() - this.hsb.getMin()) * (this.nodeWidth - this.contentWidth), 0.0D);
/* 1183 */     this.viewContent.setLayoutX(snapPositionX(d2));
/* 1184 */     if (!scrollPane.hvalueProperty().isBound()) scrollPane.setHvalue(Utils.clamp(scrollPane.getHmin(), this.posX, scrollPane.getHmax())); 
/* 1185 */     return this.posX;
/*      */   }
/*      */   
/*      */   private double updatePosY() {
/* 1189 */     ScrollPane scrollPane = getSkinnable();
/* 1190 */     double d = Math.min(-this.posY / (this.vsb.getMax() - this.vsb.getMin()) * (this.nodeHeight - this.contentHeight), 0.0D);
/* 1191 */     this.viewContent.setLayoutY(snapPositionY(d));
/* 1192 */     if (!scrollPane.vvalueProperty().isBound()) scrollPane.setVvalue(Utils.clamp(scrollPane.getVmin(), this.posY, scrollPane.getVmax())); 
/* 1193 */     return this.posY;
/*      */   }
/*      */   
/*      */   private void resetClip() {
/* 1197 */     this.clipRect.setWidth(snapSizeX(this.contentWidth));
/* 1198 */     this.clipRect.setHeight(snapSizeY(this.contentHeight));
/*      */   }
/*      */   
/*      */   private void startSBReleasedAnimation() {
/* 1202 */     if (this.sbTouchTimeline == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1207 */       this.sbTouchTimeline = new Timeline();
/* 1208 */       this.sbTouchKF1 = new KeyFrame(Duration.millis(0.0D), paramActionEvent -> { this.tempVisibility = true; if (this.touchDetected == true || this.mouseDown == true) this.sbTouchTimeline.playFromStart();  }new KeyValue[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1215 */       this.sbTouchKF2 = new KeyFrame(Duration.millis(1000.0D), paramActionEvent -> { this.tempVisibility = false; getSkinnable().requestLayout(); }new KeyValue[0]);
/*      */ 
/*      */ 
/*      */       
/* 1219 */       this.sbTouchTimeline.getKeyFrames().addAll(new KeyFrame[] { this.sbTouchKF1, this.sbTouchKF2 });
/*      */     } 
/* 1221 */     this.sbTouchTimeline.playFromStart();
/*      */   }
/*      */   
/*      */   private void startContentsToViewport() {
/* 1225 */     double d1 = this.posX;
/* 1226 */     double d2 = this.posY;
/*      */     
/* 1228 */     setContentPosX(this.posX);
/* 1229 */     setContentPosY(this.posY);
/*      */     
/* 1231 */     if (this.posY > getSkinnable().getVmax()) {
/* 1232 */       d2 = getSkinnable().getVmax();
/*      */     }
/* 1234 */     else if (this.posY < getSkinnable().getVmin()) {
/* 1235 */       d2 = getSkinnable().getVmin();
/*      */     } 
/*      */ 
/*      */     
/* 1239 */     if (this.posX > getSkinnable().getHmax()) {
/* 1240 */       d1 = getSkinnable().getHmax();
/*      */     }
/* 1242 */     else if (this.posX < getSkinnable().getHmin()) {
/* 1243 */       d1 = getSkinnable().getHmin();
/*      */     } 
/*      */     
/* 1246 */     if (!Properties.IS_TOUCH_SUPPORTED) {
/* 1247 */       startSBReleasedAnimation();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1253 */     if (this.contentsToViewTimeline != null) {
/* 1254 */       this.contentsToViewTimeline.stop();
/*      */     }
/* 1256 */     this.contentsToViewTimeline = new Timeline();
/*      */ 
/*      */ 
/*      */     
/* 1260 */     this.contentsToViewKF1 = new KeyFrame(Duration.millis(50.0D), new KeyValue[0]);
/*      */ 
/*      */ 
/*      */     
/* 1264 */     this
/*      */ 
/*      */ 
/*      */       
/* 1268 */       .contentsToViewKF2 = new KeyFrame(Duration.millis(150.0D), paramActionEvent -> getSkinnable().requestLayout(), new KeyValue[] { new KeyValue(this.contentPosX, (T)Double.valueOf(d1)), new KeyValue(this.contentPosY, (T)Double.valueOf(d2)) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1274 */     this.contentsToViewKF3 = new KeyFrame(Duration.millis(1500.0D), new KeyValue[0]);
/* 1275 */     this.contentsToViewTimeline.getKeyFrames().addAll(new KeyFrame[] { this.contentsToViewKF1, this.contentsToViewKF2, this.contentsToViewKF3 });
/* 1276 */     this.contentsToViewTimeline.playFromStart();
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ScrollPaneSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */