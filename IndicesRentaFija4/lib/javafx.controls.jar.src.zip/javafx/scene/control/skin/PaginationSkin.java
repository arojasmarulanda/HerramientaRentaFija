/*      */ package javafx.scene.control.skin;
/*      */ 
/*      */ import com.sun.javafx.scene.control.behavior.PaginationBehavior;
/*      */ import com.sun.javafx.scene.control.skin.Utils;
/*      */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import javafx.animation.Interpolator;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.KeyValue;
/*      */ import javafx.animation.Timeline;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.value.ChangeListener;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableBooleanProperty;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.BooleanConverter;
/*      */ import javafx.css.converter.EnumConverter;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.geometry.HPos;
/*      */ import javafx.geometry.Insets;
/*      */ import javafx.geometry.Pos;
/*      */ import javafx.geometry.Side;
/*      */ import javafx.geometry.VPos;
/*      */ import javafx.scene.AccessibleAction;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.Button;
/*      */ import javafx.scene.control.Control;
/*      */ import javafx.scene.control.Label;
/*      */ import javafx.scene.control.Pagination;
/*      */ import javafx.scene.control.SkinBase;
/*      */ import javafx.scene.control.Toggle;
/*      */ import javafx.scene.control.ToggleButton;
/*      */ import javafx.scene.control.ToggleGroup;
/*      */ import javafx.scene.control.Tooltip;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.input.TouchEvent;
/*      */ import javafx.scene.layout.HBox;
/*      */ import javafx.scene.layout.StackPane;
/*      */ import javafx.scene.shape.Rectangle;
/*      */ import javafx.scene.text.Font;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PaginationSkin
/*      */   extends SkinBase<Pagination>
/*      */ {
/*   88 */   private static final Duration DURATION = new Duration(125.0D);
/*      */   private static final double SWIPE_THRESHOLD = 0.3D;
/*      */   private static final double TOUCH_THRESHOLD = 15.0D;
/*   91 */   private static final Interpolator interpolator = Interpolator.SPLINE(0.4829D, 0.5709D, 0.6803D, 0.9928D);
/*      */   
/*      */   private Pagination pagination;
/*      */   
/*      */   private StackPane currentStackPane;
/*      */   
/*      */   private StackPane nextStackPane;
/*      */   
/*      */   private Timeline timeline;
/*      */   
/*      */   private Rectangle clipRect;
/*      */   
/*      */   private NavigationControl navigation;
/*      */   
/*      */   private int fromIndex;
/*      */   
/*      */   private int previousIndex;
/*      */   
/*      */   private int currentIndex;
/*      */   
/*      */   private int toIndex;
/*      */   
/*      */   private int pageCount;
/*      */   private int maxPageIndicatorCount;
/*      */   private double startTouchPos;
/*      */   private double lastTouchPos;
/*      */   private long startTouchTime;
/*      */   private long lastTouchTime;
/*      */   private double touchVelocity;
/*      */   private boolean touchThresholdBroken;
/*  121 */   private int touchEventId = -1;
/*      */ 
/*      */   
/*      */   private boolean nextPageReached = false;
/*      */ 
/*      */   
/*      */   private boolean setInitialDirection = false;
/*      */ 
/*      */   
/*      */   private int direction;
/*      */   
/*      */   private int currentAnimatedIndex;
/*      */   
/*      */   private boolean hasPendingAnimation = false;
/*      */   
/*      */   private boolean animate = true;
/*      */   
/*      */   private final PaginationBehavior behavior;
/*      */ 
/*      */   
/*  141 */   private EventHandler<ActionEvent> swipeAnimationEndEventHandler = new EventHandler<ActionEvent>() {
/*      */       public void handle(ActionEvent param1ActionEvent) {
/*  143 */         PaginationSkin.this.swapPanes();
/*  144 */         PaginationSkin.this.timeline = null;
/*      */         
/*  146 */         if (PaginationSkin.this.hasPendingAnimation) {
/*  147 */           PaginationSkin.this.animateSwitchPage();
/*  148 */           PaginationSkin.this.hasPendingAnimation = false;
/*      */         } 
/*      */       }
/*      */     };
/*      */   
/*  153 */   private EventHandler<ActionEvent> clampAnimationEndEventHandler = new EventHandler<ActionEvent>() {
/*      */       public void handle(ActionEvent param1ActionEvent) {
/*  155 */         PaginationSkin.this.currentStackPane.setTranslateX(0.0D);
/*  156 */         PaginationSkin.this.nextStackPane.setTranslateX(0.0D);
/*  157 */         PaginationSkin.this.nextStackPane.setVisible(false);
/*  158 */         PaginationSkin.this.timeline = null;
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*      */   private final DoubleProperty arrowButtonGap;
/*      */ 
/*      */   
/*      */   private BooleanProperty arrowsVisible;
/*      */ 
/*      */   
/*      */   private BooleanProperty pageInformationVisible;
/*      */   
/*      */   private ObjectProperty<Side> pageInformationAlignment;
/*      */   
/*      */   private BooleanProperty tooltipVisible;
/*      */ 
/*      */   
/*      */   public PaginationSkin(Pagination paramPagination) {
/*  178 */     super(paramPagination);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  235 */     this.arrowButtonGap = new StyleableDoubleProperty(60.0D) {
/*      */         public Object getBean() {
/*  237 */           return PaginationSkin.this;
/*      */         }
/*      */         public String getName() {
/*  240 */           return "arrowButtonGap";
/*      */         }
/*      */         
/*  243 */         public CssMetaData<Pagination, Number> getCssMetaData() { return PaginationSkin.StyleableProperties.ARROW_BUTTON_GAP; } }; this.behavior = new PaginationBehavior(paramPagination); this.clipRect = new Rectangle(); getSkinnable().setClip(this.clipRect); this.pagination = paramPagination; this.currentStackPane = new StackPane(); this.currentStackPane.getStyleClass().add("page"); this.nextStackPane = new StackPane(); this.nextStackPane.getStyleClass().add("page"); this.nextStackPane.setVisible(false); resetIndexes(true); this.navigation = new NavigationControl(); getChildren().addAll(new Node[] { this.currentStackPane, this.nextStackPane, this.navigation }); paramPagination.maxPageIndicatorCountProperty().addListener(paramObservable -> resetIndiciesAndNav()); registerChangeListener(paramPagination.widthProperty(), paramObservableValue -> this.clipRect.setWidth(getSkinnable().getWidth())); registerChangeListener(paramPagination.heightProperty(), paramObservableValue -> this.clipRect.setHeight(getSkinnable().getHeight())); registerChangeListener(paramPagination.pageCountProperty(), paramObservableValue -> resetIndiciesAndNav()); registerChangeListener(paramPagination.pageFactoryProperty(), paramObservableValue -> {
/*      */           if (this.animate && this.timeline != null) {
/*      */             this.timeline.setRate(8.0D); this.timeline.setOnFinished(()); return;
/*      */           }  resetIndiciesAndNav();
/*  247 */         }); initializeSwipeAndTouchHandlers(); } private final DoubleProperty arrowButtonGapProperty() { return this.arrowButtonGap; }
/*      */   
/*      */   private final double getArrowButtonGap() {
/*  250 */     return this.arrowButtonGap.get();
/*      */   }
/*      */   private final void setArrowButtonGap(double paramDouble) {
/*  253 */     this.arrowButtonGap.set(paramDouble);
/*      */   }
/*      */   
/*      */   private final void setArrowsVisible(boolean paramBoolean) {
/*  257 */     arrowsVisibleProperty().set(paramBoolean); } private final boolean isArrowsVisible() {
/*  258 */     return (this.arrowsVisible == null) ? DEFAULT_ARROW_VISIBLE.booleanValue() : this.arrowsVisible.get();
/*      */   } private final BooleanProperty arrowsVisibleProperty() {
/*  260 */     if (this.arrowsVisible == null) {
/*  261 */       this.arrowsVisible = new StyleableBooleanProperty(DEFAULT_ARROW_VISIBLE.booleanValue())
/*      */         {
/*      */           protected void invalidated() {
/*  264 */             PaginationSkin.this.getSkinnable().requestLayout();
/*      */           }
/*      */ 
/*      */           
/*      */           public CssMetaData<Pagination, Boolean> getCssMetaData() {
/*  269 */             return PaginationSkin.StyleableProperties.ARROWS_VISIBLE;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  274 */             return PaginationSkin.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  279 */             return "arrowVisible";
/*      */           }
/*      */         };
/*      */     }
/*  283 */     return this.arrowsVisible;
/*      */   }
/*      */   
/*      */   private final void setPageInformationVisible(boolean paramBoolean) {
/*  287 */     pageInformationVisibleProperty().set(paramBoolean); } private final boolean isPageInformationVisible() {
/*  288 */     return (this.pageInformationVisible == null) ? DEFAULT_PAGE_INFORMATION_VISIBLE.booleanValue() : this.pageInformationVisible.get();
/*      */   } private final BooleanProperty pageInformationVisibleProperty() {
/*  290 */     if (this.pageInformationVisible == null) {
/*  291 */       this.pageInformationVisible = new StyleableBooleanProperty(DEFAULT_PAGE_INFORMATION_VISIBLE.booleanValue())
/*      */         {
/*      */           protected void invalidated() {
/*  294 */             PaginationSkin.this.getSkinnable().requestLayout();
/*      */           }
/*      */ 
/*      */           
/*      */           public CssMetaData<Pagination, Boolean> getCssMetaData() {
/*  299 */             return PaginationSkin.StyleableProperties.PAGE_INFORMATION_VISIBLE;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  304 */             return PaginationSkin.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  309 */             return "pageInformationVisible";
/*      */           }
/*      */         };
/*      */     }
/*  313 */     return this.pageInformationVisible;
/*      */   }
/*      */   
/*      */   private final void setPageInformationAlignment(Side paramSide) {
/*  317 */     pageInformationAlignmentProperty().set(paramSide); } private final Side getPageInformationAlignment() {
/*  318 */     return (this.pageInformationAlignment == null) ? DEFAULT_PAGE_INFORMATION_ALIGNMENT : this.pageInformationAlignment.get();
/*      */   } private final ObjectProperty<Side> pageInformationAlignmentProperty() {
/*  320 */     if (this.pageInformationAlignment == null) {
/*  321 */       this.pageInformationAlignment = new StyleableObjectProperty<Side>(Side.BOTTOM)
/*      */         {
/*      */           protected void invalidated() {
/*  324 */             PaginationSkin.this.getSkinnable().requestLayout();
/*      */           }
/*      */ 
/*      */           
/*      */           public CssMetaData<Pagination, Side> getCssMetaData() {
/*  329 */             return PaginationSkin.StyleableProperties.PAGE_INFORMATION_ALIGNMENT;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  334 */             return PaginationSkin.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  339 */             return "pageInformationAlignment";
/*      */           }
/*      */         };
/*      */     }
/*  343 */     return this.pageInformationAlignment;
/*      */   }
/*      */   
/*      */   private final void setTooltipVisible(boolean paramBoolean) {
/*  347 */     tooltipVisibleProperty().set(paramBoolean); } private final boolean isTooltipVisible() {
/*  348 */     return (this.tooltipVisible == null) ? DEFAULT_TOOLTIP_VISIBLE.booleanValue() : this.tooltipVisible.get();
/*      */   } private final BooleanProperty tooltipVisibleProperty() {
/*  350 */     if (this.tooltipVisible == null) {
/*  351 */       this.tooltipVisible = new StyleableBooleanProperty(DEFAULT_TOOLTIP_VISIBLE.booleanValue())
/*      */         {
/*      */           protected void invalidated() {
/*  354 */             PaginationSkin.this.getSkinnable().requestLayout();
/*      */           }
/*      */ 
/*      */           
/*      */           public CssMetaData<Pagination, Boolean> getCssMetaData() {
/*  359 */             return PaginationSkin.StyleableProperties.TOOLTIP_VISIBLE;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  364 */             return PaginationSkin.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  369 */             return "tooltipVisible";
/*      */           }
/*      */         };
/*      */     }
/*  373 */     return this.tooltipVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  386 */     super.dispose();
/*      */     
/*  388 */     if (this.behavior != null) {
/*  389 */       this.behavior.dispose();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  395 */     double d = this.navigation.isVisible() ? snapSizeX(this.navigation.minWidth(paramDouble1)) : 0.0D;
/*  396 */     return paramDouble5 + Math.max(this.currentStackPane.minWidth(paramDouble1), d) + paramDouble3;
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  401 */     double d = this.navigation.isVisible() ? snapSizeY(this.navigation.minHeight(paramDouble1)) : 0.0D;
/*  402 */     return paramDouble2 + this.currentStackPane.minHeight(paramDouble1) + d + paramDouble4;
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  407 */     double d = this.navigation.isVisible() ? snapSizeX(this.navigation.prefWidth(paramDouble1)) : 0.0D;
/*  408 */     return paramDouble5 + Math.max(this.currentStackPane.prefWidth(paramDouble1), d) + paramDouble3;
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  413 */     double d = this.navigation.isVisible() ? snapSizeY(this.navigation.prefHeight(paramDouble1)) : 0.0D;
/*  414 */     return paramDouble2 + this.currentStackPane.prefHeight(paramDouble1) + d + paramDouble4;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  420 */     double d1 = this.navigation.isVisible() ? snapSizeY(this.navigation.prefHeight(-1.0D)) : 0.0D;
/*  421 */     double d2 = snapSizeY(paramDouble4 - d1);
/*      */     
/*  423 */     layoutInArea(this.currentStackPane, paramDouble1, paramDouble2, paramDouble3, d2, 0.0D, HPos.CENTER, VPos.CENTER);
/*  424 */     layoutInArea(this.nextStackPane, paramDouble1, paramDouble2, paramDouble3, d2, 0.0D, HPos.CENTER, VPos.CENTER);
/*  425 */     layoutInArea(this.navigation, paramDouble1, d2, paramDouble3, d1, 0.0D, HPos.CENTER, VPos.CENTER);
/*      */   }
/*      */   
/*      */   protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*      */     Integer integer;
/*  430 */     switch (paramAccessibleAttribute) { case REQUEST_FOCUS:
/*  431 */         return this.navigation.indicatorButtons.getSelectedToggle();
/*  432 */       case null: return Integer.valueOf(this.navigation.indicatorButtons.getToggles().size());
/*      */       case null:
/*  434 */         integer = (Integer)paramVarArgs[0];
/*  435 */         if (integer == null) return null; 
/*  436 */         return this.navigation.indicatorButtons.getToggles().get(integer.intValue()); }
/*      */     
/*  438 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void selectNext() {
/*  451 */     if (getCurrentPageIndex() < getPageCount() - 1) {
/*  452 */       this.pagination.setCurrentPageIndex(getCurrentPageIndex() + 1);
/*      */     }
/*      */   }
/*      */   
/*      */   private void selectPrevious() {
/*  457 */     if (getCurrentPageIndex() > 0) {
/*  458 */       this.pagination.setCurrentPageIndex(getCurrentPageIndex() - 1);
/*      */     }
/*      */   }
/*      */   
/*      */   private void resetIndiciesAndNav() {
/*  463 */     resetIndexes(false);
/*  464 */     this.navigation.initializePageIndicators();
/*  465 */     this.navigation.updatePageIndicators();
/*      */   }
/*      */   
/*      */   private void initializeSwipeAndTouchHandlers() {
/*  469 */     Pagination pagination = getSkinnable();
/*      */     
/*  471 */     getSkinnable().addEventHandler(TouchEvent.TOUCH_PRESSED, paramTouchEvent -> {
/*      */           if (this.touchEventId == -1) {
/*      */             this.touchEventId = paramTouchEvent.getTouchPoint().getId();
/*      */           }
/*      */           
/*      */           if (this.touchEventId != paramTouchEvent.getTouchPoint().getId()) {
/*      */             return;
/*      */           }
/*      */           this.lastTouchPos = this.startTouchPos = paramTouchEvent.getTouchPoint().getX();
/*      */           this.lastTouchTime = this.startTouchTime = System.currentTimeMillis();
/*      */           this.touchThresholdBroken = false;
/*      */           paramTouchEvent.consume();
/*      */         });
/*  484 */     getSkinnable().addEventHandler(TouchEvent.TOUCH_MOVED, paramTouchEvent -> {
/*      */           if (this.touchEventId != paramTouchEvent.getTouchPoint().getId()) {
/*      */             return;
/*      */           }
/*      */           
/*      */           double d1 = paramTouchEvent.getTouchPoint().getX() - this.lastTouchPos;
/*      */           
/*      */           long l = System.currentTimeMillis() - this.lastTouchTime;
/*      */           
/*      */           this.touchVelocity = d1 / l;
/*      */           
/*      */           this.lastTouchPos = paramTouchEvent.getTouchPoint().getX();
/*      */           
/*      */           this.lastTouchTime = System.currentTimeMillis();
/*      */           
/*      */           double d2 = paramTouchEvent.getTouchPoint().getX() - this.startTouchPos;
/*      */           
/*      */           if (!this.touchThresholdBroken && Math.abs(d2) > 15.0D) {
/*      */             this.touchThresholdBroken = true;
/*      */           }
/*      */           if (this.touchThresholdBroken) {
/*      */             double d = paramPagination.getWidth() - snappedLeftInset() + snappedRightInset();
/*      */             if (!this.setInitialDirection) {
/*      */               this.setInitialDirection = true;
/*      */               this.direction = (d2 < 0.0D) ? 1 : -1;
/*      */             } 
/*      */             if (d2 < 0.0D) {
/*      */               double d3;
/*      */               double d4;
/*      */               if (this.direction == -1) {
/*      */                 this.nextStackPane.getChildren().clear();
/*      */                 this.direction = 1;
/*      */               } 
/*      */               if (Math.abs(d2) <= d) {
/*      */                 d3 = d2;
/*      */                 d4 = d + d2;
/*      */                 this.nextPageReached = false;
/*      */               } else {
/*      */                 d3 = -d;
/*      */                 d4 = 0.0D;
/*      */                 this.nextPageReached = true;
/*      */               } 
/*      */               this.currentStackPane.setTranslateX(d3);
/*      */               if (getCurrentPageIndex() < getPageCount() - 1) {
/*      */                 createPage(this.nextStackPane, this.currentIndex + 1);
/*      */                 this.nextStackPane.setVisible(true);
/*      */                 this.nextStackPane.setTranslateX(d4);
/*      */               } else {
/*      */                 this.currentStackPane.setTranslateX(0.0D);
/*      */               } 
/*      */             } else {
/*      */               double d3;
/*      */               double d4;
/*      */               if (this.direction == 1) {
/*      */                 this.nextStackPane.getChildren().clear();
/*      */                 this.direction = -1;
/*      */               } 
/*      */               if (Math.abs(d2) <= d) {
/*      */                 d3 = d2;
/*      */                 d4 = -d + d2;
/*      */                 this.nextPageReached = false;
/*      */               } else {
/*      */                 d3 = d;
/*      */                 d4 = 0.0D;
/*      */                 this.nextPageReached = true;
/*      */               } 
/*      */               this.currentStackPane.setTranslateX(d3);
/*      */               if (getCurrentPageIndex() != 0) {
/*      */                 createPage(this.nextStackPane, this.currentIndex - 1);
/*      */                 this.nextStackPane.setVisible(true);
/*      */                 this.nextStackPane.setTranslateX(d4);
/*      */               } else {
/*      */                 this.currentStackPane.setTranslateX(0.0D);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */           paramTouchEvent.consume();
/*      */         });
/*  562 */     getSkinnable().addEventHandler(TouchEvent.TOUCH_RELEASED, paramTouchEvent -> {
/*      */           if (this.touchEventId != paramTouchEvent.getTouchPoint().getId()) {
/*      */             return;
/*      */           }
/*      */           this.touchEventId = -1;
/*      */           this.setInitialDirection = false;
/*      */           if (this.touchThresholdBroken) {
/*      */             double d1 = paramTouchEvent.getTouchPoint().getX() - this.startTouchPos;
/*      */             long l = System.currentTimeMillis() - this.startTouchTime;
/*      */             boolean bool = (l < 300L) ? true : false;
/*      */             double d2 = bool ? (d1 / l) : this.touchVelocity;
/*      */             double d3 = d2 * 500.0D;
/*      */             double d4 = paramPagination.getWidth() - snappedLeftInset() + snappedRightInset();
/*      */             double d5 = Math.abs(d3 / d4);
/*      */             double d6 = Math.abs(d1 / d4);
/*      */             if (d5 > 0.3D || d6 > 0.3D) {
/*      */               if (this.startTouchPos > paramTouchEvent.getTouchPoint().getX()) {
/*      */                 selectNext();
/*      */               } else {
/*      */                 selectPrevious();
/*      */               } 
/*      */             } else {
/*      */               animateClamping((this.startTouchPos > paramTouchEvent.getTouchPoint().getSceneX()));
/*      */             } 
/*      */           } 
/*      */           paramTouchEvent.consume();
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resetIndexes(boolean paramBoolean) {
/*  602 */     this.maxPageIndicatorCount = getMaxPageIndicatorCount();
/*      */     
/*  604 */     this.pageCount = getPageCount();
/*  605 */     if (this.pageCount > this.maxPageIndicatorCount) {
/*  606 */       this.pageCount = this.maxPageIndicatorCount;
/*      */     }
/*      */     
/*  609 */     this.fromIndex = 0;
/*  610 */     this.previousIndex = 0;
/*  611 */     this.currentIndex = paramBoolean ? getCurrentPageIndex() : 0;
/*  612 */     this.toIndex = this.pageCount - 1;
/*      */     
/*  614 */     if (this.pageCount == Integer.MAX_VALUE && this.maxPageIndicatorCount == Integer.MAX_VALUE)
/*      */     {
/*  616 */       this.toIndex = 0;
/*      */     }
/*      */     
/*  619 */     boolean bool = this.animate;
/*  620 */     if (bool) {
/*  621 */       this.animate = false;
/*      */     }
/*      */ 
/*      */     
/*  625 */     this.currentStackPane.getChildren().clear();
/*  626 */     this.nextStackPane.getChildren().clear();
/*      */     
/*  628 */     this.pagination.setCurrentPageIndex(this.currentIndex);
/*  629 */     createPage(this.currentStackPane, this.currentIndex);
/*      */     
/*  631 */     if (bool) {
/*  632 */       this.animate = true;
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean createPage(StackPane paramStackPane, int paramInt) {
/*  637 */     if (this.pagination.getPageFactory() != null && paramStackPane.getChildren().isEmpty()) {
/*  638 */       Node node = this.pagination.getPageFactory().call(Integer.valueOf(paramInt));
/*      */       
/*  640 */       if (node != null) {
/*  641 */         paramStackPane.getChildren().setAll(new Node[] { node });
/*  642 */         return true;
/*      */       } 
/*      */ 
/*      */       
/*  646 */       boolean bool = this.animate;
/*  647 */       if (bool) {
/*  648 */         this.animate = false;
/*      */       }
/*      */       
/*  651 */       if (this.pagination.getPageFactory().call(Integer.valueOf(this.previousIndex)) != null) {
/*  652 */         this.pagination.setCurrentPageIndex(this.previousIndex);
/*      */       }
/*      */       else {
/*      */         
/*  656 */         this.pagination.setCurrentPageIndex(0);
/*      */       } 
/*      */       
/*  659 */       if (bool) {
/*  660 */         this.animate = true;
/*      */       }
/*  662 */       return false;
/*      */     } 
/*      */     
/*  665 */     return false;
/*      */   }
/*      */   
/*      */   private int getPageCount() {
/*  669 */     if (getSkinnable().getPageCount() < 1) {
/*  670 */       return 1;
/*      */     }
/*  672 */     return getSkinnable().getPageCount();
/*      */   }
/*      */   
/*      */   private int getMaxPageIndicatorCount() {
/*  676 */     return getSkinnable().getMaxPageIndicatorCount();
/*      */   }
/*      */   
/*      */   private int getCurrentPageIndex() {
/*  680 */     return getSkinnable().getCurrentPageIndex();
/*      */   }
/*      */   
/*      */   private void animateSwitchPage() {
/*  684 */     if (this.timeline != null) {
/*  685 */       this.timeline.setRate(8.0D);
/*  686 */       this.hasPendingAnimation = true;
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  692 */     if (!this.nextStackPane.isVisible() && 
/*  693 */       !createPage(this.nextStackPane, this.currentAnimatedIndex)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  699 */     if (this.nextPageReached) {
/*      */ 
/*      */       
/*  702 */       swapPanes();
/*  703 */       this.nextPageReached = false;
/*      */       
/*      */       return;
/*      */     } 
/*  707 */     this.nextStackPane.setCache(true);
/*  708 */     this.currentStackPane.setCache(true);
/*      */ 
/*      */     
/*  711 */     Platform.runLater(() -> {
/*      */           boolean bool = (this.nextStackPane.getTranslateX() != 0.0D) ? true : false;
/*      */           if (this.currentAnimatedIndex > this.previousIndex) {
/*      */             if (!bool) {
/*      */               this.nextStackPane.setTranslateX(this.currentStackPane.getWidth());
/*      */             }
/*      */             this.nextStackPane.setVisible(true);
/*      */             this.timeline = new Timeline();
/*      */             KeyFrame keyFrame1 = new KeyFrame(Duration.millis(0.0D), new KeyValue[] { new KeyValue(this.currentStackPane.translateXProperty(), (T)Double.valueOf(bool ? this.currentStackPane.getTranslateX() : 0.0D), interpolator), new KeyValue(this.nextStackPane.translateXProperty(), (T)Double.valueOf(bool ? this.nextStackPane.getTranslateX() : this.currentStackPane.getWidth()), interpolator) });
/*      */             KeyFrame keyFrame2 = new KeyFrame(DURATION, this.swipeAnimationEndEventHandler, new KeyValue[] { new KeyValue(this.currentStackPane.translateXProperty(), (T)Double.valueOf(-this.currentStackPane.getWidth()), interpolator), new KeyValue(this.nextStackPane.translateXProperty(), (T)Integer.valueOf(0), interpolator) });
/*      */             this.timeline.getKeyFrames().setAll(new KeyFrame[] { keyFrame1, keyFrame2 });
/*      */             this.timeline.play();
/*      */           } else {
/*      */             if (!bool) {
/*      */               this.nextStackPane.setTranslateX(-this.currentStackPane.getWidth());
/*      */             }
/*      */             this.nextStackPane.setVisible(true);
/*      */             this.timeline = new Timeline();
/*      */             KeyFrame keyFrame1 = new KeyFrame(Duration.millis(0.0D), new KeyValue[] { new KeyValue(this.currentStackPane.translateXProperty(), (T)Double.valueOf(bool ? this.currentStackPane.getTranslateX() : 0.0D), interpolator), new KeyValue(this.nextStackPane.translateXProperty(), (T)Double.valueOf(bool ? this.nextStackPane.getTranslateX() : -this.currentStackPane.getWidth()), interpolator) });
/*      */             KeyFrame keyFrame2 = new KeyFrame(DURATION, this.swipeAnimationEndEventHandler, new KeyValue[] { new KeyValue(this.currentStackPane.translateXProperty(), (T)Double.valueOf(this.currentStackPane.getWidth()), interpolator), new KeyValue(this.nextStackPane.translateXProperty(), (T)Integer.valueOf(0), interpolator) });
/*      */             this.timeline.getKeyFrames().setAll(new KeyFrame[] { keyFrame1, keyFrame2 });
/*      */             this.timeline.play();
/*      */           } 
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void swapPanes() {
/*  757 */     StackPane stackPane = this.currentStackPane;
/*  758 */     this.currentStackPane = this.nextStackPane;
/*  759 */     this.nextStackPane = stackPane;
/*      */     
/*  761 */     this.currentStackPane.setTranslateX(0.0D);
/*  762 */     this.currentStackPane.setCache(false);
/*      */     
/*  764 */     this.nextStackPane.setTranslateX(0.0D);
/*  765 */     this.nextStackPane.setCache(false);
/*  766 */     this.nextStackPane.setVisible(false);
/*  767 */     this.nextStackPane.getChildren().clear();
/*      */   }
/*      */ 
/*      */   
/*      */   private void animateClamping(boolean paramBoolean) {
/*  772 */     if (paramBoolean) {
/*  773 */       this.timeline = new Timeline();
/*      */ 
/*      */       
/*  776 */       KeyFrame keyFrame1 = new KeyFrame(Duration.millis(0.0D), new KeyValue[] { new KeyValue(this.currentStackPane.translateXProperty(), (T)Double.valueOf(this.currentStackPane.getTranslateX()), interpolator), new KeyValue(this.nextStackPane.translateXProperty(), (T)Double.valueOf(this.nextStackPane.getTranslateX()), interpolator) });
/*      */ 
/*      */ 
/*      */       
/*  780 */       KeyFrame keyFrame2 = new KeyFrame(DURATION, this.clampAnimationEndEventHandler, new KeyValue[] { new KeyValue(this.currentStackPane.translateXProperty(), (T)Integer.valueOf(0), interpolator), new KeyValue(this.nextStackPane.translateXProperty(), (T)Double.valueOf(this.currentStackPane.getWidth()), interpolator) });
/*  781 */       this.timeline.getKeyFrames().setAll(new KeyFrame[] { keyFrame1, keyFrame2 });
/*  782 */       this.timeline.play();
/*      */     } else {
/*  784 */       this.timeline = new Timeline();
/*      */ 
/*      */       
/*  787 */       KeyFrame keyFrame1 = new KeyFrame(Duration.millis(0.0D), new KeyValue[] { new KeyValue(this.currentStackPane.translateXProperty(), (T)Double.valueOf(this.currentStackPane.getTranslateX()), interpolator), new KeyValue(this.nextStackPane.translateXProperty(), (T)Double.valueOf(this.nextStackPane.getTranslateX()), interpolator) });
/*      */ 
/*      */ 
/*      */       
/*  791 */       KeyFrame keyFrame2 = new KeyFrame(DURATION, this.clampAnimationEndEventHandler, new KeyValue[] { new KeyValue(this.currentStackPane.translateXProperty(), (T)Integer.valueOf(0), interpolator), new KeyValue(this.nextStackPane.translateXProperty(), (T)Double.valueOf(-this.currentStackPane.getWidth()), interpolator) });
/*  792 */       this.timeline.getKeyFrames().setAll(new KeyFrame[] { keyFrame1, keyFrame2 });
/*  793 */       this.timeline.play();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   class NavigationControl
/*      */     extends StackPane
/*      */   {
/*      */     private HBox controlBox;
/*      */     
/*      */     private Button leftArrowButton;
/*      */     
/*      */     private StackPane leftArrow;
/*      */     
/*      */     private Button rightArrowButton;
/*      */     
/*      */     private StackPane rightArrow;
/*      */     
/*      */     private ToggleGroup indicatorButtons;
/*      */     
/*      */     private Label pageInformation;
/*  814 */     private double minButtonSize = -1.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int previousIndicatorCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void initializeNavigationHandlers() {
/*  884 */       this.leftArrowButton.setOnAction(param1ActionEvent -> {
/*      */             PaginationSkin.this.getNode().requestFocus();
/*      */             
/*      */             PaginationSkin.this.selectPrevious();
/*      */             requestLayout();
/*      */           });
/*  890 */       this.rightArrowButton.setOnAction(param1ActionEvent -> {
/*      */             PaginationSkin.this.getNode().requestFocus();
/*      */             
/*      */             PaginationSkin.this.selectNext();
/*      */             requestLayout();
/*      */           });
/*  896 */       PaginationSkin.this.pagination.currentPageIndexProperty().addListener((param1ObservableValue, param1Number1, param1Number2) -> {
/*      */             PaginationSkin.this.previousIndex = param1Number1.intValue();
/*      */             PaginationSkin.this.currentIndex = param1Number2.intValue();
/*      */             updatePageIndex();
/*      */             if (PaginationSkin.this.animate) {
/*      */               PaginationSkin.this.currentAnimatedIndex = PaginationSkin.this.currentIndex;
/*      */               PaginationSkin.this.animateSwitchPage();
/*      */             } else {
/*      */               PaginationSkin.this.createPage(PaginationSkin.this.currentStackPane, PaginationSkin.this.currentIndex);
/*      */             } 
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     private void initializePageIndicators() {
/*  911 */       this.previousIndicatorCount = 0;
/*  912 */       this.controlBox.getChildren().clear();
/*  913 */       clearIndicatorButtons();
/*      */       
/*  915 */       this.controlBox.getChildren().add(this.leftArrowButton);
/*  916 */       for (int i = PaginationSkin.this.fromIndex; i <= PaginationSkin.this.toIndex; i++) {
/*  917 */         PaginationSkin.IndicatorButton indicatorButton = new PaginationSkin.IndicatorButton(i);
/*  918 */         indicatorButton.setMinSize(this.minButtonSize, this.minButtonSize);
/*  919 */         indicatorButton.setToggleGroup(this.indicatorButtons);
/*  920 */         this.controlBox.getChildren().add(indicatorButton);
/*      */       } 
/*  922 */       this.controlBox.getChildren().add(this.rightArrowButton);
/*      */     }
/*      */     
/*      */     private void clearIndicatorButtons() {
/*  926 */       for (Toggle toggle : this.indicatorButtons.getToggles()) {
/*  927 */         if (toggle instanceof PaginationSkin.IndicatorButton) {
/*  928 */           PaginationSkin.IndicatorButton indicatorButton = (PaginationSkin.IndicatorButton)toggle;
/*  929 */           indicatorButton.release();
/*      */         } 
/*      */       } 
/*  932 */       this.indicatorButtons.getToggles().clear();
/*      */     }
/*      */ 
/*      */     
/*      */     private void updatePageIndicators() {
/*  937 */       for (byte b = 0; b < this.indicatorButtons.getToggles().size(); b++) {
/*  938 */         PaginationSkin.IndicatorButton indicatorButton = (PaginationSkin.IndicatorButton)this.indicatorButtons.getToggles().get(b);
/*  939 */         if (indicatorButton.getPageNumber() == PaginationSkin.this.currentIndex) {
/*  940 */           indicatorButton.setSelected(true);
/*  941 */           updatePageInformation();
/*      */           break;
/*      */         } 
/*      */       } 
/*  945 */       PaginationSkin.this.getSkinnable().notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_ITEM);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updatePageIndex() {
/*  952 */       if (PaginationSkin.this.pageCount == PaginationSkin.this.maxPageIndicatorCount && 
/*  953 */         changePageSet()) {
/*  954 */         initializePageIndicators();
/*      */       }
/*      */       
/*  957 */       updatePageIndicators();
/*  958 */       requestLayout();
/*      */     }
/*      */     
/*      */     private void updatePageInformation() {
/*  962 */       String str1 = Integer.toString(PaginationSkin.this.currentIndex + 1);
/*  963 */       String str2 = (PaginationSkin.this.getPageCount() == Integer.MAX_VALUE) ? "..." : Integer.toString(PaginationSkin.this.getPageCount());
/*  964 */       this.pageInformation.setText(str1 + "/" + str1);
/*      */     }
/*      */     
/*  967 */     public NavigationControl() { this.previousIndicatorCount = 0; getStyleClass().setAll(new String[] { "pagination-control" }); Objects.requireNonNull(PaginationSkin.this.behavior); addEventHandler(MouseEvent.MOUSE_PRESSED, PaginationSkin.this.behavior::mousePressed); this.controlBox = new HBox(); this.controlBox.getStyleClass().add("control-box"); this.leftArrowButton = new Button(); this.leftArrowButton.setAccessibleText(ControlResources.getString("Accessibility.title.Pagination.PreviousButton")); this.minButtonSize = this.leftArrowButton.getFont().getSize() * 2.0D; this.leftArrowButton.fontProperty().addListener((param1ObservableValue, param1Font1, param1Font2) -> { this.minButtonSize = param1Font2.getSize() * 2.0D; for (Node node : this.controlBox.getChildren())
/*      */               ((Control)node).setMinSize(this.minButtonSize, this.minButtonSize);  requestLayout(); }); this.leftArrowButton.setMinSize(this.minButtonSize, this.minButtonSize); this.leftArrowButton.prefWidthProperty().bind(this.leftArrowButton.minWidthProperty()); this.leftArrowButton.prefHeightProperty().bind(this.leftArrowButton.minHeightProperty()); this.leftArrowButton.getStyleClass().add("left-arrow-button"); this.leftArrowButton.setFocusTraversable(false); HBox.setMargin(this.leftArrowButton, new Insets(0.0D, snapSize(PaginationSkin.this.arrowButtonGap.get()), 0.0D, 0.0D)); this.leftArrow = new StackPane(); this.leftArrow.setMaxSize(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY); this.leftArrowButton.setGraphic(this.leftArrow); this.leftArrow.getStyleClass().add("left-arrow"); this.rightArrowButton = new Button(); this.rightArrowButton.setAccessibleText(ControlResources.getString("Accessibility.title.Pagination.NextButton")); this.rightArrowButton.setMinSize(this.minButtonSize, this.minButtonSize); this.rightArrowButton.prefWidthProperty().bind(this.rightArrowButton.minWidthProperty()); this.rightArrowButton.prefHeightProperty().bind(this.rightArrowButton.minHeightProperty()); this.rightArrowButton.getStyleClass().add("right-arrow-button"); this.rightArrowButton.setFocusTraversable(false); HBox.setMargin(this.rightArrowButton, new Insets(0.0D, 0.0D, 0.0D, snapSize(PaginationSkin.this.arrowButtonGap.get()))); this.rightArrow = new StackPane(); this.rightArrow.setMaxSize(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY); this.rightArrowButton.setGraphic(this.rightArrow); this.rightArrow.getStyleClass().add("right-arrow"); this.indicatorButtons = new ToggleGroup(); this.pageInformation = new Label(); this.pageInformation.getStyleClass().add("page-information"); getChildren().addAll(new Node[] { this.controlBox, this.pageInformation }); initializeNavigationHandlers(); initializePageIndicators(); updatePageIndex(); PaginationSkin.this.arrowButtonGap.addListener((param1ObservableValue, param1Number1, param1Number2) -> { if (param1Number2.doubleValue() == 0.0D) { HBox.setMargin(this.leftArrowButton, (Insets)null); HBox.setMargin(this.rightArrowButton, (Insets)null); }
/*      */             else { HBox.setMargin(this.leftArrowButton, new Insets(0.0D, snapSize(param1Number2.doubleValue()), 0.0D, 0.0D)); HBox.setMargin(this.rightArrowButton, new Insets(0.0D, 0.0D, 0.0D, snapSize(param1Number2.doubleValue()))); }
/*      */           
/*  971 */           }); } private void layoutPageIndicators() { double d1 = snappedLeftInset();
/*  972 */       double d2 = snappedRightInset();
/*  973 */       double d3 = snapSize(getWidth()) - d1 + d2;
/*  974 */       double d4 = this.controlBox.snappedLeftInset();
/*  975 */       double d5 = this.controlBox.snappedRightInset();
/*  976 */       double d6 = snapSize(Utils.boundedSize(this.leftArrowButton.prefWidth(-1.0D), this.leftArrowButton.minWidth(-1.0D), this.leftArrowButton.maxWidth(-1.0D)));
/*  977 */       double d7 = snapSize(Utils.boundedSize(this.rightArrowButton.prefWidth(-1.0D), this.rightArrowButton.minWidth(-1.0D), this.rightArrowButton.maxWidth(-1.0D)));
/*  978 */       double d8 = snapSize(this.controlBox.getSpacing());
/*  979 */       double d9 = d3 - d4 + d6 + 2.0D * PaginationSkin.this.arrowButtonGap.get() + d8 + d7 + d5;
/*      */       
/*  981 */       if (PaginationSkin.this.isPageInformationVisible() && (Side.LEFT
/*  982 */         .equals(PaginationSkin.this.getPageInformationAlignment()) || Side.RIGHT
/*  983 */         .equals(PaginationSkin.this.getPageInformationAlignment()))) {
/*  984 */         d9 -= snapSize(this.pageInformation.prefWidth(-1.0D));
/*      */       }
/*      */       
/*  987 */       double d10 = 0.0D;
/*  988 */       byte b = 0; int i;
/*  989 */       for (i = 0; i < PaginationSkin.this.getMaxPageIndicatorCount(); i++) {
/*  990 */         boolean bool = (i < this.indicatorButtons.getToggles().size()) ? i : (this.indicatorButtons.getToggles().size() - 1);
/*  991 */         double d = this.minButtonSize;
/*  992 */         if (bool != -1) {
/*  993 */           PaginationSkin.IndicatorButton indicatorButton = (PaginationSkin.IndicatorButton)this.indicatorButtons.getToggles().get(bool);
/*  994 */           d = snapSize(Utils.boundedSize(indicatorButton.prefWidth(-1.0D), indicatorButton.minWidth(-1.0D), indicatorButton.maxWidth(-1.0D)));
/*      */         } 
/*      */         
/*  997 */         d10 += d + d8;
/*  998 */         if (d10 > d9) {
/*      */           break;
/*      */         }
/* 1001 */         b++;
/*      */       } 
/* 1003 */       if (b == 0) {
/* 1004 */         b = 1;
/*      */       }
/*      */ 
/*      */       
/* 1008 */       if (b != this.previousIndicatorCount) {
/* 1009 */         if (b < PaginationSkin.this.getMaxPageIndicatorCount()) {
/* 1010 */           PaginationSkin.this.maxPageIndicatorCount = b;
/*      */         } else {
/* 1012 */           PaginationSkin.this.maxPageIndicatorCount = PaginationSkin.this.getMaxPageIndicatorCount();
/*      */         } 
/*      */ 
/*      */         
/* 1016 */         if (PaginationSkin.this.pageCount > PaginationSkin.this.maxPageIndicatorCount) {
/* 1017 */           PaginationSkin.this.pageCount = PaginationSkin.this.maxPageIndicatorCount;
/* 1018 */           i = PaginationSkin.this.maxPageIndicatorCount - 1;
/*      */         }
/* 1020 */         else if (b > PaginationSkin.this.getPageCount()) {
/* 1021 */           PaginationSkin.this.pageCount = PaginationSkin.this.getPageCount();
/* 1022 */           i = PaginationSkin.this.getPageCount() - 1;
/*      */         } else {
/* 1024 */           PaginationSkin.this.pageCount = b;
/* 1025 */           i = b - 1;
/*      */         } 
/*      */ 
/*      */         
/* 1029 */         if (PaginationSkin.this.currentIndex >= PaginationSkin.this.toIndex) {
/*      */           
/* 1031 */           PaginationSkin.this.toIndex = PaginationSkin.this.currentIndex;
/* 1032 */           PaginationSkin.this.fromIndex = PaginationSkin.this.toIndex - i;
/* 1033 */         } else if (PaginationSkin.this.currentIndex <= PaginationSkin.this.fromIndex) {
/*      */           
/* 1035 */           PaginationSkin.this.fromIndex = PaginationSkin.this.currentIndex;
/* 1036 */           PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + i;
/*      */         } else {
/* 1038 */           PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + i;
/*      */         } 
/*      */         
/* 1041 */         if (PaginationSkin.this.toIndex > PaginationSkin.this.getPageCount() - 1) {
/* 1042 */           PaginationSkin.this.toIndex = PaginationSkin.this.getPageCount() - 1;
/*      */         }
/*      */ 
/*      */         
/* 1046 */         if (PaginationSkin.this.fromIndex < 0) {
/* 1047 */           PaginationSkin.this.fromIndex = 0;
/* 1048 */           PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + i;
/*      */         } 
/*      */         
/* 1051 */         initializePageIndicators();
/* 1052 */         updatePageIndicators();
/* 1053 */         this.previousIndicatorCount = b;
/*      */       }  }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean changePageSet() {
/* 1060 */       int i = indexToIndicatorButtonsIndex(PaginationSkin.this.currentIndex);
/* 1061 */       int j = PaginationSkin.this.maxPageIndicatorCount - 1;
/* 1062 */       if (PaginationSkin.this.previousIndex < PaginationSkin.this.currentIndex && i == 0 && j != 0 && i % j == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1067 */         PaginationSkin.this.fromIndex = PaginationSkin.this.currentIndex;
/* 1068 */         PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + j;
/* 1069 */       } else if (PaginationSkin.this.currentIndex < PaginationSkin.this.previousIndex && i == j && j != 0 && i % j == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1074 */         PaginationSkin.this.toIndex = PaginationSkin.this.currentIndex;
/* 1075 */         PaginationSkin.this.fromIndex = PaginationSkin.this.toIndex - j;
/*      */ 
/*      */       
/*      */       }
/* 1079 */       else if (PaginationSkin.this.currentIndex < PaginationSkin.this.fromIndex || PaginationSkin.this.currentIndex > PaginationSkin.this.toIndex) {
/* 1080 */         PaginationSkin.this.fromIndex = PaginationSkin.this.currentIndex - i;
/* 1081 */         PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + j;
/*      */       } else {
/* 1083 */         return false;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1088 */       if (PaginationSkin.this.toIndex > PaginationSkin.this.getPageCount() - 1) {
/* 1089 */         if (PaginationSkin.this.fromIndex > PaginationSkin.this.getPageCount() - 1) {
/* 1090 */           return false;
/*      */         }
/* 1092 */         PaginationSkin.this.toIndex = PaginationSkin.this.getPageCount() - 1;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1098 */       if (PaginationSkin.this.fromIndex < 0) {
/* 1099 */         PaginationSkin.this.fromIndex = 0;
/* 1100 */         PaginationSkin.this.toIndex = PaginationSkin.this.fromIndex + j;
/*      */       } 
/* 1102 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     private int indexToIndicatorButtonsIndex(int param1Int) {
/* 1107 */       if (param1Int >= PaginationSkin.this.fromIndex && param1Int <= PaginationSkin.this.toIndex) {
/* 1108 */         return param1Int - PaginationSkin.this.fromIndex;
/*      */       }
/*      */ 
/*      */       
/* 1112 */       int i = 0;
/* 1113 */       int j = PaginationSkin.this.fromIndex;
/* 1114 */       int k = PaginationSkin.this.toIndex;
/* 1115 */       if (PaginationSkin.this.currentIndex > PaginationSkin.this.previousIndex) {
/* 1116 */         while (j < PaginationSkin.this.getPageCount() && k < PaginationSkin.this.getPageCount()) {
/* 1117 */           j += i;
/* 1118 */           k += i;
/* 1119 */           if (param1Int >= j && param1Int <= k) {
/* 1120 */             if (param1Int == j)
/* 1121 */               return 0; 
/* 1122 */             if (param1Int == k) {
/* 1123 */               return PaginationSkin.this.maxPageIndicatorCount - 1;
/*      */             }
/* 1125 */             return param1Int - j;
/*      */           } 
/* 1127 */           i += PaginationSkin.this.maxPageIndicatorCount;
/*      */         } 
/*      */       } else {
/* 1130 */         while (j > 0 && k > 0) {
/* 1131 */           j -= i;
/* 1132 */           k -= i;
/* 1133 */           if (param1Int >= j && param1Int <= k) {
/* 1134 */             if (param1Int == j)
/* 1135 */               return 0; 
/* 1136 */             if (param1Int == k) {
/* 1137 */               return PaginationSkin.this.maxPageIndicatorCount - 1;
/*      */             }
/* 1139 */             return param1Int - j;
/*      */           } 
/* 1141 */           i += PaginationSkin.this.maxPageIndicatorCount;
/*      */         } 
/*      */       } 
/*      */       
/* 1145 */       return PaginationSkin.this.maxPageIndicatorCount - 1;
/*      */     }
/*      */     
/*      */     private Pos sideToPos(Side param1Side) {
/* 1149 */       if (Side.TOP.equals(param1Side))
/* 1150 */         return Pos.TOP_CENTER; 
/* 1151 */       if (Side.RIGHT.equals(param1Side))
/* 1152 */         return Pos.CENTER_RIGHT; 
/* 1153 */       if (Side.BOTTOM.equals(param1Side)) {
/* 1154 */         return Pos.BOTTOM_CENTER;
/*      */       }
/* 1156 */       return Pos.CENTER_LEFT;
/*      */     }
/*      */     
/*      */     protected double computeMinWidth(double param1Double) {
/* 1160 */       double d1 = snappedLeftInset();
/* 1161 */       double d2 = snappedRightInset();
/* 1162 */       double d3 = snapSize(Utils.boundedSize(this.leftArrowButton.prefWidth(-1.0D), this.leftArrowButton.minWidth(-1.0D), this.leftArrowButton.maxWidth(-1.0D)));
/* 1163 */       double d4 = snapSize(Utils.boundedSize(this.rightArrowButton.prefWidth(-1.0D), this.rightArrowButton.minWidth(-1.0D), this.rightArrowButton.maxWidth(-1.0D)));
/* 1164 */       double d5 = snapSize(this.controlBox.getSpacing());
/* 1165 */       double d6 = 0.0D;
/* 1166 */       Side side = PaginationSkin.this.getPageInformationAlignment();
/* 1167 */       if (Side.LEFT.equals(side) || Side.RIGHT.equals(side)) {
/* 1168 */         d6 = snapSize(this.pageInformation.prefWidth(-1.0D));
/*      */       }
/* 1170 */       double d7 = PaginationSkin.this.arrowButtonGap.get();
/*      */       
/* 1172 */       return d1 + d3 + 2.0D * d7 + this.minButtonSize + 2.0D * d5 + d4 + d2 + d6;
/*      */     }
/*      */ 
/*      */     
/*      */     protected double computeMinHeight(double param1Double) {
/* 1177 */       return computePrefHeight(param1Double);
/*      */     }
/*      */     
/*      */     protected double computePrefWidth(double param1Double) {
/* 1181 */       double d1 = snappedLeftInset();
/* 1182 */       double d2 = snappedRightInset();
/* 1183 */       double d3 = snapSize(this.controlBox.prefWidth(param1Double));
/* 1184 */       double d4 = 0.0D;
/* 1185 */       Side side = PaginationSkin.this.getPageInformationAlignment();
/* 1186 */       if (Side.LEFT.equals(side) || Side.RIGHT.equals(side)) {
/* 1187 */         d4 = snapSize(this.pageInformation.prefWidth(-1.0D));
/*      */       }
/*      */       
/* 1190 */       return d1 + d3 + d2 + d4;
/*      */     }
/*      */     
/*      */     protected double computePrefHeight(double param1Double) {
/* 1194 */       double d1 = snappedTopInset();
/* 1195 */       double d2 = snappedBottomInset();
/* 1196 */       double d3 = snapSize(this.controlBox.prefHeight(param1Double));
/* 1197 */       double d4 = 0.0D;
/* 1198 */       Side side = PaginationSkin.this.getPageInformationAlignment();
/* 1199 */       if (Side.TOP.equals(side) || Side.BOTTOM.equals(side)) {
/* 1200 */         d4 = snapSize(this.pageInformation.prefHeight(-1.0D));
/*      */       }
/*      */       
/* 1203 */       return d1 + d3 + d4 + d2;
/*      */     }
/*      */     
/*      */     protected void layoutChildren() {
/* 1207 */       double d1 = snappedTopInset();
/* 1208 */       double d2 = snappedBottomInset();
/* 1209 */       double d3 = snappedLeftInset();
/* 1210 */       double d4 = snappedRightInset();
/* 1211 */       double d5 = snapSize(getWidth()) - d3 + d4;
/* 1212 */       double d6 = snapSize(getHeight()) - d1 + d2;
/* 1213 */       double d7 = snapSize(this.controlBox.prefWidth(-1.0D));
/* 1214 */       double d8 = snapSize(this.controlBox.prefHeight(-1.0D));
/* 1215 */       double d9 = snapSize(this.pageInformation.prefWidth(-1.0D));
/* 1216 */       double d10 = snapSize(this.pageInformation.prefHeight(-1.0D));
/*      */       
/* 1218 */       this.leftArrowButton.setDisable(false);
/* 1219 */       this.rightArrowButton.setDisable(false);
/*      */       
/* 1221 */       if (PaginationSkin.this.currentIndex == 0)
/*      */       {
/* 1223 */         this.leftArrowButton.setDisable(true);
/*      */       }
/* 1225 */       if (PaginationSkin.this.currentIndex == PaginationSkin.this.getPageCount() - 1)
/*      */       {
/* 1227 */         this.rightArrowButton.setDisable(true);
/*      */       }
/*      */ 
/*      */       
/* 1231 */       applyCss();
/*      */       
/* 1233 */       this.leftArrowButton.setVisible(PaginationSkin.this.isArrowsVisible());
/* 1234 */       this.rightArrowButton.setVisible(PaginationSkin.this.isArrowsVisible());
/* 1235 */       this.pageInformation.setVisible(PaginationSkin.this.isPageInformationVisible());
/*      */ 
/*      */       
/* 1238 */       layoutPageIndicators();
/*      */       
/* 1240 */       HPos hPos = this.controlBox.getAlignment().getHpos();
/* 1241 */       VPos vPos = this.controlBox.getAlignment().getVpos();
/* 1242 */       double d11 = d3 + Utils.computeXOffset(d5, d7, hPos);
/* 1243 */       double d12 = d1 + Utils.computeYOffset(d6, d8, vPos);
/*      */       
/* 1245 */       if (PaginationSkin.this.isPageInformationVisible()) {
/* 1246 */         Pos pos = sideToPos(PaginationSkin.this.getPageInformationAlignment());
/* 1247 */         HPos hPos1 = pos.getHpos();
/* 1248 */         VPos vPos1 = pos.getVpos();
/* 1249 */         double d13 = d3 + Utils.computeXOffset(d5, d9, hPos1);
/* 1250 */         double d14 = d1 + Utils.computeYOffset(d6, d10, vPos1);
/*      */         
/* 1252 */         if (Side.TOP.equals(PaginationSkin.this.getPageInformationAlignment())) {
/* 1253 */           d14 = d1;
/* 1254 */           d12 = d1 + d10;
/* 1255 */         } else if (Side.RIGHT.equals(PaginationSkin.this.getPageInformationAlignment())) {
/* 1256 */           d13 = d5 - d4 - d9;
/* 1257 */         } else if (Side.BOTTOM.equals(PaginationSkin.this.getPageInformationAlignment())) {
/* 1258 */           d12 = d1;
/* 1259 */           d14 = d1 + d8;
/* 1260 */         } else if (Side.LEFT.equals(PaginationSkin.this.getPageInformationAlignment())) {
/* 1261 */           d13 = d3;
/*      */         } 
/* 1263 */         layoutInArea(this.pageInformation, d13, d14, d9, d10, 0.0D, hPos1, vPos1);
/*      */       } 
/*      */       
/* 1266 */       layoutInArea(this.controlBox, d11, d12, d7, d8, 0.0D, hPos, vPos);
/*      */     } }
/*      */   
/*      */   class IndicatorButton extends ToggleButton { private final ListChangeListener<String> updateSkinIndicatorType = param1Change -> setIndicatorType();
/*      */     private final ChangeListener<Boolean> updateTooltipVisibility;
/*      */     private int pageNumber;
/*      */     
/*      */     public IndicatorButton(int param1Int) {
/* 1274 */       this.updateTooltipVisibility = ((param1ObservableValue, param1Boolean1, param1Boolean2) -> setTooltipVisible(param1Boolean2.booleanValue()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1280 */       this.pageNumber = param1Int;
/* 1281 */       setFocusTraversable(false);
/* 1282 */       setIndicatorType();
/* 1283 */       setTooltipVisible(PaginationSkin.this.isTooltipVisible());
/*      */       
/* 1285 */       PaginationSkin.this.getSkinnable().getStyleClass().addListener(this.updateSkinIndicatorType);
/*      */       
/* 1287 */       setOnAction(param1ActionEvent -> {
/*      */             PaginationSkin.this.getNode().requestFocus();
/*      */             
/*      */             int i = PaginationSkin.this.getCurrentPageIndex();
/*      */             
/*      */             if (i != this.pageNumber) {
/*      */               PaginationSkin.this.pagination.setCurrentPageIndex(this.pageNumber);
/*      */               requestLayout();
/*      */             } 
/*      */           });
/* 1297 */       PaginationSkin.this.tooltipVisibleProperty().addListener(this.updateTooltipVisibility);
/*      */       
/* 1299 */       prefHeightProperty().bind(minHeightProperty());
/* 1300 */       setAccessibleRole(AccessibleRole.PAGE_ITEM);
/*      */     }
/*      */     
/*      */     private void setIndicatorType() {
/* 1304 */       if (PaginationSkin.this.getSkinnable().getStyleClass().contains("bullet")) {
/* 1305 */         getStyleClass().remove("number-button");
/* 1306 */         getStyleClass().add("bullet-button");
/* 1307 */         setText((String)null);
/*      */ 
/*      */         
/* 1310 */         prefWidthProperty().bind(minWidthProperty());
/*      */       } else {
/* 1312 */         getStyleClass().remove("bullet-button");
/* 1313 */         getStyleClass().add("number-button");
/* 1314 */         setText(Integer.toString(this.pageNumber + 1));
/*      */ 
/*      */         
/* 1317 */         prefWidthProperty().unbind();
/*      */       } 
/*      */     }
/*      */     
/*      */     private void setTooltipVisible(boolean param1Boolean) {
/* 1322 */       if (param1Boolean) {
/* 1323 */         setTooltip(new Tooltip(Integer.toString(this.pageNumber + 1)));
/*      */       } else {
/* 1325 */         setTooltip((Tooltip)null);
/*      */       } 
/*      */     }
/*      */     
/*      */     public int getPageNumber() {
/* 1330 */       return this.pageNumber;
/*      */     }
/*      */ 
/*      */     
/*      */     public void fire() {
/* 1335 */       if (getToggleGroup() == null || !isSelected()) {
/* 1336 */         super.fire();
/*      */       }
/*      */     }
/*      */     
/*      */     public void release() {
/* 1341 */       PaginationSkin.this.getSkinnable().getStyleClass().removeListener(this.updateSkinIndicatorType);
/* 1342 */       PaginationSkin.this.tooltipVisibleProperty().removeListener(this.updateTooltipVisibility);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Object queryAccessibleAttribute(AccessibleAttribute param1AccessibleAttribute, Object... param1VarArgs) {
/* 1348 */       switch (param1AccessibleAttribute) { case null:
/* 1349 */           return getText();
/* 1350 */         case null: return Boolean.valueOf(isSelected()); }
/* 1351 */        return super.queryAccessibleAttribute(param1AccessibleAttribute, param1VarArgs);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void executeAccessibleAction(AccessibleAction param1AccessibleAction, Object... param1VarArgs) {
/* 1358 */       switch (param1AccessibleAction) {
/*      */         case REQUEST_FOCUS:
/* 1360 */           PaginationSkin.this.getSkinnable().setCurrentPageIndex(this.pageNumber); return;
/*      */       } 
/* 1362 */       super.executeAccessibleAction(param1AccessibleAction, new Object[0]);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1373 */   private static final Boolean DEFAULT_ARROW_VISIBLE = Boolean.FALSE;
/* 1374 */   private static final Boolean DEFAULT_PAGE_INFORMATION_VISIBLE = Boolean.FALSE;
/* 1375 */   private static final Side DEFAULT_PAGE_INFORMATION_ALIGNMENT = Side.BOTTOM;
/* 1376 */   private static final Boolean DEFAULT_TOOLTIP_VISIBLE = Boolean.FALSE;
/*      */   
/*      */   private static class StyleableProperties {
/* 1379 */     private static final CssMetaData<Pagination, Boolean> ARROWS_VISIBLE = new CssMetaData<Pagination, Boolean>("-fx-arrows-visible", 
/*      */         
/* 1381 */         BooleanConverter.getInstance(), PaginationSkin.DEFAULT_ARROW_VISIBLE)
/*      */       {
/*      */         public boolean isSettable(Pagination param2Pagination)
/*      */         {
/* 1385 */           PaginationSkin paginationSkin = (PaginationSkin)param2Pagination.getSkin();
/* 1386 */           return (paginationSkin.arrowsVisible == null || !paginationSkin.arrowsVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(Pagination param2Pagination) {
/* 1391 */           PaginationSkin paginationSkin = (PaginationSkin)param2Pagination.getSkin();
/* 1392 */           return (StyleableProperty<Boolean>)paginationSkin.arrowsVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/* 1396 */     private static final CssMetaData<Pagination, Boolean> PAGE_INFORMATION_VISIBLE = new CssMetaData<Pagination, Boolean>("-fx-page-information-visible", 
/*      */         
/* 1398 */         BooleanConverter.getInstance(), PaginationSkin.DEFAULT_PAGE_INFORMATION_VISIBLE)
/*      */       {
/*      */         public boolean isSettable(Pagination param2Pagination)
/*      */         {
/* 1402 */           PaginationSkin paginationSkin = (PaginationSkin)param2Pagination.getSkin();
/* 1403 */           return (paginationSkin.pageInformationVisible == null || !paginationSkin.pageInformationVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(Pagination param2Pagination) {
/* 1408 */           PaginationSkin paginationSkin = (PaginationSkin)param2Pagination.getSkin();
/* 1409 */           return (StyleableProperty<Boolean>)paginationSkin.pageInformationVisibleProperty();
/*      */         }
/*      */       };
/*      */     
/* 1413 */     private static final CssMetaData<Pagination, Side> PAGE_INFORMATION_ALIGNMENT = new CssMetaData<Pagination, Side>("-fx-page-information-alignment", (StyleConverter)new EnumConverter(Side.class), PaginationSkin
/*      */         
/* 1415 */         .DEFAULT_PAGE_INFORMATION_ALIGNMENT)
/*      */       {
/*      */         public boolean isSettable(Pagination param2Pagination)
/*      */         {
/* 1419 */           PaginationSkin paginationSkin = (PaginationSkin)param2Pagination.getSkin();
/* 1420 */           return (paginationSkin.pageInformationAlignment == null || !paginationSkin.pageInformationAlignment.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Side> getStyleableProperty(Pagination param2Pagination) {
/* 1425 */           PaginationSkin paginationSkin = (PaginationSkin)param2Pagination.getSkin();
/* 1426 */           return (StyleableProperty<Side>)paginationSkin.pageInformationAlignmentProperty();
/*      */         }
/*      */       };
/*      */     
/* 1430 */     private static final CssMetaData<Pagination, Boolean> TOOLTIP_VISIBLE = new CssMetaData<Pagination, Boolean>("-fx-tooltip-visible", 
/*      */         
/* 1432 */         BooleanConverter.getInstance(), PaginationSkin.DEFAULT_TOOLTIP_VISIBLE)
/*      */       {
/*      */         public boolean isSettable(Pagination param2Pagination)
/*      */         {
/* 1436 */           PaginationSkin paginationSkin = (PaginationSkin)param2Pagination.getSkin();
/* 1437 */           return (paginationSkin.tooltipVisible == null || !paginationSkin.tooltipVisible.isBound());
/*      */         }
/*      */ 
/*      */         
/*      */         public StyleableProperty<Boolean> getStyleableProperty(Pagination param2Pagination) {
/* 1442 */           PaginationSkin paginationSkin = (PaginationSkin)param2Pagination.getSkin();
/* 1443 */           return (StyleableProperty<Boolean>)paginationSkin.tooltipVisibleProperty();
/*      */         }
/*      */       };
/* 1446 */     private static final CssMetaData<Pagination, Number> ARROW_BUTTON_GAP = new CssMetaData<Pagination, Number>("-fx-arrow-button-gap", 
/* 1447 */         SizeConverter.getInstance(), Integer.valueOf(4)) {
/*      */         public boolean isSettable(Pagination param2Pagination) {
/* 1449 */           PaginationSkin paginationSkin = (PaginationSkin)param2Pagination.getSkin();
/* 1450 */           return (paginationSkin.arrowButtonGap == null || 
/* 1451 */             !paginationSkin.arrowButtonGap.isBound());
/*      */         }
/*      */         public StyleableProperty<Number> getStyleableProperty(Pagination param2Pagination) {
/* 1454 */           PaginationSkin paginationSkin = (PaginationSkin)param2Pagination.getSkin();
/* 1455 */           return (StyleableProperty<Number>)paginationSkin.arrowButtonGapProperty();
/*      */         }
/*      */       };
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/* 1462 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(SkinBase.getClassCssMetaData());
/* 1463 */       arrayList.add(ARROWS_VISIBLE);
/* 1464 */       arrayList.add(PAGE_INFORMATION_VISIBLE);
/* 1465 */       arrayList.add(PAGE_INFORMATION_ALIGNMENT);
/* 1466 */       arrayList.add(TOOLTIP_VISIBLE);
/* 1467 */       arrayList.add(ARROW_BUTTON_GAP);
/* 1468 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 1479 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 1487 */     return getClassCssMetaData();
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\PaginationSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */