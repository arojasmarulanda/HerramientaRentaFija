/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.control.Separator;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.layout.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SeparatorSkin
/*     */   extends SkinBase<Separator>
/*     */ {
/*     */   private static final double DEFAULT_LENGTH = 10.0D;
/*     */   private final Region line;
/*     */   
/*     */   public SeparatorSkin(Separator paramSeparator) {
/*  93 */     super(paramSeparator);
/*     */     
/*  95 */     this.line = new Region();
/*  96 */     this.line.getStyleClass().setAll(new String[] { "line" });
/*     */     
/*  98 */     getChildren().add(this.line);
/*  99 */     registerChangeListener(paramSeparator.orientationProperty(), paramObservableValue -> getSkinnable().requestLayout());
/* 100 */     registerChangeListener(paramSeparator.halignmentProperty(), paramObservableValue -> getSkinnable().requestLayout());
/* 101 */     registerChangeListener(paramSeparator.valignmentProperty(), paramObservableValue -> getSkinnable().requestLayout());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 125 */     Separator separator = getSkinnable();
/*     */     
/* 127 */     if (separator.getOrientation() == Orientation.HORIZONTAL) {
/*     */       
/* 129 */       this.line.resize(paramDouble3, this.line.prefHeight(-1.0D));
/*     */     } else {
/*     */       
/* 132 */       this.line.resize(this.line.prefWidth(-1.0D), paramDouble4);
/*     */     } 
/*     */ 
/*     */     
/* 136 */     positionInArea(this.line, paramDouble1, paramDouble2, paramDouble3, paramDouble4, 0.0D, separator.getHalignment(), separator.getValignment());
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 141 */     return computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 146 */     return computePrefHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 151 */     Separator separator = getSkinnable();
/* 152 */     double d = (separator.getOrientation() == Orientation.VERTICAL) ? this.line.prefWidth(-1.0D) : 10.0D;
/* 153 */     return d + paramDouble5 + paramDouble3;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 158 */     Separator separator = getSkinnable();
/* 159 */     double d = (separator.getOrientation() == Orientation.VERTICAL) ? 10.0D : this.line.prefHeight(-1.0D);
/* 160 */     return d + paramDouble2 + paramDouble4;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 165 */     Separator separator = getSkinnable();
/* 166 */     return (separator.getOrientation() == Orientation.VERTICAL) ? separator.prefWidth(paramDouble1) : Double.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 171 */     Separator separator = getSkinnable();
/* 172 */     return (separator.getOrientation() == Orientation.VERTICAL) ? Double.MAX_VALUE : separator.prefHeight(paramDouble1);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\SeparatorSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */