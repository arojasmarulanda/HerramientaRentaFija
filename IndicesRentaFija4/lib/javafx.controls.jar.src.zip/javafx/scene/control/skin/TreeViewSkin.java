/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.TreeViewBehavior;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.event.WeakEventHandler;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.FocusModel;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.control.TreeCell;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeView;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.scene.layout.StackPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeViewSkin<T>
/*     */   extends VirtualContainerBase<TreeView<T>, TreeCell<T>>
/*     */ {
/*  75 */   private static final boolean IS_PANNABLE = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.scene.control.skin.TreeViewSkin.pannable")))).booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final VirtualFlow<TreeCell<T>> flow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WeakReference<TreeItem<T>> weakRoot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final TreeViewBehavior<T> behavior;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MapChangeListener<Object, Object> propertiesMapListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EventHandler<TreeItem.TreeModificationEvent<T>> rootListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WeakEventHandler<TreeItem.TreeModificationEvent<T>> weakRootListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeViewSkin(TreeView<T> paramTreeView) {
/* 153 */     super(paramTreeView); this.propertiesMapListener = (paramChange -> { if (!paramChange.wasAdded())
/*     */           return;  if ("recreateKey".equals(paramChange.getKey())) { requestRebuildCells(); getSkinnable().getProperties().remove("recreateKey"); }  }); this.rootListener = (paramTreeModificationEvent -> { if (paramTreeModificationEvent.wasAdded() && paramTreeModificationEvent.wasRemoved() && paramTreeModificationEvent.getAddedSize() == paramTreeModificationEvent.getRemovedSize()) { markItemCountDirty(); getSkinnable().requestLayout(); } else if (paramTreeModificationEvent.getEventType().equals(TreeItem.valueChangedEvent())) { requestRebuildCells(); } else { for (EventType<? extends Event> eventType = paramTreeModificationEvent.getEventType(); eventType != null; eventType = (EventType)eventType.getSuperType()) { if (eventType.equals(TreeItem.expandedItemCountChangeEvent())) { markItemCountDirty(); getSkinnable().requestLayout(); break; }  }  }
/*     */          getSkinnable().edit((TreeItem<T>)null);
/* 156 */       }); this.behavior = new TreeViewBehavior<>(paramTreeView);
/*     */ 
/*     */ 
/*     */     
/* 160 */     this.flow = getVirtualFlow();
/* 161 */     this.flow.setPannable(IS_PANNABLE);
/* 162 */     this.flow.setCellFactory(this::createCell);
/* 163 */     this.flow.setFixedCellSize(paramTreeView.getFixedCellSize());
/* 164 */     getChildren().add(this.flow);
/*     */     
/* 166 */     setRoot(getSkinnable().getRoot());
/*     */     
/* 168 */     EventHandler eventHandler = paramMouseEvent -> {
/*     */         if (paramTreeView.getEditingItem() != null) {
/*     */           paramTreeView.edit((TreeItem)null);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         if (paramTreeView.isFocusTraversable()) {
/*     */           paramTreeView.requestFocus();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     this.flow.getVbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
/* 186 */     this.flow.getHbar().addEventFilter(MouseEvent.MOUSE_PRESSED, eventHandler);
/*     */     
/* 188 */     ObservableMap<Object, Object> observableMap = paramTreeView.getProperties();
/* 189 */     observableMap.remove("recreateKey");
/* 190 */     observableMap.addListener(this.propertiesMapListener);
/*     */ 
/*     */     
/* 193 */     this.behavior.setOnFocusPreviousRow(() -> onFocusPreviousCell());
/* 194 */     this.behavior.setOnFocusNextRow(() -> onFocusNextCell());
/* 195 */     this.behavior.setOnMoveToFirstCell(() -> onMoveToFirstCell());
/* 196 */     this.behavior.setOnMoveToLastCell(() -> onMoveToLastCell());
/* 197 */     this.behavior.setOnScrollPageDown(this::onScrollPageDown);
/* 198 */     this.behavior.setOnScrollPageUp(this::onScrollPageUp);
/* 199 */     this.behavior.setOnSelectPreviousRow(() -> onSelectPreviousCell());
/* 200 */     this.behavior.setOnSelectNextRow(() -> onSelectNextCell());
/*     */     
/* 202 */     registerChangeListener(paramTreeView.rootProperty(), paramObservableValue -> setRoot(getSkinnable().getRoot()));
/* 203 */     registerChangeListener(paramTreeView.showRootProperty(), paramObservableValue -> {
/*     */           if (!getSkinnable().isShowRoot() && getRoot() != null) {
/*     */             getRoot().setExpanded(true);
/*     */           }
/*     */ 
/*     */           
/*     */           updateItemCount();
/*     */         });
/*     */ 
/*     */     
/* 213 */     registerChangeListener(paramTreeView.cellFactoryProperty(), paramObservableValue -> this.flow.recreateCells());
/* 214 */     registerChangeListener(paramTreeView.fixedCellSizeProperty(), paramObservableValue -> this.flow.setFixedCellSize(getSkinnable().getFixedCellSize()));
/*     */     
/* 216 */     updateItemCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 229 */     super.dispose();
/*     */     
/* 231 */     if (this.behavior != null) {
/* 232 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 238 */     return computePrefHeight(-1.0D, paramDouble2, paramDouble3, paramDouble4, paramDouble5) * 0.618033987D;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 243 */     return 400.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 248 */     super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/* 249 */     this.flow.resizeRelocate(paramDouble1, paramDouble2, paramDouble3, paramDouble4); } protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) { FocusModel<TreeItem<T>> focusModel; int i; MultipleSelectionModel<TreeItem<T>> multipleSelectionModel;
/*     */     int j;
/*     */     ObservableList<Integer> observableList;
/*     */     ArrayList<TreeCell> arrayList;
/*     */     Iterator<Integer> iterator;
/* 254 */     switch (paramAccessibleAttribute) {
/*     */       case SHOW_ITEM:
/* 256 */         focusModel = getSkinnable().getFocusModel();
/* 257 */         j = focusModel.getFocusedIndex();
/* 258 */         if (j == -1) {
/* 259 */           if (getItemCount() > 0) {
/* 260 */             j = 0;
/*     */           } else {
/* 262 */             return null;
/*     */           } 
/*     */         }
/* 265 */         return this.flow.getPrivateCell(j);
/*     */       
/*     */       case SET_SELECTED_ITEMS:
/* 268 */         i = ((Integer)paramVarArgs[0]).intValue();
/* 269 */         return (i < 0) ? null : this.flow.getPrivateCell(i);
/*     */       
/*     */       case null:
/* 272 */         multipleSelectionModel = getSkinnable().getSelectionModel();
/* 273 */         observableList = multipleSelectionModel.getSelectedIndices();
/* 274 */         arrayList = new ArrayList(observableList.size());
/* 275 */         for (iterator = observableList.iterator(); iterator.hasNext(); ) { int k = ((Integer)iterator.next()).intValue();
/* 276 */           TreeCell treeCell = this.flow.getPrivateCell(k);
/* 277 */           if (treeCell != null) arrayList.add(treeCell);  }
/*     */         
/* 279 */         return FXCollections.observableArrayList(arrayList);
/*     */       case null:
/* 281 */         return this.flow.getVbar();
/* 282 */       case null: return this.flow.getHbar();
/* 283 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs); }
/*     */ 
/*     */   
/*     */   protected void executeAccessibleAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/*     */     Node node;
/*     */     ObservableList observableList;
/* 289 */     switch (paramAccessibleAction) {
/*     */       case SHOW_ITEM:
/* 291 */         node = (Node)paramVarArgs[0];
/* 292 */         if (node instanceof TreeCell) {
/*     */           
/* 294 */           TreeCell treeCell = (TreeCell)node;
/* 295 */           this.flow.scrollTo(treeCell.getIndex());
/*     */         } 
/*     */         return;
/*     */ 
/*     */       
/*     */       case SET_SELECTED_ITEMS:
/* 301 */         observableList = (ObservableList)paramVarArgs[0];
/* 302 */         if (observableList != null) {
/* 303 */           MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getSkinnable().getSelectionModel();
/* 304 */           if (multipleSelectionModel != null) {
/* 305 */             multipleSelectionModel.clearSelection();
/* 306 */             for (Node node1 : observableList) {
/* 307 */               if (node1 instanceof TreeCell) {
/*     */                 
/* 309 */                 TreeCell treeCell = (TreeCell)node1;
/* 310 */                 multipleSelectionModel.select(treeCell.getIndex());
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         return;
/*     */     } 
/* 317 */     super.executeAccessibleAction(paramAccessibleAction, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TreeCell<T> createCell(VirtualFlow<TreeCell<T>> paramVirtualFlow) {
/*     */     TreeCell<T> treeCell;
/* 330 */     if (getSkinnable().getCellFactory() != null) {
/* 331 */       treeCell = getSkinnable().getCellFactory().call(getSkinnable());
/*     */     } else {
/* 333 */       treeCell = createDefaultCellImpl();
/*     */     } 
/*     */ 
/*     */     
/* 337 */     if (treeCell.getDisclosureNode() == null) {
/* 338 */       StackPane stackPane1 = new StackPane();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 354 */       stackPane1.getStyleClass().setAll(new String[] { "tree-disclosure-node" });
/*     */       
/* 356 */       StackPane stackPane2 = new StackPane();
/* 357 */       stackPane2.getStyleClass().setAll(new String[] { "arrow" });
/* 358 */       stackPane1.getChildren().add(stackPane2);
/*     */       
/* 360 */       treeCell.setDisclosureNode(stackPane1);
/*     */     } 
/*     */     
/* 363 */     treeCell.updateTreeView(getSkinnable());
/*     */     
/* 365 */     return treeCell;
/*     */   }
/*     */   
/*     */   private TreeItem<T> getRoot() {
/* 369 */     return (this.weakRoot == null) ? null : this.weakRoot.get();
/*     */   }
/*     */   private void setRoot(TreeItem<T> paramTreeItem) {
/* 372 */     if (getRoot() != null && this.weakRootListener != null) {
/* 373 */       getRoot().removeEventHandler(TreeItem.treeNotificationEvent(), this.weakRootListener);
/*     */     }
/* 375 */     this.weakRoot = new WeakReference<>(paramTreeItem);
/* 376 */     if (getRoot() != null) {
/* 377 */       this.weakRootListener = new WeakEventHandler<>(this.rootListener);
/* 378 */       getRoot().addEventHandler(TreeItem.treeNotificationEvent(), this.weakRootListener);
/*     */     } 
/*     */     
/* 381 */     updateItemCount();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getItemCount() {
/* 386 */     return getSkinnable().getExpandedItemCount();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateItemCount() {
/* 392 */     int i = getItemCount();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 397 */     requestRebuildCells();
/* 398 */     this.flow.setCellCount(i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 405 */     getSkinnable().requestLayout();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private TreeCell<T> createDefaultCellImpl() {
/* 411 */     return new TreeCell<T>()
/*     */       {
/*     */         private HBox hbox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private WeakReference<TreeItem<T>> treeItemRef;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private InvalidationListener treeItemGraphicListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private InvalidationListener treeItemListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private WeakInvalidationListener weakTreeItemGraphicListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private WeakInvalidationListener weakTreeItemListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private void updateDisplay(T param1T, boolean param1Boolean) {
/* 450 */           if (param1T == null || param1Boolean) {
/* 451 */             this.hbox = null;
/* 452 */             setText((String)null);
/* 453 */             setGraphic((Node)null);
/*     */           } else {
/*     */             
/* 456 */             TreeItem<T> treeItem = getTreeItem();
/* 457 */             Node node = (treeItem == null) ? null : treeItem.getGraphic();
/* 458 */             if (node != null) {
/* 459 */               if (param1T instanceof Node) {
/* 460 */                 setText((String)null);
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 465 */                 if (this.hbox == null) {
/* 466 */                   this.hbox = new HBox(3.0D);
/*     */                 }
/* 468 */                 this.hbox.getChildren().setAll(new Node[] { node, (Node)param1T });
/* 469 */                 setGraphic(this.hbox);
/*     */               } else {
/* 471 */                 this.hbox = null;
/* 472 */                 setText(param1T.toString());
/* 473 */                 setGraphic(node);
/*     */               } 
/*     */             } else {
/* 476 */               this.hbox = null;
/* 477 */               if (param1T instanceof Node) {
/* 478 */                 setText((String)null);
/* 479 */                 setGraphic((Node)param1T);
/*     */               } else {
/* 481 */                 setText(param1T.toString());
/* 482 */                 setGraphic((Node)null);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }
/*     */         
/*     */         public void updateItem(T param1T, boolean param1Boolean) {
/* 489 */           super.updateItem(param1T, param1Boolean);
/* 490 */           updateDisplay(param1T, param1Boolean);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private void onFocusPreviousCell() {
/* 496 */     FocusModel<TreeItem<T>> focusModel = getSkinnable().getFocusModel();
/* 497 */     if (focusModel == null)
/* 498 */       return;  this.flow.scrollTo(focusModel.getFocusedIndex());
/*     */   }
/*     */   
/*     */   private void onFocusNextCell() {
/* 502 */     FocusModel<TreeItem<T>> focusModel = getSkinnable().getFocusModel();
/* 503 */     if (focusModel == null)
/* 504 */       return;  this.flow.scrollTo(focusModel.getFocusedIndex());
/*     */   }
/*     */   
/*     */   private void onSelectPreviousCell() {
/* 508 */     int i = getSkinnable().getSelectionModel().getSelectedIndex();
/* 509 */     this.flow.scrollTo(i);
/*     */   }
/*     */   
/*     */   private void onSelectNextCell() {
/* 513 */     int i = getSkinnable().getSelectionModel().getSelectedIndex();
/* 514 */     this.flow.scrollTo(i);
/*     */   }
/*     */   
/*     */   private void onMoveToFirstCell() {
/* 518 */     this.flow.scrollTo(0);
/* 519 */     this.flow.setPosition(0.0D);
/*     */   }
/*     */   
/*     */   private void onMoveToLastCell() {
/* 523 */     this.flow.scrollTo(getItemCount());
/* 524 */     this.flow.setPosition(1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int onScrollPageDown(boolean paramBoolean) {
/* 531 */     TreeCell<T> treeCell = this.flow.getLastVisibleCellWithinViewPort();
/* 532 */     if (treeCell == null) return -1;
/*     */     
/* 534 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getSkinnable().getSelectionModel();
/* 535 */     FocusModel<TreeItem<T>> focusModel = getSkinnable().getFocusModel();
/* 536 */     if (multipleSelectionModel == null || focusModel == null) return -1;
/*     */     
/* 538 */     int i = treeCell.getIndex();
/*     */ 
/*     */     
/* 541 */     boolean bool = false;
/* 542 */     if (paramBoolean) {
/* 543 */       bool = (treeCell.isFocused() || focusModel.isFocused(i)) ? true : false;
/*     */     } else {
/* 545 */       bool = (treeCell.isSelected() || multipleSelectionModel.isSelected(i)) ? true : false;
/*     */     } 
/*     */     
/* 548 */     if (bool) {
/*     */       
/* 550 */       boolean bool1 = ((paramBoolean && focusModel.getFocusedIndex() == i) || (!paramBoolean && multipleSelectionModel.getSelectedIndex() == i)) ? true : false;
/*     */       
/* 552 */       if (bool1) {
/*     */ 
/*     */         
/* 555 */         this.flow.scrollToTop(treeCell);
/*     */         
/* 557 */         TreeCell<T> treeCell1 = this.flow.getLastVisibleCellWithinViewPort();
/* 558 */         treeCell = (treeCell1 == null) ? treeCell : treeCell1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 566 */     int j = treeCell.getIndex();
/* 567 */     this.flow.scrollTo(treeCell);
/* 568 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int onScrollPageUp(boolean paramBoolean) {
/* 575 */     TreeCell<T> treeCell = this.flow.getFirstVisibleCellWithinViewPort();
/* 576 */     if (treeCell == null) return -1;
/*     */     
/* 578 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getSkinnable().getSelectionModel();
/* 579 */     FocusModel<TreeItem<T>> focusModel = getSkinnable().getFocusModel();
/* 580 */     if (multipleSelectionModel == null || focusModel == null) return -1;
/*     */     
/* 582 */     int i = treeCell.getIndex();
/*     */ 
/*     */     
/* 585 */     boolean bool = false;
/* 586 */     if (paramBoolean) {
/* 587 */       bool = (treeCell.isFocused() || focusModel.isFocused(i)) ? true : false;
/*     */     } else {
/* 589 */       bool = (treeCell.isSelected() || multipleSelectionModel.isSelected(i)) ? true : false;
/*     */     } 
/*     */     
/* 592 */     if (bool) {
/*     */       
/* 594 */       boolean bool1 = ((paramBoolean && focusModel.getFocusedIndex() == i) || (!paramBoolean && multipleSelectionModel.getSelectedIndex() == i)) ? true : false;
/*     */       
/* 596 */       if (bool1) {
/*     */ 
/*     */         
/* 599 */         this.flow.scrollToBottom(treeCell);
/*     */         
/* 601 */         TreeCell<T> treeCell1 = this.flow.getFirstVisibleCellWithinViewPort();
/* 602 */         treeCell = (treeCell1 == null) ? treeCell : treeCell1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 610 */     int j = treeCell.getIndex();
/* 611 */     this.flow.scrollTo(treeCell);
/* 612 */     return j;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TreeViewSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */