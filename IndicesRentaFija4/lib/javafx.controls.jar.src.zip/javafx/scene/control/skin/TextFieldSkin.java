/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.PasswordFieldBehavior;
/*     */ import com.sun.javafx.scene.control.behavior.TextFieldBehavior;
/*     */ import com.sun.javafx.scene.control.behavior.TextInputControlBehavior;
/*     */ import com.sun.javafx.tk.FontMetrics;
/*     */ import java.util.List;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.binding.BooleanBinding;
/*     */ import javafx.beans.binding.DoubleBinding;
/*     */ import javafx.beans.binding.ObjectBinding;
/*     */ import javafx.beans.binding.StringBinding;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.beans.value.ObservableBooleanValue;
/*     */ import javafx.beans.value.ObservableDoubleValue;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.Rectangle2D;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Group;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.IndexRange;
/*     */ import javafx.scene.control.PasswordField;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.Pane;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.paint.Paint;
/*     */ import javafx.scene.shape.Path;
/*     */ import javafx.scene.shape.PathElement;
/*     */ import javafx.scene.shape.Rectangle;
/*     */ import javafx.scene.text.HitInfo;
/*     */ import javafx.scene.text.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextFieldSkin
/*     */   extends TextInputControlSkin<TextField>
/*     */ {
/*     */   private final TextFieldBehavior behavior;
/*  88 */   private Pane textGroup = new Pane();
/*     */ 
/*     */ 
/*     */   
/*     */   private Group handleGroup;
/*     */ 
/*     */   
/*  95 */   private Rectangle clip = new Rectangle();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private Text textNode = new Text();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Text promptNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   private Path selectionHighlightPath = new Path();
/*     */   
/* 117 */   private Path characterBoundingPath = new Path();
/*     */   private ObservableBooleanValue usePromptText;
/* 119 */   private DoubleProperty textTranslateX = new SimpleDoubleProperty(this, "textTranslateX");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double caretWidth;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObservableDoubleValue textRight;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double pressX;
/*     */ 
/*     */ 
/*     */   
/*     */   private double pressY;
/*     */ 
/*     */ 
/*     */   
/*     */   static final char BULLET = '●';
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextFieldSkin(final TextField control) {
/* 148 */     super(control);
/*     */ 
/*     */     
/* 151 */     this
/*     */       
/* 153 */       .behavior = (control instanceof PasswordField) ? new PasswordFieldBehavior((PasswordField)control) : new TextFieldBehavior(control);
/* 154 */     this.behavior.setTextFieldSkin(this);
/*     */ 
/*     */     
/* 157 */     control.caretPositionProperty().addListener((paramObservableValue, paramNumber1, paramNumber2) -> {
/*     */           if (paramTextField.getWidth() > 0.0D) {
/*     */             updateTextNodeCaretPos(paramTextField.getCaretPosition());
/*     */             
/*     */             if (!isForwardBias()) {
/*     */               setForwardBias(true);
/*     */             }
/*     */             updateCaretOff();
/*     */           } 
/*     */         });
/* 167 */     forwardBiasProperty().addListener(paramObservable -> {
/*     */           if (paramTextField.getWidth() > 0.0D) {
/*     */             updateTextNodeCaretPos(paramTextField.getCaretPosition());
/*     */             
/*     */             updateCaretOff();
/*     */           } 
/*     */         });
/* 174 */     this.textRight = new DoubleBinding()
/*     */       {
/*     */         protected double computeValue() {
/* 177 */           return TextFieldSkin.this.textGroup.getWidth();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 182 */     this.clip.setSmooth(false);
/* 183 */     this.clip.setX(0.0D);
/* 184 */     this.clip.widthProperty().bind(this.textGroup.widthProperty());
/* 185 */     this.clip.heightProperty().bind(this.textGroup.heightProperty());
/*     */ 
/*     */     
/* 188 */     this.textGroup.setClip(this.clip);
/*     */ 
/*     */ 
/*     */     
/* 192 */     this.textGroup.getChildren().addAll(new Node[] { this.selectionHighlightPath, this.textNode, new Group(new Node[] { this.caretPath }) });
/* 193 */     getChildren().add(this.textGroup);
/* 194 */     if (SHOW_HANDLES) {
/* 195 */       this.handleGroup = new Group();
/* 196 */       this.handleGroup.setManaged(false);
/* 197 */       this.handleGroup.getChildren().addAll(new Node[] { this.caretHandle, this.selectionHandle1, this.selectionHandle2 });
/* 198 */       getChildren().add(this.handleGroup);
/*     */     } 
/*     */ 
/*     */     
/* 202 */     this.textNode.setManaged(false);
/* 203 */     this.textNode.getStyleClass().add("text");
/* 204 */     this.textNode.fontProperty().bind(control.fontProperty());
/*     */     
/* 206 */     this.textNode.layoutXProperty().bind(this.textTranslateX);
/* 207 */     this.textNode.textProperty().bind(new StringBinding()
/*     */         {
/*     */           protected String computeValue() {
/* 210 */             return TextFieldSkin.this.maskText(control.textProperty().getValueSafe());
/*     */           }
/*     */         });
/* 213 */     this.textNode.fillProperty().bind(textFillProperty());
/* 214 */     this.textNode.selectionFillProperty().bind(new ObjectBinding<Paint>()
/*     */         {
/*     */           protected Paint computeValue() {
/* 217 */             return control.isFocused() ? TextFieldSkin.this.highlightTextFillProperty().get() : TextFieldSkin.this.textFillProperty().get();
/*     */           }
/*     */         });
/*     */     
/* 221 */     updateTextNodeCaretPos(control.getCaretPosition());
/* 222 */     control.selectionProperty().addListener(paramObservable -> updateSelection());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     this.selectionHighlightPath.setManaged(false);
/* 228 */     this.selectionHighlightPath.setStroke((Paint)null);
/* 229 */     this.selectionHighlightPath.layoutXProperty().bind(this.textTranslateX);
/* 230 */     this.selectionHighlightPath.visibleProperty().bind(control.anchorProperty().isNotEqualTo(control.caretPositionProperty()).and(control.focusedProperty()));
/* 231 */     this.selectionHighlightPath.fillProperty().bind(highlightFillProperty());
/* 232 */     this.textNode.selectionShapeProperty().addListener(paramObservable -> updateSelection());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 237 */     this.caretPath.setManaged(false);
/* 238 */     this.caretPath.setStrokeWidth(1.0D);
/* 239 */     this.caretPath.fillProperty().bind(textFillProperty());
/* 240 */     this.caretPath.strokeProperty().bind(textFillProperty());
/*     */ 
/*     */ 
/*     */     
/* 244 */     this.caretPath.opacityProperty().bind(new DoubleBinding()
/*     */         {
/*     */           protected double computeValue() {
/* 247 */             return TextFieldSkin.this.caretVisibleProperty().get() ? 1.0D : 0.0D;
/*     */           }
/*     */         });
/* 250 */     this.caretPath.layoutXProperty().bind(this.textTranslateX);
/* 251 */     this.textNode.caretShapeProperty().addListener(paramObservable -> {
/*     */           this.caretPath.getElements().setAll(this.textNode.caretShapeProperty().get());
/*     */ 
/*     */ 
/*     */           
/*     */           if (this.caretPath.getElements().size() == 0) {
/*     */             updateTextNodeCaretPos(paramTextField.getCaretPosition());
/*     */           } else if (this.caretPath.getElements().size() != 4) {
/*     */             this.caretWidth = Math.round(this.caretPath.getLayoutBounds().getWidth());
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 265 */     control.fontProperty().addListener(paramObservable -> {
/*     */           paramTextField.requestLayout();
/*     */ 
/*     */           
/*     */           getSkinnable().requestLayout();
/*     */         });
/*     */ 
/*     */     
/* 273 */     registerChangeListener(control.prefColumnCountProperty(), paramObservableValue -> getSkinnable().requestLayout());
/* 274 */     if (control.isFocused()) setCaretAnimating(true);
/*     */     
/* 276 */     control.alignmentProperty().addListener(paramObservable -> {
/*     */           if (paramTextField.getWidth() > 0.0D) {
/*     */             updateTextPos();
/*     */             
/*     */             updateCaretOff();
/*     */             paramTextField.requestLayout();
/*     */           } 
/*     */         });
/* 284 */     this.usePromptText = new BooleanBinding()
/*     */       {
/*     */         
/*     */         protected boolean computeValue()
/*     */         {
/* 289 */           String str1 = control.getText();
/* 290 */           String str2 = control.getPromptText();
/* 291 */           return ((str1 == null || str1.isEmpty()) && str2 != null && 
/* 292 */             !str2.isEmpty() && 
/* 293 */             !TextFieldSkin.this.getPromptTextFill().equals(Color.TRANSPARENT));
/*     */         }
/*     */       };
/*     */     
/* 297 */     promptTextFillProperty().addListener(paramObservable -> updateTextPos());
/*     */ 
/*     */ 
/*     */     
/* 301 */     control.textProperty().addListener(paramObservable -> {
/*     */           if (!this.behavior.isEditing()) {
/*     */             updateTextPos();
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 308 */     if (this.usePromptText.get()) {
/* 309 */       createPromptNode();
/*     */     }
/*     */     
/* 312 */     this.usePromptText.addListener(paramObservable -> {
/*     */           createPromptNode();
/*     */           
/*     */           paramTextField.requestLayout();
/*     */         });
/* 317 */     if (SHOW_HANDLES) {
/* 318 */       this.selectionHandle1.setRotate(180.0D);
/*     */       
/* 320 */       EventHandler<? super MouseEvent> eventHandler = paramMouseEvent -> {
/*     */           this.pressX = paramMouseEvent.getX();
/*     */           
/*     */           this.pressY = paramMouseEvent.getY();
/*     */           paramMouseEvent.consume();
/*     */         };
/* 326 */       this.caretHandle.setOnMousePressed(eventHandler);
/* 327 */       this.selectionHandle1.setOnMousePressed(eventHandler);
/* 328 */       this.selectionHandle2.setOnMousePressed(eventHandler);
/*     */       
/* 330 */       this.caretHandle.setOnMouseDragged(paramMouseEvent -> {
/*     */             Point2D point2D = new Point2D(this.caretHandle.getLayoutX() + paramMouseEvent.getX() + this.pressX - this.textNode.getLayoutX(), this.caretHandle.getLayoutY() + paramMouseEvent.getY() - this.pressY - 6.0D);
/*     */             
/*     */             HitInfo hitInfo = this.textNode.hitTest(point2D);
/*     */             
/*     */             positionCaret(hitInfo, false);
/*     */             paramMouseEvent.consume();
/*     */           });
/* 338 */       this.selectionHandle1.setOnMouseDragged(new EventHandler<MouseEvent>() {
/*     */             public void handle(MouseEvent param1MouseEvent) {
/* 340 */               TextField textField = TextFieldSkin.this.getSkinnable();
/* 341 */               Point2D point2D1 = TextFieldSkin.this.textNode.localToScene(0.0D, 0.0D);
/*     */               
/* 343 */               Point2D point2D2 = new Point2D(param1MouseEvent.getSceneX() - point2D1.getX() + 10.0D - TextFieldSkin.this.pressX + TextFieldSkin.this.selectionHandle1.getWidth() / 2.0D, param1MouseEvent.getSceneY() - point2D1.getY() - TextFieldSkin.this.pressY - 6.0D);
/* 344 */               HitInfo hitInfo = TextFieldSkin.this.textNode.hitTest(point2D2);
/* 345 */               if (textField.getAnchor() < textField.getCaretPosition())
/*     */               {
/* 347 */                 textField.selectRange(textField.getCaretPosition(), textField.getAnchor());
/*     */               }
/* 349 */               int i = hitInfo.getInsertionIndex();
/* 350 */               if (i >= 0) {
/* 351 */                 if (i >= textField.getAnchor() - 1) {
/* 352 */                   i = Math.max(0, textField.getAnchor() - 1);
/*     */                 }
/* 354 */                 TextFieldSkin.this.positionCaret(i, hitInfo.isLeading(), true);
/*     */               } 
/* 356 */               param1MouseEvent.consume();
/*     */             }
/*     */           });
/*     */       
/* 360 */       this.selectionHandle2.setOnMouseDragged(new EventHandler<MouseEvent>() {
/*     */             public void handle(MouseEvent param1MouseEvent) {
/* 362 */               TextField textField = TextFieldSkin.this.getSkinnable();
/* 363 */               Point2D point2D1 = TextFieldSkin.this.textNode.localToScene(0.0D, 0.0D);
/*     */               
/* 365 */               Point2D point2D2 = new Point2D(param1MouseEvent.getSceneX() - point2D1.getX() + 10.0D - TextFieldSkin.this.pressX + TextFieldSkin.this.selectionHandle2.getWidth() / 2.0D, param1MouseEvent.getSceneY() - point2D1.getY() - TextFieldSkin.this.pressY - 6.0D);
/* 366 */               HitInfo hitInfo = TextFieldSkin.this.textNode.hitTest(point2D2);
/* 367 */               if (textField.getAnchor() > textField.getCaretPosition())
/*     */               {
/* 369 */                 textField.selectRange(textField.getCaretPosition(), textField.getAnchor());
/*     */               }
/* 371 */               int i = hitInfo.getInsertionIndex();
/* 372 */               if (i > 0) {
/* 373 */                 if (i <= textField.getAnchor()) {
/* 374 */                   i = Math.min(textField.getAnchor() + 1, textField.getLength());
/*     */                 }
/* 376 */                 TextFieldSkin.this.positionCaret(i, hitInfo.isLeading(), true);
/*     */               } 
/* 378 */               param1MouseEvent.consume();
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 394 */     super.dispose();
/*     */     
/* 396 */     if (this.behavior != null) {
/* 397 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 403 */     TextField textField = getSkinnable();
/*     */     
/* 405 */     double d = ((FontMetrics)this.fontMetrics.get()).getCharWidth('W');
/*     */     
/* 407 */     int i = textField.getPrefColumnCount();
/*     */     
/* 409 */     return i * d + paramDouble5 + paramDouble3;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 414 */     return computePrefHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 419 */     return paramDouble2 + this.textNode.getLayoutBounds().getHeight() + paramDouble4;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 424 */     return getSkinnable().prefHeight(paramDouble1);
/*     */   }
/*     */ 
/*     */   
/*     */   public double computeBaselineOffset(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 429 */     return paramDouble1 + this.textNode.getBaselineOffset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceText(int paramInt1, int paramInt2, String paramString) {
/* 448 */     double d1 = this.textNode.getBoundsInParent().getMaxX();
/* 449 */     double d2 = this.caretPath.getLayoutBounds().getMaxX() + this.textTranslateX.get();
/* 450 */     getSkinnable().replaceText(paramInt1, paramInt2, paramString);
/* 451 */     scrollAfterDelete(d1, d2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteChar(boolean paramBoolean) {
/* 467 */     double d1 = this.textNode.getBoundsInParent().getMaxX();
/* 468 */     double d2 = this.caretPath.getLayoutBounds().getMaxX() + this.textTranslateX.get();
/* 469 */     if (paramBoolean ? getSkinnable().deletePreviousChar() : getSkinnable().deleteNextChar()) {
/* 470 */       scrollAfterDelete(d1, d2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HitInfo getIndex(double paramDouble1, double paramDouble2) {
/* 486 */     Point2D point2D = new Point2D(paramDouble1 - this.textTranslateX.get() - snappedLeftInset(), paramDouble2 - snappedTopInset());
/* 487 */     return this.textNode.hitTest(point2D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void positionCaret(HitInfo paramHitInfo, boolean paramBoolean) {
/* 498 */     positionCaret(paramHitInfo.getInsertionIndex(), paramHitInfo.isLeading(), paramBoolean);
/*     */   }
/*     */   
/*     */   private void positionCaret(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/* 502 */     TextField textField = getSkinnable();
/* 503 */     if (paramBoolean2) {
/* 504 */       textField.selectPositionCaret(paramInt);
/*     */     } else {
/* 506 */       textField.positionCaret(paramInt);
/*     */     } 
/* 508 */     setForwardBias(paramBoolean1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle2D getCharacterBounds(int paramInt) {
/*     */     double d1, d2, d3, d4;
/* 515 */     if (paramInt == this.textNode.getText().length()) {
/* 516 */       Bounds bounds1 = this.textNode.getBoundsInLocal();
/* 517 */       d1 = bounds1.getMaxX();
/* 518 */       d2 = 0.0D;
/* 519 */       d3 = 0.0D;
/* 520 */       d4 = bounds1.getMaxY();
/*     */     } else {
/* 522 */       this.characterBoundingPath.getElements().clear();
/* 523 */       this.characterBoundingPath.getElements().addAll(this.textNode.rangeShape(paramInt, paramInt + 1));
/* 524 */       this.characterBoundingPath.setLayoutX(this.textNode.getLayoutX());
/* 525 */       this.characterBoundingPath.setLayoutY(this.textNode.getLayoutY());
/*     */       
/* 527 */       Bounds bounds1 = this.characterBoundingPath.getBoundsInLocal();
/*     */       
/* 529 */       d1 = bounds1.getMinX();
/* 530 */       d2 = bounds1.getMinY();
/*     */       
/* 532 */       d3 = bounds1.isEmpty() ? 0.0D : bounds1.getWidth();
/* 533 */       d4 = bounds1.isEmpty() ? 0.0D : bounds1.getHeight();
/*     */     } 
/*     */     
/* 536 */     Bounds bounds = this.textGroup.getBoundsInParent();
/*     */     
/* 538 */     return new Rectangle2D(d1 + bounds.getMinX() + this.textTranslateX.get(), d2 + bounds
/* 539 */         .getMinY(), d3, d4);
/*     */   }
/*     */ 
/*     */   
/*     */   protected PathElement[] getUnderlineShape(int paramInt1, int paramInt2) {
/* 544 */     return this.textNode.underlineShape(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected PathElement[] getRangeShape(int paramInt1, int paramInt2) {
/* 549 */     return this.textNode.rangeShape(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addHighlight(List<? extends Node> paramList, int paramInt) {
/* 554 */     this.textGroup.getChildren().addAll(paramList);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void removeHighlight(List<? extends Node> paramList) {
/* 559 */     this.textGroup.getChildren().removeAll(paramList);
/*     */   }
/*     */ 
/*     */   
/*     */   public void moveCaret(TextInputControlSkin.TextUnit paramTextUnit, TextInputControlSkin.Direction paramDirection, boolean paramBoolean) {
/* 564 */     switch (paramTextUnit) {
/*     */       case CENTER:
/* 566 */         switch (paramDirection) {
/*     */           case CENTER:
/*     */           case RIGHT:
/* 569 */             nextCharacterVisually((paramDirection == TextInputControlSkin.Direction.RIGHT));
/*     */             return;
/*     */         } 
/* 572 */         throw new IllegalArgumentException("" + paramDirection);
/*     */     } 
/*     */ 
/*     */     
/* 576 */     throw new IllegalArgumentException("" + paramTextUnit);
/*     */   }
/*     */ 
/*     */   
/*     */   private void nextCharacterVisually(boolean paramBoolean) {
/* 581 */     if (isRTL())
/*     */     {
/* 583 */       paramBoolean = !paramBoolean;
/*     */     }
/*     */     
/* 586 */     Bounds bounds = this.caretPath.getLayoutBounds();
/* 587 */     if (this.caretPath.getElements().size() == 4)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 592 */       bounds = (new Path(new PathElement[] { this.caretPath.getElements().get(0), this.caretPath.getElements().get(1) })).getLayoutBounds();
/*     */     }
/* 594 */     double d1 = paramBoolean ? bounds.getMaxX() : bounds.getMinX();
/* 595 */     double d2 = (bounds.getMinY() + bounds.getMaxY()) / 2.0D;
/* 596 */     HitInfo hitInfo = this.textNode.hitTest(new Point2D(d1, d2));
/* 597 */     boolean bool = hitInfo.isLeading();
/* 598 */     Path path = new Path(this.textNode.rangeShape(hitInfo.getCharIndex(), hitInfo.getCharIndex() + 1));
/* 599 */     if ((paramBoolean && path.getLayoutBounds().getMaxX() > bounds.getMaxX()) || (!paramBoolean && path
/* 600 */       .getLayoutBounds().getMinX() < bounds.getMinX())) {
/* 601 */       bool = !bool;
/*     */     }
/* 603 */     positionCaret(hitInfo.getInsertionIndex(), bool, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 609 */     super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */     
/* 611 */     if (this.textNode != null) {
/*     */       double d1;
/* 613 */       Bounds bounds = this.textNode.getLayoutBounds();
/* 614 */       double d2 = this.textNode.getBaselineOffset();
/* 615 */       double d3 = bounds.getHeight() - d2;
/*     */       
/* 617 */       switch (getSkinnable().getAlignment().getVpos()) {
/*     */         case CENTER:
/* 619 */           d1 = d2;
/*     */           break;
/*     */         
/*     */         case RIGHT:
/* 623 */           d1 = (d2 + this.textGroup.getHeight() - d3) / 2.0D;
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 628 */           d1 = this.textGroup.getHeight() - d3; break;
/*     */       } 
/* 630 */       this.textNode.setY(d1);
/* 631 */       if (this.promptNode != null) {
/* 632 */         this.promptNode.setY(d1);
/*     */       }
/*     */       
/* 635 */       if (getSkinnable().getWidth() > 0.0D) {
/* 636 */         updateTextPos();
/* 637 */         updateCaretOff();
/*     */       } 
/*     */     } 
/*     */     
/* 641 */     if (SHOW_HANDLES) {
/* 642 */       this.handleGroup.setLayoutX(paramDouble1 + this.caretWidth / 2.0D);
/* 643 */       this.handleGroup.setLayoutY(paramDouble2);
/*     */ 
/*     */ 
/*     */       
/* 647 */       this.selectionHandle1.resize(this.selectionHandle1.prefWidth(-1.0D), this.selectionHandle1
/* 648 */           .prefHeight(-1.0D));
/* 649 */       this.selectionHandle2.resize(this.selectionHandle2.prefWidth(-1.0D), this.selectionHandle2
/* 650 */           .prefHeight(-1.0D));
/* 651 */       this.caretHandle.resize(this.caretHandle.prefWidth(-1.0D), this.caretHandle
/* 652 */           .prefHeight(-1.0D));
/*     */       
/* 654 */       Bounds bounds = this.caretPath.getBoundsInParent();
/* 655 */       this.caretHandle.setLayoutY(bounds.getMaxY() - 1.0D);
/*     */       
/* 657 */       this.selectionHandle1.setLayoutY(bounds.getMinY() - this.selectionHandle1.getHeight() + 1.0D);
/* 658 */       this.selectionHandle2.setLayoutY(bounds.getMaxY() - 1.0D);
/*     */     } 
/*     */   }
/*     */   
/*     */   private HPos getHAlignment() {
/* 663 */     return getSkinnable().getAlignment().getHpos();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D getMenuPosition() {
/* 669 */     Point2D point2D = super.getMenuPosition();
/* 670 */     if (point2D != null)
/*     */     {
/* 672 */       point2D = new Point2D(Math.max(0.0D, point2D.getX() - this.textNode.getLayoutX() - snappedLeftInset() + this.textTranslateX.get()), Math.max(0.0D, point2D.getY() - this.textNode.getLayoutY() - snappedTopInset()));
/*     */     }
/* 674 */     return point2D;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String maskText(String paramString) {
/* 679 */     if (getSkinnable() instanceof PasswordField) {
/* 680 */       int i = paramString.length();
/* 681 */       StringBuilder stringBuilder = new StringBuilder(i);
/* 682 */       for (byte b = 0; b < i; b++) {
/* 683 */         stringBuilder.append('●');
/*     */       }
/*     */       
/* 686 */       return stringBuilder.toString();
/*     */     } 
/* 688 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 694 */     switch (paramAccessibleAttribute) {
/*     */       case CENTER:
/*     */       case RIGHT:
/* 697 */         return this.textNode.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/* 698 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TextInputControlBehavior getBehavior() {
/* 711 */     return this.behavior;
/*     */   }
/*     */   
/*     */   private void updateTextNodeCaretPos(int paramInt) {
/* 715 */     if (paramInt == 0 || isForwardBias()) {
/* 716 */       this.textNode.setCaretPosition(paramInt);
/*     */     } else {
/* 718 */       this.textNode.setCaretPosition(paramInt - 1);
/*     */     } 
/* 720 */     this.textNode.caretBiasProperty().set(isForwardBias());
/*     */   }
/*     */   
/*     */   private void createPromptNode() {
/* 724 */     if (this.promptNode != null || !this.usePromptText.get())
/*     */       return; 
/* 726 */     this.promptNode = new Text();
/* 727 */     this.textGroup.getChildren().add(0, this.promptNode);
/* 728 */     this.promptNode.setManaged(false);
/* 729 */     this.promptNode.getStyleClass().add("text");
/* 730 */     this.promptNode.visibleProperty().bind(this.usePromptText);
/* 731 */     this.promptNode.fontProperty().bind(getSkinnable().fontProperty());
/*     */     
/* 733 */     this.promptNode.textProperty().bind(getSkinnable().promptTextProperty());
/* 734 */     this.promptNode.fillProperty().bind(promptTextFillProperty());
/* 735 */     updateSelection();
/*     */   }
/*     */   
/*     */   private void updateSelection() {
/* 739 */     TextField textField = getSkinnable();
/* 740 */     IndexRange indexRange = textField.getSelection();
/*     */     
/* 742 */     if (indexRange == null || indexRange.getLength() == 0) {
/* 743 */       this.textNode.selectionStartProperty().set(-1);
/* 744 */       this.textNode.selectionEndProperty().set(-1);
/*     */     } else {
/* 746 */       this.textNode.selectionStartProperty().set(indexRange.getStart());
/*     */       
/* 748 */       this.textNode.selectionEndProperty().set(indexRange.getStart());
/* 749 */       this.textNode.selectionEndProperty().set(indexRange.getEnd());
/*     */     } 
/*     */     
/* 752 */     PathElement[] arrayOfPathElement = this.textNode.selectionShapeProperty().get();
/* 753 */     if (arrayOfPathElement == null) {
/* 754 */       this.selectionHighlightPath.getElements().clear();
/*     */     } else {
/* 756 */       this.selectionHighlightPath.getElements().setAll(arrayOfPathElement);
/*     */     } 
/*     */     
/* 759 */     if (SHOW_HANDLES && indexRange != null && indexRange.getLength() > 0) {
/* 760 */       int i = textField.getCaretPosition();
/* 761 */       int j = textField.getAnchor();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 766 */       updateTextNodeCaretPos(j);
/* 767 */       Bounds bounds = this.caretPath.getBoundsInParent();
/* 768 */       if (i < j) {
/* 769 */         this.selectionHandle2.setLayoutX(bounds.getMinX() - this.selectionHandle2.getWidth() / 2.0D);
/*     */       } else {
/* 771 */         this.selectionHandle1.setLayoutX(bounds.getMinX() - this.selectionHandle1.getWidth() / 2.0D);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 777 */       updateTextNodeCaretPos(i);
/* 778 */       bounds = this.caretPath.getBoundsInParent();
/* 779 */       if (i < j) {
/* 780 */         this.selectionHandle1.setLayoutX(bounds.getMinX() - this.selectionHandle1.getWidth() / 2.0D);
/*     */       } else {
/* 782 */         this.selectionHandle2.setLayoutX(bounds.getMinX() - this.selectionHandle2.getWidth() / 2.0D);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateTextPos() {
/* 795 */     double d4, d1 = this.textTranslateX.get();
/*     */     
/* 797 */     double d3 = this.textNode.getLayoutBounds().getWidth();
/*     */     
/* 799 */     switch (getHAlignment()) {
/*     */       case CENTER:
/* 801 */         d4 = this.textRight.get() / 2.0D;
/* 802 */         if (this.usePromptText.get()) {
/*     */ 
/*     */ 
/*     */           
/* 806 */           d2 = d4 - this.promptNode.getLayoutBounds().getWidth() / 2.0D;
/* 807 */           this.promptNode.setLayoutX(d2);
/*     */         } else {
/* 809 */           d2 = d4 - d3 / 2.0D;
/*     */         } 
/*     */         
/* 812 */         if (d2 + d3 <= this.textRight.get()) {
/* 813 */           this.textTranslateX.set(d2);
/*     */         }
/*     */         return;
/*     */       
/*     */       case RIGHT:
/* 818 */         d2 = this.textRight.get() - d3 - this.caretWidth / 2.0D;
/*     */         
/* 820 */         if (d2 > d1 || d2 > 0.0D) {
/* 821 */           this.textTranslateX.set(d2);
/*     */         }
/* 823 */         if (this.usePromptText.get()) {
/* 824 */           this.promptNode.setLayoutX(this.textRight.get() - this.promptNode.getLayoutBounds().getWidth() - this.caretWidth / 2.0D);
/*     */         }
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 831 */     double d2 = this.caretWidth / 2.0D;
/*     */     
/* 833 */     if (d2 < d1 || d2 + d3 <= this.textRight.get()) {
/* 834 */       this.textTranslateX.set(d2);
/*     */     }
/* 836 */     if (this.usePromptText.get()) {
/* 837 */       this.promptNode.layoutXProperty().set(d2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateCaretOff() {
/* 845 */     double d1 = 0.0D;
/* 846 */     double d2 = this.caretPath.getLayoutBounds().getMinX() + this.textTranslateX.get();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 851 */     if (d2 < 0.0D) {
/*     */       
/* 853 */       d1 = d2;
/* 854 */     } else if (d2 > this.textRight.get() - this.caretWidth) {
/*     */       
/* 856 */       d1 = d2 - this.textRight.get() - this.caretWidth;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 861 */     switch (getHAlignment()) {
/*     */       case CENTER:
/* 863 */         this.textTranslateX.set(this.textTranslateX.get() - d1);
/*     */         break;
/*     */       
/*     */       case RIGHT:
/* 867 */         this.textTranslateX.set(Math.max(this.textTranslateX.get() - d1, this.textRight
/* 868 */               .get() - this.textNode.getLayoutBounds().getWidth() - this.caretWidth / 2.0D));
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 874 */         this.textTranslateX.set(Math.min(this.textTranslateX.get() - d1, this.caretWidth / 2.0D));
/*     */         break;
/*     */     } 
/* 877 */     if (SHOW_HANDLES) {
/* 878 */       this.caretHandle.setLayoutX(d2 - this.caretHandle.getWidth() / 2.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   private void scrollAfterDelete(double paramDouble1, double paramDouble2) {
/* 883 */     Bounds bounds1 = this.textNode.getLayoutBounds();
/* 884 */     Bounds bounds2 = this.textNode.localToParent(bounds1);
/* 885 */     Bounds bounds3 = this.clip.getBoundsInParent();
/* 886 */     Bounds bounds4 = this.caretPath.getLayoutBounds();
/*     */     
/* 888 */     switch (getHAlignment()) {
/*     */       case RIGHT:
/* 890 */         if (bounds2.getMaxX() > bounds3.getMaxX()) {
/* 891 */           double d = paramDouble2 - bounds4.getMaxX() - this.textTranslateX.get();
/* 892 */           if (bounds2.getMaxX() + d < bounds3.getMaxX()) {
/* 893 */             if (paramDouble1 <= bounds3.getMaxX()) {
/* 894 */               d = paramDouble1 - bounds2.getMaxX();
/*     */             } else {
/* 896 */               d = bounds3.getMaxX() - bounds2.getMaxX();
/*     */             } 
/*     */           }
/* 899 */           this.textTranslateX.set(this.textTranslateX.get() + d); break;
/*     */         } 
/* 901 */         updateTextPos();
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 908 */         if (bounds2.getMinX() < bounds3.getMinX() + this.caretWidth / 2.0D && bounds2
/* 909 */           .getMaxX() <= bounds3.getMaxX()) {
/* 910 */           double d = paramDouble2 - bounds4.getMaxX() - this.textTranslateX.get();
/* 911 */           if (bounds2.getMaxX() + d < bounds3.getMaxX()) {
/* 912 */             if (paramDouble1 <= bounds3.getMaxX()) {
/* 913 */               d = paramDouble1 - bounds2.getMaxX();
/*     */             } else {
/* 915 */               d = bounds3.getMaxX() - bounds2.getMaxX();
/*     */             } 
/*     */           }
/* 918 */           this.textTranslateX.set(this.textTranslateX.get() + d);
/*     */         } 
/*     */         break;
/*     */     } 
/* 922 */     updateCaretOff();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TextFieldSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */