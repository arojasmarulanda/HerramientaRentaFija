/*    */ package javafx.scene.control.skin;
/*    */ 
/*    */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*    */ import com.sun.javafx.scene.control.behavior.ButtonBehavior;
/*    */ import javafx.scene.control.Hyperlink;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HyperlinkSkin
/*    */   extends LabeledSkinBase<Hyperlink>
/*    */ {
/*    */   private final BehaviorBase<Hyperlink> behavior;
/*    */   
/*    */   public HyperlinkSkin(Hyperlink paramHyperlink) {
/* 69 */     super(paramHyperlink);
/*    */ 
/*    */     
/* 72 */     this.behavior = new ButtonBehavior<>(paramHyperlink);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void dispose() {
/* 86 */     super.dispose();
/*    */     
/* 88 */     if (this.behavior != null)
/* 89 */       this.behavior.dispose(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\HyperlinkSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */