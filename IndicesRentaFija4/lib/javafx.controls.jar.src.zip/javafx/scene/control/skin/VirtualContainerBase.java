/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.IndexedCell;
/*     */ import javafx.scene.control.ScrollToEvent;
/*     */ import javafx.scene.control.SkinBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class VirtualContainerBase<C extends Control, I extends IndexedCell>
/*     */   extends SkinBase<C>
/*     */ {
/*     */   private boolean itemCountDirty;
/*     */   private final VirtualFlow<I> flow;
/*     */   
/*     */   public VirtualContainerBase(C paramC) {
/*  69 */     super(paramC);
/*  70 */     this.flow = createVirtualFlow();
/*     */     
/*  72 */     paramC.addEventHandler(ScrollToEvent.scrollToTopIndex(), paramScrollToEvent -> {
/*     */           if (this.itemCountDirty) {
/*     */             updateItemCount();
/*     */             this.itemCountDirty = false;
/*     */           } 
/*     */           this.flow.scrollToTop(((Integer)paramScrollToEvent.getScrollTarget()).intValue());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected VirtualFlow<I> createVirtualFlow() {
/* 123 */     return new VirtualFlow<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final VirtualFlow<I> getVirtualFlow() {
/* 133 */     return this.flow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void markItemCountDirty() {
/* 140 */     this.itemCountDirty = true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 145 */     checkState();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double getMaxCellWidth(int paramInt) {
/* 155 */     return snappedLeftInset() + this.flow.getMaxCellWidth(paramInt) + snappedRightInset();
/*     */   }
/*     */   
/*     */   double getVirtualFlowPreferredHeight(int paramInt) {
/* 159 */     double d = 1.0D;
/*     */     
/* 161 */     for (byte b = 0; b < paramInt && b < getItemCount(); b++) {
/* 162 */       d += this.flow.getCellLength(b);
/*     */     }
/*     */     
/* 165 */     return d + snappedTopInset() + snappedBottomInset();
/*     */   }
/*     */   
/*     */   void checkState() {
/* 169 */     if (this.itemCountDirty) {
/* 170 */       updateItemCount();
/* 171 */       this.itemCountDirty = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   void requestRebuildCells() {
/* 176 */     this.flow.rebuildCells();
/*     */   }
/*     */   
/*     */   protected abstract int getItemCount();
/*     */   
/*     */   protected abstract void updateItemCount();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\VirtualContainerBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */