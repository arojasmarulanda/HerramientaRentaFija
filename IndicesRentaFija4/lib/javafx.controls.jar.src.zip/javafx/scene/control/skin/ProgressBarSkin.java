/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.animation.Transition;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.binding.When;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableBooleanProperty;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ProgressBar;
/*     */ import javafx.scene.control.ProgressIndicator;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.layout.Background;
/*     */ import javafx.scene.layout.BackgroundFill;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProgressBarSkin
/*     */   extends ProgressIndicatorSkin
/*     */ {
/*     */   private StackPane bar;
/*     */   private StackPane track;
/*     */   private Region clipRegion;
/*     */   private double barWidth;
/*     */   private DoubleProperty indeterminateBarLength;
/*     */   private BooleanProperty indeterminateBarEscape;
/*     */   private BooleanProperty indeterminateBarFlip;
/*     */   private DoubleProperty indeterminateBarAnimationTime;
/*     */   boolean wasIndeterminate;
/*     */   
/*     */   private DoubleProperty indeterminateBarLengthProperty() {
/*     */     if (this.indeterminateBarLength == null)
/*     */       this.indeterminateBarLength = new StyleableDoubleProperty(60.0D)
/*     */         {
/*     */           public Object getBean() {
/*     */             return ProgressBarSkin.this;
/*     */           }
/*     */           
/*     */           public String getName() {
/*     */             return "indeterminateBarLength";
/*     */           }
/*     */           
/*     */           public CssMetaData<ProgressBar, Number> getCssMetaData() {
/*     */             return ProgressBarSkin.StyleableProperties.INDETERMINATE_BAR_LENGTH;
/*     */           }
/*     */         }; 
/*     */     return this.indeterminateBarLength;
/*     */   }
/*     */   
/*     */   private Double getIndeterminateBarLength() {
/*     */     return Double.valueOf((this.indeterminateBarLength == null) ? 60.0D : this.indeterminateBarLength.get());
/*     */   }
/*     */   
/*     */   private BooleanProperty indeterminateBarEscapeProperty() {
/*     */     if (this.indeterminateBarEscape == null)
/*     */       this.indeterminateBarEscape = new StyleableBooleanProperty(true)
/*     */         {
/*     */           public Object getBean() {
/*     */             return ProgressBarSkin.this;
/*     */           }
/*     */           
/*     */           public String getName() {
/*     */             return "indeterminateBarEscape";
/*     */           }
/*     */           
/*     */           public CssMetaData<ProgressBar, Boolean> getCssMetaData() {
/*     */             return ProgressBarSkin.StyleableProperties.INDETERMINATE_BAR_ESCAPE;
/*     */           }
/*     */         }; 
/*     */     return this.indeterminateBarEscape;
/*     */   }
/*     */   
/*     */   private Boolean getIndeterminateBarEscape() {
/*     */     return Boolean.valueOf((this.indeterminateBarEscape == null) ? true : this.indeterminateBarEscape.get());
/*     */   }
/*     */   
/*     */   public ProgressBarSkin(ProgressBar paramProgressBar) {
/*  97 */     super(paramProgressBar);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     this.indeterminateBarLength = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     this.indeterminateBarEscape = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     this.indeterminateBarFlip = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     this.indeterminateBarAnimationTime = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 370 */     this.wasIndeterminate = false; this.barWidth = ((int)(paramProgressBar.getWidth() - snappedLeftInset() - snappedRightInset()) * 2) * Math.min(1.0D, Math.max(0.0D, paramProgressBar.getProgress())) / 2.0D; paramProgressBar.widthProperty().addListener(paramObservable -> updateProgress()); initialize(); getSkinnable().requestLayout();
/*     */   } private BooleanProperty indeterminateBarFlipProperty() { if (this.indeterminateBarFlip == null) this.indeterminateBarFlip = new StyleableBooleanProperty(true) { public Object getBean() { return ProgressBarSkin.this; } public String getName() { return "indeterminateBarFlip"; } public CssMetaData<ProgressBar, Boolean> getCssMetaData() { return ProgressBarSkin.StyleableProperties.INDETERMINATE_BAR_FLIP; } }
/*     */         ;  return this.indeterminateBarFlip; } private Boolean getIndeterminateBarFlip() { return Boolean.valueOf((this.indeterminateBarFlip == null) ? true : this.indeterminateBarFlip.get()); } private DoubleProperty indeterminateBarAnimationTimeProperty() { if (this.indeterminateBarAnimationTime == null) this.indeterminateBarAnimationTime = new StyleableDoubleProperty(2.0D) {
/*     */           public Object getBean() { return ProgressBarSkin.this; } public String getName() { return "indeterminateBarAnimationTime"; } public CssMetaData<ProgressBar, Number> getCssMetaData() { return ProgressBarSkin.StyleableProperties.INDETERMINATE_BAR_ANIMATION_TIME; }
/* 374 */         };  return this.indeterminateBarAnimationTime; } private double getIndeterminateBarAnimationTime() { return (this.indeterminateBarAnimationTime == null) ? 2.0D : this.indeterminateBarAnimationTime.get(); } public double computeBaselineOffset(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { return Double.NEGATIVE_INFINITY; } protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return Math.max(100.0D, paramDouble5 + this.bar.prefWidth(getSkinnable().getWidth()) + paramDouble3); } protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return paramDouble2 + this.bar.prefHeight(paramDouble1) + paramDouble4; } protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return getSkinnable().prefWidth(paramDouble1); } void updateProgress() { ProgressIndicator progressIndicator = getSkinnable();
/*     */     
/* 376 */     boolean bool = progressIndicator.isIndeterminate();
/* 377 */     if (!bool || !this.wasIndeterminate) {
/* 378 */       this.barWidth = ((int)(progressIndicator.getWidth() - snappedLeftInset() - snappedRightInset()) * 2) * Math.min(1.0D, Math.max(0.0D, progressIndicator.getProgress())) / 2.0D;
/* 379 */       getSkinnable().requestLayout();
/*     */     } 
/* 381 */     this.wasIndeterminate = bool; }
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return getSkinnable().prefHeight(paramDouble1); }
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { ProgressIndicator progressIndicator = getSkinnable(); boolean bool = progressIndicator.isIndeterminate(); this.clipRegion.resizeRelocate(0.0D, 0.0D, paramDouble3, paramDouble4); this.track.resizeRelocate(paramDouble1, paramDouble2, paramDouble3, paramDouble4); this.bar.resizeRelocate(paramDouble1, paramDouble2, bool ? getIndeterminateBarLength().doubleValue() : this.barWidth, paramDouble4); this.track.setVisible(true); if (bool) { createIndeterminateTimeline(); if (NodeHelper.isTreeShowing(getSkinnable()))
/*     */         this.indeterminateTransition.play();  this.bar.setClip(this.clipRegion); }
/*     */     else if (this.indeterminateTransition != null)
/*     */     { this.indeterminateTransition.stop(); this.indeterminateTransition = null; this.bar.setClip(null); this.bar.setScaleX(1.0D); this.bar.setTranslateX(0.0D); this.clipRegion.translateXProperty().unbind(); }
/*     */      } void initialize() { this.track = new StackPane(); this.track.getStyleClass().setAll(new String[] { "track" }); this.bar = new StackPane(); this.bar.getStyleClass().setAll(new String[] { "bar" }); getChildren().setAll(new Node[] { this.track, this.bar }); this.clipRegion = new Region(); this.bar.backgroundProperty().addListener((paramObservableValue, paramBackground1, paramBackground2) -> {
/*     */           if (paramBackground2 != null && !paramBackground2.getFills().isEmpty()) {
/*     */             BackgroundFill[] arrayOfBackgroundFill = new BackgroundFill[paramBackground2.getFills().size()]; for (byte b = 0; b < paramBackground2.getFills().size(); b++) {
/*     */               BackgroundFill backgroundFill = paramBackground2.getFills().get(b); arrayOfBackgroundFill[b] = new BackgroundFill(Color.BLACK, backgroundFill.getRadii(), backgroundFill.getInsets());
/*     */             }  this.clipRegion.setBackground(new Background(arrayOfBackgroundFill));
/*     */           } 
/*     */         }); } void createIndeterminateTimeline() { if (this.indeterminateTransition != null)
/*     */       this.indeterminateTransition.stop();  ProgressIndicator progressIndicator = getSkinnable(); double d1 = progressIndicator.getWidth() - snappedLeftInset() + snappedRightInset(); double d2 = getIndeterminateBarEscape().booleanValue() ? -getIndeterminateBarLength().doubleValue() : 0.0D; double d3 = getIndeterminateBarEscape().booleanValue() ? d1 : (d1 - getIndeterminateBarLength().doubleValue()); this.indeterminateTransition = new IndeterminateTransition(d2, d3, this); this.indeterminateTransition.setCycleCount(-1); this.clipRegion.translateXProperty().bind((new When(this.bar.scaleXProperty().isEqualTo(-1.0D, 1.0E-100D))).then(this.bar.translateXProperty().subtract(d1).add(indeterminateBarLengthProperty())).otherwise(this.bar.translateXProperty().negate())); } private static class StyleableProperties
/*     */   {
/* 396 */     private static final CssMetaData<ProgressBar, Number> INDETERMINATE_BAR_LENGTH = new CssMetaData<ProgressBar, Number>("-fx-indeterminate-bar-length", 
/*     */         
/* 398 */         SizeConverter.getInstance(), Double.valueOf(60.0D))
/*     */       {
/*     */         public boolean isSettable(ProgressBar param2ProgressBar)
/*     */         {
/* 402 */           ProgressBarSkin progressBarSkin = (ProgressBarSkin)param2ProgressBar.getSkin();
/* 403 */           return (progressBarSkin.indeterminateBarLength == null || 
/* 404 */             !progressBarSkin.indeterminateBarLength.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(ProgressBar param2ProgressBar) {
/* 409 */           ProgressBarSkin progressBarSkin = (ProgressBarSkin)param2ProgressBar.getSkin();
/* 410 */           return (StyleableProperty<Number>)progressBarSkin.indeterminateBarLengthProperty();
/*     */         }
/*     */       };
/*     */     
/* 414 */     private static final CssMetaData<ProgressBar, Boolean> INDETERMINATE_BAR_ESCAPE = new CssMetaData<ProgressBar, Boolean>("-fx-indeterminate-bar-escape", 
/*     */         
/* 416 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(ProgressBar param2ProgressBar)
/*     */         {
/* 420 */           ProgressBarSkin progressBarSkin = (ProgressBarSkin)param2ProgressBar.getSkin();
/* 421 */           return (progressBarSkin.indeterminateBarEscape == null || 
/* 422 */             !progressBarSkin.indeterminateBarEscape.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(ProgressBar param2ProgressBar) {
/* 427 */           ProgressBarSkin progressBarSkin = (ProgressBarSkin)param2ProgressBar.getSkin();
/* 428 */           return (StyleableProperty<Boolean>)progressBarSkin.indeterminateBarEscapeProperty();
/*     */         }
/*     */       };
/*     */     
/* 432 */     private static final CssMetaData<ProgressBar, Boolean> INDETERMINATE_BAR_FLIP = new CssMetaData<ProgressBar, Boolean>("-fx-indeterminate-bar-flip", 
/*     */         
/* 434 */         BooleanConverter.getInstance(), Boolean.TRUE)
/*     */       {
/*     */         public boolean isSettable(ProgressBar param2ProgressBar)
/*     */         {
/* 438 */           ProgressBarSkin progressBarSkin = (ProgressBarSkin)param2ProgressBar.getSkin();
/* 439 */           return (progressBarSkin.indeterminateBarFlip == null || 
/* 440 */             !progressBarSkin.indeterminateBarFlip.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Boolean> getStyleableProperty(ProgressBar param2ProgressBar) {
/* 445 */           ProgressBarSkin progressBarSkin = (ProgressBarSkin)param2ProgressBar.getSkin();
/* 446 */           return (StyleableProperty<Boolean>)progressBarSkin.indeterminateBarFlipProperty();
/*     */         }
/*     */       };
/*     */     
/* 450 */     private static final CssMetaData<ProgressBar, Number> INDETERMINATE_BAR_ANIMATION_TIME = new CssMetaData<ProgressBar, Number>("-fx-indeterminate-bar-animation-time", 
/*     */         
/* 452 */         SizeConverter.getInstance(), Double.valueOf(2.0D))
/*     */       {
/*     */         public boolean isSettable(ProgressBar param2ProgressBar)
/*     */         {
/* 456 */           ProgressBarSkin progressBarSkin = (ProgressBarSkin)param2ProgressBar.getSkin();
/* 457 */           return (progressBarSkin.indeterminateBarAnimationTime == null || 
/* 458 */             !progressBarSkin.indeterminateBarAnimationTime.isBound());
/*     */         }
/*     */ 
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(ProgressBar param2ProgressBar) {
/* 463 */           ProgressBarSkin progressBarSkin = (ProgressBarSkin)param2ProgressBar.getSkin();
/* 464 */           return (StyleableProperty<Number>)progressBarSkin.indeterminateBarAnimationTimeProperty();
/*     */         }
/*     */       };
/*     */ 
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 472 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(SkinBase.getClassCssMetaData());
/* 473 */       arrayList.add(INDETERMINATE_BAR_LENGTH);
/* 474 */       arrayList.add(INDETERMINATE_BAR_ESCAPE);
/* 475 */       arrayList.add(INDETERMINATE_BAR_FLIP);
/* 476 */       arrayList.add(INDETERMINATE_BAR_ANIMATION_TIME);
/* 477 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 488 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 495 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class IndeterminateTransition
/*     */     extends Transition
/*     */   {
/*     */     private final WeakReference<ProgressBarSkin> skin;
/*     */     
/*     */     private final double startX;
/*     */     
/*     */     private final double endX;
/*     */     
/*     */     private final boolean flip;
/*     */ 
/*     */     
/*     */     public IndeterminateTransition(double param1Double1, double param1Double2, ProgressBarSkin param1ProgressBarSkin) {
/* 513 */       this.startX = param1Double1;
/* 514 */       this.endX = param1Double2;
/* 515 */       this.skin = new WeakReference<>(param1ProgressBarSkin);
/* 516 */       this.flip = param1ProgressBarSkin.getIndeterminateBarFlip().booleanValue();
/* 517 */       param1ProgressBarSkin.getIndeterminateBarEscape();
/* 518 */       setCycleDuration(Duration.seconds(param1ProgressBarSkin.getIndeterminateBarAnimationTime() * (this.flip ? 2 : true)));
/*     */     }
/*     */ 
/*     */     
/*     */     protected void interpolate(double param1Double) {
/* 523 */       ProgressBarSkin progressBarSkin = this.skin.get();
/* 524 */       if (progressBarSkin == null) {
/* 525 */         stop();
/*     */       }
/* 527 */       else if (param1Double <= 0.5D || !this.flip) {
/* 528 */         progressBarSkin.bar.setScaleX(-1.0D);
/* 529 */         progressBarSkin.bar.setTranslateX(this.startX + (this.flip ? 2 : true) * param1Double * (this.endX - this.startX));
/*     */       } else {
/* 531 */         progressBarSkin.bar.setScaleX(1.0D);
/* 532 */         progressBarSkin.bar.setTranslateX(this.startX + 2.0D * (1.0D - param1Double) * (this.endX - this.startX));
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ProgressBarSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */