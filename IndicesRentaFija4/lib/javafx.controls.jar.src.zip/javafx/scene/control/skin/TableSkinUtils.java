/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.TableColumnBaseHelper;
/*     */ import com.sun.javafx.scene.control.TreeTableViewBackingList;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ResizeFeaturesBase;
/*     */ import javafx.scene.control.TableCell;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TableFocusModel;
/*     */ import javafx.scene.control.TablePositionBase;
/*     */ import javafx.scene.control.TableSelectionModel;
/*     */ import javafx.scene.control.TableView;
/*     */ import javafx.scene.control.TreeTableCell;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ import javafx.scene.control.TreeTableRow;
/*     */ import javafx.scene.control.TreeTableView;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TableSkinUtils
/*     */ {
/*     */   public static boolean resizeColumn(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase, TableColumnBase<?, ?> paramTableColumnBase, double paramDouble) {
/*  63 */     if (!paramTableColumnBase.isResizable()) return false;
/*     */     
/*  65 */     Object object = paramTableViewSkinBase.getSkinnable();
/*  66 */     if (object instanceof TableView)
/*  67 */       return ((TableView)object).resizeColumn((TableColumn)paramTableColumnBase, paramDouble); 
/*  68 */     if (object instanceof TreeTableView) {
/*  69 */       return ((TreeTableView)object).resizeColumn((TreeTableColumn)paramTableColumnBase, paramDouble);
/*     */     }
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resizeColumnToFitContent(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase, TableColumnBase<?, ?> paramTableColumnBase, int paramInt) {
/*  82 */     if (!paramTableColumnBase.isResizable())
/*     */       return; 
/*  84 */     Object object = paramTableViewSkinBase.getSkinnable();
/*  85 */     if (object instanceof TableView) {
/*  86 */       resizeColumnToFitContent((TableView)object, (TableColumn<?, ?>)paramTableColumnBase, paramTableViewSkinBase, paramInt);
/*  87 */     } else if (object instanceof TreeTableView) {
/*  88 */       resizeColumnToFitContent((TreeTableView)object, (TreeTableColumn<?, ?>)paramTableColumnBase, paramTableViewSkinBase, paramInt);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static <T, S> void resizeColumnToFitContent(TableView<T> paramTableView, TableColumn<T, S> paramTableColumn, TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase, int paramInt) {
/*  93 */     ObservableList<T> observableList = paramTableView.getItems();
/*  94 */     if (observableList == null || observableList.isEmpty())
/*     */       return; 
/*  96 */     Callback<TableColumn<T, S>, TableCell<T, S>> callback = paramTableColumn.getCellFactory();
/*  97 */     if (callback == null)
/*     */       return; 
/*  99 */     TableCell tableCell = callback.call(paramTableColumn);
/* 100 */     if (tableCell == null) {
/*     */       return;
/*     */     }
/*     */     
/* 104 */     tableCell.getProperties().put("deferToParentPrefWidth", Boolean.TRUE);
/*     */ 
/*     */     
/* 107 */     double d1 = 10.0D;
/* 108 */     Node node1 = (tableCell.getSkin() == null) ? null : tableCell.getSkin().getNode();
/* 109 */     if (node1 instanceof Region) {
/* 110 */       Region region = (Region)node1;
/* 111 */       d1 = region.snappedLeftInset() + region.snappedRightInset();
/*     */     } 
/*     */     
/* 114 */     int i = (paramInt == -1) ? observableList.size() : Math.min(observableList.size(), paramInt);
/* 115 */     double d2 = 0.0D;
/* 116 */     for (byte b = 0; b < i; b++) {
/* 117 */       tableCell.updateTableColumn(paramTableColumn);
/* 118 */       tableCell.updateTableView(paramTableView);
/* 119 */       tableCell.updateIndex(b);
/*     */       
/* 121 */       if ((tableCell.getText() != null && !tableCell.getText().isEmpty()) || tableCell.getGraphic() != null) {
/* 122 */         paramTableViewSkinBase.getChildren().add(tableCell);
/* 123 */         tableCell.applyCss();
/* 124 */         d2 = Math.max(d2, tableCell.prefWidth(-1.0D));
/* 125 */         paramTableViewSkinBase.getChildren().remove(tableCell);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 130 */     tableCell.updateIndex(-1);
/*     */ 
/*     */ 
/*     */     
/* 134 */     TableColumnHeader tableColumnHeader = paramTableViewSkinBase.getTableHeaderRow().getColumnHeaderFor(paramTableColumn);
/* 135 */     double d3 = Utils.computeTextWidth(tableColumnHeader.label.getFont(), paramTableColumn.getText(), -1.0D);
/* 136 */     Node node2 = tableColumnHeader.label.getGraphic();
/* 137 */     double d4 = (node2 == null) ? 0.0D : (node2.prefWidth(-1.0D) + tableColumnHeader.label.getGraphicTextGap());
/* 138 */     double d5 = d3 + d4 + 10.0D + tableColumnHeader.snappedLeftInset() + tableColumnHeader.snappedRightInset();
/* 139 */     d2 = Math.max(d2, d5);
/*     */ 
/*     */     
/* 142 */     d2 += d1;
/* 143 */     if (paramTableView.getColumnResizePolicy() == TableView.CONSTRAINED_RESIZE_POLICY && paramTableView.getWidth() > 0.0D) {
/*     */       
/* 145 */       if (d2 > paramTableColumn.getMaxWidth()) {
/* 146 */         d2 = paramTableColumn.getMaxWidth();
/*     */       }
/*     */       
/* 149 */       int j = paramTableColumn.getColumns().size();
/* 150 */       if (j > 0) {
/* 151 */         resizeColumnToFitContent(paramTableViewSkinBase, paramTableColumn.getColumns().get(j - 1), paramInt);
/*     */         
/*     */         return;
/*     */       } 
/* 155 */       resizeColumn(paramTableViewSkinBase, paramTableColumn, Math.round(d2 - paramTableColumn.getWidth()));
/*     */     } else {
/* 157 */       TableColumnBaseHelper.setWidth(paramTableColumn, d2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T, S> void resizeColumnToFitContent(TreeTableView<T> paramTreeTableView, TreeTableColumn<T, S> paramTreeTableColumn, TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase, int paramInt) {
/* 169 */     TreeTableViewBackingList treeTableViewBackingList = new TreeTableViewBackingList(paramTreeTableView);
/* 170 */     if (treeTableViewBackingList == null || treeTableViewBackingList.isEmpty())
/*     */       return; 
/* 172 */     Callback<TreeTableColumn<T, S>, TreeTableCell<T, S>> callback = paramTreeTableColumn.getCellFactory();
/* 173 */     if (callback == null)
/*     */       return; 
/* 175 */     TreeTableCell<T, S> treeTableCell = callback.call(paramTreeTableColumn);
/* 176 */     if (treeTableCell == null) {
/*     */       return;
/*     */     }
/*     */     
/* 180 */     treeTableCell.getProperties().put("deferToParentPrefWidth", Boolean.TRUE);
/*     */ 
/*     */     
/* 183 */     double d1 = 10.0D;
/* 184 */     Node node1 = (treeTableCell.getSkin() == null) ? null : treeTableCell.getSkin().getNode();
/* 185 */     if (node1 instanceof Region) {
/* 186 */       Region region = (Region)node1;
/* 187 */       d1 = region.snappedLeftInset() + region.snappedRightInset();
/*     */     } 
/*     */     
/* 190 */     TreeTableRow<T> treeTableRow = new TreeTableRow();
/* 191 */     treeTableRow.updateTreeTableView(paramTreeTableView);
/*     */     
/* 193 */     int i = (paramInt == -1) ? treeTableViewBackingList.size() : Math.min(treeTableViewBackingList.size(), paramInt);
/* 194 */     double d2 = 0.0D;
/* 195 */     for (byte b = 0; b < i; b++) {
/* 196 */       treeTableRow.updateIndex(b);
/* 197 */       treeTableRow.updateTreeItem(paramTreeTableView.getTreeItem(b));
/*     */       
/* 199 */       treeTableCell.updateTreeTableColumn(paramTreeTableColumn);
/* 200 */       treeTableCell.updateTreeTableView(paramTreeTableView);
/* 201 */       treeTableCell.updateTreeTableRow(treeTableRow);
/* 202 */       treeTableCell.updateIndex(b);
/*     */       
/* 204 */       if ((treeTableCell.getText() != null && !treeTableCell.getText().isEmpty()) || treeTableCell.getGraphic() != null) {
/* 205 */         paramTableViewSkinBase.getChildren().add(treeTableCell);
/* 206 */         treeTableCell.applyCss();
/*     */         
/* 208 */         double d = treeTableCell.prefWidth(-1.0D);
/*     */         
/* 210 */         d2 = Math.max(d2, d);
/* 211 */         paramTableViewSkinBase.getChildren().remove(treeTableCell);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 216 */     treeTableCell.updateIndex(-1);
/*     */ 
/*     */ 
/*     */     
/* 220 */     TableColumnHeader tableColumnHeader = paramTableViewSkinBase.getTableHeaderRow().getColumnHeaderFor(paramTreeTableColumn);
/* 221 */     double d3 = Utils.computeTextWidth(tableColumnHeader.label.getFont(), paramTreeTableColumn.getText(), -1.0D);
/* 222 */     Node node2 = tableColumnHeader.label.getGraphic();
/* 223 */     double d4 = (node2 == null) ? 0.0D : (node2.prefWidth(-1.0D) + tableColumnHeader.label.getGraphicTextGap());
/* 224 */     double d5 = d3 + d4 + 10.0D + tableColumnHeader.snappedLeftInset() + tableColumnHeader.snappedRightInset();
/* 225 */     d2 = Math.max(d2, d5);
/*     */ 
/*     */     
/* 228 */     d2 += d1;
/* 229 */     if (paramTreeTableView.getColumnResizePolicy() == TreeTableView.CONSTRAINED_RESIZE_POLICY && paramTreeTableView.getWidth() > 0.0D) {
/*     */       
/* 231 */       if (d2 > paramTreeTableColumn.getMaxWidth()) {
/* 232 */         d2 = paramTreeTableColumn.getMaxWidth();
/*     */       }
/*     */       
/* 235 */       int j = paramTreeTableColumn.getColumns().size();
/* 236 */       if (j > 0) {
/* 237 */         resizeColumnToFitContent(paramTableViewSkinBase, paramTreeTableColumn.getColumns().get(j - 1), paramInt);
/*     */         
/*     */         return;
/*     */       } 
/* 241 */       resizeColumn(paramTableViewSkinBase, paramTreeTableColumn, Math.round(d2 - paramTreeTableColumn.getWidth()));
/*     */     } else {
/* 243 */       TableColumnBaseHelper.setWidth(paramTreeTableColumn, d2);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ObjectProperty<Callback<ResizeFeaturesBase, Boolean>> columnResizePolicyProperty(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase) {
/* 248 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 249 */     if (object instanceof TableView)
/* 250 */       return (ObjectProperty)((TableView)object).columnResizePolicyProperty(); 
/* 251 */     if (object instanceof TreeTableView) {
/* 252 */       return (ObjectProperty)((TreeTableView)object).columnResizePolicyProperty();
/*     */     }
/* 254 */     return null;
/*     */   }
/*     */   
/*     */   public static BooleanProperty tableMenuButtonVisibleProperty(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase) {
/* 258 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 259 */     if (object instanceof TableView)
/* 260 */       return ((TableView)object).tableMenuButtonVisibleProperty(); 
/* 261 */     if (object instanceof TreeTableView) {
/* 262 */       return ((TreeTableView)object).tableMenuButtonVisibleProperty();
/*     */     }
/* 264 */     return null;
/*     */   }
/*     */   
/*     */   public static ObjectProperty<Node> placeholderProperty(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase) {
/* 268 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 269 */     if (object instanceof TableView)
/* 270 */       return ((TableView)object).placeholderProperty(); 
/* 271 */     if (object instanceof TreeTableView) {
/* 272 */       return ((TreeTableView)object).placeholderProperty();
/*     */     }
/* 274 */     return null;
/*     */   }
/*     */   
/*     */   public static <C extends javafx.scene.control.Control, I extends javafx.scene.control.IndexedCell<?>> ObjectProperty<Callback<C, I>> rowFactoryProperty(TableViewSkinBase<?, ?, C, I, ?> paramTableViewSkinBase) {
/* 278 */     C c = paramTableViewSkinBase.getSkinnable();
/* 279 */     if (c instanceof TableView)
/* 280 */       return ((TableView)c).rowFactoryProperty(); 
/* 281 */     if (c instanceof TreeTableView) {
/* 282 */       return ((TreeTableView)c).rowFactoryProperty();
/*     */     }
/* 284 */     return null;
/*     */   }
/*     */   
/*     */   public static ObservableList<TableColumnBase<?, ?>> getSortOrder(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase) {
/* 288 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 289 */     if (object instanceof TableView)
/* 290 */       return (ObservableList)((TableView)object).getSortOrder(); 
/* 291 */     if (object instanceof TreeTableView) {
/* 292 */       return (ObservableList)((TreeTableView)object).getSortOrder();
/*     */     }
/* 294 */     return FXCollections.emptyObservableList();
/*     */   }
/*     */   
/*     */   public static ObservableList<TableColumnBase<?, ?>> getColumns(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase) {
/* 298 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 299 */     if (object instanceof TableView)
/* 300 */       return (ObservableList)((TableView)object).getColumns(); 
/* 301 */     if (object instanceof TreeTableView) {
/* 302 */       return (ObservableList)((TreeTableView)object).getColumns();
/*     */     }
/* 304 */     return FXCollections.emptyObservableList();
/*     */   }
/*     */   
/*     */   public static <T> TableSelectionModel<T> getSelectionModel(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase) {
/* 308 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 309 */     if (object instanceof TableView)
/* 310 */       return ((TableView<T>)object).getSelectionModel(); 
/* 311 */     if (object instanceof TreeTableView) {
/* 312 */       return ((TreeTableView)object).getSelectionModel();
/*     */     }
/* 314 */     return null;
/*     */   }
/*     */   
/*     */   public static <T> TableFocusModel<T, ?> getFocusModel(TableViewSkinBase<T, ?, ?, ?, ?> paramTableViewSkinBase) {
/* 318 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 319 */     if (object instanceof TableView)
/* 320 */       return ((TableView<T>)object).getFocusModel(); 
/* 321 */     if (object instanceof TreeTableView) {
/* 322 */       return ((TreeTableView)object).getFocusModel();
/*     */     }
/* 324 */     return null;
/*     */   }
/*     */   
/*     */   public static <T, TC extends TableColumnBase<T, ?>> TablePositionBase<? extends TC> getFocusedCell(TableViewSkinBase<?, T, ?, ?, TC> paramTableViewSkinBase) {
/* 328 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 329 */     if (object instanceof TableView)
/* 330 */       return ((TableView)object).getFocusModel().getFocusedCell(); 
/* 331 */     if (object instanceof TreeTableView) {
/* 332 */       return ((TreeTableView)object).getFocusModel().getFocusedCell();
/*     */     }
/* 334 */     return null;
/*     */   }
/*     */   
/*     */   public static <TC extends TableColumnBase<?, ?>> ObservableList<TC> getVisibleLeafColumns(TableViewSkinBase<?, ?, ?, ?, TC> paramTableViewSkinBase) {
/* 338 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 339 */     if (object instanceof TableView)
/* 340 */       return ((TableView)object).getVisibleLeafColumns(); 
/* 341 */     if (object instanceof TreeTableView) {
/* 342 */       return ((TreeTableView)object).getVisibleLeafColumns();
/*     */     }
/* 344 */     return FXCollections.emptyObservableList();
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getVisibleLeafIndex(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase, TableColumnBase paramTableColumnBase) {
/* 349 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 350 */     if (object instanceof TableView)
/* 351 */       return ((TableView)object).getVisibleLeafIndex((TableColumn)paramTableColumnBase); 
/* 352 */     if (object instanceof TreeTableView) {
/* 353 */       return ((TreeTableView)object).getVisibleLeafIndex((TreeTableColumn)paramTableColumnBase);
/*     */     }
/* 355 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T, TC extends TableColumnBase<T, ?>> TC getVisibleLeafColumn(TableViewSkinBase<?, T, ?, ?, TC> paramTableViewSkinBase, int paramInt) {
/* 360 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 361 */     if (object instanceof TableView)
/* 362 */       return (TC)((TableView)object).getVisibleLeafColumn(paramInt); 
/* 363 */     if (object instanceof TreeTableView) {
/* 364 */       return (TC)((TreeTableView)object).getVisibleLeafColumn(paramInt);
/*     */     }
/* 366 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> ObjectProperty<ObservableList<T>> itemsProperty(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase) {
/* 371 */     Object object = paramTableViewSkinBase.getSkinnable();
/* 372 */     if (object instanceof TableView)
/* 373 */       return ((TableView<T>)object).itemsProperty(); 
/* 374 */     if (object instanceof TreeTableView && paramTableViewSkinBase instanceof TreeTableViewSkin) {
/* 375 */       TreeTableViewSkin treeTableViewSkin = (TreeTableViewSkin)paramTableViewSkinBase;
/* 376 */       if (treeTableViewSkin.tableBackingListProperty == null) {
/* 377 */         treeTableViewSkin.tableBackingList = new TreeTableViewBackingList((TreeTableView)object);
/* 378 */         treeTableViewSkin.tableBackingListProperty = new SimpleObjectProperty<>(treeTableViewSkin.tableBackingList);
/*     */       } 
/* 380 */       return treeTableViewSkin.tableBackingListProperty;
/*     */     } 
/* 382 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TableSkinUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */