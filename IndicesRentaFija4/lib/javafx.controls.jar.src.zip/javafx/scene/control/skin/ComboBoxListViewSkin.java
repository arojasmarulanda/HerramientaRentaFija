/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.ComboBoxBaseBehavior;
/*     */ import com.sun.javafx.scene.control.behavior.ComboBoxListViewBehavior;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Parent;
/*     */ import javafx.scene.control.ComboBox;
/*     */ import javafx.scene.control.ListCell;
/*     */ import javafx.scene.control.ListView;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.control.SelectionMode;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.util.Callback;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboBoxListViewSkin<T>
/*     */   extends ComboBoxPopupControl<T>
/*     */ {
/*     */   private static final String COMBO_BOX_ROWS_TO_MEASURE_WIDTH_KEY = "comboBoxRowsToMeasureWidth";
/*     */   private final ComboBox<T> comboBox;
/*     */   private ObservableList<T> comboBoxItems;
/*     */   private ListCell<T> buttonCell;
/*     */   private Callback<ListView<T>, ListCell<T>> cellFactory;
/*     */   private final ListView<T> listView;
/*     */   private ObservableList<T> listViewItems;
/*     */   private boolean listSelectionLock = false;
/*     */   private boolean listViewSelectionDirty = false;
/*     */   private final ComboBoxListViewBehavior behavior;
/*     */   private boolean itemCountDirty;
/*     */   
/* 111 */   private final ListChangeListener<T> listViewItemsListener = new ListChangeListener<T>() {
/*     */       public void onChanged(ListChangeListener.Change<? extends T> param1Change) {
/* 113 */         ComboBoxListViewSkin.this.itemCountDirty = true;
/* 114 */         ComboBoxListViewSkin.this.getSkinnable().requestLayout();
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private final InvalidationListener itemsObserver;
/* 120 */   private final WeakListChangeListener<T> weakListViewItemsListener = new WeakListChangeListener<>(this.listViewItemsListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final BooleanProperty hideOnClick;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboBoxListViewSkin(ComboBox<T> paramComboBox) {
/* 138 */     super(paramComboBox);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     this.hideOnClick = new SimpleBooleanProperty(this, "hideOnClick", true); this.behavior = new ComboBoxListViewBehavior<>(paramComboBox); this.comboBox = paramComboBox; updateComboBoxItems(); this.itemsObserver = (paramObservable -> { updateComboBoxItems(); updateListViewItems(); }); paramComboBox.itemsProperty().addListener(new WeakInvalidationListener(this.itemsObserver)); this.listView = createListView(); this.listView.setManaged(false); getChildren().add(this.listView); updateListViewItems(); updateCellFactory(); updateButtonCell(); updateValue(); registerChangeListener(paramComboBox.itemsProperty(), paramObservableValue -> { updateComboBoxItems(); updateListViewItems(); }); registerChangeListener(paramComboBox.promptTextProperty(), paramObservableValue -> updateDisplayNode()); registerChangeListener(paramComboBox.cellFactoryProperty(), paramObservableValue -> updateCellFactory()); registerChangeListener(paramComboBox.visibleRowCountProperty(), paramObservableValue -> { if (this.listView == null) return;  this.listView.requestLayout(); }); registerChangeListener(paramComboBox.converterProperty(), paramObservableValue -> updateListViewItems()); registerChangeListener(paramComboBox.buttonCellProperty(), paramObservableValue -> { updateButtonCell(); updateDisplayArea(); }); registerChangeListener(paramComboBox.valueProperty(), paramObservableValue -> { updateValue(); paramComboBox.fireEvent(new ActionEvent()); }); registerChangeListener(paramComboBox.editableProperty(), paramObservableValue -> updateEditable()); if (this.comboBox.isShowing())
/*     */       show();  this.comboBox.sceneProperty().addListener(paramObservable -> { if (((ObservableValue)paramObservable).getValue() == null)
/* 218 */             this.comboBox.hide();  }); } public final BooleanProperty hideOnClickProperty() { return this.hideOnClick; }
/*     */   
/*     */   public final boolean isHideOnClick() {
/* 221 */     return this.hideOnClick.get();
/*     */   }
/*     */   public final void setHideOnClick(boolean paramBoolean) {
/* 224 */     this.hideOnClick.set(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 237 */     super.dispose();
/*     */     
/* 239 */     if (this.behavior != null) {
/* 240 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TextField getEditor() {
/* 249 */     return getSkinnable().isEditable() ? ((ComboBox)getSkinnable()).getEditor() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringConverter<T> getConverter() {
/* 254 */     return ((ComboBox<T>)getSkinnable()).getConverter();
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getDisplayNode() {
/*     */     ListCell<T> listCell;
/* 260 */     if (this.comboBox.isEditable()) {
/* 261 */       TextField textField = getEditableInputNode();
/*     */     } else {
/* 263 */       listCell = this.buttonCell;
/*     */     } 
/*     */     
/* 266 */     updateDisplayNode();
/*     */     
/* 268 */     return listCell;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getPopupContent() {
/* 273 */     return this.listView;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 278 */     reconfigurePopup();
/* 279 */     return 50.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 284 */     double d1 = super.computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/* 285 */     double d2 = this.listView.prefWidth(paramDouble1);
/* 286 */     double d3 = Math.max(d1, d2);
/*     */     
/* 288 */     reconfigurePopup();
/*     */     
/* 290 */     return d3;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 295 */     reconfigurePopup();
/* 296 */     return super.computeMaxWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 301 */     reconfigurePopup();
/* 302 */     return super.computeMinHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 307 */     reconfigurePopup();
/* 308 */     return super.computePrefHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 313 */     reconfigurePopup();
/* 314 */     return super.computeMaxHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 320 */     if (this.listViewSelectionDirty) {
/*     */       try {
/* 322 */         this.listSelectionLock = true;
/* 323 */         Object object = this.comboBox.getSelectionModel().getSelectedItem();
/* 324 */         this.listView.getSelectionModel().clearSelection();
/* 325 */         this.listView.getSelectionModel().select(object);
/*     */       } finally {
/* 327 */         this.listSelectionLock = false;
/* 328 */         this.listViewSelectionDirty = false;
/*     */       } 
/*     */     }
/*     */     
/* 332 */     super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateDisplayNode() {
/* 345 */     if (getEditor() != null) {
/* 346 */       super.updateDisplayNode();
/*     */     } else {
/* 348 */       T t = this.comboBox.getValue();
/* 349 */       int i = getIndexOfComboBoxValueInItemsList();
/* 350 */       if (i > -1) {
/* 351 */         this.buttonCell.setItem((T)null);
/* 352 */         this.buttonCell.updateIndex(i);
/*     */       }
/*     */       else {
/*     */         
/* 356 */         this.buttonCell.updateIndex(-1);
/* 357 */         boolean bool = updateDisplayText(this.buttonCell, t, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 364 */         this.buttonCell.pseudoClassStateChanged(PSEUDO_CLASS_EMPTY, bool);
/* 365 */         this.buttonCell.pseudoClassStateChanged(PSEUDO_CLASS_FILLED, !bool);
/* 366 */         this.buttonCell.pseudoClassStateChanged(PSEUDO_CLASS_SELECTED, true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   ComboBoxBaseBehavior getBehavior() {
/* 373 */     return this.behavior;
/*     */   }
/*     */   
/*     */   private void updateComboBoxItems() {
/* 377 */     this.comboBoxItems = this.comboBox.getItems();
/* 378 */     this.comboBoxItems = (this.comboBoxItems == null) ? FXCollections.<T>emptyObservableList() : this.comboBoxItems;
/*     */   }
/*     */   
/*     */   private void updateListViewItems() {
/* 382 */     if (this.listViewItems != null) {
/* 383 */       this.listViewItems.removeListener(this.weakListViewItemsListener);
/*     */     }
/*     */     
/* 386 */     this.listViewItems = this.comboBoxItems;
/* 387 */     this.listView.setItems(this.listViewItems);
/*     */     
/* 389 */     if (this.listViewItems != null) {
/* 390 */       this.listViewItems.addListener(this.weakListViewItemsListener);
/*     */     }
/*     */     
/* 393 */     this.itemCountDirty = true;
/* 394 */     getSkinnable().requestLayout();
/*     */   }
/*     */   
/*     */   private void updateValue() {
/* 398 */     T t = this.comboBox.getValue();
/*     */     
/* 400 */     MultipleSelectionModel<T> multipleSelectionModel = this.listView.getSelectionModel();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 405 */     int i = getIndexOfComboBoxValueInItemsList();
/*     */     
/* 407 */     if (t == null && i == -1) {
/* 408 */       multipleSelectionModel.clearSelection();
/*     */     }
/* 410 */     else if (i == -1) {
/* 411 */       this.listSelectionLock = true;
/* 412 */       multipleSelectionModel.clearSelection();
/* 413 */       this.listSelectionLock = false;
/*     */     } else {
/* 415 */       int j = this.comboBox.getSelectionModel().getSelectedIndex();
/* 416 */       if (j >= 0 && j < this.comboBoxItems.size()) {
/* 417 */         T t1 = this.comboBoxItems.get(j);
/* 418 */         if ((t1 != null && t1.equals(t)) || (t1 == null && t == null)) {
/* 419 */           multipleSelectionModel.select(j);
/*     */         } else {
/* 421 */           multipleSelectionModel.select(t);
/*     */         } 
/*     */       } else {
/*     */         
/* 425 */         int k = this.comboBoxItems.indexOf(t);
/* 426 */         if (k == -1) {
/*     */ 
/*     */           
/* 429 */           updateDisplayNode();
/*     */         } else {
/* 431 */           multipleSelectionModel.select(k);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean updateDisplayText(ListCell<T> paramListCell, T paramT, boolean paramBoolean) {
/* 440 */     if (paramBoolean) {
/* 441 */       if (paramListCell == null) return true; 
/* 442 */       paramListCell.setGraphic((Node)null);
/* 443 */       paramListCell.setText((String)null);
/* 444 */       return true;
/* 445 */     }  if (paramT instanceof Node) {
/* 446 */       Node node1 = paramListCell.getGraphic();
/* 447 */       Node node2 = (Node)paramT;
/* 448 */       if (node1 == null || !node1.equals(node2)) {
/* 449 */         paramListCell.setText((String)null);
/* 450 */         paramListCell.setGraphic(node2);
/*     */       } 
/* 452 */       return (node2 == null);
/*     */     } 
/*     */     
/* 455 */     StringConverter<T> stringConverter = this.comboBox.getConverter();
/* 456 */     String str1 = this.comboBox.getPromptText();
/*     */     
/* 458 */     String str2 = (paramT == null && str1 != null) ? str1 : ((stringConverter == null) ? ((paramT == null) ? null : paramT.toString()) : stringConverter.toString(paramT));
/* 459 */     paramListCell.setText(str2);
/* 460 */     paramListCell.setGraphic((Node)null);
/* 461 */     return (str2 == null || str2.isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   private int getIndexOfComboBoxValueInItemsList() {
/* 466 */     T t = this.comboBox.getValue();
/* 467 */     return this.comboBoxItems.indexOf(t);
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateButtonCell() {
/* 472 */     this
/* 473 */       .buttonCell = (this.comboBox.getButtonCell() != null) ? this.comboBox.getButtonCell() : getDefaultCellFactory().call(this.listView);
/* 474 */     this.buttonCell.setMouseTransparent(true);
/* 475 */     this.buttonCell.updateListView(this.listView);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 480 */     this.buttonCell.setAccessibleRole(AccessibleRole.NODE);
/*     */   }
/*     */   
/*     */   private void updateCellFactory() {
/* 484 */     Callback<ListView<T>, ListCell<T>> callback = this.comboBox.getCellFactory();
/* 485 */     this.cellFactory = (callback != null) ? callback : getDefaultCellFactory();
/* 486 */     this.listView.setCellFactory(this.cellFactory);
/*     */   }
/*     */   
/*     */   private Callback<ListView<T>, ListCell<T>> getDefaultCellFactory() {
/* 490 */     return new Callback<ListView<T>, ListCell<T>>() {
/*     */         public ListCell<T> call(ListView<T> param1ListView) {
/* 492 */           return new ListCell<T>() {
/*     */               public void updateItem(T param2T, boolean param2Boolean) {
/* 494 */                 super.updateItem(param2T, param2Boolean);
/* 495 */                 ComboBoxListViewSkin.this.updateDisplayText(this, param2T, param2Boolean);
/*     */               }
/*     */             };
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private ListView<T> createListView() {
/* 503 */     ListView<T> listView = new ListView<T>()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         protected double computeMinHeight(double param1Double)
/*     */         {
/* 510 */           return 30.0D;
/*     */         }
/*     */         
/*     */         protected double computePrefWidth(double param1Double) {
/*     */           double d;
/* 515 */           if (getSkin() instanceof ListViewSkin) {
/* 516 */             ListViewSkin listViewSkin = (ListViewSkin)getSkin();
/* 517 */             if (ComboBoxListViewSkin.this.itemCountDirty) {
/* 518 */               listViewSkin.updateItemCount();
/* 519 */               ComboBoxListViewSkin.this.itemCountDirty = false;
/*     */             } 
/*     */             
/* 522 */             int i = -1;
/* 523 */             if (ComboBoxListViewSkin.this.comboBox.getProperties().containsKey("comboBoxRowsToMeasureWidth")) {
/* 524 */               i = ((Integer)ComboBoxListViewSkin.this.comboBox.getProperties().get("comboBoxRowsToMeasureWidth")).intValue();
/*     */             }
/*     */             
/* 527 */             d = Math.max(ComboBoxListViewSkin.this.comboBox.getWidth(), listViewSkin.getMaxCellWidth(i) + 30.0D);
/*     */           } else {
/* 529 */             d = Math.max(100.0D, ComboBoxListViewSkin.this.comboBox.getWidth());
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 534 */           if (getItems().isEmpty() && getPlaceholder() != null) {
/* 535 */             d = Math.max(super.computePrefWidth(param1Double), d);
/*     */           }
/*     */           
/* 538 */           return Math.max(50.0D, d);
/*     */         }
/*     */         
/*     */         protected double computePrefHeight(double param1Double) {
/* 542 */           return ComboBoxListViewSkin.this.getListViewPrefHeight();
/*     */         }
/*     */       };
/*     */     
/* 546 */     listView.setId("list-view");
/* 547 */     listView.placeholderProperty().bind(this.comboBox.placeholderProperty());
/* 548 */     listView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
/* 549 */     listView.setFocusTraversable(false);
/*     */     
/* 551 */     listView.getSelectionModel().selectedIndexProperty().addListener(paramObservable -> {
/*     */           if (this.listSelectionLock)
/*     */             return; 
/*     */           int i = this.listView.getSelectionModel().getSelectedIndex();
/*     */           this.comboBox.getSelectionModel().select(i);
/*     */           updateDisplayNode();
/*     */           this.comboBox.notifyAccessibleAttributeChanged(AccessibleAttribute.TEXT);
/*     */         });
/* 559 */     this.comboBox.getSelectionModel().selectedItemProperty().addListener(paramObservable -> this.listViewSelectionDirty = true);
/*     */ 
/*     */ 
/*     */     
/* 563 */     listView.addEventFilter(MouseEvent.MOUSE_RELEASED, paramMouseEvent -> {
/*     */           EventTarget eventTarget = paramMouseEvent.getTarget();
/*     */ 
/*     */           
/*     */           if (eventTarget instanceof Parent) {
/*     */             ObservableList<String> observableList = ((Parent)eventTarget).getStyleClass();
/*     */ 
/*     */             
/*     */             if (observableList.contains("thumb") || observableList.contains("track") || observableList.contains("decrement-arrow") || observableList.contains("increment-arrow")) {
/*     */               return;
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/*     */           if (isHideOnClick()) {
/*     */             this.comboBox.hide();
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 583 */     listView.setOnKeyPressed(paramKeyEvent -> {
/*     */           if (paramKeyEvent.getCode() == KeyCode.ENTER || paramKeyEvent.getCode() == KeyCode.SPACE || paramKeyEvent.getCode() == KeyCode.ESCAPE) {
/*     */             this.comboBox.hide();
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 592 */     return listView;
/*     */   }
/*     */   
/*     */   private double getListViewPrefHeight() {
/*     */     double d;
/* 597 */     if (this.listView.getSkin() instanceof VirtualContainerBase) {
/* 598 */       int i = this.comboBox.getVisibleRowCount();
/* 599 */       VirtualContainerBase virtualContainerBase = (VirtualContainerBase)this.listView.getSkin();
/* 600 */       d = virtualContainerBase.getVirtualFlowPreferredHeight(i);
/*     */     } else {
/* 602 */       double d1 = (this.comboBoxItems.size() * 25);
/* 603 */       d = Math.min(d1, 200.0D);
/*     */     } 
/*     */     
/* 606 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ListView<T> getListView() {
/* 618 */     return this.listView;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 632 */   private static final PseudoClass PSEUDO_CLASS_SELECTED = PseudoClass.getPseudoClass("selected");
/*     */   
/* 634 */   private static final PseudoClass PSEUDO_CLASS_EMPTY = PseudoClass.getPseudoClass("empty");
/*     */   
/* 636 */   private static final PseudoClass PSEUDO_CLASS_FILLED = PseudoClass.getPseudoClass("filled");
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/*     */     String str1;
/*     */     String str2;
/* 641 */     switch (paramAccessibleAttribute) {
/*     */       case FOCUS_ITEM:
/* 643 */         if (this.comboBox.isShowing())
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 649 */           return this.listView.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */         }
/* 651 */         return null;
/*     */       
/*     */       case TEXT:
/* 654 */         str1 = this.comboBox.getAccessibleText();
/* 655 */         if (str1 != null && !str1.isEmpty()) return str1; 
/* 656 */         str2 = this.comboBox.isEditable() ? getEditor().getText() : this.buttonCell.getText();
/* 657 */         if (str2 == null || str2.isEmpty()) {
/* 658 */           str2 = this.comboBox.getPromptText();
/*     */         }
/* 660 */         return str2;
/*     */       
/*     */       case SELECTION_START:
/* 663 */         return (getEditor() != null) ? Integer.valueOf(getEditor().getSelection().getStart()) : null;
/*     */       case SELECTION_END:
/* 665 */         return (getEditor() != null) ? Integer.valueOf(getEditor().getSelection().getEnd()) : null;
/* 666 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ComboBoxListViewSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */