/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.ContextMenuContent;
/*     */ import com.sun.javafx.scene.control.EmbeddedTextContextMenuContent;
/*     */ import com.sun.javafx.scene.control.Properties;
/*     */ import com.sun.javafx.scene.control.behavior.TwoLevelFocusPopupBehavior;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.Menu;
/*     */ import javafx.scene.control.Skin;
/*     */ import javafx.scene.control.Skinnable;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.VBox;
/*     */ import javafx.stage.WindowEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextMenuSkin
/*     */   implements Skin<ContextMenu>
/*     */ {
/*     */   private ContextMenu popupMenu;
/*     */   private final Region root;
/*     */   private TwoLevelFocusPopupBehavior tlFocus;
/*     */   private double prefHeight;
/*     */   private double shiftY;
/*     */   private double prefWidth;
/*     */   private double shiftX;
/*     */   
/*  88 */   private final EventHandler<KeyEvent> keyListener = new EventHandler<KeyEvent>() {
/*     */       public void handle(KeyEvent param1KeyEvent) {
/*  90 */         if (param1KeyEvent.getEventType() != KeyEvent.KEY_PRESSED) {
/*     */           return;
/*     */         }
/*  93 */         if (!ContextMenuSkin.this.root.isFocused())
/*     */           return; 
/*  95 */         KeyCode keyCode = param1KeyEvent.getCode();
/*  96 */         switch (keyCode) { case ENTER:
/*     */           case SPACE:
/*  98 */             ContextMenuSkin.this.popupMenu.hide();
/*     */             return; }
/*     */       
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextMenuSkin(ContextMenu paramContextMenu) {
/* 118 */     this.popupMenu = paramContextMenu;
/*     */     
/* 120 */     this.popupMenu.addEventHandler(Menu.ON_SHOWING, new EventHandler<Event>() {
/*     */           public void handle(Event param1Event) {
/* 122 */             ContextMenuSkin.this.prefHeight = ContextMenuSkin.this.root.prefHeight(-1.0D);
/* 123 */             ContextMenuSkin.this.prefWidth = ContextMenuSkin.this.root.prefWidth(-1.0D);
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 129 */     this.popupMenu.addEventHandler(Menu.ON_SHOWN, new EventHandler<Event>() {
/*     */           public void handle(Event param1Event) {
/* 131 */             Node node = ContextMenuSkin.this.popupMenu.getSkin().getNode();
/* 132 */             if (node != null)
/*     */             {
/* 134 */               if (node instanceof ContextMenuContent) {
/* 135 */                 VBox vBox = ((ContextMenuContent)node).getItemsContainer();
/* 136 */                 vBox.notifyAccessibleAttributeChanged(AccessibleAttribute.VISIBLE);
/*     */               } 
/*     */             }
/*     */             
/* 140 */             ContextMenuSkin.this.root.addEventHandler(KeyEvent.KEY_PRESSED, ContextMenuSkin.this.keyListener);
/*     */             
/* 142 */             ContextMenuSkin.this.performPopupShifts();
/*     */           }
/*     */         });
/* 145 */     this.popupMenu.addEventHandler(Menu.ON_HIDDEN, new EventHandler<Event>() {
/*     */           public void handle(Event param1Event) {
/* 147 */             Node node = ContextMenuSkin.this.popupMenu.getSkin().getNode();
/* 148 */             if (node != null) node.requestFocus();
/*     */             
/* 150 */             ContextMenuSkin.this.root.removeEventHandler(KeyEvent.KEY_PRESSED, ContextMenuSkin.this.keyListener);
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     this.popupMenu.addEventFilter(WindowEvent.WINDOW_HIDING, (EventHandler)new EventHandler<Event>() {
/*     */           public void handle(Event param1Event) {
/* 159 */             Node node = ContextMenuSkin.this.popupMenu.getSkin().getNode();
/* 160 */             if (node instanceof ContextMenuContent) {
/* 161 */               VBox vBox = ((ContextMenuContent)node).getItemsContainer();
/* 162 */               vBox.notifyAccessibleAttributeChanged(AccessibleAttribute.VISIBLE);
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 167 */     if (Properties.IS_TOUCH_SUPPORTED && this.popupMenu
/* 168 */       .getStyleClass().contains("text-input-context-menu")) {
/* 169 */       this.root = (Region)new EmbeddedTextContextMenuContent(this.popupMenu);
/*     */     } else {
/* 171 */       this.root = (Region)new ContextMenuContent(this.popupMenu);
/*     */     } 
/* 173 */     this.root.idProperty().bind(this.popupMenu.idProperty());
/* 174 */     this.root.styleProperty().bind(this.popupMenu.styleProperty());
/* 175 */     this.root.getStyleClass().addAll(this.popupMenu.getStyleClass());
/*     */ 
/*     */     
/* 178 */     if (Utils.isTwoLevelFocus()) {
/* 179 */       this.tlFocus = new TwoLevelFocusPopupBehavior(this.popupMenu);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextMenu getSkinnable() {
/* 193 */     return this.popupMenu;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getNode() {
/* 198 */     return this.root;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 203 */     this.root.idProperty().unbind();
/* 204 */     this.root.styleProperty().unbind();
/* 205 */     if (this.tlFocus != null) this.tlFocus.dispose();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void performPopupShifts() {
/* 217 */     ContextMenu contextMenu = getSkinnable();
/* 218 */     Node node = contextMenu.getOwnerNode();
/* 219 */     if (node == null)
/*     */       return; 
/* 221 */     Bounds bounds = node.localToScreen(node.getLayoutBounds());
/* 222 */     if (bounds == null) {
/*     */       return;
/*     */     }
/* 225 */     double d1 = this.root.prefHeight(-1.0D);
/* 226 */     this.shiftY = this.prefHeight - d1;
/* 227 */     if (this.shiftY > 0.0D && contextMenu.getY() + d1 < bounds.getMinY()) {
/* 228 */       contextMenu.setY(contextMenu.getY() + this.shiftY);
/*     */     }
/*     */ 
/*     */     
/* 232 */     double d2 = this.root.prefWidth(-1.0D);
/* 233 */     this.shiftX = this.prefWidth - d2;
/* 234 */     if (this.shiftX > 0.0D && contextMenu.getX() + d2 < bounds.getMinX())
/* 235 */       contextMenu.setX(contextMenu.getX() + this.shiftX); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ContextMenuSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */