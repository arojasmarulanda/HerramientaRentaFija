/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.ParentHelper;
/*     */ import com.sun.javafx.scene.control.FakeFocusTextField;
/*     */ import com.sun.javafx.scene.control.behavior.SpinnerBehavior;
/*     */ import com.sun.javafx.scene.traversal.Algorithm;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import com.sun.javafx.scene.traversal.ParentTraversalEngine;
/*     */ import com.sun.javafx.scene.traversal.TraversalContext;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.control.Spinner;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.StackPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpinnerSkin<T>
/*     */   extends SkinBase<Spinner<T>>
/*     */ {
/*     */   private TextField textField;
/*     */   private Region incrementArrow;
/*     */   private StackPane incrementArrowButton;
/*     */   private Region decrementArrow;
/*     */   private StackPane decrementArrowButton;
/*     */   private static final int ARROWS_ON_RIGHT_VERTICAL = 0;
/*     */   private static final int ARROWS_ON_LEFT_VERTICAL = 1;
/*     */   private static final int ARROWS_ON_RIGHT_HORIZONTAL = 2;
/*     */   private static final int ARROWS_ON_LEFT_HORIZONTAL = 3;
/*     */   private static final int SPLIT_ARROWS_VERTICAL = 4;
/*     */   private static final int SPLIT_ARROWS_HORIZONTAL = 5;
/*  85 */   private int layoutMode = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final SpinnerBehavior behavior;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpinnerSkin(Spinner<T> paramSpinner) {
/* 105 */     super(paramSpinner);
/*     */ 
/*     */     
/* 108 */     this.behavior = new SpinnerBehavior<>(paramSpinner);
/*     */ 
/*     */     
/* 111 */     this.textField = paramSpinner.getEditor();
/* 112 */     getChildren().add(this.textField);
/*     */     
/* 114 */     updateStyleClass();
/* 115 */     paramSpinner.getStyleClass().addListener(paramChange -> updateStyleClass());
/*     */ 
/*     */     
/* 118 */     this.incrementArrow = new Region();
/* 119 */     this.incrementArrow.setFocusTraversable(false);
/* 120 */     this.incrementArrow.getStyleClass().setAll(new String[] { "increment-arrow" });
/* 121 */     this.incrementArrow.setMaxWidth(Double.NEGATIVE_INFINITY);
/* 122 */     this.incrementArrow.setMaxHeight(Double.NEGATIVE_INFINITY);
/* 123 */     this.incrementArrow.setMouseTransparent(true);
/*     */     
/* 125 */     this.incrementArrowButton = new StackPane() {
/*     */         public void executeAccessibleAction(AccessibleAction param1AccessibleAction, Object... param1VarArgs) {
/* 127 */           switch (param1AccessibleAction) { case FIRE:
/* 128 */               SpinnerSkin.this.getSkinnable().increment(); return; }
/* 129 */            super.executeAccessibleAction(param1AccessibleAction, param1VarArgs);
/*     */         }
/*     */       };
/*     */     
/* 133 */     this.incrementArrowButton.setAccessibleRole(AccessibleRole.INCREMENT_BUTTON);
/* 134 */     this.incrementArrowButton.setFocusTraversable(false);
/* 135 */     this.incrementArrowButton.getStyleClass().setAll(new String[] { "increment-arrow-button" });
/* 136 */     this.incrementArrowButton.getChildren().add(this.incrementArrow);
/* 137 */     this.incrementArrowButton.setOnMousePressed(paramMouseEvent -> {
/*     */           getSkinnable().requestFocus();
/*     */           this.behavior.startSpinning(true);
/*     */         });
/* 141 */     this.incrementArrowButton.setOnMouseReleased(paramMouseEvent -> this.behavior.stopSpinning());
/*     */     
/* 143 */     this.decrementArrow = new Region();
/* 144 */     this.decrementArrow.setFocusTraversable(false);
/* 145 */     this.decrementArrow.getStyleClass().setAll(new String[] { "decrement-arrow" });
/* 146 */     this.decrementArrow.setMaxWidth(Double.NEGATIVE_INFINITY);
/* 147 */     this.decrementArrow.setMaxHeight(Double.NEGATIVE_INFINITY);
/* 148 */     this.decrementArrow.setMouseTransparent(true);
/*     */     
/* 150 */     this.decrementArrowButton = new StackPane() {
/*     */         public void executeAccessibleAction(AccessibleAction param1AccessibleAction, Object... param1VarArgs) {
/* 152 */           switch (param1AccessibleAction) { case FIRE:
/* 153 */               SpinnerSkin.this.getSkinnable().decrement(); return; }
/* 154 */            super.executeAccessibleAction(param1AccessibleAction, param1VarArgs);
/*     */         }
/*     */       };
/*     */     
/* 158 */     this.decrementArrowButton.setAccessibleRole(AccessibleRole.DECREMENT_BUTTON);
/* 159 */     this.decrementArrowButton.setFocusTraversable(false);
/* 160 */     this.decrementArrowButton.getStyleClass().setAll(new String[] { "decrement-arrow-button" });
/* 161 */     this.decrementArrowButton.getChildren().add(this.decrementArrow);
/* 162 */     this.decrementArrowButton.setOnMousePressed(paramMouseEvent -> {
/*     */           getSkinnable().requestFocus();
/*     */           this.behavior.startSpinning(false);
/*     */         });
/* 166 */     this.decrementArrowButton.setOnMouseReleased(paramMouseEvent -> this.behavior.stopSpinning());
/*     */     
/* 168 */     getChildren().addAll(new Node[] { this.incrementArrowButton, this.decrementArrowButton });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     paramSpinner.focusedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> ((FakeFocusTextField)this.textField).setFakeFocus(paramBoolean2.booleanValue()));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     paramSpinner.addEventFilter(KeyEvent.ANY, paramKeyEvent -> {
/*     */           if (paramSpinner.isEditable()) {
/*     */             if (paramKeyEvent.getTarget().equals(this.textField)) {
/*     */               return;
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             if (paramKeyEvent.getCode() == KeyCode.ESCAPE) {
/*     */               return;
/*     */             }
/*     */ 
/*     */             
/*     */             this.textField.fireEvent(paramKeyEvent.copyFor(this.textField, this.textField));
/*     */ 
/*     */             
/*     */             if (paramKeyEvent.getCode() == KeyCode.ENTER) {
/*     */               return;
/*     */             }
/*     */ 
/*     */             
/*     */             paramKeyEvent.consume();
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/* 204 */     this.textField.addEventFilter(KeyEvent.ANY, paramKeyEvent -> {
/*     */           if (!paramSpinner.isEditable()) {
/*     */             paramSpinner.fireEvent(paramKeyEvent.copyFor(paramSpinner, paramSpinner));
/*     */             
/*     */             paramKeyEvent.consume();
/*     */           } 
/*     */         });
/* 211 */     this.textField.focusedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*     */           paramSpinner.getProperties().put("FOCUSED", paramBoolean2);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (!paramBoolean2.booleanValue()) {
/*     */             pseudoClassStateChanged(CONTAINS_FOCUS_PSEUDOCLASS_STATE, false);
/*     */           } else {
/*     */             pseudoClassStateChanged(CONTAINS_FOCUS_PSEUDOCLASS_STATE, true);
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     this.textField.focusTraversableProperty().bind(paramSpinner.editableProperty());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     ParentHelper.setTraversalEngine(paramSpinner, new ParentTraversalEngine(paramSpinner, new Algorithm()
/*     */           {
/*     */             public Node select(Node param1Node, Direction param1Direction, TraversalContext param1TraversalContext)
/*     */             {
/* 237 */               return null;
/*     */             }
/*     */             
/*     */             public Node selectFirst(TraversalContext param1TraversalContext) {
/* 241 */               return null;
/*     */             }
/*     */             
/*     */             public Node selectLast(TraversalContext param1TraversalContext) {
/* 245 */               return null;
/*     */             }
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 260 */     super.dispose();
/*     */     
/* 262 */     if (this.behavior != null) {
/* 263 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 272 */     double d1 = this.incrementArrowButton.snappedLeftInset() + snapSizeX(this.incrementArrow.prefWidth(-1.0D)) + this.incrementArrowButton.snappedRightInset();
/*     */ 
/*     */     
/* 275 */     double d2 = this.decrementArrowButton.snappedLeftInset() + snapSizeX(this.decrementArrow.prefWidth(-1.0D)) + this.decrementArrowButton.snappedRightInset();
/*     */     
/* 277 */     double d3 = Math.max(d1, d2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 283 */     if (this.layoutMode == 0 || this.layoutMode == 1) {
/* 284 */       double d4 = (this.layoutMode == 0) ? paramDouble1 : (paramDouble1 + d3);
/* 285 */       double d5 = (this.layoutMode == 0) ? (paramDouble1 + paramDouble3 - d3) : paramDouble1;
/* 286 */       double d6 = Math.floor(paramDouble4 / 2.0D);
/*     */       
/* 288 */       this.textField.resizeRelocate(d4, paramDouble2, paramDouble3 - d3, paramDouble4);
/*     */       
/* 290 */       this.incrementArrowButton.resize(d3, d6);
/* 291 */       positionInArea(this.incrementArrowButton, d5, paramDouble2, d3, d6, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */ 
/*     */       
/* 294 */       this.decrementArrowButton.resize(d3, d6);
/* 295 */       positionInArea(this.decrementArrowButton, d5, paramDouble2 + d6, d3, paramDouble4 - d6, 0.0D, HPos.CENTER, VPos.BOTTOM);
/*     */     }
/* 297 */     else if (this.layoutMode == 2 || this.layoutMode == 3) {
/* 298 */       double d4 = d1 + d2;
/* 299 */       double d5 = (this.layoutMode == 2) ? paramDouble1 : (paramDouble1 + d4);
/* 300 */       double d6 = (this.layoutMode == 2) ? (paramDouble1 + paramDouble3 - d4) : paramDouble1;
/*     */       
/* 302 */       this.textField.resizeRelocate(d5, paramDouble2, paramDouble3 - d4, paramDouble4);
/*     */ 
/*     */       
/* 305 */       this.decrementArrowButton.resize(d2, paramDouble4);
/* 306 */       positionInArea(this.decrementArrowButton, d6, paramDouble2, d2, paramDouble4, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */ 
/*     */ 
/*     */       
/* 310 */       this.incrementArrowButton.resize(d1, paramDouble4);
/* 311 */       positionInArea(this.incrementArrowButton, d6 + d2, paramDouble2, d1, paramDouble4, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */     }
/* 313 */     else if (this.layoutMode == 4) {
/*     */       
/* 315 */       double d4 = this.incrementArrowButton.snappedTopInset() + snapSizeY(this.incrementArrow.prefHeight(-1.0D)) + this.incrementArrowButton.snappedBottomInset();
/*     */ 
/*     */       
/* 318 */       double d5 = this.decrementArrowButton.snappedTopInset() + snapSizeY(this.decrementArrow.prefHeight(-1.0D)) + this.decrementArrowButton.snappedBottomInset();
/*     */       
/* 320 */       double d6 = Math.max(d4, d5);
/*     */ 
/*     */       
/* 323 */       this.incrementArrowButton.resize(paramDouble3, d6);
/* 324 */       positionInArea(this.incrementArrowButton, paramDouble1, paramDouble2, paramDouble3, d6, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */ 
/*     */ 
/*     */       
/* 328 */       this.textField.resizeRelocate(paramDouble1, paramDouble2 + d6, paramDouble3, paramDouble4 - 2.0D * d6);
/*     */ 
/*     */       
/* 331 */       this.decrementArrowButton.resize(paramDouble3, d6);
/* 332 */       positionInArea(this.decrementArrowButton, paramDouble1, paramDouble4 - d6, paramDouble3, d6, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */     }
/* 334 */     else if (this.layoutMode == 5) {
/*     */       
/* 336 */       this.decrementArrowButton.resize(d3, paramDouble4);
/* 337 */       positionInArea(this.decrementArrowButton, paramDouble1, paramDouble2, d3, paramDouble4, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */ 
/*     */ 
/*     */       
/* 341 */       this.textField.resizeRelocate(paramDouble1 + d3, paramDouble2, paramDouble3 - 2.0D * d3, paramDouble4);
/*     */ 
/*     */       
/* 344 */       this.incrementArrowButton.resize(d3, paramDouble4);
/* 345 */       positionInArea(this.incrementArrowButton, paramDouble3 - d3, paramDouble2, d3, paramDouble4, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 352 */     return this.textField.minWidth(paramDouble1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 357 */     return computePrefHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 362 */     double d = this.textField.prefWidth(paramDouble1);
/* 363 */     return paramDouble5 + d + paramDouble3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 369 */     double d1, d2 = this.textField.prefHeight(paramDouble1);
/*     */     
/* 371 */     if (this.layoutMode == 4) {
/*     */       
/* 373 */       d1 = paramDouble2 + this.incrementArrowButton.prefHeight(paramDouble1) + d2 + this.decrementArrowButton.prefHeight(paramDouble1) + paramDouble4;
/*     */     } else {
/* 375 */       d1 = paramDouble2 + d2 + paramDouble4;
/*     */     } 
/*     */     
/* 378 */     return d1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 383 */     return getSkinnable().prefWidth(paramDouble1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 388 */     return getSkinnable().prefHeight(paramDouble1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeBaselineOffset(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 395 */     return this.textField.getLayoutBounds().getMinY() + this.textField.getLayoutY() + this.textField.getBaselineOffset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateStyleClass() {
/* 407 */     ObservableList<String> observableList = getSkinnable().getStyleClass();
/*     */     
/* 409 */     if (observableList.contains("arrows-on-left-vertical")) {
/* 410 */       this.layoutMode = 1;
/* 411 */     } else if (observableList.contains("arrows-on-left-horizontal")) {
/* 412 */       this.layoutMode = 3;
/* 413 */     } else if (observableList.contains("arrows-on-right-horizontal")) {
/* 414 */       this.layoutMode = 2;
/* 415 */     } else if (observableList.contains("split-arrows-vertical")) {
/* 416 */       this.layoutMode = 4;
/* 417 */     } else if (observableList.contains("split-arrows-horizontal")) {
/* 418 */       this.layoutMode = 5;
/*     */     } else {
/* 420 */       this.layoutMode = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 432 */   private static PseudoClass CONTAINS_FOCUS_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("contains-focus");
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\SpinnerSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */