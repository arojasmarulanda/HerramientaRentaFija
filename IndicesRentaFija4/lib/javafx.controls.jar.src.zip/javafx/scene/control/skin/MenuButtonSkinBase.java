/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.control.ContextMenuContent;
/*     */ import com.sun.javafx.scene.control.ControlAcceleratorSupport;
/*     */ import com.sun.javafx.scene.control.LabeledImpl;
/*     */ import com.sun.javafx.scene.control.behavior.MenuButtonBehaviorBase;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import java.util.Collection;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.MenuButton;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.Skin;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.StackPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MenuButtonSkinBase<C extends MenuButton>
/*     */   extends SkinBase<C>
/*     */ {
/*     */   final LabeledImpl label;
/*     */   final StackPane arrow;
/*     */   final StackPane arrowButton;
/*     */   ContextMenu popup;
/*     */   boolean behaveLikeButton = false;
/*     */   private ListChangeListener<MenuItem> itemsChangedListener;
/*     */   boolean requestFocusOnFirstMenuItem;
/*     */   
/*     */   public MenuButtonSkinBase(C paramC) {
/*  88 */     super(paramC);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 287 */     this.requestFocusOnFirstMenuItem = false; if (paramC.getOnMousePressed() == null) paramC.addEventHandler(MouseEvent.MOUSE_PRESSED, paramMouseEvent -> { MenuButtonBehaviorBase<C> menuButtonBehaviorBase = getBehavior(); if (menuButtonBehaviorBase != null) menuButtonBehaviorBase.mousePressed(paramMouseEvent, this.behaveLikeButton);  });  if (paramC.getOnMouseReleased() == null) paramC.addEventHandler(MouseEvent.MOUSE_RELEASED, paramMouseEvent -> { MenuButtonBehaviorBase<C> menuButtonBehaviorBase = getBehavior(); if (menuButtonBehaviorBase != null) menuButtonBehaviorBase.mouseReleased(paramMouseEvent, this.behaveLikeButton);  });  this.label = new MenuLabeledImpl((MenuButton)getSkinnable()); this.label.setMnemonicParsing(paramC.isMnemonicParsing()); this.label.setLabelFor((Node)paramC); this.arrow = new StackPane(); this.arrow.getStyleClass().setAll(new String[] { "arrow" }); this.arrow.setMaxWidth(Double.NEGATIVE_INFINITY); this.arrow.setMaxHeight(Double.NEGATIVE_INFINITY); this.arrowButton = new StackPane(); this.arrowButton.getStyleClass().setAll(new String[] { "arrow-button" }); this.arrowButton.getChildren().add(this.arrow); this.popup = new ContextMenu(); this.popup.getItems().clear(); this.popup.getItems().addAll(((MenuButton)getSkinnable()).getItems()); getChildren().clear(); getChildren().addAll(new Node[] { (Node)this.label, this.arrowButton }); ((MenuButton)getSkinnable()).requestLayout(); this.itemsChangedListener = (paramChange -> { while (paramChange.next()) { this.popup.getItems().removeAll(paramChange.getRemoved()); this.popup.getItems().addAll(paramChange.getFrom(), (Collection)paramChange.getAddedSubList()); }  }); paramC.getItems().addListener(this.itemsChangedListener); if (((MenuButton)getSkinnable()).getScene() != null) ControlAcceleratorSupport.addAcceleratorsIntoScene(((MenuButton)getSkinnable()).getItems(), (Node)getSkinnable());  paramC.sceneProperty().addListener((paramObservableValue, paramScene1, paramScene2) -> { if (getSkinnable() != null && ((MenuButton)getSkinnable()).getScene() != null) ControlAcceleratorSupport.addAcceleratorsIntoScene(((MenuButton)getSkinnable()).getItems(), (Node)getSkinnable());  }); registerChangeListener(paramC.showingProperty(), paramObservableValue -> { if (((MenuButton)getSkinnable()).isShowing()) { show(); } else { hide(); }  }); registerChangeListener(paramC.focusedProperty(), paramObservableValue -> { if (!((MenuButton)getSkinnable()).isFocused() && ((MenuButton)getSkinnable()).isShowing()) hide();  if (!((MenuButton)getSkinnable()).isFocused() && this.popup.isShowing()) hide();  }); registerChangeListener(paramC.mnemonicParsingProperty(), paramObservableValue -> { this.label.setMnemonicParsing(((MenuButton)getSkinnable()).isMnemonicParsing()); ((MenuButton)getSkinnable()).requestLayout(); }); registerChangeListener(this.popup.showingProperty(), paramObservableValue -> { if (!this.popup.isShowing() && ((MenuButton)getSkinnable()).isShowing()) ((MenuButton)getSkinnable()).hide();  if (this.popup.isShowing()) { Utils.addMnemonics(this.popup, ((MenuButton)getSkinnable()).getScene(), NodeHelper.isShowMnemonics((Node)getSkinnable())); } else { Platform.runLater(()); }  });
/*     */   }
/* 289 */   public void dispose() { ((MenuButton)getSkinnable()).getItems().removeListener(this.itemsChangedListener); super.dispose(); if (this.popup != null) { if (this.popup.getSkin() != null && this.popup.getSkin().getNode() != null) { ContextMenuContent contextMenuContent = (ContextMenuContent)this.popup.getSkin().getNode(); contextMenuContent.dispose(); }  this.popup.setSkin((Skin<?>)null); this.popup = null; }  } protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return paramDouble5 + this.label.minWidth(paramDouble1) + snapSizeX(this.arrowButton.minWidth(paramDouble1)) + paramDouble3; } protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return paramDouble2 + Math.max(this.label.minHeight(paramDouble1), snapSizeY(this.arrowButton.minHeight(-1.0D))) + paramDouble4; } protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return paramDouble5 + this.label.prefWidth(paramDouble1) + snapSizeX(this.arrowButton.prefWidth(paramDouble1)) + paramDouble3; } protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return paramDouble2 + Math.max(this.label.prefHeight(paramDouble1), snapSizeY(this.arrowButton.prefHeight(-1.0D))) + paramDouble4; } void requestFocusOnFirstMenuItem() { this.requestFocusOnFirstMenuItem = true; }
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return ((MenuButton)getSkinnable()).prefWidth(paramDouble1); }
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return ((MenuButton)getSkinnable()).prefHeight(paramDouble1); }
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { double d = snapSizeX(this.arrowButton.prefWidth(-1.0D)); this.label.resizeRelocate(paramDouble1, paramDouble2, paramDouble3 - d, paramDouble4); this.arrowButton.resizeRelocate(paramDouble1 + paramDouble3 - d, paramDouble2, d, paramDouble4); }
/* 293 */   MenuButtonBehaviorBase<C> getBehavior() { return null; } private void show() { if (!this.popup.isShowing()) this.popup.show((Node)getSkinnable(), ((MenuButton)getSkinnable()).getPopupSide(), 0.0D, 0.0D);  } private void hide() { if (this.popup.isShowing()) this.popup.hide();  } void putFocusOnFirstMenuItem() { Skin<?> skin = this.popup.getSkin();
/* 294 */     if (skin instanceof ContextMenuSkin) {
/* 295 */       Node node = skin.getNode();
/* 296 */       if (node instanceof ContextMenuContent) {
/* 297 */         ((ContextMenuContent)node).requestFocusOnIndex(0);
/*     */       }
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MenuLabeledImpl
/*     */     extends LabeledImpl
/*     */   {
/*     */     MenuButton button;
/*     */ 
/*     */ 
/*     */     
/*     */     public MenuLabeledImpl(MenuButton param1MenuButton) {
/* 313 */       super(param1MenuButton);
/* 314 */       this.button = param1MenuButton;
/* 315 */       addEventHandler(ActionEvent.ACTION, param1ActionEvent -> {
/*     */             this.button.fireEvent(new ActionEvent());
/*     */             param1ActionEvent.consume();
/*     */           });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\MenuButtonSkinBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */