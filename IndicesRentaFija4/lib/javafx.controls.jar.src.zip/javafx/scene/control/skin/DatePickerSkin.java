/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.DatePickerContent;
/*     */ import com.sun.javafx.scene.control.DatePickerHijrahContent;
/*     */ import com.sun.javafx.scene.control.behavior.ComboBoxBaseBehavior;
/*     */ import com.sun.javafx.scene.control.behavior.DatePickerBehavior;
/*     */ import java.time.LocalDate;
/*     */ import java.time.YearMonth;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.geometry.Insets;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.DatePicker;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatePickerSkin
/*     */   extends ComboBoxPopupControl<LocalDate>
/*     */ {
/*     */   private final DatePicker datePicker;
/*     */   private TextField displayNode;
/*     */   private DatePickerContent datePickerContent;
/*     */   private final DatePickerBehavior behavior;
/*     */   
/*     */   public DatePickerSkin(DatePicker paramDatePicker) {
/*  85 */     super(paramDatePicker);
/*     */     
/*  87 */     this.datePicker = paramDatePicker;
/*     */ 
/*     */     
/*  90 */     this.behavior = new DatePickerBehavior(paramDatePicker);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     this.arrow.paddingProperty().addListener(new InvalidationListener() {
/*     */           private boolean rounding = false;
/*     */           
/*     */           public void invalidated(Observable param1Observable) {
/*  99 */             if (!this.rounding) {
/* 100 */               Insets insets1 = DatePickerSkin.this.arrow.getPadding();
/*     */               
/* 102 */               Insets insets2 = new Insets(Math.round(insets1.getTop()), Math.round(insets1.getRight()), Math.round(insets1.getBottom()), Math.round(insets1.getLeft()));
/* 103 */               if (!insets2.equals(insets1)) {
/* 104 */                 this.rounding = true;
/* 105 */                 DatePickerSkin.this.arrow.setPadding(insets2);
/* 106 */                 this.rounding = false;
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 112 */     registerChangeListener(paramDatePicker.chronologyProperty(), paramObservableValue -> {
/*     */           updateDisplayNode();
/*     */           this.datePickerContent = null;
/*     */           this.popup = null;
/*     */         });
/* 117 */     registerChangeListener(paramDatePicker.converterProperty(), paramObservableValue -> updateDisplayNode());
/* 118 */     registerChangeListener(paramDatePicker.dayCellFactoryProperty(), paramObservableValue -> {
/*     */           updateDisplayNode();
/*     */           this.datePickerContent = null;
/*     */           this.popup = null;
/*     */         });
/* 123 */     registerChangeListener(paramDatePicker.showWeekNumbersProperty(), paramObservableValue -> {
/*     */           if (this.datePickerContent != null) {
/*     */             this.datePickerContent.updateGrid();
/*     */             this.datePickerContent.updateWeeknumberDateCells();
/*     */           } 
/*     */         });
/* 129 */     registerChangeListener(paramDatePicker.valueProperty(), paramObservableValue -> {
/*     */           updateDisplayNode();
/*     */           if (this.datePickerContent != null) {
/*     */             LocalDate localDate = paramDatePicker.getValue();
/*     */             this.datePickerContent.displayedYearMonthProperty().set((localDate != null) ? YearMonth.from(localDate) : YearMonth.now());
/*     */             this.datePickerContent.updateValues();
/*     */           } 
/*     */           paramDatePicker.fireEvent(new ActionEvent());
/*     */         });
/* 138 */     registerChangeListener(paramDatePicker.showingProperty(), paramObservableValue -> {
/*     */           if (paramDatePicker.isShowing()) {
/*     */             if (this.datePickerContent != null) {
/*     */               LocalDate localDate = paramDatePicker.getValue();
/*     */               
/*     */               this.datePickerContent.displayedYearMonthProperty().set((localDate != null) ? YearMonth.from(localDate) : YearMonth.now());
/*     */               this.datePickerContent.updateValues();
/*     */             } 
/*     */             show();
/*     */           } else {
/*     */             hide();
/*     */           } 
/*     */         });
/* 151 */     if (paramDatePicker.isShowing()) {
/* 152 */       show();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 166 */     super.dispose();
/*     */     
/* 168 */     if (this.behavior != null) {
/* 169 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getPopupContent() {
/* 175 */     if (this.datePickerContent == null) {
/* 176 */       if (this.datePicker.getChronology() instanceof java.time.chrono.HijrahChronology) {
/* 177 */         this.datePickerContent = (DatePickerContent)new DatePickerHijrahContent(this.datePicker);
/*     */       } else {
/* 179 */         this.datePickerContent = new DatePickerContent(this.datePicker);
/*     */       } 
/*     */     }
/*     */     
/* 183 */     return (Node)this.datePickerContent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 190 */     return 50.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public void show() {
/* 195 */     super.show();
/* 196 */     this.datePickerContent.clearFocus();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TextField getEditor() {
/* 203 */     return ((DatePicker)getSkinnable()).getEditor();
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringConverter<LocalDate> getConverter() {
/* 208 */     return ((DatePicker)getSkinnable()).getConverter();
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getDisplayNode() {
/* 213 */     if (this.displayNode == null) {
/* 214 */       this.displayNode = getEditableInputNode();
/* 215 */       this.displayNode.getStyleClass().add("date-picker-display-node");
/* 216 */       updateDisplayNode();
/*     */     } 
/* 218 */     this.displayNode.setEditable(this.datePicker.isEditable());
/*     */     
/* 220 */     return this.displayNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void focusLost() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ComboBoxBaseBehavior getBehavior() {
/* 238 */     return this.behavior;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\DatePickerSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */