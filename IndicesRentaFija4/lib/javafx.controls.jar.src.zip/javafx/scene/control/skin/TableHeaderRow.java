/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.Insets;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.CheckMenuItem;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.Pane;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.shape.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableHeaderRow
/*     */   extends StackPane
/*     */ {
/*  85 */   private final String MENU_SEPARATOR = ControlResources.getString("TableView.nestedColumnControlMenuSeparator");
/*     */   
/*     */   private final VirtualFlow flow;
/*     */   final TableViewSkinBase<?, ?, ?, ?, ?> tableSkin;
/*  89 */   private Map<TableColumnBase, CheckMenuItem> columnMenuItems = new HashMap<>();
/*     */   
/*     */   private double scrollX;
/*     */   
/*     */   private double tableWidth;
/*     */   
/*     */   private Rectangle clip;
/*     */   
/*     */   private TableColumnHeader reorderingRegion;
/*     */   
/*     */   private StackPane dragHeader;
/* 100 */   private final Label dragHeaderLabel = new Label();
/*     */   
/*     */   private Region filler;
/*     */   
/*     */   private Pane cornerRegion;
/*     */   
/*     */   private ContextMenu columnPopupMenu;
/*     */   
/*     */   boolean columnDragLock = false;
/*     */   
/*     */   private InvalidationListener tableWidthListener = paramObservable -> updateTableWidth();
/*     */   
/*     */   private InvalidationListener tablePaddingListener = paramObservable -> updateTableWidth();
/*     */   
/*     */   private ListChangeListener visibleLeafColumnsListener = paramChange -> getRootHeader().setHeadersNeedUpdate();
/*     */   
/*     */   private final ListChangeListener tableColumnsListener;
/*     */   
/*     */   private final InvalidationListener columnTextListener;
/*     */   
/*     */   private final WeakInvalidationListener weakTableWidthListener;
/*     */   
/*     */   private final WeakInvalidationListener weakTablePaddingListener;
/*     */   
/*     */   private final WeakListChangeListener weakVisibleLeafColumnsListener;
/*     */   private final WeakListChangeListener weakTableColumnsListener;
/*     */   private final WeakInvalidationListener weakColumnTextListener;
/*     */   private BooleanProperty reordering;
/*     */   private ReadOnlyObjectWrapper<NestedTableColumnHeader> rootHeader;
/*     */   
/*     */   final void setReordering(boolean paramBoolean) {
/*     */     this.reordering.set(paramBoolean);
/*     */   }
/*     */   
/*     */   final boolean isReordering() {
/*     */     return this.reordering.get();
/*     */   }
/*     */   
/*     */   final BooleanProperty reorderingProperty() {
/*     */     return this.reordering;
/*     */   }
/*     */   
/*     */   public TableHeaderRow(TableViewSkinBase<?, ?, ?, ?, ?> paramTableViewSkinBase) {
/* 143 */     this.tableColumnsListener = (paramChange -> {
/*     */         while (paramChange.next()) {
/*     */           updateTableColumnListeners(paramChange.getAddedSubList(), paramChange.getRemoved());
/*     */         }
/*     */       });
/*     */     
/* 149 */     this.columnTextListener = (paramObservable -> {
/*     */         TableColumnBase tableColumnBase = (TableColumnBase)((StringProperty)paramObservable).getBean();
/*     */         
/*     */         CheckMenuItem checkMenuItem = this.columnMenuItems.get(tableColumnBase);
/*     */         if (checkMenuItem != null) {
/*     */           checkMenuItem.setText(getText(tableColumnBase.getText(), tableColumnBase));
/*     */         }
/*     */       });
/* 157 */     this.weakTableWidthListener = new WeakInvalidationListener(this.tableWidthListener);
/*     */ 
/*     */     
/* 160 */     this.weakTablePaddingListener = new WeakInvalidationListener(this.tablePaddingListener);
/*     */ 
/*     */     
/* 163 */     this.weakVisibleLeafColumnsListener = new WeakListChangeListener(this.visibleLeafColumnsListener);
/*     */ 
/*     */     
/* 166 */     this.weakTableColumnsListener = new WeakListChangeListener(this.tableColumnsListener);
/*     */ 
/*     */     
/* 169 */     this.weakColumnTextListener = new WeakInvalidationListener(this.columnTextListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 280 */     this.reordering = new SimpleBooleanProperty(this, "reordering", false) {
/*     */         protected void invalidated() {
/* 282 */           TableColumnHeader tableColumnHeader = TableHeaderRow.this.getReorderingRegion();
/* 283 */           if (tableColumnHeader != null) {
/*     */ 
/*     */             
/* 286 */             double d = (tableColumnHeader.getNestedColumnHeader() != null) ? tableColumnHeader.getNestedColumnHeader().getHeight() : TableHeaderRow.this.getReorderingRegion().getHeight();
/*     */             
/* 288 */             TableHeaderRow.this.dragHeader.resize(TableHeaderRow.this.dragHeader.getWidth(), d);
/* 289 */             TableHeaderRow.this.dragHeader.setTranslateY(TableHeaderRow.this.getHeight() - d);
/*     */           } 
/* 291 */           TableHeaderRow.this.dragHeader.setVisible(TableHeaderRow.this.isReordering());
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     this.rootHeader = new ReadOnlyObjectWrapper<>(this, "rootHeader"); this.tableSkin = paramTableViewSkinBase; this.flow = paramTableViewSkinBase.flow; getStyleClass().setAll(new String[] { "column-header-background" }); this.clip = new Rectangle(); this.clip.setSmooth(false); this.clip.heightProperty().bind(heightProperty()); setClip(this.clip); updateTableWidth(); this.tableSkin.getSkinnable().widthProperty().addListener(this.weakTableWidthListener); this.tableSkin.getSkinnable().paddingProperty().addListener(this.weakTablePaddingListener); TableSkinUtils.getVisibleLeafColumns(paramTableViewSkinBase).addListener(this.weakVisibleLeafColumnsListener); this.columnPopupMenu = new ContextMenu(); updateTableColumnListeners(TableSkinUtils.getColumns(this.tableSkin), Collections.emptyList()); TableSkinUtils.getVisibleLeafColumns(paramTableViewSkinBase).addListener(this.weakTableColumnsListener); TableSkinUtils.getColumns(this.tableSkin).addListener(this.weakTableColumnsListener); this.dragHeader = new StackPane(); this.dragHeader.setVisible(false); this.dragHeader.getStyleClass().setAll(new String[] { "column-drag-header" }); this.dragHeader.setManaged(false); this.dragHeader.setMouseTransparent(true); this.dragHeader.getChildren().add(this.dragHeaderLabel); NestedTableColumnHeader nestedTableColumnHeader = createRootHeader(); setRootHeader(nestedTableColumnHeader); nestedTableColumnHeader.setFocusTraversable(false); nestedTableColumnHeader.setTableHeaderRow(this); this.filler = new Region(); this.filler.getStyleClass().setAll(new String[] { "filler" }); setOnMousePressed(paramMouseEvent -> paramTableViewSkinBase.getSkinnable().requestFocus()); final StackPane image = new StackPane(); stackPane.setSnapToPixel(false); stackPane.getStyleClass().setAll(new String[] { "show-hide-column-image" }); this.cornerRegion = new StackPane() { protected void layoutChildren() { double d1 = image.snappedLeftInset() + image.snappedRightInset(); double d2 = image.snappedTopInset() + image.snappedBottomInset(); image.resize(d1, d2); positionInArea(image, 0.0D, 0.0D, getWidth(), getHeight() - 3.0D, 0.0D, HPos.CENTER, VPos.CENTER); } }; this.cornerRegion.getStyleClass().setAll(new String[] { "show-hide-columns-button" }); this.cornerRegion.getChildren().addAll(new Node[] { stackPane }); BooleanProperty booleanProperty = TableSkinUtils.tableMenuButtonVisibleProperty(paramTableViewSkinBase); if (booleanProperty != null)
/*     */       this.cornerRegion.visibleProperty().bind(booleanProperty);  this.cornerRegion.setOnMousePressed(paramMouseEvent -> { this.columnPopupMenu.show(this.cornerRegion, Side.BOTTOM, 0.0D, 0.0D); paramMouseEvent.consume(); }); getChildren().addAll(new Node[] { this.filler, nestedTableColumnHeader, this.cornerRegion, this.dragHeader });
/* 315 */   } private final ReadOnlyObjectProperty<NestedTableColumnHeader> rootHeaderProperty() { return this.rootHeader.getReadOnlyProperty(); }
/*     */   
/*     */   final NestedTableColumnHeader getRootHeader() {
/* 318 */     return this.rootHeader.get();
/*     */   }
/*     */   private final void setRootHeader(NestedTableColumnHeader paramNestedTableColumnHeader) {
/* 321 */     this.rootHeader.set(paramNestedTableColumnHeader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren() {
/* 334 */     double d1 = this.scrollX;
/* 335 */     double d2 = snapSizeX(getRootHeader().prefWidth(-1.0D));
/* 336 */     double d3 = getHeight() - snappedTopInset() - snappedBottomInset();
/* 337 */     double d4 = snapSizeX(this.flow.getVbar().prefWidth(-1.0D));
/*     */ 
/*     */     
/* 340 */     getRootHeader().resizeRelocate(d1, snappedTopInset(), d2, d3);
/*     */ 
/*     */     
/* 343 */     Object object = this.tableSkin.getSkinnable();
/* 344 */     if (object == null) {
/*     */       return;
/*     */     }
/*     */     
/* 348 */     BooleanProperty booleanProperty = TableSkinUtils.tableMenuButtonVisibleProperty(this.tableSkin);
/*     */     
/* 350 */     double d5 = object.snappedLeftInset() + object.snappedRightInset();
/* 351 */     double d6 = this.tableWidth - d2 + this.filler.getInsets().getLeft() - d5;
/* 352 */     d6 -= (booleanProperty != null && booleanProperty.get()) ? d4 : 0.0D;
/* 353 */     this.filler.setVisible((d6 > 0.0D));
/* 354 */     if (d6 > 0.0D) {
/* 355 */       this.filler.resizeRelocate(d1 + d2, snappedTopInset(), d6, d3);
/*     */     }
/*     */ 
/*     */     
/* 359 */     this.cornerRegion.resizeRelocate(this.tableWidth - d4, snappedTopInset(), d4, d3);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble) {
/* 364 */     return getRootHeader().prefWidth(paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble) {
/* 369 */     return computePrefHeight(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble) {
/* 376 */     double d = getRootHeader().prefHeight(paramDouble);
/* 377 */     d = (d == 0.0D) ? 24.0D : d;
/* 378 */     return snappedTopInset() + d + snappedBottomInset();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void updateScrollX() {
/* 384 */     this.scrollX = this.flow.getHbar().isVisible() ? -this.flow.getHbar().getValue() : 0.0D;
/* 385 */     requestLayout();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 390 */     layout();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateTableWidth() {
/* 397 */     Object object = this.tableSkin.getSkinnable();
/* 398 */     if (object == null) {
/* 399 */       this.tableWidth = 0.0D;
/*     */     } else {
/* 401 */       Insets insets = (object.getInsets() == null) ? Insets.EMPTY : object.getInsets();
/* 402 */       double d = snapSizeX(insets.getLeft()) + snapSizeX(insets.getRight());
/* 403 */       this.tableWidth = snapSizeX(object.getWidth()) - d;
/*     */     } 
/*     */     
/* 406 */     this.clip.setWidth(this.tableWidth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NestedTableColumnHeader createRootHeader() {
/* 416 */     return new NestedTableColumnHeader(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TableColumnHeader getReorderingRegion() {
/* 428 */     return this.reorderingRegion;
/*     */   }
/*     */   
/*     */   void setReorderingColumn(TableColumnBase paramTableColumnBase) {
/* 432 */     this.dragHeaderLabel.setText((paramTableColumnBase == null) ? "" : paramTableColumnBase.getText());
/*     */   }
/*     */   
/*     */   void setReorderingRegion(TableColumnHeader paramTableColumnHeader) {
/* 436 */     this.reorderingRegion = paramTableColumnHeader;
/*     */     
/* 438 */     if (paramTableColumnHeader != null) {
/* 439 */       this.dragHeader.resize(paramTableColumnHeader.getWidth(), this.dragHeader.getHeight());
/*     */     }
/*     */   }
/*     */   
/*     */   void setDragHeaderX(double paramDouble) {
/* 444 */     this.dragHeader.setTranslateX(paramDouble);
/*     */   }
/*     */   
/*     */   TableColumnHeader getColumnHeaderFor(TableColumnBase<?, ?> paramTableColumnBase) {
/* 448 */     if (paramTableColumnBase == null) return null; 
/* 449 */     ArrayList<TableColumnBase<?, ?>> arrayList = new ArrayList();
/* 450 */     arrayList.add(paramTableColumnBase);
/*     */     
/* 452 */     TableColumnBase<?, ?> tableColumnBase = paramTableColumnBase.getParentColumn();
/* 453 */     while (tableColumnBase != null) {
/* 454 */       arrayList.add(0, tableColumnBase);
/* 455 */       tableColumnBase = tableColumnBase.getParentColumn();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 460 */     TableColumnHeader tableColumnHeader = getRootHeader();
/* 461 */     for (byte b = 0; b < arrayList.size(); b++) {
/*     */       
/* 463 */       TableColumnBase<?, ?> tableColumnBase1 = arrayList.get(b);
/*     */ 
/*     */ 
/*     */       
/* 467 */       tableColumnHeader = getColumnHeaderFor(tableColumnBase1, tableColumnHeader);
/*     */     } 
/* 469 */     return tableColumnHeader;
/*     */   }
/*     */   
/*     */   private TableColumnHeader getColumnHeaderFor(TableColumnBase<?, ?> paramTableColumnBase, TableColumnHeader paramTableColumnHeader) {
/* 473 */     if (paramTableColumnHeader instanceof NestedTableColumnHeader) {
/* 474 */       ObservableList<TableColumnHeader> observableList = ((NestedTableColumnHeader)paramTableColumnHeader).getColumnHeaders();
/*     */       
/* 476 */       for (byte b = 0; b < observableList.size(); b++) {
/* 477 */         TableColumnHeader tableColumnHeader = observableList.get(b);
/* 478 */         if (tableColumnHeader.getTableColumn() == paramTableColumnBase) {
/* 479 */           return tableColumnHeader;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 484 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateTableColumnListeners(List<? extends TableColumnBase<?, ?>> paramList1, List<? extends TableColumnBase<?, ?>> paramList2) {
/* 489 */     for (TableColumnBase<?, ?> tableColumnBase : paramList2) {
/* 490 */       remove(tableColumnBase);
/*     */     }
/*     */     
/* 493 */     rebuildColumnMenu();
/*     */   }
/*     */   
/*     */   private void remove(TableColumnBase<?, ?> paramTableColumnBase) {
/* 497 */     if (paramTableColumnBase == null)
/*     */       return; 
/* 499 */     CheckMenuItem checkMenuItem = this.columnMenuItems.remove(paramTableColumnBase);
/* 500 */     if (checkMenuItem != null) {
/* 501 */       paramTableColumnBase.textProperty().removeListener(this.weakColumnTextListener);
/* 502 */       checkMenuItem.selectedProperty().unbindBidirectional(paramTableColumnBase.visibleProperty());
/*     */       
/* 504 */       this.columnPopupMenu.getItems().remove(checkMenuItem);
/*     */     } 
/*     */     
/* 507 */     if (!paramTableColumnBase.getColumns().isEmpty()) {
/* 508 */       for (TableColumnBase<?, ?> tableColumnBase : paramTableColumnBase.getColumns()) {
/* 509 */         remove(tableColumnBase);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void rebuildColumnMenu() {
/* 515 */     this.columnPopupMenu.getItems().clear();
/*     */     
/* 517 */     for (TableColumnBase<?, ?> tableColumnBase : TableSkinUtils.getColumns(this.tableSkin)) {
/*     */       
/* 519 */       if (tableColumnBase.getColumns().isEmpty()) {
/* 520 */         createMenuItem(tableColumnBase); continue;
/*     */       } 
/* 522 */       List<TableColumnBase<?, ?>> list = getLeafColumns(tableColumnBase);
/* 523 */       for (TableColumnBase<?, ?> tableColumnBase1 : list) {
/* 524 */         createMenuItem(tableColumnBase1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private List<TableColumnBase<?, ?>> getLeafColumns(TableColumnBase<?, ?> paramTableColumnBase) {
/* 531 */     ArrayList<TableColumnBase> arrayList = new ArrayList();
/*     */     
/* 533 */     for (TableColumnBase<?, ?> tableColumnBase : paramTableColumnBase.getColumns()) {
/* 534 */       if (tableColumnBase.getColumns().isEmpty()) {
/* 535 */         arrayList.add(tableColumnBase); continue;
/*     */       } 
/* 537 */       arrayList.addAll((Collection)getLeafColumns(tableColumnBase));
/*     */     } 
/*     */ 
/*     */     
/* 541 */     return (List)arrayList;
/*     */   }
/*     */   
/*     */   private void createMenuItem(TableColumnBase<?, ?> paramTableColumnBase) {
/* 545 */     CheckMenuItem checkMenuItem1 = this.columnMenuItems.get(paramTableColumnBase);
/* 546 */     if (checkMenuItem1 == null) {
/* 547 */       checkMenuItem1 = new CheckMenuItem();
/* 548 */       this.columnMenuItems.put(paramTableColumnBase, checkMenuItem1);
/*     */     } 
/*     */ 
/*     */     
/* 552 */     checkMenuItem1.setText(getText(paramTableColumnBase.getText(), paramTableColumnBase));
/* 553 */     paramTableColumnBase.textProperty().addListener(this.weakColumnTextListener);
/*     */ 
/*     */ 
/*     */     
/* 557 */     checkMenuItem1.setDisable(paramTableColumnBase.visibleProperty().isBound());
/*     */ 
/*     */     
/* 560 */     checkMenuItem1.setSelected(paramTableColumnBase.isVisible());
/* 561 */     CheckMenuItem checkMenuItem2 = checkMenuItem1;
/* 562 */     checkMenuItem1.selectedProperty().addListener(paramObservable -> {
/*     */           if (paramTableColumnBase.visibleProperty().isBound())
/*     */             return;  paramTableColumnBase.setVisible(paramCheckMenuItem.isSelected());
/*     */         });
/* 566 */     paramTableColumnBase.visibleProperty().addListener(paramObservable -> paramCheckMenuItem.setSelected(paramTableColumnBase.isVisible()));
/*     */     
/* 568 */     this.columnPopupMenu.getItems().add(checkMenuItem1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getText(String paramString, TableColumnBase paramTableColumnBase) {
/* 575 */     String str = paramString;
/* 576 */     TableColumnBase tableColumnBase = paramTableColumnBase.getParentColumn();
/* 577 */     while (tableColumnBase != null) {
/* 578 */       if (isColumnVisibleInHeader(tableColumnBase, TableSkinUtils.getColumns(this.tableSkin))) {
/* 579 */         str = tableColumnBase.getText() + tableColumnBase.getText() + this.MENU_SEPARATOR;
/*     */       }
/* 581 */       tableColumnBase = tableColumnBase.getParentColumn();
/*     */     } 
/* 583 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isColumnVisibleInHeader(TableColumnBase paramTableColumnBase, List<TableColumnBase> paramList) {
/* 591 */     if (paramTableColumnBase == null) return false;
/*     */     
/* 593 */     for (byte b = 0; b < paramList.size(); b++) {
/* 594 */       TableColumnBase tableColumnBase = paramList.get(b);
/* 595 */       if (paramTableColumnBase.equals(tableColumnBase)) return true;
/*     */       
/* 597 */       if (!tableColumnBase.getColumns().isEmpty()) {
/* 598 */         boolean bool = isColumnVisibleInHeader(paramTableColumnBase, tableColumnBase.getColumns());
/* 599 */         if (bool) return true;
/*     */       
/*     */       } 
/*     */     } 
/* 603 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TableHeaderRow.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */