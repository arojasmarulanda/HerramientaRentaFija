/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import javafx.animation.FadeTransition;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.css.StyleOrigin;
/*     */ import javafx.css.StyleableObjectProperty;
/*     */ import javafx.geometry.Insets;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Parent;
/*     */ import javafx.scene.control.IndexedCell;
/*     */ import javafx.scene.control.Skin;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TableRowSkinBase<T, C extends IndexedCell, R extends IndexedCell>
/*     */   extends CellSkinBase<C>
/*     */ {
/*  82 */   private static boolean IS_STUB_TOOLKIT = Toolkit.getToolkit().toString().contains("StubToolkit");
/*     */ 
/*     */   
/*  85 */   private static boolean DO_ANIMATIONS = (!IS_STUB_TOOLKIT && !PlatformUtil.isEmbedded());
/*     */   
/*  87 */   private static final Duration FADE_DURATION = Duration.millis(200.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   static final Map<TableColumnBase<?, ?>, Double> maxDisclosureWidthMap = new WeakHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_FULL_REFRESH_COUNTER = 100;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WeakHashMap<TableColumnBase, Reference<R>> cellsMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   final List<R> cells = new ArrayList<>();
/*     */   
/* 131 */   private int fullRefreshCounter = 100;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDirty = false;
/*     */ 
/*     */   
/*     */   boolean updateCells = false;
/*     */ 
/*     */   
/*     */   double fixedCellSize;
/*     */ 
/*     */   
/*     */   boolean fixedCellSizeEnabled;
/*     */ 
/*     */   
/*     */   private ListChangeListener<TableColumnBase> visibleLeafColumnsListener;
/*     */ 
/*     */   
/*     */   private WeakListChangeListener<TableColumnBase> weakVisibleLeafColumnsListener;
/*     */ 
/*     */ 
/*     */   
/*     */   public TableRowSkinBase(C paramC) {
/* 155 */     super(paramC);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     this.visibleLeafColumnsListener = (paramChange -> {
/*     */         this.isDirty = true;
/*     */         
/*     */         ((IndexedCell)getSkinnable()).requestLayout();
/*     */       });
/* 196 */     this.weakVisibleLeafColumnsListener = new WeakListChangeListener<>(this.visibleLeafColumnsListener);
/*     */     ((IndexedCell)getSkinnable()).setPickOnBounds(false);
/*     */     recreateCells();
/*     */     updateCells(true);
/*     */     getVisibleLeafColumns().addListener(this.weakVisibleLeafColumnsListener);
/*     */     paramC.itemProperty().addListener(paramObservable -> requestCellUpdate());
/*     */     registerChangeListener(paramC.indexProperty(), paramObservableValue -> {
/*     */           if (((IndexedCell)getSkinnable()).isEmpty()) {
/*     */             requestCellUpdate();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectProperty<Node> graphicProperty() {
/* 251 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 256 */     checkState();
/* 257 */     if (this.cellsMap.isEmpty())
/*     */       return; 
/* 259 */     ObservableList<? extends TableColumnBase> observableList = getVisibleLeafColumns();
/* 260 */     if (observableList.isEmpty()) {
/* 261 */       super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */       
/*     */       return;
/*     */     } 
/* 265 */     IndexedCell indexedCell = (IndexedCell)getSkinnable();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 270 */     double d1 = 0.0D;
/* 271 */     double d2 = 0.0D;
/* 272 */     double d3 = 0.0D;
/* 273 */     boolean bool1 = isIndentationRequired();
/* 274 */     boolean bool2 = isDisclosureNodeVisible();
/* 275 */     byte b1 = 0;
/* 276 */     Node node = null;
/* 277 */     if (bool1) {
/*     */ 
/*     */ 
/*     */       
/* 281 */       TableColumnBase<?, ?> tableColumnBase = getTreeColumn();
/* 282 */       b1 = (tableColumnBase == null) ? 0 : observableList.indexOf(tableColumnBase);
/* 283 */       b1 = b1 ? 0 : b1;
/*     */       
/* 285 */       int k = getIndentationLevel((C)indexedCell);
/* 286 */       if (!isShowRoot()) k--; 
/* 287 */       double d7 = getIndentationPerLevel();
/* 288 */       d1 = k * d7;
/*     */ 
/*     */ 
/*     */       
/* 292 */       double d8 = maxDisclosureWidthMap.containsKey(tableColumnBase) ? ((Double)maxDisclosureWidthMap.get(tableColumnBase)).doubleValue() : 0.0D;
/* 293 */       d2 = d8;
/*     */       
/* 295 */       node = getDisclosureNode();
/* 296 */       if (node != null) {
/* 297 */         node.setVisible(bool2);
/*     */         
/* 299 */         if (bool2) {
/* 300 */           d2 = node.prefWidth(paramDouble4);
/* 301 */           if (d2 > d8) {
/* 302 */             maxDisclosureWidthMap.put(tableColumnBase, Double.valueOf(d2));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 308 */             VirtualFlow<C> virtualFlow = getVirtualFlow();
/* 309 */             int m = ((IndexedCell)getSkinnable()).getIndex();
/* 310 */             for (byte b = 0; b < virtualFlow.cells.size(); b++) {
/* 311 */               IndexedCell indexedCell1 = (IndexedCell)virtualFlow.cells.get(b);
/* 312 */               if (indexedCell1 != null && !indexedCell1.isEmpty()) {
/* 313 */                 indexedCell1.requestLayout();
/* 314 */                 indexedCell1.layout();
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 328 */     double d4 = snappedTopInset() + snappedBottomInset();
/* 329 */     double d5 = snappedLeftInset() + snappedRightInset();
/* 330 */     double d6 = indexedCell.getHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     int i = indexedCell.getIndex();
/* 340 */     if (i < 0)
/*     */       return;  byte b2; int j;
/* 342 */     for (b2 = 0, j = this.cells.size(); b2 < j; b2++) {
/* 343 */       double d7, d8; IndexedCell indexedCell1 = (IndexedCell)this.cells.get(b2);
/* 344 */       TableColumnBase<T, ?> tableColumnBase = getTableColumn((R)indexedCell1);
/*     */       
/* 346 */       boolean bool = true;
/* 347 */       if (this.fixedCellSizeEnabled) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 357 */         bool = isColumnPartiallyOrFullyVisible(tableColumnBase);
/*     */         
/* 359 */         d8 = this.fixedCellSize;
/*     */       } else {
/* 361 */         d8 = Math.max(d6, indexedCell1.prefHeight(-1.0D));
/* 362 */         d8 = snapSizeY(d8) - snapSizeY(d4);
/*     */       } 
/*     */       
/* 365 */       if (bool) {
/* 366 */         if (this.fixedCellSizeEnabled && indexedCell1.getParent() == null) {
/* 367 */           getChildren().add(indexedCell1);
/*     */         }
/*     */         
/* 370 */         d7 = indexedCell1.prefWidth(d8) - snapSizeX(d5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 379 */         boolean bool3 = (paramDouble4 <= 24.0D) ? true : false;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 384 */         StyleOrigin styleOrigin = ((StyleableObjectProperty)indexedCell1.alignmentProperty()).getStyleOrigin();
/* 385 */         if (!bool3 && styleOrigin == null) {
/* 386 */           indexedCell1.setAlignment(Pos.TOP_LEFT);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 393 */         if (bool1 && b2 == b1) {
/* 394 */           if (bool2) {
/* 395 */             double d = node.prefHeight(d2);
/*     */             
/* 397 */             if (d7 > 0.0D && d7 < d2 + d1) {
/* 398 */               fadeOut(node);
/*     */             } else {
/* 400 */               fadeIn(node);
/* 401 */               node.resize(d2, d);
/*     */               
/* 403 */               node.relocate(paramDouble1 + d1, 
/* 404 */                   bool3 ? (paramDouble4 / 2.0D - d / 2.0D) : (
/* 405 */                   paramDouble2 + indexedCell1.getPadding().getTop()));
/* 406 */               node.toFront();
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 412 */           ObjectProperty<Node> objectProperty = graphicProperty();
/* 413 */           Node node1 = (objectProperty == null) ? null : objectProperty.get();
/*     */           
/* 415 */           if (node1 != null) {
/* 416 */             d3 = node1.prefWidth(-1.0D) + 3.0D;
/* 417 */             double d = node1.prefHeight(d3);
/*     */             
/* 419 */             if (d7 > 0.0D && d7 < d2 + d1 + d3) {
/* 420 */               fadeOut(node1);
/*     */             } else {
/* 422 */               fadeIn(node1);
/*     */               
/* 424 */               node1.relocate(paramDouble1 + d1 + d2, 
/* 425 */                   bool3 ? (paramDouble4 / 2.0D - d / 2.0D) : (
/* 426 */                   paramDouble2 + indexedCell1.getPadding().getTop()));
/*     */               
/* 428 */               node1.toFront();
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 436 */         indexedCell1.resize(d7, d8);
/* 437 */         indexedCell1.relocate(paramDouble1, snappedTopInset());
/*     */ 
/*     */ 
/*     */         
/* 441 */         indexedCell1.requestLayout();
/*     */       } else {
/* 443 */         d7 = snapSizeX(indexedCell1.prefWidth(-1.0D)) - snapSizeX(d5);
/*     */         
/* 445 */         if (this.fixedCellSizeEnabled)
/*     */         {
/*     */ 
/*     */           
/* 449 */           getChildren().remove(indexedCell1);
/*     */         }
/*     */       } 
/*     */       
/* 453 */       paramDouble1 += d7;
/*     */     } 
/*     */   }
/*     */   
/*     */   int getIndentationLevel(C paramC) {
/* 458 */     return 0;
/*     */   }
/*     */   
/*     */   double getIndentationPerLevel() {
/* 462 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isIndentationRequired() {
/* 470 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TableColumnBase getTreeColumn() {
/* 478 */     return null;
/*     */   }
/*     */   
/*     */   Node getDisclosureNode() {
/* 482 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDisclosureNodeVisible() {
/* 491 */     return false;
/*     */   }
/*     */   
/*     */   boolean isShowRoot() {
/* 495 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateCells(boolean paramBoolean) {
/* 503 */     if (paramBoolean) {
/* 504 */       if (this.fullRefreshCounter == 0) {
/* 505 */         recreateCells();
/*     */       }
/* 507 */       this.fullRefreshCounter--;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 512 */     boolean bool = this.cells.isEmpty();
/* 513 */     this.cells.clear();
/*     */     
/* 515 */     IndexedCell indexedCell = (IndexedCell)getSkinnable();
/* 516 */     int i = indexedCell.getIndex();
/* 517 */     ObservableList<? extends TableColumnBase> observableList = getVisibleLeafColumns(); byte b;
/*     */     int j;
/* 519 */     for (b = 0, j = observableList.size(); b < j; b++) {
/* 520 */       TableColumnBase<T, ?> tableColumnBase = observableList.get(b);
/*     */       
/* 522 */       IndexedCell indexedCell1 = null;
/* 523 */       if (this.cellsMap.containsKey(tableColumnBase)) {
/* 524 */         indexedCell1 = ((Reference<IndexedCell>)this.cellsMap.get(tableColumnBase)).get();
/*     */ 
/*     */         
/* 527 */         if (indexedCell1 == null) {
/* 528 */           this.cellsMap.remove(tableColumnBase);
/*     */         }
/*     */       } 
/*     */       
/* 532 */       if (indexedCell1 == null)
/*     */       {
/*     */         
/* 535 */         indexedCell1 = (IndexedCell)createCellAndCache(tableColumnBase);
/*     */       }
/*     */       
/* 538 */       updateCell((R)indexedCell1, (C)indexedCell);
/* 539 */       indexedCell1.updateIndex(i);
/* 540 */       this.cells.add((R)indexedCell1);
/*     */     } 
/*     */ 
/*     */     
/* 544 */     if (this.fixedCellSizeEnabled) {
/*     */ 
/*     */ 
/*     */       
/* 548 */       ArrayList<Node> arrayList = new ArrayList();
/* 549 */       for (Node node : getChildren()) {
/* 550 */         if (node instanceof IndexedCell && 
/* 551 */           !getTableColumn((R)node).isVisible()) {
/* 552 */           arrayList.add(node);
/*     */         }
/*     */       } 
/* 555 */       getChildren().removeAll(arrayList);
/* 556 */     } else if (!this.fixedCellSizeEnabled && (paramBoolean || bool)) {
/* 557 */       getChildren().setAll((Collection)this.cells);
/*     */     } 
/*     */   }
/*     */   
/*     */   VirtualFlow<C> getVirtualFlow() {
/* 562 */     C c = getSkinnable();
/* 563 */     while (c != null) {
/* 564 */       if (c instanceof VirtualFlow) {
/* 565 */         return (VirtualFlow<C>)c;
/*     */       }
/* 567 */       Parent parent = c.getParent();
/*     */     } 
/* 569 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 574 */     double d = 0.0D;
/* 575 */     for (IndexedCell indexedCell : this.cells) {
/* 576 */       d += indexedCell.prefWidth(paramDouble1);
/*     */     }
/* 578 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 583 */     if (this.fixedCellSizeEnabled) {
/* 584 */       return this.fixedCellSize;
/*     */     }
/*     */ 
/*     */     
/* 588 */     checkState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 594 */     if (getCellSize() < 24.0D) {
/* 595 */       return getCellSize();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 600 */     double d = 0.0D;
/* 601 */     int i = this.cells.size();
/* 602 */     for (byte b = 0; b < i; b++) {
/* 603 */       IndexedCell indexedCell = (IndexedCell)this.cells.get(b);
/* 604 */       d = Math.max(d, indexedCell.prefHeight(-1.0D));
/*     */     } 
/* 606 */     return Math.max(d, Math.max(getCellSize(), ((IndexedCell)getSkinnable()).minHeight(-1.0D)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 613 */     if (this.fixedCellSizeEnabled) {
/* 614 */       return this.fixedCellSize;
/*     */     }
/*     */ 
/*     */     
/* 618 */     checkState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 624 */     if (getCellSize() < 24.0D) {
/* 625 */       return getCellSize();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 630 */     double d = 0.0D;
/* 631 */     int i = this.cells.size();
/* 632 */     for (byte b = 0; b < i; b++) {
/* 633 */       IndexedCell indexedCell = (IndexedCell)this.cells.get(b);
/* 634 */       d = Math.max(d, indexedCell.minHeight(-1.0D));
/*     */     } 
/* 636 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 641 */     if (this.fixedCellSizeEnabled) {
/* 642 */       return this.fixedCellSize;
/*     */     }
/* 644 */     return super.computeMaxHeight(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
/*     */   }
/*     */   
/*     */   final void checkState() {
/* 648 */     if (this.isDirty) {
/* 649 */       updateCells(true);
/* 650 */       this.isDirty = false;
/* 651 */       this.updateCells = false;
/* 652 */     } else if (this.updateCells) {
/* 653 */       updateCells(false);
/* 654 */       this.updateCells = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isColumnPartiallyOrFullyVisible(TableColumnBase paramTableColumnBase) {
/* 667 */     if (paramTableColumnBase == null || !paramTableColumnBase.isVisible()) return false;
/*     */     
/* 669 */     VirtualFlow<C> virtualFlow = getVirtualFlow();
/* 670 */     double d1 = (virtualFlow == null) ? 0.0D : virtualFlow.getHbar().getValue();
/*     */ 
/*     */     
/* 673 */     double d2 = 0.0D;
/* 674 */     ObservableList<? extends TableColumnBase> observableList = getVisibleLeafColumns(); byte b; int i;
/* 675 */     for (b = 0, i = observableList.size(); b < i; b++) {
/* 676 */       TableColumnBase tableColumnBase = observableList.get(b);
/* 677 */       if (tableColumnBase.equals(paramTableColumnBase))
/* 678 */         break;  d2 += tableColumnBase.getWidth();
/*     */     } 
/* 680 */     double d3 = d2 + paramTableColumnBase.getWidth();
/*     */ 
/*     */     
/* 683 */     Insets insets = ((IndexedCell)getSkinnable()).getPadding();
/* 684 */     double d4 = ((IndexedCell)getSkinnable()).getWidth() - insets.getLeft() + insets.getRight();
/*     */     
/* 686 */     return ((d2 >= d1 || d3 > d1) && (d2 < d4 + d1 || d3 <= d4 + d1));
/*     */   }
/*     */   
/*     */   private void requestCellUpdate() {
/* 690 */     this.updateCells = true;
/* 691 */     ((IndexedCell)getSkinnable()).requestLayout();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 699 */     int i = ((IndexedCell)getSkinnable()).getIndex(); byte b; int j;
/* 700 */     for (b = 0, j = this.cells.size(); b < j; b++) {
/* 701 */       ((IndexedCell)this.cells.get(b)).updateIndex(i);
/*     */     }
/*     */   }
/*     */   
/*     */   private void recreateCells() {
/* 706 */     if (this.cellsMap != null) {
/* 707 */       Collection<Reference<R>> collection = this.cellsMap.values();
/* 708 */       Iterator<Reference<R>> iterator = collection.iterator();
/* 709 */       while (iterator.hasNext()) {
/* 710 */         Reference<IndexedCell> reference = iterator.next();
/* 711 */         IndexedCell indexedCell = reference.get();
/* 712 */         if (indexedCell != null) {
/* 713 */           indexedCell.updateIndex(-1);
/* 714 */           indexedCell.getSkin().dispose();
/* 715 */           indexedCell.setSkin((Skin<?>)null);
/*     */         } 
/*     */       } 
/* 718 */       this.cellsMap.clear();
/*     */     } 
/*     */     
/* 721 */     ObservableList<? extends TableColumnBase> observableList = getVisibleLeafColumns();
/*     */     
/* 723 */     this.cellsMap = new WeakHashMap<>(observableList.size());
/* 724 */     this.fullRefreshCounter = 100;
/* 725 */     getChildren().clear();
/*     */     
/* 727 */     for (TableColumnBase<T, ?> tableColumnBase : observableList) {
/* 728 */       if (this.cellsMap.containsKey(tableColumnBase)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 734 */       createCellAndCache(tableColumnBase);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private R createCellAndCache(TableColumnBase<T, ?> paramTableColumnBase) {
/* 740 */     R r = createCell(paramTableColumnBase);
/*     */ 
/*     */     
/* 743 */     this.cellsMap.put(paramTableColumnBase, new WeakReference<>(r));
/*     */     
/* 745 */     return r;
/*     */   }
/*     */   
/*     */   private void fadeOut(Node paramNode) {
/* 749 */     if (paramNode.getOpacity() < 1.0D)
/*     */       return; 
/* 751 */     if (!DO_ANIMATIONS) {
/* 752 */       paramNode.setOpacity(0.0D);
/*     */       
/*     */       return;
/*     */     } 
/* 756 */     FadeTransition fadeTransition = new FadeTransition(FADE_DURATION, paramNode);
/* 757 */     fadeTransition.setToValue(0.0D);
/* 758 */     fadeTransition.play();
/*     */   }
/*     */   
/*     */   private void fadeIn(Node paramNode) {
/* 762 */     if (paramNode.getOpacity() > 0.0D)
/*     */       return; 
/* 764 */     if (!DO_ANIMATIONS) {
/* 765 */       paramNode.setOpacity(1.0D);
/*     */       
/*     */       return;
/*     */     } 
/* 769 */     FadeTransition fadeTransition = new FadeTransition(FADE_DURATION, paramNode);
/* 770 */     fadeTransition.setToValue(1.0D);
/* 771 */     fadeTransition.play();
/*     */   }
/*     */   
/*     */   protected abstract R createCell(TableColumnBase<T, ?> paramTableColumnBase);
/*     */   
/*     */   protected abstract void updateCell(R paramR, C paramC);
/*     */   
/*     */   protected abstract TableColumnBase<T, ?> getTableColumn(R paramR);
/*     */   
/*     */   protected abstract ObservableList<? extends TableColumnBase> getVisibleLeafColumns();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TableRowSkinBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */