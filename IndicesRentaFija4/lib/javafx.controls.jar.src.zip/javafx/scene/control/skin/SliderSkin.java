/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.SliderBehavior;
/*     */ import javafx.animation.Transition;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.chart.NumberAxis;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.control.Slider;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.BackgroundFill;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.util.Duration;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SliderSkin
/*     */   extends SkinBase<Slider>
/*     */ {
/*  64 */   private NumberAxis tickLine = null;
/*  65 */   private double trackToTickGap = 2.0D;
/*     */   
/*     */   private boolean showTickMarks;
/*     */   
/*     */   private double thumbWidth;
/*     */   
/*     */   private double thumbHeight;
/*     */   
/*     */   private double trackStart;
/*     */   
/*     */   private double trackLength;
/*     */   
/*     */   private double thumbTop;
/*     */   private double thumbLeft;
/*     */   private double preDragThumbPos;
/*     */   private Point2D dragStart;
/*     */   private StackPane thumb;
/*     */   private StackPane track;
/*     */   private boolean trackClicked = false;
/*     */   private final SliderBehavior behavior;
/*  85 */   StringConverter<Number> stringConverterWrapper = new StringConverter<Number>() {
/*  86 */       Slider slider = SliderSkin.this.getSkinnable();
/*     */       public String toString(Number param1Number) {
/*  88 */         return (param1Number != null) ? this.slider.getLabelFormatter().toString(Double.valueOf(param1Number.doubleValue())) : "";
/*     */       }
/*     */       public Number fromString(String param1String) {
/*  91 */         return this.slider.getLabelFormatter().fromString(param1String);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SliderSkin(Slider paramSlider) {
/* 111 */     super(paramSlider);
/*     */     
/* 113 */     this.behavior = new SliderBehavior(paramSlider);
/*     */ 
/*     */     
/* 116 */     initialize();
/* 117 */     paramSlider.requestLayout();
/* 118 */     registerChangeListener(paramSlider.minProperty(), paramObservableValue -> {
/*     */           if (this.showTickMarks && this.tickLine != null) {
/*     */             this.tickLine.setLowerBound(paramSlider.getMin());
/*     */           }
/*     */           getSkinnable().requestLayout();
/*     */         });
/* 124 */     registerChangeListener(paramSlider.maxProperty(), paramObservableValue -> {
/*     */           if (this.showTickMarks && this.tickLine != null) {
/*     */             this.tickLine.setUpperBound(paramSlider.getMax());
/*     */           }
/*     */           getSkinnable().requestLayout();
/*     */         });
/* 130 */     registerChangeListener(paramSlider.valueProperty(), paramObservableValue -> positionThumb(this.trackClicked));
/*     */ 
/*     */ 
/*     */     
/* 134 */     registerChangeListener(paramSlider.orientationProperty(), paramObservableValue -> {
/*     */           if (this.showTickMarks && this.tickLine != null) {
/*     */             this.tickLine.setSide((paramSlider.getOrientation() == Orientation.VERTICAL) ? Side.RIGHT : ((paramSlider.getOrientation() == null) ? Side.RIGHT : Side.BOTTOM));
/*     */           }
/*     */           getSkinnable().requestLayout();
/*     */         });
/* 140 */     registerChangeListener(paramSlider.showTickMarksProperty(), paramObservableValue -> setShowTickMarks(paramSlider.isShowTickMarks(), paramSlider.isShowTickLabels()));
/* 141 */     registerChangeListener(paramSlider.showTickLabelsProperty(), paramObservableValue -> setShowTickMarks(paramSlider.isShowTickMarks(), paramSlider.isShowTickLabels()));
/* 142 */     registerChangeListener(paramSlider.majorTickUnitProperty(), paramObservableValue -> {
/*     */           if (this.tickLine != null) {
/*     */             this.tickLine.setTickUnit(paramSlider.getMajorTickUnit());
/*     */             getSkinnable().requestLayout();
/*     */           } 
/*     */         });
/* 148 */     registerChangeListener(paramSlider.minorTickCountProperty(), paramObservableValue -> {
/*     */           if (this.tickLine != null) {
/*     */             this.tickLine.setMinorTickCount(Math.max(paramSlider.getMinorTickCount(), 0) + 1);
/*     */             getSkinnable().requestLayout();
/*     */           } 
/*     */         });
/* 154 */     registerChangeListener(paramSlider.labelFormatterProperty(), paramObservableValue -> {
/*     */           if (this.tickLine != null) {
/*     */             if (paramSlider.getLabelFormatter() == null) {
/*     */               this.tickLine.setTickLabelFormatter((StringConverter<Number>)null);
/*     */             } else {
/*     */               this.tickLine.setTickLabelFormatter(this.stringConverterWrapper);
/*     */               this.tickLine.requestAxisLayout();
/*     */             } 
/*     */           }
/*     */         });
/* 164 */     registerChangeListener(paramSlider.snapToTicksProperty(), paramObservableValue -> paramSlider.adjustValue(paramSlider.getValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 179 */     super.dispose();
/*     */     
/* 181 */     if (this.behavior != null) {
/* 182 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 191 */     this.thumbWidth = snapSizeX(this.thumb.prefWidth(-1.0D));
/* 192 */     this.thumbHeight = snapSizeY(this.thumb.prefHeight(-1.0D));
/* 193 */     this.thumb.resize(this.thumbWidth, this.thumbHeight);
/*     */ 
/*     */     
/* 196 */     double d = (this.track.getBackground() == null) ? 0.0D : ((this.track.getBackground().getFills().size() > 0) ? ((BackgroundFill)this.track.getBackground().getFills().get(0)).getRadii().getTopLeftHorizontalRadius() : 0.0D);
/*     */     
/* 198 */     if (getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
/* 199 */       double d1 = this.showTickMarks ? this.tickLine.prefHeight(-1.0D) : 0.0D;
/* 200 */       double d2 = snapSizeY(this.track.prefHeight(-1.0D));
/* 201 */       double d3 = Math.max(d2, this.thumbHeight);
/* 202 */       double d4 = d3 + (this.showTickMarks ? (this.trackToTickGap + d1) : 0.0D);
/* 203 */       double d5 = paramDouble2 + (paramDouble4 - d4) / 2.0D;
/* 204 */       this.trackLength = snapSizeX(paramDouble3 - this.thumbWidth);
/* 205 */       this.trackStart = snapPositionX(paramDouble1 + this.thumbWidth / 2.0D);
/* 206 */       double d6 = (int)(d5 + (d3 - d2) / 2.0D);
/* 207 */       this.thumbTop = (int)(d5 + (d3 - this.thumbHeight) / 2.0D);
/*     */       
/* 209 */       positionThumb(false);
/*     */       
/* 211 */       this.track.resizeRelocate((int)(this.trackStart - d), d6, (int)(this.trackLength + d + d), d2);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 216 */       if (this.showTickMarks) {
/* 217 */         this.tickLine.setLayoutX(this.trackStart);
/* 218 */         this.tickLine.setLayoutY(d6 + d2 + this.trackToTickGap);
/* 219 */         this.tickLine.resize(this.trackLength, d1);
/* 220 */         this.tickLine.requestAxisLayout();
/*     */       } else {
/* 222 */         if (this.tickLine != null) {
/* 223 */           this.tickLine.resize(0.0D, 0.0D);
/* 224 */           this.tickLine.requestAxisLayout();
/*     */         } 
/* 226 */         this.tickLine = null;
/*     */       } 
/*     */     } else {
/* 229 */       double d1 = this.showTickMarks ? this.tickLine.prefWidth(-1.0D) : 0.0D;
/* 230 */       double d2 = snapSizeX(this.track.prefWidth(-1.0D));
/* 231 */       double d3 = Math.max(d2, this.thumbWidth);
/* 232 */       double d4 = d3 + (this.showTickMarks ? (this.trackToTickGap + d1) : 0.0D);
/* 233 */       double d5 = paramDouble1 + (paramDouble3 - d4) / 2.0D;
/* 234 */       this.trackLength = snapSizeY(paramDouble4 - this.thumbHeight);
/* 235 */       this.trackStart = snapPositionY(paramDouble2 + this.thumbHeight / 2.0D);
/* 236 */       double d6 = (int)(d5 + (d3 - d2) / 2.0D);
/* 237 */       this.thumbLeft = (int)(d5 + (d3 - this.thumbWidth) / 2.0D);
/*     */       
/* 239 */       positionThumb(false);
/*     */       
/* 241 */       this.track.resizeRelocate(d6, (int)(this.trackStart - d), d2, (int)(this.trackLength + d + d));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 246 */       if (this.showTickMarks) {
/* 247 */         this.tickLine.setLayoutX(d6 + d2 + this.trackToTickGap);
/* 248 */         this.tickLine.setLayoutY(this.trackStart);
/* 249 */         this.tickLine.resize(d1, this.trackLength);
/* 250 */         this.tickLine.requestAxisLayout();
/*     */       } else {
/* 252 */         if (this.tickLine != null) {
/* 253 */           this.tickLine.resize(0.0D, 0.0D);
/* 254 */           this.tickLine.requestAxisLayout();
/*     */         } 
/* 256 */         this.tickLine = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 263 */     Slider slider = getSkinnable();
/* 264 */     if (slider.getOrientation() == Orientation.HORIZONTAL) {
/* 265 */       return paramDouble5 + minTrackLength() + this.thumb.minWidth(-1.0D) + paramDouble3;
/*     */     }
/* 267 */     return paramDouble5 + this.thumb.prefWidth(-1.0D) + paramDouble3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 273 */     Slider slider = getSkinnable();
/* 274 */     if (slider.getOrientation() == Orientation.HORIZONTAL) {
/* 275 */       double d = this.showTickMarks ? (this.tickLine.prefHeight(-1.0D) + this.trackToTickGap) : 0.0D;
/* 276 */       return paramDouble2 + this.thumb.prefHeight(-1.0D) + d + paramDouble4;
/*     */     } 
/* 278 */     return paramDouble2 + minTrackLength() + this.thumb.prefHeight(-1.0D) + paramDouble4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 284 */     Slider slider = getSkinnable();
/* 285 */     if (slider.getOrientation() == Orientation.HORIZONTAL) {
/* 286 */       if (this.showTickMarks) {
/* 287 */         return Math.max(140.0D, this.tickLine.prefWidth(-1.0D));
/*     */       }
/* 289 */       return 140.0D;
/*     */     } 
/*     */     
/* 292 */     double d = this.showTickMarks ? (this.tickLine.prefWidth(-1.0D) + this.trackToTickGap) : 0.0D;
/* 293 */     return paramDouble5 + Math.max(this.thumb.prefWidth(-1.0D), this.track.prefWidth(-1.0D)) + d + paramDouble3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 299 */     Slider slider = getSkinnable();
/* 300 */     if (slider.getOrientation() == Orientation.HORIZONTAL) {
/* 301 */       return paramDouble2 + Math.max(this.thumb.prefHeight(-1.0D), this.track.prefHeight(-1.0D)) + (
/* 302 */         this.showTickMarks ? (this.trackToTickGap + this.tickLine.prefHeight(-1.0D)) : 0.0D) + paramDouble4;
/*     */     }
/* 304 */     if (this.showTickMarks) {
/* 305 */       return Math.max(140.0D, this.tickLine.prefHeight(-1.0D));
/*     */     }
/* 307 */     return 140.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 314 */     if (getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
/* 315 */       return Double.MAX_VALUE;
/*     */     }
/* 317 */     return getSkinnable().prefWidth(-1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 323 */     if (getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
/* 324 */       return getSkinnable().prefHeight(paramDouble1);
/*     */     }
/* 326 */     return Double.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 339 */     this.thumb = new StackPane()
/*     */       {
/*     */         public Object queryAccessibleAttribute(AccessibleAttribute param1AccessibleAttribute, Object... param1VarArgs) {
/* 342 */           switch (param1AccessibleAttribute) { case VALUE:
/* 343 */               return Double.valueOf(SliderSkin.this.getSkinnable().getValue()); }
/* 344 */            return super.queryAccessibleAttribute(param1AccessibleAttribute, param1VarArgs);
/*     */         }
/*     */       };
/*     */     
/* 348 */     this.thumb.getStyleClass().setAll(new String[] { "thumb" });
/* 349 */     this.thumb.setAccessibleRole(AccessibleRole.THUMB);
/* 350 */     this.track = new StackPane();
/* 351 */     this.track.getStyleClass().setAll(new String[] { "track" });
/*     */ 
/*     */     
/* 354 */     getChildren().clear();
/* 355 */     getChildren().addAll(new Node[] { this.track, this.thumb });
/* 356 */     setShowTickMarks(getSkinnable().isShowTickMarks(), getSkinnable().isShowTickLabels());
/* 357 */     this.track.setOnMousePressed(paramMouseEvent -> {
/*     */           if (!this.thumb.isPressed()) {
/*     */             this.trackClicked = true;
/*     */             
/*     */             if (getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
/*     */               this.behavior.trackPress(paramMouseEvent, paramMouseEvent.getX() / this.trackLength);
/*     */             } else {
/*     */               this.behavior.trackPress(paramMouseEvent, paramMouseEvent.getY() / this.trackLength);
/*     */             } 
/*     */             this.trackClicked = false;
/*     */           } 
/*     */         });
/* 369 */     this.track.setOnMouseDragged(paramMouseEvent -> {
/*     */           if (!this.thumb.isPressed()) {
/*     */             if (getSkinnable().getOrientation() == Orientation.HORIZONTAL) {
/*     */               this.behavior.trackPress(paramMouseEvent, paramMouseEvent.getX() / this.trackLength);
/*     */             } else {
/*     */               this.behavior.trackPress(paramMouseEvent, paramMouseEvent.getY() / this.trackLength);
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 379 */     this.thumb.setOnMousePressed(paramMouseEvent -> {
/*     */           this.behavior.thumbPressed(paramMouseEvent, 0.0D);
/*     */           
/*     */           this.dragStart = this.thumb.localToParent(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */           
/*     */           this.preDragThumbPos = (getSkinnable().getValue() - getSkinnable().getMin()) / (getSkinnable().getMax() - getSkinnable().getMin());
/*     */         });
/* 386 */     this.thumb.setOnMouseReleased(paramMouseEvent -> this.behavior.thumbReleased(paramMouseEvent));
/*     */ 
/*     */ 
/*     */     
/* 390 */     this.thumb.setOnMouseDragged(paramMouseEvent -> {
/*     */           Point2D point2D = this.thumb.localToParent(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */           double d = (getSkinnable().getOrientation() == Orientation.HORIZONTAL) ? (point2D.getX() - this.dragStart.getX()) : -(point2D.getY() - this.dragStart.getY());
/*     */           this.behavior.thumbDragged(paramMouseEvent, this.preDragThumbPos + d / this.trackLength);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void setShowTickMarks(boolean paramBoolean1, boolean paramBoolean2) {
/* 399 */     this.showTickMarks = (paramBoolean1 || paramBoolean2);
/* 400 */     Slider slider = getSkinnable();
/* 401 */     if (this.showTickMarks) {
/* 402 */       if (this.tickLine == null) {
/* 403 */         this.tickLine = new NumberAxis();
/* 404 */         this.tickLine.setAutoRanging(false);
/* 405 */         this.tickLine.setSide((slider.getOrientation() == Orientation.VERTICAL) ? Side.RIGHT : ((slider.getOrientation() == null) ? Side.RIGHT : Side.BOTTOM));
/* 406 */         this.tickLine.setUpperBound(slider.getMax());
/* 407 */         this.tickLine.setLowerBound(slider.getMin());
/* 408 */         this.tickLine.setTickUnit(slider.getMajorTickUnit());
/* 409 */         this.tickLine.setTickMarkVisible(paramBoolean1);
/* 410 */         this.tickLine.setTickLabelsVisible(paramBoolean2);
/* 411 */         this.tickLine.setMinorTickVisible(paramBoolean1);
/*     */ 
/*     */         
/* 414 */         this.tickLine.setMinorTickCount(Math.max(slider.getMinorTickCount(), 0) + 1);
/* 415 */         if (slider.getLabelFormatter() != null) {
/* 416 */           this.tickLine.setTickLabelFormatter(this.stringConverterWrapper);
/*     */         }
/* 418 */         getChildren().clear();
/* 419 */         getChildren().addAll(new Node[] { this.tickLine, this.track, this.thumb });
/*     */       } else {
/* 421 */         this.tickLine.setTickLabelsVisible(paramBoolean2);
/* 422 */         this.tickLine.setTickMarkVisible(paramBoolean1);
/* 423 */         this.tickLine.setMinorTickVisible(paramBoolean1);
/*     */       } 
/*     */     } else {
/*     */       
/* 427 */       getChildren().clear();
/* 428 */       getChildren().addAll(new Node[] { this.track, this.thumb });
/*     */     } 
/*     */ 
/*     */     
/* 432 */     getSkinnable().requestLayout();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void positionThumb(boolean paramBoolean) {
/* 439 */     Slider slider = getSkinnable();
/* 440 */     if (slider.getValue() > slider.getMax())
/* 441 */       return;  boolean bool = (slider.getOrientation() == Orientation.HORIZONTAL) ? true : false;
/*     */     
/* 443 */     final double endX = bool ? (this.trackStart + this.trackLength * (slider.getValue() - slider.getMin()) / (slider.getMax() - slider.getMin()) - this.thumbWidth / 2.0D) : this.thumbLeft;
/*     */ 
/*     */     
/* 446 */     final double endY = bool ? this.thumbTop : (snappedTopInset() + this.trackLength - this.trackLength * (slider.getValue() - slider.getMin()) / (slider.getMax() - slider.getMin()));
/*     */     
/* 448 */     if (paramBoolean) {
/*     */       
/* 450 */       final double startX = this.thumb.getLayoutX();
/* 451 */       final double startY = this.thumb.getLayoutY();
/* 452 */       Transition transition = new Transition()
/*     */         {
/*     */ 
/*     */           
/*     */           protected void interpolate(double param1Double)
/*     */           {
/* 458 */             if (!Double.isNaN(startX)) {
/* 459 */               SliderSkin.this.thumb.setLayoutX(startX + param1Double * (endX - startX));
/*     */             }
/* 461 */             if (!Double.isNaN(startY)) {
/* 462 */               SliderSkin.this.thumb.setLayoutY(startY + param1Double * (endY - startY));
/*     */             }
/*     */           }
/*     */         };
/* 466 */       transition.play();
/*     */     } else {
/* 468 */       this.thumb.setLayoutX(d1);
/* 469 */       this.thumb.setLayoutY(d2);
/*     */     } 
/*     */   }
/*     */   
/*     */   double minTrackLength() {
/* 474 */     return 2.0D * this.thumb.prefWidth(-1.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\SliderSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */