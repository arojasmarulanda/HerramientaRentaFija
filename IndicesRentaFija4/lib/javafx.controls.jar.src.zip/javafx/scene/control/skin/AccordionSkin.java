/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.AccordionBehavior;
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Accordion;
/*     */ import javafx.scene.control.Skin;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.control.TitledPane;
/*     */ import javafx.scene.shape.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AccordionSkin
/*     */   extends SkinBase<Accordion>
/*     */ {
/*     */   private TitledPane firstTitledPane;
/*     */   private Rectangle clipRect;
/*     */   private boolean forceRelayout = false;
/*     */   private boolean relayout = false;
/*  71 */   private double previousHeight = 0.0D;
/*     */   
/*  73 */   private TitledPane expandedPane = null;
/*  74 */   private TitledPane previousPane = null;
/*  75 */   private Map<TitledPane, ChangeListener<Boolean>> listeners = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final BehaviorBase<Accordion> behavior;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AccordionSkin(Accordion paramAccordion) {
/*  95 */     super(paramAccordion);
/*     */ 
/*     */     
/*  98 */     this.behavior = new AccordionBehavior(paramAccordion);
/*     */ 
/*     */     
/* 101 */     paramAccordion.getPanes().addListener(paramChange -> {
/*     */           if (this.firstTitledPane != null) {
/*     */             this.firstTitledPane.getStyleClass().remove("first-titled-pane");
/*     */           }
/*     */           
/*     */           if (!paramAccordion.getPanes().isEmpty()) {
/*     */             this.firstTitledPane = paramAccordion.getPanes().get(0);
/*     */             
/*     */             this.firstTitledPane.getStyleClass().add("first-titled-pane");
/*     */           } 
/*     */           
/*     */           getChildren().setAll((Collection)paramAccordion.getPanes());
/*     */           
/*     */           while (paramChange.next()) {
/*     */             removeTitledPaneListeners(paramChange.getRemoved());
/*     */             initTitledPaneListeners(paramChange.getAddedSubList());
/*     */           } 
/*     */           this.forceRelayout = true;
/*     */         });
/* 120 */     if (!paramAccordion.getPanes().isEmpty()) {
/* 121 */       this.firstTitledPane = paramAccordion.getPanes().get(0);
/* 122 */       this.firstTitledPane.getStyleClass().add("first-titled-pane");
/*     */     } 
/*     */     
/* 125 */     this.clipRect = new Rectangle(paramAccordion.getWidth(), paramAccordion.getHeight());
/* 126 */     getSkinnable().setClip(this.clipRect);
/*     */     
/* 128 */     initTitledPaneListeners(paramAccordion.getPanes());
/* 129 */     getChildren().setAll((Collection)paramAccordion.getPanes());
/* 130 */     getSkinnable().requestLayout();
/*     */     
/* 132 */     registerChangeListener(getSkinnable().widthProperty(), paramObservableValue -> this.clipRect.setWidth(getSkinnable().getWidth()));
/* 133 */     registerChangeListener(getSkinnable().heightProperty(), paramObservableValue -> {
/*     */           this.clipRect.setHeight(getSkinnable().getHeight());
/*     */           this.relayout = true;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 149 */     super.dispose();
/*     */     
/* 151 */     if (this.behavior != null) {
/* 152 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 158 */     double d = 0.0D;
/*     */     
/* 160 */     if (this.expandedPane != null) {
/* 161 */       d += this.expandedPane.minHeight(paramDouble1);
/*     */     }
/*     */     
/* 164 */     if (this.previousPane != null && !this.previousPane.equals(this.expandedPane)) {
/* 165 */       d += this.previousPane.minHeight(paramDouble1);
/*     */     }
/*     */     
/* 168 */     for (Node node : getChildren()) {
/* 169 */       TitledPane titledPane = (TitledPane)node;
/* 170 */       if (!titledPane.equals(this.expandedPane) && !titledPane.equals(this.previousPane)) {
/* 171 */         Skin<?> skin = ((TitledPane)node).getSkin();
/* 172 */         if (skin instanceof TitledPaneSkin) {
/* 173 */           TitledPaneSkin titledPaneSkin = (TitledPaneSkin)skin;
/* 174 */           d += titledPaneSkin.getTitleRegionSize(paramDouble1); continue;
/*     */         } 
/* 176 */         d += titledPane.minHeight(paramDouble1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 181 */     return d + paramDouble2 + paramDouble4;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 186 */     double d = 0.0D;
/*     */     
/* 188 */     if (this.expandedPane != null) {
/* 189 */       d += this.expandedPane.prefHeight(paramDouble1);
/*     */     }
/*     */     
/* 192 */     if (this.previousPane != null && !this.previousPane.equals(this.expandedPane)) {
/* 193 */       d += this.previousPane.prefHeight(paramDouble1);
/*     */     }
/*     */     
/* 196 */     for (Node node : getChildren()) {
/* 197 */       TitledPane titledPane = (TitledPane)node;
/* 198 */       if (!titledPane.equals(this.expandedPane) && !titledPane.equals(this.previousPane)) {
/* 199 */         Skin<?> skin = ((TitledPane)node).getSkin();
/* 200 */         if (skin instanceof TitledPaneSkin) {
/* 201 */           TitledPaneSkin titledPaneSkin = (TitledPaneSkin)skin;
/* 202 */           d += titledPaneSkin.getTitleRegionSize(paramDouble1); continue;
/*     */         } 
/* 204 */         d += titledPane.prefHeight(paramDouble1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 209 */     return d + paramDouble2 + paramDouble4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 215 */     boolean bool = (this.forceRelayout || (this.relayout && this.previousHeight != paramDouble4)) ? true : false;
/* 216 */     this.forceRelayout = false;
/* 217 */     this.previousHeight = paramDouble4;
/*     */ 
/*     */     
/* 220 */     double d1 = 0.0D;
/* 221 */     for (TitledPane titledPane : getSkinnable().getPanes()) {
/* 222 */       if (!titledPane.equals(this.expandedPane)) {
/* 223 */         TitledPaneSkin titledPaneSkin = (TitledPaneSkin)titledPane.getSkin();
/* 224 */         d1 += snapSizeY(titledPaneSkin.getTitleRegionSize(paramDouble3));
/*     */       } 
/*     */     } 
/* 227 */     double d2 = paramDouble4 - d1;
/*     */     
/* 229 */     for (TitledPane titledPane : getSkinnable().getPanes()) {
/* 230 */       double d; Skin<?> skin = titledPane.getSkin();
/*     */       
/* 232 */       if (skin instanceof TitledPaneSkin) {
/* 233 */         ((TitledPaneSkin)skin).setMaxTitledPaneHeightForAccordion(d2);
/* 234 */         d = snapSizeY(((TitledPaneSkin)skin).getTitledPaneHeightForAccordion());
/*     */       } else {
/* 236 */         d = titledPane.prefHeight(paramDouble3);
/*     */       } 
/* 238 */       titledPane.resize(paramDouble3, d);
/*     */       
/* 240 */       boolean bool1 = true;
/* 241 */       if (!bool && this.previousPane != null && this.expandedPane != null) {
/* 242 */         ObservableList<TitledPane> observableList = getSkinnable().getPanes();
/* 243 */         int i = observableList.indexOf(this.previousPane);
/* 244 */         int j = observableList.indexOf(this.expandedPane);
/* 245 */         int k = observableList.indexOf(titledPane);
/*     */         
/* 247 */         if (i < j) {
/*     */ 
/*     */           
/* 250 */           if (k <= j) {
/* 251 */             titledPane.relocate(paramDouble1, paramDouble2);
/* 252 */             paramDouble2 += d;
/* 253 */             bool1 = false;
/*     */           } 
/* 255 */         } else if (i > j) {
/*     */ 
/*     */           
/* 258 */           if (k <= i) {
/* 259 */             titledPane.relocate(paramDouble1, paramDouble2);
/* 260 */             paramDouble2 += d;
/* 261 */             bool1 = false;
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 267 */           titledPane.relocate(paramDouble1, paramDouble2);
/* 268 */           paramDouble2 += d;
/* 269 */           bool1 = false;
/*     */         } 
/*     */       } 
/*     */       
/* 273 */       if (bool1) {
/* 274 */         titledPane.relocate(paramDouble1, paramDouble2);
/* 275 */         paramDouble2 += d;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initTitledPaneListeners(List<? extends TitledPane> paramList) {
/* 289 */     for (TitledPane titledPane : paramList) {
/* 290 */       titledPane.setExpanded((titledPane == getSkinnable().getExpandedPane()));
/* 291 */       if (titledPane.isExpanded()) {
/* 292 */         this.expandedPane = titledPane;
/*     */       }
/* 294 */       ChangeListener<Boolean> changeListener = expandedPropertyListener(titledPane);
/* 295 */       titledPane.expandedProperty().addListener(changeListener);
/* 296 */       this.listeners.put(titledPane, changeListener);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeTitledPaneListeners(List<? extends TitledPane> paramList) {
/* 301 */     for (TitledPane titledPane : paramList) {
/* 302 */       if (this.listeners.containsKey(titledPane)) {
/* 303 */         titledPane.expandedProperty().removeListener(this.listeners.get(titledPane));
/* 304 */         this.listeners.remove(titledPane);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private ChangeListener<Boolean> expandedPropertyListener(TitledPane paramTitledPane) {
/* 310 */     return (paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*     */         this.previousPane = this.expandedPane;
/*     */         Accordion accordion = getSkinnable();
/*     */         if (paramBoolean2.booleanValue()) {
/*     */           if (this.expandedPane != null)
/*     */             this.expandedPane.setExpanded(false); 
/*     */           if (paramTitledPane != null)
/*     */             accordion.setExpandedPane(paramTitledPane); 
/*     */           this.expandedPane = accordion.getExpandedPane();
/*     */         } else {
/*     */           this.expandedPane = null;
/*     */           accordion.setExpandedPane((TitledPane)null);
/*     */         } 
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\AccordionSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */