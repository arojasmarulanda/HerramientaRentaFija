/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.ParentHelper;
/*     */ import com.sun.javafx.scene.control.CustomColorDialog;
/*     */ import com.sun.javafx.scene.control.Properties;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import com.sun.javafx.scene.traversal.Algorithm;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import com.sun.javafx.scene.traversal.ParentTraversalEngine;
/*     */ import com.sun.javafx.scene.traversal.TraversalContext;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.util.List;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.geometry.NodeOrientation;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ColorPicker;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.Hyperlink;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.PopupControl;
/*     */ import javafx.scene.control.Separator;
/*     */ import javafx.scene.control.Tooltip;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.GridPane;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.layout.VBox;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.shape.Rectangle;
/*     */ import javafx.scene.shape.StrokeType;
/*     */ import javafx.stage.WindowEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ColorPalette
/*     */   extends Region
/*     */ {
/*     */   private static final int SQUARE_SIZE = 15;
/*     */   ColorPickerGrid colorPickerGrid;
/*  78 */   final Hyperlink customColorLink = new Hyperlink(Properties.getColorPickerString("customColorLink"));
/*  79 */   CustomColorDialog customColorDialog = null;
/*     */   
/*     */   private ColorPicker colorPicker;
/*  82 */   private final GridPane standardColorGrid = new GridPane();
/*  83 */   private final GridPane customColorGrid = new GridPane();
/*  84 */   private final Separator separator = new Separator();
/*  85 */   private final Label customColorLabel = new Label(Properties.getColorPickerString("customColorLabel"));
/*     */   
/*     */   private PopupControl popupControl;
/*     */   private ColorSquare focusedSquare;
/*  89 */   private ContextMenu contextMenu = null;
/*     */   
/*  91 */   private Color mouseDragColor = null;
/*     */   
/*     */   private boolean dragDetected = false;
/*     */   
/*  95 */   private int customColorNumber = 0;
/*  96 */   private int customColorRows = 0;
/*  97 */   private int customColorLastRowLength = 0;
/*     */   private static final int NUM_OF_COLUMNS = 12;
/*  99 */   private final ColorSquare hoverSquare = new ColorSquare();
/*     */   
/*     */   public ColorPalette(final ColorPicker colorPicker) {
/* 102 */     getStyleClass().add("color-palette-region");
/* 103 */     this.colorPicker = colorPicker;
/* 104 */     this.colorPickerGrid = new ColorPickerGrid();
/* 105 */     ((Node)this.colorPickerGrid.getChildren().get(0)).requestFocus();
/* 106 */     this.customColorLabel.setAlignment(Pos.CENTER_LEFT);
/* 107 */     this.customColorLink.setPrefWidth(this.colorPickerGrid.prefWidth(-1.0D));
/* 108 */     this.customColorLink.setAlignment(Pos.CENTER);
/* 109 */     this.customColorLink.setFocusTraversable(true);
/* 110 */     this.customColorLink.setVisited(true);
/* 111 */     this.customColorLink.setOnAction(new EventHandler<ActionEvent>() {
/*     */           public void handle(ActionEvent param1ActionEvent) {
/* 113 */             if (ColorPalette.this.customColorDialog == null) {
/* 114 */               ColorPalette.this.customColorDialog = new CustomColorDialog(ColorPalette.this.popupControl);
/* 115 */               ColorPalette.this.customColorDialog.customColorProperty().addListener((param1ObservableValue, param1Color1, param1Color2) -> param1ColorPicker.setValue(ColorPalette.this.customColorDialog.customColorProperty().get()));
/*     */ 
/*     */               
/* 118 */               ColorPalette.this.customColorDialog.setOnSave(() -> {
/*     */                     Color color = ColorPalette.this.customColorDialog.customColorProperty().get();
/*     */                     ColorPalette.this.buildCustomColors();
/*     */                     param1ColorPicker.getCustomColors().add(color);
/*     */                     ColorPalette.this.updateSelection(color);
/*     */                     Event.fireEvent(param1ColorPicker, new ActionEvent());
/*     */                     param1ColorPicker.hide();
/*     */                   });
/* 126 */               ColorPalette.this.customColorDialog.setOnUse(() -> {
/*     */                     Event.fireEvent(param1ColorPicker, new ActionEvent());
/*     */                     param1ColorPicker.hide();
/*     */                   });
/*     */             } 
/* 131 */             ColorPalette.this.customColorDialog.setCurrentColor(colorPicker.valueProperty().get());
/* 132 */             if (ColorPalette.this.popupControl != null) ColorPalette.this.popupControl.setAutoHide(false); 
/* 133 */             ColorPalette.this.customColorDialog.show();
/* 134 */             ColorPalette.this.customColorDialog.setOnHidden(param1WindowEvent -> {
/*     */                   if (ColorPalette.this.popupControl != null)
/*     */                     ColorPalette.this.popupControl.setAutoHide(true); 
/*     */                 });
/*     */           }
/*     */         });
/* 140 */     initNavigation();
/*     */     
/* 142 */     buildStandardColors();
/* 143 */     this.standardColorGrid.getStyleClass().add("color-picker-grid");
/* 144 */     this.standardColorGrid.setVisible(true);
/* 145 */     this.customColorGrid.getStyleClass().add("color-picker-grid");
/* 146 */     this.customColorGrid.setVisible(false);
/* 147 */     buildCustomColors();
/* 148 */     colorPicker.getCustomColors().addListener(new ListChangeListener<Color>() {
/*     */           public void onChanged(ListChangeListener.Change<? extends Color> param1Change) {
/* 150 */             ColorPalette.this.buildCustomColors();
/*     */           }
/*     */         });
/*     */     
/* 154 */     VBox vBox = new VBox();
/* 155 */     vBox.getStyleClass().add("color-palette");
/* 156 */     vBox.getChildren().addAll(new Node[] { this.standardColorGrid, this.colorPickerGrid, this.customColorLabel, this.customColorGrid, this.separator, this.customColorLink });
/*     */     
/* 158 */     this.hoverSquare.setMouseTransparent(true);
/* 159 */     this.hoverSquare.getStyleClass().addAll(new String[] { "hover-square" });
/* 160 */     setFocusedSquare((ColorSquare)null);
/*     */     
/* 162 */     getChildren().addAll(new Node[] { vBox, this.hoverSquare });
/*     */   }
/*     */   private void setFocusedSquare(ColorSquare paramColorSquare) {
/*     */     double d3;
/* 166 */     if (paramColorSquare == this.focusedSquare) {
/*     */       return;
/*     */     }
/* 169 */     this.focusedSquare = paramColorSquare;
/*     */     
/* 171 */     this.hoverSquare.setVisible((this.focusedSquare != null));
/* 172 */     if (this.focusedSquare == null) {
/*     */       return;
/*     */     }
/*     */     
/* 176 */     if (!this.focusedSquare.isFocused()) {
/* 177 */       this.focusedSquare.requestFocus();
/*     */     }
/*     */     
/* 180 */     this.hoverSquare.rectangle.setFill(this.focusedSquare.rectangle.getFill());
/*     */     
/* 182 */     Bounds bounds = paramColorSquare.localToScene(paramColorSquare.getLayoutBounds());
/*     */     
/* 184 */     double d1 = bounds.getMinX();
/* 185 */     double d2 = bounds.getMinY();
/*     */ 
/*     */     
/* 188 */     double d4 = (this.hoverSquare.getScaleX() == 1.0D) ? 0.0D : (this.hoverSquare.getWidth() / 4.0D);
/*     */     
/* 190 */     if (this.colorPicker.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) {
/* 191 */       d1 = this.focusedSquare.getLayoutX();
/* 192 */       d3 = -this.focusedSquare.getWidth() + d4;
/*     */     } else {
/* 194 */       d3 = this.focusedSquare.getWidth() / 2.0D + d4;
/*     */     } 
/*     */     
/* 197 */     this.hoverSquare.setLayoutX(snapPositionX(d1) - d3);
/* 198 */     this.hoverSquare.setLayoutY(snapPositionY(d2) - this.focusedSquare.getHeight() / 2.0D + ((this.hoverSquare.getScaleY() == 1.0D) ? 0.0D : (this.focusedSquare.getHeight() / 4.0D)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildStandardColors() {
/* 208 */     Color[] arrayOfColor = { Color.AQUA, Color.TEAL, Color.BLUE, Color.NAVY, Color.FUCHSIA, Color.PURPLE, Color.RED, Color.MAROON, Color.YELLOW, Color.OLIVE, Color.GREEN, Color.LIME };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     this.standardColorGrid.getChildren().clear();
/*     */     
/* 225 */     for (byte b = 0; b < 12; b++) {
/* 226 */       this.standardColorGrid.add(new ColorSquare(arrayOfColor[b], b, ColorType.STANDARD), b, 0);
/*     */     }
/*     */   }
/*     */   
/*     */   private void buildCustomColors() {
/* 231 */     ObservableList<Color> observableList = this.colorPicker.getCustomColors();
/* 232 */     this.customColorNumber = observableList.size();
/*     */     
/* 234 */     this.customColorGrid.getChildren().clear();
/* 235 */     if (observableList.isEmpty()) {
/* 236 */       this.customColorLabel.setVisible(false);
/* 237 */       this.customColorLabel.setManaged(false);
/* 238 */       this.customColorGrid.setVisible(false);
/* 239 */       this.customColorGrid.setManaged(false);
/*     */       return;
/*     */     } 
/* 242 */     this.customColorLabel.setVisible(true);
/* 243 */     this.customColorLabel.setManaged(true);
/* 244 */     this.customColorGrid.setVisible(true);
/* 245 */     this.customColorGrid.setManaged(true);
/* 246 */     if (this.contextMenu == null) {
/* 247 */       MenuItem menuItem = new MenuItem(Properties.getColorPickerString("removeColor"));
/* 248 */       menuItem.setOnAction(paramActionEvent -> {
/*     */             ColorSquare colorSquare = (ColorSquare)this.contextMenu.getOwnerNode();
/*     */             paramObservableList.remove(colorSquare.rectangle.getFill());
/*     */             buildCustomColors();
/*     */           });
/* 253 */       this.contextMenu = new ContextMenu(new MenuItem[] { menuItem });
/*     */     } 
/*     */ 
/*     */     
/* 257 */     byte b1 = 0;
/* 258 */     byte b2 = 0;
/* 259 */     int i = observableList.size() % 12;
/* 260 */     byte b3 = (i == 0) ? 0 : (12 - i);
/* 261 */     this.customColorLastRowLength = (i == 0) ? 12 : i;
/*     */     byte b4;
/* 263 */     for (b4 = 0; b4 < observableList.size(); b4++) {
/* 264 */       Color color = observableList.get(b4);
/* 265 */       ColorSquare colorSquare = new ColorSquare(color, b4, ColorType.CUSTOM);
/* 266 */       colorSquare.addEventHandler(KeyEvent.KEY_PRESSED, paramKeyEvent -> {
/*     */             if (paramKeyEvent.getCode() == KeyCode.DELETE) {
/*     */               paramObservableList.remove(paramColorSquare.rectangle.getFill());
/*     */               buildCustomColors();
/*     */             } 
/*     */           });
/* 272 */       this.customColorGrid.add(colorSquare, b1, b2);
/* 273 */       b1++;
/* 274 */       if (b1 == 12) {
/* 275 */         b1 = 0;
/* 276 */         b2++;
/*     */       } 
/*     */     } 
/* 279 */     for (b4 = 0; b4 < b3; b4++) {
/* 280 */       ColorSquare colorSquare = new ColorSquare();
/* 281 */       colorSquare.setDisable(true);
/* 282 */       this.customColorGrid.add(colorSquare, b1, b2);
/* 283 */       b1++;
/*     */     } 
/* 285 */     this.customColorRows = b2 + 1;
/* 286 */     requestLayout();
/*     */   }
/*     */ 
/*     */   
/*     */   private void initNavigation() {
/* 291 */     setOnKeyPressed(paramKeyEvent -> {
/*     */           switch (paramKeyEvent.getCode()) {
/*     */             case SPACE:
/*     */             case ENTER:
/*     */               processSelectKey(paramKeyEvent);
/*     */               paramKeyEvent.consume();
/*     */               break;
/*     */           } 
/*     */ 
/*     */         
/*     */         });
/* 302 */     ParentHelper.setTraversalEngine(this, new ParentTraversalEngine(this, new Algorithm()
/*     */           {
/*     */             public Node select(Node param1Node, Direction param1Direction, TraversalContext param1TraversalContext) {
/* 305 */               Node node = param1TraversalContext.selectInSubtree(param1TraversalContext.getRoot(), param1Node, param1Direction);
/* 306 */               switch (param1Direction) {
/*     */                 case SPACE:
/*     */                 case ENTER:
/*     */                 case null:
/* 310 */                   return node;
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 case null:
/*     */                 case null:
/*     */                 case null:
/*     */                 case null:
/* 319 */                   if (param1Node instanceof ColorPalette.ColorSquare) {
/* 320 */                     Node node1 = processArrow((ColorPalette.ColorSquare)param1Node, param1Direction);
/* 321 */                     return (node1 != null) ? node1 : node;
/*     */                   } 
/* 323 */                   return node;
/*     */               } 
/*     */               
/* 326 */               return null;
/*     */             }
/*     */             
/*     */             private Node processArrow(ColorPalette.ColorSquare param1ColorSquare, Direction param1Direction) {
/* 330 */               int i = 0;
/* 331 */               int j = 0;
/*     */               
/* 333 */               if (param1ColorSquare.colorType == ColorPalette.ColorType.STANDARD) {
/* 334 */                 i = 0;
/* 335 */                 j = param1ColorSquare.index;
/*     */               } else {
/* 337 */                 i = param1ColorSquare.index / 12;
/* 338 */                 j = param1ColorSquare.index % 12;
/*     */               } 
/*     */ 
/*     */               
/* 342 */               param1Direction = param1Direction.getDirectionForNodeOrientation(ColorPalette.this.colorPicker.getEffectiveNodeOrientation());
/*     */               
/* 344 */               if (isAtBorder(param1Direction, i, j, (param1ColorSquare.colorType == ColorPalette.ColorType.CUSTOM))) {
/*     */ 
/*     */                 
/* 347 */                 int k = i;
/* 348 */                 int m = j;
/* 349 */                 boolean bool1 = (param1ColorSquare.colorType == ColorPalette.ColorType.CUSTOM) ? true : false;
/* 350 */                 boolean bool2 = (param1ColorSquare.colorType == ColorPalette.ColorType.STANDARD) ? true : false;
/* 351 */                 switch (param1Direction) {
/*     */ 
/*     */                   
/*     */                   case null:
/*     */                   case null:
/* 356 */                     if (param1ColorSquare.colorType == ColorPalette.ColorType.STANDARD) {
/* 357 */                       k = 0;
/* 358 */                       m = (param1Direction == Direction.LEFT) ? 11 : 0; break;
/*     */                     } 
/* 360 */                     if (param1ColorSquare.colorType == ColorPalette.ColorType.CUSTOM) {
/* 361 */                       k = Math.floorMod((param1Direction == Direction.LEFT) ? (i - 1) : (i + 1), ColorPalette.this.customColorRows);
/*     */                       
/* 363 */                       m = (param1Direction == Direction.LEFT) ? ((k == ColorPalette.this.customColorRows - 1) ? (ColorPalette.this.customColorLastRowLength - 1) : 11) : 0; break;
/*     */                     } 
/* 365 */                     k = Math.floorMod((param1Direction == Direction.LEFT) ? (i - 1) : (i + 1), ColorPalette.NUM_OF_ROWS);
/* 366 */                     m = (param1Direction == Direction.LEFT) ? 11 : 0;
/*     */                     break;
/*     */                   
/*     */                   case null:
/* 370 */                     if (param1ColorSquare.colorType == ColorPalette.ColorType.NORMAL && i == 0) {
/* 371 */                       bool2 = true;
/*     */                     }
/*     */                     break;
/*     */                   case null:
/* 375 */                     if (ColorPalette.this.customColorNumber > 0) {
/* 376 */                       bool1 = true;
/* 377 */                       k = 0;
/* 378 */                       m = (ColorPalette.this.customColorRows > 1) ? j : Math.min(ColorPalette.this.customColorLastRowLength - 1, j);
/*     */                       break;
/*     */                     } 
/* 381 */                     return null;
/*     */                 } 
/*     */ 
/*     */                 
/* 385 */                 if (bool1)
/* 386 */                   return ColorPalette.this.customColorGrid.getChildren().get(k * 12 + m); 
/* 387 */                 if (bool2) {
/* 388 */                   return ColorPalette.this.standardColorGrid.getChildren().get(m);
/*     */                 }
/* 390 */                 return ColorPalette.this.colorPickerGrid.getChildren().get(k * 12 + m);
/*     */               } 
/*     */               
/* 393 */               return null;
/*     */             }
/*     */             
/*     */             private boolean isAtBorder(Direction param1Direction, int param1Int1, int param1Int2, boolean param1Boolean) {
/* 397 */               switch (param1Direction) {
/*     */                 case null:
/* 399 */                   return (param1Int2 == 0);
/*     */                 case null:
/* 401 */                   return (param1Boolean && param1Int1 == ColorPalette.this.customColorRows - 1) ? (
/* 402 */                     (param1Int2 == ColorPalette.this.customColorLastRowLength - 1)) : ((param1Int2 == 11));
/*     */                 case null:
/* 404 */                   return (!param1Boolean && param1Int1 == 0);
/*     */                 case null:
/* 406 */                   return (!param1Boolean && param1Int1 == ColorPalette.NUM_OF_ROWS - 1);
/*     */               } 
/* 408 */               return false;
/*     */             }
/*     */ 
/*     */             
/*     */             public Node selectFirst(TraversalContext param1TraversalContext) {
/* 413 */               return ColorPalette.this.standardColorGrid.getChildren().get(0);
/*     */             }
/*     */ 
/*     */             
/*     */             public Node selectLast(TraversalContext param1TraversalContext) {
/* 418 */               return ColorPalette.this.customColorLink;
/*     */             }
/*     */           }));
/*     */   }
/*     */   
/*     */   private void processSelectKey(KeyEvent paramKeyEvent) {
/* 424 */     if (this.focusedSquare != null) this.focusedSquare.selectColor(paramKeyEvent); 
/*     */   }
/*     */   
/*     */   public void setPopupControl(PopupControl paramPopupControl) {
/* 428 */     this.popupControl = paramPopupControl;
/*     */   }
/*     */   
/*     */   public ColorPickerGrid getColorGrid() {
/* 432 */     return this.colorPickerGrid;
/*     */   }
/*     */   
/*     */   public boolean isCustomColorDialogShowing() {
/* 436 */     if (this.customColorDialog != null) return this.customColorDialog.isVisible(); 
/* 437 */     return false;
/*     */   }
/*     */   
/*     */   enum ColorType
/*     */   {
/* 442 */     NORMAL,
/* 443 */     STANDARD,
/* 444 */     CUSTOM;
/*     */   }
/*     */   
/*     */   class ColorSquare extends StackPane {
/*     */     Rectangle rectangle;
/*     */     int index;
/*     */     boolean isEmpty;
/* 451 */     ColorPalette.ColorType colorType = ColorPalette.ColorType.NORMAL;
/*     */     
/*     */     public ColorSquare() {
/* 454 */       this((Color)null, -1, ColorPalette.ColorType.NORMAL);
/*     */     }
/*     */     
/*     */     public ColorSquare(Color param1Color, int param1Int) {
/* 458 */       this(param1Color, param1Int, ColorPalette.ColorType.NORMAL);
/*     */     }
/*     */ 
/*     */     
/*     */     public ColorSquare(Color param1Color, int param1Int, ColorPalette.ColorType param1ColorType) {
/* 463 */       getStyleClass().add("color-square");
/* 464 */       if (param1Color != null) {
/* 465 */         setFocusTraversable(true);
/*     */         
/* 467 */         focusedProperty().addListener((param1ObservableValue, param1Boolean1, param1Boolean2) -> ColorPalette.this.setFocusedSquare(param1Boolean2.booleanValue() ? this : null));
/*     */ 
/*     */ 
/*     */         
/* 471 */         addEventHandler(MouseEvent.MOUSE_ENTERED, param1MouseEvent -> ColorPalette.this.setFocusedSquare(this));
/*     */ 
/*     */         
/* 474 */         addEventHandler(MouseEvent.MOUSE_EXITED, param1MouseEvent -> ColorPalette.this.setFocusedSquare((ColorSquare)null));
/*     */ 
/*     */ 
/*     */         
/* 478 */         addEventHandler(MouseEvent.MOUSE_RELEASED, param1MouseEvent -> {
/*     */               if (!ColorPalette.this.dragDetected && param1MouseEvent.getButton() == MouseButton.PRIMARY && param1MouseEvent.getClickCount() == 1) {
/*     */                 if (!this.isEmpty) {
/*     */                   Color color = (Color)this.rectangle.getFill();
/*     */                   
/*     */                   ColorPalette.this.colorPicker.setValue(color);
/*     */                   
/*     */                   ColorPalette.this.colorPicker.fireEvent(new ActionEvent());
/*     */                   
/*     */                   ColorPalette.this.updateSelection(color);
/*     */                   param1MouseEvent.consume();
/*     */                 } 
/*     */                 ColorPalette.this.colorPicker.hide();
/*     */               } else if ((param1MouseEvent.getButton() == MouseButton.SECONDARY || param1MouseEvent.getButton() == MouseButton.MIDDLE) && this.colorType == ColorPalette.ColorType.CUSTOM && ColorPalette.this.contextMenu != null) {
/*     */                 if (!ColorPalette.this.contextMenu.isShowing()) {
/*     */                   ColorPalette.this.contextMenu.show(this, Side.RIGHT, 0.0D, 0.0D);
/*     */                   Utils.addMnemonics(ColorPalette.this.contextMenu, getScene(), NodeHelper.isShowMnemonics(ColorPalette.this.colorPicker));
/*     */                 } else {
/*     */                   ColorPalette.this.contextMenu.hide();
/*     */                   Utils.removeMnemonics(ColorPalette.this.contextMenu, getScene());
/*     */                 } 
/*     */               } 
/*     */             });
/*     */       } 
/* 502 */       this.index = param1Int;
/* 503 */       this.colorType = param1ColorType;
/* 504 */       this.rectangle = new Rectangle(15.0D, 15.0D);
/* 505 */       if (param1Color == null) {
/* 506 */         this.rectangle.setFill(Color.WHITE);
/* 507 */         this.isEmpty = true;
/*     */       } else {
/* 509 */         this.rectangle.setFill(param1Color);
/*     */       } 
/*     */       
/* 512 */       this.rectangle.setStrokeType(StrokeType.INSIDE);
/*     */       
/* 514 */       String str = ColorPickerSkin.tooltipString(param1Color);
/* 515 */       Tooltip.install(this, new Tooltip((str == null) ? "" : str));
/*     */       
/* 517 */       this.rectangle.getStyleClass().add("color-rect");
/*     */       
/* 519 */       getChildren().add(this.rectangle);
/*     */     }
/*     */     
/*     */     public void selectColor(KeyEvent param1KeyEvent) {
/* 523 */       if (this.rectangle.getFill() != null) {
/* 524 */         if (this.rectangle.getFill() instanceof Color) {
/* 525 */           ColorPalette.this.colorPicker.setValue((Color)this.rectangle.getFill());
/* 526 */           ColorPalette.this.colorPicker.fireEvent(new ActionEvent());
/*     */         } 
/* 528 */         param1KeyEvent.consume();
/*     */       } 
/* 530 */       ColorPalette.this.colorPicker.hide();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateSelection(Color paramColor) {
/* 536 */     setFocusedSquare((ColorSquare)null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 541 */     List list = List.of(this.standardColorGrid, this.colorPickerGrid, this.customColorGrid);
/*     */ 
/*     */     
/* 544 */     for (GridPane gridPane : list) {
/* 545 */       ColorSquare colorSquare = findColorSquare(gridPane, paramColor);
/* 546 */       if (colorSquare != null) {
/* 547 */         setFocusedSquare(colorSquare);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private ColorSquare findColorSquare(GridPane paramGridPane, Color paramColor) {
/* 554 */     for (Node node : paramGridPane.getChildren()) {
/* 555 */       ColorSquare colorSquare = (ColorSquare)node;
/* 556 */       if (colorSquare.rectangle.getFill().equals(paramColor)) {
/* 557 */         return colorSquare;
/*     */       }
/*     */     } 
/* 560 */     return null;
/*     */   }
/*     */   
/*     */   class ColorPickerGrid
/*     */     extends GridPane {
/*     */     private final List<ColorPalette.ColorSquare> squares;
/*     */     
/*     */     public ColorPickerGrid() {
/* 568 */       getStyleClass().add("color-picker-grid");
/* 569 */       setId("ColorCustomizerColorGrid");
/* 570 */       byte b1 = 0, b2 = 0;
/* 571 */       this.squares = FXCollections.observableArrayList();
/* 572 */       int i = ColorPalette.RAW_VALUES.length / 3;
/* 573 */       Color[] arrayOfColor = new Color[i];
/* 574 */       for (byte b3 = 0; b3 < i; b3++) {
/* 575 */         arrayOfColor[b3] = new Color(ColorPalette.RAW_VALUES[b3 * 3] / 255.0D, ColorPalette
/* 576 */             .RAW_VALUES[b3 * 3 + 1] / 255.0D, ColorPalette.RAW_VALUES[b3 * 3 + 2] / 255.0D, 1.0D);
/*     */         
/* 578 */         ColorPalette.ColorSquare colorSquare = new ColorPalette.ColorSquare(arrayOfColor[b3], b3);
/* 579 */         this.squares.add(colorSquare);
/*     */       } 
/*     */       
/* 582 */       for (ColorPalette.ColorSquare colorSquare : this.squares) {
/* 583 */         add(colorSquare, b1, b2);
/* 584 */         b1++;
/* 585 */         if (b1 == 12) {
/* 586 */           b1 = 0;
/* 587 */           b2++;
/*     */         } 
/*     */       } 
/* 590 */       setOnMouseDragged(param1MouseEvent -> {
/*     */             if (!ColorPalette.this.dragDetected) {
/*     */               ColorPalette.this.dragDetected = true;
/*     */               
/*     */               ColorPalette.this.mouseDragColor = ColorPalette.this.colorPicker.getValue();
/*     */             } 
/*     */             
/*     */             int i = Utils.clamp(0, (int)param1MouseEvent.getX() / 16, 11);
/*     */             int j = Utils.clamp(0, (int)param1MouseEvent.getY() / 16, ColorPalette.NUM_OF_ROWS - 1);
/*     */             int k = i + j * 12;
/*     */             ColorPalette.this.colorPicker.setValue((Color)((ColorPalette.ColorSquare)this.squares.get(k)).rectangle.getFill());
/*     */             ColorPalette.this.updateSelection(ColorPalette.this.colorPicker.getValue());
/*     */           });
/* 603 */       addEventHandler(MouseEvent.MOUSE_RELEASED, param1MouseEvent -> {
/*     */             if (ColorPalette.this.colorPickerGrid.getBoundsInLocal().contains(param1MouseEvent.getX(), param1MouseEvent.getY())) {
/*     */               ColorPalette.this.updateSelection(ColorPalette.this.colorPicker.getValue());
/*     */               ColorPalette.this.colorPicker.fireEvent(new ActionEvent());
/*     */               ColorPalette.this.colorPicker.hide();
/*     */             } else if (ColorPalette.this.mouseDragColor != null) {
/*     */               ColorPalette.this.colorPicker.setValue(ColorPalette.this.mouseDragColor);
/*     */               ColorPalette.this.updateSelection(ColorPalette.this.mouseDragColor);
/*     */             } 
/*     */             ColorPalette.this.dragDetected = false;
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<ColorPalette.ColorSquare> getSquares() {
/* 620 */       return this.squares;
/*     */     }
/*     */     
/*     */     protected double computePrefWidth(double param1Double) {
/* 624 */       return 192.0D;
/*     */     }
/*     */     
/*     */     protected double computePrefHeight(double param1Double) {
/* 628 */       return (16 * ColorPalette.NUM_OF_ROWS);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 633 */   private static double[] RAW_VALUES = new double[] { 255.0D, 255.0D, 255.0D, 242.0D, 242.0D, 242.0D, 230.0D, 230.0D, 230.0D, 204.0D, 204.0D, 204.0D, 179.0D, 179.0D, 179.0D, 153.0D, 153.0D, 153.0D, 128.0D, 128.0D, 128.0D, 102.0D, 102.0D, 102.0D, 77.0D, 77.0D, 77.0D, 51.0D, 51.0D, 51.0D, 26.0D, 26.0D, 26.0D, 0.0D, 0.0D, 0.0D, 0.0D, 51.0D, 51.0D, 0.0D, 26.0D, 128.0D, 26.0D, 0.0D, 104.0D, 51.0D, 0.0D, 51.0D, 77.0D, 0.0D, 26.0D, 153.0D, 0.0D, 0.0D, 153.0D, 51.0D, 0.0D, 153.0D, 77.0D, 0.0D, 153.0D, 102.0D, 0.0D, 153.0D, 153.0D, 0.0D, 102.0D, 102.0D, 0.0D, 0.0D, 51.0D, 0.0D, 26.0D, 77.0D, 77.0D, 26.0D, 51.0D, 153.0D, 51.0D, 26.0D, 128.0D, 77.0D, 26.0D, 77.0D, 102.0D, 26.0D, 51.0D, 179.0D, 26.0D, 26.0D, 179.0D, 77.0D, 26.0D, 179.0D, 102.0D, 26.0D, 179.0D, 128.0D, 26.0D, 179.0D, 179.0D, 26.0D, 128.0D, 128.0D, 26.0D, 26.0D, 77.0D, 26.0D, 51.0D, 102.0D, 102.0D, 51.0D, 77.0D, 179.0D, 77.0D, 51.0D, 153.0D, 102.0D, 51.0D, 102.0D, 128.0D, 51.0D, 77.0D, 204.0D, 51.0D, 51.0D, 204.0D, 102.0D, 51.0D, 204.0D, 128.0D, 51.0D, 204.0D, 153.0D, 51.0D, 204.0D, 204.0D, 51.0D, 153.0D, 153.0D, 51.0D, 51.0D, 102.0D, 51.0D, 77.0D, 128.0D, 128.0D, 77.0D, 102.0D, 204.0D, 102.0D, 77.0D, 179.0D, 128.0D, 77.0D, 128.0D, 153.0D, 77.0D, 102.0D, 230.0D, 77.0D, 77.0D, 230.0D, 128.0D, 77.0D, 230.0D, 153.0D, 77.0D, 230.0D, 179.0D, 77.0D, 230.0D, 230.0D, 77.0D, 179.0D, 179.0D, 77.0D, 77.0D, 128.0D, 77.0D, 102.0D, 153.0D, 153.0D, 102.0D, 128.0D, 230.0D, 128.0D, 102.0D, 204.0D, 153.0D, 102.0D, 153.0D, 179.0D, 102.0D, 128.0D, 255.0D, 102.0D, 102.0D, 255.0D, 153.0D, 102.0D, 255.0D, 179.0D, 102.0D, 255.0D, 204.0D, 102.0D, 255.0D, 255.0D, 77.0D, 204.0D, 204.0D, 102.0D, 102.0D, 153.0D, 102.0D, 128.0D, 179.0D, 179.0D, 128.0D, 153.0D, 255.0D, 153.0D, 128.0D, 230.0D, 179.0D, 128.0D, 179.0D, 204.0D, 128.0D, 153.0D, 255.0D, 128.0D, 128.0D, 255.0D, 153.0D, 128.0D, 255.0D, 204.0D, 128.0D, 255.0D, 230.0D, 102.0D, 255.0D, 255.0D, 102.0D, 230.0D, 230.0D, 128.0D, 128.0D, 179.0D, 128.0D, 153.0D, 204.0D, 204.0D, 153.0D, 179.0D, 255.0D, 179.0D, 153.0D, 255.0D, 204.0D, 153.0D, 204.0D, 230.0D, 153.0D, 179.0D, 255.0D, 153.0D, 153.0D, 255.0D, 179.0D, 128.0D, 255.0D, 204.0D, 153.0D, 255.0D, 230.0D, 128.0D, 255.0D, 255.0D, 128.0D, 230.0D, 230.0D, 153.0D, 153.0D, 204.0D, 153.0D, 179.0D, 230.0D, 230.0D, 179.0D, 204.0D, 255.0D, 204.0D, 179.0D, 255.0D, 230.0D, 179.0D, 230.0D, 230.0D, 179.0D, 204.0D, 255.0D, 179.0D, 179.0D, 255.0D, 179.0D, 153.0D, 255.0D, 230.0D, 179.0D, 255.0D, 230.0D, 153.0D, 255.0D, 255.0D, 153.0D, 230.0D, 230.0D, 179.0D, 179.0D, 230.0D, 179.0D, 204.0D, 255.0D, 255.0D, 204.0D, 230.0D, 255.0D, 230.0D, 204.0D, 255.0D, 255.0D, 204.0D, 255.0D, 255.0D, 204.0D, 230.0D, 255.0D, 204.0D, 204.0D, 255.0D, 204.0D, 179.0D, 255.0D, 230.0D, 204.0D, 255.0D, 255.0D, 179.0D, 255.0D, 255.0D, 204.0D, 230.0D, 230.0D, 204.0D, 204.0D, 255.0D, 204.0D };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 757 */   private static final int NUM_OF_COLORS = RAW_VALUES.length / 3;
/* 758 */   private static final int NUM_OF_ROWS = NUM_OF_COLORS / 12;
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ColorPalette.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */