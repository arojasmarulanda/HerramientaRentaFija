/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.ToggleButtonBehavior;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.RadioButton;
/*     */ import javafx.scene.layout.StackPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RadioButtonSkin
/*     */   extends LabeledSkinBase<RadioButton>
/*     */ {
/*     */   private StackPane radio;
/*     */   private final BehaviorBase<RadioButton> behavior;
/*     */   
/*     */   public RadioButtonSkin(RadioButton paramRadioButton) {
/*  72 */     super(paramRadioButton);
/*     */ 
/*     */     
/*  75 */     this.behavior = new ToggleButtonBehavior<>(paramRadioButton);
/*     */ 
/*     */     
/*  78 */     this.radio = createRadio();
/*  79 */     updateChildren();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  92 */     super.dispose();
/*     */     
/*  94 */     if (this.behavior != null) {
/*  95 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateChildren() {
/* 101 */     super.updateChildren();
/* 102 */     if (this.radio != null) {
/* 103 */       getChildren().add(this.radio);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 109 */     return super.computeMinWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5) + snapSizeX(this.radio.minWidth(-1.0D));
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 114 */     return Math.max(snapSizeY(super.computeMinHeight(paramDouble1 - this.radio.minWidth(-1.0D), paramDouble2, paramDouble3, paramDouble4, paramDouble5)), paramDouble2 + this.radio
/* 115 */         .minHeight(-1.0D) + paramDouble4);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 120 */     return super.computePrefWidth(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5) + snapSizeX(this.radio.prefWidth(-1.0D));
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 125 */     return Math.max(snapSizeY(super.computePrefHeight(paramDouble1 - this.radio.prefWidth(-1.0D), paramDouble2, paramDouble3, paramDouble4, paramDouble5)), paramDouble2 + this.radio
/* 126 */         .prefHeight(-1.0D) + paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 132 */     RadioButton radioButton = getSkinnable();
/* 133 */     double d1 = this.radio.prefWidth(-1.0D);
/* 134 */     double d2 = this.radio.prefHeight(-1.0D);
/* 135 */     double d3 = Math.max(radioButton.prefWidth(-1.0D), radioButton.minWidth(-1.0D));
/* 136 */     double d4 = Math.min(d3 - d1, paramDouble3 - snapSizeX(d1));
/* 137 */     double d5 = Math.min(radioButton.prefHeight(d4), paramDouble4);
/* 138 */     double d6 = Math.max(d2, d5);
/* 139 */     double d7 = Utils.computeXOffset(paramDouble3, d4 + d1, radioButton.getAlignment().getHpos()) + paramDouble1;
/* 140 */     double d8 = Utils.computeYOffset(paramDouble4, d6, radioButton.getAlignment().getVpos()) + paramDouble2;
/*     */     
/* 142 */     layoutLabelInArea(d7 + d1, d8, d4, d6, radioButton.getAlignment());
/* 143 */     this.radio.resize(snapSizeX(d1), snapSizeY(d2));
/* 144 */     positionInArea(this.radio, d7, d8, d1, d6, 0.0D, radioButton.getAlignment().getHpos(), radioButton.getAlignment().getVpos());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static StackPane createRadio() {
/* 156 */     StackPane stackPane1 = new StackPane();
/* 157 */     stackPane1.getStyleClass().setAll(new String[] { "radio" });
/* 158 */     stackPane1.setSnapToPixel(false);
/* 159 */     StackPane stackPane2 = new StackPane();
/* 160 */     stackPane2.getStyleClass().setAll(new String[] { "dot" });
/* 161 */     stackPane1.getChildren().clear();
/* 162 */     stackPane1.getChildren().addAll(new Node[] { stackPane2 });
/* 163 */     return stackPane1;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\RadioButtonSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */