/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.ContextMenuContent;
/*     */ import com.sun.javafx.scene.control.behavior.MenuButtonBehavior;
/*     */ import com.sun.javafx.scene.control.behavior.MenuButtonBehaviorBase;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.control.MenuButton;
/*     */ import javafx.stage.WindowEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MenuButtonSkin
/*     */   extends MenuButtonSkinBase<MenuButton>
/*     */ {
/*     */   static final String AUTOHIDE = "autoHide";
/*     */   private final MenuButtonBehavior behavior;
/*     */   
/*     */   public MenuButtonSkin(MenuButton paramMenuButton) {
/*  77 */     super(paramMenuButton);
/*     */ 
/*     */     
/*  80 */     this.behavior = new MenuButtonBehavior(paramMenuButton);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     this.popup.setOnAutoHide(paramEvent -> {
/*     */           MenuButton menuButton = getSkinnable();
/*     */ 
/*     */           
/*     */           if (!menuButton.getProperties().containsKey("autoHide")) {
/*     */             menuButton.getProperties().put("autoHide", Boolean.TRUE);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*  96 */     this.popup.setOnShown(paramWindowEvent -> {
/*     */           if (this.requestFocusOnFirstMenuItem) {
/*     */             requestFocusOnFirstMenuItem();
/*     */             
/*     */             this.requestFocusOnFirstMenuItem = false;
/*     */           } else {
/*     */             ContextMenuContent contextMenuContent = (ContextMenuContent)this.popup.getSkin().getNode();
/*     */             if (contextMenuContent != null) {
/*     */               contextMenuContent.requestFocus();
/*     */             }
/*     */           } 
/*     */         });
/* 108 */     if (paramMenuButton.getOnAction() == null) {
/* 109 */       paramMenuButton.setOnAction(paramActionEvent -> paramMenuButton.show());
/*     */     }
/*     */     
/* 112 */     this.label.setLabelFor(paramMenuButton);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 125 */     super.dispose();
/*     */     
/* 127 */     if (this.behavior != null) {
/* 128 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MenuButtonBehavior getBehavior() {
/* 141 */     return this.behavior;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 155 */     switch (paramAccessibleAttribute) { case MNEMONIC:
/* 156 */         return this.label.queryAccessibleAttribute(AccessibleAttribute.MNEMONIC, new Object[0]); }
/* 157 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\MenuButtonSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */