/*      */ package javafx.scene.control.skin;
/*      */ 
/*      */ import com.sun.javafx.scene.control.LambdaMultiplePropertyChangeListenerHandler;
/*      */ import com.sun.javafx.scene.control.Properties;
/*      */ import com.sun.javafx.scene.control.TabObservableList;
/*      */ import com.sun.javafx.scene.control.behavior.TabPaneBehavior;
/*      */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*      */ import com.sun.javafx.util.Utils;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import javafx.animation.Animation;
/*      */ import javafx.animation.Interpolator;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.KeyValue;
/*      */ import javafx.animation.Timeline;
/*      */ import javafx.animation.Transition;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.WeakInvalidationListener;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.SimpleDoubleProperty;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.collections.WeakListChangeListener;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.EnumConverter;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.geometry.Bounds;
/*      */ import javafx.geometry.HPos;
/*      */ import javafx.geometry.Point2D;
/*      */ import javafx.geometry.Pos;
/*      */ import javafx.geometry.Side;
/*      */ import javafx.geometry.VPos;
/*      */ import javafx.scene.AccessibleAction;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.ContextMenu;
/*      */ import javafx.scene.control.Label;
/*      */ import javafx.scene.control.MenuItem;
/*      */ import javafx.scene.control.RadioMenuItem;
/*      */ import javafx.scene.control.SkinBase;
/*      */ import javafx.scene.control.Tab;
/*      */ import javafx.scene.control.TabPane;
/*      */ import javafx.scene.control.ToggleGroup;
/*      */ import javafx.scene.control.Tooltip;
/*      */ import javafx.scene.effect.DropShadow;
/*      */ import javafx.scene.image.ImageView;
/*      */ import javafx.scene.input.ContextMenuEvent;
/*      */ import javafx.scene.input.MouseButton;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.input.ScrollEvent;
/*      */ import javafx.scene.input.SwipeEvent;
/*      */ import javafx.scene.layout.Pane;
/*      */ import javafx.scene.layout.Region;
/*      */ import javafx.scene.layout.StackPane;
/*      */ import javafx.scene.shape.Rectangle;
/*      */ import javafx.scene.transform.Rotate;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TabPaneSkin
/*      */   extends SkinBase<TabPane>
/*      */ {
/*      */   private enum TabAnimation
/*      */   {
/*  118 */     NONE,
/*  119 */     GROW;
/*      */   }
/*      */   
/*      */   private enum TabAnimationState
/*      */   {
/*  124 */     SHOWING, HIDING, NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   static int CLOSE_BTN_SIZE = 16;
/*      */ 
/*      */   
/*      */   private static final double ANIMATION_SPEED = 150.0D;
/*      */ 
/*      */   
/*      */   private static final int SPACER = 10;
/*      */ 
/*      */   
/*      */   private TabHeaderArea tabHeaderArea;
/*      */ 
/*      */   
/*      */   private ObservableList<TabContentRegion> tabContentRegions;
/*      */ 
/*      */   
/*      */   private Rectangle clipRect;
/*      */ 
/*      */   
/*      */   private Rectangle tabHeaderAreaClipRect;
/*      */ 
/*      */   
/*      */   private Tab selectedTab;
/*      */ 
/*      */   
/*      */   private boolean isSelectingTab;
/*      */ 
/*      */   
/*      */   private final TabPaneBehavior behavior;
/*      */ 
/*      */   
/*      */   private ObjectProperty<TabAnimation> openTabAnimation;
/*      */ 
/*      */   
/*      */   private ObjectProperty<TabAnimation> closeTabAnimation;
/*      */ 
/*      */ 
/*      */   
/*      */   public TabPaneSkin(TabPane paramTabPane) {
/*  173 */     super(paramTabPane);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  231 */     this.openTabAnimation = new StyleableObjectProperty<TabAnimation>(TabAnimation.GROW) {
/*      */         public CssMetaData<TabPane, TabPaneSkin.TabAnimation> getCssMetaData() {
/*  233 */           return TabPaneSkin.StyleableProperties.OPEN_TAB_ANIMATION;
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  237 */           return TabPaneSkin.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  241 */           return "openTabAnimation";
/*      */         }
/*      */       };
/*      */     
/*  245 */     this.closeTabAnimation = new StyleableObjectProperty<TabAnimation>(TabAnimation.GROW) {
/*      */         public CssMetaData<TabPane, TabPaneSkin.TabAnimation> getCssMetaData() {
/*  247 */           return TabPaneSkin.StyleableProperties.CLOSE_TAB_ANIMATION;
/*      */         }
/*      */         
/*      */         public Object getBean() {
/*  251 */           return TabPaneSkin.this;
/*      */         }
/*      */         
/*      */         public String getName() {
/*  255 */           return "closeTabAnimation";
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1908 */     this.headerDraggedHandler = this::handleHeaderDragged;
/* 1909 */     this.headerMousePressedHandler = this::handleHeaderMousePressed;
/* 1910 */     this.headerMouseReleasedHandler = this::handleHeaderMouseReleased;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1917 */     this.MIN_TO_MAX = 1;
/* 1918 */     this.MAX_TO_MIN = -1;
/*      */ 
/*      */     
/* 1921 */     this.prevDragDirection = 1;
/* 1922 */     this.DRAG_DIST_THRESHOLD = 0.75D;
/*      */ 
/*      */     
/* 1925 */     this.ANIM_DURATION = 120.0D;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1930 */     this.dropHeaderAnim = new Transition()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected void interpolate(double param1Double)
/*      */         {
/* 1939 */           TabPaneSkin.this.dropAnimHeader.setLayoutX(TabPaneSkin.this.dropHeaderSourceX + TabPaneSkin.this.dropHeaderTransitionX * param1Double);
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1946 */     this.dragHeaderAnim = new Transition()
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected void interpolate(double param1Double)
/*      */         {
/* 1955 */           TabPaneSkin.this.dragTabHeader.setLayoutX(TabPaneSkin.this.dragHeaderSourceX + TabPaneSkin.this.dragHeaderTransitionX * param1Double);
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1972 */     this.childListener = new ListChangeListener<Node>()
/*      */       {
/* 1974 */         public void onChanged(ListChangeListener.Change<? extends Node> param1Change) { while (param1Change.next())
/* 1975 */           { if (param1Change.wasAdded()) {
/* 1976 */               for (Node node : param1Change.getAddedSubList()) {
/* 1977 */                 TabPaneSkin.this.addReorderListeners(node);
/*      */               }
/*      */             }
/* 1980 */             if (param1Change.wasRemoved())
/* 1981 */               for (Node node : param1Change.getRemoved())
/* 1982 */                 TabPaneSkin.this.removeReorderListeners(node);   }  }
/*      */       }; this.behavior = new TabPaneBehavior(paramTabPane); this.clipRect = new Rectangle(paramTabPane.getWidth(), paramTabPane.getHeight()); getSkinnable().setClip(this.clipRect); this.tabContentRegions = FXCollections.observableArrayList(); for (Tab tab : getSkinnable().getTabs()) addTabContent(tab);  this.tabHeaderAreaClipRect = new Rectangle(); this.tabHeaderArea = new TabHeaderArea(); this.tabHeaderArea.setClip(this.tabHeaderAreaClipRect); getChildren().add(this.tabHeaderArea); if (getSkinnable().getTabs().size() == 0) this.tabHeaderArea.setVisible(false);  initializeTabListener(); registerChangeListener(paramTabPane.getSelectionModel().selectedItemProperty(), paramObservableValue -> { this.isSelectingTab = true; this.selectedTab = getSkinnable().getSelectionModel().getSelectedItem(); getSkinnable().requestLayout(); }); registerChangeListener(paramTabPane.sideProperty(), paramObservableValue -> updateTabPosition()); registerChangeListener(paramTabPane.widthProperty(), paramObservableValue -> this.clipRect.setWidth(getSkinnable().getWidth())); registerChangeListener(paramTabPane.heightProperty(), paramObservableValue -> this.clipRect.setHeight(getSkinnable().getHeight())); this.selectedTab = getSkinnable().getSelectionModel().getSelectedItem(); if (this.selectedTab == null && getSkinnable().getSelectionModel().getSelectedIndex() != -1) { getSkinnable().getSelectionModel().select(getSkinnable().getSelectionModel().getSelectedIndex()); this.selectedTab = getSkinnable().getSelectionModel().getSelectedItem(); }  if (this.selectedTab == null) getSkinnable().getSelectionModel().selectFirst();  this.selectedTab = getSkinnable().getSelectionModel().getSelectedItem(); this.isSelectingTab = false; initializeSwipeHandlers();
/*      */   } public void dispose() { super.dispose(); if (this.behavior != null) this.behavior.dispose();  } protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { double d1 = 0.0D; for (TabContentRegion tabContentRegion : this.tabContentRegions) d1 = Math.max(d1, snapSizeX(tabContentRegion.prefWidth(-1.0D)));  boolean bool = isHorizontal(); double d2 = bool ? snapSizeX(this.tabHeaderArea.prefWidth(-1.0D)) : snapSizeY(this.tabHeaderArea.prefHeight(-1.0D)); double d3 = bool ? Math.max(d1, d2) : (d1 + d2); return snapSizeX(d3) + paramDouble3 + paramDouble5; } protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { double d1 = 0.0D; for (TabContentRegion tabContentRegion : this.tabContentRegions) d1 = Math.max(d1, snapSizeY(tabContentRegion.prefHeight(-1.0D)));  boolean bool = isHorizontal(); double d2 = bool ? snapSizeY(this.tabHeaderArea.prefHeight(-1.0D)) : snapSizeX(this.tabHeaderArea.prefWidth(-1.0D)); double d3 = bool ? (d1 + snapSizeY(d2)) : Math.max(d1, d2); return snapSizeY(d3) + paramDouble2 + paramDouble4; } public double computeBaselineOffset(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { Side side = getSkinnable().getSide(); if (side == Side.TOP) return this.tabHeaderArea.getBaselineOffset() + paramDouble1;  return 0.0D; } protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { TabPane tabPane = getSkinnable(); Side side = tabPane.getSide(); double d1 = side.isHorizontal() ? snapSizeY(this.tabHeaderArea.prefHeight(-1.0D)) : snapSizeX(this.tabHeaderArea.prefHeight(-1.0D)); double d2 = side.equals(Side.RIGHT) ? (paramDouble1 + paramDouble3 - d1) : paramDouble1; double d3 = side.equals(Side.BOTTOM) ? (paramDouble2 + paramDouble4 - d1) : paramDouble2; double d4 = snappedLeftInset(); double d5 = snappedTopInset(); if (side == Side.TOP) { this.tabHeaderArea.resize(paramDouble3, d1); this.tabHeaderArea.relocate(d2, d3); this.tabHeaderArea.getTransforms().clear(); this.tabHeaderArea.getTransforms().add(new Rotate(getRotation(Side.TOP))); } else if (side == Side.BOTTOM) { this.tabHeaderArea.resize(paramDouble3, d1); this.tabHeaderArea.relocate(paramDouble3 + d4, d3 - d1); this.tabHeaderArea.getTransforms().clear(); this.tabHeaderArea.getTransforms().add(new Rotate(getRotation(Side.BOTTOM), 0.0D, d1)); } else if (side == Side.LEFT) { this.tabHeaderArea.resize(paramDouble4, d1); this.tabHeaderArea.relocate(d2 + d1, paramDouble4 - d1 + d5); this.tabHeaderArea.getTransforms().clear(); this.tabHeaderArea.getTransforms().add(new Rotate(getRotation(Side.LEFT), 0.0D, d1)); } else if (side == Side.RIGHT) { this.tabHeaderArea.resize(paramDouble4, d1); this.tabHeaderArea.relocate(d2, paramDouble2 - d1); this.tabHeaderArea.getTransforms().clear(); this.tabHeaderArea.getTransforms().add(new Rotate(getRotation(Side.RIGHT), 0.0D, d1)); }  this.tabHeaderAreaClipRect.setX(0.0D); this.tabHeaderAreaClipRect.setY(0.0D); if (isHorizontal()) { this.tabHeaderAreaClipRect.setWidth(paramDouble3); } else { this.tabHeaderAreaClipRect.setWidth(paramDouble4); }  this.tabHeaderAreaClipRect.setHeight(d1); double d6 = 0.0D; double d7 = 0.0D; if (side == Side.TOP) { d6 = paramDouble1; d7 = paramDouble2 + d1; if (isFloatingStyleClass()) d7--;  } else if (side == Side.BOTTOM) { d6 = paramDouble1; d7 = paramDouble2 + d5; if (isFloatingStyleClass()) d7 = 1.0D + d5;  } else if (side == Side.LEFT) { d6 = paramDouble1 + d1; d7 = paramDouble2; if (isFloatingStyleClass()) d6--;  } else if (side == Side.RIGHT) { d6 = paramDouble1 + d4; d7 = paramDouble2; if (isFloatingStyleClass()) d6 = 1.0D + d4;  }  double d8 = paramDouble3 - (isHorizontal() ? 0.0D : d1); double d9 = paramDouble4 - (isHorizontal() ? d1 : 0.0D); byte b; int i; for (b = 0, i = this.tabContentRegions.size(); b < i; b++) { TabContentRegion tabContentRegion = this.tabContentRegions.get(b); tabContentRegion.setAlignment(Pos.TOP_LEFT); if (tabContentRegion.getClip() != null) { ((Rectangle)tabContentRegion.getClip()).setWidth(d8); ((Rectangle)tabContentRegion.getClip()).setHeight(d9); }  tabContentRegion.resize(d8, d9); tabContentRegion.relocate(d6, d7); }  } private static int getRotation(Side paramSide) { switch (paramSide) { case TEXT: return 0;case SELECTED: return 180;case FOCUS_ITEM: return -90;case ITEM_COUNT: return 90; }  return 0; } private static Node clone(Node paramNode) { if (paramNode == null) return null;  if (paramNode instanceof ImageView) { ImageView imageView1 = (ImageView)paramNode; ImageView imageView2 = new ImageView(); imageView2.imageProperty().bind(imageView1.imageProperty()); return imageView2; }  if (paramNode instanceof Label) { Label label1 = (Label)paramNode; Label label2 = new Label(label1.getText(), clone(label1.getGraphic())); label2.textProperty().bind(label1.textProperty()); return label2; }  return null; } private void removeTabs(List<? extends Tab> paramList) { for (Iterator<? extends Tab> iterator = paramList.iterator(); iterator.hasNext(); ) { Tab tab = iterator.next(); stopCurrentAnimation(tab); TabHeaderSkin tabHeaderSkin = this.tabHeaderArea.getTabHeaderSkin(tab); if (tabHeaderSkin != null) { tabHeaderSkin.isClosing = true; tabHeaderSkin.removeListeners(tab); removeTabContent(tab); EventHandler<ActionEvent> eventHandler = paramActionEvent -> { paramTabHeaderSkin.animationState = TabAnimationState.NONE; this.tabHeaderArea.removeTab(paramTab); this.tabHeaderArea.requestLayout(); if (getSkinnable().getTabs().isEmpty()) this.tabHeaderArea.setVisible(false);  }; if (this.closeTabAnimation.get() == TabAnimation.GROW) { tabHeaderSkin.animationState = TabAnimationState.HIDING; Timeline timeline = tabHeaderSkin.currentAnimation = createTimeline(tabHeaderSkin, Duration.millis(150.0D), 0.0D, eventHandler); timeline.play(); continue; }  eventHandler.handle(null); }  }  } private void stopCurrentAnimation(Tab paramTab) { TabHeaderSkin tabHeaderSkin = this.tabHeaderArea.getTabHeaderSkin(paramTab); if (tabHeaderSkin != null) { Timeline timeline = tabHeaderSkin.currentAnimation; if (timeline != null && timeline.getStatus() == Animation.Status.RUNNING) { timeline.getOnFinished().handle(null); timeline.stop(); tabHeaderSkin.currentAnimation = null; }  }  } private void addTabs(List<? extends Tab> paramList, int paramInt) { byte b = 0; ArrayList<Node> arrayList = new ArrayList<>(this.tabHeaderArea.headersRegion.getChildren()); for (Node node : arrayList) { TabHeaderSkin tabHeaderSkin = (TabHeaderSkin)node; if (tabHeaderSkin.animationState == TabAnimationState.HIDING) stopCurrentAnimation(tabHeaderSkin.tab);  }  for (Tab tab : paramList) { stopCurrentAnimation(tab); if (!this.tabHeaderArea.isVisible()) this.tabHeaderArea.setVisible(true);  int i = paramInt + b++; this.tabHeaderArea.addTab(tab, i); addTabContent(tab); TabHeaderSkin tabHeaderSkin = this.tabHeaderArea.getTabHeaderSkin(tab); if (tabHeaderSkin != null) { if (this.openTabAnimation.get() == TabAnimation.GROW) { tabHeaderSkin.animationState = TabAnimationState.SHOWING; tabHeaderSkin.animationTransition.setValue(Double.valueOf(0.0D)); tabHeaderSkin.setVisible(true); tabHeaderSkin.currentAnimation = createTimeline(tabHeaderSkin, Duration.millis(150.0D), 1.0D, paramActionEvent -> { paramTabHeaderSkin.animationState = TabAnimationState.NONE; paramTabHeaderSkin.setVisible(true); paramTabHeaderSkin.inner.requestLayout(); }); tabHeaderSkin.currentAnimation.play(); continue; }  tabHeaderSkin.setVisible(true); tabHeaderSkin.inner.requestLayout(); }  }  } private void initializeTabListener() { getSkinnable().getTabs().addListener(paramChange -> { ArrayList<? extends Tab> arrayList = new ArrayList(); ArrayList<?> arrayList1 = new ArrayList(); int i = -1; while (paramChange.next()) { if (paramChange.wasPermutated() && this.dragState != DragState.REORDER) { TabPane tabPane = getSkinnable(); ObservableList<Tab> observableList = tabPane.getTabs(); int j = paramChange.getTo() - paramChange.getFrom(); Tab tab = tabPane.getSelectionModel().getSelectedItem(); ArrayList<Tab> arrayList2 = new ArrayList(j); getSkinnable().getSelectionModel().clearSelection(); TabAnimation tabAnimation1 = this.openTabAnimation.get(); TabAnimation tabAnimation2 = this.closeTabAnimation.get(); this.openTabAnimation.set(TabAnimation.NONE); this.closeTabAnimation.set(TabAnimation.NONE); for (int k = paramChange.getFrom(); k < paramChange.getTo(); k++) arrayList2.add(observableList.get(k));  removeTabs(arrayList2); addTabs(arrayList2, paramChange.getFrom()); this.openTabAnimation.set(tabAnimation1); this.closeTabAnimation.set(tabAnimation2); getSkinnable().getSelectionModel().select(tab); }  if (paramChange.wasRemoved()) arrayList.addAll(paramChange.getRemoved());  if (paramChange.wasAdded()) { arrayList1.addAll(paramChange.getAddedSubList()); i = paramChange.getFrom(); }  }  arrayList.removeAll(arrayList1); removeTabs(arrayList); if (!arrayList1.isEmpty()) { for (TabContentRegion tabContentRegion : this.tabContentRegions) { Tab tab = tabContentRegion.getTab(); TabHeaderSkin tabHeaderSkin = this.tabHeaderArea.getTabHeaderSkin(tab); if (!tabHeaderSkin.isClosing && arrayList1.contains(tabContentRegion.getTab())) arrayList1.remove(tabContentRegion.getTab());  }  addTabs((List)arrayList1, (i == -1) ? this.tabContentRegions.size() : i); }  getSkinnable().requestLayout(); }); } private void addTabContent(Tab paramTab) { TabContentRegion tabContentRegion = new TabContentRegion(paramTab); tabContentRegion.setClip(new Rectangle()); this.tabContentRegions.add(tabContentRegion); getChildren().add(0, tabContentRegion); } private void removeTabContent(Tab paramTab) { for (TabContentRegion tabContentRegion : this.tabContentRegions) { if (tabContentRegion.getTab().equals(paramTab)) { tabContentRegion.removeListeners(paramTab); getChildren().remove(tabContentRegion); this.tabContentRegions.remove(tabContentRegion); break; }  }  } private void updateTabPosition() { this.tabHeaderArea.setScrollOffset(0.0D); getSkinnable().applyCss(); getSkinnable().requestLayout(); } private Timeline createTimeline(TabHeaderSkin paramTabHeaderSkin, Duration paramDuration, double paramDouble, EventHandler<ActionEvent> paramEventHandler) { Timeline timeline = new Timeline(); timeline.setCycleCount(1); KeyValue keyValue = new KeyValue(paramTabHeaderSkin.animationTransition, (T)Double.valueOf(paramDouble), Interpolator.LINEAR); timeline.getKeyFrames().clear(); timeline.getKeyFrames().add(new KeyFrame(paramDuration, new KeyValue[] { keyValue })); timeline.setOnFinished(paramEventHandler); return timeline; } private boolean isHorizontal() { Side side = getSkinnable().getSide(); return (Side.TOP.equals(side) || Side.BOTTOM.equals(side)); } private void initializeSwipeHandlers() { if (Properties.IS_TOUCH_SUPPORTED) { getSkinnable().addEventHandler(SwipeEvent.SWIPE_LEFT, paramSwipeEvent -> this.behavior.selectNextTab()); getSkinnable().addEventHandler(SwipeEvent.SWIPE_RIGHT, paramSwipeEvent -> this.behavior.selectPreviousTab()); }  } private boolean isFloatingStyleClass() { return getSkinnable().getStyleClass().contains("floating"); } private static class StyleableProperties {
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES; private static final CssMetaData<TabPane, TabPaneSkin.TabAnimation> OPEN_TAB_ANIMATION = new CssMetaData<TabPane, TabPaneSkin.TabAnimation>("-fx-open-tab-animation", (StyleConverter)new EnumConverter(TabPaneSkin.TabAnimation.class), TabPaneSkin.TabAnimation.GROW) { public boolean isSettable(TabPane param2TabPane) { return true; } public StyleableProperty<TabPaneSkin.TabAnimation> getStyleableProperty(TabPane param2TabPane) { TabPaneSkin tabPaneSkin = (TabPaneSkin)param2TabPane.getSkin(); return (StyleableProperty<TabPaneSkin.TabAnimation>)tabPaneSkin.openTabAnimation; } }
/*      */     ; private static final CssMetaData<TabPane, TabPaneSkin.TabAnimation> CLOSE_TAB_ANIMATION = new CssMetaData<TabPane, TabPaneSkin.TabAnimation>("-fx-close-tab-animation", (StyleConverter)new EnumConverter(TabPaneSkin.TabAnimation.class), TabPaneSkin.TabAnimation.GROW) { public boolean isSettable(TabPane param2TabPane) { return true; } public StyleableProperty<TabPaneSkin.TabAnimation> getStyleableProperty(TabPane param2TabPane) { TabPaneSkin tabPaneSkin = (TabPaneSkin)param2TabPane.getSkin(); return (StyleableProperty<TabPaneSkin.TabAnimation>)tabPaneSkin.closeTabAnimation; } }
/*      */     ; static { ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(SkinBase.getClassCssMetaData()); arrayList.add(OPEN_TAB_ANIMATION); arrayList.add(CLOSE_TAB_ANIMATION); STYLEABLES = Collections.unmodifiableList(arrayList); } } public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() { return StyleableProperties.STYLEABLES; } public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() { return getClassCssMetaData(); } class TabHeaderArea extends StackPane {
/*      */     private Rectangle headerClip; private StackPane headersRegion; private StackPane headerBackground; private TabPaneSkin.TabControlButtons controlButtons; private boolean measureClosingTabs = false; private double scrollOffset; public TabHeaderArea() { getStyleClass().setAll(new String[] { "tab-header-area" }); setManaged(false); TabPane tabPane = TabPaneSkin.this.getSkinnable(); this.headerClip = new Rectangle(); this.headersRegion = new StackPane() { protected double computePrefWidth(double param2Double) { double d = 0.0D; for (Node node : getChildren()) { TabPaneSkin.TabHeaderSkin tabHeaderSkin = (TabPaneSkin.TabHeaderSkin)node; if (tabHeaderSkin.isVisible() && (TabPaneSkin.TabHeaderArea.this.measureClosingTabs || !tabHeaderSkin.isClosing)) d += tabHeaderSkin.prefWidth(param2Double);  }  return snapSize(d) + snappedLeftInset() + snappedRightInset(); } protected double computePrefHeight(double param2Double) { double d = 0.0D; for (Node node : getChildren()) { TabPaneSkin.TabHeaderSkin tabHeaderSkin = (TabPaneSkin.TabHeaderSkin)node; d = Math.max(d, tabHeaderSkin.prefHeight(param2Double)); }  return snapSize(d) + snappedTopInset() + snappedBottomInset(); } protected void layoutChildren() { if (TabPaneSkin.TabHeaderArea.this.tabsFit()) { TabPaneSkin.TabHeaderArea.this.setScrollOffset(0.0D); } else if (TabPaneSkin.this.isSelectingTab) { TabPaneSkin.TabHeaderArea.this.ensureSelectedTabIsVisible(); } else { TabPaneSkin.TabHeaderArea.this.validateScrollOffset(); }  TabPaneSkin.this.isSelectingTab = false; Side side = TabPaneSkin.this.getSkinnable().getSide(); double d1 = snapSize(prefHeight(-1.0D)); double d2 = (side.equals(Side.LEFT) || side.equals(Side.BOTTOM)) ? (snapSize(getWidth()) - TabPaneSkin.TabHeaderArea.this.getScrollOffset()) : TabPaneSkin.TabHeaderArea.this.getScrollOffset(); TabPaneSkin.TabHeaderArea.this.updateHeaderClip(); for (Node node : getChildren()) { TabPaneSkin.TabHeaderSkin tabHeaderSkin = (TabPaneSkin.TabHeaderSkin)node; double d3 = snapSize(tabHeaderSkin.prefWidth(-1.0D) * tabHeaderSkin.animationTransition.get()); double d4 = snapSize(tabHeaderSkin.prefHeight(-1.0D)); tabHeaderSkin.resize(d3, d4); double d5 = side.equals(Side.BOTTOM) ? 0.0D : (d1 - d4 - snappedBottomInset()); if (side.equals(Side.LEFT) || side.equals(Side.BOTTOM)) { d2 -= d3; if (TabPaneSkin.this.dragState != TabPaneSkin.DragState.REORDER || (tabHeaderSkin != TabPaneSkin.this.dragTabHeader && tabHeaderSkin != TabPaneSkin.this.dropAnimHeader)) tabHeaderSkin.relocate(d2, d5);  continue; }  if (TabPaneSkin.this.dragState != TabPaneSkin.DragState.REORDER || (tabHeaderSkin != TabPaneSkin.this.dragTabHeader && tabHeaderSkin != TabPaneSkin.this.dropAnimHeader)) tabHeaderSkin.relocate(d2, d5);  d2 += d3; }  } }
/*      */         ; this.headersRegion.getStyleClass().setAll(new String[] { "headers-region" }); this.headersRegion.setClip(this.headerClip); TabPaneSkin.this.setupReordering(this.headersRegion); this.headerBackground = new StackPane(); this.headerBackground.getStyleClass().setAll(new String[] { "tab-header-background" }); byte b = 0; for (Tab tab : tabPane.getTabs()) addTab(tab, b++);  this.controlButtons = new TabPaneSkin.TabControlButtons(); this.controlButtons.setVisible(false); if (this.controlButtons.isVisible()) this.controlButtons.setVisible(true);  getChildren().addAll(new Node[] { this.headerBackground, this.headersRegion, this.controlButtons }); addEventHandler(ScrollEvent.SCROLL, param1ScrollEvent -> { Side side = TabPaneSkin.this.getSkinnable().getSide(); side = (side == null) ? Side.TOP : side; switch (side) { default: setScrollOffset(this.scrollOffset + param1ScrollEvent.getDeltaY()); return;case FOCUS_ITEM: case ITEM_COUNT: break; }  setScrollOffset(this.scrollOffset - param1ScrollEvent.getDeltaY()); }); } private void updateHeaderClip() { Side side = TabPaneSkin.this.getSkinnable().getSide(); double d1 = 0.0D; double d2 = 0.0D; double d3 = 0.0D; double d4 = 0.0D; double d5 = 0.0D; double d6 = 0.0D; double d7 = firstTabIndent(); double d8 = snapSize(this.controlButtons.prefWidth(-1.0D)); this.measureClosingTabs = true; double d9 = snapSize(this.headersRegion.prefWidth(-1.0D)); this.measureClosingTabs = false; double d10 = snapSize(this.headersRegion.prefHeight(-1.0D)); if (d8 > 0.0D) d8 += 10.0D;  if (this.headersRegion.getEffect() instanceof DropShadow) { DropShadow dropShadow = (DropShadow)this.headersRegion.getEffect(); d6 = dropShadow.getRadius(); }  d5 = snapSize(getWidth()) - d8 - d7; if (side.equals(Side.LEFT) || side.equals(Side.BOTTOM)) { if (d9 < d5) { d3 = d9 + d6; } else { d1 = d9 - d5; d3 = d5 + d6; }  d4 = d10; } else { d1 = -d6; d3 = ((d9 < d5) ? d9 : d5) + d6; d4 = d10; }  this.headerClip.setX(d1); this.headerClip.setY(d2); this.headerClip.setWidth(d3); this.headerClip.setHeight(d4); } private void addTab(Tab param1Tab, int param1Int) { TabPaneSkin.TabHeaderSkin tabHeaderSkin = new TabPaneSkin.TabHeaderSkin(param1Tab); this.headersRegion.getChildren().add(param1Int, tabHeaderSkin); } private void removeTab(Tab param1Tab) { TabPaneSkin.TabHeaderSkin tabHeaderSkin = getTabHeaderSkin(param1Tab); if (tabHeaderSkin != null) this.headersRegion.getChildren().remove(tabHeaderSkin);  } private TabPaneSkin.TabHeaderSkin getTabHeaderSkin(Tab param1Tab) { for (Node node : this.headersRegion.getChildren()) { TabPaneSkin.TabHeaderSkin tabHeaderSkin = (TabPaneSkin.TabHeaderSkin)node; if (tabHeaderSkin.getTab().equals(param1Tab)) return tabHeaderSkin;  }  return null; } private boolean tabsFit() { double d1 = snapSize(this.headersRegion.prefWidth(-1.0D)); double d2 = snapSize(this.controlButtons.prefWidth(-1.0D)); double d3 = d1 + d2 + firstTabIndent() + 10.0D; return (d3 < getWidth()); } private void ensureSelectedTabIsVisible() { double d1 = snapSize(TabPaneSkin.this.isHorizontal() ? TabPaneSkin.this.getSkinnable().getWidth() : TabPaneSkin.this.getSkinnable().getHeight()); double d2 = snapSize(this.controlButtons.getWidth()); double d3 = d1 - d2 - firstTabIndent() - 10.0D; double d4 = 0.0D; double d5 = 0.0D; double d6 = 0.0D; for (Node node : this.headersRegion.getChildren()) { TabPaneSkin.TabHeaderSkin tabHeaderSkin = (TabPaneSkin.TabHeaderSkin)node; double d = snapSize(tabHeaderSkin.prefWidth(-1.0D)); if (TabPaneSkin.this.selectedTab != null && TabPaneSkin.this.selectedTab.equals(tabHeaderSkin.getTab())) { d5 = d4; d6 = d; }  d4 += d; }  double d7 = getScrollOffset(); double d8 = d5; double d9 = d5 + d6; double d10 = d3; if (d8 < -d7) { setScrollOffset(-d8); } else if (d9 > d10 - d7) { setScrollOffset(d10 - d9); }  } public double getScrollOffset() { return this.scrollOffset; } private void validateScrollOffset() { setScrollOffset(getScrollOffset()); } private void setScrollOffset(double param1Double) { double d5, d1 = snapSize(TabPaneSkin.this.isHorizontal() ? TabPaneSkin.this.getSkinnable().getWidth() : TabPaneSkin.this.getSkinnable().getHeight()); double d2 = snapSize(this.controlButtons.getWidth()); double d3 = d1 - d2 - firstTabIndent() - 10.0D; double d4 = 0.0D; for (Node node : this.headersRegion.getChildren()) { TabPaneSkin.TabHeaderSkin tabHeaderSkin = (TabPaneSkin.TabHeaderSkin)node; double d = snapSize(tabHeaderSkin.prefWidth(-1.0D)); d4 += d; }  if (d3 - param1Double > d4 && param1Double < 0.0D) { d5 = d3 - d4; } else if (param1Double > 0.0D) { d5 = 0.0D; } else { d5 = param1Double; }  if (Math.abs(d5 - this.scrollOffset) > 0.001D) { this.scrollOffset = d5; this.headersRegion.requestLayout(); }  } private double firstTabIndent() { switch (TabPaneSkin.this.getSkinnable().getSide()) { case TEXT: case SELECTED: return snappedLeftInset();case FOCUS_ITEM: case ITEM_COUNT: return snappedTopInset(); }  return 0.0D; } protected double computePrefWidth(double param1Double) { double d = TabPaneSkin.this.isHorizontal() ? (snappedLeftInset() + snappedRightInset()) : (snappedTopInset() + snappedBottomInset()); return snapSize(this.headersRegion.prefWidth(param1Double)) + this.controlButtons.prefWidth(param1Double) + firstTabIndent() + 10.0D + d; } protected double computePrefHeight(double param1Double) { double d = TabPaneSkin.this.isHorizontal() ? (snappedTopInset() + snappedBottomInset()) : (snappedLeftInset() + snappedRightInset()); return snapSize(this.headersRegion.prefHeight(-1.0D)) + d; } public double getBaselineOffset() { if (TabPaneSkin.this.getSkinnable().getSide() == Side.TOP) return this.headersRegion.getBaselineOffset() + snappedTopInset();  return 0.0D; } protected void layoutChildren() { double d1 = snappedLeftInset(); double d2 = snappedRightInset(); double d3 = snappedTopInset(); double d4 = snappedBottomInset(); double d5 = snapSize(getWidth()) - (TabPaneSkin.this.isHorizontal() ? (d1 + d2) : (d3 + d4)); double d6 = snapSize(getHeight()) - (TabPaneSkin.this.isHorizontal() ? (d3 + d4) : (d1 + d2)); double d7 = snapSize(prefHeight(-1.0D)); double d8 = snapSize(this.headersRegion.prefWidth(-1.0D)); double d9 = snapSize(this.headersRegion.prefHeight(-1.0D)); this.controlButtons.showTabsMenu(!tabsFit()); updateHeaderClip(); this.headersRegion.requestLayout(); double d10 = snapSize(this.controlButtons.prefWidth(-1.0D)); double d11 = this.controlButtons.prefHeight(d10); this.controlButtons.resize(d10, d11); this.headersRegion.resize(d8, d9); if (TabPaneSkin.this.isFloatingStyleClass()) { this.headerBackground.setVisible(false); } else { this.headerBackground.resize(snapSize(getWidth()), snapSize(getHeight())); this.headerBackground.setVisible(true); }  double d12 = 0.0D; double d13 = 0.0D; double d14 = 0.0D; double d15 = 0.0D; Side side = TabPaneSkin.this.getSkinnable().getSide(); if (side.equals(Side.TOP)) { d12 = d1; d13 = d7 - d9 - d4; d14 = d5 - d10 + d1; d15 = snapSize(getHeight()) - d11 - d4; } else if (side.equals(Side.RIGHT)) { d12 = d3; d13 = d7 - d9 - d1; d14 = d5 - d10 + d3; d15 = snapSize(getHeight()) - d11 - d1; } else if (side.equals(Side.BOTTOM)) { d12 = snapSize(getWidth()) - d8 - d1; d13 = d7 - d9 - d3; d14 = d2; d15 = snapSize(getHeight()) - d11 - d3; } else if (side.equals(Side.LEFT)) { d12 = snapSize(getWidth()) - d8 - d3; d13 = d7 - d9 - d2; d14 = d1; d15 = snapSize(getHeight()) - d11 - d2; }  if (this.headerBackground.isVisible()) positionInArea(this.headerBackground, 0.0D, 0.0D, snapSize(getWidth()), snapSize(getHeight()), 0.0D, HPos.CENTER, VPos.CENTER);  positionInArea(this.headersRegion, d12, d13, d5, d6, 0.0D, HPos.LEFT, VPos.CENTER); positionInArea(this.controlButtons, d14, d15, d10, d11, 0.0D, HPos.CENTER, VPos.CENTER); } } class TabHeaderSkin extends StackPane {
/* 1990 */     private final Tab tab; private Label label; private StackPane closeBtn; private StackPane inner; private Tooltip oldTooltip; private Tooltip tooltip; private Rectangle clip; public Tab getTab() { return this.tab; } private boolean isClosing = false; private LambdaMultiplePropertyChangeListenerHandler listener = new LambdaMultiplePropertyChangeListenerHandler(); private final ListChangeListener<String> styleClassListener = new ListChangeListener<String>() { public void onChanged(ListChangeListener.Change<? extends String> param2Change) { TabPaneSkin.TabHeaderSkin.this.getStyleClass().setAll(TabPaneSkin.TabHeaderSkin.this.tab.getStyleClass()); } }; private final WeakListChangeListener<String> weakStyleClassListener = new WeakListChangeListener<>(this.styleClassListener); private final DoubleProperty animationTransition; private TabPaneSkin.TabAnimationState animationState; private Timeline currentAnimation; private void updateTabDisabledState() { pseudoClassStateChanged(TabPaneSkin.DISABLED_PSEUDOCLASS_STATE, this.tab.isDisabled()); this.inner.requestLayout(); requestLayout(); } private void updateGraphicRotation() { if (this.label.getGraphic() != null) this.label.getGraphic().setRotate(TabPaneSkin.this.getSkinnable().isRotateGraphic() ? 0.0D : (TabPaneSkin.this.getSkinnable().getSide().equals(Side.RIGHT) ? -90.0F : (TabPaneSkin.this.getSkinnable().getSide().equals(Side.LEFT) ? 90.0F : 0.0F)));  } private boolean showCloseButton() { return (this.tab.isClosable() && (TabPaneSkin.this.getSkinnable().getTabClosingPolicy().equals(TabPane.TabClosingPolicy.ALL_TABS) || (TabPaneSkin.this.getSkinnable().getTabClosingPolicy().equals(TabPane.TabClosingPolicy.SELECTED_TAB) && this.tab.isSelected()))); } public TabHeaderSkin(Tab param1Tab) { this.animationTransition = new SimpleDoubleProperty(this, "animationTransition", 1.0D) { protected void invalidated() { TabPaneSkin.TabHeaderSkin.this.requestLayout(); } }; this.animationState = TabPaneSkin.TabAnimationState.NONE; getStyleClass().setAll(param1Tab.getStyleClass()); setId(param1Tab.getId()); setStyle(param1Tab.getStyle()); setAccessibleRole(AccessibleRole.TAB_ITEM); setViewOrder(1.0D); this.tab = param1Tab; this.clip = new Rectangle(); setClip(this.clip); this.label = new Label(param1Tab.getText(), param1Tab.getGraphic()); this.label.getStyleClass().setAll(new String[] { "tab-label" }); this.closeBtn = new StackPane() { protected double computePrefWidth(double param2Double) { return TabPaneSkin.CLOSE_BTN_SIZE; } protected double computePrefHeight(double param2Double) { return TabPaneSkin.CLOSE_BTN_SIZE; } public void executeAccessibleAction(AccessibleAction param2AccessibleAction, Object... param2VarArgs) { Tab tab; switch (param2AccessibleAction) { case TEXT: tab = TabPaneSkin.TabHeaderSkin.this.getTab(); if (TabPaneSkin.this.behavior.canCloseTab(tab)) { TabPaneSkin.this.behavior.closeTab(tab); setOnMousePressed((EventHandler<? super MouseEvent>)null); }  return; }  super.executeAccessibleAction(param2AccessibleAction, param2VarArgs); } }; this.closeBtn.setAccessibleRole(AccessibleRole.BUTTON); this.closeBtn.setAccessibleText(ControlResources.getString("Accessibility.title.TabPane.CloseButton")); this.closeBtn.getStyleClass().setAll(new String[] { "tab-close-button" }); this.closeBtn.setOnMousePressed(new EventHandler<MouseEvent>() { public void handle(MouseEvent param2MouseEvent) { Tab tab = TabPaneSkin.TabHeaderSkin.this.getTab(); if (param2MouseEvent.getButton().equals(MouseButton.PRIMARY) && TabPaneSkin.this.behavior.canCloseTab(tab)) { TabPaneSkin.this.behavior.closeTab(tab); TabPaneSkin.TabHeaderSkin.this.setOnMousePressed((EventHandler<? super MouseEvent>)null); param2MouseEvent.consume(); }  } }); updateGraphicRotation(); final Region focusIndicator = new Region(); region.setMouseTransparent(true); region.getStyleClass().add("focus-indicator"); this.inner = new StackPane() { protected void layoutChildren() { TabPane tabPane = TabPaneSkin.this.getSkinnable(); double d1 = snappedTopInset(); double d2 = snappedRightInset(); double d3 = snappedBottomInset(); double d4 = snappedLeftInset(); double d5 = getWidth() - d4 + d2; double d6 = getHeight() - d1 + d3; double d7 = snapSize(TabPaneSkin.TabHeaderSkin.this.label.prefWidth(-1.0D)); double d8 = snapSize(TabPaneSkin.TabHeaderSkin.this.label.prefHeight(-1.0D)); double d9 = TabPaneSkin.TabHeaderSkin.this.showCloseButton() ? snapSize(TabPaneSkin.TabHeaderSkin.this.closeBtn.prefWidth(-1.0D)) : 0.0D; double d10 = TabPaneSkin.TabHeaderSkin.this.showCloseButton() ? snapSize(TabPaneSkin.TabHeaderSkin.this.closeBtn.prefHeight(-1.0D)) : 0.0D; double d11 = snapSize(tabPane.getTabMinWidth()); double d12 = snapSize(tabPane.getTabMaxWidth()); double d13 = snapSize(tabPane.getTabMaxHeight()); double d14 = d7; double d15 = d7; double d16 = d8; double d17 = d14 + d9; double d18 = Math.max(d16, d10); if (d17 > d12 && d12 != Double.MAX_VALUE) { d14 = d12 - d9; d15 = d12 - d9; } else if (d17 < d11) { d14 = d11 - d9; }  if (d18 > d13 && d13 != Double.MAX_VALUE) d16 = d13;  if (TabPaneSkin.TabHeaderSkin.this.animationState != TabPaneSkin.TabAnimationState.NONE) { d14 *= TabPaneSkin.TabHeaderSkin.this.animationTransition.get(); TabPaneSkin.TabHeaderSkin.this.closeBtn.setVisible(false); } else { TabPaneSkin.TabHeaderSkin.this.closeBtn.setVisible(TabPaneSkin.TabHeaderSkin.this.showCloseButton()); }  TabPaneSkin.TabHeaderSkin.this.label.resize(d15, d16); double d19 = d4; double d20 = ((d12 < Double.MAX_VALUE) ? Math.min(d5, d12) : d5) - d2 - d9; positionInArea(TabPaneSkin.TabHeaderSkin.this.label, d19, d1, d14, d6, 0.0D, HPos.CENTER, VPos.CENTER); if (TabPaneSkin.TabHeaderSkin.this.closeBtn.isVisible()) { TabPaneSkin.TabHeaderSkin.this.closeBtn.resize(d9, d10); positionInArea(TabPaneSkin.TabHeaderSkin.this.closeBtn, d20, d1, d9, d6, 0.0D, HPos.CENTER, VPos.CENTER); }  byte b1 = Utils.isMac() ? 2 : 3; byte b2 = Utils.isMac() ? 2 : 1; focusIndicator.resizeRelocate(d4 - b2, d1 + b1, d5 + (2 * b2), d6 - (2 * b1)); } }; this.inner.getStyleClass().add("tab-container"); this.inner.setRotate(TabPaneSkin.this.getSkinnable().getSide().equals(Side.BOTTOM) ? 180.0D : 0.0D); this.inner.getChildren().addAll(new Node[] { this.label, this.closeBtn, region }); getChildren().addAll(new Node[] { this.inner }); this.tooltip = param1Tab.getTooltip(); if (this.tooltip != null) { Tooltip.install(this, this.tooltip); this.oldTooltip = this.tooltip; }  this.listener.registerChangeListener(param1Tab.closableProperty(), param1ObservableValue -> { this.inner.requestLayout(); requestLayout(); }); this.listener.registerChangeListener(param1Tab.selectedProperty(), param1ObservableValue -> { pseudoClassStateChanged(TabPaneSkin.SELECTED_PSEUDOCLASS_STATE, param1Tab.isSelected()); this.inner.requestLayout(); requestLayout(); }); this.listener.registerChangeListener(param1Tab.textProperty(), param1ObservableValue -> this.label.setText(getTab().getText())); this.listener.registerChangeListener(param1Tab.graphicProperty(), param1ObservableValue -> this.label.setGraphic(getTab().getGraphic())); this.listener.registerChangeListener(param1Tab.tooltipProperty(), param1ObservableValue -> { if (this.oldTooltip != null) Tooltip.uninstall(this, this.oldTooltip);  this.tooltip = param1Tab.getTooltip(); if (this.tooltip != null) { Tooltip.install(this, this.tooltip); this.oldTooltip = this.tooltip; }  }); this.listener.registerChangeListener(param1Tab.disabledProperty(), param1ObservableValue -> updateTabDisabledState()); this.listener.registerChangeListener(param1Tab.getTabPane().disabledProperty(), param1ObservableValue -> updateTabDisabledState()); this.listener.registerChangeListener(param1Tab.styleProperty(), param1ObservableValue -> setStyle(param1Tab.getStyle())); param1Tab.getStyleClass().addListener(this.weakStyleClassListener); this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().tabClosingPolicyProperty(), param1ObservableValue -> { this.inner.requestLayout(); requestLayout(); }); this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().sideProperty(), param1ObservableValue -> { Side side = TabPaneSkin.this.getSkinnable().getSide(); pseudoClassStateChanged(TabPaneSkin.TOP_PSEUDOCLASS_STATE, (side == Side.TOP)); pseudoClassStateChanged(TabPaneSkin.RIGHT_PSEUDOCLASS_STATE, (side == Side.RIGHT)); pseudoClassStateChanged(TabPaneSkin.BOTTOM_PSEUDOCLASS_STATE, (side == Side.BOTTOM)); pseudoClassStateChanged(TabPaneSkin.LEFT_PSEUDOCLASS_STATE, (side == Side.LEFT)); this.inner.setRotate((side == Side.BOTTOM) ? 180.0D : 0.0D); if (TabPaneSkin.this.getSkinnable().isRotateGraphic()) updateGraphicRotation();  }); this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().rotateGraphicProperty(), param1ObservableValue -> updateGraphicRotation()); this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().tabMinWidthProperty(), param1ObservableValue -> { requestLayout(); TabPaneSkin.this.getSkinnable().requestLayout(); }); this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().tabMaxWidthProperty(), param1ObservableValue -> { requestLayout(); TabPaneSkin.this.getSkinnable().requestLayout(); }); this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().tabMinHeightProperty(), param1ObservableValue -> { requestLayout(); TabPaneSkin.this.getSkinnable().requestLayout(); }); this.listener.registerChangeListener(TabPaneSkin.this.getSkinnable().tabMaxHeightProperty(), param1ObservableValue -> { requestLayout(); TabPaneSkin.this.getSkinnable().requestLayout(); }); getProperties().put(Tab.class, param1Tab); getProperties().put(ContextMenu.class, param1Tab.getContextMenu()); setOnContextMenuRequested(param1ContextMenuEvent -> { if (getTab().getContextMenu() != null) { getTab().getContextMenu().show(this.inner, param1ContextMenuEvent.getScreenX(), param1ContextMenuEvent.getScreenY()); param1ContextMenuEvent.consume(); }  }); setOnMousePressed(new EventHandler<MouseEvent>() { public void handle(MouseEvent param2MouseEvent) { Tab tab = TabPaneSkin.TabHeaderSkin.this.getTab(); if (tab.isDisable()) return;  if (param2MouseEvent.getButton().equals(MouseButton.MIDDLE) || param2MouseEvent.getButton().equals(MouseButton.PRIMARY)) if (tab.getContextMenu() != null && tab.getContextMenu().isShowing()) tab.getContextMenu().hide();   if (param2MouseEvent.getButton().equals(MouseButton.MIDDLE)) { if (TabPaneSkin.TabHeaderSkin.this.showCloseButton() && TabPaneSkin.this.behavior.canCloseTab(tab)) { TabPaneSkin.TabHeaderSkin.this.removeListeners(tab); TabPaneSkin.this.behavior.closeTab(tab); }  } else if (param2MouseEvent.getButton().equals(MouseButton.PRIMARY)) { TabPaneSkin.this.behavior.selectTab(tab); }  } }); pseudoClassStateChanged(TabPaneSkin.SELECTED_PSEUDOCLASS_STATE, param1Tab.isSelected()); pseudoClassStateChanged(TabPaneSkin.DISABLED_PSEUDOCLASS_STATE, param1Tab.isDisabled()); Side side = TabPaneSkin.this.getSkinnable().getSide(); pseudoClassStateChanged(TabPaneSkin.TOP_PSEUDOCLASS_STATE, (side == Side.TOP)); pseudoClassStateChanged(TabPaneSkin.RIGHT_PSEUDOCLASS_STATE, (side == Side.RIGHT)); pseudoClassStateChanged(TabPaneSkin.BOTTOM_PSEUDOCLASS_STATE, (side == Side.BOTTOM)); pseudoClassStateChanged(TabPaneSkin.LEFT_PSEUDOCLASS_STATE, (side == Side.LEFT)); } private void removeListeners(Tab param1Tab) { this.listener.dispose(); this.inner.getChildren().clear(); getChildren().clear(); setOnContextMenuRequested((EventHandler<? super ContextMenuEvent>)null); setOnMousePressed((EventHandler<? super MouseEvent>)null); } protected double computePrefWidth(double param1Double) { double d1 = snapSize(TabPaneSkin.this.getSkinnable().getTabMinWidth()); double d2 = snapSize(TabPaneSkin.this.getSkinnable().getTabMaxWidth()); double d3 = snappedRightInset(); double d4 = snappedLeftInset(); double d5 = snapSize(this.label.prefWidth(-1.0D)); if (showCloseButton()) d5 += snapSize(this.closeBtn.prefWidth(-1.0D));  if (d5 > d2) { d5 = d2; } else if (d5 < d1) { d5 = d1; }  d5 += d3 + d4; return d5; } protected double computePrefHeight(double param1Double) { double d1 = snapSize(TabPaneSkin.this.getSkinnable().getTabMinHeight()); double d2 = snapSize(TabPaneSkin.this.getSkinnable().getTabMaxHeight()); double d3 = snappedTopInset(); double d4 = snappedBottomInset(); double d5 = snapSize(this.label.prefHeight(param1Double)); if (d5 > d2) { d5 = d2; } else if (d5 < d1) { d5 = d1; }  d5 += d3 + d4; return d5; } protected void layoutChildren() { double d = (snapSize(getWidth()) - snappedRightInset() - snappedLeftInset()) * this.animationTransition.getValue().doubleValue(); this.inner.resize(d, snapSize(getHeight()) - snappedTopInset() - snappedBottomInset()); this.inner.relocate(snappedLeftInset(), snappedTopInset()); } protected void setWidth(double param1Double) { super.setWidth(param1Double); this.clip.setWidth(param1Double); } protected void setHeight(double param1Double) { super.setHeight(param1Double); this.clip.setHeight(param1Double); } public Object queryAccessibleAttribute(AccessibleAttribute param1AccessibleAttribute, Object... param1VarArgs) { switch (param1AccessibleAttribute) { case TEXT: return getTab().getText();case SELECTED: return Boolean.valueOf((TabPaneSkin.this.selectedTab == getTab())); }  return super.queryAccessibleAttribute(param1AccessibleAttribute, param1VarArgs); } public void executeAccessibleAction(AccessibleAction param1AccessibleAction, Object... param1VarArgs) { switch (param1AccessibleAction) { case SELECTED: TabPaneSkin.this.getSkinnable().getSelectionModel().select(getTab()); return; }  super.executeAccessibleAction(param1AccessibleAction, param1VarArgs); } } private static final PseudoClass SELECTED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("selected"); private static final PseudoClass TOP_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("top"); private static final PseudoClass BOTTOM_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("bottom"); private static final PseudoClass LEFT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("left"); private static final PseudoClass RIGHT_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("right"); private static final PseudoClass DISABLED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("disabled"); private EventHandler<MouseEvent> headerDraggedHandler; private EventHandler<MouseEvent> headerMousePressedHandler; private void updateListeners() { if (getSkinnable().getTabDragPolicy() == TabPane.TabDragPolicy.FIXED || 
/* 1991 */       getSkinnable().getTabDragPolicy() == null)
/* 1992 */     { for (Node node : this.headersRegion.getChildren()) {
/* 1993 */         removeReorderListeners(node);
/*      */       }
/* 1995 */       this.headersRegion.getChildren().removeListener(this.childListener); }
/* 1996 */     else if (getSkinnable().getTabDragPolicy() == TabPane.TabDragPolicy.REORDER)
/* 1997 */     { for (Node node : this.headersRegion.getChildren()) {
/* 1998 */         addReorderListeners(node);
/*      */       }
/* 2000 */       this.headersRegion.getChildren().addListener(this.childListener); }  } private EventHandler<MouseEvent> headerMouseReleasedHandler; private int dragTabHeaderIndex; private TabHeaderSkin dragTabHeader; private TabHeaderSkin dropTabHeader; private StackPane headersRegion; private DragState dragState; private final int MIN_TO_MAX = 1; private final int MAX_TO_MIN = -1; private int xLayoutDirection; private double dragEventPrevLoc; private int prevDragDirection; private final double DRAG_DIST_THRESHOLD = 0.75D; private final double ANIM_DURATION = 120.0D; private TabHeaderSkin dropAnimHeader; private Tab swapTab; private double dropHeaderSourceX; private double dropHeaderTransitionX; private final Animation dropHeaderAnim; private double dragHeaderStartX; private double dragHeaderDestX; private double dragHeaderSourceX; private double dragHeaderTransitionX; private final Animation dragHeaderAnim; private ListChangeListener childListener; static class TabContentRegion extends StackPane {
/*      */     private Tab tab; private InvalidationListener tabContentListener = param1Observable -> updateContent(); private InvalidationListener tabSelectedListener = new InvalidationListener() { public void invalidated(Observable param2Observable) { TabPaneSkin.TabContentRegion.this.setVisible(TabPaneSkin.TabContentRegion.this.tab.isSelected()); } }
/*      */     ; private WeakInvalidationListener weakTabContentListener = new WeakInvalidationListener(this.tabContentListener); private WeakInvalidationListener weakTabSelectedListener = new WeakInvalidationListener(this.tabSelectedListener); public Tab getTab() { return this.tab; } public TabContentRegion(Tab param1Tab) { getStyleClass().setAll(new String[] { "tab-content-area" }); setManaged(false); this.tab = param1Tab; updateContent(); setVisible(param1Tab.isSelected()); param1Tab.selectedProperty().addListener(this.weakTabSelectedListener); param1Tab.contentProperty().addListener(this.weakTabContentListener); } private void updateContent() { Node node = getTab().getContent(); if (node == null) { getChildren().clear(); } else { getChildren().setAll(new Node[] { node }); }  } private void removeListeners(Tab param1Tab) { param1Tab.selectedProperty().removeListener(this.weakTabSelectedListener); param1Tab.contentProperty().removeListener(this.weakTabContentListener); } } class TabControlButtons extends StackPane {
/*      */     private StackPane inner; private StackPane downArrow; private Pane downArrowBtn; private boolean showControlButtons; private ContextMenu popup; private boolean showTabsMenu; public TabControlButtons() { this.showTabsMenu = false; getStyleClass().setAll(new String[] { "control-buttons-tab" }); TabPane tabPane = TabPaneSkin.this.getSkinnable(); this.downArrowBtn = new Pane(); this.downArrowBtn.getStyleClass().setAll(new String[] { "tab-down-button" }); this.downArrowBtn.setVisible(isShowTabsMenu()); this.downArrow = new StackPane(); this.downArrow.setManaged(false); this.downArrow.getStyleClass().setAll(new String[] { "arrow" }); this.downArrow.setRotate(tabPane.getSide().equals(Side.BOTTOM) ? 180.0D : 0.0D); this.downArrowBtn.getChildren().add(this.downArrow); this.downArrowBtn.setOnMouseClicked(param1MouseEvent -> showPopupMenu()); setupPopupMenu(); this.inner = new StackPane() { protected double computePrefWidth(double param2Double) { double d2 = !TabPaneSkin.TabControlButtons.this.isShowTabsMenu() ? 0.0D : (snapSize(TabPaneSkin.TabControlButtons.this.downArrow.prefWidth(getHeight())) + snapSize(TabPaneSkin.TabControlButtons.this.downArrowBtn.prefWidth(getHeight()))); double d1 = 0.0D; if (TabPaneSkin.TabControlButtons.this.isShowTabsMenu()) d1 += d2;  if (d1 > 0.0D) d1 += snappedLeftInset() + snappedRightInset();  return d1; } protected double computePrefHeight(double param2Double) { double d = 0.0D; if (TabPaneSkin.TabControlButtons.this.isShowTabsMenu()) d = Math.max(d, snapSize(TabPaneSkin.TabControlButtons.this.downArrowBtn.prefHeight(param2Double)));  if (d > 0.0D) d += snappedTopInset() + snappedBottomInset();  return d; } protected void layoutChildren() { if (TabPaneSkin.TabControlButtons.this.isShowTabsMenu()) { double d1 = 0.0D; double d2 = snappedTopInset(); double d3 = snapSize(getWidth()) - d1 + snappedLeftInset(); double d4 = snapSize(getHeight()) - d2 + snappedBottomInset(); positionArrow(TabPaneSkin.TabControlButtons.this.downArrowBtn, TabPaneSkin.TabControlButtons.this.downArrow, d1, d2, d3, d4); }  } private void positionArrow(Pane param2Pane, StackPane param2StackPane, double param2Double1, double param2Double2, double param2Double3, double param2Double4) { param2Pane.resize(param2Double3, param2Double4); positionInArea(param2Pane, param2Double1, param2Double2, param2Double3, param2Double4, 0.0D, HPos.CENTER, VPos.CENTER); double d1 = snapSize(param2StackPane.prefWidth(-1.0D)); double d2 = snapSize(param2StackPane.prefHeight(-1.0D)); param2StackPane.resize(d1, d2); positionInArea(param2StackPane, param2Pane.snappedLeftInset(), param2Pane.snappedTopInset(), param2Double3 - param2Pane.snappedLeftInset() - param2Pane.snappedRightInset(), param2Double4 - param2Pane.snappedTopInset() - param2Pane.snappedBottomInset(), 0.0D, HPos.CENTER, VPos.CENTER); } }; this.inner.getStyleClass().add("container"); this.inner.getChildren().add(this.downArrowBtn); getChildren().add(this.inner); tabPane.sideProperty().addListener(param1Observable -> { Side side = TabPaneSkin.this.getSkinnable().getSide(); this.downArrow.setRotate(side.equals(Side.BOTTOM) ? 180.0D : 0.0D); }); tabPane.getTabs().addListener(param1Change -> setupPopupMenu()); this.showControlButtons = false; if (isShowTabsMenu()) { this.showControlButtons = true; requestLayout(); }  getProperties().put(ContextMenu.class, this.popup); } private void showTabsMenu(boolean param1Boolean) { boolean bool = isShowTabsMenu(); this.showTabsMenu = param1Boolean; if (this.showTabsMenu && !bool) { this.downArrowBtn.setVisible(true); this.showControlButtons = true; this.inner.requestLayout(); TabPaneSkin.this.tabHeaderArea.requestLayout(); } else if (!this.showTabsMenu && bool) { hideControlButtons(); }  } private boolean isShowTabsMenu() { return this.showTabsMenu; } protected double computePrefWidth(double param1Double) { double d = snapSize(this.inner.prefWidth(param1Double)); if (d > 0.0D) d += snappedLeftInset() + snappedRightInset();  return d; } protected double computePrefHeight(double param1Double) { return Math.max(TabPaneSkin.this.getSkinnable().getTabMinHeight(), snapSize(this.inner.prefHeight(param1Double))) + snappedTopInset() + snappedBottomInset(); } protected void layoutChildren() { double d1 = snappedLeftInset(); double d2 = snappedTopInset(); double d3 = snapSize(getWidth()) - d1 + snappedRightInset(); double d4 = snapSize(getHeight()) - d2 + snappedBottomInset(); if (this.showControlButtons) { showControlButtons(); this.showControlButtons = false; }  this.inner.resize(d3, d4); positionInArea(this.inner, d1, d2, d3, d4, 0.0D, HPos.CENTER, VPos.BOTTOM); } private void showControlButtons() { setVisible(true); if (this.popup == null) setupPopupMenu();  } private void hideControlButtons() { if (isShowTabsMenu()) { this.showControlButtons = true; } else { setVisible(false); clearPopupMenu(); this.popup = null; }  requestLayout(); } private void setupPopupMenu() { if (this.popup == null) this.popup = new ContextMenu();  clearPopupMenu(); ToggleGroup toggleGroup = new ToggleGroup(); ObservableList<?> observableList = FXCollections.observableArrayList(); for (Tab tab : TabPaneSkin.this.getSkinnable().getTabs()) { TabPaneSkin.TabMenuItem tabMenuItem = new TabPaneSkin.TabMenuItem(tab); tabMenuItem.setToggleGroup(toggleGroup); tabMenuItem.setOnAction(param1ActionEvent -> TabPaneSkin.this.getSkinnable().getSelectionModel().select(param1Tab)); observableList.add(tabMenuItem); }  this.popup.getItems().addAll(observableList); } private void clearPopupMenu() { for (MenuItem menuItem : this.popup.getItems()) ((TabPaneSkin.TabMenuItem)menuItem).dispose();  this.popup.getItems().clear(); } private void showPopupMenu() { for (MenuItem menuItem : this.popup.getItems()) { TabPaneSkin.TabMenuItem tabMenuItem = (TabPaneSkin.TabMenuItem)menuItem; if (TabPaneSkin.this.selectedTab.equals(tabMenuItem.getTab())) { tabMenuItem.setSelected(true); break; }  }  this.popup.show(this.downArrowBtn, Side.BOTTOM, 0.0D, 0.0D); } } static class TabMenuItem extends RadioMenuItem {
/*      */     Tab tab; private InvalidationListener disableListener = new InvalidationListener() { public void invalidated(Observable param2Observable) { TabPaneSkin.TabMenuItem.this.setDisable(TabPaneSkin.TabMenuItem.this.tab.isDisable()); } }; private WeakInvalidationListener weakDisableListener = new WeakInvalidationListener(this.disableListener); public TabMenuItem(Tab param1Tab) { super(param1Tab.getText(), TabPaneSkin.clone(param1Tab.getGraphic())); this.tab = param1Tab; setDisable(param1Tab.isDisable()); param1Tab.disableProperty().addListener(this.weakDisableListener); textProperty().bind(param1Tab.textProperty()); } public Tab getTab() { return this.tab; } public void dispose() { textProperty().unbind(); this.tab.disableProperty().removeListener(this.weakDisableListener); this.tab = null; } } public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) { Integer integer; switch (paramAccessibleAttribute) { case FOCUS_ITEM: return this.tabHeaderArea.getTabHeaderSkin(this.selectedTab);case ITEM_COUNT: return Integer.valueOf(this.tabHeaderArea.headersRegion.getChildren().size());case ITEM_AT_INDEX: integer = (Integer)paramVarArgs[0]; if (integer == null) return null;  return this.tabHeaderArea.headersRegion.getChildren().get(integer.intValue()); }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs); } private enum DragState {
/* 2005 */     NONE, START, REORDER; } private void addReorderListeners(Node paramNode) { paramNode.addEventHandler(MouseEvent.MOUSE_PRESSED, this.headerMousePressedHandler); paramNode.addEventHandler(MouseEvent.MOUSE_RELEASED, this.headerMouseReleasedHandler); paramNode.addEventHandler(MouseEvent.MOUSE_DRAGGED, this.headerDraggedHandler); } private void removeReorderListeners(Node paramNode) { paramNode.removeEventHandler(MouseEvent.MOUSE_PRESSED, this.headerMousePressedHandler); paramNode.removeEventHandler(MouseEvent.MOUSE_RELEASED, this.headerMouseReleasedHandler); paramNode.removeEventHandler(MouseEvent.MOUSE_DRAGGED, this.headerDraggedHandler); } private void setupReordering(StackPane paramStackPane) { this.dragState = DragState.NONE;
/* 2006 */     this.headersRegion = paramStackPane;
/* 2007 */     updateListeners();
/* 2008 */     getSkinnable().tabDragPolicyProperty().addListener((paramObservableValue, paramTabDragPolicy1, paramTabDragPolicy2) -> {
/*      */           if (paramTabDragPolicy1 != paramTabDragPolicy2) {
/*      */             updateListeners();
/*      */           }
/*      */         }); }
/*      */ 
/*      */   
/*      */   private void handleHeaderMousePressed(MouseEvent paramMouseEvent) {
/* 2016 */     if (paramMouseEvent.getButton().equals(MouseButton.PRIMARY)) {
/* 2017 */       ((StackPane)paramMouseEvent.getSource()).setMouseTransparent(true);
/* 2018 */       startDrag(paramMouseEvent);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void handleHeaderMouseReleased(MouseEvent paramMouseEvent) {
/* 2023 */     if (paramMouseEvent.getButton().equals(MouseButton.PRIMARY)) {
/* 2024 */       ((StackPane)paramMouseEvent.getSource()).setMouseTransparent(false);
/* 2025 */       stopDrag();
/* 2026 */       paramMouseEvent.consume();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void handleHeaderDragged(MouseEvent paramMouseEvent) {
/* 2031 */     if (paramMouseEvent.getButton().equals(MouseButton.PRIMARY)) {
/* 2032 */       perfromDrag(paramMouseEvent);
/*      */     }
/*      */   }
/*      */   
/*      */   private double getDragDelta(double paramDouble1, double paramDouble2) {
/* 2037 */     if (getSkinnable().getSide().equals(Side.TOP) || 
/* 2038 */       getSkinnable().getSide().equals(Side.RIGHT)) {
/* 2039 */       return paramDouble1 - paramDouble2;
/*      */     }
/* 2041 */     return paramDouble2 - paramDouble1;
/*      */   }
/*      */ 
/*      */   
/*      */   private int deriveTabHeaderLayoutXDirection() {
/* 2046 */     if (getSkinnable().getSide().equals(Side.TOP) || 
/* 2047 */       getSkinnable().getSide().equals(Side.RIGHT))
/*      */     {
/* 2049 */       return 1;
/*      */     }
/*      */     
/* 2052 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void perfromDrag(MouseEvent paramMouseEvent) {
/*      */     byte b;
/* 2061 */     double d2 = getHeaderRegionLocalX(paramMouseEvent);
/* 2062 */     double d3 = getDragDelta(d2, this.dragEventPrevLoc);
/*      */     
/* 2064 */     if (d3 > 0.0D) {
/*      */       
/* 2066 */       b = 1;
/*      */     } else {
/*      */       
/* 2069 */       b = -1;
/*      */     } 
/*      */     
/* 2072 */     if (this.prevDragDirection != b) {
/* 2073 */       stopAnim(this.dropHeaderAnim);
/* 2074 */       this.prevDragDirection = b;
/*      */     } 
/*      */     
/* 2077 */     double d1 = this.dragTabHeader.getLayoutX() + this.xLayoutDirection * d3;
/*      */     
/* 2079 */     if (d1 >= 0.0D && d1 + this.dragTabHeader
/* 2080 */       .getWidth() <= this.headersRegion.getWidth()) {
/*      */       
/* 2082 */       this.dragState = DragState.REORDER;
/* 2083 */       this.dragTabHeader.setLayoutX(d1);
/* 2084 */       Bounds bounds = this.dragTabHeader.getBoundsInParent();
/*      */       
/* 2086 */       if (b == 1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2093 */         for (int i = this.dragTabHeaderIndex + 1; i < this.headersRegion.getChildren().size(); i++) {
/* 2094 */           this.dropTabHeader = (TabHeaderSkin)this.headersRegion.getChildren().get(i);
/*      */ 
/*      */           
/* 2097 */           if (this.dropAnimHeader != this.dropTabHeader) {
/* 2098 */             double d; Bounds bounds1 = this.dropTabHeader.getBoundsInParent();
/*      */             
/* 2100 */             if (this.xLayoutDirection == 1) {
/* 2101 */               d = bounds.getMaxX() - bounds1.getMinX();
/*      */             } else {
/* 2103 */               d = bounds1.getMaxX() - bounds.getMinX();
/*      */             } 
/*      */ 
/*      */             
/* 2107 */             if (d > bounds1.getWidth() * 0.75D) {
/* 2108 */               stopAnim(this.dropHeaderAnim);
/*      */               
/* 2110 */               this.dropHeaderTransitionX = this.xLayoutDirection * -bounds.getWidth();
/* 2111 */               if (this.xLayoutDirection == 1) {
/* 2112 */                 this.dragHeaderDestX = bounds1.getMaxX() - bounds.getWidth();
/*      */               } else {
/* 2114 */                 this.dragHeaderDestX = bounds1.getMinX();
/*      */               } 
/* 2116 */               startHeaderReorderingAnim();
/*      */             }
/*      */             else {
/*      */               
/*      */               break;
/*      */             }
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 2130 */         for (int i = this.dragTabHeaderIndex - 1; i >= 0; i--) {
/* 2131 */           this.dropTabHeader = (TabHeaderSkin)this.headersRegion.getChildren().get(i);
/*      */ 
/*      */           
/* 2134 */           if (this.dropAnimHeader != this.dropTabHeader) {
/* 2135 */             double d; Bounds bounds1 = this.dropTabHeader.getBoundsInParent();
/*      */             
/* 2137 */             if (this.xLayoutDirection == 1) {
/* 2138 */               d = bounds1.getMaxX() - bounds.getMinX();
/*      */             } else {
/* 2140 */               d = bounds.getMaxX() - bounds1.getMinX();
/*      */             } 
/*      */ 
/*      */             
/* 2144 */             if (d > bounds1.getWidth() * 0.75D) {
/* 2145 */               stopAnim(this.dropHeaderAnim);
/*      */               
/* 2147 */               this.dropHeaderTransitionX = this.xLayoutDirection * bounds.getWidth();
/* 2148 */               if (this.xLayoutDirection == 1) {
/* 2149 */                 this.dragHeaderDestX = bounds1.getMinX();
/*      */               } else {
/* 2151 */                 this.dragHeaderDestX = bounds1.getMaxX() - bounds.getWidth();
/*      */               } 
/* 2153 */               startHeaderReorderingAnim();
/*      */             } else {
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 2161 */     this.dragEventPrevLoc = d2;
/* 2162 */     paramMouseEvent.consume();
/*      */   }
/*      */ 
/*      */   
/*      */   private void startDrag(MouseEvent paramMouseEvent) {
/* 2167 */     stopAnim(this.dropHeaderAnim);
/* 2168 */     stopAnim(this.dragHeaderAnim);
/*      */     
/* 2170 */     this.dragTabHeader = (TabHeaderSkin)paramMouseEvent.getSource();
/* 2171 */     if (this.dragTabHeader != null) {
/* 2172 */       this.dragState = DragState.START;
/* 2173 */       this.swapTab = null;
/* 2174 */       this.xLayoutDirection = deriveTabHeaderLayoutXDirection();
/* 2175 */       this.dragEventPrevLoc = getHeaderRegionLocalX(paramMouseEvent);
/* 2176 */       this.dragTabHeaderIndex = this.headersRegion.getChildren().indexOf(this.dragTabHeader);
/* 2177 */       this.dragTabHeader.setViewOrder(0.0D);
/* 2178 */       this.dragHeaderStartX = this.dragHeaderDestX = this.dragTabHeader.getLayoutX();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double getHeaderRegionLocalX(MouseEvent paramMouseEvent) {
/* 2186 */     Point2D point2D = this.headersRegion.sceneToLocal(paramMouseEvent.getSceneX(), paramMouseEvent.getSceneY());
/* 2187 */     return point2D.getX();
/*      */   }
/*      */   
/*      */   private void stopDrag() {
/* 2191 */     if (this.dragState == DragState.START) {
/*      */       
/* 2193 */       resetDrag();
/*      */       
/*      */       return;
/*      */     } 
/* 2197 */     this.dragHeaderSourceX = this.dragTabHeader.getLayoutX();
/* 2198 */     this.dragHeaderTransitionX = this.dragHeaderDestX - this.dragHeaderSourceX;
/* 2199 */     this.dragHeaderAnim.playFromStart();
/*      */ 
/*      */     
/* 2202 */     if (this.dragHeaderStartX != this.dragHeaderDestX) {
/* 2203 */       ((TabObservableList)getSkinnable().getTabs()).reorder(this.dragTabHeader.tab, this.swapTab);
/* 2204 */       this.swapTab = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void resetDrag() {
/* 2209 */     this.dragState = DragState.NONE;
/* 2210 */     this.dragTabHeader.setViewOrder(1.0D);
/* 2211 */     this.dragTabHeader = null;
/* 2212 */     this.dropTabHeader = null;
/* 2213 */     this.headersRegion.requestLayout();
/*      */   }
/*      */ 
/*      */   
/*      */   private void startHeaderReorderingAnim() {
/* 2218 */     this.dropAnimHeader = this.dropTabHeader;
/* 2219 */     this.swapTab = this.dropAnimHeader.tab;
/* 2220 */     this.dropHeaderSourceX = this.dropAnimHeader.getLayoutX();
/* 2221 */     this.dropHeaderAnim.playFromStart();
/*      */   }
/*      */ 
/*      */   
/*      */   private void completeHeaderReordering() {
/* 2226 */     if (this.dropAnimHeader != null) {
/* 2227 */       this.headersRegion.getChildren().remove(this.dropAnimHeader);
/* 2228 */       this.headersRegion.getChildren().add(this.dragTabHeaderIndex, this.dropAnimHeader);
/* 2229 */       this.dropAnimHeader = null;
/* 2230 */       this.headersRegion.requestLayout();
/* 2231 */       this.dragTabHeaderIndex = this.headersRegion.getChildren().indexOf(this.dragTabHeader);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void stopAnim(Animation paramAnimation) {
/* 2237 */     if (paramAnimation.getStatus() == Animation.Status.RUNNING) {
/* 2238 */       paramAnimation.getOnFinished().handle(null);
/* 2239 */       paramAnimation.stop();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   ContextMenu test_getTabsMenu() {
/* 2245 */     return this.tabHeaderArea.controlButtons.popup;
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TabPaneSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */