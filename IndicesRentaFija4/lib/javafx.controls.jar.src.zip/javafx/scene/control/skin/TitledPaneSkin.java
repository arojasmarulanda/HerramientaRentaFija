/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.scene.control.behavior.TitledPaneBehavior;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.animation.Animation;
/*     */ import javafx.animation.Interpolator;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.KeyValue;
/*     */ import javafx.animation.Timeline;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.binding.DoubleBinding;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.Insets;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.Cursor;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ContentDisplay;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.TitledPane;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.shape.Rectangle;
/*     */ import javafx.scene.text.Font;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TitledPaneSkin
/*     */   extends LabeledSkinBase<TitledPane>
/*     */ {
/*  72 */   private static final Duration TRANSITION_DURATION = new Duration(350.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private static final boolean CACHE_ANIMATION = PlatformUtil.isEmbedded();
/*     */ 
/*     */   
/*     */   private final TitledPaneBehavior behavior;
/*     */ 
/*     */   
/*     */   private final TitleRegion titleRegion;
/*     */ 
/*     */   
/*     */   private final StackPane contentContainer;
/*     */ 
/*     */   
/*     */   private Node content;
/*     */ 
/*     */   
/*     */   private Timeline timeline;
/*     */ 
/*     */   
/*     */   private double transitionStartValue;
/*     */ 
/*     */   
/*     */   private Rectangle clipRect;
/*     */ 
/*     */   
/*     */   private Pos pos;
/*     */ 
/*     */   
/*     */   private HPos hpos;
/*     */ 
/*     */   
/*     */   private VPos vpos;
/*     */   
/*     */   private DoubleProperty transition;
/*     */   
/*     */   private double prefHeightFromAccordion;
/*     */ 
/*     */   
/*     */   public TitledPaneSkin(TitledPane paramTitledPane) {
/* 115 */     super(paramTitledPane);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 333 */     this.prefHeightFromAccordion = 0.0D; this.behavior = new TitledPaneBehavior(paramTitledPane); this.clipRect = new Rectangle(); this.transitionStartValue = 0.0D; this.titleRegion = new TitleRegion(); this.content = getSkinnable().getContent(); this.contentContainer = new StackPane() {  }
/*     */       ; this.contentContainer.setClip(this.clipRect); updateClip(); if (paramTitledPane.isExpanded()) { setTransition(1.0D); setExpanded(paramTitledPane.isExpanded()); } else { setTransition(0.0D); if (this.content != null) this.content.setVisible(false);  }  getChildren().setAll(new Node[] { this.contentContainer, this.titleRegion }); registerChangeListener(paramTitledPane.contentProperty(), paramObservableValue -> { this.content = getSkinnable().getContent(); if (this.content == null) { this.contentContainer.getChildren().clear(); } else { this.contentContainer.getChildren().setAll(new Node[] { this.content }); }  }); registerChangeListener(paramTitledPane.expandedProperty(), paramObservableValue -> setExpanded(getSkinnable().isExpanded())); registerChangeListener(paramTitledPane.collapsibleProperty(), paramObservableValue -> this.titleRegion.update()); registerChangeListener(paramTitledPane.alignmentProperty(), paramObservableValue -> { this.pos = getSkinnable().getAlignment(); this.hpos = this.pos.getHpos(); this.vpos = this.pos.getVpos(); }); registerChangeListener(paramTitledPane.widthProperty(), paramObservableValue -> updateClip()); registerChangeListener(paramTitledPane.heightProperty(), paramObservableValue -> updateClip()); registerChangeListener(this.titleRegion.alignmentProperty(), paramObservableValue -> { this.pos = this.titleRegion.getAlignment(); this.hpos = this.pos.getHpos(); this.vpos = this.pos.getVpos(); }); this.pos = paramTitledPane.getAlignment(); this.hpos = (this.pos == null) ? HPos.LEFT : this.pos.getHpos(); this.vpos = (this.pos == null) ? VPos.CENTER : this.pos.getVpos();
/* 335 */   } private final void setTransition(double paramDouble) { transitionProperty().set(paramDouble); } private final double getTransition() { return (this.transition == null) ? 0.0D : this.transition.get(); } private final DoubleProperty transitionProperty() { if (this.transition == null) this.transition = new SimpleDoubleProperty(this, "transition", 0.0D) { protected void invalidated() { TitledPaneSkin.this.contentContainer.requestLayout(); } };  return this.transition; } public void dispose() { super.dispose(); if (this.behavior != null) this.behavior.dispose();  } protected void updateChildren() { if (this.titleRegion != null) this.titleRegion.update();  } protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { double d1 = snapSizeY(this.titleRegion.prefHeight(-1.0D)); this.titleRegion.resize(paramDouble3, d1); positionInArea(this.titleRegion, paramDouble1, paramDouble2, paramDouble3, d1, 0.0D, HPos.LEFT, VPos.CENTER); this.titleRegion.requestLayout(); double d2 = (paramDouble4 - d1) * getTransition(); if (isInsideAccordion() && this.prefHeightFromAccordion != 0.0D) d2 = (this.prefHeightFromAccordion - d1) * getTransition();  d2 = snapSizeY(d2); paramDouble2 += d1; this.contentContainer.resize(paramDouble3, d2); this.clipRect.setHeight(d2); positionInArea(this.contentContainer, paramDouble1, paramDouble2, paramDouble3, d2, 0.0D, HPos.CENTER, VPos.CENTER); } protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { double d1 = snapSizeX(this.titleRegion.prefWidth(paramDouble1)); double d2 = snapSizeX(this.contentContainer.minWidth(paramDouble1)); return Math.max(d1, d2) + paramDouble5 + paramDouble3; } void setMaxTitledPaneHeightForAccordion(double paramDouble) { this.prefHeightFromAccordion = paramDouble; }
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { double d1 = snapSizeY(this.titleRegion.prefHeight(paramDouble1)); double d2 = this.contentContainer.minHeight(paramDouble1) * getTransition(); return d1 + snapSizeY(d2) + paramDouble2 + paramDouble4; }
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { double d1 = snapSizeX(this.titleRegion.prefWidth(paramDouble1)); double d2 = snapSizeX(this.contentContainer.prefWidth(paramDouble1)); return Math.max(d1, d2) + paramDouble5 + paramDouble3; }
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { double d1 = snapSizeY(this.titleRegion.prefHeight(paramDouble1)); double d2 = this.contentContainer.prefHeight(paramDouble1) * getTransition(); return d1 + snapSizeY(d2) + paramDouble2 + paramDouble4; }
/* 339 */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) { return Double.MAX_VALUE; } private void updateClip() { this.clipRect.setWidth(getSkinnable().getWidth()); this.clipRect.setHeight(this.contentContainer.getHeight()); } private void setExpanded(boolean paramBoolean) { if (!getSkinnable().isCollapsible()) { setTransition(1.0D); return; }  if (getSkinnable().isAnimated()) { this.transitionStartValue = getTransition(); doAnimationTransition(); } else { if (paramBoolean) { setTransition(1.0D); } else { setTransition(0.0D); }  if (this.content != null) this.content.setVisible(paramBoolean);  getSkinnable().requestLayout(); }  } private boolean isInsideAccordion() { return (getSkinnable().getParent() != null && getSkinnable().getParent() instanceof javafx.scene.control.Accordion); } double getTitleRegionSize(double paramDouble) { return snapSizeY(this.titleRegion.prefHeight(paramDouble)) + snappedTopInset() + snappedBottomInset(); } double getTitledPaneHeightForAccordion() { double d1 = snapSizeY(this.titleRegion.prefHeight(-1.0D));
/* 340 */     double d2 = (this.prefHeightFromAccordion - d1) * getTransition();
/* 341 */     return d1 + snapSizeY(d2) + snappedTopInset() + snappedBottomInset(); }
/*     */    private void doAnimationTransition() {
/*     */     Duration duration;
/*     */     KeyFrame keyFrame1, keyFrame2;
/* 345 */     if (this.content == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 350 */     if (this.timeline != null && this.timeline.getStatus() != Animation.Status.STOPPED) {
/* 351 */       duration = this.timeline.getCurrentTime();
/* 352 */       this.timeline.stop();
/*     */     } else {
/* 354 */       duration = TRANSITION_DURATION;
/*     */     } 
/*     */     
/* 357 */     this.timeline = new Timeline();
/* 358 */     this.timeline.setCycleCount(1);
/*     */ 
/*     */ 
/*     */     
/* 362 */     if (getSkinnable().isExpanded()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 370 */       keyFrame1 = new KeyFrame(Duration.ZERO, paramActionEvent -> { if (CACHE_ANIMATION) this.content.setCache(true);  this.content.setVisible(true); }new KeyValue[] { new KeyValue(transitionProperty(), (T)Double.valueOf(this.transitionStartValue)) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 379 */       keyFrame2 = new KeyFrame(duration, paramActionEvent -> { if (CACHE_ANIMATION) this.content.setCache(false);  }new KeyValue[] { new KeyValue(transitionProperty(), (T)Integer.valueOf(1), Interpolator.LINEAR) });
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 389 */       keyFrame1 = new KeyFrame(Duration.ZERO, paramActionEvent -> { if (CACHE_ANIMATION) this.content.setCache(true);  }new KeyValue[] { new KeyValue(transitionProperty(), (T)Double.valueOf(this.transitionStartValue)) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 399 */       keyFrame2 = new KeyFrame(duration, paramActionEvent -> { this.content.setVisible(false); if (CACHE_ANIMATION) this.content.setCache(false);  }new KeyValue[] { new KeyValue(transitionProperty(), (T)Integer.valueOf(0), Interpolator.LINEAR) });
/*     */     } 
/*     */ 
/*     */     
/* 403 */     this.timeline.getKeyFrames().setAll(new KeyFrame[] { keyFrame1, keyFrame2 });
/* 404 */     this.timeline.play();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class TitleRegion
/*     */     extends StackPane
/*     */   {
/*     */     private final StackPane arrowRegion;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TitleRegion() {
/* 419 */       getStyleClass().setAll(new String[] { "title" });
/* 420 */       this.arrowRegion = new StackPane();
/* 421 */       this.arrowRegion.setId("arrowRegion");
/* 422 */       this.arrowRegion.getStyleClass().setAll(new String[] { "arrow-button" });
/*     */       
/* 424 */       StackPane stackPane = new StackPane();
/* 425 */       stackPane.setId("arrow");
/* 426 */       stackPane.getStyleClass().setAll(new String[] { "arrow" });
/* 427 */       this.arrowRegion.getChildren().setAll(new Node[] { stackPane });
/*     */ 
/*     */       
/* 430 */       stackPane.rotateProperty().bind(new DoubleBinding()
/*     */           {
/*     */             protected double computeValue()
/*     */             {
/* 434 */               return -90.0D * (1.0D - TitledPaneSkin.this.getTransition());
/*     */             }
/*     */           });
/*     */       
/* 438 */       setAlignment(Pos.CENTER_LEFT);
/*     */       
/* 440 */       setOnMouseReleased(param1MouseEvent -> {
/*     */             if (param1MouseEvent.getButton() != MouseButton.PRIMARY) {
/*     */               return;
/*     */             }
/*     */             ContextMenu contextMenu = TitledPaneSkin.this.getSkinnable().getContextMenu();
/*     */             if (contextMenu != null) {
/*     */               contextMenu.hide();
/*     */             }
/*     */             if (TitledPaneSkin.this.getSkinnable().isCollapsible() && TitledPaneSkin.this.getSkinnable().isFocused()) {
/*     */               TitledPaneSkin.this.behavior.toggle();
/*     */             }
/*     */           });
/* 452 */       update();
/*     */     }
/*     */     
/*     */     private void update() {
/* 456 */       getChildren().clear();
/* 457 */       TitledPane titledPane = TitledPaneSkin.this.getSkinnable();
/*     */       
/* 459 */       if (titledPane.isCollapsible()) {
/* 460 */         getChildren().add(this.arrowRegion);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 466 */       if (TitledPaneSkin.this.graphic != null) {
/* 467 */         TitledPaneSkin.this.graphic.layoutBoundsProperty().removeListener(TitledPaneSkin.this.graphicPropertyChangedListener);
/*     */       }
/*     */       
/* 470 */       TitledPaneSkin.this.graphic = titledPane.getGraphic();
/*     */       
/* 472 */       if (TitledPaneSkin.this.isIgnoreGraphic()) {
/* 473 */         if (titledPane.getContentDisplay() == ContentDisplay.GRAPHIC_ONLY) {
/* 474 */           getChildren().clear();
/* 475 */           getChildren().add(this.arrowRegion);
/*     */         } else {
/* 477 */           getChildren().add(TitledPaneSkin.this.text);
/*     */         } 
/*     */       } else {
/* 480 */         TitledPaneSkin.this.graphic.layoutBoundsProperty().addListener(TitledPaneSkin.this.graphicPropertyChangedListener);
/* 481 */         if (TitledPaneSkin.this.isIgnoreText()) {
/* 482 */           getChildren().add(TitledPaneSkin.this.graphic);
/*     */         } else {
/* 484 */           getChildren().addAll(new Node[] { this.this$0.graphic, (Node)this.this$0.text });
/*     */         } 
/*     */       } 
/* 487 */       setCursor(TitledPaneSkin.this.getSkinnable().isCollapsible() ? Cursor.HAND : Cursor.DEFAULT);
/*     */     }
/*     */     
/*     */     protected double computePrefWidth(double param1Double) {
/* 491 */       double d1 = snappedLeftInset();
/* 492 */       double d2 = snappedRightInset();
/* 493 */       double d3 = 0.0D;
/* 494 */       double d4 = labelPrefWidth(param1Double);
/*     */       
/* 496 */       if (this.arrowRegion != null) {
/* 497 */         d3 = snapSize(this.arrowRegion.prefWidth(param1Double));
/*     */       }
/*     */       
/* 500 */       return d1 + d3 + d4 + d2;
/*     */     }
/*     */     
/*     */     protected double computePrefHeight(double param1Double) {
/* 504 */       double d1 = snappedTopInset();
/* 505 */       double d2 = snappedBottomInset();
/* 506 */       double d3 = 0.0D;
/* 507 */       double d4 = labelPrefHeight(param1Double);
/*     */       
/* 509 */       if (this.arrowRegion != null) {
/* 510 */         d3 = snapSize(this.arrowRegion.prefHeight(param1Double));
/*     */       }
/*     */       
/* 513 */       return d1 + Math.max(d3, d4) + d2;
/*     */     }
/*     */     
/*     */     protected void layoutChildren() {
/* 517 */       double d1 = snappedTopInset();
/* 518 */       double d2 = snappedBottomInset();
/* 519 */       double d3 = snappedLeftInset();
/* 520 */       double d4 = snappedRightInset();
/* 521 */       double d5 = getWidth() - d3 + d4;
/* 522 */       double d6 = getHeight() - d1 + d2;
/* 523 */       double d7 = snapSize(this.arrowRegion.prefWidth(-1.0D));
/* 524 */       double d8 = snapSize(this.arrowRegion.prefHeight(-1.0D));
/* 525 */       double d9 = snapSize(Math.min(d5 - d7 / 2.0D, labelPrefWidth(-1.0D)));
/* 526 */       double d10 = snapSize(labelPrefHeight(-1.0D));
/*     */       
/* 528 */       double d11 = d3 + d7 + Utils.computeXOffset(d5 - d7, d9, TitledPaneSkin.this.hpos);
/* 529 */       if (HPos.CENTER == TitledPaneSkin.this.hpos)
/*     */       {
/* 531 */         d11 = d3 + Utils.computeXOffset(d5, d9, TitledPaneSkin.this.hpos);
/*     */       }
/* 533 */       double d12 = d1 + Utils.computeYOffset(d6, Math.max(d8, d10), TitledPaneSkin.this.vpos);
/*     */       
/* 535 */       this.arrowRegion.resize(d7, d8);
/* 536 */       positionInArea(this.arrowRegion, d3, d1, d7, d6, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */ 
/*     */       
/* 539 */       TitledPaneSkin.this.layoutLabelInArea(d11, d12, d9, d6, TitledPaneSkin.this.pos);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private double labelPrefWidth(double param1Double) {
/* 546 */       TitledPane titledPane = TitledPaneSkin.this.getSkinnable();
/* 547 */       Font font = TitledPaneSkin.this.text.getFont();
/* 548 */       String str = titledPane.getText();
/* 549 */       boolean bool = (str == null || str.isEmpty()) ? true : false;
/* 550 */       Insets insets = titledPane.getLabelPadding();
/* 551 */       double d1 = insets.getLeft() + insets.getRight();
/* 552 */       double d2 = bool ? 0.0D : Utils.computeTextWidth(font, str, 0.0D);
/*     */ 
/*     */       
/* 555 */       Node node = titledPane.getGraphic();
/* 556 */       if (TitledPaneSkin.this.isIgnoreGraphic())
/* 557 */         return d2 + d1; 
/* 558 */       if (TitledPaneSkin.this.isIgnoreText())
/* 559 */         return node.prefWidth(-1.0D) + d1; 
/* 560 */       if (titledPane.getContentDisplay() == ContentDisplay.LEFT || titledPane
/* 561 */         .getContentDisplay() == ContentDisplay.RIGHT) {
/* 562 */         return d2 + titledPane.getGraphicTextGap() + node.prefWidth(-1.0D) + d1;
/*     */       }
/* 564 */       return Math.max(d2, node.prefWidth(-1.0D)) + d1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private double labelPrefHeight(double param1Double) {
/* 571 */       TitledPane titledPane = TitledPaneSkin.this.getSkinnable();
/* 572 */       Font font = TitledPaneSkin.this.text.getFont();
/* 573 */       ContentDisplay contentDisplay = titledPane.getContentDisplay();
/* 574 */       double d1 = titledPane.getGraphicTextGap();
/* 575 */       Insets insets = titledPane.getLabelPadding();
/* 576 */       double d2 = snappedLeftInset() + snappedRightInset() + insets.getLeft() + insets.getRight();
/*     */       
/* 578 */       String str = titledPane.getText();
/* 579 */       if (str != null && str.endsWith("\n"))
/*     */       {
/* 581 */         str = str.substring(0, str.length() - 1);
/*     */       }
/*     */       
/* 584 */       if (!TitledPaneSkin.this.isIgnoreGraphic() && (contentDisplay == ContentDisplay.LEFT || contentDisplay == ContentDisplay.RIGHT))
/*     */       {
/* 586 */         param1Double -= TitledPaneSkin.this.graphic.prefWidth(-1.0D) + d1;
/*     */       }
/*     */       
/* 589 */       param1Double -= d2;
/*     */ 
/*     */       
/* 592 */       double d3 = Utils.computeTextHeight(font, str, 
/* 593 */           titledPane.isWrapText() ? param1Double : 0.0D, TitledPaneSkin.this.text.getBoundsType());
/*     */ 
/*     */       
/* 596 */       double d4 = d3;
/* 597 */       if (!TitledPaneSkin.this.isIgnoreGraphic()) {
/* 598 */         Node node = titledPane.getGraphic();
/* 599 */         if (contentDisplay == ContentDisplay.TOP || contentDisplay == ContentDisplay.BOTTOM) {
/* 600 */           d4 = node.prefHeight(-1.0D) + d1 + d3;
/*     */         } else {
/* 602 */           d4 = Math.max(d3, node.prefHeight(-1.0D));
/*     */         } 
/*     */       } 
/*     */       
/* 606 */       return d4 + insets.getTop() + insets.getBottom();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TitledPaneSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */