/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.TreeTableRowBehavior;
/*     */ import java.lang.ref.Reference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableDoubleProperty;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.IndexedCell;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeTableCell;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ import javafx.scene.control.TreeTablePosition;
/*     */ import javafx.scene.control.TreeTableRow;
/*     */ import javafx.scene.control.TreeTableView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeTableRowSkin<T>
/*     */   extends TableRowSkinBase<TreeItem<T>, TreeTableRow<T>, TreeTableCell<T, ?>>
/*     */ {
/*     */   private TreeItem<?> treeItem;
/*     */   private boolean disclosureNodeDirty = true;
/*     */   private Node graphic;
/*     */   private final BehaviorBase<TreeTableRow<T>> behavior;
/*     */   private TreeTableViewSkin treeTableViewSkin;
/*     */   private boolean childrenDirty = false;
/*     */   private final InvalidationListener graphicListener;
/*     */   private DoubleProperty indent;
/*     */   
/*     */   private void setupTreeTableViewListeners() {
/*     */     TreeTableView<T> treeTableView = getSkinnable().getTreeTableView();
/*     */     if (treeTableView == null) {
/*     */       getSkinnable().treeTableViewProperty().addListener(new InvalidationListener()
/*     */           {
/*     */             public void invalidated(Observable param1Observable) {
/*     */               TreeTableRowSkin.this.getSkinnable().treeTableViewProperty().removeListener(this);
/*     */               TreeTableRowSkin.this.setupTreeTableViewListeners();
/*     */             }
/*     */           });
/*     */     } else {
/*     */       registerChangeListener(treeTableView.treeColumnProperty(), paramObservableValue -> {
/*     */             this.isDirty = true;
/*     */             getSkinnable().requestLayout();
/*     */           });
/*     */       DoubleProperty doubleProperty = getTreeTableView().fixedCellSizeProperty();
/*     */       if (doubleProperty != null) {
/*     */         registerChangeListener(doubleProperty, paramObservableValue -> {
/*     */               this.fixedCellSize = paramDoubleProperty.get();
/*     */               this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0D);
/*     */             });
/*     */         this.fixedCellSize = doubleProperty.get();
/*     */         this.fixedCellSizeEnabled = (this.fixedCellSize > 0.0D);
/*     */         registerChangeListener(getVirtualFlow().widthProperty(), paramObservableValue -> paramTreeTableView.requestLayout());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public TreeTableRowSkin(TreeTableRow<T> paramTreeTableRow) {
/* 102 */     super(paramTreeTableRow);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     this.graphicListener = (paramObservable -> {
/*     */         this.disclosureNodeDirty = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         getSkinnable().requestLayout();
/*     */       });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     this.indent = null; this.behavior = new TreeTableRowBehavior<>(paramTreeTableRow); updateTreeItem(); updateTableViewSkin(); registerChangeListener(paramTreeTableRow.treeTableViewProperty(), paramObservableValue -> updateTableViewSkin()); registerChangeListener(paramTreeTableRow.indexProperty(), paramObservableValue -> this.updateCells = true); registerChangeListener(paramTreeTableRow.treeItemProperty(), paramObservableValue -> updateTreeItem());
/* 183 */     setupTreeTableViewListeners(); } public final void setIndent(double paramDouble) { indentProperty().set(paramDouble); } public final double getIndent() {
/* 184 */     return (this.indent == null) ? 10.0D : this.indent.get();
/*     */   } public final DoubleProperty indentProperty() {
/* 186 */     if (this.indent == null) {
/* 187 */       this.indent = new StyleableDoubleProperty(10.0D) {
/*     */           public Object getBean() {
/* 189 */             return TreeTableRowSkin.this;
/*     */           }
/*     */           
/*     */           public String getName() {
/* 193 */             return "indent";
/*     */           }
/*     */           
/*     */           public CssMetaData<TreeTableRow<?>, Number> getCssMetaData() {
/* 197 */             return TreeTableRowSkin.StyleableProperties.INDENT;
/*     */           }
/*     */         };
/*     */     }
/* 201 */     return this.indent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 214 */     super.dispose();
/*     */     
/* 216 */     if (this.behavior != null) {
/* 217 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateChildren() {
/* 223 */     super.updateChildren();
/*     */     
/* 225 */     updateDisclosureNodeAndGraphic();
/*     */     
/* 227 */     if (this.childrenDirty) {
/* 228 */       this.childrenDirty = false;
/* 229 */       if (this.cells.isEmpty()) {
/* 230 */         getChildren().clear();
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 235 */         getChildren().addAll((Collection)this.cells);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 242 */     if (this.disclosureNodeDirty) {
/* 243 */       updateDisclosureNodeAndGraphic();
/* 244 */       this.disclosureNodeDirty = false;
/*     */     } 
/*     */     
/* 247 */     Node node = getDisclosureNode();
/* 248 */     if (node != null && node.getScene() == null) {
/* 249 */       updateDisclosureNodeAndGraphic();
/*     */     }
/*     */     
/* 252 */     super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TreeTableCell<T, ?> createCell(TableColumnBase paramTableColumnBase) {
/* 265 */     TreeTableColumn treeTableColumn = (TreeTableColumn)paramTableColumnBase;
/* 266 */     TreeTableCell<T, ?> treeTableCell = treeTableColumn.getCellFactory().call(treeTableColumn);
/*     */     
/* 268 */     treeTableCell.updateTreeTableColumn(treeTableColumn);
/* 269 */     treeTableCell.updateTreeTableView(treeTableColumn.getTreeTableView());
/*     */     
/* 271 */     return treeTableCell;
/*     */   }
/*     */ 
/*     */   
/*     */   void updateCells(boolean paramBoolean) {
/* 276 */     super.updateCells(paramBoolean);
/*     */     
/* 278 */     if (paramBoolean) {
/* 279 */       this.childrenDirty = true;
/* 280 */       updateChildren();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isIndentationRequired() {
/* 286 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   TableColumnBase getTreeColumn() {
/* 291 */     return getTreeTableView().getTreeColumn();
/*     */   }
/*     */ 
/*     */   
/*     */   int getIndentationLevel(TreeTableRow<T> paramTreeTableRow) {
/* 296 */     return getTreeTableView().getTreeItemLevel(paramTreeTableRow.getTreeItem());
/*     */   }
/*     */ 
/*     */   
/*     */   double getIndentationPerLevel() {
/* 301 */     return getIndent();
/*     */   }
/*     */ 
/*     */   
/*     */   Node getDisclosureNode() {
/* 306 */     return getSkinnable().getDisclosureNode();
/*     */   }
/*     */   
/*     */   boolean isDisclosureNodeVisible() {
/* 310 */     return (getDisclosureNode() != null && this.treeItem != null && !this.treeItem.isLeaf());
/*     */   }
/*     */   
/*     */   boolean isShowRoot() {
/* 314 */     return getTreeTableView().isShowRoot();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ObservableList<TreeTableColumn<T, ?>> getVisibleLeafColumns() {
/* 319 */     return (getTreeTableView() == null) ? FXCollections.<TreeTableColumn<T, ?>>emptyObservableList() : getTreeTableView().getVisibleLeafColumns();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateCell(TreeTableCell<T, ?> paramTreeTableCell, TreeTableRow<T> paramTreeTableRow) {
/* 324 */     paramTreeTableCell.updateTreeTableRow(paramTreeTableRow);
/*     */   }
/*     */ 
/*     */   
/*     */   protected TreeTableColumn<T, ?> getTableColumn(TreeTableCell<T, ?> paramTreeTableCell) {
/* 329 */     return paramTreeTableCell.getTableColumn();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ObjectProperty<Node> graphicProperty() {
/* 334 */     TreeTableRow<T> treeTableRow = getSkinnable();
/* 335 */     if (treeTableRow == null) return null; 
/* 336 */     if (this.treeItem == null) return null;
/*     */     
/* 338 */     return this.treeItem.graphicProperty();
/*     */   }
/*     */   
/*     */   private void updateTreeItem() {
/* 342 */     if (this.treeItem != null) {
/* 343 */       this.treeItem.graphicProperty().removeListener(this.graphicListener);
/*     */     }
/* 345 */     this.treeItem = getSkinnable().getTreeItem();
/* 346 */     if (this.treeItem != null) {
/* 347 */       this.treeItem.graphicProperty().addListener(this.graphicListener);
/*     */     }
/*     */   }
/*     */   
/*     */   private TreeTableView<T> getTreeTableView() {
/* 352 */     return getSkinnable().getTreeTableView();
/*     */   }
/*     */   
/*     */   private void updateDisclosureNodeAndGraphic() {
/* 356 */     if (getSkinnable().isEmpty()) {
/* 357 */       getChildren().remove(this.graphic);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 362 */     ObjectProperty<Node> objectProperty = graphicProperty();
/* 363 */     Node node1 = (objectProperty == null) ? null : objectProperty.get();
/* 364 */     if (node1 != null) {
/*     */       
/* 366 */       if (node1 != this.graphic) {
/* 367 */         getChildren().remove(this.graphic);
/*     */       }
/*     */       
/* 370 */       if (!getChildren().contains(node1)) {
/* 371 */         getChildren().add(node1);
/* 372 */         this.graphic = node1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 377 */     Node node2 = getSkinnable().getDisclosureNode();
/* 378 */     if (node2 != null) {
/* 379 */       boolean bool = (this.treeItem != null && !this.treeItem.isLeaf()) ? true : false;
/* 380 */       node2.setVisible(bool);
/*     */       
/* 382 */       if (!bool) {
/* 383 */         getChildren().remove(node2);
/* 384 */       } else if (node2.getParent() == null) {
/* 385 */         getChildren().add(node2);
/* 386 */         node2.toFront();
/*     */       } else {
/* 388 */         node2.toBack();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 393 */       if (node2.getScene() != null) {
/* 394 */         node2.applyCss();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateTableViewSkin() {
/* 400 */     TreeTableView<T> treeTableView = getSkinnable().getTreeTableView();
/* 401 */     if (treeTableView != null && treeTableView.getSkin() instanceof TreeTableViewSkin) {
/* 402 */       this.treeTableViewSkin = (TreeTableViewSkin)treeTableView.getSkin();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StyleableProperties
/*     */   {
/* 415 */     private static final CssMetaData<TreeTableRow<?>, Number> INDENT = new CssMetaData<TreeTableRow<?>, Number>("-fx-indent", 
/*     */         
/* 417 */         SizeConverter.getInstance(), Double.valueOf(10.0D))
/*     */       {
/*     */         public boolean isSettable(TreeTableRow<?> param2TreeTableRow) {
/* 420 */           DoubleProperty doubleProperty = ((TreeTableRowSkin)param2TreeTableRow.getSkin()).indentProperty();
/* 421 */           return (doubleProperty == null || !doubleProperty.isBound());
/*     */         }
/*     */         
/*     */         public StyleableProperty<Number> getStyleableProperty(TreeTableRow<?> param2TreeTableRow) {
/* 425 */           TreeTableRowSkin treeTableRowSkin = (TreeTableRowSkin)param2TreeTableRow.getSkin();
/* 426 */           return (StyleableProperty<Number>)treeTableRowSkin.indentProperty();
/*     */         }
/*     */       };
/*     */     
/*     */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */     
/*     */     static {
/* 433 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(CellSkinBase.getClassCssMetaData());
/* 434 */       arrayList.add(INDENT);
/* 435 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/* 446 */     return StyleableProperties.STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData()
/*     */   {
/* 453 */     return getClassCssMetaData(); } protected Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) { ArrayList<TreeTableCell> arrayList; int i; TreeTableView.TreeTableViewFocusModel<T> treeTableViewFocusModel;
/*     */     int j;
/*     */     TreeTableColumn<T, ?> treeTableColumn1;
/*     */     TreeTablePosition<T, ?> treeTablePosition;
/*     */     Iterator<TreeTablePosition> iterator;
/*     */     TreeTableColumn<T, ?> treeTableColumn2;
/* 459 */     TreeTableView<T> treeTableView = getSkinnable().getTreeTableView();
/* 460 */     switch (paramAccessibleAttribute) {
/*     */ 
/*     */       
/*     */       case SELECTED_ITEMS:
/* 464 */         arrayList = new ArrayList();
/* 465 */         j = getSkinnable().getIndex();
/* 466 */         iterator = treeTableView.getSelectionModel().getSelectedCells().iterator(); if (iterator.hasNext()) { TreeTablePosition treeTablePosition1 = iterator.next();
/* 467 */           if (treeTablePosition1.getRow() == j) {
/* 468 */             TreeTableColumn<T, ?> treeTableColumn = treeTablePosition1.getTableColumn();
/* 469 */             if (treeTableColumn == null)
/*     */             {
/* 471 */               treeTableColumn = treeTableView.getVisibleLeafColumn(0);
/*     */             }
/* 473 */             TreeTableCell treeTableCell = ((Reference<TreeTableCell>)this.cellsMap.get(treeTableColumn)).get();
/* 474 */             if (treeTableCell != null) arrayList.add(treeTableCell); 
/*     */           } 
/* 476 */           return FXCollections.observableArrayList(arrayList); }
/*     */       
/*     */       
/*     */       case CELL_AT_ROW_COLUMN:
/* 480 */         i = ((Integer)paramVarArgs[1]).intValue();
/* 481 */         treeTableColumn1 = treeTableView.getVisibleLeafColumn(i);
/* 482 */         if (this.cellsMap.containsKey(treeTableColumn1)) {
/* 483 */           return ((Reference)this.cellsMap.get(treeTableColumn1)).get();
/*     */         }
/* 485 */         return null;
/*     */       
/*     */       case FOCUS_ITEM:
/* 488 */         treeTableViewFocusModel = treeTableView.getFocusModel();
/* 489 */         treeTablePosition = treeTableViewFocusModel.getFocusedCell();
/* 490 */         treeTableColumn2 = treeTablePosition.getTableColumn();
/* 491 */         if (treeTableColumn2 == null)
/*     */         {
/* 493 */           treeTableColumn2 = treeTableView.getVisibleLeafColumn(0);
/*     */         }
/* 495 */         if (this.cellsMap.containsKey(treeTableColumn2)) {
/* 496 */           return ((Reference)this.cellsMap.get(treeTableColumn2)).get();
/*     */         }
/* 498 */         return null;
/*     */     } 
/* 500 */     return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs); }
/*     */ 
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\TreeTableRowSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */