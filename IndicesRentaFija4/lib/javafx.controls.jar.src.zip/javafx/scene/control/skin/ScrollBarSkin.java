/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.Properties;
/*     */ import com.sun.javafx.scene.control.behavior.ScrollBarBehavior;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.util.function.Consumer;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ScrollBar;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.input.ScrollEvent;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.StackPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrollBarSkin
/*     */   extends SkinBase<ScrollBar>
/*     */ {
/*     */   private final ScrollBarBehavior behavior;
/*     */   private StackPane thumb;
/*     */   private StackPane trackBackground;
/*     */   private StackPane track;
/*     */   private EndButton incButton;
/*     */   private EndButton decButton;
/*     */   private double trackLength;
/*     */   private double thumbLength;
/*     */   private double preDragThumbPos;
/*     */   private Point2D dragStart;
/*     */   private double trackPos;
/*     */   
/*     */   public ScrollBarSkin(ScrollBar paramScrollBar) {
/*  97 */     super(paramScrollBar);
/*     */ 
/*     */     
/* 100 */     this.behavior = new ScrollBarBehavior(paramScrollBar);
/*     */ 
/*     */     
/* 103 */     initialize();
/* 104 */     getSkinnable().requestLayout();
/*     */ 
/*     */     
/* 107 */     Consumer consumer = paramObservableValue -> {
/*     */         positionThumb();
/*     */         getSkinnable().requestLayout();
/*     */       };
/* 111 */     registerChangeListener(paramScrollBar.minProperty(), consumer);
/* 112 */     registerChangeListener(paramScrollBar.maxProperty(), consumer);
/* 113 */     registerChangeListener(paramScrollBar.visibleAmountProperty(), consumer);
/* 114 */     registerChangeListener(paramScrollBar.valueProperty(), paramObservableValue -> positionThumb());
/* 115 */     registerChangeListener(paramScrollBar.orientationProperty(), paramObservableValue -> getSkinnable().requestLayout());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 128 */     super.dispose();
/*     */     
/* 130 */     if (this.behavior != null) {
/* 131 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*     */     double d;
/* 139 */     ScrollBar scrollBar = getSkinnable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     if (scrollBar.getMax() > scrollBar.getMin()) {
/* 147 */       d = scrollBar.getVisibleAmount() / (scrollBar.getMax() - scrollBar.getMin());
/*     */     } else {
/*     */       
/* 150 */       d = 1.0D;
/*     */     } 
/*     */     
/* 153 */     if (scrollBar.getOrientation() == Orientation.VERTICAL) {
/* 154 */       if (!Properties.IS_TOUCH_SUPPORTED) {
/* 155 */         double d1 = snapSizeY(this.decButton.prefHeight(-1.0D));
/* 156 */         double d2 = snapSizeY(this.incButton.prefHeight(-1.0D));
/*     */         
/* 158 */         this.decButton.resize(paramDouble3, d1);
/* 159 */         this.incButton.resize(paramDouble3, d2);
/*     */         
/* 161 */         this.trackLength = snapSizeY(paramDouble4 - d1 + d2);
/* 162 */         this.thumbLength = snapSizeY(Utils.clamp(minThumbLength(), this.trackLength * d, this.trackLength));
/*     */         
/* 164 */         this.trackBackground.resizeRelocate(snapPositionX(paramDouble1), snapPositionY(paramDouble2), paramDouble3, this.trackLength + d1 + d2);
/* 165 */         this.decButton.relocate(snapPositionX(paramDouble1), snapPositionY(paramDouble2));
/* 166 */         this.incButton.relocate(snapPositionX(paramDouble1), snapPositionY(paramDouble2 + paramDouble4 - d2));
/* 167 */         this.track.resizeRelocate(snapPositionX(paramDouble1), snapPositionY(paramDouble2 + d1), paramDouble3, this.trackLength);
/* 168 */         this.thumb.resize(snapSizeX((paramDouble1 >= 0.0D) ? paramDouble3 : (paramDouble3 + paramDouble1)), this.thumbLength);
/* 169 */         positionThumb();
/*     */       } else {
/*     */         
/* 172 */         this.trackLength = snapSizeY(paramDouble4);
/* 173 */         this.thumbLength = snapSizeY(Utils.clamp(minThumbLength(), this.trackLength * d, this.trackLength));
/*     */         
/* 175 */         this.track.resizeRelocate(snapPositionX(paramDouble1), snapPositionY(paramDouble2), paramDouble3, this.trackLength);
/* 176 */         this.thumb.resize(snapSizeX((paramDouble1 >= 0.0D) ? paramDouble3 : (paramDouble3 + paramDouble1)), this.thumbLength);
/* 177 */         positionThumb();
/*     */       } 
/*     */     } else {
/* 180 */       if (!Properties.IS_TOUCH_SUPPORTED) {
/* 181 */         double d1 = snapSizeX(this.decButton.prefWidth(-1.0D));
/* 182 */         double d2 = snapSizeX(this.incButton.prefWidth(-1.0D));
/*     */         
/* 184 */         this.decButton.resize(d1, paramDouble4);
/* 185 */         this.incButton.resize(d2, paramDouble4);
/*     */         
/* 187 */         this.trackLength = snapSizeX(paramDouble3 - d1 + d2);
/* 188 */         this.thumbLength = snapSizeX(Utils.clamp(minThumbLength(), this.trackLength * d, this.trackLength));
/*     */         
/* 190 */         this.trackBackground.resizeRelocate(snapPositionX(paramDouble1), snapPositionY(paramDouble2), this.trackLength + d1 + d2, paramDouble4);
/* 191 */         this.decButton.relocate(snapPositionX(paramDouble1), snapPositionY(paramDouble2));
/* 192 */         this.incButton.relocate(snapPositionX(paramDouble1 + paramDouble3 - d2), snapPositionY(paramDouble2));
/* 193 */         this.track.resizeRelocate(snapPositionX(paramDouble1 + d1), snapPositionY(paramDouble2), this.trackLength, paramDouble4);
/* 194 */         this.thumb.resize(this.thumbLength, snapSizeY((paramDouble2 >= 0.0D) ? paramDouble4 : (paramDouble4 + paramDouble2)));
/* 195 */         positionThumb();
/*     */       } else {
/*     */         
/* 198 */         this.trackLength = snapSizeX(paramDouble3);
/* 199 */         this.thumbLength = snapSizeX(Utils.clamp(minThumbLength(), this.trackLength * d, this.trackLength));
/*     */         
/* 201 */         this.track.resizeRelocate(snapPositionX(paramDouble1), snapPositionY(paramDouble2), this.trackLength, paramDouble4);
/* 202 */         this.thumb.resize(this.thumbLength, snapSizeY((paramDouble2 >= 0.0D) ? paramDouble4 : (paramDouble4 + paramDouble2)));
/* 203 */         positionThumb();
/*     */       } 
/*     */       
/* 206 */       scrollBar.resize(snapSizeX(scrollBar.getWidth()), snapSizeY(scrollBar.getHeight()));
/*     */     } 
/*     */ 
/*     */     
/* 210 */     if ((scrollBar.getOrientation() == Orientation.VERTICAL && paramDouble4 >= computeMinHeight(-1.0D, (int)paramDouble2, snappedRightInset(), snappedBottomInset(), (int)paramDouble1) - paramDouble2 + snappedBottomInset()) || (scrollBar
/* 211 */       .getOrientation() == Orientation.HORIZONTAL && paramDouble3 >= computeMinWidth(-1.0D, (int)paramDouble2, snappedRightInset(), snappedBottomInset(), (int)paramDouble1) - paramDouble1 + snappedRightInset())) {
/* 212 */       this.trackBackground.setVisible(true);
/* 213 */       this.track.setVisible(true);
/* 214 */       this.thumb.setVisible(true);
/* 215 */       if (!Properties.IS_TOUCH_SUPPORTED) {
/* 216 */         this.incButton.setVisible(true);
/* 217 */         this.decButton.setVisible(true);
/*     */       } 
/*     */     } else {
/*     */       
/* 221 */       this.trackBackground.setVisible(false);
/* 222 */       this.track.setVisible(false);
/* 223 */       this.thumb.setVisible(false);
/*     */       
/* 225 */       if (!Properties.IS_TOUCH_SUPPORTED) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 230 */         if (paramDouble4 >= this.decButton.computeMinWidth(-1.0D)) {
/* 231 */           this.decButton.setVisible(true);
/*     */         } else {
/*     */           
/* 234 */           this.decButton.setVisible(false);
/*     */         } 
/* 236 */         if (paramDouble4 >= this.incButton.computeMinWidth(-1.0D)) {
/* 237 */           this.incButton.setVisible(true);
/*     */         } else {
/*     */           
/* 240 */           this.incButton.setVisible(false);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 254 */     if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 255 */       return getBreadth();
/*     */     }
/* 257 */     if (!Properties.IS_TOUCH_SUPPORTED) {
/* 258 */       return this.decButton.minWidth(-1.0D) + this.incButton.minWidth(-1.0D) + minTrackLength() + paramDouble5 + paramDouble3;
/*     */     }
/* 260 */     return minTrackLength() + paramDouble5 + paramDouble3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computeMinHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 267 */     if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 268 */       if (!Properties.IS_TOUCH_SUPPORTED) {
/* 269 */         return this.decButton.minHeight(-1.0D) + this.incButton.minHeight(-1.0D) + minTrackLength() + paramDouble2 + paramDouble4;
/*     */       }
/* 271 */       return minTrackLength() + paramDouble2 + paramDouble4;
/*     */     } 
/*     */     
/* 274 */     return getBreadth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 287 */     ScrollBar scrollBar = getSkinnable();
/* 288 */     return (scrollBar.getOrientation() == Orientation.VERTICAL) ? getBreadth() : (100.0D + paramDouble5 + paramDouble3);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 293 */     ScrollBar scrollBar = getSkinnable();
/* 294 */     return (scrollBar.getOrientation() == Orientation.VERTICAL) ? (100.0D + paramDouble2 + paramDouble4) : getBreadth();
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 299 */     ScrollBar scrollBar = getSkinnable();
/* 300 */     return (scrollBar.getOrientation() == Orientation.VERTICAL) ? scrollBar.prefWidth(-1.0D) : Double.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected double computeMaxHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/* 305 */     ScrollBar scrollBar = getSkinnable();
/* 306 */     return (scrollBar.getOrientation() == Orientation.VERTICAL) ? Double.MAX_VALUE : scrollBar.prefHeight(-1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 323 */     this.track = new StackPane();
/* 324 */     this.track.getStyleClass().setAll(new String[] { "track" });
/*     */     
/* 326 */     this.trackBackground = new StackPane();
/* 327 */     this.trackBackground.getStyleClass().setAll(new String[] { "track-background" });
/*     */     
/* 329 */     this.thumb = new StackPane()
/*     */       {
/*     */         public Object queryAccessibleAttribute(AccessibleAttribute param1AccessibleAttribute, Object... param1VarArgs) {
/* 332 */           switch (param1AccessibleAttribute) { case FIRE:
/* 333 */               return Double.valueOf(ScrollBarSkin.this.getSkinnable().getValue()); }
/* 334 */            return super.queryAccessibleAttribute(param1AccessibleAttribute, param1VarArgs);
/*     */         }
/*     */       };
/*     */     
/* 338 */     this.thumb.getStyleClass().setAll(new String[] { "thumb" });
/* 339 */     this.thumb.setAccessibleRole(AccessibleRole.THUMB);
/*     */ 
/*     */     
/* 342 */     if (!Properties.IS_TOUCH_SUPPORTED) {
/*     */       
/* 344 */       this.incButton = new EndButton("increment-button", "increment-arrow")
/*     */         {
/*     */           public void executeAccessibleAction(AccessibleAction param1AccessibleAction, Object... param1VarArgs) {
/* 347 */             switch (param1AccessibleAction) {
/*     */               case FIRE:
/* 349 */                 ScrollBarSkin.this.getSkinnable().increment(); return;
/*     */             } 
/* 351 */             super.executeAccessibleAction(param1AccessibleAction, param1VarArgs);
/*     */           }
/*     */         };
/*     */       
/* 355 */       this.incButton.setAccessibleRole(AccessibleRole.INCREMENT_BUTTON);
/* 356 */       this.incButton.setOnMousePressed(paramMouseEvent -> {
/*     */             if (!this.thumb.isVisible() || this.trackLength > this.thumbLength) {
/*     */               this.behavior.incButtonPressed();
/*     */             }
/*     */ 
/*     */             
/*     */             paramMouseEvent.consume();
/*     */           });
/*     */       
/* 365 */       this.incButton.setOnMouseReleased(paramMouseEvent -> {
/*     */             if (!this.thumb.isVisible() || this.trackLength > this.thumbLength) {
/*     */               this.behavior.incButtonReleased();
/*     */             }
/*     */ 
/*     */             
/*     */             paramMouseEvent.consume();
/*     */           });
/*     */ 
/*     */       
/* 375 */       this.decButton = new EndButton("decrement-button", "decrement-arrow")
/*     */         {
/*     */           public void executeAccessibleAction(AccessibleAction param1AccessibleAction, Object... param1VarArgs) {
/* 378 */             switch (param1AccessibleAction) {
/*     */               case FIRE:
/* 380 */                 ScrollBarSkin.this.getSkinnable().decrement(); return;
/*     */             } 
/* 382 */             super.executeAccessibleAction(param1AccessibleAction, param1VarArgs);
/*     */           }
/*     */         };
/*     */       
/* 386 */       this.decButton.setAccessibleRole(AccessibleRole.DECREMENT_BUTTON);
/* 387 */       this.decButton.setOnMousePressed(paramMouseEvent -> {
/*     */             if (!this.thumb.isVisible() || this.trackLength > this.thumbLength) {
/*     */               this.behavior.decButtonPressed();
/*     */             }
/*     */ 
/*     */             
/*     */             paramMouseEvent.consume();
/*     */           });
/*     */       
/* 396 */       this.decButton.setOnMouseReleased(paramMouseEvent -> {
/*     */             if (!this.thumb.isVisible() || this.trackLength > this.thumbLength) {
/*     */               this.behavior.decButtonReleased();
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             paramMouseEvent.consume();
/*     */           });
/*     */     } 
/*     */ 
/*     */     
/* 408 */     this.track.setOnMousePressed(paramMouseEvent -> {
/*     */           if (!this.thumb.isPressed() && paramMouseEvent.getButton() == MouseButton.PRIMARY) {
/*     */             if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/*     */               if (this.trackLength != 0.0D) {
/*     */                 this.behavior.trackPress(paramMouseEvent.getY() / this.trackLength);
/*     */                 
/*     */                 paramMouseEvent.consume();
/*     */               } 
/*     */             } else if (this.trackLength != 0.0D) {
/*     */               this.behavior.trackPress(paramMouseEvent.getX() / this.trackLength);
/*     */               
/*     */               paramMouseEvent.consume();
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 424 */     this.track.setOnMouseReleased(paramMouseEvent -> {
/*     */           this.behavior.trackRelease();
/*     */           
/*     */           paramMouseEvent.consume();
/*     */         });
/* 429 */     this.thumb.setOnMousePressed(paramMouseEvent -> {
/*     */           if (paramMouseEvent.isSynthesized()) {
/*     */             paramMouseEvent.consume();
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/*     */           if (getSkinnable().getMax() > getSkinnable().getMin()) {
/*     */             this.dragStart = this.thumb.localToParent(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */             
/*     */             double d = Utils.clamp(getSkinnable().getMin(), getSkinnable().getValue(), getSkinnable().getMax());
/*     */             
/*     */             this.preDragThumbPos = (d - getSkinnable().getMin()) / (getSkinnable().getMax() - getSkinnable().getMin());
/*     */             
/*     */             paramMouseEvent.consume();
/*     */           } 
/*     */         });
/*     */     
/* 447 */     this.thumb.setOnMouseDragged(paramMouseEvent -> {
/*     */           if (paramMouseEvent.isSynthesized()) {
/*     */             paramMouseEvent.consume();
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */ 
/*     */           
/*     */           if (getSkinnable().getMax() > getSkinnable().getMin()) {
/*     */             if (this.trackLength > this.thumbLength) {
/*     */               Point2D point2D = this.thumb.localToParent(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */ 
/*     */               
/*     */               if (this.dragStart == null) {
/*     */                 this.dragStart = this.thumb.localToParent(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */               }
/*     */               
/*     */               double d = (getSkinnable().getOrientation() == Orientation.VERTICAL) ? (point2D.getY() - this.dragStart.getY()) : (point2D.getX() - this.dragStart.getX());
/*     */               
/*     */               this.behavior.thumbDragged(this.preDragThumbPos + d / (this.trackLength - this.thumbLength));
/*     */             } 
/*     */             
/*     */             paramMouseEvent.consume();
/*     */           } 
/*     */         });
/*     */     
/* 474 */     this.thumb.setOnScrollStarted(paramScrollEvent -> {
/*     */           if (paramScrollEvent.isDirect()) {
/*     */             if (getSkinnable().getMax() > getSkinnable().getMin()) {
/*     */               this.dragStart = this.thumb.localToParent(paramScrollEvent.getX(), paramScrollEvent.getY());
/*     */               
/*     */               double d = Utils.clamp(getSkinnable().getMin(), getSkinnable().getValue(), getSkinnable().getMax());
/*     */               
/*     */               this.preDragThumbPos = (d - getSkinnable().getMin()) / (getSkinnable().getMax() - getSkinnable().getMin());
/*     */               
/*     */               paramScrollEvent.consume();
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 488 */     this.thumb.setOnScroll(paramScrollEvent -> {
/*     */           if (paramScrollEvent.isDirect()) {
/*     */             if (getSkinnable().getMax() > getSkinnable().getMin()) {
/*     */               if (this.trackLength > this.thumbLength) {
/*     */                 Point2D point2D = this.thumb.localToParent(paramScrollEvent.getX(), paramScrollEvent.getY());
/*     */ 
/*     */                 
/*     */                 if (this.dragStart == null) {
/*     */                   this.dragStart = this.thumb.localToParent(paramScrollEvent.getX(), paramScrollEvent.getY());
/*     */                 }
/*     */ 
/*     */                 
/*     */                 double d = (getSkinnable().getOrientation() == Orientation.VERTICAL) ? (point2D.getY() - this.dragStart.getY()) : (point2D.getX() - this.dragStart.getX());
/*     */ 
/*     */                 
/*     */                 this.behavior.thumbDragged(this.preDragThumbPos + d / (this.trackLength - this.thumbLength));
/*     */               } 
/*     */ 
/*     */               
/*     */               paramScrollEvent.consume();
/*     */               
/*     */               return;
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 514 */     getSkinnable().addEventHandler(ScrollEvent.SCROLL, paramScrollEvent -> {
/*     */           if (this.trackLength > this.thumbLength) {
/*     */             double d1 = paramScrollEvent.getDeltaX();
/*     */ 
/*     */ 
/*     */             
/*     */             double d2 = paramScrollEvent.getDeltaY();
/*     */ 
/*     */ 
/*     */             
/*     */             d1 = (Math.abs(d1) < Math.abs(d2)) ? d2 : d1;
/*     */ 
/*     */ 
/*     */             
/*     */             ScrollBar scrollBar = getSkinnable();
/*     */ 
/*     */ 
/*     */             
/*     */             double d3 = (getSkinnable().getOrientation() == Orientation.VERTICAL) ? d2 : d1;
/*     */ 
/*     */ 
/*     */             
/*     */             if (paramScrollEvent.isDirect()) {
/*     */               if (this.trackLength > this.thumbLength) {
/*     */                 this.behavior.thumbDragged(((getSkinnable().getOrientation() == Orientation.VERTICAL) ? paramScrollEvent.getY() : paramScrollEvent.getX()) / this.trackLength);
/*     */ 
/*     */ 
/*     */                 
/*     */                 paramScrollEvent.consume();
/*     */               } 
/*     */             } else if (d3 > 0.0D && scrollBar.getValue() > scrollBar.getMin()) {
/*     */               scrollBar.decrement();
/*     */ 
/*     */ 
/*     */               
/*     */               paramScrollEvent.consume();
/*     */             } else if (d3 < 0.0D && scrollBar.getValue() < scrollBar.getMax()) {
/*     */               scrollBar.increment();
/*     */ 
/*     */ 
/*     */               
/*     */               paramScrollEvent.consume();
/*     */             } 
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/* 561 */     getChildren().clear();
/* 562 */     if (!Properties.IS_TOUCH_SUPPORTED) {
/* 563 */       getChildren().addAll(new Node[] { this.trackBackground, this.incButton, this.decButton, this.track, this.thumb });
/*     */     } else {
/*     */       
/* 566 */       getChildren().addAll(new Node[] { this.track, this.thumb });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double getBreadth() {
/* 579 */     if (!Properties.IS_TOUCH_SUPPORTED) {
/* 580 */       if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 581 */         return Math.max(this.decButton.prefWidth(-1.0D), this.incButton.prefWidth(-1.0D)) + snappedLeftInset() + snappedRightInset();
/*     */       }
/* 583 */       return Math.max(this.decButton.prefHeight(-1.0D), this.incButton.prefHeight(-1.0D)) + snappedTopInset() + snappedBottomInset();
/*     */     } 
/*     */ 
/*     */     
/* 587 */     if (getSkinnable().getOrientation() == Orientation.VERTICAL) {
/* 588 */       return Math.max(8.0D, 8.0D) + snappedLeftInset() + snappedRightInset();
/*     */     }
/* 590 */     return Math.max(8.0D, 8.0D) + snappedTopInset() + snappedBottomInset();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   double minThumbLength() {
/* 596 */     return 1.5D * getBreadth();
/*     */   }
/*     */   
/*     */   double minTrackLength() {
/* 600 */     return 2.0D * getBreadth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void positionThumb() {
/* 607 */     ScrollBar scrollBar = getSkinnable();
/* 608 */     double d = Utils.clamp(scrollBar.getMin(), scrollBar.getValue(), scrollBar.getMax());
/* 609 */     this.trackPos = (scrollBar.getMax() - scrollBar.getMin() > 0.0D) ? ((this.trackLength - this.thumbLength) * (d - scrollBar.getMin()) / (scrollBar.getMax() - scrollBar.getMin())) : 0.0D;
/*     */     
/* 611 */     if (!Properties.IS_TOUCH_SUPPORTED) {
/* 612 */       if (scrollBar.getOrientation() == Orientation.VERTICAL) {
/* 613 */         this.trackPos += this.decButton.prefHeight(-1.0D);
/*     */       } else {
/* 615 */         this.trackPos += this.decButton.prefWidth(-1.0D);
/*     */       } 
/*     */     }
/*     */     
/* 619 */     this.thumb.setTranslateX(snapPositionX((scrollBar.getOrientation() == Orientation.VERTICAL) ? snappedLeftInset() : (this.trackPos + snappedLeftInset())));
/* 620 */     this.thumb.setTranslateY(snapPositionY((scrollBar.getOrientation() == Orientation.VERTICAL) ? (this.trackPos + snappedTopInset()) : snappedTopInset()));
/*     */   }
/*     */   
/*     */   private Node getThumb() {
/* 624 */     return this.thumb;
/*     */   }
/*     */   
/*     */   private Node getTrack() {
/* 628 */     return this.track;
/*     */   }
/*     */   
/*     */   private Node getIncrementButton() {
/* 632 */     return this.incButton;
/*     */   }
/*     */   
/*     */   private Node getDecrementButton() {
/* 636 */     return this.decButton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EndButton
/*     */     extends Region
/*     */   {
/*     */     private Region arrow;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private EndButton(String param1String1, String param1String2) {
/* 651 */       getStyleClass().setAll(new String[] { param1String1 });
/* 652 */       this.arrow = new Region();
/* 653 */       this.arrow.getStyleClass().setAll(new String[] { param1String2 });
/* 654 */       getChildren().setAll(new Node[] { this.arrow });
/* 655 */       requestLayout();
/*     */     }
/*     */     
/*     */     protected void layoutChildren() {
/* 659 */       double d1 = snappedTopInset();
/* 660 */       double d2 = snappedLeftInset();
/* 661 */       double d3 = snappedBottomInset();
/* 662 */       double d4 = snappedRightInset();
/* 663 */       double d5 = snapSizeX(this.arrow.prefWidth(-1.0D));
/* 664 */       double d6 = snapSizeY(this.arrow.prefHeight(-1.0D));
/* 665 */       double d7 = snapPositionY((getHeight() - d1 + d3 + d6) / 2.0D);
/* 666 */       double d8 = snapPositionX((getWidth() - d2 + d4 + d5) / 2.0D);
/* 667 */       this.arrow.resizeRelocate(d8 + d2, d7 + d1, d5, d6);
/*     */     }
/*     */     
/*     */     protected double computeMinHeight(double param1Double) {
/* 671 */       return prefHeight(-1.0D);
/*     */     }
/*     */     
/*     */     protected double computeMinWidth(double param1Double) {
/* 675 */       return prefWidth(-1.0D);
/*     */     }
/*     */     
/*     */     protected double computePrefWidth(double param1Double) {
/* 679 */       double d1 = snappedLeftInset();
/* 680 */       double d2 = snappedRightInset();
/* 681 */       double d3 = snapSizeX(this.arrow.prefWidth(-1.0D));
/* 682 */       return d1 + d3 + d2;
/*     */     }
/*     */     
/*     */     protected double computePrefHeight(double param1Double) {
/* 686 */       double d1 = snappedTopInset();
/* 687 */       double d2 = snappedBottomInset();
/* 688 */       double d3 = snapSizeY(this.arrow.prefHeight(-1.0D));
/* 689 */       return d1 + d3 + d2;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ScrollBarSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */