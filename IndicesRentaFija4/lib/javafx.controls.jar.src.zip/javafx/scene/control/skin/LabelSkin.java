/*    */ package javafx.scene.control.skin;
/*    */ 
/*    */ import javafx.beans.value.ObservableValue;
/*    */ import javafx.scene.control.Label;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LabelSkin
/*    */   extends LabeledSkinBase<Label>
/*    */ {
/*    */   public LabelSkin(Label paramLabel) {
/* 53 */     super(paramLabel);
/*    */ 
/*    */     
/* 56 */     consumeMouseEvents(false);
/*    */     
/* 58 */     registerChangeListener(paramLabel.labelForProperty(), paramObservableValue -> mnemonicTargetChanged());
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\LabelSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */