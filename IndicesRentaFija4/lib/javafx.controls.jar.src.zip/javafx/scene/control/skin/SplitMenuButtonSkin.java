/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.behavior.MenuButtonBehaviorBase;
/*     */ import com.sun.javafx.scene.control.behavior.SplitMenuButtonBehavior;
/*     */ import javafx.scene.control.SplitMenuButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SplitMenuButtonSkin
/*     */   extends MenuButtonSkinBase<SplitMenuButton>
/*     */ {
/*     */   private final SplitMenuButtonBehavior behavior;
/*     */   
/*     */   public SplitMenuButtonSkin(SplitMenuButton paramSplitMenuButton) {
/*  71 */     super(paramSplitMenuButton);
/*     */ 
/*     */     
/*  74 */     this.behavior = new SplitMenuButtonBehavior(paramSplitMenuButton);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     this.behaveLikeButton = true;
/*     */ 
/*     */     
/*  84 */     this.arrowButton.addEventHandler(MouseEvent.ANY, paramMouseEvent -> paramMouseEvent.consume());
/*  85 */     this.arrowButton.setOnMousePressed(paramMouseEvent -> {
/*     */           getBehavior().mousePressed(paramMouseEvent, false);
/*     */           paramMouseEvent.consume();
/*     */         });
/*  89 */     this.arrowButton.setOnMouseReleased(paramMouseEvent -> {
/*     */           getBehavior().mouseReleased(paramMouseEvent, false);
/*     */           
/*     */           paramMouseEvent.consume();
/*     */         });
/*  94 */     this.label.setLabelFor(paramSplitMenuButton);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 107 */     super.dispose();
/*     */     
/* 109 */     if (this.behavior != null) {
/* 110 */       this.behavior.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SplitMenuButtonBehavior getBehavior() {
/* 123 */     return this.behavior;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\SplitMenuButtonSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */