/*     */ package javafx.scene.control.skin;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Button;
/*     */ import javafx.scene.control.ButtonBar;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.scene.layout.Pane;
/*     */ import javafx.scene.layout.Priority;
/*     */ import javafx.scene.layout.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ButtonBarSkin
/*     */   extends SkinBase<ButtonBar>
/*     */ {
/*     */   private static final double GAP_SIZE = 10.0D;
/*     */   private static final String CATEGORIZED_TYPES = "LRHEYNXBIACO";
/*     */   private static final double DO_NOT_CHANGE_SIZE = 1.7976931348623157E308D;
/*     */   private HBox layout;
/*     */   private InvalidationListener buttonDataListener = paramObservable -> layoutButtons();
/*     */   
/*     */   public ButtonBarSkin(ButtonBar paramButtonBar) {
/*  95 */     super(paramButtonBar);
/*     */     
/*  97 */     this.layout = new HBox(10.0D)
/*     */       {
/*     */         protected void layoutChildren() {
/* 100 */           ButtonBarSkin.this.resizeButtons();
/* 101 */           super.layoutChildren();
/*     */         }
/*     */       };
/* 104 */     this.layout.setAlignment(Pos.CENTER);
/* 105 */     this.layout.getStyleClass().add("container");
/* 106 */     getChildren().add(this.layout);
/*     */     
/* 108 */     layoutButtons();
/*     */     
/* 110 */     updateButtonListeners(paramButtonBar.getButtons(), true);
/* 111 */     paramButtonBar.getButtons().addListener(paramChange -> {
/*     */           while (paramChange.next()) {
/*     */             updateButtonListeners(paramChange.getRemoved(), false);
/*     */             
/*     */             updateButtonListeners(paramChange.getAddedSubList(), true);
/*     */           } 
/*     */           layoutButtons();
/*     */         });
/* 119 */     registerChangeListener(paramButtonBar.buttonOrderProperty(), paramObservableValue -> layoutButtons());
/* 120 */     registerChangeListener(paramButtonBar.buttonMinWidthProperty(), paramObservableValue -> resizeButtons());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateButtonListeners(List<? extends Node> paramList, boolean paramBoolean) {
/* 132 */     if (paramList != null) {
/* 133 */       for (Node node : paramList) {
/* 134 */         ObservableMap<Object, Object> observableMap = node.getProperties();
/* 135 */         if (observableMap.containsKey("javafx.scene.control.ButtonBar.ButtonData")) {
/* 136 */           ObjectProperty objectProperty = (ObjectProperty)observableMap.get("javafx.scene.control.ButtonBar.ButtonData");
/* 137 */           if (objectProperty != null) {
/* 138 */             if (paramBoolean) {
/* 139 */               objectProperty.addListener(this.buttonDataListener); continue;
/*     */             } 
/* 141 */             objectProperty.removeListener(this.buttonDataListener);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void layoutButtons() {
/* 150 */     ButtonBar buttonBar = getSkinnable();
/* 151 */     ObservableList<Node> observableList = buttonBar.getButtons();
/* 152 */     double d = buttonBar.getButtonMinWidth();
/*     */     
/* 154 */     String str = getSkinnable().getButtonOrder();
/*     */     
/* 156 */     this.layout.getChildren().clear();
/*     */ 
/*     */     
/* 159 */     if (str == null) {
/* 160 */       throw new IllegalStateException("ButtonBar buttonOrder string can not be null");
/*     */     }
/*     */     
/* 163 */     if (str.equals("")) {
/*     */ 
/*     */ 
/*     */       
/* 167 */       Spacer.DYNAMIC.add(this.layout, true);
/* 168 */       for (Node node : observableList) {
/* 169 */         sizeButton(node, d, Double.MAX_VALUE, Double.MAX_VALUE);
/* 170 */         this.layout.getChildren().add(node);
/* 171 */         HBox.setHgrow(node, Priority.NEVER);
/*     */       } 
/*     */     } else {
/* 174 */       doButtonOrderLayout(str);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void doButtonOrderLayout(String paramString) {
/* 179 */     ButtonBar buttonBar = getSkinnable();
/* 180 */     ObservableList<Node> observableList = buttonBar.getButtons();
/* 181 */     double d = buttonBar.getButtonMinWidth();
/* 182 */     Map<String, List<Node>> map = buildButtonMap(observableList);
/*     */     
/* 184 */     char[] arrayOfChar = paramString.toCharArray();
/*     */     
/* 186 */     byte b1 = 0;
/* 187 */     Spacer spacer = Spacer.NONE;
/*     */     byte b2;
/* 189 */     for (b2 = 0; b2 < arrayOfChar.length; b2++) {
/* 190 */       char c = arrayOfChar[b2];
/* 191 */       boolean bool1 = (b1 && b1 >= observableList.size() - 1) ? true : false;
/* 192 */       boolean bool2 = !this.layout.getChildren().isEmpty() ? true : false;
/* 193 */       if (c == '+') {
/* 194 */         spacer = spacer.replace(Spacer.DYNAMIC);
/* 195 */       } else if (c == '_' && bool2) {
/* 196 */         spacer = spacer.replace(Spacer.FIXED);
/*     */       } else {
/* 198 */         List list = map.get(String.valueOf(c).toUpperCase());
/* 199 */         if (list != null) {
/* 200 */           spacer.add(this.layout, bool1);
/*     */           
/* 202 */           for (Node node : list) {
/* 203 */             sizeButton(node, d, Double.MAX_VALUE, Double.MAX_VALUE);
/*     */             
/* 205 */             this.layout.getChildren().add(node);
/* 206 */             HBox.setHgrow(node, Priority.NEVER);
/* 207 */             b1++;
/*     */           } 
/* 209 */           spacer = spacer.replace(Spacer.NONE);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     b2 = 0;
/* 223 */     int i = observableList.size(); byte b3;
/* 224 */     for (b3 = 0; b3 < i; b3++) {
/* 225 */       Node node = observableList.get(b3);
/*     */       
/* 227 */       if (node instanceof Button && ((Button)node).isDefaultButton()) {
/* 228 */         node.requestFocus();
/* 229 */         b2 = 1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 233 */     if (b2 == 0) {
/* 234 */       for (b3 = 0; b3 < i; b3++) {
/* 235 */         Node node = observableList.get(b3);
/* 236 */         ButtonBar.ButtonData buttonData = ButtonBar.getButtonData(node);
/*     */         
/* 238 */         if (buttonData != null && buttonData.isDefaultButton()) {
/* 239 */           node.requestFocus();
/* 240 */           b2 = 1;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void resizeButtons() {
/* 248 */     ButtonBar buttonBar = getSkinnable();
/* 249 */     double d1 = buttonBar.getButtonMinWidth();
/* 250 */     ObservableList<Node> observableList = buttonBar.getButtons();
/*     */ 
/*     */     
/* 253 */     double d2 = d1;
/* 254 */     for (Node node : observableList) {
/* 255 */       if (ButtonBar.isButtonUniformSize(node)) {
/* 256 */         d2 = Math.max(node.prefWidth(-1.0D), d2);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 261 */     for (Node node : observableList) {
/* 262 */       if (ButtonBar.isButtonUniformSize(node)) {
/* 263 */         sizeButton(node, Double.MAX_VALUE, d2, Double.MAX_VALUE);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sizeButton(Node paramNode, double paramDouble1, double paramDouble2, double paramDouble3) {
/* 269 */     if (paramNode instanceof Region) {
/* 270 */       Region region = (Region)paramNode;
/*     */       
/* 272 */       if (paramDouble1 != Double.MAX_VALUE) {
/* 273 */         region.setMinWidth(paramDouble1);
/*     */       }
/* 275 */       if (paramDouble2 != Double.MAX_VALUE) {
/* 276 */         region.setPrefWidth(paramDouble2);
/*     */       }
/* 278 */       if (paramDouble3 != Double.MAX_VALUE) {
/* 279 */         region.setMaxWidth(paramDouble3);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getButtonType(Node paramNode) {
/* 285 */     ButtonBar.ButtonData buttonData = ButtonBar.getButtonData(paramNode);
/*     */     
/* 287 */     if (buttonData == null)
/*     */     {
/* 289 */       buttonData = ButtonBar.ButtonData.OTHER;
/*     */     }
/*     */     
/* 292 */     String str = buttonData.getTypeCode();
/* 293 */     str = (str.length() > 0) ? str.substring(0, 1) : "";
/* 294 */     return "LRHEYNXBIACO".contains(str.toUpperCase()) ? str : ButtonBar.ButtonData.OTHER.getTypeCode();
/*     */   }
/*     */   
/*     */   private Map<String, List<Node>> buildButtonMap(List<? extends Node> paramList) {
/* 298 */     HashMap<Object, Object> hashMap = new HashMap<>();
/* 299 */     for (Node node : paramList) {
/* 300 */       if (node == null)
/* 301 */         continue;  String str = getButtonType(node);
/* 302 */       List<Node> list = (List)hashMap.get(str);
/* 303 */       if (list == null) {
/* 304 */         list = new ArrayList();
/* 305 */         hashMap.put(str, list);
/*     */       } 
/* 307 */       list.add(node);
/*     */     } 
/* 309 */     return (Map)hashMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum Spacer
/*     */   {
/* 321 */     FIXED {
/*     */       protected Node create(boolean param2Boolean) {
/* 323 */         if (param2Boolean) return null; 
/* 324 */         Region region = new Region();
/* 325 */         ButtonBar.setButtonData(region, ButtonBar.ButtonData.SMALL_GAP);
/* 326 */         region.setMinWidth(10.0D);
/* 327 */         HBox.setHgrow(region, Priority.NEVER);
/* 328 */         return region;
/*     */       }
/*     */     },
/* 331 */     DYNAMIC {
/*     */       protected Node create(boolean param2Boolean) {
/* 333 */         Region region = new Region();
/* 334 */         ButtonBar.setButtonData(region, ButtonBar.ButtonData.BIG_GAP);
/* 335 */         region.setMinWidth(param2Boolean ? 0.0D : 10.0D);
/* 336 */         HBox.setHgrow(region, Priority.ALWAYS);
/* 337 */         return region;
/*     */       }
/*     */       
/*     */       public Spacer replace(Spacer param2Spacer) {
/* 341 */         return (FIXED == param2Spacer) ? this : param2Spacer;
/*     */       }
/*     */     },
/* 344 */     NONE;
/*     */     
/*     */     protected Node create(boolean param1Boolean) {
/* 347 */       return null;
/*     */     }
/*     */     
/*     */     public Spacer replace(Spacer param1Spacer) {
/* 351 */       return param1Spacer;
/*     */     }
/*     */     
/*     */     public void add(Pane param1Pane, boolean param1Boolean) {
/* 355 */       Node node = create(param1Boolean);
/* 356 */       if (node != null)
/* 357 */         param1Pane.getChildren().add(node); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\javafx\scene\control\skin\ButtonBarSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */