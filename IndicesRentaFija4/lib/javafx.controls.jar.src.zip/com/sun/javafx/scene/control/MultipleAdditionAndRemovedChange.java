/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipleAdditionAndRemovedChange<E>
/*     */   extends ListChangeListener.Change<E>
/*     */ {
/*  41 */   private static final int[] EMPTY_PERM = new int[0];
/*     */   
/*     */   private boolean invalid = true;
/*     */   
/*     */   private final List<E> addedElements;
/*     */   
/*     */   private final List<E> removedElements;
/*     */   private boolean iteratingThroughAdded = true;
/*     */   private boolean returnedRemovedElements = false;
/*  50 */   private int addedIndex = 0;
/*     */   
/*     */   private int from;
/*     */   private int to;
/*     */   
/*     */   public MultipleAdditionAndRemovedChange(List<E> paramList1, List<E> paramList2, ObservableList<E> paramObservableList) {
/*  56 */     super(paramObservableList);
/*  57 */     this.addedElements = paramList1;
/*  58 */     this.removedElements = paramList2;
/*     */   }
/*     */   
/*     */   public boolean next() {
/*  62 */     if (this.invalid) {
/*  63 */       this.invalid = false;
/*     */     }
/*     */ 
/*     */     
/*  67 */     if (this.addedIndex < this.addedElements.size()) {
/*  68 */       this.from = getList().indexOf(this.addedElements.get(this.addedIndex));
/*  69 */       this.to = this.from + 1;
/*     */       
/*  71 */       this.addedIndex++;
/*  72 */       for (byte b = 0; b + this.addedIndex < this.addedElements.size(); b++) {
/*     */ 
/*     */         
/*  75 */         E e = this.addedElements.get(b + this.addedIndex);
/*  76 */         if (e != getList().get(this.from + b)) {
/*  77 */           this.to = this.from + 1 + b;
/*  78 */           this.addedIndex += b;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*  83 */       return true;
/*  84 */     }  if (!this.returnedRemovedElements) {
/*  85 */       this.returnedRemovedElements = true;
/*  86 */       this.iteratingThroughAdded = false;
/*  87 */       this.from = 0;
/*  88 */       this.to = 0;
/*     */       
/*  90 */       return !this.removedElements.isEmpty();
/*     */     } 
/*     */     
/*  93 */     return false;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  97 */     this.invalid = true;
/*  98 */     this.from = 0;
/*  99 */     this.to = 0;
/* 100 */     this.addedIndex = 0;
/* 101 */     this.iteratingThroughAdded = true;
/* 102 */     this.returnedRemovedElements = false;
/*     */   }
/*     */   
/*     */   public int getFrom() {
/* 106 */     checkState();
/* 107 */     return this.from;
/*     */   }
/*     */   
/*     */   public int getTo() {
/* 111 */     checkState();
/* 112 */     return this.to;
/*     */   }
/*     */   
/*     */   public List<E> getRemoved() {
/* 116 */     return this.iteratingThroughAdded ? Collections.<E>emptyList() : this.removedElements;
/*     */   }
/*     */   
/*     */   protected int[] getPermutation() {
/* 120 */     return EMPTY_PERM;
/*     */   }
/*     */   
/*     */   public boolean wasAdded() {
/* 124 */     return (this.iteratingThroughAdded && !this.addedElements.isEmpty());
/*     */   }
/*     */   
/*     */   public boolean wasRemoved() {
/* 128 */     return (!this.iteratingThroughAdded && !this.removedElements.isEmpty());
/*     */   }
/*     */   
/*     */   private void checkState() {
/* 132 */     if (this.invalid)
/* 133 */       throw new IllegalStateException("Invalid Change state: next() must be called before inspecting the Change."); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\MultipleAdditionAndRemovedChange.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */