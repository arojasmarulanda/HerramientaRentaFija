/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import javafx.geometry.NodeOrientation;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BehaviorBase<N extends Node>
/*     */ {
/*     */   private final N node;
/*     */   private final List<InputMap.Mapping<?>> installedDefaultMappings;
/*     */   private final List<Runnable> childInputMapDisposalHandlers;
/*     */   
/*     */   public BehaviorBase(N paramN) {
/*  43 */     this.node = paramN;
/*  44 */     this.installedDefaultMappings = new ArrayList<>();
/*  45 */     this.childInputMapDisposalHandlers = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final N getNode() {
/*  51 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  62 */     for (InputMap.Mapping<?> mapping : this.installedDefaultMappings) {
/*  63 */       getInputMap().getMappings().remove(mapping);
/*     */     }
/*     */ 
/*     */     
/*  67 */     for (Runnable runnable : this.childInputMapDisposalHandlers) {
/*  68 */       runnable.run();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addDefaultMapping(List<InputMap.Mapping<?>> paramList) {
/*  78 */     addDefaultMapping(getInputMap(), (InputMap.Mapping<?>[])paramList.<InputMap.Mapping>toArray(new InputMap.Mapping[paramList.size()]));
/*     */   }
/*     */   
/*     */   protected void addDefaultMapping(InputMap.Mapping<?>... paramVarArgs) {
/*  82 */     addDefaultMapping(getInputMap(), paramVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addDefaultMapping(InputMap<N> paramInputMap, InputMap.Mapping<?>... paramVarArgs) {
/*  87 */     ArrayList arrayList = new ArrayList(paramInputMap.getMappings());
/*     */     
/*  89 */     for (InputMap.Mapping<?> mapping : paramVarArgs) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  97 */       if (!arrayList.contains(mapping)) {
/*     */         
/*  99 */         paramInputMap.getMappings().add(mapping);
/* 100 */         this.installedDefaultMappings.add(mapping);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   protected <T extends Node> void addDefaultChildMap(InputMap<T> paramInputMap1, InputMap<T> paramInputMap2) {
/* 105 */     paramInputMap1.getChildInputMaps().add(paramInputMap2);
/*     */     
/* 107 */     this.childInputMapDisposalHandlers.add(() -> paramInputMap1.getChildInputMaps().remove(paramInputMap2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputMap<N> createInputMap() {
/* 115 */     return new InputMap((Node)this.node);
/*     */   }
/*     */   
/*     */   protected void removeMapping(Object paramObject) {
/* 119 */     InputMap<N> inputMap = getInputMap();
/* 120 */     inputMap.lookupMapping(paramObject).ifPresent(paramMapping -> {
/*     */           paramInputMap.getMappings().remove(paramMapping);
/*     */           this.installedDefaultMappings.remove(paramMapping);
/*     */         });
/*     */   }
/*     */   
/*     */   void rtl(Node paramNode, Runnable paramRunnable1, Runnable paramRunnable2) {
/* 127 */     switch (paramNode.getEffectiveNodeOrientation()) { case RIGHT_TO_LEFT:
/* 128 */         paramRunnable1.run(); return; }
/* 129 */      paramRunnable2.run();
/*     */   }
/*     */ 
/*     */   
/*     */   <T> void rtl(Node paramNode, T paramT, Consumer<T> paramConsumer1, Consumer<T> paramConsumer2) {
/* 134 */     switch (paramNode.getEffectiveNodeOrientation()) { case RIGHT_TO_LEFT:
/* 135 */         paramConsumer1.accept(paramT); return; }
/* 136 */      paramConsumer2.accept(paramT);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isRTL(Node paramNode) {
/* 141 */     switch (paramNode.getEffectiveNodeOrientation()) { case RIGHT_TO_LEFT:
/* 142 */         return true; }
/* 143 */      return false;
/*     */   }
/*     */   
/*     */   public abstract InputMap<N> getInputMap();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\BehaviorBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */