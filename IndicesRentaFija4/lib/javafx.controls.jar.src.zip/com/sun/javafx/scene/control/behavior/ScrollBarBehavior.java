/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.Timeline;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.control.ScrollBar;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrollBarBehavior
/*     */   extends BehaviorBase<ScrollBar>
/*     */ {
/*     */   private final InputMap<ScrollBar> inputMap;
/*     */   Timeline timeline;
/*     */   
/*     */   public ScrollBarBehavior(ScrollBar paramScrollBar) {
/*  58 */     super(paramScrollBar);
/*     */ 
/*     */ 
/*     */     
/*  62 */     this.inputMap = createInputMap();
/*     */ 
/*     */     
/*  65 */     addDefaultMapping(this.inputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.HOME, KeyEvent.KEY_RELEASED, paramKeyEvent -> home()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.END, KeyEvent.KEY_RELEASED, paramKeyEvent -> end()) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     InputMap inputMap1 = new InputMap(paramScrollBar);
/*  72 */     inputMap1.setInterceptor(paramEvent -> (paramScrollBar.getOrientation() != Orientation.HORIZONTAL));
/*  73 */     inputMap1.getMappings().addAll(new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> rtl(paramScrollBar, this::incrementValue, this::decrementValue)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_LEFT, paramKeyEvent -> rtl(paramScrollBar, this::incrementValue, this::decrementValue)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> rtl(paramScrollBar, this::decrementValue, this::incrementValue)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_RIGHT, paramKeyEvent -> rtl(paramScrollBar, this::decrementValue, this::incrementValue)) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     addDefaultChildMap(this.inputMap, inputMap1);
/*     */     
/*  81 */     InputMap inputMap2 = new InputMap(paramScrollBar);
/*  82 */     inputMap2.setInterceptor(paramEvent -> (paramScrollBar.getOrientation() != Orientation.VERTICAL));
/*  83 */     inputMap2.getMappings().addAll(new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> decrementValue()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_UP, paramKeyEvent -> decrementValue()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> incrementValue()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_DOWN, paramKeyEvent -> incrementValue()) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     addDefaultChildMap(this.inputMap, inputMap2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputMap<ScrollBar> getInputMap() {
/* 100 */     return this.inputMap;
/*     */   }
/*     */   private void home() {
/* 103 */     getNode().setValue(getNode().getMin());
/*     */   }
/*     */   
/*     */   private void decrementValue() {
/* 107 */     getNode().adjustValue(0.0D);
/*     */   }
/*     */   
/*     */   private void end() {
/* 111 */     getNode().setValue(getNode().getMax());
/*     */   }
/*     */   
/*     */   private void incrementValue() {
/* 115 */     getNode().adjustValue(1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trackPress(double paramDouble) {
/* 145 */     if (this.timeline != null) {
/*     */       return;
/*     */     }
/*     */     
/* 149 */     ScrollBar scrollBar = getNode();
/* 150 */     if (!scrollBar.isFocused() && scrollBar.isFocusTraversable()) scrollBar.requestFocus(); 
/* 151 */     double d = paramDouble;
/* 152 */     boolean bool = (d > (scrollBar.getValue() - scrollBar.getMin()) / (scrollBar.getMax() - scrollBar.getMin())) ? true : false;
/* 153 */     this.timeline = new Timeline();
/* 154 */     this.timeline.setCycleCount(-1);
/*     */     
/* 156 */     EventHandler<ActionEvent> eventHandler = paramActionEvent -> {
/*     */         boolean bool = (paramDouble > (paramScrollBar.getValue() - paramScrollBar.getMin()) / (paramScrollBar.getMax() - paramScrollBar.getMin()));
/*     */ 
/*     */ 
/*     */         
/*     */         if (paramBoolean == bool) {
/*     */           paramScrollBar.adjustValue(paramDouble);
/*     */         } else {
/*     */           stopTimeline();
/*     */         } 
/*     */       };
/*     */ 
/*     */     
/* 169 */     KeyFrame keyFrame = new KeyFrame(Duration.millis(200.0D), eventHandler, new javafx.animation.KeyValue[0]);
/* 170 */     this.timeline.getKeyFrames().add(keyFrame);
/*     */     
/* 172 */     this.timeline.play();
/* 173 */     eventHandler.handle(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void trackRelease() {
/* 179 */     stopTimeline();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decButtonPressed() {
/* 187 */     ScrollBar scrollBar = getNode();
/* 188 */     if (!scrollBar.isFocused() && scrollBar.isFocusTraversable()) scrollBar.requestFocus(); 
/* 189 */     stopTimeline();
/* 190 */     this.timeline = new Timeline();
/* 191 */     this.timeline.setCycleCount(-1);
/*     */     
/* 193 */     EventHandler<ActionEvent> eventHandler = paramActionEvent -> {
/*     */         if (paramScrollBar.getValue() > paramScrollBar.getMin()) {
/*     */           paramScrollBar.decrement();
/*     */         } else {
/*     */           stopTimeline();
/*     */         } 
/*     */       };
/*     */ 
/*     */ 
/*     */     
/* 203 */     KeyFrame keyFrame = new KeyFrame(Duration.millis(200.0D), eventHandler, new javafx.animation.KeyValue[0]);
/* 204 */     this.timeline.getKeyFrames().add(keyFrame);
/*     */     
/* 206 */     this.timeline.play();
/* 207 */     eventHandler.handle(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void decButtonReleased() {
/* 213 */     stopTimeline();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incButtonPressed() {
/* 221 */     ScrollBar scrollBar = getNode();
/* 222 */     if (!scrollBar.isFocused() && scrollBar.isFocusTraversable()) scrollBar.requestFocus(); 
/* 223 */     stopTimeline();
/* 224 */     this.timeline = new Timeline();
/* 225 */     this.timeline.setCycleCount(-1);
/*     */     
/* 227 */     EventHandler<ActionEvent> eventHandler = paramActionEvent -> {
/*     */         if (paramScrollBar.getValue() < paramScrollBar.getMax()) {
/*     */           paramScrollBar.increment();
/*     */         } else {
/*     */           stopTimeline();
/*     */         } 
/*     */       };
/*     */ 
/*     */ 
/*     */     
/* 237 */     KeyFrame keyFrame = new KeyFrame(Duration.millis(200.0D), eventHandler, new javafx.animation.KeyValue[0]);
/* 238 */     this.timeline.getKeyFrames().add(keyFrame);
/*     */     
/* 240 */     this.timeline.play();
/* 241 */     eventHandler.handle(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void incButtonReleased() {
/* 247 */     stopTimeline();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void thumbDragged(double paramDouble) {
/* 260 */     ScrollBar scrollBar = getNode();
/*     */ 
/*     */     
/* 263 */     stopTimeline();
/*     */     
/* 265 */     if (!scrollBar.isFocused() && scrollBar.isFocusTraversable()) scrollBar.requestFocus(); 
/* 266 */     double d = paramDouble * (scrollBar.getMax() - scrollBar.getMin()) + scrollBar.getMin();
/* 267 */     if (!Double.isNaN(d)) {
/* 268 */       scrollBar.setValue(Utils.clamp(scrollBar.getMin(), d, scrollBar.getMax()));
/*     */     }
/*     */   }
/*     */   
/*     */   private void stopTimeline() {
/* 273 */     if (this.timeline != null) {
/* 274 */       this.timeline.stop();
/* 275 */       this.timeline = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ScrollBarBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */