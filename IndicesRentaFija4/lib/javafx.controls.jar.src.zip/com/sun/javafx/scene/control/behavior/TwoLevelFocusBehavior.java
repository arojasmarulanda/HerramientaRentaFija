/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventDispatchChain;
/*     */ import javafx.event.EventDispatcher;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.PopupControl;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TwoLevelFocusBehavior
/*     */ {
/*  57 */   Node tlNode = null;
/*  58 */   PopupControl tlPopup = null;
/*  59 */   EventDispatcher origEventDispatcher = null;
/*     */ 
/*     */   
/*     */   final EventDispatcher preemptiveEventDispatcher;
/*     */ 
/*     */   
/*     */   final EventDispatcher tlfEventDispatcher;
/*     */ 
/*     */   
/*     */   private final EventHandler<KeyEvent> keyEventListener;
/*     */ 
/*     */   
/*     */   final ChangeListener<Boolean> focusListener;
/*     */ 
/*     */   
/*     */   private final EventHandler<MouseEvent> mouseEventListener;
/*     */ 
/*     */   
/*     */   private boolean externalFocus;
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  82 */     this.tlNode.removeEventHandler(KeyEvent.ANY, this.keyEventListener);
/*  83 */     this.tlNode.removeEventHandler(MouseEvent.MOUSE_PRESSED, this.mouseEventListener);
/*  84 */     this.tlNode.focusedProperty().removeListener(this.focusListener);
/*  85 */     this.tlNode.setEventDispatcher(this.origEventDispatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TwoLevelFocusBehavior() {
/*  92 */     this.preemptiveEventDispatcher = ((paramEvent, paramEventDispatchChain) -> {
/*     */         if (paramEvent instanceof KeyEvent && paramEvent.getEventType() == KeyEvent.KEY_PRESSED && !((KeyEvent)paramEvent).isMetaDown() && !((KeyEvent)paramEvent).isControlDown() && !((KeyEvent)paramEvent).isAltDown() && isExternalFocus()) {
/*     */           EventTarget eventTarget = paramEvent.getTarget();
/*     */           switch (((KeyEvent)paramEvent).getCode()) {
/*     */             case TAB:
/*     */               if (((KeyEvent)paramEvent).isShiftDown()) {
/*     */                 NodeHelper.traverse((Node)eventTarget, Direction.PREVIOUS);
/*     */               } else {
/*     */                 NodeHelper.traverse((Node)eventTarget, Direction.NEXT);
/*     */               } 
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */ 
/*     */ 
/*     */             
/*     */             case UP:
/*     */               NodeHelper.traverse((Node)eventTarget, Direction.UP);
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */ 
/*     */ 
/*     */             
/*     */             case DOWN:
/*     */               NodeHelper.traverse((Node)eventTarget, Direction.DOWN);
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */ 
/*     */ 
/*     */             
/*     */             case LEFT:
/*     */               NodeHelper.traverse((Node)eventTarget, Direction.LEFT);
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */ 
/*     */ 
/*     */             
/*     */             case RIGHT:
/*     */               NodeHelper.traverse((Node)eventTarget, Direction.RIGHT);
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */ 
/*     */ 
/*     */             
/*     */             case ENTER:
/*     */               setExternalFocus(false);
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */           } 
/*     */ 
/*     */           
/*     */           Scene scene = this.tlNode.getScene();
/*     */           Event.fireEvent(scene, paramEvent);
/*     */           paramEvent.consume();
/*     */         } 
/*     */         return paramEvent;
/*     */       });
/* 148 */     this.tlfEventDispatcher = ((paramEvent, paramEventDispatchChain) -> {
/*     */         if (paramEvent instanceof KeyEvent && isExternalFocus()) {
/*     */           paramEventDispatchChain = paramEventDispatchChain.prepend(this.preemptiveEventDispatcher);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return paramEventDispatchChain.dispatchEvent(paramEvent);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         return this.origEventDispatcher.dispatchEvent(paramEvent, paramEventDispatchChain);
/*     */       });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     this.keyEventListener = (paramKeyEvent -> postDispatchTidyup(paramKeyEvent));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     this.focusListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*     */         if (paramBoolean2.booleanValue() && this.tlPopup != null) {
/*     */           setExternalFocus(false);
/*     */         } else {
/*     */           setExternalFocus(true);
/*     */         } 
/*     */       });
/*     */ 
/*     */     
/* 208 */     this.mouseEventListener = (paramMouseEvent -> setExternalFocus(false));
/*     */ 
/*     */ 
/*     */     
/* 212 */     this.externalFocus = true; } public TwoLevelFocusBehavior(Node paramNode) { this.preemptiveEventDispatcher = ((paramEvent, paramEventDispatchChain) -> { if (paramEvent instanceof KeyEvent && paramEvent.getEventType() == KeyEvent.KEY_PRESSED && !((KeyEvent)paramEvent).isMetaDown() && !((KeyEvent)paramEvent).isControlDown() && !((KeyEvent)paramEvent).isAltDown() && isExternalFocus()) { EventTarget eventTarget = paramEvent.getTarget(); switch (((KeyEvent)paramEvent).getCode()) { case TAB: if (((KeyEvent)paramEvent).isShiftDown()) { NodeHelper.traverse((Node)eventTarget, Direction.PREVIOUS); } else { NodeHelper.traverse((Node)eventTarget, Direction.NEXT); }  paramEvent.consume(); return paramEvent;case UP: NodeHelper.traverse((Node)eventTarget, Direction.UP); paramEvent.consume(); return paramEvent;case DOWN: NodeHelper.traverse((Node)eventTarget, Direction.DOWN); paramEvent.consume(); return paramEvent;case LEFT: NodeHelper.traverse((Node)eventTarget, Direction.LEFT); paramEvent.consume(); return paramEvent;case RIGHT: NodeHelper.traverse((Node)eventTarget, Direction.RIGHT); paramEvent.consume(); return paramEvent;case ENTER: setExternalFocus(false); paramEvent.consume(); return paramEvent; }  Scene scene = this.tlNode.getScene(); Event.fireEvent(scene, paramEvent); paramEvent.consume(); }  return paramEvent; }); this.tlfEventDispatcher = ((paramEvent, paramEventDispatchChain) -> { if (paramEvent instanceof KeyEvent && isExternalFocus()) { paramEventDispatchChain = paramEventDispatchChain.prepend(this.preemptiveEventDispatcher); return paramEventDispatchChain.dispatchEvent(paramEvent); }  return this.origEventDispatcher.dispatchEvent(paramEvent, paramEventDispatchChain); }); this.keyEventListener = (paramKeyEvent -> postDispatchTidyup(paramKeyEvent)); this.focusListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> { if (paramBoolean2.booleanValue() && this.tlPopup != null) { setExternalFocus(false); } else { setExternalFocus(true); }  }); this.mouseEventListener = (paramMouseEvent -> setExternalFocus(false)); this.externalFocus = true; this.tlNode = paramNode; this.tlPopup = null; this.tlNode.addEventHandler(KeyEvent.ANY, this.keyEventListener); this.tlNode.addEventHandler(MouseEvent.MOUSE_PRESSED, this.mouseEventListener); this.tlNode.focusedProperty().addListener(this.focusListener); this.origEventDispatcher = this.tlNode.getEventDispatcher(); this.tlNode.setEventDispatcher(this.tlfEventDispatcher); }
/*     */   private Event postDispatchTidyup(Event paramEvent) { if (paramEvent instanceof KeyEvent && paramEvent.getEventType() == KeyEvent.KEY_PRESSED && !isExternalFocus())
/*     */       if (!((KeyEvent)paramEvent).isMetaDown() && !((KeyEvent)paramEvent).isControlDown() && !((KeyEvent)paramEvent).isAltDown())
/* 215 */         switch (((KeyEvent)paramEvent).getCode()) { case TAB: case UP: case DOWN: case LEFT: case RIGHT: paramEvent.consume(); break;case ENTER: setExternalFocus(true); paramEvent.consume(); break; }    return paramEvent; } public boolean isExternalFocus() { return this.externalFocus; }
/*     */ 
/*     */ 
/*     */   
/* 219 */   private static final PseudoClass INTERNAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("internal-focus");
/*     */   
/* 221 */   private static final PseudoClass EXTERNAL_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("external-focus");
/*     */   
/*     */   public void setExternalFocus(boolean paramBoolean) {
/* 224 */     this.externalFocus = paramBoolean;
/*     */     
/* 226 */     if (this.tlNode != null && this.tlNode instanceof javafx.scene.control.Control) {
/* 227 */       this.tlNode.pseudoClassStateChanged(INTERNAL_PSEUDOCLASS_STATE, !paramBoolean);
/* 228 */       this.tlNode.pseudoClassStateChanged(EXTERNAL_PSEUDOCLASS_STATE, paramBoolean);
/*     */     }
/* 230 */     else if (this.tlPopup != null) {
/* 231 */       this.tlPopup.pseudoClassStateChanged(INTERNAL_PSEUDOCLASS_STATE, !paramBoolean);
/* 232 */       this.tlPopup.pseudoClassStateChanged(EXTERNAL_PSEUDOCLASS_STATE, paramBoolean);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TwoLevelFocusBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */