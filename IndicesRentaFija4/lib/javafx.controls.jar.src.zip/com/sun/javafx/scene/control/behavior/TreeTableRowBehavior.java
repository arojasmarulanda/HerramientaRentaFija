/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import javafx.collections.ObservableList;
/*    */ import javafx.scene.control.Cell;
/*    */ import javafx.scene.control.Control;
/*    */ import javafx.scene.control.FocusModel;
/*    */ import javafx.scene.control.MultipleSelectionModel;
/*    */ import javafx.scene.control.TableFocusModel;
/*    */ import javafx.scene.control.TablePositionBase;
/*    */ import javafx.scene.control.TableSelectionModel;
/*    */ import javafx.scene.control.TreeItem;
/*    */ import javafx.scene.control.TreeTableRow;
/*    */ import javafx.scene.control.TreeTableView;
/*    */ import javafx.scene.input.MouseButton;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TreeTableRowBehavior<T>
/*    */   extends TableRowBehaviorBase<TreeTableRow<T>>
/*    */ {
/*    */   public TreeTableRowBehavior(TreeTableRow<T> paramTreeTableRow) {
/* 46 */     super(paramTreeTableRow);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected TableSelectionModel<TreeItem<T>> getSelectionModel() {
/* 56 */     return getCellContainer().getSelectionModel();
/*    */   }
/*    */   
/*    */   protected TableFocusModel<TreeItem<T>, ?> getFocusModel() {
/* 60 */     return getCellContainer().getFocusModel();
/*    */   }
/*    */   
/*    */   protected TreeTableView<T> getCellContainer() {
/* 64 */     return getNode().getTreeTableView();
/*    */   }
/*    */   
/*    */   protected TablePositionBase<?> getFocusedCell() {
/* 68 */     return getCellContainer().getFocusModel().getFocusedCell();
/*    */   }
/*    */   
/*    */   protected ObservableList getVisibleLeafColumns() {
/* 72 */     return getCellContainer().getVisibleLeafColumns();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void edit(TreeTableRow<T> paramTreeTableRow) {}
/*    */ 
/*    */ 
/*    */   
/*    */   protected void handleClicks(MouseButton paramMouseButton, int paramInt, boolean paramBoolean) {
/* 82 */     TreeItem<T> treeItem = getNode().getTreeItem();
/* 83 */     if (paramMouseButton == MouseButton.PRIMARY)
/* 84 */       if (paramInt == 1 && paramBoolean) {
/* 85 */         edit(getNode());
/* 86 */       } else if (paramInt == 1) {
/*    */         
/* 88 */         edit((TreeTableRow<T>)null);
/* 89 */       } else if (paramInt == 2 && treeItem.isLeaf()) {
/*    */         
/* 91 */         edit(getNode());
/* 92 */       } else if (paramInt % 2 == 0) {
/*    */         
/* 94 */         treeItem.setExpanded(!treeItem.isExpanded());
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TreeTableRowBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */