/*     */ package com.sun.javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.InputField;
/*     */ import com.sun.javafx.scene.control.WebColorField;
/*     */ import java.util.Locale;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.geometry.NodeOrientation;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Skinnable;
/*     */ import javafx.scene.paint.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebColorFieldSkin
/*     */   extends InputFieldSkin
/*     */ {
/*     */   private InvalidationListener integerFieldValueListener;
/*     */   private boolean noChangeInValue = false;
/*     */   
/*     */   public WebColorFieldSkin(WebColorField paramWebColorField) {
/*  48 */     super((InputField)paramWebColorField);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     paramWebColorField.valueProperty().addListener(this.integerFieldValueListener = (paramObservable -> updateText()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     getTextField().setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
/*     */   }
/*     */   
/*     */   public WebColorField getSkinnable() {
/*  64 */     return (WebColorField)this.control;
/*     */   }
/*     */   
/*     */   public Node getNode() {
/*  68 */     return getTextField();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  80 */     ((WebColorField)this.control).valueProperty().removeListener(this.integerFieldValueListener);
/*  81 */     super.dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean accept(String paramString) {
/*  86 */     if (paramString.length() == 0) return true; 
/*  87 */     if (paramString.matches("#[a-fA-F0-9]{0,6}") || paramString.matches("[a-fA-F0-9]{0,6}")) {
/*  88 */       return true;
/*     */     }
/*  90 */     return false;
/*     */   }
/*     */   
/*     */   protected void updateText() {
/*  94 */     Color color = ((WebColorField)this.control).getValue();
/*  95 */     if (color == null) color = Color.BLACK; 
/*  96 */     getTextField().setText(Utils.formatHexString(color));
/*     */   }
/*     */   
/*     */   protected void updateValue() {
/* 100 */     if (this.noChangeInValue)
/* 101 */       return;  Color color = ((WebColorField)this.control).getValue();
/* 102 */     String str = (getTextField().getText() == null) ? "" : getTextField().getText().trim().toUpperCase(Locale.ROOT);
/* 103 */     if (str.matches("#[A-F0-9]{6}") || str.matches("[A-F0-9]{6}"))
/*     */       try {
/* 105 */         Color color1 = (str.charAt(0) == '#') ? Color.web(str) : Color.web("#" + str);
/* 106 */         if (!color1.equals(color)) {
/* 107 */           ((WebColorField)this.control).setValue(color1);
/*     */         }
/*     */         else {
/*     */           
/* 111 */           this.noChangeInValue = true;
/* 112 */           getTextField().setText(Utils.formatHexString(color1));
/* 113 */           this.noChangeInValue = false;
/*     */         } 
/* 115 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 116 */         System.out.println("Failed to parse [" + str + "]");
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\skin\WebColorFieldSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */