/*     */ package com.sun.javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.InputField;
/*     */ import com.sun.javafx.scene.control.IntegerField;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Skinnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegerFieldSkin
/*     */   extends InputFieldSkin
/*     */ {
/*     */   private InvalidationListener integerFieldValueListener;
/*     */   
/*     */   public IntegerFieldSkin(IntegerField paramIntegerField) {
/*  43 */     super((InputField)paramIntegerField);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     paramIntegerField.valueProperty().addListener(this.integerFieldValueListener = (paramObservable -> updateText()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerField getSkinnable() {
/*  54 */     return (IntegerField)this.control;
/*     */   }
/*     */   
/*     */   public Node getNode() {
/*  58 */     return getTextField();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  71 */     ((IntegerField)this.control).valueProperty().removeListener(this.integerFieldValueListener);
/*  72 */     super.dispose();
/*     */   }
/*     */   
/*     */   protected boolean accept(String paramString) {
/*  76 */     if (paramString.length() == 0) return true; 
/*  77 */     if (paramString.matches("[0-9]*")) {
/*     */       try {
/*  79 */         Integer.parseInt(paramString);
/*  80 */         int i = Integer.parseInt(paramString);
/*  81 */         int j = ((IntegerField)this.control).getMaxValue();
/*  82 */         return (j != -1) ? ((i <= j)) : true;
/*  83 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*  85 */     return false;
/*     */   }
/*     */   
/*     */   protected void updateText() {
/*  89 */     getTextField().setText("" + ((IntegerField)this.control).getValue());
/*     */   }
/*     */   
/*     */   protected void updateValue() {
/*  93 */     int i = ((IntegerField)this.control).getValue();
/*     */     
/*  95 */     String str = (getTextField().getText() == null) ? "" : getTextField().getText().trim();
/*     */     try {
/*  97 */       int j = Integer.parseInt(str);
/*  98 */       if (j != i) {
/*  99 */         ((IntegerField)this.control).setValue(j);
/*     */       }
/* 101 */     } catch (NumberFormatException numberFormatException) {
/*     */       
/* 103 */       ((IntegerField)this.control).setValue(0);
/* 104 */       Platform.runLater(() -> getTextField().positionCaret(1));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\skin\IntegerFieldSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */