/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.geometry.NodeOrientation;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.Toggle;
/*     */ import javafx.scene.control.ToggleButton;
/*     */ import javafx.scene.control.ToggleGroup;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToggleButtonBehavior<C extends ToggleButton>
/*     */   extends ButtonBehavior<C>
/*     */ {
/*     */   public ToggleButtonBehavior(C paramC) {
/*  45 */     super(paramC);
/*     */     
/*  47 */     ObservableList<InputMap.Mapping> observableList = FXCollections.observableArrayList(new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> traverse(paramKeyEvent, "ToggleNext-Right")), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> traverse(paramKeyEvent, "TogglePrevious-Left")), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> traverse(paramKeyEvent, "ToggleNext-Down")), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> traverse(paramKeyEvent, "TogglePrevious-Up")) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     for (InputMap.Mapping mapping : observableList) {
/*  57 */       mapping.setAutoConsume(false);
/*     */     }
/*     */ 
/*     */     
/*  61 */     InputMap inputMap = new InputMap((Node)paramC);
/*  62 */     inputMap.getMappings().addAll(observableList);
/*  63 */     addDefaultChildMap(getInputMap(), inputMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int nextToggleIndex(ObservableList<Toggle> paramObservableList, int paramInt) {
/*  71 */     if (paramInt < 0 || paramInt >= paramObservableList.size()) return 0; 
/*  72 */     int i = (paramInt + 1) % paramObservableList.size(); Toggle toggle;
/*  73 */     while (i != paramInt && toggle = paramObservableList.get(i) instanceof Node && ((Node)toggle)
/*  74 */       .isDisabled()) {
/*  75 */       i = (i + 1) % paramObservableList.size();
/*     */     }
/*  77 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int previousToggleIndex(ObservableList<Toggle> paramObservableList, int paramInt) {
/*  85 */     if (paramInt < 0 || paramInt >= paramObservableList.size()) return paramObservableList.size(); 
/*  86 */     int i = Math.floorMod(paramInt - 1, paramObservableList.size()); Toggle toggle;
/*  87 */     while (i != paramInt && toggle = paramObservableList.get(i) instanceof Node && ((Node)toggle)
/*  88 */       .isDisabled()) {
/*  89 */       i = Math.floorMod(i - 1, paramObservableList.size());
/*     */     }
/*  91 */     return i;
/*     */   }
/*     */   
/*     */   private void traverse(KeyEvent paramKeyEvent, String paramString) {
/*  95 */     ToggleButton toggleButton = (ToggleButton)getNode();
/*  96 */     ToggleGroup toggleGroup = toggleButton.getToggleGroup();
/*     */     
/*  98 */     if (toggleGroup == null) {
/*  99 */       paramKeyEvent.consume();
/*     */       return;
/*     */     } 
/* 102 */     ObservableList<Toggle> observableList = toggleGroup.getToggles();
/* 103 */     int i = observableList.indexOf(toggleButton);
/*     */     
/* 105 */     boolean bool = traversingToNext(paramString, toggleButton.getEffectiveNodeOrientation());
/* 106 */     if (!Utils.isTwoLevelFocus())
/*     */     {
/*     */ 
/*     */       
/* 110 */       if (bool) {
/* 111 */         int j = nextToggleIndex(observableList, i);
/* 112 */         if (j != i) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 117 */           Toggle toggle = observableList.get(j);
/* 118 */           toggleGroup.selectToggle(toggle);
/* 119 */           ((Control)toggle).requestFocus();
/* 120 */           paramKeyEvent.consume();
/*     */         } 
/*     */       } else {
/* 123 */         int j = previousToggleIndex(observableList, i);
/* 124 */         if (j != i) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 129 */           Toggle toggle = observableList.get(j);
/* 130 */           toggleGroup.selectToggle(toggle);
/* 131 */           ((Control)toggle).requestFocus();
/* 132 */           paramKeyEvent.consume();
/*     */         } 
/*     */       }  } 
/*     */   }
/*     */   
/*     */   private boolean traversingToNext(String paramString, NodeOrientation paramNodeOrientation) {
/* 138 */     boolean bool = (paramNodeOrientation == NodeOrientation.RIGHT_TO_LEFT) ? true : false;
/* 139 */     switch (paramString) {
/*     */       case "ToggleNext-Right":
/* 141 */         return !bool;
/*     */       case "ToggleNext-Down":
/* 143 */         return true;
/*     */       case "TogglePrevious-Left":
/* 145 */         return bool;
/*     */       case "TogglePrevious-Up":
/* 147 */         return false;
/*     */     } 
/* 149 */     throw new IllegalArgumentException("Not a toggle action");
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ToggleButtonBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */