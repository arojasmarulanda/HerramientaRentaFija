/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import javafx.geometry.Side;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.MenuButton;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MenuButtonBehaviorBase<C extends MenuButton>
/*     */   extends ButtonBehavior<C>
/*     */ {
/*     */   private final InputMap<C> buttonInputMap;
/*     */   
/*     */   public MenuButtonBehaviorBase(C paramC) {
/*  52 */     super(paramC);
/*     */ 
/*     */ 
/*     */     
/*  56 */     this.buttonInputMap = getInputMap();
/*     */ 
/*     */ 
/*     */     
/*  60 */     removeMapping(MouseEvent.MOUSE_RELEASED);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     addDefaultMapping((InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ESCAPE, paramKeyEvent -> ((MenuButton)getNode()).hide()) });
/*  68 */     addDefaultMapping((InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.CANCEL, paramKeyEvent -> ((MenuButton)getNode()).hide()) });
/*     */ 
/*     */ 
/*     */     
/*  72 */     InputMap<C> inputMap = new InputMap((Node)paramC);
/*  73 */     addDefaultMapping(inputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, this::overrideTraversalInput) });
/*  74 */     addDefaultMapping(inputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, this::overrideTraversalInput) });
/*  75 */     addDefaultMapping(inputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, this::overrideTraversalInput) });
/*  76 */     addDefaultMapping(inputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, this::overrideTraversalInput) });
/*  77 */     addDefaultChildMap(this.buttonInputMap, inputMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void overrideTraversalInput(KeyEvent paramKeyEvent) {
/*  88 */     MenuButton menuButton = (MenuButton)getNode();
/*  89 */     Side side = menuButton.getPopupSide();
/*  90 */     if ((!menuButton.isShowing() && paramKeyEvent
/*  91 */       .getCode() == KeyCode.UP && side == Side.TOP) || (paramKeyEvent
/*  92 */       .getCode() == KeyCode.DOWN && (side == Side.BOTTOM || side == Side.TOP)) || (paramKeyEvent
/*  93 */       .getCode() == KeyCode.LEFT && (side == Side.RIGHT || side == Side.LEFT)) || (paramKeyEvent
/*  94 */       .getCode() == KeyCode.RIGHT && (side == Side.RIGHT || side == Side.LEFT)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 101 */       menuButton.show();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void openAction() {
/* 106 */     if (((MenuButton)getNode()).isShowing()) {
/* 107 */       ((MenuButton)getNode()).hide();
/*     */     } else {
/* 109 */       ((MenuButton)getNode()).show();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent paramMouseEvent, boolean paramBoolean) {
/* 127 */     MenuButton menuButton = (MenuButton)getNode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     if (paramBoolean) {
/* 138 */       if (menuButton.isShowing()) {
/* 139 */         menuButton.hide();
/*     */       }
/* 141 */       mousePressed(paramMouseEvent);
/*     */     } else {
/* 143 */       if (!menuButton.isFocused() && menuButton.isFocusTraversable()) {
/* 144 */         menuButton.requestFocus();
/*     */       }
/* 146 */       if (menuButton.isShowing()) {
/* 147 */         menuButton.hide();
/*     */       }
/* 149 */       else if (paramMouseEvent.getButton() == MouseButton.PRIMARY) {
/* 150 */         menuButton.show();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent paramMouseEvent, boolean paramBoolean) {
/* 163 */     if (paramBoolean) {
/* 164 */       mouseReleased(paramMouseEvent);
/*     */     } else {
/* 166 */       if (((MenuButton)getNode()).isShowing() && !((MenuButton)getNode()).contains(paramMouseEvent.getX(), paramMouseEvent.getY())) {
/* 167 */         ((MenuButton)getNode()).hide();
/*     */       }
/* 169 */       ((MenuButton)getNode()).disarm();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\MenuButtonBehaviorBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */