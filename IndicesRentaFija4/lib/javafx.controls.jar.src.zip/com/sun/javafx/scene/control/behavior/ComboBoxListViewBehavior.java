/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*    */ import javafx.scene.control.ComboBox;
/*    */ import javafx.scene.control.SingleSelectionModel;
/*    */ import javafx.scene.input.KeyCode;
/*    */ import javafx.scene.input.KeyEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComboBoxListViewBehavior<T>
/*    */   extends ComboBoxBaseBehavior<T>
/*    */ {
/*    */   public ComboBoxListViewBehavior(ComboBox<T> paramComboBox) {
/* 48 */     super(paramComboBox);
/*    */ 
/*    */     
/* 51 */     InputMap inputMap = new InputMap(paramComboBox);
/* 52 */     inputMap.getMappings().addAll(new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> selectPrevious()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> selectNext()) });
/*    */ 
/*    */ 
/*    */     
/* 56 */     addDefaultChildMap(getInputMap(), inputMap);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private ComboBox<T> getComboBox() {
/* 66 */     return (ComboBox<T>)getNode();
/*    */   }
/*    */   
/*    */   private void selectPrevious() {
/* 70 */     SingleSelectionModel<T> singleSelectionModel = getComboBox().getSelectionModel();
/* 71 */     if (singleSelectionModel == null)
/* 72 */       return;  singleSelectionModel.selectPrevious();
/*    */   }
/*    */   
/*    */   private void selectNext() {
/* 76 */     SingleSelectionModel<T> singleSelectionModel = getComboBox().getSelectionModel();
/* 77 */     if (singleSelectionModel == null)
/* 78 */       return;  singleSelectionModel.selectNext();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ComboBoxListViewBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */