package com.sun.javafx.scene.control;

public interface FormatterAccessor {
  int getTextLength();
  
  String getText(int paramInt1, int paramInt2);
  
  int getCaret();
  
  int getAnchor();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\FormatterAccessor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */