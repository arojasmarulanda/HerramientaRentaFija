/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import com.sun.javafx.logging.PlatformLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Logging
/*    */ {
/* 40 */   private static PlatformLogger controlsLogger = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final PlatformLogger getControlsLogger() {
/* 46 */     if (controlsLogger == null) {
/* 47 */       controlsLogger = PlatformLogger.getLogger("javafx.scene.control");
/*    */     }
/* 49 */     return controlsLogger;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\Logging.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */