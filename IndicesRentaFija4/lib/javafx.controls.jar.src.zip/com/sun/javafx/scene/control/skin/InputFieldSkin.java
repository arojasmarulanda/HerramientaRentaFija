/*     */ package com.sun.javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.event.EventDispatchChainImpl;
/*     */ import com.sun.javafx.scene.control.InputField;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.event.EventDispatchChain;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Skin;
/*     */ import javafx.scene.control.Skinnable;
/*     */ import javafx.scene.control.TextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InputFieldSkin
/*     */   implements Skin<InputField>
/*     */ {
/*     */   protected InputField control;
/*     */   private InnerTextField textField;
/*     */   private InvalidationListener InputFieldFocusListener;
/*     */   private InvalidationListener InputFieldStyleClassListener;
/*     */   
/*     */   public InputFieldSkin(InputField paramInputField) {
/*  60 */     this.control = paramInputField;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     this.textField = new InnerTextField() {
/*     */         public void replaceText(int param1Int1, int param1Int2, String param1String) {
/*  67 */           String str = (InputFieldSkin.this.textField.getText() == null) ? "" : InputFieldSkin.this.textField.getText();
/*  68 */           str = str.substring(0, param1Int1) + str.substring(0, param1Int1) + param1String;
/*  69 */           if (InputFieldSkin.this.accept(str)) {
/*  70 */             super.replaceText(param1Int1, param1Int2, param1String);
/*     */           }
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void replaceSelection(String param1String) {
/*  78 */           String str = (InputFieldSkin.this.textField.getText() == null) ? "" : InputFieldSkin.this.textField.getText();
/*  79 */           int i = Math.min(InputFieldSkin.this.textField.getAnchor(), InputFieldSkin.this.textField.getCaretPosition());
/*  80 */           int j = Math.max(InputFieldSkin.this.textField.getAnchor(), InputFieldSkin.this.textField.getCaretPosition());
/*  81 */           str = str.substring(0, i) + str.substring(0, i) + param1String;
/*  82 */           if (InputFieldSkin.this.accept(str)) {
/*  83 */             super.replaceSelection(param1String);
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     this.textField.setId("input-text-field");
/*  93 */     this.textField.setFocusTraversable(false);
/*  94 */     paramInputField.getStyleClass().addAll(this.textField.getStyleClass());
/*  95 */     this.textField.getStyleClass().setAll(paramInputField.getStyleClass());
/*  96 */     paramInputField.getStyleClass().addListener(this.InputFieldStyleClassListener = (paramObservable -> this.textField.getStyleClass().setAll(paramInputField.getStyleClass())));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     this.textField.promptTextProperty().bind(paramInputField.promptTextProperty());
/*     */     
/* 104 */     this.textField.prefColumnCountProperty().bind(paramInputField.prefColumnCountProperty());
/*     */ 
/*     */ 
/*     */     
/* 108 */     this.textField.textProperty().addListener(paramObservable -> updateValue());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     paramInputField.focusedProperty().addListener(this.InputFieldFocusListener = (paramObservable -> this.textField.handleFocus(paramInputField.isFocused())));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     updateText();
/*     */   }
/*     */   
/*     */   public InputField getSkinnable() {
/* 142 */     return this.control;
/*     */   }
/*     */   
/*     */   public Node getNode() {
/* 146 */     return this.textField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 159 */     this.control.getStyleClass().removeListener(this.InputFieldStyleClassListener);
/* 160 */     this.control.focusedProperty().removeListener(this.InputFieldFocusListener);
/* 161 */     this.textField = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TextField getTextField() {
/* 169 */     return this.textField;
/*     */   } protected abstract boolean accept(String paramString);
/*     */   protected abstract void updateText();
/*     */   protected abstract void updateValue();
/*     */   private class InnerTextField extends TextField { public void handleFocus(boolean param1Boolean) {
/* 174 */       setFocused(param1Boolean);
/*     */     }
/*     */     private InnerTextField() {}
/*     */     public EventDispatchChain buildEventDispatchChain(EventDispatchChain param1EventDispatchChain) {
/* 178 */       EventDispatchChainImpl eventDispatchChainImpl = new EventDispatchChainImpl();
/* 179 */       eventDispatchChainImpl.append(InputFieldSkin.this.textField.getEventDispatcher());
/* 180 */       return eventDispatchChainImpl;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\skin\InputFieldSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */