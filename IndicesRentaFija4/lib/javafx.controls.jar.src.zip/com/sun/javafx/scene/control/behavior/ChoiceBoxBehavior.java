/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.event.Event;
/*     */ import javafx.scene.control.ChoiceBox;
/*     */ import javafx.scene.control.SingleSelectionModel;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChoiceBoxBehavior<T>
/*     */   extends BehaviorBase<ChoiceBox<T>>
/*     */ {
/*     */   private final InputMap<ChoiceBox<T>> choiceBoxInputMap;
/*     */   private TwoLevelFocusComboBehavior tlFocus;
/*     */   
/*     */   public ChoiceBoxBehavior(ChoiceBox<T> paramChoiceBox) {
/*  53 */     super(paramChoiceBox);
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.choiceBoxInputMap = createInputMap();
/*     */ 
/*     */     
/*  60 */     addDefaultMapping(this.choiceBoxInputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, KeyEvent.KEY_PRESSED, this::keyPressed), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, KeyEvent.KEY_RELEASED, this::keyReleased), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ESCAPE, KeyEvent.KEY_RELEASED, paramKeyEvent -> cancel()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, KeyEvent.KEY_RELEASED, paramKeyEvent -> showPopup()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.CANCEL, KeyEvent.KEY_RELEASED, paramKeyEvent -> cancel()), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_RELEASED, this::mouseReleased) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     InputMap inputMap = new InputMap(paramChoiceBox);
/*  74 */     inputMap.setInterceptor(paramEvent -> !Utils.isTwoLevelFocus());
/*  75 */     inputMap.getMappings().addAll(new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ENTER, KeyEvent.KEY_PRESSED, this::keyPressed), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ENTER, KeyEvent.KEY_RELEASED, this::keyReleased) });
/*     */ 
/*     */ 
/*     */     
/*  79 */     addDefaultChildMap(this.choiceBoxInputMap, inputMap);
/*     */ 
/*     */     
/*  82 */     if (Utils.isTwoLevelFocus()) {
/*  83 */       this.tlFocus = new TwoLevelFocusComboBehavior(paramChoiceBox);
/*     */     }
/*     */   }
/*     */   
/*     */   public InputMap<ChoiceBox<T>> getInputMap() {
/*  88 */     return this.choiceBoxInputMap;
/*     */   }
/*     */   
/*     */   public void dispose() {
/*  92 */     if (this.tlFocus != null) this.tlFocus.dispose(); 
/*  93 */     super.dispose();
/*     */   }
/*     */   
/*     */   public void select(int paramInt) {
/*  97 */     SingleSelectionModel<T> singleSelectionModel = getNode().getSelectionModel();
/*  98 */     if (singleSelectionModel == null)
/*     */       return; 
/* 100 */     singleSelectionModel.select(paramInt);
/*     */   }
/*     */   
/*     */   public void close() {
/* 104 */     getNode().hide();
/*     */   }
/*     */   
/*     */   public void showPopup() {
/* 108 */     getNode().show();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent paramMouseEvent) {
/* 116 */     ChoiceBox<T> choiceBox = getNode();
/* 117 */     if (choiceBox.isFocusTraversable()) choiceBox.requestFocus();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent paramMouseEvent) {
/* 126 */     ChoiceBox<T> choiceBox = getNode();
/* 127 */     if (choiceBox.isShowing() || !choiceBox.contains(paramMouseEvent.getX(), paramMouseEvent.getY())) {
/* 128 */       choiceBox.hide();
/*     */     }
/* 130 */     else if (paramMouseEvent.getButton() == MouseButton.PRIMARY) {
/* 131 */       choiceBox.show();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void keyPressed(KeyEvent paramKeyEvent) {
/* 141 */     ChoiceBox<T> choiceBox = getNode();
/* 142 */     if (!choiceBox.isShowing()) {
/* 143 */       choiceBox.show();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void keyReleased(KeyEvent paramKeyEvent) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 159 */     ChoiceBox<T> choiceBox = getNode();
/* 160 */     choiceBox.hide();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ChoiceBoxBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */