/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import javafx.beans.value.ChangeListener;
/*    */ import javafx.collections.ListChangeListener;
/*    */ import javafx.scene.AccessibleAttribute;
/*    */ import javafx.scene.AccessibleRole;
/*    */ import javafx.scene.control.Menu;
/*    */ import javafx.scene.control.MenuBar;
/*    */ import javafx.scene.control.MenuButton;
/*    */ import javafx.scene.control.MenuItem;
/*    */ import javafx.scene.control.skin.MenuBarSkin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MenuBarButton
/*    */   extends MenuButton
/*    */ {
/*    */   public ChangeListener<Boolean> menuListener;
/*    */   public MenuBarSkin menuBarSkin;
/*    */   public Menu menu;
/*    */   private final ListChangeListener<MenuItem> itemsListener;
/*    */   private final ListChangeListener<String> styleClassListener;
/*    */   
/*    */   public MenuBarButton(MenuBarSkin paramMenuBarSkin, Menu paramMenu) {
/* 46 */     super(paramMenu.getText(), paramMenu.getGraphic());
/* 47 */     this.menuBarSkin = paramMenuBarSkin;
/* 48 */     setAccessibleRole(AccessibleRole.MENU);
/*    */ 
/*    */     
/* 51 */     paramMenu.getItems().addListener(this.itemsListener = (paramChange -> {
/*    */           while (paramChange.next()) {
/*    */             getItems().removeAll(paramChange.getRemoved());
/*    */             getItems().addAll(paramChange.getFrom(), (Collection)paramChange.getAddedSubList());
/*    */           } 
/*    */         }));
/* 57 */     paramMenu.getStyleClass().addListener(this.styleClassListener = (paramChange -> {
/*    */           while (paramChange.next()) {
/*    */             for (int i = paramChange.getFrom(); i < paramChange.getTo(); i++) {
/*    */               getStyleClass().add(paramMenu.getStyleClass().get(i));
/*    */             }
/*    */             for (String str : paramChange.getRemoved()) {
/*    */               getStyleClass().remove(str);
/*    */             }
/*    */           } 
/*    */         }));
/* 67 */     idProperty().bind(paramMenu.idProperty());
/*    */   }
/*    */   
/*    */   public MenuBarSkin getMenuBarSkin() {
/* 71 */     return this.menuBarSkin;
/*    */   }
/*    */   
/*    */   public void clearHover() {
/* 75 */     setHover(false);
/*    */   }
/*    */   
/*    */   public void setHover() {
/* 79 */     setHover(true);
/*    */ 
/*    */     
/* 82 */     ((MenuBar)this.menuBarSkin.getSkinnable()).notifyAccessibleAttributeChanged(AccessibleAttribute.FOCUS_NODE);
/*    */   }
/*    */   
/*    */   public void dispose() {
/* 86 */     this.menu.getItems().removeListener(this.itemsListener);
/* 87 */     this.menu.getStyleClass().removeListener(this.styleClassListener);
/* 88 */     idProperty().unbind();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 94 */     switch (paramAccessibleAttribute) { case FOCUS_ITEM:
/* 95 */         return this; }
/* 96 */      return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\MenuBarButton.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */