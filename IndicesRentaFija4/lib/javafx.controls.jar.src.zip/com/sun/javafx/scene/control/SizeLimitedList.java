/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SizeLimitedList<E>
/*    */ {
/*    */   private final int maxSize;
/*    */   private final List<E> backingList;
/*    */   
/*    */   public SizeLimitedList(int paramInt) {
/* 45 */     this.maxSize = paramInt;
/* 46 */     this.backingList = new LinkedList<>();
/*    */   }
/*    */   
/*    */   public E get(int paramInt) {
/* 50 */     return this.backingList.get(paramInt);
/*    */   }
/*    */   
/*    */   public void add(E paramE) {
/* 54 */     this.backingList.add(0, paramE);
/*    */     
/* 56 */     if (this.backingList.size() > this.maxSize) {
/* 57 */       this.backingList.remove(this.maxSize);
/*    */     }
/*    */   }
/*    */   
/*    */   public int size() {
/* 62 */     return this.backingList.size();
/*    */   }
/*    */   
/*    */   public boolean contains(E paramE) {
/* 66 */     return this.backingList.contains(paramE);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\SizeLimitedList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */