/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*     */ import java.util.ArrayList;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.beans.value.WeakChangeListener;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.scene.control.FocusModel;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.control.SelectionMode;
/*     */ import javafx.scene.control.TreeCell;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeView;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeViewBehavior<T>
/*     */   extends BehaviorBase<TreeView<T>>
/*     */ {
/*     */   private final InputMap<TreeView<T>> treeViewInputMap;
/*     */   private final EventHandler<KeyEvent> keyEventListener;
/*     */   private boolean isShiftDown;
/*     */   private boolean isShortcutDown;
/*     */   private Callback<Boolean, Integer> onScrollPageUp;
/*     */   private Callback<Boolean, Integer> onScrollPageDown;
/*     */   private Runnable onSelectPreviousRow;
/*     */   private Runnable onSelectNextRow;
/*     */   private Runnable onMoveToFirstCell;
/*     */   private Runnable onMoveToLastCell;
/*     */   private Runnable onFocusPreviousRow;
/*     */   private Runnable onFocusNextRow;
/*     */   private boolean selectionChanging;
/*     */   private final ListChangeListener<Integer> selectedIndicesListener;
/*     */   private final ChangeListener<MultipleSelectionModel<TreeItem<T>>> selectionModelListener;
/*     */   private final WeakListChangeListener<Integer> weakSelectedIndicesListener;
/*     */   private final WeakChangeListener<MultipleSelectionModel<TreeItem<T>>> weakSelectionModelListener;
/*     */   
/*     */   public void setOnScrollPageUp(Callback<Boolean, Integer> paramCallback) {
/*  73 */     this.onScrollPageUp = paramCallback;
/*     */   }
/*     */   public void setOnScrollPageDown(Callback<Boolean, Integer> paramCallback) {
/*  76 */     this.onScrollPageDown = paramCallback;
/*     */   }
/*     */   public void setOnSelectPreviousRow(Runnable paramRunnable) {
/*  79 */     this.onSelectPreviousRow = paramRunnable;
/*     */   }
/*     */   public void setOnSelectNextRow(Runnable paramRunnable) {
/*  82 */     this.onSelectNextRow = paramRunnable;
/*     */   }
/*     */   public void setOnMoveToFirstCell(Runnable paramRunnable) {
/*  85 */     this.onMoveToFirstCell = paramRunnable;
/*     */   }
/*     */   public void setOnMoveToLastCell(Runnable paramRunnable) {
/*  88 */     this.onMoveToLastCell = paramRunnable;
/*     */   }
/*     */   public void setOnFocusPreviousRow(Runnable paramRunnable) {
/*  91 */     this.onFocusPreviousRow = paramRunnable;
/*     */   }
/*     */   public void setOnFocusNextRow(Runnable paramRunnable) {
/*  94 */     this.onFocusNextRow = paramRunnable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TreeViewBehavior(TreeView<T> paramTreeView) {
/* 155 */     super(paramTreeView); this.keyEventListener = (paramKeyEvent -> { if (!paramKeyEvent.isConsumed()) { this.isShiftDown = (paramKeyEvent.getEventType() == KeyEvent.KEY_PRESSED && paramKeyEvent.isShiftDown()); this.isShortcutDown = (paramKeyEvent.getEventType() == KeyEvent.KEY_PRESSED && paramKeyEvent.isShortcutDown()); }  }); this.isShiftDown = false; this.isShortcutDown = false; this.selectionChanging = false; this.selectedIndicesListener = (paramChange -> { int i = getAnchor(); while (paramChange.next()) { if (paramChange.wasReplaced() && TreeCellBehavior.hasDefaultAnchor(getNode())) { TreeCellBehavior.removeAnchor(getNode()); continue; }
/*     */            byte b = paramChange.wasPermutated() ? (paramChange.getTo() - paramChange.getFrom()) : 0; MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel(); if (!this.selectionChanging)
/*     */             if (multipleSelectionModel.isEmpty()) { i = -1; }
/*     */             else if (hasAnchor() && !multipleSelectionModel.isSelected(getAnchor() + b)) { i = -1; }
/*     */               if (i == -1) { int j = paramChange.getAddedSize(); i = (j > 0) ? ((Integer)paramChange.getAddedSubList().get(j - 1)).intValue() : i; }
/*     */            }
/*     */          if (i > -1)
/*     */           setAnchor(i); 
/*     */       }); this.selectionModelListener = (ChangeListener)new ChangeListener<MultipleSelectionModel<TreeItem<MultipleSelectionModel<TreeItem<T>>>>>() { public void changed(ObservableValue<? extends MultipleSelectionModel<TreeItem<T>>> param1ObservableValue, MultipleSelectionModel<TreeItem<T>> param1MultipleSelectionModel1, MultipleSelectionModel<TreeItem<T>> param1MultipleSelectionModel2) { if (param1MultipleSelectionModel1 != null)
/*     */             param1MultipleSelectionModel1.getSelectedIndices().removeListener(TreeViewBehavior.this.weakSelectedIndicesListener);  if (param1MultipleSelectionModel2 != null)
/*     */             param1MultipleSelectionModel2.getSelectedIndices().addListener(TreeViewBehavior.this.weakSelectedIndicesListener);  } }
/* 166 */       ; this.weakSelectedIndicesListener = new WeakListChangeListener<>(this.selectedIndicesListener); this.weakSelectionModelListener = new WeakChangeListener<>(this.selectionModelListener); this.treeViewInputMap = createInputMap();
/*     */ 
/*     */ 
/*     */     
/* 170 */     addDefaultMapping(this.treeViewInputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.HOME, paramKeyEvent -> selectFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.END, paramKeyEvent -> selectLastRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.HOME))
/*     */ 
/*     */             
/* 173 */             .shift(), paramKeyEvent -> selectAllToFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.END))
/* 174 */             .shift(), paramKeyEvent -> selectAllToLastRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP))
/* 175 */             .shift(), paramKeyEvent -> selectAllPageUp()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN))
/* 176 */             .shift(), paramKeyEvent -> selectAllPageDown()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE))
/*     */             
/* 178 */             .shift(), paramKeyEvent -> selectAllToFocus(false)), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE))
/* 179 */             .shortcut().shift(), paramKeyEvent -> selectAllToFocus(true)), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.HOME))
/*     */             
/* 181 */             .shortcut(), paramKeyEvent -> focusFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.END))
/* 182 */             .shortcut(), paramKeyEvent -> focusLastRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.PAGE_UP, paramKeyEvent -> scrollUp()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.PAGE_DOWN, paramKeyEvent -> scrollDown()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, paramKeyEvent -> toggleFocusOwnerSelection()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.A))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 189 */             .shortcut(), paramKeyEvent -> selectAll()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP))
/* 190 */             .shortcut(), paramKeyEvent -> focusPageUp()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN))
/* 191 */             .shortcut(), paramKeyEvent -> focusPageDown()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.UP))
/* 192 */             .shortcut(), paramKeyEvent -> focusPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN))
/* 193 */             .shortcut(), paramKeyEvent -> focusNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.UP))
/* 194 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN))
/* 195 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP))
/* 196 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectPageUp()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN))
/* 197 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectPageDown()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.HOME))
/* 198 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectAllToFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.END))
/* 199 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectAllToLastRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> rtl(paramTreeView, this::expandRow, this::collapseRow)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_LEFT, paramKeyEvent -> rtl(paramTreeView, this::expandRow, this::collapseRow)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> rtl(paramTreeView, this::collapseRow, this::expandRow)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_RIGHT, paramKeyEvent -> rtl(paramTreeView, this::collapseRow, this::expandRow)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.MULTIPLY, paramKeyEvent -> expandAll()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ADD, paramKeyEvent -> expandRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SUBTRACT, paramKeyEvent -> collapseRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> selectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_UP, paramKeyEvent -> selectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> selectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_DOWN, paramKeyEvent -> selectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.UP))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 216 */             .shift(), paramKeyEvent -> alsoSelectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_UP))
/* 217 */             .shift(), paramKeyEvent -> alsoSelectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN))
/* 218 */             .shift(), paramKeyEvent -> alsoSelectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_DOWN))
/* 219 */             .shift(), paramKeyEvent -> alsoSelectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ENTER, paramKeyEvent -> edit()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.F2, paramKeyEvent -> edit()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ESCAPE, paramKeyEvent -> cancelEdit()), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     InputMap<TreeView<T>> inputMap1 = new InputMap(paramTreeView);
/* 231 */     inputMap1.setInterceptor(paramEvent -> !PlatformUtil.isMac());
/* 232 */     addDefaultMapping(inputMap1, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE)).shortcut().ctrl(), paramKeyEvent -> toggleFocusOwnerSelection()) });
/* 233 */     addDefaultChildMap(this.treeViewInputMap, inputMap1);
/*     */ 
/*     */     
/* 236 */     InputMap<TreeView<T>> inputMap2 = new InputMap(paramTreeView);
/* 237 */     inputMap2.setInterceptor(paramEvent -> PlatformUtil.isMac());
/* 238 */     addDefaultMapping(inputMap2, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE)).ctrl(), paramKeyEvent -> toggleFocusOwnerSelection()) });
/* 239 */     addDefaultChildMap(this.treeViewInputMap, inputMap2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 244 */     paramTreeView.addEventFilter(KeyEvent.ANY, this.keyEventListener);
/*     */ 
/*     */     
/* 247 */     paramTreeView.selectionModelProperty().addListener(this.weakSelectionModelListener);
/* 248 */     if (paramTreeView.getSelectionModel() != null) {
/* 249 */       paramTreeView.getSelectionModel().getSelectedIndices().addListener(this.weakSelectedIndicesListener);
/*     */     }
/*     */   }
/*     */   
/*     */   public InputMap<TreeView<T>> getInputMap() {
/* 254 */     return this.treeViewInputMap;
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 258 */     TreeCellBehavior.removeAnchor(getNode());
/* 259 */     super.dispose();
/*     */   }
/*     */   
/*     */   private void setAnchor(int paramInt) {
/* 263 */     TreeCellBehavior.setAnchor(getNode(), (paramInt < 0) ? null : (TreeCell<T>)Integer.valueOf(paramInt), false);
/*     */   }
/*     */   
/*     */   private int getAnchor() {
/* 267 */     return ((Integer)TreeCellBehavior.getAnchor(getNode(), (TreeCell<T>)Integer.valueOf(getNode().getFocusModel().getFocusedIndex()))).intValue();
/*     */   }
/*     */   
/*     */   private boolean hasAnchor() {
/* 271 */     return TreeCellBehavior.hasNonDefaultAnchor(getNode());
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent paramMouseEvent) {
/* 275 */     if (!paramMouseEvent.isShiftDown()) {
/* 276 */       int i = getNode().getSelectionModel().getSelectedIndex();
/* 277 */       setAnchor(i);
/*     */     } 
/*     */     
/* 280 */     if (!getNode().isFocused() && getNode().isFocusTraversable()) {
/* 281 */       getNode().requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private void clearSelection() {
/* 286 */     getNode().getSelectionModel().clearSelection();
/*     */   }
/*     */ 
/*     */   
/*     */   private void scrollUp() {
/* 291 */     int i = -1;
/* 292 */     if (this.onScrollPageUp != null) {
/* 293 */       i = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(false))).intValue();
/*     */     }
/* 295 */     if (i == -1)
/*     */       return; 
/* 297 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 298 */     if (multipleSelectionModel == null)
/* 299 */       return;  multipleSelectionModel.clearAndSelect(i);
/*     */   }
/*     */   
/*     */   private void scrollDown() {
/* 303 */     int i = -1;
/* 304 */     if (this.onScrollPageDown != null) {
/* 305 */       i = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(false))).intValue();
/*     */     }
/* 307 */     if (i == -1)
/*     */       return; 
/* 309 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 310 */     if (multipleSelectionModel == null)
/* 311 */       return;  multipleSelectionModel.clearAndSelect(i);
/*     */   }
/*     */   
/*     */   private void focusFirstRow() {
/* 315 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 316 */     if (focusModel == null)
/* 317 */       return;  focusModel.focus(0);
/*     */     
/* 319 */     if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*     */   }
/*     */   
/*     */   private void focusLastRow() {
/* 323 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 324 */     if (focusModel == null)
/* 325 */       return;  focusModel.focus(getNode().getExpandedItemCount() - 1);
/*     */     
/* 327 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*     */   }
/*     */   
/*     */   private void focusPreviousRow() {
/* 331 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 332 */     if (focusModel == null)
/*     */       return; 
/* 334 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 335 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 337 */     focusModel.focusPrevious();
/*     */     
/* 339 */     if (!this.isShortcutDown || getAnchor() == -1) {
/* 340 */       setAnchor(focusModel.getFocusedIndex());
/*     */     }
/*     */     
/* 343 */     if (this.onFocusPreviousRow != null) this.onFocusPreviousRow.run(); 
/*     */   }
/*     */   
/*     */   private void focusNextRow() {
/* 347 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 348 */     if (focusModel == null)
/*     */       return; 
/* 350 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 351 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 353 */     focusModel.focusNext();
/*     */     
/* 355 */     if (!this.isShortcutDown || getAnchor() == -1) {
/* 356 */       setAnchor(focusModel.getFocusedIndex());
/*     */     }
/*     */     
/* 359 */     if (this.onFocusNextRow != null) this.onFocusNextRow.run(); 
/*     */   }
/*     */   
/*     */   private void focusPageUp() {
/* 363 */     int i = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(true))).intValue();
/*     */     
/* 365 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 366 */     if (focusModel == null)
/* 367 */       return;  focusModel.focus(i);
/*     */   }
/*     */   
/*     */   private void focusPageDown() {
/* 371 */     int i = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(true))).intValue();
/*     */     
/* 373 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 374 */     if (focusModel == null)
/* 375 */       return;  focusModel.focus(i);
/*     */   }
/*     */   
/*     */   private void alsoSelectPreviousRow() {
/* 379 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 380 */     if (focusModel == null)
/*     */       return; 
/* 382 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 383 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 385 */     if (this.isShiftDown && getAnchor() != -1) {
/* 386 */       int i = focusModel.getFocusedIndex() - 1;
/* 387 */       if (i < 0)
/*     */         return; 
/* 389 */       int j = getAnchor();
/*     */       
/* 391 */       if (!hasAnchor()) {
/* 392 */         setAnchor(focusModel.getFocusedIndex());
/*     */       }
/*     */       
/* 395 */       if (multipleSelectionModel.getSelectedIndices().size() > 1) {
/* 396 */         clearSelectionOutsideRange(j, i);
/*     */       }
/*     */       
/* 399 */       if (j > i) {
/* 400 */         multipleSelectionModel.selectRange(j, i - 1);
/*     */       } else {
/* 402 */         multipleSelectionModel.selectRange(j, i + 1);
/*     */       } 
/*     */     } else {
/* 405 */       multipleSelectionModel.selectPrevious();
/*     */     } 
/*     */     
/* 408 */     this.onSelectPreviousRow.run();
/*     */   }
/*     */   
/*     */   private void alsoSelectNextRow() {
/* 412 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 413 */     if (focusModel == null)
/*     */       return; 
/* 415 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 416 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 418 */     if (this.isShiftDown && getAnchor() != -1) {
/* 419 */       int i = focusModel.getFocusedIndex() + 1;
/* 420 */       int j = getAnchor();
/*     */       
/* 422 */       if (!hasAnchor()) {
/* 423 */         setAnchor(focusModel.getFocusedIndex());
/*     */       }
/*     */       
/* 426 */       if (multipleSelectionModel.getSelectedIndices().size() > 1) {
/* 427 */         clearSelectionOutsideRange(j, i);
/*     */       }
/*     */       
/* 430 */       if (j > i) {
/* 431 */         multipleSelectionModel.selectRange(j, i - 1);
/*     */       } else {
/* 433 */         multipleSelectionModel.selectRange(j, i + 1);
/*     */       } 
/*     */     } else {
/* 436 */       multipleSelectionModel.selectNext();
/*     */     } 
/*     */     
/* 439 */     this.onSelectNextRow.run();
/*     */   }
/*     */   
/*     */   private void clearSelectionOutsideRange(int paramInt1, int paramInt2) {
/* 443 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 444 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 446 */     int i = Math.min(paramInt1, paramInt2);
/* 447 */     int j = Math.max(paramInt1, paramInt2);
/*     */     
/* 449 */     ArrayList<Integer> arrayList = new ArrayList<>(multipleSelectionModel.getSelectedIndices());
/*     */     
/* 451 */     this.selectionChanging = true;
/* 452 */     for (byte b = 0; b < arrayList.size(); b++) {
/* 453 */       int k = ((Integer)arrayList.get(b)).intValue();
/* 454 */       if (k < i || k > j) {
/* 455 */         multipleSelectionModel.clearSelection(k);
/*     */       }
/*     */     } 
/* 458 */     this.selectionChanging = false;
/*     */   }
/*     */   
/*     */   private void selectPreviousRow() {
/* 462 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 463 */     if (focusModel == null)
/*     */       return; 
/* 465 */     int i = focusModel.getFocusedIndex();
/* 466 */     if (i <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 470 */     setAnchor(i - 1);
/* 471 */     getNode().getSelectionModel().clearAndSelect(i - 1);
/* 472 */     this.onSelectPreviousRow.run();
/*     */   }
/*     */   
/*     */   private void selectNextRow() {
/* 476 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 477 */     if (focusModel == null)
/*     */       return; 
/* 479 */     int i = focusModel.getFocusedIndex();
/* 480 */     if (i == getNode().getExpandedItemCount() - 1) {
/*     */       return;
/*     */     }
/*     */     
/* 484 */     setAnchor(i + 1);
/* 485 */     getNode().getSelectionModel().clearAndSelect(i + 1);
/* 486 */     this.onSelectNextRow.run();
/*     */   }
/*     */   
/*     */   private void selectFirstRow() {
/* 490 */     if (getNode().getExpandedItemCount() > 0) {
/* 491 */       getNode().getSelectionModel().clearAndSelect(0);
/* 492 */       if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void selectLastRow() {
/* 497 */     getNode().getSelectionModel().clearAndSelect(getNode().getExpandedItemCount() - 1);
/* 498 */     this.onMoveToLastCell.run();
/*     */   }
/*     */   
/*     */   private void selectAllToFirstRow() {
/* 502 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 503 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 505 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 506 */     if (focusModel == null)
/*     */       return; 
/* 508 */     int i = focusModel.getFocusedIndex();
/*     */     
/* 510 */     if (this.isShiftDown) {
/* 511 */       i = hasAnchor() ? getAnchor() : i;
/*     */     }
/*     */     
/* 514 */     multipleSelectionModel.clearSelection();
/* 515 */     multipleSelectionModel.selectRange(i, -1);
/*     */ 
/*     */     
/* 518 */     focusModel.focus(0);
/*     */     
/* 520 */     if (this.isShiftDown) {
/* 521 */       setAnchor(i);
/*     */     }
/*     */     
/* 524 */     if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*     */   }
/*     */   
/*     */   private void selectAllToLastRow() {
/* 528 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 529 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 531 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 532 */     if (focusModel == null)
/*     */       return; 
/* 534 */     int i = focusModel.getFocusedIndex();
/*     */     
/* 536 */     if (this.isShiftDown) {
/* 537 */       i = hasAnchor() ? getAnchor() : i;
/*     */     }
/*     */     
/* 540 */     multipleSelectionModel.clearSelection();
/* 541 */     multipleSelectionModel.selectRange(i, getNode().getExpandedItemCount());
/*     */     
/* 543 */     if (this.isShiftDown) {
/* 544 */       setAnchor(i);
/*     */     }
/*     */     
/* 547 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*     */   }
/*     */   
/*     */   private void selectAll() {
/* 551 */     getNode().getSelectionModel().selectAll();
/*     */   }
/*     */   
/*     */   private void selectAllPageUp() {
/* 555 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 556 */     if (focusModel == null)
/*     */       return; 
/* 558 */     int i = focusModel.getFocusedIndex();
/* 559 */     if (this.isShiftDown) {
/* 560 */       i = (getAnchor() == -1) ? i : getAnchor();
/* 561 */       setAnchor(i);
/*     */     } 
/*     */     
/* 564 */     int j = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(false))).intValue();
/*     */ 
/*     */     
/* 567 */     byte b = (i < j) ? 1 : -1;
/*     */     
/* 569 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 570 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 572 */     this.selectionChanging = true;
/* 573 */     if (multipleSelectionModel.getSelectionMode() == SelectionMode.SINGLE) {
/* 574 */       multipleSelectionModel.select(j);
/*     */     } else {
/* 576 */       multipleSelectionModel.clearSelection();
/* 577 */       multipleSelectionModel.selectRange(i, j + b);
/*     */     } 
/* 579 */     this.selectionChanging = false;
/*     */   }
/*     */   
/*     */   private void selectAllPageDown() {
/* 583 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 584 */     if (focusModel == null)
/*     */       return; 
/* 586 */     int i = focusModel.getFocusedIndex();
/* 587 */     if (this.isShiftDown) {
/* 588 */       i = (getAnchor() == -1) ? i : getAnchor();
/* 589 */       setAnchor(i);
/*     */     } 
/*     */     
/* 592 */     int j = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(false))).intValue();
/*     */ 
/*     */     
/* 595 */     byte b = (i < j) ? 1 : -1;
/*     */     
/* 597 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 598 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 600 */     this.selectionChanging = true;
/* 601 */     if (multipleSelectionModel.getSelectionMode() == SelectionMode.SINGLE) {
/* 602 */       multipleSelectionModel.select(j);
/*     */     } else {
/* 604 */       multipleSelectionModel.clearSelection();
/* 605 */       multipleSelectionModel.selectRange(i, j + b);
/*     */     } 
/* 607 */     this.selectionChanging = false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void selectAllToFocus(boolean paramBoolean) {
/* 612 */     TreeView<T> treeView = getNode();
/* 613 */     if (treeView.getEditingItem() != null)
/*     */       return; 
/* 615 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = treeView.getSelectionModel();
/* 616 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 618 */     FocusModel<TreeItem<T>> focusModel = treeView.getFocusModel();
/* 619 */     if (focusModel == null)
/*     */       return; 
/* 621 */     int i = focusModel.getFocusedIndex();
/* 622 */     int j = getAnchor();
/*     */     
/* 624 */     multipleSelectionModel.clearSelection();
/* 625 */     int k = j;
/* 626 */     int m = (j > i) ? (i - 1) : (i + 1);
/* 627 */     multipleSelectionModel.selectRange(k, m);
/* 628 */     setAnchor(paramBoolean ? i : j);
/*     */   }
/*     */   
/*     */   private void expandRow() {
/* 632 */     Callback<TreeItem<?>, Integer> callback = paramTreeItem -> Integer.valueOf(getNode().getRow(paramTreeItem));
/* 633 */     expandRow(getNode().getSelectionModel(), callback);
/*     */   }
/*     */   
/*     */   private void expandAll() {
/* 637 */     expandAll(getNode().getRoot());
/*     */   }
/*     */   
/*     */   private void collapseRow() {
/* 641 */     TreeView<T> treeView = getNode();
/* 642 */     collapseRow(treeView.getSelectionModel(), treeView.getRoot(), treeView.isShowRoot());
/*     */   }
/*     */   
/*     */   static <T> void expandRow(MultipleSelectionModel<TreeItem<T>> paramMultipleSelectionModel, Callback<TreeItem<T>, Integer> paramCallback) {
/* 646 */     if (paramMultipleSelectionModel == null)
/*     */       return; 
/* 648 */     TreeItem treeItem = paramMultipleSelectionModel.getSelectedItem();
/* 649 */     if (treeItem == null || treeItem.isLeaf())
/*     */       return; 
/* 651 */     if (treeItem.isExpanded()) {
/*     */       
/* 653 */       ObservableList<TreeItem<T>> observableList = treeItem.getChildren();
/* 654 */       if (!observableList.isEmpty()) {
/* 655 */         paramMultipleSelectionModel.clearAndSelect(((Integer)paramCallback.call(observableList.get(0))).intValue());
/*     */       }
/*     */     } else {
/* 658 */       treeItem.setExpanded(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   static <T> void expandAll(TreeItem<T> paramTreeItem) {
/* 663 */     if (paramTreeItem == null)
/*     */       return; 
/* 665 */     paramTreeItem.setExpanded(true);
/* 666 */     expandChildren(paramTreeItem);
/*     */   }
/*     */   
/*     */   private static <T> void expandChildren(TreeItem<T> paramTreeItem) {
/* 670 */     if (paramTreeItem == null)
/* 671 */       return;  ObservableList<TreeItem<T>> observableList = paramTreeItem.getChildren();
/* 672 */     if (observableList == null)
/*     */       return; 
/* 674 */     for (byte b = 0; b < observableList.size(); b++) {
/* 675 */       TreeItem<?> treeItem = observableList.get(b);
/* 676 */       if (treeItem != null && !treeItem.isLeaf()) {
/*     */         
/* 678 */         treeItem.setExpanded(true);
/* 679 */         expandChildren(treeItem);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   static <T> void collapseRow(MultipleSelectionModel<TreeItem<T>> paramMultipleSelectionModel, TreeItem<T> paramTreeItem, boolean paramBoolean) {
/* 684 */     if (paramMultipleSelectionModel == null)
/*     */       return; 
/* 686 */     TreeItem<T> treeItem = paramMultipleSelectionModel.getSelectedItem();
/* 687 */     if (treeItem == null)
/* 688 */       return;  if (paramTreeItem == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 693 */     if (!paramBoolean && (
/* 694 */       !treeItem.isExpanded() || treeItem.isLeaf()) && paramTreeItem
/* 695 */       .equals(treeItem.getParent())) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 701 */     if (paramTreeItem.equals(treeItem) && (!paramTreeItem.isExpanded() || paramTreeItem.getChildren().isEmpty())) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 707 */     if (treeItem.isLeaf() || !treeItem.isExpanded()) {
/* 708 */       paramMultipleSelectionModel.clearSelection();
/* 709 */       paramMultipleSelectionModel.select(treeItem.getParent());
/*     */     } else {
/* 711 */       treeItem.setExpanded(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cancelEdit() {
/* 716 */     getNode().edit((TreeItem<T>)null);
/*     */   }
/*     */   
/*     */   private void edit() {
/* 720 */     TreeItem<T> treeItem = getNode().getSelectionModel().getSelectedItem();
/* 721 */     if (treeItem == null)
/*     */       return; 
/* 723 */     getNode().edit(treeItem);
/*     */   }
/*     */   
/*     */   private void toggleFocusOwnerSelection() {
/* 727 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 728 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 730 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 731 */     if (focusModel == null)
/*     */       return; 
/* 733 */     int i = focusModel.getFocusedIndex();
/*     */     
/* 735 */     if (multipleSelectionModel.isSelected(i)) {
/* 736 */       multipleSelectionModel.clearSelection(i);
/* 737 */       focusModel.focus(i);
/*     */     } else {
/* 739 */       multipleSelectionModel.select(i);
/*     */     } 
/*     */     
/* 742 */     setAnchor(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void discontinuousSelectPreviousRow() {
/* 750 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 751 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 753 */     if (multipleSelectionModel.getSelectionMode() != SelectionMode.MULTIPLE) {
/* 754 */       selectPreviousRow();
/*     */       
/*     */       return;
/*     */     } 
/* 758 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 759 */     if (focusModel == null)
/*     */       return; 
/* 761 */     int i = focusModel.getFocusedIndex();
/* 762 */     int j = i - 1;
/* 763 */     if (j < 0)
/*     */       return; 
/* 765 */     int k = i;
/* 766 */     if (this.isShiftDown) {
/* 767 */       k = (getAnchor() == -1) ? i : getAnchor();
/*     */     }
/*     */     
/* 770 */     multipleSelectionModel.selectRange(j, k + 1);
/* 771 */     focusModel.focus(j);
/*     */     
/* 773 */     if (this.onFocusPreviousRow != null) this.onFocusPreviousRow.run(); 
/*     */   }
/*     */   
/*     */   private void discontinuousSelectNextRow() {
/* 777 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 778 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 780 */     if (multipleSelectionModel.getSelectionMode() != SelectionMode.MULTIPLE) {
/* 781 */       selectNextRow();
/*     */       
/*     */       return;
/*     */     } 
/* 785 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 786 */     if (focusModel == null)
/*     */       return; 
/* 788 */     int i = focusModel.getFocusedIndex();
/* 789 */     int j = i + 1;
/* 790 */     if (j >= getNode().getExpandedItemCount())
/*     */       return; 
/* 792 */     int k = i;
/* 793 */     if (this.isShiftDown) {
/* 794 */       k = (getAnchor() == -1) ? i : getAnchor();
/*     */     }
/*     */     
/* 797 */     multipleSelectionModel.selectRange(k, j + 1);
/* 798 */     focusModel.focus(j);
/*     */     
/* 800 */     if (this.onFocusNextRow != null) this.onFocusNextRow.run(); 
/*     */   }
/*     */   
/*     */   private void discontinuousSelectPageUp() {
/* 804 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 805 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 807 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 808 */     if (focusModel == null)
/*     */       return; 
/* 810 */     int i = getAnchor();
/* 811 */     int j = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(false))).intValue();
/* 812 */     multipleSelectionModel.selectRange(i, j - 1);
/*     */   }
/*     */   
/*     */   private void discontinuousSelectPageDown() {
/* 816 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 817 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 819 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 820 */     if (focusModel == null)
/*     */       return; 
/* 822 */     int i = getAnchor();
/* 823 */     int j = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(false))).intValue();
/* 824 */     multipleSelectionModel.selectRange(i, j + 1);
/*     */   }
/*     */   
/*     */   private void discontinuousSelectAllToFirstRow() {
/* 828 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 829 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 831 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 832 */     if (focusModel == null)
/*     */       return; 
/* 834 */     int i = focusModel.getFocusedIndex();
/* 835 */     multipleSelectionModel.selectRange(0, i);
/* 836 */     focusModel.focus(0);
/*     */     
/* 838 */     if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*     */   }
/*     */   
/*     */   private void discontinuousSelectAllToLastRow() {
/* 842 */     MultipleSelectionModel<TreeItem<T>> multipleSelectionModel = getNode().getSelectionModel();
/* 843 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 845 */     FocusModel<TreeItem<T>> focusModel = getNode().getFocusModel();
/* 846 */     if (focusModel == null)
/*     */       return; 
/* 848 */     int i = focusModel.getFocusedIndex() + 1;
/* 849 */     multipleSelectionModel.selectRange(i, getNode().getExpandedItemCount());
/*     */     
/* 851 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TreeViewBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */