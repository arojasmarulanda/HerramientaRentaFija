/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.event.Event;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.CheckMenuItem;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.Menu;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.RadioMenuItem;
/*     */ import javafx.scene.control.Tab;
/*     */ import javafx.scene.control.TabPane;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ import javafx.scene.input.KeyCombination;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ControlAcceleratorSupport
/*     */ {
/*     */   public static void addAcceleratorsIntoScene(ObservableList<MenuItem> paramObservableList, Tab paramTab) {
/*  56 */     addAcceleratorsIntoScene(paramObservableList, paramTab);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addAcceleratorsIntoScene(ObservableList<MenuItem> paramObservableList, TableColumnBase<?, ?> paramTableColumnBase) {
/*  61 */     addAcceleratorsIntoScene(paramObservableList, paramTableColumnBase);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addAcceleratorsIntoScene(final ObservableList<MenuItem> items, final Node anchor) {
/*  67 */     if (items == null) {
/*     */       return;
/*     */     }
/*     */     
/*  71 */     if (anchor == null) {
/*  72 */       throw new IllegalArgumentException("Anchor cannot be null");
/*     */     }
/*     */     
/*  75 */     Scene scene = anchor.getScene();
/*  76 */     if (scene == null) {
/*     */ 
/*     */       
/*  79 */       anchor.sceneProperty().addListener(new InvalidationListener() {
/*     */             public void invalidated(Observable param1Observable) {
/*  81 */               Scene scene = anchor.getScene();
/*  82 */               if (scene != null) {
/*  83 */                 anchor.sceneProperty().removeListener(this);
/*  84 */                 ControlAcceleratorSupport.doAcceleratorInstall(items, scene);
/*     */               } 
/*     */             }
/*     */           });
/*     */     } else {
/*  89 */       doAcceleratorInstall(items, scene);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addAcceleratorsIntoScene(final ObservableList<MenuItem> items, Object paramObject) {
/*  95 */     if (paramObject == null) {
/*  96 */       throw new IllegalArgumentException("Anchor cannot be null");
/*     */     }
/*     */     
/*  99 */     final ReadOnlyObjectProperty<? extends Control> controlProperty = getControlProperty(paramObject);
/* 100 */     Control control = readOnlyObjectProperty.get();
/* 101 */     if (control == null) {
/* 102 */       readOnlyObjectProperty.addListener(new InvalidationListener() {
/*     */             public void invalidated(Observable param1Observable) {
/* 104 */               Control control = controlProperty.get();
/* 105 */               if (control != null) {
/* 106 */                 controlProperty.removeListener(this);
/* 107 */                 ControlAcceleratorSupport.addAcceleratorsIntoScene(items, control);
/*     */               } 
/*     */             }
/*     */           });
/*     */     } else {
/* 112 */       addAcceleratorsIntoScene(items, control);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void doAcceleratorInstall(ObservableList<MenuItem> paramObservableList, Scene paramScene) {
/* 120 */     paramObservableList.addListener(paramChange -> {
/*     */           while (paramChange.next()) {
/*     */             if (paramChange.wasRemoved()) {
/*     */               removeAcceleratorsFromScene(paramChange.getRemoved(), paramScene);
/*     */             }
/*     */ 
/*     */             
/*     */             if (paramChange.wasAdded()) {
/*     */               doAcceleratorInstall(paramChange.getAddedSubList(), paramScene);
/*     */             }
/*     */           } 
/*     */         });
/*     */     
/* 133 */     doAcceleratorInstall(paramObservableList, paramScene);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void doAcceleratorInstall(List<? extends MenuItem> paramList, Scene paramScene) {
/* 138 */     for (Iterator<? extends MenuItem> iterator = paramList.iterator(); iterator.hasNext(); ) { MenuItem menuItem = iterator.next();
/* 139 */       if (menuItem instanceof Menu) {
/*     */         
/* 141 */         doAcceleratorInstall(((Menu)menuItem).getItems(), paramScene);
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 146 */       if (menuItem.getAccelerator() != null) {
/* 147 */         ObservableMap<KeyCombination, Runnable> observableMap = paramScene.getAccelerators();
/*     */         
/* 149 */         Runnable runnable = () -> {
/*     */             if (paramMenuItem.getOnMenuValidation() != null) {
/*     */               Event.fireEvent(paramMenuItem, new Event(MenuItem.MENU_VALIDATION_EVENT));
/*     */             }
/*     */             
/*     */             Menu menu = paramMenuItem.getParentMenu();
/*     */             
/*     */             if (menu != null && menu.getOnMenuValidation() != null) {
/*     */               Event.fireEvent(menu, new Event(MenuItem.MENU_VALIDATION_EVENT));
/*     */             }
/*     */             if (!paramMenuItem.isDisable()) {
/*     */               if (paramMenuItem instanceof RadioMenuItem) {
/*     */                 ((RadioMenuItem)paramMenuItem).setSelected(!((RadioMenuItem)paramMenuItem).isSelected());
/*     */               } else if (paramMenuItem instanceof CheckMenuItem) {
/*     */                 ((CheckMenuItem)paramMenuItem).setSelected(!((CheckMenuItem)paramMenuItem).isSelected());
/*     */               } 
/*     */               paramMenuItem.fire();
/*     */             } 
/*     */           };
/* 168 */         observableMap.put(menuItem.getAccelerator(), runnable);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 173 */       menuItem.acceleratorProperty().addListener((paramObservableValue, paramKeyCombination1, paramKeyCombination2) -> {
/*     */             ObservableMap<KeyCombination, Runnable> observableMap = paramScene.getAccelerators();
/*     */             Runnable runnable = observableMap.remove(paramKeyCombination1);
/*     */             if (paramKeyCombination2 != null) {
/*     */               observableMap.put(paramKeyCombination2, runnable);
/*     */             }
/*     */           }); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeAcceleratorsFromScene(List<? extends MenuItem> paramList, Tab paramTab) {
/* 193 */     TabPane tabPane = paramTab.getTabPane();
/* 194 */     if (tabPane == null)
/*     */       return; 
/* 196 */     Scene scene = tabPane.getScene();
/* 197 */     removeAcceleratorsFromScene(paramList, scene);
/*     */   }
/*     */   
/*     */   public static void removeAcceleratorsFromScene(List<? extends MenuItem> paramList, TableColumnBase<?, ?> paramTableColumnBase) {
/* 201 */     ReadOnlyObjectProperty<? extends Control> readOnlyObjectProperty = getControlProperty(paramTableColumnBase);
/* 202 */     if (readOnlyObjectProperty == null)
/*     */       return; 
/* 204 */     Control control = readOnlyObjectProperty.get();
/* 205 */     if (control == null)
/*     */       return; 
/* 207 */     Scene scene = control.getScene();
/* 208 */     removeAcceleratorsFromScene(paramList, scene);
/*     */   }
/*     */   
/*     */   public static void removeAcceleratorsFromScene(List<? extends MenuItem> paramList, Node paramNode) {
/* 212 */     Scene scene = paramNode.getScene();
/* 213 */     removeAcceleratorsFromScene(paramList, scene);
/*     */   }
/*     */   
/*     */   public static void removeAcceleratorsFromScene(List<? extends MenuItem> paramList, Scene paramScene) {
/* 217 */     if (paramScene == null) {
/*     */       return;
/*     */     }
/*     */     
/* 221 */     for (MenuItem menuItem : paramList) {
/* 222 */       if (menuItem instanceof Menu) {
/*     */ 
/*     */ 
/*     */         
/* 226 */         removeAcceleratorsFromScene(((Menu)menuItem).getItems(), paramScene);
/*     */         
/*     */         continue;
/*     */       } 
/* 230 */       ObservableMap<KeyCombination, Runnable> observableMap = paramScene.getAccelerators();
/* 231 */       observableMap.remove(menuItem.getAccelerator());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ReadOnlyObjectProperty<? extends Control> getControlProperty(Object paramObject) {
/* 241 */     if (paramObject instanceof TableColumn)
/* 242 */       return ((TableColumn)paramObject).tableViewProperty(); 
/* 243 */     if (paramObject instanceof TreeTableColumn)
/* 244 */       return ((TreeTableColumn)paramObject).treeTableViewProperty(); 
/* 245 */     if (paramObject instanceof Tab) {
/* 246 */       return (ReadOnlyObjectProperty)((Tab)paramObject).tabPaneProperty();
/*     */     }
/*     */     
/* 249 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\ControlAcceleratorSupport.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */