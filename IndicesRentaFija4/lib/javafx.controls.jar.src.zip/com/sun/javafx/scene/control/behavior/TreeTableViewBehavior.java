/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.beans.value.WeakChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TableFocusModel;
/*     */ import javafx.scene.control.TablePositionBase;
/*     */ import javafx.scene.control.TableSelectionModel;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ import javafx.scene.control.TreeTablePosition;
/*     */ import javafx.scene.control.TreeTableView;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeTableViewBehavior<T>
/*     */   extends TableViewBehaviorBase<TreeTableView<T>, TreeItem<T>, TreeTableColumn<T, ?>>
/*     */ {
/*     */   private final ChangeListener<TreeTableView.TreeTableViewSelectionModel<T>> selectionModelListener;
/*     */   private final WeakChangeListener<TreeTableView.TreeTableViewSelectionModel<T>> weakSelectionModelListener;
/*     */   
/*     */   public TreeTableViewBehavior(TreeTableView<T> paramTreeTableView) {
/*  74 */     super(paramTreeTableView); this.selectionModelListener = ((paramObservableValue, paramTreeTableViewSelectionModel1, paramTreeTableViewSelectionModel2) -> { if (paramTreeTableViewSelectionModel1 != null)
/*     */           paramTreeTableViewSelectionModel1.getSelectedCells().removeListener(this.weakSelectedCellsListener);  if (paramTreeTableViewSelectionModel2 != null)
/*     */           paramTreeTableViewSelectionModel2.getSelectedCells().addListener(this.weakSelectedCellsListener); 
/*  77 */       }); this.weakSelectionModelListener = new WeakChangeListener<>(this.selectionModelListener); InputMap inputMap = new InputMap(paramTreeTableView);
/*  78 */     inputMap.getMappings().addAll(new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> rtl(paramTreeTableView, this::expandRow, this::collapseRow)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_LEFT, paramKeyEvent -> rtl(paramTreeTableView, this::expandRow, this::collapseRow)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> rtl(paramTreeTableView, this::collapseRow, this::expandRow)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_RIGHT, paramKeyEvent -> rtl(paramTreeTableView, this::collapseRow, this::expandRow)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.MULTIPLY, paramKeyEvent -> expandAll()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ADD, paramKeyEvent -> expandRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SUBTRACT, paramKeyEvent -> collapseRow()) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     addDefaultChildMap(getInputMap(), inputMap);
/*     */ 
/*     */ 
/*     */     
/*  93 */     paramTreeTableView.selectionModelProperty().addListener(this.weakSelectionModelListener);
/*  94 */     if (getSelectionModel() != null) {
/*  95 */       paramTreeTableView.getSelectionModel().getSelectedCells().addListener(this.selectedCellsListener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getItemCount() {
/* 109 */     return getNode().getExpandedItemCount();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TableFocusModel getFocusModel() {
/* 114 */     return getNode().getFocusModel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TableSelectionModel<TreeItem<T>> getSelectionModel() {
/* 119 */     return getNode().getSelectionModel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ObservableList<TreeTablePosition<T, ?>> getSelectedCells() {
/* 124 */     return getNode().getSelectionModel().getSelectedCells();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TablePositionBase getFocusedCell() {
/* 129 */     return getNode().getFocusModel().getFocusedCell();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getVisibleLeafIndex(TableColumnBase paramTableColumnBase) {
/* 134 */     return getNode().getVisibleLeafIndex((TreeTableColumn<T, ?>)paramTableColumnBase);
/*     */   }
/*     */ 
/*     */   
/*     */   protected TreeTableColumn getVisibleLeafColumn(int paramInt) {
/* 139 */     return getNode().getVisibleLeafColumn(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isControlEditable() {
/* 144 */     return getNode().isEditable();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void editCell(int paramInt, TableColumnBase paramTableColumnBase) {
/* 149 */     getNode().edit(paramInt, (TreeTableColumn<T, ?>)paramTableColumnBase);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ObservableList<TreeTableColumn<T, ?>> getVisibleLeafColumns() {
/* 154 */     return getNode().getVisibleLeafColumns();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TablePositionBase<TreeTableColumn<T, ?>> getTablePosition(int paramInt, TableColumnBase<TreeItem<T>, ?> paramTableColumnBase) {
/* 160 */     return new TreeTablePosition<>(getNode(), paramInt, (TreeTableColumn)paramTableColumnBase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void selectAllToFocus(boolean paramBoolean) {
/* 174 */     if (getNode().getEditingCell() != null)
/*     */       return; 
/* 176 */     super.selectAllToFocus(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rightArrowPressed() {
/* 190 */     if (getNode().getSelectionModel().isCellSelectionEnabled()) {
/* 191 */       if (isRTL()) {
/* 192 */         selectLeftCell();
/*     */       } else {
/* 194 */         selectRightCell();
/*     */       } 
/*     */     } else {
/* 197 */       expandRow();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void leftArrowPressed() {
/* 202 */     if (getNode().getSelectionModel().isCellSelectionEnabled()) {
/* 203 */       if (isRTL()) {
/* 204 */         selectRightCell();
/*     */       } else {
/* 206 */         selectLeftCell();
/*     */       } 
/*     */     } else {
/* 209 */       collapseRow();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void expandRow() {
/* 214 */     Callback<TreeItem<?>, Integer> callback = paramTreeItem -> Integer.valueOf(getNode().getRow(paramTreeItem));
/* 215 */     TreeViewBehavior.expandRow(getNode().getSelectionModel(), callback);
/*     */   }
/*     */   
/*     */   private void expandAll() {
/* 219 */     TreeViewBehavior.expandAll(getNode().getRoot());
/*     */   }
/*     */   
/*     */   private void collapseRow() {
/* 223 */     TreeTableView<T> treeTableView = getNode();
/* 224 */     TreeViewBehavior.collapseRow(treeTableView.getSelectionModel(), treeTableView.getRoot(), treeTableView.isShowRoot());
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TreeTableViewBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */