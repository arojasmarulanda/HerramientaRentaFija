/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.Timeline;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.scene.control.Spinner;
/*     */ import javafx.scene.control.SpinnerValueFactory;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpinnerBehavior<T>
/*     */   extends BehaviorBase<Spinner<T>>
/*     */ {
/*     */   private static final double INITIAL_DURATION_MS = 750.0D;
/*     */   private final InputMap<Spinner<T>> spinnerInputMap;
/*     */   private static final int STEP_AMOUNT = 1;
/*     */   private boolean isIncrementing = false;
/*     */   private Timeline timeline;
/*     */   final EventHandler<ActionEvent> spinningKeyFrameEventHandler;
/*     */   
/*     */   public SpinnerBehavior(Spinner<T> paramSpinner) {
/*  80 */     super(paramSpinner); this.spinningKeyFrameEventHandler = (paramActionEvent -> { SpinnerValueFactory<T> spinnerValueFactory = getNode().getValueFactory(); if (spinnerValueFactory == null)
/*     */           return;  if (this.isIncrementing) { increment(1); }
/*     */         else { decrement(1); }
/*     */       
/*  84 */       }); this.spinnerInputMap = createInputMap();
/*     */ 
/*     */     
/*  87 */     addDefaultMapping(this.spinnerInputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, KeyEvent.KEY_PRESSED, paramKeyEvent -> { if (arrowsAreVertical()) { increment(1); } else { FocusTraversalInputMap.traverseUp(paramKeyEvent); }  }), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, KeyEvent.KEY_PRESSED, paramKeyEvent -> { if (!arrowsAreVertical()) { increment(1); } else { FocusTraversalInputMap.traverseRight(paramKeyEvent); }  }), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, KeyEvent.KEY_PRESSED, paramKeyEvent -> { if (!arrowsAreVertical()) { decrement(1); } else { FocusTraversalInputMap.traverseLeft(paramKeyEvent); }  }), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, KeyEvent.KEY_PRESSED, paramKeyEvent -> {
/*     */               if (arrowsAreVertical()) {
/*     */                 decrement(1);
/*     */               } else {
/*     */                 FocusTraversalInputMap.traverseDown(paramKeyEvent);
/*     */               } 
/*     */             }) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputMap<Spinner<T>> getInputMap() {
/* 112 */     return this.spinnerInputMap;
/*     */   }
/*     */   
/*     */   public void increment(int paramInt) {
/* 116 */     getNode().increment(paramInt);
/*     */   }
/*     */   
/*     */   public void decrement(int paramInt) {
/* 120 */     getNode().decrement(paramInt);
/*     */   }
/*     */   
/*     */   public void startSpinning(boolean paramBoolean) {
/* 124 */     this.isIncrementing = paramBoolean;
/*     */     
/* 126 */     if (this.timeline != null) {
/* 127 */       this.timeline.stop();
/*     */     }
/* 129 */     this.timeline = new Timeline();
/* 130 */     this.timeline.setCycleCount(-1);
/* 131 */     this.timeline.setDelay(getNode().getInitialDelay());
/* 132 */     KeyFrame keyFrame1 = new KeyFrame(Duration.ZERO, this.spinningKeyFrameEventHandler, new javafx.animation.KeyValue[0]);
/* 133 */     KeyFrame keyFrame2 = new KeyFrame(getNode().getRepeatDelay(), new javafx.animation.KeyValue[0]);
/* 134 */     this.timeline.getKeyFrames().setAll(new KeyFrame[] { keyFrame1, keyFrame2 });
/* 135 */     this.timeline.playFromStart();
/*     */     
/* 137 */     this.spinningKeyFrameEventHandler.handle(null);
/*     */   }
/*     */   
/*     */   public void stopSpinning() {
/* 141 */     if (this.timeline != null) {
/* 142 */       this.timeline.stop();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean arrowsAreVertical() {
/* 155 */     ObservableList<String> observableList = getNode().getStyleClass();
/*     */     
/* 157 */     return (!observableList.contains("arrows-on-left-horizontal") && 
/* 158 */       !observableList.contains("arrows-on-right-horizontal") && 
/* 159 */       !observableList.contains("split-arrows-horizontal"));
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\SpinnerBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */