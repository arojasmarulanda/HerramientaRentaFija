/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import java.util.ArrayList;
/*     */ import javafx.scene.control.Cell;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.FocusModel;
/*     */ import javafx.scene.control.IndexedCell;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.control.SelectionMode;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CellBehaviorBase<T extends Cell>
/*     */   extends BehaviorBase<T>
/*     */ {
/*     */   private static final String ANCHOR_PROPERTY_KEY = "anchor";
/*     */   private static final String IS_DEFAULT_ANCHOR_KEY = "isDefaultAnchor";
/*     */   private final InputMap<T> cellInputMap;
/*     */   
/*     */   public static <T> T getAnchor(Control paramControl, T paramT) {
/*  63 */     return hasNonDefaultAnchor(paramControl) ? 
/*  64 */       (T)paramControl.getProperties().get("anchor") : 
/*  65 */       paramT;
/*     */   }
/*     */   
/*     */   public static <T> void setAnchor(Control paramControl, T paramT, boolean paramBoolean) {
/*  69 */     if (paramControl == null)
/*  70 */       return;  if (paramT == null) {
/*  71 */       removeAnchor(paramControl);
/*     */     } else {
/*  73 */       paramControl.getProperties().put("anchor", paramT);
/*  74 */       paramControl.getProperties().put("isDefaultAnchor", Boolean.valueOf(paramBoolean));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean hasNonDefaultAnchor(Control paramControl) {
/*  79 */     Boolean bool = (Boolean)paramControl.getProperties().remove("isDefaultAnchor");
/*  80 */     return ((bool == null || !bool.booleanValue()) && hasAnchor(paramControl));
/*     */   }
/*     */   
/*     */   public static boolean hasDefaultAnchor(Control paramControl) {
/*  84 */     Boolean bool = (Boolean)paramControl.getProperties().remove("isDefaultAnchor");
/*  85 */     return (bool != null && bool.booleanValue() == true && hasAnchor(paramControl));
/*     */   }
/*     */   
/*     */   private static boolean hasAnchor(Control paramControl) {
/*  89 */     return (paramControl.getProperties().get("anchor") != null);
/*     */   }
/*     */   
/*     */   public static void removeAnchor(Control paramControl) {
/*  93 */     paramControl.getProperties().remove("anchor");
/*  94 */     paramControl.getProperties().remove("isDefaultAnchor");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean latePress = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Control getCellContainer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract MultipleSelectionModel<?> getSelectionModel();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellBehaviorBase(T paramT) {
/* 121 */     super(paramT);
/*     */ 
/*     */ 
/*     */     
/* 125 */     this.cellInputMap = createInputMap();
/*     */ 
/*     */     
/*     */     InputMap.MouseMapping mouseMapping1, mouseMapping2, mouseMapping3;
/*     */ 
/*     */     
/* 131 */     addDefaultMapping((InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)(mouseMapping1 = new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed)), (InputMap.Mapping)(mouseMapping2 = new InputMap.MouseMapping(MouseEvent.MOUSE_RELEASED, this::mouseReleased)), (InputMap.Mapping)(mouseMapping3 = new InputMap.MouseMapping(MouseEvent.MOUSE_DRAGGED, this::mouseDragged)) });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     mouseMapping1.setAutoConsume(false);
/* 137 */     mouseMapping2.setAutoConsume(false);
/* 138 */     mouseMapping3.setAutoConsume(false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract FocusModel<?> getFocusModel();
/*     */   
/*     */   protected abstract void edit(T paramT);
/*     */   
/*     */   protected boolean handleDisclosureNode(double paramDouble1, double paramDouble2) {
/* 147 */     return false;
/*     */   }
/*     */   protected boolean isClickPositionValid(double paramDouble1, double paramDouble2) {
/* 150 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputMap<T> getInputMap() {
/* 163 */     return this.cellInputMap;
/*     */   }
/*     */   
/*     */   protected int getIndex() {
/* 167 */     return (getNode() instanceof IndexedCell) ? ((IndexedCell)getNode()).getIndex() : -1;
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent paramMouseEvent) {
/* 171 */     if (paramMouseEvent.isSynthesized()) {
/* 172 */       this.latePress = true;
/*     */     } else {
/* 174 */       this.latePress = isSelected();
/* 175 */       if (!this.latePress) {
/* 176 */         doSelect(paramMouseEvent.getX(), paramMouseEvent.getY(), paramMouseEvent.getButton(), paramMouseEvent.getClickCount(), paramMouseEvent
/* 177 */             .isShiftDown(), paramMouseEvent.isShortcutDown());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseReleased(MouseEvent paramMouseEvent) {
/* 183 */     if (this.latePress) {
/* 184 */       this.latePress = false;
/* 185 */       doSelect(paramMouseEvent.getX(), paramMouseEvent.getY(), paramMouseEvent.getButton(), paramMouseEvent.getClickCount(), paramMouseEvent
/* 186 */           .isShiftDown(), paramMouseEvent.isShortcutDown());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseDragged(MouseEvent paramMouseEvent) {
/* 191 */     this.latePress = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doSelect(double paramDouble1, double paramDouble2, MouseButton paramMouseButton, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/* 205 */     Cell cell = (Cell)getNode();
/*     */     
/* 207 */     Control control = getCellContainer();
/*     */ 
/*     */ 
/*     */     
/* 211 */     if (cell.isEmpty() || !cell.contains(paramDouble1, paramDouble2)) {
/*     */       return;
/*     */     }
/*     */     
/* 215 */     int i = getIndex();
/* 216 */     boolean bool = cell.isSelected();
/* 217 */     MultipleSelectionModel<?> multipleSelectionModel = getSelectionModel();
/* 218 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 220 */     FocusModel<?> focusModel = getFocusModel();
/* 221 */     if (focusModel == null) {
/*     */       return;
/*     */     }
/*     */     
/* 225 */     if (handleDisclosureNode(paramDouble1, paramDouble2)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 230 */     if (!isClickPositionValid(paramDouble1, paramDouble2)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 236 */     if (paramBoolean1) {
/* 237 */       if (!hasNonDefaultAnchor(control)) {
/* 238 */         setAnchor(control, Integer.valueOf(focusModel.getFocusedIndex()), false);
/*     */       }
/*     */     } else {
/* 241 */       removeAnchor(control);
/*     */     } 
/*     */     
/* 244 */     if (paramMouseButton == MouseButton.PRIMARY || (paramMouseButton == MouseButton.SECONDARY && !bool)) {
/* 245 */       if (multipleSelectionModel.getSelectionMode() == SelectionMode.SINGLE) {
/* 246 */         simpleSelect(paramMouseButton, paramInt, paramBoolean2);
/*     */       }
/* 248 */       else if (paramBoolean2) {
/* 249 */         if (bool) {
/*     */           
/* 251 */           multipleSelectionModel.clearSelection(i);
/* 252 */           focusModel.focus(i);
/*     */         } else {
/*     */           
/* 255 */           multipleSelectionModel.select(i);
/*     */         } 
/* 257 */       } else if (paramBoolean1 && paramInt == 1) {
/*     */ 
/*     */         
/* 260 */         int j = ((Integer)getAnchor(control, Integer.valueOf(focusModel.getFocusedIndex()))).intValue();
/*     */         
/* 262 */         selectRows(j, i);
/*     */         
/* 264 */         focusModel.focus(i);
/*     */       } else {
/* 266 */         simpleSelect(paramMouseButton, paramInt, paramBoolean2);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void simpleSelect(MouseButton paramMouseButton, int paramInt, boolean paramBoolean) {
/* 273 */     int i = getIndex();
/* 274 */     MultipleSelectionModel<?> multipleSelectionModel = getSelectionModel();
/* 275 */     boolean bool = multipleSelectionModel.isSelected(i);
/*     */     
/* 277 */     if (bool && paramBoolean) {
/* 278 */       multipleSelectionModel.clearSelection(i);
/* 279 */       getFocusModel().focus(i);
/* 280 */       bool = false;
/*     */     } else {
/* 282 */       multipleSelectionModel.clearAndSelect(i);
/*     */     } 
/*     */     
/* 285 */     handleClicks(paramMouseButton, paramInt, bool);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleClicks(MouseButton paramMouseButton, int paramInt, boolean paramBoolean) {
/* 290 */     if (paramMouseButton == MouseButton.PRIMARY) {
/* 291 */       if (paramInt == 1 && paramBoolean) {
/* 292 */         edit(getNode());
/* 293 */       } else if (paramInt == 1) {
/*     */         
/* 295 */         edit((T)null);
/* 296 */       } else if (paramInt == 2 && ((Cell)getNode()).isEditable()) {
/* 297 */         edit(getNode());
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   void selectRows(int paramInt1, int paramInt2) {
/* 303 */     boolean bool = (paramInt1 < paramInt2) ? true : false;
/*     */ 
/*     */     
/* 306 */     int i = Math.min(paramInt1, paramInt2);
/* 307 */     int j = Math.max(paramInt1, paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     ArrayList<Integer> arrayList = new ArrayList<>(getSelectionModel().getSelectedIndices()); byte b; int k;
/* 313 */     for (b = 0, k = arrayList.size(); b < k; b++) {
/* 314 */       int m = ((Integer)arrayList.get(b)).intValue();
/* 315 */       if (m < i || m > j) {
/* 316 */         getSelectionModel().clearSelection(m);
/*     */       }
/*     */     } 
/*     */     
/* 320 */     if (i == j) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 325 */       getSelectionModel().select(i);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 331 */     else if (bool) {
/* 332 */       getSelectionModel().selectRange(i, j + 1);
/*     */     } else {
/* 334 */       getSelectionModel().selectRange(j, i - 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isSelected() {
/* 340 */     return ((Cell)getNode()).isSelected();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\CellBehaviorBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */