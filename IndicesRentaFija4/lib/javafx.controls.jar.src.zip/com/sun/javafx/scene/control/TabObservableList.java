/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import com.sun.javafx.collections.NonIterableChange;
/*    */ import com.sun.javafx.collections.ObservableListWrapper;
/*    */ import java.util.List;
/*    */ import java.util.ListIterator;
/*    */ import javafx.scene.control.Tab;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TabObservableList<E>
/*    */   extends ObservableListWrapper<E>
/*    */ {
/*    */   private final List<E> tabList;
/*    */   
/*    */   public TabObservableList(List<E> paramList) {
/* 42 */     super(paramList);
/* 43 */     this.tabList = paramList;
/*    */   }
/*    */   
/*    */   public void reorder(Tab paramTab1, Tab paramTab2) {
/* 47 */     if (!this.tabList.contains(paramTab1) || !this.tabList.contains(paramTab2) || paramTab1 == paramTab2) {
/*    */       return;
/*    */     }
/*    */     
/* 51 */     Object[] arrayOfObject = this.tabList.toArray();
/* 52 */     int i = this.tabList.indexOf(paramTab1);
/* 53 */     int j = this.tabList.indexOf(paramTab2);
/* 54 */     if (i == -1 || j == -1) {
/*    */       return;
/*    */     }
/* 57 */     int k = (j - i) / Math.abs(j - i);
/*    */     int m;
/* 59 */     for (m = i; m != j; m += k) {
/* 60 */       arrayOfObject[m] = arrayOfObject[m + k];
/*    */     }
/* 62 */     arrayOfObject[j] = paramTab1;
/*    */ 
/*    */     
/* 65 */     ListIterator<E> listIterator = this.tabList.listIterator(); int n;
/* 66 */     for (n = 0; n < this.tabList.size(); n++) {
/* 67 */       listIterator.next();
/* 68 */       listIterator.set((E)arrayOfObject[n]);
/*    */     } 
/*    */ 
/*    */     
/* 72 */     paramTab1.getTabPane().getSelectionModel().select(paramTab1);
/*    */ 
/*    */     
/* 75 */     n = Math.abs(j - i) + 1;
/* 76 */     int[] arrayOfInt = new int[n];
/* 77 */     int i1 = (k > 0) ? i : j;
/* 78 */     int i2 = (k < 0) ? i : j;
/* 79 */     for (byte b = 0; b < n; b++) {
/* 80 */       arrayOfInt[b] = b + i1;
/*    */     }
/* 82 */     fireChange(new NonIterableChange.SimplePermutationChange<>(i1, i2 + 1, arrayOfInt, this));
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\TabObservableList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */