/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.IntegerPropertyBase;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.beans.property.StringPropertyBase;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.control.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InputField
/*     */   extends Control
/*     */ {
/*     */   public static final int DEFAULT_PREF_COLUMN_COUNT = 12;
/*  47 */   private BooleanProperty editable = new SimpleBooleanProperty(this, "editable", true);
/*  48 */   public final boolean isEditable() { return this.editable.getValue().booleanValue(); }
/*  49 */   public final void setEditable(boolean paramBoolean) { this.editable.setValue(Boolean.valueOf(paramBoolean)); } public final BooleanProperty editableProperty() {
/*  50 */     return this.editable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private StringProperty promptText = new StringPropertyBase("")
/*     */     {
/*     */       protected void invalidated() {
/*  59 */         String str = get();
/*  60 */         if (str != null && str.contains("\n")) {
/*  61 */           str = str.replace("\n", "");
/*  62 */           set(str);
/*     */         } 
/*     */       }
/*     */       
/*  66 */       public Object getBean() { return InputField.this; }
/*  67 */       public String getName() { return "promptText"; }
/*     */     };
/*  69 */   public final StringProperty promptTextProperty() { return this.promptText; }
/*  70 */   public final String getPromptText() { return this.promptText.get(); } public final void setPromptText(String paramString) {
/*  71 */     this.promptText.set(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private IntegerProperty prefColumnCount = new IntegerPropertyBase(12) {
/*  79 */       private int oldValue = get();
/*     */ 
/*     */       
/*     */       protected void invalidated() {
/*  83 */         int i = get();
/*     */         
/*  85 */         if (i < 0) {
/*  86 */           if (isBound()) {
/*  87 */             unbind();
/*     */           }
/*  89 */           set(this.oldValue);
/*  90 */           throw new IllegalArgumentException("value cannot be negative.");
/*     */         } 
/*     */         
/*  93 */         this.oldValue = i;
/*     */       }
/*     */       
/*  96 */       public Object getBean() { return InputField.this; }
/*  97 */       public String getName() { return "prefColumnCount"; }
/*     */     };
/*  99 */   public final IntegerProperty prefColumnCountProperty() { return this.prefColumnCount; }
/* 100 */   public final int getPrefColumnCount() { return this.prefColumnCount.getValue().intValue(); } public final void setPrefColumnCount(int paramInt) {
/* 101 */     this.prefColumnCount.setValue(Integer.valueOf(paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private ObjectProperty<EventHandler<ActionEvent>> onAction = new ObjectPropertyBase<EventHandler<ActionEvent>>() {
/*     */       protected void invalidated() {
/* 111 */         InputField.this.setEventHandler((EventType)ActionEvent.ACTION, (EventHandler)get());
/*     */       }
/*     */       
/* 114 */       public Object getBean() { return InputField.this; }
/* 115 */       public String getName() { return "onAction"; }
/*     */     };
/* 117 */   public final ObjectProperty<EventHandler<ActionEvent>> onActionProperty() { return this.onAction; }
/* 118 */   public final EventHandler<ActionEvent> getOnAction() { return onActionProperty().get(); } public final void setOnAction(EventHandler<ActionEvent> paramEventHandler) {
/* 119 */     onActionProperty().set(paramEventHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InputField() {
/* 125 */     getStyleClass().setAll(new String[] { "input-field" });
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\InputField.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */