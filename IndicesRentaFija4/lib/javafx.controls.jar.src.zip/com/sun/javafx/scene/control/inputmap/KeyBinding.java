/*     */ package com.sun.javafx.scene.control.inputmap;
/*     */ 
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.util.Objects;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyBinding
/*     */ {
/*     */   private final KeyCode code;
/*     */   private final EventType<KeyEvent> eventType;
/*  55 */   private OptionalBoolean shift = OptionalBoolean.FALSE;
/*  56 */   private OptionalBoolean ctrl = OptionalBoolean.FALSE;
/*  57 */   private OptionalBoolean alt = OptionalBoolean.FALSE;
/*  58 */   private OptionalBoolean meta = OptionalBoolean.FALSE;
/*     */   
/*     */   public KeyBinding(KeyCode paramKeyCode) {
/*  61 */     this(paramKeyCode, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyBinding(EventType<KeyEvent> paramEventType) {
/*  69 */     this(null, paramEventType);
/*     */   }
/*     */   
/*     */   public KeyBinding(KeyCode paramKeyCode, EventType<KeyEvent> paramEventType) {
/*  73 */     this.code = paramKeyCode;
/*  74 */     this.eventType = (paramEventType != null) ? paramEventType : KeyEvent.KEY_PRESSED;
/*     */   }
/*     */   
/*     */   public final KeyBinding shift() {
/*  78 */     return shift(OptionalBoolean.TRUE);
/*     */   }
/*     */   
/*     */   public final KeyBinding shift(OptionalBoolean paramOptionalBoolean) {
/*  82 */     this.shift = paramOptionalBoolean;
/*  83 */     return this;
/*     */   }
/*     */   
/*     */   public final KeyBinding ctrl() {
/*  87 */     return ctrl(OptionalBoolean.TRUE);
/*     */   }
/*     */   
/*     */   public final KeyBinding ctrl(OptionalBoolean paramOptionalBoolean) {
/*  91 */     this.ctrl = paramOptionalBoolean;
/*  92 */     return this;
/*     */   }
/*     */   
/*     */   public final KeyBinding alt() {
/*  96 */     return alt(OptionalBoolean.TRUE);
/*     */   }
/*     */   
/*     */   public final KeyBinding alt(OptionalBoolean paramOptionalBoolean) {
/* 100 */     this.alt = paramOptionalBoolean;
/* 101 */     return this;
/*     */   }
/*     */   
/*     */   public final KeyBinding meta() {
/* 105 */     return meta(OptionalBoolean.TRUE);
/*     */   }
/*     */   
/*     */   public final KeyBinding meta(OptionalBoolean paramOptionalBoolean) {
/* 109 */     this.meta = paramOptionalBoolean;
/* 110 */     return this;
/*     */   }
/*     */   
/*     */   public final KeyBinding shortcut() {
/* 114 */     if (Toolkit.getToolkit().getClass().getName().endsWith("StubToolkit")) {
/*     */ 
/*     */       
/* 117 */       if (Utils.isMac()) {
/* 118 */         return meta();
/*     */       }
/* 120 */       return ctrl();
/*     */     } 
/*     */     
/* 123 */     switch (Toolkit.getToolkit().getPlatformShortcutKey()) {
/*     */       case SHIFT:
/* 125 */         return shift();
/*     */       
/*     */       case CONTROL:
/* 128 */         return ctrl();
/*     */       
/*     */       case ALT:
/* 131 */         return alt();
/*     */       
/*     */       case META:
/* 134 */         return meta();
/*     */     } 
/*     */     
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final KeyCode getCode() {
/* 144 */     return this.code;
/* 145 */   } public final EventType<KeyEvent> getType() { return this.eventType; }
/* 146 */   public final OptionalBoolean getShift() { return this.shift; }
/* 147 */   public final OptionalBoolean getCtrl() { return this.ctrl; }
/* 148 */   public final OptionalBoolean getAlt() { return this.alt; } public final OptionalBoolean getMeta() {
/* 149 */     return this.meta;
/*     */   }
/*     */   public int getSpecificity(KeyEvent paramKeyEvent) {
/* 152 */     byte b = 0;
/* 153 */     if (this.code != null && this.code != paramKeyEvent.getCode()) return 0;  b = 1;
/* 154 */     if (!this.shift.equals(paramKeyEvent.isShiftDown())) return 0;  if (this.shift != OptionalBoolean.ANY) b++; 
/* 155 */     if (!this.ctrl.equals(paramKeyEvent.isControlDown())) return 0;  if (this.ctrl != OptionalBoolean.ANY) b++; 
/* 156 */     if (!this.alt.equals(paramKeyEvent.isAltDown())) return 0;  if (this.alt != OptionalBoolean.ANY) b++; 
/* 157 */     if (!this.meta.equals(paramKeyEvent.isMetaDown())) return 0;  if (this.meta != OptionalBoolean.ANY) b++; 
/* 158 */     if (this.eventType != null && this.eventType != paramKeyEvent.getEventType()) return 0;  b++;
/*     */     
/* 160 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 165 */     return "KeyBinding [code=" + this.code + ", shift=" + this.shift + ", ctrl=" + this.ctrl + ", alt=" + this.alt + ", meta=" + this.meta + ", type=" + this.eventType + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 172 */     if (this == paramObject) return true; 
/* 173 */     if (!(paramObject instanceof KeyBinding)) return false; 
/* 174 */     KeyBinding keyBinding = (KeyBinding)paramObject;
/* 175 */     return (Objects.equals(getCode(), keyBinding.getCode()) && 
/* 176 */       Objects.equals(this.eventType, keyBinding.eventType) && 
/* 177 */       Objects.equals(getShift(), keyBinding.getShift()) && 
/* 178 */       Objects.equals(getCtrl(), keyBinding.getCtrl()) && 
/* 179 */       Objects.equals(getAlt(), keyBinding.getAlt()) && 
/* 180 */       Objects.equals(getMeta(), keyBinding.getMeta()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 185 */     return Objects.hash(new Object[] { getCode(), this.eventType, getShift(), getCtrl(), getAlt(), getMeta() });
/*     */   }
/*     */   
/*     */   public static KeyBinding toKeyBinding(KeyEvent paramKeyEvent) {
/* 189 */     KeyBinding keyBinding = new KeyBinding(paramKeyEvent.getCode(), paramKeyEvent.getEventType());
/* 190 */     if (paramKeyEvent.isShiftDown()) keyBinding.shift(); 
/* 191 */     if (paramKeyEvent.isControlDown()) keyBinding.ctrl(); 
/* 192 */     if (paramKeyEvent.isAltDown()) keyBinding.alt(); 
/* 193 */     if (paramKeyEvent.isShortcutDown()) keyBinding.shortcut(); 
/* 194 */     return keyBinding;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum OptionalBoolean
/*     */   {
/* 201 */     TRUE,
/* 202 */     FALSE,
/* 203 */     ANY;
/*     */     
/*     */     public boolean equals(boolean param1Boolean) {
/* 206 */       if (this == ANY) return true; 
/* 207 */       if (param1Boolean && this == TRUE) return true; 
/* 208 */       if (!param1Boolean && this == FALSE) return true; 
/* 209 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\inputmap\KeyBinding.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */