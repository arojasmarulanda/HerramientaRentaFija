/*      */ package com.sun.javafx.scene.control;
/*      */ 
/*      */ import com.sun.javafx.scene.NodeHelper;
/*      */ import com.sun.javafx.scene.control.behavior.TwoLevelFocusPopupBehavior;
/*      */ import com.sun.javafx.scene.control.skin.Utils;
/*      */ import com.sun.javafx.scene.traversal.Direction;
/*      */ import com.sun.javafx.util.Utils;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Optional;
/*      */ import javafx.animation.Animation;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.Timeline;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.WeakInvalidationListener;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*      */ import javafx.beans.value.ChangeListener;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.geometry.Bounds;
/*      */ import javafx.geometry.HPos;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.geometry.Side;
/*      */ import javafx.geometry.VPos;
/*      */ import javafx.scene.AccessibleAction;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Parent;
/*      */ import javafx.scene.control.CheckMenuItem;
/*      */ import javafx.scene.control.ContextMenu;
/*      */ import javafx.scene.control.CustomMenuItem;
/*      */ import javafx.scene.control.Label;
/*      */ import javafx.scene.control.Menu;
/*      */ import javafx.scene.control.MenuItem;
/*      */ import javafx.scene.control.RadioMenuItem;
/*      */ import javafx.scene.control.Skin;
/*      */ import javafx.scene.input.KeyCode;
/*      */ import javafx.scene.input.KeyEvent;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.input.ScrollEvent;
/*      */ import javafx.scene.layout.Region;
/*      */ import javafx.scene.layout.StackPane;
/*      */ import javafx.scene.layout.VBox;
/*      */ import javafx.scene.shape.Rectangle;
/*      */ import javafx.stage.Window;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ContextMenuContent
/*      */   extends Region
/*      */ {
/*      */   private static final String ITEM_STYLE_CLASS_LISTENER = "itemStyleClassListener";
/*      */   private ContextMenu contextMenu;
/*   83 */   private double maxGraphicWidth = 0.0D;
/*   84 */   private double maxRightWidth = 0.0D;
/*   85 */   private double maxLabelWidth = 0.0D;
/*   86 */   private double maxRowHeight = 0.0D;
/*   87 */   private double maxLeftWidth = 0.0D;
/*   88 */   private double oldWidth = 0.0D;
/*      */ 
/*      */   
/*      */   private Rectangle clipRect;
/*      */   
/*      */   MenuBox itemsContainer;
/*      */   
/*      */   private ArrowMenuItem upArrow;
/*      */   
/*      */   private ArrowMenuItem downArrow;
/*      */   
/*   99 */   private int currentFocusedIndex = -1;
/*      */   
/*      */   private boolean itemsDirty = true;
/*      */   
/*      */   private InvalidationListener popupShowingListener = paramObservable -> updateItems();
/*      */   
/*  105 */   private WeakInvalidationListener weakPopupShowingListener = new WeakInvalidationListener(this.popupShowingListener);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isFirstShow;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double ty;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ChangeListener<Boolean> menuShowingListener;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ListChangeListener<MenuItem> contextMenuItemsListener;
/*      */ 
/*      */ 
/*      */   
/*      */   private ChangeListener<Boolean> menuItemVisibleListener;
/*      */ 
/*      */ 
/*      */   
/*      */   private Menu openSubmenu;
/*      */ 
/*      */ 
/*      */   
/*      */   private ContextMenu submenu;
/*      */ 
/*      */ 
/*      */   
/*      */   Region selectedBackground;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VBox getItemsContainer() {
/*  147 */     return this.itemsContainer;
/*      */   }
/*      */   
/*      */   int getCurrentFocusIndex() {
/*  151 */     return this.currentFocusedIndex;
/*      */   }
/*      */   
/*      */   void setCurrentFocusedIndex(int paramInt) {
/*  155 */     if (paramInt < this.itemsContainer.getChildren().size()) {
/*  156 */       this.currentFocusedIndex = paramInt;
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateItems() {
/*  161 */     if (this.itemsDirty) {
/*  162 */       updateVisualItems();
/*  163 */       this.itemsDirty = false;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void computeVisualMetrics() {
/*  168 */     this.maxRightWidth = 0.0D;
/*  169 */     this.maxLabelWidth = 0.0D;
/*  170 */     this.maxRowHeight = 0.0D;
/*  171 */     this.maxGraphicWidth = 0.0D;
/*  172 */     this.maxLeftWidth = 0.0D;
/*      */     
/*  174 */     for (byte b = 0; b < this.itemsContainer.getChildren().size(); b++) {
/*  175 */       Node node = this.itemsContainer.getChildren().get(b);
/*  176 */       if (node instanceof MenuItemContainer) {
/*  177 */         MenuItemContainer menuItemContainer = (MenuItemContainer)this.itemsContainer.getChildren().get(b);
/*      */         
/*  179 */         if (menuItemContainer.isVisible()) {
/*      */           
/*  181 */           double d1 = -1.0D;
/*  182 */           Node node1 = menuItemContainer.left;
/*  183 */           if (node1 != null) {
/*  184 */             if (node1.getContentBias() == Orientation.VERTICAL)
/*  185 */             { d1 = snapSizeY(node1.prefHeight(-1.0D)); }
/*  186 */             else { d1 = -1.0D; }
/*  187 */              this.maxLeftWidth = Math.max(this.maxLeftWidth, snapSizeX(node1.prefWidth(d1)));
/*  188 */             this.maxRowHeight = Math.max(this.maxRowHeight, node1.prefHeight(-1.0D));
/*      */           } 
/*      */           
/*  191 */           node1 = menuItemContainer.graphic;
/*  192 */           if (node1 != null) {
/*  193 */             if (node1.getContentBias() == Orientation.VERTICAL)
/*  194 */             { d1 = snapSizeY(node1.prefHeight(-1.0D)); }
/*  195 */             else { d1 = -1.0D; }
/*  196 */              this.maxGraphicWidth = Math.max(this.maxGraphicWidth, snapSizeX(node1.prefWidth(d1)));
/*  197 */             this.maxRowHeight = Math.max(this.maxRowHeight, node1.prefHeight(-1.0D));
/*      */           } 
/*      */           
/*  200 */           node1 = menuItemContainer.label;
/*  201 */           if (node1 != null) {
/*  202 */             if (node1.getContentBias() == Orientation.VERTICAL)
/*  203 */             { d1 = snapSizeY(node1.prefHeight(-1.0D)); }
/*  204 */             else { d1 = -1.0D; }
/*  205 */              this.maxLabelWidth = Math.max(this.maxLabelWidth, snapSizeX(node1.prefWidth(d1)));
/*  206 */             this.maxRowHeight = Math.max(this.maxRowHeight, node1.prefHeight(-1.0D));
/*      */           } 
/*      */           
/*  209 */           node1 = menuItemContainer.right;
/*  210 */           if (node1 != null) {
/*  211 */             if (node1.getContentBias() == Orientation.VERTICAL)
/*  212 */             { d1 = snapSizeY(node1.prefHeight(-1.0D)); }
/*  213 */             else { d1 = -1.0D; }
/*  214 */              this.maxRightWidth = Math.max(this.maxRightWidth, snapSizeX(node1.prefWidth(d1)));
/*  215 */             this.maxRowHeight = Math.max(this.maxRowHeight, node1.prefHeight(-1.0D));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  235 */     double d = this.maxRightWidth + this.maxLabelWidth + this.maxGraphicWidth + this.maxLeftWidth;
/*  236 */     Window window = this.contextMenu.getOwnerWindow();
/*  237 */     if (window instanceof ContextMenu && 
/*  238 */       this.contextMenu.getX() < window.getX() && 
/*  239 */       this.oldWidth != d) {
/*  240 */       this.contextMenu.setX(this.contextMenu.getX() + this.oldWidth - d);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  245 */     this.oldWidth = d;
/*      */   }
/*      */   
/*      */   private void updateVisualItems() {
/*  249 */     ObservableList<Node> observableList = this.itemsContainer.getChildren();
/*      */     
/*  251 */     disposeVisualItems();
/*      */     
/*  253 */     for (byte b = 0; b < getItems().size(); b++) {
/*  254 */       MenuItem menuItem = getItems().get(b);
/*  255 */       if (!(menuItem instanceof CustomMenuItem) || ((CustomMenuItem)menuItem).getContent() != null)
/*      */       {
/*      */ 
/*      */         
/*  259 */         if (menuItem instanceof javafx.scene.control.SeparatorMenuItem) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  264 */           Node node = ((CustomMenuItem)menuItem).getContent();
/*  265 */           node.visibleProperty().bind(menuItem.visibleProperty());
/*  266 */           observableList.add(node);
/*      */ 
/*      */ 
/*      */           
/*  270 */           node.getProperties().put(MenuItem.class, menuItem);
/*      */         } else {
/*  272 */           MenuItemContainer menuItemContainer = new MenuItemContainer(menuItem);
/*  273 */           menuItemContainer.visibleProperty().bind(menuItem.visibleProperty());
/*  274 */           observableList.add(menuItemContainer);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  280 */     if (getItems().size() > 0) {
/*  281 */       MenuItem menuItem = getItems().get(0);
/*  282 */       getProperties().put(Menu.class, menuItem.getParentMenu());
/*      */     } 
/*      */ 
/*      */     
/*  286 */     NodeHelper.reapplyCSS(this);
/*      */   }
/*      */ 
/*      */   
/*      */   private void disposeVisualItems() {
/*  291 */     ObservableList<Node> observableList = this.itemsContainer.getChildren(); byte b; int i;
/*  292 */     for (b = 0, i = observableList.size(); b < i; b++) {
/*  293 */       Node node = observableList.get(b);
/*      */       
/*  295 */       if (node instanceof MenuItemContainer) {
/*  296 */         MenuItemContainer menuItemContainer = (MenuItemContainer)node;
/*  297 */         menuItemContainer.visibleProperty().unbind();
/*  298 */         menuItemContainer.dispose();
/*      */       } 
/*      */     } 
/*  301 */     observableList.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  310 */     disposeBinds();
/*  311 */     disposeVisualItems();
/*      */     
/*  313 */     disposeContextMenu(this.submenu);
/*  314 */     this.submenu = null;
/*  315 */     this.openSubmenu = null;
/*  316 */     this.selectedBackground = null;
/*  317 */     if (this.contextMenu != null) {
/*  318 */       this.contextMenu.getItems().clear();
/*  319 */       this.contextMenu = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void disposeContextMenu(ContextMenu paramContextMenu) {
/*  324 */     if (paramContextMenu == null)
/*      */       return; 
/*  326 */     Skin<?> skin = paramContextMenu.getSkin();
/*  327 */     if (skin == null)
/*      */       return; 
/*  329 */     ContextMenuContent contextMenuContent = (ContextMenuContent)skin.getNode();
/*  330 */     if (contextMenuContent == null)
/*      */       return; 
/*  332 */     contextMenuContent.dispose();
/*      */   }
/*      */   
/*      */   protected void layoutChildren() {
/*  336 */     if (this.itemsContainer.getChildren().size() == 0)
/*  337 */       return;  double d1 = snappedLeftInset();
/*  338 */     double d2 = snappedTopInset();
/*  339 */     double d3 = getWidth() - d1 - snappedRightInset();
/*  340 */     double d4 = getHeight() - d2 - snappedBottomInset();
/*  341 */     double d5 = snapSizeY(getContentHeight());
/*      */     
/*  343 */     this.itemsContainer.resize(d3, d5);
/*  344 */     this.itemsContainer.relocate(d1, d2);
/*      */     
/*  346 */     if (this.isFirstShow && this.ty == 0.0D) {
/*  347 */       this.upArrow.setVisible(false);
/*  348 */       this.isFirstShow = false;
/*      */     } else {
/*  350 */       this.upArrow.setVisible((this.ty < d2 && this.ty < 0.0D));
/*      */     } 
/*  352 */     this.downArrow.setVisible((this.ty + d5 > d2 + d4));
/*      */     
/*  354 */     this.clipRect.setX(0.0D);
/*  355 */     this.clipRect.setY(0.0D);
/*  356 */     this.clipRect.setWidth(d3);
/*  357 */     this.clipRect.setHeight(d4);
/*      */     
/*  359 */     if (this.upArrow.isVisible()) {
/*  360 */       double d = snapSizeY(this.upArrow.prefHeight(-1.0D));
/*  361 */       this.clipRect.setHeight(snapSizeY(this.clipRect.getHeight() - d));
/*  362 */       this.clipRect.setY(snapSizeY(this.clipRect.getY()) + d);
/*  363 */       this.upArrow.resize(snapSizeX(this.upArrow.prefWidth(-1.0D)), d);
/*  364 */       positionInArea(this.upArrow, d1, d2, d3, d, 0.0D, HPos.CENTER, VPos.CENTER);
/*      */     } 
/*      */ 
/*      */     
/*  368 */     if (this.downArrow.isVisible()) {
/*  369 */       double d = snapSizeY(this.downArrow.prefHeight(-1.0D));
/*  370 */       this.clipRect.setHeight(snapSizeY(this.clipRect.getHeight()) - d);
/*  371 */       this.downArrow.resize(snapSizeX(this.downArrow.prefWidth(-1.0D)), d);
/*  372 */       positionInArea(this.downArrow, d1, d2 + d4 - d, d3, d, 0.0D, HPos.CENTER, VPos.CENTER);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computePrefWidth(double paramDouble) {
/*  378 */     computeVisualMetrics();
/*  379 */     double d = 0.0D;
/*  380 */     if (this.itemsContainer.getChildren().size() == 0) return 0.0D; 
/*  381 */     for (Node node : this.itemsContainer.getChildren()) {
/*  382 */       if (!node.isVisible())
/*  383 */         continue;  d = Math.max(d, snapSizeX(node.prefWidth(-1.0D)));
/*      */     } 
/*  385 */     return snappedLeftInset() + snapSizeX(d) + snappedRightInset();
/*      */   }
/*      */   
/*      */   protected double computePrefHeight(double paramDouble) {
/*  389 */     if (this.itemsContainer.getChildren().size() == 0) return 0.0D; 
/*  390 */     double d1 = getScreenHeight();
/*  391 */     double d2 = getContentHeight();
/*  392 */     double d3 = snappedTopInset() + snapSizeY(d2) + snappedBottomInset();
/*      */ 
/*      */     
/*  395 */     return (d1 <= 0.0D) ? d3 : Math.min(d3, d1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computeMinHeight(double paramDouble) {
/*  400 */     return 0.0D;
/*      */   }
/*      */   
/*      */   protected double computeMaxHeight(double paramDouble) {
/*  404 */     return getScreenHeight();
/*      */   }
/*      */   
/*      */   private double getScreenHeight() {
/*  408 */     if (this.contextMenu == null || this.contextMenu.getOwnerWindow() == null || this.contextMenu
/*  409 */       .getOwnerWindow().getScene() == null) {
/*  410 */       return -1.0D;
/*      */     }
/*  412 */     return snapSizeY(Utils.getScreen(this.contextMenu
/*  413 */           .getOwnerWindow().getScene().getRoot()).getVisualBounds().getHeight());
/*      */   }
/*      */ 
/*      */   
/*      */   private double getContentHeight() {
/*  418 */     double d = 0.0D;
/*  419 */     for (Node node : this.itemsContainer.getChildren()) {
/*  420 */       if (node.isVisible()) {
/*  421 */         d += snapSizeY(node.prefHeight(-1.0D));
/*      */       }
/*      */     } 
/*  424 */     return d;
/*      */   }
/*      */ 
/*      */   
/*      */   private void ensureFocusedMenuItemIsVisible(Node paramNode) {
/*  429 */     if (paramNode == null)
/*      */       return; 
/*  431 */     Bounds bounds1 = paramNode.getBoundsInParent();
/*  432 */     Bounds bounds2 = this.clipRect.getBoundsInParent();
/*      */     
/*  434 */     if (bounds1.getMaxY() >= bounds2.getMaxY()) {
/*      */       
/*  436 */       scroll(-bounds1.getMaxY() + bounds2.getMaxY());
/*  437 */     } else if (bounds1.getMinY() <= bounds2.getMinY()) {
/*      */       
/*  439 */       scroll(-bounds1.getMinY() + bounds2.getMinY());
/*      */     } 
/*      */   }
/*      */   
/*      */   protected ObservableList<MenuItem> getItems() {
/*  444 */     return this.contextMenu.getItems();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int findFocusedIndex() {
/*  451 */     for (byte b = 0; b < this.itemsContainer.getChildren().size(); b++) {
/*  452 */       Node node = this.itemsContainer.getChildren().get(b);
/*  453 */       if (node.isFocused()) {
/*  454 */         return b;
/*      */       }
/*      */     } 
/*  457 */     return -1;
/*      */   } private void initialize() { this.contextMenu.addEventHandler(Menu.ON_SHOWN, paramEvent -> { this.currentFocusedIndex = -1; for (Node node : this.itemsContainer.getChildren()) { if (node instanceof MenuItemContainer) { MenuItem menuItem = ((MenuItemContainer)node).item; if ("choice-box-menu-item".equals(menuItem.getId()) && ((RadioMenuItem)menuItem).isSelected()) { node.requestFocus(); break; }  }  }  }); setOnKeyPressed(new EventHandler<KeyEvent>() {
/*      */           public void handle(KeyEvent param1KeyEvent) { Node node; switch (param1KeyEvent.getCode()) { case LINES: if (ContextMenuContent.this.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) { ContextMenuContent.this.processRightKey(param1KeyEvent); break; }  ContextMenuContent.this.processLeftKey(param1KeyEvent); break;case PAGES: if (ContextMenuContent.this.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) { ContextMenuContent.this.processLeftKey(param1KeyEvent); break; }  ContextMenuContent.this.processRightKey(param1KeyEvent); break;case NONE: param1KeyEvent.consume(); break;case null: node = ContextMenuContent.this.contextMenu.getOwnerNode(); if (!(node instanceof MenuBarButton)) { ContextMenuContent.this.contextMenu.hide(); param1KeyEvent.consume(); }  break;case null: ContextMenuContent.this.move(Direction.NEXT); param1KeyEvent.consume(); break;case null: ContextMenuContent.this.move(Direction.PREVIOUS); param1KeyEvent.consume(); break;case null: case null: ContextMenuContent.this.selectMenuItem(); param1KeyEvent.consume(); break; }  if (!param1KeyEvent.isConsumed()) { node = ContextMenuContent.this.contextMenu.getOwnerNode(); if (node instanceof ContextMenuContent.MenuItemContainer) { Parent parent = node.getParent(); while (parent != null && !(parent instanceof ContextMenuContent)) parent = parent.getParent();  if (parent instanceof ContextMenuContent) parent.getOnKeyPressed().handle(param1KeyEvent);  } else if (node instanceof MenuBarButton) {  }  }  }
/*  460 */         }); addEventHandler(ScrollEvent.SCROLL, paramScrollEvent -> { double d1 = paramScrollEvent.getTextDeltaY(); double d2 = paramScrollEvent.getDeltaY(); if ((this.downArrow.isVisible() && (d1 < 0.0D || d2 < 0.0D)) || (this.upArrow.isVisible() && (d1 > 0.0D || d2 > 0.0D))) { int i; double d; switch (paramScrollEvent.getTextDeltaYUnits()) { case LINES: i = findFocusedIndex(); if (i == -1) i = 0;  d = ((Node)this.itemsContainer.getChildren().get(i)).prefHeight(-1.0D); scroll(d1 * d); break;case PAGES: scroll(d1 * this.itemsContainer.getHeight()); break;case NONE: scroll(d2); break; }  paramScrollEvent.consume(); }  }); } private Optional<Node> getFocusedNode() { ObservableList<Node> observableList = this.itemsContainer.getChildren(); boolean bool = (this.currentFocusedIndex >= 0 && this.currentFocusedIndex < observableList.size()) ? true : false; return bool ? Optional.<Node>of(observableList.get(this.currentFocusedIndex)) : Optional.<Node>empty(); } private void processLeftKey(KeyEvent paramKeyEvent) { getFocusedNode().ifPresent(paramNode -> { if (paramNode instanceof MenuItemContainer) { MenuItem menuItem = ((MenuItemContainer)paramNode).item; if (menuItem instanceof Menu) { Menu menu = (Menu)menuItem; if (menu == this.openSubmenu && this.submenu != null && this.submenu.isShowing()) { hideSubmenu(); paramKeyEvent.consume(); }  }  }  }); } public ContextMenuContent(ContextMenu paramContextMenu) { this.isFirstShow = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  743 */     this.menuShowingListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*      */         ReadOnlyBooleanProperty readOnlyBooleanProperty = (ReadOnlyBooleanProperty)paramObservableValue;
/*      */ 
/*      */         
/*      */         Menu menu = (Menu)readOnlyBooleanProperty.getBean();
/*      */         
/*      */         if (paramBoolean1.booleanValue() && !paramBoolean2.booleanValue()) {
/*      */           hideSubmenu();
/*      */         } else if (!paramBoolean1.booleanValue() && paramBoolean2.booleanValue()) {
/*      */           showSubmenu(menu);
/*      */         } 
/*      */       });
/*      */     
/*  756 */     this.contextMenuItemsListener = (paramChange -> {
/*      */         while (paramChange.next()) {
/*      */           updateMenuShowingListeners(paramChange.getRemoved(), false);
/*      */ 
/*      */ 
/*      */           
/*      */           updateMenuShowingListeners(paramChange.getAddedSubList(), true);
/*      */         } 
/*      */ 
/*      */         
/*      */         this.itemsDirty = true;
/*      */ 
/*      */         
/*      */         updateItems();
/*      */       });
/*      */ 
/*      */     
/*  773 */     this.menuItemVisibleListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> requestLayout()); this.contextMenu = paramContextMenu; this.clipRect = new Rectangle(); this.clipRect.setSmooth(false); this.itemsContainer = new MenuBox(); this.itemsContainer.setClip(this.clipRect); this.upArrow = new ArrowMenuItem(this); this.upArrow.setUp(true); this.upArrow.setFocusTraversable(false); this.downArrow = new ArrowMenuItem(this); this.downArrow.setUp(false); this.downArrow.setFocusTraversable(false); getChildren().add(this.itemsContainer); getChildren().add(this.upArrow); getChildren().add(this.downArrow); initialize(); setUpBinds(); updateItems(); paramContextMenu.showingProperty().addListener(this.weakPopupShowingListener); if (Utils.isTwoLevelFocus()) new TwoLevelFocusPopupBehavior(this);  }
/*      */   private void processRightKey(KeyEvent paramKeyEvent) { getFocusedNode().ifPresent(paramNode -> { if (paramNode instanceof MenuItemContainer) { MenuItem menuItem = ((MenuItemContainer)paramNode).item; if (menuItem instanceof Menu) { Menu menu = (Menu)menuItem; if (menu.isDisable()) return;  this.selectedBackground = (MenuItemContainer)paramNode; if (this.openSubmenu == menu && this.submenu != null && this.submenu.isShowing()) return;  showMenu(menu); paramKeyEvent.consume(); }  }  }); }
/*      */   private void showMenu(Menu paramMenu) { paramMenu.show(); ContextMenuContent contextMenuContent = (ContextMenuContent)this.submenu.getSkin().getNode(); if (contextMenuContent != null)
/*      */       if (contextMenuContent.itemsContainer.getChildren().size() > 0) { ((Node)contextMenuContent.itemsContainer.getChildren().get(0)).requestFocus(); contextMenuContent.currentFocusedIndex = 0; } else { contextMenuContent.requestFocus(); }   }
/*      */   private void selectMenuItem() { getFocusedNode().ifPresent(paramNode -> { if (paramNode instanceof MenuItemContainer) { MenuItem menuItem = ((MenuItemContainer)paramNode).item; if (menuItem instanceof Menu) { Menu menu = (Menu)menuItem; if (this.openSubmenu != null)
/*      */                 hideSubmenu();  if (menu.isDisable())
/*  779 */                 return;  this.selectedBackground = (MenuItemContainer)paramNode; menu.show(); } else { ((MenuItemContainer)paramNode).doSelect(); }  }  }); } private void updateMenuShowingListeners(List<? extends MenuItem> paramList, boolean paramBoolean) { for (MenuItem menuItem : paramList)
/*  780 */     { if (menuItem instanceof Menu) {
/*  781 */         Menu menu = (Menu)menuItem;
/*      */         
/*  783 */         if (paramBoolean) {
/*  784 */           menu.showingProperty().addListener(this.menuShowingListener);
/*      */         } else {
/*  786 */           menu.showingProperty().removeListener(this.menuShowingListener);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  791 */       if (paramBoolean) {
/*  792 */         menuItem.visibleProperty().addListener(this.menuItemVisibleListener); continue;
/*      */       } 
/*  794 */       menuItem.visibleProperty().removeListener(this.menuItemVisibleListener); }  } private void move(Direction paramDirection) { int i = (this.currentFocusedIndex != -1) ? this.currentFocusedIndex : this.itemsContainer.getChildren().size(); requestFocusOnIndex(findSibling(paramDirection, i)); }
/*      */   private int findSibling(Direction paramDirection, int paramInt) { int i = this.itemsContainer.getChildren().size(); int j = paramInt; while (true) { if (paramDirection.isForward() && j >= i - 1) { j = 0; } else if (!paramDirection.isForward() && j == 0) { j = i - 1; } else { j += paramDirection.isForward() ? 1 : -1; }  Node node = this.itemsContainer.getChildren().get(j); if (node instanceof MenuItemContainer && node.isVisible()) return j;  if (j == paramInt)
/*      */         return -1;  }  }
/*      */   public void requestFocusOnIndex(int paramInt) { this.currentFocusedIndex = paramInt; Node node = this.itemsContainer.getChildren().get(paramInt); this.selectedBackground = (MenuItemContainer)node; node.requestFocus(); ensureFocusedMenuItemIsVisible(node); }
/*      */   public double getMenuYOffset(int paramInt) { double d = 0.0D; if (this.itemsContainer.getChildren().size() > paramInt) { d = snappedTopInset(); Node node = this.itemsContainer.getChildren().get(paramInt); d += node.getLayoutY() + node.prefHeight(-1.0D); }  return d; }
/*      */   private void setUpBinds() { updateMenuShowingListeners(this.contextMenu.getItems(), true); this.contextMenu.getItems().addListener(this.contextMenuItemsListener); }
/*      */   private void disposeBinds() { updateMenuShowingListeners(this.contextMenu.getItems(), false); this.contextMenu.getItems().removeListener(this.contextMenuItemsListener); }
/*  801 */   ContextMenu getSubMenu() { return this.submenu; }
/*      */ 
/*      */   
/*      */   Menu getOpenSubMenu() {
/*  805 */     return this.openSubmenu;
/*      */   }
/*      */   
/*      */   private void createSubmenu() {
/*  809 */     if (this.submenu == null) {
/*  810 */       this.submenu = new ContextMenu();
/*  811 */       this.submenu.showingProperty().addListener(new ChangeListener<Boolean>()
/*      */           {
/*      */             public void changed(ObservableValue<? extends Boolean> param1ObservableValue, Boolean param1Boolean1, Boolean param1Boolean2) {
/*  814 */               if (!ContextMenuContent.this.submenu.isShowing())
/*      */               {
/*      */                 
/*  817 */                 for (Node node : ContextMenuContent.this.itemsContainer.getChildren()) {
/*  818 */                   if (node instanceof ContextMenuContent.MenuItemContainer && ((ContextMenuContent.MenuItemContainer)node)
/*  819 */                     .item instanceof Menu) {
/*  820 */                     Menu menu = (Menu)((ContextMenuContent.MenuItemContainer)node).item;
/*  821 */                     if (menu.isShowing()) {
/*  822 */                       menu.hide();
/*      */                     }
/*      */                   } 
/*      */                 } 
/*      */               }
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void showSubmenu(Menu paramMenu) {
/*  833 */     this.openSubmenu = paramMenu;
/*  834 */     createSubmenu();
/*  835 */     this.submenu.getItems().setAll(paramMenu.getItems());
/*  836 */     this.submenu.show(this.selectedBackground, Side.RIGHT, 0.0D, 0.0D);
/*      */   }
/*      */   
/*      */   private void hideSubmenu() {
/*  840 */     if (this.submenu == null)
/*      */       return; 
/*  842 */     this.submenu.hide();
/*  843 */     this.openSubmenu = null;
/*      */ 
/*      */ 
/*      */     
/*  847 */     disposeContextMenu(this.submenu);
/*  848 */     this.submenu = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  853 */     getFocusedNode().ifPresent(paramNode -> {
/*      */           requestFocus();
/*      */           paramNode.requestFocus();
/*      */         });
/*      */   }
/*      */   
/*      */   private void hideAllMenus(MenuItem paramMenuItem) {
/*  860 */     if (this.contextMenu != null) this.contextMenu.hide();
/*      */     
/*      */     Menu menu;
/*  863 */     while ((menu = paramMenuItem.getParentMenu()) != null) {
/*  864 */       menu.hide();
/*  865 */       paramMenuItem = menu;
/*      */     } 
/*  867 */     if (paramMenuItem.getParentPopup() != null) {
/*  868 */       paramMenuItem.getParentPopup().hide();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void scroll(double paramDouble) {
/*  882 */     double d = this.ty + paramDouble;
/*  883 */     if (this.ty == d) {
/*      */       return;
/*      */     }
/*      */     
/*  887 */     if (d > 0.0D) {
/*  888 */       d = 0.0D;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  897 */     if (paramDouble < 0.0D && getHeight() - d > this.itemsContainer.getHeight() - this.downArrow.getHeight()) {
/*  898 */       d = getHeight() - this.itemsContainer.getHeight() - this.downArrow.getHeight();
/*      */     }
/*      */     
/*  901 */     this.ty = d;
/*  902 */     this.itemsContainer.requestLayout();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Styleable getStyleableParent() {
/*  911 */     return this.contextMenu;
/*      */   }
/*      */ 
/*      */   
/*      */   private static class StyleableProperties
/*      */   {
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/*  920 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Region.getClassCssMetaData());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  926 */       List<CssMetaData<? extends Styleable, ?>> list = Node.getClassCssMetaData(); byte b; int i;
/*  927 */       for (b = 0, i = list.size(); b < i; b++) {
/*  928 */         CssMetaData<? extends Styleable, ?> cssMetaData = list.get(b);
/*  929 */         if ("effect".equals(cssMetaData.getProperty())) {
/*  930 */           arrayList.add(cssMetaData);
/*      */           break;
/*      */         } 
/*      */       } 
/*  934 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/*  943 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/*  951 */     return getClassCssMetaData();
/*      */   }
/*      */   
/*      */   public Label getLabelAt(int paramInt) {
/*  955 */     return ((MenuItemContainer)this.itemsContainer.getChildren().get(paramInt)).getLabel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class MenuBox
/*      */     extends VBox
/*      */   {
/*      */     MenuBox() {
/*  965 */       setAccessibleRole(AccessibleRole.CONTEXT_MENU);
/*      */     }
/*      */     
/*      */     protected void layoutChildren() {
/*  969 */       double d = ContextMenuContent.this.ty;
/*  970 */       for (Node node : getChildren()) {
/*  971 */         if (node.isVisible()) {
/*  972 */           double d1 = snapSizeY(node.prefHeight(-1.0D));
/*  973 */           node.resize(snapSizeX(getWidth()), d1);
/*  974 */           node.relocate(snappedLeftInset(), d);
/*  975 */           d += d1;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Object queryAccessibleAttribute(AccessibleAttribute param1AccessibleAttribute, Object... param1VarArgs) {
/*  983 */       switch (param1AccessibleAttribute) { case LINES:
/*  984 */           return Boolean.valueOf(ContextMenuContent.this.contextMenu.isShowing());
/*  985 */         case PAGES: return ContextMenuContent.this.contextMenu.getOwnerNode(); }
/*  986 */        return super.queryAccessibleAttribute(param1AccessibleAttribute, param1VarArgs);
/*      */     } }
/*      */   
/*      */   class ArrowMenuItem extends StackPane { private StackPane upDownArrow;
/*      */     private ContextMenuContent popupMenuContent;
/*      */     private boolean up = false;
/*      */     private Timeline scrollTimeline;
/*      */     
/*      */     public final boolean isUp() {
/*  995 */       return this.up;
/*      */     } public void setUp(boolean param1Boolean) {
/*  997 */       this.up = param1Boolean;
/*  998 */       this.upDownArrow.getStyleClass().setAll(new String[] { isUp() ? "menu-up-arrow" : "menu-down-arrow" });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ArrowMenuItem(ContextMenuContent param1ContextMenuContent1) {
/* 1006 */       getStyleClass().setAll(new String[] { "scroll-arrow" });
/* 1007 */       this.upDownArrow = new StackPane();
/* 1008 */       this.popupMenuContent = param1ContextMenuContent1;
/* 1009 */       this.upDownArrow.setMouseTransparent(true);
/* 1010 */       this.upDownArrow.getStyleClass().setAll(new String[] { isUp() ? "menu-up-arrow" : "menu-down-arrow" });
/*      */       
/* 1012 */       addEventHandler(MouseEvent.MOUSE_ENTERED, param1MouseEvent -> {
/*      */             if (this.scrollTimeline != null && this.scrollTimeline.getStatus() != Animation.Status.STOPPED) {
/*      */               return;
/*      */             }
/*      */             startTimeline();
/*      */           });
/* 1018 */       addEventHandler(MouseEvent.MOUSE_EXITED, param1MouseEvent -> stopTimeline());
/*      */ 
/*      */       
/* 1021 */       setVisible(false);
/* 1022 */       setManaged(false);
/* 1023 */       getChildren().add(this.upDownArrow);
/*      */     }
/*      */ 
/*      */     
/*      */     protected double computePrefWidth(double param1Double) {
/* 1028 */       return ContextMenuContent.this.itemsContainer.getWidth();
/*      */     }
/*      */     
/*      */     protected double computePrefHeight(double param1Double) {
/* 1032 */       return snappedTopInset() + this.upDownArrow.prefHeight(-1.0D) + snappedBottomInset();
/*      */     }
/*      */     
/*      */     protected void layoutChildren() {
/* 1036 */       double d1 = snapSizeX(this.upDownArrow.prefWidth(-1.0D));
/* 1037 */       double d2 = snapSizeY(this.upDownArrow.prefHeight(-1.0D));
/*      */       
/* 1039 */       this.upDownArrow.resize(d1, d2);
/* 1040 */       positionInArea(this.upDownArrow, 0.0D, 0.0D, getWidth(), getHeight(), 0.0D, HPos.CENTER, VPos.CENTER);
/*      */     }
/*      */ 
/*      */     
/*      */     private void adjust() {
/* 1045 */       if (this.up) { this.popupMenuContent.scroll(12.0D); } else { this.popupMenuContent.scroll(-12.0D); }
/*      */     
/*      */     }
/*      */     private void startTimeline() {
/* 1049 */       this.scrollTimeline = new Timeline();
/* 1050 */       this.scrollTimeline.setCycleCount(-1);
/*      */       
/* 1052 */       KeyFrame keyFrame = new KeyFrame(Duration.millis(60.0D), param1ActionEvent -> adjust(), new javafx.animation.KeyValue[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1057 */       this.scrollTimeline.getKeyFrames().clear();
/* 1058 */       this.scrollTimeline.getKeyFrames().add(keyFrame);
/* 1059 */       this.scrollTimeline.play();
/*      */     }
/*      */     
/*      */     private void stopTimeline() {
/* 1063 */       this.scrollTimeline.stop();
/* 1064 */       this.scrollTimeline = null;
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   public class MenuItemContainer
/*      */     extends Region
/*      */   {
/*      */     private final MenuItem item;
/*      */     
/*      */     private Node left;
/*      */     
/*      */     private Node graphic;
/*      */     
/*      */     private Node label;
/*      */     
/*      */     private Node right;
/*      */     
/* 1082 */     private final LambdaMultiplePropertyChangeListenerHandler listener = new LambdaMultiplePropertyChangeListenerHandler();
/*      */     
/*      */     private EventHandler<MouseEvent> mouseEnteredEventHandler;
/*      */     
/*      */     private EventHandler<MouseEvent> mouseReleasedEventHandler;
/*      */     private EventHandler<ActionEvent> actionEventHandler;
/*      */     private EventHandler<MouseEvent> customMenuItemMouseClickedHandler;
/*      */     
/*      */     protected Label getLabel() {
/* 1091 */       return (Label)this.label;
/*      */     }
/*      */     
/*      */     public MenuItem getItem() {
/* 1095 */       return this.item;
/*      */     }
/*      */     
/*      */     public MenuItemContainer(MenuItem param1MenuItem) {
/* 1099 */       if (param1MenuItem == null) {
/* 1100 */         throw new NullPointerException("MenuItem can not be null");
/*      */       }
/*      */       
/* 1103 */       getStyleClass().addAll(param1MenuItem.getStyleClass());
/* 1104 */       setId(param1MenuItem.getId());
/* 1105 */       setFocusTraversable(!(param1MenuItem instanceof CustomMenuItem));
/* 1106 */       this.item = param1MenuItem;
/*      */       
/* 1108 */       createChildren();
/*      */ 
/*      */ 
/*      */       
/* 1112 */       if (param1MenuItem instanceof Menu) {
/* 1113 */         ReadOnlyBooleanProperty readOnlyBooleanProperty = ((Menu)param1MenuItem).showingProperty();
/* 1114 */         this.listener.registerChangeListener(readOnlyBooleanProperty, param1ObservableValue -> pseudoClassStateChanged(ContextMenuContent.SELECTED_PSEUDOCLASS_STATE, ((Menu)param1MenuItem).isShowing()));
/*      */         
/* 1116 */         pseudoClassStateChanged(ContextMenuContent.SELECTED_PSEUDOCLASS_STATE, readOnlyBooleanProperty.get());
/* 1117 */         setAccessibleRole(AccessibleRole.MENU);
/* 1118 */       } else if (param1MenuItem instanceof RadioMenuItem) {
/* 1119 */         BooleanProperty booleanProperty = ((RadioMenuItem)param1MenuItem).selectedProperty();
/* 1120 */         this.listener.registerChangeListener(booleanProperty, param1ObservableValue -> pseudoClassStateChanged(ContextMenuContent.CHECKED_PSEUDOCLASS_STATE, ((RadioMenuItem)param1MenuItem).isSelected()));
/*      */         
/* 1122 */         pseudoClassStateChanged(ContextMenuContent.CHECKED_PSEUDOCLASS_STATE, booleanProperty.get());
/* 1123 */         setAccessibleRole(AccessibleRole.RADIO_MENU_ITEM);
/* 1124 */       } else if (param1MenuItem instanceof CheckMenuItem) {
/* 1125 */         BooleanProperty booleanProperty = ((CheckMenuItem)param1MenuItem).selectedProperty();
/* 1126 */         this.listener.registerChangeListener(booleanProperty, param1ObservableValue -> pseudoClassStateChanged(ContextMenuContent.CHECKED_PSEUDOCLASS_STATE, ((CheckMenuItem)param1MenuItem).isSelected()));
/*      */         
/* 1128 */         pseudoClassStateChanged(ContextMenuContent.CHECKED_PSEUDOCLASS_STATE, booleanProperty.get());
/* 1129 */         setAccessibleRole(AccessibleRole.CHECK_MENU_ITEM);
/*      */       } else {
/* 1131 */         setAccessibleRole(AccessibleRole.MENU_ITEM);
/*      */       } 
/*      */       
/* 1134 */       pseudoClassStateChanged(ContextMenuContent.DISABLED_PSEUDOCLASS_STATE, param1MenuItem.disableProperty().get());
/* 1135 */       this.listener.registerChangeListener(param1MenuItem.disableProperty(), param1ObservableValue -> pseudoClassStateChanged(ContextMenuContent.DISABLED_PSEUDOCLASS_STATE, param1MenuItem.isDisable()));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1140 */       getProperties().put(MenuItem.class, param1MenuItem);
/*      */       
/* 1142 */       this.listener.registerChangeListener(param1MenuItem.graphicProperty(), param1ObservableValue -> {
/*      */             createChildren();
/*      */             
/*      */             ContextMenuContent.this.computeVisualMetrics();
/*      */           });
/* 1147 */       this.actionEventHandler = (param1ActionEvent -> {
/*      */           if (param1MenuItem instanceof Menu) {
/*      */             Menu menu = (Menu)param1MenuItem;
/*      */             if (ContextMenuContent.this.openSubmenu == menu && ContextMenuContent.this.submenu.isShowing()) {
/*      */               return;
/*      */             }
/*      */             if (ContextMenuContent.this.openSubmenu != null)
/*      */               ContextMenuContent.this.hideSubmenu(); 
/*      */             ContextMenuContent.this.selectedBackground = this;
/*      */             ContextMenuContent.this.showMenu(menu);
/*      */           } else {
/*      */             doSelect();
/*      */           } 
/*      */         });
/* 1161 */       addEventHandler(ActionEvent.ACTION, this.actionEventHandler);
/*      */     }
/*      */     
/*      */     public void dispose() {
/* 1165 */       if (this.item instanceof CustomMenuItem) {
/* 1166 */         Node node = ((CustomMenuItem)this.item).getContent();
/* 1167 */         if (node != null) {
/* 1168 */           node.removeEventHandler(MouseEvent.MOUSE_CLICKED, this.customMenuItemMouseClickedHandler);
/*      */         }
/*      */       } 
/*      */       
/* 1172 */       this.listener.dispose();
/* 1173 */       removeEventHandler(ActionEvent.ACTION, this.actionEventHandler);
/*      */       
/* 1175 */       if (this.label != null) {
/* 1176 */         ((Label)this.label).textProperty().unbind();
/* 1177 */         this.label.styleProperty().unbind();
/* 1178 */         this.label.idProperty().unbind();
/*      */         
/* 1180 */         ListChangeListener<? super String> listChangeListener = (ListChangeListener)this.item.getProperties().remove("itemStyleClassListener");
/* 1181 */         if (listChangeListener != null) {
/* 1182 */           this.item.getStyleClass().removeListener(listChangeListener);
/*      */         }
/*      */       } 
/*      */       
/* 1186 */       this.left = null;
/* 1187 */       this.graphic = null;
/* 1188 */       this.label = null;
/* 1189 */       this.right = null;
/*      */     }
/*      */     
/*      */     private void createChildren() {
/* 1193 */       getChildren().clear();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1198 */       if (this.item instanceof CustomMenuItem) {
/* 1199 */         createNodeMenuItemChildren((CustomMenuItem)this.item);
/*      */         
/* 1201 */         if (this.mouseEnteredEventHandler == null) {
/* 1202 */           this.mouseEnteredEventHandler = (param1MouseEvent -> requestFocus());
/*      */         }
/*      */         else {
/*      */           
/* 1206 */           removeEventHandler(MouseEvent.MOUSE_ENTERED, this.mouseEnteredEventHandler);
/*      */         } 
/* 1208 */         addEventHandler(MouseEvent.MOUSE_ENTERED, this.mouseEnteredEventHandler);
/*      */       } else {
/*      */         
/* 1211 */         Node node = getLeftGraphic(this.item);
/* 1212 */         if (node != null) {
/* 1213 */           StackPane stackPane = new StackPane();
/* 1214 */           stackPane.getStyleClass().add("left-container");
/* 1215 */           stackPane.getChildren().add(node);
/* 1216 */           this.left = stackPane;
/* 1217 */           getChildren().add(this.left);
/* 1218 */           this.left.setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
/*      */         } 
/*      */         
/* 1221 */         if (this.item.getGraphic() != null) {
/* 1222 */           Node node1 = this.item.getGraphic();
/* 1223 */           StackPane stackPane = new StackPane();
/* 1224 */           stackPane.getStyleClass().add("graphic-container");
/* 1225 */           stackPane.getChildren().add(node1);
/* 1226 */           this.graphic = stackPane;
/* 1227 */           getChildren().add(this.graphic);
/*      */         } 
/*      */ 
/*      */         
/* 1231 */         this.label = new ContextMenuContent.MenuLabel(this.item, this);
/*      */ 
/*      */         
/* 1234 */         ((Label)this.label).textProperty().bind(this.item.textProperty());
/* 1235 */         this.label.styleProperty().bind(this.item.styleProperty());
/* 1236 */         this.label.idProperty().bind(this.item.styleProperty());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1244 */         ListChangeListener<? super String> listChangeListener = param1Change -> {
/*      */             while (param1Change.next()) {
/*      */               this.label.getStyleClass().removeAll(param1Change.getRemoved());
/*      */               this.label.getStyleClass().addAll((Collection)param1Change.getAddedSubList());
/*      */             } 
/*      */           };
/* 1250 */         this.item.getStyleClass().addListener(listChangeListener);
/* 1251 */         this.item.getProperties().put("itemStyleClassListener", listChangeListener);
/*      */ 
/*      */         
/* 1254 */         this.label.setMouseTransparent(true);
/* 1255 */         getChildren().add(this.label);
/*      */         
/* 1257 */         this.listener.unregisterChangeListeners(focusedProperty());
/*      */ 
/*      */ 
/*      */         
/* 1261 */         this.listener.registerChangeListener(focusedProperty(), param1ObservableValue -> {
/*      */               if (isFocused()) {
/*      */                 ContextMenuContent.this.currentFocusedIndex = ContextMenuContent.this.itemsContainer.getChildren().indexOf(this);
/*      */               }
/*      */             });
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1270 */         if (this.item instanceof Menu) {
/*      */           
/* 1272 */           Region region = new Region();
/* 1273 */           region.setMouseTransparent(true);
/* 1274 */           region.getStyleClass().add("arrow");
/*      */           
/* 1276 */           StackPane stackPane = new StackPane();
/* 1277 */           stackPane.setMaxWidth(Math.max(region.prefWidth(-1.0D), 10.0D));
/* 1278 */           stackPane.setMouseTransparent(true);
/* 1279 */           stackPane.getStyleClass().add("right-container");
/* 1280 */           stackPane.getChildren().add(region);
/* 1281 */           this.right = stackPane;
/* 1282 */           getChildren().add(stackPane);
/*      */           
/* 1284 */           if (this.mouseEnteredEventHandler == null) {
/* 1285 */             this.mouseEnteredEventHandler = (param1MouseEvent -> {
/*      */                 if (ContextMenuContent.this.openSubmenu != null && this.item != ContextMenuContent.this.openSubmenu) {
/*      */                   ContextMenuContent.this.hideSubmenu();
/*      */                 }
/*      */                 
/*      */                 ContextMenuContent.this.selectedBackground = this;
/*      */                 requestFocus();
/*      */                 Menu menu = (Menu)this.item;
/*      */                 if (menu.isDisable()) {
/*      */                   return;
/*      */                 }
/*      */                 menu.show();
/*      */               });
/*      */           } else {
/* 1299 */             removeEventHandler(MouseEvent.MOUSE_ENTERED, this.mouseEnteredEventHandler);
/*      */           } 
/*      */           
/* 1302 */           if (this.mouseReleasedEventHandler == null) {
/* 1303 */             this.mouseReleasedEventHandler = (param1MouseEvent -> this.item.fire());
/*      */           }
/*      */           else {
/*      */             
/* 1307 */             removeEventHandler(MouseEvent.MOUSE_RELEASED, this.mouseReleasedEventHandler);
/*      */           } 
/*      */ 
/*      */           
/* 1311 */           addEventHandler(MouseEvent.MOUSE_ENTERED, this.mouseEnteredEventHandler);
/* 1312 */           addEventHandler(MouseEvent.MOUSE_RELEASED, this.mouseReleasedEventHandler);
/*      */         } else {
/*      */           
/* 1315 */           this.listener.unregisterChangeListeners(this.item.acceleratorProperty());
/*      */ 
/*      */           
/* 1318 */           updateAccelerator();
/*      */           
/* 1320 */           if (this.mouseEnteredEventHandler == null) {
/* 1321 */             this.mouseEnteredEventHandler = (param1MouseEvent -> {
/*      */                 if (ContextMenuContent.this.openSubmenu != null) {
/*      */                   ContextMenuContent.this.openSubmenu.hide();
/*      */                 }
/*      */                 requestFocus();
/*      */               });
/*      */           } else {
/* 1328 */             removeEventHandler(MouseEvent.MOUSE_ENTERED, this.mouseEnteredEventHandler);
/*      */           } 
/*      */           
/* 1331 */           if (this.mouseReleasedEventHandler == null) {
/* 1332 */             this.mouseReleasedEventHandler = (param1MouseEvent -> doSelect());
/*      */           }
/*      */           else {
/*      */             
/* 1336 */             removeEventHandler(MouseEvent.MOUSE_RELEASED, this.mouseReleasedEventHandler);
/*      */           } 
/*      */           
/* 1339 */           addEventHandler(MouseEvent.MOUSE_ENTERED, this.mouseEnteredEventHandler);
/* 1340 */           addEventHandler(MouseEvent.MOUSE_RELEASED, this.mouseReleasedEventHandler);
/*      */           
/* 1342 */           this.listener.registerChangeListener(this.item.acceleratorProperty(), param1ObservableValue -> updateAccelerator());
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void updateAccelerator() {
/* 1348 */       if (this.item.getAccelerator() != null) {
/* 1349 */         if (this.right != null) {
/* 1350 */           getChildren().remove(this.right);
/*      */         }
/*      */         
/* 1353 */         String str = this.item.getAccelerator().getDisplayText();
/* 1354 */         this.right = new Label(str);
/* 1355 */         this.right.setStyle(this.item.getStyle());
/* 1356 */         this.right.getStyleClass().add("accelerator-text");
/* 1357 */         getChildren().add(this.right);
/*      */       } else {
/* 1359 */         getChildren().remove(this.right);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void doSelect() {
/* 1365 */       if (this.item.isDisable())
/*      */         return; 
/* 1367 */       if (this.item instanceof CheckMenuItem) {
/* 1368 */         CheckMenuItem checkMenuItem = (CheckMenuItem)this.item;
/* 1369 */         checkMenuItem.setSelected(!checkMenuItem.isSelected());
/* 1370 */       } else if (this.item instanceof RadioMenuItem) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1375 */         RadioMenuItem radioMenuItem = (RadioMenuItem)this.item;
/* 1376 */         radioMenuItem.setSelected((radioMenuItem.getToggleGroup() != null) ? true : (!radioMenuItem.isSelected()));
/*      */       } 
/*      */ 
/*      */       
/* 1380 */       this.item.fire();
/*      */       
/* 1382 */       if (this.item instanceof CustomMenuItem) {
/* 1383 */         CustomMenuItem customMenuItem = (CustomMenuItem)this.item;
/* 1384 */         if (customMenuItem.isHideOnClick()) {
/* 1385 */           ContextMenuContent.this.hideAllMenus(this.item);
/*      */         }
/*      */       } else {
/* 1388 */         ContextMenuContent.this.hideAllMenus(this.item);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void createNodeMenuItemChildren(CustomMenuItem param1CustomMenuItem) {
/* 1395 */       Node node = param1CustomMenuItem.getContent();
/* 1396 */       getChildren().add(node);
/*      */ 
/*      */       
/* 1399 */       this.customMenuItemMouseClickedHandler = (param1MouseEvent -> {
/*      */           if (param1CustomMenuItem == null || param1CustomMenuItem.isDisable()) {
/*      */             return;
/*      */           }
/*      */           param1CustomMenuItem.fire();
/*      */           if (param1CustomMenuItem.isHideOnClick())
/*      */             ContextMenuContent.this.hideAllMenus(param1CustomMenuItem); 
/*      */         });
/* 1407 */       node.addEventHandler(MouseEvent.MOUSE_CLICKED, this.customMenuItemMouseClickedHandler);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void layoutChildren() {
/* 1413 */       double d = prefHeight(-1.0D);
/* 1414 */       if (this.left != null) {
/* 1415 */         double d1 = snappedLeftInset();
/* 1416 */         this.left.resize(this.left.prefWidth(-1.0D), this.left.prefHeight(-1.0D));
/* 1417 */         positionInArea(this.left, d1, 0.0D, ContextMenuContent.this
/* 1418 */             .maxLeftWidth, d, 0.0D, HPos.LEFT, VPos.CENTER);
/*      */       } 
/* 1420 */       if (this.graphic != null) {
/* 1421 */         double d1 = snappedLeftInset() + ContextMenuContent.this.maxLeftWidth;
/* 1422 */         this.graphic.resize(this.graphic.prefWidth(-1.0D), this.graphic.prefHeight(-1.0D));
/* 1423 */         positionInArea(this.graphic, d1, 0.0D, ContextMenuContent.this
/* 1424 */             .maxGraphicWidth, d, 0.0D, HPos.LEFT, VPos.CENTER);
/*      */       } 
/*      */       
/* 1427 */       if (this.label != null) {
/* 1428 */         double d1 = snappedLeftInset() + ContextMenuContent.this.maxLeftWidth + ContextMenuContent.this.maxGraphicWidth;
/* 1429 */         this.label.resize(this.label.prefWidth(-1.0D), this.label.prefHeight(-1.0D));
/* 1430 */         positionInArea(this.label, d1, 0.0D, ContextMenuContent.this
/* 1431 */             .maxLabelWidth, d, 0.0D, HPos.LEFT, VPos.CENTER);
/*      */       } 
/*      */       
/* 1434 */       if (this.right != null) {
/* 1435 */         double d1 = snappedLeftInset() + ContextMenuContent.this.maxLeftWidth + ContextMenuContent.this.maxGraphicWidth + ContextMenuContent.this.maxLabelWidth;
/* 1436 */         this.right.resize(this.right.prefWidth(-1.0D), this.right.prefHeight(-1.0D));
/* 1437 */         positionInArea(this.right, d1, 0.0D, ContextMenuContent.this
/* 1438 */             .maxRightWidth, d, 0.0D, HPos.RIGHT, VPos.CENTER);
/*      */       } 
/*      */       
/* 1441 */       if (this.item instanceof CustomMenuItem) {
/* 1442 */         Node node = ((CustomMenuItem)this.item).getContent();
/* 1443 */         if (this.item instanceof javafx.scene.control.SeparatorMenuItem) {
/* 1444 */           double d1 = prefWidth(-1.0D) - snappedLeftInset() + ContextMenuContent.this.maxGraphicWidth + snappedRightInset();
/* 1445 */           node.resize(d1, node.prefHeight(-1.0D));
/* 1446 */           positionInArea(node, snappedLeftInset() + ContextMenuContent.this.maxGraphicWidth, 0.0D, prefWidth(-1.0D), d, 0.0D, HPos.LEFT, VPos.CENTER);
/*      */         } else {
/* 1448 */           node.resize(node.prefWidth(-1.0D), node.prefHeight(-1.0D));
/*      */           
/* 1450 */           positionInArea(node, snappedLeftInset(), 0.0D, getWidth(), d, 0.0D, HPos.LEFT, VPos.CENTER);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     protected double computePrefHeight(double param1Double) {
/* 1456 */       double d = 0.0D;
/* 1457 */       if (this.item instanceof CustomMenuItem || this.item instanceof javafx.scene.control.SeparatorMenuItem) {
/* 1458 */         d = getChildren().isEmpty() ? 0.0D : ((Node)getChildren().get(0)).prefHeight(-1.0D);
/*      */       } else {
/* 1460 */         d = Math.max(d, (this.left != null) ? this.left.prefHeight(-1.0D) : 0.0D);
/* 1461 */         d = Math.max(d, (this.graphic != null) ? this.graphic.prefHeight(-1.0D) : 0.0D);
/* 1462 */         d = Math.max(d, (this.label != null) ? this.label.prefHeight(-1.0D) : 0.0D);
/* 1463 */         d = Math.max(d, (this.right != null) ? this.right.prefHeight(-1.0D) : 0.0D);
/*      */       } 
/* 1465 */       return snappedTopInset() + d + snappedBottomInset();
/*      */     }
/*      */     
/*      */     protected double computePrefWidth(double param1Double) {
/* 1469 */       double d = 0.0D;
/* 1470 */       if (this.item instanceof CustomMenuItem && !(this.item instanceof javafx.scene.control.SeparatorMenuItem))
/*      */       {
/* 1472 */         d = snappedLeftInset() + ((CustomMenuItem)this.item).getContent().prefWidth(-1.0D) + snappedRightInset();
/*      */       }
/* 1474 */       return Math.max(d, 
/* 1475 */           snappedLeftInset() + ContextMenuContent.this.maxLeftWidth + ContextMenuContent.this.maxGraphicWidth + ContextMenuContent.this
/* 1476 */           .maxLabelWidth + ContextMenuContent.this.maxRightWidth + snappedRightInset());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Node getLeftGraphic(MenuItem param1MenuItem) {
/* 1483 */       if (param1MenuItem instanceof RadioMenuItem) {
/* 1484 */         Region region = new Region();
/* 1485 */         region.getStyleClass().add("radio");
/* 1486 */         return region;
/* 1487 */       }  if (param1MenuItem instanceof CheckMenuItem) {
/* 1488 */         StackPane stackPane = new StackPane();
/* 1489 */         stackPane.getStyleClass().add("check");
/* 1490 */         return stackPane;
/*      */       } 
/*      */       
/* 1493 */       return null;
/*      */     } public Object queryAccessibleAttribute(AccessibleAttribute param1AccessibleAttribute, Object... param1VarArgs) {
/*      */       String str;
/*      */       Label label1;
/*      */       ContextMenuContent contextMenuContent;
/*      */       Label label2;
/* 1499 */       switch (param1AccessibleAttribute) {
/*      */         case NONE:
/* 1501 */           if (this.item instanceof CheckMenuItem) {
/* 1502 */             return Boolean.valueOf(((CheckMenuItem)this.item).isSelected());
/*      */           }
/* 1504 */           if (this.item instanceof RadioMenuItem) {
/* 1505 */             return Boolean.valueOf(((RadioMenuItem)this.item).isSelected());
/*      */           }
/* 1507 */           return Boolean.valueOf(false);
/* 1508 */         case null: return this.item.getAccelerator();
/*      */         case null:
/* 1510 */           str = "";
/* 1511 */           if (this.graphic != null) {
/* 1512 */             String str1 = (String)this.graphic.queryAccessibleAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 1513 */             if (str1 != null) str = str + str; 
/*      */           } 
/* 1515 */           label2 = getLabel();
/* 1516 */           if (label2 != null) {
/* 1517 */             String str1 = (String)label2.queryAccessibleAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 1518 */             if (str1 != null) str = str + str; 
/*      */           } 
/* 1520 */           if (this.item instanceof CustomMenuItem) {
/* 1521 */             Node node = ((CustomMenuItem)this.item).getContent();
/* 1522 */             if (node != null) {
/* 1523 */               String str1 = (String)node.queryAccessibleAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 1524 */               if (str1 != null) str = str + str; 
/*      */             } 
/*      */           } 
/* 1527 */           return str;
/*      */         
/*      */         case null:
/* 1530 */           label1 = getLabel();
/* 1531 */           if (label1 != null) {
/* 1532 */             String str1 = (String)label1.queryAccessibleAttribute(AccessibleAttribute.MNEMONIC, new Object[0]);
/* 1533 */             if (str1 != null) return str1; 
/*      */           } 
/* 1535 */           return null;
/*      */         case null:
/* 1537 */           return Boolean.valueOf(this.item.isDisable());
/*      */         case null:
/* 1539 */           ContextMenuContent.this.createSubmenu();
/*      */ 
/*      */           
/* 1542 */           if (ContextMenuContent.this.submenu.getSkin() == null) {
/* 1543 */             ContextMenuContent.this.submenu.getStyleableNode().applyCss();
/*      */           }
/* 1545 */           contextMenuContent = (ContextMenuContent)ContextMenuContent.this.submenu.getSkin().getNode();
/* 1546 */           return contextMenuContent.itemsContainer;
/* 1547 */       }  return super.queryAccessibleAttribute(param1AccessibleAttribute, param1VarArgs);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void executeAccessibleAction(AccessibleAction param1AccessibleAction, Object... param1VarArgs) {
/* 1554 */       switch (param1AccessibleAction) {
/*      */         case LINES:
/* 1556 */           if (this.item instanceof Menu) {
/* 1557 */             Menu menu = (Menu)this.item;
/* 1558 */             if (menu.isShowing()) {
/* 1559 */               menu.hide();
/*      */             } else {
/* 1561 */               menu.show();
/*      */             } 
/*      */           } 
/*      */           return;
/*      */         
/*      */         case PAGES:
/* 1567 */           doSelect(); return;
/*      */       } 
/* 1569 */       super.executeAccessibleAction(param1AccessibleAction, new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1576 */   private static final PseudoClass SELECTED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("selected");
/*      */   
/* 1578 */   private static final PseudoClass DISABLED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("disabled");
/*      */   
/* 1580 */   private static final PseudoClass CHECKED_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("checked");
/*      */   
/*      */   private class MenuLabel
/*      */     extends Label {
/*      */     public MenuLabel(MenuItem param1MenuItem, ContextMenuContent.MenuItemContainer param1MenuItemContainer) {
/* 1585 */       super(param1MenuItem.getText());
/* 1586 */       setMnemonicParsing(param1MenuItem.isMnemonicParsing());
/* 1587 */       setLabelFor(param1MenuItemContainer);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\ContextMenuContent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */