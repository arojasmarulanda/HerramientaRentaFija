/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ComboBox;
/*     */ import javafx.scene.control.ComboBoxBase;
/*     */ import javafx.scene.control.DatePicker;
/*     */ import javafx.scene.control.PopupControl;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboBoxBaseBehavior<T>
/*     */   extends BehaviorBase<ComboBoxBase<T>>
/*     */ {
/*     */   private final InputMap<ComboBoxBase<T>> inputMap;
/*     */   private TwoLevelFocusComboBehavior tlFocus;
/*     */   private boolean keyDown;
/*     */   private boolean showPopupOnMouseRelease;
/*     */   private boolean mouseInsideButton;
/*     */   
/*     */   public ComboBoxBaseBehavior(ComboBoxBase<T> paramComboBoxBase) {
/*  63 */     super(paramComboBoxBase);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 294 */     this.showPopupOnMouseRelease = true;
/* 295 */     this.mouseInsideButton = false; this.inputMap = createInputMap(); EventHandler eventHandler = paramKeyEvent -> { this.showPopupOnMouseRelease = true; if (getNode().isShowing()) { hide(); } else { show(); }  }; InputMap.KeyMapping keyMapping1, keyMapping2; addDefaultMapping(this.inputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.F4, KeyEvent.KEY_RELEASED, eventHandler), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.UP)).alt(), eventHandler), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN)).alt(), eventHandler), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, KeyEvent.KEY_PRESSED, this::keyPressed), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, KeyEvent.KEY_RELEASED, this::keyReleased), (InputMap.Mapping)(keyMapping1 = new InputMap.KeyMapping(KeyCode.ENTER, KeyEvent.KEY_PRESSED, this::keyPressed)), (InputMap.Mapping)(keyMapping2 = new InputMap.KeyMapping(KeyCode.ENTER, KeyEvent.KEY_RELEASED, this::keyReleased)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ESCAPE, KeyEvent.KEY_PRESSED, this::cancelEdit), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.F10, KeyEvent.KEY_PRESSED, this::forwardToParent), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_RELEASED, this::mouseReleased), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_ENTERED, this::mouseEntered), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_EXITED, this::mouseExited) }); keyMapping1.setAutoConsume(false); keyMapping2.setAutoConsume(false); paramComboBoxBase.focusedProperty().addListener(this::focusChanged); if (Utils.isTwoLevelFocus()) this.tlFocus = new TwoLevelFocusComboBehavior(paramComboBoxBase); 
/*     */   }
/*     */   public void dispose() { if (this.tlFocus != null) this.tlFocus.dispose();  getNode().focusedProperty().removeListener(this::focusChanged); super.dispose(); }
/*     */   public InputMap<ComboBoxBase<T>> getInputMap() { return this.inputMap; }
/*     */   protected void focusChanged(Observable paramObservable) { ComboBoxBase<T> comboBoxBase = getNode(); if (this.keyDown && !comboBoxBase.isFocused()) { this.keyDown = false; comboBoxBase.disarm(); }  }
/*     */   private void keyPressed(KeyEvent paramKeyEvent) { this.showPopupOnMouseRelease = true; if (Utils.isTwoLevelFocus()) { show(); if (this.tlFocus != null) this.tlFocus.setExternalFocus(false);  } else if (!getNode().isPressed() && !getNode().isArmed()) { this.keyDown = true; getNode().arm(); }  }
/*     */   private void keyReleased(KeyEvent paramKeyEvent) { this.showPopupOnMouseRelease = true; if (!Utils.isTwoLevelFocus() && this.keyDown) { this.keyDown = false; if (getNode().isArmed()) getNode().disarm();  }  }
/* 302 */   private void forwardToParent(KeyEvent paramKeyEvent) { if (getNode().getParent() != null) getNode().getParent().fireEvent(paramKeyEvent);  } private void cancelEdit(KeyEvent paramKeyEvent) { ComboBoxBase<T> comboBoxBase = getNode(); TextField textField = null; if (comboBoxBase instanceof DatePicker) { textField = ((DatePicker)comboBoxBase).getEditor(); } else if (comboBoxBase instanceof ComboBox) { textField = comboBoxBase.isEditable() ? ((ComboBox)comboBoxBase).getEditor() : null; }  if (textField != null && textField.getTextFormatter() != null) { textField.cancelEdit(); } else { forwardToParent(paramKeyEvent); }  } public void onAutoHide(PopupControl paramPopupControl) { hide();
/* 303 */     this.showPopupOnMouseRelease = this.mouseInsideButton ? (!this.showPopupOnMouseRelease) : true; }
/*     */   public void mousePressed(MouseEvent paramMouseEvent) { arm(paramMouseEvent); }
/*     */   public void mouseReleased(MouseEvent paramMouseEvent) { disarm(); if (this.showPopupOnMouseRelease) { show(); } else { this.showPopupOnMouseRelease = true; hide(); }  }
/*     */   public void mouseEntered(MouseEvent paramMouseEvent) { if (!getNode().isEditable()) { this.mouseInsideButton = true; } else { EventTarget eventTarget = paramMouseEvent.getTarget(); this.mouseInsideButton = (eventTarget instanceof Node && "arrow-button".equals(((Node)eventTarget).getId())); }  arm(); }
/* 307 */   public void mouseExited(MouseEvent paramMouseEvent) { this.mouseInsideButton = false; disarm(); } private void arm(MouseEvent paramMouseEvent) { boolean bool = (paramMouseEvent.getButton() == MouseButton.PRIMARY && !paramMouseEvent.isMiddleButtonDown() && !paramMouseEvent.isSecondaryButtonDown() && !paramMouseEvent.isShiftDown() && !paramMouseEvent.isControlDown() && !paramMouseEvent.isAltDown() && !paramMouseEvent.isMetaDown()) ? true : false; if (!getNode().isArmed() && bool) getNode().arm();  } public void show() { if (!getNode().isShowing()) { if (getNode().isFocusTraversable()) getNode().requestFocus();  getNode().show(); }  } public void hide() { if (getNode().isShowing()) getNode().hide();  } public void arm() { if (getNode().isPressed()) {
/* 308 */       getNode().arm();
/*     */     } }
/*     */ 
/*     */   
/*     */   public void disarm() {
/* 313 */     if (!this.keyDown && getNode().isArmed())
/* 314 */       getNode().disarm(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ComboBoxBaseBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */