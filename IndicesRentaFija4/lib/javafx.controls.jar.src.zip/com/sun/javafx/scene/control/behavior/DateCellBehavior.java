/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import com.sun.javafx.scene.control.DatePickerContent;
/*    */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*    */ import com.sun.javafx.scene.traversal.Direction;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import javafx.geometry.NodeOrientation;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.control.DateCell;
/*    */ import javafx.scene.input.KeyCode;
/*    */ import javafx.scene.input.KeyEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateCellBehavior
/*    */   extends BehaviorBase<DateCell>
/*    */ {
/*    */   private final InputMap<DateCell> inputMap;
/*    */   
/*    */   public DateCellBehavior(DateCell paramDateCell) {
/* 56 */     super(paramDateCell);
/*    */     
/* 58 */     this.inputMap = createInputMap();
/* 59 */     addDefaultMapping(this.inputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> traverse(paramDateCell, Direction.UP)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> traverse(paramDateCell, Direction.DOWN)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> traverse(paramDateCell, Direction.LEFT)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> traverse(paramDateCell, Direction.RIGHT)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ENTER, KeyEvent.KEY_RELEASED, paramKeyEvent -> selectDate()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, KeyEvent.KEY_RELEASED, paramKeyEvent -> selectDate()) });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InputMap<DateCell> getInputMap() {
/* 70 */     return this.inputMap;
/*    */   }
/*    */   
/*    */   private void selectDate() {
/* 74 */     DateCell dateCell = getNode();
/* 75 */     DatePickerContent datePickerContent = findDatePickerContent(dateCell);
/* 76 */     datePickerContent.selectDayCell(dateCell);
/*    */   }
/*    */   
/*    */   public void traverse(DateCell paramDateCell, Direction paramDirection) {
/* 80 */     boolean bool = (paramDateCell.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) ? true : false;
/* 81 */     DatePickerContent datePickerContent = findDatePickerContent(paramDateCell);
/* 82 */     if (datePickerContent != null) {
/* 83 */       switch (paramDirection) { case UP:
/* 84 */           datePickerContent.goToDayCell(paramDateCell, -1, ChronoUnit.WEEKS, true); break;
/* 85 */         case DOWN: datePickerContent.goToDayCell(paramDateCell, 1, ChronoUnit.WEEKS, true); break;
/* 86 */         case LEFT: datePickerContent.goToDayCell(paramDateCell, bool ? 1 : -1, ChronoUnit.DAYS, true); break;
/* 87 */         case RIGHT: datePickerContent.goToDayCell(paramDateCell, bool ? -1 : 1, ChronoUnit.DAYS, true);
/*    */           break; }
/*    */     
/*    */     }
/*    */   }
/*    */   
/*    */   protected DatePickerContent findDatePickerContent(Node paramNode) {
/* 94 */     Node node = paramNode;
/* 95 */     while ((node = node.getParent()) != null && !(node instanceof DatePickerContent));
/* 96 */     return (DatePickerContent)node;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\DateCellBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */