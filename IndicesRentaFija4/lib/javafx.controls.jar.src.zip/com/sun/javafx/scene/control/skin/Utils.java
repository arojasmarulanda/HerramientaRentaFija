/*     */ package com.sun.javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.control.ContextMenuContent;
/*     */ import com.sun.javafx.scene.control.behavior.TextBinding;
/*     */ import com.sun.javafx.scene.text.FontHelper;
/*     */ import com.sun.javafx.scene.text.TextLayout;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import java.net.URL;
/*     */ import java.text.Bidi;
/*     */ import java.util.Locale;
/*     */ import java.util.function.Consumer;
/*     */ import javafx.application.ConditionalFeature;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.OverrunStyle;
/*     */ import javafx.scene.input.KeyCombination;
/*     */ import javafx.scene.input.Mnemonic;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.text.Font;
/*     */ import javafx.scene.text.Text;
/*     */ import javafx.scene.text.TextBoundsType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*  83 */   static final Text helper = new Text();
/*  84 */   static final double DEFAULT_WRAPPING_WIDTH = helper.getWrappingWidth();
/*  85 */   static final double DEFAULT_LINE_SPACING = helper.getLineSpacing();
/*  86 */   static final String DEFAULT_TEXT = helper.getText();
/*  87 */   static final TextBoundsType DEFAULT_BOUNDS_TYPE = helper.getBoundsType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   static final TextLayout layout = Toolkit.getToolkit().getTextLayoutFactory().createLayout();
/*     */   
/*     */   public static double getAscent(Font paramFont, TextBoundsType paramTextBoundsType) {
/* 101 */     layout.setContent("", FontHelper.getNativeFont(paramFont));
/* 102 */     layout.setWrapWidth(0.0F);
/* 103 */     layout.setLineSpacing(0.0F);
/* 104 */     if (paramTextBoundsType == TextBoundsType.LOGICAL_VERTICAL_CENTER) {
/* 105 */       layout.setBoundsType(16384);
/*     */     } else {
/* 107 */       layout.setBoundsType(0);
/*     */     } 
/* 109 */     return -layout.getBounds().getMinY();
/*     */   }
/*     */   
/*     */   public static double getLineHeight(Font paramFont, TextBoundsType paramTextBoundsType) {
/* 113 */     layout.setContent("", FontHelper.getNativeFont(paramFont));
/* 114 */     layout.setWrapWidth(0.0F);
/* 115 */     layout.setLineSpacing(0.0F);
/* 116 */     if (paramTextBoundsType == TextBoundsType.LOGICAL_VERTICAL_CENTER) {
/* 117 */       layout.setBoundsType(16384);
/*     */     } else {
/* 119 */       layout.setBoundsType(0);
/*     */     } 
/*     */ 
/*     */     
/* 123 */     return layout.getLines()[0].getBounds().getHeight();
/*     */   }
/*     */   
/*     */   public static double computeTextWidth(Font paramFont, String paramString, double paramDouble) {
/* 127 */     layout.setContent((paramString != null) ? paramString : "", FontHelper.getNativeFont(paramFont));
/* 128 */     layout.setWrapWidth((float)paramDouble);
/* 129 */     return layout.getBounds().getWidth();
/*     */   }
/*     */   
/*     */   public static double computeTextHeight(Font paramFont, String paramString, double paramDouble, TextBoundsType paramTextBoundsType) {
/* 133 */     return computeTextHeight(paramFont, paramString, paramDouble, 0.0D, paramTextBoundsType);
/*     */   }
/*     */ 
/*     */   
/*     */   public static double computeTextHeight(Font paramFont, String paramString, double paramDouble1, double paramDouble2, TextBoundsType paramTextBoundsType) {
/* 138 */     layout.setContent((paramString != null) ? paramString : "", FontHelper.getNativeFont(paramFont));
/* 139 */     layout.setWrapWidth((float)paramDouble1);
/* 140 */     layout.setLineSpacing((float)paramDouble2);
/* 141 */     if (paramTextBoundsType == TextBoundsType.LOGICAL_VERTICAL_CENTER) {
/* 142 */       layout.setBoundsType(16384);
/*     */     } else {
/* 144 */       layout.setBoundsType(0);
/*     */     } 
/* 146 */     return layout.getBounds().getHeight();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Point2D computeMnemonicPosition(Font paramFont, String paramString, int paramInt, double paramDouble1, double paramDouble2) {
/* 152 */     if (paramFont == null || paramString == null || paramInt < 0 || paramInt > paramString
/* 153 */       .length()) {
/* 154 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 158 */     layout.setContent(paramString, FontHelper.getNativeFont(paramFont));
/* 159 */     layout.setWrapWidth((float)paramDouble1);
/* 160 */     layout.setLineSpacing((float)paramDouble2);
/*     */ 
/*     */ 
/*     */     
/* 164 */     int i = 0;
/* 165 */     byte b = 0;
/* 166 */     int j = (layout.getLines()).length;
/* 167 */     while (b < j) {
/* 168 */       int k = layout.getLines()[b].getLength();
/*     */       
/* 170 */       if (paramInt >= i && paramInt < i + k) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 176 */       i += k;
/* 177 */       b++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 182 */     double d1 = (layout.getBounds().getHeight() / j);
/* 183 */     double d2 = computeTextWidth(paramFont, paramString.substring(i, paramInt), 0.0D);
/*     */     
/* 185 */     double d3 = d1 * (b + 1);
/*     */     
/* 187 */     if (b + 1 != j) {
/* 188 */       d3 -= paramDouble2 / 2.0D;
/*     */     }
/*     */     
/* 191 */     return new Point2D(d2, d3);
/*     */   }
/*     */   
/*     */   public static int computeTruncationIndex(Font paramFont, String paramString, double paramDouble) {
/* 195 */     helper.setText(paramString);
/* 196 */     helper.setFont(paramFont);
/* 197 */     helper.setWrappingWidth(0.0D);
/* 198 */     helper.setLineSpacing(0.0D);
/*     */ 
/*     */ 
/*     */     
/* 202 */     Bounds bounds = helper.getLayoutBounds();
/* 203 */     Point2D point2D = new Point2D(paramDouble - 2.0D, bounds.getMinY() + bounds.getHeight() / 2.0D);
/* 204 */     int i = helper.hitTest(point2D).getCharIndex();
/*     */     
/* 206 */     helper.setWrappingWidth(DEFAULT_WRAPPING_WIDTH);
/* 207 */     helper.setLineSpacing(DEFAULT_LINE_SPACING);
/* 208 */     helper.setText(DEFAULT_TEXT);
/* 209 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String computeClippedText(Font paramFont, String paramString1, double paramDouble, OverrunStyle paramOverrunStyle, String paramString2) {
/* 214 */     if (paramFont == null) {
/* 215 */       throw new IllegalArgumentException("Must specify a font");
/*     */     }
/* 217 */     OverrunStyle overrunStyle = (paramOverrunStyle == null || paramOverrunStyle == OverrunStyle.CLIP) ? OverrunStyle.ELLIPSIS : paramOverrunStyle;
/* 218 */     String str1 = (paramOverrunStyle == OverrunStyle.CLIP) ? "" : paramString2;
/*     */     
/* 220 */     if (paramString1 == null || "".equals(paramString1)) {
/* 221 */       return paramString1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     double d1 = computeTextWidth(paramFont, paramString1, 0.0D);
/* 230 */     if (d1 - paramDouble < 0.0010000000474974513D) {
/* 231 */       return paramString1;
/*     */     }
/*     */     
/* 234 */     double d2 = computeTextWidth(paramFont, str1, 0.0D);
/*     */ 
/*     */     
/* 237 */     double d3 = paramDouble - d2;
/*     */     
/* 239 */     if (paramDouble < d2)
/*     */     {
/* 241 */       return "";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 260 */     if (overrunStyle == OverrunStyle.ELLIPSIS || overrunStyle == OverrunStyle.WORD_ELLIPSIS || overrunStyle == OverrunStyle.LEADING_ELLIPSIS || overrunStyle == OverrunStyle.LEADING_WORD_ELLIPSIS) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 265 */       boolean bool3 = (overrunStyle == OverrunStyle.WORD_ELLIPSIS || overrunStyle == OverrunStyle.LEADING_WORD_ELLIPSIS) ? true : false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 276 */       if (overrunStyle == OverrunStyle.ELLIPSIS && !(new Bidi(paramString1, 0)).isMixed()) {
/* 277 */         int i2 = computeTruncationIndex(paramFont, paramString1, paramDouble - d2);
/* 278 */         if (i2 < 0 || i2 >= paramString1.length()) {
/* 279 */           return paramString1;
/*     */         }
/* 281 */         return paramString1.substring(0, i2) + paramString1.substring(0, i2);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 289 */       double d = 0.0D;
/* 290 */       int m = -1;
/*     */ 
/*     */       
/* 293 */       int n = 0;
/* 294 */       byte b3 = (overrunStyle == OverrunStyle.LEADING_ELLIPSIS || overrunStyle == OverrunStyle.LEADING_WORD_ELLIPSIS) ? (paramString1.length() - 1) : 0;
/* 295 */       byte b4 = !b3 ? (paramString1.length() - 1) : 0;
/* 296 */       byte b5 = !b3 ? 1 : -1;
/* 297 */       boolean bool4 = !b3 ? ((b3 > b4) ? true : false) : ((b3 < b4) ? true : false); int i1;
/* 298 */       for (i1 = b3; !bool4; i1 += b5) {
/* 299 */         n = i1;
/* 300 */         char c = paramString1.charAt(n);
/* 301 */         d = computeTextWidth(paramFont, 
/* 302 */             (b3 == 0) ? paramString1.substring(0, i1 + 1) : 
/* 303 */             paramString1.substring(i1, b3 + 1), 0.0D);
/*     */         
/* 305 */         if (Character.isWhitespace(c)) {
/* 306 */           m = n;
/*     */         }
/* 308 */         if (d > d3) {
/*     */           break;
/*     */         }
/* 311 */         bool4 = (b3 == 0) ? ((i1 >= b4) ? true : false) : ((i1 <= b4) ? true : false);
/*     */       } 
/* 313 */       i1 = (!bool3 || m == -1) ? 1 : 0;
/*     */ 
/*     */       
/* 316 */       String str = (b3 == 0) ? paramString1.substring(0, (i1 != 0) ? n : m) : paramString1.substring(((i1 != 0) ? n : m) + 1);
/* 317 */       assert !paramString1.equals(str);
/*     */       
/* 319 */       if (overrunStyle == OverrunStyle.ELLIPSIS || overrunStyle == OverrunStyle.WORD_ELLIPSIS) {
/* 320 */         return str + str;
/*     */       }
/*     */       
/* 323 */       return str1 + str1;
/*     */     } 
/*     */ 
/*     */     
/* 327 */     byte b1 = 0;
/* 328 */     int i = 0;
/* 329 */     byte b2 = -1;
/* 330 */     int j = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 361 */     b1 = -1;
/* 362 */     i = -1;
/* 363 */     double d4 = 0.0D;
/* 364 */     for (byte b = 0; b <= paramString1.length() - 1; b++) {
/* 365 */       char c = paramString1.charAt(b);
/*     */       
/* 367 */       d4 += computeTextWidth(paramFont, "" + c, 0.0D);
/* 368 */       if (d4 > d3) {
/*     */         break;
/*     */       }
/* 371 */       b1 = b;
/* 372 */       if (Character.isWhitespace(c)) {
/* 373 */         b2 = b1;
/*     */       }
/* 375 */       int m = paramString1.length() - 1 - b;
/* 376 */       c = paramString1.charAt(m);
/*     */       
/* 378 */       d4 += computeTextWidth(paramFont, "" + c, 0.0D);
/* 379 */       if (d4 > d3) {
/*     */         break;
/*     */       }
/* 382 */       i = m;
/* 383 */       if (Character.isWhitespace(c)) {
/* 384 */         j = i;
/*     */       }
/*     */     } 
/*     */     
/* 388 */     if (b1 < 0) {
/* 389 */       return str1;
/*     */     }
/* 391 */     if (overrunStyle == OverrunStyle.CENTER_ELLIPSIS) {
/* 392 */       if (i < 0) {
/* 393 */         return paramString1.substring(0, b1 + 1) + paramString1.substring(0, b1 + 1);
/*     */       }
/* 395 */       return paramString1.substring(0, b1 + 1) + paramString1.substring(0, b1 + 1) + str1;
/*     */     } 
/*     */     
/* 398 */     boolean bool1 = Character.isWhitespace(paramString1.charAt(b1 + 1));
/* 399 */     int k = (b2 == -1 || bool1) ? (b1 + 1) : b2;
/* 400 */     String str2 = paramString1.substring(0, k);
/* 401 */     if (i < 0) {
/* 402 */       return str2 + str2;
/*     */     }
/*     */     
/* 405 */     boolean bool2 = Character.isWhitespace(paramString1.charAt(i - 1));
/* 406 */     k = (j == -1 || bool2) ? i : (j + 1);
/* 407 */     String str3 = paramString1.substring(k);
/* 408 */     return str2 + str2 + str1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String computeClippedWrappedText(Font paramFont, String paramString1, double paramDouble1, double paramDouble2, OverrunStyle paramOverrunStyle, String paramString2, TextBoundsType paramTextBoundsType) {
/* 416 */     if (paramFont == null) {
/* 417 */       throw new IllegalArgumentException("Must specify a font");
/*     */     }
/*     */     
/* 420 */     String str1 = (paramOverrunStyle == OverrunStyle.CLIP) ? "" : paramString2;
/* 421 */     int i = str1.length();
/*     */     
/* 423 */     double d1 = computeTextWidth(paramFont, str1, 0.0D);
/* 424 */     double d2 = computeTextHeight(paramFont, str1, 0.0D, paramTextBoundsType);
/*     */     
/* 426 */     if (paramDouble1 < d1 || paramDouble2 < d2)
/*     */     {
/* 428 */       return paramString1;
/*     */     }
/*     */     
/* 431 */     helper.setText(paramString1);
/* 432 */     helper.setFont(paramFont);
/* 433 */     helper.setWrappingWidth((int)Math.ceil(paramDouble1));
/* 434 */     helper.setBoundsType(paramTextBoundsType);
/* 435 */     helper.setLineSpacing(0.0D);
/*     */     
/* 437 */     boolean bool1 = (paramOverrunStyle == OverrunStyle.LEADING_ELLIPSIS || paramOverrunStyle == OverrunStyle.LEADING_WORD_ELLIPSIS) ? true : false;
/*     */     
/* 439 */     boolean bool2 = (paramOverrunStyle == OverrunStyle.CENTER_ELLIPSIS || paramOverrunStyle == OverrunStyle.CENTER_WORD_ELLIPSIS) ? true : false;
/*     */     
/* 441 */     boolean bool3 = (!bool1 && !bool2) ? true : false;
/* 442 */     boolean bool4 = (paramOverrunStyle == OverrunStyle.WORD_ELLIPSIS || paramOverrunStyle == OverrunStyle.LEADING_WORD_ELLIPSIS || paramOverrunStyle == OverrunStyle.CENTER_WORD_ELLIPSIS) ? true : false;
/*     */ 
/*     */ 
/*     */     
/* 446 */     String str2 = paramString1;
/* 447 */     byte b = (str2 != null) ? str2.length() : 0;
/* 448 */     int j = -1;
/*     */     
/* 450 */     Point2D point2D1 = null;
/* 451 */     if (bool2)
/*     */     {
/* 453 */       point2D1 = new Point2D((paramDouble1 - d1) / 2.0D, paramDouble2 / 2.0D - helper.getBaselineOffset());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 458 */     Point2D point2D2 = new Point2D(0.0D, paramDouble2 - helper.getBaselineOffset());
/*     */     
/* 460 */     int k = helper.hitTest(point2D2).getCharIndex();
/* 461 */     if (k >= b) {
/* 462 */       helper.setBoundsType(TextBoundsType.LOGICAL);
/* 463 */       return paramString1;
/*     */     } 
/* 465 */     if (bool2) {
/* 466 */       k = helper.hitTest(point2D1).getCharIndex();
/*     */     }
/*     */     
/* 469 */     if (k > 0 && k < b) {
/*     */ 
/*     */       
/* 472 */       if (bool2 || bool3) {
/* 473 */         int m = k;
/* 474 */         if (bool2) {
/*     */           
/* 476 */           if (bool4) {
/* 477 */             int n = lastBreakCharIndex(paramString1, m + 1);
/* 478 */             if (n >= 0) {
/* 479 */               m = n + 1;
/*     */             } else {
/* 481 */               n = firstBreakCharIndex(paramString1, m);
/* 482 */               if (n >= 0) {
/* 483 */                 m = n + 1;
/*     */               }
/*     */             } 
/*     */           } 
/* 487 */           j = m + i;
/*     */         } 
/* 489 */         str2 = str2.substring(0, m) + str2.substring(0, m);
/*     */       } 
/*     */       
/* 492 */       if (bool1 || bool2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 503 */         int m = Math.max(0, b - k - 10);
/* 504 */         if (m > 0 && bool4) {
/* 505 */           int n = lastBreakCharIndex(paramString1, m + 1);
/* 506 */           if (n >= 0) {
/* 507 */             m = n + 1;
/*     */           } else {
/* 509 */             n = firstBreakCharIndex(paramString1, m);
/* 510 */             if (n >= 0) {
/* 511 */               m = n + 1;
/*     */             }
/*     */           } 
/*     */         } 
/* 515 */         if (bool2) {
/*     */           
/* 517 */           str2 = str2 + str2;
/*     */         } else {
/* 519 */           str2 = str1 + str1;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 526 */         helper.setText(str2);
/* 527 */         int m = helper.hitTest(point2D2).getCharIndex();
/* 528 */         if (bool2 && m < j) {
/*     */ 
/*     */           
/* 531 */           if (m > 0 && str2.charAt(m - 1) == '\n') {
/* 532 */             m--;
/*     */           }
/* 534 */           str2 = paramString1.substring(0, m) + paramString1.substring(0, m); break;
/*     */         } 
/* 536 */         if (m > 0 && m < str2.length()) {
/* 537 */           if (bool1) {
/* 538 */             int i1 = i + 1;
/* 539 */             if (bool4) {
/* 540 */               int i2 = firstBreakCharIndex(str2, i1);
/* 541 */               if (i2 >= 0) {
/* 542 */                 i1 = i2 + 1;
/*     */               }
/*     */             } 
/* 545 */             str2 = str1 + str1; continue;
/* 546 */           }  if (bool2) {
/* 547 */             int i1 = j + 1;
/* 548 */             if (bool4) {
/* 549 */               int i2 = firstBreakCharIndex(str2, i1);
/* 550 */               if (i2 >= 0) {
/* 551 */                 i1 = i2 + 1;
/*     */               }
/*     */             } 
/* 554 */             str2 = str2.substring(0, j) + str2.substring(0, j); continue;
/*     */           } 
/* 556 */           int n = str2.length() - i - 1;
/* 557 */           if (bool4) {
/* 558 */             int i1 = lastBreakCharIndex(str2, n);
/* 559 */             if (i1 >= 0) {
/* 560 */               n = i1;
/*     */             }
/*     */           } 
/* 563 */           str2 = str2.substring(0, n) + str2.substring(0, n);
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 571 */     helper.setWrappingWidth(DEFAULT_WRAPPING_WIDTH);
/* 572 */     helper.setLineSpacing(DEFAULT_LINE_SPACING);
/* 573 */     helper.setText(DEFAULT_TEXT);
/* 574 */     helper.setBoundsType(DEFAULT_BOUNDS_TYPE);
/* 575 */     return str2;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int firstBreakCharIndex(String paramString, int paramInt) {
/* 580 */     char[] arrayOfChar = paramString.toCharArray();
/* 581 */     for (int i = paramInt; i < arrayOfChar.length; i++) {
/* 582 */       if (isPreferredBreakCharacter(arrayOfChar[i])) {
/* 583 */         return i;
/*     */       }
/*     */     } 
/* 586 */     return -1;
/*     */   }
/*     */   
/*     */   private static int lastBreakCharIndex(String paramString, int paramInt) {
/* 590 */     char[] arrayOfChar = paramString.toCharArray();
/* 591 */     for (int i = paramInt; i >= 0; i--) {
/* 592 */       if (isPreferredBreakCharacter(arrayOfChar[i])) {
/* 593 */         return i;
/*     */       }
/*     */     } 
/* 596 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isPreferredBreakCharacter(char paramChar) {
/* 604 */     if (Character.isWhitespace(paramChar)) {
/* 605 */       return true;
/*     */     }
/* 607 */     switch (paramChar) {
/*     */       case '.':
/*     */       case ':':
/*     */       case ';':
/* 611 */         return true;
/* 612 */     }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean requiresComplexLayout(Font paramFont, String paramString) {
/* 626 */     return false;
/*     */   }
/*     */   
/*     */   static int computeStartOfWord(Font paramFont, String paramString, int paramInt) {
/* 630 */     if ("".equals(paramString) || paramInt < 0) return 0; 
/* 631 */     if (paramString.length() <= paramInt) return paramString.length();
/*     */ 
/*     */     
/* 634 */     if (Character.isWhitespace(paramString.charAt(paramInt))) {
/* 635 */       return paramInt;
/*     */     }
/* 637 */     boolean bool = requiresComplexLayout(paramFont, paramString);
/* 638 */     if (bool)
/*     */     {
/* 640 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 644 */     int i = paramInt;
/* 645 */     while (--i >= 0) {
/* 646 */       if (Character.isWhitespace(paramString.charAt(i))) {
/* 647 */         return i + 1;
/*     */       }
/*     */     } 
/* 650 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   static int computeEndOfWord(Font paramFont, String paramString, int paramInt) {
/* 655 */     if (paramString.equals("") || paramInt < 0) {
/* 656 */       return 0;
/*     */     }
/* 658 */     if (paramString.length() <= paramInt) {
/* 659 */       return paramString.length();
/*     */     }
/*     */ 
/*     */     
/* 663 */     if (Character.isWhitespace(paramString.charAt(paramInt))) {
/* 664 */       return paramInt;
/*     */     }
/* 666 */     boolean bool = requiresComplexLayout(paramFont, paramString);
/* 667 */     if (bool)
/*     */     {
/* 669 */       return paramString.length();
/*     */     }
/*     */ 
/*     */     
/* 673 */     int i = paramInt;
/* 674 */     while (++i < paramString.length()) {
/* 675 */       if (Character.isWhitespace(paramString.charAt(i))) {
/* 676 */         return i;
/*     */       }
/*     */     } 
/* 679 */     return paramString.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double boundedSize(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 688 */     return Math.min(Math.max(paramDouble1, paramDouble2), Math.max(paramDouble2, paramDouble3));
/*     */   }
/*     */   
/*     */   public static void addMnemonics(ContextMenu paramContextMenu, Scene paramScene) {
/* 692 */     addMnemonics(paramContextMenu, paramScene, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addMnemonics(ContextMenu paramContextMenu, Scene paramScene, boolean paramBoolean) {
/* 697 */     if (!PlatformUtil.isMac()) {
/*     */       
/* 699 */       ContextMenuContent contextMenuContent = (ContextMenuContent)paramContextMenu.getSkin().getNode();
/*     */ 
/*     */       
/* 702 */       for (byte b = 0; b < paramContextMenu.getItems().size(); b++) {
/* 703 */         MenuItem menuItem = paramContextMenu.getItems().get(b);
/*     */ 
/*     */ 
/*     */         
/* 707 */         if (menuItem.isMnemonicParsing()) {
/*     */           
/* 709 */           TextBinding textBinding = new TextBinding(menuItem.getText());
/* 710 */           int i = textBinding.getMnemonicIndex();
/* 711 */           if (i >= 0) {
/* 712 */             KeyCombination keyCombination = textBinding.getMnemonicKeyCombination();
/* 713 */             Mnemonic mnemonic = new Mnemonic(contextMenuContent.getLabelAt(b), keyCombination);
/* 714 */             paramScene.addMnemonic(mnemonic);
/* 715 */             NodeHelper.setShowMnemonics(contextMenuContent.getLabelAt(b), paramBoolean);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeMnemonics(ContextMenu paramContextMenu, Scene paramScene) {
/* 726 */     if (!PlatformUtil.isMac()) {
/*     */       
/* 728 */       ContextMenuContent contextMenuContent = (ContextMenuContent)paramContextMenu.getSkin().getNode();
/*     */ 
/*     */       
/* 731 */       for (byte b = 0; b < paramContextMenu.getItems().size(); b++) {
/* 732 */         MenuItem menuItem = paramContextMenu.getItems().get(b);
/*     */ 
/*     */ 
/*     */         
/* 736 */         if (menuItem.isMnemonicParsing()) {
/*     */           
/* 738 */           TextBinding textBinding = new TextBinding(menuItem.getText());
/* 739 */           int i = textBinding.getMnemonicIndex();
/* 740 */           if (i >= 0) {
/* 741 */             KeyCombination keyCombination = textBinding.getMnemonicKeyCombination();
/*     */             
/* 743 */             ObservableList<Mnemonic> observableList = paramScene.getMnemonics().get(keyCombination);
/* 744 */             if (observableList != null) {
/* 745 */               for (byte b1 = 0; b1 < observableList.size(); b1++) {
/* 746 */                 if (((Mnemonic)observableList.get(b1)).getNode() == contextMenuContent.getLabelAt(b)) {
/* 747 */                   observableList.remove(b1);
/*     */                 }
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static double computeXOffset(double paramDouble1, double paramDouble2, HPos paramHPos) {
/* 758 */     if (paramHPos == null) {
/* 759 */       return 0.0D;
/*     */     }
/*     */     
/* 762 */     switch (paramHPos) {
/*     */       case TOP:
/* 764 */         return 0.0D;
/*     */       case CENTER:
/* 766 */         return (paramDouble1 - paramDouble2) / 2.0D;
/*     */       case BOTTOM:
/* 768 */         return paramDouble1 - paramDouble2;
/*     */     } 
/* 770 */     return 0.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double computeYOffset(double paramDouble1, double paramDouble2, VPos paramVPos) {
/* 775 */     if (paramVPos == null) {
/* 776 */       return 0.0D;
/*     */     }
/*     */     
/* 779 */     switch (paramVPos) {
/*     */       case TOP:
/* 781 */         return 0.0D;
/*     */       case CENTER:
/* 783 */         return (paramDouble1 - paramDouble2) / 2.0D;
/*     */       case BOTTOM:
/* 785 */         return paramDouble1 - paramDouble2;
/*     */     } 
/* 787 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTwoLevelFocus() {
/* 801 */     return Platform.isSupported(ConditionalFeature.TWO_LEVEL_FOCUS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> void executeOnceWhenPropertyIsNonNull(final ObservableValue<T> p, final Consumer<T> consumer) {
/* 808 */     if (p == null)
/*     */       return; 
/* 810 */     T t = p.getValue();
/* 811 */     if (t != null) {
/* 812 */       consumer.accept(t);
/*     */     } else {
/* 814 */       InvalidationListener invalidationListener = new InvalidationListener() {
/*     */           public void invalidated(Observable param1Observable) {
/* 816 */             Object object = p.getValue();
/*     */             
/* 818 */             if (object != null) {
/* 819 */               p.removeListener(this);
/* 820 */               consumer.accept(object);
/*     */             } 
/*     */           }
/*     */         };
/* 824 */       p.addListener(invalidationListener);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String formatHexString(Color paramColor) {
/* 829 */     if (paramColor != null)
/* 830 */       return String.format((Locale)null, "#%02x%02x%02x", new Object[] {
/* 831 */             Long.valueOf(Math.round(paramColor.getRed() * 255.0D)), 
/* 832 */             Long.valueOf(Math.round(paramColor.getGreen() * 255.0D)), 
/* 833 */             Long.valueOf(Math.round(paramColor.getBlue() * 255.0D))
/*     */           }); 
/* 835 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static URL getResource(String paramString) {
/* 840 */     return Utils.class.getResource(paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\skin\Utils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */