/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.transformation.SortedList;
/*     */ import javafx.scene.control.TablePositionBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SelectedCellsMap<T extends TablePositionBase>
/*     */ {
/*     */   private final ObservableList<T> selectedCells;
/*     */   private final ObservableList<T> sortedSelectedCells;
/*     */   private final Map<Integer, BitSet> selectedCellBitSetMap;
/*     */   
/*     */   public SelectedCellsMap(ListChangeListener<T> paramListChangeListener) {
/*  57 */     this.selectedCells = FXCollections.observableArrayList();
/*  58 */     this.sortedSelectedCells = new SortedList<>(this.selectedCells, (paramTablePositionBase1, paramTablePositionBase2) -> {
/*     */           int i = paramTablePositionBase1.getRow() - paramTablePositionBase2.getRow();
/*     */           return (i == 0) ? (paramTablePositionBase1.getColumn() - paramTablePositionBase2.getColumn()) : i;
/*     */         });
/*  62 */     this.sortedSelectedCells.addListener(paramListChangeListener);
/*     */     
/*  64 */     this.selectedCellBitSetMap = new TreeMap<>((paramInteger1, paramInteger2) -> paramInteger1.compareTo(paramInteger2));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  70 */     return this.selectedCells.size();
/*     */   }
/*     */   
/*     */   public T get(int paramInt) {
/*  74 */     if (paramInt < 0) {
/*  75 */       return null;
/*     */     }
/*  77 */     return this.sortedSelectedCells.get(paramInt);
/*     */   }
/*     */   public void add(T paramT) {
/*     */     BitSet bitSet;
/*  81 */     int i = paramT.getRow();
/*  82 */     int j = paramT.getColumn();
/*     */ 
/*     */     
/*  85 */     boolean bool = false;
/*     */     
/*  87 */     if (!this.selectedCellBitSetMap.containsKey(Integer.valueOf(i))) {
/*  88 */       bitSet = new BitSet();
/*  89 */       this.selectedCellBitSetMap.put(Integer.valueOf(i), bitSet);
/*  90 */       bool = true;
/*     */     } else {
/*  92 */       bitSet = this.selectedCellBitSetMap.get(Integer.valueOf(i));
/*     */     } 
/*     */     
/*  95 */     boolean bool1 = isCellSelectionEnabled();
/*     */     
/*  97 */     if (bool1) {
/*  98 */       if (j >= 0) {
/*  99 */         boolean bool2 = bitSet.get(j);
/*     */         
/* 101 */         if (!bool2) {
/* 102 */           bitSet.set(j);
/*     */ 
/*     */           
/* 105 */           this.selectedCells.add(paramT);
/*     */         }
/*     */       
/*     */       }
/* 109 */       else if (!this.selectedCells.contains(paramT)) {
/* 110 */         this.selectedCells.add(paramT);
/*     */       }
/*     */     
/*     */     }
/* 114 */     else if (bool) {
/* 115 */       if (j >= 0) {
/* 116 */         bitSet.set(j);
/*     */       }
/* 118 */       this.selectedCells.add(paramT);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(Collection<T> paramCollection) {
/* 125 */     for (TablePositionBase tablePositionBase : paramCollection) {
/* 126 */       BitSet bitSet; int i = tablePositionBase.getRow();
/* 127 */       int j = tablePositionBase.getColumn();
/*     */ 
/*     */ 
/*     */       
/* 131 */       if (!this.selectedCellBitSetMap.containsKey(Integer.valueOf(i))) {
/* 132 */         bitSet = new BitSet();
/* 133 */         this.selectedCellBitSetMap.put(Integer.valueOf(i), bitSet);
/*     */       } else {
/* 135 */         bitSet = this.selectedCellBitSetMap.get(Integer.valueOf(i));
/*     */       } 
/*     */       
/* 138 */       if (j < 0) {
/*     */         continue;
/*     */       }
/*     */       
/* 142 */       bitSet.set(j);
/*     */     } 
/*     */ 
/*     */     
/* 146 */     this.selectedCells.addAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAll(Collection<T> paramCollection) {
/* 151 */     this.selectedCellBitSetMap.clear();
/* 152 */     for (TablePositionBase tablePositionBase : paramCollection) {
/* 153 */       BitSet bitSet; int i = tablePositionBase.getRow();
/* 154 */       int j = tablePositionBase.getColumn();
/*     */ 
/*     */ 
/*     */       
/* 158 */       if (!this.selectedCellBitSetMap.containsKey(Integer.valueOf(i))) {
/* 159 */         bitSet = new BitSet();
/* 160 */         this.selectedCellBitSetMap.put(Integer.valueOf(i), bitSet);
/*     */       } else {
/* 162 */         bitSet = this.selectedCellBitSetMap.get(Integer.valueOf(i));
/*     */       } 
/*     */       
/* 165 */       if (j < 0) {
/*     */         continue;
/*     */       }
/*     */       
/* 169 */       bitSet.set(j);
/*     */     } 
/*     */ 
/*     */     
/* 173 */     this.selectedCells.setAll(paramCollection);
/*     */   }
/*     */   
/*     */   public void remove(T paramT) {
/* 177 */     int i = paramT.getRow();
/* 178 */     int j = paramT.getColumn();
/*     */ 
/*     */     
/* 181 */     if (this.selectedCellBitSetMap.containsKey(Integer.valueOf(i))) {
/* 182 */       BitSet bitSet = this.selectedCellBitSetMap.get(Integer.valueOf(i));
/*     */       
/* 184 */       if (j >= 0) {
/* 185 */         bitSet.clear(j);
/*     */       }
/*     */       
/* 188 */       if (bitSet.isEmpty()) {
/* 189 */         this.selectedCellBitSetMap.remove(Integer.valueOf(i));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 194 */     this.selectedCells.remove(paramT);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 199 */     this.selectedCellBitSetMap.clear();
/*     */ 
/*     */     
/* 202 */     this.selectedCells.clear();
/*     */   }
/*     */   
/*     */   public boolean isSelected(int paramInt1, int paramInt2) {
/* 206 */     if (paramInt2 < 0) {
/* 207 */       return this.selectedCellBitSetMap.containsKey(Integer.valueOf(paramInt1));
/*     */     }
/* 209 */     return this.selectedCellBitSetMap.containsKey(Integer.valueOf(paramInt1)) ? ((BitSet)this.selectedCellBitSetMap.get(Integer.valueOf(paramInt1))).get(paramInt2) : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(T paramT) {
/* 214 */     return this.sortedSelectedCells.indexOf(paramT);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 218 */     return this.selectedCells.isEmpty();
/*     */   }
/*     */   
/*     */   public ObservableList<T> getSelectedCells() {
/* 222 */     return this.selectedCells;
/*     */   }
/*     */   
/*     */   public abstract boolean isCellSelectionEnabled();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\SelectedCellsMap.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */