/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.FocusModel;
/*     */ import javafx.scene.control.IndexedCell;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.control.SelectionMode;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TableFocusModel;
/*     */ import javafx.scene.control.TablePositionBase;
/*     */ import javafx.scene.control.TableSelectionModel;
/*     */ import javafx.scene.input.MouseButton;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TableCellBehaviorBase<S, T, TC extends TableColumnBase<S, ?>, C extends IndexedCell<T>>
/*     */   extends CellBehaviorBase<C>
/*     */ {
/*     */   public TableCellBehaviorBase(C paramC) {
/*  53 */     super(paramC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doSelect(double paramDouble1, double paramDouble2, MouseButton paramMouseButton, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/*  99 */     IndexedCell indexedCell = (IndexedCell)getNode();
/*     */ 
/*     */ 
/*     */     
/* 103 */     if (!indexedCell.contains(paramDouble1, paramDouble2))
/*     */       return; 
/* 105 */     Control control = getCellContainer();
/* 106 */     if (control == null)
/*     */       return; 
/* 108 */     int i = getItemCount();
/* 109 */     if (indexedCell.getIndex() >= i)
/*     */       return; 
/* 111 */     TableSelectionModel<S> tableSelectionModel = getSelectionModel();
/* 112 */     if (tableSelectionModel == null)
/*     */       return; 
/* 114 */     boolean bool = isSelected();
/* 115 */     int j = indexedCell.getIndex();
/* 116 */     int k = getColumn();
/* 117 */     TableColumnBase<S, T> tableColumnBase = getTableColumn();
/*     */     
/* 119 */     TableFocusModel<S, TC> tableFocusModel = getFocusModel();
/* 120 */     if (tableFocusModel == null)
/*     */       return; 
/* 122 */     TablePositionBase tablePositionBase = getFocusedCell();
/*     */ 
/*     */ 
/*     */     
/* 126 */     if (handleDisclosureNode(paramDouble1, paramDouble2)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     if (paramBoolean1) {
/* 135 */       if (!hasNonDefaultAnchor(control)) {
/* 136 */         setAnchor(control, (C)tablePositionBase, false);
/*     */       }
/*     */     } else {
/* 139 */       removeAnchor(control);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 144 */     if (paramMouseButton == MouseButton.PRIMARY || (paramMouseButton == MouseButton.SECONDARY && !bool)) {
/* 145 */       if (tableSelectionModel.getSelectionMode() == SelectionMode.SINGLE) {
/* 146 */         simpleSelect(paramMouseButton, paramInt, paramBoolean2);
/*     */       }
/* 148 */       else if (paramBoolean2) {
/* 149 */         if (bool) {
/*     */           
/* 151 */           tableSelectionModel.clearSelection(j, tableColumnBase);
/* 152 */           tableFocusModel.focus(j, (TC)tableColumnBase);
/*     */         } else {
/*     */           
/* 155 */           tableSelectionModel.select(j, tableColumnBase);
/*     */         } 
/* 157 */       } else if (paramBoolean1) {
/*     */ 
/*     */         
/* 160 */         TablePositionBase<Object> tablePositionBase1 = (TablePositionBase)getAnchor(control, (C)tablePositionBase);
/*     */         
/* 162 */         int m = tablePositionBase1.getRow();
/*     */         
/* 164 */         boolean bool1 = (m < j) ? true : false;
/*     */ 
/*     */         
/* 167 */         tableSelectionModel.clearSelection();
/*     */ 
/*     */         
/* 170 */         int n = Math.min(m, j);
/* 171 */         int i1 = Math.max(m, j);
/* 172 */         TableColumnBase<S, ?> tableColumnBase1 = (TableColumnBase<S, ?>)((tablePositionBase1.getColumn() < k) ? tablePositionBase1.getTableColumn() : tableColumnBase);
/* 173 */         TableColumnBase<S, ?> tableColumnBase2 = (TableColumnBase<S, ?>)((tablePositionBase1.getColumn() >= k) ? tablePositionBase1.getTableColumn() : tableColumnBase);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 180 */         if (bool1) {
/* 181 */           tableSelectionModel.selectRange(n, tableColumnBase1, i1, tableColumnBase2);
/*     */         } else {
/* 183 */           tableSelectionModel.selectRange(i1, tableColumnBase1, n, tableColumnBase2);
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 195 */         simpleSelect(paramMouseButton, paramInt, paramBoolean2);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void simpleSelect(MouseButton paramMouseButton, int paramInt, boolean paramBoolean) {
/* 202 */     TableSelectionModel<S> tableSelectionModel = getSelectionModel();
/* 203 */     int i = ((IndexedCell)getNode()).getIndex();
/* 204 */     TableColumnBase<S, T> tableColumnBase = getTableColumn();
/* 205 */     boolean bool = tableSelectionModel.isSelected(i, tableColumnBase);
/*     */     
/* 207 */     if (bool && paramBoolean) {
/* 208 */       tableSelectionModel.clearSelection(i, tableColumnBase);
/* 209 */       getFocusModel().focus(i, (TC)tableColumnBase);
/* 210 */       bool = false;
/*     */     } else {
/*     */       
/* 213 */       tableSelectionModel.clearAndSelect(i, tableColumnBase);
/*     */     } 
/*     */     
/* 216 */     handleClicks(paramMouseButton, paramInt, bool);
/*     */   }
/*     */   
/*     */   private int getColumn() {
/* 220 */     if (getSelectionModel().isCellSelectionEnabled()) {
/* 221 */       TableColumnBase<S, T> tableColumnBase = getTableColumn();
/* 222 */       return getVisibleLeafIndex(tableColumnBase);
/*     */     } 
/*     */     
/* 225 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isSelected() {
/* 230 */     TableSelectionModel<S> tableSelectionModel = getSelectionModel();
/* 231 */     if (tableSelectionModel == null) return false;
/*     */     
/* 233 */     if (tableSelectionModel.isCellSelectionEnabled()) {
/* 234 */       IndexedCell indexedCell = (IndexedCell)getNode();
/* 235 */       return indexedCell.isSelected();
/*     */     } 
/* 237 */     return isTableRowSelected();
/*     */   }
/*     */   
/*     */   protected abstract TableColumnBase<S, T> getTableColumn();
/*     */   
/*     */   protected abstract int getItemCount();
/*     */   
/*     */   protected abstract TableSelectionModel<S> getSelectionModel();
/*     */   
/*     */   protected abstract TableFocusModel<S, TC> getFocusModel();
/*     */   
/*     */   protected abstract TablePositionBase getFocusedCell();
/*     */   
/*     */   protected abstract boolean isTableRowSelected();
/*     */   
/*     */   protected abstract int getVisibleLeafIndex(TableColumnBase<S, T> paramTableColumnBase);
/*     */   
/*     */   protected abstract void focus(int paramInt, TableColumnBase<S, T> paramTableColumnBase);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TableCellBehaviorBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */