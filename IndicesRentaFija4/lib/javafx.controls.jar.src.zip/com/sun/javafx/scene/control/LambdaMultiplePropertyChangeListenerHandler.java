/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.function.Consumer;
/*    */ import javafx.beans.value.ChangeListener;
/*    */ import javafx.beans.value.ObservableValue;
/*    */ import javafx.beans.value.WeakChangeListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LambdaMultiplePropertyChangeListenerHandler
/*    */ {
/*    */   private final Map<ObservableValue<?>, Consumer<ObservableValue<?>>> propertyReferenceMap;
/*    */   private final ChangeListener<Object> propertyChangedListener;
/*    */   private final WeakChangeListener<Object> weakPropertyChangedListener;
/*    */   private static final Consumer<ObservableValue<?>> EMPTY_CONSUMER = paramObservableValue -> {
/*    */     
/*    */     };
/*    */   
/*    */   public LambdaMultiplePropertyChangeListenerHandler() {
/* 45 */     this.propertyReferenceMap = new HashMap<>();
/* 46 */     this.propertyChangedListener = ((paramObservableValue, paramObject1, paramObject2) -> ((Consumer<ObservableValue>)this.propertyReferenceMap.getOrDefault(paramObservableValue, EMPTY_CONSUMER)).accept(paramObservableValue));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 51 */     this.weakPropertyChangedListener = new WeakChangeListener(this.propertyChangedListener);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void registerChangeListener(ObservableValue<?> paramObservableValue, Consumer<ObservableValue<?>> paramConsumer) {
/* 61 */     if (paramConsumer == null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 66 */     if (!this.propertyReferenceMap.containsKey(paramObservableValue)) {
/* 67 */       paramObservableValue.addListener(this.weakPropertyChangedListener);
/*    */     }
/*    */     
/* 70 */     this.propertyReferenceMap.merge(paramObservableValue, paramConsumer, Consumer::andThen);
/*    */   }
/*    */ 
/*    */   
/*    */   public final Consumer<ObservableValue<?>> unregisterChangeListeners(ObservableValue<?> paramObservableValue) {
/* 75 */     paramObservableValue.removeListener(this.weakPropertyChangedListener);
/* 76 */     return this.propertyReferenceMap.remove(paramObservableValue);
/*    */   }
/*    */ 
/*    */   
/*    */   public void dispose() {
/* 81 */     for (ObservableValue<Object> observableValue : this.propertyReferenceMap.keySet()) {
/* 82 */       observableValue.removeListener(this.weakPropertyChangedListener);
/*    */     }
/* 84 */     this.propertyReferenceMap.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\LambdaMultiplePropertyChangeListenerHandler.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */