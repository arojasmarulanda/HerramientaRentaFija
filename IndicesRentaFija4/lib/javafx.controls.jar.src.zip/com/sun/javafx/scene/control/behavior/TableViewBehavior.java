/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.beans.value.WeakChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TableFocusModel;
/*     */ import javafx.scene.control.TablePosition;
/*     */ import javafx.scene.control.TablePositionBase;
/*     */ import javafx.scene.control.TableSelectionModel;
/*     */ import javafx.scene.control.TableView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableViewBehavior<T>
/*     */   extends TableViewBehaviorBase<TableView<T>, T, TableColumn<T, ?>>
/*     */ {
/*     */   private final ChangeListener<TableView.TableViewSelectionModel<T>> selectionModelListener;
/*     */   private final WeakChangeListener<TableView.TableViewSelectionModel<T>> weakSelectionModelListener;
/*     */   private TwoLevelFocusBehavior tlFocus;
/*     */   
/*     */   public TableViewBehavior(TableView<T> paramTableView) {
/*  74 */     super(paramTableView); this.selectionModelListener = ((paramObservableValue, paramTableViewSelectionModel1, paramTableViewSelectionModel2) -> { if (paramTableViewSelectionModel1 != null)
/*     */           paramTableViewSelectionModel1.getSelectedCells().removeListener(this.weakSelectedCellsListener);  if (paramTableViewSelectionModel2 != null)
/*     */           paramTableViewSelectionModel2.getSelectedCells().addListener(this.weakSelectedCellsListener); 
/*  77 */       }); this.weakSelectionModelListener = new WeakChangeListener<>(this.selectionModelListener); paramTableView.selectionModelProperty().addListener(this.weakSelectionModelListener);
/*  78 */     TableView.TableViewSelectionModel<T> tableViewSelectionModel = paramTableView.getSelectionModel();
/*  79 */     if (tableViewSelectionModel != null) {
/*  80 */       tableViewSelectionModel.getSelectedCells().addListener(this.selectedCellsListener);
/*     */     }
/*     */ 
/*     */     
/*  84 */     if (Utils.isTwoLevelFocus()) {
/*  85 */       this.tlFocus = new TwoLevelFocusBehavior(paramTableView);
/*     */     }
/*     */   }
/*     */   
/*     */   public void dispose() {
/*  90 */     if (this.tlFocus != null) this.tlFocus.dispose(); 
/*  91 */     super.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getItemCount() {
/* 102 */     return (getNode().getItems() == null) ? 0 : getNode().getItems().size();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TableFocusModel getFocusModel() {
/* 107 */     return getNode().getFocusModel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TableSelectionModel<T> getSelectionModel() {
/* 112 */     return getNode().getSelectionModel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ObservableList<TablePosition> getSelectedCells() {
/* 117 */     return getNode().getSelectionModel().getSelectedCells();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TablePositionBase getFocusedCell() {
/* 122 */     return getNode().getFocusModel().getFocusedCell();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getVisibleLeafIndex(TableColumnBase paramTableColumnBase) {
/* 127 */     return getNode().getVisibleLeafIndex((TableColumn<T, ?>)paramTableColumnBase);
/*     */   }
/*     */ 
/*     */   
/*     */   protected TableColumn<T, ?> getVisibleLeafColumn(int paramInt) {
/* 132 */     return getNode().getVisibleLeafColumn(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isControlEditable() {
/* 137 */     return getNode().isEditable();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void editCell(int paramInt, TableColumnBase paramTableColumnBase) {
/* 142 */     getNode().edit(paramInt, (TableColumn<T, ?>)paramTableColumnBase);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ObservableList<TableColumn<T, ?>> getVisibleLeafColumns() {
/* 147 */     return getNode().getVisibleLeafColumns();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TablePositionBase<TableColumn<T, ?>> getTablePosition(int paramInt, TableColumnBase<T, ?> paramTableColumnBase) {
/* 153 */     return new TablePosition<>(getNode(), paramInt, (TableColumn<T, ?>)paramTableColumnBase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void selectAllToFocus(boolean paramBoolean) {
/* 167 */     if (getNode().getEditingCell() != null)
/*     */       return; 
/* 169 */     super.selectAllToFocus(paramBoolean);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TableViewBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */