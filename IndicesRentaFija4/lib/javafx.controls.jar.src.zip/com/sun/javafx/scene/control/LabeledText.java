/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.FontCssMetaData;
/*     */ import javafx.css.SimpleStyleableObjectProperty;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.css.StyleOrigin;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.css.converter.BooleanConverter;
/*     */ import javafx.css.converter.EnumConverter;
/*     */ import javafx.css.converter.PaintConverter;
/*     */ import javafx.css.converter.SizeConverter;
/*     */ import javafx.scene.control.Labeled;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.paint.Paint;
/*     */ import javafx.scene.text.Font;
/*     */ import javafx.scene.text.Text;
/*     */ import javafx.scene.text.TextAlignment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabeledText
/*     */   extends Text
/*     */ {
/*     */   private final Labeled labeled;
/*     */   
/*     */   public LabeledText(Labeled paramLabeled) {
/*  62 */     if (paramLabeled == null) {
/*  63 */       throw new IllegalArgumentException("labeled cannot be null");
/*     */     }
/*     */     
/*  66 */     this.labeled = paramLabeled;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     setFill(this.labeled.getTextFill());
/*  72 */     setFont(this.labeled.getFont());
/*  73 */     setTextAlignment(this.labeled.getTextAlignment());
/*  74 */     setUnderline(this.labeled.isUnderline());
/*  75 */     setLineSpacing(this.labeled.getLineSpacing());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     fillProperty().bind(this.labeled.textFillProperty());
/*  82 */     fontProperty().bind(this.labeled.fontProperty());
/*     */     
/*  84 */     textAlignmentProperty().bind(this.labeled.textAlignmentProperty());
/*  85 */     underlineProperty().bind(this.labeled.underlineProperty());
/*  86 */     lineSpacingProperty().bind(this.labeled.lineSpacingProperty());
/*     */     
/*  88 */     getStyleClass().addAll(new String[] { "text" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/*  96 */     return STYLEABLES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/* 104 */     return getClassCssMetaData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   private StyleablePropertyMirror<Font> fontMirror = null;
/*     */   private StyleableProperty<Font> fontMirror() {
/* 115 */     if (this.fontMirror == null) {
/* 116 */       this.fontMirror = new StyleablePropertyMirror<>(FONT, "fontMirror", Font.getDefault(), (StyleableProperty)this.labeled.fontProperty());
/* 117 */       fontProperty().addListener(this.fontMirror);
/*     */     } 
/* 119 */     return this.fontMirror;
/*     */   }
/*     */   
/* 122 */   private static final CssMetaData<LabeledText, Font> FONT = new FontCssMetaData<LabeledText>("-fx-font", 
/* 123 */       Font.getDefault())
/*     */     {
/*     */       public boolean isSettable(LabeledText param1LabeledText)
/*     */       {
/* 127 */         return (param1LabeledText.labeled != null) ? (!param1LabeledText.labeled.fontProperty().isBound()) : true;
/*     */       }
/*     */ 
/*     */       
/*     */       public StyleableProperty<Font> getStyleableProperty(LabeledText param1LabeledText) {
/* 132 */         return param1LabeledText.fontMirror();
/*     */       }
/*     */     };
/*     */   private StyleablePropertyMirror<Paint> fillMirror;
/*     */   
/*     */   private StyleableProperty<Paint> fillMirror() {
/* 138 */     if (this.fillMirror == null) {
/* 139 */       this.fillMirror = new StyleablePropertyMirror<>(FILL, "fillMirror", Color.BLACK, (StyleableProperty)this.labeled.textFillProperty());
/* 140 */       fillProperty().addListener(this.fillMirror);
/*     */     } 
/* 142 */     return this.fillMirror;
/*     */   }
/*     */   
/* 145 */   private static final CssMetaData<LabeledText, Paint> FILL = new CssMetaData<LabeledText, Paint>("-fx-fill", 
/*     */       
/* 147 */       PaintConverter.getInstance(), Color.BLACK)
/*     */     {
/*     */       public boolean isSettable(LabeledText param1LabeledText)
/*     */       {
/* 151 */         return !param1LabeledText.labeled.textFillProperty().isBound();
/*     */       }
/*     */ 
/*     */       
/*     */       public StyleableProperty<Paint> getStyleableProperty(LabeledText param1LabeledText) {
/* 156 */         return param1LabeledText.fillMirror();
/*     */       }
/*     */     };
/*     */   private StyleablePropertyMirror<TextAlignment> textAlignmentMirror;
/*     */   
/*     */   private StyleableProperty<TextAlignment> textAlignmentMirror() {
/* 162 */     if (this.textAlignmentMirror == null) {
/* 163 */       this.textAlignmentMirror = new StyleablePropertyMirror<>(TEXT_ALIGNMENT, "textAlignmentMirror", TextAlignment.LEFT, (StyleableProperty)this.labeled.textAlignmentProperty());
/* 164 */       textAlignmentProperty().addListener(this.textAlignmentMirror);
/*     */     } 
/* 166 */     return this.textAlignmentMirror;
/*     */   }
/*     */   
/* 169 */   private static final CssMetaData<LabeledText, TextAlignment> TEXT_ALIGNMENT = new CssMetaData<LabeledText, TextAlignment>("-fx-text-alignment", (StyleConverter)new EnumConverter(TextAlignment.class), TextAlignment.LEFT)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isSettable(LabeledText param1LabeledText)
/*     */       {
/* 176 */         return !param1LabeledText.labeled.textAlignmentProperty().isBound();
/*     */       }
/*     */ 
/*     */       
/*     */       public StyleableProperty<TextAlignment> getStyleableProperty(LabeledText param1LabeledText) {
/* 181 */         return param1LabeledText.textAlignmentMirror();
/*     */       }
/*     */     };
/*     */   private StyleablePropertyMirror<Boolean> underlineMirror;
/*     */   
/*     */   private StyleableProperty<Boolean> underlineMirror() {
/* 187 */     if (this.underlineMirror == null) {
/* 188 */       this.underlineMirror = new StyleablePropertyMirror<>(UNDERLINE, "underLineMirror", Boolean.FALSE, (StyleableProperty)this.labeled.underlineProperty());
/* 189 */       underlineProperty().addListener(this.underlineMirror);
/*     */     } 
/* 191 */     return this.underlineMirror;
/*     */   }
/*     */   
/* 194 */   private static final CssMetaData<LabeledText, Boolean> UNDERLINE = new CssMetaData<LabeledText, Boolean>("-fx-underline", 
/*     */       
/* 196 */       BooleanConverter.getInstance(), Boolean.FALSE)
/*     */     {
/*     */       
/*     */       public boolean isSettable(LabeledText param1LabeledText)
/*     */       {
/* 201 */         return !param1LabeledText.labeled.underlineProperty().isBound();
/*     */       }
/*     */ 
/*     */       
/*     */       public StyleableProperty<Boolean> getStyleableProperty(LabeledText param1LabeledText) {
/* 206 */         return param1LabeledText.underlineMirror();
/*     */       }
/*     */     };
/*     */   private StyleablePropertyMirror<Number> lineSpacingMirror;
/*     */   
/*     */   private StyleableProperty<Number> lineSpacingMirror() {
/* 212 */     if (this.lineSpacingMirror == null) {
/* 213 */       this.lineSpacingMirror = new StyleablePropertyMirror<>(LINE_SPACING, "lineSpacingMirror", Double.valueOf(0.0D), (StyleableProperty)this.labeled.lineSpacingProperty());
/* 214 */       lineSpacingProperty().addListener(this.lineSpacingMirror);
/*     */     } 
/* 216 */     return this.lineSpacingMirror;
/*     */   }
/*     */   
/* 219 */   private static final CssMetaData<LabeledText, Number> LINE_SPACING = new CssMetaData<LabeledText, Number>("-fx-line-spacing", 
/*     */       
/* 221 */       SizeConverter.getInstance(), 
/* 222 */       Integer.valueOf(0))
/*     */     {
/*     */       public boolean isSettable(LabeledText param1LabeledText)
/*     */       {
/* 226 */         return !param1LabeledText.labeled.lineSpacingProperty().isBound();
/*     */       }
/*     */ 
/*     */       
/*     */       public StyleableProperty<Number> getStyleableProperty(LabeledText param1LabeledText) {
/* 231 */         return param1LabeledText.lineSpacingMirror();
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*     */   
/*     */   static {
/* 239 */     ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Text.getClassCssMetaData()); byte b;
/*     */     int i;
/* 241 */     for (b = 0, i = arrayList.size(); b < i; b++) {
/* 242 */       String str = ((CssMetaData)arrayList.get(b)).getProperty();
/*     */       
/* 244 */       if ("-fx-fill".equals(str)) {
/* 245 */         arrayList.set(b, FILL);
/* 246 */       } else if ("-fx-font".equals(str)) {
/* 247 */         arrayList.set(b, FONT);
/* 248 */       } else if ("-fx-text-alignment".equals(str)) {
/* 249 */         arrayList.set(b, TEXT_ALIGNMENT);
/* 250 */       } else if ("-fx-underline".equals(str)) {
/* 251 */         arrayList.set(b, UNDERLINE);
/* 252 */       } else if ("-fx-line-spacing".equals(str)) {
/* 253 */         arrayList.set(b, LINE_SPACING);
/*     */       } 
/*     */     } 
/*     */     
/* 257 */     STYLEABLES = Collections.unmodifiableList(arrayList);
/*     */   }
/*     */   
/*     */   private class StyleablePropertyMirror<T> extends SimpleStyleableObjectProperty<T> implements InvalidationListener { boolean applying;
/*     */     
/*     */     private StyleablePropertyMirror(CssMetaData<LabeledText, T> param1CssMetaData, String param1String, T param1T, StyleableProperty<T> param1StyleableProperty) {
/* 263 */       super((CssMetaData)param1CssMetaData, LabeledText.this, param1String, param1T);
/* 264 */       this.property = param1StyleableProperty;
/* 265 */       this.applying = false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private final StyleableProperty<T> property;
/*     */ 
/*     */     
/*     */     public void invalidated(Observable param1Observable) {
/* 274 */       if (!this.applying) {
/* 275 */         super.applyStyle(null, ((ObservableValue<T>)param1Observable).getValue());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void applyStyle(StyleOrigin param1StyleOrigin, T param1T) {
/* 282 */       this.applying = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 288 */       StyleOrigin styleOrigin = this.property.getStyleOrigin();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 297 */       if (styleOrigin == null || ((param1StyleOrigin != null) ? (styleOrigin
/*     */         
/* 299 */         .compareTo(param1StyleOrigin) <= 0) : (styleOrigin != StyleOrigin.USER))) {
/*     */         
/* 301 */         super.applyStyle(param1StyleOrigin, param1T);
/* 302 */         this.property.applyStyle(param1StyleOrigin, param1T);
/*     */       } 
/* 304 */       this.applying = false;
/*     */     }
/*     */     
/*     */     public StyleOrigin getStyleOrigin() {
/* 308 */       return this.property.getStyleOrigin();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\LabeledText.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */