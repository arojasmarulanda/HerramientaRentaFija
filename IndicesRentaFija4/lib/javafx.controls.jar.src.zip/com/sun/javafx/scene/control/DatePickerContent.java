/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.LocalDate;
/*     */ import java.time.YearMonth;
/*     */ import java.time.chrono.ChronoLocalDate;
/*     */ import java.time.chrono.Chronology;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DecimalStyle;
/*     */ import java.time.temporal.ChronoField;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.time.temporal.ValueRange;
/*     */ import java.time.temporal.WeekFields;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.beans.value.WeakChangeListener;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.Button;
/*     */ import javafx.scene.control.DateCell;
/*     */ import javafx.scene.control.DatePicker;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.Tooltip;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.BorderPane;
/*     */ import javafx.scene.layout.ColumnConstraints;
/*     */ import javafx.scene.layout.GridPane;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.layout.VBox;
/*     */ import javafx.scene.text.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatePickerContent
/*     */   extends VBox
/*     */ {
/*     */   protected DatePicker datePicker;
/*     */   private Button backMonthButton;
/*     */   private Button forwardMonthButton;
/*     */   private Button backYearButton;
/*     */   private Button forwardYearButton;
/*     */   private Label monthLabel;
/*     */   private Label yearLabel;
/*     */   protected GridPane gridPane;
/*     */   private int daysPerWeek;
/*  89 */   private List<DateCell> dayNameCells = new ArrayList<>();
/*  90 */   private List<DateCell> weekNumberCells = new ArrayList<>();
/*  91 */   protected List<DateCell> dayCells = new ArrayList<>();
/*     */   private LocalDate[] dayCellDates;
/*  93 */   private DateCell lastFocusedDayCell = null;
/*     */ 
/*     */   
/*  96 */   final DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("MMMM");
/*     */ 
/*     */   
/*  99 */   final DateTimeFormatter monthFormatterSO = DateTimeFormatter.ofPattern("LLLL");
/*     */ 
/*     */   
/* 102 */   final DateTimeFormatter yearFormatter = DateTimeFormatter.ofPattern("y");
/*     */ 
/*     */   
/* 105 */   final DateTimeFormatter yearWithEraFormatter = DateTimeFormatter.ofPattern("GGGGy");
/*     */ 
/*     */   
/* 108 */   final DateTimeFormatter weekNumberFormatter = DateTimeFormatter.ofPattern("w");
/*     */ 
/*     */   
/* 111 */   final DateTimeFormatter weekDayNameFormatter = DateTimeFormatter.ofPattern("ccc");
/*     */ 
/*     */   
/* 114 */   final DateTimeFormatter dayCellFormatter = DateTimeFormatter.ofPattern("d"); private ObjectProperty<YearMonth> displayedYearMonth;
/*     */   
/*     */   static String getString(String paramString) {
/* 117 */     return ControlResources.getString("DatePicker." + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatePickerContent(final DatePicker datePicker) {
/* 293 */     this.displayedYearMonth = new SimpleObjectProperty<>(this, "displayedYearMonth"); this.datePicker = datePicker; getStyleClass().add("date-picker-popup"); this.daysPerWeek = getDaysPerWeek(); LocalDate localDate = datePicker.getValue(); this.displayedYearMonth.set((localDate != null) ? YearMonth.from(localDate) : YearMonth.now()); this.displayedYearMonth.addListener((paramObservableValue, paramYearMonth1, paramYearMonth2) -> updateValues()); getChildren().add(createMonthYearPane()); this.gridPane = new GridPane() { protected double computePrefWidth(double param1Double) { double d1 = super.computePrefWidth(param1Double); int i = DatePickerContent.this.daysPerWeek + (datePicker.isShowWeekNumbers() ? 1 : 0); double d2 = snapSpaceX(getHgap()); double d3 = snapSpaceX(getInsets().getLeft()); double d4 = snapSpaceX(getInsets().getRight()); double d5 = d2 * (i - 1); double d6 = d1 - d3 - d4 - d5; return snapSizeX(d6 / i) * i + d3 + d4 + d5; } protected void layoutChildren() { if (getWidth() > 0.0D && getHeight() > 0.0D) super.layoutChildren();  } }
/*     */       ; this.gridPane.setFocusTraversable(true); this.gridPane.getStyleClass().add("calendar-grid"); this.gridPane.setVgap(-1.0D); this.gridPane.setHgap(-1.0D); WeakChangeListener<? super Node> weakChangeListener = new WeakChangeListener((paramObservableValue, paramNode1, paramNode2) -> { if (paramNode2 == this.gridPane) if (paramNode1 instanceof DateCell) { NodeHelper.traverse(this.gridPane, Direction.PREVIOUS); } else if (this.lastFocusedDayCell != null) { Platform.runLater(()); } else { clearFocus(); }   }); this.gridPane.sceneProperty().addListener(new WeakChangeListener<>((paramObservableValue, paramScene1, paramScene2) -> { if (paramScene1 != null) paramScene1.focusOwnerProperty().removeListener(paramWeakChangeListener);  if (paramScene2 != null) Platform.runLater(());  })); if (this.gridPane.getScene() != null) this.gridPane.getScene().focusOwnerProperty().addListener(weakChangeListener);  byte b; for (b = 0; b < this.daysPerWeek; b++) { DateCell dateCell = new DateCell(); dateCell.getStyleClass().add("day-name-cell"); this.dayNameCells.add(dateCell); }  for (b = 0; b < 6; b++) { DateCell dateCell = new DateCell(); dateCell.getStyleClass().add("week-number-cell"); this.weekNumberCells.add(dateCell); }  createDayCells(); updateGrid(); getChildren().add(this.gridPane); refresh(); addEventHandler(KeyEvent.ANY, paramKeyEvent -> { Node node = getScene().getFocusOwner(); if (node instanceof DateCell) this.lastFocusedDayCell = (DateCell)node;  if (paramKeyEvent.getEventType() == KeyEvent.KEY_PRESSED) { switch (paramKeyEvent.getCode()) { case HOME: goToDate(LocalDate.now(), true); paramKeyEvent.consume(); break;case PAGE_UP: if ((PlatformUtil.isMac() && paramKeyEvent.isMetaDown()) || (!PlatformUtil.isMac() && paramKeyEvent.isControlDown())) { if (!this.backYearButton.isDisabled()) forward(-1, ChronoUnit.YEARS, true);  } else if (!this.backMonthButton.isDisabled()) { forward(-1, ChronoUnit.MONTHS, true); }  paramKeyEvent.consume(); break;case PAGE_DOWN: if ((PlatformUtil.isMac() && paramKeyEvent.isMetaDown()) || (!PlatformUtil.isMac() && paramKeyEvent.isControlDown())) { if (!this.forwardYearButton.isDisabled())
/*     */                     forward(1, ChronoUnit.YEARS, true);  } else if (!this.forwardMonthButton.isDisabled()) { forward(1, ChronoUnit.MONTHS, true); }  paramKeyEvent.consume(); break; }  node = getScene().getFocusOwner(); if (node instanceof DateCell)
/*     */               this.lastFocusedDayCell = (DateCell)node;  }  switch (paramKeyEvent.getCode()) { case F4: case F10: case UP: case DOWN: case LEFT: case RIGHT: case TAB: return;case ESCAPE: paramDatePicker.hide(); paramKeyEvent.consume(); }  paramKeyEvent.consume(); });
/* 297 */   } public ObjectProperty<YearMonth> displayedYearMonthProperty() { return this.displayedYearMonth; }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BorderPane createMonthYearPane() {
/* 302 */     BorderPane borderPane = new BorderPane();
/* 303 */     borderPane.getStyleClass().add("month-year-pane");
/*     */ 
/*     */ 
/*     */     
/* 307 */     HBox hBox1 = new HBox();
/* 308 */     hBox1.getStyleClass().add("spinner");
/*     */     
/* 310 */     this.backMonthButton = new Button();
/* 311 */     this.backMonthButton.getStyleClass().add("left-button");
/*     */     
/* 313 */     this.forwardMonthButton = new Button();
/* 314 */     this.forwardMonthButton.getStyleClass().add("right-button");
/*     */     
/* 316 */     StackPane stackPane1 = new StackPane();
/* 317 */     stackPane1.getStyleClass().add("left-arrow");
/* 318 */     stackPane1.setMaxSize(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
/* 319 */     this.backMonthButton.setGraphic(stackPane1);
/*     */     
/* 321 */     StackPane stackPane2 = new StackPane();
/* 322 */     stackPane2.getStyleClass().add("right-arrow");
/* 323 */     stackPane2.setMaxSize(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
/* 324 */     this.forwardMonthButton.setGraphic(stackPane2);
/*     */ 
/*     */     
/* 327 */     this.backMonthButton.setOnAction(paramActionEvent -> forward(-1, ChronoUnit.MONTHS, false));
/*     */ 
/*     */ 
/*     */     
/* 331 */     this.monthLabel = new Label();
/* 332 */     this.monthLabel.getStyleClass().add("spinner-label");
/* 333 */     this.monthLabel.fontProperty().addListener((paramObservableValue, paramFont1, paramFont2) -> updateMonthLabelWidth());
/*     */ 
/*     */ 
/*     */     
/* 337 */     this.forwardMonthButton.setOnAction(paramActionEvent -> forward(1, ChronoUnit.MONTHS, false));
/*     */ 
/*     */ 
/*     */     
/* 341 */     hBox1.getChildren().addAll(new Node[] { this.backMonthButton, this.monthLabel, this.forwardMonthButton });
/* 342 */     borderPane.setLeft(hBox1);
/*     */ 
/*     */ 
/*     */     
/* 346 */     HBox hBox2 = new HBox();
/* 347 */     hBox2.getStyleClass().add("spinner");
/*     */     
/* 349 */     this.backYearButton = new Button();
/* 350 */     this.backYearButton.getStyleClass().add("left-button");
/*     */     
/* 352 */     this.forwardYearButton = new Button();
/* 353 */     this.forwardYearButton.getStyleClass().add("right-button");
/*     */     
/* 355 */     StackPane stackPane3 = new StackPane();
/* 356 */     stackPane3.getStyleClass().add("left-arrow");
/* 357 */     stackPane3.setMaxSize(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
/* 358 */     this.backYearButton.setGraphic(stackPane3);
/*     */     
/* 360 */     StackPane stackPane4 = new StackPane();
/* 361 */     stackPane4.getStyleClass().add("right-arrow");
/* 362 */     stackPane4.setMaxSize(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
/* 363 */     this.forwardYearButton.setGraphic(stackPane4);
/*     */ 
/*     */     
/* 366 */     this.backYearButton.setOnAction(paramActionEvent -> forward(-1, ChronoUnit.YEARS, false));
/*     */ 
/*     */ 
/*     */     
/* 370 */     this.yearLabel = new Label();
/* 371 */     this.yearLabel.getStyleClass().add("spinner-label");
/*     */     
/* 373 */     this.forwardYearButton.setOnAction(paramActionEvent -> forward(1, ChronoUnit.YEARS, false));
/*     */ 
/*     */ 
/*     */     
/* 377 */     hBox2.getChildren().addAll(new Node[] { this.backYearButton, this.yearLabel, this.forwardYearButton });
/* 378 */     hBox2.setFillHeight(false);
/* 379 */     borderPane.setRight(hBox2);
/*     */     
/* 381 */     return borderPane;
/*     */   }
/*     */   
/*     */   private void refresh() {
/* 385 */     updateMonthLabelWidth();
/* 386 */     updateDayNameCells();
/* 387 */     updateValues();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateValues() {
/* 393 */     updateWeeknumberDateCells();
/* 394 */     updateDayCells();
/* 395 */     updateMonthYearPane();
/*     */   }
/*     */   
/*     */   public void updateGrid() {
/* 399 */     this.gridPane.getColumnConstraints().clear();
/* 400 */     this.gridPane.getChildren().clear();
/*     */     
/* 402 */     int i = this.daysPerWeek + (this.datePicker.isShowWeekNumbers() ? 1 : 0);
/*     */     
/* 404 */     ColumnConstraints columnConstraints = new ColumnConstraints();
/* 405 */     columnConstraints.setPercentWidth(100.0D); byte b;
/* 406 */     for (b = 0; b < i; b++) {
/* 407 */       this.gridPane.getColumnConstraints().add(columnConstraints);
/*     */     }
/*     */     
/* 410 */     for (b = 0; b < this.daysPerWeek; b++) {
/* 411 */       this.gridPane.add(this.dayNameCells.get(b), b + i - this.daysPerWeek, 1);
/*     */     }
/*     */ 
/*     */     
/* 415 */     if (this.datePicker.isShowWeekNumbers()) {
/* 416 */       for (b = 0; b < 6; b++) {
/* 417 */         this.gridPane.add(this.weekNumberCells.get(b), 0, b + 2);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 422 */     for (b = 0; b < 6; b++) {
/* 423 */       for (byte b1 = 0; b1 < this.daysPerWeek; b1++) {
/* 424 */         this.gridPane.add(this.dayCells.get(b * this.daysPerWeek + b1), b1 + i - this.daysPerWeek, b + 2);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateDayNameCells() {
/* 431 */     int i = WeekFields.of(getLocale()).getFirstDayOfWeek().getValue();
/*     */ 
/*     */     
/* 434 */     LocalDate localDate = LocalDate.of(2009, 7, 12 + i);
/* 435 */     for (byte b = 0; b < this.daysPerWeek; b++) {
/* 436 */       String str = this.weekDayNameFormatter.withLocale(getLocale()).format(localDate.plus(b, ChronoUnit.DAYS));
/* 437 */       ((DateCell)this.dayNameCells.get(b)).setText(titleCaseWord(str));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updateWeeknumberDateCells() {
/* 442 */     if (this.datePicker.isShowWeekNumbers()) {
/* 443 */       Locale locale = getLocale();
/*     */ 
/*     */       
/* 446 */       LocalDate localDate = ((YearMonth)this.displayedYearMonth.get()).atDay(1);
/* 447 */       for (byte b = 0; b < 6; b++) {
/* 448 */         LocalDate localDate1 = localDate.plus(b, ChronoUnit.WEEKS);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 454 */         String str = this.weekNumberFormatter.withLocale(locale).withDecimalStyle(DecimalStyle.of(locale)).format(localDate1);
/* 455 */         ((DateCell)this.weekNumberCells.get(b)).setText(str);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updateDayCells() {
/* 461 */     Locale locale = getLocale();
/* 462 */     Chronology chronology = getPrimaryChronology();
/* 463 */     int i = determineFirstOfMonthDayOfWeek();
/* 464 */     YearMonth yearMonth1 = this.displayedYearMonth.get();
/*     */ 
/*     */     
/* 467 */     YearMonth yearMonth2 = null;
/* 468 */     YearMonth yearMonth3 = null;
/* 469 */     int j = -1;
/* 470 */     int k = -1;
/* 471 */     int m = -1;
/*     */     
/* 473 */     for (byte b = 0; b < 6 * this.daysPerWeek; b++) {
/* 474 */       DateCell dateCell = this.dayCells.get(b);
/* 475 */       dateCell.getStyleClass().setAll(new String[] { "cell", "date-cell", "day-cell" });
/* 476 */       dateCell.setDisable(false);
/* 477 */       dateCell.setStyle((String)null);
/* 478 */       dateCell.setGraphic((Node)null);
/* 479 */       dateCell.setTooltip((Tooltip)null);
/*     */       
/*     */       try {
/* 482 */         if (j == -1) {
/* 483 */           j = yearMonth1.lengthOfMonth();
/*     */         }
/* 485 */         YearMonth yearMonth = yearMonth1;
/* 486 */         int n = b - i + 1;
/*     */         
/* 488 */         if (b < i) {
/* 489 */           if (yearMonth2 == null) {
/* 490 */             yearMonth2 = yearMonth1.minusMonths(1L);
/* 491 */             k = yearMonth2.lengthOfMonth();
/*     */           } 
/* 493 */           yearMonth = yearMonth2;
/* 494 */           n = b + k - i + 1;
/* 495 */           dateCell.getStyleClass().add("previous-month");
/* 496 */         } else if (b >= i + j) {
/* 497 */           if (yearMonth3 == null) {
/* 498 */             yearMonth3 = yearMonth1.plusMonths(1L);
/* 499 */             m = yearMonth3.lengthOfMonth();
/*     */           } 
/* 501 */           yearMonth = yearMonth3;
/* 502 */           n = b - j - i + 1;
/* 503 */           dateCell.getStyleClass().add("next-month");
/*     */         } 
/* 505 */         LocalDate localDate = yearMonth.atDay(n);
/* 506 */         this.dayCellDates[b] = localDate;
/* 507 */         ChronoLocalDate chronoLocalDate = chronology.date(localDate);
/*     */         
/* 509 */         dateCell.setDisable(false);
/*     */         
/* 511 */         if (isToday(localDate)) {
/* 512 */           dateCell.getStyleClass().add("today");
/*     */         }
/*     */         
/* 515 */         if (localDate.equals(this.datePicker.getValue())) {
/* 516 */           dateCell.getStyleClass().add("selected");
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 523 */         String str = this.dayCellFormatter.withLocale(locale).withChronology(chronology).withDecimalStyle(DecimalStyle.of(locale)).format(chronoLocalDate);
/* 524 */         dateCell.setText(str);
/*     */         
/* 526 */         dateCell.updateItem(localDate, false);
/* 527 */       } catch (DateTimeException dateTimeException) {
/*     */ 
/*     */         
/* 530 */         dateCell.setText(" ");
/* 531 */         dateCell.setDisable(true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getDaysPerWeek() {
/* 537 */     ValueRange valueRange = getPrimaryChronology().range(ChronoField.DAY_OF_WEEK);
/* 538 */     return (int)(valueRange.getMaximum() - valueRange.getMinimum() + 1L);
/*     */   }
/*     */   
/*     */   private int getMonthsPerYear() {
/* 542 */     ValueRange valueRange = getPrimaryChronology().range(ChronoField.MONTH_OF_YEAR);
/* 543 */     return (int)(valueRange.getMaximum() - valueRange.getMinimum() + 1L);
/*     */   }
/*     */   
/*     */   private void updateMonthLabelWidth() {
/* 547 */     if (this.monthLabel != null) {
/* 548 */       int i = getMonthsPerYear();
/* 549 */       double d = 0.0D;
/* 550 */       for (byte b = 0; b < i; b++) {
/* 551 */         YearMonth yearMonth = ((YearMonth)this.displayedYearMonth.get()).withMonth(b + 1);
/* 552 */         String str = this.monthFormatterSO.withLocale(getLocale()).format(yearMonth);
/* 553 */         if (Character.isDigit(str.charAt(0)))
/*     */         {
/* 555 */           str = this.monthFormatter.withLocale(getLocale()).format(yearMonth);
/*     */         }
/* 557 */         d = Math.max(d, Utils.computeTextWidth(this.monthLabel.getFont(), str, 0.0D));
/*     */       } 
/* 559 */       this.monthLabel.setMinWidth(d);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void updateMonthYearPane() {
/* 564 */     YearMonth yearMonth = this.displayedYearMonth.get();
/* 565 */     String str = formatMonth(yearMonth);
/* 566 */     this.monthLabel.setText(str);
/*     */     
/* 568 */     str = formatYear(yearMonth);
/* 569 */     this.yearLabel.setText(str);
/* 570 */     double d = Utils.computeTextWidth(this.yearLabel.getFont(), str, 0.0D);
/* 571 */     if (d > this.yearLabel.getMinWidth()) {
/* 572 */       this.yearLabel.setMinWidth(d);
/*     */     }
/*     */     
/* 575 */     Chronology chronology = this.datePicker.getChronology();
/* 576 */     LocalDate localDate = yearMonth.atDay(1);
/* 577 */     this.backMonthButton.setDisable(!isValidDate(chronology, localDate, -1, ChronoUnit.DAYS));
/* 578 */     this.forwardMonthButton.setDisable(!isValidDate(chronology, localDate, 1, ChronoUnit.MONTHS));
/* 579 */     this.backYearButton.setDisable(!isValidDate(chronology, localDate, -1, ChronoUnit.YEARS));
/* 580 */     this.forwardYearButton.setDisable(!isValidDate(chronology, localDate, 1, ChronoUnit.YEARS));
/*     */   }
/*     */   
/*     */   private String formatMonth(YearMonth paramYearMonth) {
/* 584 */     Chronology chronology = getPrimaryChronology();
/*     */     try {
/* 586 */       ChronoLocalDate chronoLocalDate = chronology.date(paramYearMonth.atDay(1));
/*     */ 
/*     */ 
/*     */       
/* 590 */       String str = this.monthFormatterSO.withLocale(getLocale()).withChronology(chronology).format(chronoLocalDate);
/* 591 */       if (Character.isDigit(str.charAt(0)))
/*     */       {
/*     */ 
/*     */         
/* 595 */         str = this.monthFormatter.withLocale(getLocale()).withChronology(chronology).format(chronoLocalDate);
/*     */       }
/* 597 */       return titleCaseWord(str);
/* 598 */     } catch (DateTimeException dateTimeException) {
/*     */       
/* 600 */       return "";
/*     */     } 
/*     */   }
/*     */   
/*     */   private String formatYear(YearMonth paramYearMonth) {
/* 605 */     Chronology chronology = getPrimaryChronology();
/*     */     try {
/* 607 */       DateTimeFormatter dateTimeFormatter = this.yearFormatter;
/* 608 */       ChronoLocalDate chronoLocalDate = chronology.date(paramYearMonth.atDay(1));
/* 609 */       int i = chronoLocalDate.getEra().getValue();
/* 610 */       int j = chronology.eras().size();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 615 */       if ((j == 2 && i == 0) || j > 2) {
/* 616 */         dateTimeFormatter = this.yearWithEraFormatter;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 623 */       return dateTimeFormatter.withLocale(getLocale()).withChronology(chronology).withDecimalStyle(DecimalStyle.of(getLocale())).format(chronoLocalDate);
/*     */     
/*     */     }
/* 626 */     catch (DateTimeException dateTimeException) {
/*     */       
/* 628 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String titleCaseWord(String paramString) {
/* 634 */     if (paramString.length() > 0) {
/* 635 */       int i = paramString.codePointAt(0);
/* 636 */       if (!Character.isTitleCase(i))
/*     */       {
/* 638 */         paramString = new String(new int[] { Character.toTitleCase(i) }, 0, 1) + new String(new int[] { Character.toTitleCase(i) }, 0, 1);
/*     */       }
/*     */     } 
/* 641 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int determineFirstOfMonthDayOfWeek() {
/* 651 */     int i = WeekFields.of(getLocale()).getFirstDayOfWeek().getValue();
/* 652 */     int j = ((YearMonth)this.displayedYearMonth.get()).atDay(1).getDayOfWeek().getValue() - i;
/* 653 */     if (j < 0) {
/* 654 */       j += this.daysPerWeek;
/*     */     }
/* 656 */     return j;
/*     */   }
/*     */   
/*     */   private boolean isToday(LocalDate paramLocalDate) {
/* 660 */     return paramLocalDate.equals(LocalDate.now());
/*     */   }
/*     */   
/*     */   protected LocalDate dayCellDate(DateCell paramDateCell) {
/* 664 */     assert this.dayCellDates != null;
/* 665 */     return this.dayCellDates[this.dayCells.indexOf(paramDateCell)];
/*     */   }
/*     */ 
/*     */   
/*     */   public void goToDayCell(DateCell paramDateCell, int paramInt, ChronoUnit paramChronoUnit, boolean paramBoolean) {
/* 670 */     goToDate(dayCellDate(paramDateCell).plus(paramInt, paramChronoUnit), paramBoolean);
/*     */   }
/*     */   
/*     */   protected void forward(int paramInt, ChronoUnit paramChronoUnit, boolean paramBoolean) {
/* 674 */     YearMonth yearMonth = this.displayedYearMonth.get();
/* 675 */     DateCell dateCell = this.lastFocusedDayCell;
/* 676 */     if (dateCell == null || !dayCellDate(dateCell).getMonth().equals(yearMonth.getMonth())) {
/* 677 */       dateCell = findDayCellForDate(yearMonth.atDay(1));
/*     */     }
/* 679 */     goToDayCell(dateCell, paramInt, paramChronoUnit, paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public void goToDate(LocalDate paramLocalDate, boolean paramBoolean) {
/* 684 */     if (isValidDate(this.datePicker.getChronology(), paramLocalDate)) {
/* 685 */       this.displayedYearMonth.set(YearMonth.from(paramLocalDate));
/* 686 */       if (paramBoolean) {
/* 687 */         findDayCellForDate(paramLocalDate).requestFocus();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void selectDayCell(DateCell paramDateCell) {
/* 694 */     this.datePicker.setValue(dayCellDate(paramDateCell));
/* 695 */     this.datePicker.hide();
/*     */   }
/*     */   
/*     */   private DateCell findDayCellForDate(LocalDate paramLocalDate) {
/* 699 */     for (byte b = 0; b < this.dayCellDates.length; b++) {
/* 700 */       if (paramLocalDate.equals(this.dayCellDates[b])) {
/* 701 */         return this.dayCells.get(b);
/*     */       }
/*     */     } 
/* 704 */     return this.dayCells.get(this.dayCells.size() / 2 + 1);
/*     */   }
/*     */   
/*     */   public void clearFocus() {
/* 708 */     LocalDate localDate = this.datePicker.getValue();
/* 709 */     if (localDate == null) {
/* 710 */       localDate = LocalDate.now();
/*     */     }
/* 712 */     if (YearMonth.from(localDate).equals(this.displayedYearMonth.get())) {
/*     */       
/* 714 */       goToDate(localDate, true);
/*     */     } else {
/*     */       
/* 717 */       this.backMonthButton.requestFocus();
/*     */     } 
/*     */ 
/*     */     
/* 721 */     if (this.backMonthButton.getWidth() == 0.0D) {
/* 722 */       this.backMonthButton.requestLayout();
/* 723 */       this.forwardMonthButton.requestLayout();
/* 724 */       this.backYearButton.requestLayout();
/* 725 */       this.forwardYearButton.requestLayout();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void createDayCells() {
/* 730 */     EventHandler<? super LocalDate> eventHandler = paramMouseEvent -> {
/*     */         if (paramMouseEvent.getButton() != MouseButton.PRIMARY) {
/*     */           return;
/*     */         }
/*     */         
/*     */         DateCell dateCell = (DateCell)paramMouseEvent.getSource();
/*     */         
/*     */         selectDayCell(dateCell);
/*     */         this.lastFocusedDayCell = dateCell;
/*     */       };
/* 740 */     for (byte b = 0; b < 6; b++) {
/* 741 */       for (byte b1 = 0; b1 < this.daysPerWeek; b1++) {
/* 742 */         DateCell dateCell = createDayCell();
/* 743 */         dateCell.addEventHandler((EventType)MouseEvent.MOUSE_CLICKED, eventHandler);
/* 744 */         this.dayCells.add(dateCell);
/*     */       } 
/*     */     } 
/*     */     
/* 748 */     this.dayCellDates = new LocalDate[6 * this.daysPerWeek];
/*     */   }
/*     */   
/*     */   private DateCell createDayCell() {
/* 752 */     DateCell dateCell = null;
/* 753 */     if (this.datePicker.getDayCellFactory() != null) {
/* 754 */       dateCell = this.datePicker.getDayCellFactory().call(this.datePicker);
/*     */     }
/* 756 */     if (dateCell == null) {
/* 757 */       dateCell = new DateCell();
/*     */     }
/*     */     
/* 760 */     return dateCell;
/*     */   }
/*     */   
/*     */   protected Locale getLocale() {
/* 764 */     return Locale.getDefault(Locale.Category.FORMAT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Chronology getPrimaryChronology() {
/* 774 */     return this.datePicker.getChronology();
/*     */   }
/*     */   
/*     */   protected boolean isValidDate(Chronology paramChronology, LocalDate paramLocalDate, int paramInt, ChronoUnit paramChronoUnit) {
/* 778 */     if (paramLocalDate != null) {
/*     */       try {
/* 780 */         return isValidDate(paramChronology, paramLocalDate.plus(paramInt, paramChronoUnit));
/* 781 */       } catch (DateTimeException dateTimeException) {}
/*     */     }
/*     */     
/* 784 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isValidDate(Chronology paramChronology, LocalDate paramLocalDate) {
/*     */     try {
/* 789 */       if (paramLocalDate != null) {
/* 790 */         paramChronology.date(paramLocalDate);
/*     */       }
/* 792 */       return true;
/* 793 */     } catch (DateTimeException dateTimeException) {
/* 794 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\DatePickerContent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */