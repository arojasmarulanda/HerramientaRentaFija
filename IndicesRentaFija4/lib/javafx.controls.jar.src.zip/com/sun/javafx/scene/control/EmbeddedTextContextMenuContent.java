/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.geometry.HPos;
/*     */ import javafx.geometry.VPos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Button;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.Menu;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.TextArea;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.control.skin.TextAreaSkin;
/*     */ import javafx.scene.control.skin.TextFieldSkin;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.scene.layout.StackPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmbeddedTextContextMenuContent
/*     */   extends StackPane
/*     */ {
/*     */   private ContextMenu contextMenu;
/*     */   private StackPane pointer;
/*     */   private HBox menuBox;
/*     */   
/*     */   public EmbeddedTextContextMenuContent(ContextMenu paramContextMenu) {
/*  57 */     this.contextMenu = paramContextMenu;
/*  58 */     this.menuBox = new HBox();
/*  59 */     this.pointer = new StackPane();
/*  60 */     this.pointer.getStyleClass().add("pointer");
/*     */     
/*  62 */     updateMenuItemContainer();
/*  63 */     getChildren().addAll(new Node[] { this.pointer, this.menuBox });
/*     */     
/*  65 */     this.contextMenu.ownerNodeProperty().addListener(paramObservable -> {
/*     */           if (this.contextMenu.getOwnerNode() instanceof TextArea) {
/*     */             TextAreaSkin textAreaSkin = (TextAreaSkin)((TextArea)this.contextMenu.getOwnerNode()).getSkin();
/*     */             ((TextArea)textAreaSkin.getSkinnable()).getProperties().addListener(new InvalidationListener() {
/*     */                   public void invalidated(Observable param1Observable) {
/*  70 */                     EmbeddedTextContextMenuContent.this.requestLayout();
/*     */                   }
/*     */                 });
/*     */           } else if (this.contextMenu.getOwnerNode() instanceof TextField) {
/*     */             TextFieldSkin textFieldSkin = (TextFieldSkin)((TextField)this.contextMenu.getOwnerNode()).getSkin();
/*     */             ((TextField)textFieldSkin.getSkinnable()).getProperties().addListener(new InvalidationListener() {
/*     */                   public void invalidated(Observable param1Observable) {
/*  77 */                     EmbeddedTextContextMenuContent.this.requestLayout();
/*     */                   }
/*     */                 });
/*     */           } 
/*     */         });
/*     */     
/*  83 */     this.contextMenu.getItems().addListener(paramChange -> updateMenuItemContainer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateMenuItemContainer() {
/*  90 */     this.menuBox.getChildren().clear();
/*  91 */     for (MenuItem menuItem : this.contextMenu.getItems()) {
/*  92 */       MenuItemContainer menuItemContainer = new MenuItemContainer(menuItem);
/*  93 */       menuItemContainer.visibleProperty().bind(menuItem.visibleProperty());
/*  94 */       this.menuBox.getChildren().add(menuItemContainer);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void hideAllMenus(MenuItem paramMenuItem) {
/*  99 */     this.contextMenu.hide();
/*     */     
/*     */     Menu menu;
/* 102 */     while ((menu = paramMenuItem.getParentMenu()) != null) {
/* 103 */       menu.hide();
/* 104 */       paramMenuItem = menu;
/*     */     } 
/* 106 */     if (menu == null && paramMenuItem.getParentPopup() != null) {
/* 107 */       paramMenuItem.getParentPopup().hide();
/*     */     }
/*     */   }
/*     */   
/*     */   protected double computePrefHeight(double paramDouble) {
/* 112 */     double d1 = snapSizeY(this.pointer.prefHeight(paramDouble));
/* 113 */     double d2 = snapSizeY(this.menuBox.prefHeight(paramDouble));
/* 114 */     return snappedTopInset() + d1 + d2 + snappedBottomInset();
/*     */   }
/*     */   
/*     */   protected double computePrefWidth(double paramDouble) {
/* 118 */     double d = snapSizeX(this.menuBox.prefWidth(paramDouble));
/* 119 */     return snappedLeftInset() + d + snappedRightInset();
/*     */   }
/*     */   
/*     */   protected void layoutChildren() {
/* 123 */     double d1 = snappedLeftInset();
/* 124 */     double d2 = snappedRightInset();
/* 125 */     double d3 = snappedTopInset();
/* 126 */     double d4 = getWidth() - d1 + d2;
/* 127 */     double d5 = snapSizeX(Utils.boundedSize(this.pointer.prefWidth(-1.0D), this.pointer.minWidth(-1.0D), this.pointer.maxWidth(-1.0D)));
/* 128 */     double d6 = snapSizeY(Utils.boundedSize(this.pointer.prefWidth(-1.0D), this.pointer.minWidth(-1.0D), this.pointer.maxWidth(-1.0D)));
/* 129 */     double d7 = snapSizeX(Utils.boundedSize(this.menuBox.prefWidth(-1.0D), this.menuBox.minWidth(-1.0D), this.menuBox.maxWidth(-1.0D)));
/* 130 */     double d8 = snapSizeY(Utils.boundedSize(this.menuBox.prefWidth(-1.0D), this.menuBox.minWidth(-1.0D), this.menuBox.maxWidth(-1.0D)));
/* 131 */     double d9 = 0.0D;
/* 132 */     double d10 = 0.0D;
/* 133 */     double d11 = 0.0D;
/*     */ 
/*     */     
/* 136 */     ObservableMap<Object, Object> observableMap = null;
/* 137 */     if (this.contextMenu.getOwnerNode() instanceof TextArea) {
/* 138 */       observableMap = ((TextArea)this.contextMenu.getOwnerNode()).getProperties();
/* 139 */     } else if (this.contextMenu.getOwnerNode() instanceof TextField) {
/* 140 */       observableMap = ((TextField)this.contextMenu.getOwnerNode()).getProperties();
/*     */     } 
/*     */     
/* 143 */     if (observableMap != null) {
/* 144 */       if (observableMap.containsKey("CONTEXT_MENU_SCENE_X")) {
/* 145 */         d9 = Double.valueOf(observableMap.get("CONTEXT_MENU_SCENE_X").toString()).doubleValue();
/* 146 */         observableMap.remove("CONTEXT_MENU_SCENE_X");
/*     */       } 
/*     */       
/* 149 */       if (observableMap.containsKey("CONTEXT_MENU_SCREEN_X")) {
/* 150 */         d10 = Double.valueOf(observableMap.get("CONTEXT_MENU_SCREEN_X").toString()).doubleValue();
/* 151 */         observableMap.remove("CONTEXT_MENU_SCREEN_X");
/*     */       } 
/*     */     } 
/*     */     
/* 155 */     if (d9 == 0.0D) {
/* 156 */       d11 = d4 / 2.0D;
/*     */     } else {
/* 158 */       d11 = d10 - d9 - this.contextMenu.getX() + d9;
/*     */     } 
/*     */     
/* 161 */     this.pointer.resize(d5, d6);
/* 162 */     positionInArea(this.pointer, d11, d3, d5, d6, 0.0D, HPos.CENTER, VPos.CENTER);
/* 163 */     this.menuBox.resize(d7, d8);
/* 164 */     positionInArea(this.menuBox, d1, d3 + d6, d7, d8, 0.0D, HPos.CENTER, VPos.CENTER);
/*     */   }
/*     */   
/*     */   class MenuItemContainer extends Button {
/*     */     private MenuItem item;
/*     */     
/*     */     public MenuItemContainer(MenuItem param1MenuItem) {
/* 171 */       getStyleClass().addAll(param1MenuItem.getStyleClass());
/* 172 */       setId(param1MenuItem.getId());
/* 173 */       this.item = param1MenuItem;
/* 174 */       setText(param1MenuItem.getText());
/* 175 */       setStyle(param1MenuItem.getStyle());
/*     */ 
/*     */       
/* 178 */       textProperty().bind(param1MenuItem.textProperty());
/*     */     }
/*     */     
/*     */     public MenuItem getItem() {
/* 182 */       return this.item;
/*     */     }
/*     */     
/*     */     public void fire() {
/* 186 */       Event.fireEvent(this.item, new ActionEvent());
/* 187 */       if (!Boolean.TRUE.equals(this.item.getProperties().get("refreshMenu")))
/* 188 */         EmbeddedTextContextMenuContent.this.hideAllMenus(this.item); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\EmbeddedTextContextMenuContent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */