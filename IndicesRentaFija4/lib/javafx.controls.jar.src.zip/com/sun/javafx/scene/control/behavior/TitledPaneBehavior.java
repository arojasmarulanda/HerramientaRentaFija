/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import javafx.scene.control.TitledPane;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TitledPaneBehavior
/*     */   extends BehaviorBase<TitledPane>
/*     */ {
/*     */   private final TitledPane titledPane;
/*     */   private final InputMap<TitledPane> inputMap;
/*     */   
/*     */   public TitledPaneBehavior(TitledPane paramTitledPane) {
/*  40 */     super(paramTitledPane);
/*  41 */     this.titledPane = paramTitledPane;
/*     */ 
/*     */ 
/*     */     
/*  45 */     this.inputMap = createInputMap();
/*     */ 
/*     */     
/*  48 */     addDefaultMapping(this.inputMap, FocusTraversalInputMap.getFocusTraversalMappings());
/*     */ 
/*     */ 
/*     */     
/*  52 */     addDefaultMapping((InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, paramKeyEvent -> { if (this.titledPane.isCollapsible() && this.titledPane.isFocused()) { this.titledPane.setExpanded(!this.titledPane.isExpanded()); this.titledPane.requestFocus(); }  }), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputMap<TitledPane> getInputMap() {
/*  64 */     return this.inputMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent paramMouseEvent) {
/* 103 */     getNode().requestFocus();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expand() {
/* 111 */     this.titledPane.setExpanded(true);
/*     */   }
/*     */   
/*     */   public void collapse() {
/* 115 */     this.titledPane.setExpanded(false);
/*     */   }
/*     */   
/*     */   public void toggle() {
/* 119 */     this.titledPane.setExpanded(!this.titledPane.isExpanded());
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TitledPaneBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */