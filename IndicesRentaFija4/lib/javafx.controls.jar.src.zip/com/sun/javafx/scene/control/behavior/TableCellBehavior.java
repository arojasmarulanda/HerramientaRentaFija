/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import javafx.scene.control.Cell;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.FocusModel;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.control.TableCell;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TableFocusModel;
/*     */ import javafx.scene.control.TablePositionBase;
/*     */ import javafx.scene.control.TableSelectionModel;
/*     */ import javafx.scene.control.TableView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableCellBehavior<S, T>
/*     */   extends TableCellBehaviorBase<S, T, TableColumn<S, ?>, TableCell<S, T>>
/*     */ {
/*     */   public TableCellBehavior(TableCell<S, T> paramTableCell) {
/*  47 */     super(paramTableCell);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TableView<S> getCellContainer() {
/*  60 */     return getNode().getTableView();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TableColumn<S, T> getTableColumn() {
/*  65 */     return getNode().getTableColumn();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getItemCount() {
/*  70 */     return getCellContainer().getItems().size();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TableView.TableViewSelectionModel<S> getSelectionModel() {
/*  75 */     return getCellContainer().getSelectionModel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TableView.TableViewFocusModel<S> getFocusModel() {
/*  80 */     return getCellContainer().getFocusModel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TablePositionBase getFocusedCell() {
/*  85 */     return getCellContainer().getFocusModel().getFocusedCell();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isTableRowSelected() {
/*  90 */     return getNode().getTableRow().isSelected();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getVisibleLeafIndex(TableColumnBase paramTableColumnBase) {
/*  95 */     return getCellContainer().getVisibleLeafIndex((TableColumn<S, ?>)paramTableColumnBase);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void focus(int paramInt, TableColumnBase paramTableColumnBase) {
/* 100 */     getFocusModel().focus(paramInt, (TableColumn<S, ?>)paramTableColumnBase);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void edit(TableCell<S, T> paramTableCell) {
/* 105 */     if (paramTableCell == null) {
/* 106 */       getCellContainer().edit(-1, null);
/*     */     } else {
/* 108 */       getCellContainer().edit(paramTableCell.getIndex(), paramTableCell.getTableColumn());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TableCellBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */