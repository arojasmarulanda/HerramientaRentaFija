/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import javafx.scene.input.KeyCombination;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextBinding
/*     */ {
/*  67 */   private String MNEMONIC_SYMBOL = "_";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private String text = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/*  80 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private String mnemonic = null;
/*  87 */   private KeyCombination mnemonicKeyCombination = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMnemonic() {
/*  97 */     return this.mnemonic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyCombination getMnemonicKeyCombination() {
/* 109 */     if (this.mnemonic != null && this.mnemonicKeyCombination == null) {
/* 110 */       this.mnemonicKeyCombination = new MnemonicKeyCombination(this.mnemonic);
/*     */     }
/* 112 */     return this.mnemonicKeyCombination;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private int mnemonicIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMnemonicIndex() {
/* 131 */     return this.mnemonicIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   private String extendedMnemonicText = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExtendedMnemonicText() {
/* 147 */     return this.extendedMnemonicText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextBinding(String paramString) {
/* 156 */     parseAndSplit(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseAndSplit(String paramString) {
/* 163 */     if (paramString == null || paramString.length() == 0) {
/* 164 */       this.text = paramString;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 171 */     StringBuffer stringBuffer = new StringBuffer(paramString);
/*     */ 
/*     */ 
/*     */     
/* 175 */     int i = stringBuffer.indexOf(this.MNEMONIC_SYMBOL);
/* 176 */     while (i >= 0 && i < stringBuffer.length() - 1) {
/*     */       
/* 178 */       if (this.MNEMONIC_SYMBOL.equals(stringBuffer.substring(i + 1, i + 2)))
/* 179 */       { stringBuffer.delete(i, i + 1); }
/* 180 */       else { if (stringBuffer.charAt(i + 1) != '(' || i == stringBuffer
/* 181 */           .length() - 2) {
/* 182 */           this.mnemonic = stringBuffer.substring(i + 1, i + 2);
/* 183 */           if (this.mnemonic != null) {
/* 184 */             this.mnemonicIndex = i;
/*     */           }
/* 186 */           stringBuffer.delete(i, i + 1);
/*     */           break;
/*     */         } 
/* 189 */         int j = stringBuffer.indexOf(")", i + 3);
/* 190 */         if (j == -1) {
/* 191 */           this.mnemonic = stringBuffer.substring(i + 1, i + 2);
/* 192 */           if (this.mnemonic != null) {
/* 193 */             this.mnemonicIndex = i;
/*     */           }
/* 195 */           stringBuffer.delete(i, i + 1); break;
/*     */         } 
/* 197 */         if (j == i + 3) {
/* 198 */           this.mnemonic = stringBuffer.substring(i + 2, i + 3);
/* 199 */           this.extendedMnemonicText = stringBuffer.substring(i + 1, i + 4);
/* 200 */           stringBuffer.delete(i, j + 3);
/*     */           break;
/*     */         }  }
/*     */       
/* 204 */       i = stringBuffer.indexOf(this.MNEMONIC_SYMBOL, i + 1);
/*     */     } 
/* 206 */     this.text = stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MnemonicKeyCombination
/*     */     extends KeyCombination
/*     */   {
/* 214 */     private String character = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MnemonicKeyCombination(String param1String) {
/* 223 */       super(new KeyCombination.Modifier[] { PlatformUtil.isMac() ? 
/* 224 */             KeyCombination.META_DOWN : 
/* 225 */             KeyCombination.ALT_DOWN });
/* 226 */       this.character = param1String;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getCharacter() {
/* 234 */       return this.character;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean match(KeyEvent param1KeyEvent) {
/* 246 */       String str = param1KeyEvent.getText();
/* 247 */       return (str != null && 
/* 248 */         !str.isEmpty() && str
/* 249 */         .equalsIgnoreCase(getCharacter()) && super
/* 250 */         .match(param1KeyEvent));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 271 */       StringBuilder stringBuilder = new StringBuilder();
/*     */       
/* 273 */       stringBuilder.append(super.getName());
/* 274 */       if (stringBuilder.length() > 0) {
/* 275 */         stringBuilder.append("+");
/*     */       }
/*     */       
/* 278 */       return stringBuilder.append('\'').append(this.character.replace("'", "\\'"))
/* 279 */         .append('\'').toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 290 */       if (this == param1Object) {
/* 291 */         return true;
/*     */       }
/*     */       
/* 294 */       if (!(param1Object instanceof MnemonicKeyCombination)) {
/* 295 */         return false;
/*     */       }
/*     */       
/* 298 */       return (this.character.equals(((MnemonicKeyCombination)param1Object).getCharacter()) && super
/* 299 */         .equals(param1Object));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 308 */       return 23 * super.hashCode() + this.character.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TextBinding.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */