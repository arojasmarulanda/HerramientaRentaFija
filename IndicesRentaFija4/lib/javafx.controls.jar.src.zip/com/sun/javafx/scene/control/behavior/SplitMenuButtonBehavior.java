/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*    */ import javafx.scene.control.SplitMenuButton;
/*    */ import javafx.scene.input.KeyCode;
/*    */ import javafx.scene.input.KeyEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SplitMenuButtonBehavior
/*    */   extends MenuButtonBehaviorBase<SplitMenuButton>
/*    */ {
/*    */   public SplitMenuButtonBehavior(SplitMenuButton paramSplitMenuButton) {
/* 53 */     super(paramSplitMenuButton);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 59 */     addDefaultMapping((InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, KeyEvent.KEY_PRESSED, this::keyPressed) });
/* 60 */     addDefaultMapping((InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, KeyEvent.KEY_RELEASED, this::keyReleased) });
/* 61 */     addDefaultMapping((InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ENTER, KeyEvent.KEY_PRESSED, this::keyPressed) });
/* 62 */     addDefaultMapping((InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ENTER, KeyEvent.KEY_RELEASED, this::keyReleased) });
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\SplitMenuButtonBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */