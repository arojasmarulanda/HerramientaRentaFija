/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.Affine3D;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.text.HitInfo;
/*     */ 
/*     */ public class TextFieldBehavior extends TextInputControlBehavior<TextField> {
/*     */   private TextFieldSkin skin;
/*     */   private TwoLevelFocusBehavior tlFocus;
/*     */   private ChangeListener<Scene> sceneListener;
/*     */   private ChangeListener<Node> focusOwnerListener;
/*     */   private boolean focusGainedByMouseClick;
/*     */   private boolean shiftDown;
/*     */   private boolean deferClick;
/*     */   
/*     */   public void dispose() {
/*     */     if (this.tlFocus != null)
/*     */       this.tlFocus.dispose(); 
/*     */     super.dispose();
/*     */   }
/*     */   
/*     */   private void handleFocusChange() {
/*     */     TextField textField = getNode();
/*     */     if (textField.isFocused()) {
/*     */       if (PlatformUtil.isIOS()) {
/*     */         TextInputTypes textInputTypes = TextInputTypes.TEXT_FIELD;
/*     */         if (textField.getClass().equals(PasswordField.class)) {
/*     */           textInputTypes = TextInputTypes.PASSWORD_FIELD;
/*     */         } else if (textField.getParent().getClass().equals(ComboBox.class)) {
/*     */           textInputTypes = TextInputTypes.EDITABLE_COMBO;
/*     */         } 
/*     */         Bounds bounds = textField.getBoundsInParent();
/*     */         double d1 = bounds.getWidth();
/*     */         double d2 = bounds.getHeight();
/*     */         Affine3D affine3D = calculateNodeToSceneTransform(textField);
/*     */         String str = textField.getText();
/*     */         WindowHelper.getPeer(textField.getScene().getWindow()).requestInput(str, textInputTypes.ordinal(), d1, d2, affine3D.getMxx(), affine3D.getMxy(), affine3D.getMxz(), affine3D.getMxt(), affine3D.getMyx(), affine3D.getMyy(), affine3D.getMyz(), affine3D.getMyt(), affine3D.getMzx(), affine3D.getMzy(), affine3D.getMzz(), affine3D.getMzt());
/*     */       } 
/*     */       if (!this.focusGainedByMouseClick)
/*     */         setCaretAnimating(true); 
/*     */     } else {
/*     */       if (PlatformUtil.isIOS() && textField.getScene() != null)
/*     */         WindowHelper.getPeer(textField.getScene().getWindow()).releaseInput(); 
/*     */       this.focusGainedByMouseClick = false;
/*     */       setCaretAnimating(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   static Affine3D calculateNodeToSceneTransform(Node paramNode) {
/*     */     Affine3D affine3D = new Affine3D();
/*     */     do {
/*     */       affine3D.preConcatenate(NodeHelper.getLeafTransform(paramNode));
/*     */       paramNode = paramNode.getParent();
/*     */     } while (paramNode != null);
/*     */     return affine3D;
/*     */   }
/*     */   
/*     */   public void setTextFieldSkin(TextFieldSkin paramTextFieldSkin) {
/*     */     this.skin = paramTextFieldSkin;
/*     */   }
/*     */   
/*  66 */   public TextFieldBehavior(TextField paramTextField) { super(paramTextField);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     this.focusGainedByMouseClick = false;
/* 240 */     this.shiftDown = false;
/* 241 */     this.deferClick = false; if (Properties.IS_TOUCH_SUPPORTED) this.contextMenu.getStyleClass().add("text-input-context-menu");  handleFocusChange(); paramTextField.focusedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> handleFocusChange()); this.focusOwnerListener = ((paramObservableValue, paramNode1, paramNode2) -> { if (paramNode2 == paramTextField) { if (!this.focusGainedByMouseClick) paramTextField.selectRange(paramTextField.getLength(), 0);  } else { paramTextField.selectRange(0, 0); }  }); WeakChangeListener<Node> weakChangeListener = new WeakChangeListener<>(this.focusOwnerListener); this.sceneListener = ((paramObservableValue, paramScene1, paramScene2) -> { if (paramScene1 != null) paramScene1.focusOwnerProperty().removeListener(paramWeakChangeListener);  if (paramScene2 != null) paramScene2.focusOwnerProperty().addListener(paramWeakChangeListener);  }); paramTextField.sceneProperty().addListener(new WeakChangeListener<>(this.sceneListener)); if (paramTextField.getScene() != null) paramTextField.getScene().focusOwnerProperty().addListener(weakChangeListener);  if (Utils.isTwoLevelFocus())
/*     */       this.tlFocus = new TwoLevelFocusBehavior(paramTextField);  }
/*     */   protected void fire(KeyEvent paramKeyEvent) { TextField textField = getNode(); EventHandler<ActionEvent> eventHandler = textField.getOnAction(); ActionEvent actionEvent = new ActionEvent(textField, null); textField.commitValue(); textField.fireEvent(actionEvent); if (eventHandler == null && !actionEvent.isConsumed())
/* 244 */       forwardToParent(paramKeyEvent);  } public void mousePressed(MouseEvent paramMouseEvent) { TextField textField = getNode();
/*     */     
/* 246 */     if (!textField.isDisabled()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 251 */       if (!textField.isFocused()) {
/* 252 */         this.focusGainedByMouseClick = true;
/* 253 */         textField.requestFocus();
/*     */       } 
/*     */ 
/*     */       
/* 257 */       setCaretAnimating(false);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 262 */       if (paramMouseEvent.isPrimaryButtonDown() && !paramMouseEvent.isMiddleButtonDown() && !paramMouseEvent.isSecondaryButtonDown()) {
/* 263 */         HitInfo hitInfo = this.skin.getIndex(paramMouseEvent.getX(), paramMouseEvent.getY());
/* 264 */         int i = hitInfo.getInsertionIndex();
/* 265 */         int j = textField.getAnchor();
/* 266 */         int k = textField.getCaretPosition();
/* 267 */         if (paramMouseEvent.getClickCount() < 2 && (Properties.IS_TOUCH_SUPPORTED || (j != k && ((i > j && i < k) || (i < j && i > k))))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 277 */           this.deferClick = true;
/*     */ 
/*     */         
/*     */         }
/* 281 */         else if (!paramMouseEvent.isControlDown() && !paramMouseEvent.isAltDown() && !paramMouseEvent.isShiftDown() && !paramMouseEvent.isMetaDown()) {
/* 282 */           switch (paramMouseEvent.getClickCount()) { case 1:
/* 283 */               mouseSingleClick(hitInfo); break;
/* 284 */             case 2: mouseDoubleClick(hitInfo); break;
/* 285 */             case 3: mouseTripleClick(hitInfo);
/*     */               break; }
/*     */         
/* 288 */         } else if (paramMouseEvent.isShiftDown() && !paramMouseEvent.isControlDown() && !paramMouseEvent.isAltDown() && !paramMouseEvent.isMetaDown() && paramMouseEvent.getClickCount() == 1) {
/*     */           
/* 290 */           this.shiftDown = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 297 */           if (PlatformUtil.isMac()) {
/* 298 */             textField.extendSelection(i);
/*     */           } else {
/* 300 */             this.skin.positionCaret(hitInfo, true);
/*     */           } 
/*     */         } 
/* 303 */         this.skin.setForwardBias(hitInfo.isLeading());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 308 */     if (this.contextMenu.isShowing())
/* 309 */       this.contextMenu.hide();  } protected void cancelEdit(KeyEvent paramKeyEvent) { TextField textField = getNode(); if (textField.getTextFormatter() != null) { textField.cancelEdit(); paramKeyEvent.consume(); } else { super.cancelEdit(paramKeyEvent); }  } protected void deleteChar(boolean paramBoolean) { this.skin.deleteChar(paramBoolean); }
/*     */   protected void replaceText(int paramInt1, int paramInt2, String paramString) { this.skin.setForwardBias(true); this.skin.replaceText(paramInt1, paramInt2, paramString); }
/*     */   protected void deleteFromLineStart() { TextField textField = getNode(); int i = textField.getCaretPosition(); if (i > 0) replaceText(0, i, "");  }
/*     */   protected void setCaretAnimating(boolean paramBoolean) { if (this.skin != null) this.skin.setCaretAnimating(paramBoolean);  }
/*     */   private void beep() {}
/* 314 */   public void mouseDragged(MouseEvent paramMouseEvent) { TextField textField = getNode();
/*     */ 
/*     */     
/* 317 */     if (!textField.isDisabled() && !this.deferClick && 
/* 318 */       paramMouseEvent.isPrimaryButtonDown() && !paramMouseEvent.isMiddleButtonDown() && !paramMouseEvent.isSecondaryButtonDown() && 
/* 319 */       !paramMouseEvent.isControlDown() && !paramMouseEvent.isAltDown() && !paramMouseEvent.isShiftDown() && !paramMouseEvent.isMetaDown()) {
/* 320 */       this.skin.positionCaret(this.skin.getIndex(paramMouseEvent.getX(), paramMouseEvent.getY()), true);
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent paramMouseEvent) {
/* 327 */     TextField textField = getNode();
/*     */ 
/*     */     
/* 330 */     if (!textField.isDisabled()) {
/* 331 */       setCaretAnimating(false);
/* 332 */       if (this.deferClick) {
/* 333 */         this.deferClick = false;
/* 334 */         this.skin.positionCaret(this.skin.getIndex(paramMouseEvent.getX(), paramMouseEvent.getY()), this.shiftDown);
/* 335 */         this.shiftDown = false;
/*     */       } 
/* 337 */       setCaretAnimating(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void contextMenuRequested(ContextMenuEvent paramContextMenuEvent) {
/* 342 */     TextField textField = getNode();
/*     */     
/* 344 */     if (this.contextMenu.isShowing()) {
/* 345 */       this.contextMenu.hide();
/* 346 */     } else if (textField.getContextMenu() == null && textField
/* 347 */       .getOnContextMenuRequested() == null) {
/* 348 */       double d1 = paramContextMenuEvent.getScreenX();
/* 349 */       double d2 = paramContextMenuEvent.getScreenY();
/* 350 */       double d3 = paramContextMenuEvent.getSceneX();
/*     */       
/* 352 */       if (Properties.IS_TOUCH_SUPPORTED) {
/*     */         Point2D point2D;
/* 354 */         if (textField.getSelection().getLength() == 0) {
/* 355 */           this.skin.positionCaret(this.skin.getIndex(paramContextMenuEvent.getX(), paramContextMenuEvent.getY()), false);
/* 356 */           point2D = this.skin.getMenuPosition();
/*     */         } else {
/* 358 */           point2D = this.skin.getMenuPosition();
/* 359 */           if (point2D != null && (point2D.getX() <= 0.0D || point2D.getY() <= 0.0D)) {
/* 360 */             this.skin.positionCaret(this.skin.getIndex(paramContextMenuEvent.getX(), paramContextMenuEvent.getY()), false);
/* 361 */             point2D = this.skin.getMenuPosition();
/*     */           } 
/*     */         } 
/*     */         
/* 365 */         if (point2D != null) {
/* 366 */           Point2D point2D1 = getNode().localToScene(point2D);
/* 367 */           Scene scene = getNode().getScene();
/* 368 */           Window window = scene.getWindow();
/*     */           
/* 370 */           Point2D point2D2 = new Point2D(window.getX() + scene.getX() + point2D1.getX(), window.getY() + scene.getY() + point2D1.getY());
/* 371 */           d1 = point2D2.getX();
/* 372 */           d3 = point2D1.getX();
/* 373 */           d2 = point2D2.getY();
/*     */         } 
/*     */       } 
/*     */       
/* 377 */       populateContextMenu();
/* 378 */       double d4 = this.contextMenu.prefWidth(-1.0D);
/* 379 */       double d5 = d1 - (Properties.IS_TOUCH_SUPPORTED ? (d4 / 2.0D) : 0.0D);
/* 380 */       Screen screen = Utils.getScreenForPoint(d1, 0.0D);
/* 381 */       Rectangle2D rectangle2D = screen.getBounds();
/*     */       
/* 383 */       if (d5 < rectangle2D.getMinX()) {
/* 384 */         getNode().getProperties().put("CONTEXT_MENU_SCREEN_X", Double.valueOf(d1));
/* 385 */         getNode().getProperties().put("CONTEXT_MENU_SCENE_X", Double.valueOf(d3));
/* 386 */         this.contextMenu.show(getNode(), rectangle2D.getMinX(), d2);
/* 387 */       } else if (d1 + d4 > rectangle2D.getMaxX()) {
/* 388 */         double d = d4 - rectangle2D.getMaxX() - d1;
/* 389 */         getNode().getProperties().put("CONTEXT_MENU_SCREEN_X", Double.valueOf(d1));
/* 390 */         getNode().getProperties().put("CONTEXT_MENU_SCENE_X", Double.valueOf(d3));
/* 391 */         this.contextMenu.show(getNode(), d1 - d, d2);
/*     */       } else {
/* 393 */         getNode().getProperties().put("CONTEXT_MENU_SCREEN_X", Integer.valueOf(0));
/* 394 */         getNode().getProperties().put("CONTEXT_MENU_SCENE_X", Integer.valueOf(0));
/* 395 */         this.contextMenu.show(getNode(), d5, d2);
/*     */       } 
/*     */     } 
/*     */     
/* 399 */     paramContextMenuEvent.consume();
/*     */   }
/*     */   
/*     */   protected void mouseSingleClick(HitInfo paramHitInfo) {
/* 403 */     this.skin.positionCaret(paramHitInfo, false);
/*     */   }
/*     */   
/*     */   protected void mouseDoubleClick(HitInfo paramHitInfo) {
/* 407 */     TextField textField = getNode();
/* 408 */     textField.previousWord();
/* 409 */     if (PlatformUtil.isWindows()) {
/* 410 */       textField.selectNextWord();
/*     */     } else {
/* 412 */       textField.selectEndOfNextWord();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void mouseTripleClick(HitInfo paramHitInfo) {
/* 417 */     getNode().selectAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum TextInputTypes
/*     */   {
/* 426 */     TEXT_FIELD,
/* 427 */     PASSWORD_FIELD,
/* 428 */     EDITABLE_COMBO,
/* 429 */     TEXT_AREA;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TextFieldBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */