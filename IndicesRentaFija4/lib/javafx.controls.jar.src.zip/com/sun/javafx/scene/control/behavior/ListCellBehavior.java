/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import javafx.scene.control.Cell;
/*    */ import javafx.scene.control.Control;
/*    */ import javafx.scene.control.FocusModel;
/*    */ import javafx.scene.control.ListCell;
/*    */ import javafx.scene.control.ListView;
/*    */ import javafx.scene.control.MultipleSelectionModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ListCellBehavior<T>
/*    */   extends CellBehaviorBase<ListCell<T>>
/*    */ {
/*    */   public ListCellBehavior(ListCell<T> paramListCell) {
/* 42 */     super(paramListCell);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MultipleSelectionModel<T> getSelectionModel() {
/* 54 */     return getCellContainer().getSelectionModel();
/*    */   }
/*    */   
/*    */   protected FocusModel<T> getFocusModel() {
/* 58 */     return getCellContainer().getFocusModel();
/*    */   }
/*    */   
/*    */   protected ListView<T> getCellContainer() {
/* 62 */     return getNode().getListView();
/*    */   }
/*    */   
/*    */   protected void edit(ListCell<T> paramListCell) {
/* 66 */     boolean bool = (paramListCell == null) ? true : paramListCell.getIndex();
/* 67 */     getCellContainer().edit(bool);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ListCellBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */