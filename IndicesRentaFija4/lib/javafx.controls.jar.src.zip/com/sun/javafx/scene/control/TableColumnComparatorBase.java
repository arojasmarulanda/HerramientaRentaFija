/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TableColumnComparatorBase<S, T>
/*     */   implements Comparator<S>
/*     */ {
/*     */   private final List<? extends TableColumnBase> columns;
/*     */   
/*     */   public TableColumnComparatorBase(TableColumnBase<S, T>... paramVarArgs) {
/*  43 */     this(Arrays.asList((TableColumnBase[])paramVarArgs));
/*     */   }
/*     */   
/*     */   public TableColumnComparatorBase(List<? extends TableColumnBase> paramList) {
/*  47 */     this.columns = new ArrayList<>(paramList);
/*     */   }
/*     */   
/*     */   public List<? extends TableColumnBase> getColumns() {
/*  51 */     return Collections.unmodifiableList(this.columns);
/*     */   }
/*     */   
/*     */   public int compare(S paramS1, S paramS2) {
/*  55 */     for (TableColumnBase<S, T> tableColumnBase : this.columns) {
/*  56 */       if (!isSortable(tableColumnBase))
/*     */         continue; 
/*  58 */       T t1 = tableColumnBase.getCellData(paramS1);
/*  59 */       T t2 = tableColumnBase.getCellData(paramS2);
/*     */       
/*  61 */       int i = doCompare(tableColumnBase, t1, t2);
/*     */       
/*  63 */       if (i != 0) {
/*  64 */         return i;
/*     */       }
/*     */     } 
/*  67 */     return 0;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  71 */     int i = 7;
/*  72 */     i = 59 * i + ((this.columns != null) ? this.columns.hashCode() : 0);
/*  73 */     return i;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  77 */     if (paramObject == null) {
/*  78 */       return false;
/*     */     }
/*  80 */     if (getClass() != paramObject.getClass()) {
/*  81 */       return false;
/*     */     }
/*  83 */     TableColumnComparatorBase tableColumnComparatorBase = (TableColumnComparatorBase)paramObject;
/*  84 */     if (this.columns != tableColumnComparatorBase.columns && (this.columns == null || !this.columns.equals(tableColumnComparatorBase.columns))) {
/*  85 */       return false;
/*     */     }
/*  87 */     return true;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  91 */     return "TableColumnComparatorBase [ columns: " + getColumns() + "] ";
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract boolean isSortable(TableColumnBase<S, T> paramTableColumnBase);
/*     */ 
/*     */   
/*     */   public abstract int doCompare(TableColumnBase<S, T> paramTableColumnBase, T paramT1, T paramT2);
/*     */   
/*     */   public static final class TableColumnComparator<S, T>
/*     */     extends TableColumnComparatorBase<S, T>
/*     */   {
/*     */     public TableColumnComparator(TableColumn<S, T>... param1VarArgs) {
/* 104 */       super(Arrays.asList((TableColumnBase[])param1VarArgs));
/*     */     }
/*     */     
/*     */     public TableColumnComparator(List<TableColumn<S, T>> param1List) {
/* 108 */       super((List)param1List);
/*     */     }
/*     */     
/*     */     public boolean isSortable(TableColumnBase<S, T> param1TableColumnBase) {
/* 112 */       TableColumn tableColumn = (TableColumn)param1TableColumnBase;
/* 113 */       return (tableColumn.getSortType() != null && tableColumn.isSortable());
/*     */     }
/*     */     
/*     */     public int doCompare(TableColumnBase<S, T> param1TableColumnBase, T param1T1, T param1T2) {
/* 117 */       TableColumn tableColumn = (TableColumn)param1TableColumnBase;
/* 118 */       Comparator<T> comparator = tableColumn.getComparator();
/* 119 */       switch (tableColumn.getSortType()) { case ASCENDING:
/* 120 */           return comparator.compare(param1T1, param1T2);
/* 121 */         case DESCENDING: return comparator.compare(param1T2, param1T1); }
/*     */       
/* 123 */       return 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class TreeTableColumnComparator<S, T>
/*     */     extends TableColumnComparatorBase<S, T>
/*     */   {
/*     */     public TreeTableColumnComparator(TreeTableColumn<S, T>... param1VarArgs) {
/* 131 */       super(Arrays.asList((TableColumnBase[])param1VarArgs));
/*     */     }
/*     */     
/*     */     public TreeTableColumnComparator(List<TreeTableColumn<S, T>> param1List) {
/* 135 */       super((List)param1List);
/*     */     }
/*     */     
/*     */     public boolean isSortable(TableColumnBase<S, T> param1TableColumnBase) {
/* 139 */       TreeTableColumn treeTableColumn = (TreeTableColumn)param1TableColumnBase;
/* 140 */       return (treeTableColumn.getSortType() != null && treeTableColumn.isSortable());
/*     */     }
/*     */     
/*     */     public int doCompare(TableColumnBase<S, T> param1TableColumnBase, T param1T1, T param1T2) {
/* 144 */       TreeTableColumn treeTableColumn = (TreeTableColumn)param1TableColumnBase;
/* 145 */       Comparator<T> comparator = treeTableColumn.getComparator();
/* 146 */       switch (treeTableColumn.getSortType()) { case ASCENDING:
/* 147 */           return comparator.compare(param1T1, param1T2);
/* 148 */         case DESCENDING: return comparator.compare(param1T2, param1T1); }
/*     */       
/* 150 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\TableColumnComparatorBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */