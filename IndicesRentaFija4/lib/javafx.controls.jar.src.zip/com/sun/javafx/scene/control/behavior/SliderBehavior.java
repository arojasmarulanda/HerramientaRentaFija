/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.event.Event;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.control.Slider;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SliderBehavior
/*     */   extends BehaviorBase<Slider>
/*     */ {
/*     */   private final InputMap<Slider> sliderInputMap;
/*     */   private TwoLevelFocusBehavior tlFocus;
/*     */   
/*     */   public SliderBehavior(Slider paramSlider) {
/*  44 */     super(paramSlider);
/*     */ 
/*     */ 
/*     */     
/*  48 */     this.sliderInputMap = createInputMap();
/*     */ 
/*     */     
/*  51 */     addDefaultMapping(this.sliderInputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.HOME, KeyEvent.KEY_RELEASED, paramKeyEvent -> home()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.END, KeyEvent.KEY_RELEASED, paramKeyEvent -> end()) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  59 */     InputMap inputMap1 = new InputMap(paramSlider);
/*  60 */     inputMap1.setInterceptor(paramEvent -> (paramSlider.getOrientation() != Orientation.HORIZONTAL));
/*  61 */     inputMap1.getMappings().addAll(new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> rtl(paramSlider, this::incrementValue, this::decrementValue)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_LEFT, paramKeyEvent -> rtl(paramSlider, this::incrementValue, this::decrementValue)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> rtl(paramSlider, this::decrementValue, this::incrementValue)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_RIGHT, paramKeyEvent -> rtl(paramSlider, this::decrementValue, this::incrementValue)) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     addDefaultChildMap(this.sliderInputMap, inputMap1);
/*     */ 
/*     */     
/*  71 */     InputMap inputMap2 = new InputMap(paramSlider);
/*  72 */     inputMap2.setInterceptor(paramEvent -> (paramSlider.getOrientation() != Orientation.VERTICAL));
/*  73 */     inputMap2.getMappings().addAll(new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> decrementValue()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_DOWN, paramKeyEvent -> decrementValue()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> incrementValue()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_UP, paramKeyEvent -> incrementValue()) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     addDefaultChildMap(this.sliderInputMap, inputMap2);
/*     */ 
/*     */     
/*  82 */     if (Utils.isTwoLevelFocus()) {
/*  83 */       this.tlFocus = new TwoLevelFocusBehavior(paramSlider);
/*     */     }
/*     */   }
/*     */   
/*     */   public void dispose() {
/*  88 */     if (this.tlFocus != null) this.tlFocus.dispose(); 
/*  89 */     super.dispose();
/*     */   }
/*     */   
/*     */   public InputMap<Slider> getInputMap() {
/*  93 */     return this.sliderInputMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trackPress(MouseEvent paramMouseEvent, double paramDouble) {
/* 111 */     Slider slider = getNode();
/*     */     
/* 113 */     if (!slider.isFocused()) slider.requestFocus(); 
/* 114 */     if (slider.getOrientation().equals(Orientation.HORIZONTAL)) {
/* 115 */       slider.adjustValue(paramDouble * (slider.getMax() - slider.getMin()) + slider.getMin());
/*     */     } else {
/* 117 */       slider.adjustValue((1.0D - paramDouble) * (slider.getMax() - slider.getMin()) + slider.getMin());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void thumbPressed(MouseEvent paramMouseEvent, double paramDouble) {
/* 127 */     Slider slider = getNode();
/* 128 */     if (!slider.isFocused()) slider.requestFocus(); 
/* 129 */     slider.setValueChanging(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void thumbDragged(MouseEvent paramMouseEvent, double paramDouble) {
/* 137 */     Slider slider = getNode();
/* 138 */     slider.setValue(Utils.clamp(slider.getMin(), paramDouble * (slider.getMax() - slider.getMin()) + slider.getMin(), slider.getMax()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void thumbReleased(MouseEvent paramMouseEvent) {
/* 145 */     Slider slider = getNode();
/* 146 */     slider.setValueChanging(false);
/*     */ 
/*     */     
/* 149 */     slider.adjustValue(slider.getValue());
/*     */   }
/*     */   
/*     */   void home() {
/* 153 */     Slider slider = getNode();
/* 154 */     slider.adjustValue(slider.getMin());
/*     */   }
/*     */   
/*     */   void decrementValue() {
/* 158 */     Slider slider = getNode();
/*     */ 
/*     */     
/* 161 */     if (slider.isSnapToTicks()) {
/* 162 */       slider.adjustValue(slider.getValue() - computeIncrement());
/*     */     } else {
/* 164 */       slider.decrement();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void end() {
/* 170 */     Slider slider = getNode();
/* 171 */     slider.adjustValue(slider.getMax());
/*     */   }
/*     */   
/*     */   void incrementValue() {
/* 175 */     Slider slider = getNode();
/*     */ 
/*     */     
/* 178 */     if (slider.isSnapToTicks()) {
/* 179 */       slider.adjustValue(slider.getValue() + computeIncrement());
/*     */     } else {
/* 181 */       slider.increment();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   double computeIncrement() {
/* 187 */     Slider slider = getNode();
/* 188 */     double d = 0.0D;
/* 189 */     if (slider.getMinorTickCount() != 0) {
/* 190 */       d = slider.getMajorTickUnit() / (Math.max(slider.getMinorTickCount(), 0) + 1);
/*     */     } else {
/* 192 */       d = slider.getMajorTickUnit();
/*     */     } 
/*     */     
/* 195 */     if (slider.getBlockIncrement() > 0.0D && slider.getBlockIncrement() < d) {
/* 196 */       return d;
/*     */     }
/*     */     
/* 199 */     return slider.getBlockIncrement();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\SliderBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */