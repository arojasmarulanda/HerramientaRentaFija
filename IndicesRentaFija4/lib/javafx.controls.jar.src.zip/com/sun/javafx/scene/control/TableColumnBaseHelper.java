/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.control.TableColumnBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableColumnBaseHelper
/*    */ {
/*    */   private static TableColumnBaseAccessor tableColumnBaseAccessor;
/*    */   
/*    */   static {
/* 39 */     Utils.forceInit(TableColumnBase.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setWidth(TableColumnBase paramTableColumnBase, double paramDouble) {
/* 46 */     tableColumnBaseAccessor.setWidth(paramTableColumnBase, paramDouble);
/*    */   }
/*    */   
/*    */   public static void setTableColumnBaseAccessor(TableColumnBaseAccessor paramTableColumnBaseAccessor) {
/* 50 */     if (tableColumnBaseAccessor != null) {
/* 51 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 54 */     tableColumnBaseAccessor = paramTableColumnBaseAccessor;
/*    */   }
/*    */   
/*    */   public static interface TableColumnBaseAccessor {
/*    */     void setWidth(TableColumnBase param1TableColumnBase, double param1Double);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\TableColumnBaseHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */