/*     */ package com.sun.javafx.scene.control.inputmap;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.util.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputMap<N extends Node>
/*     */   implements EventHandler<Event>
/*     */ {
/*     */   private final N node;
/*     */   private final ObservableList<InputMap<N>> childInputMaps;
/*     */   private final ObservableList<Mapping<?>> mappings;
/*     */   private final Map<EventType<?>, List<EventHandler<? super Event>>> installedEventHandlers;
/*     */   private final Map<EventType, List<Mapping>> eventTypeMappings;
/*     */   
/*     */   public InputMap(N paramN) {
/*  99 */     if (paramN == null) {
/* 100 */       throw new IllegalArgumentException("Node can not be null");
/*     */     }
/*     */     
/* 103 */     this.node = paramN;
/* 104 */     this.eventTypeMappings = new HashMap<>();
/* 105 */     this.installedEventHandlers = new HashMap<>();
/*     */ 
/*     */ 
/*     */     
/* 109 */     this.mappings = FXCollections.observableArrayList();
/* 110 */     this.mappings.addListener(paramChange -> {
/*     */           while (paramChange.next()) {
/*     */             if (paramChange.wasRemoved()) {
/*     */               for (Mapping<?> mapping : (Iterable<Mapping<?>>)paramChange.getRemoved()) {
/*     */                 removeMapping(mapping);
/*     */               }
/*     */             }
/*     */             
/*     */             if (paramChange.wasAdded()) {
/*     */               ArrayList<?> arrayList = new ArrayList();
/*     */               
/*     */               for (Mapping<?> mapping : (Iterable<Mapping<?>>)paramChange.getAddedSubList()) {
/*     */                 if (mapping == null) {
/*     */                   arrayList.add(null);
/*     */                   
/*     */                   continue;
/*     */                 } 
/*     */                 
/*     */                 addMapping(mapping);
/*     */               } 
/*     */               if (!arrayList.isEmpty()) {
/*     */                 getMappings().removeAll(arrayList);
/*     */                 throw new IllegalArgumentException("Null mappings not permitted");
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         });
/* 137 */     this.childInputMaps = FXCollections.observableArrayList();
/* 138 */     this.childInputMaps.addListener(paramChange -> {
/*     */           while (paramChange.next()) {
/*     */             if (paramChange.wasRemoved()) {
/*     */               for (InputMap inputMap : paramChange.getRemoved()) {
/*     */                 inputMap.setParentInputMap(null);
/*     */               }
/*     */             }
/*     */             if (paramChange.wasAdded()) {
/*     */               ArrayList<InputMap<N>> arrayList = new ArrayList();
/*     */               for (InputMap<N> inputMap : (Iterable<InputMap<N>>)paramChange.getAddedSubList()) {
/*     */                 if (inputMap.getNode() != getNode()) {
/*     */                   arrayList.add(inputMap);
/*     */                   continue;
/*     */                 } 
/*     */                 inputMap.setParentInputMap(this);
/*     */               } 
/*     */               if (!arrayList.isEmpty()) {
/*     */                 getChildInputMaps().removeAll(arrayList);
/*     */                 throw new IllegalArgumentException("Child InputMap intances need to share a common Node object");
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   private ReadOnlyObjectWrapper<InputMap<N>> parentInputMap = new ReadOnlyObjectWrapper<InputMap<N>>(this, "parentInputMap")
/*     */     {
/*     */       protected void invalidated()
/*     */       {
/* 180 */         InputMap.this.reprocessAllMappings();
/*     */       }
/*     */     };
/* 183 */   private final void setParentInputMap(InputMap<N> paramInputMap) { this.parentInputMap.set(paramInputMap); }
/* 184 */   private final InputMap<N> getParentInputMap() { return this.parentInputMap.get(); } private final ReadOnlyObjectProperty<InputMap<N>> parentInputMapProperty() {
/* 185 */     return this.parentInputMap.getReadOnlyProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   private ObjectProperty<Predicate<? extends Event>> interceptor = new SimpleObjectProperty<>(this, "interceptor");
/*     */   public final Predicate<? extends Event> getInterceptor() {
/* 200 */     return this.interceptor.get();
/*     */   }
/*     */   public final void setInterceptor(Predicate<? extends Event> paramPredicate) {
/* 203 */     this.interceptor.set(paramPredicate);
/*     */   }
/*     */   public final ObjectProperty<Predicate<? extends Event>> interceptorProperty() {
/* 206 */     return this.interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final N getNode() {
/* 221 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<Mapping<?>> getMappings() {
/* 231 */     return this.mappings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<InputMap<N>> getChildInputMaps() {
/* 247 */     return this.childInputMaps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 255 */     for (InputMap<N> inputMap : getChildInputMaps()) {
/* 256 */       inputMap.dispose();
/*     */     }
/*     */ 
/*     */     
/* 260 */     removeAllEventHandlers();
/*     */ 
/*     */     
/* 263 */     getMappings().clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void handle(Event paramEvent) {
/* 268 */     if (paramEvent == null || paramEvent.isConsumed())
/*     */       return; 
/* 270 */     List<Mapping<?>> list = lookup(paramEvent, true);
/* 271 */     for (Mapping<?> mapping : list) {
/* 272 */       EventHandler<Event> eventHandler = mapping.getEventHandler();
/* 273 */       if (eventHandler != null) {
/* 274 */         eventHandler.handle(paramEvent);
/*     */       }
/*     */       
/* 277 */       if (mapping.isAutoConsume()) {
/* 278 */         paramEvent.consume();
/*     */       }
/*     */       
/* 281 */       if (paramEvent.isConsumed()) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Mapping<?>> lookupMapping(Object paramObject) {
/* 312 */     if (paramObject == null) {
/* 313 */       return Optional.empty();
/*     */     }
/*     */     
/* 316 */     List<Mapping<?>> list = lookupMappingKey(paramObject);
/*     */ 
/*     */     
/* 319 */     for (byte b = 0; b < getChildInputMaps().size(); b++) {
/* 320 */       InputMap inputMap = getChildInputMaps().get(b);
/*     */       
/* 322 */       List<Mapping<?>> list1 = inputMap.lookupMappingKey(paramObject);
/* 323 */       list.addAll(0, list1);
/*     */     } 
/*     */     
/* 326 */     return (list.size() > 0) ? Optional.<Mapping<?>>of(list.get(0)) : Optional.<Mapping<?>>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Mapping<?>> lookupMappingKey(Object paramObject) {
/* 339 */     return (List<Mapping<?>>)getMappings().stream()
/* 340 */       .filter(paramMapping -> !paramMapping.isDisabled())
/* 341 */       .filter(paramMapping -> paramObject.equals(paramMapping.getMappingKey()))
/* 342 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<Mapping<?>> lookup(Event paramEvent, boolean paramBoolean) {
/* 354 */     if (paramBoolean) {
/* 355 */       boolean bool = testInterceptor(paramEvent, getInterceptor());
/*     */       
/* 357 */       if (bool) {
/* 358 */         return Collections.emptyList();
/*     */       }
/*     */     } 
/*     */     
/* 362 */     ArrayList<Mapping<?>> arrayList = new ArrayList();
/*     */     
/* 364 */     int i = 0;
/* 365 */     List<Pair<Integer, Mapping<?>>> list = lookupMappingAndSpecificity(paramEvent, i);
/* 366 */     if (!list.isEmpty()) {
/* 367 */       i = ((Integer)((Pair)list.get(0)).getKey()).intValue();
/* 368 */       arrayList.addAll((Collection)list.stream().map(paramPair -> (Mapping)paramPair.getValue()).collect(Collectors.toList()));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 374 */     for (byte b = 0; b < getChildInputMaps().size(); b++) {
/* 375 */       InputMap<?> inputMap = getChildInputMaps().get(b);
/* 376 */       i = scanRecursively(inputMap, paramEvent, paramBoolean, i, arrayList);
/*     */     } 
/*     */     
/* 379 */     return arrayList;
/*     */   }
/*     */ 
/*     */   
/*     */   private int scanRecursively(InputMap<?> paramInputMap, Event paramEvent, boolean paramBoolean, int paramInt, List<Mapping<?>> paramList) {
/* 384 */     if (paramBoolean) {
/* 385 */       boolean bool = testInterceptor(paramEvent, paramInputMap.getInterceptor());
/* 386 */       if (bool) {
/* 387 */         return paramInt;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 392 */     List<Pair<Integer, Mapping<?>>> list = paramInputMap.lookupMappingAndSpecificity(paramEvent, paramInt);
/* 393 */     if (!list.isEmpty()) {
/* 394 */       int i = ((Integer)((Pair)list.get(0)).getKey()).intValue();
/*     */ 
/*     */       
/* 397 */       List<? extends Mapping<?>> list1 = (List)list.stream().map(paramPair -> (Mapping)paramPair.getValue()).collect(Collectors.toList());
/* 398 */       if (i == paramInt) {
/* 399 */         paramList.addAll(0, list1);
/* 400 */       } else if (i > paramInt) {
/* 401 */         paramList.clear();
/* 402 */         paramInt = i;
/* 403 */         paramList.addAll(list1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 408 */     for (byte b = 0; b < paramInputMap.getChildInputMaps().size(); b++) {
/* 409 */       paramInt = scanRecursively(paramInputMap.getChildInputMaps().get(b), paramEvent, paramBoolean, paramInt, paramList);
/*     */     }
/*     */     
/* 412 */     return paramInt;
/*     */   }
/*     */   
/*     */   private InputMap<N> getRootInputMap() {
/* 416 */     InputMap<N> inputMap = this;
/*     */     
/* 418 */     while (inputMap != null) {
/* 419 */       InputMap<N> inputMap1 = inputMap.getParentInputMap();
/* 420 */       if (inputMap1 == null)
/* 421 */         break;  inputMap = inputMap1;
/*     */     } 
/* 423 */     return inputMap;
/*     */   }
/*     */   
/*     */   private void addMapping(Mapping<?> paramMapping) {
/* 427 */     InputMap<N> inputMap = getRootInputMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 433 */     inputMap.addEventHandler(paramMapping.eventType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 438 */     EventType<?> eventType = paramMapping.getEventType();
/* 439 */     List<Mapping<?>> list = (List)this.eventTypeMappings.computeIfAbsent(eventType, paramEventType -> new ArrayList());
/* 440 */     list.add(paramMapping);
/*     */   }
/*     */   
/*     */   private void removeMapping(Mapping<?> paramMapping) {
/* 444 */     EventType<?> eventType = paramMapping.getEventType();
/* 445 */     if (this.eventTypeMappings.containsKey(eventType)) {
/* 446 */       List list = this.eventTypeMappings.get(eventType);
/* 447 */       list.remove(paramMapping);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addEventHandler(EventType<?> paramEventType) {
/* 456 */     List<EventHandler<?>> list = this.installedEventHandlers.computeIfAbsent(paramEventType, paramEventType -> new ArrayList());
/*     */     
/* 458 */     EventHandler<?> eventHandler = this::handle;
/*     */     
/* 460 */     if (list.isEmpty())
/*     */     {
/* 462 */       this.node.addEventHandler(paramEventType, eventHandler);
/*     */     }
/*     */ 
/*     */     
/* 466 */     list.add(eventHandler);
/*     */   }
/*     */   
/*     */   private void removeAllEventHandlers() {
/* 470 */     for (EventType<Event> eventType : this.installedEventHandlers.keySet()) {
/* 471 */       List list = this.installedEventHandlers.get(eventType);
/* 472 */       for (EventHandler<? super Event> eventHandler : (Iterable<EventHandler<? super Event>>)list)
/*     */       {
/* 474 */         this.node.removeEventHandler(eventType, eventHandler);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void reprocessAllMappings() {
/* 480 */     removeAllEventHandlers();
/* 481 */     this.mappings.stream().forEach(this::addMapping);
/*     */ 
/*     */     
/* 484 */     for (InputMap<N> inputMap : getChildInputMaps()) {
/* 485 */       inputMap.reprocessAllMappings();
/*     */     }
/*     */   }
/*     */   
/*     */   private List<Pair<Integer, Mapping<?>>> lookupMappingAndSpecificity(Event paramEvent, int paramInt) {
/* 490 */     int i = paramInt;
/*     */     
/* 492 */     List list = this.eventTypeMappings.getOrDefault(paramEvent.getEventType(), Collections.emptyList());
/* 493 */     ArrayList<Pair<Integer, Mapping<?>>> arrayList = new ArrayList();
/* 494 */     for (Mapping mapping : list) {
/* 495 */       if (mapping.isDisabled()) {
/*     */         continue;
/*     */       }
/*     */       
/* 499 */       boolean bool = testInterceptor(paramEvent, mapping.getInterceptor());
/* 500 */       if (bool) {
/*     */         continue;
/*     */       }
/*     */       
/* 504 */       int j = mapping.getSpecificity(paramEvent);
/* 505 */       if (j > 0 && j == i) {
/* 506 */         arrayList.add(new Pair<>(Integer.valueOf(j), mapping)); continue;
/* 507 */       }  if (j > i) {
/* 508 */         arrayList.clear();
/* 509 */         arrayList.add(new Pair<>(Integer.valueOf(j), mapping));
/* 510 */         i = j;
/*     */       } 
/*     */     } 
/*     */     
/* 514 */     return arrayList;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean testInterceptor(Event paramEvent, Predicate<Event> paramPredicate) {
/* 519 */     return (paramPredicate != null && paramPredicate.test(paramEvent));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Mapping<T extends Event>
/*     */   {
/*     */     private final EventType<T> eventType;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final EventHandler<T> eventHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private BooleanProperty disabled;
/*     */ 
/*     */ 
/*     */     
/*     */     private BooleanProperty autoConsume;
/*     */ 
/*     */ 
/*     */     
/*     */     private ObjectProperty<Predicate<? extends Event>> interceptor;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setDisabled(boolean param1Boolean) {
/*     */       this.disabled.set(param1Boolean);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isDisabled() {
/*     */       return this.disabled.get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final BooleanProperty disabledProperty() {
/*     */       return this.disabled;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setAutoConsume(boolean param1Boolean) {
/*     */       this.autoConsume.set(param1Boolean);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean isAutoConsume() {
/*     */       return this.autoConsume.get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final BooleanProperty autoConsumeProperty() {
/*     */       return this.autoConsume;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final EventType<T> getEventType() {
/*     */       return this.eventType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final EventHandler<T> getEventHandler() {
/*     */       return this.eventHandler;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Mapping(EventType<T> param1EventType, EventHandler<T> param1EventHandler) {
/* 608 */       this.disabled = new SimpleBooleanProperty(this, "disabled", false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 624 */       this.autoConsume = new SimpleBooleanProperty(this, "autoConsume", true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 665 */       this.interceptor = new SimpleObjectProperty<>(this, "interceptor");
/*     */       this.eventType = param1EventType;
/* 667 */       this.eventHandler = param1EventHandler; } public final Predicate<? extends Event> getInterceptor() { return this.interceptor.get(); }
/*     */     
/*     */     public final void setInterceptor(Predicate<? extends Event> param1Predicate) {
/* 670 */       this.interceptor.set(param1Predicate);
/*     */     }
/*     */     public final ObjectProperty<Predicate<? extends Event>> interceptorProperty() {
/* 673 */       return this.interceptor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getMappingKey() {
/* 681 */       return this.eventType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 686 */       if (this == param1Object) return true; 
/* 687 */       if (!(param1Object instanceof Mapping)) return false;
/*     */       
/* 689 */       Mapping mapping = (Mapping)param1Object;
/*     */       
/* 691 */       if ((this.eventType != null) ? !this.eventType.equals(mapping.getEventType()) : (mapping.getEventType() != null)) return false;
/*     */       
/* 693 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 698 */       return (this.eventType != null) ? this.eventType.hashCode() : 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract int getSpecificity(Event param1Event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class KeyMapping
/*     */     extends Mapping<KeyEvent>
/*     */   {
/*     */     private final KeyBinding keyBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public KeyMapping(KeyCode param1KeyCode, EventHandler<KeyEvent> param1EventHandler) {
/* 733 */       this(new KeyBinding(param1KeyCode), param1EventHandler);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public KeyMapping(KeyCode param1KeyCode, EventType<KeyEvent> param1EventType, EventHandler<KeyEvent> param1EventHandler) {
/* 755 */       this(new KeyBinding(param1KeyCode, param1EventType), param1EventHandler);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public KeyMapping(KeyBinding param1KeyBinding, EventHandler<KeyEvent> param1EventHandler) {
/* 768 */       this(param1KeyBinding, param1EventHandler, (Predicate<KeyEvent>)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public KeyMapping(KeyBinding param1KeyBinding, EventHandler<KeyEvent> param1EventHandler, Predicate<KeyEvent> param1Predicate) {
/* 784 */       super((param1KeyBinding == null) ? null : param1KeyBinding.getType(), param1EventHandler);
/* 785 */       if (param1KeyBinding == null) {
/* 786 */         throw new IllegalArgumentException("KeyMapping keyBinding constructor argument can not be null");
/*     */       }
/* 788 */       this.keyBinding = param1KeyBinding;
/* 789 */       setInterceptor((Predicate)param1Predicate);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getMappingKey() {
/* 802 */       return this.keyBinding;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getSpecificity(Event param1Event) {
/* 807 */       if (isDisabled()) return 0; 
/* 808 */       if (!(param1Event instanceof KeyEvent)) return 0; 
/* 809 */       return this.keyBinding.getSpecificity((KeyEvent)param1Event);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 814 */       if (this == param1Object) return true; 
/* 815 */       if (!(param1Object instanceof KeyMapping)) return false; 
/* 816 */       if (!super.equals(param1Object)) return false;
/*     */       
/* 818 */       KeyMapping keyMapping = (KeyMapping)param1Object;
/*     */ 
/*     */       
/* 821 */       return this.keyBinding.equals(keyMapping.keyBinding);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 826 */       return Objects.hash(new Object[] { this.keyBinding });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MouseMapping
/*     */     extends Mapping<MouseEvent>
/*     */   {
/*     */     public MouseMapping(EventType<MouseEvent> param1EventType, EventHandler<MouseEvent> param1EventHandler) {
/* 863 */       super(param1EventType, param1EventHandler);
/* 864 */       if (param1EventType == null) {
/* 865 */         throw new IllegalArgumentException("MouseMapping eventType constructor argument can not be null");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getSpecificity(Event param1Event) {
/* 879 */       if (isDisabled()) return 0; 
/* 880 */       if (!(param1Event instanceof MouseEvent)) return 0; 
/* 881 */       EventType<MouseEvent> eventType = getEventType();
/*     */ 
/*     */       
/* 884 */       byte b = 0;
/* 885 */       if (param1Event.getEventType() == MouseEvent.MOUSE_CLICKED && eventType != MouseEvent.MOUSE_CLICKED) return 0;  b++;
/* 886 */       if (param1Event.getEventType() == MouseEvent.MOUSE_DRAGGED && eventType != MouseEvent.MOUSE_DRAGGED) return 0;  b++;
/* 887 */       if (param1Event.getEventType() == MouseEvent.MOUSE_ENTERED && eventType != MouseEvent.MOUSE_ENTERED) return 0;  b++;
/* 888 */       if (param1Event.getEventType() == MouseEvent.MOUSE_ENTERED_TARGET && eventType != MouseEvent.MOUSE_ENTERED_TARGET) return 0;  b++;
/* 889 */       if (param1Event.getEventType() == MouseEvent.MOUSE_EXITED && eventType != MouseEvent.MOUSE_EXITED) return 0;  b++;
/* 890 */       if (param1Event.getEventType() == MouseEvent.MOUSE_EXITED_TARGET && eventType != MouseEvent.MOUSE_EXITED_TARGET) return 0;  b++;
/* 891 */       if (param1Event.getEventType() == MouseEvent.MOUSE_MOVED && eventType != MouseEvent.MOUSE_MOVED) return 0;  b++;
/* 892 */       if (param1Event.getEventType() == MouseEvent.MOUSE_PRESSED && eventType != MouseEvent.MOUSE_PRESSED) return 0;  b++;
/* 893 */       if (param1Event.getEventType() == MouseEvent.MOUSE_RELEASED && eventType != MouseEvent.MOUSE_RELEASED) return 0;  b++;
/*     */ 
/*     */ 
/*     */       
/* 897 */       return b;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class KeyMappingInterceptor
/*     */     implements Predicate<Event>
/*     */   {
/*     */     private final KeyBinding keyBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public KeyMappingInterceptor(KeyBinding param1KeyBinding) {
/* 924 */       this.keyBinding = param1KeyBinding;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(Event param1Event) {
/* 929 */       if (!(param1Event instanceof KeyEvent)) return false; 
/* 930 */       return KeyBinding.toKeyBinding((KeyEvent)param1Event).equals(this.keyBinding);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MouseMappingInterceptor
/*     */     implements Predicate<Event>
/*     */   {
/*     */     private final EventType<MouseEvent> eventType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MouseMappingInterceptor(EventType<MouseEvent> param1EventType) {
/* 960 */       this.eventType = param1EventType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean test(Event param1Event) {
/* 965 */       if (!(param1Event instanceof MouseEvent)) return false; 
/* 966 */       return (param1Event.getEventType() == this.eventType);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\inputmap\InputMap.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */