/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableListBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SelectedItemsReadOnlyObservableList<E>
/*     */   extends ObservableListBase<E>
/*     */ {
/*     */   private final ObservableList<Integer> selectedIndices;
/*     */   private ObservableList<E> itemsList;
/*     */   private boolean itemsListChanged = false;
/*     */   private ListChangeListener.Change<? extends E> itemsListChange;
/*     */   private final ListChangeListener itemsListListener;
/*     */   private final Supplier<Integer> modelSizeSupplier;
/*     */   private final List<WeakReference<E>> itemsRefList;
/*     */   
/*     */   public SelectedItemsReadOnlyObservableList(ObservableList<Integer> paramObservableList, Supplier<Integer> paramSupplier) {
/*  45 */     this.itemsListListener = (paramChange -> {
/*     */         this.itemsListChanged = true;
/*     */ 
/*     */ 
/*     */         
/*     */         this.itemsListChange = paramChange;
/*     */       });
/*     */ 
/*     */ 
/*     */     
/*  55 */     this.modelSizeSupplier = paramSupplier;
/*  56 */     this.selectedIndices = paramObservableList;
/*  57 */     this.itemsRefList = new ArrayList<>();
/*     */     
/*  59 */     paramObservableList.addListener(paramChange -> {
/*     */           beginChange();
/*     */           while (paramChange.next()) {
/*     */             if (paramChange.wasReplaced()) {
/*     */               List<E> list1 = getRemovedElements(paramChange);
/*     */               List<E> list2 = getAddedElements(paramChange);
/*     */               if (!list1.equals(list2)) {
/*     */                 nextReplace(paramChange.getFrom(), paramChange.getTo(), list1);
/*     */               }
/*     */               continue;
/*     */             } 
/*     */             if (paramChange.wasAdded()) {
/*     */               nextAdd(paramChange.getFrom(), paramChange.getTo());
/*     */               continue;
/*     */             } 
/*     */             if (paramChange.wasRemoved()) {
/*     */               int i = paramChange.getRemovedSize();
/*     */               if (i == 1) {
/*     */                 nextRemove(paramChange.getFrom(), getRemovedModelItem(paramChange.getFrom()));
/*     */                 continue;
/*     */               } 
/*     */               nextRemove(paramChange.getFrom(), getRemovedElements(paramChange));
/*     */               continue;
/*     */             } 
/*     */             if (paramChange.wasPermutated()) {
/*     */               int[] arrayOfInt = new int[size()];
/*     */               for (byte b = 0; b < size(); b++) {
/*     */                 arrayOfInt[b] = paramChange.getPermutation(b);
/*     */               }
/*     */               nextPermutation(paramChange.getFrom(), paramChange.getTo(), arrayOfInt);
/*     */               continue;
/*     */             } 
/*     */             if (paramChange.wasUpdated()) {
/*     */               for (int i = paramChange.getFrom(); i < paramChange.getTo(); i++) {
/*     */                 nextUpdate(i);
/*     */               }
/*     */             }
/*     */           } 
/*     */           this.itemsRefList.clear();
/*     */           Iterator<Integer> iterator = paramObservableList.iterator();
/*     */           while (iterator.hasNext()) {
/*     */             int i = ((Integer)iterator.next()).intValue();
/*     */             this.itemsRefList.add(new WeakReference<>(getModelItem(i)));
/*     */           } 
/*     */           this.itemsListChanged = false;
/*     */           this.itemsListChange = null;
/*     */           endChange();
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public E get(int paramInt) {
/* 111 */     int i = ((Integer)this.selectedIndices.get(paramInt)).intValue();
/* 112 */     return getModelItem(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 117 */     return this.selectedIndices.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setItemsList(ObservableList<E> paramObservableList) {
/* 122 */     if (this.itemsList != null) {
/* 123 */       this.itemsList.removeListener(this.itemsListListener);
/*     */     }
/* 125 */     this.itemsList = paramObservableList;
/* 126 */     if (paramObservableList != null) {
/* 127 */       paramObservableList.addListener(this.itemsListListener);
/*     */     }
/*     */   }
/*     */   
/*     */   private E _getModelItem(int paramInt) {
/* 132 */     if (paramInt >= ((Integer)this.modelSizeSupplier.get()).intValue())
/*     */     {
/* 134 */       return getRemovedModelItem(paramInt);
/*     */     }
/* 136 */     return getModelItem(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private E getRemovedModelItem(int paramInt) {
/* 142 */     return (paramInt < 0 || paramInt >= this.itemsRefList.size()) ? null : ((WeakReference<E>)this.itemsRefList.get(paramInt)).get();
/*     */   }
/*     */   
/*     */   private List<E> getRemovedElements(ListChangeListener.Change<? extends Integer> paramChange) {
/* 146 */     ArrayList<E> arrayList = new ArrayList(paramChange.getRemovedSize());
/* 147 */     int i = paramChange.getFrom();
/* 148 */     for (int j = i, k = i + paramChange.getRemovedSize(); j < k; j++) {
/* 149 */       arrayList.add(getRemovedModelItem(j));
/*     */     }
/* 151 */     return arrayList;
/*     */   }
/*     */   
/*     */   private List<E> getAddedElements(ListChangeListener.Change<? extends Integer> paramChange) {
/* 155 */     ArrayList<E> arrayList = new ArrayList(paramChange.getAddedSize());
/* 156 */     for (Iterator<Integer> iterator = paramChange.getAddedSubList().iterator(); iterator.hasNext(); ) { int i = ((Integer)iterator.next()).intValue();
/* 157 */       arrayList.add(_getModelItem(i)); }
/*     */     
/* 159 */     return arrayList;
/*     */   }
/*     */   
/*     */   protected abstract E getModelItem(int paramInt);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\SelectedItemsReadOnlyObservableList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */