/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.collections.TrackableObservableList;
/*     */ import com.sun.javafx.menu.CheckMenuItemBase;
/*     */ import com.sun.javafx.menu.CustomMenuItemBase;
/*     */ import com.sun.javafx.menu.MenuBase;
/*     */ import com.sun.javafx.menu.MenuItemBase;
/*     */ import com.sun.javafx.menu.RadioMenuItemBase;
/*     */ import com.sun.javafx.menu.SeparatorMenuItemBase;
/*     */ import java.util.List;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.scene.control.CheckMenuItem;
/*     */ import javafx.scene.control.CustomMenuItem;
/*     */ import javafx.scene.control.Menu;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.RadioMenuItem;
/*     */ import javafx.scene.control.SeparatorMenuItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlobalMenuAdapter
/*     */   extends Menu
/*     */   implements MenuBase
/*     */ {
/*     */   private Menu menu;
/*     */   
/*     */   public static MenuBase adapt(Menu paramMenu) {
/*  58 */     return new GlobalMenuAdapter(paramMenu);
/*     */   }
/*     */   
/*  61 */   private final ObservableList<MenuItemBase> items = new TrackableObservableList<MenuItemBase>()
/*     */     {
/*     */       protected void onChanged(ListChangeListener.Change<MenuItemBase> param1Change) {}
/*     */     };
/*     */   
/*     */   private GlobalMenuAdapter(Menu paramMenu) {
/*  67 */     super(paramMenu.getText());
/*     */     
/*  69 */     this.menu = paramMenu;
/*     */     
/*  71 */     bindMenuItemProperties(this, paramMenu);
/*     */     
/*  73 */     paramMenu.showingProperty().addListener(paramObservable -> {
/*     */           if (paramMenu.isShowing() && !isShowing()) {
/*     */             show();
/*     */           } else if (!paramMenu.isShowing() && isShowing()) {
/*     */             hide();
/*     */           } 
/*     */         });
/*  80 */     showingProperty().addListener(paramObservable -> {
/*     */           if (isShowing() && !paramMenu.isShowing()) {
/*     */             paramMenu.show();
/*     */           } else if (!isShowing() && paramMenu.isShowing()) {
/*     */             paramMenu.hide();
/*     */           } 
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     paramMenu.getItems().addListener(new ListChangeListener<MenuItem>() {
/*     */           public void onChanged(ListChangeListener.Change<? extends MenuItem> param1Change) {
/*  96 */             while (param1Change.next()) {
/*  97 */               int i = param1Change.getFrom();
/*  98 */               int j = param1Change.getTo();
/*  99 */               List<? extends MenuItem> list = param1Change.getRemoved(); int k;
/* 100 */               for (k = i + list.size() - 1; k >= i; k--) {
/* 101 */                 GlobalMenuAdapter.this.items.remove(k);
/* 102 */                 GlobalMenuAdapter.this.getItems().remove(k);
/*     */               } 
/* 104 */               for (k = i; k < j; k++) {
/* 105 */                 MenuItem menuItem = param1Change.getList().get(k);
/* 106 */                 GlobalMenuAdapter.this.insertItem(menuItem, k);
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 112 */     for (MenuItem menuItem : paramMenu.getItems()) {
/* 113 */       insertItem(menuItem, this.items.size());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void insertItem(MenuItem paramMenuItem, int paramInt) {
/*     */     MenuItemAdapter menuItemAdapter;
/* 120 */     if (paramMenuItem instanceof Menu) {
/* 121 */       GlobalMenuAdapter globalMenuAdapter = new GlobalMenuAdapter((Menu)paramMenuItem);
/* 122 */     } else if (paramMenuItem instanceof CheckMenuItem) {
/* 123 */       CheckMenuItemAdapter checkMenuItemAdapter = new CheckMenuItemAdapter((CheckMenuItem)paramMenuItem);
/* 124 */     } else if (paramMenuItem instanceof RadioMenuItem) {
/* 125 */       RadioMenuItemAdapter radioMenuItemAdapter = new RadioMenuItemAdapter((RadioMenuItem)paramMenuItem);
/* 126 */     } else if (paramMenuItem instanceof SeparatorMenuItem) {
/* 127 */       SeparatorMenuItemAdapter separatorMenuItemAdapter = new SeparatorMenuItemAdapter((SeparatorMenuItem)paramMenuItem);
/* 128 */     } else if (paramMenuItem instanceof CustomMenuItem) {
/* 129 */       CustomMenuItemAdapter customMenuItemAdapter = new CustomMenuItemAdapter((CustomMenuItem)paramMenuItem);
/*     */     } else {
/* 131 */       menuItemAdapter = new MenuItemAdapter(paramMenuItem);
/*     */     } 
/*     */     
/* 134 */     this.items.add(paramInt, menuItemAdapter);
/* 135 */     getItems().add(paramInt, menuItemAdapter);
/*     */   }
/*     */   
/*     */   public final ObservableList<MenuItemBase> getItemsBase() {
/* 139 */     return this.items;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void bindMenuItemProperties(MenuItem paramMenuItem1, MenuItem paramMenuItem2) {
/* 144 */     paramMenuItem1.idProperty().bind(paramMenuItem2.idProperty());
/* 145 */     paramMenuItem1.textProperty().bind(paramMenuItem2.textProperty());
/* 146 */     paramMenuItem1.graphicProperty().bind(paramMenuItem2.graphicProperty());
/* 147 */     paramMenuItem1.disableProperty().bind(paramMenuItem2.disableProperty());
/* 148 */     paramMenuItem1.visibleProperty().bind(paramMenuItem2.visibleProperty());
/* 149 */     paramMenuItem1.acceleratorProperty().bind(paramMenuItem2.acceleratorProperty());
/* 150 */     paramMenuItem1.mnemonicParsingProperty().bind(paramMenuItem2.mnemonicParsingProperty());
/*     */     
/* 152 */     paramMenuItem1.setOnAction(paramActionEvent -> paramMenuItem.fire());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireValidation() {
/* 159 */     if (this.menu.getOnMenuValidation() != null) {
/* 160 */       Event.fireEvent(this.menu, new Event(MENU_VALIDATION_EVENT));
/*     */     }
/* 162 */     Menu menu = this.menu.getParentMenu();
/* 163 */     if (menu != null && menu.getOnMenuValidation() != null)
/* 164 */       Event.fireEvent(menu, new Event(MenuItem.MENU_VALIDATION_EVENT)); 
/*     */   }
/*     */   
/*     */   private static class MenuItemAdapter
/*     */     extends MenuItem
/*     */     implements MenuItemBase {
/*     */     private MenuItem menuItem;
/*     */     
/*     */     private MenuItemAdapter(MenuItem param1MenuItem) {
/* 173 */       super(param1MenuItem.getText());
/*     */       
/* 175 */       this.menuItem = param1MenuItem;
/*     */       
/* 177 */       GlobalMenuAdapter.bindMenuItemProperties(this, param1MenuItem);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fireValidation() {
/* 182 */       if (this.menuItem.getOnMenuValidation() != null) {
/* 183 */         Event.fireEvent(this.menuItem, new Event(MenuItem.MENU_VALIDATION_EVENT));
/*     */       }
/* 185 */       Menu menu = this.menuItem.getParentMenu();
/* 186 */       if (menu.getOnMenuValidation() != null)
/* 187 */         Event.fireEvent(menu, new Event(MenuItem.MENU_VALIDATION_EVENT)); 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CheckMenuItemAdapter
/*     */     extends CheckMenuItem implements CheckMenuItemBase {
/*     */     private CheckMenuItem menuItem;
/*     */     
/*     */     private CheckMenuItemAdapter(CheckMenuItem param1CheckMenuItem) {
/* 196 */       super(param1CheckMenuItem.getText());
/* 197 */       this.menuItem = param1CheckMenuItem;
/*     */       
/* 199 */       GlobalMenuAdapter.bindMenuItemProperties(this, param1CheckMenuItem);
/*     */       
/* 201 */       selectedProperty().bindBidirectional(param1CheckMenuItem.selectedProperty());
/*     */     }
/*     */ 
/*     */     
/*     */     public void fireValidation() {
/* 206 */       if (getOnMenuValidation() != null) {
/* 207 */         Event.fireEvent(this.menuItem, new Event(MENU_VALIDATION_EVENT));
/*     */       }
/* 209 */       Menu menu = this.menuItem.getParentMenu();
/* 210 */       if (menu.getOnMenuValidation() != null)
/* 211 */         Event.fireEvent(menu, new Event(MenuItem.MENU_VALIDATION_EVENT)); 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class RadioMenuItemAdapter
/*     */     extends RadioMenuItem implements RadioMenuItemBase {
/*     */     private RadioMenuItem menuItem;
/*     */     
/*     */     private RadioMenuItemAdapter(RadioMenuItem param1RadioMenuItem) {
/* 220 */       super(param1RadioMenuItem.getText());
/*     */       
/* 222 */       this.menuItem = param1RadioMenuItem;
/*     */       
/* 224 */       GlobalMenuAdapter.bindMenuItemProperties(this, param1RadioMenuItem);
/*     */       
/* 226 */       selectedProperty().bindBidirectional(param1RadioMenuItem.selectedProperty());
/*     */     }
/*     */ 
/*     */     
/*     */     public void fireValidation() {
/* 231 */       if (getOnMenuValidation() != null) {
/* 232 */         Event.fireEvent(this.menuItem, new Event(MENU_VALIDATION_EVENT));
/*     */       }
/* 234 */       Menu menu = this.menuItem.getParentMenu();
/* 235 */       if (menu.getOnMenuValidation() != null)
/* 236 */         Event.fireEvent(menu, new Event(MenuItem.MENU_VALIDATION_EVENT)); 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SeparatorMenuItemAdapter
/*     */     extends SeparatorMenuItem implements SeparatorMenuItemBase {
/*     */     private SeparatorMenuItem menuItem;
/*     */     
/*     */     private SeparatorMenuItemAdapter(SeparatorMenuItem param1SeparatorMenuItem) {
/* 245 */       this.menuItem = param1SeparatorMenuItem;
/*     */       
/* 247 */       GlobalMenuAdapter.bindMenuItemProperties(this, param1SeparatorMenuItem);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fireValidation() {
/* 252 */       if (getOnMenuValidation() != null) {
/* 253 */         Event.fireEvent(this.menuItem, new Event(MENU_VALIDATION_EVENT));
/*     */       }
/* 255 */       Menu menu = this.menuItem.getParentMenu();
/* 256 */       if (menu.getOnMenuValidation() != null)
/* 257 */         Event.fireEvent(menu, new Event(MenuItem.MENU_VALIDATION_EVENT)); 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CustomMenuItemAdapter
/*     */     extends CustomMenuItem implements CustomMenuItemBase {
/*     */     private CustomMenuItem menuItem;
/*     */     
/*     */     private CustomMenuItemAdapter(CustomMenuItem param1CustomMenuItem) {
/* 266 */       this.menuItem = param1CustomMenuItem;
/*     */       
/* 268 */       GlobalMenuAdapter.bindMenuItemProperties(this, param1CustomMenuItem);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fireValidation() {
/* 273 */       if (getOnMenuValidation() != null) {
/* 274 */         Event.fireEvent(this.menuItem, new Event(MENU_VALIDATION_EVENT));
/*     */       }
/* 276 */       Menu menu = this.menuItem.getParentMenu();
/* 277 */       if (menu.getOnMenuValidation() != null)
/* 278 */         Event.fireEvent(menu, new Event(MenuItem.MENU_VALIDATION_EVENT)); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\GlobalMenuAdapter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */