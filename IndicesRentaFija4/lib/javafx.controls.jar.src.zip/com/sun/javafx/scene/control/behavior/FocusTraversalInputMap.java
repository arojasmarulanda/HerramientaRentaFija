/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FocusTraversalInputMap<N extends Node>
/*     */ {
/*  47 */   private static final List<InputMap.Mapping<?>> mappings = new ArrayList<>();
/*     */   static {
/*  49 */     mappings.add(new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> traverseUp(paramKeyEvent)));
/*  50 */     mappings.add(new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> traverseDown(paramKeyEvent)));
/*  51 */     mappings.add(new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> traverseLeft(paramKeyEvent)));
/*  52 */     mappings.add(new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> traverseRight(paramKeyEvent)));
/*  53 */     mappings.add(new InputMap.KeyMapping(KeyCode.TAB, paramKeyEvent -> traverseNext(paramKeyEvent)));
/*  54 */     mappings.add(new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB)).shift(), paramKeyEvent -> traversePrevious(paramKeyEvent)));
/*     */     
/*  56 */     mappings.add(new InputMap.KeyMapping((new KeyBinding(KeyCode.UP)).shift().alt().ctrl(), paramKeyEvent -> traverseUp(paramKeyEvent)));
/*  57 */     mappings.add(new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN)).shift().alt().ctrl(), paramKeyEvent -> traverseDown(paramKeyEvent)));
/*  58 */     mappings.add(new InputMap.KeyMapping((new KeyBinding(KeyCode.LEFT)).shift().alt().ctrl(), paramKeyEvent -> traverseLeft(paramKeyEvent)));
/*  59 */     mappings.add(new InputMap.KeyMapping((new KeyBinding(KeyCode.RIGHT)).shift().alt().ctrl(), paramKeyEvent -> traverseRight(paramKeyEvent)));
/*  60 */     mappings.add(new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB)).shift().alt().ctrl(), paramKeyEvent -> traverseNext(paramKeyEvent)));
/*  61 */     mappings.add(new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB)).alt().ctrl(), paramKeyEvent -> traversePrevious(paramKeyEvent)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InputMap.Mapping<?>[] getFocusTraversalMappings() {
/*  69 */     return (InputMap.Mapping<?>[])mappings.<InputMap.Mapping>toArray(new InputMap.Mapping[mappings.size()]);
/*     */   }
/*     */   
/*     */   public static <N extends Node> InputMap<N> createInputMap(N paramN) {
/*  73 */     InputMap<N> inputMap = new InputMap((Node)paramN);
/*  74 */     inputMap.getMappings().addAll(getFocusTraversalMappings());
/*  75 */     return inputMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void traverse(Node paramNode, Direction paramDirection) {
/*  94 */     if (paramNode == null) {
/*  95 */       throw new IllegalArgumentException("Attempting to traverse on a null Node. Most probably a KeyEvent has been fired with a null target specified.");
/*     */     }
/*     */     
/*  98 */     NodeHelper.traverse(paramNode, paramDirection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void traverseUp(KeyEvent paramKeyEvent) {
/* 106 */     traverse(getNode(paramKeyEvent), Direction.UP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void traverseDown(KeyEvent paramKeyEvent) {
/* 114 */     traverse(getNode(paramKeyEvent), Direction.DOWN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void traverseLeft(KeyEvent paramKeyEvent) {
/* 122 */     traverse(getNode(paramKeyEvent), Direction.LEFT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void traverseRight(KeyEvent paramKeyEvent) {
/* 130 */     traverse(getNode(paramKeyEvent), Direction.RIGHT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void traverseNext(KeyEvent paramKeyEvent) {
/* 138 */     traverse(getNode(paramKeyEvent), Direction.NEXT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void traversePrevious(KeyEvent paramKeyEvent) {
/* 146 */     traverse(getNode(paramKeyEvent), Direction.PREVIOUS);
/*     */   }
/*     */   
/*     */   private static Node getNode(KeyEvent paramKeyEvent) {
/* 150 */     EventTarget eventTarget = paramKeyEvent.getTarget();
/* 151 */     if (eventTarget instanceof Node) {
/* 152 */       return (Node)eventTarget;
/*     */     }
/* 154 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\FocusTraversalInputMap.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */