/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.control.Accordion;
/*     */ import javafx.scene.control.FocusModel;
/*     */ import javafx.scene.control.TitledPane;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AccordionBehavior
/*     */   extends BehaviorBase<Accordion>
/*     */ {
/*     */   private final InputMap<Accordion> inputMap;
/*     */   private AccordionFocusModel focusModel;
/*     */   
/*     */   public AccordionBehavior(Accordion paramAccordion) {
/*  49 */     super(paramAccordion);
/*  50 */     this.focusModel = new AccordionFocusModel(paramAccordion);
/*     */ 
/*     */ 
/*     */     
/*  54 */     this.inputMap = createInputMap();
/*     */ 
/*     */     
/*  57 */     addDefaultMapping(this.inputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> pageUp(false)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> pageDown(false)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> { if (isRTL(paramAccordion)) { pageDown(false); } else { pageUp(false); }  }), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> { if (isRTL(paramAccordion)) { pageUp(false); } else { pageDown(false); }  }), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.HOME, this::home), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.END, this::end), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.PAGE_UP, paramKeyEvent -> pageUp(true)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.PAGE_DOWN, paramKeyEvent -> pageDown(true)), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  72 */             .ctrl(), this::moveBackward), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN))
/*  73 */             .ctrl(), this::moveForward), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB))
/*  74 */             .ctrl(), this::moveForward), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB))
/*  75 */             .ctrl().shift(), this::moveBackward), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  81 */     this.focusModel.dispose();
/*  82 */     super.dispose();
/*     */   }
/*     */   
/*     */   public InputMap<Accordion> getInputMap() {
/*  86 */     return this.inputMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void pageUp(boolean paramBoolean) {
/* 164 */     Accordion accordion = getNode();
/* 165 */     if (this.focusModel.getFocusedIndex() != -1 && ((TitledPane)accordion.getPanes().get(this.focusModel.getFocusedIndex())).isFocused()) {
/* 166 */       this.focusModel.focusPrevious();
/* 167 */       int i = this.focusModel.getFocusedIndex();
/* 168 */       ((TitledPane)accordion.getPanes().get(i)).requestFocus();
/* 169 */       if (paramBoolean) {
/* 170 */         ((TitledPane)accordion.getPanes().get(i)).setExpanded(true);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void pageDown(boolean paramBoolean) {
/* 176 */     Accordion accordion = getNode();
/* 177 */     if (this.focusModel.getFocusedIndex() != -1 && ((TitledPane)accordion.getPanes().get(this.focusModel.getFocusedIndex())).isFocused()) {
/* 178 */       this.focusModel.focusNext();
/* 179 */       int i = this.focusModel.getFocusedIndex();
/* 180 */       ((TitledPane)accordion.getPanes().get(i)).requestFocus();
/* 181 */       if (paramBoolean) {
/* 182 */         ((TitledPane)accordion.getPanes().get(i)).setExpanded(true);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void moveBackward(KeyEvent paramKeyEvent) {
/* 188 */     Accordion accordion = getNode();
/* 189 */     this.focusModel.focusPrevious();
/* 190 */     if (this.focusModel.getFocusedIndex() != -1) {
/* 191 */       int i = this.focusModel.getFocusedIndex();
/* 192 */       ((TitledPane)accordion.getPanes().get(i)).requestFocus();
/* 193 */       ((TitledPane)accordion.getPanes().get(i)).setExpanded(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void moveForward(KeyEvent paramKeyEvent) {
/* 198 */     Accordion accordion = getNode();
/* 199 */     this.focusModel.focusNext();
/* 200 */     if (this.focusModel.getFocusedIndex() != -1) {
/* 201 */       int i = this.focusModel.getFocusedIndex();
/* 202 */       ((TitledPane)accordion.getPanes().get(i)).requestFocus();
/* 203 */       ((TitledPane)accordion.getPanes().get(i)).setExpanded(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void home(KeyEvent paramKeyEvent) {
/* 208 */     Accordion accordion = getNode();
/* 209 */     if (this.focusModel.getFocusedIndex() != -1 && ((TitledPane)accordion.getPanes().get(this.focusModel.getFocusedIndex())).isFocused()) {
/* 210 */       TitledPane titledPane = accordion.getPanes().get(0);
/* 211 */       titledPane.requestFocus();
/* 212 */       titledPane.setExpanded(!titledPane.isExpanded());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void end(KeyEvent paramKeyEvent) {
/* 217 */     Accordion accordion = getNode();
/* 218 */     if (this.focusModel.getFocusedIndex() != -1 && ((TitledPane)accordion.getPanes().get(this.focusModel.getFocusedIndex())).isFocused()) {
/* 219 */       TitledPane titledPane = accordion.getPanes().get(accordion.getPanes().size() - 1);
/* 220 */       titledPane.requestFocus();
/* 221 */       titledPane.setExpanded(!titledPane.isExpanded());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent paramMouseEvent) {
/* 233 */     Accordion accordion = getNode();
/* 234 */     if (accordion.getPanes().size() > 0) {
/* 235 */       TitledPane titledPane = accordion.getPanes().get(accordion.getPanes().size() - 1);
/* 236 */       titledPane.requestFocus();
/*     */     } else {
/*     */       
/* 239 */       accordion.requestFocus();
/*     */     } 
/*     */   }
/*     */   
/*     */   static class AccordionFocusModel
/*     */     extends FocusModel<TitledPane> {
/*     */     private final Accordion accordion;
/*     */     
/* 247 */     private final ChangeListener<Boolean> focusListener = new ChangeListener<Boolean>()
/*     */       {
/*     */         public void changed(ObservableValue<? extends Boolean> param2ObservableValue, Boolean param2Boolean1, Boolean param2Boolean2) {
/* 250 */           if (param2Boolean2.booleanValue()) {
/* 251 */             if (AccordionBehavior.AccordionFocusModel.this.accordion.getExpandedPane() != null) {
/* 252 */               AccordionBehavior.AccordionFocusModel.this.accordion.getExpandedPane().requestFocus();
/*     */ 
/*     */ 
/*     */             
/*     */             }
/* 257 */             else if (!AccordionBehavior.AccordionFocusModel.this.accordion.getPanes().isEmpty()) {
/* 258 */               ((TitledPane)AccordionBehavior.AccordionFocusModel.this.accordion.getPanes().get(0)).requestFocus();
/*     */             } 
/*     */           }
/*     */         }
/*     */       };
/*     */     
/* 264 */     private final ChangeListener<Boolean> paneFocusListener = new ChangeListener<Boolean>() {
/*     */         public void changed(ObservableValue<? extends Boolean> param2ObservableValue, Boolean param2Boolean1, Boolean param2Boolean2) {
/* 266 */           if (param2Boolean2.booleanValue()) {
/* 267 */             ReadOnlyBooleanProperty readOnlyBooleanProperty = (ReadOnlyBooleanProperty)param2ObservableValue;
/* 268 */             TitledPane titledPane = (TitledPane)readOnlyBooleanProperty.getBean();
/* 269 */             AccordionBehavior.AccordionFocusModel.this.focus(AccordionBehavior.AccordionFocusModel.this.accordion.getPanes().indexOf(titledPane));
/*     */           } 
/*     */         }
/*     */       }; private final ListChangeListener<TitledPane> panesListener; public AccordionFocusModel(Accordion param1Accordion) {
/* 273 */       this.panesListener = (param1Change -> {
/*     */           while (param1Change.next()) {
/*     */             if (param1Change.wasAdded()) {
/*     */               for (TitledPane titledPane : param1Change.getAddedSubList()) {
/*     */                 titledPane.focusedProperty().addListener(this.paneFocusListener);
/*     */               }
/*     */               continue;
/*     */             } 
/*     */             if (param1Change.wasRemoved()) {
/*     */               for (TitledPane titledPane : param1Change.getAddedSubList()) {
/*     */                 titledPane.focusedProperty().removeListener(this.paneFocusListener);
/*     */               }
/*     */             }
/*     */           } 
/*     */         });
/* 288 */       if (param1Accordion == null) {
/* 289 */         throw new IllegalArgumentException("Accordion can not be null");
/*     */       }
/* 291 */       this.accordion = param1Accordion;
/* 292 */       this.accordion.focusedProperty().addListener(this.focusListener);
/* 293 */       this.accordion.getPanes().addListener(this.panesListener);
/* 294 */       for (TitledPane titledPane : this.accordion.getPanes()) {
/* 295 */         titledPane.focusedProperty().addListener(this.paneFocusListener);
/*     */       }
/*     */     }
/*     */     
/*     */     void dispose() {
/* 300 */       this.accordion.focusedProperty().removeListener(this.focusListener);
/* 301 */       this.accordion.getPanes().removeListener(this.panesListener);
/* 302 */       for (TitledPane titledPane : this.accordion.getPanes()) {
/* 303 */         titledPane.focusedProperty().removeListener(this.paneFocusListener);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getItemCount() {
/* 309 */       ObservableList<TitledPane> observableList = this.accordion.getPanes();
/* 310 */       return (observableList == null) ? 0 : observableList.size();
/*     */     }
/*     */ 
/*     */     
/*     */     protected TitledPane getModelItem(int param1Int) {
/* 315 */       ObservableList<TitledPane> observableList = this.accordion.getPanes();
/* 316 */       if (observableList == null) return null; 
/* 317 */       if (param1Int < 0) return null; 
/* 318 */       return observableList.get(param1Int % observableList.size());
/*     */     }
/*     */     
/*     */     public void focusPrevious() {
/* 322 */       if (getFocusedIndex() <= 0) {
/* 323 */         focus(this.accordion.getPanes().size() - 1);
/*     */       } else {
/* 325 */         focus((getFocusedIndex() - 1) % this.accordion.getPanes().size());
/*     */       } 
/*     */     }
/*     */     
/*     */     public void focusNext() {
/* 330 */       if (getFocusedIndex() == -1) {
/* 331 */         focus(0);
/*     */       } else {
/* 333 */         focus((getFocusedIndex() + 1) % this.accordion.getPanes().size());
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\AccordionBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */