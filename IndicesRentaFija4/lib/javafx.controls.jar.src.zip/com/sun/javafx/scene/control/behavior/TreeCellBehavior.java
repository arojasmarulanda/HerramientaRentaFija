/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Cell;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.FocusModel;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.control.TreeCell;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeView;
/*     */ import javafx.scene.input.MouseButton;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeCellBehavior<T>
/*     */   extends CellBehaviorBase<TreeCell<T>>
/*     */ {
/*     */   public TreeCellBehavior(TreeCell<T> paramTreeCell) {
/*  45 */     super(paramTreeCell);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MultipleSelectionModel<TreeItem<T>> getSelectionModel() {
/*  58 */     return getCellContainer().getSelectionModel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected FocusModel<TreeItem<T>> getFocusModel() {
/*  63 */     return getCellContainer().getFocusModel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TreeView<T> getCellContainer() {
/*  68 */     return getNode().getTreeView();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void edit(TreeCell<T> paramTreeCell) {
/*  73 */     TreeItem<T> treeItem = (paramTreeCell == null) ? null : paramTreeCell.getTreeItem();
/*  74 */     getCellContainer().edit(treeItem);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleClicks(MouseButton paramMouseButton, int paramInt, boolean paramBoolean) {
/*  80 */     TreeItem<T> treeItem = getNode().getTreeItem();
/*  81 */     if (paramMouseButton == MouseButton.PRIMARY) {
/*  82 */       if (paramInt == 1 && paramBoolean) {
/*  83 */         edit(getNode());
/*  84 */       } else if (paramInt == 1) {
/*     */         
/*  86 */         edit((TreeCell<T>)null);
/*  87 */       } else if (paramInt == 2 && treeItem.isLeaf()) {
/*     */         
/*  89 */         edit(getNode());
/*  90 */       } else if (paramInt % 2 == 0) {
/*     */         
/*  92 */         treeItem.setExpanded(!treeItem.isExpanded());
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean handleDisclosureNode(double paramDouble1, double paramDouble2) {
/*  98 */     TreeCell<T> treeCell = getNode();
/*  99 */     Node node = treeCell.getDisclosureNode();
/* 100 */     if (node != null && 
/* 101 */       node.getBoundsInParent().contains(paramDouble1, paramDouble2)) {
/* 102 */       if (treeCell.getTreeItem() != null) {
/* 103 */         treeCell.getTreeItem().setExpanded(!treeCell.getTreeItem().isExpanded());
/*     */       }
/* 105 */       return true;
/*     */     } 
/*     */     
/* 108 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TreeCellBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */