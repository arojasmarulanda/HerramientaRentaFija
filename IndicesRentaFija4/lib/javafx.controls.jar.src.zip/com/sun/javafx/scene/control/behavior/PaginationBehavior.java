/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*    */ import javafx.scene.control.Pagination;
/*    */ import javafx.scene.input.KeyCode;
/*    */ import javafx.scene.input.KeyEvent;
/*    */ import javafx.scene.input.MouseEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PaginationBehavior
/*    */   extends BehaviorBase<Pagination>
/*    */ {
/*    */   private final InputMap<Pagination> paginationInputMap;
/*    */   
/*    */   public PaginationBehavior(Pagination paramPagination) {
/* 41 */     super(paramPagination);
/*    */ 
/*    */ 
/*    */     
/* 45 */     this.paginationInputMap = createInputMap();
/*    */ 
/*    */     
/* 48 */     addDefaultMapping(this.paginationInputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> rtl(paramPagination, this::right, this::left)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> rtl(paramPagination, this::left, this::right)), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed) });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InputMap<Pagination> getInputMap() {
/* 56 */     return this.paginationInputMap;
/*    */   }
/*    */   
/*    */   public void mousePressed(MouseEvent paramMouseEvent) {
/* 60 */     getNode().requestFocus();
/*    */   }
/*    */   
/*    */   private void left() {
/* 64 */     movePage(-1);
/*    */   }
/*    */   
/*    */   private void right() {
/* 68 */     movePage(1);
/*    */   }
/*    */   
/*    */   private void movePage(int paramInt) {
/* 72 */     Pagination pagination = getNode();
/* 73 */     int i = pagination.getCurrentPageIndex();
/* 74 */     pagination.setCurrentPageIndex(i + paramInt);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\PaginationBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */