/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.scene.control.IndexedCell;
/*     */ import javafx.scene.control.ScrollBar;
/*     */ import javafx.scene.control.skin.VirtualFlow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VirtualScrollBar
/*     */   extends ScrollBar
/*     */ {
/*     */   private final VirtualFlow flow;
/*     */   private boolean adjusting;
/*     */   private BooleanProperty virtual;
/*     */   
/*     */   public VirtualScrollBar(VirtualFlow paramVirtualFlow) {
/*  86 */     this.virtual = new SimpleBooleanProperty(this, "virtual"); this.flow = paramVirtualFlow; valueProperty().addListener(paramObservable -> { if (isVirtual() && !this.adjusting)
/*     */             paramVirtualFlow.setPosition(getValue()); 
/*  88 */         }); } public final void setVirtual(boolean paramBoolean) { this.virtual.set(paramBoolean); }
/*     */ 
/*     */   
/*     */   public final boolean isVirtual() {
/*  92 */     return this.virtual.get();
/*     */   }
/*     */   
/*     */   public final BooleanProperty virtualProperty() {
/*  96 */     return this.virtual;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decrement() {
/* 108 */     if (isVirtual()) {
/* 109 */       this.flow.scrollPixels(-10.0D);
/*     */     } else {
/* 111 */       super.decrement();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void increment() {
/* 117 */     if (isVirtual()) {
/* 118 */       this.flow.scrollPixels(10.0D);
/*     */     } else {
/* 120 */       super.increment();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustValue(double paramDouble) {
/* 129 */     if (isVirtual()) {
/* 130 */       this.adjusting = true;
/* 131 */       double d1 = this.flow.getPosition();
/*     */       
/* 133 */       double d2 = (getMax() - getMin()) * Utils.clamp(0.0D, paramDouble, 1.0D) + getMin();
/* 134 */       if (d2 < d1) {
/* 135 */         IndexedCell indexedCell = this.flow.getFirstVisibleCell();
/* 136 */         if (indexedCell == null)
/* 137 */           return;  this.flow.scrollToBottom(indexedCell);
/* 138 */       } else if (d2 > d1) {
/* 139 */         IndexedCell indexedCell = this.flow.getLastVisibleCell();
/* 140 */         if (indexedCell == null)
/* 141 */           return;  this.flow.scrollToTop(indexedCell);
/*     */       } 
/*     */       
/* 144 */       this.adjusting = false;
/*     */     } else {
/* 146 */       super.adjustValue(paramDouble);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\VirtualScrollBar.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */