/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import com.sun.javafx.collections.NonIterableChange;
/*    */ import javafx.collections.FXCollections;
/*    */ import javafx.scene.control.TreeItem;
/*    */ import javafx.scene.control.TreeTableView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TreeTableViewBackingList<T>
/*    */   extends ReadOnlyUnbackedObservableList<TreeItem<T>>
/*    */ {
/*    */   private final TreeTableView<T> treeTable;
/* 41 */   private int size = -1;
/*    */   
/*    */   public TreeTableViewBackingList(TreeTableView<T> paramTreeTableView) {
/* 44 */     this.treeTable = paramTreeTableView;
/*    */   }
/*    */   
/*    */   public void resetSize() {
/* 48 */     int i = this.size;
/* 49 */     this.size = -1;
/*    */ 
/*    */     
/* 52 */     callObservers(new NonIterableChange.GenericAddRemoveChange<>(0, i, FXCollections.emptyObservableList(), this));
/*    */   }
/*    */   
/*    */   public TreeItem<T> get(int paramInt) {
/* 56 */     return this.treeTable.getTreeItem(paramInt);
/*    */   }
/*    */   
/*    */   public int size() {
/* 60 */     if (this.size == -1) {
/* 61 */       this.size = this.treeTable.getExpandedItemCount();
/*    */     }
/* 63 */     return this.size;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\TreeTableViewBackingList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */