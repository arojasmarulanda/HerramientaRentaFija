/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import javafx.scene.control.ColorPicker;
/*    */ import javafx.scene.control.PopupControl;
/*    */ import javafx.scene.paint.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColorPickerBehavior
/*    */   extends ComboBoxBaseBehavior<Color>
/*    */ {
/*    */   public ColorPickerBehavior(ColorPicker paramColorPicker) {
/* 45 */     super(paramColorPicker);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAutoHide(PopupControl paramPopupControl) {
/* 57 */     if (!paramPopupControl.isShowing() && getNode().isShowing())
/*    */     {
/*    */       
/* 60 */       getNode().hide();
/*    */     }
/*    */ 
/*    */     
/* 64 */     if (!getNode().isShowing())
/* 65 */       super.onAutoHide(paramPopupControl); 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ColorPickerBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */