/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.geom.transform.Affine3D;
/*     */ import com.sun.javafx.scene.control.Properties;
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import com.sun.javafx.stage.WindowHelper;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.util.function.Predicate;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.event.Event;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.Rectangle2D;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.TextArea;
/*     */ import javafx.scene.control.skin.TextAreaSkin;
/*     */ import javafx.scene.control.skin.TextInputControlSkin;
/*     */ import javafx.scene.input.ContextMenuEvent;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.text.HitInfo;
/*     */ import javafx.stage.Screen;
/*     */ import javafx.stage.Window;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextAreaBehavior
/*     */   extends TextInputControlBehavior<TextArea>
/*     */ {
/*     */   private TextAreaSkin skin;
/*     */   private TwoLevelFocusBehavior tlFocus;
/*     */   private boolean focusGainedByMouseClick;
/*     */   private boolean shiftDown;
/*     */   private boolean deferClick;
/*     */   
/*     */   public void dispose() {
/*     */     if (this.tlFocus != null)
/*     */       this.tlFocus.dispose(); 
/*     */     super.dispose();
/*     */   }
/*     */   
/*     */   public void setTextAreaSkin(TextAreaSkin paramTextAreaSkin) {
/*     */     this.skin = paramTextAreaSkin;
/*     */   }
/*     */   
/*     */   private void insertNewLine() {
/*     */     setEditing(true);
/*     */     getNode().replaceSelection("\n");
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   private void insertTab() {
/*     */     setEditing(true);
/*     */     getNode().replaceSelection("\t");
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   public TextAreaBehavior(TextArea paramTextArea) {
/*  73 */     super(paramTextArea);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 250 */     this.focusGainedByMouseClick = false;
/* 251 */     this.shiftDown = false;
/* 252 */     this.deferClick = false; if (Properties.IS_TOUCH_SUPPORTED) this.contextMenu.getStyleClass().add("text-input-context-menu");  Predicate<KeyEvent> predicate = paramKeyEvent -> !paramTextArea.isEditable(); InputMap<TextArea> inputMap = new InputMap(paramTextArea); inputMap.getMappings().addAll(new InputMap.Mapping[] { (InputMap.Mapping)keyMapping(KeyCode.HOME, paramKeyEvent -> lineStart(false)), (InputMap.Mapping)keyMapping(KeyCode.END, paramKeyEvent -> lineEnd(false)), (InputMap.Mapping)keyMapping(KeyCode.UP, paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.LINE, TextInputControlSkin.Direction.UP, false)), (InputMap.Mapping)keyMapping(KeyCode.DOWN, paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.LINE, TextInputControlSkin.Direction.DOWN, false)), (InputMap.Mapping)keyMapping(KeyCode.PAGE_UP, paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PAGE, TextInputControlSkin.Direction.UP, false)), (InputMap.Mapping)keyMapping(KeyCode.PAGE_DOWN, paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PAGE, TextInputControlSkin.Direction.DOWN, false)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.HOME)).shift(), paramKeyEvent -> lineStart(true)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.END)).shift(), paramKeyEvent -> lineEnd(true)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.UP)).shift(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.LINE, TextInputControlSkin.Direction.UP, true)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.DOWN)).shift(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.LINE, TextInputControlSkin.Direction.DOWN, true)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.PAGE_UP)).shift(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PAGE, TextInputControlSkin.Direction.UP, true)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.PAGE_DOWN)).shift(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PAGE, TextInputControlSkin.Direction.DOWN, true)), (InputMap.Mapping)keyMapping(new KeyBinding(KeyCode.ENTER), paramKeyEvent -> insertNewLine(), predicate), (InputMap.Mapping)keyMapping(new KeyBinding(KeyCode.TAB), paramKeyEvent -> insertTab(), predicate) }); addDefaultChildMap(getInputMap(), inputMap); InputMap inputMap1 = new InputMap(paramTextArea); inputMap1.setInterceptor(paramEvent -> !PlatformUtil.isMac()); inputMap1.getMappings().addAll(new InputMap.Mapping[] { 
/*     */           (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.LEFT)).shortcut(), paramKeyEvent -> lineStart(false)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.RIGHT)).shortcut(), paramKeyEvent -> lineEnd(false)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.UP)).shortcut(), paramKeyEvent -> paramTextArea.home()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.DOWN)).shortcut(), paramKeyEvent -> paramTextArea.end()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.LEFT)).shortcut().shift(), paramKeyEvent -> lineStart(true)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.RIGHT)).shortcut().shift(), paramKeyEvent -> lineEnd(true)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.UP)).shortcut().shift(), paramKeyEvent -> selectHomeExtend()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.DOWN)).shortcut().shift(), paramKeyEvent -> selectEndExtend()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.UP)).alt(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PARAGRAPH, TextInputControlSkin.Direction.UP, false)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.DOWN)).alt(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PARAGRAPH, TextInputControlSkin.Direction.DOWN, false)), 
/*     */           (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.UP)).alt().shift(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PARAGRAPH, TextInputControlSkin.Direction.UP, true)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.DOWN)).alt().shift(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PARAGRAPH, TextInputControlSkin.Direction.DOWN, true)) }); addDefaultChildMap(inputMap, inputMap1); InputMap inputMap2 = new InputMap(paramTextArea); inputMap2.setInterceptor(paramEvent -> PlatformUtil.isMac()); inputMap2.getMappings().addAll(new InputMap.Mapping[] { (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.UP)).ctrl(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PARAGRAPH, TextInputControlSkin.Direction.UP, false)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.DOWN)).ctrl(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PARAGRAPH, TextInputControlSkin.Direction.DOWN, false)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.UP)).ctrl().shift(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PARAGRAPH, TextInputControlSkin.Direction.UP, true)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.DOWN)).ctrl().shift(), paramKeyEvent -> this.skin.moveCaret(TextInputControlSkin.TextUnit.PARAGRAPH, TextInputControlSkin.Direction.DOWN, true)) }); addDefaultChildMap(inputMap, inputMap2); addKeyPadMappings(inputMap); paramTextArea.focusedProperty().addListener(new ChangeListener<Boolean>() { public void changed(ObservableValue<? extends Boolean> param1ObservableValue, Boolean param1Boolean1, Boolean param1Boolean2) { TextArea textArea = TextAreaBehavior.this.getNode(); if (textArea.isFocused()) { if (PlatformUtil.isIOS()) { Bounds bounds = textArea.getBoundsInParent(); double d1 = bounds.getWidth(); double d2 = bounds.getHeight(); Affine3D affine3D = TextFieldBehavior.calculateNodeToSceneTransform(textArea); String str = textArea.textProperty().getValueSafe(); WindowHelper.getPeer(textArea.getScene().getWindow()).requestInput(str, TextFieldBehavior.TextInputTypes.TEXT_AREA.ordinal(), d1, d2, affine3D.getMxx(), affine3D.getMxy(), affine3D.getMxz(), affine3D.getMxt(), affine3D.getMyx(), affine3D.getMyy(), affine3D.getMyz(), affine3D.getMyt(), affine3D.getMzx(), affine3D.getMzy(), affine3D.getMzz(), affine3D.getMzt()); }  if (!TextAreaBehavior.this.focusGainedByMouseClick) TextAreaBehavior.this.setCaretAnimating(true);  } else { if (PlatformUtil.isIOS() && textArea.getScene() != null) WindowHelper.getPeer(textArea.getScene().getWindow()).releaseInput();  TextAreaBehavior.this.focusGainedByMouseClick = false; TextAreaBehavior.this.setCaretAnimating(false); }  } }); if (Utils.isTwoLevelFocus()) this.tlFocus = new TwoLevelFocusBehavior(paramTextArea); 
/* 255 */   } public void mousePressed(MouseEvent paramMouseEvent) { TextArea textArea = getNode();
/*     */     
/* 257 */     if (!textArea.isDisabled())
/*     */     
/*     */     { 
/*     */ 
/*     */       
/* 262 */       if (!textArea.isFocused()) {
/* 263 */         this.focusGainedByMouseClick = true;
/* 264 */         textArea.requestFocus();
/*     */       } 
/*     */ 
/*     */       
/* 268 */       setCaretAnimating(false);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 273 */       if (paramMouseEvent.getButton() == MouseButton.PRIMARY && !paramMouseEvent.isMiddleButtonDown() && !paramMouseEvent.isSecondaryButtonDown()) {
/* 274 */         HitInfo hitInfo = this.skin.getIndex(paramMouseEvent.getX(), paramMouseEvent.getY());
/* 275 */         int i = hitInfo.getInsertionIndex();
/* 276 */         int j = textArea.getAnchor();
/* 277 */         int k = textArea.getCaretPosition();
/* 278 */         if (paramMouseEvent.getClickCount() < 2 && (paramMouseEvent
/* 279 */           .isSynthesized() || (j != k && ((i > j && i < k) || (i < j && i > k))))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 288 */           this.deferClick = true;
/*     */ 
/*     */         
/*     */         }
/* 292 */         else if (!paramMouseEvent.isControlDown() && !paramMouseEvent.isAltDown() && !paramMouseEvent.isShiftDown() && !paramMouseEvent.isMetaDown() && !paramMouseEvent.isShortcutDown()) {
/* 293 */           switch (paramMouseEvent.getClickCount()) { case 1:
/* 294 */               this.skin.positionCaret(hitInfo, false); break;
/* 295 */             case 2: mouseDoubleClick(hitInfo); break;
/* 296 */             case 3: mouseTripleClick(hitInfo);
/*     */               break; }
/*     */         
/* 299 */         } else if (paramMouseEvent.isShiftDown() && !paramMouseEvent.isControlDown() && !paramMouseEvent.isAltDown() && !paramMouseEvent.isMetaDown() && !paramMouseEvent.isShortcutDown() && paramMouseEvent.getClickCount() == 1) {
/*     */           
/* 301 */           this.shiftDown = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 308 */           if (PlatformUtil.isMac()) {
/* 309 */             textArea.extendSelection(i);
/*     */           } else {
/* 311 */             this.skin.positionCaret(hitInfo, true);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 318 */       if (this.contextMenu.isShowing())
/* 319 */         this.contextMenu.hide();  }  } protected void deleteChar(boolean paramBoolean) { if (paramBoolean) { getNode().deletePreviousChar(); } else { getNode().deleteNextChar(); }  }
/*     */   protected void deleteFromLineStart() { TextArea textArea = getNode(); int i = textArea.getCaretPosition(); if (i > 0) { lineStart(false); int j = textArea.getCaretPosition(); if (i > j)
/*     */         replaceText(j, i, "");  }  }
/*     */   private void lineStart(boolean paramBoolean) { this.skin.moveCaret(TextInputControlSkin.TextUnit.LINE, TextInputControlSkin.Direction.BEGINNING, paramBoolean); }
/*     */   private void lineEnd(boolean paramBoolean) { this.skin.moveCaret(TextInputControlSkin.TextUnit.LINE, TextInputControlSkin.Direction.END, paramBoolean); }
/*     */   protected void replaceText(int paramInt1, int paramInt2, String paramString) { getNode().replaceText(paramInt1, paramInt2, paramString); }
/* 325 */   public void mouseDragged(MouseEvent paramMouseEvent) { TextArea textArea = getNode();
/*     */ 
/*     */     
/* 328 */     if (!textArea.isDisabled() && !paramMouseEvent.isSynthesized() && 
/* 329 */       paramMouseEvent.getButton() == MouseButton.PRIMARY && 
/* 330 */       !paramMouseEvent.isMiddleButtonDown() && !paramMouseEvent.isSecondaryButtonDown() && 
/* 331 */       !paramMouseEvent.isControlDown() && !paramMouseEvent.isAltDown() && !paramMouseEvent.isShiftDown() && !paramMouseEvent.isMetaDown()) {
/* 332 */       this.skin.positionCaret(this.skin.getIndex(paramMouseEvent.getX(), paramMouseEvent.getY()), true);
/*     */     }
/*     */     
/* 335 */     this.deferClick = false; }
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent paramMouseEvent) {
/* 339 */     TextArea textArea = getNode();
/*     */ 
/*     */     
/* 342 */     if (!textArea.isDisabled()) {
/* 343 */       setCaretAnimating(false);
/* 344 */       if (this.deferClick) {
/* 345 */         this.deferClick = false;
/* 346 */         this.skin.positionCaret(this.skin.getIndex(paramMouseEvent.getX(), paramMouseEvent.getY()), this.shiftDown);
/* 347 */         this.shiftDown = false;
/*     */       } 
/* 349 */       setCaretAnimating(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void contextMenuRequested(ContextMenuEvent paramContextMenuEvent) {
/* 354 */     TextArea textArea = getNode();
/*     */     
/* 356 */     if (this.contextMenu.isShowing()) {
/* 357 */       this.contextMenu.hide();
/* 358 */     } else if (textArea.getContextMenu() == null && textArea
/* 359 */       .getOnContextMenuRequested() == null) {
/* 360 */       double d1 = paramContextMenuEvent.getScreenX();
/* 361 */       double d2 = paramContextMenuEvent.getScreenY();
/* 362 */       double d3 = paramContextMenuEvent.getSceneX();
/*     */       
/* 364 */       if (Properties.IS_TOUCH_SUPPORTED) {
/*     */         Point2D point2D;
/* 366 */         if (textArea.getSelection().getLength() == 0) {
/* 367 */           this.skin.positionCaret(this.skin.getIndex(paramContextMenuEvent.getX(), paramContextMenuEvent.getY()), false);
/* 368 */           point2D = this.skin.getMenuPosition();
/*     */         } else {
/* 370 */           point2D = this.skin.getMenuPosition();
/* 371 */           if (point2D != null && (point2D.getX() <= 0.0D || point2D.getY() <= 0.0D)) {
/* 372 */             this.skin.positionCaret(this.skin.getIndex(paramContextMenuEvent.getX(), paramContextMenuEvent.getY()), false);
/* 373 */             point2D = this.skin.getMenuPosition();
/*     */           } 
/*     */         } 
/*     */         
/* 377 */         if (point2D != null) {
/* 378 */           Point2D point2D1 = getNode().localToScene(point2D);
/* 379 */           Scene scene = getNode().getScene();
/* 380 */           Window window = scene.getWindow();
/*     */           
/* 382 */           Point2D point2D2 = new Point2D(window.getX() + scene.getX() + point2D1.getX(), window.getY() + scene.getY() + point2D1.getY());
/* 383 */           d1 = point2D2.getX();
/* 384 */           d3 = point2D1.getX();
/* 385 */           d2 = point2D2.getY();
/*     */         } 
/*     */       } 
/*     */       
/* 389 */       populateContextMenu();
/* 390 */       double d4 = this.contextMenu.prefWidth(-1.0D);
/* 391 */       double d5 = d1 - (Properties.IS_TOUCH_SUPPORTED ? (d4 / 2.0D) : 0.0D);
/* 392 */       Screen screen = Utils.getScreenForPoint(d1, 0.0D);
/* 393 */       Rectangle2D rectangle2D = screen.getBounds();
/*     */       
/* 395 */       if (d5 < rectangle2D.getMinX()) {
/* 396 */         getNode().getProperties().put("CONTEXT_MENU_SCREEN_X", Double.valueOf(d1));
/* 397 */         getNode().getProperties().put("CONTEXT_MENU_SCENE_X", Double.valueOf(d3));
/* 398 */         this.contextMenu.show(getNode(), rectangle2D.getMinX(), d2);
/* 399 */       } else if (d1 + d4 > rectangle2D.getMaxX()) {
/* 400 */         double d = d4 - rectangle2D.getMaxX() - d1;
/* 401 */         getNode().getProperties().put("CONTEXT_MENU_SCREEN_X", Double.valueOf(d1));
/* 402 */         getNode().getProperties().put("CONTEXT_MENU_SCENE_X", Double.valueOf(d3));
/* 403 */         this.contextMenu.show(getNode(), d1 - d, d2);
/*     */       } else {
/* 405 */         getNode().getProperties().put("CONTEXT_MENU_SCREEN_X", Integer.valueOf(0));
/* 406 */         getNode().getProperties().put("CONTEXT_MENU_SCENE_X", Integer.valueOf(0));
/* 407 */         this.contextMenu.show(getNode(), d5, d2);
/*     */       } 
/*     */     } 
/*     */     
/* 411 */     paramContextMenuEvent.consume();
/*     */   }
/*     */   
/*     */   protected void setCaretAnimating(boolean paramBoolean) {
/* 415 */     this.skin.setCaretAnimating(paramBoolean);
/*     */   }
/*     */   
/*     */   protected void mouseDoubleClick(HitInfo paramHitInfo) {
/* 419 */     TextArea textArea = getNode();
/* 420 */     textArea.previousWord();
/* 421 */     if (PlatformUtil.isWindows()) {
/* 422 */       textArea.selectNextWord();
/*     */     } else {
/* 424 */       textArea.selectEndOfNextWord();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void mouseTripleClick(HitInfo paramHitInfo) {
/* 430 */     this.skin.moveCaret(TextInputControlSkin.TextUnit.PARAGRAPH, TextInputControlSkin.Direction.BEGINNING, false);
/* 431 */     this.skin.moveCaret(TextInputControlSkin.TextUnit.PARAGRAPH, TextInputControlSkin.Direction.END, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TextAreaBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */