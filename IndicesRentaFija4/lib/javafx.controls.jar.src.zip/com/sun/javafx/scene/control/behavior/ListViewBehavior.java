/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*     */ import com.sun.javafx.scene.control.skin.Utils;
/*     */ import java.util.ArrayList;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.beans.value.WeakChangeListener;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.control.FocusModel;
/*     */ import javafx.scene.control.ListCell;
/*     */ import javafx.scene.control.ListView;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.control.SelectionMode;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListViewBehavior<T>
/*     */   extends BehaviorBase<ListView<T>>
/*     */ {
/*     */   private final InputMap<ListView<T>> listViewInputMap;
/*     */   private final EventHandler<KeyEvent> keyEventListener;
/*     */   private boolean isShiftDown;
/*     */   private boolean isShortcutDown;
/*     */   private Callback<Boolean, Integer> onScrollPageUp;
/*     */   private Callback<Boolean, Integer> onScrollPageDown;
/*     */   private Runnable onFocusPreviousRow;
/*     */   private Runnable onFocusNextRow;
/*     */   private Runnable onSelectPreviousRow;
/*     */   private Runnable onSelectNextRow;
/*     */   private Runnable onMoveToFirstCell;
/*     */   private Runnable onMoveToLastCell;
/*     */   private boolean selectionChanging;
/*     */   private final ListChangeListener<Integer> selectedIndicesListener;
/*     */   private final ListChangeListener<T> itemsListListener;
/*     */   private final ChangeListener<ObservableList<T>> itemsListener;
/*     */   private final ChangeListener<MultipleSelectionModel<T>> selectionModelListener;
/*     */   private final WeakChangeListener<ObservableList<T>> weakItemsListener;
/*     */   private final WeakListChangeListener<Integer> weakSelectedIndicesListener;
/*     */   private final WeakListChangeListener<T> weakItemsListListener;
/*     */   private final WeakChangeListener<MultipleSelectionModel<T>> weakSelectionModelListener;
/*     */   private TwoLevelFocusListBehavior tlFocus;
/*     */   
/*     */   public ListViewBehavior(ListView<T> paramListView) {
/*  75 */     super(paramListView);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.keyEventListener = (paramKeyEvent -> {
/*     */         if (!paramKeyEvent.isConsumed()) {
/*     */           this.isShiftDown = (paramKeyEvent.getEventType() == KeyEvent.KEY_PRESSED && paramKeyEvent.isShiftDown());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.isShortcutDown = (paramKeyEvent.getEventType() == KeyEvent.KEY_PRESSED && paramKeyEvent.isShortcutDown());
/*     */         } 
/*     */       });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     this.isShiftDown = false;
/* 231 */     this.isShortcutDown = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 251 */     this.selectionChanging = false;
/*     */     
/* 253 */     this.selectedIndicesListener = (paramChange -> {
/*     */         int i = getAnchor();
/*     */ 
/*     */         
/*     */         while (paramChange.next()) {
/*     */           if (paramChange.wasReplaced() && ListCellBehavior.hasDefaultAnchor(getNode())) {
/*     */             ListCellBehavior.removeAnchor(getNode());
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */ 
/*     */           
/*     */           byte b = paramChange.wasPermutated() ? (paramChange.getTo() - paramChange.getFrom()) : 0;
/*     */           
/*     */           MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/*     */           
/*     */           if (!this.selectionChanging) {
/*     */             if (multipleSelectionModel.isEmpty()) {
/*     */               i = -1;
/*     */             } else if (hasAnchor() && !multipleSelectionModel.isSelected(getAnchor() + b)) {
/*     */               i = -1;
/*     */             } 
/*     */           }
/*     */           
/*     */           if (i == -1) {
/*     */             int j = paramChange.getAddedSize();
/*     */             
/*     */             i = (j > 0) ? ((Integer)paramChange.getAddedSubList().get(j - 1)).intValue() : i;
/*     */           } 
/*     */         } 
/*     */         
/*     */         if (i > -1) {
/*     */           setAnchor(i);
/*     */         }
/*     */       });
/*     */     
/* 290 */     this.itemsListListener = (paramChange -> {
/*     */         while (paramChange.next()) {
/*     */           if (!hasAnchor()) {
/*     */             continue;
/*     */           }
/*     */           
/*     */           int i = hasAnchor() ? getAnchor() : 0;
/*     */           
/*     */           if (paramChange.wasAdded() && paramChange.getFrom() <= i) {
/*     */             i += paramChange.getAddedSize();
/*     */           } else if (paramChange.wasRemoved() && paramChange.getFrom() <= i) {
/*     */             i -= paramChange.getRemovedSize();
/*     */           } 
/*     */           setAnchor((i < 0) ? 0 : i);
/*     */         } 
/*     */       });
/* 306 */     this.itemsListener = (ChangeListener)new ChangeListener<ObservableList<ObservableList<T>>>()
/*     */       {
/*     */         
/*     */         public void changed(ObservableValue<? extends ObservableList<T>> param1ObservableValue, ObservableList<T> param1ObservableList1, ObservableList<T> param1ObservableList2)
/*     */         {
/* 311 */           if (param1ObservableList1 != null)
/* 312 */             param1ObservableList1.removeListener(ListViewBehavior.this.weakItemsListListener); 
/* 313 */           if (param1ObservableList2 != null) {
/* 314 */             param1ObservableList2.addListener(ListViewBehavior.this.weakItemsListListener);
/*     */           }
/*     */         }
/*     */       };
/*     */     
/* 319 */     this.selectionModelListener = (ChangeListener)new ChangeListener<MultipleSelectionModel<MultipleSelectionModel<T>>>()
/*     */       {
/*     */         
/*     */         public void changed(ObservableValue<? extends MultipleSelectionModel<T>> param1ObservableValue, MultipleSelectionModel<T> param1MultipleSelectionModel1, MultipleSelectionModel<T> param1MultipleSelectionModel2)
/*     */         {
/* 324 */           if (param1MultipleSelectionModel1 != null) {
/* 325 */             param1MultipleSelectionModel1.getSelectedIndices().removeListener(ListViewBehavior.this.weakSelectedIndicesListener);
/*     */           }
/* 327 */           if (param1MultipleSelectionModel2 != null) {
/* 328 */             param1MultipleSelectionModel2.getSelectedIndices().addListener(ListViewBehavior.this.weakSelectedIndicesListener);
/*     */           }
/*     */         }
/*     */       };
/*     */     
/* 333 */     this.weakItemsListener = new WeakChangeListener<>(this.itemsListener);
/*     */     
/* 335 */     this.weakSelectedIndicesListener = new WeakListChangeListener<>(this.selectedIndicesListener);
/*     */     
/* 337 */     this.weakItemsListListener = new WeakListChangeListener<>(this.itemsListListener);
/*     */     
/* 339 */     this.weakSelectionModelListener = new WeakChangeListener<>(this.selectionModelListener); this.listViewInputMap = createInputMap(); addDefaultMapping(this.listViewInputMap, FocusTraversalInputMap.getFocusTraversalMappings()); addDefaultMapping(this.listViewInputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.HOME, paramKeyEvent -> selectFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.END, paramKeyEvent -> selectLastRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.HOME)).shift(), paramKeyEvent -> selectAllToFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.END)).shift(), paramKeyEvent -> selectAllToLastRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP)).shift(), paramKeyEvent -> selectAllPageUp()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN)).shift(), paramKeyEvent -> selectAllPageDown()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE)).shift(), paramKeyEvent -> selectAllToFocus(false)), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE)).shortcut().shift(), paramKeyEvent -> selectAllToFocus(true)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.PAGE_UP, paramKeyEvent -> scrollPageUp()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.PAGE_DOWN, paramKeyEvent -> scrollPageDown()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ENTER, paramKeyEvent -> activate()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, paramKeyEvent -> activate()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.F2, paramKeyEvent -> activate()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ESCAPE, paramKeyEvent -> cancelEdit()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.A)).shortcut(), paramKeyEvent -> selectAll()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.HOME)).shortcut(), paramKeyEvent -> focusFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.END)).shortcut(), paramKeyEvent -> focusLastRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP)).shortcut(), paramKeyEvent -> focusPageUp()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN)).shortcut(), paramKeyEvent -> focusPageDown()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.BACK_SLASH)).shortcut(), paramKeyEvent -> clearSelection()), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed) }); InputMap<ListView<T>> inputMap1 = new InputMap(paramListView); inputMap1.setInterceptor(paramEvent -> !PlatformUtil.isMac()); addDefaultMapping(inputMap1, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE)).shortcut().ctrl(), paramKeyEvent -> toggleFocusOwnerSelection()) }); addDefaultChildMap(this.listViewInputMap, inputMap1); InputMap<ListView<T>> inputMap2 = new InputMap(paramListView); inputMap2.setInterceptor(paramEvent -> PlatformUtil.isMac()); addDefaultMapping(inputMap2, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE)).ctrl(), paramKeyEvent -> toggleFocusOwnerSelection()) }); addDefaultChildMap(this.listViewInputMap, inputMap2); InputMap<ListView<T>> inputMap3 = new InputMap(paramListView); inputMap3.setInterceptor(paramEvent -> (paramListView.getOrientation() != Orientation.VERTICAL)); addDefaultMapping(inputMap3, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> selectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_UP, paramKeyEvent -> selectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> selectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_DOWN, paramKeyEvent -> selectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.UP)).shift(), paramKeyEvent -> alsoSelectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_UP)).shift(), paramKeyEvent -> alsoSelectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN)).shift(), paramKeyEvent -> alsoSelectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_DOWN)).shift(), paramKeyEvent -> alsoSelectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.UP)).shortcut(), paramKeyEvent -> focusPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN)).shortcut(), paramKeyEvent -> focusNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.UP)).shortcut().shift(), paramKeyEvent -> discontinuousSelectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN)).shortcut().shift(), paramKeyEvent -> discontinuousSelectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP)).shortcut().shift(), paramKeyEvent -> discontinuousSelectPageUp()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN)).shortcut().shift(), paramKeyEvent -> discontinuousSelectPageDown()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.HOME)).shortcut().shift(), paramKeyEvent -> discontinuousSelectAllToFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.END)).shortcut().shift(), paramKeyEvent -> discontinuousSelectAllToLastRow()) }); addDefaultChildMap(this.listViewInputMap, inputMap3); InputMap<ListView<T>> inputMap4 = new InputMap(paramListView); inputMap4.setInterceptor(paramEvent -> (paramListView.getOrientation() != Orientation.HORIZONTAL)); addDefaultMapping(inputMap4, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> selectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_LEFT, paramKeyEvent -> selectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> selectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_RIGHT, paramKeyEvent -> selectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.LEFT)).shift(), paramKeyEvent -> alsoSelectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_LEFT)).shift(), paramKeyEvent -> alsoSelectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.RIGHT)).shift(), paramKeyEvent -> alsoSelectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_RIGHT)).shift(), paramKeyEvent -> alsoSelectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.LEFT)).shortcut(), paramKeyEvent -> focusPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.RIGHT)).shortcut(), paramKeyEvent -> focusNextRow()), 
/*     */           (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.LEFT)).shortcut().shift(), paramKeyEvent -> discontinuousSelectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.RIGHT)).shortcut().shift(), paramKeyEvent -> discontinuousSelectNextRow()) }); addDefaultChildMap(this.listViewInputMap, inputMap4); paramListView.addEventFilter(KeyEvent.ANY, this.keyEventListener); paramListView.itemsProperty().addListener(this.weakItemsListener); if (paramListView.getItems() != null) paramListView.getItems().addListener(this.weakItemsListListener);  paramListView.selectionModelProperty().addListener(this.weakSelectionModelListener); if (paramListView.getSelectionModel() != null) paramListView.getSelectionModel().getSelectedIndices().addListener(this.weakSelectedIndicesListener);  if (Utils.isTwoLevelFocus()) this.tlFocus = new TwoLevelFocusListBehavior(paramListView); 
/*     */   }
/*     */   public InputMap<ListView<T>> getInputMap() { return this.listViewInputMap; }
/*     */   public void dispose() { ListView<T> listView = getNode(); ListCellBehavior.removeAnchor(listView); if (this.tlFocus != null) this.tlFocus.dispose();  super.dispose(); listView.removeEventHandler(KeyEvent.ANY, this.keyEventListener); }
/*     */   public void setOnScrollPageUp(Callback<Boolean, Integer> paramCallback) { this.onScrollPageUp = paramCallback; }
/* 345 */   public void setOnScrollPageDown(Callback<Boolean, Integer> paramCallback) { this.onScrollPageDown = paramCallback; } public void setOnFocusPreviousRow(Runnable paramRunnable) { this.onFocusPreviousRow = paramRunnable; } private void setAnchor(int paramInt) { ListCellBehavior.setAnchor(getNode(), (paramInt < 0) ? null : (ListCell<T>)Integer.valueOf(paramInt), false); }
/*     */   public void setOnFocusNextRow(Runnable paramRunnable) { this.onFocusNextRow = paramRunnable; }
/*     */   public void setOnSelectPreviousRow(Runnable paramRunnable) { this.onSelectPreviousRow = paramRunnable; }
/*     */   public void setOnSelectNextRow(Runnable paramRunnable) { this.onSelectNextRow = paramRunnable; }
/* 349 */   public void setOnMoveToFirstCell(Runnable paramRunnable) { this.onMoveToFirstCell = paramRunnable; } public void setOnMoveToLastCell(Runnable paramRunnable) { this.onMoveToLastCell = paramRunnable; } private int getAnchor() { return ((Integer)ListCellBehavior.getAnchor(getNode(), (ListCell<T>)Integer.valueOf(getNode().getFocusModel().getFocusedIndex()))).intValue(); }
/*     */ 
/*     */   
/*     */   private boolean hasAnchor() {
/* 353 */     return ListCellBehavior.hasNonDefaultAnchor(getNode());
/*     */   }
/*     */   
/*     */   private void mousePressed(MouseEvent paramMouseEvent) {
/* 357 */     if (!paramMouseEvent.isShiftDown() && !paramMouseEvent.isSynthesized()) {
/* 358 */       int i = getNode().getSelectionModel().getSelectedIndex();
/* 359 */       setAnchor(i);
/*     */     } 
/*     */     
/* 362 */     if (!getNode().isFocused() && getNode().isFocusTraversable()) {
/* 363 */       getNode().requestFocus();
/*     */     }
/*     */   }
/*     */   
/*     */   private int getRowCount() {
/* 368 */     return (getNode().getItems() == null) ? 0 : getNode().getItems().size();
/*     */   }
/*     */   
/*     */   private void clearSelection() {
/* 372 */     getNode().getSelectionModel().clearSelection();
/*     */   }
/*     */   
/*     */   private void scrollPageUp() {
/* 376 */     int i = -1;
/* 377 */     if (this.onScrollPageUp != null) {
/* 378 */       i = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(false))).intValue();
/*     */     }
/* 380 */     if (i == -1)
/*     */       return; 
/* 382 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 383 */     if (multipleSelectionModel == null)
/* 384 */       return;  multipleSelectionModel.clearAndSelect(i);
/*     */   }
/*     */   
/*     */   private void scrollPageDown() {
/* 388 */     int i = -1;
/* 389 */     if (this.onScrollPageDown != null) {
/* 390 */       i = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(false))).intValue();
/*     */     }
/* 392 */     if (i == -1)
/*     */       return; 
/* 394 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 395 */     if (multipleSelectionModel == null)
/* 396 */       return;  multipleSelectionModel.clearAndSelect(i);
/*     */   }
/*     */   
/*     */   private void focusFirstRow() {
/* 400 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 401 */     if (focusModel == null)
/* 402 */       return;  focusModel.focus(0);
/*     */     
/* 404 */     if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*     */   }
/*     */   
/*     */   private void focusLastRow() {
/* 408 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 409 */     if (focusModel == null)
/* 410 */       return;  focusModel.focus(getRowCount() - 1);
/*     */     
/* 412 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*     */   }
/*     */   
/*     */   private void focusPreviousRow() {
/* 416 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 417 */     if (focusModel == null)
/*     */       return; 
/* 419 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 420 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 422 */     focusModel.focusPrevious();
/*     */     
/* 424 */     if (!this.isShortcutDown || getAnchor() == -1) {
/* 425 */       setAnchor(focusModel.getFocusedIndex());
/*     */     }
/*     */     
/* 428 */     if (this.onFocusPreviousRow != null) this.onFocusPreviousRow.run(); 
/*     */   }
/*     */   
/*     */   private void focusNextRow() {
/* 432 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 433 */     if (focusModel == null)
/*     */       return; 
/* 435 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 436 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 438 */     focusModel.focusNext();
/*     */     
/* 440 */     if (!this.isShortcutDown || getAnchor() == -1) {
/* 441 */       setAnchor(focusModel.getFocusedIndex());
/*     */     }
/*     */     
/* 444 */     if (this.onFocusNextRow != null) this.onFocusNextRow.run(); 
/*     */   }
/*     */   
/*     */   private void focusPageUp() {
/* 448 */     int i = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(true))).intValue();
/*     */     
/* 450 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 451 */     if (focusModel == null)
/* 452 */       return;  focusModel.focus(i);
/*     */   }
/*     */   
/*     */   private void focusPageDown() {
/* 456 */     int i = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(true))).intValue();
/*     */     
/* 458 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 459 */     if (focusModel == null)
/* 460 */       return;  focusModel.focus(i);
/*     */   }
/*     */   
/*     */   private void alsoSelectPreviousRow() {
/* 464 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 465 */     if (focusModel == null)
/*     */       return; 
/* 467 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 468 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 470 */     if (this.isShiftDown && getAnchor() != -1) {
/* 471 */       int i = focusModel.getFocusedIndex() - 1;
/* 472 */       if (i < 0)
/*     */         return; 
/* 474 */       int j = getAnchor();
/*     */       
/* 476 */       if (!hasAnchor()) {
/* 477 */         setAnchor(focusModel.getFocusedIndex());
/*     */       }
/*     */       
/* 480 */       if (multipleSelectionModel.getSelectedIndices().size() > 1) {
/* 481 */         clearSelectionOutsideRange(j, i);
/*     */       }
/*     */       
/* 484 */       if (j > i) {
/* 485 */         multipleSelectionModel.selectRange(j, i - 1);
/*     */       } else {
/* 487 */         multipleSelectionModel.selectRange(j, i + 1);
/*     */       } 
/*     */     } else {
/* 490 */       multipleSelectionModel.selectPrevious();
/*     */     } 
/*     */     
/* 493 */     this.onSelectPreviousRow.run();
/*     */   }
/*     */   
/*     */   private void alsoSelectNextRow() {
/* 497 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 498 */     if (focusModel == null)
/*     */       return; 
/* 500 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 501 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 503 */     if (this.isShiftDown && getAnchor() != -1) {
/* 504 */       int i = focusModel.getFocusedIndex() + 1;
/* 505 */       int j = getAnchor();
/*     */       
/* 507 */       if (!hasAnchor()) {
/* 508 */         setAnchor(focusModel.getFocusedIndex());
/*     */       }
/*     */       
/* 511 */       if (multipleSelectionModel.getSelectedIndices().size() > 1) {
/* 512 */         clearSelectionOutsideRange(j, i);
/*     */       }
/*     */       
/* 515 */       if (j > i) {
/* 516 */         multipleSelectionModel.selectRange(j, i - 1);
/*     */       } else {
/* 518 */         multipleSelectionModel.selectRange(j, i + 1);
/*     */       } 
/*     */     } else {
/* 521 */       multipleSelectionModel.selectNext();
/*     */     } 
/*     */     
/* 524 */     this.onSelectNextRow.run();
/*     */   }
/*     */   
/*     */   private void clearSelectionOutsideRange(int paramInt1, int paramInt2) {
/* 528 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 529 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 531 */     int i = Math.min(paramInt1, paramInt2);
/* 532 */     int j = Math.max(paramInt1, paramInt2);
/*     */     
/* 534 */     ArrayList<Integer> arrayList = new ArrayList<>(multipleSelectionModel.getSelectedIndices());
/*     */     
/* 536 */     this.selectionChanging = true;
/* 537 */     for (byte b = 0; b < arrayList.size(); b++) {
/* 538 */       int k = ((Integer)arrayList.get(b)).intValue();
/* 539 */       if (k < i || k > j) {
/* 540 */         multipleSelectionModel.clearSelection(k);
/*     */       }
/*     */     } 
/* 543 */     this.selectionChanging = false;
/*     */   }
/*     */   
/*     */   private void selectPreviousRow() {
/* 547 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 548 */     if (focusModel == null)
/*     */       return; 
/* 550 */     int i = focusModel.getFocusedIndex();
/* 551 */     if (i <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 555 */     setAnchor(i - 1);
/* 556 */     getNode().getSelectionModel().clearAndSelect(i - 1);
/* 557 */     this.onSelectPreviousRow.run();
/*     */   }
/*     */   
/*     */   private void selectNextRow() {
/* 561 */     ListView<T> listView = getNode();
/* 562 */     FocusModel<T> focusModel = listView.getFocusModel();
/* 563 */     if (focusModel == null)
/*     */       return; 
/* 565 */     int i = focusModel.getFocusedIndex();
/* 566 */     if (i == getRowCount() - 1) {
/*     */       return;
/*     */     }
/*     */     
/* 570 */     MultipleSelectionModel<T> multipleSelectionModel = listView.getSelectionModel();
/* 571 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 573 */     setAnchor(i + 1);
/* 574 */     multipleSelectionModel.clearAndSelect(i + 1);
/* 575 */     if (this.onSelectNextRow != null) this.onSelectNextRow.run(); 
/*     */   }
/*     */   
/*     */   private void selectFirstRow() {
/* 579 */     if (getRowCount() > 0) {
/* 580 */       getNode().getSelectionModel().clearAndSelect(0);
/* 581 */       if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void selectLastRow() {
/* 586 */     getNode().getSelectionModel().clearAndSelect(getRowCount() - 1);
/* 587 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*     */   }
/*     */   
/*     */   private void selectAllPageUp() {
/* 591 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 592 */     if (focusModel == null)
/*     */       return; 
/* 594 */     int i = focusModel.getFocusedIndex();
/* 595 */     if (this.isShiftDown) {
/* 596 */       i = (getAnchor() == -1) ? i : getAnchor();
/* 597 */       setAnchor(i);
/*     */     } 
/*     */     
/* 600 */     int j = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(false))).intValue();
/*     */ 
/*     */     
/* 603 */     byte b = (i < j) ? 1 : -1;
/*     */     
/* 605 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 606 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 608 */     this.selectionChanging = true;
/* 609 */     if (multipleSelectionModel.getSelectionMode() == SelectionMode.SINGLE) {
/* 610 */       multipleSelectionModel.select(j);
/*     */     } else {
/* 612 */       multipleSelectionModel.clearSelection();
/* 613 */       multipleSelectionModel.selectRange(i, j + b);
/*     */     } 
/* 615 */     this.selectionChanging = false;
/*     */   }
/*     */   
/*     */   private void selectAllPageDown() {
/* 619 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 620 */     if (focusModel == null)
/*     */       return; 
/* 622 */     int i = focusModel.getFocusedIndex();
/* 623 */     if (this.isShiftDown) {
/* 624 */       i = (getAnchor() == -1) ? i : getAnchor();
/* 625 */       setAnchor(i);
/*     */     } 
/*     */     
/* 628 */     int j = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(false))).intValue();
/*     */ 
/*     */     
/* 631 */     byte b = (i < j) ? 1 : -1;
/*     */     
/* 633 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 634 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 636 */     this.selectionChanging = true;
/* 637 */     if (multipleSelectionModel.getSelectionMode() == SelectionMode.SINGLE) {
/* 638 */       multipleSelectionModel.select(j);
/*     */     } else {
/* 640 */       multipleSelectionModel.clearSelection();
/* 641 */       multipleSelectionModel.selectRange(i, j + b);
/*     */     } 
/* 643 */     this.selectionChanging = false;
/*     */   }
/*     */   
/*     */   private void selectAllToFirstRow() {
/* 647 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 648 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 650 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 651 */     if (focusModel == null)
/*     */       return; 
/* 653 */     int i = focusModel.getFocusedIndex();
/*     */     
/* 655 */     if (this.isShiftDown) {
/* 656 */       i = hasAnchor() ? getAnchor() : i;
/*     */     }
/*     */     
/* 659 */     multipleSelectionModel.clearSelection();
/* 660 */     multipleSelectionModel.selectRange(i, -1);
/*     */ 
/*     */     
/* 663 */     focusModel.focus(0);
/*     */     
/* 665 */     if (this.isShiftDown) {
/* 666 */       setAnchor(i);
/*     */     }
/*     */     
/* 669 */     if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*     */   }
/*     */   
/*     */   private void selectAllToLastRow() {
/* 673 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 674 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 676 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 677 */     if (focusModel == null)
/*     */       return; 
/* 679 */     int i = focusModel.getFocusedIndex();
/*     */     
/* 681 */     if (this.isShiftDown) {
/* 682 */       i = hasAnchor() ? getAnchor() : i;
/*     */     }
/*     */     
/* 685 */     multipleSelectionModel.clearSelection();
/* 686 */     multipleSelectionModel.selectRange(i, getRowCount());
/*     */     
/* 688 */     if (this.isShiftDown) {
/* 689 */       setAnchor(i);
/*     */     }
/*     */     
/* 692 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*     */   }
/*     */   
/*     */   private void selectAll() {
/* 696 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 697 */     if (multipleSelectionModel == null)
/* 698 */       return;  multipleSelectionModel.selectAll();
/*     */   }
/*     */ 
/*     */   
/*     */   private void selectAllToFocus(boolean paramBoolean) {
/* 703 */     ListView<T> listView = getNode();
/* 704 */     if (listView.getEditingIndex() >= 0)
/*     */       return; 
/* 706 */     MultipleSelectionModel<T> multipleSelectionModel = listView.getSelectionModel();
/* 707 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 709 */     FocusModel<T> focusModel = listView.getFocusModel();
/* 710 */     if (focusModel == null)
/*     */       return; 
/* 712 */     int i = focusModel.getFocusedIndex();
/* 713 */     int j = getAnchor();
/*     */     
/* 715 */     multipleSelectionModel.clearSelection();
/* 716 */     int k = j;
/* 717 */     int m = (j > i) ? (i - 1) : (i + 1);
/* 718 */     multipleSelectionModel.selectRange(k, m);
/* 719 */     setAnchor(paramBoolean ? i : j);
/*     */   }
/*     */   
/*     */   private void cancelEdit() {
/* 723 */     getNode().edit(-1);
/*     */   }
/*     */   
/*     */   private void activate() {
/* 727 */     int i = getNode().getFocusModel().getFocusedIndex();
/* 728 */     getNode().getSelectionModel().select(i);
/* 729 */     setAnchor(i);
/*     */ 
/*     */     
/* 732 */     if (i >= 0) {
/* 733 */       getNode().edit(i);
/*     */     }
/*     */   }
/*     */   
/*     */   private void toggleFocusOwnerSelection() {
/* 738 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 739 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 741 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 742 */     if (focusModel == null)
/*     */       return; 
/* 744 */     int i = focusModel.getFocusedIndex();
/*     */     
/* 746 */     if (multipleSelectionModel.isSelected(i)) {
/* 747 */       multipleSelectionModel.clearSelection(i);
/* 748 */       focusModel.focus(i);
/*     */     } else {
/* 750 */       multipleSelectionModel.select(i);
/*     */     } 
/*     */     
/* 753 */     setAnchor(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void discontinuousSelectPreviousRow() {
/* 761 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 762 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 764 */     if (multipleSelectionModel.getSelectionMode() != SelectionMode.MULTIPLE) {
/* 765 */       selectPreviousRow();
/*     */       
/*     */       return;
/*     */     } 
/* 769 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 770 */     if (focusModel == null)
/*     */       return; 
/* 772 */     int i = focusModel.getFocusedIndex();
/* 773 */     int j = i - 1;
/* 774 */     if (j < 0)
/*     */       return; 
/* 776 */     int k = i;
/* 777 */     if (this.isShiftDown) {
/* 778 */       k = (getAnchor() == -1) ? i : getAnchor();
/*     */     }
/*     */     
/* 781 */     multipleSelectionModel.selectRange(j, k + 1);
/* 782 */     focusModel.focus(j);
/*     */     
/* 784 */     if (this.onFocusPreviousRow != null) this.onFocusPreviousRow.run(); 
/*     */   }
/*     */   
/*     */   private void discontinuousSelectNextRow() {
/* 788 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 789 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 791 */     if (multipleSelectionModel.getSelectionMode() != SelectionMode.MULTIPLE) {
/* 792 */       selectNextRow();
/*     */       
/*     */       return;
/*     */     } 
/* 796 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 797 */     if (focusModel == null)
/*     */       return; 
/* 799 */     int i = focusModel.getFocusedIndex();
/* 800 */     int j = i + 1;
/* 801 */     if (j >= getRowCount())
/*     */       return; 
/* 803 */     int k = i;
/* 804 */     if (this.isShiftDown) {
/* 805 */       k = (getAnchor() == -1) ? i : getAnchor();
/*     */     }
/*     */     
/* 808 */     multipleSelectionModel.selectRange(k, j + 1);
/* 809 */     focusModel.focus(j);
/*     */     
/* 811 */     if (this.onFocusNextRow != null) this.onFocusNextRow.run(); 
/*     */   }
/*     */   
/*     */   private void discontinuousSelectPageUp() {
/* 815 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 816 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 818 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 819 */     if (focusModel == null)
/*     */       return; 
/* 821 */     int i = getAnchor();
/* 822 */     int j = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(false))).intValue();
/* 823 */     multipleSelectionModel.selectRange(i, j - 1);
/*     */   }
/*     */   
/*     */   private void discontinuousSelectPageDown() {
/* 827 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 828 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 830 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 831 */     if (focusModel == null)
/*     */       return; 
/* 833 */     int i = getAnchor();
/* 834 */     int j = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(false))).intValue();
/* 835 */     multipleSelectionModel.selectRange(i, j + 1);
/*     */   }
/*     */   
/*     */   private void discontinuousSelectAllToFirstRow() {
/* 839 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 840 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 842 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 843 */     if (focusModel == null)
/*     */       return; 
/* 845 */     int i = focusModel.getFocusedIndex();
/* 846 */     multipleSelectionModel.selectRange(0, i);
/* 847 */     focusModel.focus(0);
/*     */     
/* 849 */     if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*     */   }
/*     */   
/*     */   private void discontinuousSelectAllToLastRow() {
/* 853 */     MultipleSelectionModel<T> multipleSelectionModel = getNode().getSelectionModel();
/* 854 */     if (multipleSelectionModel == null)
/*     */       return; 
/* 856 */     FocusModel<T> focusModel = getNode().getFocusModel();
/* 857 */     if (focusModel == null)
/*     */       return; 
/* 859 */     int i = focusModel.getFocusedIndex() + 1;
/* 860 */     multipleSelectionModel.selectRange(i, getRowCount());
/*     */     
/* 862 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ListViewBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */