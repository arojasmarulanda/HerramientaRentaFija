/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import com.sun.javafx.scene.control.skin.IntegerFieldSkin;
/*     */ import com.sun.javafx.scene.control.skin.WebColorFieldSkin;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.binding.ObjectBinding;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.Property;
/*     */ import javafx.beans.property.SimpleDoubleProperty;
/*     */ import javafx.beans.property.SimpleIntegerProperty;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Insets;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.geometry.Rectangle2D;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.Button;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.Slider;
/*     */ import javafx.scene.control.Toggle;
/*     */ import javafx.scene.control.ToggleButton;
/*     */ import javafx.scene.control.ToggleGroup;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.Background;
/*     */ import javafx.scene.layout.BackgroundFill;
/*     */ import javafx.scene.layout.ColumnConstraints;
/*     */ import javafx.scene.layout.CornerRadii;
/*     */ import javafx.scene.layout.GridPane;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.scene.layout.Pane;
/*     */ import javafx.scene.layout.Priority;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.RowConstraints;
/*     */ import javafx.scene.layout.StackPane;
/*     */ import javafx.scene.layout.VBox;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.paint.CycleMethod;
/*     */ import javafx.scene.paint.LinearGradient;
/*     */ import javafx.scene.paint.Stop;
/*     */ import javafx.stage.Modality;
/*     */ import javafx.stage.Screen;
/*     */ import javafx.stage.Stage;
/*     */ import javafx.stage.StageStyle;
/*     */ import javafx.stage.Window;
/*     */ import javafx.stage.WindowEvent;
/*     */ 
/*     */ public class CustomColorDialog
/*     */   extends HBox {
/*  60 */   private final Stage dialog = new Stage();
/*     */   
/*     */   private ColorRectPane colorRectPane;
/*     */   private ControlsPane controlsPane;
/*  64 */   private ObjectProperty<Color> currentColorProperty = new SimpleObjectProperty<>(Color.WHITE);
/*  65 */   private ObjectProperty<Color> customColorProperty = new SimpleObjectProperty<>(Color.TRANSPARENT);
/*     */   
/*     */   private Runnable onSave;
/*     */   private Runnable onUse;
/*     */   private Runnable onCancel;
/*  70 */   private WebColorField webField = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Scene customScene;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String saveBtnText;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean showUseBtn = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean showOpacitySlider = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private final EventHandler<KeyEvent> keyEventListener;
/*     */ 
/*     */ 
/*     */   
/*     */   private InvalidationListener positionAdjuster;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildUI() {
/* 103 */     this.colorRectPane = new ColorRectPane();
/* 104 */     this.controlsPane = new ControlsPane();
/* 105 */     setHgrow(this.controlsPane, Priority.ALWAYS);
/* 106 */     getChildren().setAll(new Node[] { this.colorRectPane, this.controlsPane });
/*     */   }
/*     */   
/* 109 */   public CustomColorDialog(Window paramWindow) { this.keyEventListener = (paramKeyEvent -> {
/*     */         switch (paramKeyEvent.getCode()) {
/*     */           case ESCAPE:
/*     */             this.dialog.setScene((Scene)null);
/*     */             this.dialog.close();
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       });
/* 209 */     this.positionAdjuster = new InvalidationListener()
/*     */       {
/*     */         public void invalidated(Observable param1Observable)
/*     */         {
/* 213 */           if (Double.isNaN(CustomColorDialog.this.dialog.getWidth()) || Double.isNaN(CustomColorDialog.this.dialog.getHeight())) {
/*     */             return;
/*     */           }
/* 216 */           CustomColorDialog.this.dialog.widthProperty().removeListener(CustomColorDialog.this.positionAdjuster);
/* 217 */           CustomColorDialog.this.dialog.heightProperty().removeListener(CustomColorDialog.this.positionAdjuster);
/* 218 */           CustomColorDialog.this.fixPosition();
/*     */         }
/*     */       }; getStyleClass().add("custom-color-dialog"); if (paramWindow != null) this.dialog.initOwner(paramWindow);  this.dialog.setTitle(Properties.getColorPickerString("customColorDialogTitle")); this.dialog.initModality(Modality.APPLICATION_MODAL); this.dialog.initStyle(StageStyle.UTILITY); this.dialog.setResizable(false); this.dialog.addEventHandler(KeyEvent.ANY, this.keyEventListener); this.customScene = new Scene(this); Scene scene = paramWindow.getScene(); if (scene != null) { if (scene.getUserAgentStylesheet() != null) this.customScene.setUserAgentStylesheet(scene.getUserAgentStylesheet());  this.customScene.getStylesheets().addAll(scene.getStylesheets()); }  buildUI(); this.dialog.setScene(this.customScene); }
/*     */   public void setCurrentColor(Color paramColor) { this.currentColorProperty.set(paramColor); }
/*     */   public final Color getCurrentColor() { return this.currentColorProperty.get(); }
/*     */   public final ObjectProperty<Color> customColorProperty() { return this.customColorProperty; }
/* 224 */   public final void setCustomColor(Color paramColor) { this.customColorProperty.set(paramColor); } public final Color getCustomColor() { return this.customColorProperty.get(); } public Runnable getOnSave() { return this.onSave; } public void setOnSave(Runnable paramRunnable) { this.onSave = paramRunnable; } public void setSaveBtnToOk() { this.saveBtnText = Properties.getColorPickerString("OK"); buildUI(); } public Runnable getOnUse() { return this.onUse; } public void setOnUse(Runnable paramRunnable) { this.onUse = paramRunnable; } public void setShowUseBtn(boolean paramBoolean) { this.showUseBtn = paramBoolean; buildUI(); } public void setShowOpacitySlider(boolean paramBoolean) { this.showOpacitySlider = paramBoolean; buildUI(); } public Runnable getOnCancel() { return this.onCancel; } public void setOnCancel(Runnable paramRunnable) { this.onCancel = paramRunnable; } public void setOnHidden(EventHandler<WindowEvent> paramEventHandler) { this.dialog.setOnHidden(paramEventHandler); } public Stage getDialog() { return this.dialog; } public void show() { if (this.dialog.getOwner() != null) { this.dialog.widthProperty().addListener(this.positionAdjuster); this.dialog.heightProperty().addListener(this.positionAdjuster); this.positionAdjuster.invalidated(null); }  if (this.dialog.getScene() == null) this.dialog.setScene(this.customScene);  this.colorRectPane.updateValues(); this.dialog.show(); } public void hide() { if (this.dialog.getOwner() != null) this.dialog.hide();  } private void fixPosition() { double d3; Window window = this.dialog.getOwner();
/* 225 */     Screen screen = Utils.getScreen(window);
/* 226 */     Rectangle2D rectangle2D = screen.getBounds();
/* 227 */     double d1 = window.getX() + window.getWidth();
/* 228 */     double d2 = window.getX() - this.dialog.getWidth();
/*     */     
/* 230 */     if (rectangle2D.getMaxX() >= d1 + this.dialog.getWidth()) {
/* 231 */       d3 = d1;
/* 232 */     } else if (rectangle2D.getMinX() <= d2) {
/* 233 */       d3 = d2;
/*     */     } else {
/* 235 */       d3 = Math.max(rectangle2D.getMinX(), rectangle2D.getMaxX() - this.dialog.getWidth());
/*     */     } 
/* 237 */     double d4 = Math.max(rectangle2D.getMinY(), Math.min(rectangle2D.getMaxY() - this.dialog.getHeight(), window.getY()));
/* 238 */     this.dialog.setX(d3);
/* 239 */     this.dialog.setY(d4); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void layoutChildren() {
/* 244 */     super.layoutChildren();
/* 245 */     if (this.dialog.getMinWidth() > 0.0D && this.dialog.getMinHeight() > 0.0D) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 251 */     double d1 = Math.max(0.0D, computeMinWidth(getHeight()) + this.dialog.getWidth() - this.customScene.getWidth());
/* 252 */     double d2 = Math.max(0.0D, computeMinHeight(getWidth()) + this.dialog.getHeight() - this.customScene.getHeight());
/* 253 */     this.dialog.setMinWidth(d1);
/* 254 */     this.dialog.setMinHeight(d2);
/*     */   }
/*     */ 
/*     */   
/*     */   private class ColorRectPane
/*     */     extends HBox
/*     */   {
/*     */     private Pane colorRect;
/*     */     private Pane colorBar;
/*     */     private Pane colorRectOverlayOne;
/*     */     private Pane colorRectOverlayTwo;
/*     */     private Region colorRectIndicator;
/*     */     private Region colorBarIndicator;
/*     */     private boolean changeIsLocal = false;
/*     */     
/* 269 */     private DoubleProperty hue = new SimpleDoubleProperty(-1.0D)
/*     */       {
/*     */         protected void invalidated() {
/* 272 */           if (!CustomColorDialog.ColorRectPane.this.changeIsLocal) {
/* 273 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = true;
/* 274 */             CustomColorDialog.ColorRectPane.this.updateHSBColor();
/* 275 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = false;
/*     */           } 
/*     */         }
/*     */       };
/* 279 */     private DoubleProperty sat = new SimpleDoubleProperty(-1.0D)
/*     */       {
/*     */         protected void invalidated() {
/* 282 */           if (!CustomColorDialog.ColorRectPane.this.changeIsLocal) {
/* 283 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = true;
/* 284 */             CustomColorDialog.ColorRectPane.this.updateHSBColor();
/* 285 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = false;
/*     */           } 
/*     */         }
/*     */       };
/* 289 */     private DoubleProperty bright = new SimpleDoubleProperty(-1.0D)
/*     */       {
/*     */         protected void invalidated() {
/* 292 */           if (!CustomColorDialog.ColorRectPane.this.changeIsLocal) {
/* 293 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = true;
/* 294 */             CustomColorDialog.ColorRectPane.this.updateHSBColor();
/* 295 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = false;
/*     */           } 
/*     */         }
/*     */       };
/* 299 */     private IntegerProperty red = new SimpleIntegerProperty(-1)
/*     */       {
/*     */         protected void invalidated() {
/* 302 */           if (!CustomColorDialog.ColorRectPane.this.changeIsLocal) {
/* 303 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = true;
/* 304 */             CustomColorDialog.ColorRectPane.this.updateRGBColor();
/* 305 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = false;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 310 */     private IntegerProperty green = new SimpleIntegerProperty(-1)
/*     */       {
/*     */         protected void invalidated() {
/* 313 */           if (!CustomColorDialog.ColorRectPane.this.changeIsLocal) {
/* 314 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = true;
/* 315 */             CustomColorDialog.ColorRectPane.this.updateRGBColor();
/* 316 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = false;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 321 */     private IntegerProperty blue = new SimpleIntegerProperty(-1)
/*     */       {
/*     */         protected void invalidated() {
/* 324 */           if (!CustomColorDialog.ColorRectPane.this.changeIsLocal) {
/* 325 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = true;
/* 326 */             CustomColorDialog.ColorRectPane.this.updateRGBColor();
/* 327 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = false;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 332 */     private DoubleProperty alpha = new SimpleDoubleProperty(100.0D)
/*     */       {
/*     */         protected void invalidated() {
/* 335 */           if (!CustomColorDialog.ColorRectPane.this.changeIsLocal) {
/* 336 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = true;
/* 337 */             CustomColorDialog.this.setCustomColor(new Color(CustomColorDialog.this
/* 338 */                   .getCustomColor().getRed(), CustomColorDialog.this
/* 339 */                   .getCustomColor().getGreen(), CustomColorDialog.this
/* 340 */                   .getCustomColor().getBlue(), 
/* 341 */                   CustomColorDialog.clamp(CustomColorDialog.ColorRectPane.this.alpha.get() / 100.0D)));
/* 342 */             CustomColorDialog.ColorRectPane.this.changeIsLocal = false;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/*     */     private void updateRGBColor() {
/* 348 */       Color color = Color.rgb(this.red.get(), this.green.get(), this.blue.get(), CustomColorDialog.clamp(this.alpha.get() / 100.0D));
/* 349 */       this.hue.set(color.getHue());
/* 350 */       this.sat.set(color.getSaturation() * 100.0D);
/* 351 */       this.bright.set(color.getBrightness() * 100.0D);
/* 352 */       CustomColorDialog.this.setCustomColor(color);
/*     */     }
/*     */     
/*     */     private void updateHSBColor() {
/* 356 */       Color color = Color.hsb(this.hue.get(), CustomColorDialog.clamp(this.sat.get() / 100.0D), 
/* 357 */           CustomColorDialog.clamp(this.bright.get() / 100.0D), CustomColorDialog.clamp(this.alpha.get() / 100.0D));
/* 358 */       this.red.set(CustomColorDialog.doubleToInt(color.getRed()));
/* 359 */       this.green.set(CustomColorDialog.doubleToInt(color.getGreen()));
/* 360 */       this.blue.set(CustomColorDialog.doubleToInt(color.getBlue()));
/* 361 */       CustomColorDialog.this.setCustomColor(color);
/*     */     }
/*     */     
/*     */     private void colorChanged() {
/* 365 */       if (!this.changeIsLocal) {
/* 366 */         this.changeIsLocal = true;
/* 367 */         this.hue.set(CustomColorDialog.this.getCustomColor().getHue());
/* 368 */         this.sat.set(CustomColorDialog.this.getCustomColor().getSaturation() * 100.0D);
/* 369 */         this.bright.set(CustomColorDialog.this.getCustomColor().getBrightness() * 100.0D);
/* 370 */         this.red.set(CustomColorDialog.doubleToInt(CustomColorDialog.this.getCustomColor().getRed()));
/* 371 */         this.green.set(CustomColorDialog.doubleToInt(CustomColorDialog.this.getCustomColor().getGreen()));
/* 372 */         this.blue.set(CustomColorDialog.doubleToInt(CustomColorDialog.this.getCustomColor().getBlue()));
/* 373 */         this.changeIsLocal = false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public ColorRectPane() {
/* 379 */       getStyleClass().add("color-rect-pane");
/*     */       
/* 381 */       CustomColorDialog.this.customColorProperty().addListener((param1ObservableValue, param1Color1, param1Color2) -> colorChanged());
/*     */ 
/*     */ 
/*     */       
/* 385 */       this.colorRectIndicator = new Region();
/* 386 */       this.colorRectIndicator.setId("color-rect-indicator");
/* 387 */       this.colorRectIndicator.setManaged(false);
/* 388 */       this.colorRectIndicator.setMouseTransparent(true);
/* 389 */       this.colorRectIndicator.setCache(true);
/*     */       
/* 391 */       StackPane stackPane = new StackPane();
/*     */       
/* 393 */       this.colorRect = new StackPane()
/*     */         {
/*     */           
/*     */           public Orientation getContentBias()
/*     */           {
/* 398 */             return Orientation.VERTICAL;
/*     */           }
/*     */ 
/*     */           
/*     */           protected double computePrefWidth(double param2Double) {
/* 403 */             return param2Double;
/*     */           }
/*     */ 
/*     */           
/*     */           protected double computeMaxWidth(double param2Double) {
/* 408 */             return param2Double;
/*     */           }
/*     */         };
/* 411 */       this.colorRect.getStyleClass().addAll(new String[] { "color-rect", "transparent-pattern" });
/*     */       
/* 413 */       Pane pane1 = new Pane();
/* 414 */       pane1.backgroundProperty().bind(new ObjectBinding<Background>()
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             protected Background computeValue()
/*     */             {
/* 422 */               return new Background(new BackgroundFill[] { new BackgroundFill(
/* 423 */                       Color.hsb(CustomColorDialog.ColorRectPane.access$900(this.this$1).getValue().doubleValue(), 1.0D, 1.0D), CornerRadii.EMPTY, Insets.EMPTY) });
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 428 */       this.colorRectOverlayOne = new Pane();
/* 429 */       this.colorRectOverlayOne.getStyleClass().add("color-rect");
/* 430 */       this.colorRectOverlayOne.setBackground(new Background(new BackgroundFill[] { new BackgroundFill(new LinearGradient(0.0D, 0.0D, 1.0D, 0.0D, true, CycleMethod.NO_CYCLE, new Stop[] { new Stop(0.0D, 
/*     */                       
/* 432 */                       Color.rgb(255, 255, 255, 1.0D)), new Stop(1.0D, 
/* 433 */                       Color.rgb(255, 255, 255, 0.0D)) }), CornerRadii.EMPTY, Insets.EMPTY) }));
/*     */ 
/*     */       
/* 436 */       EventHandler<? super MouseEvent> eventHandler1 = param1MouseEvent -> {
/*     */           double d1 = param1MouseEvent.getX();
/*     */           
/*     */           double d2 = param1MouseEvent.getY();
/*     */           this.sat.set(CustomColorDialog.clamp(d1 / this.colorRect.getWidth()) * 100.0D);
/*     */           this.bright.set(100.0D - CustomColorDialog.clamp(d2 / this.colorRect.getHeight()) * 100.0D);
/*     */         };
/* 443 */       this.colorRectOverlayTwo = new Pane();
/* 444 */       this.colorRectOverlayTwo.getStyleClass().addAll(new String[] { "color-rect" });
/* 445 */       this.colorRectOverlayTwo.setBackground(new Background(new BackgroundFill[] { new BackgroundFill(new LinearGradient(0.0D, 0.0D, 0.0D, 1.0D, true, CycleMethod.NO_CYCLE, new Stop[] { new Stop(0.0D, 
/*     */                       
/* 447 */                       Color.rgb(0, 0, 0, 0.0D)), new Stop(1.0D, Color.rgb(0, 0, 0, 1.0D)) }), CornerRadii.EMPTY, Insets.EMPTY) }));
/*     */       
/* 449 */       this.colorRectOverlayTwo.setOnMouseDragged(eventHandler1);
/* 450 */       this.colorRectOverlayTwo.setOnMousePressed(eventHandler1);
/*     */       
/* 452 */       Pane pane2 = new Pane();
/* 453 */       pane2.setMouseTransparent(true);
/* 454 */       pane2.getStyleClass().addAll(new String[] { "color-rect", "color-rect-border" });
/*     */       
/* 456 */       this.colorBar = new Pane();
/* 457 */       this.colorBar.getStyleClass().add("color-bar");
/* 458 */       this.colorBar.setBackground(new Background(new BackgroundFill[] { new BackgroundFill(CustomColorDialog.access$1000(), CornerRadii.EMPTY, Insets.EMPTY) }));
/*     */ 
/*     */       
/* 461 */       this.colorBarIndicator = new Region();
/* 462 */       this.colorBarIndicator.setId("color-bar-indicator");
/* 463 */       this.colorBarIndicator.setMouseTransparent(true);
/* 464 */       this.colorBarIndicator.setCache(true);
/*     */       
/* 466 */       this.colorRectIndicator.layoutXProperty().bind(this.sat.divide(100).multiply(this.colorRect.widthProperty()));
/* 467 */       this.colorRectIndicator.layoutYProperty().bind(Bindings.subtract(1, this.bright.divide(100)).multiply(this.colorRect.heightProperty()));
/* 468 */       this.colorBarIndicator.layoutYProperty().bind(this.hue.divide(360).multiply(this.colorBar.heightProperty()));
/* 469 */       stackPane.opacityProperty().bind(this.alpha.divide(100));
/*     */       
/* 471 */       EventHandler<? super MouseEvent> eventHandler2 = param1MouseEvent -> {
/*     */           double d = param1MouseEvent.getY();
/*     */           
/*     */           this.hue.set(CustomColorDialog.clamp(d / this.colorRect.getHeight()) * 360.0D);
/*     */         };
/* 476 */       this.colorBar.setOnMouseDragged(eventHandler2);
/* 477 */       this.colorBar.setOnMousePressed(eventHandler2);
/*     */       
/* 479 */       this.colorBar.getChildren().setAll(new Node[] { this.colorBarIndicator });
/* 480 */       stackPane.getChildren().setAll(new Node[] { pane1, this.colorRectOverlayOne, this.colorRectOverlayTwo });
/* 481 */       this.colorRect.getChildren().setAll(new Node[] { stackPane, pane2, this.colorRectIndicator });
/* 482 */       HBox.setHgrow(this.colorRect, Priority.SOMETIMES);
/* 483 */       getChildren().addAll(new Node[] { this.colorRect, this.colorBar });
/*     */     }
/*     */     
/*     */     private void updateValues() {
/* 487 */       if (CustomColorDialog.this.getCurrentColor() == null) {
/* 488 */         CustomColorDialog.this.setCurrentColor(Color.TRANSPARENT);
/*     */       }
/* 490 */       this.changeIsLocal = true;
/*     */       
/* 492 */       this.hue.set(CustomColorDialog.this.getCurrentColor().getHue());
/* 493 */       this.sat.set(CustomColorDialog.this.getCurrentColor().getSaturation() * 100.0D);
/* 494 */       this.bright.set(CustomColorDialog.this.getCurrentColor().getBrightness() * 100.0D);
/* 495 */       this.alpha.set(CustomColorDialog.this.getCurrentColor().getOpacity() * 100.0D);
/* 496 */       CustomColorDialog.this.setCustomColor(Color.hsb(this.hue.get(), CustomColorDialog.clamp(this.sat.get() / 100.0D), CustomColorDialog.clamp(this.bright.get() / 100.0D), 
/* 497 */             CustomColorDialog.clamp(this.alpha.get() / 100.0D)));
/* 498 */       this.red.set(CustomColorDialog.doubleToInt(CustomColorDialog.this.getCustomColor().getRed()));
/* 499 */       this.green.set(CustomColorDialog.doubleToInt(CustomColorDialog.this.getCustomColor().getGreen()));
/* 500 */       this.blue.set(CustomColorDialog.doubleToInt(CustomColorDialog.this.getCustomColor().getBlue()));
/* 501 */       this.changeIsLocal = false;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void layoutChildren() {
/* 506 */       super.layoutChildren();
/*     */ 
/*     */       
/* 509 */       this.colorRectIndicator.autosize();
/*     */       
/* 511 */       double d = Math.min(this.colorRect.getWidth(), this.colorRect.getHeight());
/* 512 */       this.colorRect.resize(d, d);
/* 513 */       this.colorBar.resize(this.colorBar.getWidth(), d);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class ControlsPane
/*     */     extends VBox
/*     */   {
/*     */     private Label currentColorLabel;
/*     */     
/*     */     private Label newColorLabel;
/*     */     private Region currentColorRect;
/*     */     private Region newColorRect;
/*     */     private Region currentTransparent;
/*     */     private GridPane currentAndNewColor;
/*     */     private Region currentNewColorBorder;
/*     */     private ToggleButton hsbButton;
/*     */     private ToggleButton rgbButton;
/*     */     private ToggleButton webButton;
/*     */     private HBox hBox;
/* 533 */     private Label[] labels = new Label[4];
/* 534 */     private Slider[] sliders = new Slider[4];
/* 535 */     private IntegerField[] fields = new IntegerField[4];
/* 536 */     private Label[] units = new Label[4];
/*     */     
/*     */     private HBox buttonBox;
/*     */     private Region whiteBox;
/* 540 */     private GridPane settingsPane = new GridPane();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Property<Number>[] bindedProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void showHSBSettings() {
/* 752 */       set(0, Properties.getColorPickerString("hue_colon"), 360, CustomColorDialog.this.colorRectPane.hue);
/* 753 */       set(1, Properties.getColorPickerString("saturation_colon"), 100, CustomColorDialog.this.colorRectPane.sat);
/* 754 */       set(2, Properties.getColorPickerString("brightness_colon"), 100, CustomColorDialog.this.colorRectPane.bright);
/*     */     }
/*     */     
/*     */     private void showRGBSettings() {
/* 758 */       set(0, Properties.getColorPickerString("red_colon"), 255, CustomColorDialog.this.colorRectPane.red);
/* 759 */       set(1, Properties.getColorPickerString("green_colon"), 255, CustomColorDialog.this.colorRectPane.green);
/* 760 */       set(2, Properties.getColorPickerString("blue_colon"), 255, CustomColorDialog.this.colorRectPane.blue);
/*     */     }
/*     */     
/*     */     private void showWebSettings() {
/* 764 */       this.labels[0].setText(Properties.getColorPickerString("web_colon"));
/*     */     }
/*     */     
/* 767 */     public ControlsPane() { this.bindedProperties = (Property<Number>[])new Property[4]; getStyleClass().add("controls-pane"); this.currentNewColorBorder = new Region(); this.currentNewColorBorder.setId("current-new-color-border"); this.currentTransparent = new Region(); this.currentTransparent.getStyleClass().addAll(new String[] { "transparent-pattern" }); this.currentColorRect = new Region(); this.currentColorRect.getStyleClass().add("color-rect"); this.currentColorRect.setId("current-color"); this.currentColorRect.backgroundProperty().bind(new ObjectBinding<Background>() { protected Background computeValue() { return new Background(new BackgroundFill[] { new BackgroundFill(CustomColorDialog.access$1100(this.this$1.this$0).get(), CornerRadii.EMPTY, Insets.EMPTY) }); } }
/*     */         ); this.newColorRect = new Region(); this.newColorRect.getStyleClass().add("color-rect"); this.newColorRect.setId("new-color"); this.newColorRect.backgroundProperty().bind(new ObjectBinding<Background>() { protected Background computeValue() { return new Background(new BackgroundFill[] { new BackgroundFill(CustomColorDialog.access$1200(this.this$1.this$0).get(), CornerRadii.EMPTY, Insets.EMPTY) }); } }
/*     */         ); this.currentColorLabel = new Label(Properties.getColorPickerString("currentColor")); this.newColorLabel = new Label(Properties.getColorPickerString("newColor")); this.whiteBox = new Region(); this.whiteBox.getStyleClass().add("customcolor-controls-background"); this.hsbButton = new ToggleButton(Properties.getColorPickerString("colorType.hsb")); this.hsbButton.getStyleClass().add("left-pill"); this.rgbButton = new ToggleButton(Properties.getColorPickerString("colorType.rgb")); this.rgbButton.getStyleClass().add("center-pill"); this.webButton = new ToggleButton(Properties.getColorPickerString("colorType.web")); this.webButton.getStyleClass().add("right-pill"); ToggleGroup toggleGroup = new ToggleGroup(); this.hBox = new HBox(); this.hBox.setAlignment(Pos.CENTER); this.hBox.getChildren().addAll(new Node[] { this.hsbButton, this.rgbButton, this.webButton }); Region region1 = new Region(); region1.setId("spacer1"); Region region2 = new Region(); region2.setId("spacer2"); Region region3 = new Region(); region3.setId("spacer-side"); Region region4 = new Region(); region4.setId("spacer-side"); Region region5 = new Region(); region5.setId("spacer-bottom"); this.currentAndNewColor = new GridPane(); this.currentAndNewColor.getColumnConstraints().addAll(new ColumnConstraints[] { new ColumnConstraints(), new ColumnConstraints() }); ((ColumnConstraints)this.currentAndNewColor.getColumnConstraints().get(0)).setHgrow(Priority.ALWAYS); ((ColumnConstraints)this.currentAndNewColor.getColumnConstraints().get(1)).setHgrow(Priority.ALWAYS); this.currentAndNewColor.getRowConstraints().addAll(new RowConstraints[] { new RowConstraints(), new RowConstraints(), new RowConstraints() }); ((RowConstraints)this.currentAndNewColor.getRowConstraints().get(2)).setVgrow(Priority.ALWAYS); VBox.setVgrow(this.currentAndNewColor, Priority.ALWAYS); this.currentAndNewColor.getStyleClass().add("current-new-color-grid"); this.currentAndNewColor.add(this.currentColorLabel, 0, 0); this.currentAndNewColor.add(this.newColorLabel, 1, 0); this.currentAndNewColor.add(region1, 0, 1, 2, 1); this.currentAndNewColor.add(this.currentTransparent, 0, 2, 2, 1); this.currentAndNewColor.add(this.currentColorRect, 0, 2); this.currentAndNewColor.add(this.newColorRect, 1, 2); this.currentAndNewColor.add(this.currentNewColorBorder, 0, 2, 2, 1); this.currentAndNewColor.add(region2, 0, 3, 2, 1); this.settingsPane = new GridPane(); this.settingsPane.setId("settings-pane"); this.settingsPane.getColumnConstraints().addAll(new ColumnConstraints[] { new ColumnConstraints(), new ColumnConstraints(), new ColumnConstraints(), new ColumnConstraints(), new ColumnConstraints(), new ColumnConstraints() }); ((ColumnConstraints)this.settingsPane.getColumnConstraints().get(0)).setHgrow(Priority.NEVER); ((ColumnConstraints)this.settingsPane.getColumnConstraints().get(2)).setHgrow(Priority.ALWAYS); ((ColumnConstraints)this.settingsPane.getColumnConstraints().get(3)).setHgrow(Priority.NEVER); ((ColumnConstraints)this.settingsPane.getColumnConstraints().get(4)).setHgrow(Priority.NEVER); ((ColumnConstraints)this.settingsPane.getColumnConstraints().get(5)).setHgrow(Priority.NEVER); this.settingsPane.add(this.whiteBox, 0, 0, 6, 5); this.settingsPane.add(this.hBox, 0, 0, 6, 1); this.settingsPane.add(region3, 0, 0); this.settingsPane.add(region4, 5, 0); this.settingsPane.add(region5, 0, 4); CustomColorDialog.this.webField = new WebColorField(); CustomColorDialog.this.webField.getStyleClass().add("web-field"); CustomColorDialog.this.webField.setSkin(new WebColorFieldSkin(CustomColorDialog.this.webField)); CustomColorDialog.this.webField.valueProperty().bindBidirectional(CustomColorDialog.this.customColorProperty); CustomColorDialog.this.webField.visibleProperty().bind(toggleGroup.selectedToggleProperty().isEqualTo(this.webButton)); this.settingsPane.add(CustomColorDialog.this.webField, 2, 1); for (byte b = 0; b < 4; b++) { this.labels[b] = new Label(); this.labels[b].getStyleClass().add("settings-label"); this.sliders[b] = new Slider(); this.fields[b] = new IntegerField(); this.fields[b].getStyleClass().add("color-input-field"); this.fields[b].setSkin(new IntegerFieldSkin(this.fields[b])); this.units[b] = new Label((b == 0) ? "°" : "%"); this.units[b].getStyleClass().add("settings-unit"); if (b > 0 && b < 3) this.labels[b].visibleProperty().bind(toggleGroup.selectedToggleProperty().isNotEqualTo(this.webButton));  if (b < 3) { this.sliders[b].visibleProperty().bind(toggleGroup.selectedToggleProperty().isNotEqualTo(this.webButton)); this.fields[b].visibleProperty().bind(toggleGroup.selectedToggleProperty().isNotEqualTo(this.webButton)); this.units[b].visibleProperty().bind(toggleGroup.selectedToggleProperty().isEqualTo(this.hsbButton)); }  int i = 1 + b; if (b == 3) i++;  if (b != 3 || CustomColorDialog.this.showOpacitySlider) { this.settingsPane.add(this.labels[b], 1, i); this.settingsPane.add(this.sliders[b], 2, i); this.settingsPane.add(this.fields[b], 3, i); this.settingsPane.add(this.units[b], 4, i); }  }  set(3, Properties.getColorPickerString("opacity_colon"), 100, CustomColorDialog.this.colorRectPane.alpha); this.hsbButton.setToggleGroup(toggleGroup); this.rgbButton.setToggleGroup(toggleGroup); this.webButton.setToggleGroup(toggleGroup); toggleGroup.selectedToggleProperty().addListener((param1ObservableValue, param1Toggle1, param1Toggle2) -> { if (param1Toggle2 == null) { param1ToggleGroup.selectToggle(param1Toggle1); } else if (param1Toggle2 == this.hsbButton) { showHSBSettings(); } else if (param1Toggle2 == this.rgbButton) { showRGBSettings(); } else { showWebSettings(); }  }); toggleGroup.selectToggle(this.hsbButton); this.buttonBox = new HBox(); this.buttonBox.setId("buttons-hbox"); Button button1 = new Button((CustomColorDialog.this.saveBtnText != null && !CustomColorDialog.this.saveBtnText.isEmpty()) ? CustomColorDialog.this.saveBtnText : Properties.getColorPickerString("Save")); button1.setDefaultButton(true); button1.setOnAction(param1ActionEvent -> { if (CustomColorDialog.this.onSave != null) CustomColorDialog.this.onSave.run();  CustomColorDialog.this.dialog.hide(); }); Button button2 = new Button(Properties.getColorPickerString("Use")); button2.setOnAction(param1ActionEvent -> { if (CustomColorDialog.this.onUse != null) CustomColorDialog.this.onUse.run();  CustomColorDialog.this.dialog.hide(); }); Button button3 = new Button(Properties.getColorPickerString("Cancel")); button3.setCancelButton(true); button3.setOnAction(param1ActionEvent -> { CustomColorDialog.this.customColorProperty.set(CustomColorDialog.this.getCurrentColor()); if (CustomColorDialog.this.onCancel != null)
/* 770 */               CustomColorDialog.this.onCancel.run();  CustomColorDialog.this.dialog.hide(); }); if (CustomColorDialog.this.showUseBtn) { this.buttonBox.getChildren().addAll(new Node[] { button1, button2, button3 }); } else { this.buttonBox.getChildren().addAll(new Node[] { button1, button3 }); }  getChildren().addAll(new Node[] { this.currentAndNewColor, this.settingsPane, this.buttonBox }); } private void set(int param1Int1, String param1String, int param1Int2, Property<Number> param1Property) { this.labels[param1Int1].setText(param1String);
/* 771 */       if (this.bindedProperties[param1Int1] != null) {
/* 772 */         this.sliders[param1Int1].valueProperty().unbindBidirectional(this.bindedProperties[param1Int1]);
/* 773 */         this.fields[param1Int1].valueProperty().unbindBidirectional(this.bindedProperties[param1Int1]);
/*     */       } 
/* 775 */       this.sliders[param1Int1].setMax(param1Int2);
/* 776 */       this.sliders[param1Int1].valueProperty().bindBidirectional(param1Property);
/* 777 */       this.labels[param1Int1].setLabelFor(this.sliders[param1Int1]);
/* 778 */       this.fields[param1Int1].setMaxValue(param1Int2);
/* 779 */       this.fields[param1Int1].valueProperty().bindBidirectional(param1Property);
/* 780 */       this.bindedProperties[param1Int1] = param1Property; }
/*     */   
/*     */   }
/*     */   
/*     */   static double clamp(double paramDouble) {
/* 785 */     return (paramDouble < 0.0D) ? 0.0D : ((paramDouble > 1.0D) ? 1.0D : paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   private static LinearGradient createHueGradient() {
/* 790 */     Stop[] arrayOfStop = new Stop[255];
/* 791 */     for (byte b = 0; b < 'ÿ'; b++) {
/* 792 */       double d = 1.0D - 0.00392156862745098D * b;
/* 793 */       int i = (int)(b / 255.0D * 360.0D);
/* 794 */       arrayOfStop[b] = new Stop(d, Color.hsb(i, 1.0D, 1.0D));
/*     */     } 
/* 796 */     return new LinearGradient(0.0D, 1.0D, 0.0D, 0.0D, true, CycleMethod.NO_CYCLE, arrayOfStop);
/*     */   }
/*     */   
/*     */   private static int doubleToInt(double paramDouble) {
/* 800 */     return (int)(paramDouble * 255.0D + 0.5D);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\CustomColorDialog.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */