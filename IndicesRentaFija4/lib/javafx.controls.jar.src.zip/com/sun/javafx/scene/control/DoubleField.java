/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import com.sun.javafx.scene.control.skin.DoubleFieldSkin;
/*    */ import javafx.beans.property.DoubleProperty;
/*    */ import javafx.beans.property.SimpleDoubleProperty;
/*    */ import javafx.scene.control.Skin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleField
/*    */   extends InputField
/*    */ {
/* 41 */   private DoubleProperty value = new SimpleDoubleProperty(this, "value");
/* 42 */   public final double getValue() { return this.value.get(); }
/* 43 */   public final void setValue(double paramDouble) { this.value.set(paramDouble); } public final DoubleProperty valueProperty() {
/* 44 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public DoubleField() {
/* 50 */     getStyleClass().setAll(new String[] { "double-field" });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Skin<?> createDefaultSkin() {
/* 61 */     return new DoubleFieldSkin(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\DoubleField.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */