/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import javafx.scene.control.PasswordField;
/*    */ import javafx.scene.text.HitInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PasswordFieldBehavior
/*    */   extends TextFieldBehavior
/*    */ {
/*    */   protected void deletePreviousWord() {}
/*    */   
/*    */   protected void deleteNextWord() {}
/*    */   
/*    */   protected void selectPreviousWord() {}
/*    */   
/*    */   public PasswordFieldBehavior(PasswordField paramPasswordField) {
/* 37 */     super(paramPasswordField);
/*    */   }
/*    */ 
/*    */   
/*    */   public void selectNextWord() {}
/*    */ 
/*    */   
/*    */   protected void previousWord() {}
/*    */   
/*    */   protected void nextWord() {}
/*    */   
/*    */   protected void selectWord() {
/* 49 */     selectAll();
/*    */   }
/*    */   protected void mouseDoubleClick(HitInfo paramHitInfo) {
/* 52 */     getNode().selectAll();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\PasswordFieldBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */