/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.css.CssMetaData;
/*     */ import javafx.css.StyleOrigin;
/*     */ import javafx.css.Styleable;
/*     */ import javafx.css.StyleableProperty;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.Labeled;
/*     */ import javafx.scene.layout.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabeledImpl
/*     */   extends Label
/*     */ {
/*     */   private final Shuttler shuttler;
/*     */   
/*     */   public LabeledImpl(Labeled paramLabeled) {
/*  51 */     this.shuttler = new Shuttler(this, paramLabeled);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initialize(Shuttler paramShuttler, LabeledImpl paramLabeledImpl, Labeled paramLabeled) {
/*  57 */     paramLabeledImpl.setText(paramLabeled.getText());
/*  58 */     paramLabeled.textProperty().addListener(paramShuttler);
/*     */     
/*  60 */     paramLabeledImpl.setGraphic(paramLabeled.getGraphic());
/*  61 */     paramLabeled.graphicProperty().addListener(paramShuttler);
/*     */     
/*  63 */     List<CssMetaData<? extends Styleable, ?>> list = StyleableProperties.STYLEABLES_TO_MIRROR; byte b;
/*     */     int i;
/*  65 */     for (b = 0, i = list.size(); b < i; b++) {
/*     */       
/*  67 */       CssMetaData cssMetaData = list.get(b);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  72 */       if (!"-fx-skin".equals(cssMetaData.getProperty())) {
/*     */         
/*  74 */         StyleableProperty styleableProperty = cssMetaData.getStyleableProperty(paramLabeled);
/*  75 */         if (styleableProperty instanceof Observable) {
/*     */           
/*  77 */           ((Observable)styleableProperty).addListener(paramShuttler);
/*     */           
/*  79 */           StyleOrigin styleOrigin = styleableProperty.getStyleOrigin();
/*  80 */           if (styleOrigin != null) {
/*  81 */             StyleableProperty styleableProperty1 = cssMetaData.getStyleableProperty(paramLabeledImpl);
/*  82 */             styleableProperty1.applyStyle(styleOrigin, styleableProperty.getValue());
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class Shuttler implements InvalidationListener { private final LabeledImpl labeledImpl;
/*     */     private final Labeled labeled;
/*     */     
/*     */     Shuttler(LabeledImpl param1LabeledImpl, Labeled param1Labeled) {
/*  93 */       this.labeledImpl = param1LabeledImpl;
/*  94 */       this.labeled = param1Labeled;
/*  95 */       LabeledImpl.initialize(this, param1LabeledImpl, param1Labeled);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void invalidated(Observable param1Observable) {
/* 101 */       if (param1Observable == this.labeled.textProperty()) {
/* 102 */         this.labeledImpl.setText(this.labeled.getText());
/* 103 */       } else if (param1Observable == this.labeled.graphicProperty()) {
/*     */ 
/*     */ 
/*     */         
/* 107 */         StyleOrigin styleOrigin = ((StyleableProperty)this.labeled.graphicProperty()).getStyleOrigin();
/* 108 */         if (styleOrigin == null || styleOrigin == StyleOrigin.USER) {
/* 109 */           this.labeledImpl.setGraphic(this.labeled.getGraphic());
/*     */         }
/*     */       }
/* 112 */       else if (param1Observable instanceof StyleableProperty) {
/* 113 */         StyleableProperty styleableProperty = (StyleableProperty)param1Observable;
/*     */         
/* 115 */         CssMetaData cssMetaData = styleableProperty.getCssMetaData();
/* 116 */         if (cssMetaData != null) {
/* 117 */           StyleOrigin styleOrigin = styleableProperty.getStyleOrigin();
/* 118 */           StyleableProperty styleableProperty1 = cssMetaData.getStyleableProperty(this.labeledImpl);
/* 119 */           styleableProperty1.applyStyle(styleOrigin, styleableProperty.getValue());
/*     */         } 
/*     */       } 
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class StyleableProperties
/*     */   {
/*     */     static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES_TO_MIRROR;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static {
/* 144 */       List<CssMetaData<? extends Styleable, ?>> list1 = Labeled.getClassCssMetaData();
/* 145 */       List<CssMetaData<? extends Styleable, ?>> list2 = Region.getClassCssMetaData();
/* 146 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(list1);
/*     */       
/* 148 */       arrayList.removeAll(list2);
/* 149 */       STYLEABLES_TO_MIRROR = Collections.unmodifiableList(arrayList);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\LabeledImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */