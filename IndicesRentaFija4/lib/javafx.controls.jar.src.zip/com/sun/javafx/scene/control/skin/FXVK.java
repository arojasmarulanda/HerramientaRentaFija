/*     */ package com.sun.javafx.scene.control.skin;
/*     */ 
/*     */ import javafx.application.ConditionalFeature;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.SimpleObjectProperty;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.NodeOrientation;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.Skin;
/*     */ import javafx.scene.control.TextInputControl;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FXVK
/*     */   extends Control
/*     */ {
/*     */   public enum Type
/*     */   {
/*  45 */     TEXT,
/*  46 */     NUMERIC,
/*  47 */     EMAIL;
/*     */   }
/*     */ 
/*     */   
/*  51 */   private final ObjectProperty<EventHandler<KeyEvent>> onAction = new SimpleObjectProperty<>(this, "onAction");
/*     */   
/*  53 */   public final void setOnAction(EventHandler<KeyEvent> paramEventHandler) { this.onAction.set(paramEventHandler); }
/*  54 */   public final EventHandler<KeyEvent> getOnAction() { return this.onAction.get(); } public final ObjectProperty<EventHandler<KeyEvent>> onActionProperty() {
/*  55 */     return this.onAction;
/*     */   }
/*     */   
/*  58 */   static final String[] VK_TYPE_NAMES = new String[] { "text", "numeric", "url", "email" }; public static final String VK_TYPE_PROP_KEY = "vkType";
/*     */   String[] chars;
/*     */   private ObjectProperty<Node> attachedNode;
/*     */   static FXVK vk;
/*     */   
/*     */   public FXVK() {
/*  64 */     setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
/*  65 */     getStyleClass().add("fxvk");
/*     */   }
/*     */   
/*     */   final ObjectProperty<Node> attachedNodeProperty() {
/*  69 */     if (this.attachedNode == null) {
/*  70 */       this.attachedNode = new ObjectPropertyBase<Node>() {
/*     */           public Object getBean() {
/*  72 */             return FXVK.this;
/*     */           }
/*     */           
/*     */           public String getName() {
/*  76 */             return "attachedNode";
/*     */           }
/*     */         };
/*     */     }
/*  80 */     return this.attachedNode;
/*     */   }
/*     */   
/*     */   final void setAttachedNode(Node paramNode) {
/*  84 */     attachedNodeProperty().setValue(paramNode); } final Node getAttachedNode() {
/*  85 */     return (this.attachedNode == null) ? null : this.attachedNode.getValue();
/*     */   }
/*     */   
/*     */   public static void init(Node paramNode) {
/*  89 */     if (vk != null)
/*  90 */       return;  vk = new FXVK();
/*  91 */     FXVKSkin fXVKSkin = new FXVKSkin(vk);
/*  92 */     vk.setSkin(fXVKSkin);
/*  93 */     fXVKSkin.prerender(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void attach(Node paramNode) {
/*  98 */     if (vk == null) {
/*  99 */       vk = new FXVK();
/* 100 */       vk.setSkin(new FXVKSkin(vk));
/*     */     } 
/* 102 */     vk.setAttachedNode(paramNode);
/*     */   }
/*     */   
/*     */   public static void detach() {
/* 106 */     if (vk != null) {
/* 107 */       vk.setAttachedNode((Node)null);
/*     */     }
/*     */   }
/*     */   
/* 111 */   private static final boolean IS_FXVK_SUPPORTED = Platform.isSupported(ConditionalFeature.VIRTUAL_KEYBOARD);
/* 112 */   private static boolean USE_FXVK = IS_FXVK_SUPPORTED; private static final String DEFAULT_STYLE_CLASS = "fxvk";
/*     */   
/*     */   public static boolean useFXVK() {
/* 115 */     return USE_FXVK;
/*     */   }
/*     */   
/*     */   public static void toggleUseVK(TextInputControl paramTextInputControl) {
/* 119 */     Integer integer1 = (Integer)paramTextInputControl.getProperties().get("vkType");
/* 120 */     if (integer1 == null) {
/* 121 */       integer1 = Integer.valueOf(-1);
/*     */     }
/* 123 */     Integer integer2 = integer1, integer3 = integer1 = Integer.valueOf(integer1.intValue() + 1);
/* 124 */     if (integer1.intValue() < 4) {
/* 125 */       USE_FXVK = true;
/* 126 */       paramTextInputControl.getProperties().put("vkType", integer1);
/* 127 */       attach(paramTextInputControl);
/*     */     } else {
/* 129 */       detach();
/* 130 */       paramTextInputControl.getProperties().put("vkType", null);
/* 131 */       USE_FXVK = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Skin<?> createDefaultSkin() {
/* 143 */     return new FXVKSkin(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\skin\FXVK.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */