/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import java.time.LocalDate;
/*    */ import javafx.scene.control.DatePicker;
/*    */ import javafx.scene.control.PopupControl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DatePickerBehavior
/*    */   extends ComboBoxBaseBehavior<LocalDate>
/*    */ {
/*    */   public DatePickerBehavior(DatePicker paramDatePicker) {
/* 46 */     super(paramDatePicker);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onAutoHide(PopupControl paramPopupControl) {
/* 59 */     if (!paramPopupControl.isShowing() && getNode().isShowing())
/*    */     {
/*    */       
/* 62 */       getNode().hide();
/*    */     }
/*    */ 
/*    */     
/* 66 */     if (!getNode().isShowing())
/* 67 */       super.onAutoHide(paramPopupControl); 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\DatePickerBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */