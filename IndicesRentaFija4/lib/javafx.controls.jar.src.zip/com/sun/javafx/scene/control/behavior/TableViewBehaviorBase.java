/*      */ package com.sun.javafx.scene.control.behavior;
/*      */ 
/*      */ import com.sun.javafx.PlatformUtil;
/*      */ import com.sun.javafx.scene.control.SizeLimitedList;
/*      */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*      */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.collections.WeakListChangeListener;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.control.Control;
/*      */ import javafx.scene.control.SelectionMode;
/*      */ import javafx.scene.control.TableColumnBase;
/*      */ import javafx.scene.control.TableFocusModel;
/*      */ import javafx.scene.control.TablePositionBase;
/*      */ import javafx.scene.control.TableSelectionModel;
/*      */ import javafx.scene.input.KeyCode;
/*      */ import javafx.scene.input.KeyEvent;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.util.Callback;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class TableViewBehaviorBase<C extends Control, T, TC extends TableColumnBase<T, ?>>
/*      */   extends BehaviorBase<C>
/*      */ {
/*      */   private final InputMap<C> tableViewInputMap;
/*      */   protected boolean isShortcutDown = false;
/*      */   protected boolean isShiftDown = false;
/*      */   private boolean selectionPathDeviated = false;
/*      */   protected boolean selectionChanging = false;
/*      */   private final EventHandler<KeyEvent> keyEventListener;
/*      */   private final SizeLimitedList<TablePositionBase> selectionHistory;
/*      */   protected final ListChangeListener<TablePositionBase> selectedCellsListener;
/*      */   protected final WeakListChangeListener<TablePositionBase> weakSelectedCellsListener;
/*      */   private Callback<Boolean, Integer> onScrollPageUp;
/*      */   private Callback<Boolean, Integer> onScrollPageDown;
/*      */   private Runnable onFocusPreviousRow;
/*      */   private Runnable onFocusNextRow;
/*      */   private Runnable onSelectPreviousRow;
/*      */   private Runnable onSelectNextRow;
/*      */   private Runnable onMoveToFirstCell;
/*      */   private Runnable onMoveToLastCell;
/*      */   private Runnable onSelectRightCell;
/*      */   private Runnable onSelectLeftCell;
/*      */   
/*      */   public TableViewBehaviorBase(C paramC) {
/*  132 */     super(paramC); this.keyEventListener = (paramKeyEvent -> { if (!paramKeyEvent.isConsumed()) { this.isShiftDown = (paramKeyEvent.getEventType() == KeyEvent.KEY_PRESSED && paramKeyEvent.isShiftDown()); this.isShortcutDown = (paramKeyEvent.getEventType() == KeyEvent.KEY_PRESSED && paramKeyEvent.isShortcutDown()); }  }); this.selectionHistory = new SizeLimitedList<>(10); this.selectedCellsListener = (paramChange -> { while (paramChange.next()) { if (paramChange.wasReplaced() && TreeTableCellBehavior.hasDefaultAnchor((Control)getNode())) TreeTableCellBehavior.removeAnchor((Control)getNode());  if (!paramChange.wasAdded())
/*      */             continue;  TableSelectionModel<T> tableSelectionModel = getSelectionModel(); if (tableSelectionModel == null)
/*      */             return;  TablePositionBase tablePositionBase = getAnchor(); boolean bool = tableSelectionModel.isCellSelectionEnabled(); int i = paramChange.getAddedSize(); List<TablePositionBase> list = paramChange.getAddedSubList(); for (TablePositionBase tablePositionBase1 : list) { if (!this.selectionHistory.contains(tablePositionBase1))
/*      */               this.selectionHistory.add(tablePositionBase1);  }  if (i > 0 && !hasAnchor()) { TablePositionBase tablePositionBase1 = list.get(i - 1); setAnchor(tablePositionBase1); }  if (tablePositionBase != null && bool && !this.selectionPathDeviated)
/*  136 */             for (byte b = 0; b < i; b++) { TablePositionBase tablePositionBase1 = list.get(b); if (tablePositionBase.getRow() != -1 && tablePositionBase1.getRow() != tablePositionBase.getRow() && tablePositionBase1.getColumn() != tablePositionBase.getColumn()) { setSelectionPathDeviated(true); break; }  }   }  }); this.weakSelectedCellsListener = new WeakListChangeListener<>(this.selectedCellsListener); this.tableViewInputMap = createInputMap();
/*      */     
/*      */     InputMap.KeyMapping keyMapping1, keyMapping2;
/*  139 */     addDefaultMapping(this.tableViewInputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.TAB, FocusTraversalInputMap::traverseNext), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB))
/*      */             
/*  141 */             .shift(), FocusTraversalInputMap::traversePrevious), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.HOME, paramKeyEvent -> selectFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.END, paramKeyEvent -> selectLastRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.PAGE_UP, paramKeyEvent -> scrollUp()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.PAGE_DOWN, paramKeyEvent -> scrollDown()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> selectLeftCell()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_LEFT, paramKeyEvent -> selectLeftCell()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> selectRightCell()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_RIGHT, paramKeyEvent -> selectRightCell()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> selectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_UP, paramKeyEvent -> selectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> selectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_DOWN, paramKeyEvent -> selectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, FocusTraversalInputMap::traverseLeft), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_LEFT, FocusTraversalInputMap::traverseLeft), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, FocusTraversalInputMap::traverseRight), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_RIGHT, FocusTraversalInputMap::traverseRight), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, FocusTraversalInputMap::traverseUp), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_UP, FocusTraversalInputMap::traverseUp), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, FocusTraversalInputMap::traverseDown), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.KP_DOWN, FocusTraversalInputMap::traverseDown), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.HOME))
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  168 */             .shift(), paramKeyEvent -> selectAllToFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.END))
/*  169 */             .shift(), paramKeyEvent -> selectAllToLastRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP))
/*  170 */             .shift(), paramKeyEvent -> selectAllPageUp()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN))
/*  171 */             .shift(), paramKeyEvent -> selectAllPageDown()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.UP))
/*      */             
/*  173 */             .shift(), paramKeyEvent -> alsoSelectPrevious()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_UP))
/*  174 */             .shift(), paramKeyEvent -> alsoSelectPrevious()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN))
/*  175 */             .shift(), paramKeyEvent -> alsoSelectNext()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_DOWN))
/*  176 */             .shift(), paramKeyEvent -> alsoSelectNext()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE))
/*      */             
/*  178 */             .shift(), paramKeyEvent -> selectAllToFocus(false)), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE))
/*  179 */             .shortcut().shift(), paramKeyEvent -> selectAllToFocus(true)), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.LEFT))
/*      */             
/*  181 */             .shift(), paramKeyEvent -> alsoSelectLeftCell()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_LEFT))
/*  182 */             .shift(), paramKeyEvent -> alsoSelectLeftCell()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.RIGHT))
/*  183 */             .shift(), paramKeyEvent -> alsoSelectRightCell()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_RIGHT))
/*  184 */             .shift(), paramKeyEvent -> alsoSelectRightCell()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.UP))
/*      */             
/*  186 */             .shortcut(), paramKeyEvent -> focusPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN))
/*  187 */             .shortcut(), paramKeyEvent -> focusNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.RIGHT))
/*  188 */             .shortcut(), paramKeyEvent -> focusRightCell()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_RIGHT))
/*  189 */             .shortcut(), paramKeyEvent -> focusRightCell()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.LEFT))
/*  190 */             .shortcut(), paramKeyEvent -> focusLeftCell()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.KP_LEFT))
/*  191 */             .shortcut(), paramKeyEvent -> focusLeftCell()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.A))
/*      */             
/*  193 */             .shortcut(), paramKeyEvent -> selectAll()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.HOME))
/*  194 */             .shortcut(), paramKeyEvent -> focusFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.END))
/*  195 */             .shortcut(), paramKeyEvent -> focusLastRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP))
/*  196 */             .shortcut(), paramKeyEvent -> focusPageUp()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN))
/*  197 */             .shortcut(), paramKeyEvent -> focusPageDown()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.UP))
/*      */             
/*  199 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectPreviousRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DOWN))
/*  200 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectNextRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.LEFT))
/*  201 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectPreviousColumn()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.RIGHT))
/*  202 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectNextColumn()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP))
/*  203 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectPageUp()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN))
/*  204 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectPageDown()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.HOME))
/*  205 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectAllToFirstRow()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.END))
/*  206 */             .shortcut().shift(), paramKeyEvent -> discontinuousSelectAllToLastRow()), (InputMap.Mapping)(keyMapping1 = new InputMap.KeyMapping(KeyCode.ENTER, this::activate)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, this::activate), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.F2, this::activate), (InputMap.Mapping)(keyMapping2 = new InputMap.KeyMapping(KeyCode.ESCAPE, this::cancelEdit)), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  216 */     keyMapping1.setAutoConsume(false);
/*  217 */     keyMapping2.setAutoConsume(false);
/*      */ 
/*      */ 
/*      */     
/*  221 */     InputMap<C> inputMap1 = new InputMap((Node)paramC);
/*  222 */     inputMap1.setInterceptor(paramEvent -> !PlatformUtil.isMac());
/*  223 */     addDefaultMapping(inputMap1, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE)).shortcut().ctrl(), paramKeyEvent -> toggleFocusOwnerSelection()) });
/*  224 */     addDefaultChildMap(this.tableViewInputMap, inputMap1);
/*      */ 
/*      */     
/*  227 */     InputMap<C> inputMap2 = new InputMap((Node)paramC);
/*  228 */     inputMap2.setInterceptor(paramEvent -> PlatformUtil.isMac());
/*  229 */     addDefaultMapping(inputMap2, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.SPACE)).ctrl(), paramKeyEvent -> toggleFocusOwnerSelection()) });
/*  230 */     addDefaultChildMap(this.tableViewInputMap, inputMap2);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  235 */     paramC.addEventFilter(KeyEvent.ANY, this.keyEventListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputMap<C> getInputMap() {
/*  248 */     return this.tableViewInputMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setAnchor(TablePositionBase paramTablePositionBase) {
/*  255 */     TableCellBehaviorBase.setAnchor((Control)getNode(), (C)paramTablePositionBase, false);
/*  256 */     setSelectionPathDeviated(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TablePositionBase getAnchor() {
/*  263 */     return (TablePositionBase)TableCellBehaviorBase.getAnchor((Control)getNode(), (C)getFocusedCell());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasAnchor() {
/*  270 */     return TableCellBehaviorBase.hasNonDefaultAnchor((Control)getNode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setAnchor(int paramInt, TableColumnBase<T, ?> paramTableColumnBase) {
/*  369 */     setAnchor((paramInt == -1 && paramTableColumnBase == null) ? null : getTablePosition(paramInt, paramTableColumnBase));
/*      */   }
/*      */   
/*      */   public void setOnScrollPageUp(Callback<Boolean, Integer> paramCallback) {
/*  373 */     this.onScrollPageUp = paramCallback;
/*      */   }
/*      */   public void setOnScrollPageDown(Callback<Boolean, Integer> paramCallback) {
/*  376 */     this.onScrollPageDown = paramCallback;
/*      */   }
/*      */   public void setOnFocusPreviousRow(Runnable paramRunnable) {
/*  379 */     this.onFocusPreviousRow = paramRunnable;
/*      */   }
/*      */   public void setOnFocusNextRow(Runnable paramRunnable) {
/*  382 */     this.onFocusNextRow = paramRunnable;
/*      */   }
/*      */   public void setOnSelectPreviousRow(Runnable paramRunnable) {
/*  385 */     this.onSelectPreviousRow = paramRunnable;
/*      */   }
/*      */   public void setOnSelectNextRow(Runnable paramRunnable) {
/*  388 */     this.onSelectNextRow = paramRunnable;
/*      */   }
/*      */   public void setOnMoveToFirstCell(Runnable paramRunnable) {
/*  391 */     this.onMoveToFirstCell = paramRunnable;
/*      */   }
/*      */   public void setOnMoveToLastCell(Runnable paramRunnable) {
/*  394 */     this.onMoveToLastCell = paramRunnable;
/*      */   }
/*      */   public void setOnSelectRightCell(Runnable paramRunnable) {
/*  397 */     this.onSelectRightCell = paramRunnable;
/*      */   }
/*      */   public void setOnSelectLeftCell(Runnable paramRunnable) {
/*  400 */     this.onSelectLeftCell = paramRunnable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mousePressed(MouseEvent paramMouseEvent) {
/*  407 */     if (!((Control)getNode()).isFocused() && ((Control)getNode()).isFocusTraversable()) {
/*  408 */       ((Control)getNode()).requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   protected boolean isRTL() {
/*  413 */     return (((Control)getNode()).getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setSelectionPathDeviated(boolean paramBoolean) {
/*  424 */     this.selectionPathDeviated = paramBoolean;
/*      */   }
/*      */   
/*      */   protected void scrollUp() {
/*  428 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  429 */     if (tableSelectionModel == null || getSelectedCells().isEmpty())
/*      */       return; 
/*  431 */     TablePositionBase<TableColumnBase<T, ?>> tablePositionBase = getSelectedCells().get(0);
/*      */     
/*  433 */     int i = -1;
/*  434 */     if (this.onScrollPageUp != null) {
/*  435 */       i = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(false))).intValue();
/*      */     }
/*  437 */     if (i == -1)
/*      */       return; 
/*  439 */     tableSelectionModel.clearAndSelect(i, tablePositionBase.getTableColumn());
/*      */   }
/*      */   
/*      */   protected void scrollDown() {
/*  443 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  444 */     if (tableSelectionModel == null || getSelectedCells().isEmpty())
/*      */       return; 
/*  446 */     TablePositionBase<TableColumnBase<T, ?>> tablePositionBase = getSelectedCells().get(0);
/*      */     
/*  448 */     int i = -1;
/*  449 */     if (this.onScrollPageDown != null) {
/*  450 */       i = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(false))).intValue();
/*      */     }
/*  452 */     if (i == -1)
/*      */       return; 
/*  454 */     tableSelectionModel.clearAndSelect(i, tablePositionBase.getTableColumn());
/*      */   }
/*      */   
/*      */   protected void focusFirstRow() {
/*  458 */     TableFocusModel tableFocusModel = getFocusModel();
/*  459 */     if (tableFocusModel == null)
/*      */       return; 
/*  461 */     TC tC = (getFocusedCell() == null) ? null : (TC)getFocusedCell().getTableColumn();
/*  462 */     tableFocusModel.focus(0, tC);
/*      */     
/*  464 */     if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*      */   }
/*      */   
/*      */   protected void focusLastRow() {
/*  468 */     TableFocusModel tableFocusModel = getFocusModel();
/*  469 */     if (tableFocusModel == null)
/*      */       return; 
/*  471 */     TC tC = (getFocusedCell() == null) ? null : (TC)getFocusedCell().getTableColumn();
/*  472 */     tableFocusModel.focus(getItemCount() - 1, tC);
/*      */     
/*  474 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*      */   }
/*      */   
/*      */   protected void focusPreviousRow() {
/*  478 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  479 */     if (tableSelectionModel == null)
/*      */       return; 
/*  481 */     TableFocusModel tableFocusModel = getFocusModel();
/*  482 */     if (tableFocusModel == null)
/*      */       return; 
/*  484 */     if (tableSelectionModel.isCellSelectionEnabled()) {
/*  485 */       tableFocusModel.focusAboveCell();
/*      */     } else {
/*  487 */       tableFocusModel.focusPrevious();
/*      */     } 
/*      */     
/*  490 */     if (!this.isShortcutDown || getAnchor() == null) {
/*  491 */       setAnchor(tableFocusModel.getFocusedIndex(), (TableColumnBase)null);
/*      */     }
/*      */     
/*  494 */     if (this.onFocusPreviousRow != null) this.onFocusPreviousRow.run(); 
/*      */   }
/*      */   
/*      */   protected void focusNextRow() {
/*  498 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  499 */     if (tableSelectionModel == null)
/*      */       return; 
/*  501 */     TableFocusModel tableFocusModel = getFocusModel();
/*  502 */     if (tableFocusModel == null)
/*      */       return; 
/*  504 */     if (tableSelectionModel.isCellSelectionEnabled()) {
/*  505 */       tableFocusModel.focusBelowCell();
/*      */     } else {
/*  507 */       tableFocusModel.focusNext();
/*      */     } 
/*      */     
/*  510 */     if (!this.isShortcutDown || getAnchor() == null) {
/*  511 */       setAnchor(tableFocusModel.getFocusedIndex(), (TableColumnBase)null);
/*      */     }
/*      */     
/*  514 */     if (this.onFocusNextRow != null) this.onFocusNextRow.run(); 
/*      */   }
/*      */   
/*      */   protected void focusLeftCell() {
/*  518 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  519 */     if (tableSelectionModel == null)
/*      */       return; 
/*  521 */     TableFocusModel tableFocusModel = getFocusModel();
/*  522 */     if (tableFocusModel == null)
/*      */       return; 
/*  524 */     tableFocusModel.focusLeftCell();
/*  525 */     if (this.onFocusPreviousRow != null) this.onFocusPreviousRow.run(); 
/*      */   }
/*      */   
/*      */   protected void focusRightCell() {
/*  529 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  530 */     if (tableSelectionModel == null)
/*      */       return; 
/*  532 */     TableFocusModel tableFocusModel = getFocusModel();
/*  533 */     if (tableFocusModel == null)
/*      */       return; 
/*  535 */     tableFocusModel.focusRightCell();
/*  536 */     if (this.onFocusNextRow != null) this.onFocusNextRow.run(); 
/*      */   }
/*      */   
/*      */   protected void focusPageUp() {
/*  540 */     int i = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(true))).intValue();
/*      */     
/*  542 */     TableFocusModel tableFocusModel = getFocusModel();
/*  543 */     if (tableFocusModel == null)
/*  544 */       return;  TC tC = (getFocusedCell() == null) ? null : (TC)getFocusedCell().getTableColumn();
/*  545 */     tableFocusModel.focus(i, tC);
/*      */   }
/*      */   
/*      */   protected void focusPageDown() {
/*  549 */     int i = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(true))).intValue();
/*      */     
/*  551 */     TableFocusModel tableFocusModel = getFocusModel();
/*  552 */     if (tableFocusModel == null)
/*  553 */       return;  TC tC = (getFocusedCell() == null) ? null : (TC)getFocusedCell().getTableColumn();
/*  554 */     tableFocusModel.focus(i, tC);
/*      */   }
/*      */   
/*      */   protected void clearSelection() {
/*  558 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  559 */     if (tableSelectionModel == null)
/*      */       return; 
/*  561 */     tableSelectionModel.clearSelection();
/*      */   }
/*      */   
/*      */   protected void clearSelectionOutsideRange(int paramInt1, int paramInt2, TableColumnBase<T, ?> paramTableColumnBase) {
/*  565 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  566 */     if (tableSelectionModel == null)
/*      */       return; 
/*  568 */     int i = Math.min(paramInt1, paramInt2);
/*  569 */     int j = Math.max(paramInt1, paramInt2);
/*      */     
/*  571 */     ArrayList<Integer> arrayList = new ArrayList(tableSelectionModel.getSelectedIndices());
/*      */     
/*  573 */     this.selectionChanging = true;
/*  574 */     for (byte b = 0; b < arrayList.size(); b++) {
/*  575 */       int k = ((Integer)arrayList.get(b)).intValue();
/*  576 */       if (k < i || k > j) {
/*  577 */         tableSelectionModel.clearSelection(k, paramTableColumnBase);
/*      */       }
/*      */     } 
/*  580 */     this.selectionChanging = false;
/*      */   }
/*      */   
/*      */   protected void alsoSelectPrevious() {
/*  584 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  585 */     if (tableSelectionModel == null)
/*      */       return; 
/*  587 */     if (tableSelectionModel.getSelectionMode() == SelectionMode.SINGLE) {
/*  588 */       selectPreviousRow();
/*      */       
/*      */       return;
/*      */     } 
/*  592 */     TableFocusModel tableFocusModel = getFocusModel();
/*  593 */     if (tableFocusModel == null)
/*      */       return; 
/*  595 */     if (tableSelectionModel.isCellSelectionEnabled()) {
/*  596 */       updateCellVerticalSelection(-1, () -> getSelectionModel().selectAboveCell());
/*      */ 
/*      */     
/*      */     }
/*  600 */     else if (this.isShiftDown && hasAnchor()) {
/*  601 */       updateRowSelection(-1);
/*      */     } else {
/*  603 */       tableSelectionModel.selectPrevious();
/*      */     } 
/*      */     
/*  606 */     this.onSelectPreviousRow.run();
/*      */   }
/*      */   
/*      */   protected void alsoSelectNext() {
/*  610 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  611 */     if (tableSelectionModel == null)
/*      */       return; 
/*  613 */     if (tableSelectionModel.getSelectionMode() == SelectionMode.SINGLE) {
/*  614 */       selectNextRow();
/*      */       
/*      */       return;
/*      */     } 
/*  618 */     TableFocusModel tableFocusModel = getFocusModel();
/*  619 */     if (tableFocusModel == null)
/*      */       return; 
/*  621 */     if (tableSelectionModel.isCellSelectionEnabled()) {
/*  622 */       updateCellVerticalSelection(1, () -> getSelectionModel().selectBelowCell());
/*      */ 
/*      */     
/*      */     }
/*  626 */     else if (this.isShiftDown && hasAnchor()) {
/*  627 */       updateRowSelection(1);
/*      */     } else {
/*  629 */       tableSelectionModel.selectNext();
/*      */     } 
/*      */     
/*  632 */     this.onSelectNextRow.run();
/*      */   }
/*      */   
/*      */   protected void alsoSelectLeftCell() {
/*  636 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  637 */     if (tableSelectionModel == null || !tableSelectionModel.isCellSelectionEnabled())
/*      */       return; 
/*  639 */     updateCellHorizontalSelection(-1, () -> getSelectionModel().selectLeftCell());
/*  640 */     this.onSelectLeftCell.run();
/*      */   }
/*      */   
/*      */   protected void alsoSelectRightCell() {
/*  644 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  645 */     if (tableSelectionModel == null || !tableSelectionModel.isCellSelectionEnabled())
/*      */       return; 
/*  647 */     updateCellHorizontalSelection(1, () -> getSelectionModel().selectRightCell());
/*  648 */     this.onSelectRightCell.run();
/*      */   }
/*      */   
/*      */   protected void updateRowSelection(int paramInt) {
/*  652 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  653 */     if (tableSelectionModel == null || tableSelectionModel.getSelectionMode() == SelectionMode.SINGLE)
/*      */       return; 
/*  655 */     TableFocusModel tableFocusModel = getFocusModel();
/*  656 */     if (tableFocusModel == null)
/*      */       return; 
/*  658 */     int i = tableFocusModel.getFocusedIndex() + paramInt;
/*  659 */     TablePositionBase tablePositionBase = getAnchor();
/*      */     
/*  661 */     if (!hasAnchor()) {
/*  662 */       setAnchor(getFocusedCell());
/*      */     }
/*      */     
/*  665 */     if (tableSelectionModel.getSelectedIndices().size() > 1) {
/*  666 */       clearSelectionOutsideRange(tablePositionBase.getRow(), i, (TableColumnBase<T, ?>)null);
/*      */     }
/*      */     
/*  669 */     if (tablePositionBase.getRow() > i) {
/*  670 */       tableSelectionModel.selectRange(tablePositionBase.getRow(), i - 1);
/*      */     } else {
/*  672 */       tableSelectionModel.selectRange(tablePositionBase.getRow(), i + 1);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void updateCellVerticalSelection(int paramInt, Runnable paramRunnable) {
/*  677 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  678 */     if (tableSelectionModel == null || tableSelectionModel.getSelectionMode() == SelectionMode.SINGLE)
/*      */       return; 
/*  680 */     TableFocusModel tableFocusModel = getFocusModel();
/*  681 */     if (tableFocusModel == null)
/*      */       return; 
/*  683 */     TablePositionBase<TableColumnBase<T, ?>> tablePositionBase = getFocusedCell();
/*  684 */     int i = tablePositionBase.getRow();
/*      */     
/*  686 */     if (this.isShiftDown && tableSelectionModel.isSelected(i + paramInt, tablePositionBase.getTableColumn())) {
/*  687 */       int j = i + paramInt;
/*      */ 
/*      */       
/*  690 */       boolean bool = false;
/*  691 */       if (this.selectionHistory.size() >= 2) {
/*  692 */         TablePositionBase tablePositionBase1 = this.selectionHistory.get(1);
/*      */         
/*  694 */         bool = (tablePositionBase1.getRow() == j && tablePositionBase1.getColumn() == tablePositionBase.getColumn()) ? true : false;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  701 */       int k = this.selectionPathDeviated ? (bool ? i : j) : i;
/*      */       
/*  703 */       tableSelectionModel.clearSelection(k, tablePositionBase.getTableColumn());
/*  704 */       tableFocusModel.focus(j, tablePositionBase.getTableColumn());
/*  705 */     } else if (this.isShiftDown && getAnchor() != null && !this.selectionPathDeviated) {
/*  706 */       int j = tableFocusModel.getFocusedIndex() + paramInt;
/*      */ 
/*      */       
/*  709 */       j = Math.max(Math.min(getItemCount() - 1, j), 0);
/*      */       
/*  711 */       int k = Math.min(getAnchor().getRow(), j);
/*  712 */       int m = Math.max(getAnchor().getRow(), j);
/*      */       
/*  714 */       if (tableSelectionModel.getSelectedIndices().size() > 1) {
/*  715 */         clearSelectionOutsideRange(k, m, tablePositionBase.getTableColumn());
/*      */       }
/*      */       
/*  718 */       for (int n = k; n <= m; n++) {
/*  719 */         if (!tableSelectionModel.isSelected(n, tablePositionBase.getTableColumn()))
/*      */         {
/*      */           
/*  722 */           tableSelectionModel.select(n, tablePositionBase.getTableColumn()); } 
/*      */       } 
/*  724 */       tableFocusModel.focus(j, tablePositionBase.getTableColumn());
/*      */     } else {
/*  726 */       int j = tableFocusModel.getFocusedIndex();
/*  727 */       if (!tableSelectionModel.isSelected(j, tablePositionBase.getTableColumn())) {
/*  728 */         tableSelectionModel.select(j, tablePositionBase.getTableColumn());
/*      */       }
/*  730 */       paramRunnable.run();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void updateCellHorizontalSelection(int paramInt, Runnable paramRunnable) {
/*  735 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  736 */     if (tableSelectionModel == null || tableSelectionModel.getSelectionMode() == SelectionMode.SINGLE)
/*      */       return; 
/*  738 */     TableFocusModel tableFocusModel = getFocusModel();
/*  739 */     if (tableFocusModel == null)
/*      */       return; 
/*  741 */     TablePositionBase<TableColumnBase> tablePositionBase = getFocusedCell();
/*  742 */     if (tablePositionBase == null || tablePositionBase.getTableColumn() == null)
/*      */       return; 
/*  744 */     boolean bool = false;
/*  745 */     TableColumnBase<T, ?> tableColumnBase = getColumn(tablePositionBase.getTableColumn(), paramInt);
/*  746 */     if (tableColumnBase == null) {
/*      */ 
/*      */       
/*  749 */       tableColumnBase = tablePositionBase.getTableColumn();
/*  750 */       bool = true;
/*      */     } 
/*      */     
/*  753 */     int i = tablePositionBase.getRow();
/*      */     
/*  755 */     if (this.isShiftDown && tableSelectionModel.isSelected(i, tableColumnBase)) {
/*  756 */       if (bool) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  761 */       boolean bool1 = false;
/*  762 */       ObservableList<? extends TablePositionBase> observableList = getSelectedCells();
/*  763 */       if (observableList.size() >= 2) {
/*  764 */         TablePositionBase tablePositionBase1 = observableList.get(observableList.size() - 2);
/*      */         
/*  766 */         bool1 = (tablePositionBase1.getRow() == i && tablePositionBase1.getTableColumn().equals(tableColumnBase)) ? true : false;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  773 */       TableColumnBase tableColumnBase1 = (TableColumnBase)(this.selectionPathDeviated ? (bool1 ? tablePositionBase.getTableColumn() : tableColumnBase) : tablePositionBase.getTableColumn());
/*      */       
/*  775 */       tableSelectionModel.clearSelection(i, tableColumnBase1);
/*  776 */       tableFocusModel.focus(i, tableColumnBase);
/*  777 */     } else if (this.isShiftDown && getAnchor() != null && !this.selectionPathDeviated) {
/*  778 */       int j = getAnchor().getColumn();
/*      */ 
/*      */       
/*  781 */       int k = getVisibleLeafIndex(tablePositionBase.getTableColumn()) + paramInt;
/*  782 */       k = Math.max(Math.min(getVisibleLeafColumns().size() - 1, k), 0);
/*      */       
/*  784 */       int m = Math.min(j, k);
/*  785 */       int n = Math.max(j, k);
/*      */       
/*  787 */       for (int i1 = m; i1 <= n; i1++) {
/*  788 */         tableSelectionModel.select(tablePositionBase.getRow(), getColumn(i1));
/*      */       }
/*  790 */       tableFocusModel.focus(tablePositionBase.getRow(), getColumn(k));
/*      */     } else {
/*  792 */       paramRunnable.run();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected TableColumnBase getColumn(int paramInt) {
/*  797 */     return getVisibleLeafColumn(paramInt);
/*      */   }
/*      */   
/*      */   protected TableColumnBase getColumn(TableColumnBase paramTableColumnBase, int paramInt) {
/*  801 */     return getVisibleLeafColumn(getVisibleLeafIndex(paramTableColumnBase) + paramInt);
/*      */   }
/*      */   
/*      */   protected void selectFirstRow() {
/*  805 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  806 */     if (tableSelectionModel == null)
/*      */       return; 
/*  808 */     ObservableList<? extends TablePositionBase> observableList = getSelectedCells();
/*  809 */     TC tC = (observableList.size() == 0) ? null : (TC)((TablePositionBase)observableList.get(0)).getTableColumn();
/*  810 */     tableSelectionModel.clearAndSelect(0, (TableColumnBase<T, ?>)tC);
/*      */     
/*  812 */     if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*      */   }
/*      */   
/*      */   protected void selectLastRow() {
/*  816 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  817 */     if (tableSelectionModel == null)
/*      */       return; 
/*  819 */     ObservableList<? extends TablePositionBase> observableList = getSelectedCells();
/*  820 */     TC tC = (observableList.size() == 0) ? null : (TC)((TablePositionBase)observableList.get(0)).getTableColumn();
/*  821 */     tableSelectionModel.clearAndSelect(getItemCount() - 1, (TableColumnBase<T, ?>)tC);
/*      */     
/*  823 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*      */   }
/*      */   
/*      */   protected void selectPreviousRow() {
/*  827 */     selectCell(-1, 0);
/*  828 */     if (this.onSelectPreviousRow != null) this.onSelectPreviousRow.run(); 
/*      */   }
/*      */   
/*      */   protected void selectNextRow() {
/*  832 */     selectCell(1, 0);
/*  833 */     if (this.onSelectNextRow != null) this.onSelectNextRow.run(); 
/*      */   }
/*      */   
/*      */   protected void selectLeftCell() {
/*  837 */     selectCell(0, -1);
/*  838 */     if (this.onSelectLeftCell != null) this.onSelectLeftCell.run(); 
/*      */   }
/*      */   
/*      */   protected void selectRightCell() {
/*  842 */     selectCell(0, 1);
/*  843 */     if (this.onSelectRightCell != null) this.onSelectRightCell.run(); 
/*      */   }
/*      */   
/*      */   protected void selectCell(int paramInt1, int paramInt2) {
/*  847 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  848 */     if (tableSelectionModel == null)
/*      */       return; 
/*  850 */     TableFocusModel tableFocusModel = getFocusModel();
/*  851 */     if (tableFocusModel == null)
/*      */       return; 
/*  853 */     TablePositionBase<TableColumnBase> tablePositionBase = getFocusedCell();
/*  854 */     int i = tablePositionBase.getRow();
/*  855 */     int j = getVisibleLeafIndex(tablePositionBase.getTableColumn());
/*      */     
/*  857 */     if (paramInt1 < 0 && i <= 0)
/*  858 */       return;  if (paramInt1 > 0 && i >= getItemCount() - 1)
/*  859 */       return;  if (paramInt2 < 0 && j <= 0)
/*  860 */       return;  if (paramInt2 > 0 && j >= getVisibleLeafColumns().size() - 1)
/*  861 */       return;  if (paramInt2 > 0 && j == -1)
/*      */       return; 
/*  863 */     TableColumnBase<T, ?> tableColumnBase = (TableColumnBase<T, ?>)tablePositionBase.getTableColumn();
/*  864 */     tableColumnBase = getColumn(tableColumnBase, paramInt2);
/*      */     
/*  866 */     int k = tablePositionBase.getRow() + paramInt1;
/*  867 */     tableSelectionModel.clearAndSelect(k, tableColumnBase);
/*  868 */     setAnchor(k, tableColumnBase);
/*      */   }
/*      */   
/*      */   protected void cancelEdit(KeyEvent paramKeyEvent) {
/*  872 */     if (isControlEditable()) {
/*  873 */       editCell(-1, (TableColumnBase)null);
/*  874 */       paramKeyEvent.consume();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void activate(KeyEvent paramKeyEvent) {
/*  879 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  880 */     if (tableSelectionModel == null)
/*      */       return; 
/*  882 */     TableFocusModel tableFocusModel = getFocusModel();
/*  883 */     if (tableFocusModel == null)
/*      */       return; 
/*  885 */     TablePositionBase<TableColumnBase<T, ?>> tablePositionBase = getFocusedCell();
/*  886 */     tableSelectionModel.select(tablePositionBase.getRow(), tablePositionBase.getTableColumn());
/*  887 */     setAnchor(tablePositionBase);
/*      */ 
/*      */     
/*  890 */     boolean bool = (isControlEditable() && tablePositionBase.getTableColumn().isEditable()) ? true : false;
/*      */ 
/*      */     
/*  893 */     if (bool && tablePositionBase.getRow() >= 0) {
/*  894 */       editCell(tablePositionBase.getRow(), tablePositionBase.getTableColumn());
/*  895 */       paramKeyEvent.consume();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void selectAllToFocus(boolean paramBoolean) {
/*  900 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  901 */     if (tableSelectionModel == null)
/*      */       return; 
/*  903 */     TableFocusModel tableFocusModel = getFocusModel();
/*  904 */     if (tableFocusModel == null)
/*      */       return; 
/*  906 */     TablePositionBase<TableColumnBase<T, ?>> tablePositionBase1 = getFocusedCell();
/*  907 */     int i = tablePositionBase1.getRow();
/*      */     
/*  909 */     TablePositionBase<TableColumnBase<T, ?>> tablePositionBase2 = getAnchor();
/*  910 */     int j = tablePositionBase2.getRow();
/*      */     
/*  912 */     tableSelectionModel.clearSelection();
/*  913 */     if (!tableSelectionModel.isCellSelectionEnabled()) {
/*  914 */       int k = j;
/*  915 */       int m = (j > i) ? (i - 1) : (i + 1);
/*  916 */       tableSelectionModel.selectRange(k, m);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  921 */       tableSelectionModel.selectRange(tablePositionBase2.getRow(), tablePositionBase2.getTableColumn(), tablePositionBase1
/*  922 */           .getRow(), tablePositionBase1.getTableColumn());
/*      */     } 
/*      */     
/*  925 */     setAnchor(paramBoolean ? tablePositionBase1 : tablePositionBase2);
/*      */   }
/*      */   
/*      */   protected void selectAll() {
/*  929 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  930 */     if (tableSelectionModel == null)
/*  931 */       return;  tableSelectionModel.selectAll();
/*      */   }
/*      */   
/*      */   protected void selectAllToFirstRow() {
/*  935 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  936 */     if (tableSelectionModel == null)
/*      */       return; 
/*  938 */     TableFocusModel tableFocusModel = getFocusModel();
/*  939 */     if (tableFocusModel == null)
/*      */       return; 
/*  941 */     boolean bool = (tableSelectionModel.getSelectionMode() == SelectionMode.SINGLE) ? true : false;
/*  942 */     TablePositionBase tablePositionBase = getFocusedCell();
/*  943 */     TableColumnBase<T, ?> tableColumnBase = (TableColumnBase<T, ?>)getFocusedCell().getTableColumn();
/*  944 */     int i = tablePositionBase.getRow();
/*      */     
/*  946 */     if (this.isShiftDown) {
/*  947 */       i = (getAnchor() == null) ? i : getAnchor().getRow();
/*      */     }
/*      */     
/*  950 */     tableSelectionModel.clearSelection();
/*  951 */     if (!tableSelectionModel.isCellSelectionEnabled()) {
/*      */ 
/*      */       
/*  954 */       if (bool) {
/*  955 */         tableSelectionModel.select(0);
/*      */       } else {
/*  957 */         tableSelectionModel.selectRange(i, -1);
/*      */       } 
/*  959 */       tableFocusModel.focus(0);
/*      */     } else {
/*  961 */       if (bool) {
/*  962 */         tableSelectionModel.select(0, tableColumnBase);
/*      */       } else {
/*  964 */         tableSelectionModel.selectRange(i, tableColumnBase, -1, tableColumnBase);
/*      */       } 
/*  966 */       tableFocusModel.focus(0, tableColumnBase);
/*      */     } 
/*      */     
/*  969 */     if (this.isShiftDown) {
/*  970 */       setAnchor(i, tableColumnBase);
/*      */     }
/*      */     
/*  973 */     if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*      */   }
/*      */   
/*      */   protected void selectAllToLastRow() {
/*  977 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/*  978 */     if (tableSelectionModel == null)
/*      */       return; 
/*  980 */     TableFocusModel tableFocusModel = getFocusModel();
/*  981 */     if (tableFocusModel == null)
/*      */       return; 
/*  983 */     int i = getItemCount();
/*  984 */     TablePositionBase tablePositionBase = getFocusedCell();
/*  985 */     TableColumnBase<T, ?> tableColumnBase = (TableColumnBase<T, ?>)getFocusedCell().getTableColumn();
/*  986 */     int j = tablePositionBase.getRow();
/*      */     
/*  988 */     if (this.isShiftDown) {
/*  989 */       j = (getAnchor() == null) ? j : getAnchor().getRow();
/*      */     }
/*      */     
/*  992 */     tableSelectionModel.clearSelection();
/*  993 */     if (!tableSelectionModel.isCellSelectionEnabled()) {
/*  994 */       tableSelectionModel.selectRange(j, i);
/*      */     } else {
/*  996 */       tableSelectionModel.selectRange(j, tableColumnBase, i - 1, tableColumnBase);
/*      */     } 
/*      */     
/*  999 */     if (this.isShiftDown) {
/* 1000 */       setAnchor(j, tableColumnBase);
/*      */     }
/*      */     
/* 1003 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*      */   }
/*      */   
/*      */   protected void selectAllPageUp() {
/* 1007 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1008 */     if (tableSelectionModel == null)
/*      */       return; 
/* 1010 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1011 */     if (tableFocusModel == null)
/*      */       return; 
/* 1013 */     int i = tableFocusModel.getFocusedIndex();
/* 1014 */     TC tC = tableSelectionModel.isCellSelectionEnabled() ? (TC)getFocusedCell().getTableColumn() : null;
/* 1015 */     if (this.isShiftDown) {
/* 1016 */       i = (getAnchor() == null) ? i : getAnchor().getRow();
/* 1017 */       setAnchor(i, (TableColumnBase)tC);
/*      */     } 
/*      */     
/* 1020 */     int j = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(false))).intValue();
/*      */     
/* 1022 */     this.selectionChanging = true;
/* 1023 */     if (tableSelectionModel.getSelectionMode() == null || tableSelectionModel.getSelectionMode() == SelectionMode.SINGLE) {
/* 1024 */       if (tableSelectionModel.isCellSelectionEnabled()) {
/* 1025 */         tableSelectionModel.select(j, (TableColumnBase<T, ?>)tC);
/*      */       } else {
/* 1027 */         tableSelectionModel.select(j);
/*      */       } 
/*      */     } else {
/* 1030 */       tableSelectionModel.clearSelection();
/* 1031 */       if (tableSelectionModel.isCellSelectionEnabled()) {
/* 1032 */         tableSelectionModel.selectRange(i, (TableColumnBase<T, ?>)tC, j, (TableColumnBase<T, ?>)tC);
/*      */       } else {
/*      */         
/* 1035 */         byte b = (i < j) ? 1 : -1;
/* 1036 */         tableSelectionModel.selectRange(i, j + b);
/*      */       } 
/*      */     } 
/* 1039 */     this.selectionChanging = false;
/*      */   }
/*      */   
/*      */   protected void selectAllPageDown() {
/* 1043 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1044 */     if (tableSelectionModel == null)
/*      */       return; 
/* 1046 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1047 */     if (tableFocusModel == null)
/*      */       return; 
/* 1049 */     int i = tableFocusModel.getFocusedIndex();
/* 1050 */     TC tC = tableSelectionModel.isCellSelectionEnabled() ? (TC)getFocusedCell().getTableColumn() : null;
/* 1051 */     if (this.isShiftDown) {
/* 1052 */       i = (getAnchor() == null) ? i : getAnchor().getRow();
/* 1053 */       setAnchor(i, (TableColumnBase)tC);
/*      */     } 
/*      */     
/* 1056 */     int j = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(false))).intValue();
/*      */     
/* 1058 */     this.selectionChanging = true;
/* 1059 */     if (tableSelectionModel.getSelectionMode() == null || tableSelectionModel.getSelectionMode() == SelectionMode.SINGLE) {
/* 1060 */       if (tableSelectionModel.isCellSelectionEnabled()) {
/* 1061 */         tableSelectionModel.select(j, (TableColumnBase<T, ?>)tC);
/*      */       } else {
/* 1063 */         tableSelectionModel.select(j);
/*      */       } 
/*      */     } else {
/* 1066 */       tableSelectionModel.clearSelection();
/*      */       
/* 1068 */       if (tableSelectionModel.isCellSelectionEnabled()) {
/* 1069 */         tableSelectionModel.selectRange(i, (TableColumnBase<T, ?>)tC, j, (TableColumnBase<T, ?>)tC);
/*      */       } else {
/*      */         
/* 1072 */         byte b = (i < j) ? 1 : -1;
/* 1073 */         tableSelectionModel.selectRange(i, j + b);
/*      */       } 
/*      */     } 
/* 1076 */     this.selectionChanging = false;
/*      */   }
/*      */   
/*      */   protected void toggleFocusOwnerSelection() {
/* 1080 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1081 */     if (tableSelectionModel == null)
/*      */       return; 
/* 1083 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1084 */     if (tableFocusModel == null)
/*      */       return; 
/* 1086 */     TablePositionBase<TableColumnBase<T, ?>> tablePositionBase = getFocusedCell();
/*      */     
/* 1088 */     if (tableSelectionModel.isSelected(tablePositionBase.getRow(), tablePositionBase.getTableColumn())) {
/* 1089 */       tableSelectionModel.clearSelection(tablePositionBase.getRow(), tablePositionBase.getTableColumn());
/* 1090 */       tableFocusModel.focus(tablePositionBase.getRow(), tablePositionBase.getTableColumn());
/*      */     } else {
/* 1092 */       tableSelectionModel.select(tablePositionBase.getRow(), tablePositionBase.getTableColumn());
/*      */     } 
/*      */     
/* 1095 */     setAnchor(tablePositionBase.getRow(), tablePositionBase.getTableColumn());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void discontinuousSelectPreviousRow() {
/* 1142 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1143 */     if (tableSelectionModel == null)
/*      */       return; 
/* 1145 */     if (tableSelectionModel.getSelectionMode() != SelectionMode.MULTIPLE) {
/* 1146 */       selectPreviousRow();
/*      */       
/*      */       return;
/*      */     } 
/* 1150 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1151 */     if (tableFocusModel == null)
/*      */       return; 
/* 1153 */     int i = tableFocusModel.getFocusedIndex();
/* 1154 */     int j = i - 1;
/* 1155 */     if (j < 0)
/*      */       return; 
/* 1157 */     int k = i;
/* 1158 */     TC tC = tableSelectionModel.isCellSelectionEnabled() ? (TC)getFocusedCell().getTableColumn() : null;
/* 1159 */     if (this.isShiftDown) {
/* 1160 */       k = (getAnchor() == null) ? i : getAnchor().getRow();
/*      */     }
/*      */     
/* 1163 */     if (!tableSelectionModel.isCellSelectionEnabled()) {
/* 1164 */       tableSelectionModel.selectRange(j, k + 1);
/* 1165 */       tableFocusModel.focus(j);
/*      */     } else {
/* 1167 */       for (int m = j; m < k + 1; m++) {
/* 1168 */         tableSelectionModel.select(m, (TableColumnBase<T, ?>)tC);
/*      */       }
/* 1170 */       tableFocusModel.focus(j, tC);
/*      */     } 
/*      */     
/* 1173 */     if (this.onFocusPreviousRow != null) this.onFocusPreviousRow.run(); 
/*      */   }
/*      */   
/*      */   protected void discontinuousSelectNextRow() {
/* 1177 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1178 */     if (tableSelectionModel == null)
/*      */       return; 
/* 1180 */     if (tableSelectionModel.getSelectionMode() != SelectionMode.MULTIPLE) {
/* 1181 */       selectNextRow();
/*      */       
/*      */       return;
/*      */     } 
/* 1185 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1186 */     if (tableFocusModel == null)
/*      */       return; 
/* 1188 */     int i = tableFocusModel.getFocusedIndex();
/* 1189 */     int j = i + 1;
/* 1190 */     if (j >= getItemCount())
/*      */       return; 
/* 1192 */     int k = i;
/* 1193 */     TC tC = tableSelectionModel.isCellSelectionEnabled() ? (TC)getFocusedCell().getTableColumn() : null;
/* 1194 */     if (this.isShiftDown) {
/* 1195 */       k = (getAnchor() == null) ? i : getAnchor().getRow();
/*      */     }
/*      */     
/* 1198 */     if (!tableSelectionModel.isCellSelectionEnabled()) {
/* 1199 */       tableSelectionModel.selectRange(k, j + 1);
/* 1200 */       tableFocusModel.focus(j);
/*      */     } else {
/* 1202 */       for (int m = k; m < j + 1; m++) {
/* 1203 */         tableSelectionModel.select(m, (TableColumnBase<T, ?>)tC);
/*      */       }
/* 1205 */       tableFocusModel.focus(j, tC);
/*      */     } 
/*      */     
/* 1208 */     if (this.onFocusNextRow != null) this.onFocusNextRow.run(); 
/*      */   }
/*      */   
/*      */   protected void discontinuousSelectPreviousColumn() {
/* 1212 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1213 */     if (tableSelectionModel == null || !tableSelectionModel.isCellSelectionEnabled())
/*      */       return; 
/* 1215 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1216 */     if (tableFocusModel == null)
/*      */       return; 
/* 1218 */     TableColumnBase<T, ?> tableColumnBase = getColumn(getFocusedCell().getTableColumn(), -1);
/* 1219 */     tableSelectionModel.select(tableFocusModel.getFocusedIndex(), tableColumnBase);
/*      */   }
/*      */   
/*      */   protected void discontinuousSelectNextColumn() {
/* 1223 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1224 */     if (tableSelectionModel == null || !tableSelectionModel.isCellSelectionEnabled())
/*      */       return; 
/* 1226 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1227 */     if (tableFocusModel == null)
/*      */       return; 
/* 1229 */     TableColumnBase<T, ?> tableColumnBase = getColumn(getFocusedCell().getTableColumn(), 1);
/* 1230 */     tableSelectionModel.select(tableFocusModel.getFocusedIndex(), tableColumnBase);
/*      */   }
/*      */   
/*      */   protected void discontinuousSelectPageUp() {
/* 1234 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1235 */     if (tableSelectionModel == null)
/*      */       return; 
/* 1237 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1238 */     if (tableFocusModel == null)
/*      */       return; 
/* 1240 */     int i = hasAnchor() ? getAnchor().getRow() : tableFocusModel.getFocusedIndex();
/* 1241 */     int j = ((Integer)this.onScrollPageUp.call(Boolean.valueOf(false))).intValue();
/*      */     
/* 1243 */     if (!tableSelectionModel.isCellSelectionEnabled()) {
/* 1244 */       tableSelectionModel.selectRange(i, j - 1);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void discontinuousSelectPageDown() {
/* 1249 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1250 */     if (tableSelectionModel == null)
/*      */       return; 
/* 1252 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1253 */     if (tableFocusModel == null)
/*      */       return; 
/* 1255 */     int i = hasAnchor() ? getAnchor().getRow() : tableFocusModel.getFocusedIndex();
/* 1256 */     int j = ((Integer)this.onScrollPageDown.call(Boolean.valueOf(false))).intValue();
/*      */     
/* 1258 */     if (!tableSelectionModel.isCellSelectionEnabled()) {
/* 1259 */       tableSelectionModel.selectRange(i, j + 1);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void discontinuousSelectAllToFirstRow() {
/* 1264 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1265 */     if (tableSelectionModel == null)
/*      */       return; 
/* 1267 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1268 */     if (tableFocusModel == null)
/*      */       return; 
/* 1270 */     int i = tableFocusModel.getFocusedIndex();
/*      */     
/* 1272 */     if (!tableSelectionModel.isCellSelectionEnabled()) {
/* 1273 */       tableSelectionModel.selectRange(0, i);
/* 1274 */       tableFocusModel.focus(0);
/*      */     } else {
/* 1276 */       for (byte b = 0; b < i; b++) {
/* 1277 */         tableSelectionModel.select(b, getFocusedCell().getTableColumn());
/*      */       }
/* 1279 */       tableFocusModel.focus(0, getFocusedCell().getTableColumn());
/*      */     } 
/*      */     
/* 1282 */     if (this.onMoveToFirstCell != null) this.onMoveToFirstCell.run(); 
/*      */   }
/*      */   
/*      */   protected void discontinuousSelectAllToLastRow() {
/* 1286 */     TableSelectionModel<T> tableSelectionModel = getSelectionModel();
/* 1287 */     if (tableSelectionModel == null)
/*      */       return; 
/* 1289 */     TableFocusModel tableFocusModel = getFocusModel();
/* 1290 */     if (tableFocusModel == null)
/*      */       return; 
/* 1292 */     int i = tableFocusModel.getFocusedIndex() + 1;
/*      */     
/* 1294 */     if (!tableSelectionModel.isCellSelectionEnabled()) {
/* 1295 */       tableSelectionModel.selectRange(i, getItemCount());
/*      */     } else {
/* 1297 */       for (int j = i; j < getItemCount(); j++) {
/* 1298 */         tableSelectionModel.select(j, getFocusedCell().getTableColumn());
/*      */       }
/*      */     } 
/*      */     
/* 1302 */     if (this.onMoveToLastCell != null) this.onMoveToLastCell.run(); 
/*      */   }
/*      */   
/*      */   protected abstract int getItemCount();
/*      */   
/*      */   protected abstract TableFocusModel getFocusModel();
/*      */   
/*      */   protected abstract TableSelectionModel<T> getSelectionModel();
/*      */   
/*      */   protected abstract ObservableList<? extends TablePositionBase> getSelectedCells();
/*      */   
/*      */   protected abstract TablePositionBase getFocusedCell();
/*      */   
/*      */   protected abstract int getVisibleLeafIndex(TableColumnBase paramTableColumnBase);
/*      */   
/*      */   protected abstract TableColumnBase getVisibleLeafColumn(int paramInt);
/*      */   
/*      */   protected abstract boolean isControlEditable();
/*      */   
/*      */   protected abstract void editCell(int paramInt, TableColumnBase paramTableColumnBase);
/*      */   
/*      */   protected abstract ObservableList<? extends TableColumnBase> getVisibleLeafColumns();
/*      */   
/*      */   protected abstract TablePositionBase<TC> getTablePosition(int paramInt, TableColumnBase<T, ?> paramTableColumnBase);
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TableViewBehaviorBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */