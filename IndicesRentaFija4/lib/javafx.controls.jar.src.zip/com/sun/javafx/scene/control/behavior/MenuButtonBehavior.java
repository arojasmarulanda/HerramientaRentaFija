/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*    */ import javafx.scene.control.MenuButton;
/*    */ import javafx.scene.input.KeyCode;
/*    */ import javafx.scene.input.KeyEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MenuButtonBehavior
/*    */   extends MenuButtonBehaviorBase<MenuButton>
/*    */ {
/*    */   public MenuButtonBehavior(MenuButton paramMenuButton) {
/* 51 */     super(paramMenuButton);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 56 */     addDefaultMapping((InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, paramKeyEvent -> openAction()) });
/* 57 */     addDefaultMapping((InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.ENTER, paramKeyEvent -> openAction()) });
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\MenuButtonBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */