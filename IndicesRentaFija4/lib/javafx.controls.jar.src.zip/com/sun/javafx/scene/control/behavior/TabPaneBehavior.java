/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.Event;
/*     */ import javafx.scene.control.SingleSelectionModel;
/*     */ import javafx.scene.control.Tab;
/*     */ import javafx.scene.control.TabPane;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabPaneBehavior
/*     */   extends BehaviorBase<TabPane>
/*     */ {
/*     */   private final InputMap<TabPane> tabPaneInputMap;
/*     */   
/*     */   public TabPaneBehavior(TabPane paramTabPane) {
/*  47 */     super(paramTabPane);
/*     */ 
/*     */ 
/*     */     
/*  51 */     this.tabPaneInputMap = createInputMap();
/*     */ 
/*     */     
/*  54 */     addDefaultMapping(this.tabPaneInputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> selectPreviousTab()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> selectNextTab()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> rtl(paramTabPane, this::selectNextTab, this::selectPreviousTab)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> rtl(paramTabPane, this::selectPreviousTab, this::selectNextTab)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.HOME, paramKeyEvent -> { if (getNode().isFocused()) moveSelection(-1, 1);  }), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.END, paramKeyEvent -> { if (getNode().isFocused()) moveSelection(getNode().getTabs().size(), -1);  }), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_UP))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  69 */             .ctrl(), paramKeyEvent -> selectPreviousTab()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.PAGE_DOWN))
/*  70 */             .ctrl(), paramKeyEvent -> selectNextTab()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB))
/*  71 */             .ctrl(), paramKeyEvent -> selectNextTab()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB))
/*  72 */             .ctrl().shift(), paramKeyEvent -> selectPreviousTab()), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, paramMouseEvent -> getNode().requestFocus()) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InputMap<TabPane> getInputMap() {
/*  78 */     return this.tabPaneInputMap;
/*     */   }
/*     */   
/*     */   public void selectTab(Tab paramTab) {
/*  82 */     getNode().getSelectionModel().select(paramTab);
/*     */   }
/*     */   
/*     */   public boolean canCloseTab(Tab paramTab) {
/*  86 */     Event event = new Event(paramTab, paramTab, Tab.TAB_CLOSE_REQUEST_EVENT);
/*  87 */     Event.fireEvent(paramTab, event);
/*  88 */     return !event.isConsumed();
/*     */   }
/*     */   
/*     */   public void closeTab(Tab paramTab) {
/*  92 */     TabPane tabPane = getNode();
/*     */     
/*  94 */     int i = tabPane.getTabs().indexOf(paramTab);
/*  95 */     if (i != -1) {
/*  96 */       tabPane.getTabs().remove(i);
/*     */     }
/*  98 */     if (paramTab.getOnClosed() != null) {
/*  99 */       Event.fireEvent(paramTab, new Event(Tab.CLOSED_EVENT));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectNextTab() {
/* 106 */     moveSelection(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void selectPreviousTab() {
/* 111 */     moveSelection(-1);
/*     */   }
/*     */   
/*     */   private void moveSelection(int paramInt) {
/* 115 */     moveSelection(getNode().getSelectionModel().getSelectedIndex(), paramInt);
/*     */   }
/*     */   
/*     */   private void moveSelection(int paramInt1, int paramInt2) {
/* 119 */     TabPane tabPane = getNode();
/* 120 */     if (tabPane.getTabs().isEmpty())
/*     */       return; 
/* 122 */     int i = findValidTab(paramInt1, paramInt2);
/* 123 */     if (i > -1) {
/* 124 */       SingleSelectionModel<Tab> singleSelectionModel = tabPane.getSelectionModel();
/* 125 */       singleSelectionModel.select(i);
/*     */     } 
/* 127 */     tabPane.requestFocus();
/*     */   }
/*     */   
/*     */   private int findValidTab(int paramInt1, int paramInt2) {
/* 131 */     TabPane tabPane = getNode();
/* 132 */     ObservableList<Tab> observableList = tabPane.getTabs();
/* 133 */     int i = observableList.size();
/*     */     
/* 135 */     int j = paramInt1;
/*     */     do {
/* 137 */       j = nextIndex(j + paramInt2, i);
/* 138 */       Tab tab = observableList.get(j);
/* 139 */       if (tab != null && !tab.isDisable()) {
/* 140 */         return j;
/*     */       }
/* 142 */     } while (j != paramInt1);
/*     */     
/* 144 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private int nextIndex(int paramInt1, int paramInt2) {
/* 149 */     int i = paramInt1 % paramInt2;
/* 150 */     if (i > 0 && paramInt2 < 0) {
/* 151 */       i = i + paramInt2 - 0;
/* 152 */     } else if (i < 0 && paramInt2 > 0) {
/* 153 */       i = i + paramInt2 - 0;
/*     */     } 
/* 155 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TabPaneBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */