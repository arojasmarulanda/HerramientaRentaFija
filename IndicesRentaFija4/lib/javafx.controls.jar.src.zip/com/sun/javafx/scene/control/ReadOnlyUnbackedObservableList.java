/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableListBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReadOnlyUnbackedObservableList<E>
/*     */   extends ObservableListBase<E>
/*     */ {
/*     */   public abstract E get(int paramInt);
/*     */   
/*     */   public abstract int size();
/*     */   
/*     */   public void _beginChange() {
/*  60 */     beginChange();
/*     */   }
/*     */   
/*     */   public void _endChange() {
/*  64 */     endChange();
/*     */   }
/*     */   
/*     */   public void _nextUpdate(int paramInt) {
/*  68 */     nextUpdate(paramInt);
/*     */   }
/*     */   
/*     */   public void _nextSet(int paramInt, E paramE) {
/*  72 */     nextSet(paramInt, paramE);
/*     */   }
/*     */   
/*     */   public void _nextReplace(int paramInt1, int paramInt2, List<? extends E> paramList) {
/*  76 */     nextReplace(paramInt1, paramInt2, paramList);
/*     */   }
/*     */   
/*     */   public void _nextRemove(int paramInt, List<? extends E> paramList) {
/*  80 */     nextRemove(paramInt, paramList);
/*     */   }
/*     */   
/*     */   public void _nextRemove(E paramE) {
/*  84 */     int i = indexOf(paramE);
/*  85 */     _nextRemove(i, paramE);
/*     */   }
/*     */   
/*     */   public void _nextRemove(int paramInt, E paramE) {
/*  89 */     nextRemove(paramInt, paramE);
/*     */   }
/*     */   
/*     */   public void _nextPermutation(int paramInt1, int paramInt2, int[] paramArrayOfint) {
/*  93 */     nextPermutation(paramInt1, paramInt2, paramArrayOfint);
/*     */   }
/*     */   
/*     */   public void _nextAdd(int paramInt1, int paramInt2) {
/*  97 */     nextAdd(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public void fireChange(Runnable paramRunnable) {
/* 101 */     _beginChange();
/* 102 */     paramRunnable.run();
/* 103 */     _endChange();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void callObservers(ListChangeListener.Change<E> paramChange) {
/* 110 */     fireChange(paramChange);
/*     */   }
/*     */   
/*     */   public int indexOf(Object paramObject) {
/* 114 */     if (paramObject == null) return -1;
/*     */     
/* 116 */     for (byte b = 0; b < size(); b++) {
/* 117 */       E e = get(b);
/* 118 */       if (paramObject.equals(e)) return b;
/*     */     
/*     */     } 
/* 121 */     return -1;
/*     */   }
/*     */   
/*     */   public int lastIndexOf(Object paramObject) {
/* 125 */     if (paramObject == null) return -1;
/*     */     
/* 127 */     for (int i = size() - 1; i >= 0; i--) {
/* 128 */       E e = get(i);
/* 129 */       if (paramObject.equals(e)) return i;
/*     */     
/*     */     } 
/* 132 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean contains(Object paramObject) {
/* 136 */     return (indexOf(paramObject) != -1);
/*     */   }
/*     */   
/*     */   public boolean containsAll(Collection<?> paramCollection) {
/* 140 */     for (Object object : paramCollection) {
/* 141 */       if (!contains(object)) {
/* 142 */         return false;
/*     */       }
/*     */     } 
/* 145 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 149 */     return (size() == 0);
/*     */   }
/*     */   
/*     */   public ListIterator<E> listIterator() {
/* 153 */     return new SelectionListIterator<>(this);
/*     */   }
/*     */   
/*     */   public ListIterator<E> listIterator(int paramInt) {
/* 157 */     return new SelectionListIterator<>(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 162 */     return new SelectionListIterator<>(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<E> subList(final int fromIndex, final int toIndex) {
/* 170 */     if (fromIndex < 0 || toIndex > size() || fromIndex > toIndex) {
/* 171 */       throw new IndexOutOfBoundsException("[ fromIndex: " + fromIndex + ", toIndex: " + toIndex + ", size: " + size() + " ]");
/*     */     }
/*     */     
/* 174 */     final ReadOnlyUnbackedObservableList outer = this;
/* 175 */     return new ReadOnlyUnbackedObservableList<E>() {
/*     */         public E get(int param1Int) {
/* 177 */           return outer.get(param1Int + fromIndex);
/*     */         }
/*     */         
/*     */         public int size() {
/* 181 */           return toIndex - fromIndex;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 188 */     Object[] arrayOfObject = new Object[size()];
/* 189 */     for (byte b = 0; b < size(); b++) {
/* 190 */       arrayOfObject[b] = get(b);
/*     */     }
/* 192 */     return arrayOfObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] paramArrayOfT) {
/* 198 */     Object[] arrayOfObject = toArray();
/* 199 */     int i = arrayOfObject.length;
/*     */     
/* 201 */     if (paramArrayOfT.length < i)
/*     */     {
/* 203 */       return Arrays.copyOf(arrayOfObject, i, (Class)paramArrayOfT.getClass()); } 
/* 204 */     System.arraycopy(arrayOfObject, 0, paramArrayOfT, 0, i);
/* 205 */     if (paramArrayOfT.length > i)
/* 206 */       paramArrayOfT[i] = null; 
/* 207 */     return paramArrayOfT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 213 */     Iterator<E> iterator = iterator();
/* 214 */     if (!iterator.hasNext()) {
/* 215 */       return "[]";
/*     */     }
/* 217 */     StringBuilder stringBuilder = new StringBuilder();
/* 218 */     stringBuilder.append('[');
/*     */     while (true) {
/* 220 */       E e = iterator.next();
/* 221 */       stringBuilder.append((e == this) ? "(this Collection)" : e);
/* 222 */       if (!iterator.hasNext())
/* 223 */         return stringBuilder.append(']').toString(); 
/* 224 */       stringBuilder.append(", ");
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean add(E paramE) {
/* 229 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public void add(int paramInt, E paramE) {
/* 233 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public boolean addAll(Collection<? extends E> paramCollection) {
/* 237 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public boolean addAll(int paramInt, Collection<? extends E> paramCollection) {
/* 241 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public boolean addAll(E... paramVarArgs) {
/* 245 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public E set(int paramInt, E paramE) {
/* 249 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public boolean setAll(Collection<? extends E> paramCollection) {
/* 253 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public boolean setAll(E... paramVarArgs) {
/* 257 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public void clear() {
/* 261 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public E remove(int paramInt) {
/* 265 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public boolean remove(Object paramObject) {
/* 269 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public boolean removeAll(Collection<?> paramCollection) {
/* 273 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public boolean retainAll(Collection<?> paramCollection) {
/* 277 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public void remove(int paramInt1, int paramInt2) {
/* 281 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public boolean removeAll(E... paramVarArgs) {
/* 285 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   public boolean retainAll(E... paramVarArgs) {
/* 289 */     throw new UnsupportedOperationException("Not supported.");
/*     */   }
/*     */   
/*     */   private static class SelectionListIterator<E>
/*     */     implements ListIterator<E> {
/*     */     private int pos;
/*     */     private final ReadOnlyUnbackedObservableList<E> list;
/*     */     
/*     */     public SelectionListIterator(ReadOnlyUnbackedObservableList<E> param1ReadOnlyUnbackedObservableList) {
/* 298 */       this(param1ReadOnlyUnbackedObservableList, 0);
/*     */     }
/*     */     
/*     */     public SelectionListIterator(ReadOnlyUnbackedObservableList<E> param1ReadOnlyUnbackedObservableList, int param1Int) {
/* 302 */       this.list = param1ReadOnlyUnbackedObservableList;
/* 303 */       this.pos = param1Int;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 307 */       return (this.pos < this.list.size());
/*     */     }
/*     */     
/*     */     public E next() {
/* 311 */       if (!hasNext()) {
/* 312 */         throw new NoSuchElementException();
/*     */       }
/* 314 */       return this.list.get(this.pos++);
/*     */     }
/*     */     
/*     */     public boolean hasPrevious() {
/* 318 */       return (this.pos > 0);
/*     */     }
/*     */     
/*     */     public E previous() {
/* 322 */       if (!hasPrevious()) {
/* 323 */         throw new NoSuchElementException();
/*     */       }
/* 325 */       return this.list.get(--this.pos);
/*     */     }
/*     */     
/*     */     public int nextIndex() {
/* 329 */       return this.pos;
/*     */     }
/*     */     
/*     */     public int previousIndex() {
/* 333 */       return this.pos - 1;
/*     */     }
/*     */     
/*     */     public void remove() {
/* 337 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */     
/*     */     public void set(E param1E) {
/* 341 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */     
/*     */     public void add(E param1E) {
/* 345 */       throw new UnsupportedOperationException("Not supported.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\ReadOnlyUnbackedObservableList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */