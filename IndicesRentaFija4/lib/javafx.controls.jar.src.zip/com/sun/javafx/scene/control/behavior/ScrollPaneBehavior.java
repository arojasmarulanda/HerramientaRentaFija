/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import java.util.Optional;
/*     */ import javafx.scene.control.ScrollBar;
/*     */ import javafx.scene.control.ScrollPane;
/*     */ import javafx.scene.control.skin.ScrollPaneSkin;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrollPaneBehavior
/*     */   extends BehaviorBase<ScrollPane>
/*     */ {
/*     */   private final InputMap<ScrollPane> inputMap;
/*     */   
/*     */   public ScrollPaneBehavior(ScrollPane paramScrollPane) {
/*  66 */     super(paramScrollPane);
/*     */ 
/*     */ 
/*     */     
/*  70 */     this.inputMap = createInputMap();
/*     */ 
/*     */     
/*  73 */     addDefaultMapping(this.inputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.LEFT, paramKeyEvent -> rtl(paramScrollPane, this::horizontalUnitIncrement, this::horizontalUnitDecrement)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.RIGHT, paramKeyEvent -> rtl(paramScrollPane, this::horizontalUnitDecrement, this::horizontalUnitIncrement)), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.UP, paramKeyEvent -> verticalUnitDecrement()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.DOWN, paramKeyEvent -> verticalUnitIncrement()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.PAGE_UP, paramKeyEvent -> verticalPageDecrement()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.PAGE_DOWN, paramKeyEvent -> verticalPageIncrement()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, paramKeyEvent -> verticalPageIncrement()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.HOME, paramKeyEvent -> verticalHome()), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.END, paramKeyEvent -> verticalEnd()), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputMap<ScrollPane> getInputMap() {
/* 100 */     return this.inputMap;
/*     */   }
/*     */   
/*     */   public void horizontalUnitIncrement() {
/* 104 */     getHorizontalScrollBar().ifPresent(ScrollBar::increment);
/*     */   }
/*     */   public void horizontalUnitDecrement() {
/* 107 */     getHorizontalScrollBar().ifPresent(ScrollBar::decrement);
/*     */   }
/*     */   public void verticalUnitIncrement() {
/* 110 */     getVerticalScrollBar().ifPresent(ScrollBar::increment);
/*     */   }
/*     */   void verticalUnitDecrement() {
/* 113 */     getVerticalScrollBar().ifPresent(ScrollBar::decrement);
/*     */   }
/*     */   void horizontalPageIncrement() {
/* 116 */     getHorizontalScrollBar().ifPresent(ScrollBar::increment);
/*     */   }
/*     */   void horizontalPageDecrement() {
/* 119 */     getHorizontalScrollBar().ifPresent(ScrollBar::decrement);
/*     */   }
/*     */   void verticalPageIncrement() {
/* 122 */     getVerticalScrollBar().ifPresent(ScrollBar::increment);
/*     */   }
/*     */   void verticalPageDecrement() {
/* 125 */     getVerticalScrollBar().ifPresent(ScrollBar::decrement);
/*     */   }
/*     */   void verticalHome() {
/* 128 */     ScrollPane scrollPane = getNode();
/* 129 */     scrollPane.setHvalue(scrollPane.getHmin());
/* 130 */     scrollPane.setVvalue(scrollPane.getVmin());
/*     */   }
/*     */   void verticalEnd() {
/* 133 */     ScrollPane scrollPane = getNode();
/* 134 */     scrollPane.setHvalue(scrollPane.getHmax());
/* 135 */     scrollPane.setVvalue(scrollPane.getVmax());
/*     */   }
/*     */   
/*     */   private Optional<ScrollBar> getVerticalScrollBar() {
/* 139 */     return Optional.ofNullable(((ScrollPaneSkin)getNode().getSkin()).getVerticalScrollBar());
/*     */   }
/*     */   
/*     */   private Optional<ScrollBar> getHorizontalScrollBar() {
/* 143 */     return Optional.ofNullable(((ScrollPaneSkin)getNode().getSkin()).getHorizontalScrollBar());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent paramMouseEvent) {
/* 154 */     getNode().requestFocus();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ScrollPaneBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */