/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.scene.control.ButtonBase;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ButtonBehavior<C extends ButtonBase>
/*     */   extends BehaviorBase<C>
/*     */ {
/*     */   private final InputMap<C> buttonInputMap;
/*     */   private boolean keyDown;
/*     */   
/*     */   public ButtonBehavior(C paramC) {
/*  68 */     super(paramC);
/*     */ 
/*     */ 
/*     */     
/*  72 */     this.buttonInputMap = createInputMap();
/*     */ 
/*     */     
/*  75 */     addDefaultMapping(this.buttonInputMap, FocusTraversalInputMap.getFocusTraversalMappings());
/*     */ 
/*     */     
/*  78 */     addDefaultMapping(this.buttonInputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, KeyEvent.KEY_PRESSED, this::keyPressed), (InputMap.Mapping)new InputMap.KeyMapping(KeyCode.SPACE, KeyEvent.KEY_RELEASED, this::keyReleased), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_RELEASED, this::mouseReleased), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_ENTERED, this::mouseEntered), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_EXITED, this::mouseExited), (InputMap.Mapping)new InputMap.KeyMapping(new KeyBinding(KeyCode.ENTER, KeyEvent.KEY_PRESSED), this::keyPressed, paramKeyEvent -> PlatformUtil.isMac()), (InputMap.Mapping)new InputMap.KeyMapping(new KeyBinding(KeyCode.ENTER, KeyEvent.KEY_RELEASED), this::keyReleased, paramKeyEvent -> PlatformUtil.isMac()) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     paramC.focusedProperty().addListener(this::focusChanged);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputMap<C> getInputMap() {
/* 104 */     return this.buttonInputMap;
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 108 */     super.dispose();
/*     */ 
/*     */     
/* 111 */     ((ButtonBase)getNode()).focusedProperty().removeListener(this::focusChanged);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void focusChanged(Observable paramObservable) {
/* 125 */     ButtonBase buttonBase = (ButtonBase)getNode();
/* 126 */     if (this.keyDown && !buttonBase.isFocused()) {
/* 127 */       this.keyDown = false;
/* 128 */       buttonBase.disarm();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void keyPressed(KeyEvent paramKeyEvent) {
/* 146 */     if (!((ButtonBase)getNode()).isPressed() && !((ButtonBase)getNode()).isArmed()) {
/* 147 */       this.keyDown = true;
/* 148 */       ((ButtonBase)getNode()).arm();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void keyReleased(KeyEvent paramKeyEvent) {
/* 157 */     if (this.keyDown) {
/* 158 */       this.keyDown = false;
/* 159 */       if (((ButtonBase)getNode()).isArmed()) {
/* 160 */         ((ButtonBase)getNode()).disarm();
/* 161 */         ((ButtonBase)getNode()).fire();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mousePressed(MouseEvent paramMouseEvent) {
/* 180 */     if (!((ButtonBase)getNode()).isFocused() && ((ButtonBase)getNode()).isFocusTraversable()) {
/* 181 */       ((ButtonBase)getNode()).requestFocus();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     boolean bool = (paramMouseEvent.getButton() == MouseButton.PRIMARY && !paramMouseEvent.isMiddleButtonDown() && !paramMouseEvent.isSecondaryButtonDown() && !paramMouseEvent.isShiftDown() && !paramMouseEvent.isControlDown() && !paramMouseEvent.isAltDown() && !paramMouseEvent.isMetaDown()) ? true : false;
/*     */     
/* 193 */     if (!((ButtonBase)getNode()).isArmed() && bool) {
/* 194 */       ((ButtonBase)getNode()).arm();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mouseReleased(MouseEvent paramMouseEvent) {
/* 205 */     if (!this.keyDown && ((ButtonBase)getNode()).isArmed()) {
/* 206 */       ((ButtonBase)getNode()).fire();
/* 207 */       ((ButtonBase)getNode()).disarm();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mouseEntered(MouseEvent paramMouseEvent) {
/* 218 */     if (!this.keyDown && ((ButtonBase)getNode()).isPressed()) {
/* 219 */       ((ButtonBase)getNode()).arm();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mouseExited(MouseEvent paramMouseEvent) {
/* 230 */     if (!this.keyDown && ((ButtonBase)getNode()).isArmed())
/* 231 */       ((ButtonBase)getNode()).disarm(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ButtonBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */