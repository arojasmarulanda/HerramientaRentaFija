/*     */ package com.sun.javafx.scene.control.skin;
/*     */ 
/*     */ import com.sun.javafx.scene.control.DoubleField;
/*     */ import com.sun.javafx.scene.control.InputField;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Skinnable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoubleFieldSkin
/*     */   extends InputFieldSkin
/*     */ {
/*     */   private InvalidationListener doubleFieldValueListener;
/*     */   
/*     */   public DoubleFieldSkin(DoubleField paramDoubleField) {
/*  43 */     super((InputField)paramDoubleField);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     paramDoubleField.valueProperty().addListener(this.doubleFieldValueListener = (paramObservable -> updateText()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DoubleField getSkinnable() {
/*  54 */     return (DoubleField)this.control;
/*     */   }
/*     */   
/*     */   public Node getNode() {
/*  58 */     return getTextField();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  71 */     ((DoubleField)this.control).valueProperty().removeListener(this.doubleFieldValueListener);
/*  72 */     super.dispose();
/*     */   }
/*     */   
/*     */   protected boolean accept(String paramString) {
/*  76 */     if (paramString.length() == 0) return true; 
/*  77 */     if (paramString.matches("[0-9\\.]*")) {
/*     */       try {
/*  79 */         Double.parseDouble(paramString);
/*  80 */         return true;
/*  81 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*  83 */     return false;
/*     */   }
/*     */   
/*     */   protected void updateText() {
/*  87 */     getTextField().setText("" + ((DoubleField)this.control).getValue());
/*     */   }
/*     */   
/*     */   protected void updateValue() {
/*  91 */     double d = ((DoubleField)this.control).getValue();
/*     */     
/*  93 */     String str = (getTextField().getText() == null) ? "" : getTextField().getText().trim();
/*     */     try {
/*  95 */       double d1 = Double.parseDouble(str);
/*  96 */       if (d1 != d) {
/*  97 */         ((DoubleField)this.control).setValue(d1);
/*     */       }
/*  99 */     } catch (NumberFormatException numberFormatException) {
/*     */       
/* 101 */       ((DoubleField)this.control).setValue(0.0D);
/* 102 */       Platform.runLater(() -> getTextField().positionCaret(1));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\skin\DoubleFieldSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */