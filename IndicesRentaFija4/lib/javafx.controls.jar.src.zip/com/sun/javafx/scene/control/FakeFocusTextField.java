/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import javafx.scene.AccessibleAttribute;
/*    */ import javafx.scene.control.TextField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FakeFocusTextField
/*    */   extends TextField
/*    */ {
/*    */   public void requestFocus() {
/* 33 */     if (getParent() != null) {
/* 34 */       getParent().requestFocus();
/*    */     }
/*    */   }
/*    */   
/*    */   public void setFakeFocus(boolean paramBoolean) {
/* 39 */     setFocused(paramBoolean);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object queryAccessibleAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 45 */     switch (paramAccessibleAttribute) {
/*    */ 
/*    */ 
/*    */ 
/*    */       
/*    */       case FOCUS_ITEM:
/* 51 */         return getParent();
/* 52 */     }  return super.queryAccessibleAttribute(paramAccessibleAttribute, paramVarArgs);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\FakeFocusTextField.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */