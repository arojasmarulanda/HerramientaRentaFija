/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.application.PlatformImpl;
/*     */ import com.sun.javafx.scene.control.Properties;
/*     */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*     */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*     */ import com.sun.javafx.scene.control.skin.FXVK;
/*     */ import com.sun.javafx.scene.control.skin.resources.ControlResources;
/*     */ import java.text.Bidi;
/*     */ import java.util.function.Predicate;
/*     */ import javafx.application.ConditionalFeature;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.geometry.NodeOrientation;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.IndexRange;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.SeparatorMenuItem;
/*     */ import javafx.scene.control.TextInputControl;
/*     */ import javafx.scene.control.skin.TextInputControlSkin;
/*     */ import javafx.scene.input.Clipboard;
/*     */ import javafx.scene.input.ContextMenuEvent;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TextInputControlBehavior<T extends TextInputControl>
/*     */   extends BehaviorBase<T>
/*     */ {
/*  83 */   static final boolean SHOW_HANDLES = (Properties.IS_TOUCH_SUPPORTED && !PlatformUtil.isIOS());
/*     */   
/*     */   public static final String DISABLE_FORWARD_TO_PARENT = "TextInputControlBehavior.disableForwardToParent";
/*     */   
/*     */   final T textInputControl;
/*     */   
/*     */   protected ContextMenu contextMenu;
/*     */   
/*     */   private InvalidationListener textListener = paramObservable -> invalidateBidi();
/*     */   
/*     */   private final InputMap<T> inputMap;
/*     */   private Bidi bidi;
/*     */   private Boolean mixed;
/*     */   private Boolean rtlText;
/*     */   private boolean editing;
/*     */   private final MenuItem undoMI;
/*     */   private final MenuItem redoMI;
/*     */   private final MenuItem cutMI;
/*     */   private final MenuItem copyMI;
/*     */   private final MenuItem pasteMI;
/*     */   private final MenuItem deleteMI;
/*     */   private final MenuItem selectWordMI;
/*     */   private final MenuItem selectAllMI;
/*     */   private final MenuItem separatorMI;
/*     */   
/*     */   public TextInputControlBehavior(T paramT) {
/* 109 */     super(paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 406 */     this.bidi = null;
/* 407 */     this.mixed = null;
/* 408 */     this.rtlText = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 653 */     this.editing = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 712 */     this.undoMI = new ContextMenuItem("Undo", paramActionEvent -> undo());
/* 713 */     this.redoMI = new ContextMenuItem("Redo", paramActionEvent -> redo());
/* 714 */     this.cutMI = new ContextMenuItem("Cut", paramActionEvent -> cut());
/* 715 */     this.copyMI = new ContextMenuItem("Copy", paramActionEvent -> ((TextInputControl)getNode()).copy());
/* 716 */     this.pasteMI = new ContextMenuItem("Paste", paramActionEvent -> paste());
/* 717 */     this.deleteMI = new ContextMenuItem("DeleteSelection", paramActionEvent -> deleteSelection());
/* 718 */     this.selectWordMI = new ContextMenuItem("SelectWord", paramActionEvent -> selectWord());
/* 719 */     this.selectAllMI = new ContextMenuItem("SelectAll", paramActionEvent -> selectAll());
/* 720 */     this.separatorMI = new SeparatorMenuItem();
/*     */     this.textInputControl = paramT;
/*     */     this.textInputControl.textProperty().addListener(this.textListener);
/*     */     this.inputMap = createInputMap();
/*     */     Predicate<KeyEvent> predicate1 = paramKeyEvent -> !paramTextInputControl.isEditable();
/*     */     Predicate<KeyEvent> predicate2 = paramKeyEvent -> !PlatformUtil.isWindows();
/*     */     Predicate<KeyEvent> predicate3 = paramKeyEvent -> !PlatformUtil.isLinux();
/*     */     InputMap.KeyMapping keyMapping1, keyMapping2;
/*     */     addDefaultMapping(this.inputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { 
/*     */           (InputMap.Mapping)keyMapping(KeyCode.RIGHT, paramKeyEvent -> nextCharacterVisually(true)), (InputMap.Mapping)keyMapping(KeyCode.LEFT, paramKeyEvent -> nextCharacterVisually(false)), (InputMap.Mapping)keyMapping(KeyCode.UP, paramKeyEvent -> paramTextInputControl.home()), (InputMap.Mapping)keyMapping(KeyCode.HOME, paramKeyEvent -> paramTextInputControl.home()), (InputMap.Mapping)keyMapping(KeyCode.DOWN, paramKeyEvent -> paramTextInputControl.end()), (InputMap.Mapping)keyMapping(KeyCode.END, paramKeyEvent -> paramTextInputControl.end()), (InputMap.Mapping)keyMapping(KeyCode.ENTER, this::fire), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.HOME)).shortcut(), paramKeyEvent -> paramTextInputControl.home()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.END)).shortcut(), paramKeyEvent -> paramTextInputControl.end()), (InputMap.Mapping)keyMapping(new KeyBinding(KeyCode.BACK_SPACE), paramKeyEvent -> deletePreviousChar(), predicate1), 
/*     */           (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.BACK_SPACE)).shift(), paramKeyEvent -> deletePreviousChar(), predicate1), (InputMap.Mapping)keyMapping(new KeyBinding(KeyCode.DELETE), paramKeyEvent -> deleteNextChar(), predicate1), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.X)).shortcut(), paramKeyEvent -> cut(), predicate1), (InputMap.Mapping)keyMapping(new KeyBinding(KeyCode.CUT), paramKeyEvent -> cut(), predicate1), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.C)).shortcut(), paramKeyEvent -> paramTextInputControl.copy()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.INSERT)).shortcut(), paramKeyEvent -> paramTextInputControl.copy()), (InputMap.Mapping)keyMapping(KeyCode.COPY, paramKeyEvent -> paramTextInputControl.copy()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.V)).shortcut(), paramKeyEvent -> paste(), predicate1), (InputMap.Mapping)keyMapping(new KeyBinding(KeyCode.PASTE), paramKeyEvent -> paste(), predicate1), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.INSERT)).shift(), paramKeyEvent -> paste(), predicate1), 
/*     */           (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.RIGHT)).shift(), paramKeyEvent -> selectRight()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.LEFT)).shift(), paramKeyEvent -> selectLeft()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.UP)).shift(), paramKeyEvent -> selectHome()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.DOWN)).shift(), paramKeyEvent -> selectEnd()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.HOME)).shortcut().shift(), paramKeyEvent -> selectHome()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.END)).shortcut().shift(), paramKeyEvent -> selectEnd()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.A)).shortcut(), paramKeyEvent -> paramTextInputControl.selectAll()), (InputMap.Mapping)new InputMap.KeyMapping(new KeyBinding(KeyCode.TAB), FocusTraversalInputMap::traverseNext), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB)).shift(), FocusTraversalInputMap::traversePrevious), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB)).ctrl(), FocusTraversalInputMap::traverseNext), 
/*     */           (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB)).ctrl().shift(), FocusTraversalInputMap::traversePrevious), (InputMap.Mapping)(keyMapping1 = new InputMap.KeyMapping(KeyCode.ESCAPE, this::cancelEdit)), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.Z)).shortcut(), paramKeyEvent -> undo()), (InputMap.Mapping)keyMapping((new KeyBinding(null, KeyEvent.KEY_TYPED)).alt(KeyBinding.OptionalBoolean.ANY).shift(KeyBinding.OptionalBoolean.ANY).ctrl(KeyBinding.OptionalBoolean.ANY).meta(KeyBinding.OptionalBoolean.ANY), this::defaultKeyTyped), (InputMap.Mapping)(keyMapping2 = keyMapping((new KeyBinding(null, KeyEvent.KEY_PRESSED)).shift(KeyBinding.OptionalBoolean.ANY), paramKeyEvent -> {
/*     */               if (!paramKeyEvent.getCode().isFunctionKey())
/*     */                 paramKeyEvent.consume(); 
/*     */             })), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.DIGIT9)).ctrl().shift(), paramKeyEvent -> FXVK.toggleUseVK((TextInputControl)this.textInputControl), paramKeyEvent -> !PlatformImpl.isSupported(ConditionalFeature.VIRTUAL_KEYBOARD)), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_PRESSED, this::mousePressed), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_DRAGGED, this::mouseDragged), (InputMap.Mapping)new InputMap.MouseMapping(MouseEvent.MOUSE_RELEASED, this::mouseReleased), new InputMap.Mapping<ContextMenuEvent>(ContextMenuEvent.CONTEXT_MENU_REQUESTED, this::contextMenuRequested) {
/*     */             public int getSpecificity(Event param1Event) {
/*     */               return 1;
/*     */             }
/*     */           } });
/*     */     keyMapping1.setAutoConsume(false);
/*     */     keyMapping2.setAutoConsume(false);
/*     */     InputMap inputMap1 = new InputMap((Node)paramT);
/*     */     inputMap1.setInterceptor(paramEvent -> !PlatformUtil.isMac());
/*     */     inputMap1.getMappings().addAll(new InputMap.Mapping[] { 
/*     */           (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.HOME)).shift(), paramKeyEvent -> selectHomeExtend()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.END)).shift(), paramKeyEvent -> selectEndExtend()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.LEFT)).shortcut(), paramKeyEvent -> paramTextInputControl.home()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.RIGHT)).shortcut(), paramKeyEvent -> paramTextInputControl.end()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.LEFT)).alt(), paramKeyEvent -> leftWord()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.RIGHT)).alt(), paramKeyEvent -> rightWord()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.DELETE)).alt(), paramKeyEvent -> deleteNextWord()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.BACK_SPACE)).alt(), paramKeyEvent -> deletePreviousWord()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.BACK_SPACE)).shortcut(), paramKeyEvent -> deleteFromLineStart()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.Z)).shortcut().shift(), paramKeyEvent -> redo()), 
/*     */           (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.LEFT)).shortcut().shift(), paramKeyEvent -> selectHomeExtend()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.RIGHT)).shortcut().shift(), paramKeyEvent -> selectEndExtend()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.LEFT)).shift().alt(), paramKeyEvent -> selectLeftWord()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.RIGHT)).shift().alt(), paramKeyEvent -> selectRightWord()) });
/*     */     addDefaultChildMap(this.inputMap, inputMap1);
/*     */     InputMap inputMap2 = new InputMap((Node)paramT);
/*     */     inputMap2.setInterceptor(paramEvent -> PlatformUtil.isMac());
/*     */     inputMap2.getMappings().addAll(new InputMap.Mapping[] { 
/*     */           (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.HOME)).shift(), paramKeyEvent -> selectHome()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.END)).shift(), paramKeyEvent -> selectEnd()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.LEFT)).ctrl(), paramKeyEvent -> leftWord()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.RIGHT)).ctrl(), paramKeyEvent -> rightWord()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.H)).ctrl(), paramKeyEvent -> deletePreviousChar()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.DELETE)).ctrl(), paramKeyEvent -> deleteNextWord()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.BACK_SPACE)).ctrl(), paramKeyEvent -> deletePreviousWord()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.BACK_SLASH)).ctrl(), paramKeyEvent -> paramTextInputControl.deselect()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.Y)).ctrl(), paramKeyEvent -> redo(), predicate2), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.Z)).ctrl().shift(), paramKeyEvent -> redo(), predicate3), 
/*     */           (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.LEFT)).ctrl().shift(), paramKeyEvent -> selectLeftWord()), (InputMap.Mapping)keyMapping((new KeyBinding(KeyCode.RIGHT)).ctrl().shift(), paramKeyEvent -> selectRightWord()) });
/*     */     addDefaultChildMap(this.inputMap, inputMap2);
/*     */     addKeyPadMappings(this.inputMap);
/*     */     this.textInputControl.textProperty().addListener(this.textListener);
/*     */     this.contextMenu = new ContextMenu();
/*     */   }
/*     */   
/*     */   public InputMap<T> getInputMap() {
/*     */     return this.inputMap;
/*     */   }
/*     */   
/*     */   protected void addKeyPadMappings(InputMap<T> paramInputMap) {
/*     */     InputMap inputMap = new InputMap((TextInputControl)getNode());
/*     */     for (InputMap.KeyMapping keyMapping : paramInputMap.getMappings()) {
/*     */       if (keyMapping instanceof InputMap.KeyMapping) {
/*     */         InputMap.KeyMapping keyMapping1 = keyMapping;
/*     */         KeyBinding keyBinding = (KeyBinding)keyMapping1.getMappingKey();
/*     */         if (keyBinding.getCode() != null) {
/*     */           KeyCode keyCode = null;
/*     */           switch (keyBinding.getCode()) {
/*     */             case LEFT:
/*     */               keyCode = KeyCode.KP_LEFT;
/*     */               break;
/*     */             case RIGHT:
/*     */               keyCode = KeyCode.KP_RIGHT;
/*     */               break;
/*     */             case UP:
/*     */               keyCode = KeyCode.KP_UP;
/*     */               break;
/*     */             case DOWN:
/*     */               keyCode = KeyCode.KP_DOWN;
/*     */               break;
/*     */           } 
/*     */           if (keyCode != null) {
/*     */             KeyBinding keyBinding1 = (new KeyBinding(keyCode)).shift(keyBinding.getShift()).ctrl(keyBinding.getCtrl()).alt(keyBinding.getAlt()).meta(keyBinding.getMeta());
/*     */             inputMap.getMappings().add(new InputMap.KeyMapping(keyBinding1, keyMapping1.getEventHandler()));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     for (InputMap.KeyMapping keyMapping : inputMap.getMappings())
/*     */       paramInputMap.getMappings().add(keyMapping); 
/*     */     for (InputMap inputMap1 : paramInputMap.getChildInputMaps())
/*     */       addKeyPadMappings(inputMap1); 
/*     */   }
/*     */   
/*     */   protected InputMap.KeyMapping keyMapping(KeyCode paramKeyCode, EventHandler<KeyEvent> paramEventHandler) {
/*     */     return keyMapping(new KeyBinding(paramKeyCode), paramEventHandler);
/*     */   }
/*     */   
/*     */   protected InputMap.KeyMapping keyMapping(KeyBinding paramKeyBinding, EventHandler<KeyEvent> paramEventHandler) {
/*     */     return keyMapping(paramKeyBinding, paramEventHandler, (Predicate<KeyEvent>)null);
/*     */   }
/*     */   
/*     */   protected InputMap.KeyMapping keyMapping(KeyBinding paramKeyBinding, EventHandler<KeyEvent> paramEventHandler, Predicate<KeyEvent> paramPredicate) {
/*     */     return new InputMap.KeyMapping(paramKeyBinding, paramKeyEvent -> {
/*     */           setCaretAnimating(false);
/*     */           paramEventHandler.handle(paramKeyEvent);
/*     */           setCaretAnimating(true);
/*     */         }paramPredicate);
/*     */   }
/*     */   
/*     */   public void dispose() {
/*     */     this.textInputControl.textProperty().removeListener(this.textListener);
/*     */     super.dispose();
/*     */   }
/*     */   
/*     */   private void defaultKeyTyped(KeyEvent paramKeyEvent) {
/*     */     TextInputControl textInputControl = (TextInputControl)getNode();
/*     */     if (!textInputControl.isEditable() || textInputControl.isDisabled())
/*     */       return; 
/*     */     String str = paramKeyEvent.getCharacter();
/*     */     if (str.length() == 0)
/*     */       return; 
/*     */     if ((paramKeyEvent.isControlDown() || paramKeyEvent.isAltDown() || (PlatformUtil.isMac() && paramKeyEvent.isMetaDown())) && ((!paramKeyEvent.isControlDown() && !PlatformUtil.isMac()) || !paramKeyEvent.isAltDown()))
/*     */       return; 
/*     */     setEditing(true);
/*     */     if (str.charAt(0) > '\037' && str.charAt(0) != '' && !paramKeyEvent.isMetaDown()) {
/*     */       IndexRange indexRange = textInputControl.getSelection();
/*     */       int i = indexRange.getStart();
/*     */       int j = indexRange.getEnd();
/*     */       replaceText(i, j, str);
/*     */     } 
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   private void invalidateBidi() {
/*     */     this.bidi = null;
/*     */     this.mixed = null;
/*     */     this.rtlText = null;
/*     */   }
/*     */   
/*     */   private Bidi getBidi() {
/*     */     if (this.bidi == null)
/*     */       this.bidi = new Bidi(this.textInputControl.textProperty().getValueSafe(), (this.textInputControl.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT) ? 1 : 0); 
/*     */     return this.bidi;
/*     */   }
/*     */   
/*     */   protected boolean isMixed() {
/*     */     if (this.mixed == null)
/*     */       this.mixed = Boolean.valueOf(getBidi().isMixed()); 
/*     */     return this.mixed.booleanValue();
/*     */   }
/*     */   
/*     */   protected boolean isRTLText() {
/*     */     if (this.rtlText == null) {
/*     */       Bidi bidi = getBidi();
/*     */       this.rtlText = Boolean.valueOf((bidi.isRightToLeft() || (isMixed() && this.textInputControl.getEffectiveNodeOrientation() == NodeOrientation.RIGHT_TO_LEFT)));
/*     */     } 
/*     */     return this.rtlText.booleanValue();
/*     */   }
/*     */   
/*     */   private void nextCharacterVisually(boolean paramBoolean) {
/*     */     if (isMixed()) {
/*     */       TextInputControlSkin textInputControlSkin = (TextInputControlSkin)this.textInputControl.getSkin();
/*     */       textInputControlSkin.moveCaret(TextInputControlSkin.TextUnit.CHARACTER, paramBoolean ? TextInputControlSkin.Direction.RIGHT : TextInputControlSkin.Direction.LEFT, false);
/*     */     } else if (paramBoolean != isRTLText()) {
/*     */       this.textInputControl.forward();
/*     */     } else {
/*     */       this.textInputControl.backward();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void selectLeft() {
/*     */     if (isRTLText()) {
/*     */       this.textInputControl.selectForward();
/*     */     } else {
/*     */       this.textInputControl.selectBackward();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void selectRight() {
/*     */     if (isRTLText()) {
/*     */       this.textInputControl.selectBackward();
/*     */     } else {
/*     */       this.textInputControl.selectForward();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void deletePreviousChar() {
/*     */     setEditing(true);
/*     */     deleteChar(true);
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   private void deleteNextChar() {
/*     */     setEditing(true);
/*     */     deleteChar(false);
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   protected void deletePreviousWord() {
/*     */     setEditing(true);
/*     */     TextInputControl textInputControl = (TextInputControl)getNode();
/*     */     int i = textInputControl.getCaretPosition();
/*     */     if (i > 0) {
/*     */       textInputControl.previousWord();
/*     */       int j = textInputControl.getCaretPosition();
/*     */       replaceText(j, i, "");
/*     */     } 
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   protected void deleteNextWord() {
/*     */     setEditing(true);
/*     */     TextInputControl textInputControl = (TextInputControl)getNode();
/*     */     int i = textInputControl.getCaretPosition();
/*     */     if (i < textInputControl.getLength()) {
/*     */       nextWord();
/*     */       int j = textInputControl.getCaretPosition();
/*     */       replaceText(i, j, "");
/*     */     } 
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   public void deleteSelection() {
/*     */     setEditing(true);
/*     */     TextInputControl textInputControl = (TextInputControl)getNode();
/*     */     IndexRange indexRange = textInputControl.getSelection();
/*     */     if (indexRange.getLength() > 0)
/*     */       deleteChar(false); 
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   public void cut() {
/*     */     setEditing(true);
/*     */     ((TextInputControl)getNode()).cut();
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   public void paste() {
/*     */     setEditing(true);
/*     */     ((TextInputControl)getNode()).paste();
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   public void undo() {
/*     */     setEditing(true);
/*     */     ((TextInputControl)getNode()).undo();
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   public void redo() {
/*     */     setEditing(true);
/*     */     ((TextInputControl)getNode()).redo();
/*     */     setEditing(false);
/*     */   }
/*     */   
/*     */   protected void selectPreviousWord() {
/*     */     ((TextInputControl)getNode()).selectPreviousWord();
/*     */   }
/*     */   
/*     */   public void selectNextWord() {
/*     */     TextInputControl textInputControl = (TextInputControl)getNode();
/*     */     if (PlatformUtil.isMac() || PlatformUtil.isLinux()) {
/*     */       textInputControl.selectEndOfNextWord();
/*     */     } else {
/*     */       textInputControl.selectNextWord();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void selectLeftWord() {
/*     */     if (isRTLText()) {
/*     */       selectNextWord();
/*     */     } else {
/*     */       selectPreviousWord();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void selectRightWord() {
/*     */     if (isRTLText()) {
/*     */       selectPreviousWord();
/*     */     } else {
/*     */       selectNextWord();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void selectWord() {
/*     */     TextInputControl textInputControl = (TextInputControl)getNode();
/*     */     textInputControl.previousWord();
/*     */     if (PlatformUtil.isWindows()) {
/*     */       textInputControl.selectNextWord();
/*     */     } else {
/*     */       textInputControl.selectEndOfNextWord();
/*     */     } 
/*     */     if (SHOW_HANDLES && this.contextMenu.isShowing())
/*     */       populateContextMenu(); 
/*     */   }
/*     */   
/*     */   protected void selectAll() {
/*     */     ((TextInputControl)getNode()).selectAll();
/*     */     if (SHOW_HANDLES && this.contextMenu.isShowing())
/*     */       populateContextMenu(); 
/*     */   }
/*     */   
/*     */   protected void previousWord() {
/*     */     ((TextInputControl)getNode()).previousWord();
/*     */   }
/*     */   
/*     */   protected void nextWord() {
/*     */     TextInputControl textInputControl = (TextInputControl)getNode();
/*     */     if (PlatformUtil.isMac() || PlatformUtil.isLinux()) {
/*     */       textInputControl.endOfNextWord();
/*     */     } else {
/*     */       textInputControl.nextWord();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void leftWord() {
/*     */     if (isRTLText()) {
/*     */       nextWord();
/*     */     } else {
/*     */       previousWord();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void rightWord() {
/*     */     if (isRTLText()) {
/*     */       previousWord();
/*     */     } else {
/*     */       nextWord();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void fire(KeyEvent paramKeyEvent) {}
/*     */   
/*     */   protected void cancelEdit(KeyEvent paramKeyEvent) {
/*     */     forwardToParent(paramKeyEvent);
/*     */   }
/*     */   
/*     */   protected void forwardToParent(KeyEvent paramKeyEvent) {
/*     */     if (((TextInputControl)getNode()).getProperties().containsKey("TextInputControlBehavior.disableForwardToParent"))
/*     */       return; 
/*     */     if (((TextInputControl)getNode()).getParent() != null)
/*     */       ((TextInputControl)getNode()).getParent().fireEvent(paramKeyEvent); 
/*     */   }
/*     */   
/*     */   protected void selectHome() {
/*     */     ((TextInputControl)getNode()).selectHome();
/*     */   }
/*     */   
/*     */   protected void selectEnd() {
/*     */     ((TextInputControl)getNode()).selectEnd();
/*     */   }
/*     */   
/*     */   protected void selectHomeExtend() {
/*     */     ((TextInputControl)getNode()).extendSelection(0);
/*     */   }
/*     */   
/*     */   protected void selectEndExtend() {
/*     */     TextInputControl textInputControl = (TextInputControl)getNode();
/*     */     textInputControl.extendSelection(textInputControl.getLength());
/*     */   }
/*     */   
/*     */   protected void setEditing(boolean paramBoolean) {
/*     */     this.editing = paramBoolean;
/*     */   }
/*     */   
/*     */   public boolean isEditing() {
/*     */     return this.editing;
/*     */   }
/*     */   
/*     */   protected void populateContextMenu() {
/*     */     TextInputControl textInputControl = (TextInputControl)getNode();
/*     */     boolean bool1 = textInputControl.isEditable();
/*     */     boolean bool2 = (textInputControl.getLength() > 0) ? true : false;
/*     */     boolean bool3 = (textInputControl.getSelection().getLength() > 0) ? true : false;
/*     */     boolean bool4 = (textInputControl.getSelection().getLength() == textInputControl.getLength()) ? true : false;
/*     */     boolean bool5 = textInputControl instanceof javafx.scene.control.PasswordField;
/*     */     ObservableList<MenuItem> observableList = this.contextMenu.getItems();
/*     */     if (SHOW_HANDLES) {
/*     */       observableList.clear();
/*     */       if (!bool5 && bool3) {
/*     */         if (bool1)
/*     */           observableList.add(this.cutMI); 
/*     */         observableList.add(this.copyMI);
/*     */       } 
/*     */       if (bool1 && Clipboard.getSystemClipboard().hasString())
/*     */         observableList.add(this.pasteMI); 
/*     */       if (bool2 && !bool4) {
/*     */         if (!bool3 && !(textInputControl instanceof javafx.scene.control.PasswordField))
/*     */           observableList.add(this.selectWordMI); 
/*     */         observableList.add(this.selectAllMI);
/*     */       } 
/*     */       this.selectWordMI.getProperties().put("refreshMenu", Boolean.TRUE);
/*     */       this.selectAllMI.getProperties().put("refreshMenu", Boolean.TRUE);
/*     */     } else {
/*     */       if (bool1) {
/*     */         observableList.setAll(new MenuItem[] { this.undoMI, this.redoMI, this.cutMI, this.copyMI, this.pasteMI, this.deleteMI, this.separatorMI, this.selectAllMI });
/*     */       } else {
/*     */         observableList.setAll(new MenuItem[] { this.copyMI, this.separatorMI, this.selectAllMI });
/*     */       } 
/*     */       this.undoMI.setDisable(!((TextInputControl)getNode()).isUndoable());
/*     */       this.redoMI.setDisable(!((TextInputControl)getNode()).isRedoable());
/*     */       this.cutMI.setDisable((bool5 || !bool3));
/*     */       this.copyMI.setDisable((bool5 || !bool3));
/*     */       this.pasteMI.setDisable(!Clipboard.getSystemClipboard().hasString());
/*     */       this.deleteMI.setDisable(!bool3);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class ContextMenuItem extends MenuItem {
/*     */     ContextMenuItem(String param1String, EventHandler<ActionEvent> param1EventHandler) {
/*     */       super(ControlResources.getString("TextInputControl.menu." + param1String));
/*     */       setOnAction(param1EventHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void deleteChar(boolean paramBoolean);
/*     */   
/*     */   protected abstract void replaceText(int paramInt1, int paramInt2, String paramString);
/*     */   
/*     */   protected abstract void setCaretAnimating(boolean paramBoolean);
/*     */   
/*     */   protected abstract void deleteFromLineStart();
/*     */   
/*     */   protected abstract void mousePressed(MouseEvent paramMouseEvent);
/*     */   
/*     */   protected abstract void mouseDragged(MouseEvent paramMouseEvent);
/*     */   
/*     */   protected abstract void mouseReleased(MouseEvent paramMouseEvent);
/*     */   
/*     */   protected abstract void contextMenuRequested(ContextMenuEvent paramContextMenuEvent);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TextInputControlBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */