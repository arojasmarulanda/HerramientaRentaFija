/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import com.sun.javafx.scene.NodeHelper;
/*    */ import com.sun.javafx.scene.layout.RegionHelper;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.beans.property.StringProperty;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.control.Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ControlHelper
/*    */   extends RegionHelper
/*    */ {
/* 42 */   private static final ControlHelper theInstance = new ControlHelper(); static {
/* 43 */     Utils.forceInit(Control.class);
/*    */   }
/*    */   private static ControlAccessor controlAccessor;
/*    */   private static ControlHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Control paramControl) {
/* 51 */     setHelper(paramControl, (NodeHelper)getInstance());
/*    */   }
/*    */   
/*    */   public static void superProcessCSS(Node paramNode) {
/* 55 */     ((ControlHelper)getHelper(paramNode)).superProcessCSSImpl(paramNode);
/*    */   }
/*    */   
/*    */   public static StringProperty skinClassNameProperty(Control paramControl) {
/* 59 */     return controlAccessor.skinClassNameProperty(paramControl);
/*    */   }
/*    */   
/*    */   void superProcessCSSImpl(Node paramNode) {
/* 63 */     super.processCSSImpl(paramNode);
/*    */   }
/*    */   
/*    */   protected void processCSSImpl(Node paramNode) {
/* 67 */     controlAccessor.doProcessCSS(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void setControlAccessor(ControlAccessor paramControlAccessor) {
/* 72 */     if (controlAccessor != null) {
/* 73 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 76 */     controlAccessor = paramControlAccessor;
/*    */   }
/*    */   
/*    */   public static interface ControlAccessor {
/*    */     void doProcessCSS(Node param1Node);
/*    */     
/*    */     StringProperty skinClassNameProperty(Control param1Control);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\ControlHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */