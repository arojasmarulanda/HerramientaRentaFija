/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import javafx.beans.value.ObservableValue;
/*    */ import javafx.scene.control.TableColumn;
/*    */ import javafx.scene.control.TableColumnBase;
/*    */ import javafx.scene.control.TreeTableColumn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableColumnSortTypeWrapper
/*    */ {
/*    */   public static boolean isAscending(TableColumnBase<?, ?> paramTableColumnBase) {
/* 42 */     String str = getSortTypeName(paramTableColumnBase);
/* 43 */     return "ASCENDING".equals(str);
/*    */   }
/*    */   
/*    */   public static boolean isDescending(TableColumnBase<?, ?> paramTableColumnBase) {
/* 47 */     String str = getSortTypeName(paramTableColumnBase);
/* 48 */     return "DESCENDING".equals(str);
/*    */   }
/*    */   
/*    */   public static void setSortType(TableColumnBase<?, ?> paramTableColumnBase, TableColumn.SortType paramSortType) {
/* 52 */     if (paramTableColumnBase instanceof TableColumn) {
/* 53 */       TableColumn tableColumn = (TableColumn)paramTableColumnBase;
/* 54 */       tableColumn.setSortType(paramSortType);
/* 55 */     } else if (paramTableColumnBase instanceof TreeTableColumn) {
/* 56 */       TreeTableColumn treeTableColumn = (TreeTableColumn)paramTableColumnBase;
/* 57 */       if (paramSortType == TableColumn.SortType.ASCENDING) {
/* 58 */         treeTableColumn.setSortType(TreeTableColumn.SortType.ASCENDING);
/* 59 */       } else if (paramSortType == TableColumn.SortType.DESCENDING) {
/* 60 */         treeTableColumn.setSortType(TreeTableColumn.SortType.DESCENDING);
/* 61 */       } else if (paramSortType == null) {
/* 62 */         treeTableColumn.setSortType(null);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String getSortTypeName(TableColumnBase<?, ?> paramTableColumnBase) {
/* 68 */     if (paramTableColumnBase instanceof TableColumn) {
/* 69 */       TableColumn tableColumn = (TableColumn)paramTableColumnBase;
/* 70 */       TableColumn.SortType sortType = tableColumn.getSortType();
/* 71 */       return (sortType == null) ? null : sortType.name();
/* 72 */     }  if (paramTableColumnBase instanceof TreeTableColumn) {
/* 73 */       TreeTableColumn treeTableColumn = (TreeTableColumn)paramTableColumnBase;
/* 74 */       TreeTableColumn.SortType sortType = treeTableColumn.getSortType();
/* 75 */       return (sortType == null) ? null : sortType.name();
/*    */     } 
/* 77 */     return null;
/*    */   }
/*    */   
/*    */   public static ObservableValue getSortTypeProperty(TableColumnBase<?, ?> paramTableColumnBase) {
/* 81 */     if (paramTableColumnBase instanceof TableColumn)
/* 82 */       return ((TableColumn)paramTableColumnBase).sortTypeProperty(); 
/* 83 */     if (paramTableColumnBase instanceof TreeTableColumn) {
/* 84 */       return ((TreeTableColumn)paramTableColumnBase).sortTypeProperty();
/*    */     }
/* 86 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\TableColumnSortTypeWrapper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */