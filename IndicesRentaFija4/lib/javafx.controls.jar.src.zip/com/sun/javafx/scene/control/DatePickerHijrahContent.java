/*     */ package com.sun.javafx.scene.control;
/*     */ 
/*     */ import java.time.DateTimeException;
/*     */ import java.time.LocalDate;
/*     */ import java.time.YearMonth;
/*     */ import java.time.chrono.Chronology;
/*     */ import java.time.chrono.HijrahChronology;
/*     */ import java.time.chrono.HijrahDate;
/*     */ import java.time.chrono.IsoChronology;
/*     */ import java.time.format.DecimalStyle;
/*     */ import java.time.temporal.ChronoField;
/*     */ import java.util.Locale;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.control.DateCell;
/*     */ import javafx.scene.control.DatePicker;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.layout.BorderPane;
/*     */ import javafx.scene.text.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatePickerHijrahContent
/*     */   extends DatePickerContent
/*     */ {
/*     */   private Label hijrahMonthYearLabel;
/*     */   
/*     */   public DatePickerHijrahContent(DatePicker paramDatePicker) {
/*  61 */     super(paramDatePicker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Chronology getPrimaryChronology() {
/*  70 */     return IsoChronology.INSTANCE;
/*     */   }
/*     */   
/*     */   protected BorderPane createMonthYearPane() {
/*  74 */     BorderPane borderPane = super.createMonthYearPane();
/*     */     
/*  76 */     this.hijrahMonthYearLabel = new Label();
/*  77 */     this.hijrahMonthYearLabel.getStyleClass().add("secondary-label");
/*  78 */     borderPane.setBottom(this.hijrahMonthYearLabel);
/*  79 */     BorderPane.setAlignment(this.hijrahMonthYearLabel, Pos.CENTER);
/*     */     
/*  81 */     return borderPane;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateMonthYearPane() {
/*  86 */     super.updateMonthYearPane();
/*     */     
/*  88 */     Locale locale = getLocale();
/*  89 */     HijrahChronology hijrahChronology = HijrahChronology.INSTANCE;
/*  90 */     long l1 = -1L;
/*  91 */     long l2 = -1L;
/*  92 */     String str1 = null;
/*  93 */     String str2 = null;
/*  94 */     String str3 = null;
/*  95 */     YearMonth yearMonth = displayedYearMonthProperty().get();
/*     */     
/*  97 */     for (DateCell dateCell : this.dayCells) {
/*  98 */       LocalDate localDate = dayCellDate(dateCell);
/*     */ 
/*     */       
/* 101 */       if (!yearMonth.equals(YearMonth.from(localDate))) {
/*     */         continue;
/*     */       }
/*     */       
/*     */       try {
/* 106 */         HijrahDate hijrahDate = hijrahChronology.date(localDate);
/* 107 */         long l3 = hijrahDate.getLong(ChronoField.MONTH_OF_YEAR);
/* 108 */         long l4 = hijrahDate.getLong(ChronoField.YEAR);
/*     */         
/* 110 */         if (str3 == null || l3 != l1) {
/*     */ 
/*     */ 
/*     */           
/* 114 */           String str4 = this.monthFormatter.withLocale(locale).withChronology(hijrahChronology).withDecimalStyle(DecimalStyle.of(locale)).format(hijrahDate);
/*     */ 
/*     */ 
/*     */           
/* 118 */           String str5 = this.yearFormatter.withLocale(locale).withChronology(hijrahChronology).withDecimalStyle(DecimalStyle.of(locale)).format(hijrahDate);
/* 119 */           if (str3 == null) {
/* 120 */             l1 = l3;
/* 121 */             l2 = l4;
/* 122 */             str1 = str4;
/* 123 */             str2 = str5;
/* 124 */             str3 = str1 + " " + str1; continue;
/*     */           } 
/* 126 */           if (l4 > l2) {
/* 127 */             str3 = str1 + " " + str1 + " - " + str2 + " " + str4; break;
/*     */           } 
/* 129 */           str3 = str1 + " - " + str1 + " " + str4;
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/* 134 */       } catch (DateTimeException dateTimeException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     this.hijrahMonthYearLabel.setText(str3);
/*     */   }
/*     */   
/*     */   protected void createDayCells() {
/* 145 */     super.createDayCells();
/*     */     
/* 147 */     for (DateCell dateCell : this.dayCells) {
/* 148 */       Text text = new Text();
/* 149 */       dateCell.getProperties().put("DateCell.secondaryText", text);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updateDayCells() {
/* 154 */     super.updateDayCells();
/*     */     
/* 156 */     Locale locale = getLocale();
/* 157 */     HijrahChronology hijrahChronology = HijrahChronology.INSTANCE;
/*     */     
/* 159 */     byte b1 = -1;
/* 160 */     byte b2 = -1;
/* 161 */     byte b3 = -1;
/* 162 */     boolean bool = false;
/*     */     
/* 164 */     for (DateCell dateCell : this.dayCells) {
/* 165 */       Text text = (Text)dateCell.getProperties().get("DateCell.secondaryText");
/* 166 */       dateCell.getStyleClass().add("hijrah-day-cell");
/* 167 */       text.getStyleClass().setAll(new String[] { "text", "secondary-text" });
/*     */       
/*     */       try {
/* 170 */         HijrahDate hijrahDate = hijrahChronology.date(dayCellDate(dateCell));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 177 */         String str = this.dayCellFormatter.withLocale(locale).withChronology(hijrahChronology).withDecimalStyle(DecimalStyle.of(locale)).format(hijrahDate);
/*     */         
/* 179 */         text.setText(str);
/* 180 */         dateCell.requestLayout();
/* 181 */       } catch (DateTimeException dateTimeException) {
/*     */ 
/*     */         
/* 184 */         text.setText(" ");
/* 185 */         dateCell.setDisable(true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\DatePickerHijrahContent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */