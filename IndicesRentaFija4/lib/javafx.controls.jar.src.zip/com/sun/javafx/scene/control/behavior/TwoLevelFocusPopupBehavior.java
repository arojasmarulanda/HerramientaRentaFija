/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventDispatchChain;
/*     */ import javafx.event.EventDispatcher;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.PopupControl;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TwoLevelFocusPopupBehavior
/*     */   extends TwoLevelFocusBehavior
/*     */ {
/*     */   final EventDispatcher preemptiveEventDispatcher;
/*     */   final EventDispatcher preemptivePopupEventDispatcher;
/*     */   final EventDispatcher tlfEventDispatcher;
/*     */   private final EventHandler<KeyEvent> keyEventListener;
/*     */   final ChangeListener<Boolean> focusListener;
/*     */   private final EventHandler<MouseEvent> mouseEventListener;
/*     */   
/*     */   public TwoLevelFocusPopupBehavior(PopupControl paramPopupControl) {
/*  93 */     this.preemptiveEventDispatcher = ((paramEvent, paramEventDispatchChain) -> {
/*     */         if (paramEvent instanceof KeyEvent && paramEvent.getEventType() == KeyEvent.KEY_PRESSED && !((KeyEvent)paramEvent).isMetaDown() && !((KeyEvent)paramEvent).isControlDown() && !((KeyEvent)paramEvent).isAltDown() && isExternalFocus()) {
/*     */           EventTarget eventTarget = paramEvent.getTarget();
/*     */           switch (((KeyEvent)paramEvent).getCode()) {
/*     */             case TAB:
/*     */               if (((KeyEvent)paramEvent).isShiftDown()) {
/*     */                 NodeHelper.traverse((Node)eventTarget, Direction.PREVIOUS);
/*     */               } else {
/*     */                 NodeHelper.traverse((Node)eventTarget, Direction.NEXT);
/*     */               } 
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */ 
/*     */ 
/*     */             
/*     */             case UP:
/*     */               NodeHelper.traverse((Node)eventTarget, Direction.UP);
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */ 
/*     */ 
/*     */             
/*     */             case DOWN:
/*     */               NodeHelper.traverse((Node)eventTarget, Direction.DOWN);
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */ 
/*     */ 
/*     */             
/*     */             case LEFT:
/*     */               NodeHelper.traverse((Node)eventTarget, Direction.LEFT);
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */ 
/*     */             
/*     */             case RIGHT:
/*     */               NodeHelper.traverse((Node)eventTarget, Direction.RIGHT);
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */ 
/*     */             
/*     */             case ENTER:
/*     */               setExternalFocus(false);
/*     */               paramEvent.consume();
/*     */               return paramEvent;
/*     */           } 
/*     */ 
/*     */           
/*     */           Scene scene = this.tlNode.getScene();
/*     */           Event.fireEvent(scene, paramEvent);
/*     */           paramEvent.consume();
/*     */         } 
/*     */         return paramEvent;
/*     */       });
/* 147 */     this.preemptivePopupEventDispatcher = ((paramEvent, paramEventDispatchChain) -> {
/*     */         if (paramEvent instanceof KeyEvent && paramEvent.getEventType() == KeyEvent.KEY_PRESSED && !((KeyEvent)paramEvent).isMetaDown() && !((KeyEvent)paramEvent).isControlDown() && !((KeyEvent)paramEvent).isAltDown() && !isExternalFocus()) {
/*     */           EventTarget eventTarget = paramEvent.getTarget();
/*     */           switch (((KeyEvent)paramEvent).getCode()) {
/*     */             case TAB:
/*     */             case ENTER:
/*     */               paramEvent.consume();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             case UP:
/*     */             case DOWN:
/*     */               return paramEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             case LEFT:
/*     */               if (eventTarget instanceof Node) {
/*     */                 NodeHelper.traverse((Node)eventTarget, Direction.LEFT);
/*     */                 paramEvent.consume();
/*     */               } else if (eventTarget instanceof Scene) {
/*     */                 Node node = ((Scene)eventTarget).getFocusOwner();
/*     */                 if (node != null) {
/*     */                   NodeHelper.traverse(node, Direction.LEFT);
/*     */                   paramEvent.consume();
/*     */                 } 
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             case RIGHT:
/*     */               if (eventTarget instanceof Node) {
/*     */                 NodeHelper.traverse((Node)eventTarget, Direction.RIGHT);
/*     */                 paramEvent.consume();
/*     */               } else if (eventTarget instanceof Scene) {
/*     */                 Node node = ((Scene)eventTarget).getFocusOwner();
/*     */                 if (node != null) {
/*     */                   NodeHelper.traverse(node, Direction.RIGHT);
/*     */                   paramEvent.consume();
/*     */                 } 
/*     */               } 
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Scene scene = null;
/*     */           if (this.tlNode != null) {
/*     */             scene = this.tlNode.getScene();
/*     */             Event.fireEvent(scene, paramEvent);
/*     */           } 
/*     */           paramEvent.consume();
/*     */         } 
/*     */       });
/* 210 */     this.tlfEventDispatcher = ((paramEvent, paramEventDispatchChain) -> {
/*     */         if (paramEvent instanceof KeyEvent) {
/*     */           if (isExternalFocus()) {
/*     */             paramEventDispatchChain = paramEventDispatchChain.prepend(this.preemptiveEventDispatcher);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return paramEventDispatchChain.dispatchEvent(paramEvent);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           paramEventDispatchChain = paramEventDispatchChain.prepend(this.preemptivePopupEventDispatcher);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           paramEventDispatchChain = paramEventDispatchChain.prepend(this.origEventDispatcher);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return paramEventDispatchChain.dispatchEvent(paramEvent);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         return this.origEventDispatcher.dispatchEvent(paramEvent, paramEventDispatchChain);
/*     */       });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     this.keyEventListener = (paramKeyEvent -> postDispatchTidyup(paramKeyEvent));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     this.focusListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*     */       
/*     */       });
/* 272 */     this.mouseEventListener = (paramMouseEvent -> setExternalFocus(false)); this.tlPopup = paramPopupControl; setExternalFocus(false); this.tlPopup.addEventHandler(KeyEvent.ANY, this.keyEventListener); this.tlPopup.addEventHandler(MouseEvent.MOUSE_PRESSED, this.mouseEventListener); this.tlPopup.focusedProperty().addListener(this.focusListener); this.origEventDispatcher = this.tlPopup.getEventDispatcher(); this.tlPopup.setEventDispatcher(this.tlfEventDispatcher); } public TwoLevelFocusPopupBehavior(Node paramNode) { this.preemptiveEventDispatcher = ((paramEvent, paramEventDispatchChain) -> { if (paramEvent instanceof KeyEvent && paramEvent.getEventType() == KeyEvent.KEY_PRESSED && !((KeyEvent)paramEvent).isMetaDown() && !((KeyEvent)paramEvent).isControlDown() && !((KeyEvent)paramEvent).isAltDown() && isExternalFocus()) { EventTarget eventTarget = paramEvent.getTarget(); switch (((KeyEvent)paramEvent).getCode()) { case TAB: if (((KeyEvent)paramEvent).isShiftDown()) { NodeHelper.traverse((Node)eventTarget, Direction.PREVIOUS); } else { NodeHelper.traverse((Node)eventTarget, Direction.NEXT); }  paramEvent.consume(); return paramEvent;case UP: NodeHelper.traverse((Node)eventTarget, Direction.UP); paramEvent.consume(); return paramEvent;case DOWN: NodeHelper.traverse((Node)eventTarget, Direction.DOWN); paramEvent.consume(); return paramEvent;case LEFT: NodeHelper.traverse((Node)eventTarget, Direction.LEFT); paramEvent.consume(); return paramEvent;case RIGHT: NodeHelper.traverse((Node)eventTarget, Direction.RIGHT); paramEvent.consume(); return paramEvent;case ENTER: setExternalFocus(false); paramEvent.consume(); return paramEvent; }  Scene scene = this.tlNode.getScene(); Event.fireEvent(scene, paramEvent); paramEvent.consume(); }  return paramEvent; }); this.preemptivePopupEventDispatcher = ((paramEvent, paramEventDispatchChain) -> { if (paramEvent instanceof KeyEvent && paramEvent.getEventType() == KeyEvent.KEY_PRESSED && !((KeyEvent)paramEvent).isMetaDown() && !((KeyEvent)paramEvent).isControlDown() && !((KeyEvent)paramEvent).isAltDown() && !isExternalFocus()) { EventTarget eventTarget = paramEvent.getTarget(); switch (((KeyEvent)paramEvent).getCode()) { case TAB: case ENTER: paramEvent.consume();case UP: case DOWN: return paramEvent;case LEFT: if (eventTarget instanceof Node) { NodeHelper.traverse((Node)eventTarget, Direction.LEFT); paramEvent.consume(); } else if (eventTarget instanceof Scene) { Node node = ((Scene)eventTarget).getFocusOwner(); if (node != null) { NodeHelper.traverse(node, Direction.LEFT); paramEvent.consume(); }  } case RIGHT: if (eventTarget instanceof Node) { NodeHelper.traverse((Node)eventTarget, Direction.RIGHT); paramEvent.consume(); } else if (eventTarget instanceof Scene) { Node node = ((Scene)eventTarget).getFocusOwner(); if (node != null) { NodeHelper.traverse(node, Direction.RIGHT); paramEvent.consume(); }  }  }  Scene scene = null; if (this.tlNode != null) { scene = this.tlNode.getScene(); Event.fireEvent(scene, paramEvent); }  paramEvent.consume(); }  }); this.tlfEventDispatcher = ((paramEvent, paramEventDispatchChain) -> { if (paramEvent instanceof KeyEvent) { if (isExternalFocus()) { paramEventDispatchChain = paramEventDispatchChain.prepend(this.preemptiveEventDispatcher); return paramEventDispatchChain.dispatchEvent(paramEvent); }  paramEventDispatchChain = paramEventDispatchChain.prepend(this.preemptivePopupEventDispatcher); paramEventDispatchChain = paramEventDispatchChain.prepend(this.origEventDispatcher); return paramEventDispatchChain.dispatchEvent(paramEvent); }  return this.origEventDispatcher.dispatchEvent(paramEvent, paramEventDispatchChain); }); this.keyEventListener = (paramKeyEvent -> postDispatchTidyup(paramKeyEvent)); this.focusListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> {  }); this.mouseEventListener = (paramMouseEvent -> setExternalFocus(false));
/*     */     this.tlNode = paramNode;
/*     */     setExternalFocus(false);
/*     */     this.tlNode.addEventHandler(KeyEvent.ANY, this.keyEventListener);
/*     */     this.tlNode.addEventHandler(MouseEvent.MOUSE_PRESSED, this.mouseEventListener);
/*     */     this.tlNode.focusedProperty().addListener(this.focusListener);
/*     */     this.origEventDispatcher = this.tlNode.getEventDispatcher();
/*     */     this.tlNode.setEventDispatcher(this.tlfEventDispatcher); }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*     */     this.tlNode.removeEventHandler(KeyEvent.ANY, this.keyEventListener);
/*     */     this.tlNode.removeEventHandler(MouseEvent.MOUSE_PRESSED, this.mouseEventListener);
/*     */     this.tlNode.focusedProperty().removeListener(this.focusListener);
/*     */     this.tlNode.setEventDispatcher(this.origEventDispatcher);
/*     */   }
/*     */   
/*     */   private Event postDispatchTidyup(Event paramEvent) {
/*     */     if (paramEvent instanceof KeyEvent && paramEvent.getEventType() == KeyEvent.KEY_PRESSED && !isExternalFocus())
/*     */       if (!((KeyEvent)paramEvent).isMetaDown() && !((KeyEvent)paramEvent).isControlDown() && !((KeyEvent)paramEvent).isAltDown())
/*     */         switch (((KeyEvent)paramEvent).getCode()) {
/*     */           case TAB:
/*     */           case UP:
/*     */           case DOWN:
/*     */           case LEFT:
/*     */           case RIGHT:
/*     */             paramEvent.consume();
/*     */             break;
/*     */           case ENTER:
/*     */             setExternalFocus(true);
/*     */             paramEvent.consume();
/*     */             break;
/*     */         }   
/*     */     return paramEvent;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TwoLevelFocusPopupBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */