/*    */ package com.sun.javafx.scene.control.skin.resources;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ControlResources
/*    */ {
/*    */   private static final String BASE_NAME = "com/sun/javafx/scene/control/skin/resources/controls";
/*    */   private static final String NT_BASE_NAME = "com/sun/javafx/scene/control/skin/resources/controls-nt";
/*    */   
/*    */   public static String getString(String paramString) {
/* 52 */     return ResourceBundle.getBundle("com/sun/javafx/scene/control/skin/resources/controls").getString(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getNonTranslatableString(String paramString) {
/* 68 */     return ResourceBundle.getBundle("com/sun/javafx/scene/control/skin/resources/controls-nt").getString(paramString);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\skin\resources\ControlResources.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */