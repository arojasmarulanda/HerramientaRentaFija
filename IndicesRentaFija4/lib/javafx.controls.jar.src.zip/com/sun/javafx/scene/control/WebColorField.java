/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import com.sun.javafx.scene.control.skin.WebColorFieldSkin;
/*    */ import javafx.beans.property.ObjectProperty;
/*    */ import javafx.beans.property.SimpleObjectProperty;
/*    */ import javafx.scene.control.Skin;
/*    */ import javafx.scene.paint.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebColorField
/*    */   extends InputField
/*    */ {
/* 42 */   private ObjectProperty<Color> value = new SimpleObjectProperty<>(this, "value");
/* 43 */   public final Color getValue() { return this.value.get(); }
/* 44 */   public final void setValue(Color paramColor) { this.value.set(paramColor); } public final ObjectProperty<Color> valueProperty() {
/* 45 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public WebColorField() {
/* 51 */     getStyleClass().setAll(new String[] { "webcolor-field" });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Skin<?> createDefaultSkin() {
/* 62 */     return new WebColorFieldSkin(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\WebColorField.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */