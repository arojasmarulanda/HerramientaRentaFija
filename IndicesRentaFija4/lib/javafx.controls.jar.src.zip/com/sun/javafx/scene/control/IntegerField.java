/*    */ package com.sun.javafx.scene.control;
/*    */ 
/*    */ import com.sun.javafx.scene.control.skin.IntegerFieldSkin;
/*    */ import javafx.beans.property.IntegerProperty;
/*    */ import javafx.beans.property.SimpleIntegerProperty;
/*    */ import javafx.scene.control.Skin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerField
/*    */   extends InputField
/*    */ {
/* 41 */   private IntegerProperty value = new SimpleIntegerProperty(this, "value");
/* 42 */   public final int getValue() { return this.value.get(); }
/* 43 */   public final void setValue(int paramInt) { this.value.set(paramInt); } public final IntegerProperty valueProperty() {
/* 44 */     return this.value;
/*    */   }
/* 46 */   private IntegerProperty maxValue = new SimpleIntegerProperty(this, "maxValue", -1);
/* 47 */   public final int getMaxValue() { return this.maxValue.get(); }
/* 48 */   public final void setMaxValue(int paramInt) { this.maxValue.set(paramInt); } public final IntegerProperty maxValueProperty() {
/* 49 */     return this.maxValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public IntegerField() {
/* 54 */     this(-1);
/*    */   }
/*    */   public IntegerField(int paramInt) {
/* 57 */     getStyleClass().setAll(new String[] { "integer-field" });
/* 58 */     setMaxValue(paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Skin<?> createDefaultSkin() {
/* 69 */     return new IntegerFieldSkin(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\IntegerField.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */