/*      */ package com.sun.javafx.scene.control.skin;
/*      */ 
/*      */ import com.sun.javafx.util.Utils;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.security.AccessController;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import javafx.animation.Animation;
/*      */ import javafx.animation.Interpolator;
/*      */ import javafx.animation.KeyFrame;
/*      */ import javafx.animation.KeyValue;
/*      */ import javafx.animation.Timeline;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.SimpleDoubleProperty;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.EventType;
/*      */ import javafx.geometry.Bounds;
/*      */ import javafx.geometry.HPos;
/*      */ import javafx.geometry.Point2D;
/*      */ import javafx.geometry.Rectangle2D;
/*      */ import javafx.geometry.VPos;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Parent;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.control.SkinBase;
/*      */ import javafx.scene.control.TextArea;
/*      */ import javafx.scene.control.TextInputControl;
/*      */ import javafx.scene.control.skin.TextAreaSkin;
/*      */ import javafx.scene.input.InputEvent;
/*      */ import javafx.scene.input.KeyCode;
/*      */ import javafx.scene.input.KeyEvent;
/*      */ import javafx.scene.input.MouseButton;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.input.TouchEvent;
/*      */ import javafx.scene.layout.Region;
/*      */ import javafx.scene.text.Text;
/*      */ import javafx.stage.Popup;
/*      */ import javafx.stage.Window;
/*      */ import javafx.util.Duration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FXVKSkin
/*      */   extends SkinBase<FXVK>
/*      */ {
/*      */   private static final int GAP = 6;
/*      */   private List<List<Key>> currentBoard;
/*   84 */   private static HashMap<String, List<List<Key>>> boardMap = new HashMap<>();
/*      */   
/*      */   private int numCols;
/*      */   private boolean capsDown = false;
/*      */   private boolean shiftDown = false;
/*      */   private boolean isSymbol = false;
/*   90 */   long lastTime = -1L; private static Popup vkPopup;
/*      */   
/*      */   void clearShift() {
/*   93 */     if (this.shiftDown && !this.capsDown) {
/*   94 */       this.shiftDown = false;
/*   95 */       updateKeys();
/*      */     } 
/*   97 */     this.lastTime = -1L;
/*      */   }
/*      */   private static Popup secondaryPopup; private static FXVK primaryVK;
/*      */   void pressShift() {
/*  101 */     long l = System.currentTimeMillis();
/*      */ 
/*      */     
/*  104 */     if (this.shiftDown && !this.capsDown) {
/*  105 */       if (this.lastTime > 0L && l - this.lastTime < 400L) {
/*      */         
/*  107 */         this.shiftDown = false;
/*  108 */         this.capsDown = true;
/*      */       } else {
/*      */         
/*  111 */         this.shiftDown = false;
/*  112 */         this.capsDown = false;
/*      */       } 
/*  114 */     } else if (!this.shiftDown && !this.capsDown) {
/*      */       
/*  116 */       this.shiftDown = true;
/*      */     } else {
/*      */       
/*  119 */       this.shiftDown = false;
/*  120 */       this.capsDown = false;
/*      */     } 
/*      */     
/*  123 */     updateKeys();
/*  124 */     this.lastTime = l;
/*      */   }
/*      */   
/*      */   void clearSymbolABC() {
/*  128 */     this.isSymbol = false;
/*  129 */     updateKeys();
/*      */   }
/*      */   
/*      */   void pressSymbolABC() {
/*  133 */     this.isSymbol = !this.isSymbol;
/*  134 */     updateKeys();
/*      */   }
/*      */   
/*      */   void clearStateKeys() {
/*  138 */     this.capsDown = false;
/*  139 */     this.shiftDown = false;
/*  140 */     this.isSymbol = false;
/*  141 */     this.lastTime = -1L;
/*  142 */     updateKeys();
/*      */   }
/*      */   
/*      */   private void updateKeys() {
/*  146 */     for (List<Key> list : this.currentBoard) {
/*  147 */       for (Key key : list) {
/*  148 */         key.update(this.capsDown, this.shiftDown, this.isSymbol);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  157 */   private static Timeline slideInTimeline = new Timeline();
/*  158 */   private static Timeline slideOutTimeline = new Timeline();
/*      */   
/*      */   private static boolean hideAfterSlideOut = false;
/*      */   
/*      */   private static FXVK secondaryVK;
/*      */   
/*      */   private static Timeline secondaryVKDelay;
/*      */   
/*      */   private static CharKey secondaryVKKey;
/*      */   private static TextInputKey repeatKey;
/*      */   private static Timeline repeatInitialDelay;
/*      */   private static Timeline repeatSubsequentDelay;
/*  170 */   private static double KEY_REPEAT_DELAY = 400.0D;
/*  171 */   private static double KEY_REPEAT_DELAY_MIN = 100.0D;
/*  172 */   private static double KEY_REPEAT_DELAY_MAX = 1000.0D;
/*      */ 
/*      */   
/*  175 */   private static double KEY_REPEAT_RATE = 25.0D;
/*  176 */   private static double KEY_REPEAT_RATE_MIN = 2.0D;
/*  177 */   private static double KEY_REPEAT_RATE_MAX = 50.0D;
/*      */   
/*      */   private Node attachedNode;
/*  180 */   private String vkType = null;
/*      */   
/*      */   FXVK fxvk;
/*      */   
/*      */   static final double VK_HEIGHT = 243.0D;
/*      */   
/*      */   static final double VK_SLIDE_MILLIS = 250.0D;
/*      */   static final double PREF_PORTRAIT_KEY_WIDTH = 40.0D;
/*      */   static final double PREF_KEY_HEIGHT = 56.0D;
/*      */   static boolean vkAdjustWindow = false;
/*      */   static boolean vkLookup = false;
/*      */   
/*      */   static {
/*  193 */     AccessController.doPrivileged(() -> {
/*      */           String str = System.getProperty("com.sun.javafx.vk.adjustwindow");
/*      */           if (str != null) {
/*      */             vkAdjustWindow = Boolean.valueOf(str).booleanValue();
/*      */           }
/*      */           str = System.getProperty("com.sun.javafx.sqe.vk.lookup");
/*      */           if (str != null) {
/*      */             vkLookup = Boolean.valueOf(str).booleanValue();
/*      */           }
/*      */           str = System.getProperty("com.sun.javafx.virtualKeyboard.backspaceRepeatDelay");
/*      */           if (str != null) {
/*      */             Double double_ = Double.valueOf(str);
/*      */             KEY_REPEAT_DELAY = Math.min(Math.max(double_.doubleValue(), KEY_REPEAT_DELAY_MIN), KEY_REPEAT_DELAY_MAX);
/*      */           } 
/*      */           str = System.getProperty("com.sun.javafx.virtualKeyboard.backspaceRepeatRate");
/*      */           if (str != null) {
/*      */             Double double_ = Double.valueOf(str);
/*      */             if (double_.doubleValue() <= 0.0D) {
/*      */               KEY_REPEAT_RATE = 0.0D;
/*      */             } else {
/*      */               KEY_REPEAT_RATE = Math.min(Math.max(double_.doubleValue(), KEY_REPEAT_RATE_MIN), KEY_REPEAT_RATE_MAX);
/*      */             } 
/*      */           } 
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  222 */   private static DoubleProperty winY = new SimpleDoubleProperty(); EventHandler<InputEvent> unHideEventHandler;
/*      */   static {
/*  224 */     winY.addListener(paramObservable -> {
/*      */           if (vkPopup != null) {
/*      */             vkPopup.setY(winY.get());
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private static void startSlideIn() {
/*  232 */     slideOutTimeline.stop();
/*  233 */     slideInTimeline.playFromStart();
/*      */   }
/*      */   
/*      */   private static void startSlideOut(boolean paramBoolean) {
/*  237 */     hideAfterSlideOut = paramBoolean;
/*  238 */     slideInTimeline.stop();
/*  239 */     slideOutTimeline.playFromStart();
/*      */   }
/*      */   
/*      */   private void adjustWindowPosition(Node paramNode) {
/*  243 */     if (!(paramNode instanceof TextInputControl)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  248 */     double d1 = paramNode.localToScene(0.0D, 0.0D).getY() + paramNode.getScene().getY();
/*  249 */     double d2 = ((TextInputControl)paramNode).getHeight();
/*  250 */     double d3 = d1 + d2;
/*      */ 
/*      */     
/*  253 */     double d4 = Utils.getScreen(paramNode).getBounds().getHeight();
/*  254 */     double d5 = d4 - 243.0D;
/*      */     
/*  256 */     double d6 = 0.0D;
/*  257 */     double d7 = 0.0D;
/*  258 */     double d8 = 0.0D;
/*  259 */     double d9 = 10.0D;
/*      */     
/*  261 */     if (paramNode instanceof javafx.scene.control.TextField) {
/*  262 */       d6 = d1 + d2 / 2.0D;
/*  263 */       d7 = d3;
/*      */       
/*  265 */       Parent parent = this.attachedNode.getParent();
/*  266 */       if (parent instanceof javafx.scene.control.ComboBoxBase) {
/*      */ 
/*      */         
/*  269 */         d8 = Math.min(d9 - d1, 0.0D);
/*      */       } else {
/*      */         
/*  272 */         d8 = Math.min(d5 / 2.0D - d6, 0.0D);
/*      */       } 
/*  274 */     } else if (paramNode instanceof TextArea) {
/*  275 */       TextAreaSkin textAreaSkin = (TextAreaSkin)((TextArea)paramNode).getSkin();
/*  276 */       Bounds bounds = textAreaSkin.getCaretBounds();
/*  277 */       double d10 = bounds.getMinY();
/*  278 */       double d11 = bounds.getMaxY();
/*  279 */       d6 = d1 + (d10 + d11) / 2.0D;
/*  280 */       d7 = d1 + d11;
/*      */       
/*  282 */       if (d2 < d5) {
/*      */         
/*  284 */         d8 = d5 / 2.0D - d1 + d2 / 2.0D;
/*      */       } else {
/*      */         
/*  287 */         d8 = d5 / 2.0D - d6;
/*      */       } 
/*  289 */       d8 = Math.min(d8, 0.0D);
/*      */     } else {
/*      */       
/*  292 */       d6 = d1 + d2 / 2.0D;
/*  293 */       d7 = d3;
/*      */       
/*  295 */       d8 = Math.min(d5 / 2.0D - d6, 0.0D);
/*      */     } 
/*      */     
/*  298 */     Window window = paramNode.getScene().getWindow();
/*  299 */     if (this.origWindowYPos.doubleValue() + d7 > d5) {
/*  300 */       window.setY(d8);
/*      */     } else {
/*  302 */       window.setY(this.origWindowYPos.doubleValue());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void saveWindowPosition(Node paramNode) {
/*  307 */     Window window = paramNode.getScene().getWindow();
/*  308 */     this.origWindowYPos = Double.valueOf(window.getY());
/*      */   }
/*      */   
/*      */   private void restoreWindowPosition(Node paramNode) {
/*  312 */     if (paramNode != null) {
/*  313 */       Scene scene = paramNode.getScene();
/*  314 */       if (scene != null) {
/*  315 */         Window window = scene.getWindow();
/*  316 */         if (window != null) {
/*  317 */           window.setY(this.origWindowYPos.doubleValue());
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isVKHidden = false;
/*      */   
/*  326 */   private Double origWindowYPos = null;
/*      */   
/*      */   private void registerUnhideHandler(Node paramNode) {
/*  329 */     if (this.unHideEventHandler == null) {
/*  330 */       this.unHideEventHandler = (paramInputEvent -> {
/*      */           if (this.attachedNode != null && this.isVKHidden) {
/*      */             double d = Utils.getScreen(this.attachedNode).getBounds().getHeight();
/*      */             
/*      */             if (this.fxvk.getHeight() > 0.0D && vkPopup.getY() > d - this.fxvk.getHeight() && slideInTimeline.getStatus() != Animation.Status.RUNNING) {
/*      */               startSlideIn();
/*      */               
/*      */               if (vkAdjustWindow) {
/*      */                 adjustWindowPosition(this.attachedNode);
/*      */               }
/*      */             } 
/*      */           } 
/*      */           this.isVKHidden = false;
/*      */         });
/*      */     }
/*  345 */     paramNode.addEventHandler((EventType)TouchEvent.TOUCH_PRESSED, this.unHideEventHandler);
/*  346 */     paramNode.addEventHandler((EventType)MouseEvent.MOUSE_PRESSED, this.unHideEventHandler);
/*      */   }
/*      */   
/*      */   private void unRegisterUnhideHandler(Node paramNode) {
/*  350 */     if (this.unHideEventHandler != null) {
/*  351 */       paramNode.removeEventHandler((EventType)TouchEvent.TOUCH_PRESSED, this.unHideEventHandler);
/*  352 */       paramNode.removeEventHandler((EventType)MouseEvent.MOUSE_PRESSED, this.unHideEventHandler);
/*      */     } 
/*      */   }
/*      */   
/*      */   private String getNodeVKType(Node paramNode) {
/*  357 */     Integer integer = (Integer)paramNode.getProperties().get("vkType");
/*  358 */     String str = null;
/*  359 */     if (integer != null) {
/*  360 */       String str1 = FXVK.VK_TYPE_NAMES[integer.intValue()];
/*  361 */       if (str1 instanceof String) {
/*  362 */         str = str1.toLowerCase(Locale.ROOT);
/*      */       }
/*      */     } 
/*  365 */     return (str != null) ? str : "text";
/*      */   }
/*      */   
/*      */   private void updateKeyboardType(Node paramNode) {
/*  369 */     String str = this.vkType;
/*  370 */     this.vkType = getNodeVKType(paramNode);
/*      */     
/*  372 */     if (str == null || !this.vkType.equals(str)) {
/*  373 */       rebuildPrimaryVK(this.vkType);
/*      */     }
/*      */   }
/*      */   
/*      */   private void closeSecondaryVK() {
/*  378 */     if (secondaryVK != null) {
/*  379 */       secondaryVK.setAttachedNode((Node)null);
/*  380 */       secondaryPopup.hide();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setupPrimaryVK() {
/*  385 */     this.fxvk.setFocusTraversable(false);
/*  386 */     this.fxvk.setVisible(true);
/*      */ 
/*      */     
/*  389 */     if (vkPopup == null) {
/*  390 */       vkPopup = new Popup();
/*  391 */       vkPopup.setAutoFix(false);
/*      */     } 
/*  393 */     vkPopup.getContent().setAll(new Node[] { this.fxvk });
/*      */ 
/*      */     
/*  396 */     double d1 = Utils.getScreen(this.fxvk).getBounds().getHeight();
/*  397 */     double d2 = Utils.getScreen(this.fxvk).getBounds().getWidth();
/*      */ 
/*      */     
/*  400 */     slideInTimeline.getKeyFrames().setAll(new KeyFrame[] { new KeyFrame(
/*  401 */             Duration.millis(250.0D), new KeyValue[] { new KeyValue(winY, 
/*  402 */                 (T)Double.valueOf(d1 - 243.0D), Interpolator.EASE_BOTH) }) });
/*      */     
/*  404 */     slideOutTimeline.getKeyFrames().setAll(new KeyFrame[] { new KeyFrame(
/*  405 */             Duration.millis(250.0D), paramActionEvent -> { if (hideAfterSlideOut && vkPopup.isShowing()) vkPopup.hide();  }new KeyValue[] { new KeyValue(winY, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  411 */                 (T)Double.valueOf(d1), Interpolator.EASE_BOTH) }) });
/*      */ 
/*      */     
/*  414 */     this.fxvk.setPrefWidth(d2);
/*  415 */     this.fxvk.setMinWidth(Double.NEGATIVE_INFINITY);
/*  416 */     this.fxvk.setMaxWidth(Double.NEGATIVE_INFINITY);
/*      */     
/*  418 */     this.fxvk.setPrefHeight(243.0D);
/*  419 */     this.fxvk.setMinHeight(Double.NEGATIVE_INFINITY);
/*      */ 
/*      */ 
/*      */     
/*  423 */     if (secondaryVKDelay == null) {
/*  424 */       secondaryVKDelay = new Timeline();
/*      */     }
/*  426 */     KeyFrame keyFrame = new KeyFrame(Duration.millis(500.0D), paramActionEvent -> { if (secondaryVKKey != null) showSecondaryVK(secondaryVKKey);  }new KeyValue[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  431 */     secondaryVKDelay.getKeyFrames().setAll(new KeyFrame[] { keyFrame });
/*      */ 
/*      */     
/*  434 */     if (KEY_REPEAT_RATE > 0.0D) {
/*      */       
/*  436 */       repeatInitialDelay = new Timeline(new KeyFrame[] { new KeyFrame(Duration.millis(KEY_REPEAT_DELAY), paramActionEvent -> { repeatKey.sendKeyEvents(); repeatSubsequentDelay.playFromStart(); }new KeyValue[0]) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  445 */       repeatSubsequentDelay = new Timeline(new KeyFrame[] { new KeyFrame(Duration.millis(1000.0D / KEY_REPEAT_RATE), paramActionEvent -> repeatKey.sendKeyEvents(), new KeyValue[0]) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  451 */       repeatSubsequentDelay.setCycleCount(-1);
/*      */     } 
/*      */   }
/*      */   
/*      */   void prerender(Node paramNode) {
/*  456 */     if (this.fxvk != primaryVK) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  461 */     loadBoard("text");
/*  462 */     loadBoard("numeric");
/*  463 */     loadBoard("url");
/*  464 */     loadBoard("email");
/*      */     
/*  466 */     updateKeyboardType(paramNode);
/*  467 */     this.fxvk.setVisible(true);
/*      */     
/*  469 */     if (!vkPopup.isShowing()) {
/*      */       
/*  471 */       Rectangle2D rectangle2D = Utils.getScreen(paramNode).getBounds();
/*      */       
/*  473 */       vkPopup.setX((rectangle2D.getWidth() - this.fxvk.prefWidth(-1.0D)) / 2.0D);
/*  474 */       winY.set(rectangle2D.getHeight());
/*  475 */       vkPopup.show(paramNode.getScene().getWindow());
/*      */     } 
/*      */   }
/*      */   
/*      */   public FXVKSkin(final FXVK fxvk) {
/*  480 */     super(fxvk);
/*  481 */     this.fxvk = fxvk;
/*  482 */     if (fxvk == FXVK.vk) {
/*  483 */       primaryVK = fxvk;
/*      */     }
/*      */     
/*  486 */     if (fxvk == primaryVK) {
/*  487 */       setupPrimaryVK();
/*      */     }
/*      */     
/*  490 */     fxvk.attachedNodeProperty().addListener(new InvalidationListener() {
/*      */           public void invalidated(Observable param1Observable) {
/*  492 */             Node node = FXVKSkin.this.attachedNode;
/*  493 */             FXVKSkin.this.attachedNode = fxvk.getAttachedNode();
/*  494 */             if (fxvk != FXVKSkin.primaryVK) {
/*      */               return;
/*      */             }
/*      */             
/*  498 */             FXVKSkin.this.closeSecondaryVK();
/*      */             
/*  500 */             if (FXVKSkin.this.attachedNode != null) {
/*  501 */               if (node != null) {
/*  502 */                 FXVKSkin.this.unRegisterUnhideHandler(node);
/*      */               }
/*  504 */               FXVKSkin.this.registerUnhideHandler(FXVKSkin.this.attachedNode);
/*  505 */               FXVKSkin.this.updateKeyboardType(FXVKSkin.this.attachedNode);
/*      */ 
/*      */               
/*  508 */               if ((node == null || node.getScene() == null || node.getScene().getWindow() != FXVKSkin.this.attachedNode.getScene().getWindow()) && FXVKSkin
/*  509 */                 .vkPopup.isShowing()) {
/*  510 */                 FXVKSkin.vkPopup.hide();
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*  515 */               if (!FXVKSkin.vkPopup.isShowing()) {
/*      */                 
/*  517 */                 Rectangle2D rectangle2D = Utils.getScreen(FXVKSkin.this.attachedNode).getBounds();
/*      */                 
/*  519 */                 FXVKSkin.vkPopup.setX((rectangle2D.getWidth() - fxvk.prefWidth(-1.0D)) / 2.0D);
/*  520 */                 if (node == null || FXVKSkin.this.isVKHidden) {
/*      */                   
/*  522 */                   FXVKSkin.winY.set(rectangle2D.getHeight());
/*      */                 } else {
/*      */                   
/*  525 */                   FXVKSkin.winY.set(rectangle2D.getHeight() - 243.0D);
/*      */                 } 
/*  527 */                 FXVKSkin.vkPopup.show(FXVKSkin.this.attachedNode.getScene().getWindow());
/*      */               } 
/*      */               
/*  530 */               if (node == null || FXVKSkin.this.isVKHidden) {
/*  531 */                 FXVKSkin.startSlideIn();
/*      */               }
/*      */               
/*  534 */               if (FXVKSkin.vkAdjustWindow) {
/*      */                 
/*  536 */                 if (node == null || node.getScene() == null || node
/*  537 */                   .getScene().getWindow() != FXVKSkin.this.attachedNode.getScene().getWindow()) {
/*  538 */                   FXVKSkin.this.saveWindowPosition(FXVKSkin.this.attachedNode);
/*      */                 }
/*      */                 
/*  541 */                 FXVKSkin.this.adjustWindowPosition(FXVKSkin.this.attachedNode);
/*      */               } 
/*      */             } else {
/*  544 */               if (node != null) {
/*  545 */                 FXVKSkin.this.unRegisterUnhideHandler(node);
/*      */               }
/*  547 */               FXVKSkin.startSlideOut(true);
/*      */               
/*  549 */               if (FXVKSkin.vkAdjustWindow) {
/*  550 */                 FXVKSkin.this.restoreWindowPosition(node);
/*      */               }
/*      */             } 
/*  553 */             FXVKSkin.this.isVKHidden = false;
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void rebuildSecondaryVK() {
/*  562 */     if (secondaryVK.chars != null) {
/*      */       
/*  564 */       int i = secondaryVK.chars.length;
/*  565 */       int j = (int)Math.floor(Math.sqrt(Math.max(1, i - 2)));
/*  566 */       int k = (int)Math.ceil(i / j);
/*      */ 
/*      */       
/*  569 */       ArrayList<ArrayList<CharKey>> arrayList = new ArrayList(2);
/*      */       
/*  571 */       for (byte b = 0; b < j; b++) {
/*  572 */         int m = b * k;
/*  573 */         int n = Math.min(m + k, i);
/*  574 */         if (m >= n) {
/*      */           break;
/*      */         }
/*  577 */         ArrayList<CharKey> arrayList1 = new ArrayList(k);
/*  578 */         for (int i1 = m; i1 < n; i1++) {
/*  579 */           CharKey charKey = new CharKey(secondaryVK.chars[i1], null, null);
/*  580 */           charKey.col = (i1 - m) * 2;
/*  581 */           charKey.colSpan = 2;
/*  582 */           for (String str : charKey.getStyleClass()) {
/*  583 */             charKey.text.getStyleClass().add(str + "-text");
/*  584 */             charKey.altText.getStyleClass().add(str + "-alttext");
/*  585 */             charKey.icon.getStyleClass().add(str + "-icon");
/*      */           } 
/*  587 */           if (secondaryVK.chars[i1] != null && secondaryVK.chars[i1].length() > 1) {
/*  588 */             charKey.text.getStyleClass().add("multi-char-text");
/*      */           }
/*  590 */           arrayList1.add(charKey);
/*      */         } 
/*  592 */         arrayList.add(arrayList1);
/*      */       } 
/*  594 */       this.currentBoard = (List)arrayList;
/*      */       
/*  596 */       getChildren().clear();
/*  597 */       this.numCols = 0;
/*  598 */       for (List<? extends Node> list : this.currentBoard) {
/*  599 */         for (Key key : list) {
/*  600 */           this.numCols = Math.max(this.numCols, key.col + key.colSpan);
/*      */         }
/*  602 */         getChildren().addAll(list);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void rebuildPrimaryVK(String paramString) {
/*  612 */     this.currentBoard = loadBoard(paramString);
/*      */ 
/*      */     
/*  615 */     clearStateKeys();
/*      */     
/*  617 */     getChildren().clear();
/*  618 */     this.numCols = 0;
/*  619 */     for (List<? extends Node> list : this.currentBoard) {
/*  620 */       for (Key key : list) {
/*  621 */         this.numCols = Math.max(this.numCols, key.col + key.colSpan);
/*      */       }
/*  623 */       getChildren().addAll(list);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double computePrefWidth(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  631 */     return paramDouble5 + (56 * this.numCols) + paramDouble3;
/*      */   }
/*      */ 
/*      */   
/*      */   protected double computePrefHeight(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  636 */     return paramDouble2 + 400.0D + paramDouble4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  643 */     int i = this.currentBoard.size();
/*  644 */     double d1 = (paramDouble3 - ((this.numCols - 1) * 6)) / this.numCols;
/*  645 */     double d2 = (paramDouble4 - ((i - 1) * 6)) / i;
/*  646 */     double d3 = paramDouble2;
/*  647 */     for (List<Key> list : this.currentBoard) {
/*  648 */       for (Key key : list) {
/*  649 */         double d4 = paramDouble1 + key.col * (d1 + 6.0D);
/*  650 */         double d5 = key.colSpan * (d1 + 6.0D) - 6.0D;
/*  651 */         key.resizeRelocate((int)(d4 + 0.5D), (int)(d3 + 0.5D), d5, d2);
/*      */       } 
/*      */       
/*  654 */       d3 += d2 + 6.0D;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class Key
/*      */     extends Region
/*      */   {
/*  665 */     int col = 0;
/*  666 */     int colSpan = 1;
/*      */     protected final Text text;
/*      */     protected final Text altText;
/*      */     protected final Region icon;
/*      */     
/*      */     protected Key() {
/*  672 */       this.icon = new Region();
/*  673 */       this.text = new Text();
/*  674 */       this.text.setTextOrigin(VPos.TOP);
/*  675 */       this.altText = new Text();
/*  676 */       this.altText.setTextOrigin(VPos.TOP);
/*  677 */       getChildren().setAll(new Node[] { this.text, this.altText, this.icon });
/*  678 */       getStyleClass().setAll(new String[] { "key" });
/*  679 */       addEventHandler(MouseEvent.MOUSE_PRESSED, param1MouseEvent -> {
/*      */             if (param1MouseEvent.getButton() == MouseButton.PRIMARY)
/*      */               press(); 
/*      */           });
/*  683 */       addEventHandler(MouseEvent.MOUSE_RELEASED, param1MouseEvent -> {
/*      */             if (param1MouseEvent.getButton() == MouseButton.PRIMARY)
/*      */               release(); 
/*      */           });
/*      */     }
/*      */     protected void press() {}
/*      */     protected void release() {
/*  690 */       FXVKSkin.this.clearShift();
/*      */     }
/*      */     
/*      */     public void update(boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {}
/*      */     
/*      */     protected void layoutChildren() {
/*  696 */       double d1 = snappedLeftInset();
/*  697 */       double d2 = snappedTopInset();
/*  698 */       double d3 = getWidth() - d1 - snappedRightInset();
/*  699 */       double d4 = getHeight() - d2 - snappedBottomInset();
/*      */       
/*  701 */       this.text.setVisible((this.icon.getBackground() == null));
/*  702 */       double d5 = this.text.prefWidth(-1.0D);
/*  703 */       double d6 = this.text.prefHeight(-1.0D);
/*  704 */       this.text.resizeRelocate((int)(d1 + (d3 - d5) / 2.0D + 0.5D), (int)(d2 + (d4 - d6) / 2.0D + 0.5D), (int)d5, (int)d6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  710 */       this.altText.setVisible((this.icon.getBackground() == null && this.altText.getText().length() > 0));
/*  711 */       d5 = this.altText.prefWidth(-1.0D);
/*  712 */       d6 = this.altText.prefHeight(-1.0D);
/*  713 */       this.altText.resizeRelocate((int)d1 + d3 - d5 + 0.5D, (int)(d2 + (d4 - d6) / 2.0D + 0.5D - d4 / 2.0D), (int)d5, (int)d6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  719 */       this.icon.resizeRelocate(d1 - 8.0D, d2 - 8.0D, d3 + 16.0D, d4 + 16.0D);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class TextInputKey
/*      */     extends Key
/*      */   {
/*      */     String chars;
/*      */ 
/*      */     
/*      */     private TextInputKey() {
/*  731 */       this.chars = "";
/*      */     }
/*      */     protected void press() {}
/*      */     
/*      */     protected void release() {
/*  736 */       if (FXVKSkin.this.fxvk != FXVKSkin.secondaryVK && FXVKSkin.secondaryPopup != null && FXVKSkin.secondaryPopup.isShowing()) {
/*      */         return;
/*      */       }
/*  739 */       sendKeyEvents();
/*  740 */       if (FXVKSkin.this.fxvk == FXVKSkin.secondaryVK) {
/*  741 */         FXVKSkin.this.showSecondaryVK((FXVKSkin.CharKey)null);
/*      */       }
/*  743 */       super.release();
/*      */     }
/*      */     
/*      */     protected void sendKeyEvents() {
/*  747 */       Node node = FXVKSkin.this.fxvk.getAttachedNode();
/*  748 */       if (node instanceof javafx.event.EventTarget && 
/*  749 */         this.chars != null) {
/*  750 */         node.fireEvent(new KeyEvent(KeyEvent.KEY_TYPED, this.chars, "", KeyCode.UNDEFINED, FXVKSkin.this.shiftDown, false, false, false));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class CharKey
/*      */     extends TextInputKey
/*      */   {
/*      */     private final String letterChars;
/*      */     
/*      */     private final String altChars;
/*      */     
/*      */     private final String[] moreChars;
/*      */     
/*      */     private CharKey(String param1String1, String param1String2, String[] param1ArrayOfString, String param1String3) {
/*  766 */       this.letterChars = param1String1;
/*  767 */       this.altChars = param1String2;
/*  768 */       this.moreChars = param1ArrayOfString;
/*  769 */       this.chars = this.letterChars;
/*      */       
/*  771 */       this.text.setText(this.chars);
/*  772 */       this.altText.setText(this.altChars);
/*  773 */       if (FXVKSkin.vkLookup) {
/*  774 */         setId(((param1String3 != null) ? param1String3 : this.chars).replaceAll("\\.", ""));
/*      */       }
/*      */     }
/*      */     
/*      */     private CharKey(String param1String1, String param1String2, String[] param1ArrayOfString) {
/*  779 */       this(param1String1, param1String2, param1ArrayOfString, (String)null);
/*      */     }
/*      */     
/*      */     protected void press() {
/*  783 */       super.press();
/*  784 */       if (this.letterChars.equals(this.altChars) && this.moreChars == null) {
/*      */         return;
/*      */       }
/*  787 */       if (FXVKSkin.this.fxvk == FXVKSkin.primaryVK) {
/*  788 */         FXVKSkin.this.showSecondaryVK((CharKey)null);
/*  789 */         FXVKSkin.secondaryVKKey = this;
/*  790 */         FXVKSkin.secondaryVKDelay.playFromStart();
/*      */       } 
/*      */     }
/*      */     
/*      */     protected void release() {
/*  795 */       super.release();
/*  796 */       if (this.letterChars.equals(this.altChars) && this.moreChars == null) {
/*      */         return;
/*      */       }
/*  799 */       if (FXVKSkin.this.fxvk == FXVKSkin.primaryVK) {
/*  800 */         FXVKSkin.secondaryVKDelay.stop();
/*      */       }
/*      */     }
/*      */     
/*      */     public void update(boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
/*  805 */       if (param1Boolean3) {
/*  806 */         this.chars = this.altChars;
/*  807 */         this.text.setText(this.chars);
/*  808 */         if (this.moreChars != null && this.moreChars.length > 0 && !Character.isLetter(this.moreChars[0].charAt(0))) {
/*  809 */           this.altText.setText(this.moreChars[0]);
/*      */         } else {
/*  811 */           this.altText.setText((String)null);
/*      */         } 
/*      */       } else {
/*  814 */         this.chars = (param1Boolean1 || param1Boolean2) ? this.letterChars.toUpperCase() : this.letterChars.toLowerCase();
/*  815 */         this.text.setText(this.chars);
/*  816 */         this.altText.setText(this.altChars);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class SuperKey
/*      */     extends TextInputKey
/*      */   {
/*      */     private SuperKey(String param1String1, String param1String2) {
/*  829 */       this.chars = param1String2;
/*  830 */       this.text.setText(param1String1);
/*  831 */       getStyleClass().add("special");
/*  832 */       if (FXVKSkin.vkLookup) {
/*  833 */         setId(param1String1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class KeyCodeKey
/*      */     extends SuperKey
/*      */   {
/*      */     private KeyCode code;
/*      */ 
/*      */     
/*      */     private KeyCodeKey(String param1String1, String param1String2, KeyCode param1KeyCode) {
/*  846 */       super(param1String1, param1String2);
/*  847 */       this.code = param1KeyCode;
/*  848 */       if (FXVKSkin.vkLookup) {
/*  849 */         setId(param1String1);
/*      */       }
/*      */     }
/*      */     
/*      */     protected void sendKeyEvents() {
/*  854 */       Node node = FXVKSkin.this.fxvk.getAttachedNode();
/*  855 */       if (node instanceof javafx.event.EventTarget) {
/*  856 */         node.fireEvent(new KeyEvent(KeyEvent.KEY_PRESSED, KeyEvent.CHAR_UNDEFINED, this.chars, this.code, FXVKSkin.this.shiftDown, false, false, false));
/*  857 */         node.fireEvent(new KeyEvent(KeyEvent.KEY_TYPED, this.chars, "", KeyCode.UNDEFINED, FXVKSkin.this.shiftDown, false, false, false));
/*  858 */         node.fireEvent(new KeyEvent(KeyEvent.KEY_RELEASED, KeyEvent.CHAR_UNDEFINED, this.chars, this.code, FXVKSkin.this.shiftDown, false, false, false));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class KeyboardStateKey
/*      */     extends Key
/*      */   {
/*      */     private final String defaultText;
/*      */     
/*      */     private final String toggledText;
/*      */ 
/*      */     
/*      */     private KeyboardStateKey(String param1String1, String param1String2, String param1String3) {
/*  873 */       this.defaultText = param1String1;
/*  874 */       this.toggledText = param1String2;
/*  875 */       this.text.setText(this.defaultText);
/*  876 */       if (FXVKSkin.vkLookup && param1String3 != null) {
/*  877 */         setId(param1String3);
/*      */       }
/*  879 */       getStyleClass().add("special");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void update(boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
/*  885 */       if (param1Boolean3) {
/*  886 */         this.text.setText(this.toggledText);
/*      */       } else {
/*  888 */         this.text.setText(this.defaultText);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private void showSecondaryVK(CharKey paramCharKey) {
/*  894 */     if (paramCharKey != null) {
/*  895 */       Node node = primaryVK.getAttachedNode();
/*      */       
/*  897 */       if (secondaryVK == null) {
/*  898 */         secondaryVK = new FXVK();
/*      */         
/*  900 */         secondaryVK.setSkin(new FXVKSkin(secondaryVK));
/*  901 */         secondaryVK.getStyleClass().setAll(new String[] { "fxvk-secondary" });
/*  902 */         secondaryPopup = new Popup();
/*  903 */         secondaryPopup.setAutoHide(true);
/*  904 */         secondaryPopup.getContent().add(secondaryVK);
/*      */       } 
/*      */       
/*  907 */       secondaryVK.chars = null;
/*  908 */       ArrayList<String> arrayList = new ArrayList();
/*      */ 
/*      */       
/*  911 */       if (!this.isSymbol && 
/*  912 */         paramCharKey.letterChars != null && paramCharKey.letterChars.length() > 0) {
/*  913 */         if (this.shiftDown || this.capsDown) {
/*  914 */           arrayList.add(paramCharKey.letterChars.toUpperCase());
/*      */         } else {
/*  916 */           arrayList.add(paramCharKey.letterChars);
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  922 */       if (paramCharKey.altChars != null && paramCharKey.altChars.length() > 0) {
/*  923 */         if (this.shiftDown || this.capsDown) {
/*  924 */           arrayList.add(paramCharKey.altChars.toUpperCase());
/*      */         } else {
/*  926 */           arrayList.add(paramCharKey.altChars);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  931 */       if (paramCharKey.moreChars != null && paramCharKey.moreChars.length > 0) {
/*  932 */         if (this.isSymbol) {
/*      */           
/*  934 */           for (String str : paramCharKey.moreChars) {
/*  935 */             if (!Character.isLetter(str.charAt(0))) {
/*  936 */               arrayList.add(str);
/*      */             }
/*      */           } 
/*      */         } else {
/*      */           
/*  941 */           for (String str : paramCharKey.moreChars) {
/*  942 */             if (Character.isLetter(str.charAt(0))) {
/*  943 */               if (this.shiftDown || this.capsDown) {
/*  944 */                 arrayList.add(str.toUpperCase());
/*      */               } else {
/*  946 */                 arrayList.add(str);
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/*  953 */       boolean bool = false;
/*  954 */       for (String str : arrayList) {
/*  955 */         if (str.length() > 1) {
/*  956 */           bool = true;
/*      */         }
/*      */       } 
/*      */       
/*  960 */       secondaryVK.chars = arrayList.<String>toArray(new String[arrayList.size()]);
/*      */       
/*  962 */       if (secondaryVK.chars.length > 1) {
/*  963 */         if (secondaryVK.getSkin() != null) {
/*  964 */           ((FXVKSkin)secondaryVK.getSkin()).rebuildSecondaryVK();
/*      */         }
/*      */         
/*  967 */         secondaryVK.setAttachedNode(node);
/*  968 */         FXVKSkin fXVKSkin1 = (FXVKSkin)primaryVK.getSkin();
/*  969 */         FXVKSkin fXVKSkin2 = (FXVKSkin)secondaryVK.getSkin();
/*      */         
/*  971 */         int i = secondaryVK.chars.length;
/*  972 */         int j = (int)Math.floor(Math.sqrt(Math.max(1, i - 2)));
/*  973 */         int k = (int)Math.ceil(i / j);
/*      */ 
/*      */         
/*  976 */         double d1 = snappedLeftInset() + snappedRightInset() + k * 40.0D * (bool ? 2 : true) + ((k - 1) * 6);
/*  977 */         double d2 = snappedTopInset() + snappedBottomInset() + j * 56.0D + ((j - 1) * 6);
/*      */ 
/*      */         
/*  980 */         secondaryVK.setPrefWidth(d1);
/*  981 */         secondaryVK.setMinWidth(Double.NEGATIVE_INFINITY);
/*  982 */         secondaryVK.setPrefHeight(d2);
/*  983 */         secondaryVK.setMinHeight(Double.NEGATIVE_INFINITY);
/*  984 */         Platform.runLater(() -> {
/*      */               Point2D point2D = Utils.pointRelativeTo(paramCharKey, paramDouble1, paramDouble2, HPos.CENTER, VPos.TOP, 5.0D, -3.0D, true);
/*      */               
/*      */               double d1 = point2D.getX();
/*      */               
/*      */               double d2 = point2D.getY();
/*      */               
/*      */               Scene scene = paramCharKey.getScene();
/*      */               d1 = Math.min(d1, scene.getWindow().getX() + scene.getWidth() - paramDouble1);
/*      */               secondaryPopup.show(paramCharKey.getScene().getWindow(), d1, d2);
/*      */             });
/*      */       } 
/*      */     } else {
/*  997 */       closeSecondaryVK();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private List<List<Key>> loadBoard(String paramString) {
/* 1003 */     List<List<Key>> list = boardMap.get(paramString);
/* 1004 */     if (list != null) {
/* 1005 */       return list;
/*      */     }
/*      */     
/* 1008 */     String str = paramString.substring(0, 1).toUpperCase() + paramString.substring(0, 1).toUpperCase() + "Board.txt";
/*      */     try {
/* 1010 */       list = new ArrayList<>(5);
/* 1011 */       ArrayList<CharKey> arrayList = new ArrayList(20);
/*      */       
/* 1013 */       InputStream inputStream = FXVKSkin.class.getResourceAsStream(str);
/* 1014 */       BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
/*      */ 
/*      */ 
/*      */       
/* 1018 */       byte b1 = 0;
/*      */       
/* 1020 */       byte b2 = 0;
/*      */       
/* 1022 */       int i = 1;
/*      */       
/* 1024 */       boolean bool = false;
/*      */       
/* 1026 */       ArrayList<String> arrayList1 = new ArrayList(10);
/*      */       String str1;
/* 1028 */       while ((str1 = bufferedReader.readLine()) != null) {
/* 1029 */         if (str1.length() == 0 || str1.charAt(0) == '#') {
/*      */           continue;
/*      */         }
/*      */         
/* 1033 */         for (int j = 0; j < str1.length(); j++) {
/* 1034 */           char c = str1.charAt(j);
/*      */ 
/*      */           
/* 1037 */           if (c == ' ') {
/* 1038 */             b1++;
/* 1039 */           } else if (c == '[') {
/*      */             
/* 1041 */             b2 = b1;
/* 1042 */             arrayList1 = new ArrayList(10);
/* 1043 */             bool = false;
/* 1044 */           } else if (c == ']') {
/* 1045 */             CharKey charKey; String str2 = "";
/* 1046 */             String str3 = null;
/* 1047 */             String[] arrayOfString = null;
/*      */             int k;
/* 1049 */             for (k = 0; k < arrayList1.size(); k++) {
/* 1050 */               arrayList1.set(k, FXVKCharEntities.get(arrayList1.get(k)));
/*      */             }
/*      */             
/* 1053 */             k = arrayList1.size();
/* 1054 */             if (k > 0) {
/* 1055 */               str2 = arrayList1.get(0);
/* 1056 */               if (k > 1) {
/* 1057 */                 str3 = arrayList1.get(1);
/* 1058 */                 if (k > 2) {
/* 1059 */                   arrayOfString = (String[])arrayList1.subList(2, k).toArray((Object[])new String[k - 2]);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/* 1065 */             i = b1 - b2;
/*      */             
/* 1067 */             if (bool) {
/* 1068 */               if ("$shift".equals(str2)) {
/* 1069 */                 KeyboardStateKey keyboardStateKey = new KeyboardStateKey("", null, "shift") {
/*      */                     protected void release() {
/* 1071 */                       FXVKSkin.this.pressShift();
/*      */                     }
/*      */                     
/*      */                     public void update(boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
/* 1075 */                       if (param1Boolean3) {
/* 1076 */                         setDisable(true);
/* 1077 */                         setVisible(false);
/*      */                       } else {
/* 1079 */                         if (param1Boolean1) {
/* 1080 */                           this.icon.getStyleClass().remove("shift-icon");
/* 1081 */                           this.icon.getStyleClass().add("capslock-icon");
/*      */                         } else {
/* 1083 */                           this.icon.getStyleClass().remove("capslock-icon");
/* 1084 */                           this.icon.getStyleClass().add("shift-icon");
/*      */                         } 
/* 1086 */                         setDisable(false);
/* 1087 */                         setVisible(true);
/*      */                       } 
/*      */                     }
/*      */                   };
/* 1091 */                 keyboardStateKey.getStyleClass().add("shift");
/*      */               }
/* 1093 */               else if ("$SymbolABC".equals(str2)) {
/* 1094 */                 KeyboardStateKey keyboardStateKey = new KeyboardStateKey("!#123", "ABC", "symbol") {
/*      */                     protected void release() {
/* 1096 */                       FXVKSkin.this.pressSymbolABC();
/*      */                     }
/*      */                   };
/* 1099 */               } else if ("$backspace".equals(str2)) {
/* 1100 */                 KeyCodeKey keyCodeKey = new KeyCodeKey("backspace", "\b", KeyCode.BACK_SPACE) {
/*      */                     protected void press() {
/* 1102 */                       if (FXVKSkin.KEY_REPEAT_RATE > 0.0D) {
/* 1103 */                         FXVKSkin.this.clearShift();
/* 1104 */                         sendKeyEvents();
/* 1105 */                         FXVKSkin.repeatKey = this;
/* 1106 */                         FXVKSkin.repeatInitialDelay.playFromStart();
/*      */                       } else {
/* 1108 */                         super.press();
/*      */                       } 
/*      */                     }
/*      */                     protected void release() {
/* 1112 */                       if (FXVKSkin.KEY_REPEAT_RATE > 0.0D) {
/* 1113 */                         FXVKSkin.repeatInitialDelay.stop();
/* 1114 */                         FXVKSkin.repeatSubsequentDelay.stop();
/*      */                       } else {
/* 1116 */                         super.release();
/*      */                       } 
/*      */                     }
/*      */                   };
/* 1120 */                 keyCodeKey.getStyleClass().add("backspace");
/* 1121 */               } else if ("$enter".equals(str2)) {
/* 1122 */                 KeyCodeKey keyCodeKey = new KeyCodeKey("enter", "\n", KeyCode.ENTER);
/* 1123 */                 keyCodeKey.getStyleClass().add("enter");
/* 1124 */               } else if ("$tab".equals(str2)) {
/* 1125 */                 KeyCodeKey keyCodeKey = new KeyCodeKey("tab", "\t", KeyCode.TAB);
/* 1126 */               } else if ("$space".equals(str2)) {
/* 1127 */                 charKey = new CharKey(" ", " ", null, "space");
/* 1128 */               } else if ("$clear".equals(str2)) {
/* 1129 */                 SuperKey superKey = new SuperKey("clear", "");
/* 1130 */               } else if ("$.org".equals(str2)) {
/* 1131 */                 SuperKey superKey = new SuperKey(".org", ".org");
/* 1132 */               } else if ("$.com".equals(str2)) {
/* 1133 */                 SuperKey superKey = new SuperKey(".com", ".com");
/* 1134 */               } else if ("$.net".equals(str2)) {
/* 1135 */                 SuperKey superKey = new SuperKey(".net", ".net");
/* 1136 */               } else if ("$oracle.com".equals(str2)) {
/* 1137 */                 SuperKey superKey = new SuperKey("oracle.com", "oracle.com");
/* 1138 */               } else if ("$gmail.com".equals(str2)) {
/* 1139 */                 SuperKey superKey = new SuperKey("gmail.com", "gmail.com");
/* 1140 */               } else if ("$hide".equals(str2)) {
/* 1141 */                 KeyboardStateKey keyboardStateKey = new KeyboardStateKey("hide", null, "hide") {
/*      */                     protected void release() {
/* 1143 */                       FXVKSkin.this.isVKHidden = true;
/* 1144 */                       FXVKSkin.startSlideOut(false);
/*      */                       
/* 1146 */                       if (FXVKSkin.vkAdjustWindow) {
/* 1147 */                         FXVKSkin.this.restoreWindowPosition(FXVKSkin.this.attachedNode);
/*      */                       }
/*      */                     }
/*      */                   };
/* 1151 */                 keyboardStateKey.getStyleClass().add("hide");
/* 1152 */               } else if ("$undo".equals(str2)) {
/* 1153 */                 SuperKey superKey = new SuperKey("undo", "");
/* 1154 */               } else if ("$redo".equals(str2)) {
/* 1155 */                 SuperKey superKey = new SuperKey("redo", "");
/*      */               } else {
/*      */                 
/* 1158 */                 charKey = null;
/*      */               } 
/*      */             } else {
/* 1161 */               charKey = new CharKey(str2, str3, arrayOfString);
/*      */             } 
/* 1163 */             if (charKey != null) {
/* 1164 */               charKey.col = b2;
/* 1165 */               charKey.colSpan = i;
/* 1166 */               for (String str4 : charKey.getStyleClass()) {
/* 1167 */                 charKey.text.getStyleClass().add(str4 + "-text");
/* 1168 */                 charKey.altText.getStyleClass().add(str4 + "-alttext");
/* 1169 */                 charKey.icon.getStyleClass().add(str4 + "-icon");
/*      */               } 
/* 1171 */               if (str2 != null && str2.length() > 1) {
/* 1172 */                 charKey.text.getStyleClass().add("multi-char-text");
/*      */               }
/* 1174 */               if (str3 != null && str3.length() > 1) {
/* 1175 */                 charKey.altText.getStyleClass().add("multi-char-text");
/*      */               }
/*      */               
/* 1178 */               arrayList.add(charKey);
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/* 1183 */             for (int k = j; k < str1.length(); k++) {
/* 1184 */               char c1 = str1.charAt(k);
/* 1185 */               boolean bool1 = false;
/* 1186 */               if (c1 == '\\') {
/* 1187 */                 k++;
/* 1188 */                 j++;
/* 1189 */                 bool1 = true;
/* 1190 */                 c1 = str1.charAt(k);
/*      */               } 
/*      */               
/* 1193 */               if (c1 == '$' && !bool1) {
/* 1194 */                 bool = true;
/*      */               }
/*      */               
/* 1197 */               if (c1 == '|' && !bool1) {
/* 1198 */                 arrayList1.add(str1.substring(j, k));
/* 1199 */                 j = k + 1;
/* 1200 */               } else if ((c1 == ']' || c1 == ' ') && !bool1) {
/* 1201 */                 arrayList1.add(str1.substring(j, k));
/* 1202 */                 j = k - 1;
/*      */                 break;
/*      */               } 
/*      */             } 
/* 1206 */             b1++;
/*      */           } 
/*      */         } 
/*      */         
/* 1210 */         b1 = 0;
/* 1211 */         b2 = 0;
/* 1212 */         list.add(arrayList);
/* 1213 */         arrayList = new ArrayList<>(20);
/*      */       } 
/* 1215 */       bufferedReader.close();
/* 1216 */       boardMap.put(paramString, list);
/* 1217 */       return list;
/* 1218 */     } catch (Exception exception) {
/* 1219 */       exception.printStackTrace();
/* 1220 */       return Collections.emptyList();
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\skin\FXVKSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */