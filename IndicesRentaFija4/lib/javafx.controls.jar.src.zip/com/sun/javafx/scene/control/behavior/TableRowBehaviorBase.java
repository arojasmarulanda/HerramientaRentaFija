/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.control.Cell;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TablePositionBase;
/*     */ import javafx.scene.control.TableSelectionModel;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TableRowBehaviorBase<T extends Cell>
/*     */   extends CellBehaviorBase<T>
/*     */ {
/*     */   public TableRowBehaviorBase(T paramT) {
/*  48 */     super(paramT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent paramMouseEvent) {
/*  61 */     if (!isClickPositionValid(paramMouseEvent.getX(), paramMouseEvent.getY()))
/*     */       return; 
/*  63 */     super.mousePressed(paramMouseEvent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doSelect(double paramDouble1, double paramDouble2, MouseButton paramMouseButton, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/*  82 */     Control control = getCellContainer();
/*  83 */     if (control == null) {
/*     */       return;
/*     */     }
/*     */     
/*  87 */     if (handleDisclosureNode(paramDouble1, paramDouble2)) {
/*     */       return;
/*     */     }
/*     */     
/*  91 */     TableSelectionModel<?> tableSelectionModel = getSelectionModel();
/*  92 */     if (tableSelectionModel == null || tableSelectionModel.isCellSelectionEnabled())
/*     */       return; 
/*  94 */     int i = getIndex();
/*  95 */     boolean bool = tableSelectionModel.isSelected(i);
/*  96 */     if (paramInt == 1) {
/*     */       
/*  98 */       if (!isClickPositionValid(paramDouble1, paramDouble2)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 103 */       if (bool && paramBoolean2) {
/* 104 */         tableSelectionModel.clearSelection(i);
/*     */       }
/* 106 */       else if (paramBoolean2) {
/* 107 */         tableSelectionModel.select(getIndex());
/* 108 */       } else if (paramBoolean1) {
/*     */ 
/*     */         
/* 111 */         TablePositionBase tablePositionBase = (TablePositionBase)getAnchor(control, (T)getFocusedCell());
/* 112 */         int j = tablePositionBase.getRow();
/* 113 */         selectRows(j, i);
/*     */       } else {
/* 115 */         simpleSelect(paramMouseButton, paramInt, paramBoolean2);
/*     */       } 
/*     */     } else {
/*     */       
/* 119 */       simpleSelect(paramMouseButton, paramInt, paramBoolean2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isClickPositionValid(double paramDouble1, double paramDouble2) {
/* 126 */     ObservableList<TableColumnBase> observableList = getVisibleLeafColumns();
/* 127 */     double d = 0.0D;
/* 128 */     for (byte b = 0; b < observableList.size(); b++) {
/* 129 */       d += ((TableColumnBase)observableList.get(b)).getWidth();
/*     */     }
/*     */     
/* 132 */     return (paramDouble1 > d);
/*     */   }
/*     */   
/*     */   protected abstract TableSelectionModel<?> getSelectionModel();
/*     */   
/*     */   protected abstract TablePositionBase<?> getFocusedCell();
/*     */   
/*     */   protected abstract ObservableList getVisibleLeafColumns();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TableRowBehaviorBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */