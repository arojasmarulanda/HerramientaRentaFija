/*     */ package com.sun.javafx.scene.control.behavior;
/*     */ 
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Cell;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.FocusModel;
/*     */ import javafx.scene.control.MultipleSelectionModel;
/*     */ import javafx.scene.control.TableColumnBase;
/*     */ import javafx.scene.control.TableFocusModel;
/*     */ import javafx.scene.control.TablePositionBase;
/*     */ import javafx.scene.control.TableSelectionModel;
/*     */ import javafx.scene.control.TreeItem;
/*     */ import javafx.scene.control.TreeTableCell;
/*     */ import javafx.scene.control.TreeTableColumn;
/*     */ import javafx.scene.control.TreeTableView;
/*     */ import javafx.scene.input.MouseButton;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeTableCellBehavior<S, T>
/*     */   extends TableCellBehaviorBase<TreeItem<S>, T, TreeTableColumn<S, ?>, TreeTableCell<S, T>>
/*     */ {
/*     */   public TreeTableCellBehavior(TreeTableCell<S, T> paramTreeTableCell) {
/*  48 */     super(paramTreeTableCell);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TreeTableView<S> getCellContainer() {
/*  61 */     return getNode().getTreeTableView();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TreeTableColumn<S, T> getTableColumn() {
/*  66 */     return getNode().getTableColumn();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getItemCount() {
/*  71 */     return getCellContainer().getExpandedItemCount();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TreeTableView.TreeTableViewSelectionModel<S> getSelectionModel() {
/*  76 */     return getCellContainer().getSelectionModel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TreeTableView.TreeTableViewFocusModel<S> getFocusModel() {
/*  81 */     return getCellContainer().getFocusModel();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TablePositionBase getFocusedCell() {
/*  86 */     return getCellContainer().getFocusModel().getFocusedCell();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isTableRowSelected() {
/*  91 */     return getNode().getTreeTableRow().isSelected();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getVisibleLeafIndex(TableColumnBase paramTableColumnBase) {
/*  96 */     return getCellContainer().getVisibleLeafIndex((TreeTableColumn<S, ?>)paramTableColumnBase);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void focus(int paramInt, TableColumnBase paramTableColumnBase) {
/* 101 */     getFocusModel().focus(paramInt, (TreeTableColumn<S, ?>)paramTableColumnBase);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void edit(TreeTableCell<S, T> paramTreeTableCell) {
/* 106 */     if (paramTreeTableCell == null) {
/* 107 */       getCellContainer().edit(-1, null);
/*     */     } else {
/* 109 */       getCellContainer().edit(paramTreeTableCell.getIndex(), paramTreeTableCell.getTableColumn());
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean handleDisclosureNode(double paramDouble1, double paramDouble2) {
/* 114 */     TreeItem treeItem = getNode().getTreeTableRow().getTreeItem();
/*     */     
/* 116 */     TreeTableView<S> treeTableView = getNode().getTreeTableView();
/* 117 */     TreeTableColumn<S, T> treeTableColumn = getTableColumn();
/*     */     
/* 119 */     TreeTableColumn<S, ?> treeTableColumn1 = (treeTableView.getTreeColumn() == null) ? treeTableView.getVisibleLeafColumn(0) : treeTableView.getTreeColumn();
/*     */     
/* 121 */     if (treeTableColumn == treeTableColumn1) {
/* 122 */       Node node = getNode().getTreeTableRow().getDisclosureNode();
/* 123 */       if (node != null) {
/* 124 */         double d1 = 0.0D;
/* 125 */         for (TreeTableColumn<S, ?> treeTableColumn2 : treeTableView.getVisibleLeafColumns()) {
/* 126 */           if (treeTableColumn2 == treeTableColumn1)
/* 127 */             break;  d1 += treeTableColumn2.getWidth();
/*     */         } 
/* 129 */         double d2 = node.getBoundsInParent().getMaxX();
/* 130 */         if (paramDouble1 < d2 - d1) {
/* 131 */           if (treeItem != null) {
/* 132 */             treeItem.setExpanded(!treeItem.isExpanded());
/*     */           }
/* 134 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleClicks(MouseButton paramMouseButton, int paramInt, boolean paramBoolean) {
/* 144 */     TreeItem treeItem = getNode().getTreeTableRow().getTreeItem();
/* 145 */     if (paramMouseButton == MouseButton.PRIMARY)
/* 146 */       if (paramInt == 1 && paramBoolean) {
/* 147 */         edit(getNode());
/* 148 */       } else if (paramInt == 1) {
/*     */         
/* 150 */         edit((TreeTableCell<S, T>)null);
/* 151 */       } else if (paramInt == 2 && treeItem.isLeaf()) {
/*     */         
/* 153 */         edit(getNode());
/* 154 */       } else if (paramInt % 2 == 0) {
/*     */         
/* 156 */         treeItem.setExpanded(!treeItem.isExpanded());
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TreeTableCellBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */