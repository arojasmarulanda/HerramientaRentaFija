/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*    */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.control.ToolBar;
/*    */ import javafx.scene.input.KeyCode;
/*    */ import javafx.scene.input.KeyEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ToolBarBehavior
/*    */   extends BehaviorBase<ToolBar>
/*    */ {
/*    */   private final InputMap<ToolBar> toolBarInputMap;
/*    */   
/*    */   public ToolBarBehavior(ToolBar paramToolBar) {
/* 42 */     super(paramToolBar);
/*    */ 
/*    */ 
/*    */     
/* 46 */     this.toolBarInputMap = createInputMap();
/*    */ 
/*    */     
/* 49 */     addDefaultMapping(this.toolBarInputMap, (InputMap.Mapping<?>[])new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.F5))
/* 50 */             .ctrl(), paramKeyEvent -> {
/*    */               if (!paramToolBar.getItems().isEmpty()) {
/*    */                 ((Node)paramToolBar.getItems().get(0)).requestFocus();
/*    */               }
/*    */             }) });
/*    */   }
/*    */ 
/*    */   
/*    */   public InputMap<ToolBar> getInputMap() {
/* 59 */     return this.toolBarInputMap;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\ToolBarBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */