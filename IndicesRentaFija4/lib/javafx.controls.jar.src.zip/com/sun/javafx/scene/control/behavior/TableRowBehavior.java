/*    */ package com.sun.javafx.scene.control.behavior;
/*    */ 
/*    */ import javafx.collections.ObservableList;
/*    */ import javafx.scene.control.Cell;
/*    */ import javafx.scene.control.Control;
/*    */ import javafx.scene.control.FocusModel;
/*    */ import javafx.scene.control.MultipleSelectionModel;
/*    */ import javafx.scene.control.TablePositionBase;
/*    */ import javafx.scene.control.TableRow;
/*    */ import javafx.scene.control.TableSelectionModel;
/*    */ import javafx.scene.control.TableView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableRowBehavior<T>
/*    */   extends TableRowBehaviorBase<TableRow<T>>
/*    */ {
/*    */   public TableRowBehavior(TableRow<T> paramTableRow) {
/* 44 */     super(paramTableRow);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected TableSelectionModel<T> getSelectionModel() {
/* 56 */     return getCellContainer().getSelectionModel();
/*    */   }
/*    */   
/*    */   protected TablePositionBase<?> getFocusedCell() {
/* 60 */     return getCellContainer().getFocusModel().getFocusedCell();
/*    */   }
/*    */   
/*    */   protected FocusModel<T> getFocusModel() {
/* 64 */     return getCellContainer().getFocusModel();
/*    */   }
/*    */   
/*    */   protected ObservableList getVisibleLeafColumns() {
/* 68 */     return getCellContainer().getVisibleLeafColumns();
/*    */   }
/*    */   
/*    */   protected TableView<T> getCellContainer() {
/* 72 */     return getNode().getTableView();
/*    */   }
/*    */   
/*    */   protected void edit(TableRow<T> paramTableRow) {}
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\scene\control\behavior\TableRowBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */