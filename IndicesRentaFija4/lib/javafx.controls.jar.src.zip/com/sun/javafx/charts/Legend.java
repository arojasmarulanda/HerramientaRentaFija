/*     */ package com.sun.javafx.charts;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.beans.property.StringPropertyBase;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.geometry.Pos;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.ContentDisplay;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.layout.Region;
/*     */ import javafx.scene.layout.TilePane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Legend
/*     */   extends TilePane
/*     */ {
/*     */   private static final int GAP = 5;
/*     */   private ListChangeListener<LegendItem> itemsListener;
/*     */   private BooleanProperty vertical;
/*     */   private ObjectProperty<ObservableList<LegendItem>> items;
/*     */   
/*     */   public final boolean isVertical() {
/*  83 */     return this.vertical.get();
/*  84 */   } public final void setVertical(boolean paramBoolean) { this.vertical.set(paramBoolean); } public final BooleanProperty verticalProperty() {
/*  85 */     return this.vertical;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setItems(ObservableList<LegendItem> paramObservableList) {
/* 115 */     itemsProperty().set(paramObservableList);
/* 116 */   } public final ObservableList<LegendItem> getItems() { return this.items.get(); } public final ObjectProperty<ObservableList<LegendItem>> itemsProperty() {
/* 117 */     return this.items;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Legend() {
/* 124 */     super(5.0D, 5.0D); this.itemsListener = (paramChange -> { List<? extends Node> list = (List)getItems().stream().map(()).collect(Collectors.toList()); getChildren().setAll(list); if (isVisible()) requestLayout();  }); this.vertical = new BooleanPropertyBase(false) { protected void invalidated() { Legend.this.setOrientation(get() ? Orientation.VERTICAL : Orientation.HORIZONTAL); } public Object getBean() { return Legend.this; } public String getName() { return "vertical"; } }
/* 125 */       ; this.items = new ObjectPropertyBase<ObservableList<LegendItem>>() { ObservableList<Legend.LegendItem> oldItems = null; protected void invalidated() { if (this.oldItems != null) this.oldItems.removeListener(Legend.this.itemsListener);  Legend.this.getChildren().clear(); ObservableList<Legend.LegendItem> observableList = get(); if (observableList != null) { observableList.addListener(Legend.this.itemsListener); List<? extends Node> list = (List)observableList.stream().map(param1LegendItem -> param1LegendItem.label).collect(Collectors.toList()); Legend.this.getChildren().addAll(list); }  this.oldItems = observableList; Legend.this.requestLayout(); } public Object getBean() { return Legend.this; } public String getName() { return "items"; } }; setTileAlignment(Pos.CENTER_LEFT);
/* 126 */     setItems(FXCollections.observableArrayList());
/* 127 */     getStyleClass().setAll(new String[] { "chart-legend" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefWidth(double paramDouble) {
/* 135 */     return (getItems().size() > 0) ? super.computePrefWidth(paramDouble) : 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected double computePrefHeight(double paramDouble) {
/* 141 */     return (getItems().size() > 0) ? super.computePrefHeight(paramDouble) : 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LegendItem
/*     */   {
/* 148 */     private Label label = new Label();
/*     */ 
/*     */     
/* 151 */     private StringProperty text = new StringPropertyBase() {
/*     */         protected void invalidated() {
/* 153 */           Legend.LegendItem.this.label.setText(get());
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 158 */           return Legend.LegendItem.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 163 */           return "text";
/*     */         }
/*     */       };
/* 166 */     public final String getText() { return this.text.getValue(); }
/* 167 */     public final void setText(String param1String) { this.text.setValue(param1String); } public final StringProperty textProperty() {
/* 168 */       return this.text;
/*     */     }
/*     */ 
/*     */     
/* 172 */     private ObjectProperty<Node> symbol = new ObjectPropertyBase<Node>(new Region()) {
/*     */         protected void invalidated() {
/* 174 */           Node node = get();
/* 175 */           if (node != null) node.getStyleClass().setAll(new String[] { "chart-legend-item-symbol" }); 
/* 176 */           Legend.LegendItem.this.label.setGraphic(node);
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 181 */           return Legend.LegendItem.this;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 186 */           return "symbol";
/*     */         }
/*     */       };
/* 189 */     public final Node getSymbol() { return this.symbol.getValue(); }
/* 190 */     public final void setSymbol(Node param1Node) { this.symbol.setValue(param1Node); } public final ObjectProperty<Node> symbolProperty() {
/* 191 */       return this.symbol;
/*     */     }
/*     */     public LegendItem(String param1String) {
/* 194 */       setText(param1String);
/* 195 */       this.label.getStyleClass().add("chart-legend-item");
/* 196 */       this.label.setAlignment(Pos.CENTER_LEFT);
/* 197 */       this.label.setContentDisplay(ContentDisplay.LEFT);
/* 198 */       this.label.setGraphic(getSymbol());
/* 199 */       getSymbol().getStyleClass().setAll(new String[] { "chart-legend-item-symbol" });
/*     */     }
/*     */     
/*     */     public LegendItem(String param1String, Node param1Node) {
/* 203 */       this(param1String);
/* 204 */       setSymbol(param1Node);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.controls.jar!\com\sun\javafx\charts\Legend.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */