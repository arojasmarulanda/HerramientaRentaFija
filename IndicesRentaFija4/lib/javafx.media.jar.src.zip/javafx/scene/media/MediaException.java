/*     */ package javafx.scene.media;
/*     */ 
/*     */ import com.sun.media.jfxmedia.MediaError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MediaException
/*     */   extends RuntimeException
/*     */ {
/*     */   private final Type type;
/*     */   
/*     */   public enum Type
/*     */   {
/*  50 */     MEDIA_CORRUPTED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     MEDIA_INACCESSIBLE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     MEDIA_UNAVAILABLE,
/*     */ 
/*     */ 
/*     */     
/*  66 */     MEDIA_UNSPECIFIED,
/*     */ 
/*     */ 
/*     */     
/*  70 */     MEDIA_UNSUPPORTED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     OPERATION_UNSUPPORTED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     PLAYBACK_ERROR,
/*     */ 
/*     */ 
/*     */     
/*  84 */     PLAYBACK_HALTED,
/*     */ 
/*     */ 
/*     */     
/*  88 */     UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Type errorCodeToType(int paramInt) {
/*     */     Type type;
/*  99 */     if (paramInt == MediaError.ERROR_LOCATOR_CONNECTION_LOST.code()) {
/* 100 */       type = Type.MEDIA_INACCESSIBLE;
/* 101 */     } else if (paramInt == MediaError.ERROR_GSTREAMER_SOURCEFILE_NONEXISTENT.code() || paramInt == MediaError.ERROR_GSTREAMER_SOURCEFILE_NONREGULAR
/* 102 */       .code()) {
/* 103 */       type = Type.MEDIA_UNAVAILABLE;
/* 104 */     } else if (paramInt == MediaError.ERROR_MEDIA_AUDIO_FORMAT_UNSUPPORTED.code() || paramInt == MediaError.ERROR_MEDIA_UNKNOWN_PIXEL_FORMAT
/* 105 */       .code() || paramInt == MediaError.ERROR_MEDIA_VIDEO_FORMAT_UNSUPPORTED
/* 106 */       .code() || paramInt == MediaError.ERROR_LOCATOR_CONTENT_TYPE_NULL
/* 107 */       .code() || paramInt == MediaError.ERROR_LOCATOR_UNSUPPORTED_MEDIA_FORMAT
/* 108 */       .code() || paramInt == MediaError.ERROR_LOCATOR_UNSUPPORTED_TYPE
/* 109 */       .code() || paramInt == MediaError.ERROR_GSTREAMER_UNSUPPORTED_PROTOCOL
/* 110 */       .code() || paramInt == MediaError.ERROR_MEDIA_MP3_FORMAT_UNSUPPORTED
/* 111 */       .code() || paramInt == MediaError.ERROR_MEDIA_AAC_FORMAT_UNSUPPORTED
/* 112 */       .code() || paramInt == MediaError.ERROR_MEDIA_H264_FORMAT_UNSUPPORTED
/* 113 */       .code() || paramInt == MediaError.ERROR_MEDIA_HLS_FORMAT_UNSUPPORTED
/* 114 */       .code()) {
/* 115 */       type = Type.MEDIA_UNSUPPORTED;
/* 116 */     } else if (paramInt == MediaError.ERROR_MEDIA_CORRUPTED.code()) {
/* 117 */       type = Type.MEDIA_CORRUPTED;
/* 118 */     } else if ((paramInt & MediaError.ERROR_BASE_GSTREAMER.code()) == MediaError.ERROR_BASE_GSTREAMER.code() || (paramInt & MediaError.ERROR_BASE_JNI
/* 119 */       .code()) == MediaError.ERROR_BASE_JNI.code()) {
/* 120 */       type = Type.PLAYBACK_ERROR;
/*     */     } else {
/* 122 */       type = Type.UNKNOWN;
/*     */     } 
/*     */     
/* 125 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MediaException exceptionToMediaException(Exception paramException) {
/* 132 */     Type type = Type.UNKNOWN;
/*     */     
/* 134 */     if (paramException.getCause() instanceof java.net.UnknownHostException) {
/* 135 */       type = Type.MEDIA_UNAVAILABLE;
/* 136 */     } else if (paramException.getCause() instanceof IllegalArgumentException) {
/* 137 */       type = Type.MEDIA_UNSUPPORTED;
/* 138 */     } else if (paramException instanceof com.sun.media.jfxmedia.MediaException) {
/* 139 */       com.sun.media.jfxmedia.MediaException mediaException = (com.sun.media.jfxmedia.MediaException)paramException;
/* 140 */       MediaError mediaError = mediaException.getMediaError();
/* 141 */       if (mediaError != null) {
/* 142 */         type = errorCodeToType(mediaError.code());
/*     */       }
/*     */     } 
/*     */     
/* 146 */     return new MediaException(type, paramException);
/*     */   }
/*     */   
/*     */   static MediaException haltException(String paramString) {
/* 150 */     return new MediaException(Type.PLAYBACK_HALTED, paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   static MediaException getMediaException(Object paramObject, int paramInt, String paramString) {
/* 155 */     String str1 = MediaError.getFromCode(paramInt).description();
/* 156 */     String str2 = "[" + paramObject + "] " + paramString + ": " + str1;
/*     */ 
/*     */     
/* 159 */     Type type = errorCodeToType(paramInt);
/* 160 */     return new MediaException(type, str2);
/*     */   }
/*     */   
/*     */   MediaException(Type paramType, Throwable paramThrowable) {
/* 164 */     super(paramThrowable);
/* 165 */     this.type = paramType;
/*     */   }
/*     */   
/*     */   MediaException(Type paramType, String paramString, Throwable paramThrowable) {
/* 169 */     super(paramString, paramThrowable);
/* 170 */     this.type = paramType;
/*     */   }
/*     */   
/*     */   MediaException(Type paramType, String paramString) {
/* 174 */     super(paramString);
/* 175 */     this.type = paramType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 186 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 195 */     String str = "MediaException: " + this.type;
/* 196 */     if (getMessage() != null) str = str + " : " + str; 
/* 197 */     if (getCause() != null) str = str + " : " + str; 
/* 198 */     return str;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\javafx\scene\media\MediaException.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */