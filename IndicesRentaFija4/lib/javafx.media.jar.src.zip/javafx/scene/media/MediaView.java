/*      */ package javafx.scene.media;
/*      */ 
/*      */ import com.sun.javafx.geom.BaseBounds;
/*      */ import com.sun.javafx.geom.transform.Affine3D;
/*      */ import com.sun.javafx.geom.transform.BaseTransform;
/*      */ import com.sun.javafx.scene.DirtyBits;
/*      */ import com.sun.javafx.scene.NodeHelper;
/*      */ import com.sun.javafx.scene.media.MediaViewHelper;
/*      */ import com.sun.javafx.sg.prism.MediaFrameTracker;
/*      */ import com.sun.javafx.sg.prism.NGNode;
/*      */ import com.sun.javafx.tk.Toolkit;
/*      */ import com.sun.media.jfxmedia.MediaPlayer;
/*      */ import com.sun.media.jfxmedia.control.MediaPlayerOverlay;
/*      */ import com.sun.media.jfxmedia.events.VideoFrameRateListener;
/*      */ import com.sun.media.jfxmediaimpl.HostUtils;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.BooleanPropertyBase;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.DoublePropertyBase;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.value.ChangeListener;
/*      */ import javafx.beans.value.ObservableObjectValue;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.ObservableMap;
/*      */ import javafx.event.Event;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.EventType;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.geometry.Rectangle2D;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Parent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MediaView
/*      */   extends Node
/*      */ {
/*      */   private static final String VIDEO_FRAME_RATE_PROPERTY_NAME = "jfxmedia.decodedVideoFPS";
/*      */   private static final String DEFAULT_STYLE_CLASS = "media-view";
/*      */   
/*      */   static {
/*   95 */     MediaViewHelper.setMediaViewAccessor(new MediaViewHelper.MediaViewAccessor()
/*      */         {
/*      */           public NGNode doCreatePeer(Node param1Node) {
/*   98 */             return ((MediaView)param1Node).doCreatePeer();
/*      */           }
/*      */ 
/*      */           
/*      */           public void doUpdatePeer(Node param1Node) {
/*  103 */             ((MediaView)param1Node).doUpdatePeer();
/*      */           }
/*      */ 
/*      */           
/*      */           public void doTransformsChanged(Node param1Node) {
/*  108 */             ((MediaView)param1Node).doTransformsChanged();
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform) {
/*  114 */             return ((MediaView)param1Node).doComputeGeomBounds(param1BaseBounds, param1BaseTransform);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2) {
/*  119 */             return ((MediaView)param1Node).doComputeContains(param1Double1, param1Double2);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class MediaErrorInvalidationListener
/*      */     implements InvalidationListener
/*      */   {
/*      */     private MediaErrorInvalidationListener() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void invalidated(Observable param1Observable) {
/*  140 */       ObservableObjectValue<MediaException> observableObjectValue = (ObservableObjectValue)param1Observable;
/*  141 */       MediaView.this.fireEvent(new MediaErrorEvent(MediaView.this.getMediaPlayer(), MediaView.this.getMediaView(), observableObjectValue.get()));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*  146 */   private InvalidationListener errorListener = new MediaErrorInvalidationListener();
/*      */ 
/*      */   
/*      */   private InvalidationListener mediaDimensionListener = paramObservable -> {
/*      */       NodeHelper.markDirty(this, DirtyBits.NODE_VIEWPORT);
/*      */       NodeHelper.geomChanged(this);
/*      */     };
/*      */ 
/*      */   
/*      */   private VideoFrameRateListener decodedFrameRateListener;
/*      */ 
/*      */   
/*      */   private boolean registerVideoFrameRateListener = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private VideoFrameRateListener createVideoFrameRateListener() {
/*  163 */     String str = null;
/*      */     try {
/*  165 */       str = System.getProperty("jfxmedia.decodedVideoFPS");
/*  166 */     } catch (Throwable throwable) {}
/*      */ 
/*      */     
/*  169 */     if (str == null || !Boolean.getBoolean("jfxmedia.decodedVideoFPS")) {
/*  170 */       return null;
/*      */     }
/*  172 */     return paramDouble -> Platform.runLater(());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  183 */   private MediaPlayerOverlay mediaPlayerOverlay = null; private ChangeListener<Parent> parentListener; private ChangeListener<Boolean> treeVisibleListener; private ChangeListener<Number> opacityListener;
/*      */   private ObjectProperty<MediaPlayer> mediaPlayer;
/*      */   private ObjectProperty<EventHandler<MediaErrorEvent>> onError;
/*      */   private BooleanProperty preserveRatio;
/*      */   private BooleanProperty smooth;
/*      */   
/*      */   private void createListeners() {
/*  190 */     this.parentListener = ((paramObservableValue, paramParent1, paramParent2) -> updateOverlayVisibility());
/*      */ 
/*      */ 
/*      */     
/*  194 */     this.treeVisibleListener = ((paramObservableValue, paramBoolean1, paramBoolean2) -> updateOverlayVisibility());
/*      */ 
/*      */ 
/*      */     
/*  198 */     this.opacityListener = ((paramObservableValue, paramNumber1, paramNumber2) -> updateOverlayOpacity());
/*      */   }
/*      */   private DoubleProperty x; private DoubleProperty y;
/*      */   private DoubleProperty fitWidth;
/*      */   
/*      */   private boolean determineVisibility() {
/*  204 */     return (getParent() != null && isVisible());
/*      */   }
/*      */   private DoubleProperty fitHeight; private ObjectProperty<Rectangle2D> viewport; private int decodedFrameCount; private int renderedFrameCount;
/*      */   private synchronized void updateOverlayVisibility() {
/*  208 */     if (this.mediaPlayerOverlay != null) {
/*  209 */       this.mediaPlayerOverlay.setOverlayVisible(determineVisibility());
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void updateOverlayOpacity() {
/*  214 */     if (this.mediaPlayerOverlay != null) {
/*  215 */       this.mediaPlayerOverlay.setOverlayOpacity(getOpacity());
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void updateOverlayX() {
/*  220 */     if (this.mediaPlayerOverlay != null) {
/*  221 */       this.mediaPlayerOverlay.setOverlayX(getX());
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void updateOverlayY() {
/*  226 */     if (this.mediaPlayerOverlay != null) {
/*  227 */       this.mediaPlayerOverlay.setOverlayY(getY());
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void updateOverlayWidth() {
/*  232 */     if (this.mediaPlayerOverlay != null) {
/*  233 */       this.mediaPlayerOverlay.setOverlayWidth(getFitWidth());
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void updateOverlayHeight() {
/*  238 */     if (this.mediaPlayerOverlay != null) {
/*  239 */       this.mediaPlayerOverlay.setOverlayHeight(getFitHeight());
/*      */     }
/*      */   }
/*      */   
/*      */   private synchronized void updateOverlayPreserveRatio() {
/*  244 */     if (this.mediaPlayerOverlay != null) {
/*  245 */       this.mediaPlayerOverlay.setOverlayPreserveRatio(isPreserveRatio());
/*      */     }
/*      */   }
/*      */   
/*      */   private static Affine3D calculateNodeToSceneTransform(Node paramNode) {
/*  250 */     Affine3D affine3D = new Affine3D();
/*      */     do {
/*  252 */       affine3D.preConcatenate(NodeHelper.getLeafTransform(paramNode));
/*  253 */       paramNode = paramNode.getParent();
/*  254 */     } while (paramNode != null);
/*      */     
/*  256 */     return affine3D;
/*      */   }
/*      */   
/*      */   private void updateOverlayTransform() {
/*  260 */     if (this.mediaPlayerOverlay != null) {
/*  261 */       Affine3D affine3D = calculateNodeToSceneTransform(this);
/*  262 */       this.mediaPlayerOverlay.setOverlayTransform(affine3D
/*  263 */           .getMxx(), affine3D.getMxy(), affine3D.getMxz(), affine3D.getMxt(), affine3D
/*  264 */           .getMyx(), affine3D.getMyy(), affine3D.getMyz(), affine3D.getMyt(), affine3D
/*  265 */           .getMzx(), affine3D.getMzy(), affine3D.getMzz(), affine3D.getMzt());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void updateMediaPlayerOverlay() {
/*  270 */     this.mediaPlayerOverlay.setOverlayX(getX());
/*  271 */     this.mediaPlayerOverlay.setOverlayY(getY());
/*  272 */     this.mediaPlayerOverlay.setOverlayPreserveRatio(isPreserveRatio());
/*  273 */     this.mediaPlayerOverlay.setOverlayWidth(getFitWidth());
/*  274 */     this.mediaPlayerOverlay.setOverlayHeight(getFitHeight());
/*  275 */     this.mediaPlayerOverlay.setOverlayOpacity(getOpacity());
/*  276 */     this.mediaPlayerOverlay.setOverlayVisible(determineVisibility());
/*  277 */     updateOverlayTransform();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doTransformsChanged() {
/*  285 */     if (this.mediaPlayerOverlay != null) {
/*  286 */       updateOverlayTransform();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MediaView getMediaView() {
/*  296 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MediaView() {
/*  301 */     MediaViewHelper.initHelper(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  309 */     getStyleClass().add("media-view");
/*  310 */     setSmooth(Toolkit.getToolkit().getDefaultImageSmooth());
/*  311 */     this.decodedFrameRateListener = createVideoFrameRateListener();
/*  312 */     setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MediaView(MediaPlayer paramMediaPlayer) {
/*  328 */     this();
/*  329 */     setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
/*  330 */     setMediaPlayer(paramMediaPlayer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setMediaPlayer(MediaPlayer paramMediaPlayer) {
/*  349 */     mediaPlayerProperty().set(paramMediaPlayer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MediaPlayer getMediaPlayer() {
/*  358 */     return (this.mediaPlayer == null) ? null : this.mediaPlayer.get();
/*      */   }
/*      */   
/*      */   public final ObjectProperty<MediaPlayer> mediaPlayerProperty() {
/*  362 */     if (this.mediaPlayer == null) {
/*  363 */       this.mediaPlayer = new ObjectPropertyBase<MediaPlayer>() {
/*  364 */           MediaPlayer oldValue = null;
/*      */           protected void invalidated() {
/*  366 */             if (this.oldValue != null) {
/*  367 */               Media media = this.oldValue.getMedia();
/*  368 */               if (media != null) {
/*  369 */                 media.widthProperty().removeListener(MediaView.this.mediaDimensionListener);
/*  370 */                 media.heightProperty().removeListener(MediaView.this.mediaDimensionListener);
/*      */               } 
/*  372 */               if (MediaView.this.decodedFrameRateListener != null && MediaView.this.getMediaPlayer().retrieveJfxPlayer() != null) {
/*  373 */                 MediaView.this.getMediaPlayer().retrieveJfxPlayer().getVideoRenderControl().removeVideoFrameRateListener(MediaView.this.decodedFrameRateListener);
/*      */               }
/*  375 */               this.oldValue.errorProperty().removeListener(MediaView.this.errorListener);
/*  376 */               this.oldValue.removeView(MediaView.this.getMediaView());
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  383 */             MediaPlayer mediaPlayer = get();
/*  384 */             if (mediaPlayer != null) {
/*  385 */               mediaPlayer.addView(MediaView.this.getMediaView());
/*  386 */               mediaPlayer.errorProperty().addListener(MediaView.this.errorListener);
/*  387 */               if (MediaView.this.decodedFrameRateListener != null && MediaView.this.getMediaPlayer().retrieveJfxPlayer() != null) {
/*  388 */                 MediaView.this.getMediaPlayer().retrieveJfxPlayer().getVideoRenderControl().addVideoFrameRateListener(MediaView.this.decodedFrameRateListener);
/*  389 */               } else if (MediaView.this.decodedFrameRateListener != null) {
/*  390 */                 MediaView.this.registerVideoFrameRateListener = true;
/*      */               } 
/*  392 */               Media media = mediaPlayer.getMedia();
/*  393 */               if (media != null) {
/*  394 */                 media.widthProperty().addListener(MediaView.this.mediaDimensionListener);
/*  395 */                 media.heightProperty().addListener(MediaView.this.mediaDimensionListener);
/*      */               } 
/*      */             } 
/*  398 */             NodeHelper.markDirty(MediaView.this, DirtyBits.MEDIAVIEW_MEDIA);
/*  399 */             NodeHelper.geomChanged(MediaView.this);
/*  400 */             this.oldValue = mediaPlayer;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  404 */             return MediaView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  409 */             return "mediaPlayer";
/*      */           }
/*      */         };
/*      */     }
/*  413 */     return this.mediaPlayer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnError(EventHandler<MediaErrorEvent> paramEventHandler) {
/*  428 */     onErrorProperty().set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EventHandler<MediaErrorEvent> getOnError() {
/*  436 */     return (this.onError == null) ? null : this.onError.get();
/*      */   }
/*      */   
/*      */   public final ObjectProperty<EventHandler<MediaErrorEvent>> onErrorProperty() {
/*  440 */     if (this.onError == null) {
/*  441 */       this.onError = new ObjectPropertyBase<EventHandler<MediaErrorEvent>>()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  445 */             MediaView.this.setEventHandler((EventType)MediaErrorEvent.MEDIA_ERROR, (EventHandler)get());
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  450 */             return MediaView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  455 */             return "onError";
/*      */           }
/*      */         };
/*      */     }
/*  459 */     return this.onError;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setPreserveRatio(boolean paramBoolean) {
/*  474 */     preserveRatioProperty().set(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isPreserveRatio() {
/*  482 */     return (this.preserveRatio == null) ? true : this.preserveRatio.get();
/*      */   }
/*      */   
/*      */   public final BooleanProperty preserveRatioProperty() {
/*  486 */     if (this.preserveRatio == null) {
/*  487 */       this.preserveRatio = new BooleanPropertyBase(true)
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  491 */             if (HostUtils.isIOS()) {
/*  492 */               MediaView.this.updateOverlayPreserveRatio();
/*      */             } else {
/*      */               
/*  495 */               NodeHelper.markDirty(MediaView.this, DirtyBits.NODE_VIEWPORT);
/*  496 */               NodeHelper.geomChanged(MediaView.this);
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  502 */             return MediaView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  507 */             return "preserveRatio";
/*      */           }
/*      */         };
/*      */     }
/*  511 */     return this.preserveRatio;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setSmooth(boolean paramBoolean) {
/*  531 */     smoothProperty().set(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isSmooth() {
/*  539 */     return (this.smooth == null) ? false : this.smooth.get();
/*      */   }
/*      */   
/*      */   public final BooleanProperty smoothProperty() {
/*  543 */     if (this.smooth == null) {
/*  544 */       this.smooth = new BooleanPropertyBase()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  548 */             NodeHelper.markDirty(MediaView.this, DirtyBits.NODE_SMOOTH);
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  553 */             return MediaView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  558 */             return "smooth";
/*      */           }
/*      */         };
/*      */     }
/*  562 */     return this.smooth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setX(double paramDouble) {
/*  575 */     xProperty().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getX() {
/*  583 */     return (this.x == null) ? 0.0D : this.x.get();
/*      */   }
/*      */   
/*      */   public final DoubleProperty xProperty() {
/*  587 */     if (this.x == null) {
/*  588 */       this.x = new DoublePropertyBase()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  592 */             if (HostUtils.isIOS()) {
/*  593 */               MediaView.this.updateOverlayX();
/*      */             } else {
/*      */               
/*  596 */               NodeHelper.markDirty(MediaView.this, DirtyBits.NODE_GEOMETRY);
/*  597 */               NodeHelper.geomChanged(MediaView.this);
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  603 */             return MediaView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  608 */             return "x";
/*      */           }
/*      */         };
/*      */     }
/*  612 */     return this.x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setY(double paramDouble) {
/*  625 */     yProperty().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getY() {
/*  633 */     return (this.y == null) ? 0.0D : this.y.get();
/*      */   }
/*      */   
/*      */   public final DoubleProperty yProperty() {
/*  637 */     if (this.y == null) {
/*  638 */       this.y = new DoublePropertyBase()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  642 */             if (HostUtils.isIOS()) {
/*  643 */               MediaView.this.updateOverlayY();
/*      */             } else {
/*      */               
/*  646 */               NodeHelper.markDirty(MediaView.this, DirtyBits.NODE_GEOMETRY);
/*  647 */               NodeHelper.geomChanged(MediaView.this);
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  653 */             return MediaView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  658 */             return "y";
/*      */           }
/*      */         };
/*      */     }
/*  662 */     return this.y;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFitWidth(double paramDouble) {
/*  684 */     fitWidthProperty().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getFitWidth() {
/*  692 */     return (this.fitWidth == null) ? 0.0D : this.fitWidth.get();
/*      */   }
/*      */   
/*      */   public final DoubleProperty fitWidthProperty() {
/*  696 */     if (this.fitWidth == null) {
/*  697 */       this.fitWidth = new DoublePropertyBase()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  701 */             if (HostUtils.isIOS()) {
/*  702 */               MediaView.this.updateOverlayWidth();
/*      */             } else {
/*      */               
/*  705 */               NodeHelper.markDirty(MediaView.this, DirtyBits.NODE_VIEWPORT);
/*  706 */               NodeHelper.geomChanged(MediaView.this);
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  712 */             return MediaView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  717 */             return "fitWidth";
/*      */           }
/*      */         };
/*      */     }
/*  721 */     return this.fitWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFitHeight(double paramDouble) {
/*  743 */     fitHeightProperty().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getFitHeight() {
/*  751 */     return (this.fitHeight == null) ? 0.0D : this.fitHeight.get();
/*      */   }
/*      */   
/*      */   public final DoubleProperty fitHeightProperty() {
/*  755 */     if (this.fitHeight == null) {
/*  756 */       this.fitHeight = new DoublePropertyBase()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  760 */             if (HostUtils.isIOS()) {
/*  761 */               MediaView.this.updateOverlayHeight();
/*      */             } else {
/*      */               
/*  764 */               NodeHelper.markDirty(MediaView.this, DirtyBits.NODE_VIEWPORT);
/*  765 */               NodeHelper.geomChanged(MediaView.this);
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  771 */             return MediaView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  776 */             return "fitHeight";
/*      */           }
/*      */         };
/*      */     }
/*  780 */     return this.fitHeight;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setViewport(Rectangle2D paramRectangle2D) {
/*  799 */     viewportProperty().set(paramRectangle2D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Rectangle2D getViewport() {
/*  807 */     return (this.viewport == null) ? null : this.viewport.get();
/*      */   }
/*      */   
/*      */   public final ObjectProperty<Rectangle2D> viewportProperty() {
/*  811 */     if (this.viewport == null) {
/*  812 */       this.viewport = new ObjectPropertyBase<Rectangle2D>()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  816 */             NodeHelper.markDirty(MediaView.this, DirtyBits.NODE_VIEWPORT);
/*  817 */             NodeHelper.geomChanged(MediaView.this);
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  822 */             return MediaView.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  827 */             return "viewport";
/*      */           }
/*      */         };
/*      */     }
/*  831 */     return this.viewport;
/*      */   }
/*      */   
/*      */   void notifyMediaChange() {
/*  835 */     MediaPlayer mediaPlayer = getMediaPlayer();
/*  836 */     if (mediaPlayer != null) {
/*  837 */       NGMediaView nGMediaView = (NGMediaView)NodeHelper.getPeer(this);
/*  838 */       nGMediaView.setMediaProvider(mediaPlayer);
/*      */     } 
/*      */     
/*  841 */     NodeHelper.markDirty(this, DirtyBits.MEDIAVIEW_MEDIA);
/*  842 */     NodeHelper.geomChanged(this);
/*      */   }
/*      */   
/*      */   void notifyMediaSizeChange() {
/*  846 */     NodeHelper.markDirty(this, DirtyBits.NODE_VIEWPORT);
/*  847 */     NodeHelper.geomChanged(this);
/*      */   }
/*      */   
/*      */   void notifyMediaFrameUpdated() {
/*  851 */     this.decodedFrameCount++;
/*  852 */     NodeHelper.markDirty(this, DirtyBits.NODE_CONTENTS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private NGNode doCreatePeer() {
/*  859 */     NGMediaView nGMediaView = new NGMediaView();
/*      */     
/*  861 */     nGMediaView.setFrameTracker(new MediaViewFrameTracker());
/*  862 */     return nGMediaView;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BaseBounds doComputeGeomBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  871 */     Media media = (getMediaPlayer() == null) ? null : getMediaPlayer().getMedia();
/*  872 */     double d1 = (media != null) ? media.getWidth() : 0.0D;
/*  873 */     double d2 = (media != null) ? media.getHeight() : 0.0D;
/*  874 */     double d3 = getFitWidth();
/*  875 */     double d4 = getFitHeight();
/*  876 */     double d5 = (getViewport() != null) ? getViewport().getWidth() : 0.0D;
/*  877 */     double d6 = (getViewport() != null) ? getViewport().getHeight() : 0.0D;
/*      */     
/*  879 */     if (d5 > 0.0D && d6 > 0.0D) {
/*  880 */       d1 = d5;
/*  881 */       d2 = d6;
/*      */     } 
/*      */     
/*  884 */     if (getFitWidth() <= 0.0D && getFitHeight() <= 0.0D) {
/*  885 */       d3 = d1;
/*  886 */       d4 = d2;
/*  887 */     } else if (isPreserveRatio()) {
/*  888 */       if (getFitWidth() <= 0.0D) {
/*  889 */         d3 = (d2 > 0.0D) ? (d1 * getFitHeight() / d2) : 0.0D;
/*  890 */         d4 = getFitHeight();
/*  891 */       } else if (getFitHeight() <= 0.0D) {
/*  892 */         d3 = getFitWidth();
/*  893 */         d4 = (d1 > 0.0D) ? (d2 * getFitWidth() / d1) : 0.0D;
/*      */       } else {
/*  895 */         if (d1 == 0.0D) d1 = getFitWidth(); 
/*  896 */         if (d2 == 0.0D) d2 = getFitHeight(); 
/*  897 */         double d = Math.min(getFitWidth() / d1, getFitHeight() / d2);
/*  898 */         d3 = d1 * d;
/*  899 */         d4 = d2 * d;
/*      */       } 
/*  901 */     } else if (getFitHeight() <= 0.0D) {
/*  902 */       d4 = d2;
/*  903 */     } else if (getFitWidth() <= 0.0D) {
/*  904 */       d3 = d1;
/*      */     } 
/*  906 */     if (d4 < 1.0D) {
/*  907 */       d4 = 1.0D;
/*      */     }
/*  909 */     if (d3 < 1.0D) {
/*  910 */       d3 = 1.0D;
/*      */     }
/*      */     
/*  913 */     d1 = d3;
/*  914 */     d2 = d4;
/*      */ 
/*      */ 
/*      */     
/*  918 */     if (d1 <= 0.0D || d2 <= 0.0D) {
/*  919 */       return paramBaseBounds.makeEmpty();
/*      */     }
/*  921 */     paramBaseBounds = paramBaseBounds.deriveWithNewBounds((float)getX(), (float)getY(), 0.0F, 
/*  922 */         (float)(getX() + d1), (float)(getY() + d2), 0.0F);
/*  923 */     paramBaseBounds = paramBaseTransform.transform(paramBaseBounds, paramBaseBounds);
/*  924 */     return paramBaseBounds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doComputeContains(double paramDouble1, double paramDouble2) {
/*  933 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   void updateViewport() {
/*  938 */     if (getMediaPlayer() == null) {
/*      */       return;
/*      */     }
/*      */     
/*  942 */     NGMediaView nGMediaView = (NGMediaView)NodeHelper.getPeer(this);
/*  943 */     if (getViewport() != null) {
/*  944 */       nGMediaView.setViewport((float)getFitWidth(), (float)getFitHeight(), 
/*  945 */           (float)getViewport().getMinX(), (float)getViewport().getMinY(), 
/*  946 */           (float)getViewport().getWidth(), (float)getViewport().getHeight(), 
/*  947 */           isPreserveRatio());
/*      */     } else {
/*  949 */       nGMediaView.setViewport((float)getFitWidth(), (float)getFitHeight(), 0.0F, 0.0F, 0.0F, 0.0F, 
/*      */           
/*  951 */           isPreserveRatio());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doUpdatePeer() {
/*  960 */     NGMediaView nGMediaView = (NGMediaView)NodeHelper.getPeer(this);
/*  961 */     if (NodeHelper.isDirty(this, DirtyBits.NODE_GEOMETRY)) {
/*  962 */       nGMediaView.setX((float)getX());
/*  963 */       nGMediaView.setY((float)getY());
/*      */     } 
/*  965 */     if (NodeHelper.isDirty(this, DirtyBits.NODE_SMOOTH)) {
/*  966 */       nGMediaView.setSmooth(isSmooth());
/*      */     }
/*  968 */     if (NodeHelper.isDirty(this, DirtyBits.NODE_VIEWPORT)) {
/*  969 */       updateViewport();
/*      */     }
/*  971 */     if (NodeHelper.isDirty(this, DirtyBits.NODE_CONTENTS)) {
/*  972 */       nGMediaView.renderNextFrame();
/*      */     }
/*  974 */     if (NodeHelper.isDirty(this, DirtyBits.MEDIAVIEW_MEDIA)) {
/*  975 */       MediaPlayer mediaPlayer = getMediaPlayer();
/*  976 */       if (mediaPlayer != null) {
/*  977 */         nGMediaView.setMediaProvider(mediaPlayer);
/*  978 */         updateViewport();
/*      */       } else {
/*  980 */         nGMediaView.setMediaProvider(null);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void perfReset() {
/*  990 */     this.decodedFrameCount = 0;
/*  991 */     this.renderedFrameCount = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int perfGetDecodedFrameCount() {
/*  998 */     return this.decodedFrameCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int perfGetRenderedFrameCount() {
/* 1005 */     return this.renderedFrameCount;
/*      */   }
/*      */   
/*      */   private class MediaViewFrameTracker implements MediaFrameTracker { private MediaViewFrameTracker() {}
/*      */     
/*      */     public void incrementDecodedFrameCount(int param1Int) {
/* 1011 */       MediaView.this.decodedFrameCount += param1Int;
/*      */     }
/*      */ 
/*      */     
/*      */     public void incrementRenderedFrameCount(int param1Int) {
/* 1016 */       MediaView.this.renderedFrameCount += param1Int;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void _mediaPlayerOnReady() {
/* 1024 */     MediaPlayer mediaPlayer = getMediaPlayer().retrieveJfxPlayer();
/* 1025 */     if (mediaPlayer != null) {
/* 1026 */       if (this.decodedFrameRateListener != null && this.registerVideoFrameRateListener) {
/* 1027 */         mediaPlayer.getVideoRenderControl().addVideoFrameRateListener(this.decodedFrameRateListener);
/* 1028 */         this.registerVideoFrameRateListener = false;
/*      */       } 
/*      */ 
/*      */       
/* 1032 */       this.mediaPlayerOverlay = mediaPlayer.getMediaPlayerOverlay();
/* 1033 */       if (this.mediaPlayerOverlay != null) {
/*      */         
/* 1035 */         createListeners();
/* 1036 */         parentProperty().addListener(this.parentListener);
/* 1037 */         NodeHelper.treeVisibleProperty(this).addListener(this.treeVisibleListener);
/* 1038 */         opacityProperty().addListener(this.opacityListener);
/*      */         
/* 1040 */         synchronized (this) {
/* 1041 */           updateMediaPlayerOverlay();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\javafx\scene\media\MediaView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */