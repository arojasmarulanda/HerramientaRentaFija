/*      */ package javafx.scene.media;
/*      */ 
/*      */ import com.sun.javafx.tk.TKPulseListener;
/*      */ import com.sun.javafx.tk.Toolkit;
/*      */ import com.sun.media.jfxmedia.Media;
/*      */ import com.sun.media.jfxmedia.MediaException;
/*      */ import com.sun.media.jfxmedia.MediaManager;
/*      */ import com.sun.media.jfxmedia.control.VideoDataBuffer;
/*      */ import com.sun.media.jfxmedia.events.AudioSpectrumEvent;
/*      */ import com.sun.media.jfxmedia.events.AudioSpectrumListener;
/*      */ import com.sun.media.jfxmedia.events.BufferListener;
/*      */ import com.sun.media.jfxmedia.events.BufferProgressEvent;
/*      */ import com.sun.media.jfxmedia.events.MarkerEvent;
/*      */ import com.sun.media.jfxmedia.events.MarkerListener;
/*      */ import com.sun.media.jfxmedia.events.MediaErrorListener;
/*      */ import com.sun.media.jfxmedia.events.NewFrameEvent;
/*      */ import com.sun.media.jfxmedia.events.PlayerStateEvent;
/*      */ import com.sun.media.jfxmedia.events.PlayerStateListener;
/*      */ import com.sun.media.jfxmedia.events.PlayerTimeListener;
/*      */ import com.sun.media.jfxmedia.events.VideoRendererListener;
/*      */ import com.sun.media.jfxmedia.events.VideoTrackSizeListener;
/*      */ import com.sun.media.jfxmedia.locator.Locator;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.NamedArg;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.BooleanPropertyBase;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.DoublePropertyBase;
/*      */ import javafx.beans.property.IntegerProperty;
/*      */ import javafx.beans.property.IntegerPropertyBase;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ObjectPropertyBase;
/*      */ import javafx.beans.property.ReadOnlyDoubleProperty;
/*      */ import javafx.beans.property.ReadOnlyDoubleWrapper;
/*      */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*      */ import javafx.beans.property.ReadOnlyIntegerWrapper;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.collections.MapChangeListener;
/*      */ import javafx.collections.ObservableMap;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.util.Duration;
/*      */ import javafx.util.Pair;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class MediaPlayer
/*      */ {
/*      */   public static final int INDEFINITE = -1;
/*      */   private static final double RATE_MIN = 0.0D;
/*      */   private static final double RATE_MAX = 8.0D;
/*      */   private static final int AUDIOSPECTRUM_THRESHOLD_MAX = 0;
/*      */   private static final double AUDIOSPECTRUM_INTERVAL_MIN = 1.0E-9D;
/*      */   private static final int AUDIOSPECTRUM_NUMBANDS_MIN = 2;
/*      */   private com.sun.media.jfxmedia.MediaPlayer jfxPlayer;
/*      */   
/*      */   public enum Status
/*      */   {
/*  224 */     UNKNOWN,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  229 */     READY,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  234 */     PAUSED,
/*      */ 
/*      */ 
/*      */     
/*  238 */     PLAYING,
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  243 */     STOPPED,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  252 */     STALLED,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  258 */     HALTED,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  265 */     DISPOSED;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   com.sun.media.jfxmedia.MediaPlayer retrieveJfxPlayer() {
/*  288 */     synchronized (this.disposeLock) {
/*  289 */       return this.jfxPlayer;
/*      */     } 
/*      */   }
/*      */   
/*  293 */   private MapChangeListener<String, Duration> markerMapListener = null;
/*  294 */   private MarkerListener markerEventListener = null;
/*      */   
/*  296 */   private PlayerStateListener stateListener = null;
/*  297 */   private PlayerTimeListener timeListener = null;
/*  298 */   private VideoTrackSizeListener sizeListener = null;
/*  299 */   private MediaErrorListener errorListener = null;
/*  300 */   private BufferListener bufferListener = null;
/*  301 */   private AudioSpectrumListener spectrumListener = null;
/*  302 */   private RendererListener rendererListener = null;
/*      */   
/*      */   private boolean rateChangeRequested = false;
/*      */   
/*      */   private boolean volumeChangeRequested = false;
/*      */   
/*      */   private boolean balanceChangeRequested = false;
/*      */   private boolean startTimeChangeRequested = false;
/*      */   private boolean stopTimeChangeRequested = false;
/*      */   private boolean muteChangeRequested = false;
/*      */   private boolean playRequested = false;
/*      */   private boolean audioSpectrumNumBandsChangeRequested = false;
/*      */   private boolean audioSpectrumIntervalChangeRequested = false;
/*      */   private boolean audioSpectrumThresholdChangeRequested = false;
/*      */   private boolean audioSpectrumEnabledChangeRequested = false;
/*  317 */   private MediaTimerTask mediaTimerTask = null;
/*  318 */   private double prevTimeMs = -1.0D;
/*      */   private boolean isUpdateTimeEnabled = false;
/*  320 */   private BufferProgressEvent lastBufferEvent = null;
/*  321 */   private Duration startTimeAtStop = null;
/*      */   
/*      */   private boolean isEOS = false;
/*  324 */   private final Object disposeLock = new Object();
/*      */   
/*      */   private static final int DEFAULT_SPECTRUM_BAND_COUNT = 128;
/*      */   
/*      */   private static final double DEFAULT_SPECTRUM_INTERVAL = 0.1D;
/*      */   
/*      */   private static final int DEFAULT_SPECTRUM_THRESHOLD = -60;
/*  331 */   private final Set<WeakReference<MediaView>> viewRefs = new HashSet<>(); private AudioEqualizer audioEqualizer; private ReadOnlyObjectWrapper<MediaException> error; private ObjectProperty<Runnable> onError; private Media media; private BooleanProperty autoPlay; private boolean playerReady; private DoubleProperty rate; private ReadOnlyDoubleWrapper currentRate; private DoubleProperty volume; private DoubleProperty balance; private ObjectProperty<Duration> startTime;
/*      */   private ObjectProperty<Duration> stopTime;
/*      */   private ReadOnlyObjectWrapper<Duration> cycleDuration;
/*      */   private ReadOnlyObjectWrapper<Duration> totalDuration;
/*      */   private ReadOnlyObjectWrapper<Duration> currentTime;
/*      */   private ReadOnlyObjectWrapper<Status> status;
/*      */   private ReadOnlyObjectWrapper<Duration> bufferProgressTime;
/*      */   private IntegerProperty cycleCount;
/*      */   
/*      */   private static double clamp(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  341 */     if (paramDouble2 != Double.MIN_VALUE && paramDouble1 < paramDouble2)
/*  342 */       return paramDouble2; 
/*  343 */     if (paramDouble3 != Double.MAX_VALUE && paramDouble1 > paramDouble3) {
/*  344 */       return paramDouble3;
/*      */     }
/*  346 */     return paramDouble1;
/*      */   }
/*      */   private ReadOnlyIntegerWrapper currentCount; private BooleanProperty mute; private ObjectProperty<EventHandler<MediaMarkerEvent>> onMarker; private ObjectProperty<Runnable> onEndOfMedia; private ObjectProperty<Runnable> onReady; private ObjectProperty<Runnable> onPlaying; private ObjectProperty<Runnable> onPaused; private ObjectProperty<Runnable> onStopped; private ObjectProperty<Runnable> onHalted; private ObjectProperty<Runnable> onRepeat; private ObjectProperty<Runnable> onStalled; private IntegerProperty audioSpectrumNumBands; private DoubleProperty audioSpectrumInterval; private IntegerProperty audioSpectrumThreshold; private ObjectProperty<AudioSpectrumListener> audioSpectrumListener; private final Object renderLock; private VideoDataBuffer currentRenderFrame; private VideoDataBuffer nextRenderFrame;
/*      */   
/*      */   private static int clamp(int paramInt1, int paramInt2, int paramInt3) {
/*  351 */     if (paramInt2 != Integer.MIN_VALUE && paramInt1 < paramInt2)
/*  352 */       return paramInt2; 
/*  353 */     if (paramInt3 != Integer.MAX_VALUE && paramInt1 > paramInt3) {
/*  354 */       return paramInt3;
/*      */     }
/*  356 */     return paramInt1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AudioEqualizer getAudioEqualizer() {
/*  365 */     synchronized (this.disposeLock) {
/*  366 */       if (getStatus() == Status.DISPOSED) {
/*  367 */         return null;
/*      */       }
/*      */       
/*  370 */       if (this.audioEqualizer == null) {
/*  371 */         this.audioEqualizer = new AudioEqualizer();
/*  372 */         if (this.jfxPlayer != null) {
/*  373 */           this.audioEqualizer.setAudioEqualizer(this.jfxPlayer.getEqualizer());
/*      */         }
/*  375 */         this.audioEqualizer.setEnabled(true);
/*      */       } 
/*  377 */       return this.audioEqualizer;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerListeners() {
/*  431 */     synchronized (this.disposeLock) {
/*  432 */       if (getStatus() == Status.DISPOSED) {
/*      */         return;
/*      */       }
/*      */       
/*  436 */       if (this.jfxPlayer != null) {
/*      */ 
/*      */         
/*  439 */         MediaManager.registerMediaPlayerForDispose(this, this.jfxPlayer);
/*      */         
/*  441 */         this.jfxPlayer.addMediaErrorListener(this.errorListener);
/*      */         
/*  443 */         this.jfxPlayer.addMediaTimeListener(this.timeListener);
/*  444 */         this.jfxPlayer.addVideoTrackSizeListener(this.sizeListener);
/*  445 */         this.jfxPlayer.addBufferListener(this.bufferListener);
/*  446 */         this.jfxPlayer.addMarkerListener(this.markerEventListener);
/*  447 */         this.jfxPlayer.addAudioSpectrumListener(this.spectrumListener);
/*  448 */         this.jfxPlayer.getVideoRenderControl().addVideoRendererListener(this.rendererListener);
/*  449 */         this.jfxPlayer.addMediaPlayerListener(this.stateListener);
/*      */       } 
/*      */       
/*  452 */       if (null != this.rendererListener)
/*      */       {
/*      */         
/*  455 */         Toolkit.getToolkit().addStageTkPulseListener(this.rendererListener);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void init() throws MediaException {
/*      */     try {
/*  463 */       Locator locator = this.media.retrieveJfxLocator();
/*      */ 
/*      */ 
/*      */       
/*  467 */       locator.waitForReadySignal();
/*      */       
/*  469 */       synchronized (this.disposeLock) {
/*  470 */         if (getStatus() == Status.DISPOSED) {
/*      */           return;
/*      */         }
/*      */         
/*  474 */         this.jfxPlayer = MediaManager.getPlayer(locator);
/*      */         
/*  476 */         if (this.jfxPlayer != null) {
/*      */           
/*  478 */           MediaPlayerShutdownHook.addMediaPlayer(this);
/*      */ 
/*      */           
/*  481 */           this.jfxPlayer.setBalance((float)getBalance());
/*  482 */           this.jfxPlayer.setMute(isMute());
/*  483 */           this.jfxPlayer.setVolume((float)getVolume());
/*      */ 
/*      */           
/*  486 */           this.sizeListener = new _VideoTrackSizeListener();
/*  487 */           this.stateListener = new _PlayerStateListener();
/*  488 */           this.timeListener = new _PlayerTimeListener();
/*  489 */           this.bufferListener = new _BufferListener();
/*  490 */           this.markerEventListener = new _MarkerListener();
/*  491 */           this.spectrumListener = new _SpectrumListener();
/*  492 */           this.rendererListener = new RendererListener();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  497 */         this.markerMapListener = new MarkerMapChangeListener();
/*  498 */         ObservableMap<String, Duration> observableMap = this.media.getMarkers();
/*  499 */         observableMap.addListener(this.markerMapListener);
/*      */ 
/*      */ 
/*      */         
/*  503 */         Media media = this.jfxPlayer.getMedia();
/*  504 */         for (Map.Entry<String, Duration> entry : observableMap.entrySet()) {
/*  505 */           String str = (String)entry.getKey();
/*  506 */           if (str != null) {
/*  507 */             Duration duration = (Duration)entry.getValue();
/*  508 */             if (duration != null) {
/*  509 */               double d = duration.toMillis();
/*  510 */               if (d >= 0.0D) {
/*  511 */                 media.addMarker(str, d / 1000.0D);
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  517 */     } catch (MediaException mediaException) {
/*  518 */       throw MediaException.exceptionToMediaException(mediaException);
/*      */     } 
/*      */ 
/*      */     
/*  522 */     Platform.runLater(() -> registerListeners());
/*      */   }
/*      */   
/*      */   private class InitMediaPlayer
/*      */     implements Runnable
/*      */   {
/*      */     private InitMediaPlayer() {}
/*      */     
/*      */     public void run() {
/*      */       try {
/*  532 */         MediaPlayer.this.init();
/*  533 */       } catch (MediaException mediaException) {
/*  534 */         MediaPlayer.this.handleError(MediaException.exceptionToMediaException(mediaException));
/*  535 */       } catch (MediaException mediaException) {
/*      */         
/*  537 */         if (MediaPlayer.this.media.getError() != null) {
/*  538 */           MediaPlayer.this.handleError(MediaPlayer.this.media.getError());
/*      */         } else {
/*  540 */           MediaPlayer.this.handleError(mediaException);
/*      */         } 
/*  542 */       } catch (Exception exception) {
/*  543 */         MediaPlayer.this.handleError(new MediaException(MediaException.Type.UNKNOWN, exception.getMessage()));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setError(MediaException paramMediaException) {
/*  554 */     if (getError() == null) {
/*  555 */       errorPropertyImpl().set(paramMediaException);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MediaException getError() {
/*  565 */     return (this.error == null) ? null : this.error.get();
/*      */   }
/*      */   
/*      */   public ReadOnlyObjectProperty<MediaException> errorProperty() {
/*  569 */     return errorPropertyImpl().getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   private ReadOnlyObjectWrapper<MediaException> errorPropertyImpl() {
/*  573 */     if (this.error == null) {
/*  574 */       this.error = new ReadOnlyObjectWrapper<MediaException>()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  578 */             if (MediaPlayer.this.getOnError() != null) {
/*  579 */               Platform.runLater(MediaPlayer.this.getOnError());
/*      */             }
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  585 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  590 */             return "error";
/*      */           }
/*      */         };
/*      */     }
/*  594 */     return this.error;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnError(Runnable paramRunnable) {
/*  607 */     onErrorProperty().set(paramRunnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Runnable getOnError() {
/*  615 */     return (this.onError == null) ? null : this.onError.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Runnable> onErrorProperty() {
/*  619 */     if (this.onError == null) {
/*  620 */       this.onError = new ObjectPropertyBase<Runnable>()
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected void invalidated()
/*      */           {
/*  629 */             if (get() != null && MediaPlayer.this.getError() != null) {
/*  630 */               Platform.runLater(get());
/*      */             }
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  636 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  641 */             return "onError";
/*      */           }
/*      */         };
/*      */     }
/*  645 */     return this.onError;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Media getMedia() {
/*  660 */     return this.media;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setAutoPlay(boolean paramBoolean) {
/*  677 */     autoPlayProperty().set(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isAutoPlay() {
/*  685 */     return (this.autoPlay == null) ? false : this.autoPlay.get();
/*      */   }
/*      */   
/*      */   public BooleanProperty autoPlayProperty() {
/*  689 */     if (this.autoPlay == null) {
/*  690 */       this.autoPlay = new BooleanPropertyBase()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  694 */             if (MediaPlayer.this.autoPlay.get()) {
/*  695 */               MediaPlayer.this.play();
/*      */             } else {
/*  697 */               MediaPlayer.this.playRequested = false;
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  703 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  708 */             return "autoPlay";
/*      */           }
/*      */         };
/*      */     }
/*  712 */     return this.autoPlay;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void play() {
/*  724 */     synchronized (this.disposeLock) {
/*  725 */       if (getStatus() != Status.DISPOSED) {
/*  726 */         if (this.playerReady) {
/*  727 */           this.jfxPlayer.play();
/*      */         } else {
/*  729 */           this.playRequested = true;
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pause() {
/*  740 */     synchronized (this.disposeLock) {
/*  741 */       if (getStatus() != Status.DISPOSED) {
/*  742 */         if (this.playerReady) {
/*  743 */           this.jfxPlayer.pause();
/*      */         } else {
/*  745 */           this.playRequested = false;
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop() {
/*  763 */     synchronized (this.disposeLock) {
/*  764 */       if (getStatus() != Status.DISPOSED) {
/*  765 */         if (this.playerReady) {
/*  766 */           this.jfxPlayer.stop();
/*  767 */           setCurrentCount(0);
/*  768 */           destroyMediaTimer();
/*      */         } else {
/*  770 */           this.playRequested = false;
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setRate(double paramDouble) {
/*  792 */     rateProperty().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getRate() {
/*  800 */     return (this.rate == null) ? 1.0D : this.rate.get();
/*      */   }
/*      */   
/*      */   public DoubleProperty rateProperty() {
/*  804 */     if (this.rate == null) {
/*  805 */       this.rate = new DoublePropertyBase(1.0D)
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  809 */             synchronized (MediaPlayer.this.disposeLock) {
/*  810 */               if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/*  811 */                 if (MediaPlayer.this.playerReady) {
/*  812 */                   if (MediaPlayer.this.jfxPlayer.getDuration() != Double.POSITIVE_INFINITY) {
/*  813 */                     MediaPlayer.this.jfxPlayer.setRate((float)MediaPlayer.clamp(MediaPlayer.this.rate.get(), 0.0D, 8.0D));
/*      */                   }
/*      */                 } else {
/*  816 */                   MediaPlayer.this.rateChangeRequested = true;
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  824 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  829 */             return "rate";
/*      */           }
/*      */         };
/*      */     }
/*  833 */     return this.rate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setCurrentRate(double paramDouble) {
/*  845 */     currentRatePropertyImpl().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getCurrentRate() {
/*  853 */     return (this.currentRate == null) ? 0.0D : this.currentRate.get();
/*      */   }
/*      */   
/*      */   public ReadOnlyDoubleProperty currentRateProperty() {
/*  857 */     return currentRatePropertyImpl().getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   private ReadOnlyDoubleWrapper currentRatePropertyImpl() {
/*  861 */     if (this.currentRate == null) {
/*  862 */       this.currentRate = new ReadOnlyDoubleWrapper(this, "currentRate");
/*      */     }
/*  864 */     return this.currentRate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setVolume(double paramDouble) {
/*  881 */     volumeProperty().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getVolume() {
/*  889 */     return (this.volume == null) ? 1.0D : this.volume.get();
/*      */   }
/*      */   
/*      */   public DoubleProperty volumeProperty() {
/*  893 */     if (this.volume == null) {
/*  894 */       this.volume = new DoublePropertyBase(1.0D)
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  898 */             synchronized (MediaPlayer.this.disposeLock) {
/*  899 */               if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/*  900 */                 if (MediaPlayer.this.playerReady) {
/*  901 */                   MediaPlayer.this.jfxPlayer.setVolume((float)MediaPlayer.clamp(MediaPlayer.this.volume.get(), 0.0D, 1.0D));
/*      */                 } else {
/*  903 */                   MediaPlayer.this.volumeChangeRequested = true;
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  911 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  916 */             return "volume";
/*      */           }
/*      */         };
/*      */     }
/*  920 */     return this.volume;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setBalance(double paramDouble) {
/*  937 */     balanceProperty().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getBalance() {
/*  945 */     return (this.balance == null) ? 0.0D : this.balance.get();
/*      */   }
/*      */   
/*      */   public DoubleProperty balanceProperty() {
/*  949 */     if (this.balance == null) {
/*  950 */       this.balance = new DoublePropertyBase()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/*  954 */             synchronized (MediaPlayer.this.disposeLock) {
/*  955 */               if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/*  956 */                 if (MediaPlayer.this.playerReady) {
/*  957 */                   MediaPlayer.this.jfxPlayer.setBalance((float)MediaPlayer.clamp(MediaPlayer.this.balance.get(), -1.0D, 1.0D));
/*      */                 } else {
/*  959 */                   MediaPlayer.this.balanceChangeRequested = true;
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/*  967 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/*  972 */             return "balance";
/*      */           }
/*      */         };
/*      */     }
/*  976 */     return this.balance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private double[] calculateStartStopTimes(Duration paramDuration1, Duration paramDuration2) {
/*      */     double d1, d2;
/*  995 */     if (paramDuration1 == null || paramDuration1.lessThan(Duration.ZERO) || paramDuration1
/*  996 */       .equals(Duration.UNKNOWN)) {
/*  997 */       d1 = 0.0D;
/*  998 */     } else if (paramDuration1.equals(Duration.INDEFINITE)) {
/*  999 */       d1 = Double.MAX_VALUE;
/*      */     } else {
/* 1001 */       d1 = paramDuration1.toMillis() / 1000.0D;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1006 */     if (paramDuration2 == null || paramDuration2.equals(Duration.UNKNOWN) || paramDuration2
/* 1007 */       .equals(Duration.INDEFINITE)) {
/* 1008 */       d2 = Double.MAX_VALUE;
/* 1009 */     } else if (paramDuration2.lessThan(Duration.ZERO)) {
/* 1010 */       d2 = 0.0D;
/*      */     } else {
/* 1012 */       d2 = paramDuration2.toMillis() / 1000.0D;
/*      */     } 
/*      */ 
/*      */     
/* 1016 */     Duration duration = this.media.getDuration();
/*      */     
/* 1018 */     double d3 = (duration == Duration.UNKNOWN) ? Double.MAX_VALUE : (duration.toMillis() / 1000.0D);
/*      */ 
/*      */     
/* 1021 */     double d4 = clamp(d1, 0.0D, d3);
/* 1022 */     double d5 = clamp(d2, 0.0D, d3);
/*      */ 
/*      */     
/* 1025 */     if (d4 > d5) {
/* 1026 */       d5 = d4;
/*      */     }
/*      */     
/* 1029 */     return new double[] { d4, d5 };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setStartStopTimes(Duration paramDuration1, boolean paramBoolean1, Duration paramDuration2, boolean paramBoolean2) {
/* 1040 */     if (this.jfxPlayer.getDuration() == Double.POSITIVE_INFINITY) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1045 */     double[] arrayOfDouble = calculateStartStopTimes(paramDuration1, paramDuration2);
/*      */ 
/*      */     
/* 1048 */     if (paramBoolean1) {
/* 1049 */       this.jfxPlayer.setStartTime(arrayOfDouble[0]);
/* 1050 */       if (getStatus() == Status.READY || getStatus() == Status.PAUSED) {
/* 1051 */         Platform.runLater(() -> setCurrentTime(getStartTime()));
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1056 */     if (paramBoolean2) {
/* 1057 */       this.jfxPlayer.setStopTime(arrayOfDouble[1]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setStartTime(Duration paramDuration) {
/* 1085 */     startTimeProperty().set(paramDuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Duration getStartTime() {
/* 1093 */     return (this.startTime == null) ? Duration.ZERO : this.startTime.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Duration> startTimeProperty() {
/* 1097 */     if (this.startTime == null) {
/* 1098 */       this.startTime = new ObjectPropertyBase<Duration>()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/* 1102 */             synchronized (MediaPlayer.this.disposeLock) {
/* 1103 */               if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/* 1104 */                 if (MediaPlayer.this.playerReady) {
/* 1105 */                   MediaPlayer.this.setStartStopTimes(MediaPlayer.this.startTime.get(), true, MediaPlayer.this.getStopTime(), false);
/*      */                 } else {
/* 1107 */                   MediaPlayer.this.startTimeChangeRequested = true;
/*      */                 } 
/* 1109 */                 MediaPlayer.this.calculateCycleDuration();
/*      */               } 
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/* 1116 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/* 1121 */             return "startTime";
/*      */           }
/*      */         };
/*      */     }
/* 1125 */     return this.startTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setStopTime(Duration paramDuration) {
/* 1143 */     stopTimeProperty().set(paramDuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Duration getStopTime() {
/* 1154 */     return (this.stopTime == null) ? this.media.getDuration() : this.stopTime.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Duration> stopTimeProperty() {
/* 1158 */     if (this.stopTime == null) {
/* 1159 */       this.stopTime = new ObjectPropertyBase<Duration>()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/* 1163 */             synchronized (MediaPlayer.this.disposeLock) {
/* 1164 */               if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/* 1165 */                 if (MediaPlayer.this.playerReady) {
/* 1166 */                   MediaPlayer.this.setStartStopTimes(MediaPlayer.this.getStartTime(), false, MediaPlayer.this.stopTime.get(), true);
/*      */                 } else {
/* 1168 */                   MediaPlayer.this.stopTimeChangeRequested = true;
/*      */                 } 
/* 1170 */                 MediaPlayer.this.calculateCycleDuration();
/*      */               } 
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/* 1177 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/* 1182 */             return "stopTime";
/*      */           }
/*      */         };
/*      */     }
/* 1186 */     return this.stopTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setCycleDuration(Duration paramDuration) {
/* 1199 */     cycleDurationPropertyImpl().set(paramDuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Duration getCycleDuration() {
/* 1207 */     return (this.cycleDuration == null) ? Duration.UNKNOWN : this.cycleDuration.get();
/*      */   }
/*      */   
/*      */   public ReadOnlyObjectProperty<Duration> cycleDurationProperty() {
/* 1211 */     return cycleDurationPropertyImpl().getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   private ReadOnlyObjectWrapper<Duration> cycleDurationPropertyImpl() {
/* 1215 */     if (this.cycleDuration == null) {
/* 1216 */       this.cycleDuration = new ReadOnlyObjectWrapper<>(this, "cycleDuration");
/*      */     }
/* 1218 */     return this.cycleDuration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void calculateCycleDuration() {
/* 1225 */     Duration duration1, duration2 = this.media.getDuration();
/*      */     
/* 1227 */     if (!getStopTime().isUnknown()) {
/* 1228 */       duration1 = getStopTime();
/*      */     } else {
/* 1230 */       duration1 = duration2;
/*      */     } 
/* 1232 */     if (duration1.greaterThan(duration2)) {
/* 1233 */       duration1 = duration2;
/*      */     }
/*      */ 
/*      */     
/* 1237 */     if ((duration1.isUnknown() || getStartTime().isUnknown() || getStartTime().isIndefinite()) && 
/* 1238 */       !getCycleDuration().isUnknown()) {
/* 1239 */       setCycleDuration(Duration.UNKNOWN);
/*      */     }
/*      */     
/* 1242 */     setCycleDuration(duration1.subtract(getStartTime()));
/* 1243 */     calculateTotalDuration();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setTotalDuration(Duration paramDuration) {
/* 1256 */     totalDurationPropertyImpl().set(paramDuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Duration getTotalDuration() {
/* 1264 */     return (this.totalDuration == null) ? Duration.UNKNOWN : this.totalDuration.get();
/*      */   }
/*      */   
/*      */   public ReadOnlyObjectProperty<Duration> totalDurationProperty() {
/* 1268 */     return totalDurationPropertyImpl().getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   private ReadOnlyObjectWrapper<Duration> totalDurationPropertyImpl() {
/* 1272 */     if (this.totalDuration == null) {
/* 1273 */       this.totalDuration = new ReadOnlyObjectWrapper<>(this, "totalDuration");
/*      */     }
/* 1275 */     return this.totalDuration;
/*      */   }
/*      */   private void calculateTotalDuration() {
/* 1278 */     if (getCycleCount() == -1) {
/* 1279 */       setTotalDuration(Duration.INDEFINITE);
/* 1280 */     } else if (getCycleDuration().isUnknown()) {
/* 1281 */       setTotalDuration(Duration.UNKNOWN);
/*      */     } else {
/* 1283 */       setTotalDuration(getCycleDuration().multiply(getCycleCount()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setCurrentTime(Duration paramDuration) {
/* 1297 */     currentTimePropertyImpl().set(paramDuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Duration getCurrentTime() {
/* 1305 */     synchronized (this.disposeLock) {
/* 1306 */       if (getStatus() == Status.DISPOSED) {
/* 1307 */         return Duration.ZERO;
/*      */       }
/*      */       
/* 1310 */       if (getStatus() == Status.STOPPED) {
/* 1311 */         return Duration.millis(getStartTime().toMillis());
/*      */       }
/*      */       
/* 1314 */       if (this.isEOS) {
/* 1315 */         Duration duration1 = this.media.getDuration();
/* 1316 */         Duration duration2 = getStopTime();
/* 1317 */         if (duration2 != Duration.UNKNOWN && duration1 != Duration.UNKNOWN) {
/* 1318 */           if (duration2.greaterThan(duration1)) {
/* 1319 */             return Duration.millis(duration1.toMillis());
/*      */           }
/* 1321 */           return Duration.millis(duration2.toMillis());
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1331 */       Duration duration = currentTimeProperty().get();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1336 */       if (this.playerReady) {
/* 1337 */         double d = this.jfxPlayer.getPresentationTime();
/* 1338 */         if (d >= 0.0D) {
/* 1339 */           duration = Duration.seconds(d);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1348 */       return duration;
/*      */     } 
/*      */   }
/*      */   
/*      */   public ReadOnlyObjectProperty<Duration> currentTimeProperty() {
/* 1353 */     return currentTimePropertyImpl().getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   private ReadOnlyObjectWrapper<Duration> currentTimePropertyImpl() {
/* 1357 */     if (this.currentTime == null) {
/* 1358 */       this.currentTime = new ReadOnlyObjectWrapper<>(this, "currentTime");
/* 1359 */       this.currentTime.setValue(Duration.ZERO);
/* 1360 */       updateTime();
/*      */     } 
/* 1362 */     return this.currentTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void seek(Duration paramDuration) {
/* 1387 */     synchronized (this.disposeLock) {
/* 1388 */       if (getStatus() == Status.DISPOSED) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1393 */       if (this.playerReady && paramDuration != null && !paramDuration.isUnknown()) {
/* 1394 */         double d; if (this.jfxPlayer.getDuration() == Double.POSITIVE_INFINITY) {
/*      */           return;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1402 */         if (paramDuration.isIndefinite()) {
/*      */           
/* 1404 */           Duration duration = this.media.getDuration();
/* 1405 */           if (duration == null || duration
/* 1406 */             .isUnknown() || duration
/* 1407 */             .isIndefinite()) {
/* 1408 */             duration = Duration.millis(Double.MAX_VALUE);
/*      */           }
/*      */ 
/*      */           
/* 1412 */           d = duration.toMillis() / 1000.0D;
/*      */         } else {
/*      */           
/* 1415 */           d = paramDuration.toMillis() / 1000.0D;
/*      */ 
/*      */           
/* 1418 */           double[] arrayOfDouble = calculateStartStopTimes(getStartTime(), getStopTime());
/* 1419 */           if (d < arrayOfDouble[0]) {
/* 1420 */             d = arrayOfDouble[0];
/* 1421 */           } else if (d > arrayOfDouble[1]) {
/* 1422 */             d = arrayOfDouble[1];
/*      */           } 
/*      */         } 
/*      */         
/* 1426 */         if (!this.isUpdateTimeEnabled) {
/*      */ 
/*      */           
/* 1429 */           Status status = getStatus();
/* 1430 */           if ((status == Status.PLAYING || status == Status.PAUSED) && 
/*      */             
/* 1432 */             getStartTime().toSeconds() <= d && d <= 
/* 1433 */             getStopTime().toSeconds()) {
/* 1434 */             this.isEOS = false;
/* 1435 */             this.isUpdateTimeEnabled = true;
/* 1436 */             setCurrentRate(getRate());
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1441 */         this.jfxPlayer.seek(d);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setStatus(Status paramStatus) {
/* 1451 */     statusPropertyImpl().set(paramStatus);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Status getStatus() {
/* 1459 */     return (this.status == null) ? Status.UNKNOWN : this.status.get();
/*      */   }
/*      */   
/*      */   public ReadOnlyObjectProperty<Status> statusProperty() {
/* 1463 */     return statusPropertyImpl().getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   private ReadOnlyObjectWrapper<Status> statusPropertyImpl() {
/* 1467 */     if (this.status == null) {
/* 1468 */       this.status = new ReadOnlyObjectWrapper<Status>()
/*      */         {
/*      */           
/*      */           protected void invalidated()
/*      */           {
/* 1473 */             if (get() == MediaPlayer.Status.PLAYING) {
/* 1474 */               MediaPlayer.this.setCurrentRate(MediaPlayer.this.getRate());
/*      */             } else {
/* 1476 */               MediaPlayer.this.setCurrentRate(0.0D);
/*      */             } 
/*      */ 
/*      */             
/* 1480 */             if (get() == MediaPlayer.Status.READY) {
/* 1481 */               if (MediaPlayer.this.getOnReady() != null) {
/* 1482 */                 Platform.runLater(MediaPlayer.this.getOnReady());
/*      */               }
/* 1484 */             } else if (get() == MediaPlayer.Status.PLAYING) {
/* 1485 */               if (MediaPlayer.this.getOnPlaying() != null) {
/* 1486 */                 Platform.runLater(MediaPlayer.this.getOnPlaying());
/*      */               }
/* 1488 */             } else if (get() == MediaPlayer.Status.PAUSED) {
/* 1489 */               if (MediaPlayer.this.getOnPaused() != null) {
/* 1490 */                 Platform.runLater(MediaPlayer.this.getOnPaused());
/*      */               }
/* 1492 */             } else if (get() == MediaPlayer.Status.STOPPED) {
/* 1493 */               if (MediaPlayer.this.getOnStopped() != null) {
/* 1494 */                 Platform.runLater(MediaPlayer.this.getOnStopped());
/*      */               }
/* 1496 */             } else if (get() == MediaPlayer.Status.STALLED && 
/* 1497 */               MediaPlayer.this.getOnStalled() != null) {
/* 1498 */               Platform.runLater(MediaPlayer.this.getOnStalled());
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public Object getBean() {
/* 1505 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/* 1510 */             return "status";
/*      */           }
/*      */         };
/*      */     }
/* 1514 */     return this.status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setBufferProgressTime(Duration paramDuration) {
/* 1529 */     bufferProgressTimePropertyImpl().set(paramDuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Duration getBufferProgressTime() {
/* 1537 */     return (this.bufferProgressTime == null) ? null : this.bufferProgressTime.get();
/*      */   }
/*      */   
/*      */   public ReadOnlyObjectProperty<Duration> bufferProgressTimeProperty() {
/* 1541 */     return bufferProgressTimePropertyImpl().getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   private ReadOnlyObjectWrapper<Duration> bufferProgressTimePropertyImpl() {
/* 1545 */     if (this.bufferProgressTime == null) {
/* 1546 */       this.bufferProgressTime = new ReadOnlyObjectWrapper<>(this, "bufferProgressTime");
/*      */     }
/* 1548 */     return this.bufferProgressTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCycleCount(int paramInt) {
/* 1569 */     cycleCountProperty().set(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getCycleCount() {
/* 1577 */     return (this.cycleCount == null) ? 1 : this.cycleCount.get();
/*      */   }
/*      */   
/*      */   public IntegerProperty cycleCountProperty() {
/* 1581 */     if (this.cycleCount == null) {
/* 1582 */       this.cycleCount = new IntegerPropertyBase(1)
/*      */         {
/*      */           public Object getBean()
/*      */           {
/* 1586 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/* 1591 */             return "cycleCount";
/*      */           }
/*      */         };
/*      */     }
/* 1595 */     return this.cycleCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setCurrentCount(int paramInt) {
/* 1608 */     currentCountPropertyImpl().set(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getCurrentCount() {
/* 1616 */     return (this.currentCount == null) ? 0 : this.currentCount.get();
/*      */   }
/*      */   
/*      */   public ReadOnlyIntegerProperty currentCountProperty() {
/* 1620 */     return currentCountPropertyImpl().getReadOnlyProperty();
/*      */   }
/*      */   
/*      */   private ReadOnlyIntegerWrapper currentCountPropertyImpl() {
/* 1624 */     if (this.currentCount == null) {
/* 1625 */       this.currentCount = new ReadOnlyIntegerWrapper(this, "currentCount");
/*      */     }
/* 1627 */     return this.currentCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setMute(boolean paramBoolean) {
/* 1645 */     muteProperty().set(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMute() {
/* 1653 */     return (this.mute == null) ? false : this.mute.get();
/*      */   }
/*      */   
/*      */   public BooleanProperty muteProperty() {
/* 1657 */     if (this.mute == null) {
/* 1658 */       this.mute = new BooleanPropertyBase()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/* 1662 */             synchronized (MediaPlayer.this.disposeLock) {
/* 1663 */               if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/* 1664 */                 if (MediaPlayer.this.playerReady) {
/* 1665 */                   MediaPlayer.this.jfxPlayer.setMute(get());
/*      */                 } else {
/* 1667 */                   MediaPlayer.this.muteChangeRequested = true;
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/* 1675 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/* 1680 */             return "mute";
/*      */           }
/*      */         };
/*      */     }
/* 1684 */     return this.mute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnMarker(EventHandler<MediaMarkerEvent> paramEventHandler) {
/* 1698 */     onMarkerProperty().set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final EventHandler<MediaMarkerEvent> getOnMarker() {
/* 1706 */     return (this.onMarker == null) ? null : this.onMarker.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<EventHandler<MediaMarkerEvent>> onMarkerProperty() {
/* 1710 */     if (this.onMarker == null) {
/* 1711 */       this.onMarker = new SimpleObjectProperty<>(this, "onMarker");
/*      */     }
/* 1713 */     return this.onMarker;
/*      */   }
/*      */   
/*      */   void addView(MediaView paramMediaView) {
/* 1717 */     WeakReference<MediaView> weakReference = new WeakReference<>(paramMediaView);
/* 1718 */     synchronized (this.viewRefs) {
/* 1719 */       this.viewRefs.add(weakReference);
/*      */     } 
/*      */   }
/*      */   
/*      */   void removeView(MediaView paramMediaView) {
/* 1724 */     synchronized (this.viewRefs) {
/* 1725 */       for (WeakReference<MediaView> weakReference : this.viewRefs) {
/* 1726 */         MediaView mediaView = weakReference.get();
/* 1727 */         if (mediaView != null && mediaView.equals(paramMediaView)) {
/* 1728 */           this.viewRefs.remove(weakReference);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void handleError(MediaException paramMediaException) {
/* 1736 */     Platform.runLater(() -> {
/*      */           setError(paramMediaException);
/*      */           if (paramMediaException.getType() == MediaException.Type.MEDIA_CORRUPTED || paramMediaException.getType() == MediaException.Type.MEDIA_UNSUPPORTED || paramMediaException.getType() == MediaException.Type.MEDIA_INACCESSIBLE || paramMediaException.getType() == MediaException.Type.MEDIA_UNAVAILABLE) {
/*      */             this.media._setError(paramMediaException.getType(), paramMediaException.getMessage());
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void createMediaTimer() {
/* 1750 */     synchronized (MediaTimerTask.timerLock) {
/* 1751 */       if (this.mediaTimerTask == null) {
/* 1752 */         this.mediaTimerTask = new MediaTimerTask(this);
/* 1753 */         this.mediaTimerTask.start();
/*      */       } 
/* 1755 */       this.isUpdateTimeEnabled = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   void destroyMediaTimer() {
/* 1760 */     synchronized (MediaTimerTask.timerLock) {
/* 1761 */       if (this.mediaTimerTask != null) {
/* 1762 */         this.isUpdateTimeEnabled = false;
/* 1763 */         this.mediaTimerTask.stop();
/* 1764 */         this.mediaTimerTask = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void updateTime() {
/* 1771 */     if (this.playerReady && this.isUpdateTimeEnabled && this.jfxPlayer != null) {
/* 1772 */       double d = this.jfxPlayer.getPresentationTime();
/* 1773 */       if (d >= 0.0D) {
/* 1774 */         double d1 = d * 1000.0D;
/*      */         
/* 1776 */         if (Double.compare(d1, this.prevTimeMs) != 0) {
/* 1777 */           setCurrentTime(Duration.millis(d1));
/* 1778 */           this.prevTimeMs = d1;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   void loopPlayback() {
/* 1785 */     seek(getStartTime());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleRequestedChanges() {
/* 1794 */     if (this.rateChangeRequested) {
/* 1795 */       if (this.jfxPlayer.getDuration() != Double.POSITIVE_INFINITY) {
/* 1796 */         this.jfxPlayer.setRate((float)clamp(getRate(), 0.0D, 8.0D));
/*      */       }
/* 1798 */       this.rateChangeRequested = false;
/*      */     } 
/*      */     
/* 1801 */     if (this.volumeChangeRequested) {
/* 1802 */       this.jfxPlayer.setVolume((float)clamp(getVolume(), 0.0D, 1.0D));
/* 1803 */       this.volumeChangeRequested = false;
/*      */     } 
/*      */     
/* 1806 */     if (this.balanceChangeRequested) {
/* 1807 */       this.jfxPlayer.setBalance((float)clamp(getBalance(), -1.0D, 1.0D));
/* 1808 */       this.balanceChangeRequested = false;
/*      */     } 
/*      */     
/* 1811 */     if (this.startTimeChangeRequested || this.stopTimeChangeRequested) {
/* 1812 */       setStartStopTimes(getStartTime(), this.startTimeChangeRequested, getStopTime(), this.stopTimeChangeRequested);
/* 1813 */       this.startTimeChangeRequested = this.stopTimeChangeRequested = false;
/*      */     } 
/*      */     
/* 1816 */     if (this.muteChangeRequested) {
/* 1817 */       this.jfxPlayer.setMute(isMute());
/* 1818 */       this.muteChangeRequested = false;
/*      */     } 
/*      */     
/* 1821 */     if (this.audioSpectrumNumBandsChangeRequested) {
/* 1822 */       this.jfxPlayer.getAudioSpectrum().setBandCount(clamp(getAudioSpectrumNumBands(), 2, 2147483647));
/* 1823 */       this.audioSpectrumNumBandsChangeRequested = false;
/*      */     } 
/*      */     
/* 1826 */     if (this.audioSpectrumIntervalChangeRequested) {
/* 1827 */       this.jfxPlayer.getAudioSpectrum().setInterval(clamp(getAudioSpectrumInterval(), 1.0E-9D, Double.MAX_VALUE));
/* 1828 */       this.audioSpectrumIntervalChangeRequested = false;
/*      */     } 
/*      */     
/* 1831 */     if (this.audioSpectrumThresholdChangeRequested) {
/* 1832 */       this.jfxPlayer.getAudioSpectrum().setSensitivityThreshold(clamp(getAudioSpectrumThreshold(), -2147483648, 0));
/* 1833 */       this.audioSpectrumThresholdChangeRequested = false;
/*      */     } 
/*      */     
/* 1836 */     if (this.audioSpectrumEnabledChangeRequested) {
/* 1837 */       boolean bool = (getAudioSpectrumListener() != null) ? true : false;
/* 1838 */       this.jfxPlayer.getAudioSpectrum().setEnabled(bool);
/* 1839 */       this.audioSpectrumEnabledChangeRequested = false;
/*      */     } 
/*      */     
/* 1842 */     if (this.playRequested) {
/* 1843 */       this.jfxPlayer.play();
/* 1844 */       this.playRequested = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void preReady() {
/*      */     Duration duration;
/* 1854 */     synchronized (this.viewRefs) {
/* 1855 */       for (WeakReference<MediaView> weakReference : this.viewRefs) {
/* 1856 */         MediaView mediaView = weakReference.get();
/* 1857 */         if (mediaView != null) {
/* 1858 */           mediaView._mediaPlayerOnReady();
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1864 */     if (this.audioEqualizer != null) {
/* 1865 */       this.audioEqualizer.setAudioEqualizer(this.jfxPlayer.getEqualizer());
/*      */     }
/*      */ 
/*      */     
/* 1869 */     double d = this.jfxPlayer.getDuration();
/*      */     
/* 1871 */     if (d >= 0.0D && !Double.isNaN(d)) {
/* 1872 */       duration = Duration.millis(d * 1000.0D);
/*      */     } else {
/* 1874 */       duration = Duration.UNKNOWN;
/*      */     } 
/*      */     
/* 1877 */     this.playerReady = true;
/*      */     
/* 1879 */     this.media.setDuration(duration);
/* 1880 */     this.media._updateMedia(this.jfxPlayer.getMedia());
/*      */ 
/*      */ 
/*      */     
/* 1884 */     handleRequestedChanges();
/*      */ 
/*      */     
/* 1887 */     calculateCycleDuration();
/*      */ 
/*      */     
/* 1890 */     if (this.lastBufferEvent != null && duration.toMillis() > 0.0D) {
/* 1891 */       double d1 = this.lastBufferEvent.getBufferPosition();
/* 1892 */       double d2 = this.lastBufferEvent.getBufferStop();
/* 1893 */       double d3 = d1 / d2 * duration.toMillis();
/* 1894 */       this.lastBufferEvent = null;
/* 1895 */       setBufferProgressTime(Duration.millis(d3));
/*      */     } 
/*      */     
/* 1898 */     setStatus(Status.READY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnEndOfMedia(Runnable paramRunnable) {
/* 1911 */     onEndOfMediaProperty().set(paramRunnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Runnable getOnEndOfMedia() {
/* 1919 */     return (this.onEndOfMedia == null) ? null : this.onEndOfMedia.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Runnable> onEndOfMediaProperty() {
/* 1923 */     if (this.onEndOfMedia == null) {
/* 1924 */       this.onEndOfMedia = new SimpleObjectProperty<>(this, "onEndOfMedia");
/*      */     }
/* 1926 */     return this.onEndOfMedia;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnReady(Runnable paramRunnable) {
/* 1940 */     onReadyProperty().set(paramRunnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Runnable getOnReady() {
/* 1948 */     return (this.onReady == null) ? null : this.onReady.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Runnable> onReadyProperty() {
/* 1952 */     if (this.onReady == null) {
/* 1953 */       this.onReady = new SimpleObjectProperty<>(this, "onReady");
/*      */     }
/* 1955 */     return this.onReady;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnPlaying(Runnable paramRunnable) {
/* 1969 */     onPlayingProperty().set(paramRunnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Runnable getOnPlaying() {
/* 1977 */     return (this.onPlaying == null) ? null : this.onPlaying.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Runnable> onPlayingProperty() {
/* 1981 */     if (this.onPlaying == null) {
/* 1982 */       this.onPlaying = new SimpleObjectProperty<>(this, "onPlaying");
/*      */     }
/* 1984 */     return this.onPlaying;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnPaused(Runnable paramRunnable) {
/* 1997 */     onPausedProperty().set(paramRunnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Runnable getOnPaused() {
/* 2005 */     return (this.onPaused == null) ? null : this.onPaused.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Runnable> onPausedProperty() {
/* 2009 */     if (this.onPaused == null) {
/* 2010 */       this.onPaused = new SimpleObjectProperty<>(this, "onPaused");
/*      */     }
/* 2012 */     return this.onPaused;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnStopped(Runnable paramRunnable) {
/* 2026 */     onStoppedProperty().set(paramRunnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Runnable getOnStopped() {
/* 2034 */     return (this.onStopped == null) ? null : this.onStopped.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Runnable> onStoppedProperty() {
/* 2038 */     if (this.onStopped == null) {
/* 2039 */       this.onStopped = new SimpleObjectProperty<>(this, "onStopped");
/*      */     }
/* 2041 */     return this.onStopped;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnHalted(Runnable paramRunnable) {
/* 2054 */     onHaltedProperty().set(paramRunnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Runnable getOnHalted() {
/* 2062 */     return (this.onHalted == null) ? null : this.onHalted.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Runnable> onHaltedProperty() {
/* 2066 */     if (this.onHalted == null) {
/* 2067 */       this.onHalted = new SimpleObjectProperty<>(this, "onHalted");
/*      */     }
/* 2069 */     return this.onHalted;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnRepeat(Runnable paramRunnable) {
/* 2085 */     onRepeatProperty().set(paramRunnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Runnable getOnRepeat() {
/* 2093 */     return (this.onRepeat == null) ? null : this.onRepeat.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Runnable> onRepeatProperty() {
/* 2097 */     if (this.onRepeat == null) {
/* 2098 */       this.onRepeat = new SimpleObjectProperty<>(this, "onRepeat");
/*      */     }
/* 2100 */     return this.onRepeat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setOnStalled(Runnable paramRunnable) {
/* 2114 */     onStalledProperty().set(paramRunnable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Runnable getOnStalled() {
/* 2122 */     return (this.onStalled == null) ? null : this.onStalled.get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<Runnable> onStalledProperty() {
/* 2126 */     if (this.onStalled == null) {
/* 2127 */       this.onStalled = new SimpleObjectProperty<>(this, "onStalled");
/*      */     }
/* 2129 */     return this.onStalled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setAudioSpectrumNumBands(int paramInt) {
/* 2152 */     audioSpectrumNumBandsProperty().setValue(Integer.valueOf(paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getAudioSpectrumNumBands() {
/* 2160 */     return audioSpectrumNumBandsProperty().getValue().intValue();
/*      */   }
/*      */   
/*      */   public IntegerProperty audioSpectrumNumBandsProperty() {
/* 2164 */     if (this.audioSpectrumNumBands == null) {
/* 2165 */       this.audioSpectrumNumBands = new IntegerPropertyBase(128)
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/* 2169 */             synchronized (MediaPlayer.this.disposeLock) {
/* 2170 */               if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/* 2171 */                 if (MediaPlayer.this.playerReady) {
/* 2172 */                   MediaPlayer.this.jfxPlayer.getAudioSpectrum().setBandCount(MediaPlayer.clamp(MediaPlayer.this.audioSpectrumNumBands.get(), 2, 2147483647));
/*      */                 } else {
/* 2174 */                   MediaPlayer.this.audioSpectrumNumBandsChangeRequested = true;
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/* 2182 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/* 2187 */             return "audioSpectrumNumBands";
/*      */           }
/*      */         };
/*      */     }
/* 2191 */     return this.audioSpectrumNumBands;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setAudioSpectrumInterval(double paramDouble) {
/* 2205 */     audioSpectrumIntervalProperty().set(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double getAudioSpectrumInterval() {
/* 2213 */     return audioSpectrumIntervalProperty().get();
/*      */   }
/*      */   
/*      */   public DoubleProperty audioSpectrumIntervalProperty() {
/* 2217 */     if (this.audioSpectrumInterval == null) {
/* 2218 */       this.audioSpectrumInterval = new DoublePropertyBase(0.1D)
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/* 2222 */             synchronized (MediaPlayer.this.disposeLock) {
/* 2223 */               if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/* 2224 */                 if (MediaPlayer.this.playerReady) {
/* 2225 */                   MediaPlayer.this.jfxPlayer.getAudioSpectrum().setInterval(MediaPlayer.clamp(MediaPlayer.this.audioSpectrumInterval.get(), 1.0E-9D, Double.MAX_VALUE));
/*      */                 } else {
/* 2227 */                   MediaPlayer.this.audioSpectrumIntervalChangeRequested = true;
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/* 2235 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/* 2240 */             return "audioSpectrumInterval";
/*      */           }
/*      */         };
/*      */     }
/* 2244 */     return this.audioSpectrumInterval;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setAudioSpectrumThreshold(int paramInt) {
/* 2260 */     audioSpectrumThresholdProperty().set(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getAudioSpectrumThreshold() {
/* 2268 */     return audioSpectrumThresholdProperty().get();
/*      */   }
/*      */   
/*      */   public IntegerProperty audioSpectrumThresholdProperty() {
/* 2272 */     if (this.audioSpectrumThreshold == null) {
/* 2273 */       this.audioSpectrumThreshold = new IntegerPropertyBase(-60)
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/* 2277 */             synchronized (MediaPlayer.this.disposeLock) {
/* 2278 */               if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/* 2279 */                 if (MediaPlayer.this.playerReady) {
/* 2280 */                   MediaPlayer.this.jfxPlayer.getAudioSpectrum().setSensitivityThreshold(MediaPlayer.clamp(MediaPlayer.this.audioSpectrumThreshold.get(), -2147483648, 0));
/*      */                 } else {
/* 2282 */                   MediaPlayer.this.audioSpectrumThresholdChangeRequested = true;
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/* 2290 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/* 2295 */             return "audioSpectrumThreshold";
/*      */           }
/*      */         };
/*      */     }
/* 2299 */     return this.audioSpectrumThreshold;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setAudioSpectrumListener(AudioSpectrumListener paramAudioSpectrumListener) {
/* 2319 */     audioSpectrumListenerProperty().set(paramAudioSpectrumListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AudioSpectrumListener getAudioSpectrumListener() {
/* 2327 */     return audioSpectrumListenerProperty().get();
/*      */   }
/*      */   
/*      */   public ObjectProperty<AudioSpectrumListener> audioSpectrumListenerProperty() {
/* 2331 */     if (this.audioSpectrumListener == null) {
/* 2332 */       this.audioSpectrumListener = new ObjectPropertyBase<AudioSpectrumListener>()
/*      */         {
/*      */           protected void invalidated()
/*      */           {
/* 2336 */             synchronized (MediaPlayer.this.disposeLock) {
/* 2337 */               if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/* 2338 */                 if (MediaPlayer.this.playerReady) {
/* 2339 */                   boolean bool = (MediaPlayer.this.audioSpectrumListener.get() != null) ? true : false;
/* 2340 */                   MediaPlayer.this.jfxPlayer.getAudioSpectrum().setEnabled(bool);
/*      */                 } else {
/* 2342 */                   MediaPlayer.this.audioSpectrumEnabledChangeRequested = true;
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public Object getBean() {
/* 2350 */             return MediaPlayer.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getName() {
/* 2355 */             return "audioSpectrumListener";
/*      */           }
/*      */         };
/*      */     }
/* 2359 */     return this.audioSpectrumListener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void dispose() {
/* 2369 */     synchronized (this.disposeLock) {
/* 2370 */       setStatus(Status.DISPOSED);
/*      */       
/* 2372 */       destroyMediaTimer();
/*      */       
/* 2374 */       if (this.audioEqualizer != null) {
/* 2375 */         this.audioEqualizer.setAudioEqualizer(null);
/* 2376 */         this.audioEqualizer = null;
/*      */       } 
/*      */       
/* 2379 */       if (this.jfxPlayer != null) {
/* 2380 */         this.jfxPlayer.dispose();
/* 2381 */         synchronized (this.renderLock) {
/* 2382 */           if (this.rendererListener != null) {
/* 2383 */             Toolkit.getToolkit().removeStageTkPulseListener(this.rendererListener);
/* 2384 */             this.rendererListener = null;
/*      */           } 
/*      */         } 
/* 2387 */         this.jfxPlayer = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class MarkerMapChangeListener
/*      */     implements MapChangeListener<String, Duration>
/*      */   {
/*      */     private MarkerMapChangeListener() {}
/*      */ 
/*      */     
/*      */     public void onChanged(MapChangeListener.Change<? extends String, ? extends Duration> param1Change) {
/* 2401 */       synchronized (MediaPlayer.this.disposeLock) {
/* 2402 */         if (MediaPlayer.this.getStatus() != MediaPlayer.Status.DISPOSED) {
/* 2403 */           String str = param1Change.getKey();
/*      */           
/* 2405 */           if (str == null) {
/*      */             return;
/*      */           }
/* 2408 */           Media media = MediaPlayer.this.jfxPlayer.getMedia();
/* 2409 */           if (param1Change.wasAdded()) {
/* 2410 */             if (param1Change.wasRemoved())
/*      */             {
/*      */ 
/*      */ 
/*      */               
/* 2415 */               media.removeMarker(str);
/*      */             }
/* 2417 */             Duration duration = param1Change.getValueAdded();
/*      */             
/* 2419 */             if (duration != null && duration.greaterThanOrEqualTo(Duration.ZERO)) {
/* 2420 */               media.addMarker(str, ((Duration)param1Change.getValueAdded()).toMillis() / 1000.0D);
/*      */             }
/* 2422 */           } else if (param1Change.wasRemoved()) {
/* 2423 */             media.removeMarker(str);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class _MarkerListener
/*      */     implements MarkerListener
/*      */   {
/*      */     private _MarkerListener() {}
/*      */ 
/*      */     
/*      */     public void onMarker(MarkerEvent param1MarkerEvent) {
/* 2438 */       Platform.runLater(() -> {
/*      */             Duration duration = Duration.millis(param1MarkerEvent.getPresentationTime() * 1000.0D);
/*      */             if (MediaPlayer.this.getOnMarker() != null)
/*      */               MediaPlayer.this.getOnMarker().handle(new MediaMarkerEvent(new Pair<>(param1MarkerEvent.getMarkerName(), duration))); 
/*      */           });
/*      */     }
/*      */   }
/*      */   
/*      */   private class _PlayerStateListener
/*      */     implements PlayerStateListener {
/*      */     private _PlayerStateListener() {}
/*      */     
/*      */     public void onReady(PlayerStateEvent param1PlayerStateEvent) {
/* 2451 */       Platform.runLater(() -> {
/*      */             synchronized (MediaPlayer.this.disposeLock) {
/*      */               if (MediaPlayer.this.getStatus() == MediaPlayer.Status.DISPOSED) {
/*      */                 return;
/*      */               }
/*      */               MediaPlayer.this.preReady();
/*      */             } 
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onPlaying(PlayerStateEvent param1PlayerStateEvent) {
/* 2465 */       MediaPlayer.this.startTimeAtStop = null;
/*      */       
/* 2467 */       Platform.runLater(() -> {
/*      */             MediaPlayer.this.createMediaTimer();
/*      */             MediaPlayer.this.setStatus(MediaPlayer.Status.PLAYING);
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onPause(PlayerStateEvent param1PlayerStateEvent) {
/* 2477 */       Platform.runLater(() -> {
/*      */             MediaPlayer.this.isUpdateTimeEnabled = false;
/*      */ 
/*      */             
/*      */             MediaPlayer.this.setStatus(MediaPlayer.Status.PAUSED);
/*      */           });
/*      */       
/* 2484 */       if (MediaPlayer.this.startTimeAtStop != null && MediaPlayer.this.startTimeAtStop != MediaPlayer.this.getStartTime()) {
/* 2485 */         MediaPlayer.this.startTimeAtStop = null;
/* 2486 */         Platform.runLater(() -> MediaPlayer.this.setCurrentTime(MediaPlayer.this.getStartTime()));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onStop(PlayerStateEvent param1PlayerStateEvent) {
/* 2495 */       Platform.runLater(() -> {
/*      */             MediaPlayer.this.destroyMediaTimer();
/*      */             MediaPlayer.this.startTimeAtStop = MediaPlayer.this.getStartTime();
/*      */             MediaPlayer.this.setCurrentTime(MediaPlayer.this.getStartTime());
/*      */             MediaPlayer.this.setStatus(MediaPlayer.Status.STOPPED);
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onStall(PlayerStateEvent param1PlayerStateEvent) {
/* 2507 */       Platform.runLater(() -> {
/*      */             MediaPlayer.this.isUpdateTimeEnabled = false;
/*      */             MediaPlayer.this.setStatus(MediaPlayer.Status.STALLED);
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void handleFinish() {
/* 2519 */       MediaPlayer.this.setCurrentCount(MediaPlayer.this.getCurrentCount() + 1);
/*      */ 
/*      */ 
/*      */       
/* 2523 */       if (MediaPlayer.this.getCurrentCount() < MediaPlayer.this.getCycleCount() || MediaPlayer.this.getCycleCount() == -1) {
/* 2524 */         if (MediaPlayer.this.getOnEndOfMedia() != null) {
/* 2525 */           Platform.runLater(MediaPlayer.this.getOnEndOfMedia());
/*      */         }
/*      */         
/* 2528 */         MediaPlayer.this.loopPlayback();
/*      */         
/* 2530 */         if (MediaPlayer.this.getOnRepeat() != null) {
/* 2531 */           Platform.runLater(MediaPlayer.this.getOnRepeat());
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 2537 */         MediaPlayer.this.isUpdateTimeEnabled = false;
/*      */ 
/*      */         
/* 2540 */         MediaPlayer.this.setCurrentRate(0.0D);
/*      */ 
/*      */         
/* 2543 */         MediaPlayer.this.isEOS = true;
/*      */         
/* 2545 */         if (MediaPlayer.this.getOnEndOfMedia() != null) {
/* 2546 */           Platform.runLater(MediaPlayer.this.getOnEndOfMedia());
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onFinish(PlayerStateEvent param1PlayerStateEvent) {
/* 2554 */       MediaPlayer.this.startTimeAtStop = null;
/*      */       
/* 2556 */       Platform.runLater(() -> handleFinish());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void onHalt(PlayerStateEvent param1PlayerStateEvent) {
/* 2563 */       Platform.runLater(() -> {
/*      */             MediaPlayer.this.setStatus(MediaPlayer.Status.HALTED);
/*      */             MediaPlayer.this.handleError(MediaException.haltException(param1PlayerStateEvent.getMessage()));
/*      */             MediaPlayer.this.isUpdateTimeEnabled = false;
/*      */           });
/*      */     }
/*      */   }
/*      */   
/*      */   private class _PlayerTimeListener implements PlayerTimeListener {
/*      */     double theDuration;
/*      */     
/*      */     private _PlayerTimeListener() {}
/*      */     
/*      */     void handleDurationChanged() {
/* 2577 */       MediaPlayer.this.media.setDuration(Duration.millis(this.theDuration * 1000.0D));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onDurationChanged(double param1Double) {
/* 2583 */       Platform.runLater(() -> {
/*      */             this.theDuration = param1Double;
/*      */             handleDurationChanged();
/*      */           });
/*      */     } }
/*      */   
/*      */   private class _VideoTrackSizeListener implements VideoTrackSizeListener {
/*      */     int trackWidth;
/*      */     int trackHeight;
/*      */     
/*      */     private _VideoTrackSizeListener() {}
/*      */     
/*      */     public void onSizeChanged(int param1Int1, int param1Int2) {
/* 2596 */       Platform.runLater(() -> {
/*      */             if (MediaPlayer.this.media != null) {
/*      */               this.trackWidth = param1Int1;
/*      */               this.trackHeight = param1Int2;
/*      */               setSize();
/*      */             } 
/*      */           });
/*      */     }
/*      */     
/*      */     void setSize() {
/* 2606 */       MediaPlayer.this.media.setWidth(this.trackWidth);
/* 2607 */       MediaPlayer.this.media.setHeight(this.trackHeight);
/*      */       
/* 2609 */       synchronized (MediaPlayer.this.viewRefs) {
/* 2610 */         for (WeakReference<MediaView> weakReference : (Iterable<WeakReference<MediaView>>)MediaPlayer.this.viewRefs) {
/* 2611 */           MediaView mediaView = weakReference.get();
/* 2612 */           if (mediaView != null)
/* 2613 */             mediaView.notifyMediaSizeChange(); 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private class _MediaErrorListener implements MediaErrorListener {
/*      */     private _MediaErrorListener() {}
/*      */     
/*      */     public void onError(Object param1Object, int param1Int, String param1String) {
/* 2623 */       MediaException mediaException = MediaException.getMediaException(param1Object, param1Int, param1String);
/*      */       
/* 2625 */       MediaPlayer.this.handleError(mediaException);
/*      */     }
/*      */   }
/*      */   
/*      */   private class _BufferListener implements BufferListener { double bufferedTime;
/*      */     
/*      */     private _BufferListener() {}
/*      */     
/*      */     public void onBufferProgress(BufferProgressEvent param1BufferProgressEvent) {
/* 2634 */       if (MediaPlayer.this.media != null)
/* 2635 */         if (param1BufferProgressEvent.getDuration() > 0.0D) {
/* 2636 */           double d1 = param1BufferProgressEvent.getBufferPosition();
/* 2637 */           double d2 = param1BufferProgressEvent.getBufferStop();
/* 2638 */           this.bufferedTime = d1 / d2 * param1BufferProgressEvent.getDuration() * 1000.0D;
/* 2639 */           MediaPlayer.this.lastBufferEvent = null;
/*      */           
/* 2641 */           Platform.runLater(() -> MediaPlayer.this.setBufferProgressTime(Duration.millis(this.bufferedTime)));
/*      */         }
/*      */         else {
/*      */           
/* 2645 */           MediaPlayer.this.lastBufferEvent = param1BufferProgressEvent;
/*      */         }  
/*      */     } }
/*      */   
/*      */   private class _SpectrumListener implements AudioSpectrumListener {
/*      */     private float[] magnitudes;
/*      */     private float[] phases;
/*      */     
/*      */     private _SpectrumListener() {}
/*      */     
/*      */     public void onAudioSpectrumEvent(AudioSpectrumEvent param1AudioSpectrumEvent) {
/* 2656 */       Platform.runLater(() -> {
/*      */             AudioSpectrumListener audioSpectrumListener = MediaPlayer.this.getAudioSpectrumListener();
/*      */             if (audioSpectrumListener != null) {
/*      */               audioSpectrumListener.spectrumDataUpdate(param1AudioSpectrumEvent.getTimestamp(), param1AudioSpectrumEvent.getDuration(), this.magnitudes = param1AudioSpectrumEvent.getSource().getMagnitudes(this.magnitudes), this.phases = param1AudioSpectrumEvent.getSource().getPhases(this.phases));
/*      */             }
/*      */           });
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public MediaPlayer(@NamedArg("media") Media paramMedia)
/*      */   {
/* 2668 */     this.renderLock = new Object(); if (null == paramMedia)
/*      */       throw new NullPointerException("media == null!");  this.media = paramMedia; this.errorListener = new _MediaErrorListener(); MediaManager.addMediaErrorListener(this.errorListener); try {
/*      */       Locator locator = paramMedia.retrieveJfxLocator(); if (locator.canBlock()) {
/*      */         InitMediaPlayer initMediaPlayer = new InitMediaPlayer(); Thread thread = new Thread(initMediaPlayer); thread.setDaemon(true);
/*      */         thread.start();
/*      */       } else {
/*      */         init();
/*      */       } 
/*      */     } catch (MediaException mediaException) {
/*      */       throw MediaException.exceptionToMediaException(mediaException);
/*      */     } catch (MediaException mediaException) {
/*      */       throw mediaException;
/* 2680 */     }  } VideoDataBuffer getLatestFrame() { synchronized (this.renderLock) {
/* 2681 */       if (null != this.currentRenderFrame) {
/* 2682 */         this.currentRenderFrame.holdFrame();
/*      */       }
/* 2684 */       return this.currentRenderFrame;
/*      */     }  }
/*      */ 
/*      */   
/*      */   private class RendererListener
/*      */     implements VideoRendererListener, TKPulseListener
/*      */   {
/*      */     boolean updateMediaViews;
/*      */     
/*      */     private RendererListener() {}
/*      */     
/*      */     public void videoFrameUpdated(NewFrameEvent param1NewFrameEvent) {
/* 2696 */       VideoDataBuffer videoDataBuffer = param1NewFrameEvent.getFrameData();
/* 2697 */       if (null != videoDataBuffer) {
/*      */         
/* 2699 */         Duration duration1 = new Duration(videoDataBuffer.getTimestamp() * 1000.0D);
/* 2700 */         Duration duration2 = MediaPlayer.this.getStopTime();
/* 2701 */         if (duration1.greaterThanOrEqualTo(MediaPlayer.this.getStartTime()) && (duration2.isUnknown() || duration1.lessThanOrEqualTo(duration2))) {
/* 2702 */           this.updateMediaViews = true;
/*      */           
/* 2704 */           synchronized (MediaPlayer.this.renderLock) {
/* 2705 */             videoDataBuffer.holdFrame();
/*      */ 
/*      */             
/* 2708 */             if (null != MediaPlayer.this.nextRenderFrame) {
/* 2709 */               MediaPlayer.this.nextRenderFrame.releaseFrame();
/*      */             }
/* 2711 */             MediaPlayer.this.nextRenderFrame = videoDataBuffer;
/*      */           } 
/*      */           
/* 2714 */           Toolkit.getToolkit().requestNextPulse();
/*      */         } else {
/* 2716 */           videoDataBuffer.releaseFrame();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void releaseVideoFrames() {
/* 2723 */       synchronized (MediaPlayer.this.renderLock) {
/* 2724 */         if (null != MediaPlayer.this.currentRenderFrame) {
/* 2725 */           MediaPlayer.this.currentRenderFrame.releaseFrame();
/* 2726 */           MediaPlayer.this.currentRenderFrame = null;
/*      */         } 
/*      */         
/* 2729 */         if (null != MediaPlayer.this.nextRenderFrame) {
/* 2730 */           MediaPlayer.this.nextRenderFrame.releaseFrame();
/* 2731 */           MediaPlayer.this.nextRenderFrame = null;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void pulse() {
/* 2738 */       if (this.updateMediaViews) {
/* 2739 */         this.updateMediaViews = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2745 */         synchronized (MediaPlayer.this.renderLock) {
/* 2746 */           if (null != MediaPlayer.this.nextRenderFrame) {
/* 2747 */             if (null != MediaPlayer.this.currentRenderFrame) {
/* 2748 */               MediaPlayer.this.currentRenderFrame.releaseFrame();
/*      */             }
/* 2750 */             MediaPlayer.this.currentRenderFrame = MediaPlayer.this.nextRenderFrame;
/* 2751 */             MediaPlayer.this.nextRenderFrame = null;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 2756 */         synchronized (MediaPlayer.this.viewRefs) {
/* 2757 */           Iterator<WeakReference<MediaView>> iterator = MediaPlayer.this.viewRefs.iterator();
/* 2758 */           while (iterator.hasNext()) {
/* 2759 */             MediaView mediaView = ((WeakReference<MediaView>)iterator.next()).get();
/* 2760 */             if (null != mediaView) {
/* 2761 */               mediaView.notifyMediaFrameUpdated(); continue;
/*      */             } 
/* 2763 */             iterator.remove();
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\javafx\scene\media\MediaPlayer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */