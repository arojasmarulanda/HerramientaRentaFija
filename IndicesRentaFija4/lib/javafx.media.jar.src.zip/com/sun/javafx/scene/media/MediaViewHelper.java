/*    */ package com.sun.javafx.scene.media;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.scene.NodeHelper;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.media.MediaView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaViewHelper
/*    */   extends NodeHelper
/*    */ {
/* 45 */   private static final MediaViewHelper theInstance = new MediaViewHelper(); static {
/* 46 */     Utils.forceInit(MediaView.class);
/*    */   }
/*    */   private static MediaViewAccessor mediaViewAccessor;
/*    */   private static MediaViewHelper getInstance() {
/* 50 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(MediaView paramMediaView) {
/* 54 */     setHelper(paramMediaView, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 59 */     return mediaViewAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 64 */     super.updatePeerImpl(paramNode);
/* 65 */     mediaViewAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */   
/*    */   protected void transformsChangedImpl(Node paramNode) {
/* 69 */     super.transformsChangedImpl(paramNode);
/* 70 */     mediaViewAccessor.doTransformsChanged(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 76 */     return mediaViewAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/* 81 */     return mediaViewAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*    */   }
/*    */   
/*    */   public static void setMediaViewAccessor(MediaViewAccessor paramMediaViewAccessor) {
/* 85 */     if (mediaViewAccessor != null) {
/* 86 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 89 */     mediaViewAccessor = paramMediaViewAccessor;
/*    */   }
/*    */   
/*    */   public static interface MediaViewAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     void doTransformsChanged(Node param1Node);
/*    */     
/*    */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\javafx\scene\media\MediaViewHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */