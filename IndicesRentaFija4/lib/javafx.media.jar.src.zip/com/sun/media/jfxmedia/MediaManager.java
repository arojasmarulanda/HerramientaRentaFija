/*     */ package com.sun.media.jfxmedia;
/*     */ 
/*     */ import com.sun.media.jfxmedia.events.MediaErrorListener;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmediaimpl.NativeMediaManager;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaManager
/*     */ {
/*     */   public static String[] getSupportedContentTypes() {
/*  50 */     return NativeMediaManager.getDefaultInstance().getSupportedContentTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canPlayContentType(String paramString) {
/*  61 */     if (paramString == null) {
/*  62 */       throw new IllegalArgumentException("contentType == null!");
/*     */     }
/*  64 */     return NativeMediaManager.getDefaultInstance().canPlayContentType(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canPlayProtocol(String paramString) {
/*  75 */     if (paramString == null) {
/*  76 */       throw new IllegalArgumentException("protocol == null!");
/*     */     }
/*  78 */     return NativeMediaManager.getDefaultInstance().canPlayProtocol(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MetadataParser getMetadataParser(Locator paramLocator) {
/*  84 */     if (paramLocator == null) {
/*  85 */       throw new IllegalArgumentException("locator == null!");
/*     */     }
/*  87 */     NativeMediaManager.getDefaultInstance(); return NativeMediaManager.getMetadataParser(paramLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Media getMedia(Locator paramLocator) {
/* 100 */     if (paramLocator == null) {
/* 101 */       throw new IllegalArgumentException("locator == null!");
/*     */     }
/* 103 */     return NativeMediaManager.getDefaultInstance().getMedia(paramLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MediaPlayer getPlayer(Locator paramLocator) {
/* 115 */     if (paramLocator == null) {
/* 116 */       throw new IllegalArgumentException("locator == null!");
/*     */     }
/* 118 */     return NativeMediaManager.getDefaultInstance().getPlayer(paramLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addMediaErrorListener(MediaErrorListener paramMediaErrorListener) {
/* 130 */     if (paramMediaErrorListener == null) {
/* 131 */       throw new IllegalArgumentException("listener == null!");
/*     */     }
/* 133 */     NativeMediaManager.getDefaultInstance().addMediaErrorListener(paramMediaErrorListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeMediaErrorListener(MediaErrorListener paramMediaErrorListener) {
/* 144 */     if (paramMediaErrorListener == null) {
/* 145 */       throw new IllegalArgumentException("listener == null!");
/*     */     }
/* 147 */     NativeMediaManager.getDefaultInstance().removeMediaErrorListener(paramMediaErrorListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerMediaPlayerForDispose(Object paramObject, MediaPlayer paramMediaPlayer) {
/* 158 */     NativeMediaManager.registerMediaPlayerForDispose(paramObject, paramMediaPlayer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<MediaPlayer> getAllMediaPlayers() {
/* 166 */     return NativeMediaManager.getDefaultInstance().getAllMediaPlayers();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\MediaManager.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */