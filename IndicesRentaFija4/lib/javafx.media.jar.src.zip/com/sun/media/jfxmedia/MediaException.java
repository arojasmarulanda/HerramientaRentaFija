/*    */ package com.sun.media.jfxmedia;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 14L;
/* 35 */   private MediaError error = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MediaException(String paramString) {
/* 45 */     super(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MediaException(String paramString, Throwable paramThrowable) {
/* 57 */     super(paramString, paramThrowable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MediaException(String paramString, Throwable paramThrowable, MediaError paramMediaError) {
/* 70 */     super(paramString, paramThrowable);
/* 71 */     this.error = paramMediaError;
/*    */   }
/*    */   
/*    */   public MediaError getMediaError() {
/* 75 */     return this.error;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\MediaException.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */