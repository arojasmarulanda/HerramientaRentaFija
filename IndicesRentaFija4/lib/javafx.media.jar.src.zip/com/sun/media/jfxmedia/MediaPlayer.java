package com.sun.media.jfxmedia;

import com.sun.media.jfxmedia.control.MediaPlayerOverlay;
import com.sun.media.jfxmedia.control.VideoRenderControl;
import com.sun.media.jfxmedia.effects.AudioEqualizer;
import com.sun.media.jfxmedia.effects.AudioSpectrum;
import com.sun.media.jfxmedia.events.AudioSpectrumListener;
import com.sun.media.jfxmedia.events.BufferListener;
import com.sun.media.jfxmedia.events.MarkerListener;
import com.sun.media.jfxmedia.events.MediaErrorListener;
import com.sun.media.jfxmedia.events.PlayerStateEvent;
import com.sun.media.jfxmedia.events.PlayerStateListener;
import com.sun.media.jfxmedia.events.PlayerTimeListener;
import com.sun.media.jfxmedia.events.VideoTrackSizeListener;

public interface MediaPlayer {
  void addMediaErrorListener(MediaErrorListener paramMediaErrorListener);
  
  void removeMediaErrorListener(MediaErrorListener paramMediaErrorListener);
  
  void addMediaPlayerListener(PlayerStateListener paramPlayerStateListener);
  
  void removeMediaPlayerListener(PlayerStateListener paramPlayerStateListener);
  
  void addMediaTimeListener(PlayerTimeListener paramPlayerTimeListener);
  
  void removeMediaTimeListener(PlayerTimeListener paramPlayerTimeListener);
  
  void addVideoTrackSizeListener(VideoTrackSizeListener paramVideoTrackSizeListener);
  
  void removeVideoTrackSizeListener(VideoTrackSizeListener paramVideoTrackSizeListener);
  
  void addMarkerListener(MarkerListener paramMarkerListener);
  
  void removeMarkerListener(MarkerListener paramMarkerListener);
  
  void addBufferListener(BufferListener paramBufferListener);
  
  void removeBufferListener(BufferListener paramBufferListener);
  
  void addAudioSpectrumListener(AudioSpectrumListener paramAudioSpectrumListener);
  
  void removeAudioSpectrumListener(AudioSpectrumListener paramAudioSpectrumListener);
  
  VideoRenderControl getVideoRenderControl();
  
  MediaPlayerOverlay getMediaPlayerOverlay();
  
  Media getMedia();
  
  void setAudioSyncDelay(long paramLong);
  
  long getAudioSyncDelay();
  
  void play();
  
  void stop();
  
  void pause();
  
  float getRate();
  
  void setRate(float paramFloat);
  
  double getPresentationTime();
  
  float getVolume();
  
  void setVolume(float paramFloat);
  
  boolean getMute();
  
  void setMute(boolean paramBoolean);
  
  float getBalance();
  
  void setBalance(float paramFloat);
  
  AudioEqualizer getEqualizer();
  
  AudioSpectrum getAudioSpectrum();
  
  double getDuration();
  
  double getStartTime();
  
  void setStartTime(double paramDouble);
  
  double getStopTime();
  
  void setStopTime(double paramDouble);
  
  void seek(double paramDouble);
  
  PlayerStateEvent.PlayerState getState();
  
  void dispose();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\MediaPlayer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */