package com.sun.media.jfxmedia.events;

import java.util.Map;

public interface MetadataListener {
  void onMetadata(Map<String, Object> paramMap);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\events\MetadataListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */