package com.sun.media.jfxmedia.events;

public interface MediaErrorListener {
  void onError(Object paramObject, int paramInt, String paramString);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\events\MediaErrorListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */