package com.sun.media.jfxmedia.events;

public interface BufferListener {
  void onBufferProgress(BufferProgressEvent paramBufferProgressEvent);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\events\BufferListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */