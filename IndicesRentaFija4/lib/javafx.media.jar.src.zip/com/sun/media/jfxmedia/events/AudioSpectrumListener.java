package com.sun.media.jfxmedia.events;

public interface AudioSpectrumListener {
  void onAudioSpectrumEvent(AudioSpectrumEvent paramAudioSpectrumEvent);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\events\AudioSpectrumListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */