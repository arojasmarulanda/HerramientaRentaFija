package com.sun.media.jfxmedia.events;

public interface MarkerListener {
  void onMarker(MarkerEvent paramMarkerEvent);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\events\MarkerListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */