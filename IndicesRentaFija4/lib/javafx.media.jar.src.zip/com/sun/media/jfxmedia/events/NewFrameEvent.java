/*    */ package com.sun.media.jfxmedia.events;
/*    */ 
/*    */ import com.sun.media.jfxmedia.control.VideoDataBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewFrameEvent
/*    */   extends PlayerEvent
/*    */ {
/*    */   private VideoDataBuffer frameData;
/*    */   
/*    */   public NewFrameEvent(VideoDataBuffer paramVideoDataBuffer) {
/* 44 */     if (paramVideoDataBuffer == null) {
/* 45 */       throw new IllegalArgumentException("buffer == null!");
/*    */     }
/* 47 */     this.frameData = paramVideoDataBuffer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VideoDataBuffer getFrameData() {
/* 56 */     return this.frameData;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\events\NewFrameEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */