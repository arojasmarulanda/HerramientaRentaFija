/*    */ package com.sun.media.jfxmedia.track;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubtitleTrack
/*    */   extends Track
/*    */ {
/*    */   public SubtitleTrack(boolean paramBoolean, long paramLong, String paramString, Locale paramLocale, Track.Encoding paramEncoding) {
/* 35 */     super(paramBoolean, paramLong, paramString, paramLocale, paramEncoding);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\track\SubtitleTrack.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */