/*     */ package com.sun.media.jfxmedia.track;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Track
/*     */ {
/*     */   private boolean trackEnabled;
/*     */   private long trackID;
/*     */   private String name;
/*     */   private Locale locale;
/*     */   private Encoding encoding;
/*     */   
/*     */   public enum Encoding
/*     */   {
/*  38 */     NONE,
/*     */ 
/*     */     
/*  41 */     PCM,
/*  42 */     MPEG1AUDIO,
/*  43 */     MPEG1LAYER3,
/*  44 */     AAC,
/*     */ 
/*     */     
/*  47 */     H264,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  52 */     CUSTOM;
/*     */     
/*     */     public static Encoding toEncoding(int param1Int) {
/*  55 */       for (Encoding encoding : values()) {
/*  56 */         if (encoding.ordinal() == param1Int) {
/*  57 */           return encoding;
/*     */         }
/*     */       } 
/*  60 */       return NONE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Track(boolean paramBoolean, long paramLong, String paramString, Locale paramLocale, Encoding paramEncoding) {
/*  83 */     if (paramString == null)
/*  84 */       throw new IllegalArgumentException("name == null!"); 
/*  85 */     if (paramEncoding == null) {
/*  86 */       throw new IllegalArgumentException("encoding == null!");
/*     */     }
/*     */     
/*  89 */     this.trackEnabled = paramBoolean;
/*  90 */     this.trackID = paramLong;
/*  91 */     this.locale = paramLocale;
/*  92 */     this.encoding = paramEncoding;
/*  93 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Encoding getEncodingType() {
/* 103 */     return this.encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 113 */     return this.name;
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 117 */     return this.locale;
/*     */   }
/*     */   
/*     */   public long getTrackID() {
/* 121 */     return this.trackID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 131 */     return this.trackEnabled;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\track\Track.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */