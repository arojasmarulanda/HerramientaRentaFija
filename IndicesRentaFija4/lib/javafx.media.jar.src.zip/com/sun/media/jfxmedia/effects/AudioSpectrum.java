package com.sun.media.jfxmedia.effects;

public interface AudioSpectrum {
  boolean getEnabled();
  
  void setEnabled(boolean paramBoolean);
  
  int getBandCount();
  
  void setBandCount(int paramInt);
  
  double getInterval();
  
  void setInterval(double paramDouble);
  
  int getSensitivityThreshold();
  
  void setSensitivityThreshold(int paramInt);
  
  float[] getMagnitudes(float[] paramArrayOffloat);
  
  float[] getPhases(float[] paramArrayOffloat);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\effects\AudioSpectrum.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */