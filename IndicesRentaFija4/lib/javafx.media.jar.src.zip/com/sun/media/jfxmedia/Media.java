/*     */ package com.sun.media.jfxmedia;
/*     */ 
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.track.Track;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Media
/*     */ {
/*     */   private Locator locator;
/*  44 */   private final List<Track> tracks = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Media(Locator paramLocator) {
/*  54 */     if (paramLocator == null) {
/*  55 */       throw new IllegalArgumentException("locator == null!");
/*     */     }
/*     */     
/*  58 */     this.locator = paramLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void addMarker(String paramString, double paramDouble);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract double removeMarker(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void removeAllMarkers();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Track> getTracks() {
/*     */     List<?> list;
/*  97 */     synchronized (this.tracks) {
/*  98 */       if (this.tracks.isEmpty()) {
/*  99 */         list = null;
/*     */       } else {
/* 101 */         list = Collections.unmodifiableList(new ArrayList(this.tracks));
/*     */       } 
/*     */     } 
/* 104 */     return (List)list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Map<String, Double> getMarkers();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Locator getLocator() {
/* 121 */     return this.locator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addTrack(Track paramTrack) {
/* 130 */     if (paramTrack == null) {
/* 131 */       throw new IllegalArgumentException("track == null!");
/*     */     }
/* 133 */     synchronized (this.tracks) {
/* 134 */       this.tracks.add(paramTrack);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 142 */     if (this.tracks != null && !this.tracks.isEmpty()) {
/* 143 */       for (Track track : this.tracks) {
/* 144 */         stringBuffer.append(track);
/* 145 */         stringBuffer.append("\n");
/*     */       } 
/*     */     }
/*     */     
/* 149 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\Media.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */