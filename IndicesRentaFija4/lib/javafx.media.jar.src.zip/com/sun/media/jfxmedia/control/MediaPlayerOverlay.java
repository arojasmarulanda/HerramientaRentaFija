package com.sun.media.jfxmedia.control;

public interface MediaPlayerOverlay {
  void setOverlayX(double paramDouble);
  
  void setOverlayY(double paramDouble);
  
  void setOverlayVisible(boolean paramBoolean);
  
  void setOverlayWidth(double paramDouble);
  
  void setOverlayHeight(double paramDouble);
  
  void setOverlayPreserveRatio(boolean paramBoolean);
  
  void setOverlayOpacity(double paramDouble);
  
  void setOverlayTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\control\MediaPlayerOverlay.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */