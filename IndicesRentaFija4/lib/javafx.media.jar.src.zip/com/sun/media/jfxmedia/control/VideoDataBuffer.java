package com.sun.media.jfxmedia.control;

import java.nio.ByteBuffer;

public interface VideoDataBuffer {
  public static final int PACKED_FORMAT_PLANE = 0;
  
  public static final int YCBCR_PLANE_LUMA = 0;
  
  public static final int YCBCR_PLANE_CR = 1;
  
  public static final int YCBCR_PLANE_CB = 2;
  
  public static final int YCBCR_PLANE_ALPHA = 3;
  
  ByteBuffer getBufferForPlane(int paramInt);
  
  double getTimestamp();
  
  int getWidth();
  
  int getHeight();
  
  int getEncodedWidth();
  
  int getEncodedHeight();
  
  VideoFormat getFormat();
  
  boolean hasAlpha();
  
  int getPlaneCount();
  
  int getStrideForPlane(int paramInt);
  
  int[] getPlaneStrides();
  
  VideoDataBuffer convertToFormat(VideoFormat paramVideoFormat);
  
  void setDirty();
  
  void holdFrame();
  
  void releaseFrame();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\control\VideoDataBuffer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */