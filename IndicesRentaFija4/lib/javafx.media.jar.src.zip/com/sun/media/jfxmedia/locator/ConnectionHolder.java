/*     */ package com.sun.media.jfxmedia.locator;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.Channels;
/*     */ import java.nio.channels.ClosedChannelException;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConnectionHolder
/*     */ {
/*  48 */   private static int DEFAULT_BUFFER_SIZE = 4096;
/*     */   
/*     */   ReadableByteChannel channel;
/*  51 */   ByteBuffer buffer = ByteBuffer.allocateDirect(DEFAULT_BUFFER_SIZE);
/*     */   
/*     */   static ConnectionHolder createMemoryConnectionHolder(ByteBuffer paramByteBuffer) {
/*  54 */     return new MemoryConnectionHolder(paramByteBuffer);
/*     */   }
/*     */   
/*     */   static ConnectionHolder createURIConnectionHolder(URI paramURI, Map<String, Object> paramMap) throws IOException {
/*  58 */     return new URIConnectionHolder(paramURI, paramMap);
/*     */   }
/*     */   
/*     */   static ConnectionHolder createFileConnectionHolder(URI paramURI) throws IOException {
/*  62 */     return new FileConnectionHolder(paramURI);
/*     */   }
/*     */   
/*     */   static ConnectionHolder createHLSConnectionHolder(URI paramURI) throws IOException {
/*  66 */     return new HLSConnectionHolder(paramURI);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readNextBlock() throws IOException {
/*  79 */     this.buffer.rewind();
/*  80 */     if (this.buffer.limit() < this.buffer.capacity()) {
/*  81 */       this.buffer.limit(this.buffer.capacity());
/*     */     }
/*     */     
/*  84 */     if (null == this.channel) {
/*  85 */       throw new ClosedChannelException();
/*     */     }
/*  87 */     return this.channel.read(this.buffer);
/*     */   }
/*     */   
/*     */   public ByteBuffer getBuffer() {
/*  91 */     return this.buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeConnection() {
/*     */     
/* 140 */     try { if (this.channel != null) {
/* 141 */         this.channel.close();
/*     */       } }
/* 143 */     catch (IOException iOException) {  }
/*     */     finally
/* 145 */     { this.channel = null; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int property(int paramInt1, int paramInt2) {
/* 157 */     return 0;
/*     */   }
/*     */   abstract int readBlock(long paramLong, int paramInt) throws IOException;
/*     */   abstract boolean needBuffer();
/*     */   abstract boolean isSeekable();
/*     */   
/*     */   abstract boolean isRandomAccess();
/*     */   
/*     */   public abstract long seek(long paramLong);
/*     */   
/*     */   int getStreamSize() {
/* 168 */     return -1;
/*     */   }
/*     */   
/*     */   private static class FileConnectionHolder extends ConnectionHolder {
/* 172 */     private RandomAccessFile file = null;
/*     */     
/*     */     FileConnectionHolder(URI param1URI) throws IOException {
/* 175 */       this.channel = openFile(param1URI);
/*     */     }
/*     */     
/*     */     boolean needBuffer() {
/* 179 */       return false;
/*     */     }
/*     */     
/*     */     boolean isRandomAccess() {
/* 183 */       return true;
/*     */     }
/*     */     
/*     */     boolean isSeekable() {
/* 187 */       return true;
/*     */     }
/*     */     
/*     */     public long seek(long param1Long) {
/*     */       try {
/* 192 */         ((FileChannel)this.channel).position(param1Long);
/* 193 */         return param1Long;
/* 194 */       } catch (IOException iOException) {
/* 195 */         return -1L;
/*     */       } 
/*     */     }
/*     */     
/*     */     int readBlock(long param1Long, int param1Int) throws IOException {
/* 200 */       if (null == this.channel) {
/* 201 */         throw new ClosedChannelException();
/*     */       }
/*     */       
/* 204 */       if (this.buffer.capacity() < param1Int) {
/* 205 */         this.buffer = ByteBuffer.allocateDirect(param1Int);
/*     */       }
/* 207 */       this.buffer.rewind().limit(param1Int);
/* 208 */       return ((FileChannel)this.channel).read(this.buffer, param1Long);
/*     */     }
/*     */     
/*     */     private ReadableByteChannel openFile(URI param1URI) throws IOException {
/* 212 */       if (this.file != null) {
/* 213 */         this.file.close();
/*     */       }
/*     */       
/* 216 */       this.file = new RandomAccessFile(new File(param1URI), "r");
/* 217 */       return this.file.getChannel();
/*     */     }
/*     */ 
/*     */     
/*     */     public void closeConnection() {
/* 222 */       super.closeConnection();
/*     */       
/* 224 */       if (this.file != null)
/*     */         
/* 226 */         try { this.file.close(); }
/* 227 */         catch (IOException iOException) {  }
/*     */         finally
/* 229 */         { this.file = null; }
/*     */          
/*     */     }
/*     */   }
/*     */   
/*     */   private static class URIConnectionHolder
/*     */     extends ConnectionHolder {
/*     */     private URI uri;
/*     */     private URLConnection urlConnection;
/*     */     
/*     */     URIConnectionHolder(URI param1URI, Map<String, Object> param1Map) throws IOException {
/* 240 */       this.uri = param1URI;
/* 241 */       this.urlConnection = param1URI.toURL().openConnection();
/* 242 */       if (param1Map != null) {
/* 243 */         for (Map.Entry<String, Object> entry : param1Map.entrySet()) {
/* 244 */           Object object = entry.getValue();
/* 245 */           if (object instanceof String) {
/* 246 */             this.urlConnection.setRequestProperty((String)entry.getKey(), (String)object);
/*     */           }
/*     */         } 
/*     */       }
/* 250 */       this.channel = openChannel(null);
/*     */     }
/*     */     
/*     */     boolean needBuffer() {
/* 254 */       String str = this.uri.getScheme().toLowerCase();
/* 255 */       return ("http".equals(str) || "https".equals(str));
/*     */     }
/*     */     
/*     */     boolean isSeekable() {
/* 259 */       return (this.urlConnection instanceof HttpURLConnection || this.urlConnection instanceof java.net.JarURLConnection);
/*     */     }
/*     */     
/*     */     boolean isRandomAccess() {
/* 263 */       return false;
/*     */     }
/*     */     
/*     */     int readBlock(long param1Long, int param1Int) throws IOException {
/* 267 */       throw new IOException();
/*     */     }
/*     */     
/*     */     public long seek(long param1Long) {
/* 271 */       if (this.urlConnection instanceof HttpURLConnection) {
/* 272 */         URLConnection uRLConnection = null;
/*     */ 
/*     */         
/*     */         try {
/* 276 */           uRLConnection = this.uri.toURL().openConnection();
/*     */           
/* 278 */           HttpURLConnection httpURLConnection = (HttpURLConnection)uRLConnection;
/* 279 */           httpURLConnection.setRequestMethod("GET");
/* 280 */           httpURLConnection.setUseCaches(false);
/* 281 */           httpURLConnection.setRequestProperty("Range", "bytes=" + param1Long + "-");
/*     */ 
/*     */           
/* 284 */           if (httpURLConnection.getResponseCode() == 206) {
/* 285 */             closeConnection();
/* 286 */             this.urlConnection = uRLConnection;
/* 287 */             uRLConnection = null;
/* 288 */             this.channel = openChannel(null);
/* 289 */             return param1Long;
/*     */           } 
/* 291 */           return -1L;
/*     */         }
/* 293 */         catch (IOException iOException) {
/* 294 */           return -1L;
/*     */         } finally {
/* 296 */           if (uRLConnection != null)
/* 297 */             Locator.closeConnection(uRLConnection); 
/*     */         } 
/*     */       } 
/* 300 */       if (this.urlConnection instanceof java.net.JarURLConnection) {
/*     */         try {
/* 302 */           closeConnection();
/*     */           
/* 304 */           this.urlConnection = this.uri.toURL().openConnection();
/*     */ 
/*     */           
/* 307 */           long l = param1Long;
/* 308 */           InputStream inputStream = this.urlConnection.getInputStream();
/*     */           do {
/* 310 */             long l1 = inputStream.skip(l);
/* 311 */             l -= l1;
/* 312 */           } while (l > 0L);
/*     */           
/* 314 */           this.channel = openChannel(inputStream);
/*     */           
/* 316 */           return param1Long;
/* 317 */         } catch (IOException iOException) {
/* 318 */           return -1L;
/*     */         } 
/*     */       }
/*     */       
/* 322 */       return -1L;
/*     */     }
/*     */ 
/*     */     
/*     */     public void closeConnection() {
/* 327 */       super.closeConnection();
/*     */       
/* 329 */       Locator.closeConnection(this.urlConnection);
/* 330 */       this.urlConnection = null;
/*     */     }
/*     */     
/*     */     private ReadableByteChannel openChannel(InputStream param1InputStream) throws IOException {
/* 334 */       return (param1InputStream == null) ? 
/* 335 */         Channels.newChannel(this.urlConnection.getInputStream()) : 
/* 336 */         Channels.newChannel(param1InputStream);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class MemoryConnectionHolder
/*     */     extends ConnectionHolder
/*     */   {
/*     */     private final ByteBuffer backingBuffer;
/*     */     
/*     */     public MemoryConnectionHolder(ByteBuffer param1ByteBuffer) {
/* 346 */       if (null == param1ByteBuffer) {
/* 347 */         throw new IllegalArgumentException("Can't connect to null buffer...");
/*     */       }
/*     */       
/* 350 */       if (param1ByteBuffer.isDirect()) {
/*     */         
/* 352 */         this.backingBuffer = param1ByteBuffer.duplicate();
/*     */       } else {
/*     */         
/* 355 */         this.backingBuffer = ByteBuffer.allocateDirect(param1ByteBuffer.capacity());
/* 356 */         this.backingBuffer.put(param1ByteBuffer);
/*     */       } 
/*     */ 
/*     */       
/* 360 */       this.backingBuffer.rewind();
/*     */ 
/*     */ 
/*     */       
/* 364 */       this.channel = new ReadableByteChannel() { public int read(ByteBuffer param2ByteBuffer) throws IOException {
/*     */             int i;
/* 366 */             if (ConnectionHolder.MemoryConnectionHolder.this.backingBuffer.remaining() <= 0) {
/* 367 */               return -1;
/*     */             }
/*     */ 
/*     */             
/* 371 */             if (param2ByteBuffer.equals(ConnectionHolder.MemoryConnectionHolder.this.buffer)) {
/*     */ 
/*     */               
/* 374 */               i = Math.min(ConnectionHolder.DEFAULT_BUFFER_SIZE, ConnectionHolder.MemoryConnectionHolder.this.backingBuffer.remaining());
/* 375 */               if (i > 0) {
/* 376 */                 ConnectionHolder.MemoryConnectionHolder.this.buffer = ConnectionHolder.MemoryConnectionHolder.this.backingBuffer.slice();
/* 377 */                 ConnectionHolder.MemoryConnectionHolder.this.buffer.limit(i);
/*     */               } 
/*     */             } else {
/* 380 */               i = Math.min(param2ByteBuffer.remaining(), ConnectionHolder.MemoryConnectionHolder.this.backingBuffer.remaining());
/* 381 */               if (i > 0) {
/* 382 */                 ConnectionHolder.MemoryConnectionHolder.this.backingBuffer.limit(ConnectionHolder.MemoryConnectionHolder.this.backingBuffer.position() + i);
/* 383 */                 param2ByteBuffer.put(ConnectionHolder.MemoryConnectionHolder.this.backingBuffer);
/* 384 */                 ConnectionHolder.MemoryConnectionHolder.this.backingBuffer.limit(ConnectionHolder.MemoryConnectionHolder.this.backingBuffer.capacity());
/*     */               } 
/*     */             } 
/* 387 */             return i;
/*     */           }
/*     */           
/*     */           public boolean isOpen() {
/* 391 */             return true;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void close() throws IOException {} }
/*     */         ;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     int readBlock(long param1Long, int param1Int) throws IOException {
/* 403 */       if (null == this.channel) {
/* 404 */         throw new ClosedChannelException();
/*     */       }
/*     */       
/* 407 */       if ((int)param1Long > this.backingBuffer.capacity()) {
/* 408 */         return -1;
/*     */       }
/* 410 */       this.backingBuffer.position((int)param1Long);
/*     */       
/* 412 */       this.buffer = this.backingBuffer.slice();
/*     */       
/* 414 */       int i = Math.min(this.backingBuffer.remaining(), param1Int);
/* 415 */       this.buffer.limit(i);
/* 416 */       this.backingBuffer.position(this.backingBuffer.position() + i);
/*     */       
/* 418 */       return i;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean needBuffer() {
/* 423 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isSeekable() {
/* 428 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean isRandomAccess() {
/* 433 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public long seek(long param1Long) {
/* 438 */       if ((int)param1Long < this.backingBuffer.capacity()) {
/* 439 */         this.backingBuffer.limit(this.backingBuffer.capacity());
/* 440 */         this.backingBuffer.position((int)param1Long);
/* 441 */         return param1Long;
/*     */       } 
/* 443 */       return -1L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void closeConnection() {
/* 449 */       this.channel = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\locator\ConnectionHolder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */