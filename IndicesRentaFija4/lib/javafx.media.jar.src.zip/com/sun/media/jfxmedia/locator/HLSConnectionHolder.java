/*     */ package com.sun.media.jfxmedia.locator;
/*     */ 
/*     */ import com.sun.media.jfxmedia.MediaError;
/*     */ import com.sun.media.jfxmediaimpl.MediaUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.channels.Channels;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.Semaphore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HLSConnectionHolder
/*     */   extends ConnectionHolder
/*     */ {
/*  45 */   private URLConnection urlConnection = null;
/*  46 */   private PlaylistThread playlistThread = new PlaylistThread();
/*  47 */   private VariantPlaylist variantPlaylist = null;
/*  48 */   private Playlist currentPlaylist = null;
/*  49 */   private int mediaFileIndex = -1;
/*  50 */   private CountDownLatch readySignal = new CountDownLatch(1);
/*  51 */   private Semaphore liveSemaphore = new Semaphore(0);
/*     */   private boolean isPlaylistClosed = false;
/*     */   private boolean isBitrateAdjustable = false;
/*  54 */   private long startTime = -1L;
/*     */   private static final long HLS_VALUE_FLOAT_MULTIPLIER = 1000L;
/*     */   private static final int HLS_PROP_GET_DURATION = 1;
/*     */   private static final int HLS_PROP_GET_HLS_MODE = 2;
/*     */   private static final int HLS_PROP_GET_MIMETYPE = 3;
/*     */   private static final int HLS_VALUE_MIMETYPE_MP2T = 1;
/*     */   private static final int HLS_VALUE_MIMETYPE_MP3 = 2;
/*     */   private static final String CHARSET_UTF_8 = "UTF-8";
/*     */   private static final String CHARSET_US_ASCII = "US-ASCII";
/*     */   
/*     */   HLSConnectionHolder(URI paramURI) throws IOException {
/*  65 */     this.playlistThread.setPlaylistURI(paramURI);
/*  66 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  70 */     this.playlistThread.putState(0);
/*  71 */     this.playlistThread.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public int readNextBlock() throws IOException {
/*  76 */     if (this.isBitrateAdjustable && this.startTime == -1L) {
/*  77 */       this.startTime = System.currentTimeMillis();
/*     */     }
/*     */     
/*  80 */     int i = super.readNextBlock();
/*  81 */     if (this.isBitrateAdjustable && i == -1) {
/*  82 */       long l = System.currentTimeMillis() - this.startTime;
/*  83 */       this.startTime = -1L;
/*  84 */       adjustBitrate(l);
/*     */     } 
/*     */     
/*  87 */     return i;
/*     */   }
/*     */   
/*     */   int readBlock(long paramLong, int paramInt) throws IOException {
/*  91 */     throw new IOException();
/*     */   }
/*     */   
/*     */   boolean needBuffer() {
/*  95 */     return true;
/*     */   }
/*     */   
/*     */   boolean isSeekable() {
/*  99 */     return true;
/*     */   }
/*     */   
/*     */   boolean isRandomAccess() {
/* 103 */     return false;
/*     */   }
/*     */   
/*     */   public long seek(long paramLong) {
/*     */     try {
/* 108 */       this.readySignal.await();
/* 109 */     } catch (Exception exception) {
/* 110 */       return -1L;
/*     */     } 
/*     */     
/* 113 */     return (long)(this.currentPlaylist.seek(paramLong) * 1000.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeConnection() {
/* 118 */     this.currentPlaylist.close();
/* 119 */     super.closeConnection();
/* 120 */     resetConnection();
/* 121 */     this.playlistThread.putState(1);
/*     */   }
/*     */ 
/*     */   
/*     */   int property(int paramInt1, int paramInt2) {
/*     */     try {
/* 127 */       this.readySignal.await();
/* 128 */     } catch (Exception exception) {
/* 129 */       return -1;
/*     */     } 
/*     */     
/* 132 */     if (paramInt1 == 1)
/* 133 */       return (int)(this.currentPlaylist.getDuration() * 1000.0D); 
/* 134 */     if (paramInt1 == 2)
/* 135 */       return 1; 
/* 136 */     if (paramInt1 == 3) {
/* 137 */       return this.currentPlaylist.getMimeType();
/*     */     }
/*     */     
/* 140 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   int getStreamSize() {
/*     */     try {
/* 146 */       this.readySignal.await();
/* 147 */     } catch (Exception exception) {
/* 148 */       return -1;
/*     */     } 
/*     */     
/* 151 */     return loadNextSegment();
/*     */   }
/*     */   
/*     */   private void resetConnection() {
/* 155 */     super.closeConnection();
/*     */     
/* 157 */     Locator.closeConnection(this.urlConnection);
/* 158 */     this.urlConnection = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int loadNextSegment() {
/* 165 */     resetConnection();
/*     */     
/* 167 */     String str = this.currentPlaylist.getNextMediaFile();
/* 168 */     if (str == null) {
/* 169 */       return -1;
/*     */     }
/*     */     
/*     */     try {
/* 173 */       URI uRI = new URI(str);
/* 174 */       this.urlConnection = uRI.toURL().openConnection();
/* 175 */       this.channel = openChannel();
/* 176 */     } catch (Exception exception) {
/* 177 */       return -1;
/*     */     } 
/*     */     
/* 180 */     if (this.currentPlaylist.isCurrentMediaFileDiscontinuity()) {
/* 181 */       return -1 * this.urlConnection.getContentLength();
/*     */     }
/* 183 */     return this.urlConnection.getContentLength();
/*     */   }
/*     */ 
/*     */   
/*     */   private ReadableByteChannel openChannel() throws IOException {
/* 188 */     return Channels.newChannel(this.urlConnection.getInputStream());
/*     */   }
/*     */   
/*     */   private void adjustBitrate(long paramLong) {
/* 192 */     int i = (int)(this.urlConnection.getContentLength() * 8L * 1000L / paramLong);
/*     */     
/* 194 */     Playlist playlist = this.variantPlaylist.getPlaylistBasedOnBitrate(i);
/* 195 */     if (playlist != null && playlist != this.currentPlaylist) {
/* 196 */       if (this.currentPlaylist.isLive()) {
/* 197 */         playlist.update(this.currentPlaylist.getNextMediaFile());
/* 198 */         this.playlistThread.setReloadPlaylist(playlist);
/*     */       } 
/*     */       
/* 201 */       playlist.setForceDiscontinuity(true);
/* 202 */       this.currentPlaylist = playlist;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String stripParameters(String paramString) {
/* 207 */     int i = paramString.indexOf('?');
/* 208 */     if (i > 0) {
/* 209 */       paramString = paramString.substring(0, i);
/*     */     }
/* 211 */     return paramString;
/*     */   }
/*     */   
/*     */   private class PlaylistThread
/*     */     extends Thread {
/*     */     public static final int STATE_INIT = 0;
/*     */     public static final int STATE_EXIT = 1;
/*     */     public static final int STATE_RELOAD_PLAYLIST = 2;
/* 219 */     private BlockingQueue<Integer> stateQueue = new LinkedBlockingQueue<>();
/* 220 */     private URI playlistURI = null;
/* 221 */     private HLSConnectionHolder.Playlist reloadPlaylist = null;
/* 222 */     private final Object reloadLock = new Object();
/*     */     private volatile boolean stopped = false;
/*     */     
/*     */     private PlaylistThread() {
/* 226 */       setName("JFXMedia HLS Playlist Thread");
/* 227 */       setDaemon(true);
/*     */     }
/*     */     
/*     */     private void setPlaylistURI(URI param1URI) {
/* 231 */       this.playlistURI = param1URI;
/*     */     }
/*     */     
/*     */     private void setReloadPlaylist(HLSConnectionHolder.Playlist param1Playlist) {
/* 235 */       synchronized (this.reloadLock) {
/* 236 */         this.reloadPlaylist = param1Playlist;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 242 */       while (!this.stopped) {
/*     */         try {
/* 244 */           int i = ((Integer)this.stateQueue.take()).intValue();
/* 245 */           switch (i) {
/*     */             case 0:
/* 247 */               stateInit();
/*     */             
/*     */             case 1:
/* 250 */               this.stopped = true;
/*     */             
/*     */             case 2:
/* 253 */               stateReloadPlaylist();
/*     */           } 
/*     */ 
/*     */ 
/*     */         
/* 258 */         } catch (Exception exception) {}
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void putState(int param1Int) {
/* 264 */       if (this.stateQueue != null) {
/*     */         try {
/* 266 */           this.stateQueue.put(Integer.valueOf(param1Int));
/* 267 */         } catch (InterruptedException interruptedException) {}
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private void stateInit() {
/* 273 */       if (this.playlistURI == null) {
/*     */         return;
/*     */       }
/*     */       
/* 277 */       HLSConnectionHolder.PlaylistParser playlistParser = new HLSConnectionHolder.PlaylistParser();
/* 278 */       playlistParser.load(this.playlistURI);
/*     */       
/* 280 */       if (playlistParser.isVariantPlaylist()) {
/* 281 */         HLSConnectionHolder.this.variantPlaylist = new HLSConnectionHolder.VariantPlaylist(this.playlistURI);
/*     */         
/* 283 */         while (playlistParser.hasNext()) {
/* 284 */           HLSConnectionHolder.this.variantPlaylist.addPlaylistInfo(playlistParser.getString(), playlistParser.getInteger().intValue());
/*     */         }
/*     */       } else {
/* 287 */         if (HLSConnectionHolder.this.currentPlaylist == null) {
/* 288 */           HLSConnectionHolder.this.currentPlaylist = new HLSConnectionHolder.Playlist(playlistParser.isLivePlaylist(), playlistParser.getTargetDuration());
/* 289 */           HLSConnectionHolder.this.currentPlaylist.setPlaylistURI(this.playlistURI);
/*     */         } 
/*     */         
/* 292 */         if (HLSConnectionHolder.this.currentPlaylist.setSequenceNumber(playlistParser.getSequenceNumber())) {
/* 293 */           while (playlistParser.hasNext()) {
/* 294 */             HLSConnectionHolder.this.currentPlaylist.addMediaFile(playlistParser.getString(), playlistParser.getDouble().doubleValue(), playlistParser.getBoolean().booleanValue());
/*     */           }
/*     */         }
/*     */         
/* 298 */         if (HLSConnectionHolder.this.variantPlaylist != null) {
/* 299 */           HLSConnectionHolder.this.variantPlaylist.addPlaylist(HLSConnectionHolder.this.currentPlaylist);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 304 */       if (HLSConnectionHolder.this.variantPlaylist != null) {
/* 305 */         while (HLSConnectionHolder.this.variantPlaylist.hasNext()) {
/*     */           
/* 307 */           try { HLSConnectionHolder.this.currentPlaylist = new HLSConnectionHolder.Playlist(HLSConnectionHolder.this.variantPlaylist.getPlaylistURI());
/* 308 */             HLSConnectionHolder.this.currentPlaylist.update(null);
/* 309 */             HLSConnectionHolder.this.variantPlaylist.addPlaylist(HLSConnectionHolder.this.currentPlaylist); }
/* 310 */           catch (URISyntaxException uRISyntaxException) {  }
/* 311 */           catch (MalformedURLException malformedURLException) {}
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 317 */       if (HLSConnectionHolder.this.variantPlaylist != null) {
/* 318 */         HLSConnectionHolder.this.currentPlaylist = HLSConnectionHolder.this.variantPlaylist.getPlaylist(0);
/* 319 */         HLSConnectionHolder.this.isBitrateAdjustable = true;
/*     */       } 
/*     */ 
/*     */       
/* 323 */       if (HLSConnectionHolder.this.currentPlaylist.isLive()) {
/* 324 */         setReloadPlaylist(HLSConnectionHolder.this.currentPlaylist);
/* 325 */         putState(2);
/*     */       } 
/*     */       
/* 328 */       HLSConnectionHolder.this.readySignal.countDown();
/*     */     }
/*     */     
/*     */     private void stateReloadPlaylist() {
/*     */       try {
/*     */         long l;
/* 334 */         synchronized (this.reloadLock) {
/* 335 */           l = this.reloadPlaylist.getTargetDuration() / 2L;
/*     */         } 
/* 337 */         Thread.sleep(l);
/* 338 */       } catch (InterruptedException interruptedException) {
/*     */         return;
/*     */       } 
/*     */       
/* 342 */       synchronized (this.reloadLock) {
/* 343 */         this.reloadPlaylist.update(null);
/*     */       } 
/*     */       
/* 346 */       putState(2);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PlaylistParser
/*     */   {
/*     */     private boolean isFirstLine = true;
/*     */     private boolean isLineMediaFileURI = false;
/*     */     private boolean isEndList = false;
/*     */     private boolean isLinePlaylistURI = false;
/*     */     private boolean isVariantPlaylist = false;
/*     */     private boolean isDiscontinuity = false;
/* 358 */     private int targetDuration = 0;
/* 359 */     private int sequenceNumber = 0;
/* 360 */     private int dataListIndex = -1;
/* 361 */     private List<String> dataListString = new ArrayList<>();
/* 362 */     private List<Integer> dataListInteger = new ArrayList<>();
/* 363 */     private List<Double> dataListDouble = new ArrayList<>();
/* 364 */     private List<Boolean> dataListBoolean = new ArrayList<>();
/*     */     
/*     */     private void load(URI param1URI) {
/* 367 */       HttpURLConnection httpURLConnection = null;
/* 368 */       BufferedReader bufferedReader = null;
/*     */       
/* 370 */       try { httpURLConnection = (HttpURLConnection)param1URI.toURL().openConnection();
/* 371 */         httpURLConnection.setRequestMethod("GET");
/*     */         
/* 373 */         if (httpURLConnection.getResponseCode() != 200) {
/* 374 */           MediaUtils.error(this, MediaError.ERROR_LOCATOR_CONNECTION_LOST.code(), "HTTP responce code: " + httpURLConnection.getResponseCode(), null);
/*     */         }
/*     */         
/* 377 */         Charset charset = getCharset(param1URI.toURL().toExternalForm(), httpURLConnection.getContentType());
/* 378 */         if (charset != null) {
/* 379 */           bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream(), charset));
/*     */         }
/*     */         
/* 382 */         if (bufferedReader != null) {
/*     */           boolean bool;
/*     */           do {
/* 385 */             bool = parseLine(bufferedReader.readLine());
/* 386 */           } while (bool);
/*     */         }  }
/* 388 */       catch (MalformedURLException malformedURLException) {  }
/* 389 */       catch (IOException iOException) {  }
/*     */       finally
/* 391 */       { if (bufferedReader != null) {
/*     */           try {
/* 393 */             bufferedReader.close();
/* 394 */           } catch (IOException iOException) {}
/*     */           
/* 396 */           Locator.closeConnection(httpURLConnection);
/*     */         }  }
/*     */     
/*     */     }
/*     */     
/*     */     private boolean isVariantPlaylist() {
/* 402 */       return this.isVariantPlaylist;
/*     */     }
/*     */     
/*     */     private boolean isLivePlaylist() {
/* 406 */       return !this.isEndList;
/*     */     }
/*     */     
/*     */     private int getTargetDuration() {
/* 410 */       return this.targetDuration;
/*     */     }
/*     */     
/*     */     private int getSequenceNumber() {
/* 414 */       return this.sequenceNumber;
/*     */     }
/*     */     
/*     */     private boolean hasNext() {
/* 418 */       this.dataListIndex++;
/* 419 */       if (this.dataListString.size() > this.dataListIndex || this.dataListInteger.size() > this.dataListIndex || this.dataListDouble.size() > this.dataListIndex || this.dataListBoolean.size() > this.dataListIndex) {
/* 420 */         return true;
/*     */       }
/* 422 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     private String getString() {
/* 427 */       return this.dataListString.get(this.dataListIndex);
/*     */     }
/*     */     
/*     */     private Integer getInteger() {
/* 431 */       return this.dataListInteger.get(this.dataListIndex);
/*     */     }
/*     */     
/*     */     private Double getDouble() {
/* 435 */       return this.dataListDouble.get(this.dataListIndex);
/*     */     }
/*     */     
/*     */     private Boolean getBoolean() {
/* 439 */       return this.dataListBoolean.get(this.dataListIndex);
/*     */     }
/*     */     
/*     */     private boolean parseLine(String param1String) {
/* 443 */       if (param1String == null) {
/* 444 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 448 */       if (this.isFirstLine) {
/* 449 */         if (param1String.compareTo("#EXTM3U") != 0) {
/* 450 */           return false;
/*     */         }
/*     */         
/* 453 */         this.isFirstLine = false;
/* 454 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 458 */       if (param1String.isEmpty() || (param1String.startsWith("#") && !param1String.startsWith("#EXT"))) {
/* 459 */         return true;
/*     */       }
/*     */       
/* 462 */       if (param1String.startsWith("#EXTINF")) {
/*     */         
/* 464 */         String[] arrayOfString = param1String.split(":");
/* 465 */         if (arrayOfString.length == 2 && arrayOfString[1].length() > 0) {
/* 466 */           String[] arrayOfString1 = arrayOfString[1].split(",");
/* 467 */           if (arrayOfString1.length >= 1) {
/* 468 */             this.dataListDouble.add(Double.valueOf(Double.parseDouble(arrayOfString1[0])));
/*     */           }
/*     */         } 
/*     */         
/* 472 */         this.isLineMediaFileURI = true;
/* 473 */       } else if (param1String.startsWith("#EXT-X-TARGETDURATION")) {
/*     */         
/* 475 */         String[] arrayOfString = param1String.split(":");
/* 476 */         if (arrayOfString.length == 2 && arrayOfString[1].length() > 0) {
/* 477 */           this.targetDuration = Integer.parseInt(arrayOfString[1]);
/*     */         }
/* 479 */       } else if (param1String.startsWith("#EXT-X-MEDIA-SEQUENCE")) {
/*     */         
/* 481 */         String[] arrayOfString = param1String.split(":");
/* 482 */         if (arrayOfString.length == 2 && arrayOfString[1].length() > 0) {
/* 483 */           this.sequenceNumber = Integer.parseInt(arrayOfString[1]);
/*     */         }
/* 485 */       } else if (param1String.startsWith("#EXT-X-STREAM-INF")) {
/*     */         
/* 487 */         this.isVariantPlaylist = true;
/*     */         
/* 489 */         int i = 0;
/* 490 */         String[] arrayOfString = param1String.split(":");
/* 491 */         if (arrayOfString.length == 2 && arrayOfString[1].length() > 0) {
/* 492 */           String[] arrayOfString1 = arrayOfString[1].split(",");
/* 493 */           if (arrayOfString1.length > 0) {
/* 494 */             for (byte b = 0; b < arrayOfString1.length; b++) {
/* 495 */               arrayOfString1[b] = arrayOfString1[b].trim();
/* 496 */               if (arrayOfString1[b].startsWith("BANDWIDTH")) {
/* 497 */                 String[] arrayOfString2 = arrayOfString1[b].split("=");
/* 498 */                 if (arrayOfString2.length == 2 && arrayOfString2[1].length() > 0) {
/* 499 */                   i = Integer.parseInt(arrayOfString2[1]);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           }
/*     */         } 
/*     */         
/* 506 */         if (i < 1) {
/* 507 */           return false;
/*     */         }
/*     */         
/* 510 */         this.dataListInteger.add(Integer.valueOf(i));
/*     */         
/* 512 */         this.isLinePlaylistURI = true;
/* 513 */       } else if (param1String.startsWith("#EXT-X-ENDLIST")) {
/* 514 */         this.isEndList = true;
/* 515 */       } else if (param1String.startsWith("#EXT-X-DISCONTINUITY")) {
/* 516 */         this.isDiscontinuity = true;
/* 517 */       } else if (this.isLinePlaylistURI) {
/* 518 */         this.isLinePlaylistURI = false;
/* 519 */         this.dataListString.add(param1String);
/* 520 */       } else if (this.isLineMediaFileURI) {
/* 521 */         this.isLineMediaFileURI = false;
/* 522 */         this.dataListString.add(param1String);
/* 523 */         this.dataListBoolean.add(Boolean.valueOf(this.isDiscontinuity));
/* 524 */         this.isDiscontinuity = false;
/*     */       } 
/*     */       
/* 527 */       return true;
/*     */     }
/*     */     
/*     */     private Charset getCharset(String param1String1, String param1String2) {
/* 531 */       if ((param1String1 != null && HLSConnectionHolder.stripParameters(param1String1).endsWith(".m3u8")) || (param1String2 != null && param1String2.equals("application/vnd.apple.mpegurl"))) {
/* 532 */         if (Charset.isSupported("UTF-8")) {
/* 533 */           return Charset.forName("UTF-8");
/*     */         }
/* 535 */       } else if (((param1String1 != null && HLSConnectionHolder.stripParameters(param1String1).endsWith(".m3u")) || (param1String2 != null && param1String2.equals("audio/mpegurl"))) && 
/* 536 */         Charset.isSupported("US-ASCII")) {
/* 537 */         return Charset.forName("US-ASCII");
/*     */       } 
/*     */ 
/*     */       
/* 541 */       return null;
/*     */     }
/*     */     
/*     */     private PlaylistParser() {} }
/*     */   
/*     */   private static class VariantPlaylist {
/* 547 */     private URI playlistURI = null;
/* 548 */     private int infoIndex = -1;
/* 549 */     private List<String> playlistsLocations = new ArrayList<>();
/* 550 */     private List<Integer> playlistsBitrates = new ArrayList<>();
/* 551 */     private List<HLSConnectionHolder.Playlist> playlists = new ArrayList<>();
/* 552 */     private String mediaFileExtension = null;
/*     */     
/*     */     private VariantPlaylist(URI param1URI) {
/* 555 */       this.playlistURI = param1URI;
/*     */     }
/*     */     
/*     */     private void addPlaylistInfo(String param1String, int param1Int) {
/* 559 */       this.playlistsLocations.add(param1String);
/* 560 */       this.playlistsBitrates.add(Integer.valueOf(param1Int));
/*     */     }
/*     */     
/*     */     private void addPlaylist(HLSConnectionHolder.Playlist param1Playlist) {
/* 564 */       if (this.mediaFileExtension == null) {
/* 565 */         this.mediaFileExtension = param1Playlist.getMediaFileExtension();
/*     */       }
/* 567 */       else if (!this.mediaFileExtension.equals(param1Playlist.getMediaFileExtension())) {
/* 568 */         this.playlistsLocations.remove(this.infoIndex);
/* 569 */         this.playlistsBitrates.remove(this.infoIndex);
/* 570 */         this.infoIndex--;
/*     */         
/*     */         return;
/*     */       } 
/* 574 */       this.playlists.add(param1Playlist);
/*     */     }
/*     */     
/*     */     private HLSConnectionHolder.Playlist getPlaylist(int param1Int) {
/* 578 */       if (this.playlists.size() > param1Int) {
/* 579 */         return this.playlists.get(param1Int);
/*     */       }
/* 581 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean hasNext() {
/* 586 */       this.infoIndex++;
/* 587 */       if (this.playlistsLocations.size() > this.infoIndex && this.playlistsBitrates.size() > this.infoIndex) {
/* 588 */         return true;
/*     */       }
/* 590 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     private URI getPlaylistURI() throws URISyntaxException, MalformedURLException {
/* 595 */       String str = this.playlistsLocations.get(this.infoIndex);
/* 596 */       if (str.startsWith("http://") || str.startsWith("https://")) {
/* 597 */         return new URI(str);
/*     */       }
/* 599 */       return new URI(this.playlistURI.toURL().toString().substring(0, this.playlistURI.toURL().toString().lastIndexOf("/") + 1) + this.playlistURI.toURL().toString().substring(0, this.playlistURI.toURL().toString().lastIndexOf("/") + 1));
/*     */     }
/*     */ 
/*     */     
/*     */     private HLSConnectionHolder.Playlist getPlaylistBasedOnBitrate(int param1Int) {
/* 604 */       byte b = -1;
/* 605 */       int i = 0;
/*     */       
/*     */       byte b1;
/* 608 */       for (b1 = 0; b1 < this.playlistsBitrates.size(); b1++) {
/* 609 */         int j = ((Integer)this.playlistsBitrates.get(b1)).intValue();
/* 610 */         if (j < param1Int) {
/* 611 */           if (b != -1) {
/* 612 */             if (j > i) {
/* 613 */               i = j;
/* 614 */               b = b1;
/*     */             } 
/*     */           } else {
/* 617 */             b = b1;
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 623 */       if (b == -1) {
/* 624 */         for (b1 = 0; b1 < this.playlistsBitrates.size(); b1++) {
/* 625 */           int j = ((Integer)this.playlistsBitrates.get(b1)).intValue();
/* 626 */           if (j < i || b == -1) {
/* 627 */             i = j;
/* 628 */             b = b1;
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 634 */       if (b < 0 || b >= this.playlists.size()) {
/* 635 */         return null;
/*     */       }
/* 637 */       return this.playlists.get(b);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class Playlist
/*     */   {
/*     */     private boolean isLive = false;
/*     */     private volatile boolean isLiveWaiting = false;
/*     */     private volatile boolean isLiveStop = false;
/* 647 */     private long targetDuration = 0L;
/* 648 */     private URI playlistURI = null;
/* 649 */     private final Object lock = new Object();
/* 650 */     private List<String> mediaFiles = new ArrayList<>();
/* 651 */     private List<Double> mediaFilesStartTimes = new ArrayList<>();
/* 652 */     private List<Boolean> mediaFilesDiscontinuities = new ArrayList<>();
/*     */     private boolean needBaseURI = true;
/* 654 */     private String baseURI = null;
/* 655 */     private double duration = 0.0D;
/* 656 */     private int sequenceNumber = -1;
/* 657 */     private int sequenceNumberStart = -1;
/*     */     private boolean sequenceNumberUpdated = false;
/*     */     private boolean forceDiscontinuity = false;
/*     */     
/*     */     private Playlist(boolean param1Boolean, int param1Int) {
/* 662 */       this.isLive = param1Boolean;
/* 663 */       this.targetDuration = (param1Int * 1000);
/*     */       
/* 665 */       if (param1Boolean) {
/* 666 */         this.duration = -1.0D;
/*     */       }
/*     */     }
/*     */     
/*     */     private Playlist(URI param1URI) {
/* 671 */       this.playlistURI = param1URI;
/*     */     }
/*     */     
/*     */     private void update(String param1String) {
/* 675 */       HLSConnectionHolder.PlaylistParser playlistParser = new HLSConnectionHolder.PlaylistParser();
/* 676 */       playlistParser.load(this.playlistURI);
/*     */       
/* 678 */       this.isLive = playlistParser.isLivePlaylist();
/* 679 */       this.targetDuration = (playlistParser.getTargetDuration() * 1000);
/*     */       
/* 681 */       if (this.isLive) {
/* 682 */         this.duration = -1.0D;
/*     */       }
/*     */       
/* 685 */       if (setSequenceNumber(playlistParser.getSequenceNumber())) {
/* 686 */         while (playlistParser.hasNext()) {
/* 687 */           addMediaFile(playlistParser.getString(), playlistParser.getDouble().doubleValue(), playlistParser.getBoolean().booleanValue());
/*     */         }
/*     */       }
/*     */       
/* 691 */       if (param1String != null) {
/* 692 */         synchronized (this.lock) {
/* 693 */           for (byte b = 0; b < this.mediaFiles.size(); b++) {
/* 694 */             String str = this.mediaFiles.get(b);
/* 695 */             if (param1String.endsWith(str)) {
/* 696 */               HLSConnectionHolder.this.mediaFileIndex = b - 1;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean isLive() {
/* 705 */       return this.isLive;
/*     */     }
/*     */     
/*     */     private long getTargetDuration() {
/* 709 */       return this.targetDuration;
/*     */     }
/*     */     
/*     */     private void setPlaylistURI(URI param1URI) {
/* 713 */       this.playlistURI = param1URI;
/*     */     }
/*     */     
/*     */     private void addMediaFile(String param1String, double param1Double, boolean param1Boolean) {
/* 717 */       synchronized (this.lock) {
/*     */         
/* 719 */         if (this.needBaseURI) {
/* 720 */           setBaseURI(this.playlistURI.toString(), param1String);
/*     */         }
/*     */         
/* 723 */         if (this.isLive) {
/* 724 */           if (this.sequenceNumberUpdated) {
/* 725 */             int i = this.mediaFiles.indexOf(param1String);
/* 726 */             if (i != -1) {
/* 727 */               for (byte b = 0; b < i; b++) {
/* 728 */                 this.mediaFiles.remove(0);
/* 729 */                 this.mediaFilesDiscontinuities.remove(0);
/* 730 */                 if (HLSConnectionHolder.this.mediaFileIndex == -1) {
/* 731 */                   this.forceDiscontinuity = true;
/*     */                 }
/* 733 */                 if (HLSConnectionHolder.this.mediaFileIndex >= 0) {
/* 734 */                   HLSConnectionHolder.this.mediaFileIndex--;
/*     */                 }
/*     */               } 
/*     */             }
/* 738 */             this.sequenceNumberUpdated = false;
/*     */           } 
/*     */           
/* 741 */           if (this.mediaFiles.contains(param1String)) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */         
/* 746 */         this.mediaFiles.add(param1String);
/* 747 */         this.mediaFilesDiscontinuities.add(Boolean.valueOf(param1Boolean));
/*     */         
/* 749 */         if (this.isLive) {
/* 750 */           if (this.isLiveWaiting) {
/* 751 */             HLSConnectionHolder.this.liveSemaphore.release();
/*     */           }
/*     */         } else {
/* 754 */           this.mediaFilesStartTimes.add(Double.valueOf(this.duration));
/* 755 */           this.duration += param1Double;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private String getNextMediaFile() {
/* 761 */       if (this.isLive) {
/* 762 */         synchronized (this.lock) {
/* 763 */           this.isLiveWaiting = (HLSConnectionHolder.this.mediaFileIndex + 1 >= this.mediaFiles.size());
/*     */         } 
/* 765 */         if (this.isLiveWaiting) {
/*     */           try {
/* 767 */             HLSConnectionHolder.this.liveSemaphore.acquire();
/* 768 */             this.isLiveWaiting = false;
/* 769 */             if (this.isLiveStop) {
/* 770 */               this.isLiveStop = false;
/* 771 */               return null;
/*     */             } 
/* 773 */           } catch (InterruptedException interruptedException) {
/* 774 */             this.isLiveWaiting = false;
/* 775 */             return null;
/*     */           } 
/*     */         }
/* 778 */         if (HLSConnectionHolder.this.isPlaylistClosed) {
/* 779 */           return null;
/*     */         }
/*     */       } 
/*     */       
/* 783 */       synchronized (this.lock) {
/* 784 */         HLSConnectionHolder.this.mediaFileIndex++;
/* 785 */         if (HLSConnectionHolder.this.mediaFileIndex < this.mediaFiles.size()) {
/* 786 */           if (this.baseURI != null) {
/* 787 */             return this.baseURI + this.baseURI;
/*     */           }
/* 789 */           return this.mediaFiles.get(HLSConnectionHolder.this.mediaFileIndex);
/*     */         } 
/*     */         
/* 792 */         return null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private double getDuration() {
/* 798 */       return this.duration;
/*     */     }
/*     */     
/*     */     private void setForceDiscontinuity(boolean param1Boolean) {
/* 802 */       this.forceDiscontinuity = param1Boolean;
/*     */     }
/*     */     
/*     */     private boolean isCurrentMediaFileDiscontinuity() {
/* 806 */       if (this.forceDiscontinuity) {
/* 807 */         this.forceDiscontinuity = false;
/* 808 */         return true;
/*     */       } 
/* 810 */       return ((Boolean)this.mediaFilesDiscontinuities.get(HLSConnectionHolder.this.mediaFileIndex)).booleanValue();
/*     */     }
/*     */ 
/*     */     
/*     */     private double seek(long param1Long) {
/* 815 */       synchronized (this.lock) {
/* 816 */         if (this.isLive) {
/* 817 */           if (param1Long == 0L) {
/* 818 */             HLSConnectionHolder.this.mediaFileIndex = -1;
/* 819 */             if (this.isLiveWaiting) {
/* 820 */               this.isLiveStop = true;
/* 821 */               HLSConnectionHolder.this.liveSemaphore.release();
/*     */             } 
/* 823 */             return 0.0D;
/*     */           } 
/*     */         } else {
/* 826 */           param1Long += this.targetDuration / 2000L;
/*     */           
/* 828 */           int i = this.mediaFilesStartTimes.size();
/*     */           
/* 830 */           for (byte b = 0; b < i; b++) {
/* 831 */             if (param1Long >= ((Double)this.mediaFilesStartTimes.get(b)).doubleValue()) {
/* 832 */               if (b + 1 < i) {
/* 833 */                 if (param1Long < ((Double)this.mediaFilesStartTimes.get(b + 1)).doubleValue()) {
/* 834 */                   HLSConnectionHolder.this.mediaFileIndex = b - 1;
/* 835 */                   return ((Double)this.mediaFilesStartTimes.get(b)).doubleValue();
/*     */                 } 
/*     */               } else {
/* 838 */                 if ((param1Long - this.targetDuration / 2000L) < this.duration) {
/* 839 */                   HLSConnectionHolder.this.mediaFileIndex = b - 1;
/* 840 */                   return ((Double)this.mediaFilesStartTimes.get(b)).doubleValue();
/* 841 */                 }  if (Double.compare((param1Long - this.targetDuration / 2000L), this.duration) == 0) {
/* 842 */                   return this.duration;
/*     */                 }
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 850 */       return -1.0D;
/*     */     }
/*     */     
/*     */     private int getMimeType() {
/* 854 */       synchronized (this.lock) {
/* 855 */         if (this.mediaFiles.size() > 0) {
/* 856 */           if (HLSConnectionHolder.stripParameters(this.mediaFiles.get(0)).endsWith(".ts"))
/* 857 */             return 1; 
/* 858 */           if (HLSConnectionHolder.stripParameters(this.mediaFiles.get(0)).endsWith(".mp3")) {
/* 859 */             return 2;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 864 */       return -1;
/*     */     }
/*     */     
/*     */     private String getMediaFileExtension() {
/* 868 */       synchronized (this.lock) {
/* 869 */         if (this.mediaFiles.size() > 0) {
/* 870 */           String str = HLSConnectionHolder.stripParameters(this.mediaFiles.get(0));
/* 871 */           int i = str.lastIndexOf(".");
/* 872 */           if (i != -1) {
/* 873 */             return str.substring(i);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 878 */       return null;
/*     */     }
/*     */     
/*     */     private boolean setSequenceNumber(int param1Int) {
/* 882 */       if (this.sequenceNumberStart == -1) {
/* 883 */         this.sequenceNumberStart = param1Int;
/* 884 */       } else if (this.sequenceNumber != param1Int) {
/* 885 */         this.sequenceNumberUpdated = true;
/* 886 */         this.sequenceNumber = param1Int;
/*     */       } else {
/* 888 */         return false;
/*     */       } 
/*     */       
/* 891 */       return true;
/*     */     }
/*     */     
/*     */     private void close() {
/* 895 */       if (this.isLive) {
/* 896 */         HLSConnectionHolder.this.isPlaylistClosed = true;
/* 897 */         HLSConnectionHolder.this.liveSemaphore.release();
/*     */       } 
/*     */     }
/*     */     
/*     */     private void setBaseURI(String param1String1, String param1String2) {
/* 902 */       if (!param1String2.startsWith("http://") && !param1String2.startsWith("https://")) {
/* 903 */         this.baseURI = param1String1.substring(0, param1String1.lastIndexOf("/") + 1);
/*     */       }
/* 905 */       this.needBaseURI = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\locator\HLSConnectionHolder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */