/*     */ package com.sun.media.jfxmedia.locator;
/*     */ 
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import com.sun.media.jfxmediaimpl.MediaDisposer;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.net.URI;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocatorCache
/*     */ {
/*     */   private final Map<URI, WeakReference<CacheReference>> uriCache;
/*     */   private final CacheDisposer cacheDisposer;
/*     */   
/*     */   private static class CacheInitializer
/*     */   {
/*  40 */     private static final LocatorCache globalInstance = new LocatorCache();
/*     */   }
/*     */   
/*     */   public static LocatorCache locatorCache() {
/*  44 */     return CacheInitializer.globalInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LocatorCache() {
/*  51 */     this.uriCache = new HashMap<>();
/*  52 */     this.cacheDisposer = new CacheDisposer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheReference registerURICache(URI paramURI, ByteBuffer paramByteBuffer, String paramString) {
/*  60 */     if (Logger.canLog(1)) {
/*  61 */       Logger.logMsg(1, "New cache entry: URI " + paramURI + ", buffer " + paramByteBuffer + ", MIME type " + paramString);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     if (!paramByteBuffer.isDirect()) {
/*  68 */       paramByteBuffer.rewind();
/*  69 */       ByteBuffer byteBuffer = ByteBuffer.allocateDirect(paramByteBuffer.capacity());
/*  70 */       byteBuffer.put(paramByteBuffer);
/*  71 */       paramByteBuffer = byteBuffer;
/*     */     } 
/*     */     
/*  74 */     CacheReference cacheReference = new CacheReference(paramByteBuffer, paramString);
/*  75 */     synchronized (this.uriCache) {
/*  76 */       this.uriCache.put(paramURI, new WeakReference<>(cacheReference));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  81 */     MediaDisposer.addResourceDisposer(cacheReference, paramURI, this.cacheDisposer);
/*  82 */     return cacheReference;
/*     */   }
/*     */   
/*     */   public CacheReference fetchURICache(URI paramURI) {
/*  86 */     synchronized (this.uriCache) {
/*  87 */       WeakReference<CacheReference> weakReference = this.uriCache.get(paramURI);
/*  88 */       if (null == weakReference) {
/*  89 */         return null;
/*     */       }
/*     */       
/*  92 */       CacheReference cacheReference = weakReference.get();
/*  93 */       if (null != cacheReference) {
/*  94 */         if (Logger.canLog(1)) {
/*  95 */           Logger.logMsg(1, "Fetched cache entry: URI " + paramURI + ", buffer " + cacheReference
/*  96 */               .getBuffer() + ", MIME type " + cacheReference
/*  97 */               .getMIMEType());
/*     */         }
/*     */ 
/*     */         
/* 101 */         return cacheReference;
/*     */       } 
/*     */     } 
/* 104 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isCached(URI paramURI) {
/* 108 */     synchronized (this.uriCache) {
/* 109 */       return this.uriCache.containsKey(paramURI);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class CacheReference {
/*     */     private final ByteBuffer buffer;
/*     */     private String mimeType;
/*     */     
/*     */     public CacheReference(ByteBuffer param1ByteBuffer, String param1String) {
/* 118 */       this.buffer = param1ByteBuffer;
/* 119 */       this.mimeType = param1String;
/*     */     }
/*     */     
/*     */     public ByteBuffer getBuffer() {
/* 123 */       return this.buffer;
/*     */     }
/*     */     
/*     */     public String getMIMEType() {
/* 127 */       return this.mimeType;
/*     */     }
/*     */   }
/*     */   
/*     */   private class CacheDisposer
/*     */     implements MediaDisposer.ResourceDisposer {
/*     */     private CacheDisposer() {}
/*     */     
/*     */     public void disposeResource(Object param1Object) {
/* 136 */       if (param1Object instanceof URI)
/* 137 */         synchronized (LocatorCache.this.uriCache) {
/* 138 */           LocatorCache.this.uriCache.remove(param1Object);
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\locator\LocatorCache.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */