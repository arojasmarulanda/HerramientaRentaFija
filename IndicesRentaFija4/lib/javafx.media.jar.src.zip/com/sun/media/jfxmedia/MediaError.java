/*     */ package com.sun.media.jfxmedia;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MediaError
/*     */ {
/*  36 */   ERROR_BASE_MEDIA(256),
/*  37 */   ERROR_BASE_MANAGER(512),
/*  38 */   ERROR_BASE_PIPELINE(768),
/*  39 */   ERROR_BASE_FACTORY(1024),
/*  40 */   ERROR_BASE_LOCATOR(1280),
/*  41 */   ERROR_BASE_REGISTRY(1536),
/*  42 */   ERROR_BASE_GSTREAMER(2048),
/*  43 */   ERROR_BASE_SYSTEM(2560),
/*  44 */   ERROR_BASE_FUNCTION(2816),
/*  45 */   ERROR_BASE_JNI(3072),
/*  46 */   ERROR_BASE_OSX(3328),
/*     */   
/*  48 */   WARNING_BASE_JFXMEDIA(1048576),
/*  49 */   WARNING_BASE_GSTREAMER(8388608),
/*  50 */   WARNING_BASE_GLIB(9437184),
/*     */   
/*  52 */   ERROR_MASK_BASE(3840),
/*  53 */   WARNING_MASK_BASE(15728640),
/*     */   
/*  55 */   ERROR_NONE(0),
/*     */   
/*  57 */   ERROR_MANAGER_NULL(ERROR_BASE_MANAGER.code() + 1),
/*  58 */   ERROR_MANAGER_CREATION(ERROR_BASE_MANAGER.code() + 2),
/*  59 */   ERROR_MANAGER_ENGINEINIT_FAIL(ERROR_BASE_MANAGER.code() + 3),
/*  60 */   ERROR_MANAGER_RUNLOOP_FAIL(ERROR_BASE_MANAGER.code() + 4),
/*  61 */   ERROR_MANAGER_LOGGER_INIT(ERROR_BASE_MANAGER.code() + 5),
/*     */   
/*  63 */   ERROR_MEDIA_NULL(ERROR_BASE_MEDIA.code() + 1),
/*  64 */   ERROR_MEDIA_CREATION(ERROR_BASE_MEDIA.code() + 2),
/*  65 */   ERROR_MEDIA_UNKNOWN_PIXEL_FORMAT(ERROR_BASE_MEDIA.code() + 3),
/*  66 */   ERROR_MEDIA_INVALID(ERROR_BASE_MEDIA.code() + 4),
/*  67 */   ERROR_MEDIA_MARKER_NAME_NULL(ERROR_BASE_MEDIA.code() + 5),
/*  68 */   ERROR_MEDIA_MARKER_TIME_NEGATIVE(ERROR_BASE_MEDIA.code() + 6),
/*  69 */   ERROR_MEDIA_MARKER_MAP_NULL(ERROR_BASE_MEDIA.code() + 7),
/*  70 */   ERROR_MEDIA_VIDEO_FORMAT_UNSUPPORTED(ERROR_BASE_MEDIA.code() + 8),
/*  71 */   ERROR_MEDIA_AUDIO_FORMAT_UNSUPPORTED(ERROR_BASE_MEDIA.code() + 9),
/*  72 */   ERROR_MEDIA_MP3_FORMAT_UNSUPPORTED(ERROR_BASE_MEDIA.code() + 10),
/*  73 */   ERROR_MEDIA_AAC_FORMAT_UNSUPPORTED(ERROR_BASE_MEDIA.code() + 11),
/*  74 */   ERROR_MEDIA_H264_FORMAT_UNSUPPORTED(ERROR_BASE_MEDIA.code() + 12),
/*  75 */   ERROR_MEDIA_HLS_FORMAT_UNSUPPORTED(ERROR_BASE_MEDIA.code() + 13),
/*  76 */   ERROR_MEDIA_CORRUPTED(ERROR_BASE_MEDIA.code() + 14),
/*     */   
/*  78 */   ERROR_PIPELINE_NULL(ERROR_BASE_PIPELINE.code() + 1),
/*  79 */   ERROR_PIPELINE_CREATION(ERROR_BASE_PIPELINE.code() + 2),
/*  80 */   ERROR_PIPELINE_NO_FRAME_QUEUE(ERROR_BASE_PIPELINE.code() + 3),
/*     */   
/*  82 */   ERROR_FACTORY_NULL(ERROR_BASE_FACTORY.code() + 1),
/*  83 */   ERROR_FACTORY_CONTAINER_CREATION(ERROR_BASE_FACTORY.code() + 2),
/*  84 */   ERROR_FACTORY_INVALID_URI(ERROR_BASE_FACTORY.code() + 3),
/*     */   
/*  86 */   ERROR_LOCATOR_NULL(ERROR_BASE_LOCATOR.code() + 1),
/*  87 */   ERROR_LOCATOR_UNSUPPORTED_TYPE(ERROR_BASE_LOCATOR.code() + 2),
/*  88 */   ERROR_LOCATOR_UNSUPPORTED_MEDIA_FORMAT(ERROR_BASE_LOCATOR.code() + 3),
/*  89 */   ERROR_LOCATOR_CONNECTION_LOST(ERROR_BASE_LOCATOR.code() + 4),
/*  90 */   ERROR_LOCATOR_CONTENT_TYPE_NULL(ERROR_BASE_LOCATOR.code() + 5),
/*     */   
/*  92 */   ERROR_REGISTRY_NULL(ERROR_BASE_REGISTRY.code() + 1),
/*  93 */   ERROR_REGISTRY_PLUGIN_ALREADY_EXIST(ERROR_BASE_REGISTRY.code() + 2),
/*  94 */   ERROR_REGISTRY_PLUGIN_PATH(ERROR_BASE_REGISTRY.code() + 3),
/*  95 */   ERROR_REGISTRY_NO_MATCHING_RECIPE(ERROR_BASE_REGISTRY.code() + 4),
/*     */   
/*  97 */   ERROR_GSTREAMER_ERROR(ERROR_BASE_GSTREAMER.code() + 1),
/*  98 */   ERROR_GSTREAMER_PIPELINE_CREATION(ERROR_BASE_GSTREAMER.code() + 2),
/*  99 */   ERROR_GSTREAMER_AUDIO_DECODER_SINK_PAD(ERROR_BASE_GSTREAMER.code() + 3),
/* 100 */   ERROR_GSTREAMER_AUDIO_DECODER_SRC_PAD(ERROR_BASE_GSTREAMER.code() + 4),
/* 101 */   ERROR_GSTREAMER_AUDIO_SINK_SINK_PAD(ERROR_BASE_GSTREAMER.code() + 5),
/* 102 */   ERROR_GSTREAMER_VIDEO_DECODER_SINK_PAD(ERROR_BASE_GSTREAMER.code() + 6),
/* 103 */   ERROR_GSTREAMER_PIPELINE_STATE_CHANGE(ERROR_BASE_GSTREAMER.code() + 7),
/* 104 */   ERROR_GSTREAMER_PIPELINE_SEEK(ERROR_BASE_GSTREAMER.code() + 8),
/* 105 */   ERROR_GSTREAMER_PIPELINE_QUERY_LENGTH(ERROR_BASE_GSTREAMER.code() + 9),
/* 106 */   ERROR_GSTREAMER_PIPELINE_QUERY_POS(ERROR_BASE_GSTREAMER.code() + 10),
/* 107 */   ERROR_GSTREAMER_PIPELINE_METADATA_TYPE(ERROR_BASE_GSTREAMER.code() + 11),
/* 108 */   ERROR_GSTREAMER_AUDIO_SINK_CREATE(ERROR_BASE_GSTREAMER.code() + 12),
/* 109 */   ERROR_GSTREAMER_GET_BUFFER_SRC_PAD(ERROR_BASE_GSTREAMER.code() + 13),
/* 110 */   ERROR_GSTREAMER_CREATE_GHOST_PAD(ERROR_BASE_GSTREAMER.code() + 14),
/* 111 */   ERROR_GSTREAMER_ELEMENT_ADD_PAD(ERROR_BASE_GSTREAMER.code() + 15),
/* 112 */   ERROR_GSTREAMER_UNSUPPORTED_PROTOCOL(ERROR_BASE_GSTREAMER.code() + 16),
/* 113 */   ERROR_GSTREAMER_SOURCEFILE_NONEXISTENT(ERROR_BASE_GSTREAMER.code() + 32),
/* 114 */   ERROR_GSTREAMER_SOURCEFILE_NONREGULAR(ERROR_BASE_GSTREAMER.code() + 48),
/* 115 */   ERROR_GSTREAMER_ELEMENT_LINK(ERROR_BASE_GSTREAMER.code() + 64),
/* 116 */   ERROR_GSTREAMER_ELEMENT_LINK_AUDIO_BIN(ERROR_BASE_GSTREAMER.code() + 80),
/* 117 */   ERROR_GSTREAMER_ELEMENT_LINK_VIDEO_BIN(ERROR_BASE_GSTREAMER.code() + 96),
/* 118 */   ERROR_GSTREAMER_ELEMENT_CREATE(ERROR_BASE_GSTREAMER.code() + 112),
/* 119 */   ERROR_GSTREAMER_VIDEO_SINK_CREATE(ERROR_BASE_GSTREAMER.code() + 128),
/* 120 */   ERROR_GSTREAMER_BIN_CREATE(ERROR_BASE_GSTREAMER.code() + 144),
/* 121 */   ERROR_GSTREAMER_BIN_ADD_ELEMENT(ERROR_BASE_GSTREAMER.code() + 160),
/* 122 */   ERROR_GSTREAMER_ELEMENT_GET_PAD(ERROR_BASE_GSTREAMER.code() + 176),
/* 123 */   ERROR_GSTREAMER_MAIN_LOOP_CREATE(ERROR_BASE_GSTREAMER.code() + 192),
/* 124 */   ERROR_GSTREAMER_BUS_SOURCE_ATTACH(ERROR_BASE_GSTREAMER.code() + 193),
/* 125 */   ERROR_GSTREAMER_PIPELINE_SET_RATE_ZERO(ERROR_BASE_GSTREAMER.code() + 208),
/* 126 */   ERROR_GSTREAMER_VIDEO_SINK_SINK_PAD(ERROR_BASE_GSTREAMER.code() + 224),
/*     */   
/* 128 */   ERROR_NOT_IMPLEMENTED(ERROR_BASE_SYSTEM.code() + 1),
/* 129 */   ERROR_MEMORY_ALLOCATION(ERROR_BASE_SYSTEM.code() + 2),
/* 130 */   ERROR_OS_UNSUPPORTED(ERROR_BASE_SYSTEM.code() + 3),
/* 131 */   ERROR_PLATFORM_UNSUPPORTED(ERROR_BASE_SYSTEM.code() + 4),
/*     */   
/* 133 */   ERROR_FUNCTION_PARAM(ERROR_BASE_FUNCTION.code() + 1),
/* 134 */   ERROR_FUNCTION_PARAM_NULL(ERROR_BASE_FUNCTION.code() + 2),
/*     */   
/* 136 */   ERROR_JNI_SEND_PLAYER_MEDIA_ERROR_EVENT(ERROR_BASE_JNI.code() + 1),
/* 137 */   ERROR_JNI_SEND_PLAYER_HALT_EVENT(ERROR_BASE_JNI.code() + 2),
/* 138 */   ERROR_JNI_SEND_PLAYER_STATE_EVENT(ERROR_BASE_JNI.code() + 3),
/* 139 */   ERROR_JNI_SEND_NEW_FRAME_EVENT(ERROR_BASE_JNI.code() + 4),
/* 140 */   ERROR_JNI_SEND_FRAME_SIZE_CHANGED_EVENT(ERROR_BASE_JNI.code() + 5),
/* 141 */   ERROR_JNI_SEND_END_OF_MEDIA_EVENT(ERROR_BASE_JNI.code() + 6),
/* 142 */   ERROR_JNI_SEND_AUDIO_TRACK_EVENT(ERROR_BASE_JNI.code() + 7),
/* 143 */   ERROR_JNI_SEND_VIDEO_TRACK_EVENT(ERROR_BASE_JNI.code() + 8),
/* 144 */   ERROR_JNI_SEND_METADATA_EVENT(ERROR_BASE_JNI.code() + 9),
/* 145 */   ERROR_JNI_SEND_MARKER_EVENT(ERROR_BASE_JNI.code() + 10),
/* 146 */   ERROR_JNI_SEND_BUFFER_PROGRESS_EVENT(ERROR_BASE_JNI.code() + 11),
/* 147 */   ERROR_JNI_SEND_STOP_REACHED_EVENT(ERROR_BASE_JNI.code() + 12),
/* 148 */   ERROR_JNI_SEND_DURATION_UPDATE_EVENT(ERROR_BASE_JNI.code() + 13),
/* 149 */   ERROR_JNI_SEND_AUDIO_SPECTRUM_EVENT(ERROR_BASE_JNI.code() + 14),
/*     */   
/* 151 */   ERROR_OSX_INIT(ERROR_BASE_OSX.code() + 1),
/*     */   
/* 153 */   WARNING_JFXMEDIA_BALANCE(WARNING_BASE_JFXMEDIA.code() + 1),
/*     */   
/* 155 */   WARNING_GSTREAMER_WARNING(WARNING_BASE_GSTREAMER.code() + 1),
/* 156 */   WARNING_GSTREAMER_PIPELINE_ERROR(WARNING_BASE_GSTREAMER.code() + 2),
/* 157 */   WARNING_GSTREAMER_PIPELINE_WARNING(WARNING_BASE_GSTREAMER.code() + 3),
/* 158 */   WARNING_GSTREAMER_PIPELINE_STATE_EVENT(WARNING_BASE_GSTREAMER.code() + 4),
/* 159 */   WARNING_GSTREAMER_PIPELINE_FRAME_SIZE(WARNING_BASE_GSTREAMER.code() + 5),
/* 160 */   WARNING_GSTREAMER_INVALID_FRAME(WARNING_BASE_GSTREAMER.code() + 6),
/* 161 */   WARNING_GSTREAMER_PIPELINE_INFO_ERROR(WARNING_BASE_GSTREAMER.code() + 7),
/* 162 */   WARNING_GSTREAMER_AUDIO_BUFFER_FIELD(WARNING_BASE_GSTREAMER.code() + 8);
/*     */   
/*     */   static {
/* 165 */     map = new HashMap<>();
/*     */ 
/*     */     
/*     */     try {
/* 169 */       bundle = ResourceBundle.getBundle("MediaErrors", Locale.getDefault());
/* 170 */     } catch (MissingResourceException missingResourceException) {
/* 171 */       bundle = null;
/*     */     } 
/*     */     
/* 174 */     for (MediaError mediaError : values())
/* 175 */       map.put(Integer.valueOf(mediaError.code()), mediaError); 
/*     */   }
/*     */   private static ResourceBundle bundle;
/*     */   private static final Map<Integer, MediaError> map;
/*     */   private int code;
/*     */   private String description;
/*     */   
/*     */   MediaError(int paramInt1) {
/* 183 */     this.code = paramInt1;
/*     */   }
/*     */   
/*     */   public int code() {
/* 187 */     return this.code;
/*     */   }
/*     */   
/*     */   public String description() {
/* 191 */     if (this.description == null) {
/* 192 */       String str = name();
/* 193 */       if (bundle != null) {
/*     */         try {
/* 195 */           this.description = bundle.getString(str);
/* 196 */         } catch (MissingResourceException missingResourceException) {
/* 197 */           this.description = str;
/*     */         } 
/*     */       } else {
/* 200 */         this.description = str;
/*     */       } 
/*     */     } 
/* 203 */     return this.description;
/*     */   }
/*     */   
/*     */   public static MediaError getFromCode(int paramInt) {
/* 207 */     return map.get(Integer.valueOf(paramInt));
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmedia\MediaError.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */