/*     */ package com.sun.media.jfxmediaimpl;
/*     */ 
/*     */ import com.sun.media.jfxmedia.control.VideoDataBuffer;
/*     */ import com.sun.media.jfxmedia.control.VideoFormat;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NativeVideoBuffer
/*     */   implements VideoDataBuffer
/*     */ {
/*     */   private long nativePeer;
/*     */   private final AtomicInteger holdCount;
/*     */   private NativeVideoBuffer cachedBGRARep;
/*     */   private static final boolean DEBUG_DISPOSED_BUFFERS = false;
/*  58 */   private static final VideoBufferDisposer disposer = new VideoBufferDisposer();
/*     */   
/*     */   public static NativeVideoBuffer createVideoBuffer(long paramLong) {
/*  61 */     NativeVideoBuffer nativeVideoBuffer = new NativeVideoBuffer(paramLong);
/*  62 */     MediaDisposer.addResourceDisposer(nativeVideoBuffer, Long.valueOf(paramLong), disposer);
/*  63 */     return nativeVideoBuffer;
/*     */   }
/*     */   
/*     */   private NativeVideoBuffer(long paramLong) {
/*  67 */     this.holdCount = new AtomicInteger(1);
/*  68 */     this.nativePeer = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void holdFrame() {
/*  74 */     if (0L != this.nativePeer) {
/*  75 */       this.holdCount.incrementAndGet();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseFrame() {
/*  84 */     if (0L != this.nativePeer && 
/*  85 */       this.holdCount.decrementAndGet() <= 0) {
/*     */       
/*  87 */       if (null != this.cachedBGRARep) {
/*  88 */         this.cachedBGRARep.releaseFrame();
/*  89 */         this.cachedBGRARep = null;
/*     */       } 
/*     */ 
/*     */       
/*  93 */       MediaDisposer.removeResourceDisposer(Long.valueOf(this.nativePeer));
/*  94 */       nativeDisposeBuffer(this.nativePeer);
/*  95 */       this.nativePeer = 0L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getTimestamp() {
/* 104 */     if (0L != this.nativePeer) {
/* 105 */       return nativeGetTimestamp(this.nativePeer);
/*     */     }
/*     */ 
/*     */     
/* 109 */     return 0.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuffer getBufferForPlane(int paramInt) {
/* 114 */     if (0L != this.nativePeer) {
/* 115 */       ByteBuffer byteBuffer = nativeGetBufferForPlane(this.nativePeer, paramInt);
/*     */ 
/*     */       
/* 118 */       byteBuffer.order(ByteOrder.nativeOrder());
/* 119 */       return byteBuffer;
/*     */     } 
/*     */ 
/*     */     
/* 123 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 128 */     if (0L != this.nativePeer) {
/* 129 */       return nativeGetWidth(this.nativePeer);
/*     */     }
/*     */ 
/*     */     
/* 133 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 138 */     if (0L != this.nativePeer) {
/* 139 */       return nativeGetHeight(this.nativePeer);
/*     */     }
/*     */ 
/*     */     
/* 143 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getEncodedWidth() {
/* 148 */     if (0L != this.nativePeer) {
/* 149 */       return nativeGetEncodedWidth(this.nativePeer);
/*     */     }
/*     */ 
/*     */     
/* 153 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getEncodedHeight() {
/* 158 */     if (0L != this.nativePeer) {
/* 159 */       return nativeGetEncodedHeight(this.nativePeer);
/*     */     }
/*     */ 
/*     */     
/* 163 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoFormat getFormat() {
/* 168 */     if (0L != this.nativePeer) {
/* 169 */       int i = nativeGetFormat(this.nativePeer);
/* 170 */       return VideoFormat.formatForType(i);
/*     */     } 
/*     */ 
/*     */     
/* 174 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAlpha() {
/* 179 */     if (0L != this.nativePeer) {
/* 180 */       return nativeHasAlpha(this.nativePeer);
/*     */     }
/*     */ 
/*     */     
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPlaneCount() {
/* 189 */     if (0L != this.nativePeer) {
/* 190 */       return nativeGetPlaneCount(this.nativePeer);
/*     */     }
/*     */ 
/*     */     
/* 194 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStrideForPlane(int paramInt) {
/* 199 */     if (0L != this.nativePeer) {
/* 200 */       int[] arrayOfInt = nativeGetPlaneStrides(this.nativePeer);
/* 201 */       return arrayOfInt[paramInt];
/*     */     } 
/*     */ 
/*     */     
/* 205 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getPlaneStrides() {
/* 210 */     if (0L != this.nativePeer) {
/* 211 */       return nativeGetPlaneStrides(this.nativePeer);
/*     */     }
/*     */ 
/*     */     
/* 215 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public VideoDataBuffer convertToFormat(VideoFormat paramVideoFormat) {
/* 220 */     if (0L != this.nativePeer) {
/*     */       
/* 222 */       if (paramVideoFormat == VideoFormat.BGRA_PRE && null != this.cachedBGRARep) {
/* 223 */         this.cachedBGRARep.holdFrame();
/* 224 */         return this.cachedBGRARep;
/*     */       } 
/*     */       
/* 227 */       long l = nativeConvertToFormat(this.nativePeer, paramVideoFormat.getNativeType());
/* 228 */       if (0L != l) {
/* 229 */         NativeVideoBuffer nativeVideoBuffer = createVideoBuffer(l);
/* 230 */         if (paramVideoFormat == VideoFormat.BGRA_PRE) {
/* 231 */           nativeVideoBuffer.holdFrame();
/* 232 */           this.cachedBGRARep = nativeVideoBuffer;
/*     */         } 
/* 234 */         return nativeVideoBuffer;
/*     */       } 
/* 236 */       throw new UnsupportedOperationException("Conversion from " + getFormat() + " to " + paramVideoFormat + " is not supported.");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 241 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDirty() {
/* 246 */     if (0L != this.nativePeer) {
/* 247 */       nativeSetDirty(this.nativePeer);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class VideoBufferDisposer
/*     */     implements MediaDisposer.ResourceDisposer
/*     */   {
/*     */     private VideoBufferDisposer() {}
/*     */     
/*     */     public void disposeResource(Object param1Object) {
/* 257 */       if (param1Object instanceof Long) {
/* 258 */         NativeVideoBuffer.nativeDisposeBuffer(((Long)param1Object).longValue());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 268 */     return "[NativeVideoBuffer peer=" + Long.toHexString(this.nativePeer) + ", format=" + getFormat() + ", size=(" + getWidth() + "," + getHeight() + "), timestamp=" + getTimestamp() + "]";
/*     */   }
/*     */   
/*     */   private static native void nativeDisposeBuffer(long paramLong);
/*     */   
/*     */   private native double nativeGetTimestamp(long paramLong);
/*     */   
/*     */   private native ByteBuffer nativeGetBufferForPlane(long paramLong, int paramInt);
/*     */   
/*     */   private native int nativeGetWidth(long paramLong);
/*     */   
/*     */   private native int nativeGetHeight(long paramLong);
/*     */   
/*     */   private native int nativeGetEncodedWidth(long paramLong);
/*     */   
/*     */   private native int nativeGetEncodedHeight(long paramLong);
/*     */   
/*     */   private native int nativeGetFormat(long paramLong);
/*     */   
/*     */   private native boolean nativeHasAlpha(long paramLong);
/*     */   
/*     */   private native int nativeGetPlaneCount(long paramLong);
/*     */   
/*     */   private native int[] nativeGetPlaneStrides(long paramLong);
/*     */   
/*     */   private native long nativeConvertToFormat(long paramLong, int paramInt);
/*     */   
/*     */   private native void nativeSetDirty(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\NativeVideoBuffer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */