/*     */ package com.sun.media.jfxmediaimpl;
/*     */ 
/*     */ import com.sun.media.jfxmedia.AudioClip;
/*     */ import com.sun.media.jfxmedia.MediaException;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NativeAudioClip
/*     */   extends AudioClip
/*     */ {
/*     */   private final Locator mediaSource;
/*  37 */   private long nativeHandle = 0L;
/*     */   
/*  39 */   private static NativeAudioClipDisposer clipDisposer = new NativeAudioClipDisposer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean init() {
/*  48 */     return nacInit();
/*     */   }
/*     */   
/*     */   public static AudioClip load(URI paramURI) {
/*  52 */     NativeAudioClip nativeAudioClip = null;
/*     */     try {
/*  54 */       Locator locator = new Locator(paramURI);
/*  55 */       locator.init();
/*  56 */       nativeAudioClip = new NativeAudioClip(locator);
/*  57 */     } catch (URISyntaxException uRISyntaxException) {
/*  58 */       throw new MediaException("Non-compliant URI", uRISyntaxException);
/*  59 */     } catch (IOException iOException) {
/*  60 */       throw new MediaException("Cannot connect to media", iOException);
/*     */     } 
/*  62 */     if (null != nativeAudioClip && 0L != nativeAudioClip.getNativeHandle()) {
/*  63 */       MediaDisposer.addResourceDisposer(nativeAudioClip, Long.valueOf(nativeAudioClip.getNativeHandle()), clipDisposer);
/*     */     } else {
/*  65 */       nativeAudioClip = null;
/*  66 */       throw new MediaException("Cannot create audio clip");
/*     */     } 
/*  68 */     return nativeAudioClip;
/*     */   }
/*     */   
/*     */   public static AudioClip create(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  72 */     NativeAudioClip nativeAudioClip = new NativeAudioClip(paramArrayOfbyte, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*  73 */     if (null != nativeAudioClip && 0L != nativeAudioClip.getNativeHandle()) {
/*  74 */       MediaDisposer.addResourceDisposer(nativeAudioClip, Long.valueOf(nativeAudioClip.getNativeHandle()), clipDisposer);
/*     */     } else {
/*  76 */       nativeAudioClip = null;
/*  77 */       throw new MediaException("Cannot create audio clip");
/*     */     } 
/*  79 */     return nativeAudioClip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NativeAudioClip(Locator paramLocator) {
/*  93 */     this.mediaSource = paramLocator;
/*  94 */     this.nativeHandle = nacLoad(this.mediaSource);
/*     */   }
/*     */   
/*     */   private NativeAudioClip(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  98 */     this.mediaSource = null;
/*  99 */     this.nativeHandle = nacCreate(paramArrayOfbyte, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */   
/*     */   long getNativeHandle() {
/* 103 */     return this.nativeHandle;
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioClip createSegment(double paramDouble1, double paramDouble2) {
/* 108 */     return nacCreateSegment(this.nativeHandle, paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioClip createSegment(int paramInt1, int paramInt2) {
/* 113 */     return nacCreateSegment(this.nativeHandle, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioClip resample(int paramInt1, int paramInt2, int paramInt3) {
/* 118 */     return nacResample(this.nativeHandle, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AudioClip append(AudioClip paramAudioClip) {
/* 124 */     if (!(paramAudioClip instanceof NativeAudioClip)) {
/* 125 */       throw new IllegalArgumentException("AudioClip type mismatch, cannot append");
/*     */     }
/* 127 */     return nacAppend(this.nativeHandle, ((NativeAudioClip)paramAudioClip).getNativeHandle());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AudioClip flatten() {
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPlaying() {
/* 138 */     return nacIsPlaying(this.nativeHandle);
/*     */   }
/*     */ 
/*     */   
/*     */   public void play() {
/* 143 */     nacPlay(this.nativeHandle, this.clipVolume, this.clipBalance, this.clipPan, this.clipRate, this.loopCount, this.clipPriority);
/*     */   }
/*     */ 
/*     */   
/*     */   public void play(double paramDouble) {
/* 148 */     nacPlay(this.nativeHandle, paramDouble, this.clipBalance, this.clipPan, this.clipRate, this.loopCount, this.clipPriority);
/*     */   }
/*     */ 
/*     */   
/*     */   public void play(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt1, int paramInt2) {
/* 153 */     nacPlay(this.nativeHandle, paramDouble1, paramDouble2, paramDouble4, paramDouble3, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 158 */     nacStop(this.nativeHandle);
/*     */   } private static native boolean nacInit(); private static native long nacLoad(Locator paramLocator); private static native long nacCreate(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5); private static native void nacUnload(long paramLong); private static native void nacStopAll();
/*     */   private native NativeAudioClip nacCreateSegment(long paramLong, double paramDouble1, double paramDouble2);
/*     */   public static void stopAllClips() {
/* 162 */     nacStopAll();
/*     */   } private native NativeAudioClip nacCreateSegment(long paramLong, int paramInt1, int paramInt2); private native NativeAudioClip nacResample(long paramLong, int paramInt1, int paramInt2, int paramInt3); private native NativeAudioClip nacAppend(long paramLong1, long paramLong2);
/*     */   private native boolean nacIsPlaying(long paramLong);
/*     */   private native void nacPlay(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt1, int paramInt2);
/*     */   private native void nacStop(long paramLong);
/*     */   private static class NativeAudioClipDisposer implements MediaDisposer.ResourceDisposer { public void disposeResource(Object param1Object) {
/* 168 */       long l = ((Long)param1Object).longValue();
/* 169 */       if (0L != l)
/* 170 */         NativeAudioClip.nacUnload(l); 
/*     */     }
/*     */     
/*     */     private NativeAudioClipDisposer() {} }
/*     */ 
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\NativeAudioClip.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */