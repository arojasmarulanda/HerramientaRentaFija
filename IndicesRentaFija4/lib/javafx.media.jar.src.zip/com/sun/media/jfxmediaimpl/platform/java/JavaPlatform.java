/*    */ package com.sun.media.jfxmediaimpl.platform.java;
/*    */ 
/*    */ import com.sun.media.jfxmedia.Media;
/*    */ import com.sun.media.jfxmedia.MediaPlayer;
/*    */ import com.sun.media.jfxmedia.MetadataParser;
/*    */ import com.sun.media.jfxmedia.locator.Locator;
/*    */ import com.sun.media.jfxmediaimpl.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JavaPlatform
/*    */   extends Platform
/*    */ {
/* 39 */   private static JavaPlatform globalInstance = null;
/*    */   
/*    */   public static synchronized Platform getPlatformInstance() {
/* 42 */     if (null == globalInstance) {
/* 43 */       globalInstance = new JavaPlatform();
/*    */     }
/*    */     
/* 46 */     return globalInstance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean loadPlatform() {
/* 53 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MetadataParser createMetadataParser(Locator paramLocator) {
/* 59 */     String str = paramLocator.getContentType();
/* 60 */     if (str.equals("audio/mpeg") || str
/* 61 */       .equals("audio/mp3")) {
/* 62 */       return new ID3MetadataParser(paramLocator);
/*    */     }
/*    */     
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Media createMedia(Locator paramLocator) {
/* 70 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public MediaPlayer createMediaPlayer(Locator paramLocator) {
/* 75 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\platform\java\JavaPlatform.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */