/*    */ package com.sun.media.jfxmediaimpl.platform.gstreamer;
/*    */ 
/*    */ import com.sun.media.jfxmedia.MediaError;
/*    */ import com.sun.media.jfxmedia.locator.Locator;
/*    */ import com.sun.media.jfxmediaimpl.MediaUtils;
/*    */ import com.sun.media.jfxmediaimpl.NativeMedia;
/*    */ import com.sun.media.jfxmediaimpl.platform.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GSTMedia
/*    */   extends NativeMedia
/*    */ {
/* 42 */   private final Object markerMutex = new Object();
/*    */ 
/*    */   
/*    */   protected long refNativeMedia;
/*    */ 
/*    */ 
/*    */   
/*    */   GSTMedia(Locator paramLocator) {
/* 50 */     super(paramLocator);
/*    */     
/* 52 */     init();
/*    */   }
/*    */ 
/*    */   
/*    */   public Platform getPlatform() {
/* 57 */     return GSTPlatform.getPlatformInstance();
/*    */   }
/*    */ 
/*    */   
/*    */   private void init() {
/* 62 */     long[] arrayOfLong = new long[1];
/*    */     
/* 64 */     Locator locator = getLocator();
/* 65 */     MediaError mediaError = MediaError.getFromCode(gstInitNativeMedia(locator, locator
/* 66 */           .getContentType(), locator.getContentLength(), arrayOfLong));
/*    */     
/* 68 */     if (mediaError != MediaError.ERROR_NONE && mediaError != MediaError.ERROR_PLATFORM_UNSUPPORTED) {
/* 69 */       MediaUtils.nativeError(this, mediaError);
/*    */     }
/* 71 */     this.refNativeMedia = arrayOfLong[0];
/*    */   }
/*    */   
/*    */   long getNativeMediaRef() {
/* 75 */     return this.refNativeMedia;
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void dispose() {
/* 80 */     if (0L != this.refNativeMedia) {
/* 81 */       gstDispose(this.refNativeMedia);
/* 82 */       this.refNativeMedia = 0L;
/*    */     } 
/*    */   }
/*    */   
/*    */   private native int gstInitNativeMedia(Locator paramLocator, String paramString, long paramLong, long[] paramArrayOflong);
/*    */   
/*    */   private native void gstDispose(long paramLong);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\platform\gstreamer\GSTMedia.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */