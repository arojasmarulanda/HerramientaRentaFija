/*     */ package com.sun.media.jfxmediaimpl.platform.java;
/*     */ 
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import com.sun.media.jfxmediaimpl.MetadataParserImpl;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ID3MetadataParser
/*     */   extends MetadataParserImpl
/*     */ {
/*     */   private static final int ID3_VERSION_MIN = 2;
/*     */   private static final int ID3_VERSION_MAX = 4;
/*     */   private static final String CHARSET_UTF_8 = "UTF-8";
/*     */   private static final String CHARSET_ISO_8859_1 = "ISO-8859-1";
/*     */   private static final String CHARSET_UTF_16 = "UTF-16";
/*     */   private static final String CHARSET_UTF_16BE = "UTF-16BE";
/*  46 */   private int COMMCount = 0;
/*  47 */   private int TXXXCount = 0;
/*  48 */   private int version = 3;
/*     */   private boolean unsynchronized = false;
/*     */   
/*     */   public ID3MetadataParser(Locator paramLocator) {
/*  52 */     super(paramLocator);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void parse() {
/*     */     try {
/*  58 */       if (!Charset.isSupported("ISO-8859-1")) {
/*  59 */         throw new UnsupportedCharsetException("ISO-8859-1");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  75 */       byte[] arrayOfByte = getBytes(10);
/*  76 */       this.version = arrayOfByte[3] & 0xFF;
/*  77 */       if (arrayOfByte[0] == 73 && arrayOfByte[1] == 68 && arrayOfByte[2] == 51 && this.version >= 2 && this.version <= 4) {
/*     */         
/*  79 */         int i = arrayOfByte[5] & 0xFF;
/*  80 */         if ((i & 0x80) == 128) {
/*  81 */           this.unsynchronized = true;
/*     */         }
/*     */         
/*  84 */         int j = 0; int k; byte b;
/*  85 */         for (k = 6, b = 21; k < 10; k++) {
/*  86 */           j += (arrayOfByte[k] & Byte.MAX_VALUE) << b;
/*  87 */           b -= 7;
/*     */         } 
/*     */         
/*  90 */         startRawMetadata(j + 10);
/*  91 */         stuffRawMetadata(arrayOfByte, 0, 10);
/*  92 */         readRawMetadata(j);
/*  93 */         setParseRawMetadata(true);
/*  94 */         skipBytes(10);
/*     */         
/*  96 */         while (getStreamPosition() < j) {
/*     */           byte[] arrayOfByte1;
/*     */ 
/*     */           
/* 100 */           if (2 == this.version) {
/*     */             
/* 102 */             arrayOfByte1 = getBytes(3);
/* 103 */             k = getU24();
/*     */           } else {
/* 105 */             arrayOfByte1 = getBytes(4);
/* 106 */             k = getFrameSize();
/* 107 */             skipBytes(2);
/*     */           } 
/*     */           
/* 110 */           if (0 == arrayOfByte1[0]) {
/*     */             
/* 112 */             if (Logger.canLog(1)) {
/* 113 */               Logger.logMsg(1, "ID3MetadataParser", "parse", "ID3 parser: zero padding detected at " + 
/*     */                   
/* 115 */                   getStreamPosition() + ", terminating");
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/* 120 */           String str = new String(arrayOfByte1, Charset.forName("ISO-8859-1"));
/*     */           
/* 122 */           if (Logger.canLog(1)) {
/* 123 */             Logger.logMsg(1, "ID3MetadataParser", "parse", "" + 
/* 124 */                 getStreamPosition() + "\\" + getStreamPosition() + ": frame ID " + j + ", size " + str);
/*     */           }
/*     */           
/* 127 */           if (str.equals("APIC") || str.equals("PIC")) {
/* 128 */             byte[] arrayOfByte2 = getBytes(k);
/* 129 */             if (this.unsynchronized) {
/* 130 */               arrayOfByte2 = unsynchronizeBuffer(arrayOfByte2);
/*     */             }
/*     */             
/* 133 */             byte[] arrayOfByte3 = str.equals("PIC") ? getImageFromPIC(arrayOfByte2) : getImageFromAPIC(arrayOfByte2);
/*     */             
/* 135 */             if (arrayOfByte3 != null)
/* 136 */               addMetadataItem("image", arrayOfByte3);  continue;
/*     */           } 
/* 138 */           if (str.startsWith("T") && !str.equals("TXXX")) {
/* 139 */             String str1 = getEncoding();
/* 140 */             byte[] arrayOfByte2 = getBytes(k - 1);
/* 141 */             if (this.unsynchronized) {
/* 142 */               arrayOfByte2 = unsynchronizeBuffer(arrayOfByte2);
/*     */             }
/* 144 */             String str2 = new String(arrayOfByte2, str1);
/* 145 */             String[] arrayOfString = getTagFromFrameID(str);
/* 146 */             if (arrayOfString != null)
/* 147 */               for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/* 148 */                 Object object = convertValue(arrayOfString[b1], str2);
/* 149 */                 if (object != null)
/* 150 */                   addMetadataItem(arrayOfString[b1], object); 
/*     */               }  
/*     */             continue;
/*     */           } 
/* 154 */           if (str.equals("COMM") || str.equals("COM")) {
/* 155 */             String str1 = getEncoding();
/*     */             
/* 157 */             byte[] arrayOfByte2 = getBytes(3);
/* 158 */             if (this.unsynchronized) {
/* 159 */               arrayOfByte2 = unsynchronizeBuffer(arrayOfByte2);
/*     */             }
/* 161 */             String str2 = new String(arrayOfByte2, Charset.forName("ISO-8859-1"));
/*     */             
/* 163 */             arrayOfByte2 = getBytes(k - 4);
/* 164 */             if (this.unsynchronized) {
/* 165 */               arrayOfByte2 = unsynchronizeBuffer(arrayOfByte2);
/*     */             }
/* 167 */             String str3 = new String(arrayOfByte2, str1);
/* 168 */             if (str3 != null) {
/* 169 */               String str5; int m = str3.indexOf(false);
/* 170 */               String str4 = "";
/*     */               
/* 172 */               if (m == 0) {
/* 173 */                 if (isTwoByteEncoding(str1)) {
/* 174 */                   str5 = str3.substring(2);
/*     */                 } else {
/* 176 */                   str5 = str3.substring(1);
/*     */                 } 
/*     */               } else {
/* 179 */                 str4 = str3.substring(0, m);
/* 180 */                 if (isTwoByteEncoding(str1)) {
/* 181 */                   str5 = str3.substring(m + 2);
/*     */                 } else {
/* 183 */                   str5 = str3.substring(m + 1);
/*     */                 } 
/*     */               } 
/* 186 */               String[] arrayOfString = getTagFromFrameID(str);
/* 187 */               if (arrayOfString != null)
/* 188 */                 for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/* 189 */                   addMetadataItem(arrayOfString[b1] + "-" + arrayOfString[b1], str4 + "[" + str4 + "]=" + str2);
/* 190 */                   this.COMMCount++;
/*     */                 }  
/*     */             }  continue;
/*     */           } 
/* 194 */           if (str.equals("TXX") || str.equals("TXXX")) {
/* 195 */             String str1 = getEncoding();
/* 196 */             byte[] arrayOfByte2 = getBytes(k - 1);
/* 197 */             if (this.unsynchronized) {
/* 198 */               arrayOfByte2 = unsynchronizeBuffer(arrayOfByte2);
/*     */             }
/* 200 */             String str2 = new String(arrayOfByte2, str1);
/* 201 */             if (null != str2) {
/* 202 */               int m = str2.indexOf(false);
/* 203 */               String str3 = (m != 0) ? str2.substring(0, m) : "";
/* 204 */               String str4 = isTwoByteEncoding(str1) ? str2.substring(m + 2) : str2.substring(m + 1);
/*     */               
/* 206 */               String[] arrayOfString = getTagFromFrameID(str);
/* 207 */               if (arrayOfString != null) {
/* 208 */                 for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/* 209 */                   if (str3.equals("")) {
/* 210 */                     addMetadataItem(arrayOfString[b1] + "-" + arrayOfString[b1], str4);
/*     */                   } else {
/* 212 */                     addMetadataItem(arrayOfString[b1] + "-" + arrayOfString[b1], str3 + "=" + str3);
/*     */                   } 
/* 214 */                   this.TXXXCount++;
/*     */                 } 
/*     */               }
/*     */             } 
/*     */             continue;
/*     */           } 
/* 220 */           skipBytes(k);
/*     */         }
/*     */       
/*     */       } 
/* 224 */     } catch (Exception exception) {
/*     */ 
/*     */       
/* 227 */       if (Logger.canLog(3)) {
/* 228 */         Logger.logMsg(3, "ID3MetadataParser", "parse", "Exception while processing ID3v2 metadata: " + exception);
/*     */       }
/*     */     } finally {
/*     */       
/* 232 */       if (null != this.rawMetaBlob) {
/* 233 */         setParseRawMetadata(false);
/* 234 */         addRawMetadata("ID3");
/* 235 */         disposeRawMetadata();
/*     */       } 
/* 237 */       done();
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getFrameSize() throws IOException {
/* 242 */     if (this.version == 4) {
/* 243 */       byte[] arrayOfByte = getBytes(4);
/* 244 */       int i = 0;
/* 245 */       for (byte b1 = 0, b2 = 21; b1 < 4; b1++) {
/* 246 */         i += (arrayOfByte[b1] & Byte.MAX_VALUE) << b2;
/* 247 */         b2 -= 7;
/*     */       } 
/* 249 */       return i;
/*     */     } 
/* 251 */     return getInteger();
/*     */   }
/*     */ 
/*     */   
/*     */   private String getEncoding() throws IOException {
/* 256 */     byte b = getNextByte();
/* 257 */     if (b == 0)
/* 258 */       return "ISO-8859-1"; 
/* 259 */     if (b == 1)
/* 260 */       return "UTF-16"; 
/* 261 */     if (b == 2)
/* 262 */       return "UTF-16BE"; 
/* 263 */     if (b == 3) {
/* 264 */       return "UTF-8";
/*     */     }
/* 266 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isTwoByteEncoding(String paramString) {
/* 271 */     if (paramString.equals("ISO-8859-1") || paramString.equals("UTF-8"))
/* 272 */       return false; 
/* 273 */     if (paramString.equals("UTF-16") || paramString.equals("UTF-16BE")) {
/* 274 */       return true;
/*     */     }
/* 276 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getTagFromFrameID(String paramString) {
/* 297 */     if (paramString.equals("TPE2") || paramString.equals("TP2"))
/* 298 */       return new String[] { "album artist" }; 
/* 299 */     if (paramString.equals("TALB") || paramString.equals("TAL"))
/* 300 */       return new String[] { "album" }; 
/* 301 */     if (paramString.equals("TPE1") || paramString.equals("TP1"))
/* 302 */       return new String[] { "artist" }; 
/* 303 */     if (paramString.equals("COMM") || paramString.equals("COM"))
/* 304 */       return new String[] { "comment" }; 
/* 305 */     if (paramString.equals("TCOM") || paramString.equals("TCM"))
/* 306 */       return new String[] { "composer" }; 
/* 307 */     if (paramString.equals("TLEN") || paramString.equals("TLE"))
/* 308 */       return new String[] { "duration" }; 
/* 309 */     if (paramString.equals("TCON") || paramString.equals("TCO"))
/* 310 */       return new String[] { "genre" }; 
/* 311 */     if (paramString.equals("TIT2") || paramString.equals("TT2"))
/* 312 */       return new String[] { "title" }; 
/* 313 */     if (paramString.equals("TRCK") || paramString.equals("TRK"))
/* 314 */       return new String[] { "track number", "track count" }; 
/* 315 */     if (paramString.equals("TPOS") || paramString.equals("TPA"))
/* 316 */       return new String[] { "disc number", "disc count" }; 
/* 317 */     if (paramString.equals("TYER") || paramString.equals("TDRC"))
/* 318 */       return new String[] { "year" }; 
/* 319 */     if (paramString.equals("TXX") || paramString.equals("TXXX")) {
/* 320 */       return new String[] { "text" };
/*     */     }
/*     */     
/* 323 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getImageFromPIC(byte[] paramArrayOfbyte) {
/* 338 */     byte b = 5;
/* 339 */     while (0 != paramArrayOfbyte[b] && b < paramArrayOfbyte.length) {
/* 340 */       b++;
/*     */     }
/* 342 */     if (b == paramArrayOfbyte.length)
/*     */     {
/* 344 */       return null;
/*     */     }
/*     */     
/* 347 */     String str = new String(paramArrayOfbyte, 1, 3, Charset.forName("ISO-8859-1"));
/* 348 */     if (Logger.canLog(1)) {
/* 349 */       Logger.logMsg(1, "ID3MetadataParser", "getImageFromPIC", "PIC type: " + str);
/*     */     }
/*     */ 
/*     */     
/* 353 */     if (str.equalsIgnoreCase("PNG") || str.equalsIgnoreCase("JPG"))
/*     */     {
/* 355 */       return Arrays.copyOfRange(paramArrayOfbyte, b + 1, paramArrayOfbyte.length);
/*     */     }
/* 357 */     if (Logger.canLog(3)) {
/* 358 */       Logger.logMsg(3, "ID3MetadataParser", "getImageFromPIC", "Unsupported picture type found \"" + str + "\"");
/*     */     }
/*     */     
/* 361 */     return null;
/*     */   }
/*     */   
/*     */   private byte[] getImageFromAPIC(byte[] paramArrayOfbyte) {
/* 365 */     boolean bool1 = false;
/* 366 */     boolean bool2 = false;
/*     */ 
/*     */     
/* 369 */     int i = paramArrayOfbyte.length - 10;
/* 370 */     int j = 0; byte b;
/* 371 */     for (b = 0; b < i; b++) {
/* 372 */       if (paramArrayOfbyte[b] == 105 && paramArrayOfbyte[b + 1] == 109 && paramArrayOfbyte[b + 2] == 97 && paramArrayOfbyte[b + 3] == 103 && paramArrayOfbyte[b + 4] == 101 && paramArrayOfbyte[b + 5] == 47) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 379 */         b += 6;
/*     */ 
/*     */         
/* 382 */         if (paramArrayOfbyte[b] == 106 && paramArrayOfbyte[b + 1] == 112 && paramArrayOfbyte[b + 2] == 101 && paramArrayOfbyte[b + 3] == 103) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 387 */           bool1 = true;
/* 388 */           j = b + 4;
/*     */           break;
/*     */         } 
/* 391 */         if (paramArrayOfbyte[b] == 112 && paramArrayOfbyte[b + 1] == 110 && paramArrayOfbyte[b + 2] == 103) {
/*     */ 
/*     */ 
/*     */           
/* 395 */           bool2 = true;
/* 396 */           j = b + 3;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 402 */     if (bool1) {
/*     */       
/* 404 */       b = 0;
/* 405 */       int k = paramArrayOfbyte.length - 1;
/*     */       
/* 407 */       for (int m = j; m < k; m++) {
/*     */         
/* 409 */         if (-1 == paramArrayOfbyte[m] && -40 == paramArrayOfbyte[m + 1]) {
/*     */           
/* 411 */           b = 1;
/* 412 */           j = m;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 417 */       if (b != 0)
/*     */       {
/* 419 */         return Arrays.copyOfRange(paramArrayOfbyte, j, paramArrayOfbyte.length);
/*     */       }
/*     */     } 
/*     */     
/* 423 */     if (bool2) {
/*     */       
/* 425 */       b = 0;
/* 426 */       int k = paramArrayOfbyte.length - 7;
/*     */       
/* 428 */       for (int m = j; m < k; m++) {
/*     */         
/* 430 */         if (-119 == paramArrayOfbyte[m] && 80 == paramArrayOfbyte[m + 1] && 78 == paramArrayOfbyte[m + 2] && 71 == paramArrayOfbyte[m + 3] && 13 == paramArrayOfbyte[m + 4] && 10 == paramArrayOfbyte[m + 5] && 26 == paramArrayOfbyte[m + 6] && 10 == paramArrayOfbyte[m + 7]) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 440 */           b = 1;
/* 441 */           j = m;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 446 */       if (b != 0)
/*     */       {
/* 448 */         return Arrays.copyOfRange(paramArrayOfbyte, j, paramArrayOfbyte.length);
/*     */       }
/*     */     } 
/* 451 */     return null;
/*     */   }
/*     */   
/*     */   private byte[] unsynchronizeBuffer(byte[] paramArrayOfbyte) {
/* 455 */     byte[] arrayOfByte = new byte[paramArrayOfbyte.length];
/* 456 */     byte b1 = 0;
/*     */     
/* 458 */     for (byte b2 = 0; b2 < paramArrayOfbyte.length; b2++) {
/* 459 */       if (((paramArrayOfbyte[b2] & 0xFF) == 255 && paramArrayOfbyte[b2 + 1] == 0 && paramArrayOfbyte[b2 + 2] == 0) || ((paramArrayOfbyte[b2] & 0xFF) == 255 && paramArrayOfbyte[b2 + 1] == 0 && (paramArrayOfbyte[b2 + 2] & 0xE0) == 224)) {
/*     */         
/* 461 */         arrayOfByte[b1] = paramArrayOfbyte[b2];
/* 462 */         b1++;
/* 463 */         arrayOfByte[b1] = paramArrayOfbyte[b2 + 2];
/* 464 */         b1++;
/* 465 */         b2 += 2;
/*     */       } else {
/* 467 */         arrayOfByte[b1] = paramArrayOfbyte[b2];
/* 468 */         b1++;
/*     */       } 
/*     */     } 
/*     */     
/* 472 */     return Arrays.copyOf(arrayOfByte, b1);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\platform\java\ID3MetadataParser.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */