/*     */ package com.sun.media.jfxmediaimpl.platform.gstreamer;
/*     */ 
/*     */ import com.sun.media.jfxmedia.Media;
/*     */ import com.sun.media.jfxmedia.MediaError;
/*     */ import com.sun.media.jfxmedia.MediaPlayer;
/*     */ import com.sun.media.jfxmedia.events.PlayerStateEvent;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import com.sun.media.jfxmediaimpl.HostUtils;
/*     */ import com.sun.media.jfxmediaimpl.MediaUtils;
/*     */ import com.sun.media.jfxmediaimpl.platform.Platform;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GSTPlatform
/*     */   extends Platform
/*     */ {
/*  46 */   private static final String[] CONTENT_TYPES = new String[] { "audio/x-aiff", "audio/mp3", "audio/mpeg", "audio/x-wav", "video/mp4", "audio/x-m4a", "video/x-m4v", "application/vnd.apple.mpegurl", "audio/mpegurl" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private static final String[] PROTOCOLS = new String[] { "file", "http", "https" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private static GSTPlatform globalInstance = null;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean loadPlatform() {
/*     */     MediaError mediaError;
/*     */     try {
/*  74 */       mediaError = MediaError.getFromCode(gstInitPlatform());
/*  75 */     } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/*  76 */       mediaError = MediaError.ERROR_MANAGER_ENGINEINIT_FAIL;
/*     */     } 
/*     */     
/*  79 */     if (mediaError != MediaError.ERROR_NONE) {
/*  80 */       MediaUtils.nativeError(GSTPlatform.class, mediaError);
/*     */     }
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized Platform getPlatformInstance() {
/*  89 */     if (null == globalInstance) {
/*  90 */       globalInstance = new GSTPlatform();
/*     */     }
/*     */     
/*  93 */     return globalInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getSupportedContentTypes() {
/* 100 */     return Arrays.<String>copyOf(CONTENT_TYPES, CONTENT_TYPES.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSupportedProtocols() {
/* 105 */     return Arrays.<String>copyOf(PROTOCOLS, PROTOCOLS.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public Media createMedia(Locator paramLocator) {
/* 110 */     return new GSTMedia(paramLocator);
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaPlayer createMediaPlayer(Locator paramLocator) {
/*     */     GSTMediaPlayer gSTMediaPlayer;
/*     */     try {
/* 117 */       gSTMediaPlayer = new GSTMediaPlayer(paramLocator);
/* 118 */     } catch (Exception exception) {
/* 119 */       if (Logger.canLog(1)) {
/* 120 */         Logger.logMsg(1, "GSTPlatform caught exception while creating media player: " + exception);
/*     */       }
/* 122 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 126 */     if (HostUtils.isMacOSX()) {
/* 127 */       String str = paramLocator.getContentType();
/* 128 */       if ("video/mp4".equals(str) || "video/x-m4v".equals(str) || paramLocator
/* 129 */         .getStringLocation().endsWith(".m3u8")) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 134 */         String str1 = paramLocator.getURI().getScheme();
/*     */         
/* 136 */         long l1 = (str1.equals("http") || str1.equals("https")) ? 60000L : 5000L;
/*     */         
/* 138 */         long l2 = 0L;
/*     */         
/* 140 */         Object object = new Object();
/* 141 */         PlayerStateEvent.PlayerState playerState = gSTMediaPlayer.getState();
/*     */         
/* 143 */         while (l2 < l1 && (playerState == PlayerStateEvent.PlayerState.UNKNOWN || playerState == PlayerStateEvent.PlayerState.STALLED)) {
/*     */           
/*     */           try {
/* 146 */             synchronized (object) {
/* 147 */               object.wait(50L);
/* 148 */               l2 += 50L;
/*     */             } 
/* 150 */           } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */ 
/*     */           
/* 154 */           playerState = gSTMediaPlayer.getState();
/*     */         } 
/*     */ 
/*     */         
/* 158 */         if (gSTMediaPlayer.getState() != PlayerStateEvent.PlayerState.READY) {
/* 159 */           gSTMediaPlayer.dispose();
/* 160 */           gSTMediaPlayer = null;
/*     */         } 
/*     */       } 
/*     */     } 
/* 164 */     return gSTMediaPlayer;
/*     */   }
/*     */   
/*     */   private static native int gstInitPlatform();
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\platform\gstreamer\GSTPlatform.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */