/*     */ package com.sun.media.jfxmediaimpl;
/*     */ 
/*     */ import com.sun.media.jfxmedia.effects.AudioSpectrum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NativeAudioSpectrum
/*     */   implements AudioSpectrum
/*     */ {
/*  31 */   private static final float[] EMPTY_FLOAT_ARRAY = new float[0];
/*     */   
/*     */   public static final int DEFAULT_THRESHOLD = -60;
/*     */   
/*     */   public static final int DEFAULT_BANDS = 128;
/*     */   
/*     */   public static final double DEFAULT_INTERVAL = 0.1D;
/*     */   
/*     */   private final long nativeRef;
/*     */   
/*  41 */   private float[] magnitudes = EMPTY_FLOAT_ARRAY;
/*  42 */   private float[] phases = EMPTY_FLOAT_ARRAY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NativeAudioSpectrum(long paramLong) {
/*  53 */     if (paramLong == 0L) {
/*  54 */       throw new IllegalArgumentException("Invalid native media reference");
/*     */     }
/*     */     
/*  57 */     this.nativeRef = paramLong;
/*  58 */     setBandCount(128);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getEnabled() {
/*  66 */     return nativeGetEnabled(this.nativeRef);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean paramBoolean) {
/*  71 */     nativeSetEnabled(this.nativeRef, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBandCount() {
/*  77 */     return this.phases.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBandCount(int paramInt) {
/*  82 */     if (paramInt > 1) {
/*  83 */       this.magnitudes = new float[paramInt];
/*  84 */       for (byte b = 0; b < this.magnitudes.length; b++) {
/*  85 */         this.magnitudes[b] = -60.0F;
/*     */       }
/*     */       
/*  88 */       this.phases = new float[paramInt];
/*  89 */       nativeSetBands(this.nativeRef, paramInt, this.magnitudes, this.phases);
/*     */     } else {
/*  91 */       this.magnitudes = EMPTY_FLOAT_ARRAY;
/*  92 */       this.phases = EMPTY_FLOAT_ARRAY;
/*     */       
/*  94 */       throw new IllegalArgumentException("Number of bands must at least be 2");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public double getInterval() {
/* 100 */     return nativeGetInterval(this.nativeRef);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInterval(double paramDouble) {
/* 105 */     if (paramDouble * 1.0E9D >= 1.0D) {
/* 106 */       nativeSetInterval(this.nativeRef, paramDouble);
/*     */     } else {
/* 108 */       throw new IllegalArgumentException("Interval can't be less that 1 nanosecond");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSensitivityThreshold() {
/* 114 */     return nativeGetThreshold(this.nativeRef);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSensitivityThreshold(int paramInt) {
/* 119 */     if (paramInt <= 0) {
/* 120 */       nativeSetThreshold(this.nativeRef, paramInt);
/*     */     } else {
/* 122 */       throw new IllegalArgumentException(String.format("Sensitivity threshold must be less than 0: %d", new Object[] { Integer.valueOf(paramInt) }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] getMagnitudes(float[] paramArrayOffloat) {
/* 128 */     int i = this.magnitudes.length;
/* 129 */     if (paramArrayOffloat == null || paramArrayOffloat.length < i) {
/* 130 */       paramArrayOffloat = new float[i];
/*     */     }
/* 132 */     System.arraycopy(this.magnitudes, 0, paramArrayOffloat, 0, i);
/* 133 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] getPhases(float[] paramArrayOffloat) {
/* 138 */     int i = this.phases.length;
/* 139 */     if (paramArrayOffloat == null || paramArrayOffloat.length < i) {
/* 140 */       paramArrayOffloat = new float[i];
/*     */     }
/* 142 */     System.arraycopy(this.phases, 0, paramArrayOffloat, 0, i);
/* 143 */     return paramArrayOffloat;
/*     */   }
/*     */   
/*     */   private native boolean nativeGetEnabled(long paramLong);
/*     */   
/*     */   private native void nativeSetEnabled(long paramLong, boolean paramBoolean);
/*     */   
/*     */   private native void nativeSetBands(long paramLong, int paramInt, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*     */   
/*     */   private native double nativeGetInterval(long paramLong);
/*     */   
/*     */   private native void nativeSetInterval(long paramLong, double paramDouble);
/*     */   
/*     */   private native int nativeGetThreshold(long paramLong);
/*     */   
/*     */   private native void nativeSetThreshold(long paramLong, int paramInt);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\NativeAudioSpectrum.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */