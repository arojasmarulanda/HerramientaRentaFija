/*     */ package com.sun.media.jfxmediaimpl;
/*     */ 
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import java.lang.ref.PhantomReference;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaDisposer
/*     */ {
/*     */   private final ReferenceQueue<Object> purgatory;
/*     */   private final Map<Reference, Disposable> disposers;
/*     */   private static MediaDisposer theDisposinator;
/*     */   
/*     */   public static void addResourceDisposer(Object paramObject1, Object paramObject2, ResourceDisposer paramResourceDisposer) {
/*  74 */     disposinator().implAddResourceDisposer(paramObject1, paramObject2, paramResourceDisposer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeResourceDisposer(Object paramObject) {
/*  85 */     disposinator().implRemoveResourceDisposer(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addDisposable(Object paramObject, Disposable paramDisposable) {
/*  95 */     disposinator().implAddDisposable(paramObject, paramDisposable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized MediaDisposer disposinator() {
/* 103 */     if (null == theDisposinator) {
/* 104 */       theDisposinator = new MediaDisposer();
/*     */ 
/*     */       
/* 107 */       Thread thread = new Thread(() -> theDisposinator.disposerLoop(), "Media Resource Disposer");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 112 */       thread.setDaemon(true);
/* 113 */       thread.start();
/*     */     } 
/* 115 */     return theDisposinator;
/*     */   }
/*     */   
/*     */   private MediaDisposer() {
/* 119 */     this.purgatory = new ReferenceQueue();
/*     */ 
/*     */     
/* 122 */     this.disposers = new HashMap<>();
/*     */   }
/*     */ 
/*     */   
/*     */   private void disposerLoop() {
/*     */     while (true) {
/*     */       try {
/* 129 */         Reference<?> reference = this.purgatory.remove();
/*     */ 
/*     */         
/* 132 */         synchronized (this.disposers) {
/* 133 */           disposable = this.disposers.remove(reference);
/*     */         } 
/*     */         
/* 136 */         reference.clear();
/* 137 */         if (null != disposable) {
/* 138 */           disposable.dispose();
/*     */         }
/* 140 */         reference = null;
/* 141 */         Disposable disposable = null;
/* 142 */       } catch (InterruptedException interruptedException) {
/* 143 */         if (Logger.canLog(1)) {
/* 144 */           Logger.logMsg(1, MediaDisposer.class.getName(), "disposerLoop", "Disposer loop interrupted, terminating");
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void implAddResourceDisposer(Object paramObject1, Object paramObject2, ResourceDisposer paramResourceDisposer) {
/* 152 */     PhantomReference phantomReference = new PhantomReference(paramObject1, this.purgatory);
/* 153 */     synchronized (this.disposers) {
/* 154 */       this.disposers.put(phantomReference, new ResourceDisposerRecord(paramObject2, paramResourceDisposer));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void implRemoveResourceDisposer(Object paramObject) {
/* 159 */     Reference reference = null;
/*     */     
/* 161 */     synchronized (this.disposers) {
/* 162 */       for (Map.Entry<Reference, Disposable> entry : this.disposers.entrySet()) {
/* 163 */         Disposable disposable = (Disposable)entry.getValue();
/* 164 */         if (disposable instanceof ResourceDisposerRecord) {
/* 165 */           ResourceDisposerRecord resourceDisposerRecord = (ResourceDisposerRecord)disposable;
/* 166 */           if (resourceDisposerRecord.resource.equals(paramObject)) {
/* 167 */             reference = (Reference)entry.getKey();
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 173 */       if (null != reference) {
/* 174 */         this.disposers.remove(reference);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void implAddDisposable(Object paramObject, Disposable paramDisposable) {
/* 180 */     PhantomReference phantomReference = new PhantomReference(paramObject, this.purgatory);
/* 181 */     synchronized (this.disposers) {
/* 182 */       this.disposers.put(phantomReference, paramDisposable);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class ResourceDisposerRecord implements Disposable {
/*     */     Object resource;
/*     */     MediaDisposer.ResourceDisposer disposer;
/*     */     
/*     */     public ResourceDisposerRecord(Object param1Object, MediaDisposer.ResourceDisposer param1ResourceDisposer) {
/* 191 */       this.resource = param1Object;
/* 192 */       this.disposer = param1ResourceDisposer;
/*     */     }
/*     */     
/*     */     public void dispose() {
/* 196 */       this.disposer.disposeResource(this.resource);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface ResourceDisposer {
/*     */     void disposeResource(Object param1Object);
/*     */   }
/*     */   
/*     */   public static interface Disposable {
/*     */     void dispose();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\MediaDisposer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */