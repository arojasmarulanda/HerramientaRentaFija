/*    */ package com.sun.media.jfxmediaimpl;
/*    */ 
/*    */ import com.sun.media.jfxmedia.effects.EqualizerBand;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NativeEqualizerBand
/*    */   implements EqualizerBand
/*    */ {
/*    */   private final long bandRef;
/*    */   
/*    */   private NativeEqualizerBand(long paramLong) {
/* 35 */     if (paramLong != 0L) {
/* 36 */       this.bandRef = paramLong;
/*    */     } else {
/* 38 */       throw new IllegalArgumentException("bandRef == 0");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public double getCenterFrequency() {
/* 44 */     return nativeGetCenterFrequency(this.bandRef);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCenterFrequency(double paramDouble) {
/* 49 */     nativeSetCenterFrequency(this.bandRef, paramDouble);
/*    */   }
/*    */ 
/*    */   
/*    */   public double getBandwidth() {
/* 54 */     return nativeGetBandwidth(this.bandRef);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBandwidth(double paramDouble) {
/* 59 */     nativeSetBandwidth(this.bandRef, paramDouble);
/*    */   }
/*    */ 
/*    */   
/*    */   public double getGain() {
/* 64 */     return nativeGetGain(this.bandRef);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setGain(double paramDouble) {
/* 69 */     if (paramDouble >= -24.0D && paramDouble <= 12.0D)
/* 70 */       nativeSetGain(this.bandRef, paramDouble); 
/*    */   }
/*    */   
/*    */   private native double nativeGetCenterFrequency(long paramLong);
/*    */   
/*    */   private native void nativeSetCenterFrequency(long paramLong, double paramDouble);
/*    */   
/*    */   private native double nativeGetBandwidth(long paramLong);
/*    */   
/*    */   private native void nativeSetBandwidth(long paramLong, double paramDouble);
/*    */   
/*    */   private native double nativeGetGain(long paramLong);
/*    */   
/*    */   private native void nativeSetGain(long paramLong, double paramDouble);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\NativeEqualizerBand.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */