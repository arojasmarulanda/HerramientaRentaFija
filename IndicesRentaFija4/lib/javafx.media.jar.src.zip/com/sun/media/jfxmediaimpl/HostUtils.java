/*    */ package com.sun.media.jfxmediaimpl;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HostUtils
/*    */ {
/*    */   private static String osName;
/*    */   private static String osArch;
/*    */   private static boolean embedded;
/*    */   private static boolean is64bit = false;
/*    */   
/*    */   static {
/* 41 */     embedded = ((Boolean)AccessController.<Boolean>doPrivileged(() -> {
/*    */           osName = System.getProperty("os.name").toLowerCase();
/*    */           
/*    */           osArch = System.getProperty("os.arch").toLowerCase();
/* 45 */           is64bit = (osArch.equals("x64") || osArch.equals("x86_64") || osArch.equals("ia64"));
/*    */           return Boolean.valueOf(Boolean.getBoolean("com.sun.javafx.isEmbedded"));
/*    */         })).booleanValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean is64Bit() {
/* 54 */     return is64bit;
/*    */   }
/*    */   
/*    */   public static boolean isWindows() {
/* 58 */     return osName.startsWith("windows");
/*    */   }
/*    */   
/*    */   public static boolean isMacOSX() {
/* 62 */     return osName.startsWith("mac os x");
/*    */   }
/*    */   
/*    */   public static boolean isLinux() {
/* 66 */     return osName.startsWith("linux");
/*    */   }
/*    */   
/*    */   public static boolean isIOS() {
/* 70 */     return osName.startsWith("ios");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isEmbedded() {
/* 77 */     return embedded;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\HostUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */