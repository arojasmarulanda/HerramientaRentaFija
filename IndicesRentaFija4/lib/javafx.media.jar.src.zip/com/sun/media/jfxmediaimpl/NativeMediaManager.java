/*     */ package com.sun.media.jfxmediaimpl;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import com.sun.media.jfxmedia.Media;
/*     */ import com.sun.media.jfxmedia.MediaError;
/*     */ import com.sun.media.jfxmedia.MediaException;
/*     */ import com.sun.media.jfxmedia.MediaPlayer;
/*     */ import com.sun.media.jfxmedia.MetadataParser;
/*     */ import com.sun.media.jfxmedia.events.MediaErrorListener;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import com.sun.media.jfxmediaimpl.platform.PlatformManager;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeMediaManager
/*     */ {
/*     */   private static boolean isNativeLayerInitialized = false;
/*  57 */   private final List<WeakReference<MediaErrorListener>> errorListeners = new ArrayList<>();
/*     */   
/*  59 */   private static final NativeMediaPlayerDisposer playerDisposer = new NativeMediaPlayerDisposer();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private static final Map<MediaPlayer, Boolean> allMediaPlayers = new WeakHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private final List<String> supportedContentTypes = new ArrayList<>();
/*     */   
/*  71 */   private final List<String> supportedProtocols = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NativeMediaManagerInitializer
/*     */   {
/*  78 */     private static final NativeMediaManager globalInstance = new NativeMediaManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NativeMediaManager getDefaultInstance() {
/*  90 */     return NativeMediaManagerInitializer.globalInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NativeMediaManager() {
/*     */     try {
/* 107 */       AccessController.doPrivileged(() -> {
/*     */             ArrayList<String> arrayList = new ArrayList();
/*     */             
/*     */             if (HostUtils.isWindows() || HostUtils.isMacOSX()) {
/*     */               NativeLibLoader.loadLibrary("glib-lite");
/*     */             }
/*     */             if (!HostUtils.isLinux() && !HostUtils.isIOS()) {
/*     */               NativeLibLoader.loadLibrary("gstreamer-lite");
/*     */             } else {
/*     */               arrayList.add("gstreamer-lite");
/*     */             } 
/*     */             if (HostUtils.isLinux()) {
/*     */               arrayList.add("fxplugins");
/*     */               arrayList.add("avplugin");
/*     */               arrayList.add("avplugin-54");
/*     */               arrayList.add("avplugin-56");
/*     */               arrayList.add("avplugin-57");
/*     */               arrayList.add("avplugin-ffmpeg-56");
/*     */               arrayList.add("avplugin-ffmpeg-57");
/*     */             } 
/*     */             if (HostUtils.isMacOSX()) {
/*     */               arrayList.add("fxplugins");
/*     */               arrayList.add("glib-lite");
/*     */               arrayList.add("jfxmedia_avf");
/*     */             } 
/*     */             if (HostUtils.isWindows()) {
/*     */               arrayList.add("fxplugins");
/*     */               arrayList.add("glib-lite");
/*     */             } 
/*     */             NativeLibLoader.loadLibrary("jfxmedia", arrayList);
/*     */             return null;
/*     */           });
/* 139 */     } catch (PrivilegedActionException privilegedActionException) {
/* 140 */       MediaUtils.error(null, MediaError.ERROR_MANAGER_ENGINEINIT_FAIL.code(), "Unable to load one or more dependent libraries.", privilegedActionException);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (!Logger.initNative()) {
/* 146 */       MediaUtils.error(null, MediaError.ERROR_MANAGER_LOGGER_INIT.code(), "Unable to init logger", null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static synchronized void initNativeLayer() {
/* 155 */     if (!isNativeLayerInitialized) {
/*     */       
/* 157 */       PlatformManager.getManager().loadPlatforms();
/*     */ 
/*     */       
/* 160 */       isNativeLayerInitialized = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void loadContentTypes() {
/* 169 */     if (!this.supportedContentTypes.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 174 */     List<String> list = PlatformManager.getManager().getSupportedContentTypes();
/* 175 */     if (null != list && !list.isEmpty()) {
/* 176 */       this.supportedContentTypes.addAll(list);
/*     */     }
/*     */     
/* 179 */     if (Logger.canLog(1)) {
/* 180 */       StringBuilder stringBuilder = new StringBuilder("JFXMedia supported content types:\n");
/* 181 */       for (String str : this.supportedContentTypes) {
/* 182 */         stringBuilder.append("    ");
/* 183 */         stringBuilder.append(str);
/* 184 */         stringBuilder.append("\n");
/*     */       } 
/* 186 */       Logger.logMsg(1, stringBuilder.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   private synchronized void loadProtocols() {
/* 191 */     if (!this.supportedProtocols.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 196 */     List<String> list = PlatformManager.getManager().getSupportedProtocols();
/* 197 */     if (null != list && !list.isEmpty()) {
/* 198 */       this.supportedProtocols.addAll(list);
/*     */     }
/*     */     
/* 201 */     if (Logger.canLog(1)) {
/* 202 */       StringBuilder stringBuilder = new StringBuilder("JFXMedia supported protocols:\n");
/* 203 */       for (String str : this.supportedProtocols) {
/* 204 */         stringBuilder.append("    ");
/* 205 */         stringBuilder.append(str);
/* 206 */         stringBuilder.append("\n");
/*     */       } 
/* 208 */       Logger.logMsg(1, stringBuilder.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canPlayContentType(String paramString) {
/* 222 */     if (paramString == null) {
/* 223 */       throw new IllegalArgumentException("contentType == null!");
/*     */     }
/*     */     
/* 226 */     if (this.supportedContentTypes.isEmpty()) {
/* 227 */       loadContentTypes();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     for (String str : this.supportedContentTypes) {
/* 235 */       if (paramString.equalsIgnoreCase(str)) {
/* 236 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 240 */     return false;
/*     */   }
/*     */   
/*     */   public String[] getSupportedContentTypes() {
/* 244 */     if (this.supportedContentTypes.isEmpty()) {
/* 245 */       loadContentTypes();
/*     */     }
/*     */     
/* 248 */     return this.supportedContentTypes.<String>toArray(new String[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canPlayProtocol(String paramString) {
/* 261 */     if (paramString == null) {
/* 262 */       throw new IllegalArgumentException("protocol == null!");
/*     */     }
/*     */     
/* 265 */     if (this.supportedProtocols.isEmpty()) {
/* 266 */       loadProtocols();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     for (String str : this.supportedProtocols) {
/* 274 */       if (paramString.equalsIgnoreCase(str)) {
/* 275 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 279 */     return false;
/*     */   }
/*     */   
/*     */   public static MetadataParser getMetadataParser(Locator paramLocator) {
/* 283 */     return PlatformManager.getManager().createMetadataParser(paramLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaPlayer getPlayer(Locator paramLocator) {
/* 291 */     initNativeLayer();
/*     */     
/* 293 */     MediaPlayer mediaPlayer = PlatformManager.getManager().createMediaPlayer(paramLocator);
/* 294 */     if (null == mediaPlayer) {
/* 295 */       throw new MediaException("Could not create player!");
/*     */     }
/*     */ 
/*     */     
/* 299 */     allMediaPlayers.put(mediaPlayer, Boolean.TRUE);
/*     */     
/* 301 */     return mediaPlayer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Media getMedia(Locator paramLocator) {
/* 315 */     initNativeLayer();
/* 316 */     return PlatformManager.getManager().createMedia(paramLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMediaErrorListener(MediaErrorListener paramMediaErrorListener) {
/* 324 */     if (paramMediaErrorListener != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 329 */       for (ListIterator<WeakReference<MediaErrorListener>> listIterator = this.errorListeners.listIterator(); listIterator.hasNext(); ) {
/* 330 */         MediaErrorListener mediaErrorListener = ((WeakReference<MediaErrorListener>)listIterator.next()).get();
/* 331 */         if (mediaErrorListener == null) {
/* 332 */           listIterator.remove();
/*     */         }
/*     */       } 
/*     */       
/* 336 */       this.errorListeners.add(new WeakReference<>(paramMediaErrorListener));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeMediaErrorListener(MediaErrorListener paramMediaErrorListener) {
/* 345 */     if (paramMediaErrorListener != null)
/*     */     {
/* 347 */       for (ListIterator<WeakReference<MediaErrorListener>> listIterator = this.errorListeners.listIterator(); listIterator.hasNext(); ) {
/* 348 */         MediaErrorListener mediaErrorListener = ((WeakReference<MediaErrorListener>)listIterator.next()).get();
/* 349 */         if (mediaErrorListener == null || mediaErrorListener == paramMediaErrorListener) {
/* 350 */           listIterator.remove();
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerMediaPlayerForDispose(Object paramObject, MediaPlayer paramMediaPlayer) {
/* 366 */     MediaDisposer.addResourceDisposer(paramObject, paramMediaPlayer, playerDisposer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MediaPlayer> getAllMediaPlayers() {
/* 376 */     ArrayList<MediaPlayer> arrayList = null;
/*     */     
/* 378 */     if (!allMediaPlayers.isEmpty()) {
/* 379 */       arrayList = new ArrayList(allMediaPlayers.keySet());
/*     */     }
/*     */     
/* 382 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<WeakReference<MediaErrorListener>> getMediaErrorListeners() {
/* 389 */     return this.errorListeners;
/*     */   }
/*     */   
/*     */   private static class NativeMediaPlayerDisposer implements MediaDisposer.ResourceDisposer {
/*     */     private NativeMediaPlayerDisposer() {}
/*     */     
/*     */     public void disposeResource(Object param1Object) {
/* 396 */       MediaPlayer mediaPlayer = (MediaPlayer)param1Object;
/* 397 */       if (mediaPlayer != null)
/* 398 */         mediaPlayer.dispose(); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\NativeMediaManager.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */