/*     */ package com.sun.media.jfxmediaimpl;
/*     */ 
/*     */ import com.sun.media.jfxmedia.AudioClip;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NativeMediaAudioClip
/*     */   extends AudioClip
/*     */ {
/*     */   private URI sourceURI;
/*     */   private Locator mediaLocator;
/*     */   private AtomicInteger playCount;
/*     */   
/*     */   private NativeMediaAudioClip(URI paramURI) throws URISyntaxException, FileNotFoundException, IOException {
/*  46 */     this.sourceURI = paramURI;
/*  47 */     this.playCount = new AtomicInteger(0);
/*     */     
/*  49 */     if (Logger.canLog(1)) {
/*  50 */       Logger.logMsg(1, "Creating AudioClip for URI " + paramURI);
/*     */     }
/*     */     
/*  53 */     this.mediaLocator = new Locator(this.sourceURI);
/*  54 */     this.mediaLocator.init();
/*  55 */     this.mediaLocator.cacheMedia();
/*     */   }
/*     */   
/*     */   Locator getLocator() {
/*  59 */     return this.mediaLocator;
/*     */   }
/*     */   
/*     */   public static AudioClip load(URI paramURI) throws URISyntaxException, FileNotFoundException, IOException {
/*  63 */     return new NativeMediaAudioClip(paramURI);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AudioClip create(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  71 */     throw new UnsupportedOperationException("NativeMediaAudioClip does not support creating clips from raw sample data");
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioClip createSegment(double paramDouble1, double paramDouble2) throws IllegalArgumentException {
/*  76 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioClip createSegment(int paramInt1, int paramInt2) throws IllegalArgumentException {
/*  81 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioClip resample(int paramInt1, int paramInt2, int paramInt3) throws IllegalArgumentException, IOException {
/*  86 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioClip append(AudioClip paramAudioClip) throws IOException {
/*  91 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioClip flatten() {
/*  96 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPlaying() {
/* 101 */     return (this.playCount.get() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void play() {
/* 106 */     play(this.clipVolume, this.clipBalance, this.clipRate, this.clipPan, this.loopCount, this.clipPriority);
/*     */   }
/*     */ 
/*     */   
/*     */   public void play(double paramDouble) {
/* 111 */     play(paramDouble, this.clipBalance, this.clipRate, this.clipPan, this.loopCount, this.clipPriority);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void play(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt1, int paramInt2) {
/* 117 */     this.playCount.getAndIncrement();
/* 118 */     NativeMediaAudioClipPlayer.playClip(this, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 123 */     NativeMediaAudioClipPlayer.stopPlayers(this.mediaLocator);
/*     */   }
/*     */   
/*     */   public static void stopAllClips() {
/* 127 */     NativeMediaAudioClipPlayer.stopPlayers(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void playFinished() {
/* 133 */     this.playCount.decrementAndGet();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\NativeMediaAudioClip.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */