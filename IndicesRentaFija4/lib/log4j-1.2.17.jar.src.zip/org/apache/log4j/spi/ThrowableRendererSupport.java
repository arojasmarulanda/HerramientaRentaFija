package org.apache.log4j.spi;

public interface ThrowableRendererSupport {
  ThrowableRenderer getThrowableRenderer();
  
  void setThrowableRenderer(ThrowableRenderer paramThrowableRenderer);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\log4j-1.2.17.jar!\org\apache\log4j\spi\ThrowableRendererSupport.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.3
 */