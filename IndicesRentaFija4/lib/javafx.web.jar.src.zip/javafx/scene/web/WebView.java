/*      */ package javafx.scene.web;
/*      */ 
/*      */ import com.sun.java.scene.web.WebViewHelper;
/*      */ import com.sun.javafx.geom.BaseBounds;
/*      */ import com.sun.javafx.geom.PickRay;
/*      */ import com.sun.javafx.geom.transform.BaseTransform;
/*      */ import com.sun.javafx.scene.DirtyBits;
/*      */ import com.sun.javafx.scene.NodeHelper;
/*      */ import com.sun.javafx.scene.SceneHelper;
/*      */ import com.sun.javafx.scene.input.PickResultChooser;
/*      */ import com.sun.javafx.sg.prism.NGNode;
/*      */ import com.sun.javafx.sg.prism.web.NGWebView;
/*      */ import com.sun.javafx.tk.TKPulseListener;
/*      */ import com.sun.javafx.tk.Toolkit;
/*      */ import com.sun.javafx.webkit.InputMethodClientImpl;
/*      */ import com.sun.javafx.webkit.KeyCodeMap;
/*      */ import com.sun.webkit.WebPage;
/*      */ import com.sun.webkit.event.WCFocusEvent;
/*      */ import com.sun.webkit.event.WCInputMethodEvent;
/*      */ import com.sun.webkit.event.WCKeyEvent;
/*      */ import com.sun.webkit.event.WCMouseEvent;
/*      */ import com.sun.webkit.event.WCMouseWheelEvent;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.DoubleProperty;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyDoubleProperty;
/*      */ import javafx.beans.property.ReadOnlyDoubleWrapper;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.CssMetaData;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.StyleableBooleanProperty;
/*      */ import javafx.css.StyleableDoubleProperty;
/*      */ import javafx.css.StyleableObjectProperty;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.css.converter.BooleanConverter;
/*      */ import javafx.css.converter.EnumConverter;
/*      */ import javafx.css.converter.SizeConverter;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.EventType;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.geometry.Point2D;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Parent;
/*      */ import javafx.scene.input.DataFormat;
/*      */ import javafx.scene.input.DragEvent;
/*      */ import javafx.scene.input.Dragboard;
/*      */ import javafx.scene.input.InputMethodEvent;
/*      */ import javafx.scene.input.KeyEvent;
/*      */ import javafx.scene.input.MouseButton;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.input.ScrollEvent;
/*      */ import javafx.scene.input.TransferMode;
/*      */ import javafx.scene.text.FontSmoothingType;
/*      */ import javafx.stage.Stage;
/*      */ import javafx.stage.Window;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class WebView
/*      */   extends Parent
/*      */ {
/*  103 */   private static final Map<Object, Integer> idMap = new HashMap<>();
/*      */   
/*      */   private static final boolean DEFAULT_CONTEXT_MENU_ENABLED = true;
/*  106 */   private static final FontSmoothingType DEFAULT_FONT_SMOOTHING_TYPE = FontSmoothingType.LCD;
/*      */   
/*      */   private static final double DEFAULT_ZOOM = 1.0D;
/*      */   
/*      */   private static final double DEFAULT_FONT_SCALE = 1.0D;
/*      */   
/*      */   private static final double DEFAULT_MIN_WIDTH = 0.0D;
/*      */   
/*      */   private static final double DEFAULT_MIN_HEIGHT = 0.0D;
/*      */   
/*      */   private static final double DEFAULT_PREF_WIDTH = 800.0D;
/*      */   
/*      */   private static final double DEFAULT_PREF_HEIGHT = 600.0D;
/*      */   
/*      */   private static final double DEFAULT_MAX_WIDTH = 1.7976931348623157E308D;
/*      */   
/*      */   private static final double DEFAULT_MAX_HEIGHT = 1.7976931348623157E308D;
/*      */   
/*      */   private final WebPage page;
/*      */   
/*      */   private final WebEngine engine;
/*      */   
/*      */   private volatile InputMethodClientImpl imClient;
/*      */   
/*      */   private final TKPulseListener stagePulseListener;
/*      */   
/*      */   public final WebEngine getEngine() {
/*  133 */     return this.engine;
/*      */   }
/*      */   
/*  136 */   private final ReadOnlyDoubleWrapper width = new ReadOnlyDoubleWrapper(this, "width");
/*      */   
/*      */   public final double getWidth() {
/*  139 */     return this.width.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReadOnlyDoubleProperty widthProperty() {
/*  147 */     return this.width.getReadOnlyProperty();
/*      */   }
/*      */   private DoubleProperty zoom; private DoubleProperty fontScale; private DoubleProperty minWidth; private DoubleProperty minHeight;
/*  150 */   private final ReadOnlyDoubleWrapper height = new ReadOnlyDoubleWrapper(this, "height"); private DoubleProperty prefWidth; private DoubleProperty prefHeight; private DoubleProperty maxWidth;
/*      */   
/*      */   public final double getHeight() {
/*  153 */     return this.height.get();
/*      */   }
/*      */   private DoubleProperty maxHeight; private ObjectProperty<FontSmoothingType> fontSmoothingType; private BooleanProperty contextMenuEnabled; private static final int WK_DND_ACTION_NONE = 0;
/*      */   private static final int WK_DND_ACTION_COPY = 1;
/*      */   private static final int WK_DND_ACTION_MOVE = 2;
/*      */   private static final int WK_DND_ACTION_LINK = 1073741824;
/*      */   
/*      */   public ReadOnlyDoubleProperty heightProperty() {
/*  161 */     return this.height.getReadOnlyProperty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setZoom(double paramDouble) {
/*  170 */     WebEngine.checkThread();
/*  171 */     zoomProperty().set(paramDouble);
/*      */   }
/*      */   
/*      */   public final double getZoom() {
/*  175 */     return (this.zoom != null) ? 
/*  176 */       this.zoom.get() : 
/*  177 */       1.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DoubleProperty zoomProperty() {
/*  189 */     if (this.zoom == null) {
/*  190 */       this.zoom = new StyleableDoubleProperty(1.0D) {
/*      */           public void invalidated() {
/*  192 */             Toolkit.getToolkit().checkFxUserThread();
/*  193 */             WebView.this.page.setZoomFactor((float)get(), false);
/*      */           }
/*      */           
/*      */           public CssMetaData<WebView, Number> getCssMetaData() {
/*  197 */             return WebView.StyleableProperties.ZOOM;
/*      */           }
/*      */           public Object getBean() {
/*  200 */             return WebView.this;
/*      */           }
/*      */           public String getName() {
/*  203 */             return "zoom";
/*      */           }
/*      */         };
/*      */     }
/*  207 */     return this.zoom;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFontScale(double paramDouble) {
/*  219 */     WebEngine.checkThread();
/*  220 */     fontScaleProperty().set(paramDouble);
/*      */   }
/*      */   
/*      */   public final double getFontScale() {
/*  224 */     return (this.fontScale != null) ? 
/*  225 */       this.fontScale.get() : 
/*  226 */       1.0D;
/*      */   }
/*      */   
/*      */   public DoubleProperty fontScaleProperty() {
/*  230 */     if (this.fontScale == null) {
/*  231 */       this.fontScale = new StyleableDoubleProperty(1.0D) {
/*      */           public void invalidated() {
/*  233 */             Toolkit.getToolkit().checkFxUserThread();
/*  234 */             WebView.this.page.setZoomFactor((float)get(), true);
/*      */           }
/*      */           public CssMetaData<WebView, Number> getCssMetaData() {
/*  237 */             return WebView.StyleableProperties.FONT_SCALE;
/*      */           }
/*      */           public Object getBean() {
/*  240 */             return WebView.this;
/*      */           }
/*      */           public String getName() {
/*  243 */             return "fontScale";
/*      */           }
/*      */         };
/*      */     }
/*  247 */     return this.fontScale;
/*      */   }
/*      */ 
/*      */   
/*      */   public WebView() {
/*  252 */     WebViewHelper.initHelper(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  258 */     setNodeOrientation(NodeOrientation.LEFT_TO_RIGHT);
/*  259 */     getStyleClass().add("web-view");
/*  260 */     this.engine = new WebEngine();
/*  261 */     this.engine.setView(this);
/*  262 */     this.page = this.engine.getPage();
/*  263 */     this.page.setFontSmoothingType(DEFAULT_FONT_SMOOTHING_TYPE.ordinal());
/*      */     
/*  265 */     registerEventHandlers();
/*  266 */     this.stagePulseListener = (() -> handleStagePulse());
/*      */ 
/*      */     
/*  269 */     focusedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*      */           if (this.page != null) {
/*      */             WCFocusEvent wCFocusEvent = new WCFocusEvent(isFocused() ? 2 : 3, -1);
/*      */ 
/*      */             
/*      */             this.page.dispatchFocusEvent(wCFocusEvent);
/*      */           } 
/*      */         });
/*      */ 
/*      */     
/*  279 */     setFocusTraversable(true);
/*  280 */     Toolkit.getToolkit().addStageTkPulseListener(this.stagePulseListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isResizable() {
/*  287 */     return true;
/*      */   }
/*      */   
/*      */   public void resize(double paramDouble1, double paramDouble2) {
/*  291 */     if (paramDouble1 != this.width.get() || paramDouble2 != this.height.get()) {
/*  292 */       this.width.set(paramDouble1);
/*  293 */       this.height.set(paramDouble2);
/*  294 */       NodeHelper.markDirty(this, DirtyBits.NODE_GEOMETRY);
/*  295 */       NodeHelper.geomChanged(this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double minWidth(double paramDouble) {
/*  305 */     double d = getMinWidth();
/*  306 */     return (Double.isNaN(d) || d < 0.0D) ? 0.0D : d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double minHeight(double paramDouble) {
/*  315 */     double d = getMinHeight();
/*  316 */     return (Double.isNaN(d) || d < 0.0D) ? 0.0D : d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double prefWidth(double paramDouble) {
/*  326 */     double d = getPrefWidth();
/*  327 */     return (Double.isNaN(d) || d < 0.0D) ? 0.0D : d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double prefHeight(double paramDouble) {
/*  336 */     double d = getPrefHeight();
/*  337 */     return (Double.isNaN(d) || d < 0.0D) ? 0.0D : d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double maxWidth(double paramDouble) {
/*  345 */     double d = getMaxWidth();
/*  346 */     return (Double.isNaN(d) || d < 0.0D) ? 0.0D : d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double maxHeight(double paramDouble) {
/*  355 */     double d = getMaxHeight();
/*  356 */     return (Double.isNaN(d) || d < 0.0D) ? 0.0D : d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DoubleProperty minWidthProperty() {
/*  364 */     if (this.minWidth == null) {
/*  365 */       this.minWidth = new StyleableDoubleProperty(0.0D)
/*      */         {
/*      */           public void invalidated() {
/*  368 */             if (WebView.this.getParent() != null) {
/*  369 */               WebView.this.getParent().requestLayout();
/*      */             }
/*      */           }
/*      */           
/*      */           public CssMetaData<WebView, Number> getCssMetaData() {
/*  374 */             return WebView.StyleableProperties.MIN_WIDTH;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  378 */             return WebView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  382 */             return "minWidth";
/*      */           }
/*      */         };
/*      */     }
/*  386 */     return this.minWidth;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMinWidth(double paramDouble) {
/*  391 */     minWidthProperty().set(paramDouble);
/*      */   }
/*      */   
/*      */   public final double getMinWidth() {
/*  395 */     return (this.minWidth != null) ? 
/*  396 */       this.minWidth.get() : 
/*  397 */       0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DoubleProperty minHeightProperty() {
/*  405 */     if (this.minHeight == null) {
/*  406 */       this.minHeight = new StyleableDoubleProperty(0.0D)
/*      */         {
/*      */           public void invalidated() {
/*  409 */             if (WebView.this.getParent() != null) {
/*  410 */               WebView.this.getParent().requestLayout();
/*      */             }
/*      */           }
/*      */           
/*      */           public CssMetaData<WebView, Number> getCssMetaData() {
/*  415 */             return WebView.StyleableProperties.MIN_HEIGHT;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  419 */             return WebView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  423 */             return "minHeight";
/*      */           }
/*      */         };
/*      */     }
/*  427 */     return this.minHeight;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMinHeight(double paramDouble) {
/*  432 */     minHeightProperty().set(paramDouble);
/*      */   }
/*      */   
/*      */   public final double getMinHeight() {
/*  436 */     return (this.minHeight != null) ? 
/*  437 */       this.minHeight.get() : 
/*  438 */       0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMinSize(double paramDouble1, double paramDouble2) {
/*  447 */     setMinWidth(paramDouble1);
/*  448 */     setMinHeight(paramDouble2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DoubleProperty prefWidthProperty() {
/*  456 */     if (this.prefWidth == null) {
/*  457 */       this.prefWidth = new StyleableDoubleProperty(800.0D)
/*      */         {
/*      */           public void invalidated() {
/*  460 */             if (WebView.this.getParent() != null) {
/*  461 */               WebView.this.getParent().requestLayout();
/*      */             }
/*      */           }
/*      */           
/*      */           public CssMetaData<WebView, Number> getCssMetaData() {
/*  466 */             return WebView.StyleableProperties.PREF_WIDTH;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  470 */             return WebView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  474 */             return "prefWidth";
/*      */           }
/*      */         };
/*      */     }
/*  478 */     return this.prefWidth;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setPrefWidth(double paramDouble) {
/*  483 */     prefWidthProperty().set(paramDouble);
/*      */   }
/*      */   
/*      */   public final double getPrefWidth() {
/*  487 */     return (this.prefWidth != null) ? 
/*  488 */       this.prefWidth.get() : 
/*  489 */       800.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DoubleProperty prefHeightProperty() {
/*  497 */     if (this.prefHeight == null) {
/*  498 */       this.prefHeight = new StyleableDoubleProperty(600.0D)
/*      */         {
/*      */           public void invalidated() {
/*  501 */             if (WebView.this.getParent() != null) {
/*  502 */               WebView.this.getParent().requestLayout();
/*      */             }
/*      */           }
/*      */           
/*      */           public CssMetaData<WebView, Number> getCssMetaData() {
/*  507 */             return WebView.StyleableProperties.PREF_HEIGHT;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  511 */             return WebView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  515 */             return "prefHeight";
/*      */           }
/*      */         };
/*      */     }
/*  519 */     return this.prefHeight;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setPrefHeight(double paramDouble) {
/*  524 */     prefHeightProperty().set(paramDouble);
/*      */   }
/*      */   
/*      */   public final double getPrefHeight() {
/*  528 */     return (this.prefHeight != null) ? 
/*  529 */       this.prefHeight.get() : 
/*  530 */       600.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPrefSize(double paramDouble1, double paramDouble2) {
/*  539 */     setPrefWidth(paramDouble1);
/*  540 */     setPrefHeight(paramDouble2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DoubleProperty maxWidthProperty() {
/*  548 */     if (this.maxWidth == null) {
/*  549 */       this.maxWidth = new StyleableDoubleProperty(Double.MAX_VALUE)
/*      */         {
/*      */           public void invalidated() {
/*  552 */             if (WebView.this.getParent() != null) {
/*  553 */               WebView.this.getParent().requestLayout();
/*      */             }
/*      */           }
/*      */           
/*      */           public CssMetaData<WebView, Number> getCssMetaData() {
/*  558 */             return WebView.StyleableProperties.MAX_WIDTH;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  562 */             return WebView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  566 */             return "maxWidth";
/*      */           }
/*      */         };
/*      */     }
/*  570 */     return this.maxWidth;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMaxWidth(double paramDouble) {
/*  575 */     maxWidthProperty().set(paramDouble);
/*      */   }
/*      */   
/*      */   public final double getMaxWidth() {
/*  579 */     return (this.maxWidth != null) ? 
/*  580 */       this.maxWidth.get() : 
/*  581 */       Double.MAX_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DoubleProperty maxHeightProperty() {
/*  589 */     if (this.maxHeight == null) {
/*  590 */       this.maxHeight = new StyleableDoubleProperty(Double.MAX_VALUE)
/*      */         {
/*      */           public void invalidated() {
/*  593 */             if (WebView.this.getParent() != null) {
/*  594 */               WebView.this.getParent().requestLayout();
/*      */             }
/*      */           }
/*      */           
/*      */           public CssMetaData<WebView, Number> getCssMetaData() {
/*  599 */             return WebView.StyleableProperties.MAX_HEIGHT;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  603 */             return WebView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  607 */             return "maxHeight";
/*      */           }
/*      */         };
/*      */     }
/*  611 */     return this.maxHeight;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMaxHeight(double paramDouble) {
/*  616 */     maxHeightProperty().set(paramDouble);
/*      */   }
/*      */   
/*      */   public final double getMaxHeight() {
/*  620 */     return (this.maxHeight != null) ? 
/*  621 */       this.maxHeight.get() : 
/*  622 */       Double.MAX_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxSize(double paramDouble1, double paramDouble2) {
/*  631 */     setMaxWidth(paramDouble1);
/*  632 */     setMaxHeight(paramDouble2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFontSmoothingType(FontSmoothingType paramFontSmoothingType) {
/*  650 */     fontSmoothingTypeProperty().set(paramFontSmoothingType);
/*      */   }
/*      */   
/*      */   public final FontSmoothingType getFontSmoothingType() {
/*  654 */     return (this.fontSmoothingType != null) ? 
/*  655 */       this.fontSmoothingType.get() : 
/*  656 */       DEFAULT_FONT_SMOOTHING_TYPE;
/*      */   }
/*      */   
/*      */   public final ObjectProperty<FontSmoothingType> fontSmoothingTypeProperty() {
/*  660 */     if (this.fontSmoothingType == null) {
/*  661 */       this.fontSmoothingType = new StyleableObjectProperty<FontSmoothingType>(DEFAULT_FONT_SMOOTHING_TYPE)
/*      */         {
/*      */           public void invalidated() {
/*  664 */             Toolkit.getToolkit().checkFxUserThread();
/*  665 */             WebView.this.page.setFontSmoothingType(get().ordinal());
/*      */           }
/*      */           
/*      */           public CssMetaData<WebView, FontSmoothingType> getCssMetaData() {
/*  669 */             return WebView.StyleableProperties.FONT_SMOOTHING_TYPE;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  673 */             return WebView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  677 */             return "fontSmoothingType";
/*      */           }
/*      */         };
/*      */     }
/*  681 */     return this.fontSmoothingType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setContextMenuEnabled(boolean paramBoolean) {
/*  693 */     contextMenuEnabledProperty().set(paramBoolean);
/*      */   }
/*      */   
/*      */   public final boolean isContextMenuEnabled() {
/*  697 */     return (this.contextMenuEnabled == null) ? true : 
/*      */       
/*  699 */       this.contextMenuEnabled.get();
/*      */   }
/*      */   
/*      */   public final BooleanProperty contextMenuEnabledProperty() {
/*  703 */     if (this.contextMenuEnabled == null) {
/*  704 */       this.contextMenuEnabled = new StyleableBooleanProperty(true) {
/*      */           public void invalidated() {
/*  706 */             Toolkit.getToolkit().checkFxUserThread();
/*  707 */             WebView.this.page.setContextMenuEnabled(get());
/*      */           }
/*      */           
/*      */           public CssMetaData<WebView, Boolean> getCssMetaData() {
/*  711 */             return WebView.StyleableProperties.CONTEXT_MENU_ENABLED;
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  715 */             return WebView.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  719 */             return "contextMenuEnabled";
/*      */           }
/*      */         };
/*      */     }
/*  723 */     return this.contextMenuEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class StyleableProperties
/*      */   {
/*  731 */     private static final CssMetaData<WebView, Boolean> CONTEXT_MENU_ENABLED = new CssMetaData<WebView, Boolean>("-fx-context-menu-enabled", 
/*      */ 
/*      */         
/*  734 */         BooleanConverter.getInstance(), 
/*  735 */         Boolean.valueOf(true))
/*      */       {
/*      */         public boolean isSettable(WebView param2WebView) {
/*  738 */           return (param2WebView.contextMenuEnabled == null || !param2WebView.contextMenuEnabled.isBound());
/*      */         }
/*      */         public StyleableProperty<Boolean> getStyleableProperty(WebView param2WebView) {
/*  741 */           return (StyleableProperty<Boolean>)param2WebView.contextMenuEnabledProperty();
/*      */         }
/*      */       };
/*      */     
/*  745 */     private static final CssMetaData<WebView, FontSmoothingType> FONT_SMOOTHING_TYPE = new CssMetaData<WebView, FontSmoothingType>("-fx-font-smoothing-type", (StyleConverter)new EnumConverter(FontSmoothingType.class), WebView
/*      */ 
/*      */ 
/*      */         
/*  749 */         .DEFAULT_FONT_SMOOTHING_TYPE)
/*      */       {
/*      */         public boolean isSettable(WebView param2WebView) {
/*  752 */           return (param2WebView.fontSmoothingType == null || !param2WebView.fontSmoothingType.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<FontSmoothingType> getStyleableProperty(WebView param2WebView) {
/*  756 */           return (StyleableProperty<FontSmoothingType>)param2WebView.fontSmoothingTypeProperty();
/*      */         }
/*      */       };
/*      */     
/*  760 */     private static final CssMetaData<WebView, Number> ZOOM = new CssMetaData<WebView, Number>("-fx-zoom", 
/*      */ 
/*      */         
/*  763 */         SizeConverter.getInstance(), 
/*  764 */         Double.valueOf(1.0D)) {
/*      */         public boolean isSettable(WebView param2WebView) {
/*  766 */           return (param2WebView.zoom == null || !param2WebView.zoom.isBound());
/*      */         }
/*      */         public StyleableProperty<Number> getStyleableProperty(WebView param2WebView) {
/*  769 */           return (StyleableProperty<Number>)param2WebView.zoomProperty();
/*      */         }
/*      */       };
/*      */     
/*  773 */     private static final CssMetaData<WebView, Number> FONT_SCALE = new CssMetaData<WebView, Number>("-fx-font-scale", 
/*      */ 
/*      */         
/*  776 */         SizeConverter.getInstance(), 
/*  777 */         Double.valueOf(1.0D))
/*      */       {
/*      */         public boolean isSettable(WebView param2WebView) {
/*  780 */           return (param2WebView.fontScale == null || !param2WebView.fontScale.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(WebView param2WebView) {
/*  784 */           return (StyleableProperty<Number>)param2WebView.fontScaleProperty();
/*      */         }
/*      */       };
/*      */     
/*  788 */     private static final CssMetaData<WebView, Number> MIN_WIDTH = new CssMetaData<WebView, Number>("-fx-min-width", 
/*      */ 
/*      */         
/*  791 */         SizeConverter.getInstance(), 
/*  792 */         Double.valueOf(0.0D))
/*      */       {
/*      */         public boolean isSettable(WebView param2WebView) {
/*  795 */           return (param2WebView.minWidth == null || !param2WebView.minWidth.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(WebView param2WebView) {
/*  799 */           return (StyleableProperty<Number>)param2WebView.minWidthProperty();
/*      */         }
/*      */       };
/*      */     
/*  803 */     private static final CssMetaData<WebView, Number> MIN_HEIGHT = new CssMetaData<WebView, Number>("-fx-min-height", 
/*      */ 
/*      */         
/*  806 */         SizeConverter.getInstance(), 
/*  807 */         Double.valueOf(0.0D))
/*      */       {
/*      */         public boolean isSettable(WebView param2WebView) {
/*  810 */           return (param2WebView.minHeight == null || !param2WebView.minHeight.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(WebView param2WebView) {
/*  814 */           return (StyleableProperty<Number>)param2WebView.minHeightProperty();
/*      */         }
/*      */       };
/*      */     
/*  818 */     private static final CssMetaData<WebView, Number> MAX_WIDTH = new CssMetaData<WebView, Number>("-fx-max-width", 
/*      */ 
/*      */         
/*  821 */         SizeConverter.getInstance(), 
/*  822 */         Double.valueOf(Double.MAX_VALUE))
/*      */       {
/*      */         public boolean isSettable(WebView param2WebView) {
/*  825 */           return (param2WebView.maxWidth == null || !param2WebView.maxWidth.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(WebView param2WebView) {
/*  829 */           return (StyleableProperty<Number>)param2WebView.maxWidthProperty();
/*      */         }
/*      */       };
/*      */     
/*  833 */     private static final CssMetaData<WebView, Number> MAX_HEIGHT = new CssMetaData<WebView, Number>("-fx-max-height", 
/*      */ 
/*      */         
/*  836 */         SizeConverter.getInstance(), 
/*  837 */         Double.valueOf(Double.MAX_VALUE))
/*      */       {
/*      */         public boolean isSettable(WebView param2WebView) {
/*  840 */           return (param2WebView.maxHeight == null || !param2WebView.maxHeight.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(WebView param2WebView) {
/*  844 */           return (StyleableProperty<Number>)param2WebView.maxHeightProperty();
/*      */         }
/*      */       };
/*      */     
/*  848 */     private static final CssMetaData<WebView, Number> PREF_WIDTH = new CssMetaData<WebView, Number>("-fx-pref-width", 
/*      */ 
/*      */         
/*  851 */         SizeConverter.getInstance(), 
/*  852 */         Double.valueOf(800.0D))
/*      */       {
/*      */         public boolean isSettable(WebView param2WebView) {
/*  855 */           return (param2WebView.prefWidth == null || !param2WebView.prefWidth.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(WebView param2WebView) {
/*  859 */           return (StyleableProperty<Number>)param2WebView.prefWidthProperty();
/*      */         }
/*      */       };
/*      */     
/*  863 */     private static final CssMetaData<WebView, Number> PREF_HEIGHT = new CssMetaData<WebView, Number>("-fx-pref-height", 
/*      */ 
/*      */         
/*  866 */         SizeConverter.getInstance(), 
/*  867 */         Double.valueOf(600.0D))
/*      */       {
/*      */         public boolean isSettable(WebView param2WebView) {
/*  870 */           return (param2WebView.prefHeight == null || !param2WebView.prefHeight.isBound());
/*      */         }
/*      */         
/*      */         public StyleableProperty<Number> getStyleableProperty(WebView param2WebView) {
/*  874 */           return (StyleableProperty<Number>)param2WebView.prefHeightProperty();
/*      */         }
/*      */       };
/*      */ 
/*      */     
/*      */     private static final List<CssMetaData<? extends Styleable, ?>> STYLEABLES;
/*      */     
/*      */     static {
/*  882 */       ArrayList<CssMetaData<? extends Styleable, ?>> arrayList = new ArrayList<>(Parent.getClassCssMetaData());
/*  883 */       arrayList.add(CONTEXT_MENU_ENABLED);
/*  884 */       arrayList.add(FONT_SMOOTHING_TYPE);
/*  885 */       arrayList.add(ZOOM);
/*  886 */       arrayList.add(FONT_SCALE);
/*  887 */       arrayList.add(MIN_WIDTH);
/*  888 */       arrayList.add(PREF_WIDTH);
/*  889 */       arrayList.add(MAX_WIDTH);
/*  890 */       arrayList.add(MIN_HEIGHT);
/*  891 */       arrayList.add(PREF_HEIGHT);
/*  892 */       arrayList.add(MAX_HEIGHT);
/*  893 */       STYLEABLES = Collections.unmodifiableList(arrayList);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<CssMetaData<? extends Styleable, ?>> getClassCssMetaData() {
/*  903 */     return StyleableProperties.STYLEABLES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<CssMetaData<? extends Styleable, ?>> getCssMetaData() {
/*  912 */     return getClassCssMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isTreeReallyVisible() {
/*  920 */     if (getScene() == null) {
/*  921 */       return false;
/*      */     }
/*      */     
/*  924 */     Window window = getScene().getWindow();
/*      */     
/*  926 */     if (window == null) {
/*  927 */       return false;
/*      */     }
/*      */     
/*  930 */     boolean bool = (window instanceof Stage) ? ((Stage)window).isIconified() : false;
/*      */     
/*  932 */     return (NodeHelper.isTreeVisible(this) && window
/*  933 */       .isShowing() && window
/*  934 */       .getWidth() > 0.0D && window
/*  935 */       .getHeight() > 0.0D && !bool);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleStagePulse() {
/*  954 */     if (this.page == null)
/*      */       return; 
/*  956 */     boolean bool = isTreeReallyVisible();
/*      */     
/*  958 */     if (bool) {
/*  959 */       if (this.page.isDirty()) {
/*  960 */         SceneHelper.setAllowPGAccess(true);
/*  961 */         NGWebView nGWebView = (NGWebView)NodeHelper.getPeer(this);
/*  962 */         nGWebView.update();
/*  963 */         if (this.page.isRepaintPending()) {
/*  964 */           NodeHelper.markDirty(this, DirtyBits.WEBVIEW_VIEW);
/*      */         }
/*  966 */         SceneHelper.setAllowPGAccess(false);
/*      */       } 
/*      */     } else {
/*  969 */       this.page.dropRenderFrames();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void processMouseEvent(MouseEvent paramMouseEvent) {
/*  974 */     if (this.page == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  979 */     EventType<? extends MouseEvent> eventType = paramMouseEvent.getEventType();
/*  980 */     double d1 = paramMouseEvent.getX();
/*  981 */     double d2 = paramMouseEvent.getY();
/*  982 */     double d3 = paramMouseEvent.getScreenX();
/*  983 */     double d4 = paramMouseEvent.getScreenY();
/*  984 */     if (eventType == MouseEvent.MOUSE_EXITED) {
/*  985 */       eventType = MouseEvent.MOUSE_MOVED;
/*  986 */       d1 = -32768.0D;
/*  987 */       d2 = -32768.0D;
/*  988 */       Point2D point2D = localToScreen(d1, d2);
/*  989 */       if (point2D == null) {
/*      */         return;
/*      */       }
/*  992 */       d3 = point2D.getX();
/*  993 */       d4 = point2D.getY();
/*      */     } 
/*      */     
/*  996 */     Integer integer = idMap.get(eventType);
/*  997 */     if (integer == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1007 */     WCMouseEvent wCMouseEvent = new WCMouseEvent(integer.intValue(), ((Integer)idMap.get(paramMouseEvent.getButton())).intValue(), paramMouseEvent.getClickCount(), (int)d1, (int)d2, (int)d3, (int)d4, System.currentTimeMillis(), paramMouseEvent.isShiftDown(), paramMouseEvent.isControlDown(), paramMouseEvent.isAltDown(), paramMouseEvent.isMetaDown(), paramMouseEvent.isPopupTrigger());
/* 1008 */     this.page.dispatchMouseEvent(wCMouseEvent);
/* 1009 */     paramMouseEvent.consume();
/*      */   }
/*      */   
/*      */   private void processScrollEvent(ScrollEvent paramScrollEvent) {
/* 1013 */     if (this.page == null) {
/*      */       return;
/*      */     }
/* 1016 */     double d1 = -paramScrollEvent.getDeltaX() * getFontScale() * getScaleX();
/* 1017 */     double d2 = -paramScrollEvent.getDeltaY() * getFontScale() * getScaleY();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1023 */     WCMouseWheelEvent wCMouseWheelEvent = new WCMouseWheelEvent((int)paramScrollEvent.getX(), (int)paramScrollEvent.getY(), (int)paramScrollEvent.getScreenX(), (int)paramScrollEvent.getScreenY(), System.currentTimeMillis(), paramScrollEvent.isShiftDown(), paramScrollEvent.isControlDown(), paramScrollEvent.isAltDown(), paramScrollEvent.isMetaDown(), (float)d1, (float)d2);
/* 1024 */     this.page.dispatchMouseWheelEvent(wCMouseWheelEvent);
/* 1025 */     paramScrollEvent.consume();
/*      */   }
/*      */   
/*      */   private void processKeyEvent(KeyEvent paramKeyEvent) {
/* 1029 */     if (this.page == null)
/*      */       return; 
/* 1031 */     String str1 = null;
/* 1032 */     String str2 = null;
/* 1033 */     int i = 0;
/* 1034 */     if (paramKeyEvent.getEventType() == KeyEvent.KEY_TYPED) {
/* 1035 */       str1 = paramKeyEvent.getCharacter();
/*      */     } else {
/* 1037 */       KeyCodeMap.Entry entry = KeyCodeMap.lookup(paramKeyEvent.getCode());
/* 1038 */       str2 = entry.getKeyIdentifier();
/* 1039 */       i = entry.getWindowsVirtualKeyCode();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1048 */     WCKeyEvent wCKeyEvent = new WCKeyEvent(((Integer)idMap.get(paramKeyEvent.getEventType())).intValue(), str1, str2, i, paramKeyEvent.isShiftDown(), paramKeyEvent.isControlDown(), paramKeyEvent.isAltDown(), paramKeyEvent.isMetaDown(), System.currentTimeMillis());
/* 1049 */     if (this.page.dispatchKeyEvent(wCKeyEvent)) {
/* 1050 */       paramKeyEvent.consume();
/*      */     }
/*      */   }
/*      */   
/*      */   private InputMethodClientImpl getInputMethodClient() {
/* 1055 */     if (this.imClient == null) {
/* 1056 */       synchronized (this) {
/* 1057 */         if (this.imClient == null) {
/* 1058 */           this.imClient = new InputMethodClientImpl(this, this.page);
/*      */         }
/*      */       } 
/*      */     }
/* 1062 */     return this.imClient;
/*      */   }
/*      */   
/*      */   private void processInputMethodEvent(InputMethodEvent paramInputMethodEvent) {
/* 1066 */     if (this.page == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1070 */     if (!getInputMethodClient().getInputMethodState()) {
/* 1071 */       paramInputMethodEvent.consume();
/*      */       
/*      */       return;
/*      */     } 
/* 1075 */     WCInputMethodEvent wCInputMethodEvent = InputMethodClientImpl.convertToWCInputMethodEvent(paramInputMethodEvent);
/* 1076 */     if (this.page.dispatchInputMethodEvent(wCInputMethodEvent)) {
/* 1077 */       paramInputMethodEvent.consume();
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getWKDndEventType(EventType<DragEvent> paramEventType) {
/* 1088 */     byte b = 0;
/* 1089 */     if (paramEventType == DragEvent.DRAG_ENTERED) {
/* 1090 */       b = 0;
/* 1091 */     } else if (paramEventType == DragEvent.DRAG_EXITED) {
/* 1092 */       b = 3;
/* 1093 */     } else if (paramEventType == DragEvent.DRAG_OVER) {
/* 1094 */       b = 1;
/* 1095 */     } else if (paramEventType == DragEvent.DRAG_DROPPED) {
/* 1096 */       b = 4;
/* 1097 */     }  return b;
/*      */   }
/*      */   
/*      */   private static int getWKDndAction(TransferMode... paramVarArgs) {
/* 1101 */     int i = 0;
/* 1102 */     for (TransferMode transferMode : paramVarArgs) {
/* 1103 */       if (transferMode == TransferMode.COPY) {
/* 1104 */         i |= 0x1;
/* 1105 */       } else if (transferMode == TransferMode.MOVE) {
/* 1106 */         i |= 0x2;
/* 1107 */       } else if (transferMode == TransferMode.LINK) {
/* 1108 */         i |= 0x40000000;
/*      */       } 
/* 1110 */     }  return i;
/*      */   }
/*      */   
/*      */   private static TransferMode[] getFXDndAction(int paramInt) {
/* 1114 */     LinkedList<TransferMode> linkedList = new LinkedList();
/* 1115 */     if ((paramInt & 0x1) != 0)
/* 1116 */       linkedList.add(TransferMode.COPY); 
/* 1117 */     if ((paramInt & 0x2) != 0)
/* 1118 */       linkedList.add(TransferMode.MOVE); 
/* 1119 */     if ((paramInt & 0x40000000) != 0)
/* 1120 */       linkedList.add(TransferMode.LINK); 
/* 1121 */     return linkedList.<TransferMode>toArray(new TransferMode[0]);
/*      */   }
/*      */   
/*      */   private void registerEventHandlers() {
/* 1125 */     addEventHandler(KeyEvent.ANY, paramKeyEvent -> processKeyEvent(paramKeyEvent));
/*      */ 
/*      */ 
/*      */     
/* 1129 */     addEventHandler(MouseEvent.ANY, paramMouseEvent -> {
/*      */           processMouseEvent(paramMouseEvent);
/*      */ 
/*      */           
/*      */           if (paramMouseEvent.isDragDetect() && !this.page.isDragConfirmed()) {
/*      */             paramMouseEvent.setDragDetect(false);
/*      */           }
/*      */         });
/*      */ 
/*      */     
/* 1139 */     addEventHandler(ScrollEvent.SCROLL, paramScrollEvent -> processScrollEvent(paramScrollEvent));
/*      */ 
/*      */ 
/*      */     
/* 1143 */     setOnInputMethodTextChanged(paramInputMethodEvent -> processInputMethodEvent(paramInputMethodEvent));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1149 */     EventHandler<? super DragEvent> eventHandler = paramDragEvent -> {
/*      */         try {
/*      */           Dragboard dragboard = paramDragEvent.getDragboard();
/*      */           
/*      */           LinkedList<String> linkedList1 = new LinkedList();
/*      */           
/*      */           LinkedList<String> linkedList2 = new LinkedList();
/*      */           
/*      */           for (DataFormat dataFormat : dragboard.getContentTypes()) {
/*      */             Object object = dragboard.getContent(dataFormat);
/*      */             
/*      */             if (object != null) {
/*      */               for (String str : dataFormat.getIdentifiers()) {
/*      */                 linkedList1.add(str);
/*      */                 
/*      */                 linkedList2.add(object.toString());
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/*      */           if (!linkedList1.isEmpty()) {
/*      */             int i = getWKDndEventType(paramDragEvent.getEventType());
/*      */             
/*      */             int j = this.page.dispatchDragOperation(i, linkedList1.<String>toArray(new String[0]), linkedList2.<String>toArray(new String[0]), (int)paramDragEvent.getX(), (int)paramDragEvent.getY(), (int)paramDragEvent.getScreenX(), (int)paramDragEvent.getScreenY(), getWKDndAction(dragboard.getTransferModes().<TransferMode>toArray(new TransferMode[0])));
/*      */             
/*      */             if (i != 4 || j != 0) {
/*      */               paramDragEvent.acceptTransferModes(getFXDndAction(j));
/*      */             }
/*      */             
/*      */             paramDragEvent.consume();
/*      */           } 
/* 1180 */         } catch (SecurityException securityException) {}
/*      */       };
/*      */ 
/*      */ 
/*      */     
/* 1185 */     setOnDragEntered(eventHandler);
/* 1186 */     setOnDragExited(eventHandler);
/* 1187 */     setOnDragOver(eventHandler);
/* 1188 */     setOnDragDropped(eventHandler);
/*      */ 
/*      */     
/* 1191 */     setOnDragDetected(paramMouseEvent -> {
/*      */           if (this.page.isDragConfirmed()) {
/*      */             this.page.confirmStartDrag();
/*      */             paramMouseEvent.consume();
/*      */           } 
/*      */         });
/* 1197 */     setOnDragDone(paramDragEvent -> {
/*      */           this.page.dispatchDragOperation(104, null, null, (int)paramDragEvent.getX(), (int)paramDragEvent.getY(), (int)paramDragEvent.getScreenX(), (int)paramDragEvent.getScreenY(), getWKDndAction(new TransferMode[] { paramDragEvent.getAcceptedTransferMode() }));
/*      */ 
/*      */ 
/*      */           
/*      */           paramDragEvent.consume();
/*      */         });
/*      */ 
/*      */ 
/*      */     
/* 1207 */     setInputMethodRequests(getInputMethodClient());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doPickNodeLocal(PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 1214 */     NodeHelper.intersects(this, paramPickRay, paramPickResultChooser);
/*      */   }
/*      */   
/*      */   protected ObservableList<Node> getChildren() {
/* 1218 */     return super.getChildren();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private NGNode doCreatePeer() {
/* 1227 */     return new NGWebView();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BaseBounds doComputeGeomBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 1234 */     paramBaseBounds.deriveWithNewBounds(0.0F, 0.0F, 0.0F, (float)getWidth(), (float)getHeight(), 0.0F);
/* 1235 */     paramBaseTransform.transform(paramBaseBounds, paramBaseBounds);
/* 1236 */     return paramBaseBounds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doTransformsChanged() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doComputeContains(double paramDouble1, double paramDouble2) {
/* 1250 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doUpdatePeer() {
/* 1257 */     NGWebView nGWebView = (NGWebView)NodeHelper.getPeer(this);
/*      */     
/* 1259 */     if (NodeHelper.isDirty(this, DirtyBits.NODE_CONTENTS)) {
/* 1260 */       nGWebView.setPage(this.page);
/*      */     }
/* 1262 */     if (NodeHelper.isDirty(this, DirtyBits.NODE_GEOMETRY)) {
/* 1263 */       nGWebView.resize((float)getWidth(), (float)getHeight());
/*      */     }
/* 1265 */     if (NodeHelper.isDirty(this, DirtyBits.WEBVIEW_VIEW)) {
/* 1266 */       nGWebView.requestRender();
/*      */     }
/*      */   }
/*      */   
/*      */   static {
/* 1271 */     WebViewHelper.setWebViewAccessor(new WebViewHelper.WebViewAccessor()
/*      */         {
/*      */           public NGNode doCreatePeer(Node param1Node) {
/* 1274 */             return ((WebView)param1Node).doCreatePeer();
/*      */           }
/*      */ 
/*      */           
/*      */           public void doUpdatePeer(Node param1Node) {
/* 1279 */             ((WebView)param1Node).doUpdatePeer();
/*      */           }
/*      */ 
/*      */           
/*      */           public void doTransformsChanged(Node param1Node) {
/* 1284 */             ((WebView)param1Node).doTransformsChanged();
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform) {
/* 1290 */             return ((WebView)param1Node).doComputeGeomBounds(param1BaseBounds, param1BaseTransform);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2) {
/* 1295 */             return ((WebView)param1Node).doComputeContains(param1Double1, param1Double2);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void doPickNodeLocal(Node param1Node, PickRay param1PickRay, PickResultChooser param1PickResultChooser) {
/* 1301 */             ((WebView)param1Node).doPickNodeLocal(param1PickRay, param1PickResultChooser);
/*      */           }
/*      */         });
/*      */     
/* 1305 */     idMap.put(MouseButton.NONE, Integer.valueOf(0));
/* 1306 */     idMap.put(MouseButton.PRIMARY, Integer.valueOf(1));
/* 1307 */     idMap.put(MouseButton.MIDDLE, Integer.valueOf(2));
/* 1308 */     idMap.put(MouseButton.SECONDARY, Integer.valueOf(4));
/*      */     
/* 1310 */     idMap.put(MouseEvent.MOUSE_PRESSED, Integer.valueOf(0));
/* 1311 */     idMap.put(MouseEvent.MOUSE_RELEASED, Integer.valueOf(1));
/* 1312 */     idMap.put(MouseEvent.MOUSE_MOVED, Integer.valueOf(2));
/* 1313 */     idMap.put(MouseEvent.MOUSE_DRAGGED, Integer.valueOf(3));
/*      */     
/* 1315 */     idMap.put(KeyEvent.KEY_PRESSED, Integer.valueOf(1));
/* 1316 */     idMap.put(KeyEvent.KEY_RELEASED, Integer.valueOf(2));
/* 1317 */     idMap.put(KeyEvent.KEY_TYPED, Integer.valueOf(0));
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\javafx\scene\web\WebView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */