/*     */ package javafx.scene.web;
/*     */ 
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.event.EventType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebErrorEvent
/*     */   extends Event
/*     */ {
/*  45 */   public static final EventType<WebErrorEvent> ANY = (EventType)new EventType<>(Event.ANY, "WEB_ERROR");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public static final EventType<WebErrorEvent> USER_DATA_DIRECTORY_ALREADY_IN_USE = new EventType<>(ANY, "USER_DATA_DIRECTORY_ALREADY_IN_USE");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public static final EventType<WebErrorEvent> USER_DATA_DIRECTORY_IO_ERROR = new EventType<>(ANY, "USER_DATA_DIRECTORY_IO_ERROR");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public static final EventType<WebErrorEvent> USER_DATA_DIRECTORY_SECURITY_ERROR = new EventType<>(ANY, "USER_DATA_DIRECTORY_SECURITY_ERROR");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String message;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Throwable exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebErrorEvent(@NamedArg("source") Object paramObject, @NamedArg("type") EventType<WebErrorEvent> paramEventType, @NamedArg("message") String paramString, @NamedArg("exception") Throwable paramThrowable) {
/* 141 */     super(paramObject, (EventTarget)null, (EventType)paramEventType);
/* 142 */     this.message = paramString;
/* 143 */     this.exception = paramThrowable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 153 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getException() {
/* 162 */     return this.exception;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 169 */     return String.format("WebErrorEvent [source = %s, eventType = %s, message = \"%s\", exception = %s]", new Object[] {
/*     */           
/* 171 */           getSource(), getEventType(), getMessage(), getException()
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\javafx\scene\web\WebErrorEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */