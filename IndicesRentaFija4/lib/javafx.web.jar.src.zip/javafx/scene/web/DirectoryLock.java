/*     */ package javafx.scene.web;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.nio.channels.OverlappingFileLockException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DirectoryLock
/*     */ {
/*  41 */   private static final PlatformLogger logger = PlatformLogger.getLogger(DirectoryLock.class.getName());
/*  42 */   private static final Map<File, Descriptor> descriptors = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private Descriptor descriptor;
/*     */ 
/*     */ 
/*     */   
/*     */   DirectoryLock(File paramFile) throws IOException, DirectoryAlreadyInUseException {
/*  51 */     paramFile = canonicalize(paramFile);
/*  52 */     this.descriptor = descriptors.get(paramFile);
/*  53 */     if (this.descriptor == null) {
/*  54 */       File file = lockFile(paramFile);
/*  55 */       RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");
/*     */       try {
/*  57 */         FileLock fileLock = randomAccessFile.getChannel().tryLock();
/*  58 */         if (fileLock == null) {
/*  59 */           throw new DirectoryAlreadyInUseException(paramFile
/*  60 */               .toString(), null);
/*     */         }
/*  62 */         this.descriptor = new Descriptor(paramFile, randomAccessFile, fileLock);
/*  63 */         descriptors.put(paramFile, this.descriptor);
/*  64 */       } catch (OverlappingFileLockException overlappingFileLockException) {
/*  65 */         throw new DirectoryAlreadyInUseException(paramFile
/*  66 */             .toString(), overlappingFileLockException);
/*     */       } finally {
/*  68 */         if (this.descriptor == null) {
/*     */           try {
/*  70 */             randomAccessFile.close();
/*  71 */           } catch (IOException iOException) {
/*  72 */             logger.warning(String.format("Error closing [%s]", new Object[] { file }), iOException);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  78 */     this.descriptor.referenceCount++;
/*     */   }
/*     */ 
/*     */   
/*     */   void close() {
/*  83 */     if (this.descriptor == null) {
/*     */       return;
/*     */     }
/*  86 */     this.descriptor.referenceCount--;
/*  87 */     if (this.descriptor.referenceCount == 0) {
/*     */       try {
/*  89 */         this.descriptor.lock.release();
/*  90 */       } catch (IOException iOException) {
/*  91 */         logger.warning(String.format("Error releasing lock on [%s]", new Object[] {
/*  92 */                 lockFile(Descriptor.access$300(this.descriptor)) }), iOException);
/*     */       } 
/*     */       try {
/*  95 */         this.descriptor.lockRaf.close();
/*  96 */       } catch (IOException iOException) {
/*  97 */         logger.warning(String.format("Error closing [%s]", new Object[] {
/*  98 */                 lockFile(Descriptor.access$300(this.descriptor)) }), iOException);
/*     */       } 
/* 100 */       descriptors.remove(this.descriptor.directory);
/*     */     } 
/* 102 */     this.descriptor = null;
/*     */   }
/*     */ 
/*     */   
/*     */   static int referenceCount(File paramFile) throws IOException {
/* 107 */     Descriptor descriptor = descriptors.get(canonicalize(paramFile));
/* 108 */     return (descriptor == null) ? 0 : descriptor.referenceCount;
/*     */   }
/*     */   
/*     */   static File canonicalize(File paramFile) throws IOException {
/* 112 */     String str = paramFile.getCanonicalPath();
/* 113 */     if (str.length() > 0 && str
/* 114 */       .charAt(str.length() - 1) != File.separatorChar)
/*     */     {
/* 116 */       str = str + str;
/*     */     }
/* 118 */     return new File(str);
/*     */   }
/*     */   
/*     */   private static File lockFile(File paramFile) {
/* 122 */     return new File(paramFile, ".lock");
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Descriptor
/*     */   {
/*     */     private final File directory;
/*     */     
/*     */     private final RandomAccessFile lockRaf;
/*     */     
/*     */     private final FileLock lock;
/*     */     private int referenceCount;
/*     */     
/*     */     private Descriptor(File param1File, RandomAccessFile param1RandomAccessFile, FileLock param1FileLock) {
/* 136 */       this.directory = param1File;
/* 137 */       this.lockRaf = param1RandomAccessFile;
/* 138 */       this.lock = param1FileLock;
/*     */     }
/*     */   }
/*     */   
/*     */   final class DirectoryAlreadyInUseException extends Exception {
/*     */     DirectoryAlreadyInUseException(String param1String, Throwable param1Throwable) {
/* 144 */       super(param1String, param1Throwable);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\javafx\scene\web\DirectoryLock.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */