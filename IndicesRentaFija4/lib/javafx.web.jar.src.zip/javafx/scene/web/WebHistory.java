/*     */ package javafx.scene.web;
/*     */ 
/*     */ import com.sun.webkit.BackForwardList;
/*     */ import com.sun.webkit.WebPage;
/*     */ import com.sun.webkit.event.WCChangeEvent;
/*     */ import java.net.URL;
/*     */ import java.util.Date;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerWrapper;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.beans.property.SimpleIntegerProperty;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebHistory
/*     */ {
/*     */   private final BackForwardList bfl;
/*     */   private final ObservableList<Entry> list;
/*     */   private final ObservableList<Entry> ulist;
/*     */   private final ReadOnlyIntegerWrapper currentIndex;
/*     */   private IntegerProperty maxSize;
/*     */   
/*     */   public final class Entry
/*     */   {
/*     */     private final URL url;
/*  79 */     private final ReadOnlyObjectWrapper<String> title = new ReadOnlyObjectWrapper<>(this, "title");
/*  80 */     private final ReadOnlyObjectWrapper<Date> lastVisitedDate = new ReadOnlyObjectWrapper<>(this, "lastVisitedDate");
/*     */     private final BackForwardList.Entry peer;
/*     */     
/*     */     private Entry(BackForwardList.Entry param1Entry) {
/*  84 */       this.url = param1Entry.getURL();
/*  85 */       this.title.set(param1Entry.getTitle());
/*  86 */       this.lastVisitedDate.set(param1Entry.getLastVisitedDate());
/*  87 */       this.peer = param1Entry;
/*     */       
/*  89 */       param1Entry.addChangeListener(param1WCChangeEvent -> {
/*     */             String str = param1Entry.getTitle();
/*     */             if (str == null || !str.equals(getTitle())) {
/*     */               this.title.set(str);
/*     */             }
/*     */             Date date = param1Entry.getLastVisitedDate();
/*     */             if (date != null && !date.equals(getLastVisitedDate())) {
/*     */               this.lastVisitedDate.set(date);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getUrl() {
/* 110 */       assert this.url != null;
/* 111 */       return this.url.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ReadOnlyObjectProperty<String> titleProperty() {
/* 119 */       return this.title.getReadOnlyProperty();
/*     */     }
/*     */     
/*     */     public String getTitle() {
/* 123 */       return this.title.get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ReadOnlyObjectProperty<Date> lastVisitedDateProperty() {
/* 131 */       return this.lastVisitedDate.getReadOnlyProperty();
/*     */     }
/*     */     
/*     */     public Date getLastVisitedDate() {
/* 135 */       return this.lastVisitedDate.get();
/*     */     }
/*     */     
/*     */     boolean isPeer(BackForwardList.Entry param1Entry) {
/* 139 */       return (this.peer == param1Entry);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 144 */       return "[url: " + getUrl() + ", title: " + 
/* 145 */         getTitle() + ", date: " + 
/* 146 */         getLastVisitedDate() + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WebHistory(WebPage paramWebPage) {
/* 215 */     this.currentIndex = new ReadOnlyIntegerWrapper(this, "currentIndex"); this.list = FXCollections.observableArrayList(); this.ulist = FXCollections.unmodifiableObservableList(this.list); this.bfl = paramWebPage.createBackForwardList(); setMaxSize(getMaxSize()); this.bfl.addChangeListener(paramWCChangeEvent -> { if (this.bfl.size() > this.list.size()) { assert this.bfl.size() == this.list.size() + 1; this.list.add(new Entry(this.bfl.getCurrentEntry())); setCurrentIndex(this.list.size() - 1); return; }
/*     */            if (this.bfl.size() == this.list.size()) {
/*     */             if (this.list.size() == 0)
/*     */               return;  assert this.list.size() > 0; BackForwardList.Entry entry1 = this.bfl.get(this.list.size() - 1); BackForwardList.Entry entry2 = this.bfl.get(0); if (((Entry)this.list.get(this.list.size() - 1)).isPeer(entry1)) {
/*     */               setCurrentIndex(this.bfl.getCurrentIndex()); return;
/*     */             }  if (!((Entry)this.list.get(0)).isPeer(entry2)) {
/*     */               this.list.remove(0); this.list.add(new Entry(entry1)); setCurrentIndex(this.bfl.getCurrentIndex()); return;
/*     */             } 
/*     */           }  assert this.bfl.size() <= this.list.size(); this.list.remove(this.bfl.size(), this.list.size()); int i = this.list.size() - 1; if (i >= 0 && !((Entry)this.list.get(i)).isPeer(this.bfl.get(i))) {
/*     */             this.list.remove(i); this.list.add(new Entry(this.bfl.get(i)));
/*     */           }  setCurrentIndex(this.bfl.getCurrentIndex());
/* 226 */         }); } public ReadOnlyIntegerProperty currentIndexProperty() { return this.currentIndex.getReadOnlyProperty(); }
/*     */ 
/*     */   
/*     */   public int getCurrentIndex() {
/* 230 */     return currentIndexProperty().get();
/*     */   }
/*     */   
/*     */   private void setCurrentIndex(int paramInt) {
/* 234 */     this.currentIndex.set(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerProperty maxSizeProperty() {
/* 251 */     if (this.maxSize == null) {
/* 252 */       this.maxSize = new SimpleIntegerProperty(this, "maxSize", 100)
/*     */         {
/*     */           public void set(int param1Int) {
/* 255 */             if (param1Int < 0) {
/* 256 */               throw new IllegalArgumentException("value cannot be negative.");
/*     */             }
/* 258 */             super.set(param1Int);
/*     */           }
/*     */         };
/*     */     }
/* 262 */     return this.maxSize;
/*     */   }
/*     */   
/*     */   public void setMaxSize(int paramInt) {
/* 266 */     maxSizeProperty().set(paramInt);
/* 267 */     this.bfl.setMaximumSize(paramInt);
/*     */   }
/*     */   
/*     */   public int getMaxSize() {
/* 271 */     return maxSizeProperty().get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<Entry> getEntries() {
/* 280 */     return this.ulist;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void go(int paramInt) throws IndexOutOfBoundsException {
/* 304 */     if (paramInt == 0) {
/*     */       return;
/*     */     }
/* 307 */     int i = getCurrentIndex() + paramInt;
/* 308 */     if (i < 0 || i >= this.list.size()) {
/* 309 */       throw new IndexOutOfBoundsException("the effective index " + i + " is out of the range [0.." + this.list
/*     */           
/* 311 */           .size() - 1 + "]");
/*     */     }
/* 313 */     this.bfl.setCurrentIndex(i);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\javafx\scene\web\WebHistory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */