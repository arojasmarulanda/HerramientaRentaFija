/*    */ package javafx.scene.web;
/*    */ 
/*    */ import javafx.beans.NamedArg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PopupFeatures
/*    */ {
/*    */   private final boolean menu;
/*    */   private final boolean status;
/*    */   private final boolean toolbar;
/*    */   private final boolean resizable;
/*    */   
/*    */   public PopupFeatures(@NamedArg("menu") boolean paramBoolean1, @NamedArg("status") boolean paramBoolean2, @NamedArg("toolbar") boolean paramBoolean3, @NamedArg("resizable") boolean paramBoolean4) {
/* 55 */     this.menu = paramBoolean1;
/* 56 */     this.status = paramBoolean2;
/* 57 */     this.toolbar = paramBoolean3;
/* 58 */     this.resizable = paramBoolean4;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean hasMenu() {
/* 66 */     return this.menu;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean hasStatus() {
/* 74 */     return this.status;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean hasToolbar() {
/* 82 */     return this.toolbar;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isResizable() {
/* 90 */     return this.resizable;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\javafx\scene\web\PopupFeatures.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */