/*    */ package javafx.scene.web;
/*    */ 
/*    */ import com.sun.javafx.scene.control.ControlHelper;
/*    */ import javafx.css.StyleableProperty;
/*    */ import javafx.print.PrinterJob;
/*    */ import javafx.scene.control.Control;
/*    */ import javafx.scene.control.Skin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLEditor
/*    */   extends Control
/*    */ {
/*    */   public HTMLEditor() {
/* 50 */     ((StyleableProperty<String>)ControlHelper.skinClassNameProperty(this)).applyStyle(null, "javafx.scene.web.HTMLEditorSkin");
/*    */ 
/*    */ 
/*    */     
/* 54 */     getStyleClass().add("html-editor");
/*    */   }
/*    */   
/*    */   protected Skin<?> createDefaultSkin() {
/* 58 */     return new HTMLEditorSkin(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getHtmlText() {
/* 66 */     return ((HTMLEditorSkin)getSkin()).getHTMLText();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setHtmlText(String paramString) {
/* 83 */     ((HTMLEditorSkin)getSkin()).setHTMLText(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void print(PrinterJob paramPrinterJob) {
/* 95 */     ((HTMLEditorSkin)getSkin()).print(paramPrinterJob);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\javafx\scene\web\HTMLEditor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */