/*    */ package com.sun.javafx.webkit;
/*    */ 
/*    */ import com.sun.webkit.WebPage;
/*    */ import javafx.beans.InvalidationListener;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.web.WebEngine;
/*    */ import javafx.scene.web.WebView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Accessor
/*    */ {
/*    */   private static PageAccessor pageAccessor;
/*    */   
/*    */   public static void setPageAccessor(PageAccessor paramPageAccessor) {
/* 43 */     pageAccessor = paramPageAccessor;
/*    */   }
/*    */   
/*    */   public static WebPage getPageFor(WebEngine paramWebEngine) {
/* 47 */     return pageAccessor.getPage(paramWebEngine);
/*    */   }
/*    */   
/*    */   public abstract WebEngine getEngine();
/*    */   
/*    */   public abstract WebView getView();
/*    */   
/*    */   public abstract WebPage getPage();
/*    */   
/*    */   public abstract void addChild(Node paramNode);
/*    */   
/*    */   public abstract void removeChild(Node paramNode);
/*    */   
/*    */   public abstract void addViewListener(InvalidationListener paramInvalidationListener);
/*    */   
/*    */   public static interface PageAccessor {
/*    */     WebPage getPage(WebEngine param1WebEngine);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\Accessor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */