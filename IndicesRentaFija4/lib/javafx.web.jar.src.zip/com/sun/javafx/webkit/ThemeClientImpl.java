/*    */ package com.sun.javafx.webkit;
/*    */ 
/*    */ import com.sun.javafx.webkit.theme.RenderThemeImpl;
/*    */ import com.sun.javafx.webkit.theme.ScrollBarThemeImpl;
/*    */ import com.sun.webkit.ThemeClient;
/*    */ import com.sun.webkit.graphics.RenderTheme;
/*    */ import com.sun.webkit.graphics.ScrollBarTheme;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ThemeClientImpl
/*    */   extends ThemeClient
/*    */ {
/*    */   private final Accessor accessor;
/*    */   
/*    */   public ThemeClientImpl(Accessor paramAccessor) {
/* 38 */     this.accessor = paramAccessor;
/*    */   }
/*    */   
/*    */   protected RenderTheme createRenderTheme() {
/* 42 */     return new RenderThemeImpl(this.accessor);
/*    */   }
/*    */   
/*    */   protected ScrollBarTheme createScrollBarTheme() {
/* 46 */     return new ScrollBarThemeImpl(this.accessor);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\ThemeClientImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */