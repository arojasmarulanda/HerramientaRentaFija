/*     */ package com.sun.javafx.webkit;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.javafx.scene.SceneHelper;
/*     */ import com.sun.javafx.scene.input.ExtendedInputMethodRequests;
/*     */ import com.sun.webkit.InputMethodClient;
/*     */ import com.sun.webkit.Invoker;
/*     */ import com.sun.webkit.WebPage;
/*     */ import com.sun.webkit.event.WCInputMethodEvent;
/*     */ import com.sun.webkit.graphics.WCPoint;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.scene.input.InputMethodEvent;
/*     */ import javafx.scene.input.InputMethodHighlight;
/*     */ import javafx.scene.input.InputMethodTextRun;
/*     */ import javafx.scene.web.WebView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InputMethodClientImpl
/*     */   implements InputMethodClient, ExtendedInputMethodRequests
/*     */ {
/*  53 */   private static final PlatformLogger log = PlatformLogger.getLogger(InputMethodClientImpl.class.getName());
/*     */   
/*     */   private final WeakReference<WebView> wvRef;
/*     */   
/*     */   private final WebPage webPage;
/*     */   private boolean state;
/*     */   
/*     */   public InputMethodClientImpl(WebView paramWebView, WebPage paramWebPage) {
/*  61 */     this.wvRef = new WeakReference<>(paramWebView);
/*  62 */     this.webPage = paramWebPage;
/*  63 */     if (paramWebPage != null) {
/*  64 */       paramWebPage.setInputMethodClient(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void activateInputMethods(boolean paramBoolean) {
/*  69 */     WebView webView = this.wvRef.get();
/*  70 */     if (webView != null && webView.getScene() != null) {
/*  71 */       SceneHelper.enableInputMethodEvents(webView.getScene(), paramBoolean);
/*     */     }
/*  73 */     this.state = paramBoolean;
/*     */   }
/*     */   
/*     */   public boolean getInputMethodState() {
/*  77 */     return this.state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WCInputMethodEvent convertToWCInputMethodEvent(InputMethodEvent paramInputMethodEvent) {
/*  84 */     ArrayList<Integer> arrayList = new ArrayList();
/*  85 */     StringBuilder stringBuilder = new StringBuilder();
/*  86 */     int i = 0;
/*     */ 
/*     */     
/*  89 */     for (InputMethodTextRun inputMethodTextRun : paramInputMethodEvent.getComposed()) {
/*  90 */       String str = inputMethodTextRun.getText();
/*     */ 
/*     */ 
/*     */       
/*  94 */       InputMethodHighlight inputMethodHighlight = inputMethodTextRun.getHighlight();
/*  95 */       arrayList.add(Integer.valueOf(i));
/*  96 */       arrayList.add(Integer.valueOf(i + str.length()));
/*     */ 
/*     */ 
/*     */       
/* 100 */       arrayList.add(Integer.valueOf((inputMethodHighlight == InputMethodHighlight.SELECTED_CONVERTED || inputMethodHighlight == InputMethodHighlight.SELECTED_RAW) ? 
/* 101 */             1 : 0));
/* 102 */       i += str.length();
/* 103 */       stringBuilder.append(str);
/*     */     } 
/*     */     
/* 106 */     int j = arrayList.size();
/*     */ 
/*     */     
/* 109 */     if (j == 0) {
/* 110 */       arrayList.add(Integer.valueOf(0));
/* 111 */       arrayList.add(Integer.valueOf(i));
/* 112 */       arrayList.add(Integer.valueOf(0));
/* 113 */       j = arrayList.size();
/*     */     } 
/* 115 */     int[] arrayOfInt = new int[j];
/* 116 */     for (byte b = 0; b < j; b++) {
/* 117 */       arrayOfInt[b] = ((Integer)arrayList.get(b)).intValue();
/*     */     }
/*     */     
/* 120 */     return new WCInputMethodEvent(paramInputMethodEvent.getCommitted(), stringBuilder.toString(), arrayOfInt, paramInputMethodEvent
/* 121 */         .getCaretPosition());
/*     */   }
/*     */ 
/*     */   
/*     */   public Point2D getTextLocation(int paramInt) {
/* 126 */     FutureTask<Point2D> futureTask = new FutureTask(() -> {
/*     */           int[] arrayOfInt = this.webPage.getClientTextLocation(paramInt);
/*     */           
/*     */           WCPoint wCPoint = this.webPage.getPageClient().windowToScreen(new WCPoint(arrayOfInt[0], (arrayOfInt[1] + arrayOfInt[3])));
/*     */           
/*     */           return new Point2D(wCPoint.getIntX(), wCPoint.getIntY());
/*     */         });
/*     */     
/* 134 */     Invoker.getInvoker().invokeOnEventThread(futureTask);
/* 135 */     Point2D point2D = null;
/*     */     try {
/* 137 */       point2D = futureTask.get();
/* 138 */     } catch (ExecutionException executionException) {
/* 139 */       log.severe("InputMethodClientImpl.getTextLocation " + executionException);
/* 140 */     } catch (InterruptedException interruptedException) {
/* 141 */       log.severe("InputMethodClientImpl.getTextLocation InterruptedException" + interruptedException);
/*     */     } 
/* 143 */     return point2D;
/*     */   }
/*     */   
/*     */   public int getLocationOffset(int paramInt1, int paramInt2) {
/* 147 */     FutureTask<Integer> futureTask = new FutureTask(() -> {
/*     */           WCPoint wCPoint = this.webPage.getPageClient().windowToScreen(new WCPoint(0.0F, 0.0F));
/*     */           
/*     */           return Integer.valueOf(this.webPage.getClientLocationOffset(paramInt1 - wCPoint.getIntX(), paramInt2 - wCPoint.getIntY()));
/*     */         });
/* 152 */     Invoker.getInvoker().invokeOnEventThread(futureTask);
/* 153 */     int i = 0;
/*     */     try {
/* 155 */       i = ((Integer)futureTask.get()).intValue();
/* 156 */     } catch (ExecutionException executionException) {
/* 157 */       log.severe("InputMethodClientImpl.getLocationOffset " + executionException);
/* 158 */     } catch (InterruptedException interruptedException) {
/* 159 */       log.severe("InputMethodClientImpl.getTextLocation InterruptedException" + interruptedException);
/*     */     } 
/* 161 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancelLatestCommittedText() {}
/*     */ 
/*     */   
/*     */   public String getSelectedText() {
/* 169 */     return this.webPage.getClientSelectedText();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInsertPositionOffset() {
/* 174 */     return this.webPage.getClientInsertPositionOffset();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCommittedText(int paramInt1, int paramInt2) {
/*     */     try {
/* 180 */       return this.webPage.getClientCommittedText().substring(paramInt1, paramInt2);
/* 181 */     } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {
/* 182 */       throw new IllegalArgumentException(stringIndexOutOfBoundsException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCommittedTextLength() {
/* 188 */     return this.webPage.getClientCommittedTextLength();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\InputMethodClientImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */