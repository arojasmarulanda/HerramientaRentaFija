/*     */ package com.sun.javafx.webkit;
/*     */ 
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import com.sun.webkit.UIClient;
/*     */ import com.sun.webkit.WebPage;
/*     */ import com.sun.webkit.graphics.WCImage;
/*     */ import com.sun.webkit.graphics.WCRectangle;
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.awt.image.SampleModel;
/*     */ import java.awt.image.SinglePixelPackedSampleModel;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Rectangle2D;
/*     */ import javafx.scene.image.Image;
/*     */ import javafx.scene.image.PixelFormat;
/*     */ import javafx.scene.image.PixelReader;
/*     */ import javafx.scene.image.WritablePixelFormat;
/*     */ import javafx.scene.input.ClipboardContent;
/*     */ import javafx.scene.input.DataFormat;
/*     */ import javafx.scene.input.Dragboard;
/*     */ import javafx.scene.input.TransferMode;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.web.PopupFeatures;
/*     */ import javafx.scene.web.PromptData;
/*     */ import javafx.scene.web.WebEngine;
/*     */ import javafx.scene.web.WebEvent;
/*     */ import javafx.scene.web.WebView;
/*     */ import javafx.stage.FileChooser;
/*     */ import javafx.stage.Window;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UIClientImpl
/*     */   implements UIClient
/*     */ {
/*     */   private final Accessor accessor;
/*     */   private FileChooser chooser;
/*  83 */   private static final Map<String, FileExtensionInfo> fileExtensionMap = new HashMap<>();
/*     */   private ClipboardContent content;
/*     */   
/*     */   private static class FileExtensionInfo { private String description;
/*     */     
/*     */     static void add(String param1String1, String param1String2, String... param1VarArgs) {
/*  89 */       FileExtensionInfo fileExtensionInfo = new FileExtensionInfo();
/*  90 */       fileExtensionInfo.description = param1String2;
/*  91 */       fileExtensionInfo.extensions = Arrays.asList(param1VarArgs);
/*  92 */       UIClientImpl.fileExtensionMap.put(param1String1, fileExtensionInfo);
/*     */     }
/*     */     private List<String> extensions;
/*     */     private FileChooser.ExtensionFilter getExtensionFilter(String param1String) {
/*  96 */       String str1 = "*." + param1String;
/*  97 */       String str2 = this.description + " ";
/*     */       
/*  99 */       if (param1String.equals("*")) {
/* 100 */         str2 = str2 + str2;
/* 101 */         return new FileChooser.ExtensionFilter(str2, this.extensions);
/* 102 */       }  if (this.extensions.contains(str1)) {
/* 103 */         str2 = str2 + "(" + str2 + ")";
/* 104 */         return new FileChooser.ExtensionFilter(str2, new String[] { str1 });
/*     */       } 
/* 106 */       return null;
/*     */     } }
/*     */ 
/*     */   
/*     */   static {
/* 111 */     FileExtensionInfo.add("video", "Video Files", new String[] { "*.webm", "*.mp4", "*.ogg" });
/* 112 */     FileExtensionInfo.add("audio", "Audio Files", new String[] { "*.mp3", "*.aac", "*.wav" });
/* 113 */     FileExtensionInfo.add("text", "Text Files", new String[] { "*.txt", "*.csv", "*.text", "*.ttf", "*.sdf", "*.srt", "*.htm", "*.html" });
/* 114 */     FileExtensionInfo.add("image", "Image Files", new String[] { "*.png", "*.jpg", "*.gif", "*.bmp", "*.jpeg" });
/*     */   }
/*     */   
/*     */   public UIClientImpl(Accessor paramAccessor) {
/* 118 */     this.accessor = paramAccessor;
/*     */   }
/*     */   
/*     */   private WebEngine getWebEngine() {
/* 122 */     return this.accessor.getEngine();
/*     */   }
/*     */   
/*     */   private AccessControlContext getAccessContext() {
/* 126 */     return this.accessor.getPage().getAccessControlContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public WebPage createPage(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
/* 131 */     WebEngine webEngine = getWebEngine();
/* 132 */     if (webEngine != null && webEngine.getCreatePopupHandler() != null) {
/* 133 */       PopupFeatures popupFeatures = new PopupFeatures(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
/*     */       
/* 135 */       WebEngine webEngine1 = AccessController.<WebEngine>doPrivileged(() -> (WebEngine)paramWebEngine.getCreatePopupHandler().call(paramPopupFeatures), 
/* 136 */           getAccessContext());
/* 137 */       return Accessor.getPageFor(webEngine1);
/*     */     } 
/* 139 */     return null;
/*     */   }
/*     */   
/*     */   private void dispatchWebEvent(EventHandler paramEventHandler, WebEvent paramWebEvent) {
/* 143 */     AccessController.doPrivileged(() -> {
/*     */           paramEventHandler.handle(paramWebEvent);
/*     */           return null;
/* 146 */         }getAccessContext());
/*     */   }
/*     */   
/*     */   private void notifyVisibilityChanged(boolean paramBoolean) {
/* 150 */     WebEngine webEngine = getWebEngine();
/* 151 */     if (webEngine != null && webEngine.getOnVisibilityChanged() != null) {
/* 152 */       dispatchWebEvent(webEngine
/* 153 */           .getOnVisibilityChanged(), new WebEvent<>(webEngine, WebEvent.VISIBILITY_CHANGED, 
/* 154 */             Boolean.valueOf(paramBoolean)));
/*     */     }
/*     */   }
/*     */   
/*     */   public void closePage() {
/* 159 */     notifyVisibilityChanged(false);
/*     */   }
/*     */   
/*     */   public void showView() {
/* 163 */     notifyVisibilityChanged(true);
/*     */   }
/*     */   
/*     */   public WCRectangle getViewBounds() {
/* 167 */     WebView webView = this.accessor.getView();
/* 168 */     Window window = null;
/* 169 */     if (webView != null && webView
/* 170 */       .getScene() != null && (
/* 171 */       window = webView.getScene().getWindow()) != null)
/*     */     {
/* 173 */       return new WCRectangle(
/* 174 */           (float)window.getX(), (float)window.getY(), 
/* 175 */           (float)window.getWidth(), (float)window.getHeight());
/*     */     }
/* 177 */     return null;
/*     */   }
/*     */   
/*     */   public void setViewBounds(WCRectangle paramWCRectangle) {
/* 181 */     WebEngine webEngine = getWebEngine();
/* 182 */     if (webEngine != null && webEngine.getOnResized() != null) {
/* 183 */       dispatchWebEvent(webEngine
/* 184 */           .getOnResized(), new WebEvent<>(webEngine, WebEvent.RESIZED, new Rectangle2D(paramWCRectangle
/*     */               
/* 186 */               .getX(), paramWCRectangle.getY(), paramWCRectangle.getWidth(), paramWCRectangle.getHeight())));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setStatusbarText(String paramString) {
/* 191 */     WebEngine webEngine = getWebEngine();
/* 192 */     if (webEngine != null && webEngine.getOnStatusChanged() != null) {
/* 193 */       dispatchWebEvent(webEngine
/* 194 */           .getOnStatusChanged(), new WebEvent<>(webEngine, WebEvent.STATUS_CHANGED, paramString));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void alert(String paramString) {
/* 200 */     WebEngine webEngine = getWebEngine();
/* 201 */     if (webEngine != null && webEngine.getOnAlert() != null) {
/* 202 */       dispatchWebEvent(webEngine
/* 203 */           .getOnAlert(), new WebEvent<>(webEngine, WebEvent.ALERT, paramString));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean confirm(String paramString) {
/* 209 */     WebEngine webEngine = getWebEngine();
/* 210 */     if (webEngine != null && webEngine.getConfirmHandler() != null) {
/* 211 */       return ((Boolean)AccessController.<Boolean>doPrivileged(() -> (Boolean)paramWebEngine.getConfirmHandler().call(paramString), 
/* 212 */           getAccessContext())).booleanValue();
/*     */     }
/* 214 */     return false;
/*     */   }
/*     */   
/*     */   public String prompt(String paramString1, String paramString2) {
/* 218 */     WebEngine webEngine = getWebEngine();
/* 219 */     if (webEngine != null && webEngine.getPromptHandler() != null) {
/* 220 */       PromptData promptData = new PromptData(paramString1, paramString2);
/* 221 */       return AccessController.<String>doPrivileged(() -> (String)paramWebEngine.getPromptHandler().call(paramPromptData), 
/* 222 */           getAccessContext());
/*     */     } 
/* 224 */     return "";
/*     */   }
/*     */   
/*     */   public boolean canRunBeforeUnloadConfirmPanel() {
/* 228 */     return false;
/*     */   }
/*     */   
/*     */   public boolean runBeforeUnloadConfirmPanel(String paramString) {
/* 232 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] chooseFile(String paramString1, boolean paramBoolean, String paramString2) {
/* 237 */     Window window = null;
/* 238 */     WebView webView = this.accessor.getView();
/* 239 */     if (webView != null && webView.getScene() != null) {
/* 240 */       window = webView.getScene().getWindow();
/*     */     }
/*     */     
/* 243 */     if (this.chooser == null) {
/* 244 */       this.chooser = new FileChooser();
/*     */     }
/*     */ 
/*     */     
/* 248 */     this.chooser.getExtensionFilters().clear();
/* 249 */     if (paramString2 != null && !paramString2.isEmpty()) {
/* 250 */       addMimeFilters(this.chooser, paramString2);
/*     */     }
/* 252 */     this.chooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter[] { new FileChooser.ExtensionFilter("All Files", new String[] { "*.*" }) });
/*     */ 
/*     */     
/* 255 */     if (paramString1 != null) {
/* 256 */       File file1 = new File(paramString1);
/* 257 */       while (file1 != null && !file1.isDirectory()) {
/* 258 */         file1 = file1.getParentFile();
/*     */       }
/* 260 */       this.chooser.setInitialDirectory(file1);
/*     */     } 
/*     */     
/* 263 */     if (paramBoolean) {
/* 264 */       List<File> list = this.chooser.showOpenMultipleDialog(window);
/* 265 */       if (list != null) {
/* 266 */         int i = list.size();
/* 267 */         String[] arrayOfString = new String[i];
/* 268 */         for (byte b = 0; b < i; b++) {
/* 269 */           arrayOfString[b] = ((File)list.get(b)).getAbsolutePath();
/*     */         }
/* 271 */         return arrayOfString;
/*     */       } 
/* 273 */       return null;
/*     */     } 
/* 275 */     File file = this.chooser.showOpenDialog(window);
/*     */     
/* 277 */     (new String[1])[0] = file.getAbsolutePath(); return (file != null) ? new String[1] : 
/* 278 */       null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void addSpecificFilters(FileChooser paramFileChooser, String paramString) {
/* 283 */     if (paramString.contains("/")) {
/* 284 */       String[] arrayOfString = paramString.split("/");
/* 285 */       String str1 = arrayOfString[0];
/* 286 */       String str2 = arrayOfString[1];
/* 287 */       FileExtensionInfo fileExtensionInfo = fileExtensionMap.get(str1);
/*     */       
/* 289 */       if (fileExtensionInfo != null) {
/* 290 */         FileChooser.ExtensionFilter extensionFilter = fileExtensionInfo.getExtensionFilter(str2);
/* 291 */         if (extensionFilter != null) {
/* 292 */           paramFileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter[] { extensionFilter });
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addMimeFilters(FileChooser paramFileChooser, String paramString) {
/* 299 */     if (paramString.contains(",")) {
/*     */       
/* 301 */       String[] arrayOfString = paramString.split(",");
/* 302 */       for (String str : arrayOfString) {
/* 303 */         addSpecificFilters(paramFileChooser, str);
/*     */       }
/*     */     } else {
/*     */       
/* 307 */       addSpecificFilters(paramFileChooser, paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void print() {}
/*     */ 
/*     */   
/*     */   private static DataFormat getDataFormat(String paramString) {
/* 316 */     synchronized (DataFormat.class) {
/* 317 */       DataFormat dataFormat = DataFormat.lookupMimeType(paramString);
/* 318 */       if (dataFormat == null) {
/* 319 */         dataFormat = new DataFormat(new String[] { paramString });
/*     */       }
/* 321 */       return dataFormat;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 326 */   private static final DataFormat DF_DRAG_IMAGE = getDataFormat("application/x-java-drag-image");
/* 327 */   private static final DataFormat DF_DRAG_IMAGE_OFFSET = getDataFormat("application/x-java-drag-image-offset");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDrag(WCImage paramWCImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String[] paramArrayOfString, Object[] paramArrayOfObject, boolean paramBoolean) {
/* 334 */     this.content = new ClipboardContent();
/* 335 */     for (byte b = 0; b < paramArrayOfString.length; ) { if (paramArrayOfObject[b] != null) {
/*     */         try {
/* 337 */           this.content.put(getDataFormat(paramArrayOfString[b]), 
/* 338 */               "text/ie-shortcut-filename".equals(paramArrayOfString[b]) ? 
/* 339 */               ByteBuffer.wrap(((String)paramArrayOfObject[b]).getBytes("UTF-16LE")) : 
/* 340 */               paramArrayOfObject[b]);
/* 341 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */       }
/*     */       b++; }
/*     */     
/* 345 */     if (paramWCImage != null) {
/* 346 */       ByteBuffer byteBuffer1 = ByteBuffer.allocate(8);
/* 347 */       byteBuffer1.rewind();
/* 348 */       byteBuffer1.putInt(paramInt1);
/* 349 */       byteBuffer1.putInt(paramInt2);
/* 350 */       this.content.put(DF_DRAG_IMAGE_OFFSET, byteBuffer1);
/*     */       
/* 352 */       int i = paramWCImage.getWidth();
/* 353 */       int j = paramWCImage.getHeight();
/* 354 */       ByteBuffer byteBuffer2 = paramWCImage.getPixelBuffer();
/*     */       
/* 356 */       ByteBuffer byteBuffer3 = ByteBuffer.allocate(8 + i * j * 4);
/* 357 */       byteBuffer3.putInt(i);
/* 358 */       byteBuffer3.putInt(j);
/* 359 */       byteBuffer3.put(byteBuffer2);
/* 360 */       this.content.put(DF_DRAG_IMAGE, byteBuffer3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 366 */       if (paramBoolean) {
/*     */         
/* 368 */         Object object = (paramWCImage.getWidth() > 0 && paramWCImage.getHeight() > 0) ? paramWCImage.getPlatformImage() : null;
/* 369 */         String str = paramWCImage.getFileExtension();
/* 370 */         if (object != null) {
/*     */           try {
/* 372 */             File file = File.createTempFile("jfx", "." + str);
/* 373 */             file.deleteOnExit();
/* 374 */             ImageIO.write(
/* 375 */                 toBufferedImage(Toolkit.getImageAccessor().fromPlatformImage(
/* 376 */                     Toolkit.getToolkit().loadPlatformImage(object))), str, file);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 382 */             this.content.put(DataFormat.FILES, Arrays.asList(new File[] { file }));
/* 383 */           } catch (IOException|SecurityException iOException) {}
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void confirmStartDrag() {
/* 393 */     WebView webView = this.accessor.getView();
/* 394 */     if (webView != null && this.content != null) {
/*     */       
/* 396 */       Dragboard dragboard = webView.startDragAndDrop(TransferMode.ANY);
/* 397 */       dragboard.setContent(this.content);
/*     */     } 
/* 399 */     this.content = null;
/*     */   }
/*     */   
/*     */   public boolean isDragConfirmed() {
/* 403 */     return (this.accessor.getView() != null && this.content != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getBestBufferedImageType(PixelFormat<?> paramPixelFormat, BufferedImage paramBufferedImage, boolean paramBoolean) {
/* 410 */     if (paramBufferedImage != null) {
/* 411 */       int i = paramBufferedImage.getType();
/* 412 */       if (i == 2 || i == 3 || (paramBoolean && (i == 4 || i == 1)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 425 */         return i;
/*     */       }
/*     */     } 
/* 428 */     switch (paramPixelFormat.getType())
/*     */     
/*     */     { 
/*     */       default:
/* 432 */         return 3;
/*     */       case BYTE_BGRA:
/*     */       case INT_ARGB:
/* 435 */         return 2;
/*     */       case BYTE_RGB:
/* 437 */         return 1;
/*     */       case BYTE_INDEXED:
/* 439 */         break; }  return paramPixelFormat.isPremultiplied() ? 
/* 440 */       3 : 
/* 441 */       2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static WritablePixelFormat<IntBuffer> getAssociatedPixelFormat(BufferedImage paramBufferedImage) {
/* 448 */     switch (paramBufferedImage.getType()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 3:
/* 455 */         return PixelFormat.getIntArgbPreInstance();
/*     */       case 2:
/* 457 */         return PixelFormat.getIntArgbInstance();
/*     */     } 
/*     */     
/* 460 */     throw new InternalError("Failed to validate BufferedImage type");
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean checkFXImageOpaque(PixelReader paramPixelReader, int paramInt1, int paramInt2) {
/* 465 */     for (byte b = 0; b < paramInt1; b++) {
/* 466 */       for (byte b1 = 0; b1 < paramInt2; b1++) {
/* 467 */         Color color = paramPixelReader.getColor(b, b1);
/* 468 */         if (color.getOpacity() != 1.0D) {
/* 469 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/* 473 */     return true;
/*     */   }
/*     */   
/*     */   private static BufferedImage fromFXImage(Image paramImage, BufferedImage paramBufferedImage) {
/* 477 */     PixelReader pixelReader = paramImage.getPixelReader();
/* 478 */     if (pixelReader == null) {
/* 479 */       return null;
/*     */     }
/* 481 */     int i = (int)paramImage.getWidth();
/* 482 */     int j = (int)paramImage.getHeight();
/* 483 */     PixelFormat pixelFormat = pixelReader.getPixelFormat();
/* 484 */     boolean bool = false;
/* 485 */     switch (pixelFormat.getType()) {
/*     */ 
/*     */       
/*     */       case BYTE_BGRA_PRE:
/*     */       case INT_ARGB_PRE:
/*     */       case BYTE_BGRA:
/*     */       case INT_ARGB:
/* 492 */         if (paramBufferedImage != null && (paramBufferedImage
/* 493 */           .getType() == 4 || paramBufferedImage
/* 494 */           .getType() == 1)) {
/* 495 */           bool = checkFXImageOpaque(pixelReader, i, j);
/*     */         }
/*     */         break;
/*     */       case BYTE_RGB:
/* 499 */         bool = true;
/*     */         break;
/*     */     } 
/* 502 */     int k = getBestBufferedImageType(pixelReader.getPixelFormat(), paramBufferedImage, bool);
/* 503 */     if (paramBufferedImage != null) {
/* 504 */       int i1 = paramBufferedImage.getWidth();
/* 505 */       int i2 = paramBufferedImage.getHeight();
/* 506 */       if (i1 < i || i2 < j || paramBufferedImage.getType() != k) {
/* 507 */         paramBufferedImage = null;
/* 508 */       } else if (i < i1 || j < i2) {
/* 509 */         Graphics2D graphics2D = paramBufferedImage.createGraphics();
/* 510 */         graphics2D.setComposite(AlphaComposite.Clear);
/* 511 */         graphics2D.fillRect(0, 0, i1, i2);
/* 512 */         graphics2D.dispose();
/*     */       } 
/*     */     } 
/* 515 */     if (paramBufferedImage == null) {
/* 516 */       paramBufferedImage = new BufferedImage(i, j, k);
/*     */     }
/* 518 */     DataBufferInt dataBufferInt = (DataBufferInt)paramBufferedImage.getRaster().getDataBuffer();
/* 519 */     int[] arrayOfInt = dataBufferInt.getData();
/* 520 */     int m = paramBufferedImage.getRaster().getDataBuffer().getOffset();
/* 521 */     int n = 0;
/* 522 */     SampleModel sampleModel = paramBufferedImage.getRaster().getSampleModel();
/* 523 */     if (sampleModel instanceof SinglePixelPackedSampleModel) {
/* 524 */       n = ((SinglePixelPackedSampleModel)sampleModel).getScanlineStride();
/*     */     }
/*     */     
/* 527 */     WritablePixelFormat<IntBuffer> writablePixelFormat = getAssociatedPixelFormat(paramBufferedImage);
/* 528 */     pixelReader.getPixels(0, 0, i, j, writablePixelFormat, arrayOfInt, m, n);
/* 529 */     return paramBufferedImage;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedImage toBufferedImage(Image paramImage) {
/*     */     try {
/* 536 */       return fromFXImage(paramImage, null);
/* 537 */     } catch (Exception exception) {
/* 538 */       exception.printStackTrace(System.err);
/*     */ 
/*     */ 
/*     */       
/* 542 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\UIClientImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */