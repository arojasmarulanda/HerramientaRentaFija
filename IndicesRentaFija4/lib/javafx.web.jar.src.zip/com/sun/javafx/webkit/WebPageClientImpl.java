/*     */ package com.sun.javafx.webkit;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import com.sun.webkit.CursorManager;
/*     */ import com.sun.webkit.WebPageClient;
/*     */ import com.sun.webkit.graphics.WCGraphicsManager;
/*     */ import com.sun.webkit.graphics.WCPageBackBuffer;
/*     */ import com.sun.webkit.graphics.WCPoint;
/*     */ import com.sun.webkit.graphics.WCRectangle;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.AccessController;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.Rectangle2D;
/*     */ import javafx.scene.Cursor;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.Tooltip;
/*     */ import javafx.scene.web.WebView;
/*     */ import javafx.stage.Screen;
/*     */ import javafx.stage.Window;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebPageClientImpl
/*     */   implements WebPageClient<WebView>
/*     */ {
/*     */   private static final boolean backBufferSupported;
/*  53 */   private static WebConsoleListener consoleListener = null; private final Accessor accessor; private WeakReference<Tooltip> tooltipRef; private boolean isTooltipRegistered;
/*     */   private String oldTooltipText;
/*     */   
/*     */   static {
/*  57 */     backBufferSupported = Boolean.valueOf(
/*  58 */         AccessController.<String>doPrivileged(() -> System.getProperty("com.sun.webkit.pagebackbuffer", "true"))).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   static void setConsoleListener(WebConsoleListener paramWebConsoleListener) {
/*  63 */     consoleListener = paramWebConsoleListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebPageClientImpl(Accessor paramAccessor) {
/*  86 */     this.isTooltipRegistered = false;
/*  87 */     this.oldTooltipText = ""; this.accessor = paramAccessor;
/*     */   } public void setFocus(boolean paramBoolean) { WebView webView = this.accessor.getView(); if (webView != null && paramBoolean)
/*  89 */       webView.requestFocus();  } public void setTooltip(String paramString) { WebView webView = this.accessor.getView();
/*  90 */     if (paramString != null) {
/*  91 */       Tooltip tooltip = (this.tooltipRef == null) ? null : this.tooltipRef.get();
/*  92 */       if (tooltip == null) {
/*  93 */         tooltip = new Tooltip(paramString);
/*  94 */         this.tooltipRef = new WeakReference<>(tooltip);
/*     */       } else {
/*  96 */         tooltip.setText(paramString);
/*  97 */         if (!this.oldTooltipText.equals(paramString)) {
/*  98 */           Tooltip.uninstall(webView, tooltip);
/*  99 */           this.isTooltipRegistered = false;
/*     */         } 
/*     */       } 
/* 102 */       this.oldTooltipText = paramString;
/* 103 */       if (!this.isTooltipRegistered) {
/* 104 */         Tooltip.install(webView, tooltip);
/* 105 */         this.isTooltipRegistered = true;
/*     */       } 
/* 107 */     } else if (this.isTooltipRegistered) {
/* 108 */       Tooltip tooltip = this.tooltipRef.get();
/* 109 */       if (tooltip != null) {
/* 110 */         Tooltip.uninstall(webView, tooltip);
/*     */       }
/* 112 */       this.isTooltipRegistered = false;
/*     */     }  }
/*     */   public void setCursor(long paramLong) { WebView webView = this.accessor.getView(); if (webView != null) {
/*     */       Cursor cursor = (Cursor)CursorManager.getCursorManager().getCursor(paramLong);
/*     */       webView.setCursor((cursor instanceof Cursor) ? cursor : Cursor.DEFAULT);
/* 117 */     }  } public void transferFocus(boolean paramBoolean) { NodeHelper.traverse(this.accessor.getView(), paramBoolean ? Direction.NEXT : Direction.PREVIOUS); }
/*     */ 
/*     */   
/*     */   public WCRectangle getScreenBounds(boolean paramBoolean) {
/* 121 */     WebView webView = this.accessor.getView();
/*     */     
/* 123 */     Screen screen = Utils.getScreen(webView);
/* 124 */     if (screen != null) {
/*     */ 
/*     */       
/* 127 */       Rectangle2D rectangle2D = paramBoolean ? screen.getVisualBounds() : screen.getBounds();
/* 128 */       return new WCRectangle(
/* 129 */           (float)rectangle2D.getMinX(), (float)rectangle2D.getMinY(), 
/* 130 */           (float)rectangle2D.getWidth(), (float)rectangle2D.getHeight());
/*     */     } 
/* 132 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getScreenDepth() {
/* 137 */     return 24;
/*     */   }
/*     */   
/*     */   public WebView getContainer() {
/* 141 */     return this.accessor.getView();
/*     */   }
/*     */   
/*     */   public WCPoint screenToWindow(WCPoint paramWCPoint) {
/* 145 */     WebView webView = this.accessor.getView();
/* 146 */     Scene scene = webView.getScene();
/* 147 */     Window window = null;
/*     */     
/* 149 */     if (scene != null && (
/* 150 */       window = scene.getWindow()) != null) {
/*     */       
/* 152 */       Point2D point2D = webView.sceneToLocal(paramWCPoint
/* 153 */           .getX() - window.getX() - scene.getX(), paramWCPoint
/* 154 */           .getY() - window.getY() - scene.getY());
/* 155 */       return new WCPoint((float)point2D.getX(), (float)point2D.getY());
/*     */     } 
/* 157 */     return new WCPoint(0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public WCPoint windowToScreen(WCPoint paramWCPoint) {
/* 162 */     WebView webView = this.accessor.getView();
/* 163 */     Scene scene = webView.getScene();
/* 164 */     Window window = null;
/*     */     
/* 166 */     if (scene != null && (
/* 167 */       window = scene.getWindow()) != null) {
/*     */       
/* 169 */       Point2D point2D = webView.localToScene(paramWCPoint.getX(), paramWCPoint.getY());
/* 170 */       return new WCPoint((float)(point2D.getX() + scene.getX() + window.getX()), 
/* 171 */           (float)(point2D.getY() + scene.getY() + window.getY()));
/*     */     } 
/* 173 */     return new WCPoint(0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public WCPageBackBuffer createBackBuffer() {
/* 178 */     if (isBackBufferSupported()) {
/* 179 */       return WCGraphicsManager.getGraphicsManager().createPageBackBuffer();
/*     */     }
/* 181 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isBackBufferSupported() {
/* 185 */     return backBufferSupported;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMessageToConsole(String paramString1, int paramInt, String paramString2) {
/* 191 */     if (consoleListener != null)
/*     */       try {
/* 193 */         consoleListener.messageAdded(this.accessor.getView(), paramString1, paramInt, paramString2);
/* 194 */       } catch (Exception exception) {
/* 195 */         exception.printStackTrace();
/*     */       }  
/*     */   }
/*     */   
/*     */   public void didClearWindowObject(long paramLong1, long paramLong2) {}
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\WebPageClientImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */