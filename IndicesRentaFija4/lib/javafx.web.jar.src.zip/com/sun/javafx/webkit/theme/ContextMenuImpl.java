/*     */ package com.sun.javafx.webkit.theme;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.ContextMenu;
/*     */ import com.sun.webkit.ContextMenuItem;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.control.CheckMenuItem;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.Menu;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.Separator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContextMenuImpl
/*     */   extends ContextMenu
/*     */ {
/*  44 */   private static final PlatformLogger log = PlatformLogger.getLogger(ContextMenuImpl.class.getName());
/*     */ 
/*     */   
/*  47 */   private final ObservableList<ContextMenuItem> items = FXCollections.observableArrayList();
/*     */   
/*     */   protected void show(ContextMenu.ShowContext paramShowContext, int paramInt1, int paramInt2) {
/*  50 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  51 */       log.fine("show at [{0}, {1}]", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/*     */     }
/*  53 */     ContextMenu contextMenu = new ContextMenu();
/*     */     
/*  55 */     contextMenu.setOnAction(paramActionEvent -> {
/*     */           MenuItem menuItem = (MenuItem)paramActionEvent.getTarget();
/*     */           
/*     */           log.fine("onAction: item={0}", new Object[] { menuItem });
/*     */           paramShowContext.notifyItemSelected(((MenuItemPeer)menuItem).getItemPeer().getAction());
/*     */         });
/*  61 */     contextMenu.getItems().addAll(fillMenu());
/*  62 */     PopupMenuImpl.doShow(contextMenu, paramShowContext.getPage(), paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   protected void appendItem(ContextMenuItem paramContextMenuItem) {
/*  66 */     insertItem(paramContextMenuItem, this.items.size());
/*     */   }
/*     */   
/*     */   protected void insertItem(ContextMenuItem paramContextMenuItem, int paramInt) {
/*  70 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  71 */       log.fine("item={0}, index={1}", new Object[] { paramContextMenuItem, Integer.valueOf(paramInt) });
/*     */     }
/*  73 */     if (paramContextMenuItem == null) {
/*     */       return;
/*     */     }
/*  76 */     this.items.remove(paramContextMenuItem);
/*     */     
/*  78 */     if (this.items.size() == 0) {
/*  79 */       this.items.add(paramContextMenuItem);
/*     */     } else {
/*  81 */       this.items.add(paramInt, paramContextMenuItem);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected int getItemCount() {
/*  86 */     return this.items.size();
/*     */   }
/*     */   
/*     */   private MenuItem createMenuItem(ContextMenuItem paramContextMenuItem) {
/*  90 */     log.fine("item={0}", new Object[] { paramContextMenuItem });
/*     */     
/*  92 */     if (paramContextMenuItem.getType() == 2) {
/*  93 */       MenuImpl menuImpl = new MenuImpl(paramContextMenuItem.getTitle());
/*  94 */       if (paramContextMenuItem.getSubmenu() != null) {
/*  95 */         menuImpl.getItems().addAll(((ContextMenuImpl)paramContextMenuItem.getSubmenu()).fillMenu());
/*     */       }
/*  97 */       return menuImpl;
/*     */     } 
/*  99 */     if (paramContextMenuItem.getType() == 0) {
/*     */       MenuItemImpl menuItemImpl;
/* 101 */       CheckMenuItemImpl checkMenuItemImpl = null;
/* 102 */       if (paramContextMenuItem.isChecked()) {
/* 103 */         checkMenuItemImpl = new CheckMenuItemImpl(paramContextMenuItem);
/*     */       } else {
/* 105 */         menuItemImpl = new MenuItemImpl(paramContextMenuItem);
/*     */       } 
/* 107 */       menuItemImpl.setDisable(!paramContextMenuItem.isEnabled());
/* 108 */       return menuItemImpl;
/*     */     } 
/* 110 */     if (paramContextMenuItem.getType() == 1) {
/* 111 */       return new SeparatorImpl(paramContextMenuItem);
/*     */     }
/* 113 */     throw new IllegalArgumentException("unexpected item type");
/*     */   }
/*     */   
/*     */   private ObservableList<MenuItem> fillMenu() {
/* 117 */     ObservableList<?> observableList = FXCollections.observableArrayList();
/* 118 */     for (ContextMenuItem contextMenuItem : this.items) {
/* 119 */       observableList.add(createMenuItem(contextMenuItem));
/*     */     }
/* 121 */     return (ObservableList)observableList;
/*     */   }
/*     */   
/*     */   private static interface MenuItemPeer {
/*     */     ContextMenuItem getItemPeer(); }
/*     */   
/*     */   private static final class MenuItemImpl extends MenuItem implements MenuItemPeer {
/*     */     private final ContextMenuItem itemPeer;
/*     */     
/* 130 */     private MenuItemImpl(ContextMenuItem param1ContextMenuItem) { super(param1ContextMenuItem.getTitle()); this.itemPeer = param1ContextMenuItem; } public ContextMenuItem getItemPeer() {
/* 131 */       return this.itemPeer;
/*     */     }
/*     */   }
/*     */   private static final class CheckMenuItemImpl extends CheckMenuItem implements MenuItemPeer { private final ContextMenuItem itemPeer;
/*     */     
/* 136 */     private CheckMenuItemImpl(ContextMenuItem param1ContextMenuItem) { this.itemPeer = param1ContextMenuItem; } public ContextMenuItem getItemPeer() {
/* 137 */       return this.itemPeer;
/*     */     } }
/*     */   
/*     */   private static final class MenuImpl extends Menu { private MenuImpl(String param1String) {
/* 141 */       super(param1String);
/*     */     } }
/*     */   
/*     */   static final class SeparatorImpl extends MenuItem implements MenuItemPeer { private final ContextMenuItem itemPeer;
/*     */     
/*     */     SeparatorImpl(ContextMenuItem param1ContextMenuItem) {
/* 147 */       this.itemPeer = param1ContextMenuItem;
/* 148 */       setGraphic(new Separator());
/* 149 */       setDisable(true);
/*     */     } public ContextMenuItem getItemPeer() {
/* 151 */       return this.itemPeer;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\theme\ContextMenuImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */