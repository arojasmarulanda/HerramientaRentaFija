/*     */ package com.sun.javafx.webkit.theme;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.Invoker;
/*     */ import com.sun.webkit.PopupMenu;
/*     */ import com.sun.webkit.WebPage;
/*     */ import com.sun.webkit.WebPageClient;
/*     */ import com.sun.webkit.graphics.WCFont;
/*     */ import com.sun.webkit.graphics.WCPoint;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.scene.control.ContextMenu;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.web.WebView;
/*     */ import javafx.stage.WindowEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PopupMenuImpl
/*     */   extends PopupMenu
/*     */ {
/*  43 */   private static final PlatformLogger log = PlatformLogger.getLogger(PopupMenuImpl.class.getName());
/*     */   
/*     */   private final ContextMenu popupMenu;
/*     */   
/*     */   public PopupMenuImpl() {
/*  48 */     this.popupMenu = new ContextMenu();
/*     */     
/*  50 */     this.popupMenu.setOnHidden(paramWindowEvent -> {
/*     */           log.finer("onHidden");
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           Invoker.getInvoker().postOnEventThread(());
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     this.popupMenu.setOnAction(paramActionEvent -> {
/*     */           MenuItem menuItem = (MenuItem)paramActionEvent.getTarget();
/*     */           log.fine("onAction: item={0}", new Object[] { menuItem });
/*     */           notifySelectionCommited(this.popupMenu.getItems().indexOf(menuItem));
/*     */         });
/*     */   }
/*     */   
/*     */   protected void show(WebPage paramWebPage, int paramInt1, int paramInt2, int paramInt3) {
/*  70 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  71 */       log.fine("show at [{0}, {1}], width={2}", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) });
/*     */     }
/*     */     
/*  74 */     this.popupMenu.setPrefWidth(paramInt3);
/*  75 */     this.popupMenu.setPrefHeight(this.popupMenu.getHeight());
/*  76 */     doShow(this.popupMenu, paramWebPage, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   protected void hide() {
/*  80 */     log.fine("hiding");
/*  81 */     this.popupMenu.hide();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void appendItem(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt1, int paramInt2, WCFont paramWCFont) {
/*     */     MenuItem menuItem;
/*  88 */     if (log.isLoggable(PlatformLogger.Level.FINEST)) {
/*  89 */       log.finest("itemText={0}, isLabel={1}, isSeparator={2}, isEnabled={3}, bgColor={4}, fgColor={5}, font={6}", new Object[] { paramString, 
/*  90 */             Boolean.valueOf(paramBoolean1), 
/*  91 */             Boolean.valueOf(paramBoolean2), Boolean.valueOf(paramBoolean3), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramWCFont });
/*     */     }
/*     */ 
/*     */     
/*  95 */     if (paramBoolean2) {
/*  96 */       menuItem = new ContextMenuImpl.SeparatorImpl(null);
/*     */     } else {
/*  98 */       menuItem = new MenuItem(paramString);
/*  99 */       menuItem.setDisable(!paramBoolean3);
/*     */     } 
/*     */ 
/*     */     
/* 103 */     menuItem.setMnemonicParsing(false);
/* 104 */     this.popupMenu.getItems().add(menuItem);
/*     */   }
/*     */   
/*     */   protected void setSelectedItem(int paramInt) {
/* 108 */     log.finest("index={0}", new Object[] { Integer.valueOf(paramInt) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void doShow(ContextMenu paramContextMenu, WebPage paramWebPage, int paramInt1, int paramInt2) {
/* 114 */     WebPageClient<WebView> webPageClient = paramWebPage.getPageClient();
/* 115 */     assert webPageClient != null;
/* 116 */     WCPoint wCPoint = webPageClient.windowToScreen(new WCPoint(paramInt1, paramInt2));
/* 117 */     paramContextMenu.show(((WebView)webPageClient.getContainer()).getScene().getWindow(), wCPoint.getX(), wCPoint.getY());
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\theme\PopupMenuImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */