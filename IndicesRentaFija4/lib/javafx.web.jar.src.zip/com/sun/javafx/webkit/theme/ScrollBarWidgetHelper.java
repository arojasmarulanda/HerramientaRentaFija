/*    */ package com.sun.javafx.webkit.theme;
/*    */ 
/*    */ import com.sun.javafx.scene.NodeHelper;
/*    */ import com.sun.javafx.scene.control.ControlHelper;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScrollBarWidgetHelper
/*    */   extends ControlHelper
/*    */ {
/* 40 */   private static final ScrollBarWidgetHelper theInstance = new ScrollBarWidgetHelper(); static {
/* 41 */     Utils.forceInit(ScrollBarWidget.class);
/*    */   }
/*    */   private static ScrollBarWidgetAccessor scrollBarWidgetAccessor;
/*    */   private static ScrollBarWidgetHelper getInstance() {
/* 45 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(ScrollBarWidget paramScrollBarWidget) {
/* 49 */     setHelper(paramScrollBarWidget, (NodeHelper)getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 54 */     super.updatePeerImpl(paramNode);
/* 55 */     scrollBarWidgetAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */   
/*    */   public static void setScrollBarWidgetAccessor(ScrollBarWidgetAccessor paramScrollBarWidgetAccessor) {
/* 59 */     if (scrollBarWidgetAccessor != null) {
/* 60 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 63 */     scrollBarWidgetAccessor = paramScrollBarWidgetAccessor;
/*    */   }
/*    */   
/*    */   public static interface ScrollBarWidgetAccessor {
/*    */     void doUpdatePeer(Node param1Node);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\theme\ScrollBarWidgetHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */