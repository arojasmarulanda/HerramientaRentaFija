/*     */ package com.sun.javafx.webkit.theme;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.javafx.webkit.Accessor;
/*     */ import com.sun.webkit.graphics.Ref;
/*     */ import com.sun.webkit.graphics.ScrollBarTheme;
/*     */ import com.sun.webkit.graphics.WCGraphicsContext;
/*     */ import com.sun.webkit.graphics.WCSize;
/*     */ import java.lang.ref.WeakReference;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.ScrollBar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ScrollBarThemeImpl
/*     */   extends ScrollBarTheme
/*     */ {
/*  49 */   private static final PlatformLogger log = PlatformLogger.getLogger(ScrollBarThemeImpl.class.getName());
/*     */   
/*  51 */   private WeakReference<ScrollBar> testSBRef = new WeakReference<>(null);
/*     */   
/*     */   private final Accessor accessor;
/*     */   private final RenderThemeImpl.Pool<ScrollBarWidget> pool;
/*     */   
/*     */   private static final class ScrollBarRef
/*     */     extends Ref
/*     */   {
/*     */     private final WeakReference<ScrollBarWidget> sbRef;
/*     */     
/*     */     private ScrollBarRef(ScrollBarWidget param1ScrollBarWidget) {
/*  62 */       this.sbRef = new WeakReference<>(param1ScrollBarWidget);
/*     */     }
/*     */     
/*     */     private Control asControl() {
/*  66 */       return this.sbRef.get();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScrollBarThemeImpl(final Accessor accessor) {
/*  76 */     this.accessor = accessor;
/*  77 */     this.pool = new RenderThemeImpl.Pool<>(paramScrollBarWidget -> paramAccessor.removeChild(paramScrollBarWidget), ScrollBarWidget.class);
/*     */ 
/*     */ 
/*     */     
/*  81 */     accessor.addViewListener(new RenderThemeImpl.ViewListener(this.pool, accessor) {
/*     */           public void invalidated(Observable param1Observable) {
/*  83 */             super.invalidated(param1Observable);
/*  84 */             ScrollBarWidget scrollBarWidget = new ScrollBarWidget(ScrollBarThemeImpl.this);
/*     */             
/*  86 */             accessor.addChild(scrollBarWidget);
/*  87 */             ScrollBarThemeImpl.this.testSBRef = (WeakReference)new WeakReference<>(scrollBarWidget);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   ScrollBar getTestSBRef() {
/*  94 */     return this.testSBRef.get();
/*     */   }
/*     */   
/*     */   private static Orientation convertOrientation(int paramInt) {
/*  98 */     return (paramInt == 1) ? Orientation.VERTICAL : Orientation.HORIZONTAL;
/*     */   }
/*     */   
/*     */   private void adjustScrollBar(ScrollBar paramScrollBar, int paramInt1, int paramInt2, int paramInt3) {
/* 102 */     Orientation orientation = convertOrientation(paramInt3);
/* 103 */     if (orientation != paramScrollBar.getOrientation()) {
/* 104 */       paramScrollBar.setOrientation(orientation);
/*     */     }
/*     */     
/* 107 */     if (orientation == Orientation.VERTICAL) {
/* 108 */       paramInt1 = ScrollBarTheme.getThickness();
/*     */     } else {
/* 110 */       paramInt2 = ScrollBarTheme.getThickness();
/*     */     } 
/*     */     
/* 113 */     if (paramInt1 != paramScrollBar.getWidth() || paramInt2 != paramScrollBar.getHeight()) {
/* 114 */       paramScrollBar.resize(paramInt1, paramInt2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void adjustScrollBar(ScrollBar paramScrollBar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 121 */     adjustScrollBar(paramScrollBar, paramInt1, paramInt2, paramInt3);
/* 122 */     boolean bool = (paramInt6 <= paramInt5) ? true : false;
/* 123 */     paramScrollBar.setDisable(bool);
/* 124 */     if (bool) {
/*     */       return;
/*     */     }
/* 127 */     if (paramInt4 < 0) {
/* 128 */       paramInt4 = 0;
/* 129 */     } else if (paramInt4 > paramInt6 - paramInt5) {
/* 130 */       paramInt4 = paramInt6 - paramInt5;
/*     */     } 
/*     */     
/* 133 */     if (paramScrollBar.getMax() != paramInt6 || paramScrollBar.getVisibleAmount() != paramInt5) {
/* 134 */       paramScrollBar.setValue(0.0D);
/* 135 */       paramScrollBar.setMax(paramInt6);
/* 136 */       paramScrollBar.setVisibleAmount(paramInt5);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (paramInt6 > paramInt5) {
/* 146 */       float f = paramInt6 / (paramInt6 - paramInt5);
/* 147 */       if (paramScrollBar.getValue() != (paramInt4 * f)) {
/* 148 */         paramScrollBar.setValue((paramInt4 * f));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Ref createWidget(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 157 */     ScrollBarWidget scrollBarWidget = this.pool.get(paramLong);
/* 158 */     if (scrollBarWidget == null) {
/* 159 */       scrollBarWidget = new ScrollBarWidget(this);
/* 160 */       this.pool.put(paramLong, scrollBarWidget, this.accessor.getPage().getUpdateContentCycleID());
/* 161 */       this.accessor.addChild(scrollBarWidget);
/*     */     } 
/* 163 */     adjustScrollBar(scrollBarWidget, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
/* 164 */     return new ScrollBarRef(scrollBarWidget);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(WCGraphicsContext paramWCGraphicsContext, Ref paramRef, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 170 */     ScrollBar scrollBar = (ScrollBar)((ScrollBarRef)paramRef).asControl();
/* 171 */     if (scrollBar == null) {
/*     */       return;
/*     */     }
/*     */     
/* 175 */     if (log.isLoggable(PlatformLogger.Level.FINEST))
/* 176 */       log.finest("[{0}, {1} {2}x{3}], {4}", new Object[] {
/* 177 */             Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Double.valueOf(scrollBar.getWidth()), Double.valueOf(scrollBar.getHeight()), 
/* 178 */             (scrollBar.getOrientation() == Orientation.VERTICAL) ? "VERTICAL" : "HORIZONTAL"
/*     */           }); 
/* 180 */     paramWCGraphicsContext.saveState();
/* 181 */     paramWCGraphicsContext.translate(paramInt1, paramInt2);
/* 182 */     Renderer.getRenderer().render(scrollBar, paramWCGraphicsContext);
/* 183 */     paramWCGraphicsContext.restoreState();
/*     */   }
/*     */   
/*     */   public WCSize getWidgetSize(Ref paramRef) {
/* 187 */     ScrollBar scrollBar = (ScrollBar)((ScrollBarRef)paramRef).asControl();
/* 188 */     if (scrollBar != null) {
/* 189 */       return new WCSize((float)scrollBar.getWidth(), (float)scrollBar.getHeight());
/*     */     }
/* 191 */     return new WCSize(0.0F, 0.0F);
/*     */   }
/*     */   
/*     */   protected void getScrollBarPartRect(long paramLong, int paramInt, int[] paramArrayOfint) {
/* 195 */     ScrollBar scrollBar = this.pool.get(paramLong);
/* 196 */     if (scrollBar == null) {
/*     */       return;
/*     */     }
/*     */     
/* 200 */     Node node = null;
/* 201 */     if (paramInt == 2) {
/* 202 */       node = getIncButton(scrollBar);
/* 203 */     } else if (paramInt == 1) {
/* 204 */       node = getDecButton(scrollBar);
/* 205 */     } else if (paramInt == 256) {
/* 206 */       node = getTrack(scrollBar);
/*     */     } 
/*     */     
/* 209 */     assert paramArrayOfint.length >= 4;
/* 210 */     if (node != null) {
/* 211 */       Bounds bounds = node.getBoundsInParent();
/* 212 */       paramArrayOfint[0] = (int)bounds.getMinX();
/* 213 */       paramArrayOfint[1] = (int)bounds.getMinY();
/* 214 */       paramArrayOfint[2] = (int)bounds.getWidth();
/* 215 */       paramArrayOfint[3] = (int)bounds.getHeight();
/*     */     } else {
/* 217 */       paramArrayOfint[3] = 0; paramArrayOfint[2] = 0; paramArrayOfint[1] = 0; paramArrayOfint[0] = 0;
/*     */     } 
/* 219 */     log.finest("id {0} part {1} bounds {2},{3} {4}x{5}", new Object[] {
/* 220 */           String.valueOf(paramLong), String.valueOf(paramInt), Integer.valueOf(paramArrayOfint[0]), Integer.valueOf(paramArrayOfint[1]), Integer.valueOf(paramArrayOfint[2]), Integer.valueOf(paramArrayOfint[3])
/*     */         });
/*     */   }
/*     */   
/*     */   private static Node getTrack(ScrollBar paramScrollBar) {
/* 225 */     return findNode(paramScrollBar, "track");
/*     */   }
/*     */ 
/*     */   
/*     */   private static Node getIncButton(ScrollBar paramScrollBar) {
/* 230 */     return findNode(paramScrollBar, "increment-button");
/*     */   }
/*     */ 
/*     */   
/*     */   private static Node getDecButton(ScrollBar paramScrollBar) {
/* 235 */     return findNode(paramScrollBar, "decrement-button");
/*     */   }
/*     */   
/*     */   private static Node findNode(ScrollBar paramScrollBar, String paramString) {
/* 239 */     for (Node node : paramScrollBar.getChildrenUnmodifiable()) {
/* 240 */       if (node.getStyleClass().contains(paramString)) {
/* 241 */         return node;
/*     */       }
/*     */     } 
/* 244 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\theme\ScrollBarThemeImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */