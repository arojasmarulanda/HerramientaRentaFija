/*    */ package com.sun.javafx.webkit.theme;
/*    */ 
/*    */ import com.sun.webkit.graphics.WCGraphicsContext;
/*    */ import javafx.scene.control.Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Renderer
/*    */ {
/*    */   private static Renderer instance;
/*    */   
/*    */   public static void setRenderer(Renderer paramRenderer) {
/* 36 */     instance = paramRenderer;
/*    */   }
/*    */   
/*    */   public static Renderer getRenderer() {
/* 40 */     return instance;
/*    */   }
/*    */   
/*    */   protected abstract void render(Control paramControl, WCGraphicsContext paramWCGraphicsContext);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\theme\Renderer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */