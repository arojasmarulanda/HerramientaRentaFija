/*     */ package com.sun.javafx.webkit.prism;
/*     */ 
/*     */ import com.sun.prism.CompositeMode;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.GraphicsPipeline;
/*     */ import com.sun.prism.Image;
/*     */ import com.sun.prism.PixelFormat;
/*     */ import com.sun.prism.RTTexture;
/*     */ import com.sun.prism.ResourceFactory;
/*     */ import com.sun.prism.ResourceFactoryListener;
/*     */ import com.sun.prism.Texture;
/*     */ import com.sun.prism.paint.Color;
/*     */ import com.sun.prism.paint.Paint;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RTImage
/*     */   extends PrismImage
/*     */   implements ResourceFactoryListener
/*     */ {
/*     */   private RTTexture txt;
/*     */   private final int width;
/*     */   private final int height;
/*     */   private boolean listenerAdded = false;
/*     */   private ByteBuffer pixelBuffer;
/*     */   private float pixelScale;
/*     */   
/*     */   RTImage(int paramInt1, int paramInt2, float paramFloat) {
/*  55 */     this.width = paramInt1;
/*  56 */     this.height = paramInt2;
/*  57 */     this.pixelScale = paramFloat;
/*     */   }
/*     */ 
/*     */   
/*     */   Image getImage() {
/*  62 */     return Image.fromByteBgraPreData(
/*  63 */         getPixelBuffer(), 
/*  64 */         getWidth(), getHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   Graphics getGraphics() {
/*  69 */     Graphics graphics = getTexture().createGraphics();
/*  70 */     graphics.transform(PrismGraphicsManager.getPixelScaleTransform());
/*  71 */     return graphics;
/*     */   }
/*     */   
/*     */   private RTTexture getTexture() {
/*  75 */     if (this.txt == null) {
/*  76 */       ResourceFactory resourceFactory = GraphicsPipeline.getDefaultResourceFactory();
/*  77 */       this.txt = resourceFactory.createRTTexture(
/*  78 */           (int)Math.ceil((this.width * this.pixelScale)), 
/*  79 */           (int)Math.ceil((this.height * this.pixelScale)), Texture.WrapMode.CLAMP_NOT_NEEDED);
/*     */       
/*  81 */       this.txt.contentsUseful();
/*  82 */       this.txt.makePermanent();
/*  83 */       if (!this.listenerAdded) {
/*  84 */         resourceFactory.addFactoryListener(this);
/*  85 */         this.listenerAdded = true;
/*     */       } 
/*     */     } 
/*  88 */     return this.txt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void draw(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
/*  96 */     if (this.txt == null && paramGraphics.getCompositeMode() == CompositeMode.SRC_OVER) {
/*     */       return;
/*     */     }
/*  99 */     if (paramGraphics instanceof com.sun.prism.PrinterGraphics) {
/*     */       
/* 101 */       int i = paramInt7 - paramInt5;
/* 102 */       int j = paramInt8 - paramInt6;
/* 103 */       IntBuffer intBuffer = IntBuffer.allocate(i * j);
/*     */       
/* 105 */       PrismInvoker.runOnRenderThread(() -> getTexture().readPixels(paramIntBuffer));
/*     */ 
/*     */       
/* 108 */       Image image = Image.fromIntArgbPreData(intBuffer, i, j);
/* 109 */       Texture texture = paramGraphics.getResourceFactory().createTexture(image, Texture.Usage.STATIC, Texture.WrapMode.CLAMP_NOT_NEEDED);
/*     */       
/* 111 */       paramGraphics.drawTexture(texture, paramInt1, paramInt2, paramInt3, paramInt4, 0.0F, 0.0F, i, j);
/*     */ 
/*     */       
/* 114 */       texture.dispose();
/*     */     }
/* 116 */     else if (this.txt == null) {
/* 117 */       Paint paint = paramGraphics.getPaint();
/* 118 */       paramGraphics.setPaint(Color.TRANSPARENT);
/* 119 */       paramGraphics.fillQuad(paramInt1, paramInt2, paramInt3, paramInt4);
/* 120 */       paramGraphics.setPaint(paint);
/*     */     } else {
/*     */       
/* 123 */       paramGraphics.drawTexture(this.txt, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5 * this.pixelScale, paramInt6 * this.pixelScale, paramInt7 * this.pixelScale, paramInt8 * this.pixelScale);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {
/* 133 */     PrismInvoker.invokeOnRenderThread(() -> {
/*     */           if (this.txt != null) {
/*     */             this.txt.dispose();
/*     */             this.txt = null;
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 143 */     return this.width;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 148 */     return this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuffer getPixelBuffer() {
/* 153 */     boolean bool = false;
/* 154 */     if (this.pixelBuffer == null) {
/* 155 */       this.pixelBuffer = ByteBuffer.allocateDirect(this.width * this.height * 4);
/* 156 */       if (this.pixelBuffer != null) {
/* 157 */         this.pixelBuffer.order(ByteOrder.nativeOrder());
/* 158 */         bool = true;
/*     */       } 
/*     */     } 
/* 161 */     if (bool || isDirty()) {
/* 162 */       PrismInvoker.runOnRenderThread(() -> {
/*     */             flushRQ();
/*     */             
/*     */             if (this.txt != null && this.pixelBuffer != null) {
/*     */               PixelFormat pixelFormat = this.txt.getPixelFormat();
/*     */               
/*     */               if (pixelFormat != PixelFormat.INT_ARGB_PRE && pixelFormat != PixelFormat.BYTE_BGRA_PRE) {
/*     */                 throw new AssertionError("Unexpected pixel format: " + pixelFormat);
/*     */               }
/*     */               
/*     */               RTTexture rTTexture = this.txt;
/*     */               
/*     */               if (this.pixelScale != 1.0F) {
/*     */                 ResourceFactory resourceFactory = GraphicsPipeline.getDefaultResourceFactory();
/*     */                 
/*     */                 rTTexture = resourceFactory.createRTTexture(this.width, this.height, Texture.WrapMode.CLAMP_NOT_NEEDED);
/*     */                 
/*     */                 Graphics graphics = rTTexture.createGraphics();
/*     */                 
/*     */                 graphics.drawTexture(this.txt, 0.0F, 0.0F, this.width, this.height, 0.0F, 0.0F, this.width * this.pixelScale, this.height * this.pixelScale);
/*     */               } 
/*     */               this.pixelBuffer.rewind();
/*     */               int[] arrayOfInt = rTTexture.getPixels();
/*     */               if (arrayOfInt != null) {
/*     */                 this.pixelBuffer.asIntBuffer().put(arrayOfInt);
/*     */               } else {
/*     */                 rTTexture.readPixels(this.pixelBuffer);
/*     */               } 
/*     */               if (rTTexture != this.txt) {
/*     */                 rTTexture.dispose();
/*     */               }
/*     */             } 
/*     */           });
/*     */     }
/* 196 */     return this.pixelBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void drawPixelBuffer() {
/* 203 */     PrismInvoker.invokeOnRenderThread(new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 207 */             Graphics graphics = RTImage.this.getGraphics();
/* 208 */             if (graphics != null && RTImage.this.pixelBuffer != null) {
/* 209 */               RTImage.this.pixelBuffer.rewind();
/* 210 */               Image image = Image.fromByteBgraPreData(RTImage.this
/* 211 */                   .pixelBuffer, RTImage.this
/* 212 */                   .width, RTImage.this
/* 213 */                   .height);
/* 214 */               Texture texture = graphics.getResourceFactory().createTexture(image, Texture.Usage.DEFAULT, Texture.WrapMode.CLAMP_NOT_NEEDED);
/* 215 */               graphics.clear();
/* 216 */               graphics.drawTexture(texture, 0.0F, 0.0F, RTImage.this.width, RTImage.this.height);
/* 217 */               texture.dispose();
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public void factoryReset() {
/* 224 */     if (this.txt != null) {
/* 225 */       this.txt.dispose();
/* 226 */       this.txt = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void factoryReleased() {}
/*     */ 
/*     */   
/*     */   public float getPixelScale() {
/* 235 */     return this.pixelScale;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\RTImage.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */