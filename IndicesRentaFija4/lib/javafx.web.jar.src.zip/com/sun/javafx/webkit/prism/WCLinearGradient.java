/*    */ package com.sun.javafx.webkit.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.prism.paint.LinearGradient;
/*    */ import com.sun.prism.paint.Stop;
/*    */ import com.sun.webkit.graphics.WCGradient;
/*    */ import com.sun.webkit.graphics.WCPoint;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WCLinearGradient
/*    */   extends WCGradient<LinearGradient>
/*    */ {
/*    */   private final WCPoint p1;
/*    */   private final WCPoint p2;
/* 42 */   private final List<Stop> stops = new ArrayList<>();
/*    */   
/*    */   WCLinearGradient(WCPoint paramWCPoint1, WCPoint paramWCPoint2) {
/* 45 */     this.p1 = paramWCPoint1;
/* 46 */     this.p2 = paramWCPoint2;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void addStop(int paramInt, float paramFloat) {
/* 51 */     this.stops.add(new Stop(WCGraphicsPrismContext.createColor(paramInt), paramFloat));
/*    */   }
/*    */   
/*    */   public LinearGradient getPlatformGradient() {
/* 55 */     Collections.sort(this.stops, WCRadialGradient.COMPARATOR);
/* 56 */     return new LinearGradient(this.p1
/* 57 */         .getX(), this.p1
/* 58 */         .getY(), this.p2
/* 59 */         .getX(), this.p2
/* 60 */         .getY(), BaseTransform.IDENTITY_TRANSFORM, 
/*    */         
/* 62 */         isProportional(), 
/* 63 */         getSpreadMethod() - 1, this.stops);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 69 */     return WCRadialGradient.toString(this, this.p1, this.p2, null, this.stops);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCLinearGradient.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */