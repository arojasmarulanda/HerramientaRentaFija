/*    */ package com.sun.javafx.webkit.prism;
/*    */ 
/*    */ import com.sun.javafx.tk.Toolkit;
/*    */ import com.sun.javafx.webkit.UIClientImpl;
/*    */ import com.sun.prism.Graphics;
/*    */ import com.sun.prism.Image;
/*    */ import com.sun.webkit.graphics.WCImage;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.Base64;
/*    */ import java.util.Iterator;
/*    */ import javax.imageio.ImageIO;
/*    */ import javax.imageio.ImageWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class PrismImage
/*    */   extends WCImage
/*    */ {
/*    */   abstract Image getImage();
/*    */   
/*    */   abstract Graphics getGraphics();
/*    */   
/*    */   abstract void draw(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
/*    */   
/*    */   abstract void dispose();
/*    */   
/*    */   public Object getPlatformImage() {
/* 55 */     return getImage();
/*    */   }
/*    */ 
/*    */   
/*    */   public void deref() {
/* 60 */     super.deref();
/* 61 */     if (!hasRefs()) {
/* 62 */       dispose();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected final byte[] toData(String paramString) {
/* 68 */     BufferedImage bufferedImage = UIClientImpl.toBufferedImage(Toolkit.getImageAccessor().fromPlatformImage(getImage()));
/* 69 */     if (bufferedImage instanceof BufferedImage) {
/* 70 */       Iterator<ImageWriter> iterator = ImageIO.getImageWritersByMIMEType(paramString);
/* 71 */       while (iterator.hasNext()) {
/* 72 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 73 */         ImageWriter imageWriter = iterator.next();
/*    */         try {
/* 75 */           imageWriter.setOutput(ImageIO.createImageOutputStream(byteArrayOutputStream));
/* 76 */           imageWriter.write(bufferedImage);
/*    */         }
/* 78 */         catch (IOException iOException) {
/*    */           
/*    */           continue;
/*    */         } finally {
/* 82 */           imageWriter.dispose();
/*    */         } 
/* 84 */         return byteArrayOutputStream.toByteArray();
/*    */       } 
/*    */     } 
/* 87 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   protected final String toDataURL(String paramString) {
/* 92 */     byte[] arrayOfByte = toData(paramString);
/* 93 */     if (arrayOfByte != null) {
/* 94 */       StringBuilder stringBuilder = new StringBuilder();
/* 95 */       stringBuilder.append("data:").append(paramString).append(";base64,");
/* 96 */       stringBuilder.append(Base64.getMimeEncoder().encodeToString(arrayOfByte));
/* 97 */       return stringBuilder.toString();
/*    */     } 
/* 99 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\PrismImage.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */