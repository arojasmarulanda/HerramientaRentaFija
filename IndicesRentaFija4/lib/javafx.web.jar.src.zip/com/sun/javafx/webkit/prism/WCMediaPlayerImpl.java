/*     */ package com.sun.javafx.webkit.prism;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.javafx.media.PrismMediaFrameHandler;
/*     */ import com.sun.media.jfxmedia.Media;
/*     */ import com.sun.media.jfxmedia.MediaManager;
/*     */ import com.sun.media.jfxmedia.MediaPlayer;
/*     */ import com.sun.media.jfxmedia.control.VideoDataBuffer;
/*     */ import com.sun.media.jfxmedia.events.BufferListener;
/*     */ import com.sun.media.jfxmedia.events.BufferProgressEvent;
/*     */ import com.sun.media.jfxmedia.events.MediaErrorListener;
/*     */ import com.sun.media.jfxmedia.events.NewFrameEvent;
/*     */ import com.sun.media.jfxmedia.events.PlayerStateEvent;
/*     */ import com.sun.media.jfxmedia.events.PlayerStateListener;
/*     */ import com.sun.media.jfxmedia.events.PlayerTimeListener;
/*     */ import com.sun.media.jfxmedia.events.VideoRendererListener;
/*     */ import com.sun.media.jfxmedia.events.VideoTrackSizeListener;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.track.Track;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.Texture;
/*     */ import com.sun.webkit.graphics.WCGraphicsContext;
/*     */ import com.sun.webkit.graphics.WCMediaPlayer;
/*     */ import java.net.URI;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WCMediaPlayerImpl
/*     */   extends WCMediaPlayer
/*     */   implements PlayerStateListener, MediaErrorListener, VideoTrackSizeListener, BufferListener, PlayerTimeListener
/*     */ {
/*  62 */   private final Object lock = new Object();
/*     */   
/*     */   private volatile MediaPlayer player;
/*     */   
/*     */   private volatile CreateThread createThread;
/*     */   
/*     */   private volatile PrismMediaFrameHandler frameHandler;
/*     */   
/*     */   private final MediaFrameListener frameListener;
/*     */   
/*     */   private boolean gotFirstFrame = false;
/*     */   
/*  74 */   private int finished = 0;
/*     */   
/*     */   private float bufferedStart;
/*     */   private float bufferedEnd;
/*     */   private boolean buffering;
/*     */   
/*     */   private MediaPlayer getPlayer() {
/*  81 */     synchronized (this.lock) {
/*  82 */       if (this.createThread != null) {
/*  83 */         return null;
/*     */       }
/*  85 */       return this.player;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setPlayer(MediaPlayer paramMediaPlayer) {
/*  90 */     synchronized (this.lock) {
/*  91 */       this.player = paramMediaPlayer;
/*  92 */       installListeners();
/*  93 */       this.frameHandler = PrismMediaFrameHandler.getHandler(this.player);
/*     */     } 
/*     */     
/*  96 */     this.finished = 0;
/*     */   }
/*     */   
/*     */   private final class CreateThread
/*     */     extends Thread {
/*     */     private boolean cancelled = false;
/*     */     
/*     */     private CreateThread(String param1String1, String param1String2) {
/* 104 */       this.url = param1String1;
/* 105 */       this.userAgent = param1String2;
/* 106 */       WCMediaPlayerImpl.this.gotFirstFrame = false;
/*     */     }
/*     */     private final String url; private final String userAgent;
/*     */     
/*     */     public void run() {
/* 111 */       WCMediaPlayerImpl.log.fine("CreateThread: started, url={0}", new Object[] { this.url });
/*     */       
/* 113 */       WCMediaPlayerImpl.this.notifyNetworkStateChanged(2);
/* 114 */       WCMediaPlayerImpl.this.notifyReadyStateChanged(0);
/*     */       
/* 116 */       MediaPlayer mediaPlayer = null;
/*     */       
/*     */       try {
/* 119 */         Locator locator = new Locator(new URI(this.url));
/* 120 */         if (this.userAgent != null) {
/* 121 */           locator.setConnectionProperty("User-Agent", this.userAgent);
/*     */         }
/* 123 */         locator.init();
/* 124 */         WCMediaPlayerImpl.log.fine("CreateThread: locator created");
/*     */         
/* 126 */         mediaPlayer = MediaManager.getPlayer(locator);
/* 127 */       } catch (Exception exception) {
/* 128 */         WCMediaPlayerImpl.log.warning("CreateThread ERROR: {0}", new Object[] { exception.toString() });
/* 129 */         if (WCMediaPlayerImpl.log.isLoggable(PlatformLogger.Level.FINE)) {
/* 130 */           exception.printStackTrace(System.out);
/*     */         }
/* 132 */         WCMediaPlayerImpl.this.onError(this, 0, exception.getMessage());
/*     */         
/*     */         return;
/*     */       } 
/* 136 */       synchronized (WCMediaPlayerImpl.this.lock) {
/* 137 */         if (this.cancelled) {
/* 138 */           WCMediaPlayerImpl.log.fine("CreateThread: cancelled");
/* 139 */           mediaPlayer.dispose();
/*     */           return;
/*     */         } 
/* 142 */         WCMediaPlayerImpl.this.createThread = null;
/* 143 */         WCMediaPlayerImpl.this.setPlayer(mediaPlayer);
/*     */       } 
/* 145 */       WCMediaPlayerImpl.log.fine("CreateThread: completed");
/*     */     }
/*     */     
/*     */     private void cancel() {
/* 149 */       synchronized (WCMediaPlayerImpl.this.lock) {
/* 150 */         this.cancelled = true;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void load(String paramString1, String paramString2) {
/* 157 */     synchronized (this.lock) {
/* 158 */       if (this.createThread != null) {
/* 159 */         this.createThread.cancel();
/*     */       }
/* 161 */       disposePlayer();
/* 162 */       this.createThread = new CreateThread(paramString1, paramString2);
/*     */     } 
/*     */ 
/*     */     
/* 166 */     if (getPreload() != 0) {
/* 167 */       this.createThread.start();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void cancelLoad() {
/* 172 */     synchronized (this.lock) {
/* 173 */       if (this.createThread != null) {
/* 174 */         this.createThread.cancel();
/*     */       }
/*     */     } 
/* 177 */     MediaPlayer mediaPlayer = getPlayer();
/* 178 */     if (mediaPlayer != null) {
/* 179 */       mediaPlayer.stop();
/*     */     }
/* 181 */     notifyNetworkStateChanged(0);
/* 182 */     notifyReadyStateChanged(0);
/*     */   }
/*     */   
/*     */   protected void disposePlayer() {
/*     */     MediaPlayer mediaPlayer;
/* 187 */     synchronized (this.lock) {
/* 188 */       removeListeners();
/* 189 */       mediaPlayer = this.player;
/* 190 */       this.player = null;
/* 191 */       if (this.frameHandler != null) {
/* 192 */         this.frameHandler.releaseTextures();
/* 193 */         this.frameHandler = null;
/*     */       } 
/*     */     } 
/* 196 */     if (mediaPlayer != null) {
/* 197 */       mediaPlayer.stop();
/* 198 */       mediaPlayer.dispose();
/* 199 */       mediaPlayer = null;
/* 200 */       if (this.frameListener != null) {
/* 201 */         this.frameListener.releaseVideoFrames();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void installListeners() {
/* 207 */     if (null != this.player) {
/* 208 */       this.player.addMediaPlayerListener(this);
/* 209 */       this.player.addMediaErrorListener(this);
/* 210 */       this.player.addVideoTrackSizeListener(this);
/* 211 */       this.player.addBufferListener(this);
/* 212 */       this.player.getVideoRenderControl().addVideoRendererListener(this.frameListener);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeListeners() {
/* 217 */     if (null != this.player) {
/* 218 */       this.player.removeMediaPlayerListener(this);
/* 219 */       this.player.removeMediaErrorListener(this);
/* 220 */       this.player.removeVideoTrackSizeListener(this);
/* 221 */       this.player.removeBufferListener(this);
/* 222 */       this.player.getVideoRenderControl().removeVideoRendererListener(this.frameListener);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void prepareToPlay() {
/* 227 */     synchronized (this.lock) {
/* 228 */       if (this.player == null) {
/*     */         
/* 230 */         CreateThread createThread = this.createThread;
/* 231 */         if (createThread != null && createThread.getState() == Thread.State.NEW) {
/* 232 */           createThread.start();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void play() {
/* 239 */     MediaPlayer mediaPlayer = getPlayer();
/* 240 */     if (mediaPlayer != null) {
/* 241 */       mediaPlayer.play();
/*     */       
/* 243 */       notifyPaused(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void pause() {
/* 248 */     MediaPlayer mediaPlayer = getPlayer();
/* 249 */     if (mediaPlayer != null) {
/* 250 */       mediaPlayer.pause();
/*     */       
/* 252 */       notifyPaused(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected float getCurrentTime() {
/* 257 */     MediaPlayer mediaPlayer = getPlayer();
/* 258 */     if (mediaPlayer == null) {
/* 259 */       return 0.0F;
/*     */     }
/* 261 */     return (this.finished == 0) ? (float)mediaPlayer.getPresentationTime() : (
/* 262 */       (this.finished > 0) ? (float)mediaPlayer.getDuration() : 
/* 263 */       0.0F);
/*     */   }
/*     */   
/*     */   protected void seek(float paramFloat) {
/* 267 */     MediaPlayer mediaPlayer = getPlayer();
/* 268 */     if (mediaPlayer != null) {
/* 269 */       this.finished = 0;
/* 270 */       if (getReadyState() >= 1) {
/* 271 */         notifySeeking(true, 1);
/*     */       } else {
/* 273 */         notifySeeking(true, 0);
/*     */       } 
/* 275 */       mediaPlayer.seek(paramFloat);
/*     */ 
/*     */ 
/*     */       
/* 279 */       final float seekTime = paramFloat;
/* 280 */       Thread thread = new Thread(new Runnable() {
/*     */             public void run() {
/* 282 */               while (WCMediaPlayerImpl.this.isSeeking()) {
/* 283 */                 MediaPlayer mediaPlayer = WCMediaPlayerImpl.this.getPlayer();
/* 284 */                 if (mediaPlayer == null) {
/*     */                   break;
/*     */                 }
/* 287 */                 double d = mediaPlayer.getPresentationTime();
/* 288 */                 if (seekTime < 0.01D || Math.abs(d) >= 0.01D) {
/* 289 */                   WCMediaPlayerImpl.this.notifySeeking(false, 4);
/*     */                   break;
/*     */                 } 
/*     */                 try {
/* 293 */                   Thread.sleep(10L);
/* 294 */                 } catch (InterruptedException interruptedException) {}
/*     */               } 
/*     */             }
/*     */           });
/*     */       
/* 299 */       thread.setDaemon(true);
/* 300 */       thread.start();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setRate(float paramFloat) {
/* 305 */     MediaPlayer mediaPlayer = getPlayer();
/* 306 */     if (mediaPlayer != null) {
/* 307 */       mediaPlayer.setRate(paramFloat);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setVolume(float paramFloat) {
/* 312 */     MediaPlayer mediaPlayer = getPlayer();
/* 313 */     if (mediaPlayer != null) {
/* 314 */       mediaPlayer.setVolume(paramFloat);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setMute(boolean paramBoolean) {
/* 319 */     MediaPlayer mediaPlayer = getPlayer();
/* 320 */     if (mediaPlayer != null) {
/* 321 */       mediaPlayer.setMute(paramBoolean);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSize(int paramInt1, int paramInt2) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setPreservesPitch(boolean paramBoolean) {}
/*     */ 
/*     */   
/*     */   protected void renderCurrentFrame(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 335 */     synchronized (this.lock) {
/* 336 */       renderImpl(paramWCGraphicsContext, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderImpl(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 342 */     log.finer(">>(Prism)renderImpl");
/* 343 */     Graphics graphics = (Graphics)paramWCGraphicsContext.getPlatformGraphics();
/*     */     
/* 345 */     Texture texture = null;
/* 346 */     VideoDataBuffer videoDataBuffer = this.frameListener.getLatestFrame();
/*     */     
/* 348 */     if (null != videoDataBuffer) {
/* 349 */       if (null != this.frameHandler) {
/* 350 */         texture = this.frameHandler.getTexture(graphics, videoDataBuffer);
/*     */       }
/* 352 */       videoDataBuffer.releaseFrame();
/*     */     } 
/*     */     
/* 355 */     if (texture != null) {
/* 356 */       graphics.drawTexture(texture, paramInt1, paramInt2, (paramInt1 + paramInt3), (paramInt2 + paramInt4), 0.0F, 0.0F, texture
/*     */           
/* 358 */           .getContentWidth(), texture.getContentHeight());
/* 359 */       texture.unlock();
/*     */     } else {
/* 361 */       log.finest("  (Prism)renderImpl, texture is null, draw black rect");
/* 362 */       paramWCGraphicsContext.fillRect(paramInt1, paramInt2, paramInt3, paramInt4, Integer.valueOf(-16777216));
/*     */     } 
/* 364 */     log.finer("<<(Prism)renderImpl");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onReady(PlayerStateEvent paramPlayerStateEvent) {
/* 370 */     MediaPlayer mediaPlayer = getPlayer();
/* 371 */     log.fine("onReady");
/* 372 */     Media media = mediaPlayer.getMedia();
/* 373 */     boolean bool1 = false;
/* 374 */     boolean bool2 = false;
/* 375 */     if (media != null) {
/* 376 */       List<Track> list = media.getTracks();
/* 377 */       if (list != null) {
/* 378 */         log.fine("{0} track(s) detected:", new Object[] { Integer.valueOf(list.size()) });
/* 379 */         for (Track track : list) {
/* 380 */           if (track instanceof com.sun.media.jfxmedia.track.VideoTrack) {
/* 381 */             bool1 = true;
/* 382 */           } else if (track instanceof com.sun.media.jfxmedia.track.AudioTrack) {
/* 383 */             bool2 = true;
/*     */           } 
/* 385 */           log.fine("track: {0}", new Object[] { track });
/*     */         } 
/*     */       } else {
/* 388 */         log.warning("onReady, tracks IS NULL");
/*     */       } 
/*     */     } else {
/* 391 */       log.warning("onReady, media IS NULL");
/*     */     } 
/* 393 */     log.fine("onReady, hasVideo:{0}, hasAudio: {1}", new Object[] { Boolean.valueOf(bool1), Boolean.valueOf(bool2) });
/* 394 */     notifyReady(bool1, bool2, (float)mediaPlayer.getDuration());
/*     */ 
/*     */     
/* 397 */     if (!bool1) {
/* 398 */       notifyReadyStateChanged(4);
/*     */     }
/* 400 */     else if (getReadyState() < 1) {
/* 401 */       if (this.gotFirstFrame) {
/* 402 */         notifyReadyStateChanged(4);
/*     */       } else {
/* 404 */         notifyReadyStateChanged(1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onPlaying(PlayerStateEvent paramPlayerStateEvent) {
/* 412 */     log.fine("onPlaying");
/* 413 */     notifyPaused(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPause(PlayerStateEvent paramPlayerStateEvent) {
/* 418 */     log.fine("onPause, time: {0}", new Object[] { Double.valueOf(paramPlayerStateEvent.getTime()) });
/* 419 */     notifyPaused(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStop(PlayerStateEvent paramPlayerStateEvent) {
/* 424 */     log.fine("onStop");
/* 425 */     notifyPaused(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStall(PlayerStateEvent paramPlayerStateEvent) {
/* 430 */     log.fine("onStall");
/*     */   }
/*     */ 
/*     */   
/*     */   public void onFinish(PlayerStateEvent paramPlayerStateEvent) {
/* 435 */     MediaPlayer mediaPlayer = getPlayer();
/* 436 */     if (mediaPlayer != null) {
/* 437 */       this.finished = (mediaPlayer.getRate() > 0.0F) ? 1 : -1;
/* 438 */       log.fine("onFinish, time: {0}", new Object[] { Double.valueOf(paramPlayerStateEvent.getTime()) });
/* 439 */       notifyFinished();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onHalt(PlayerStateEvent paramPlayerStateEvent) {
/* 445 */     log.fine("onHalt");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onError(Object paramObject, int paramInt, String paramString) {
/* 452 */     log.warning("onError, errCode={0}, msg={1}", new Object[] { Integer.valueOf(paramInt), paramString });
/*     */ 
/*     */     
/* 455 */     notifyNetworkStateChanged(5);
/* 456 */     notifyReadyStateChanged(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDurationChanged(double paramDouble) {
/* 462 */     log.fine("onDurationChanged, duration={0}", new Object[] { Double.valueOf(paramDouble) });
/* 463 */     notifyDurationChanged((float)paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onSizeChanged(int paramInt1, int paramInt2) {
/* 470 */     log.fine("onSizeChanged, new size = {0} x {1}", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/* 471 */     notifySizeChanged(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   private void notifyFrameArrived() {
/* 475 */     if (!this.gotFirstFrame) {
/*     */ 
/*     */       
/* 478 */       if (getReadyState() >= 1) {
/* 479 */         notifyReadyStateChanged(4);
/*     */       }
/* 481 */       this.gotFirstFrame = true;
/*     */     } 
/* 483 */     if (this.finished != 0) {
/* 484 */       log.fine("notifyFrameArrived (after finished) time: {0}", new Object[] { Double.valueOf(getPlayer().getPresentationTime()) });
/*     */     }
/* 486 */     notifyNewFrame();
/*     */   }
/*     */   WCMediaPlayerImpl() {
/* 489 */     this.bufferedStart = 0.0F;
/* 490 */     this.bufferedEnd = 0.0F;
/* 491 */     this.buffering = false;
/*     */     this.frameListener = new MediaFrameListener();
/*     */   }
/*     */   
/*     */   private void updateBufferingStatus() {
/* 496 */     boolean bool = this.buffering ? true : ((this.bufferedStart > 0.0F) ? true : true);
/* 497 */     log.fine("updateBufferingStatus, buffered: [{0} - {1}], buffering = {2}", new Object[] {
/* 498 */           Float.valueOf(this.bufferedStart), Float.valueOf(this.bufferedEnd), Boolean.valueOf(this.buffering) });
/* 499 */     notifyNetworkStateChanged(bool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onBufferProgress(BufferProgressEvent paramBufferProgressEvent) {
/* 512 */     if (paramBufferProgressEvent.getDuration() < 0.0D) {
/*     */       return;
/*     */     }
/* 515 */     double d = paramBufferProgressEvent.getDuration() / paramBufferProgressEvent.getBufferStop();
/* 516 */     this.bufferedStart = (float)(d * paramBufferProgressEvent.getBufferStart());
/* 517 */     this.bufferedEnd = (float)(d * paramBufferProgressEvent.getBufferPosition());
/* 518 */     this.buffering = (paramBufferProgressEvent.getBufferPosition() < paramBufferProgressEvent.getBufferStop());
/*     */     
/* 520 */     float[] arrayOfFloat = new float[2];
/* 521 */     arrayOfFloat[0] = this.bufferedStart;
/* 522 */     arrayOfFloat[1] = this.bufferedEnd;
/* 523 */     int i = (int)(paramBufferProgressEvent.getBufferPosition() - paramBufferProgressEvent.getBufferStart());
/* 524 */     log.finer("onBufferProgress, bufferStart={0}, bufferStop={1}, bufferPos={2}, duration={3}; notify range [{4},[5]], bytesLoaded: {6}", new Object[] {
/*     */ 
/*     */           
/* 527 */           Long.valueOf(paramBufferProgressEvent.getBufferStart()), Long.valueOf(paramBufferProgressEvent.getBufferStop()), 
/* 528 */           Long.valueOf(paramBufferProgressEvent.getBufferPosition()), Double.valueOf(paramBufferProgressEvent.getDuration()), 
/* 529 */           Float.valueOf(arrayOfFloat[0]), Float.valueOf(arrayOfFloat[1]), Integer.valueOf(i) });
/* 530 */     notifyBufferChanged(arrayOfFloat, i);
/* 531 */     updateBufferingStatus();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class MediaFrameListener
/*     */     implements VideoRendererListener
/*     */   {
/* 539 */     private final Object frameLock = new Object();
/*     */     private VideoDataBuffer currentFrame;
/*     */     private VideoDataBuffer nextFrame;
/*     */     
/*     */     public void videoFrameUpdated(NewFrameEvent param1NewFrameEvent) {
/* 544 */       synchronized (this.frameLock) {
/* 545 */         if (null != this.nextFrame) {
/* 546 */           this.nextFrame.releaseFrame();
/*     */         }
/* 548 */         this.nextFrame = param1NewFrameEvent.getFrameData();
/* 549 */         if (null != this.nextFrame) {
/* 550 */           this.nextFrame.holdFrame();
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 555 */       WCMediaPlayerImpl.this.notifyFrameArrived();
/*     */     }
/*     */     
/*     */     public void releaseVideoFrames() {
/* 559 */       synchronized (this.frameLock) {
/* 560 */         if (null != this.nextFrame) {
/* 561 */           this.nextFrame.releaseFrame();
/* 562 */           this.nextFrame = null;
/*     */         } 
/*     */         
/* 565 */         if (null != this.currentFrame) {
/* 566 */           this.currentFrame.releaseFrame();
/* 567 */           this.currentFrame = null;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public VideoDataBuffer getLatestFrame() {
/* 573 */       synchronized (this.frameLock) {
/* 574 */         if (null != this.nextFrame) {
/* 575 */           if (null != this.currentFrame) {
/* 576 */             this.currentFrame.releaseFrame();
/*     */           }
/* 578 */           this.currentFrame = this.nextFrame;
/* 579 */           this.nextFrame = null;
/*     */         } 
/*     */ 
/*     */         
/* 583 */         if (null != this.currentFrame) {
/* 584 */           this.currentFrame.holdFrame();
/*     */         }
/* 586 */         return this.currentFrame;
/*     */       } 
/*     */     }
/*     */     
/*     */     private MediaFrameListener() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCMediaPlayerImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */