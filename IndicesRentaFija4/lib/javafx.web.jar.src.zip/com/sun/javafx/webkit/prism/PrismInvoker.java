/*    */ package com.sun.javafx.webkit.prism;
/*    */ 
/*    */ import com.sun.javafx.application.PlatformImpl;
/*    */ import com.sun.javafx.tk.RenderJob;
/*    */ import com.sun.javafx.tk.Toolkit;
/*    */ import com.sun.webkit.Invoker;
/*    */ import java.util.concurrent.ExecutionException;
/*    */ import java.util.concurrent.FutureTask;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PrismInvoker
/*    */   extends Invoker
/*    */ {
/*    */   protected boolean lock(ReentrantLock paramReentrantLock) {
/* 46 */     return false;
/*    */   }
/*    */   
/*    */   protected boolean unlock(ReentrantLock paramReentrantLock) {
/* 50 */     return false;
/*    */   }
/*    */   
/*    */   protected boolean isEventThread() {
/* 54 */     return isEventThreadPrivate();
/*    */   }
/*    */   
/*    */   private static boolean isEventThreadPrivate() {
/* 58 */     return Toolkit.getToolkit().isFxUserThread();
/*    */   }
/*    */   
/*    */   public void checkEventThread() {
/* 62 */     Toolkit.getToolkit().checkFxUserThread();
/*    */   }
/*    */   
/*    */   public void invokeOnEventThread(Runnable paramRunnable) {
/* 66 */     if (isEventThread()) {
/* 67 */       paramRunnable.run();
/*    */     } else {
/* 69 */       PlatformImpl.runLater(paramRunnable);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void postOnEventThread(Runnable paramRunnable) {
/* 74 */     PlatformImpl.runLater(paramRunnable);
/*    */   }
/*    */   
/*    */   static void invokeOnRenderThread(Runnable paramRunnable) {
/* 78 */     Toolkit.getToolkit().addRenderJob(new RenderJob(paramRunnable));
/*    */   }
/*    */   
/*    */   static void runOnRenderThread(Runnable paramRunnable) {
/* 82 */     if (Thread.currentThread().getName().startsWith("QuantumRenderer")) {
/* 83 */       paramRunnable.run();
/*    */     } else {
/* 85 */       FutureTask futureTask = new FutureTask(paramRunnable, null);
/* 86 */       Toolkit.getToolkit().addRenderJob(new RenderJob(futureTask));
/*    */       
/*    */       try {
/* 89 */         futureTask.get();
/* 90 */       } catch (ExecutionException executionException) {
/* 91 */         throw new AssertionError(executionException);
/* 92 */       } catch (InterruptedException interruptedException) {}
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\PrismInvoker.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */