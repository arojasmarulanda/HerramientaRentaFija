/*     */ package com.sun.javafx.webkit.prism;
/*     */ 
/*     */ import com.sun.glass.ui.Screen;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.media.jfxmedia.MediaManager;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.webkit.graphics.WCFont;
/*     */ import com.sun.webkit.graphics.WCFontCustomPlatformData;
/*     */ import com.sun.webkit.graphics.WCGraphicsContext;
/*     */ import com.sun.webkit.graphics.WCGraphicsManager;
/*     */ import com.sun.webkit.graphics.WCImage;
/*     */ import com.sun.webkit.graphics.WCImageDecoder;
/*     */ import com.sun.webkit.graphics.WCImageFrame;
/*     */ import com.sun.webkit.graphics.WCMediaPlayer;
/*     */ import com.sun.webkit.graphics.WCPageBackBuffer;
/*     */ import com.sun.webkit.graphics.WCPath;
/*     */ import com.sun.webkit.graphics.WCRectangle;
/*     */ import com.sun.webkit.graphics.WCRenderQueue;
/*     */ import com.sun.webkit.graphics.WCTransform;
/*     */ import com.sun.webkit.perf.WCFontPerfLogger;
/*     */ import com.sun.webkit.perf.WCGraphicsPerfLogger;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PrismGraphicsManager
/*     */   extends WCGraphicsManager
/*     */ {
/*     */   private static final float highestPixelScale;
/*     */   private static final BaseTransform pixelScaleTransform;
/*     */   
/*     */   static {
/*  46 */     float f = 1.0F;
/*  47 */     for (Screen screen : Screen.getScreens()) {
/*  48 */       f = Math.max(screen.getRecommendedOutputScaleX(), f);
/*  49 */       f = Math.max(screen.getRecommendedOutputScaleY(), f);
/*     */     } 
/*  51 */     highestPixelScale = (float)Math.ceil(f);
/*  52 */     pixelScaleTransform = BaseTransform.getScaleInstance(f, f);
/*     */   }
/*     */   
/*     */   static BaseTransform getPixelScaleTransform() {
/*  56 */     return pixelScaleTransform;
/*     */   }
/*     */   
/*     */   public float getDevicePixelScale() {
/*  60 */     return highestPixelScale;
/*     */   }
/*     */   
/*     */   protected WCImageDecoder getImageDecoder() {
/*  64 */     return new WCImageDecoderImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WCRenderQueue createRenderQueue(WCRectangle paramWCRectangle, boolean paramBoolean) {
/*  70 */     return new WCRenderQueueImpl(paramWCRectangle, paramBoolean);
/*     */   }
/*     */   
/*     */   protected WCRenderQueue createBufferedContextRQ(WCImage paramWCImage) {
/*  74 */     WCBufferedContext wCBufferedContext = new WCBufferedContext((PrismImage)paramWCImage);
/*     */ 
/*     */     
/*  77 */     WCRenderQueueImpl wCRenderQueueImpl = new WCRenderQueueImpl(WCGraphicsPerfLogger.isEnabled() ? new WCGraphicsPerfLogger(wCBufferedContext) : wCBufferedContext);
/*  78 */     paramWCImage.setRQ(wCRenderQueueImpl);
/*  79 */     return wCRenderQueueImpl;
/*     */   }
/*     */ 
/*     */   
/*     */   protected WCFont getWCFont(String paramString, boolean paramBoolean1, boolean paramBoolean2, float paramFloat) {
/*  84 */     WCFont wCFont = WCFontImpl.getFont(paramString, paramBoolean1, paramBoolean2, paramFloat);
/*  85 */     return (WCFontPerfLogger.isEnabled() && wCFont != null) ? new WCFontPerfLogger(wCFont) : wCFont;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WCFontCustomPlatformData createFontCustomPlatformData(InputStream paramInputStream) throws IOException {
/*  92 */     return new WCFontCustomPlatformDataImpl(paramInputStream);
/*     */   }
/*     */ 
/*     */   
/*     */   public WCGraphicsContext createGraphicsContext(Object paramObject) {
/*  97 */     WCGraphicsPrismContext wCGraphicsPrismContext = new WCGraphicsPrismContext((Graphics)paramObject);
/*  98 */     return WCGraphicsPerfLogger.isEnabled() ? new WCGraphicsPerfLogger(wCGraphicsPrismContext) : wCGraphicsPrismContext;
/*     */   }
/*     */   
/*     */   public WCPageBackBuffer createPageBackBuffer() {
/* 102 */     return new WCPageBackBufferImpl(highestPixelScale);
/*     */   }
/*     */ 
/*     */   
/*     */   protected WCPath createWCPath() {
/* 107 */     return new WCPathImpl();
/*     */   }
/*     */ 
/*     */   
/*     */   protected WCPath createWCPath(WCPath paramWCPath) {
/* 112 */     return new WCPathImpl((WCPathImpl)paramWCPath);
/*     */   }
/*     */ 
/*     */   
/*     */   protected WCImage createWCImage(int paramInt1, int paramInt2) {
/* 117 */     return new WCImageImpl(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected WCImage createRTImage(int paramInt1, int paramInt2) {
/* 122 */     return new RTImage(paramInt1, paramInt2, highestPixelScale);
/*     */   }
/*     */   
/*     */   public WCImage getIconImage(String paramString) {
/* 126 */     return null;
/*     */   }
/*     */   
/*     */   public Object toPlatformImage(WCImage paramWCImage) {
/* 130 */     return ((WCImageImpl)paramWCImage).getImage();
/*     */   }
/*     */ 
/*     */   
/*     */   protected WCImageFrame createFrame(final int w, final int h, ByteBuffer paramByteBuffer) {
/* 135 */     int[] arrayOfInt = new int[paramByteBuffer.capacity() / 4];
/* 136 */     paramByteBuffer.order(ByteOrder.nativeOrder());
/* 137 */     paramByteBuffer.asIntBuffer().get(arrayOfInt);
/* 138 */     final WCImageImpl wimg = new WCImageImpl(arrayOfInt, w, h);
/*     */     
/* 140 */     return new WCImageFrame() {
/* 141 */         public WCImage getFrame() { return wimg; } public int[] getSize() {
/* 142 */           return new int[] { this.val$w, this.val$h };
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected WCTransform createTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 150 */     return new WCTransform(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String[] getSupportedMediaTypes() {
/* 155 */     String[] arrayOfString = MediaManager.getSupportedContentTypes();
/*     */ 
/*     */ 
/*     */     
/* 159 */     int i = arrayOfString.length;
/* 160 */     for (byte b = 0; b < i; b++) {
/* 161 */       if ("video/x-flv".compareToIgnoreCase(arrayOfString[b]) == 0) {
/* 162 */         System.arraycopy(arrayOfString, b + 1, arrayOfString, b, i - b + 1);
/* 163 */         i--;
/*     */       } 
/*     */     } 
/* 166 */     if (i < arrayOfString.length) {
/* 167 */       String[] arrayOfString1 = new String[i];
/* 168 */       System.arraycopy(arrayOfString, 0, arrayOfString1, 0, i);
/* 169 */       arrayOfString = arrayOfString1;
/*     */     } 
/* 171 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */   
/*     */   protected WCMediaPlayer createMediaPlayer() {
/* 176 */     return new WCMediaPlayerImpl();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\PrismGraphicsManager.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */