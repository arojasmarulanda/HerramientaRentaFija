/*     */ package com.sun.javafx.webkit.prism;
/*     */ 
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.GraphicsPipeline;
/*     */ import com.sun.prism.RTTexture;
/*     */ import com.sun.prism.ResourceFactoryListener;
/*     */ import com.sun.prism.Texture;
/*     */ import com.sun.webkit.graphics.WCCamera;
/*     */ import com.sun.webkit.graphics.WCGraphicsContext;
/*     */ import com.sun.webkit.graphics.WCGraphicsManager;
/*     */ import com.sun.webkit.graphics.WCPageBackBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WCPageBackBufferImpl
/*     */   extends WCPageBackBuffer
/*     */   implements ResourceFactoryListener
/*     */ {
/*     */   private RTTexture texture;
/*     */   private boolean listenerAdded = false;
/*     */   private float pixelScale;
/*     */   
/*     */   WCPageBackBufferImpl(float paramFloat) {
/*  48 */     this.pixelScale = paramFloat;
/*     */   }
/*     */   
/*     */   private static RTTexture createTexture(int paramInt1, int paramInt2) {
/*  52 */     return GraphicsPipeline.getDefaultResourceFactory()
/*  53 */       .createRTTexture(paramInt1, paramInt2, Texture.WrapMode.CLAMP_NOT_NEEDED);
/*     */   }
/*     */   
/*     */   public WCGraphicsContext createGraphics() {
/*  57 */     Graphics graphics = this.texture.createGraphics();
/*     */     
/*  59 */     graphics.setCamera(WCCamera.INSTANCE);
/*  60 */     graphics.scale(this.pixelScale, this.pixelScale);
/*  61 */     return WCGraphicsManager.getGraphicsManager().createGraphicsContext(graphics);
/*     */   }
/*     */   
/*     */   public void disposeGraphics(WCGraphicsContext paramWCGraphicsContext) {
/*  65 */     paramWCGraphicsContext.dispose();
/*     */   }
/*     */   
/*     */   public void flush(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  69 */     int i = paramInt1 + paramInt3;
/*  70 */     int j = paramInt2 + paramInt4;
/*  71 */     ((Graphics)paramWCGraphicsContext.getPlatformGraphics()).drawTexture(this.texture, paramInt1, paramInt2, i, j, paramInt1 * this.pixelScale, paramInt2 * this.pixelScale, i * this.pixelScale, j * this.pixelScale);
/*     */     
/*  73 */     this.texture.unlock();
/*     */   }
/*     */   
/*     */   protected void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  77 */     paramInt1 = (int)(paramInt1 * this.pixelScale);
/*  78 */     paramInt2 = (int)(paramInt2 * this.pixelScale);
/*  79 */     paramInt3 = (int)Math.ceil((paramInt3 * this.pixelScale));
/*  80 */     paramInt4 = (int)Math.ceil((paramInt4 * this.pixelScale));
/*  81 */     paramInt5 = (int)(paramInt5 * this.pixelScale);
/*  82 */     paramInt6 = (int)(paramInt6 * this.pixelScale);
/*  83 */     RTTexture rTTexture = createTexture(paramInt3, paramInt4);
/*  84 */     rTTexture.createGraphics().drawTexture(this.texture, 0.0F, 0.0F, paramInt3, paramInt4, paramInt1, paramInt2, (paramInt1 + paramInt3), (paramInt2 + paramInt4));
/*  85 */     this.texture.createGraphics().drawTexture(rTTexture, (paramInt1 + paramInt5), (paramInt2 + paramInt6), (paramInt1 + paramInt3 + paramInt5), (paramInt2 + paramInt4 + paramInt6), 0.0F, 0.0F, paramInt3, paramInt4);
/*     */     
/*  87 */     rTTexture.dispose();
/*     */   }
/*     */   
/*     */   public boolean validate(int paramInt1, int paramInt2) {
/*  91 */     paramInt1 = (int)Math.ceil((paramInt1 * this.pixelScale));
/*  92 */     paramInt2 = (int)Math.ceil((paramInt2 * this.pixelScale));
/*  93 */     if (this.texture != null) {
/*  94 */       this.texture.lock();
/*  95 */       if (this.texture.isSurfaceLost()) {
/*  96 */         this.texture.dispose();
/*  97 */         this.texture = null;
/*     */       } 
/*     */     } 
/* 100 */     if (this.texture == null) {
/* 101 */       this.texture = createTexture(paramInt1, paramInt2);
/* 102 */       this.texture.contentsUseful();
/* 103 */       if (!this.listenerAdded) {
/*     */ 
/*     */         
/* 106 */         GraphicsPipeline.getDefaultResourceFactory().addFactoryListener(this);
/* 107 */         this.listenerAdded = true;
/*     */       }
/*     */       else {
/*     */         
/* 111 */         this.texture.unlock();
/* 112 */         return false;
/*     */       } 
/*     */     } else {
/* 115 */       int i = this.texture.getContentWidth();
/* 116 */       int j = this.texture.getContentHeight();
/* 117 */       if (i != paramInt1 || j != paramInt2) {
/*     */         
/* 119 */         RTTexture rTTexture = createTexture(paramInt1, paramInt2);
/* 120 */         rTTexture.contentsUseful();
/* 121 */         rTTexture.createGraphics().drawTexture(this.texture, 0.0F, 0.0F, 
/* 122 */             Math.min(paramInt1, i), Math.min(paramInt2, j));
/* 123 */         this.texture.dispose();
/* 124 */         this.texture = rTTexture;
/*     */       } 
/*     */     } 
/* 127 */     return true;
/*     */   }
/*     */   
/*     */   public void factoryReset() {
/* 131 */     if (this.texture != null) {
/* 132 */       this.texture.dispose();
/* 133 */       this.texture = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void factoryReleased() {}
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCPageBackBufferImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */