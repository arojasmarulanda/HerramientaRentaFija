/*     */ package com.sun.javafx.webkit;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javafx.scene.input.KeyCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class KeyCodeMap
/*     */ {
/*     */   private static final Map<KeyCode, Entry> MAP;
/*     */   
/*     */   public static final class Entry
/*     */   {
/*     */     private final int windowsVirtualKeyCode;
/*     */     private final String keyIdentifier;
/*     */     
/*     */     private Entry(int param1Int, String param1String) {
/*  53 */       this.windowsVirtualKeyCode = param1Int;
/*  54 */       this.keyIdentifier = param1String;
/*     */     }
/*     */     
/*     */     public int getWindowsVirtualKeyCode() {
/*  58 */       return this.windowsVirtualKeyCode;
/*     */     }
/*     */     
/*     */     public String getKeyIdentifier() {
/*  62 */       return this.keyIdentifier;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  69 */     HashMap<Object, Object> hashMap = new HashMap<>();
/*     */     
/*  71 */     put((Map)hashMap, KeyCode.ENTER, 13, "Enter");
/*  72 */     put((Map)hashMap, KeyCode.BACK_SPACE, 8);
/*  73 */     put((Map)hashMap, KeyCode.TAB, 9);
/*  74 */     put((Map)hashMap, KeyCode.CANCEL, 3);
/*  75 */     put((Map)hashMap, KeyCode.CLEAR, 12, "Clear");
/*  76 */     put((Map)hashMap, KeyCode.SHIFT, 16, "Shift");
/*  77 */     put((Map)hashMap, KeyCode.CONTROL, 17, "Control");
/*  78 */     put((Map)hashMap, KeyCode.ALT, 18, "Alt");
/*  79 */     put((Map)hashMap, KeyCode.PAUSE, 19, "Pause");
/*  80 */     put((Map)hashMap, KeyCode.CAPS, 20, "CapsLock");
/*  81 */     put((Map)hashMap, KeyCode.ESCAPE, 27);
/*  82 */     put((Map)hashMap, KeyCode.SPACE, 32);
/*  83 */     put((Map)hashMap, KeyCode.PAGE_UP, 33, "PageUp");
/*  84 */     put((Map)hashMap, KeyCode.PAGE_DOWN, 34, "PageDown");
/*  85 */     put((Map)hashMap, KeyCode.END, 35, "End");
/*  86 */     put((Map)hashMap, KeyCode.HOME, 36, "Home");
/*  87 */     put((Map)hashMap, KeyCode.LEFT, 37, "Left");
/*  88 */     put((Map)hashMap, KeyCode.UP, 38, "Up");
/*  89 */     put((Map)hashMap, KeyCode.RIGHT, 39, "Right");
/*  90 */     put((Map)hashMap, KeyCode.DOWN, 40, "Down");
/*  91 */     put((Map)hashMap, KeyCode.COMMA, 188);
/*  92 */     put((Map)hashMap, KeyCode.MINUS, 189);
/*  93 */     put((Map)hashMap, KeyCode.PERIOD, 190);
/*  94 */     put((Map)hashMap, KeyCode.SLASH, 191);
/*  95 */     put((Map)hashMap, KeyCode.DIGIT0, 48);
/*  96 */     put((Map)hashMap, KeyCode.DIGIT1, 49);
/*  97 */     put((Map)hashMap, KeyCode.DIGIT2, 50);
/*  98 */     put((Map)hashMap, KeyCode.DIGIT3, 51);
/*  99 */     put((Map)hashMap, KeyCode.DIGIT4, 52);
/* 100 */     put((Map)hashMap, KeyCode.DIGIT5, 53);
/* 101 */     put((Map)hashMap, KeyCode.DIGIT6, 54);
/* 102 */     put((Map)hashMap, KeyCode.DIGIT7, 55);
/* 103 */     put((Map)hashMap, KeyCode.DIGIT8, 56);
/* 104 */     put((Map)hashMap, KeyCode.DIGIT9, 57);
/* 105 */     put((Map)hashMap, KeyCode.SEMICOLON, 186);
/* 106 */     put((Map)hashMap, KeyCode.EQUALS, 187);
/* 107 */     put((Map)hashMap, KeyCode.A, 65);
/* 108 */     put((Map)hashMap, KeyCode.B, 66);
/* 109 */     put((Map)hashMap, KeyCode.C, 67);
/* 110 */     put((Map)hashMap, KeyCode.D, 68);
/* 111 */     put((Map)hashMap, KeyCode.E, 69);
/* 112 */     put((Map)hashMap, KeyCode.F, 70);
/* 113 */     put((Map)hashMap, KeyCode.G, 71);
/* 114 */     put((Map)hashMap, KeyCode.H, 72);
/* 115 */     put((Map)hashMap, KeyCode.I, 73);
/* 116 */     put((Map)hashMap, KeyCode.J, 74);
/* 117 */     put((Map)hashMap, KeyCode.K, 75);
/* 118 */     put((Map)hashMap, KeyCode.L, 76);
/* 119 */     put((Map)hashMap, KeyCode.M, 77);
/* 120 */     put((Map)hashMap, KeyCode.N, 78);
/* 121 */     put((Map)hashMap, KeyCode.O, 79);
/* 122 */     put((Map)hashMap, KeyCode.P, 80);
/* 123 */     put((Map)hashMap, KeyCode.Q, 81);
/* 124 */     put((Map)hashMap, KeyCode.R, 82);
/* 125 */     put((Map)hashMap, KeyCode.S, 83);
/* 126 */     put((Map)hashMap, KeyCode.T, 84);
/* 127 */     put((Map)hashMap, KeyCode.U, 85);
/* 128 */     put((Map)hashMap, KeyCode.V, 86);
/* 129 */     put((Map)hashMap, KeyCode.W, 87);
/* 130 */     put((Map)hashMap, KeyCode.X, 88);
/* 131 */     put((Map)hashMap, KeyCode.Y, 89);
/* 132 */     put((Map)hashMap, KeyCode.Z, 90);
/* 133 */     put((Map)hashMap, KeyCode.OPEN_BRACKET, 219);
/* 134 */     put((Map)hashMap, KeyCode.BACK_SLASH, 220);
/* 135 */     put((Map)hashMap, KeyCode.CLOSE_BRACKET, 221);
/* 136 */     put((Map)hashMap, KeyCode.NUMPAD0, 96);
/* 137 */     put((Map)hashMap, KeyCode.NUMPAD1, 97);
/* 138 */     put((Map)hashMap, KeyCode.NUMPAD2, 98);
/* 139 */     put((Map)hashMap, KeyCode.NUMPAD3, 99);
/* 140 */     put((Map)hashMap, KeyCode.NUMPAD4, 100);
/* 141 */     put((Map)hashMap, KeyCode.NUMPAD5, 101);
/* 142 */     put((Map)hashMap, KeyCode.NUMPAD6, 102);
/* 143 */     put((Map)hashMap, KeyCode.NUMPAD7, 103);
/* 144 */     put((Map)hashMap, KeyCode.NUMPAD8, 104);
/* 145 */     put((Map)hashMap, KeyCode.NUMPAD9, 105);
/* 146 */     put((Map)hashMap, KeyCode.MULTIPLY, 106);
/* 147 */     put((Map)hashMap, KeyCode.ADD, 107);
/* 148 */     put((Map)hashMap, KeyCode.SEPARATOR, 108);
/* 149 */     put((Map)hashMap, KeyCode.SUBTRACT, 109);
/* 150 */     put((Map)hashMap, KeyCode.DECIMAL, 110);
/* 151 */     put((Map)hashMap, KeyCode.DIVIDE, 111);
/* 152 */     put((Map)hashMap, KeyCode.DELETE, 46, "U+007F");
/* 153 */     put((Map)hashMap, KeyCode.NUM_LOCK, 144);
/* 154 */     put((Map)hashMap, KeyCode.SCROLL_LOCK, 145, "Scroll");
/* 155 */     put((Map)hashMap, KeyCode.F1, 112, "F1");
/* 156 */     put((Map)hashMap, KeyCode.F2, 113, "F2");
/* 157 */     put((Map)hashMap, KeyCode.F3, 114, "F3");
/* 158 */     put((Map)hashMap, KeyCode.F4, 115, "F4");
/* 159 */     put((Map)hashMap, KeyCode.F5, 116, "F5");
/* 160 */     put((Map)hashMap, KeyCode.F6, 117, "F6");
/* 161 */     put((Map)hashMap, KeyCode.F7, 118, "F7");
/* 162 */     put((Map)hashMap, KeyCode.F8, 119, "F8");
/* 163 */     put((Map)hashMap, KeyCode.F9, 120, "F9");
/* 164 */     put((Map)hashMap, KeyCode.F10, 121, "F10");
/* 165 */     put((Map)hashMap, KeyCode.F11, 122, "F11");
/* 166 */     put((Map)hashMap, KeyCode.F12, 123, "F12");
/* 167 */     put((Map)hashMap, KeyCode.F13, 124, "F13");
/* 168 */     put((Map)hashMap, KeyCode.F14, 125, "F14");
/* 169 */     put((Map)hashMap, KeyCode.F15, 126, "F15");
/* 170 */     put((Map)hashMap, KeyCode.F16, 127, "F16");
/* 171 */     put((Map)hashMap, KeyCode.F17, 128, "F17");
/* 172 */     put((Map)hashMap, KeyCode.F18, 129, "F18");
/* 173 */     put((Map)hashMap, KeyCode.F19, 130, "F19");
/* 174 */     put((Map)hashMap, KeyCode.F20, 131, "F20");
/* 175 */     put((Map)hashMap, KeyCode.F21, 132, "F21");
/* 176 */     put((Map)hashMap, KeyCode.F22, 133, "F22");
/* 177 */     put((Map)hashMap, KeyCode.F23, 134, "F23");
/* 178 */     put((Map)hashMap, KeyCode.F24, 135, "F24");
/* 179 */     put((Map)hashMap, KeyCode.PRINTSCREEN, 44, "PrintScreen");
/* 180 */     put((Map)hashMap, KeyCode.INSERT, 45, "Insert");
/* 181 */     put((Map)hashMap, KeyCode.HELP, 47, "Help");
/* 182 */     put((Map)hashMap, KeyCode.META, 0, "Meta");
/* 183 */     put((Map)hashMap, KeyCode.BACK_QUOTE, 192);
/* 184 */     put((Map)hashMap, KeyCode.QUOTE, 222);
/* 185 */     put((Map)hashMap, KeyCode.KP_UP, 38, "Up");
/* 186 */     put((Map)hashMap, KeyCode.KP_DOWN, 40, "Down");
/* 187 */     put((Map)hashMap, KeyCode.KP_LEFT, 37, "Left");
/* 188 */     put((Map)hashMap, KeyCode.KP_RIGHT, 39, "Right");
/* 189 */     put((Map)hashMap, KeyCode.AMPERSAND, 55);
/* 190 */     put((Map)hashMap, KeyCode.ASTERISK, 56);
/* 191 */     put((Map)hashMap, KeyCode.QUOTEDBL, 222);
/* 192 */     put((Map)hashMap, KeyCode.LESS, 188);
/* 193 */     put((Map)hashMap, KeyCode.GREATER, 190);
/* 194 */     put((Map)hashMap, KeyCode.BRACELEFT, 219);
/* 195 */     put((Map)hashMap, KeyCode.BRACERIGHT, 221);
/* 196 */     put((Map)hashMap, KeyCode.AT, 50);
/* 197 */     put((Map)hashMap, KeyCode.COLON, 186);
/* 198 */     put((Map)hashMap, KeyCode.CIRCUMFLEX, 54);
/* 199 */     put((Map)hashMap, KeyCode.DOLLAR, 52);
/* 200 */     put((Map)hashMap, KeyCode.EXCLAMATION_MARK, 49);
/* 201 */     put((Map)hashMap, KeyCode.LEFT_PARENTHESIS, 57);
/* 202 */     put((Map)hashMap, KeyCode.NUMBER_SIGN, 51);
/* 203 */     put((Map)hashMap, KeyCode.PLUS, 187);
/* 204 */     put((Map)hashMap, KeyCode.RIGHT_PARENTHESIS, 48);
/* 205 */     put((Map)hashMap, KeyCode.UNDERSCORE, 189);
/* 206 */     put((Map)hashMap, KeyCode.WINDOWS, 91, "Win");
/* 207 */     put((Map)hashMap, KeyCode.CONTEXT_MENU, 93);
/* 208 */     put((Map)hashMap, KeyCode.FINAL, 24);
/* 209 */     put((Map)hashMap, KeyCode.CONVERT, 28);
/* 210 */     put((Map)hashMap, KeyCode.NONCONVERT, 29);
/* 211 */     put((Map)hashMap, KeyCode.ACCEPT, 30);
/* 212 */     put((Map)hashMap, KeyCode.MODECHANGE, 31);
/* 213 */     put((Map)hashMap, KeyCode.KANA, 21);
/* 214 */     put((Map)hashMap, KeyCode.KANJI, 25);
/* 215 */     put((Map)hashMap, KeyCode.ALT_GRAPH, 165);
/* 216 */     put((Map)hashMap, KeyCode.PLAY, 250);
/* 217 */     put((Map)hashMap, KeyCode.TRACK_PREV, 177);
/* 218 */     put((Map)hashMap, KeyCode.TRACK_NEXT, 176);
/* 219 */     put((Map)hashMap, KeyCode.VOLUME_UP, 175);
/* 220 */     put((Map)hashMap, KeyCode.VOLUME_DOWN, 174);
/* 221 */     put((Map)hashMap, KeyCode.MUTE, 173);
/*     */     
/* 223 */     MAP = Collections.unmodifiableMap(hashMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void put(Map<KeyCode, Entry> paramMap, KeyCode paramKeyCode, int paramInt, String paramString) {
/* 230 */     paramMap.put(paramKeyCode, new Entry(paramInt, paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void put(Map<KeyCode, Entry> paramMap, KeyCode paramKeyCode, int paramInt) {
/* 236 */     put(paramMap, paramKeyCode, paramInt, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Entry lookup(KeyCode paramKeyCode) {
/* 245 */     Entry entry = MAP.get(paramKeyCode);
/* 246 */     if (entry == null || entry.getKeyIdentifier() == null) {
/*     */       
/* 248 */       boolean bool = (entry != null) ? entry.getWindowsVirtualKeyCode() : false;
/*     */       
/* 250 */       String str = String.format("U+%04X", new Object[] { Integer.valueOf(bool) });
/* 251 */       entry = new Entry(bool, str);
/*     */     } 
/* 253 */     return entry;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\KeyCodeMap.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */