/*    */ package com.sun.javafx.webkit;
/*    */ 
/*    */ import com.sun.javafx.webkit.theme.ContextMenuImpl;
/*    */ import com.sun.javafx.webkit.theme.PopupMenuImpl;
/*    */ import com.sun.webkit.ContextMenu;
/*    */ import com.sun.webkit.Pasteboard;
/*    */ import com.sun.webkit.PopupMenu;
/*    */ import com.sun.webkit.Utilities;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UtilitiesImpl
/*    */   extends Utilities
/*    */ {
/*    */   protected Pasteboard createPasteboard() {
/* 39 */     return new PasteboardImpl();
/*    */   }
/*    */   
/*    */   protected PopupMenu createPopupMenu() {
/* 43 */     return new PopupMenuImpl();
/*    */   }
/*    */   
/*    */   protected ContextMenu createContextMenu() {
/* 47 */     return new ContextMenuImpl();
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\webkit\UtilitiesImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */