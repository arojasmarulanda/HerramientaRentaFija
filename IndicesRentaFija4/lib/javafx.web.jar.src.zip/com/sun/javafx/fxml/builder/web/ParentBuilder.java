/*    */ package com.sun.javafx.fxml.builder.web;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import javafx.scene.Parent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class ParentBuilder<B extends ParentBuilder<B>>
/*    */   extends NodeBuilder<B>
/*    */ {
/*    */   private int __set;
/*    */   private Collection<? extends String> stylesheets;
/*    */   
/*    */   public void applyTo(Parent paramParent) {
/* 44 */     applyTo(paramParent);
/* 45 */     int i = this.__set;
/* 46 */     if ((i & 0x2) != 0) paramParent.getStylesheets().addAll(this.stylesheets);
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public B stylesheets(Collection<? extends String> paramCollection) {
/* 56 */     this.stylesheets = paramCollection;
/* 57 */     this.__set |= 0x2;
/* 58 */     return (B)this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public B stylesheets(String... paramVarArgs) {
/* 66 */     return stylesheets(Arrays.asList(paramVarArgs));
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\fxml\builder\web\ParentBuilder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */