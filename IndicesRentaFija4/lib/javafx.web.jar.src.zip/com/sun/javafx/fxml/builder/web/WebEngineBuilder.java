/*     */ package com.sun.javafx.fxml.builder.web;
/*     */ 
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Rectangle2D;
/*     */ import javafx.scene.web.PopupFeatures;
/*     */ import javafx.scene.web.PromptData;
/*     */ import javafx.scene.web.WebEngine;
/*     */ import javafx.scene.web.WebEvent;
/*     */ import javafx.util.Builder;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class WebEngineBuilder
/*     */   implements Builder<WebEngine>
/*     */ {
/*     */   private Callback<String, Boolean> confirmHandler;
/*     */   private boolean confirmHandlerSet;
/*     */   private Callback<PopupFeatures, WebEngine> createPopupHandler;
/*     */   private boolean createPopupHandlerSet;
/*     */   private EventHandler<WebEvent<String>> onAlert;
/*     */   private boolean onAlertSet;
/*     */   private EventHandler<WebEvent<Rectangle2D>> onResized;
/*     */   private boolean onResizedSet;
/*     */   private EventHandler<WebEvent<String>> onStatusChanged;
/*     */   private boolean onStatusChangedSet;
/*     */   private EventHandler<WebEvent<Boolean>> onVisibilityChanged;
/*     */   private boolean onVisibilityChangedSet;
/*     */   private Callback<PromptData, String> promptHandler;
/*     */   private boolean promptHandlerSet;
/*     */   private String location;
/*     */   private boolean locationSet;
/*     */   
/*     */   public static WebEngineBuilder create() {
/*  56 */     return new WebEngineBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebEngine build() {
/*  64 */     WebEngine webEngine = new WebEngine();
/*  65 */     applyTo(webEngine);
/*  66 */     return webEngine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTo(WebEngine paramWebEngine) {
/*  75 */     if (this.confirmHandlerSet) {
/*  76 */       paramWebEngine.setConfirmHandler(this.confirmHandler);
/*     */     }
/*  78 */     if (this.createPopupHandlerSet) {
/*  79 */       paramWebEngine.setCreatePopupHandler(this.createPopupHandler);
/*     */     }
/*  81 */     if (this.onAlertSet) {
/*  82 */       paramWebEngine.setOnAlert(this.onAlert);
/*     */     }
/*  84 */     if (this.onResizedSet) {
/*  85 */       paramWebEngine.setOnResized(this.onResized);
/*     */     }
/*  87 */     if (this.onStatusChangedSet) {
/*  88 */       paramWebEngine.setOnStatusChanged(this.onStatusChanged);
/*     */     }
/*  90 */     if (this.onVisibilityChangedSet) {
/*  91 */       paramWebEngine.setOnVisibilityChanged(this.onVisibilityChanged);
/*     */     }
/*  93 */     if (this.promptHandlerSet) {
/*  94 */       paramWebEngine.setPromptHandler(this.promptHandler);
/*     */     }
/*  96 */     if (this.locationSet) {
/*  97 */       paramWebEngine.load(this.location);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebEngineBuilder confirmHandler(Callback<String, Boolean> paramCallback) {
/* 109 */     this.confirmHandler = paramCallback;
/* 110 */     this.confirmHandlerSet = true;
/* 111 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebEngineBuilder createPopupHandler(Callback<PopupFeatures, WebEngine> paramCallback) {
/* 125 */     this.createPopupHandler = paramCallback;
/* 126 */     this.createPopupHandlerSet = true;
/* 127 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebEngineBuilder onAlert(EventHandler<WebEvent<String>> paramEventHandler) {
/* 141 */     this.onAlert = paramEventHandler;
/* 142 */     this.onAlertSet = true;
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebEngineBuilder onResized(EventHandler<WebEvent<Rectangle2D>> paramEventHandler) {
/* 157 */     this.onResized = paramEventHandler;
/* 158 */     this.onResizedSet = true;
/* 159 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebEngineBuilder onStatusChanged(EventHandler<WebEvent<String>> paramEventHandler) {
/* 173 */     this.onStatusChanged = paramEventHandler;
/* 174 */     this.onStatusChangedSet = true;
/* 175 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebEngineBuilder onVisibilityChanged(EventHandler<WebEvent<Boolean>> paramEventHandler) {
/* 189 */     this.onVisibilityChanged = paramEventHandler;
/* 190 */     this.onVisibilityChangedSet = true;
/* 191 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebEngineBuilder promptHandler(Callback<PromptData, String> paramCallback) {
/* 205 */     this.promptHandler = paramCallback;
/* 206 */     this.promptHandlerSet = true;
/* 207 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebEngineBuilder location(String paramString) {
/* 222 */     this.location = paramString;
/* 223 */     this.locationSet = true;
/* 224 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\fxml\builder\web\WebEngineBuilder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */