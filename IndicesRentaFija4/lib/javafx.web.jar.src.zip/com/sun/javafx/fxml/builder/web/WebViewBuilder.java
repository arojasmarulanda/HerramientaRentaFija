/*     */ package com.sun.javafx.fxml.builder.web;
/*     */ 
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.geometry.Rectangle2D;
/*     */ import javafx.scene.web.PopupFeatures;
/*     */ import javafx.scene.web.PromptData;
/*     */ import javafx.scene.web.WebEngine;
/*     */ import javafx.scene.web.WebEvent;
/*     */ import javafx.scene.web.WebView;
/*     */ import javafx.util.Builder;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class WebViewBuilder
/*     */   extends ParentBuilder<WebViewBuilder>
/*     */   implements Builder<WebView>
/*     */ {
/*     */   private double fontScale;
/*     */   private boolean fontScaleSet;
/*     */   private double maxHeight;
/*     */   private boolean maxHeightSet;
/*     */   private double maxWidth;
/*     */   private boolean maxWidthSet;
/*     */   private double minHeight;
/*     */   private boolean minHeightSet;
/*     */   private double minWidth;
/*     */   private boolean minWidthSet;
/*     */   private double prefHeight;
/*     */   private boolean prefHeightSet;
/*     */   private double prefWidth;
/*     */   private boolean prefWidthSet;
/*     */   private WebEngineBuilder engineBuilder;
/*     */   
/*     */   public static WebViewBuilder create() {
/*  58 */     return new WebViewBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebView build() {
/*  66 */     WebView webView = new WebView();
/*  67 */     applyTo(webView);
/*  68 */     return webView;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTo(WebView paramWebView) {
/*  77 */     applyTo(paramWebView);
/*  78 */     if (this.fontScaleSet) {
/*  79 */       paramWebView.setFontScale(this.fontScale);
/*     */     }
/*  81 */     if (this.maxHeightSet) {
/*  82 */       paramWebView.setMaxHeight(this.maxHeight);
/*     */     }
/*  84 */     if (this.maxWidthSet) {
/*  85 */       paramWebView.setMaxWidth(this.maxWidth);
/*     */     }
/*  87 */     if (this.minHeightSet) {
/*  88 */       paramWebView.setMinHeight(this.minHeight);
/*     */     }
/*  90 */     if (this.minWidthSet) {
/*  91 */       paramWebView.setMinWidth(this.minWidth);
/*     */     }
/*  93 */     if (this.prefHeightSet) {
/*  94 */       paramWebView.setPrefHeight(this.prefHeight);
/*     */     }
/*  96 */     if (this.prefWidthSet) {
/*  97 */       paramWebView.setPrefWidth(this.prefWidth);
/*     */     }
/*  99 */     if (this.engineBuilder != null) {
/* 100 */       this.engineBuilder.applyTo(paramWebView.getEngine());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder fontScale(double paramDouble) {
/* 112 */     this.fontScale = paramDouble;
/* 113 */     this.fontScaleSet = true;
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder maxHeight(double paramDouble) {
/* 128 */     this.maxHeight = paramDouble;
/* 129 */     this.maxHeightSet = true;
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder maxWidth(double paramDouble) {
/* 144 */     this.maxWidth = paramDouble;
/* 145 */     this.maxWidthSet = true;
/* 146 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder minHeight(double paramDouble) {
/* 160 */     this.minHeight = paramDouble;
/* 161 */     this.minHeightSet = true;
/* 162 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder minWidth(double paramDouble) {
/* 176 */     this.minWidth = paramDouble;
/* 177 */     this.minWidthSet = true;
/* 178 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder prefHeight(double paramDouble) {
/* 192 */     this.prefHeight = paramDouble;
/* 193 */     this.prefHeightSet = true;
/* 194 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder prefWidth(double paramDouble) {
/* 208 */     this.prefWidth = paramDouble;
/* 209 */     this.prefWidthSet = true;
/* 210 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder confirmHandler(Callback<String, Boolean> paramCallback) {
/* 226 */     engineBuilder().confirmHandler(paramCallback);
/* 227 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder createPopupHandler(Callback<PopupFeatures, WebEngine> paramCallback) {
/* 240 */     engineBuilder().createPopupHandler(paramCallback);
/* 241 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder onAlert(EventHandler<WebEvent<String>> paramEventHandler) {
/* 254 */     engineBuilder().onAlert(paramEventHandler);
/* 255 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder onResized(EventHandler<WebEvent<Rectangle2D>> paramEventHandler) {
/* 268 */     engineBuilder().onResized(paramEventHandler);
/* 269 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder onStatusChanged(EventHandler<WebEvent<String>> paramEventHandler) {
/* 282 */     engineBuilder().onStatusChanged(paramEventHandler);
/* 283 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder onVisibilityChanged(EventHandler<WebEvent<Boolean>> paramEventHandler) {
/* 296 */     engineBuilder().onVisibilityChanged(paramEventHandler);
/* 297 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder promptHandler(Callback<PromptData, String> paramCallback) {
/* 310 */     engineBuilder().promptHandler(paramCallback);
/* 311 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebViewBuilder location(String paramString) {
/* 324 */     engineBuilder().location(paramString);
/* 325 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private WebEngineBuilder engineBuilder() {
/* 331 */     if (this.engineBuilder == null) {
/* 332 */       this.engineBuilder = WebEngineBuilder.create();
/*     */     }
/* 334 */     return this.engineBuilder;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\fxml\builder\web\WebViewBuilder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */