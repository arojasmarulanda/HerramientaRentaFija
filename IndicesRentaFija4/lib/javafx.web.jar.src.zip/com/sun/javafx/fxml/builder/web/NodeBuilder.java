/*     */ package com.sun.javafx.fxml.builder.web;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class NodeBuilder<B extends NodeBuilder<B>> {
/*     */   private BlendMode blendMode;
/*     */   private boolean cache;
/*     */   private CacheHint cacheHint;
/*     */   private Node clip;
/*     */   private Cursor cursor;
/*     */   private DepthTest depthTest;
/*     */   private boolean disable;
/*     */   private Effect effect;
/*     */   private EventDispatcher eventDispatcher;
/*     */   private boolean focusTraversable;
/*     */   private String id;
/*     */   private InputMethodRequests inputMethodRequests;
/*     */   private double layoutX;
/*     */   private double layoutY;
/*     */   private boolean managed;
/*     */   private boolean mouseTransparent;
/*     */   private EventHandler<? super ContextMenuEvent> onContextMenuRequested;
/*     */   private EventHandler<? super MouseEvent> onDragDetected;
/*     */   private EventHandler<? super DragEvent> onDragDone;
/*     */   private EventHandler<? super DragEvent> onDragDropped;
/*     */   private EventHandler<? super DragEvent> onDragEntered;
/*     */   private EventHandler<? super DragEvent> onDragExited;
/*     */   private EventHandler<? super DragEvent> onDragOver;
/*     */   private EventHandler<? super InputMethodEvent> onInputMethodTextChanged;
/*     */   private EventHandler<? super KeyEvent> onKeyPressed;
/*     */   private EventHandler<? super KeyEvent> onKeyReleased;
/*     */   private EventHandler<? super KeyEvent> onKeyTyped;
/*     */   private EventHandler<? super MouseEvent> onMouseClicked;
/*     */   private EventHandler<? super MouseDragEvent> onMouseDragEntered;
/*     */   private EventHandler<? super MouseDragEvent> onMouseDragExited;
/*     */   private EventHandler<? super MouseEvent> onMouseDragged;
/*     */   private EventHandler<? super MouseDragEvent> onMouseDragOver;
/*     */   private EventHandler<? super MouseDragEvent> onMouseDragReleased;
/*     */   private EventHandler<? super MouseEvent> onMouseEntered;
/*     */   private EventHandler<? super MouseEvent> onMouseExited;
/*  42 */   BitSet __set = new BitSet(); private EventHandler<? super MouseEvent> onMouseMoved; private EventHandler<? super MouseEvent> onMousePressed; private EventHandler<? super MouseEvent> onMouseReleased; private EventHandler<? super RotateEvent> onRotate; private EventHandler<? super RotateEvent> onRotationFinished; private EventHandler<? super RotateEvent> onRotationStarted; private EventHandler<? super ScrollEvent> onScroll; private EventHandler<? super ScrollEvent> onScrollFinished; private EventHandler<? super ScrollEvent> onScrollStarted; private EventHandler<? super SwipeEvent> onSwipeDown; private EventHandler<? super SwipeEvent> onSwipeLeft; private EventHandler<? super SwipeEvent> onSwipeRight; private EventHandler<? super SwipeEvent> onSwipeUp; private EventHandler<? super TouchEvent> onTouchMoved; private EventHandler<? super TouchEvent> onTouchPressed; private EventHandler<? super TouchEvent> onTouchReleased; private EventHandler<? super TouchEvent> onTouchStationary;
/*     */   private void __set(int paramInt) {
/*  44 */     this.__set.set(paramInt);
/*     */   } private EventHandler<? super ZoomEvent> onZoom; private EventHandler<? super ZoomEvent> onZoomFinished; private EventHandler<? super ZoomEvent> onZoomStarted; private double opacity; private boolean pickOnBounds; private double rotate; private Point3D rotationAxis; private double scaleX; private double scaleY; private double scaleZ; private String style; private Collection<? extends String> styleClass; private Collection<? extends Transform> transforms; private double translateX; private double translateY; private double translateZ; private Object userData; private boolean visible;
/*     */   public void applyTo(Node paramNode) {
/*  47 */     BitSet bitSet = this.__set;
/*  48 */     for (int i = -1; (i = bitSet.nextSetBit(i + 1)) >= 0;) {
/*  49 */       switch (i) { case 0:
/*  50 */           paramNode.setBlendMode(this.blendMode);
/*  51 */         case 1: paramNode.setCache(this.cache);
/*  52 */         case 2: paramNode.setCacheHint(this.cacheHint);
/*  53 */         case 3: paramNode.setClip(this.clip);
/*  54 */         case 4: paramNode.setCursor(this.cursor);
/*  55 */         case 5: paramNode.setDepthTest(this.depthTest);
/*  56 */         case 6: paramNode.setDisable(this.disable);
/*  57 */         case 7: paramNode.setEffect(this.effect);
/*  58 */         case 8: paramNode.setEventDispatcher(this.eventDispatcher);
/*  59 */         case 9: paramNode.setFocusTraversable(this.focusTraversable);
/*  60 */         case 10: paramNode.setId(this.id);
/*  61 */         case 11: paramNode.setInputMethodRequests(this.inputMethodRequests);
/*  62 */         case 12: paramNode.setLayoutX(this.layoutX);
/*  63 */         case 13: paramNode.setLayoutY(this.layoutY);
/*  64 */         case 14: paramNode.setManaged(this.managed);
/*  65 */         case 15: paramNode.setMouseTransparent(this.mouseTransparent);
/*  66 */         case 16: paramNode.setOnContextMenuRequested(this.onContextMenuRequested);
/*  67 */         case 17: paramNode.setOnDragDetected(this.onDragDetected);
/*  68 */         case 18: paramNode.setOnDragDone(this.onDragDone);
/*  69 */         case 19: paramNode.setOnDragDropped(this.onDragDropped);
/*  70 */         case 20: paramNode.setOnDragEntered(this.onDragEntered);
/*  71 */         case 21: paramNode.setOnDragExited(this.onDragExited);
/*  72 */         case 22: paramNode.setOnDragOver(this.onDragOver);
/*  73 */         case 23: paramNode.setOnInputMethodTextChanged(this.onInputMethodTextChanged);
/*  74 */         case 24: paramNode.setOnKeyPressed(this.onKeyPressed);
/*  75 */         case 25: paramNode.setOnKeyReleased(this.onKeyReleased);
/*  76 */         case 26: paramNode.setOnKeyTyped(this.onKeyTyped);
/*  77 */         case 27: paramNode.setOnMouseClicked(this.onMouseClicked);
/*  78 */         case 28: paramNode.setOnMouseDragEntered(this.onMouseDragEntered);
/*  79 */         case 29: paramNode.setOnMouseDragExited(this.onMouseDragExited);
/*  80 */         case 30: paramNode.setOnMouseDragged(this.onMouseDragged);
/*  81 */         case 31: paramNode.setOnMouseDragOver(this.onMouseDragOver);
/*  82 */         case 32: paramNode.setOnMouseDragReleased(this.onMouseDragReleased);
/*  83 */         case 33: paramNode.setOnMouseEntered(this.onMouseEntered);
/*  84 */         case 34: paramNode.setOnMouseExited(this.onMouseExited);
/*  85 */         case 35: paramNode.setOnMouseMoved(this.onMouseMoved);
/*  86 */         case 36: paramNode.setOnMousePressed(this.onMousePressed);
/*  87 */         case 37: paramNode.setOnMouseReleased(this.onMouseReleased);
/*  88 */         case 38: paramNode.setOnRotate(this.onRotate);
/*  89 */         case 39: paramNode.setOnRotationFinished(this.onRotationFinished);
/*  90 */         case 40: paramNode.setOnRotationStarted(this.onRotationStarted);
/*  91 */         case 41: paramNode.setOnScroll(this.onScroll);
/*  92 */         case 42: paramNode.setOnScrollFinished(this.onScrollFinished);
/*  93 */         case 43: paramNode.setOnScrollStarted(this.onScrollStarted);
/*  94 */         case 44: paramNode.setOnSwipeDown(this.onSwipeDown);
/*  95 */         case 45: paramNode.setOnSwipeLeft(this.onSwipeLeft);
/*  96 */         case 46: paramNode.setOnSwipeRight(this.onSwipeRight);
/*  97 */         case 47: paramNode.setOnSwipeUp(this.onSwipeUp);
/*  98 */         case 48: paramNode.setOnTouchMoved(this.onTouchMoved);
/*  99 */         case 49: paramNode.setOnTouchPressed(this.onTouchPressed);
/* 100 */         case 50: paramNode.setOnTouchReleased(this.onTouchReleased);
/* 101 */         case 51: paramNode.setOnTouchStationary(this.onTouchStationary);
/* 102 */         case 52: paramNode.setOnZoom(this.onZoom);
/* 103 */         case 53: paramNode.setOnZoomFinished(this.onZoomFinished);
/* 104 */         case 54: paramNode.setOnZoomStarted(this.onZoomStarted);
/* 105 */         case 55: paramNode.setOpacity(this.opacity);
/* 106 */         case 56: paramNode.setPickOnBounds(this.pickOnBounds);
/* 107 */         case 57: paramNode.setRotate(this.rotate);
/* 108 */         case 58: paramNode.setRotationAxis(this.rotationAxis);
/* 109 */         case 59: paramNode.setScaleX(this.scaleX);
/* 110 */         case 60: paramNode.setScaleY(this.scaleY);
/* 111 */         case 61: paramNode.setScaleZ(this.scaleZ);
/* 112 */         case 62: paramNode.setStyle(this.style);
/* 113 */         case 63: paramNode.getStyleClass().addAll(this.styleClass);
/* 114 */         case 64: paramNode.getTransforms().addAll(this.transforms);
/* 115 */         case 65: paramNode.setTranslateX(this.translateX);
/* 116 */         case 66: paramNode.setTranslateY(this.translateY);
/* 117 */         case 67: paramNode.setTranslateZ(this.translateZ);
/* 118 */         case 68: paramNode.setUserData(this.userData);
/* 119 */         case 69: paramNode.setVisible(this.visible); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B blendMode(BlendMode paramBlendMode) {
/* 130 */     this.blendMode = paramBlendMode;
/* 131 */     __set(0);
/* 132 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B cache(boolean paramBoolean) {
/* 141 */     this.cache = paramBoolean;
/* 142 */     __set(1);
/* 143 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B cacheHint(CacheHint paramCacheHint) {
/* 152 */     this.cacheHint = paramCacheHint;
/* 153 */     __set(2);
/* 154 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B clip(Node paramNode) {
/* 163 */     this.clip = paramNode;
/* 164 */     __set(3);
/* 165 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B cursor(Cursor paramCursor) {
/* 174 */     this.cursor = paramCursor;
/* 175 */     __set(4);
/* 176 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B depthTest(DepthTest paramDepthTest) {
/* 185 */     this.depthTest = paramDepthTest;
/* 186 */     __set(5);
/* 187 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B disable(boolean paramBoolean) {
/* 196 */     this.disable = paramBoolean;
/* 197 */     __set(6);
/* 198 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B effect(Effect paramEffect) {
/* 207 */     this.effect = paramEffect;
/* 208 */     __set(7);
/* 209 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B eventDispatcher(EventDispatcher paramEventDispatcher) {
/* 218 */     this.eventDispatcher = paramEventDispatcher;
/* 219 */     __set(8);
/* 220 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B focusTraversable(boolean paramBoolean) {
/* 229 */     this.focusTraversable = paramBoolean;
/* 230 */     __set(9);
/* 231 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B id(String paramString) {
/* 240 */     this.id = paramString;
/* 241 */     __set(10);
/* 242 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B inputMethodRequests(InputMethodRequests paramInputMethodRequests) {
/* 251 */     this.inputMethodRequests = paramInputMethodRequests;
/* 252 */     __set(11);
/* 253 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B layoutX(double paramDouble) {
/* 262 */     this.layoutX = paramDouble;
/* 263 */     __set(12);
/* 264 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B layoutY(double paramDouble) {
/* 273 */     this.layoutY = paramDouble;
/* 274 */     __set(13);
/* 275 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B managed(boolean paramBoolean) {
/* 284 */     this.managed = paramBoolean;
/* 285 */     __set(14);
/* 286 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B mouseTransparent(boolean paramBoolean) {
/* 295 */     this.mouseTransparent = paramBoolean;
/* 296 */     __set(15);
/* 297 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onContextMenuRequested(EventHandler<? super ContextMenuEvent> paramEventHandler) {
/* 307 */     this.onContextMenuRequested = paramEventHandler;
/* 308 */     __set(16);
/* 309 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onDragDetected(EventHandler<? super MouseEvent> paramEventHandler) {
/* 318 */     this.onDragDetected = paramEventHandler;
/* 319 */     __set(17);
/* 320 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onDragDone(EventHandler<? super DragEvent> paramEventHandler) {
/* 329 */     this.onDragDone = paramEventHandler;
/* 330 */     __set(18);
/* 331 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onDragDropped(EventHandler<? super DragEvent> paramEventHandler) {
/* 340 */     this.onDragDropped = paramEventHandler;
/* 341 */     __set(19);
/* 342 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onDragEntered(EventHandler<? super DragEvent> paramEventHandler) {
/* 351 */     this.onDragEntered = paramEventHandler;
/* 352 */     __set(20);
/* 353 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onDragExited(EventHandler<? super DragEvent> paramEventHandler) {
/* 362 */     this.onDragExited = paramEventHandler;
/* 363 */     __set(21);
/* 364 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onDragOver(EventHandler<? super DragEvent> paramEventHandler) {
/* 373 */     this.onDragOver = paramEventHandler;
/* 374 */     __set(22);
/* 375 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onInputMethodTextChanged(EventHandler<? super InputMethodEvent> paramEventHandler) {
/* 384 */     this.onInputMethodTextChanged = paramEventHandler;
/* 385 */     __set(23);
/* 386 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onKeyPressed(EventHandler<? super KeyEvent> paramEventHandler) {
/* 395 */     this.onKeyPressed = paramEventHandler;
/* 396 */     __set(24);
/* 397 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onKeyReleased(EventHandler<? super KeyEvent> paramEventHandler) {
/* 406 */     this.onKeyReleased = paramEventHandler;
/* 407 */     __set(25);
/* 408 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onKeyTyped(EventHandler<? super KeyEvent> paramEventHandler) {
/* 417 */     this.onKeyTyped = paramEventHandler;
/* 418 */     __set(26);
/* 419 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMouseClicked(EventHandler<? super MouseEvent> paramEventHandler) {
/* 428 */     this.onMouseClicked = paramEventHandler;
/* 429 */     __set(27);
/* 430 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMouseDragEntered(EventHandler<? super MouseDragEvent> paramEventHandler) {
/* 440 */     this.onMouseDragEntered = paramEventHandler;
/* 441 */     __set(28);
/* 442 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMouseDragExited(EventHandler<? super MouseDragEvent> paramEventHandler) {
/* 452 */     this.onMouseDragExited = paramEventHandler;
/* 453 */     __set(29);
/* 454 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMouseDragged(EventHandler<? super MouseEvent> paramEventHandler) {
/* 463 */     this.onMouseDragged = paramEventHandler;
/* 464 */     __set(30);
/* 465 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMouseDragOver(EventHandler<? super MouseDragEvent> paramEventHandler) {
/* 475 */     this.onMouseDragOver = paramEventHandler;
/* 476 */     __set(31);
/* 477 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMouseDragReleased(EventHandler<? super MouseDragEvent> paramEventHandler) {
/* 487 */     this.onMouseDragReleased = paramEventHandler;
/* 488 */     __set(32);
/* 489 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMouseEntered(EventHandler<? super MouseEvent> paramEventHandler) {
/* 498 */     this.onMouseEntered = paramEventHandler;
/* 499 */     __set(33);
/* 500 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMouseExited(EventHandler<? super MouseEvent> paramEventHandler) {
/* 509 */     this.onMouseExited = paramEventHandler;
/* 510 */     __set(34);
/* 511 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMouseMoved(EventHandler<? super MouseEvent> paramEventHandler) {
/* 520 */     this.onMouseMoved = paramEventHandler;
/* 521 */     __set(35);
/* 522 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMousePressed(EventHandler<? super MouseEvent> paramEventHandler) {
/* 531 */     this.onMousePressed = paramEventHandler;
/* 532 */     __set(36);
/* 533 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onMouseReleased(EventHandler<? super MouseEvent> paramEventHandler) {
/* 542 */     this.onMouseReleased = paramEventHandler;
/* 543 */     __set(37);
/* 544 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onRotate(EventHandler<? super RotateEvent> paramEventHandler) {
/* 554 */     this.onRotate = paramEventHandler;
/* 555 */     __set(38);
/* 556 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onRotationFinished(EventHandler<? super RotateEvent> paramEventHandler) {
/* 566 */     this.onRotationFinished = paramEventHandler;
/* 567 */     __set(39);
/* 568 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onRotationStarted(EventHandler<? super RotateEvent> paramEventHandler) {
/* 578 */     this.onRotationStarted = paramEventHandler;
/* 579 */     __set(40);
/* 580 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onScroll(EventHandler<? super ScrollEvent> paramEventHandler) {
/* 589 */     this.onScroll = paramEventHandler;
/* 590 */     __set(41);
/* 591 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onScrollFinished(EventHandler<? super ScrollEvent> paramEventHandler) {
/* 601 */     this.onScrollFinished = paramEventHandler;
/* 602 */     __set(42);
/* 603 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onScrollStarted(EventHandler<? super ScrollEvent> paramEventHandler) {
/* 613 */     this.onScrollStarted = paramEventHandler;
/* 614 */     __set(43);
/* 615 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onSwipeDown(EventHandler<? super SwipeEvent> paramEventHandler) {
/* 625 */     this.onSwipeDown = paramEventHandler;
/* 626 */     __set(44);
/* 627 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onSwipeLeft(EventHandler<? super SwipeEvent> paramEventHandler) {
/* 637 */     this.onSwipeLeft = paramEventHandler;
/* 638 */     __set(45);
/* 639 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onSwipeRight(EventHandler<? super SwipeEvent> paramEventHandler) {
/* 649 */     this.onSwipeRight = paramEventHandler;
/* 650 */     __set(46);
/* 651 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onSwipeUp(EventHandler<? super SwipeEvent> paramEventHandler) {
/* 661 */     this.onSwipeUp = paramEventHandler;
/* 662 */     __set(47);
/* 663 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onTouchMoved(EventHandler<? super TouchEvent> paramEventHandler) {
/* 673 */     this.onTouchMoved = paramEventHandler;
/* 674 */     __set(48);
/* 675 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onTouchPressed(EventHandler<? super TouchEvent> paramEventHandler) {
/* 685 */     this.onTouchPressed = paramEventHandler;
/* 686 */     __set(49);
/* 687 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onTouchReleased(EventHandler<? super TouchEvent> paramEventHandler) {
/* 697 */     this.onTouchReleased = paramEventHandler;
/* 698 */     __set(50);
/* 699 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onTouchStationary(EventHandler<? super TouchEvent> paramEventHandler) {
/* 709 */     this.onTouchStationary = paramEventHandler;
/* 710 */     __set(51);
/* 711 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onZoom(EventHandler<? super ZoomEvent> paramEventHandler) {
/* 721 */     this.onZoom = paramEventHandler;
/* 722 */     __set(52);
/* 723 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onZoomFinished(EventHandler<? super ZoomEvent> paramEventHandler) {
/* 733 */     this.onZoomFinished = paramEventHandler;
/* 734 */     __set(53);
/* 735 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B onZoomStarted(EventHandler<? super ZoomEvent> paramEventHandler) {
/* 745 */     this.onZoomStarted = paramEventHandler;
/* 746 */     __set(54);
/* 747 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B opacity(double paramDouble) {
/* 756 */     this.opacity = paramDouble;
/* 757 */     __set(55);
/* 758 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B pickOnBounds(boolean paramBoolean) {
/* 767 */     this.pickOnBounds = paramBoolean;
/* 768 */     __set(56);
/* 769 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B rotate(double paramDouble) {
/* 778 */     this.rotate = paramDouble;
/* 779 */     __set(57);
/* 780 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B rotationAxis(Point3D paramPoint3D) {
/* 789 */     this.rotationAxis = paramPoint3D;
/* 790 */     __set(58);
/* 791 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B scaleX(double paramDouble) {
/* 800 */     this.scaleX = paramDouble;
/* 801 */     __set(59);
/* 802 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B scaleY(double paramDouble) {
/* 811 */     this.scaleY = paramDouble;
/* 812 */     __set(60);
/* 813 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B scaleZ(double paramDouble) {
/* 822 */     this.scaleZ = paramDouble;
/* 823 */     __set(61);
/* 824 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B style(String paramString) {
/* 833 */     this.style = paramString;
/* 834 */     __set(62);
/* 835 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B styleClass(Collection<? extends String> paramCollection) {
/* 844 */     this.styleClass = paramCollection;
/* 845 */     __set(63);
/* 846 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B styleClass(String... paramVarArgs) {
/* 853 */     return styleClass(Arrays.asList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B transforms(Collection<? extends Transform> paramCollection) {
/* 862 */     this.transforms = paramCollection;
/* 863 */     __set(64);
/* 864 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B transforms(Transform... paramVarArgs) {
/* 871 */     return transforms(Arrays.asList(paramVarArgs));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B translateX(double paramDouble) {
/* 880 */     this.translateX = paramDouble;
/* 881 */     __set(65);
/* 882 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B translateY(double paramDouble) {
/* 891 */     this.translateY = paramDouble;
/* 892 */     __set(66);
/* 893 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B translateZ(double paramDouble) {
/* 902 */     this.translateZ = paramDouble;
/* 903 */     __set(67);
/* 904 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B userData(Object paramObject) {
/* 913 */     this.userData = paramObject;
/* 914 */     __set(68);
/* 915 */     return (B)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B visible(boolean paramBoolean) {
/* 924 */     this.visible = paramBoolean;
/* 925 */     __set(69);
/* 926 */     return (B)this;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\fxml\builder\web\NodeBuilder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */