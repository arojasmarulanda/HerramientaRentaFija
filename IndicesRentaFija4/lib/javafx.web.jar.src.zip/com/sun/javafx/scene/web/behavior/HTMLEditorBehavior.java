/*    */ package com.sun.javafx.scene.web.behavior;
/*    */ 
/*    */ import com.sun.javafx.scene.ParentHelper;
/*    */ import com.sun.javafx.scene.control.behavior.BehaviorBase;
/*    */ import com.sun.javafx.scene.control.behavior.FocusTraversalInputMap;
/*    */ import com.sun.javafx.scene.control.inputmap.InputMap;
/*    */ import com.sun.javafx.scene.control.inputmap.KeyBinding;
/*    */ import javafx.scene.Parent;
/*    */ import javafx.scene.input.KeyCode;
/*    */ import javafx.scene.input.KeyEvent;
/*    */ import javafx.scene.web.HTMLEditor;
/*    */ import javafx.scene.web.HTMLEditorSkin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLEditorBehavior
/*    */   extends BehaviorBase<HTMLEditor>
/*    */ {
/*    */   private final InputMap<HTMLEditor> inputMap;
/*    */   
/*    */   public HTMLEditorBehavior(HTMLEditor paramHTMLEditor) {
/* 46 */     super(paramHTMLEditor);
/*    */     
/* 48 */     this.inputMap = createInputMap();
/* 49 */     addDefaultMapping(this.inputMap, new InputMap.Mapping[] { (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.B))
/* 50 */             .shortcut(), paramKeyEvent -> keyboardShortcuts(HTMLEditorSkin.Command.BOLD)), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.I))
/* 51 */             .shortcut(), paramKeyEvent -> keyboardShortcuts(HTMLEditorSkin.Command.ITALIC)), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.U))
/* 52 */             .shortcut(), paramKeyEvent -> keyboardShortcuts(HTMLEditorSkin.Command.UNDERLINE)), (InputMap.Mapping)new InputMap.KeyMapping(new KeyBinding(KeyCode.F12), paramKeyEvent -> ParentHelper.getTraversalEngine((Parent)getNode()).selectFirst().requestFocus()), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB))
/*    */ 
/*    */             
/* 55 */             .ctrl(), FocusTraversalInputMap::traverseNext), (InputMap.Mapping)new InputMap.KeyMapping((new KeyBinding(KeyCode.TAB))
/* 56 */             .ctrl().shift(), FocusTraversalInputMap::traversePrevious) });
/*    */   }
/*    */ 
/*    */   
/*    */   public InputMap<HTMLEditor> getInputMap() {
/* 61 */     return this.inputMap;
/*    */   }
/*    */   
/*    */   private void keyboardShortcuts(HTMLEditorSkin.Command paramCommand) {
/* 65 */     HTMLEditor hTMLEditor = (HTMLEditor)getNode();
/* 66 */     HTMLEditorSkin hTMLEditorSkin = (HTMLEditorSkin)hTMLEditor.getSkin();
/* 67 */     hTMLEditorSkin.performCommand(paramCommand);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\scene\web\behavior\HTMLEditorBehavior.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */