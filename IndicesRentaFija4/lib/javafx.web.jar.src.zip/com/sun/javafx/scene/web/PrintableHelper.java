/*    */ package com.sun.javafx.scene.web;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.scene.NodeHelper;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrintableHelper
/*    */   extends NodeHelper
/*    */ {
/* 41 */   private static final PrintableHelper theInstance = new PrintableHelper(); static {
/* 42 */     Utils.forceInit(Printable.class);
/*    */   }
/*    */   private static PrintableAccessor printableAccessor;
/*    */   private static PrintableHelper getInstance() {
/* 46 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Printable paramPrintable) {
/* 50 */     setHelper(paramPrintable, getInstance());
/*    */   }
/*    */   
/*    */   public static void setPrintableAccessor(PrintableAccessor paramPrintableAccessor) {
/* 54 */     if (printableAccessor != null) {
/* 55 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 58 */     printableAccessor = paramPrintableAccessor;
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 63 */     return printableAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 69 */     return printableAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/* 74 */     return printableAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*    */   }
/*    */   
/*    */   public static interface PrintableAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\javafx\scene\web\PrintableHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */