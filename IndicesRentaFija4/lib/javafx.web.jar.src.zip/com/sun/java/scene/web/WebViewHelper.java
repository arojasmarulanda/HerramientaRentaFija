/*    */ package com.sun.java.scene.web;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.PickRay;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.scene.NodeHelper;
/*    */ import com.sun.javafx.scene.ParentHelper;
/*    */ import com.sun.javafx.scene.input.PickResultChooser;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.web.WebView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebViewHelper
/*    */   extends ParentHelper
/*    */ {
/* 47 */   private static final WebViewHelper theInstance = new WebViewHelper(); static {
/* 48 */     Utils.forceInit(WebView.class);
/*    */   }
/*    */   private static WebViewAccessor webViewAccessor;
/*    */   private static WebViewHelper getInstance() {
/* 52 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(WebView paramWebView) {
/* 56 */     setHelper(paramWebView, (NodeHelper)getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 61 */     return webViewAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 66 */     super.updatePeerImpl(paramNode);
/* 67 */     webViewAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */   
/*    */   protected void transformsChangedImpl(Node paramNode) {
/* 71 */     super.transformsChangedImpl(paramNode);
/* 72 */     webViewAccessor.doTransformsChanged(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 78 */     return webViewAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/* 83 */     return webViewAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void pickNodeLocalImpl(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 89 */     webViewAccessor.doPickNodeLocal(paramNode, paramPickRay, paramPickResultChooser);
/*    */   }
/*    */   
/*    */   public static void setWebViewAccessor(WebViewAccessor paramWebViewAccessor) {
/* 93 */     if (webViewAccessor != null) {
/* 94 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 97 */     webViewAccessor = paramWebViewAccessor;
/*    */   }
/*    */   
/*    */   public static interface WebViewAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     void doTransformsChanged(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*    */     
/*    */     void doPickNodeLocal(Node param1Node, PickRay param1PickRay, PickResultChooser param1PickResultChooser);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\java\scene\web\WebViewHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */