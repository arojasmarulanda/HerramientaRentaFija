package com.sun.webkit;

public interface InspectorClient {
  boolean sendMessageToFrontend(String paramString);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\InspectorClient.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */