/*     */ package com.sun.webkit;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.AccessController;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Disposer
/*     */   implements Runnable
/*     */ {
/*  56 */   private static final ReferenceQueue queue = new ReferenceQueue();
/*  57 */   private static final Disposer disposerInstance = new Disposer();
/*  58 */   private static final Set<WeakDisposerRecord> records = new HashSet<>();
/*     */ 
/*     */   
/*     */   static {
/*  62 */     AccessController.doPrivileged(() -> {
/*     */           ThreadGroup threadGroup1 = Thread.currentThread().getThreadGroup();
/*     */           for (ThreadGroup threadGroup2 = threadGroup1; threadGroup2 != null; threadGroup2 = threadGroup1.getParent()) {
/*     */             threadGroup1 = threadGroup2;
/*     */           }
/*     */           Thread thread = new Thread(threadGroup1, disposerInstance, "Disposer");
/*     */           thread.setDaemon(true);
/*     */           thread.setPriority(10);
/*     */           thread.start();
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addRecord(Object paramObject, DisposerRecord paramDisposerRecord) {
/*  88 */     disposerInstance.add(paramObject, paramDisposerRecord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void add(Object paramObject, DisposerRecord paramDisposerRecord) {
/*  98 */     records.add(new WeakDisposerRecord(paramObject, paramDisposerRecord));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addRecord(WeakDisposerRecord paramWeakDisposerRecord) {
/* 107 */     disposerInstance.add(paramWeakDisposerRecord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void add(WeakDisposerRecord paramWeakDisposerRecord) {
/* 116 */     records.add(paramWeakDisposerRecord);
/*     */   }
/*     */   public void run() {
/*     */     while (true) {
/*     */       try {
/*     */         while (true)
/* 122 */         { WeakDisposerRecord weakDisposerRecord = (WeakDisposerRecord)queue.remove();
/* 123 */           weakDisposerRecord.clear();
/* 124 */           DisposerRunnable.getInstance().enqueue(weakDisposerRecord); }  break;
/* 125 */       } catch (Exception exception) {
/* 126 */         System.out.println("Exception while removing reference: " + exception);
/* 127 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class DisposerRunnable implements Runnable {
/* 133 */     private static final DisposerRunnable theInstance = new DisposerRunnable();
/*     */     
/*     */     private static DisposerRunnable getInstance() {
/* 136 */       return theInstance;
/*     */     }
/*     */     
/*     */     private boolean isRunning = false;
/* 140 */     private final Object disposerLock = new Object();
/* 141 */     private final LinkedBlockingQueue<Disposer.WeakDisposerRecord> disposerQueue = new LinkedBlockingQueue<>();
/*     */ 
/*     */     
/*     */     private void enqueueAll(Collection<Disposer.WeakDisposerRecord> param1Collection) {
/* 145 */       synchronized (this.disposerLock) {
/* 146 */         this.disposerQueue.addAll(param1Collection);
/* 147 */         if (!this.isRunning) {
/* 148 */           Invoker.getInvoker().invokeOnEventThread(this);
/* 149 */           this.isRunning = true;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void enqueue(Disposer.WeakDisposerRecord param1WeakDisposerRecord) {
/* 155 */       enqueueAll(Arrays.asList(new Disposer.WeakDisposerRecord[] { param1WeakDisposerRecord }));
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       while (true) {
/*     */         Disposer.WeakDisposerRecord weakDisposerRecord;
/* 161 */         synchronized (this.disposerLock) {
/* 162 */           weakDisposerRecord = this.disposerQueue.poll();
/* 163 */           if (weakDisposerRecord == null) {
/* 164 */             this.isRunning = false;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 169 */         if (Disposer.records.contains(weakDisposerRecord)) {
/* 170 */           Disposer.records.remove(weakDisposerRecord);
/* 171 */           weakDisposerRecord.dispose();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static class WeakDisposerRecord
/*     */     extends WeakReference implements DisposerRecord {
/*     */     private final DisposerRecord record;
/*     */     
/*     */     protected WeakDisposerRecord(Object param1Object) {
/* 182 */       super((T)param1Object, Disposer.queue);
/* 183 */       this.record = null;
/*     */     }
/*     */     
/*     */     private WeakDisposerRecord(Object param1Object, DisposerRecord param1DisposerRecord) {
/* 187 */       super((T)param1Object, Disposer.queue);
/* 188 */       this.record = param1DisposerRecord;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 195 */       this.record.dispose();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\Disposer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */