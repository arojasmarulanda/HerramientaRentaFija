/*    */ package com.sun.webkit.graphics;
/*    */ 
/*    */ import com.sun.javafx.sg.prism.NGCamera;
/*    */ import com.sun.javafx.sg.prism.NGDefaultCamera;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WCCamera
/*    */   extends NGDefaultCamera
/*    */ {
/* 56 */   public static final NGCamera INSTANCE = new WCCamera();
/*    */   
/*    */   public void validate(int paramInt1, int paramInt2) {
/* 59 */     if (paramInt1 != this.viewWidth || paramInt2 != this.viewHeight) {
/* 60 */       setViewWidth(paramInt1);
/* 61 */       setViewHeight(paramInt2);
/*    */       
/* 63 */       this.projViewTx.ortho(0.0D, paramInt1, paramInt2, 0.0D, -9999999.0D, 99999.0D);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCCamera.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */