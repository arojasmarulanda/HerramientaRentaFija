/*    */ package com.sun.webkit.graphics;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WCTransform
/*    */   extends Ref
/*    */ {
/*    */   private final double[] m;
/*    */   private final boolean is3D;
/*    */   
/*    */   public WCTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12, double paramDouble13, double paramDouble14, double paramDouble15, double paramDouble16) {
/* 39 */     this.m = new double[16];
/*    */     
/* 41 */     this.m[0] = paramDouble1;
/* 42 */     this.m[1] = paramDouble5;
/* 43 */     this.m[2] = paramDouble9;
/* 44 */     this.m[3] = paramDouble13;
/*    */     
/* 46 */     this.m[4] = paramDouble2;
/* 47 */     this.m[5] = paramDouble6;
/* 48 */     this.m[6] = paramDouble10;
/* 49 */     this.m[7] = paramDouble14;
/*    */     
/* 51 */     this.m[8] = paramDouble3;
/* 52 */     this.m[9] = paramDouble7;
/* 53 */     this.m[10] = paramDouble11;
/* 54 */     this.m[11] = paramDouble15;
/*    */     
/* 56 */     this.m[12] = paramDouble4;
/* 57 */     this.m[13] = paramDouble8;
/* 58 */     this.m[14] = paramDouble12;
/* 59 */     this.m[15] = paramDouble16;
/*    */     
/* 61 */     this.is3D = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public WCTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 66 */     this.m = new double[6];
/* 67 */     this.m[0] = paramDouble1;
/* 68 */     this.m[1] = paramDouble2;
/* 69 */     this.m[2] = paramDouble3;
/* 70 */     this.m[3] = paramDouble4;
/* 71 */     this.m[4] = paramDouble5;
/* 72 */     this.m[5] = paramDouble6;
/*    */     
/* 74 */     this.is3D = false;
/*    */   }
/*    */   
/*    */   public double[] getMatrix() {
/* 78 */     return Arrays.copyOf(this.m, this.m.length);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 83 */     String str = "WCTransform:";
/* 84 */     if (this.is3D) {
/* 85 */       str = str + "(" + str + "," + this.m[0] + "," + this.m[1] + "," + this.m[2] + ")(" + this.m[3] + "," + this.m[4] + "," + this.m[5] + "," + this.m[6] + ")(" + this.m[7] + "," + this.m[8] + "," + this.m[9] + "," + this.m[10] + ")(" + this.m[11] + "," + this.m[12] + "," + this.m[13] + "," + this.m[14] + ")";
/*    */     
/*    */     }
/*    */     else {
/*    */       
/* 90 */       str = str + "(" + str + "," + this.m[0] + "," + this.m[1] + ")(" + this.m[2] + "," + this.m[3] + "," + this.m[4] + ")";
/*    */     } 
/*    */     
/* 93 */     return str;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCTransform.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */