package com.sun.webkit.graphics;

public final class WCIcon extends Ref {}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCIcon.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */