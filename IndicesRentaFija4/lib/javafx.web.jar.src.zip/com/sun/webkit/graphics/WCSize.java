/*    */ package com.sun.webkit.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WCSize
/*    */ {
/*    */   private final float width;
/*    */   private final float height;
/*    */   
/*    */   public WCSize(float paramFloat1, float paramFloat2) {
/* 33 */     this.width = paramFloat1;
/* 34 */     this.height = paramFloat2;
/*    */   }
/*    */   
/*    */   public float getWidth() {
/* 38 */     return this.width;
/*    */   }
/*    */   
/*    */   public float getHeight() {
/* 42 */     return this.height;
/*    */   }
/*    */   
/*    */   public int getIntWidth() {
/* 46 */     return (int)this.width;
/*    */   }
/*    */   
/*    */   public int getIntHeight() {
/* 50 */     return (int)this.height;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCSize.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */