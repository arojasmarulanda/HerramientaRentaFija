/*    */ package com.sun.webkit.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WCGradient<G>
/*    */ {
/*    */   public static final int PAD = 1;
/*    */   public static final int REFLECT = 2;
/*    */   public static final int REPEAT = 3;
/* 37 */   private int spreadMethod = 1;
/*    */   private boolean proportional;
/*    */   
/*    */   void setSpreadMethod(int paramInt) {
/* 41 */     if (paramInt != 2 && paramInt != 3) {
/* 42 */       paramInt = 1;
/*    */     }
/* 44 */     this.spreadMethod = paramInt;
/*    */   }
/*    */   
/*    */   public int getSpreadMethod() {
/* 48 */     return this.spreadMethod;
/*    */   }
/*    */   
/*    */   void setProportional(boolean paramBoolean) {
/* 52 */     this.proportional = paramBoolean;
/*    */   }
/*    */   
/*    */   public boolean isProportional() {
/* 56 */     return this.proportional;
/*    */   }
/*    */   
/*    */   protected abstract void addStop(int paramInt, float paramFloat);
/*    */   
/*    */   public abstract G getPlatformGradient();
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCGradient.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */