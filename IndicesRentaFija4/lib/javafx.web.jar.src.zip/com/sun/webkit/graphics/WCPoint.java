/*    */ package com.sun.webkit.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WCPoint
/*    */ {
/*    */   final float x;
/*    */   final float y;
/*    */   
/*    */   public WCPoint(float paramFloat1, float paramFloat2) {
/* 32 */     this.x = paramFloat1;
/* 33 */     this.y = paramFloat2;
/*    */   }
/*    */   
/*    */   public float getX() {
/* 37 */     return this.x;
/*    */   }
/*    */   
/*    */   public float getY() {
/* 41 */     return this.y;
/*    */   }
/*    */   
/*    */   public int getIntX() {
/* 45 */     return (int)this.x;
/*    */   }
/*    */   
/*    */   public int getIntY() {
/* 49 */     return (int)this.y;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCPoint.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */