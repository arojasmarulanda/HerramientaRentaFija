package com.sun.webkit.graphics;

public abstract class WCImageDecoder {
  protected abstract void addImageData(byte[] paramArrayOfbyte);
  
  protected abstract int[] getImageSize();
  
  protected abstract int getFrameCount();
  
  protected abstract WCImageFrame getFrame(int paramInt);
  
  protected abstract int getFrameDuration(int paramInt);
  
  protected abstract int[] getFrameSize(int paramInt);
  
  protected abstract boolean getFrameCompleteStatus(int paramInt);
  
  protected abstract void loadFromResource(String paramString);
  
  protected abstract void destroy();
  
  protected abstract String getFilenameExtension();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCImageDecoder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */