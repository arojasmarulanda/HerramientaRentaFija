/*     */ package com.sun.webkit.graphics;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.Invoker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WCMediaPlayer
/*     */   extends Ref
/*     */ {
/*  33 */   protected static final PlatformLogger log = PlatformLogger.getLogger("webkit.mediaplayer");
/*     */   private long nPtr;
/*     */   protected static final int NETWORK_STATE_EMPTY = 0;
/*     */   protected static final int NETWORK_STATE_IDLE = 1;
/*     */   protected static final int NETWORK_STATE_LOADING = 2;
/*     */   protected static final int NETWORK_STATE_LOADED = 3;
/*     */   protected static final int NETWORK_STATE_FORMAT_ERROR = 4;
/*     */   protected static final int NETWORK_STATE_NETWORK_ERROR = 5;
/*     */   protected static final int NETWORK_STATE_DECODE_ERROR = 6;
/*     */   
/*     */   void setNativePointer(long paramLong) {
/*  44 */     if (paramLong == 0L) {
/*  45 */       throw new IllegalArgumentException("nativePointer is 0");
/*     */     }
/*  47 */     if (this.nPtr != 0L) {
/*  48 */       throw new IllegalStateException("nPtr is not 0");
/*     */     }
/*  50 */     this.nPtr = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int READY_STATE_HAVE_NOTHING = 0;
/*     */ 
/*     */   
/*     */   protected static final int READY_STATE_HAVE_METADATA = 1;
/*     */ 
/*     */   
/*     */   protected static final int READY_STATE_HAVE_CURRENT_DATA = 2;
/*     */ 
/*     */   
/*     */   protected static final int READY_STATE_HAVE_FUTURE_DATA = 3;
/*     */ 
/*     */   
/*     */   protected static final int READY_STATE_HAVE_ENOUGH_DATA = 4;
/*     */ 
/*     */   
/*     */   protected static final int PRELOAD_NONE = 0;
/*     */ 
/*     */   
/*     */   protected static final int PRELOAD_METADATA = 1;
/*     */   
/*     */   protected static final int PRELOAD_AUTO = 2;
/*     */ 
/*     */   
/*     */   protected boolean getPreservesPitch() {
/*  79 */     return this.preserve;
/*     */   }
/*     */   
/*     */   protected int getNetworkState() {
/*  83 */     return this.networkState;
/*     */   }
/*     */   
/*     */   protected int getReadyState() {
/*  87 */     return this.readyState;
/*     */   }
/*     */   
/*     */   protected int getPreload() {
/*  91 */     return this.preload;
/*     */   }
/*     */   
/*     */   protected boolean isPaused() {
/*  95 */     return this.paused;
/*     */   }
/*     */   
/*     */   protected boolean isSeeking() {
/*  99 */     return this.seeking;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   private int networkState = 0;
/* 126 */   private int readyState = 0;
/* 127 */   private int preload = 2;
/*     */   
/*     */   private boolean paused = true;
/*     */   private boolean seeking = false;
/*     */   
/*     */   protected void notifyNetworkStateChanged(int paramInt) {
/* 133 */     if (this.networkState != paramInt) {
/* 134 */       this.networkState = paramInt;
/* 135 */       int i = paramInt;
/* 136 */       Invoker.getInvoker().invokeOnEventThread(() -> {
/*     */             if (this.nPtr != 0L) {
/*     */               notifyNetworkStateChanged(this.nPtr, paramInt);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void notifyReadyStateChanged(int paramInt) {
/* 145 */     if (this.readyState != paramInt) {
/* 146 */       this.readyState = paramInt;
/* 147 */       int i = paramInt;
/* 148 */       Invoker.getInvoker().invokeOnEventThread(() -> {
/*     */             if (this.nPtr != 0L) {
/*     */               notifyReadyStateChanged(this.nPtr, paramInt);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void notifyPaused(boolean paramBoolean) {
/* 157 */     log.fine("notifyPaused, {0} => {1}", new Object[] {
/* 158 */           Boolean.valueOf(this.paused), Boolean.valueOf(paramBoolean) });
/* 159 */     if (this.paused != paramBoolean) {
/* 160 */       this.paused = paramBoolean;
/* 161 */       boolean bool = paramBoolean;
/* 162 */       Invoker.getInvoker().invokeOnEventThread(() -> {
/*     */             if (this.nPtr != 0L) {
/*     */               notifyPaused(this.nPtr, paramBoolean);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void notifySeeking(boolean paramBoolean, int paramInt) {
/* 172 */     log.fine("notifySeeking, {0} => {1}", new Object[] {
/* 173 */           Boolean.valueOf(this.seeking), Boolean.valueOf(paramBoolean) });
/* 174 */     if (this.seeking != paramBoolean || this.readyState != paramInt) {
/* 175 */       this.seeking = paramBoolean;
/* 176 */       this.readyState = paramInt;
/* 177 */       boolean bool = paramBoolean;
/* 178 */       int i = paramInt;
/* 179 */       Invoker.getInvoker().invokeOnEventThread(() -> {
/*     */             if (this.nPtr != 0L) {
/*     */               notifySeeking(this.nPtr, paramBoolean, paramInt);
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void notifyFinished() {
/* 188 */     Invoker.getInvoker().invokeOnEventThread(() -> {
/*     */           if (this.nPtr != 0L) {
/*     */             notifyFinished(this.nPtr);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   protected void notifyReady(boolean paramBoolean1, boolean paramBoolean2, float paramFloat) {
/* 197 */     boolean bool1 = paramBoolean1;
/* 198 */     boolean bool2 = paramBoolean2;
/* 199 */     float f = paramFloat;
/* 200 */     Invoker.getInvoker().invokeOnEventThread(() -> {
/*     */           if (this.nPtr != 0L) {
/*     */             notifyReady(this.nPtr, paramBoolean1, paramBoolean2, paramFloat);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   protected void notifyDurationChanged(float paramFloat) {
/* 208 */     float f = paramFloat;
/* 209 */     Invoker.getInvoker().invokeOnEventThread(() -> {
/*     */           if (this.nPtr != 0L) {
/*     */             notifyDurationChanged(this.nPtr, paramFloat);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   protected void notifySizeChanged(int paramInt1, int paramInt2) {
/* 218 */     int i = paramInt1;
/* 219 */     int j = paramInt2;
/* 220 */     Invoker.getInvoker().invokeOnEventThread(() -> {
/*     */           if (this.nPtr != 0L) {
/*     */             notifySizeChanged(this.nPtr, paramInt1, paramInt2);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private Runnable newFrameNotifier = () -> {
/*     */       if (this.nPtr != 0L) {
/*     */         notifyNewFrame(this.nPtr);
/*     */       }
/*     */     };
/*     */   
/*     */   protected void notifyNewFrame() {
/* 234 */     Invoker.getInvoker().invokeOnEventThread(this.newFrameNotifier);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyBufferChanged(float[] paramArrayOffloat, int paramInt) {
/* 240 */     float[] arrayOfFloat = paramArrayOffloat;
/* 241 */     int i = paramInt;
/* 242 */     Invoker.getInvoker().invokeOnEventThread(() -> {
/*     */           if (this.nPtr != 0L) {
/*     */             notifyBufferChanged(this.nPtr, paramArrayOffloat, paramInt);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fwkLoad(String paramString1, String paramString2) {
/* 255 */     log.fine("fwkLoad, url={0}, userAgent={1}", new Object[] { paramString1, paramString2 });
/* 256 */     load(paramString1, paramString2);
/*     */   }
/*     */   
/*     */   private void fwkCancelLoad() {
/* 260 */     log.fine("fwkCancelLoad");
/* 261 */     cancelLoad();
/*     */   }
/*     */   
/*     */   private void fwkPrepareToPlay() {
/* 265 */     log.fine("fwkPrepareToPlay");
/* 266 */     prepareToPlay();
/*     */   }
/*     */   
/*     */   private void fwkDispose() {
/* 270 */     log.fine("fwkDispose");
/* 271 */     this.nPtr = 0L;
/* 272 */     cancelLoad();
/* 273 */     disposePlayer();
/*     */   }
/*     */   
/*     */   private void fwkPlay() {
/* 277 */     log.fine("fwkPlay");
/* 278 */     play();
/*     */   }
/*     */   
/*     */   private void fwkPause() {
/* 282 */     log.fine("fwkPause");
/* 283 */     pause();
/*     */   }
/*     */   
/*     */   private float fwkGetCurrentTime() {
/* 287 */     float f = getCurrentTime();
/* 288 */     log.finer("fwkGetCurrentTime(), return {0}", new Object[] { Float.valueOf(f) });
/* 289 */     return f;
/*     */   }
/*     */   
/*     */   private void fwkSeek(float paramFloat) {
/* 293 */     log.fine("fwkSeek({0})", new Object[] { Float.valueOf(paramFloat) });
/* 294 */     seek(paramFloat);
/*     */   }
/*     */   
/*     */   private void fwkSetRate(float paramFloat) {
/* 298 */     log.fine("fwkSetRate({0})", new Object[] { Float.valueOf(paramFloat) });
/* 299 */     setRate(paramFloat);
/*     */   }
/*     */   
/*     */   private void fwkSetVolume(float paramFloat) {
/* 303 */     log.fine("fwkSetVolume({0})", new Object[] { Float.valueOf(paramFloat) });
/* 304 */     setVolume(paramFloat);
/*     */   }
/*     */   
/*     */   private void fwkSetMute(boolean paramBoolean) {
/* 308 */     log.fine("fwkSetMute({0})", new Object[] { Boolean.valueOf(paramBoolean) });
/* 309 */     setMute(paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   private void fwkSetSize(int paramInt1, int paramInt2) {
/* 314 */     setSize(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   private boolean preserve = true;
/*     */   
/*     */   private void fwkSetPreservesPitch(boolean paramBoolean) {
/* 320 */     log.fine("setPreservesPitch({0})", new Object[] { Boolean.valueOf(paramBoolean) });
/*     */     
/* 322 */     this.preserve = paramBoolean;
/* 323 */     setPreservesPitch(paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   private void fwkSetPreload(int paramInt) {
/* 328 */     log.fine("fwkSetPreload({0})", new Object[] {
/* 329 */           (paramInt == 0) ? "PRELOAD_NONE" : (
/* 330 */           (paramInt == 1) ? "PRELOAD_METADATA" : (
/* 331 */           (paramInt == 2) ? "PRELOAD_AUTO" : ("INVALID VALUE: " + 
/* 332 */           paramInt))) });
/* 333 */     this.preload = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   void render(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 338 */     log.finer("render(x={0}, y={1}, w={2}, h={3}", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4) });
/* 339 */     renderCurrentFrame(paramWCGraphicsContext, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   protected abstract void load(String paramString1, String paramString2);
/*     */   
/*     */   protected abstract void cancelLoad();
/*     */   
/*     */   protected abstract void disposePlayer();
/*     */   
/*     */   protected abstract void prepareToPlay();
/*     */   
/*     */   protected abstract void play();
/*     */   
/*     */   protected abstract void pause();
/*     */   
/*     */   protected abstract float getCurrentTime();
/*     */   
/*     */   protected abstract void seek(float paramFloat);
/*     */   
/*     */   protected abstract void setRate(float paramFloat);
/*     */   
/*     */   protected abstract void setVolume(float paramFloat);
/*     */   
/*     */   protected abstract void setMute(boolean paramBoolean);
/*     */   
/*     */   protected abstract void setSize(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract void setPreservesPitch(boolean paramBoolean);
/*     */   
/*     */   protected abstract void renderCurrentFrame(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */   
/*     */   private native void notifyNetworkStateChanged(long paramLong, int paramInt);
/*     */   
/*     */   private native void notifyReadyStateChanged(long paramLong, int paramInt);
/*     */   
/*     */   private native void notifyPaused(long paramLong, boolean paramBoolean);
/*     */   
/*     */   private native void notifySeeking(long paramLong, boolean paramBoolean, int paramInt);
/*     */   
/*     */   private native void notifyFinished(long paramLong);
/*     */   
/*     */   private native void notifyReady(long paramLong, boolean paramBoolean1, boolean paramBoolean2, float paramFloat);
/*     */   
/*     */   private native void notifyDurationChanged(long paramLong, float paramFloat);
/*     */   
/*     */   private native void notifySizeChanged(long paramLong, int paramInt1, int paramInt2);
/*     */   
/*     */   private native void notifyNewFrame(long paramLong);
/*     */   
/*     */   private native void notifyBufferChanged(long paramLong, float[] paramArrayOffloat, int paramInt);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCMediaPlayer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */