/*     */ package com.sun.webkit.graphics;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.Invoker;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.LinkedList;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WCRenderQueue
/*     */   extends Ref
/*     */ {
/*  38 */   private static final AtomicInteger idCountObj = new AtomicInteger(0);
/*     */   
/*  40 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCRenderQueue.class.getName());
/*     */   
/*     */   public static final int MAX_QUEUE_SIZE = 524288;
/*  43 */   private final LinkedList<BufferData> buffers = new LinkedList<>();
/*  44 */   private BufferData currentBuffer = new BufferData();
/*     */   private final WCRectangle clip;
/*  46 */   private int size = 0;
/*     */   
/*     */   private final boolean opaque;
/*     */   
/*     */   protected final WCGraphicsContext gc;
/*     */   
/*     */   protected WCRenderQueue(WCGraphicsContext paramWCGraphicsContext) {
/*  53 */     this.clip = null;
/*  54 */     this.opaque = false;
/*  55 */     this.gc = paramWCGraphicsContext;
/*     */   }
/*     */   
/*     */   protected WCRenderQueue(WCRectangle paramWCRectangle, boolean paramBoolean) {
/*  59 */     this.clip = paramWCRectangle;
/*  60 */     this.opaque = paramBoolean;
/*  61 */     this.gc = null;
/*     */   }
/*     */   
/*     */   public synchronized int getSize() {
/*  65 */     return this.size;
/*     */   }
/*     */   
/*     */   public synchronized void addBuffer(ByteBuffer paramByteBuffer) {
/*  69 */     if (log.isLoggable(PlatformLogger.Level.FINE) && this.buffers.isEmpty())
/*  70 */       log.fine("'{'WCRenderQueue{0}[{1}]", new Object[] {
/*  71 */             Integer.valueOf(hashCode()), Integer.valueOf(idCountObj.incrementAndGet())
/*     */           }); 
/*  73 */     this.currentBuffer.setBuffer(paramByteBuffer);
/*  74 */     this.buffers.addLast(this.currentBuffer);
/*  75 */     this.currentBuffer = new BufferData();
/*  76 */     this.size += paramByteBuffer.capacity();
/*  77 */     if (this.size > 524288 && this.gc != null)
/*     */     {
/*     */ 
/*     */       
/*  81 */       flush();
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized boolean isEmpty() {
/*  86 */     return this.buffers.isEmpty();
/*     */   }
/*     */   
/*     */   public synchronized void decode(WCGraphicsContext paramWCGraphicsContext) {
/*  90 */     for (BufferData bufferData : this.buffers) {
/*     */       try {
/*  92 */         GraphicsDecoder.decode(
/*  93 */             WCGraphicsManager.getGraphicsManager(), paramWCGraphicsContext, bufferData);
/*  94 */       } catch (RuntimeException runtimeException) {
/*  95 */         runtimeException.printStackTrace(System.err);
/*     */       } 
/*     */     } 
/*  98 */     dispose();
/*     */   }
/*     */   
/*     */   public synchronized void decode() {
/* 102 */     assert this.gc != null;
/* 103 */     decode(this.gc);
/* 104 */     this.gc.flush();
/*     */   }
/*     */   
/*     */   public synchronized void decode(int paramInt) {
/* 108 */     assert this.gc != null;
/* 109 */     this.gc.setFontSmoothingType(paramInt);
/* 110 */     decode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void fwkFlush() {
/* 116 */     flush();
/*     */   }
/*     */   
/*     */   private void fwkAddBuffer(ByteBuffer paramByteBuffer) {
/* 120 */     addBuffer(paramByteBuffer);
/*     */   }
/*     */   
/*     */   public WCRectangle getClip() {
/* 124 */     return this.clip;
/*     */   }
/*     */   
/*     */   public synchronized void dispose() {
/* 128 */     int i = this.buffers.size();
/* 129 */     if (i > 0) {
/* 130 */       byte b = 0;
/* 131 */       Object[] arrayOfObject = new Object[i];
/* 132 */       for (BufferData bufferData : this.buffers) {
/* 133 */         arrayOfObject[b++] = bufferData.getBuffer();
/*     */       }
/* 135 */       this.buffers.clear();
/* 136 */       Invoker.getInvoker().invokeOnEventThread(() -> twkRelease(paramArrayOfObject));
/*     */ 
/*     */       
/* 139 */       this.size = 0;
/* 140 */       if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 141 */         log.fine("'}'WCRenderQueue{0}[{1}]", new Object[] {
/* 142 */               Integer.valueOf(hashCode()), Integer.valueOf(idCountObj.decrementAndGet())
/*     */             });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void fwkDisposeGraphics() {
/* 150 */     disposeGraphics();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int refString(String paramString) {
/* 157 */     return this.currentBuffer.addString(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   private int refIntArr(int[] paramArrayOfint) {
/* 162 */     return this.currentBuffer.addIntArray(paramArrayOfint);
/*     */   }
/*     */ 
/*     */   
/*     */   private int refFloatArr(float[] paramArrayOffloat) {
/* 167 */     return this.currentBuffer.addFloatArray(paramArrayOffloat);
/*     */   }
/*     */   
/*     */   public boolean isOpaque() {
/* 171 */     return this.opaque;
/*     */   }
/*     */   
/*     */   public synchronized String toString() {
/* 175 */     return "WCRenderQueue{clip=" + this.clip + ", size=" + this.size + ", opaque=" + this.opaque + "}";
/*     */   }
/*     */   
/*     */   protected abstract void flush();
/*     */   
/*     */   protected abstract void disposeGraphics();
/*     */   
/*     */   private native void twkRelease(Object[] paramArrayOfObject);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCRenderQueue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */