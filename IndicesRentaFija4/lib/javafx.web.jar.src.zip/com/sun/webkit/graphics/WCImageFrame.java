package com.sun.webkit.graphics;

public abstract class WCImageFrame extends Ref {
  public abstract WCImage getFrame();
  
  public abstract int[] getSize();
  
  protected void destroyDecodedData() {}
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCImageFrame.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */