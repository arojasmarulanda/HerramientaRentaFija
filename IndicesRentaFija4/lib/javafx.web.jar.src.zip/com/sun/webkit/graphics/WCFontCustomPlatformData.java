package com.sun.webkit.graphics;

public abstract class WCFontCustomPlatformData {
  protected abstract WCFont createFont(int paramInt, boolean paramBoolean1, boolean paramBoolean2);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCFontCustomPlatformData.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */