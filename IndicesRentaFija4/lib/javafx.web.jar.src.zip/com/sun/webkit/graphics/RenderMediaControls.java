/*     */ package com.sun.webkit.graphics;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RenderMediaControls
/*     */ {
/*     */   private static final int PLAY_BUTTON = 1;
/*     */   private static final int PAUSE_BUTTON = 2;
/*     */   private static final int DISABLED_PLAY_BUTTON = 3;
/*     */   private static final int MUTE_BUTTON = 4;
/*     */   private static final int UNMUTE_BUTTON = 5;
/*     */   private static final int DISABLED_MUTE_BUTTON = 6;
/*     */   private static final int TIME_SLIDER_TRACK = 9;
/*     */   private static final int TIME_SLIDER_THUMB = 10;
/*     */   private static final int VOLUME_CONTAINER = 11;
/*     */   private static final int VOLUME_TRACK = 12;
/*     */   private static final int VOLUME_THUMB = 13;
/*     */   
/*     */   private static String getControlName(int paramInt) {
/*  62 */     switch (paramInt) { case 1:
/*  63 */         return "PLAY_BUTTON";
/*  64 */       case 2: return "PAUSE_BUTTON";
/*  65 */       case 3: return "DISABLED_PLAY_BUTTON";
/*     */       case 4:
/*  67 */         return "MUTE_BUTTON";
/*  68 */       case 5: return "UNMUTE_BUTTON";
/*  69 */       case 6: return "DISABLED_MUTE_BUTTON";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 9:
/*  75 */         return "TIME_SLIDER_TRACK";
/*  76 */       case 10: return "TIME_SLIDER_THUMB";
/*     */       case 11:
/*  78 */         return "VOLUME_CONTAINER";
/*  79 */       case 12: return "VOLUME_TRACK";
/*  80 */       case 13: return "VOLUME_THUMB"; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     return "{UNKNOWN CONTROL " + paramInt + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void paintControl(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  97 */     switch (paramInt1) {
/*     */       case 1:
/*  99 */         paintControlImage("mediaPlay", paramWCGraphicsContext, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */         break;
/*     */       case 2:
/* 102 */         paintControlImage("mediaPause", paramWCGraphicsContext, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */         break;
/*     */       case 3:
/* 105 */         paintControlImage("mediaPlayDisabled", paramWCGraphicsContext, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */         break;
/*     */       case 4:
/* 108 */         paintControlImage("mediaMute", paramWCGraphicsContext, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */         break;
/*     */       case 5:
/* 111 */         paintControlImage("mediaUnmute", paramWCGraphicsContext, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */         break;
/*     */       case 6:
/* 114 */         paintControlImage("mediaMuteDisabled", paramWCGraphicsContext, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */         break;
/*     */       case 10:
/* 117 */         paintControlImage("mediaTimeThumb", paramWCGraphicsContext, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 13:
/* 122 */         paintControlImage("mediaVolumeThumb", paramWCGraphicsContext, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   private static final int TimeSliderTrackUnbufferedColor = rgba(236, 135, 125);
/*     */   
/* 133 */   private static final int TimeSliderTrackBufferedColor = rgba(249, 26, 2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int TimeSliderTrackThickness = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void paintTimeSliderTrack(WCGraphicsContext paramWCGraphicsContext, float paramFloat1, float paramFloat2, float[] paramArrayOffloat, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 155 */     paramInt2 += (paramInt4 - 3) / 2;
/* 156 */     paramInt4 = 3;
/*     */     
/* 158 */     int i = fwkGetSliderThumbSize(0) >> 16 & 0xFFFF;
/* 159 */     paramInt3 -= i;
/* 160 */     paramInt1 += i / 2;
/*     */     
/* 162 */     if (paramFloat1 >= 0.0F) {
/*     */ 
/*     */       
/* 165 */       float f1 = 1.0F / paramFloat1 * paramInt3;
/* 166 */       float f2 = 0.0F;
/* 167 */       for (byte b = 0; b < paramArrayOffloat.length; b += 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 173 */         paramWCGraphicsContext.fillRect(paramInt1 + f1 * f2, paramInt2, f1 * (paramArrayOffloat[b] - f2), paramInt4, 
/*     */             
/* 175 */             Integer.valueOf(TimeSliderTrackUnbufferedColor));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 181 */         paramWCGraphicsContext.fillRect(paramInt1 + f1 * paramArrayOffloat[b], paramInt2, f1 * (paramArrayOffloat[b + 1] - paramArrayOffloat[b]), paramInt4, 
/*     */             
/* 183 */             Integer.valueOf(TimeSliderTrackBufferedColor));
/* 184 */         f2 = paramArrayOffloat[b + 1];
/*     */       } 
/* 186 */       if (f2 < paramFloat1)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 192 */         paramWCGraphicsContext.fillRect(paramInt1 + f1 * f2, paramInt2, f1 * (paramFloat1 - f2), paramInt4, 
/*     */             
/* 194 */             Integer.valueOf(TimeSliderTrackUnbufferedColor));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 200 */   private static final int VolumeTrackColor = rgba(208, 208, 208, 128);
/*     */ 
/*     */   
/*     */   private static final int VolumeTrackThickness = 1;
/*     */ 
/*     */   
/*     */   private static final int SLIDER_TYPE_TIME = 0;
/*     */ 
/*     */   
/*     */   private static final int SLIDER_TYPE_VOLUME = 1;
/*     */ 
/*     */   
/*     */   static void paintVolumeTrack(WCGraphicsContext paramWCGraphicsContext, float paramFloat, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 213 */     paramInt1 += (paramInt3 + 1 - 1) / 2;
/* 214 */     paramInt3 = 1;
/*     */     
/* 216 */     int i = fwkGetSliderThumbSize(0) & 0xFFFF;
/* 217 */     paramInt4 -= i;
/* 218 */     paramInt2 += i / 2;
/*     */ 
/*     */     
/* 221 */     paramWCGraphicsContext.fillRect(paramInt1, paramInt2, paramInt3, paramInt4, Integer.valueOf(VolumeTrackColor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int fwkGetSliderThumbSize(int paramInt) {
/* 230 */     WCImage wCImage = null;
/* 231 */     switch (paramInt) {
/*     */       case 0:
/* 233 */         wCImage = getControlImage("mediaTimeThumb");
/*     */         break;
/*     */       case 1:
/* 236 */         wCImage = getControlImage("mediaVolumeThumb");
/*     */         break;
/*     */     } 
/* 239 */     if (wCImage != null) {
/* 240 */       return wCImage.getWidth() << 16 | wCImage.getHeight();
/*     */     }
/* 242 */     return 0;
/*     */   }
/*     */   
/* 245 */   private static final Map<String, WCImage> controlImages = new HashMap<>();
/*     */   private static final boolean log = false;
/*     */   
/*     */   private static WCImage getControlImage(String paramString) {
/* 249 */     WCImage wCImage = controlImages.get(paramString);
/* 250 */     if (wCImage == null) {
/*     */       
/* 252 */       WCImageDecoder wCImageDecoder = WCGraphicsManager.getGraphicsManager().getImageDecoder();
/* 253 */       wCImageDecoder.loadFromResource(paramString);
/* 254 */       WCImageFrame wCImageFrame = wCImageDecoder.getFrame(0);
/* 255 */       if (wCImageFrame != null) {
/* 256 */         wCImage = wCImageFrame.getFrame();
/* 257 */         controlImages.put(paramString, wCImage);
/*     */       } 
/*     */     } 
/* 260 */     return wCImage;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void paintControlImage(String paramString, WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 265 */     WCImage wCImage = getControlImage(paramString);
/* 266 */     if (wCImage != null) {
/*     */       
/* 268 */       paramInt1 += (paramInt3 - wCImage.getWidth()) / 2;
/* 269 */       paramInt3 = wCImage.getWidth();
/* 270 */       paramInt2 += (paramInt4 - wCImage.getHeight()) / 2;
/* 271 */       paramInt4 = wCImage.getHeight();
/* 272 */       paramWCGraphicsContext.drawImage(wCImage, paramInt1, paramInt2, paramInt3, paramInt4, 0.0F, 0.0F, wCImage
/*     */           
/* 274 */           .getWidth(), wCImage.getHeight());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int rgba(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 281 */     return (paramInt4 & 0xFF) << 24 | (paramInt1 & 0xFF) << 16 | (paramInt2 & 0xFF) << 8 | paramInt3 & 0xFF;
/*     */   }
/*     */   private static int rgba(int paramInt1, int paramInt2, int paramInt3) {
/* 284 */     return rgba(paramInt1, paramInt2, paramInt3, 255);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void log(String paramString) {
/* 289 */     System.out.println(paramString);
/* 290 */     System.out.flush();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\graphics\RenderMediaControls.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */