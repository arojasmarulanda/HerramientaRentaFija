package com.sun.webkit;

import java.net.URL;

public interface PolicyClient {
  boolean permitNavigateAction(long paramLong, URL paramURL);
  
  boolean permitRedirectAction(long paramLong, URL paramURL);
  
  boolean permitAcceptResourceAction(long paramLong, URL paramURL);
  
  boolean permitSubmitDataAction(long paramLong, URL paramURL, String paramString);
  
  boolean permitResubmitDataAction(long paramLong, URL paramURL, String paramString);
  
  boolean permitEnableScriptsAction(long paramLong, URL paramURL);
  
  boolean permitNewPageAction(long paramLong, URL paramURL);
  
  boolean permitClosePageAction(long paramLong);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\PolicyClient.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */