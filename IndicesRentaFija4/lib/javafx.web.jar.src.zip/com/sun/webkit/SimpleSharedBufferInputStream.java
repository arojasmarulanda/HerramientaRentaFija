/*    */ package com.sun.webkit;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleSharedBufferInputStream
/*    */   extends InputStream
/*    */ {
/*    */   private final SharedBuffer sharedBuffer;
/*    */   private long position;
/*    */   
/*    */   public SimpleSharedBufferInputStream(SharedBuffer paramSharedBuffer) {
/* 37 */     if (paramSharedBuffer == null) {
/* 38 */       throw new NullPointerException("sharedBuffer is null");
/*    */     }
/* 40 */     this.sharedBuffer = paramSharedBuffer;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int read() {
/* 46 */     byte[] arrayOfByte = new byte[1];
/* 47 */     int i = this.sharedBuffer.getSomeData(this.position, arrayOfByte, 0, 1);
/* 48 */     if (i != 0) {
/* 49 */       this.position++;
/* 50 */       return arrayOfByte[0] & 0xFF;
/*    */     } 
/* 52 */     return -1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 58 */     if (paramArrayOfbyte == null) {
/* 59 */       throw new NullPointerException("b is null");
/*    */     }
/* 61 */     if (paramInt1 < 0) {
/* 62 */       throw new IndexOutOfBoundsException("off is negative");
/*    */     }
/* 64 */     if (paramInt2 < 0) {
/* 65 */       throw new IndexOutOfBoundsException("len is negative");
/*    */     }
/* 67 */     if (paramInt2 > paramArrayOfbyte.length - paramInt1) {
/* 68 */       throw new IndexOutOfBoundsException("len is greater than b.length - off");
/*    */     }
/*    */     
/* 71 */     if (paramInt2 == 0) {
/* 72 */       return 0;
/*    */     }
/* 74 */     int i = this.sharedBuffer.getSomeData(this.position, paramArrayOfbyte, paramInt1, paramInt2);
/* 75 */     if (i != 0) {
/* 76 */       this.position += i;
/* 77 */       return i;
/*    */     } 
/* 79 */     return -1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public long skip(long paramLong) {
/* 85 */     long l = this.sharedBuffer.size() - this.position;
/* 86 */     if (paramLong < l) {
/* 87 */       l = (paramLong < 0L) ? 0L : paramLong;
/*    */     }
/* 89 */     this.position += l;
/* 90 */     return l;
/*    */   }
/*    */ 
/*    */   
/*    */   public int available() {
/* 95 */     return (int)Math.min(this.sharedBuffer.size() - this.position, 2147483647L);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\SimpleSharedBufferInputStream.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */