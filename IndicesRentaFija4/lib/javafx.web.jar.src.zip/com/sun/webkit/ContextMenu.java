/*    */ package com.sun.webkit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ContextMenu
/*    */ {
/*    */   public final class ShowContext
/*    */   {
/*    */     private final WebPage page;
/*    */     private final long pdata;
/*    */     
/*    */     private ShowContext(WebPage param1WebPage, long param1Long) {
/* 43 */       this.page = param1WebPage;
/* 44 */       this.pdata = param1Long;
/*    */     }
/*    */     
/*    */     public WebPage getPage() {
/* 48 */       return this.page;
/*    */     }
/*    */     
/*    */     public void notifyItemSelected(int param1Int) {
/* 52 */       ContextMenu.this.twkHandleItemSelected(this.pdata, param1Int);
/*    */     }
/*    */   }
/*    */   
/*    */   private static ContextMenu fwkCreateContextMenu() {
/* 57 */     return Utilities.getUtilities().createContextMenu();
/*    */   }
/*    */   
/*    */   private void fwkShow(WebPage paramWebPage, long paramLong, int paramInt1, int paramInt2) {
/* 61 */     show(new ShowContext(paramWebPage, paramLong), paramInt1, paramInt2);
/*    */   }
/*    */   
/*    */   private void fwkAppendItem(ContextMenuItem paramContextMenuItem) {
/* 65 */     appendItem(paramContextMenuItem);
/*    */   }
/*    */   
/*    */   private void fwkInsertItem(ContextMenuItem paramContextMenuItem, int paramInt) {
/* 69 */     insertItem(paramContextMenuItem, paramInt);
/*    */   }
/*    */   
/*    */   private int fwkGetItemCount() {
/* 73 */     return getItemCount();
/*    */   }
/*    */   
/*    */   protected abstract void show(ShowContext paramShowContext, int paramInt1, int paramInt2);
/*    */   
/*    */   protected abstract void appendItem(ContextMenuItem paramContextMenuItem);
/*    */   
/*    */   protected abstract void insertItem(ContextMenuItem paramContextMenuItem, int paramInt);
/*    */   
/*    */   protected abstract int getItemCount();
/*    */   
/*    */   private native void twkHandleItemSelected(long paramLong, int paramInt);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\ContextMenu.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */