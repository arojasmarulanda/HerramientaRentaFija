/*    */ package com.sun.webkit;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.AccessControlContext;
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedActionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Utilities
/*    */ {
/*    */   private static Utilities instance;
/*    */   
/*    */   public static synchronized void setUtilities(Utilities paramUtilities) {
/* 42 */     instance = paramUtilities;
/*    */   }
/*    */   
/*    */   public static synchronized Utilities getUtilities() {
/* 46 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   protected abstract Pasteboard createPasteboard();
/*    */ 
/*    */   
/*    */   protected abstract PopupMenu createPopupMenu();
/*    */   
/*    */   protected abstract ContextMenu createContextMenu();
/*    */   
/*    */   private static Object fwkInvokeWithContext(Method paramMethod, Object paramObject, Object[] paramArrayOfObject, AccessControlContext paramAccessControlContext) throws Throwable {
/*    */     try {
/* 59 */       return AccessController.doPrivileged(() -> MethodHelper.invoke(paramMethod, paramObject, paramArrayOfObject), paramAccessControlContext);
/*    */     }
/* 61 */     catch (PrivilegedActionException privilegedActionException) {
/* 62 */       Throwable throwable = privilegedActionException.getCause();
/* 63 */       if (throwable == null) {
/* 64 */         throwable = privilegedActionException;
/* 65 */       } else if (throwable instanceof java.lang.reflect.InvocationTargetException && throwable
/* 66 */         .getCause() != null) {
/* 67 */         throwable = throwable.getCause();
/* 68 */       }  throw throwable;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\Utilities.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */