/*    */ package com.sun.webkit;
/*    */ 
/*    */ import com.sun.webkit.perf.PerfLogger;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Invoker
/*    */ {
/*    */   private static Invoker instance;
/* 34 */   private static final PerfLogger locksLog = PerfLogger.getLogger("Locks");
/*    */   
/*    */   public static synchronized void setInvoker(Invoker paramInvoker) {
/* 37 */     instance = paramInvoker;
/*    */   }
/*    */   
/*    */   public static synchronized Invoker getInvoker() {
/* 41 */     return instance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean lock(ReentrantLock paramReentrantLock) {
/* 50 */     if (paramReentrantLock.getHoldCount() == 0) {
/*    */       
/* 52 */       paramReentrantLock.lock();
/* 53 */       locksLog.resumeCount(isEventThread() ? "EventThread" : "RenderThread");
/* 54 */       return true;
/*    */     } 
/* 56 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean unlock(ReentrantLock paramReentrantLock) {
/* 65 */     if (paramReentrantLock.getHoldCount() != 0) {
/*    */       
/* 67 */       locksLog.suspendCount(isEventThread() ? "EventThread" : "RenderThread");
/* 68 */       paramReentrantLock.unlock();
/* 69 */       return true;
/*    */     } 
/* 71 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract boolean isEventThread();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void checkEventThread() {
/* 83 */     if (!isEventThread())
/* 84 */       throw new IllegalStateException("Current thread is not event thread, current thread: " + 
/* 85 */           Thread.currentThread().getName()); 
/*    */   }
/*    */   
/*    */   public abstract void invokeOnEventThread(Runnable paramRunnable);
/*    */   
/*    */   public abstract void postOnEventThread(Runnable paramRunnable);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\Invoker.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */