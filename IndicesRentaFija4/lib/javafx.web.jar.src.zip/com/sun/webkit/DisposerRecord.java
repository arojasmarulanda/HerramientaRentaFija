package com.sun.webkit;

public interface DisposerRecord {
  void dispose();
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\DisposerRecord.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */