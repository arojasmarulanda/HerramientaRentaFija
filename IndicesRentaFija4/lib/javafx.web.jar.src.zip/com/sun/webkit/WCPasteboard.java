/*    */ package com.sun.webkit;
/*    */ 
/*    */ import com.sun.javafx.logging.PlatformLogger;
/*    */ import com.sun.webkit.graphics.WCImageFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WCPasteboard
/*    */ {
/* 35 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCPasteboard.class.getName());
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   private static final Pasteboard pasteboard = Utilities.getUtilities().createPasteboard();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String getPlainText() {
/* 47 */     log.fine("getPlainText()");
/* 48 */     return pasteboard.getPlainText();
/*    */   }
/*    */   
/*    */   private static String getHtml() {
/* 52 */     log.fine("getHtml()");
/* 53 */     return pasteboard.getHtml();
/*    */   }
/*    */   
/*    */   private static void writePlainText(String paramString) {
/* 57 */     log.fine("writePlainText(): text = {0}", new Object[] { paramString });
/* 58 */     pasteboard.writePlainText(paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   private static void writeSelection(boolean paramBoolean, String paramString1, String paramString2) {
/* 63 */     log.fine("writeSelection(): canSmartCopyOrDelete = {0},\n text = \n{1}\n html=\n{2}", new Object[] {
/* 64 */           Boolean.valueOf(paramBoolean), paramString1, paramString2 });
/* 65 */     pasteboard.writeSelection(paramBoolean, paramString1, paramString2);
/*    */   }
/*    */   
/*    */   private static void writeImage(WCImageFrame paramWCImageFrame) {
/* 69 */     log.fine("writeImage(): img = {0}", new Object[] { paramWCImageFrame });
/* 70 */     pasteboard.writeImage(paramWCImageFrame);
/*    */   }
/*    */   
/*    */   private static void writeUrl(String paramString1, String paramString2) {
/* 74 */     log.fine("writeUrl(): url = {0}, markup = {1}", new Object[] { paramString1, paramString2 });
/*    */     
/* 76 */     pasteboard.writeUrl(paramString1, paramString2);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\WCPasteboard.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */