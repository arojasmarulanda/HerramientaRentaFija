/*    */ package com.sun.webkit;
/*    */ 
/*    */ import com.sun.webkit.graphics.RenderTheme;
/*    */ import com.sun.webkit.graphics.ScrollBarTheme;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ThemeClient
/*    */ {
/*    */   private static RenderTheme defaultRenderTheme;
/*    */   
/*    */   public static void setDefaultRenderTheme(RenderTheme paramRenderTheme) {
/* 36 */     defaultRenderTheme = paramRenderTheme;
/*    */   }
/*    */   
/*    */   public static RenderTheme getDefaultRenderTheme() {
/* 40 */     return defaultRenderTheme;
/*    */   }
/*    */   
/*    */   protected abstract RenderTheme createRenderTheme();
/*    */   
/*    */   protected abstract ScrollBarTheme createScrollBarTheme();
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\ThemeClient.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */