/*      */ package com.sun.webkit;
/*      */ 
/*      */ import com.sun.glass.utils.NativeLibLoader;
/*      */ import com.sun.javafx.logging.PlatformLogger;
/*      */ import com.sun.webkit.event.WCFocusEvent;
/*      */ import com.sun.webkit.event.WCInputMethodEvent;
/*      */ import com.sun.webkit.event.WCKeyEvent;
/*      */ import com.sun.webkit.event.WCMouseEvent;
/*      */ import com.sun.webkit.event.WCMouseWheelEvent;
/*      */ import com.sun.webkit.graphics.RenderTheme;
/*      */ import com.sun.webkit.graphics.ScrollBarTheme;
/*      */ import com.sun.webkit.graphics.WCGraphicsContext;
/*      */ import com.sun.webkit.graphics.WCGraphicsManager;
/*      */ import com.sun.webkit.graphics.WCImage;
/*      */ import com.sun.webkit.graphics.WCPageBackBuffer;
/*      */ import com.sun.webkit.graphics.WCPoint;
/*      */ import com.sun.webkit.graphics.WCRectangle;
/*      */ import com.sun.webkit.graphics.WCRenderQueue;
/*      */ import com.sun.webkit.graphics.WCSize;
/*      */ import com.sun.webkit.network.CookieManager;
/*      */ import com.sun.webkit.network.URLs;
/*      */ import java.net.CookieHandler;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessController;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Queue;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.FutureTask;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import javafx.application.ConditionalFeature;
/*      */ import javafx.application.Platform;
/*      */ import netscape.javascript.JSException;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class WebPage
/*      */ {
/*   81 */   private static final PlatformLogger log = PlatformLogger.getLogger(WebPage.class.getName());
/*   82 */   private static final PlatformLogger paintLog = PlatformLogger.getLogger(WebPage.class.getName() + ".paint");
/*      */ 
/*      */   
/*      */   private static final int MAX_FRAME_QUEUE_SIZE = 10;
/*      */   
/*   87 */   private long pPage = 0L;
/*      */ 
/*      */   
/*      */   private boolean isDisposed = false;
/*      */   
/*      */   private int width;
/*      */   
/*      */   private int height;
/*      */   
/*      */   private int fontSmoothingType;
/*      */   
/*      */   private final WCFrameView hostWindow;
/*      */   
/*  100 */   private final Set<Long> frames = new HashSet<>();
/*      */ 
/*      */   
/*      */   private final AccessControlContext accessControlContext;
/*      */ 
/*      */   
/*  106 */   private final Map<Integer, String> requestURLs = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  111 */   private final Set<Integer> requestStarted = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  117 */   private static final ReentrantLock PAGE_LOCK = new ReentrantLock();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  122 */   private final Queue<RenderFrame> frameQueue = new LinkedList<>();
/*      */ 
/*      */ 
/*      */   
/*  126 */   private RenderFrame currentFrame = new RenderFrame();
/*      */   
/*      */   private int updateContentCycleID;
/*      */ 
/*      */   
/*      */   static {
/*  132 */     AccessController.doPrivileged(() -> {
/*      */           NativeLibLoader.loadLibrary("jfxwebkit");
/*      */ 
/*      */           
/*      */           log.finer("jfxwebkit loaded");
/*      */ 
/*      */           
/*      */           if (CookieHandler.getDefault() == null) {
/*      */             boolean bool = Boolean.valueOf(System.getProperty("com.sun.webkit.setDefaultCookieHandler", "true")).booleanValue();
/*      */             
/*      */             if (bool) {
/*      */               CookieHandler.setDefault(new CookieManager());
/*      */             }
/*      */           } 
/*      */           
/*      */           boolean bool1 = Boolean.valueOf(System.getProperty("com.sun.webkit.useJIT", "true")).booleanValue();
/*      */           
/*      */           boolean bool2 = Boolean.valueOf(System.getProperty("com.sun.webkit.useDFGJIT", "true")).booleanValue();
/*      */           
/*      */           boolean bool3 = Boolean.valueOf(System.getProperty("com.sun.webkit.useCSS3D", "false")).booleanValue();
/*      */           
/*  153 */           bool3 = (bool3 && Platform.isSupported(ConditionalFeature.SCENE3D));
/*      */           twkInitWebCore(bool1, bool2, bool3);
/*      */           return null;
/*      */         });
/*      */   }
/*      */   private static boolean firstWebPageCreated = false; private WCPageBackBuffer backbuffer; private List<WCRectangle> dirtyRects; private final WebPageClient pageClient; private final UIClient uiClient; private final PolicyClient policyClient; private InputMethodClient imClient; private final List<LoadListenerClient> loadListenerClients; private final InspectorClient inspectorClient; private final RenderTheme renderTheme; private final ScrollBarTheme scrollbarTheme; public static final int DND_DST_ENTER = 0; public static final int DND_DST_OVER = 1; public static final int DND_DST_CHANGE = 2; public static final int DND_DST_EXIT = 3; public static final int DND_DST_DROP = 4; public static final int DND_SRC_ENTER = 100;
/*      */   public static final int DND_SRC_OVER = 101;
/*      */   public static final int DND_SRC_CHANGE = 102;
/*      */   public static final int DND_SRC_EXIT = 103;
/*      */   public static final int DND_SRC_DROP = 104;
/*      */   
/*      */   private static void collectJSCGarbages() {
/*  165 */     Invoker.getInvoker().checkEventThread();
/*      */ 
/*      */     
/*  168 */     Disposer.addRecord(new Object(), WebPage::collectJSCGarbages);
/*      */     
/*  170 */     twkDoJSCGarbageCollection();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long getPage() {
/*  215 */     return this.pPage;
/*      */   }
/*      */ 
/*      */   
/*      */   private WCWidget getHostWindow() {
/*  220 */     return this.hostWindow;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AccessControlContext getAccessControlContext() {
/*  229 */     return this.accessControlContext;
/*      */   }
/*      */   
/*      */   static boolean lockPage() {
/*  233 */     return Invoker.getInvoker().lock(PAGE_LOCK);
/*      */   }
/*      */   
/*      */   static boolean unlockPage() {
/*  237 */     return Invoker.getInvoker().unlock(PAGE_LOCK);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebPage(WebPageClient paramWebPageClient, UIClient paramUIClient, PolicyClient paramPolicyClient, InspectorClient paramInspectorClient, ThemeClient paramThemeClient, boolean paramBoolean) {
/*  245 */     this.dirtyRects = new LinkedList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  485 */     this.loadListenerClients = new LinkedList<>(); Invoker.getInvoker().checkEventThread(); this.pageClient = paramWebPageClient; this.uiClient = paramUIClient; this.policyClient = paramPolicyClient; this.inspectorClient = paramInspectorClient; if (paramThemeClient != null) { this.renderTheme = paramThemeClient.createRenderTheme(); this.scrollbarTheme = paramThemeClient.createScrollBarTheme(); } else { this.renderTheme = null; this.scrollbarTheme = null; }  this.accessControlContext = AccessController.getContext(); this.hostWindow = new WCFrameView(this); this.pPage = twkCreatePage(paramBoolean); twkInit(this.pPage, false, WCGraphicsManager.getGraphicsManager().getDevicePixelScale()); if (paramWebPageClient != null && paramWebPageClient.isBackBufferSupported()) { this.backbuffer = paramWebPageClient.createBackBuffer(); this.backbuffer.ref(); }  if (!firstWebPageCreated) { Disposer.addRecord(new Object(), WebPage::collectJSCGarbages); firstWebPageCreated = true; } 
/*      */   }
/*      */   private void addDirtyRect(WCRectangle paramWCRectangle) { if (paramWCRectangle.getWidth() <= 0.0F || paramWCRectangle.getHeight() <= 0.0F)
/*      */       return;  for (Iterator<WCRectangle> iterator = this.dirtyRects.iterator(); iterator.hasNext(); ) { WCRectangle wCRectangle1 = iterator.next(); if (wCRectangle1.contains(paramWCRectangle))
/*      */         return;  if (paramWCRectangle.contains(wCRectangle1)) { iterator.remove(); continue; }  WCRectangle wCRectangle2 = wCRectangle1.createUnion(paramWCRectangle); if (wCRectangle2.getIntWidth() * wCRectangle2.getIntHeight() < wCRectangle1.getIntWidth() * wCRectangle1.getIntHeight() + paramWCRectangle.getIntWidth() * paramWCRectangle.getIntHeight()) { iterator.remove(); paramWCRectangle = wCRectangle2; }  }
/*      */      this.dirtyRects.add(paramWCRectangle); } public boolean isDirty() { lockPage(); try { return !this.dirtyRects.isEmpty(); }
/*      */     finally { unlockPage(); }
/*  492 */      } public WebPageClient getPageClient() { return this.pageClient; }
/*      */   private void updateDirty(WCRectangle paramWCRectangle) { if (paintLog.isLoggable(PlatformLogger.Level.FINEST)) paintLog.finest("Entering, dirtyRects: {0}, currentFrame: {1}", new Object[] { this.dirtyRects, this.currentFrame });  if (this.isDisposed || this.width <= 0 || this.height <= 0) { this.dirtyRects.clear(); return; }  if (paramWCRectangle == null) paramWCRectangle = new WCRectangle(0.0F, 0.0F, this.width, this.height);  List<WCRectangle> list = this.dirtyRects; this.dirtyRects = new LinkedList<>(); twkPrePaint(getPage()); while (!list.isEmpty()) { WCRectangle wCRectangle = ((WCRectangle)list.remove(0)).intersection(paramWCRectangle); if (wCRectangle.getWidth() <= 0.0F || wCRectangle.getHeight() <= 0.0F) continue;  paintLog.finest("Updating: {0}", new Object[] { wCRectangle }); WCRenderQueue wCRenderQueue1 = WCGraphicsManager.getGraphicsManager().createRenderQueue(wCRectangle, true); twkUpdateContent(getPage(), wCRenderQueue1, wCRectangle.getIntX() - 1, wCRectangle.getIntY() - 1, wCRectangle.getIntWidth() + 2, wCRectangle.getIntHeight() + 2); this.currentFrame.addRenderQueue(wCRenderQueue1); }  WCRenderQueue wCRenderQueue = WCGraphicsManager.getGraphicsManager().createRenderQueue(paramWCRectangle, false); twkPostPaint(getPage(), wCRenderQueue, paramWCRectangle.getIntX(), paramWCRectangle.getIntY(), paramWCRectangle.getIntWidth(), paramWCRectangle.getIntHeight()); this.currentFrame.addRenderQueue(wCRenderQueue); if (paintLog.isLoggable(PlatformLogger.Level.FINEST)) paintLog.finest("Dirty rects processed, dirtyRects: {0}, currentFrame: {1}", new Object[] { this.dirtyRects, this.currentFrame });  if (this.currentFrame.getRQList().size() > 0) synchronized (this.frameQueue) { paintLog.finest("About to update frame queue, frameQueue: {0}", new Object[] { this.frameQueue }); Iterator<RenderFrame> iterator = this.frameQueue.iterator(); while (iterator.hasNext()) { RenderFrame renderFrame = iterator.next(); for (WCRenderQueue wCRenderQueue1 : this.currentFrame.getRQList()) { WCRectangle wCRectangle = wCRenderQueue1.getClip(); if (wCRenderQueue1.isOpaque() && wCRectangle.contains(renderFrame.getEnclosingRect())) { paintLog.finest("Dropping: {0}", new Object[] { renderFrame }); renderFrame.drop(); iterator.remove(); }  }  }  this.frameQueue.add(this.currentFrame); this.currentFrame = new RenderFrame(); if (this.frameQueue.size() > 10) { paintLog.finest("Frame queue exceeded maximum size, clearing and requesting full repaint"); dropRenderFrames(); repaintAll(); }  paintLog.finest("Frame queue updated, frameQueue: {0}", new Object[] { this.frameQueue }); }   if (paintLog.isLoggable(PlatformLogger.Level.FINEST)) paintLog.finest("Exiting, dirtyRects: {0}, currentFrame: {1}", new Object[] { this.dirtyRects, this.currentFrame });  }
/*      */   private void scroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { if (paintLog.isLoggable(PlatformLogger.Level.FINEST)) paintLog.finest("rect=[" + paramInt1 + ", " + paramInt2 + " " + paramInt3 + "x" + paramInt4 + "] delta=[" + paramInt5 + ", " + paramInt6 + "]");  paramInt5 += this.currentFrame.scrollDx; paramInt6 += this.currentFrame.scrollDy; if (Math.abs(paramInt5) < paramInt3 && Math.abs(paramInt6) < paramInt4) { int i = (paramInt5 >= 0) ? paramInt1 : (paramInt1 - paramInt5); int j = (paramInt6 >= 0) ? paramInt2 : (paramInt2 - paramInt6); int k = (paramInt5 == 0) ? paramInt3 : (paramInt3 - Math.abs(paramInt5)); int m = (paramInt6 == 0) ? paramInt4 : (paramInt4 - Math.abs(paramInt6)); WCRenderQueue wCRenderQueue = WCGraphicsManager.getGraphicsManager().createRenderQueue(new WCRectangle(0.0F, 0.0F, this.width, this.height), false); ByteBuffer byteBuffer = ByteBuffer.allocate(32).order(ByteOrder.nativeOrder()).putInt(40).putInt(this.backbuffer.getID()).putInt(i).putInt(j).putInt(k).putInt(m).putInt(paramInt5).putInt(paramInt6); byteBuffer.flip(); wCRenderQueue.addBuffer(byteBuffer); this.currentFrame.drop(); this.currentFrame.addRenderQueue(wCRenderQueue); this.currentFrame.scrollDx = paramInt5; this.currentFrame.scrollDy = paramInt6; if (!this.dirtyRects.isEmpty()) { WCRectangle wCRectangle = new WCRectangle(paramInt1, paramInt2, paramInt3, paramInt4); for (WCRectangle wCRectangle1 : this.dirtyRects) { if (wCRectangle.contains(wCRectangle1)) { if (paintLog.isLoggable(PlatformLogger.Level.FINEST)) paintLog.finest("translating old dirty rect by the delta: " + wCRectangle1);  wCRectangle1.translate(paramInt5, paramInt6); }  }  }  }  addDirtyRect(new WCRectangle(paramInt1, (paramInt6 >= 0) ? paramInt2 : (paramInt2 + paramInt4 + paramInt6), paramInt3, Math.abs(paramInt6))); addDirtyRect(new WCRectangle((paramInt5 >= 0) ? paramInt1 : (paramInt1 + paramInt3 + paramInt5), paramInt2, Math.abs(paramInt5), (paramInt4 - Math.abs(paramInt6)))); }
/*      */   private static final class RenderFrame {
/*  496 */     private final List<WCRenderQueue> rqList = new LinkedList<>(); private int scrollDx; private int scrollDy; private final WCRectangle enclosingRect = new WCRectangle(); private void addRenderQueue(WCRenderQueue param1WCRenderQueue) { if (param1WCRenderQueue.isEmpty()) return;  this.rqList.add(param1WCRenderQueue); WCRectangle wCRectangle = param1WCRenderQueue.getClip(); if (this.enclosingRect.isEmpty()) { this.enclosingRect.setFrame(wCRectangle.getX(), wCRectangle.getY(), wCRectangle.getWidth(), wCRectangle.getHeight()); } else if (!wCRectangle.isEmpty()) { WCRectangle.union(this.enclosingRect, wCRectangle, this.enclosingRect); }  } private List<WCRenderQueue> getRQList() { return this.rqList; } private WCRectangle getEnclosingRect() { return this.enclosingRect; } private void drop() { for (WCRenderQueue wCRenderQueue : this.rqList) wCRenderQueue.dispose();  this.rqList.clear(); this.enclosingRect.setFrame(0.0F, 0.0F, 0.0F, 0.0F); this.scrollDx = 0; this.scrollDy = 0; } public String toString() { return "RenderFrame{rqList=" + this.rqList + ", enclosingRect=" + this.enclosingRect + "}"; } private RenderFrame() {} } public void setInputMethodClient(InputMethodClient paramInputMethodClient) { this.imClient = paramInputMethodClient; }
/*      */ 
/*      */   
/*      */   public void setInputMethodState(boolean paramBoolean) {
/*  500 */     if (this.imClient != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  506 */       this.imClient.activateInputMethods(paramBoolean);
/*      */     }
/*      */   }
/*      */   
/*      */   public void addLoadListenerClient(LoadListenerClient paramLoadListenerClient) {
/*  511 */     if (!this.loadListenerClients.contains(paramLoadListenerClient)) {
/*  512 */       this.loadListenerClients.add(paramLoadListenerClient);
/*      */     }
/*      */   }
/*      */   
/*      */   private RenderTheme getRenderTheme() {
/*  517 */     return this.renderTheme;
/*      */   }
/*      */   
/*      */   private static RenderTheme fwkGetDefaultRenderTheme() {
/*  521 */     return ThemeClient.getDefaultRenderTheme();
/*      */   }
/*      */   
/*      */   private ScrollBarTheme getScrollBarTheme() {
/*  525 */     return this.scrollbarTheme;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  533 */     lockPage();
/*      */     try {
/*  535 */       log.fine("setBounds: " + paramInt1 + " " + paramInt2 + " " + paramInt3 + " " + paramInt4);
/*  536 */       if (this.isDisposed) {
/*  537 */         log.fine("setBounds() request for a disposed web page.");
/*      */         return;
/*      */       } 
/*  540 */       this.width = paramInt3;
/*  541 */       this.height = paramInt4;
/*  542 */       twkSetBounds(getPage(), 0, 0, paramInt3, paramInt4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  560 */       repaintAll();
/*      */     } finally {
/*      */       
/*  563 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setOpaque(long paramLong, boolean paramBoolean) {
/*  568 */     lockPage();
/*      */     try {
/*  570 */       log.fine("setOpaque: " + paramBoolean);
/*  571 */       if (this.isDisposed) {
/*  572 */         log.fine("setOpaque() request for a disposed web page.");
/*      */         return;
/*      */       } 
/*  575 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/*      */         return;
/*      */       }
/*  578 */       twkSetTransparent(paramLong, !paramBoolean);
/*      */     } finally {
/*      */       
/*  581 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setBackgroundColor(long paramLong, int paramInt) {
/*  586 */     lockPage();
/*      */     try {
/*  588 */       log.fine("setBackgroundColor: " + paramInt);
/*  589 */       if (this.isDisposed) {
/*  590 */         log.fine("setBackgroundColor() request for a disposed web page.");
/*      */         return;
/*      */       } 
/*  593 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/*      */         return;
/*      */       }
/*  596 */       twkSetBackgroundColor(paramLong, paramInt);
/*      */     } finally {
/*      */       
/*  599 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setBackgroundColor(int paramInt) {
/*  604 */     lockPage();
/*      */     try {
/*  606 */       log.fine("setBackgroundColor: " + paramInt + " for all frames");
/*      */       
/*  608 */       if (this.isDisposed) {
/*  609 */         log.fine("setBackgroundColor() request for a disposed web page.");
/*      */         
/*      */         return;
/*      */       } 
/*  613 */       for (Iterator<Long> iterator = this.frames.iterator(); iterator.hasNext(); ) { long l = ((Long)iterator.next()).longValue();
/*  614 */         twkSetBackgroundColor(l, paramInt); }
/*      */     
/*      */     } finally {
/*      */       
/*  618 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateContent(WCRectangle paramWCRectangle) {
/*  626 */     lockPage();
/*      */     try {
/*  628 */       this.updateContentCycleID++;
/*      */       
/*  630 */       paintLog.finest("toPaint: {0}", new Object[] { paramWCRectangle });
/*  631 */       if (this.isDisposed) {
/*  632 */         paintLog.fine("updateContent() request for a disposed web page.");
/*      */         return;
/*      */       } 
/*  635 */       updateDirty(paramWCRectangle);
/*      */     } finally {
/*      */       
/*  638 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getUpdateContentCycleID() {
/*  643 */     return this.updateContentCycleID;
/*      */   }
/*      */   
/*      */   public boolean isRepaintPending() {
/*  647 */     lockPage();
/*      */ 
/*      */     
/*      */     try {
/*      */     
/*      */     } finally {
/*  653 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void print(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  663 */     lockPage();
/*      */     
/*      */     try {
/*  666 */       WCRenderQueue wCRenderQueue = WCGraphicsManager.getGraphicsManager().createRenderQueue(new WCRectangle(paramInt1, paramInt2, paramInt3, paramInt4), true);
/*  667 */       FutureTask futureTask = new FutureTask(() -> twkUpdateContent(getPage(), paramWCRenderQueue, paramInt1, paramInt2, paramInt3, paramInt4), null);
/*      */ 
/*      */       
/*  670 */       Invoker.getInvoker().invokeOnEventThread(futureTask);
/*      */ 
/*      */       
/*      */       try {
/*  674 */         futureTask.get();
/*  675 */       } catch (ExecutionException executionException) {
/*  676 */         throw new AssertionError(executionException);
/*  677 */       } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */ 
/*      */       
/*  681 */       wCRenderQueue.decode(paramWCGraphicsContext);
/*      */     } finally {
/*  683 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void paint(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  691 */     lockPage();
/*      */     try {
/*  693 */       if (this.pageClient != null && this.pageClient.isBackBufferSupported()) {
/*  694 */         if (!this.backbuffer.validate(this.width, this.height)) {
/*      */           
/*  696 */           Invoker.getInvoker().invokeOnEventThread(() -> repaintAll());
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  701 */         WCGraphicsContext wCGraphicsContext = this.backbuffer.createGraphics();
/*      */         try {
/*  703 */           paint2GC(wCGraphicsContext);
/*  704 */           wCGraphicsContext.flush();
/*      */         } finally {
/*  706 */           this.backbuffer.disposeGraphics(wCGraphicsContext);
/*      */         } 
/*  708 */         this.backbuffer.flush(paramWCGraphicsContext, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */       } else {
/*  710 */         paint2GC(paramWCGraphicsContext);
/*      */       } 
/*      */     } finally {
/*  713 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   private void paint2GC(WCGraphicsContext paramWCGraphicsContext) {
/*      */     ArrayList<RenderFrame> arrayList;
/*  718 */     paintLog.finest("Entering");
/*  719 */     paramWCGraphicsContext.setFontSmoothingType(this.fontSmoothingType);
/*      */ 
/*      */     
/*  722 */     synchronized (this.frameQueue) {
/*  723 */       arrayList = new ArrayList<>(this.frameQueue);
/*  724 */       this.frameQueue.clear();
/*      */     } 
/*      */     
/*  727 */     paintLog.finest("Frames to render: {0}", new Object[] { arrayList });
/*      */     
/*  729 */     for (RenderFrame renderFrame : arrayList) {
/*  730 */       paintLog.finest("Rendering: {0}", new Object[] { renderFrame });
/*  731 */       for (WCRenderQueue wCRenderQueue : renderFrame.getRQList()) {
/*  732 */         paramWCGraphicsContext.saveState();
/*  733 */         if (wCRenderQueue.getClip() != null) {
/*  734 */           paramWCGraphicsContext.setClip(wCRenderQueue.getClip());
/*      */         }
/*  736 */         wCRenderQueue.decode(paramWCGraphicsContext);
/*  737 */         paramWCGraphicsContext.restoreState();
/*      */       } 
/*      */     } 
/*  740 */     paintLog.finest("Exiting");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dropRenderFrames() {
/*  747 */     lockPage();
/*      */     try {
/*  749 */       this.currentFrame.drop();
/*  750 */       synchronized (this.frameQueue) {
/*  751 */         for (RenderFrame renderFrame = this.frameQueue.poll(); renderFrame != null; renderFrame = this.frameQueue.poll()) {
/*  752 */           renderFrame.drop();
/*      */         }
/*      */       } 
/*      */     } finally {
/*  756 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void dispatchFocusEvent(WCFocusEvent paramWCFocusEvent) {
/*  761 */     lockPage();
/*      */     try {
/*  763 */       log.finest("dispatchFocusEvent: " + paramWCFocusEvent);
/*  764 */       if (this.isDisposed) {
/*  765 */         log.fine("Focus event for a disposed web page.");
/*      */         return;
/*      */       } 
/*  768 */       twkProcessFocusEvent(getPage(), paramWCFocusEvent.getID(), paramWCFocusEvent.getDirection());
/*      */     } finally {
/*      */       
/*  771 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean dispatchKeyEvent(WCKeyEvent paramWCKeyEvent) {
/*  776 */     lockPage();
/*      */     try {
/*  778 */       log.finest("dispatchKeyEvent: " + paramWCKeyEvent);
/*  779 */       if (this.isDisposed) {
/*  780 */         log.fine("Key event for a disposed web page.");
/*  781 */         return false;
/*      */       } 
/*  783 */       if (WCKeyEvent.filterEvent(paramWCKeyEvent)) {
/*  784 */         log.finest("filtered");
/*  785 */         return false;
/*      */       } 
/*  787 */       return twkProcessKeyEvent(getPage(), paramWCKeyEvent.getType(), paramWCKeyEvent.getText(), paramWCKeyEvent
/*  788 */           .getKeyIdentifier(), paramWCKeyEvent
/*  789 */           .getWindowsVirtualKeyCode(), paramWCKeyEvent
/*  790 */           .isShiftDown(), paramWCKeyEvent.isCtrlDown(), paramWCKeyEvent
/*  791 */           .isAltDown(), paramWCKeyEvent.isMetaDown(), paramWCKeyEvent.getWhen() / 1000.0D);
/*      */     } finally {
/*  793 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean dispatchMouseEvent(WCMouseEvent paramWCMouseEvent) {
/*  798 */     lockPage();
/*      */     try {
/*  800 */       log.finest("dispatchMouseEvent: " + paramWCMouseEvent.getX() + "," + paramWCMouseEvent.getY());
/*  801 */       if (this.isDisposed) {
/*  802 */         log.fine("Mouse event for a disposed web page.");
/*  803 */         return false;
/*      */       } 
/*      */       
/*  806 */       return (!isDragConfirmed() && 
/*      */ 
/*      */         
/*  809 */         twkProcessMouseEvent(getPage(), paramWCMouseEvent.getID(), paramWCMouseEvent
/*  810 */           .getButton(), paramWCMouseEvent.getClickCount(), paramWCMouseEvent
/*  811 */           .getX(), paramWCMouseEvent.getY(), paramWCMouseEvent.getScreenX(), paramWCMouseEvent.getScreenY(), paramWCMouseEvent
/*  812 */           .isShiftDown(), paramWCMouseEvent.isControlDown(), paramWCMouseEvent.isAltDown(), paramWCMouseEvent.isMetaDown(), paramWCMouseEvent.isPopupTrigger(), paramWCMouseEvent
/*  813 */           .getWhen() / 1000.0D));
/*      */     } finally {
/*  815 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean dispatchMouseWheelEvent(WCMouseWheelEvent paramWCMouseWheelEvent) {
/*  820 */     lockPage();
/*      */     try {
/*  822 */       log.finest("dispatchMouseWheelEvent: " + paramWCMouseWheelEvent);
/*  823 */       if (this.isDisposed) {
/*  824 */         log.fine("MouseWheel event for a disposed web page.");
/*  825 */         return false;
/*      */       } 
/*  827 */       return twkProcessMouseWheelEvent(getPage(), paramWCMouseWheelEvent
/*  828 */           .getX(), paramWCMouseWheelEvent.getY(), paramWCMouseWheelEvent.getScreenX(), paramWCMouseWheelEvent.getScreenY(), paramWCMouseWheelEvent
/*  829 */           .getDeltaX(), paramWCMouseWheelEvent.getDeltaY(), paramWCMouseWheelEvent
/*  830 */           .isShiftDown(), paramWCMouseWheelEvent.isControlDown(), paramWCMouseWheelEvent.isAltDown(), paramWCMouseWheelEvent.isMetaDown(), paramWCMouseWheelEvent
/*  831 */           .getWhen() / 1000.0D);
/*      */     } finally {
/*  833 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean dispatchInputMethodEvent(WCInputMethodEvent paramWCInputMethodEvent) {
/*  838 */     lockPage();
/*      */     try {
/*  840 */       log.finest("dispatchInputMethodEvent: " + paramWCInputMethodEvent);
/*  841 */       if (this.isDisposed) {
/*  842 */         log.fine("InputMethod event for a disposed web page.");
/*  843 */         return false;
/*      */       } 
/*  845 */       switch (paramWCInputMethodEvent.getID()) {
/*      */         case 0:
/*  847 */           bool = twkProcessInputTextChange(getPage(), paramWCInputMethodEvent
/*  848 */               .getComposed(), paramWCInputMethodEvent.getCommitted(), paramWCInputMethodEvent
/*  849 */               .getAttributes(), paramWCInputMethodEvent.getCaretPosition());
/*      */           return bool;
/*      */         case 1:
/*  852 */           bool = twkProcessCaretPositionChange(getPage(), paramWCInputMethodEvent
/*  853 */               .getCaretPosition()); return bool;
/*      */       } 
/*  855 */       boolean bool = false; return bool;
/*      */     } finally {
/*      */       
/*  858 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int dispatchDragOperation(int paramInt1, String[] paramArrayOfString1, String[] paramArrayOfString2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  881 */     lockPage();
/*      */     try {
/*  883 */       log.finest("dispatchDragOperation: " + paramInt2 + "," + paramInt3 + " dndCommand:" + paramInt1 + " dndAction" + paramInt6);
/*      */ 
/*      */       
/*  886 */       if (this.isDisposed) {
/*  887 */         log.fine("DnD event for a disposed web page.");
/*  888 */         return 0;
/*      */       } 
/*  890 */       return twkProcessDrag(getPage(), paramInt1, paramArrayOfString1, paramArrayOfString2, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */       
/*  897 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void confirmStartDrag() {
/*  902 */     if (this.uiClient != null)
/*  903 */       this.uiClient.confirmStartDrag(); 
/*      */   }
/*      */   
/*      */   public boolean isDragConfirmed() {
/*  907 */     return (this.uiClient != null) ? 
/*  908 */       this.uiClient.isDragConfirmed() : false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getClientTextLocation(int paramInt) {
/*  917 */     lockPage();
/*      */     try {
/*  919 */       if (this.isDisposed) {
/*  920 */         log.fine("getClientTextLocation() request for a disposed web page.");
/*  921 */         return new int[] { 0, 0, 0, 0 };
/*      */       } 
/*  923 */       Invoker.getInvoker().checkEventThread();
/*  924 */       return twkGetTextLocation(getPage(), paramInt);
/*      */     } finally {
/*      */       
/*  927 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getClientLocationOffset(int paramInt1, int paramInt2) {
/*  932 */     lockPage();
/*      */     try {
/*  934 */       if (this.isDisposed) {
/*  935 */         log.fine("getClientLocationOffset() request for a disposed web page.");
/*  936 */         return 0;
/*      */       } 
/*  938 */       Invoker.getInvoker().checkEventThread();
/*  939 */       return twkGetInsertPositionOffset(getPage());
/*      */     } finally {
/*      */       
/*  942 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getClientInsertPositionOffset() {
/*  947 */     lockPage();
/*      */     try {
/*  949 */       if (this.isDisposed) {
/*  950 */         log.fine("getClientInsertPositionOffset() request for a disposed web page.");
/*  951 */         return 0;
/*      */       } 
/*  953 */       return twkGetInsertPositionOffset(getPage());
/*      */     } finally {
/*      */       
/*  956 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getClientCommittedTextLength() {
/*  961 */     lockPage();
/*      */     try {
/*  963 */       if (this.isDisposed) {
/*  964 */         log.fine("getClientCommittedTextOffset() request for a disposed web page.");
/*  965 */         return 0;
/*      */       } 
/*  967 */       return twkGetCommittedTextLength(getPage());
/*      */     } finally {
/*      */       
/*  970 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getClientCommittedText() {
/*  975 */     lockPage();
/*      */     try {
/*  977 */       if (this.isDisposed) {
/*  978 */         log.fine("getClientCommittedText() request for a disposed web page.");
/*  979 */         return "";
/*      */       } 
/*  981 */       return twkGetCommittedText(getPage());
/*      */     } finally {
/*      */       
/*  984 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getClientSelectedText() {
/*  989 */     lockPage();
/*      */     try {
/*  991 */       if (this.isDisposed) {
/*  992 */         log.fine("getClientSelectedText() request for a disposed web page.");
/*  993 */         return "";
/*      */       } 
/*  995 */       return twkGetSelectedText(getPage());
/*      */     } finally {
/*      */       
/*  998 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose() {
/* 1007 */     lockPage();
/*      */     try {
/* 1009 */       log.finer("dispose");
/*      */       
/* 1011 */       stop();
/* 1012 */       dropRenderFrames();
/* 1013 */       this.isDisposed = true;
/*      */       
/* 1015 */       twkDestroyPage(this.pPage);
/* 1016 */       this.pPage = 0L;
/*      */       
/* 1018 */       for (Iterator<Long> iterator = this.frames.iterator(); iterator.hasNext(); ) { long l = ((Long)iterator.next()).longValue();
/* 1019 */         log.fine("Undestroyed frame view: " + l); }
/*      */       
/* 1021 */       this.frames.clear();
/*      */       
/* 1023 */       if (this.backbuffer != null) {
/* 1024 */         this.backbuffer.deref();
/* 1025 */         this.backbuffer = null;
/*      */       } 
/*      */     } finally {
/* 1028 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getName(long paramLong) {
/* 1033 */     lockPage();
/*      */     try {
/* 1035 */       log.fine("Get Name: frame = " + paramLong);
/* 1036 */       if (this.isDisposed) {
/* 1037 */         log.fine("getName() request for a disposed web page.");
/* 1038 */         return null;
/*      */       } 
/* 1040 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1041 */         return null;
/*      */       }
/* 1043 */       return twkGetName(paramLong);
/*      */     } finally {
/*      */       
/* 1046 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getURL(long paramLong) {
/* 1051 */     lockPage();
/*      */     try {
/* 1053 */       log.fine("Get URL: frame = " + paramLong);
/* 1054 */       if (this.isDisposed) {
/* 1055 */         log.fine("getURL() request for a disposed web page.");
/* 1056 */         return null;
/*      */       } 
/* 1058 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1059 */         return null;
/*      */       }
/* 1061 */       return twkGetURL(paramLong);
/*      */     } finally {
/*      */       
/* 1064 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getEncoding() {
/* 1069 */     lockPage();
/*      */     try {
/* 1071 */       log.fine("Get encoding");
/* 1072 */       if (this.isDisposed) {
/* 1073 */         log.fine("getEncoding() request for a disposed web page.");
/* 1074 */         return null;
/*      */       } 
/* 1076 */       return twkGetEncoding(getPage());
/*      */     } finally {
/*      */       
/* 1079 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setEncoding(String paramString) {
/* 1084 */     lockPage();
/*      */     try {
/* 1086 */       log.fine("Set encoding: encoding = " + paramString);
/* 1087 */       if (this.isDisposed) {
/* 1088 */         log.fine("setEncoding() request for a disposed web page.");
/*      */         return;
/*      */       } 
/* 1091 */       if (paramString != null && !paramString.isEmpty()) {
/* 1092 */         twkSetEncoding(getPage(), paramString);
/*      */       }
/*      */     } finally {
/*      */       
/* 1096 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getInnerText(long paramLong) {
/* 1102 */     lockPage();
/*      */     try {
/* 1104 */       log.fine("Get inner text: frame = " + paramLong);
/* 1105 */       if (this.isDisposed) {
/* 1106 */         log.fine("getInnerText() request for a disposed web page.");
/* 1107 */         return null;
/*      */       } 
/* 1109 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1110 */         return null;
/*      */       }
/* 1112 */       return twkGetInnerText(paramLong);
/*      */     } finally {
/*      */       
/* 1115 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getRenderTree(long paramLong) {
/* 1121 */     lockPage();
/*      */     try {
/* 1123 */       log.fine("Get render tree: frame = " + paramLong);
/* 1124 */       if (this.isDisposed) {
/* 1125 */         log.fine("getRenderTree() request for a disposed web page.");
/* 1126 */         return null;
/*      */       } 
/* 1128 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1129 */         return null;
/*      */       }
/* 1131 */       return twkGetRenderTree(paramLong);
/*      */     } finally {
/*      */       
/* 1134 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getUnloadEventListenersCount(long paramLong) {
/* 1140 */     lockPage();
/*      */     try {
/* 1142 */       log.fine("frame: " + paramLong);
/* 1143 */       if (this.isDisposed) {
/* 1144 */         log.fine("request for a disposed web page.");
/* 1145 */         return 0;
/*      */       } 
/* 1147 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1148 */         return 0;
/*      */       }
/* 1150 */       return twkGetUnloadEventListenersCount(paramLong);
/*      */     } finally {
/*      */       
/* 1153 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getContentType(long paramLong) {
/* 1158 */     lockPage();
/*      */     try {
/* 1160 */       log.fine("Get content type: frame = " + paramLong);
/* 1161 */       if (this.isDisposed) {
/* 1162 */         log.fine("getContentType() request for a disposed web page.");
/* 1163 */         return null;
/*      */       } 
/* 1165 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1166 */         return null;
/*      */       }
/* 1168 */       return twkGetContentType(paramLong);
/*      */     } finally {
/*      */       
/* 1171 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getTitle(long paramLong) {
/* 1176 */     lockPage();
/*      */     try {
/* 1178 */       log.fine("Get title: frame = " + paramLong);
/* 1179 */       if (this.isDisposed) {
/* 1180 */         log.fine("getTitle() request for a disposed web page.");
/* 1181 */         return null;
/*      */       } 
/* 1183 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1184 */         return null;
/*      */       }
/* 1186 */       return twkGetTitle(paramLong);
/*      */     } finally {
/*      */       
/* 1189 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public WCImage getIcon(long paramLong) {
/* 1194 */     lockPage();
/*      */     try {
/* 1196 */       log.fine("Get icon: frame = " + paramLong);
/* 1197 */       if (this.isDisposed) {
/* 1198 */         log.fine("getIcon() request for a disposed web page.");
/* 1199 */         return null;
/*      */       } 
/* 1201 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1202 */         return null;
/*      */       }
/* 1204 */       String str = twkGetIconURL(paramLong);
/*      */       
/* 1206 */       if (str != null && !str.isEmpty()) {
/* 1207 */         return WCGraphicsManager.getGraphicsManager().getIconImage(str);
/*      */       }
/* 1209 */       return null;
/*      */     } finally {
/*      */       
/* 1212 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void open(long paramLong, String paramString) {
/* 1217 */     lockPage();
/*      */     try {
/* 1219 */       log.fine("Open URL: " + paramString);
/* 1220 */       if (this.isDisposed) {
/* 1221 */         log.fine("open() request for a disposed web page.");
/*      */         return;
/*      */       } 
/* 1224 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/*      */         return;
/*      */       }
/* 1227 */       if (twkIsLoading(paramLong)) {
/* 1228 */         Invoker.getInvoker().postOnEventThread(() -> twkOpen(paramLong, paramString));
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1235 */         twkOpen(paramLong, paramString);
/*      */       } 
/*      */     } finally {
/* 1238 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void load(long paramLong, String paramString1, String paramString2) {
/* 1243 */     lockPage();
/*      */     try {
/* 1245 */       log.fine("Load text: " + paramString1);
/* 1246 */       if (paramString1 == null) {
/*      */         return;
/*      */       }
/* 1249 */       if (this.isDisposed) {
/* 1250 */         log.fine("load() request for a disposed web page.");
/*      */         return;
/*      */       } 
/* 1253 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/*      */         return;
/*      */       }
/*      */       
/* 1257 */       if (twkIsLoading(paramLong)) {
/*      */ 
/*      */ 
/*      */         
/* 1261 */         Invoker.getInvoker().postOnEventThread(() -> twkLoad(paramLong, paramString1, paramString2));
/*      */       }
/*      */       else {
/*      */         
/* 1265 */         twkLoad(paramLong, paramString1, paramString2);
/*      */       } 
/*      */     } finally {
/* 1268 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void stop(long paramLong) {
/* 1273 */     lockPage();
/*      */     try {
/* 1275 */       log.fine("Stop loading: frame = " + paramLong);
/*      */ 
/*      */ 
/*      */       
/* 1279 */       if (this.isDisposed) {
/* 1280 */         log.fine("cancel() request for a disposed web page.");
/*      */         return;
/*      */       } 
/* 1283 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/*      */         return;
/*      */       }
/* 1286 */       String str1 = twkGetURL(paramLong);
/* 1287 */       String str2 = twkGetContentType(paramLong);
/* 1288 */       twkStop(paramLong);
/*      */ 
/*      */       
/* 1291 */       fireLoadEvent(paramLong, 6, str1, str2, 1.0D, 0);
/*      */     } finally {
/*      */       
/* 1294 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void stop() {
/* 1300 */     lockPage();
/*      */     try {
/* 1302 */       log.fine("Stop loading sync");
/* 1303 */       if (this.isDisposed) {
/* 1304 */         log.fine("stopAll() request for a disposed web page.");
/*      */         return;
/*      */       } 
/* 1307 */       twkStopAll(getPage());
/*      */     } finally {
/*      */       
/* 1310 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void refresh(long paramLong) {
/* 1315 */     lockPage();
/*      */     try {
/* 1317 */       log.fine("Refresh: frame = " + paramLong);
/* 1318 */       if (this.isDisposed) {
/* 1319 */         log.fine("refresh() request for a disposed web page.");
/*      */         return;
/*      */       } 
/* 1322 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/*      */         return;
/*      */       }
/* 1325 */       twkRefresh(paramLong);
/*      */     } finally {
/*      */       
/* 1328 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public BackForwardList createBackForwardList() {
/* 1333 */     return new BackForwardList(this);
/*      */   }
/*      */   
/*      */   public boolean goBack() {
/* 1337 */     lockPage();
/*      */     try {
/* 1339 */       log.fine("Go back");
/* 1340 */       if (this.isDisposed) {
/* 1341 */         log.fine("goBack() request for a disposed web page.");
/* 1342 */         return false;
/*      */       } 
/* 1344 */       return twkGoBackForward(getPage(), -1);
/*      */     } finally {
/*      */       
/* 1347 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean goForward() {
/* 1352 */     lockPage();
/*      */     try {
/* 1354 */       log.fine("Go forward");
/* 1355 */       if (this.isDisposed) {
/* 1356 */         log.fine("goForward() request for a disposed web page.");
/* 1357 */         return false;
/*      */       } 
/* 1359 */       return twkGoBackForward(getPage(), 1);
/*      */     } finally {
/*      */       
/* 1362 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean copy() {
/* 1367 */     lockPage();
/*      */     try {
/* 1369 */       log.fine("Copy");
/* 1370 */       if (this.isDisposed) {
/* 1371 */         log.fine("copy() request for a disposed web page.");
/* 1372 */         return false;
/*      */       } 
/* 1374 */       long l = getMainFrame();
/* 1375 */       if (!this.frames.contains(Long.valueOf(l))) {
/* 1376 */         return false;
/*      */       }
/* 1378 */       return twkCopy(l);
/*      */     } finally {
/*      */       
/* 1381 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean find(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/* 1387 */     lockPage();
/*      */     try {
/* 1389 */       log.fine("Find in page: stringToFind = " + paramString + ", " + (
/* 1390 */           paramBoolean1 ? "forward" : "backward") + (paramBoolean2 ? ", wrap" : "") + (paramBoolean3 ? ", matchCase" : ""));
/* 1391 */       if (this.isDisposed) {
/* 1392 */         log.fine("find() request for a disposed web page.");
/* 1393 */         return false;
/*      */       } 
/* 1395 */       return twkFindInPage(getPage(), paramString, paramBoolean1, paramBoolean2, paramBoolean3);
/*      */     } finally {
/*      */       
/* 1398 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean find(long paramLong, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/* 1406 */     lockPage();
/*      */     try {
/* 1408 */       log.fine("Find in frame: stringToFind = " + paramString + ", " + (
/* 1409 */           paramBoolean1 ? "forward" : "backward") + (paramBoolean2 ? ", wrap" : "") + (paramBoolean3 ? ", matchCase" : ""));
/* 1410 */       if (this.isDisposed) {
/* 1411 */         log.fine("find() request for a disposed web page.");
/* 1412 */         return false;
/*      */       } 
/* 1414 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1415 */         return false;
/*      */       }
/* 1417 */       return twkFindInFrame(paramLong, paramString, paramBoolean1, paramBoolean2, paramBoolean3);
/*      */     } finally {
/*      */       
/* 1420 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void overridePreference(String paramString1, String paramString2) {
/* 1425 */     lockPage();
/*      */     try {
/* 1427 */       twkOverridePreference(getPage(), paramString1, paramString2);
/*      */     } finally {
/* 1429 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void resetToConsistentStateBeforeTesting() {
/* 1434 */     lockPage();
/*      */     try {
/* 1436 */       twkResetToConsistentStateBeforeTesting(getPage());
/*      */     } finally {
/* 1438 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public float getZoomFactor(boolean paramBoolean) {
/* 1443 */     lockPage();
/*      */     try {
/* 1445 */       log.fine("Get zoom factor, textOnly=" + paramBoolean);
/* 1446 */       if (this.isDisposed) {
/* 1447 */         log.fine("getZoomFactor() request for a disposed web page.");
/* 1448 */         return 1.0F;
/*      */       } 
/* 1450 */       long l = getMainFrame();
/* 1451 */       if (!this.frames.contains(Long.valueOf(l))) {
/* 1452 */         return 1.0F;
/*      */       }
/* 1454 */       return twkGetZoomFactor(l, paramBoolean);
/*      */     } finally {
/* 1456 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setZoomFactor(float paramFloat, boolean paramBoolean) {
/* 1461 */     lockPage();
/*      */     try {
/* 1463 */       log.fine(String.format("Set zoom factor %.2f, textOnly=%b", new Object[] { Float.valueOf(paramFloat), Boolean.valueOf(paramBoolean) }));
/* 1464 */       if (this.isDisposed) {
/* 1465 */         log.fine("setZoomFactor() request for a disposed web page.");
/*      */         return;
/*      */       } 
/* 1468 */       long l = getMainFrame();
/* 1469 */       if (l == 0L || !this.frames.contains(Long.valueOf(l))) {
/*      */         return;
/*      */       }
/* 1472 */       twkSetZoomFactor(l, paramFloat, paramBoolean);
/*      */     } finally {
/* 1474 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setFontSmoothingType(int paramInt) {
/* 1479 */     this.fontSmoothingType = paramInt;
/* 1480 */     repaintAll();
/*      */   }
/*      */ 
/*      */   
/*      */   public void reset(long paramLong) {
/* 1485 */     lockPage();
/*      */     try {
/* 1487 */       log.fine("Reset: frame = " + paramLong);
/* 1488 */       if (this.isDisposed) {
/* 1489 */         log.fine("reset() request for a disposed web page.");
/*      */         return;
/*      */       } 
/* 1492 */       if (paramLong == 0L || !this.frames.contains(Long.valueOf(paramLong))) {
/*      */         return;
/*      */       }
/* 1495 */       twkReset(paramLong);
/*      */     } finally {
/*      */       
/* 1498 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public Object executeScript(long paramLong, String paramString) throws JSException {
/* 1503 */     lockPage();
/*      */     try {
/* 1505 */       log.fine("execute script: \"" + paramString + "\" in frame = " + paramLong);
/* 1506 */       if (this.isDisposed) {
/* 1507 */         log.fine("executeScript() request for a disposed web page.");
/* 1508 */         return null;
/*      */       } 
/* 1510 */       if (paramLong == 0L || !this.frames.contains(Long.valueOf(paramLong))) {
/* 1511 */         return null;
/*      */       }
/* 1513 */       return twkExecuteScript(paramLong, paramString);
/*      */     } finally {
/*      */       
/* 1516 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public long getMainFrame() {
/* 1521 */     lockPage();
/*      */     try {
/* 1523 */       log.finer("getMainFrame: page = " + this.pPage);
/* 1524 */       if (this.isDisposed) {
/* 1525 */         log.fine("getMainFrame() request for a disposed web page.");
/* 1526 */         return 0L;
/*      */       } 
/* 1528 */       long l = twkGetMainFrame(getPage());
/* 1529 */       log.finer("Main frame = " + l);
/* 1530 */       this.frames.add(Long.valueOf(l));
/* 1531 */       return l;
/*      */     } finally {
/* 1533 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public long getParentFrame(long paramLong) {
/* 1538 */     lockPage();
/*      */     try {
/* 1540 */       log.fine("getParentFrame: child = " + paramLong);
/* 1541 */       if (this.isDisposed) {
/* 1542 */         log.fine("getParentFrame() request for a disposed web page.");
/* 1543 */         return 0L;
/*      */       } 
/* 1545 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1546 */         return 0L;
/*      */       }
/* 1548 */       return twkGetParentFrame(paramLong);
/*      */     } finally {
/* 1550 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public List<Long> getChildFrames(long paramLong) {
/* 1555 */     lockPage();
/*      */     try {
/* 1557 */       log.fine("getChildFrames: parent = " + paramLong);
/* 1558 */       if (this.isDisposed) {
/* 1559 */         log.fine("getChildFrames() request for a disposed web page.");
/* 1560 */         return null;
/*      */       } 
/* 1562 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1563 */         return null;
/*      */       }
/* 1565 */       long[] arrayOfLong = twkGetChildFrames(paramLong);
/* 1566 */       LinkedList<Long> linkedList = new LinkedList();
/* 1567 */       for (long l : arrayOfLong) {
/* 1568 */         linkedList.add(Long.valueOf(l));
/*      */       }
/* 1570 */       return linkedList;
/*      */     } finally {
/* 1572 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public WCRectangle getVisibleRect(long paramLong) {
/* 1577 */     lockPage();
/*      */     try {
/* 1579 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1580 */         return null;
/*      */       }
/* 1582 */       int[] arrayOfInt = twkGetVisibleRect(paramLong);
/* 1583 */       if (arrayOfInt != null) {
/* 1584 */         return new WCRectangle(arrayOfInt[0], arrayOfInt[1], arrayOfInt[2], arrayOfInt[3]);
/*      */       }
/* 1586 */       return null;
/*      */     } finally {
/* 1588 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void scrollToPosition(long paramLong, WCPoint paramWCPoint) {
/* 1593 */     lockPage();
/*      */     try {
/* 1595 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/*      */         return;
/*      */       }
/* 1598 */       twkScrollToPosition(paramLong, paramWCPoint.getIntX(), paramWCPoint.getIntY());
/*      */     } finally {
/* 1600 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public WCSize getContentSize(long paramLong) {
/* 1605 */     lockPage();
/*      */     try {
/* 1607 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1608 */         return null;
/*      */       }
/* 1610 */       int[] arrayOfInt = twkGetContentSize(paramLong);
/* 1611 */       if (arrayOfInt != null) {
/* 1612 */         return new WCSize(arrayOfInt[0], arrayOfInt[1]);
/*      */       }
/* 1614 */       return null;
/*      */     } finally {
/* 1616 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Document getDocument(long paramLong) {
/* 1623 */     lockPage();
/*      */     try {
/* 1625 */       log.fine("getDocument");
/* 1626 */       if (this.isDisposed) {
/* 1627 */         log.fine("getDocument() request for a disposed web page.");
/* 1628 */         return null;
/*      */       } 
/*      */       
/* 1631 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1632 */         return null;
/*      */       }
/* 1634 */       return twkGetDocument(paramLong);
/*      */     } finally {
/* 1636 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public Element getOwnerElement(long paramLong) {
/* 1641 */     lockPage();
/*      */     try {
/* 1643 */       log.fine("getOwnerElement");
/* 1644 */       if (this.isDisposed) {
/* 1645 */         log.fine("getOwnerElement() request for a disposed web page.");
/* 1646 */         return null;
/*      */       } 
/*      */       
/* 1649 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1650 */         return null;
/*      */       }
/* 1652 */       return twkGetOwnerElement(paramLong);
/*      */     } finally {
/* 1654 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean executeCommand(String paramString1, String paramString2) {
/* 1661 */     lockPage();
/*      */     try {
/* 1663 */       if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 1664 */         log.fine("command: [{0}], value: [{1}]", new Object[] { paramString1, paramString2 });
/*      */       }
/*      */       
/* 1667 */       if (this.isDisposed) {
/* 1668 */         log.fine("Web page is already disposed");
/* 1669 */         return false;
/*      */       } 
/*      */       
/* 1672 */       boolean bool = twkExecuteCommand(getPage(), paramString1, paramString2);
/*      */       
/* 1674 */       log.fine("result: [{0}]", new Object[] { Boolean.valueOf(bool) });
/* 1675 */       return bool;
/*      */     } finally {
/* 1677 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean queryCommandEnabled(String paramString) {
/* 1682 */     lockPage();
/*      */     try {
/* 1684 */       log.fine("command: [{0}]", new Object[] { paramString });
/* 1685 */       if (this.isDisposed) {
/* 1686 */         log.fine("Web page is already disposed");
/* 1687 */         return false;
/*      */       } 
/*      */       
/* 1690 */       boolean bool = twkQueryCommandEnabled(getPage(), paramString);
/*      */       
/* 1692 */       log.fine("result: [{0}]", new Object[] { Boolean.valueOf(bool) });
/* 1693 */       return bool;
/*      */     } finally {
/* 1695 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean queryCommandState(String paramString) {
/* 1700 */     lockPage();
/*      */     try {
/* 1702 */       log.fine("command: [{0}]", new Object[] { paramString });
/* 1703 */       if (this.isDisposed) {
/* 1704 */         log.fine("Web page is already disposed");
/* 1705 */         return false;
/*      */       } 
/*      */       
/* 1708 */       boolean bool = twkQueryCommandState(getPage(), paramString);
/*      */       
/* 1710 */       log.fine("result: [{0}]", new Object[] { Boolean.valueOf(bool) });
/* 1711 */       return bool;
/*      */     } finally {
/* 1713 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String queryCommandValue(String paramString) {
/* 1718 */     lockPage();
/*      */     try {
/* 1720 */       log.fine("command: [{0}]", new Object[] { paramString });
/* 1721 */       if (this.isDisposed) {
/* 1722 */         log.fine("Web page is already disposed");
/* 1723 */         return null;
/*      */       } 
/*      */       
/* 1726 */       String str = twkQueryCommandValue(getPage(), paramString);
/*      */       
/* 1728 */       log.fine("result: [{0}]", new Object[] { str });
/* 1729 */       return str;
/*      */     } finally {
/* 1731 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isEditable() {
/* 1736 */     lockPage();
/*      */     try {
/* 1738 */       log.fine("isEditable");
/* 1739 */       if (this.isDisposed) {
/* 1740 */         log.fine("isEditable() request for a disposed web page.");
/* 1741 */         return false;
/*      */       } 
/*      */       
/* 1744 */       return twkIsEditable(getPage());
/*      */     } finally {
/* 1746 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setEditable(boolean paramBoolean) {
/* 1751 */     lockPage();
/*      */     try {
/* 1753 */       log.fine("setEditable");
/* 1754 */       if (this.isDisposed) {
/* 1755 */         log.fine("setEditable() request for a disposed web page.");
/*      */         
/*      */         return;
/*      */       } 
/* 1759 */       twkSetEditable(getPage(), paramBoolean);
/*      */     } finally {
/* 1761 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getHtml(long paramLong) {
/* 1770 */     lockPage();
/*      */     try {
/* 1772 */       log.fine("getHtml");
/* 1773 */       if (this.isDisposed) {
/* 1774 */         log.fine("getHtml() request for a disposed web page.");
/* 1775 */         return null;
/*      */       } 
/* 1777 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1778 */         return null;
/*      */       }
/* 1780 */       return twkGetHtml(paramLong);
/*      */     } finally {
/* 1782 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int beginPrinting(float paramFloat1, float paramFloat2) {
/* 1789 */     lockPage();
/*      */     try {
/* 1791 */       if (this.isDisposed) {
/* 1792 */         log.warning("beginPrinting() called for a disposed web page.");
/* 1793 */         return 0;
/*      */       } 
/* 1795 */       AtomicReference<Integer> atomicReference = new AtomicReference<>(Integer.valueOf(0));
/* 1796 */       CountDownLatch countDownLatch = new CountDownLatch(1);
/* 1797 */       Invoker.getInvoker().invokeOnEventThread(() -> {
/*      */             try {
/*      */               int i = twkBeginPrinting(getPage(), paramFloat1, paramFloat2);
/*      */               
/*      */               paramAtomicReference.set(Integer.valueOf(i));
/*      */             } finally {
/*      */               paramCountDownLatch.countDown();
/*      */             } 
/*      */           });
/*      */       try {
/* 1807 */         countDownLatch.await();
/* 1808 */       } catch (InterruptedException interruptedException) {
/* 1809 */         throw new RuntimeException(interruptedException);
/*      */       } 
/* 1811 */       return ((Integer)atomicReference.get()).intValue();
/*      */     } finally {
/* 1813 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void endPrinting() {
/* 1818 */     lockPage();
/*      */     try {
/* 1820 */       if (this.isDisposed) {
/* 1821 */         log.warning("endPrinting() called for a disposed web page.");
/*      */         return;
/*      */       } 
/* 1824 */       CountDownLatch countDownLatch = new CountDownLatch(1);
/* 1825 */       Invoker.getInvoker().invokeOnEventThread(() -> {
/*      */             try {
/*      */               twkEndPrinting(getPage());
/*      */             } finally {
/*      */               paramCountDownLatch.countDown();
/*      */             } 
/*      */           });
/*      */       
/*      */       try {
/* 1834 */         countDownLatch.await();
/* 1835 */       } catch (InterruptedException interruptedException) {
/* 1836 */         throw new RuntimeException(interruptedException);
/*      */       } 
/*      */     } finally {
/* 1839 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void print(WCGraphicsContext paramWCGraphicsContext, int paramInt, float paramFloat) {
/* 1844 */     lockPage();
/*      */     try {
/* 1846 */       if (this.isDisposed) {
/* 1847 */         log.warning("print() called for a disposed web page.");
/*      */         
/*      */         return;
/*      */       } 
/* 1851 */       WCRenderQueue wCRenderQueue = WCGraphicsManager.getGraphicsManager().createRenderQueue(null, true);
/* 1852 */       CountDownLatch countDownLatch = new CountDownLatch(1);
/* 1853 */       Invoker.getInvoker().invokeOnEventThread(() -> {
/*      */             try {
/*      */               twkPrint(getPage(), paramWCRenderQueue, paramInt, paramFloat);
/*      */             } finally {
/*      */               paramCountDownLatch.countDown();
/*      */             } 
/*      */           });
/*      */       
/*      */       try {
/* 1862 */         countDownLatch.await();
/* 1863 */       } catch (InterruptedException interruptedException) {
/* 1864 */         wCRenderQueue.dispose();
/*      */         return;
/*      */       } 
/* 1867 */       wCRenderQueue.decode(paramWCGraphicsContext);
/*      */     } finally {
/* 1869 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getPageHeight() {
/* 1874 */     return getFrameHeight(getMainFrame());
/*      */   }
/*      */   
/*      */   public int getFrameHeight(long paramLong) {
/* 1878 */     lockPage();
/*      */     try {
/* 1880 */       log.fine("Get page height");
/* 1881 */       if (this.isDisposed) {
/* 1882 */         log.fine("getFrameHeight() request for a disposed web page.");
/* 1883 */         return 0;
/*      */       } 
/* 1885 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1886 */         return 0;
/*      */       }
/* 1888 */       int i = twkGetFrameHeight(paramLong);
/* 1889 */       log.fine("Height = " + i);
/* 1890 */       return i;
/*      */     } finally {
/* 1892 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float adjustFrameHeight(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 1899 */     lockPage();
/*      */     try {
/* 1901 */       log.fine("Adjust page height");
/* 1902 */       if (this.isDisposed) {
/* 1903 */         log.fine("adjustFrameHeight() request for a disposed web page.");
/* 1904 */         return 0.0F;
/*      */       } 
/* 1906 */       if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 1907 */         return 0.0F;
/*      */       }
/* 1909 */       return twkAdjustFrameHeight(paramLong, paramFloat1, paramFloat2, paramFloat3);
/*      */     } finally {
/* 1911 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getUsePageCache() {
/* 1923 */     lockPage();
/*      */     try {
/* 1925 */       return twkGetUsePageCache(getPage());
/*      */     } finally {
/* 1927 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUsePageCache(boolean paramBoolean) {
/* 1937 */     lockPage();
/*      */     try {
/* 1939 */       twkSetUsePageCache(getPage(), paramBoolean);
/*      */     } finally {
/* 1941 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean getDeveloperExtrasEnabled() {
/* 1946 */     lockPage();
/*      */     try {
/* 1948 */       boolean bool = twkGetDeveloperExtrasEnabled(getPage());
/* 1949 */       log.fine("Getting developerExtrasEnabled, result: [{0}]", new Object[] { Boolean.valueOf(bool) });
/* 1950 */       return bool;
/*      */     } finally {
/* 1952 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setDeveloperExtrasEnabled(boolean paramBoolean) {
/* 1957 */     lockPage();
/*      */     try {
/* 1959 */       log.fine("Setting developerExtrasEnabled, value: [{0}]", new Object[] { Boolean.valueOf(paramBoolean) });
/* 1960 */       twkSetDeveloperExtrasEnabled(getPage(), paramBoolean);
/*      */     } finally {
/* 1962 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isJavaScriptEnabled() {
/* 1967 */     lockPage();
/*      */     try {
/* 1969 */       return twkIsJavaScriptEnabled(getPage());
/*      */     } finally {
/* 1971 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setJavaScriptEnabled(boolean paramBoolean) {
/* 1976 */     lockPage();
/*      */     try {
/* 1978 */       twkSetJavaScriptEnabled(getPage(), paramBoolean);
/*      */     } finally {
/* 1980 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isContextMenuEnabled() {
/* 1985 */     lockPage();
/*      */     try {
/* 1987 */       return twkIsContextMenuEnabled(getPage());
/*      */     } finally {
/* 1989 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setContextMenuEnabled(boolean paramBoolean) {
/* 1994 */     lockPage();
/*      */     try {
/* 1996 */       twkSetContextMenuEnabled(getPage(), paramBoolean);
/*      */     } finally {
/* 1998 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setUserStyleSheetLocation(String paramString) {
/* 2003 */     lockPage();
/*      */     try {
/* 2005 */       twkSetUserStyleSheetLocation(getPage(), paramString);
/*      */     } finally {
/* 2007 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getUserAgent() {
/* 2012 */     lockPage();
/*      */     try {
/* 2014 */       return twkGetUserAgent(getPage());
/*      */     } finally {
/* 2016 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setUserAgent(String paramString) {
/* 2021 */     lockPage();
/*      */     try {
/* 2023 */       twkSetUserAgent(getPage(), paramString);
/*      */     } finally {
/* 2025 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setLocalStorageDatabasePath(String paramString) {
/* 2030 */     lockPage();
/*      */     try {
/* 2032 */       twkSetLocalStorageDatabasePath(getPage(), paramString);
/*      */     } finally {
/* 2034 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setLocalStorageEnabled(boolean paramBoolean) {
/* 2039 */     lockPage();
/*      */     try {
/* 2041 */       twkSetLocalStorageEnabled(getPage(), paramBoolean);
/*      */     } finally {
/* 2043 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void connectInspectorFrontend() {
/* 2050 */     lockPage();
/*      */     try {
/* 2052 */       log.fine("Connecting inspector frontend");
/* 2053 */       twkConnectInspectorFrontend(getPage());
/*      */     } finally {
/* 2055 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void disconnectInspectorFrontend() {
/* 2060 */     lockPage();
/*      */     try {
/* 2062 */       log.fine("Disconnecting inspector frontend");
/* 2063 */       twkDisconnectInspectorFrontend(getPage());
/*      */     } finally {
/* 2065 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void dispatchInspectorMessageFromFrontend(String paramString) {
/* 2070 */     lockPage();
/*      */     try {
/* 2072 */       if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 2073 */         log.fine("Dispatching inspector message from frontend, message: [{0}]", new Object[] { paramString });
/*      */       }
/*      */       
/* 2076 */       twkDispatchInspectorMessageFromFrontend(getPage(), paramString);
/*      */     } finally {
/* 2078 */       unlockPage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fwkFrameCreated(long paramLong) {
/* 2087 */     log.fine("Frame created: frame = " + paramLong);
/* 2088 */     if (this.frames.contains(Long.valueOf(paramLong))) {
/* 2089 */       log.fine("Error in fwkFrameCreated: frame is already in frames");
/*      */       return;
/*      */     } 
/* 2092 */     this.frames.add(Long.valueOf(paramLong));
/*      */   }
/*      */   
/*      */   private void fwkFrameDestroyed(long paramLong) {
/* 2096 */     log.fine("Frame destroyed: frame = " + paramLong);
/* 2097 */     if (!this.frames.contains(Long.valueOf(paramLong))) {
/* 2098 */       log.fine("Error in fwkFrameDestroyed: frame is not found in frames");
/*      */       return;
/*      */     } 
/* 2101 */     this.frames.remove(Long.valueOf(paramLong));
/*      */   }
/*      */   
/*      */   private void fwkRepaint(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 2105 */     lockPage();
/*      */     try {
/* 2107 */       if (paintLog.isLoggable(PlatformLogger.Level.FINEST))
/* 2108 */         paintLog.finest("x: {0}, y: {1}, w: {2}, h: {3}", new Object[] {
/* 2109 */               Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4)
/*      */             }); 
/* 2111 */       addDirtyRect(new WCRectangle(paramInt1, paramInt2, paramInt3, paramInt4));
/*      */     } finally {
/* 2113 */       unlockPage();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void fwkScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 2118 */     if (paintLog.isLoggable(PlatformLogger.Level.FINEST)) {
/* 2119 */       paintLog.finest("Scroll: " + paramInt1 + " " + paramInt2 + " " + paramInt3 + " " + paramInt4 + "  " + paramInt5 + " " + paramInt6);
/*      */     }
/* 2121 */     if (this.pageClient == null || !this.pageClient.isBackBufferSupported()) {
/* 2122 */       paintLog.finest("blit scrolling is switched off");
/*      */       
/*      */       return;
/*      */     } 
/* 2126 */     scroll(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
/*      */   }
/*      */   
/*      */   private void fwkTransferFocus(boolean paramBoolean) {
/* 2130 */     log.finer("Transfer focus " + (paramBoolean ? "forward" : "backward"));
/*      */     
/* 2132 */     if (this.pageClient != null) {
/* 2133 */       this.pageClient.transferFocus(paramBoolean);
/*      */     }
/*      */   }
/*      */   
/*      */   private void fwkSetCursor(long paramLong) {
/* 2138 */     log.finer("Set cursor: " + paramLong);
/*      */     
/* 2140 */     if (this.pageClient != null) {
/* 2141 */       this.pageClient.setCursor(paramLong);
/*      */     }
/*      */   }
/*      */   
/*      */   private void fwkSetFocus(boolean paramBoolean) {
/* 2146 */     log.finer("Set focus: " + (paramBoolean ? "true" : "false"));
/*      */     
/* 2148 */     if (this.pageClient != null) {
/* 2149 */       this.pageClient.setFocus(paramBoolean);
/*      */     }
/*      */   }
/*      */   
/*      */   private void fwkSetTooltip(String paramString) {
/* 2154 */     log.finer("Set tooltip: " + paramString);
/*      */     
/* 2156 */     if (this.pageClient != null) {
/* 2157 */       this.pageClient.setTooltip(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */   private void fwkPrint() {
/* 2162 */     log.finer("Print");
/*      */     
/* 2164 */     if (this.uiClient != null) {
/* 2165 */       this.uiClient.print();
/*      */     }
/*      */   }
/*      */   
/*      */   private void fwkSetRequestURL(long paramLong, int paramInt, String paramString) {
/* 2170 */     log.finer("Set request URL: id = " + paramInt + ", url = " + paramString);
/*      */     
/* 2172 */     synchronized (this.requestURLs) {
/* 2173 */       this.requestURLs.put(Integer.valueOf(paramInt), paramString);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void fwkRemoveRequestURL(long paramLong, int paramInt) {
/* 2178 */     log.finer("Set request URL: id = " + paramInt);
/*      */     
/* 2180 */     synchronized (this.requestURLs) {
/* 2181 */       this.requestURLs.remove(Integer.valueOf(paramInt));
/* 2182 */       this.requestStarted.remove(Integer.valueOf(paramInt));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private WebPage fwkCreateWindow(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
/* 2188 */     log.finer("Create window");
/*      */     
/* 2190 */     if (this.uiClient != null) {
/* 2191 */       return this.uiClient.createPage(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
/*      */     }
/* 2193 */     return null;
/*      */   }
/*      */   
/*      */   private void fwkShowWindow() {
/* 2197 */     log.finer("Show window");
/*      */     
/* 2199 */     if (this.uiClient != null) {
/* 2200 */       this.uiClient.showView();
/*      */     }
/*      */   }
/*      */   
/*      */   private void fwkCloseWindow() {
/* 2205 */     log.finer("Close window");
/*      */     
/* 2207 */     if (permitCloseWindowAction() && 
/* 2208 */       this.uiClient != null) {
/* 2209 */       this.uiClient.closePage();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private WCRectangle fwkGetWindowBounds() {
/* 2215 */     log.fine("Get window bounds");
/*      */     
/* 2217 */     if (this.uiClient != null) {
/* 2218 */       WCRectangle wCRectangle = this.uiClient.getViewBounds();
/* 2219 */       if (wCRectangle != null) {
/* 2220 */         return wCRectangle;
/*      */       }
/*      */     } 
/* 2223 */     return fwkGetPageBounds();
/*      */   }
/*      */   
/*      */   private void fwkSetWindowBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 2227 */     log.finer("Set window bounds: " + paramInt1 + " " + paramInt2 + " " + paramInt3 + " " + paramInt4);
/*      */     
/* 2229 */     if (this.uiClient != null) {
/* 2230 */       this.uiClient.setViewBounds(new WCRectangle(paramInt1, paramInt2, paramInt3, paramInt4));
/*      */     }
/*      */   }
/*      */   
/*      */   private WCRectangle fwkGetPageBounds() {
/* 2235 */     log.finer("Get page bounds");
/* 2236 */     return new WCRectangle(0.0F, 0.0F, this.width, this.height);
/*      */   }
/*      */ 
/*      */   
/*      */   private void fwkSetScrollbarsVisible(boolean paramBoolean) {}
/*      */ 
/*      */   
/*      */   private void fwkSetStatusbarText(String paramString) {
/* 2244 */     log.finer("Set statusbar text: " + paramString);
/*      */     
/* 2246 */     if (this.uiClient != null) {
/* 2247 */       this.uiClient.setStatusbarText(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */   private String[] fwkChooseFile(String paramString1, boolean paramBoolean, String paramString2) {
/* 2252 */     log.finer("Choose file, initial=" + paramString1);
/*      */     
/* 2254 */     return (this.uiClient != null) ? 
/* 2255 */       this.uiClient.chooseFile(paramString1, paramBoolean, paramString2) : 
/* 2256 */       null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fwkStartDrag(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String[] paramArrayOfString, Object[] paramArrayOfObject, boolean paramBoolean) {
/* 2266 */     log.finer("Start drag: ");
/* 2267 */     if (this.uiClient != null) {
/* 2268 */       this.uiClient.startDrag(
/* 2269 */           WCImage.getImage(paramObject), paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfString, paramArrayOfObject, paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WCPoint fwkScreenToWindow(WCPoint paramWCPoint) {
/* 2278 */     log.finer("fwkScreenToWindow");
/*      */     
/* 2280 */     if (this.pageClient != null) {
/* 2281 */       return this.pageClient.screenToWindow(paramWCPoint);
/*      */     }
/* 2283 */     return paramWCPoint;
/*      */   }
/*      */   
/*      */   private WCPoint fwkWindowToScreen(WCPoint paramWCPoint) {
/* 2287 */     log.finer("fwkWindowToScreen");
/*      */     
/* 2289 */     if (this.pageClient != null) {
/* 2290 */       return this.pageClient.windowToScreen(paramWCPoint);
/*      */     }
/* 2292 */     return paramWCPoint;
/*      */   }
/*      */ 
/*      */   
/*      */   private void fwkAlert(String paramString) {
/* 2297 */     log.fine("JavaScript alert(): text = " + paramString);
/*      */     
/* 2299 */     if (this.uiClient != null) {
/* 2300 */       this.uiClient.alert(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean fwkConfirm(String paramString) {
/* 2305 */     log.fine("JavaScript confirm(): text = " + paramString);
/*      */     
/* 2307 */     if (this.uiClient != null) {
/* 2308 */       return this.uiClient.confirm(paramString);
/*      */     }
/* 2310 */     return false;
/*      */   }
/*      */   
/*      */   private String fwkPrompt(String paramString1, String paramString2) {
/* 2314 */     log.fine("JavaScript prompt(): text = " + paramString1 + ", default = " + paramString2);
/*      */     
/* 2316 */     if (this.uiClient != null) {
/* 2317 */       return this.uiClient.prompt(paramString1, paramString2);
/*      */     }
/* 2319 */     return null;
/*      */   }
/*      */   
/*      */   private boolean fwkCanRunBeforeUnloadConfirmPanel() {
/* 2323 */     log.fine("JavaScript canRunBeforeUnloadConfirmPanel()");
/*      */     
/* 2325 */     if (this.uiClient != null) {
/* 2326 */       return this.uiClient.canRunBeforeUnloadConfirmPanel();
/*      */     }
/* 2328 */     return false;
/*      */   }
/*      */   
/*      */   private boolean fwkRunBeforeUnloadConfirmPanel(String paramString) {
/* 2332 */     log.fine("JavaScript runBeforeUnloadConfirmPanel(): message = " + paramString);
/*      */     
/* 2334 */     if (this.uiClient != null) {
/* 2335 */       return this.uiClient.runBeforeUnloadConfirmPanel(paramString);
/*      */     }
/* 2337 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void fwkAddMessageToConsole(String paramString1, int paramInt, String paramString2) {
/* 2343 */     log.fine("fwkAddMessageToConsole(): message = " + paramString1 + ", lineNumber = " + paramInt + ", sourceId = " + paramString2);
/*      */     
/* 2345 */     if (this.pageClient != null) {
/* 2346 */       this.pageClient.addMessageToConsole(paramString1, paramInt, paramString2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fwkFireLoadEvent(long paramLong, int paramInt1, String paramString1, String paramString2, double paramDouble, int paramInt2) {
/* 2354 */     log.finer("Load event: pFrame = " + paramLong + ", state = " + paramInt1 + ", url = " + paramString1 + ", contenttype=" + paramString2 + ", progress = " + paramDouble + ", error = " + paramInt2);
/*      */ 
/*      */ 
/*      */     
/* 2358 */     fireLoadEvent(paramLong, paramInt1, paramString1, paramString2, paramDouble, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fwkFireResourceLoadEvent(long paramLong, int paramInt1, int paramInt2, String paramString, double paramDouble, int paramInt3) {
/* 2365 */     log.finer("Resource load event: pFrame = " + paramLong + ", state = " + paramInt1 + ", id = " + paramInt2 + ", contenttype=" + paramString + ", progress = " + paramDouble + ", error = " + paramInt3);
/*      */ 
/*      */ 
/*      */     
/* 2369 */     String str = this.requestURLs.get(Integer.valueOf(paramInt2));
/* 2370 */     if (str == null) {
/* 2371 */       log.fine("Error in fwkFireResourceLoadEvent: unknown request id " + paramInt2);
/*      */       
/*      */       return;
/*      */     } 
/* 2375 */     int i = paramInt1;
/*      */     
/* 2377 */     if (paramInt1 == 20) {
/* 2378 */       if (this.requestStarted.contains(Integer.valueOf(paramInt2))) {
/* 2379 */         i = 21;
/*      */       } else {
/* 2381 */         this.requestStarted.add(Integer.valueOf(paramInt2));
/*      */       } 
/*      */     }
/*      */     
/* 2385 */     fireResourceLoadEvent(paramLong, i, str, paramString, paramDouble, paramInt3);
/*      */   }
/*      */   
/*      */   private boolean fwkPermitNavigateAction(long paramLong, String paramString) {
/* 2389 */     log.fine("Policy: permit NAVIGATE: pFrame = " + paramLong + ", url = " + paramString);
/*      */     
/* 2391 */     if (this.policyClient != null) {
/* 2392 */       return this.policyClient.permitNavigateAction(paramLong, str2url(paramString));
/*      */     }
/* 2394 */     return true;
/*      */   }
/*      */   
/*      */   private boolean fwkPermitRedirectAction(long paramLong, String paramString) {
/* 2398 */     log.fine("Policy: permit REDIRECT: pFrame = " + paramLong + ", url = " + paramString);
/*      */     
/* 2400 */     if (this.policyClient != null) {
/* 2401 */       return this.policyClient.permitRedirectAction(paramLong, str2url(paramString));
/*      */     }
/* 2403 */     return true;
/*      */   }
/*      */   
/*      */   private boolean fwkPermitAcceptResourceAction(long paramLong, String paramString) {
/* 2407 */     log.fine("Policy: permit ACCEPT_RESOURCE: pFrame + " + paramLong + ", url = " + paramString);
/*      */     
/* 2409 */     if (this.policyClient != null) {
/* 2410 */       return this.policyClient.permitAcceptResourceAction(paramLong, str2url(paramString));
/*      */     }
/* 2412 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fwkPermitSubmitDataAction(long paramLong, String paramString1, String paramString2, boolean paramBoolean) {
/* 2418 */     log.fine("Policy: permit " + (paramBoolean ? "" : "RE") + "SUBMIT_DATA: pFrame = " + paramLong + ", url = " + paramString1 + ", httpMethod = " + paramString2);
/*      */ 
/*      */     
/* 2421 */     if (this.policyClient != null) {
/* 2422 */       if (paramBoolean) {
/* 2423 */         return this.policyClient.permitSubmitDataAction(paramLong, str2url(paramString1), paramString2);
/*      */       }
/* 2425 */       return this.policyClient.permitResubmitDataAction(paramLong, str2url(paramString1), paramString2);
/*      */     } 
/*      */     
/* 2428 */     return true;
/*      */   }
/*      */   
/*      */   private boolean fwkPermitEnableScriptsAction(long paramLong, String paramString) {
/* 2432 */     log.fine("Policy: permit ENABLE_SCRIPTS: pFrame + " + paramLong + ", url = " + paramString);
/*      */     
/* 2434 */     if (this.policyClient != null) {
/* 2435 */       return this.policyClient.permitEnableScriptsAction(paramLong, str2url(paramString));
/*      */     }
/* 2437 */     return true;
/*      */   }
/*      */   
/*      */   private boolean fwkPermitNewWindowAction(long paramLong, String paramString) {
/* 2441 */     log.fine("Policy: permit NEW_PAGE: pFrame = " + paramLong + ", url = " + paramString);
/*      */     
/* 2443 */     if (this.policyClient != null) {
/* 2444 */       return this.policyClient.permitNewPageAction(paramLong, str2url(paramString));
/*      */     }
/* 2446 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean permitCloseWindowAction() {
/* 2451 */     log.fine("Policy: permit CLOSE_PAGE");
/*      */     
/* 2453 */     if (this.policyClient != null)
/*      */     {
/*      */       
/* 2456 */       return this.policyClient.permitClosePageAction(getMainFrame());
/*      */     }
/* 2458 */     return true;
/*      */   }
/*      */   
/*      */   private void fwkRepaintAll() {
/* 2462 */     log.fine("Repainting the entire page");
/* 2463 */     repaintAll();
/*      */   }
/*      */   
/*      */   private boolean fwkSendInspectorMessageToFrontend(String paramString) {
/* 2467 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 2468 */       log.fine("Sending inspector message to frontend, message: [{0}]", new Object[] { paramString });
/*      */     }
/*      */     
/* 2471 */     boolean bool = false;
/* 2472 */     if (this.inspectorClient != null) {
/* 2473 */       log.fine("Invoking inspector client");
/* 2474 */       bool = this.inspectorClient.sendMessageToFrontend(paramString);
/*      */     } 
/* 2476 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 2477 */       log.fine("Result: [{0}]", new Object[] { Boolean.valueOf(bool) });
/*      */     }
/* 2479 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getWorkerThreadCount() {
/* 2485 */     return twkWorkerThreadCount();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void fwkDidClearWindowObject(long paramLong1, long paramLong2) {
/* 2491 */     if (this.pageClient != null) {
/* 2492 */       this.pageClient.didClearWindowObject(paramLong1, paramLong2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private URL str2url(String paramString) {
/*      */     try {
/* 2502 */       return URLs.newURL(paramString);
/* 2503 */     } catch (MalformedURLException malformedURLException) {
/* 2504 */       log.fine("Exception while converting \"" + paramString + "\" to URL", malformedURLException);
/*      */       
/* 2506 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void fireLoadEvent(long paramLong, int paramInt1, String paramString1, String paramString2, double paramDouble, int paramInt2) {
/* 2512 */     for (LoadListenerClient loadListenerClient : this.loadListenerClients) {
/* 2513 */       loadListenerClient.dispatchLoadEvent(paramLong, paramInt1, paramString1, paramString2, paramDouble, paramInt2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireResourceLoadEvent(long paramLong, int paramInt1, String paramString1, String paramString2, double paramDouble, int paramInt2) {
/* 2520 */     for (LoadListenerClient loadListenerClient : this.loadListenerClients) {
/* 2521 */       loadListenerClient.dispatchResourceLoadEvent(paramLong, paramInt1, paramString1, paramString2, paramDouble, paramInt2);
/*      */     }
/*      */   }
/*      */   
/*      */   private void repaintAll() {
/* 2526 */     this.dirtyRects.clear();
/* 2527 */     addDirtyRect(new WCRectangle(0.0F, 0.0F, this.width, this.height));
/*      */   }
/*      */ 
/*      */   
/*      */   int test_getFramesCount() {
/* 2532 */     return this.frames.size();
/*      */   }
/*      */   
/*      */   private static native int twkWorkerThreadCount();
/*      */   
/*      */   private static native void twkInitWebCore(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
/*      */   
/*      */   private native long twkCreatePage(boolean paramBoolean);
/*      */   
/*      */   private native void twkInit(long paramLong, boolean paramBoolean, float paramFloat);
/*      */   
/*      */   private native void twkDestroyPage(long paramLong);
/*      */   
/*      */   private native long twkGetMainFrame(long paramLong);
/*      */   
/*      */   private native long twkGetParentFrame(long paramLong);
/*      */   
/*      */   private native long[] twkGetChildFrames(long paramLong);
/*      */   
/*      */   private native String twkGetName(long paramLong);
/*      */   
/*      */   private native String twkGetURL(long paramLong);
/*      */   
/*      */   private native String twkGetInnerText(long paramLong);
/*      */   
/*      */   private native String twkGetRenderTree(long paramLong);
/*      */   
/*      */   private native String twkGetContentType(long paramLong);
/*      */   
/*      */   private native String twkGetTitle(long paramLong);
/*      */   
/*      */   private native String twkGetIconURL(long paramLong);
/*      */   
/*      */   private static native Document twkGetDocument(long paramLong);
/*      */   
/*      */   private static native Element twkGetOwnerElement(long paramLong);
/*      */   
/*      */   private native void twkOpen(long paramLong, String paramString);
/*      */   
/*      */   private native void twkOverridePreference(long paramLong, String paramString1, String paramString2);
/*      */   
/*      */   private native void twkResetToConsistentStateBeforeTesting(long paramLong);
/*      */   
/*      */   private native void twkLoad(long paramLong, String paramString1, String paramString2);
/*      */   
/*      */   private native boolean twkIsLoading(long paramLong);
/*      */   
/*      */   private native void twkStop(long paramLong);
/*      */   
/*      */   private native void twkStopAll(long paramLong);
/*      */   
/*      */   private native void twkRefresh(long paramLong);
/*      */   
/*      */   private native boolean twkGoBackForward(long paramLong, int paramInt);
/*      */   
/*      */   private native boolean twkCopy(long paramLong);
/*      */   
/*      */   private native boolean twkFindInPage(long paramLong, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
/*      */   
/*      */   private native boolean twkFindInFrame(long paramLong, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
/*      */   
/*      */   private native float twkGetZoomFactor(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private native void twkSetZoomFactor(long paramLong, float paramFloat, boolean paramBoolean);
/*      */   
/*      */   private native Object twkExecuteScript(long paramLong, String paramString);
/*      */   
/*      */   private native void twkReset(long paramLong);
/*      */   
/*      */   private native int twkGetFrameHeight(long paramLong);
/*      */   
/*      */   private native int twkBeginPrinting(long paramLong, float paramFloat1, float paramFloat2);
/*      */   
/*      */   private native void twkEndPrinting(long paramLong);
/*      */   
/*      */   private native void twkPrint(long paramLong, WCRenderQueue paramWCRenderQueue, int paramInt, float paramFloat);
/*      */   
/*      */   private native float twkAdjustFrameHeight(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3);
/*      */   
/*      */   private native int[] twkGetVisibleRect(long paramLong);
/*      */   
/*      */   private native void twkScrollToPosition(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   private native int[] twkGetContentSize(long paramLong);
/*      */   
/*      */   private native void twkSetTransparent(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private native void twkSetBackgroundColor(long paramLong, int paramInt);
/*      */   
/*      */   private native void twkSetBounds(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */   private native void twkPrePaint(long paramLong);
/*      */   
/*      */   private native void twkUpdateContent(long paramLong, WCRenderQueue paramWCRenderQueue, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */   private native void twkPostPaint(long paramLong, WCRenderQueue paramWCRenderQueue, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */   private native String twkGetEncoding(long paramLong);
/*      */   
/*      */   private native void twkSetEncoding(long paramLong, String paramString);
/*      */   
/*      */   private native void twkProcessFocusEvent(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   private native boolean twkProcessKeyEvent(long paramLong, int paramInt1, String paramString1, String paramString2, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, double paramDouble);
/*      */   
/*      */   private native boolean twkProcessMouseEvent(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, double paramDouble);
/*      */   
/*      */   private native boolean twkProcessMouseWheelEvent(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, double paramDouble);
/*      */   
/*      */   private native boolean twkProcessInputTextChange(long paramLong, String paramString1, String paramString2, int[] paramArrayOfint, int paramInt);
/*      */   
/*      */   private native boolean twkProcessCaretPositionChange(long paramLong, int paramInt);
/*      */   
/*      */   private native int[] twkGetTextLocation(long paramLong, int paramInt);
/*      */   
/*      */   private native int twkGetInsertPositionOffset(long paramLong);
/*      */   
/*      */   private native int twkGetCommittedTextLength(long paramLong);
/*      */   
/*      */   private native String twkGetCommittedText(long paramLong);
/*      */   
/*      */   private native String twkGetSelectedText(long paramLong);
/*      */   
/*      */   private native int twkProcessDrag(long paramLong, int paramInt1, String[] paramArrayOfString1, String[] paramArrayOfString2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */   
/*      */   private native boolean twkExecuteCommand(long paramLong, String paramString1, String paramString2);
/*      */   
/*      */   private native boolean twkQueryCommandEnabled(long paramLong, String paramString);
/*      */   
/*      */   private native boolean twkQueryCommandState(long paramLong, String paramString);
/*      */   
/*      */   private native String twkQueryCommandValue(long paramLong, String paramString);
/*      */   
/*      */   private native boolean twkIsEditable(long paramLong);
/*      */   
/*      */   private native void twkSetEditable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private native String twkGetHtml(long paramLong);
/*      */   
/*      */   private native boolean twkGetUsePageCache(long paramLong);
/*      */   
/*      */   private native void twkSetUsePageCache(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private native boolean twkGetDeveloperExtrasEnabled(long paramLong);
/*      */   
/*      */   private native void twkSetDeveloperExtrasEnabled(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private native boolean twkIsJavaScriptEnabled(long paramLong);
/*      */   
/*      */   private native void twkSetJavaScriptEnabled(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private native boolean twkIsContextMenuEnabled(long paramLong);
/*      */   
/*      */   private native void twkSetContextMenuEnabled(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private native void twkSetUserStyleSheetLocation(long paramLong, String paramString);
/*      */   
/*      */   private native String twkGetUserAgent(long paramLong);
/*      */   
/*      */   private native void twkSetUserAgent(long paramLong, String paramString);
/*      */   
/*      */   private native void twkSetLocalStorageDatabasePath(long paramLong, String paramString);
/*      */   
/*      */   private native void twkSetLocalStorageEnabled(long paramLong, boolean paramBoolean);
/*      */   
/*      */   private native int twkGetUnloadEventListenersCount(long paramLong);
/*      */   
/*      */   private native void twkConnectInspectorFrontend(long paramLong);
/*      */   
/*      */   private native void twkDisconnectInspectorFrontend(long paramLong);
/*      */   
/*      */   private native void twkDispatchInspectorMessageFromFrontend(long paramLong, String paramString);
/*      */   
/*      */   private static native void twkDoJSCGarbageCollection();
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\WebPage.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */