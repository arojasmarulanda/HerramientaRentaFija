/*     */ package com.sun.webkit.network.about;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AboutURLConnection
/*     */   extends URLConnection
/*     */ {
/*     */   private static final String DEFAULT_CHARSET = "UTF-8";
/*     */   private static final String DEFAULT_MIMETYPE = "text/html";
/*     */   private final AboutRecord record;
/*     */   
/*     */   AboutURLConnection(URL paramURL) {
/*  47 */     super(paramURL);
/*  48 */     this.record = new AboutRecord("");
/*     */   }
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/*  53 */     if (this.connected) {
/*     */       return;
/*     */     }
/*  56 */     this.connected = (this.record != null);
/*  57 */     if (this.connected) {
/*  58 */       this.record.content.reset();
/*     */       return;
/*     */     } 
/*  61 */     throw new ProtocolException("The URL is not valid and cannot be loaded.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  67 */     connect();
/*  68 */     return this.record.content;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*     */     try {
/*  75 */       connect();
/*  76 */       if (this.record.contentType != null) {
/*  77 */         return this.record.contentType;
/*     */       }
/*  79 */     } catch (IOException iOException) {}
/*     */     
/*  81 */     return "text/html";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentEncoding() {
/*     */     try {
/*  88 */       connect();
/*  89 */       if (this.record.contentEncoding != null) {
/*  90 */         return this.record.contentEncoding;
/*     */       }
/*  92 */     } catch (IOException iOException) {}
/*     */     
/*  94 */     return "UTF-8";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getContentLength() {
/*     */     try {
/* 101 */       connect();
/* 102 */       return this.record.contentLength;
/* 103 */     } catch (IOException iOException) {
/*     */       
/* 105 */       return -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class AboutRecord {
/*     */     private final InputStream content;
/*     */     private final int contentLength;
/*     */     private final String contentEncoding;
/*     */     private final String contentType;
/*     */     
/*     */     private AboutRecord(String param1String) {
/* 116 */       byte[] arrayOfByte = new byte[0];
/*     */       try {
/* 118 */         arrayOfByte = param1String.getBytes("UTF-8");
/* 119 */       } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */ 
/*     */       
/* 122 */       this.content = new ByteArrayInputStream(arrayOfByte);
/* 123 */       this.contentLength = arrayOfByte.length;
/* 124 */       this.contentEncoding = "UTF-8";
/* 125 */       this.contentType = "text/html";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\about\AboutURLConnection.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */