/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.WebPage;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NetworkContext
/*     */ {
/*  48 */   private static final PlatformLogger logger = PlatformLogger.getLogger(NetworkContext.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int THREAD_POOL_SIZE = 20;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long THREAD_POOL_KEEP_ALIVE_TIME = 10000L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_HTTP_MAX_CONNECTIONS = 5;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int BYTE_BUFFER_SIZE = 40960;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private static final ThreadPoolExecutor threadPool = new ThreadPoolExecutor(20, 20, 10000L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(), new URLLoaderThreadFactory());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  82 */     threadPool.allowCoreThreadTimeOut(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private static final ByteBufferPool byteBufferPool = ByteBufferPool.newInstance(40960);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NetworkContext() {
/*  96 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean canHandleURL(String paramString) {
/* 109 */     URL uRL = null;
/*     */     try {
/* 111 */       uRL = URLs.newURL(paramString);
/* 112 */     } catch (MalformedURLException malformedURLException) {}
/*     */     
/* 114 */     return (uRL != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URLLoader fwkLoad(WebPage paramWebPage, boolean paramBoolean, String paramString1, String paramString2, String paramString3, FormDataElement[] paramArrayOfFormDataElement, long paramLong) {
/* 128 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 129 */       logger.finest(String.format("webPage: [%s], asynchronous: [%s], url: [%s], method: [%s], formDataElements: %s, data: [0x%016X], headers:%n%s", new Object[] { paramWebPage, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 138 */               Boolean.valueOf(paramBoolean), paramString1, paramString2, 
/*     */ 
/*     */               
/* 141 */               (paramArrayOfFormDataElement != null) ? 
/* 142 */               Arrays.<FormDataElement>asList(paramArrayOfFormDataElement) : "[null]", 
/* 143 */               Long.valueOf(paramLong), 
/* 144 */               Util.formatHeaders(paramString3) }));
/*     */     }
/* 146 */     URLLoader uRLLoader = new URLLoader(paramWebPage, byteBufferPool, paramBoolean, paramString1, paramString2, paramString3, paramArrayOfFormDataElement, paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     if (paramBoolean) {
/* 156 */       threadPool.submit(uRLLoader);
/* 157 */       if (logger.isLoggable(PlatformLogger.Level.FINEST))
/* 158 */         logger.finest("active count: [{0}], pool size: [{1}], max pool size: [{2}], task count: [{3}], completed task count: [{4}]", new Object[] {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 165 */               Integer.valueOf(threadPool.getActiveCount()), 
/* 166 */               Integer.valueOf(threadPool.getPoolSize()), 
/* 167 */               Integer.valueOf(threadPool.getMaximumPoolSize()), 
/* 168 */               Long.valueOf(threadPool.getTaskCount()), 
/* 169 */               Long.valueOf(threadPool.getCompletedTaskCount())
/*     */             }); 
/* 171 */       return uRLLoader;
/*     */     } 
/* 173 */     uRLLoader.run();
/* 174 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int fwkGetMaximumHTTPConnectionCountPerHost() {
/* 185 */     int i = ((Integer)AccessController.<Integer>doPrivileged(() -> Integer.getInteger("http.maxConnections", -1))).intValue();
/*     */     
/* 187 */     return (i >= 0) ? i : 5;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class URLLoaderThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/*     */     private final ThreadGroup group;
/* 195 */     private final AtomicInteger index = new AtomicInteger(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     private static final Permission modifyThreadGroupPerm = new RuntimePermission("modifyThreadGroup");
/* 202 */     private static final Permission modifyThreadPerm = new RuntimePermission("modifyThread");
/*     */     
/*     */     private URLLoaderThreadFactory() {
/* 205 */       SecurityManager securityManager = System.getSecurityManager();
/* 206 */       this
/* 207 */         .group = (securityManager != null) ? securityManager.getThreadGroup() : Thread.currentThread().getThreadGroup();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable param1Runnable) {
/* 213 */       return 
/* 214 */         AccessController.<Thread>doPrivileged(() -> {
/*     */             Thread thread = new Thread(this.group, param1Runnable, "URL-Loader-" + this.index.getAndIncrement());
/*     */             thread.setDaemon(true);
/*     */             if (thread.getPriority() != 5)
/*     */               thread.setPriority(5); 
/*     */             return thread;
/*     */           }(AccessControlContext)null, new Permission[] { modifyThreadGroupPerm, modifyThreadPerm });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\NetworkContext.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */