/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.PriorityQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CookieStore
/*     */ {
/*  48 */   private static final PlatformLogger logger = PlatformLogger.getLogger(CookieStore.class.getName());
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MAX_BUCKET_SIZE = 50;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int TOTAL_COUNT_LOWER_THRESHOLD = 3000;
/*     */ 
/*     */   
/*     */   private static final int TOTAL_COUNT_UPPER_THRESHOLD = 4000;
/*     */ 
/*     */   
/*  62 */   private final Map<String, Map<Cookie, Cookie>> buckets = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private int totalCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Cookie get(Cookie paramCookie) {
/*  83 */     Map<Cookie, Cookie> map = this.buckets.get(paramCookie.getDomain());
/*  84 */     if (map == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     Cookie cookie = (Cookie)map.get(paramCookie);
/*  88 */     if (cookie == null) {
/*  89 */       return null;
/*     */     }
/*  91 */     if (cookie.hasExpired()) {
/*  92 */       map.remove(cookie);
/*  93 */       this.totalCount--;
/*  94 */       log("Expired cookie removed by get", cookie, map);
/*  95 */       return null;
/*     */     } 
/*  97 */     return cookie;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<Cookie> get(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) {
/* 107 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 108 */       logger.finest("hostname: [{0}], path: [{1}], secureProtocol: [{2}], httpApi: [{3}]", new Object[] { paramString1, paramString2, 
/*     */             
/* 110 */             Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) });
/*     */     }
/*     */     
/* 113 */     ArrayList<Cookie> arrayList = new ArrayList();
/*     */     
/* 115 */     String str = paramString1;
/* 116 */     while (str.length() > 0) {
/* 117 */       Map<Cookie, Cookie> map = this.buckets.get(str);
/* 118 */       if (map != null) {
/* 119 */         find(arrayList, map, paramString1, paramString2, paramBoolean1, paramBoolean2);
/*     */       }
/* 121 */       int i = str.indexOf('.');
/* 122 */       if (i != -1) {
/* 123 */         str = str.substring(i + 1);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 129 */     Collections.sort(arrayList, new GetComparator());
/*     */     
/* 131 */     long l = System.currentTimeMillis();
/* 132 */     for (Cookie cookie : arrayList) {
/* 133 */       cookie.setLastAccessTime(l);
/*     */     }
/*     */     
/* 136 */     logger.finest("result: {0}", new Object[] { arrayList });
/* 137 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void find(List<Cookie> paramList, Map<Cookie, Cookie> paramMap, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) {
/* 148 */     Iterator<Cookie> iterator = paramMap.values().iterator();
/* 149 */     while (iterator.hasNext()) {
/* 150 */       Cookie cookie = iterator.next();
/* 151 */       if (cookie.hasExpired()) {
/* 152 */         iterator.remove();
/* 153 */         this.totalCount--;
/* 154 */         log("Expired cookie removed by find", cookie, paramMap);
/*     */         
/*     */         continue;
/*     */       } 
/* 158 */       if (cookie.getHostOnly() ? 
/* 159 */         !paramString1.equalsIgnoreCase(cookie.getDomain()) : 
/*     */ 
/*     */ 
/*     */         
/* 163 */         !Cookie.domainMatches(paramString1, cookie.getDomain())) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 168 */       if (!Cookie.pathMatches(paramString2, cookie.getPath())) {
/*     */         continue;
/*     */       }
/*     */       
/* 172 */       if (cookie.getSecureOnly() && !paramBoolean1) {
/*     */         continue;
/*     */       }
/*     */       
/* 176 */       if (cookie.getHttpOnly() && !paramBoolean2) {
/*     */         continue;
/*     */       }
/*     */       
/* 180 */       paramList.add(cookie);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class GetComparator
/*     */     implements Comparator<Cookie> {
/*     */     public int compare(Cookie param1Cookie1, Cookie param1Cookie2) {
/* 187 */       int i = param1Cookie2.getPath().length() - param1Cookie1.getPath().length();
/* 188 */       if (i != 0) {
/* 189 */         return i;
/*     */       }
/* 191 */       return param1Cookie1.getCreationTime().compareTo(param1Cookie2.getCreationTime());
/*     */     }
/*     */ 
/*     */     
/*     */     private GetComparator() {}
/*     */   }
/*     */   
/*     */   void put(Cookie paramCookie) {
/* 199 */     Map<Object, Object> map = (Map)this.buckets.get(paramCookie.getDomain());
/* 200 */     if (map == null) {
/* 201 */       map = new LinkedHashMap<>(20);
/* 202 */       this.buckets.put(paramCookie.getDomain(), map);
/*     */     } 
/* 204 */     if (paramCookie.hasExpired()) {
/* 205 */       log("Cookie expired", paramCookie, (Map)map);
/* 206 */       if (map.remove(paramCookie) != null) {
/* 207 */         this.totalCount--;
/* 208 */         log("Expired cookie removed by put", paramCookie, (Map)map);
/*     */       }
/*     */     
/* 211 */     } else if (map.put(paramCookie, paramCookie) == null) {
/* 212 */       this.totalCount++;
/* 213 */       log("Cookie added", paramCookie, (Map)map);
/* 214 */       if (map.size() > 50) {
/* 215 */         purge((Map)map);
/*     */       }
/* 217 */       if (this.totalCount > 4000) {
/* 218 */         purge();
/*     */       }
/*     */     } else {
/* 221 */       log("Cookie updated", paramCookie, (Map)map);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void purge(Map<Cookie, Cookie> paramMap) {
/* 230 */     logger.finest("Purging bucket: {0}", new Object[] { paramMap.values() });
/*     */     
/* 232 */     Cookie cookie = null;
/* 233 */     Iterator<Cookie> iterator = paramMap.values().iterator();
/* 234 */     while (iterator.hasNext()) {
/* 235 */       Cookie cookie1 = iterator.next();
/* 236 */       if (cookie1.hasExpired()) {
/* 237 */         iterator.remove();
/* 238 */         this.totalCount--;
/* 239 */         log("Expired cookie removed", cookie1, paramMap); continue;
/*     */       } 
/* 241 */       if (cookie == null || cookie1.getLastAccessTime() < cookie
/* 242 */         .getLastAccessTime())
/*     */       {
/* 244 */         cookie = cookie1;
/*     */       }
/*     */     } 
/*     */     
/* 248 */     if (paramMap.size() > 50) {
/* 249 */       paramMap.remove(cookie);
/* 250 */       this.totalCount--;
/* 251 */       log("Excess cookie removed", cookie, paramMap);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void purge() {
/* 259 */     logger.finest("Purging store");
/*     */     
/* 261 */     PriorityQueue<Cookie> priorityQueue = new PriorityQueue(this.totalCount / 2, new RemovalComparator());
/*     */ 
/*     */     
/* 264 */     for (Map.Entry<String, Map<Cookie, Cookie>> entry : this.buckets.entrySet()) {
/* 265 */       Map<Cookie, Cookie> map = (Map)entry.getValue();
/* 266 */       Iterator<Cookie> iterator = map.values().iterator();
/* 267 */       while (iterator.hasNext()) {
/* 268 */         Cookie cookie = iterator.next();
/* 269 */         if (cookie.hasExpired()) {
/* 270 */           iterator.remove();
/* 271 */           this.totalCount--;
/* 272 */           log("Expired cookie removed", cookie, map); continue;
/*     */         } 
/* 274 */         priorityQueue.add(cookie);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 279 */     while (this.totalCount > 3000) {
/* 280 */       Cookie cookie = priorityQueue.remove();
/* 281 */       Map<Cookie, Cookie> map = this.buckets.get(cookie.getDomain());
/* 282 */       if (map != null) {
/* 283 */         map.remove(cookie);
/* 284 */         this.totalCount--;
/* 285 */         log("Excess cookie removed", cookie, map);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class RemovalComparator implements Comparator<Cookie> { private RemovalComparator() {}
/*     */     
/*     */     public int compare(Cookie param1Cookie1, Cookie param1Cookie2) {
/* 293 */       return (int)(param1Cookie1.getLastAccessTime() - param1Cookie2.getLastAccessTime());
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void log(String paramString, Cookie paramCookie, Map<Cookie, Cookie> paramMap) {
/* 303 */     if (logger.isLoggable(PlatformLogger.Level.FINEST))
/* 304 */       logger.finest("{0}: {1}, bucket size: {2}, total count: {3}", new Object[] { paramString, paramCookie, 
/* 305 */             Integer.valueOf(paramMap.size()), Integer.valueOf(this.totalCount) }); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\CookieStore.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */