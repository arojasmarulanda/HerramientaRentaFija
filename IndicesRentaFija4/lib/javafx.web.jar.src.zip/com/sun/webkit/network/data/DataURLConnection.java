/*     */ package com.sun.webkit.network.data;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Base64;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DataURLConnection
/*     */   extends URLConnection
/*     */ {
/*  51 */   private static final Charset US_ASCII = Charset.forName("US-ASCII");
/*     */   
/*     */   private final String mediaType;
/*     */   
/*     */   private final byte[] data;
/*     */   
/*     */   private final InputStream inputStream;
/*     */   
/*     */   DataURLConnection(URL paramURL) throws IOException {
/*  60 */     super(paramURL);
/*     */     
/*  62 */     String str1 = paramURL.toString();
/*  63 */     str1 = str1.substring(str1.indexOf(':') + 1);
/*     */     
/*  65 */     int i = str1.indexOf(',');
/*  66 */     if (i < 0) {
/*  67 */       throw new ProtocolException("Invalid URL, ',' not found in: " + 
/*  68 */           getURL());
/*     */     }
/*     */     
/*  71 */     String str2 = str1.substring(0, i);
/*  72 */     String str3 = str1.substring(i + 1);
/*     */     
/*  74 */     String str4 = null;
/*  75 */     LinkedList<String> linkedList = new LinkedList();
/*  76 */     Charset charset = null;
/*  77 */     boolean bool = false;
/*     */     
/*  79 */     String[] arrayOfString = str2.split(";", -1);
/*  80 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*  81 */       String str = arrayOfString[b];
/*  82 */       if (str.equalsIgnoreCase("base64")) {
/*  83 */         bool = true;
/*     */       }
/*  85 */       else if (b == 0 && !str.contains("=")) {
/*  86 */         str4 = str;
/*     */       } else {
/*  88 */         linkedList.add(str);
/*  89 */         if (str.toLowerCase().startsWith("charset=")) {
/*     */           try {
/*  91 */             charset = Charset.forName(str.substring(8));
/*  92 */           } catch (IllegalArgumentException illegalArgumentException) {
/*  93 */             UnsupportedEncodingException unsupportedEncodingException = new UnsupportedEncodingException();
/*     */             
/*  95 */             unsupportedEncodingException.initCause(illegalArgumentException);
/*  96 */             throw unsupportedEncodingException;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 103 */     if (str4 == null || str4.isEmpty()) {
/* 104 */       str4 = "text/plain";
/*     */     }
/*     */     
/* 107 */     if (charset == null) {
/* 108 */       charset = US_ASCII;
/* 109 */       if (str4.toLowerCase().startsWith("text/")) {
/* 110 */         linkedList.addFirst("charset=" + charset.name());
/*     */       }
/*     */     } 
/*     */     
/* 114 */     StringBuilder stringBuilder = new StringBuilder();
/* 115 */     stringBuilder.append(str4);
/* 116 */     for (String str : linkedList) {
/* 117 */       stringBuilder.append(';').append(str);
/*     */     }
/* 119 */     this.mediaType = stringBuilder.toString();
/*     */     
/* 121 */     if (bool) {
/* 122 */       String str = urlDecode(str3, US_ASCII);
/* 123 */       str = str.replaceAll("\\s+", "");
/* 124 */       this.data = Base64.getMimeDecoder().decode(str);
/*     */     } else {
/* 126 */       String str = urlDecode(str3, charset);
/* 127 */       this.data = str.getBytes(charset);
/*     */     } 
/*     */     
/* 130 */     this.inputStream = new ByteArrayInputStream(this.data);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect() {
/* 136 */     this.connected = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() {
/* 141 */     return this.inputStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 146 */     return this.mediaType;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentEncoding() {
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getContentLength() {
/* 157 */     return (this.data != null) ? this.data.length : -1;
/*     */   }
/*     */   
/*     */   private static String urlDecode(String paramString, Charset paramCharset) {
/* 161 */     int i = paramString.length();
/* 162 */     StringBuilder stringBuilder = new StringBuilder(i);
/* 163 */     byte[] arrayOfByte = null;
/*     */     
/* 165 */     byte b = 0;
/* 166 */     while (b < i) {
/* 167 */       char c = paramString.charAt(b);
/* 168 */       if (c == '%') {
/*     */         
/* 170 */         if (arrayOfByte == null) {
/* 171 */           arrayOfByte = new byte[(i - b) / 3];
/*     */         }
/* 173 */         byte b1 = 0;
/* 174 */         int j = b;
/* 175 */         for (; b < i; b += 3) {
/* 176 */           byte b2; c = paramString.charAt(b);
/* 177 */           if (c != '%') {
/*     */             break;
/*     */           }
/*     */           
/* 181 */           if (b + 2 >= i) {
/*     */ 
/*     */ 
/*     */             
/* 185 */             j = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */           try {
/* 190 */             b2 = (byte)Integer.parseInt(paramString
/* 191 */                 .substring(b + 1, b + 3), 16);
/* 192 */           } catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */             
/* 195 */             j = b + 3;
/*     */             break;
/*     */           } 
/* 198 */           arrayOfByte[b1++] = b2;
/*     */         } 
/* 200 */         if (b1 > 0) {
/* 201 */           stringBuilder.append(new String(arrayOfByte, 0, b1, paramCharset));
/*     */         }
/* 203 */         while (b < j)
/* 204 */           stringBuilder.append(paramString.charAt(b++)); 
/*     */         continue;
/*     */       } 
/* 207 */       stringBuilder.append(c);
/* 208 */       b++;
/*     */     } 
/*     */ 
/*     */     
/* 212 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\data\DataURLConnection.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */