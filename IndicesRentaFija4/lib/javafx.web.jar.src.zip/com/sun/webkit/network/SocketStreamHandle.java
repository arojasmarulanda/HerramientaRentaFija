/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.Invoker;
/*     */ import com.sun.webkit.WebPage;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.ConnectException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.NoRouteToHostException;
/*     */ import java.net.PortUnreachableException;
/*     */ import java.net.Proxy;
/*     */ import java.net.ProxySelector;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.AccessController;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import javax.net.ssl.SSLException;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SocketStreamHandle
/*     */ {
/*  60 */   private static final Pattern FIRST_LINE_PATTERN = Pattern.compile("^HTTP/1.[01]\\s+(\\d{3})(?:\\s.*)?$");
/*     */   
/*  62 */   private static final PlatformLogger logger = PlatformLogger.getLogger(SocketStreamHandle.class
/*  63 */       .getName());
/*  64 */   private static final ThreadPoolExecutor threadPool = new ThreadPoolExecutor(0, 2147483647, 10L, TimeUnit.SECONDS, new SynchronousQueue<>(), new CustomThreadFactory()); private final String host; private final int port;
/*     */   private final boolean ssl;
/*     */   private final WebPage webPage;
/*     */   private final long data;
/*     */   private volatile Socket socket;
/*     */   
/*  70 */   private enum State { ACTIVE, CLOSE_REQUESTED, DISPOSED; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private volatile State state = State.ACTIVE;
/*     */   
/*     */   private volatile boolean connected;
/*     */ 
/*     */   
/*     */   private SocketStreamHandle(String paramString, int paramInt, boolean paramBoolean, WebPage paramWebPage, long paramLong) {
/*  84 */     this.host = paramString;
/*  85 */     this.port = paramInt;
/*  86 */     this.ssl = paramBoolean;
/*  87 */     this.webPage = paramWebPage;
/*  88 */     this.data = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SocketStreamHandle fwkCreate(String paramString, int paramInt, boolean paramBoolean, WebPage paramWebPage, long paramLong) {
/*  95 */     SocketStreamHandle socketStreamHandle = new SocketStreamHandle(paramString, paramInt, paramBoolean, paramWebPage, paramLong);
/*     */     
/*  97 */     logger.finest("Starting {0}", new Object[] { socketStreamHandle });
/*  98 */     threadPool.submit(() -> paramSocketStreamHandle.run());
/*     */ 
/*     */     
/* 101 */     return socketStreamHandle;
/*     */   }
/*     */   
/*     */   private void run() {
/* 105 */     if (this.webPage == null) {
/* 106 */       logger.finest("{0} is not associated with any web page, aborted", new Object[] { this });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 112 */       didFail(0, "Web socket is not associated with any web page");
/* 113 */       didClose();
/*     */       return;
/*     */     } 
/* 116 */     AccessController.doPrivileged(() -> { doRun(); return null; }this.webPage
/*     */ 
/*     */         
/* 119 */         .getAccessControlContext());
/*     */   }
/*     */   
/*     */   private void doRun() {
/* 123 */     Throwable throwable = null;
/* 124 */     String str = null;
/*     */     try {
/* 126 */       logger.finest("{0} started", new Object[] { this });
/* 127 */       connect();
/* 128 */       this.connected = true;
/* 129 */       logger.finest("{0} connected", new Object[] { this });
/* 130 */       didOpen();
/* 131 */       InputStream inputStream = this.socket.getInputStream();
/*     */       while (true) {
/* 133 */         byte[] arrayOfByte = new byte[8192];
/* 134 */         int i = inputStream.read(arrayOfByte);
/* 135 */         if (i > 0) {
/* 136 */           if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 137 */             logger.finest(String.format("%s received len: [%d], data:%s", new Object[] { this, 
/* 138 */                     Integer.valueOf(i), dump(arrayOfByte, i) }));
/*     */           }
/* 140 */           didReceiveData(arrayOfByte, i); continue;
/*     */         }  break;
/* 142 */       }  logger.finest("{0} connection closed by remote host", new Object[] { this });
/*     */ 
/*     */     
/*     */     }
/* 146 */     catch (UnknownHostException unknownHostException) {
/* 147 */       throwable = unknownHostException;
/* 148 */       str = "Unknown host";
/* 149 */     } catch (ConnectException connectException2) {
/* 150 */       ConnectException connectException1 = connectException2;
/* 151 */       str = "Unable to connect";
/* 152 */     } catch (NoRouteToHostException noRouteToHostException2) {
/* 153 */       NoRouteToHostException noRouteToHostException1 = noRouteToHostException2;
/* 154 */       str = "No route to host";
/* 155 */     } catch (PortUnreachableException portUnreachableException2) {
/* 156 */       PortUnreachableException portUnreachableException1 = portUnreachableException2;
/* 157 */       str = "Port unreachable";
/* 158 */     } catch (SocketException socketException) {
/* 159 */       if (this.state != State.ACTIVE) {
/* 160 */         if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 161 */           logger.finest(String.format("%s exception (most likely caused by local close)", new Object[] { this }), socketException);
/*     */         }
/*     */       } else {
/*     */         
/* 165 */         SocketException socketException1 = socketException;
/* 166 */         str = "Socket error";
/*     */       } 
/* 168 */     } catch (SSLException sSLException2) {
/* 169 */       SSLException sSLException1 = sSLException2;
/* 170 */       str = "SSL error";
/* 171 */     } catch (IOException iOException2) {
/* 172 */       IOException iOException1 = iOException2;
/* 173 */       str = "I/O error";
/* 174 */     } catch (SecurityException securityException2) {
/* 175 */       SecurityException securityException1 = securityException2;
/* 176 */       str = "Security error";
/* 177 */     } catch (Throwable throwable1) {
/* 178 */       throwable = throwable1;
/*     */     } 
/*     */     
/* 181 */     if (throwable != null) {
/* 182 */       if (str == null) {
/* 183 */         str = "Unknown error";
/* 184 */         logger.warning(String.format("%s unexpected error", new Object[] { this }), throwable);
/*     */       } else {
/* 186 */         logger.finest(String.format("%s exception", new Object[] { this }), throwable);
/*     */       } 
/* 188 */       didFail(0, str);
/*     */     } 
/*     */     
/*     */     try {
/* 192 */       this.socket.close();
/* 193 */     } catch (IOException iOException) {}
/* 194 */     didClose();
/*     */     
/* 196 */     logger.finest("{0} finished", new Object[] { this });
/*     */   }
/*     */   
/*     */   private void connect() throws IOException {
/* 200 */     SecurityManager securityManager = System.getSecurityManager();
/* 201 */     if (securityManager != null) {
/* 202 */       securityManager.checkConnect(this.host, this.port);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 207 */     boolean bool1 = false;
/* 208 */     IOException iOException = null;
/* 209 */     boolean bool2 = false;
/* 210 */     ProxySelector proxySelector = AccessController.<ProxySelector>doPrivileged(() -> ProxySelector.getDefault());
/*     */     
/* 212 */     if (proxySelector != null) {
/*     */       URI uRI;
/*     */       try {
/* 215 */         uRI = new URI((this.ssl ? "https" : "http") + "://" + (this.ssl ? "https" : "http"));
/* 216 */       } catch (URISyntaxException uRISyntaxException) {
/* 217 */         throw new IOException(uRISyntaxException);
/*     */       } 
/* 219 */       if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 220 */         logger.finest(String.format("%s selecting proxies for: [%s]", new Object[] { this, uRI }));
/*     */       }
/* 222 */       List<Proxy> list = proxySelector.select(uRI);
/* 223 */       if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 224 */         logger.finest(String.format("%s selected proxies: %s", new Object[] { this, list }));
/*     */       }
/* 226 */       for (Proxy proxy : list) {
/* 227 */         if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 228 */           logger.finest(String.format("%s trying proxy: [%s]", new Object[] { this, proxy }));
/*     */         }
/* 230 */         if (proxy.type() == Proxy.Type.DIRECT) {
/* 231 */           bool2 = true;
/*     */         }
/*     */         try {
/* 234 */           connect(proxy);
/* 235 */           bool1 = true;
/*     */           break;
/* 237 */         } catch (IOException iOException1) {
/* 238 */           logger.finest(String.format("%s exception", new Object[] { this }), iOException1);
/* 239 */           iOException = iOException1;
/* 240 */           if (proxy.address() != null) {
/* 241 */             proxySelector.connectFailed(uRI, proxy.address(), iOException1);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 247 */     if (!bool1 && !bool2) {
/* 248 */       logger.finest("{0} trying direct connection", new Object[] { this });
/* 249 */       connect(Proxy.NO_PROXY);
/* 250 */       bool1 = true;
/*     */     } 
/* 252 */     if (!bool1) {
/* 253 */       throw iOException;
/*     */     }
/*     */   }
/*     */   
/*     */   private void connect(Proxy paramProxy) throws IOException {
/* 258 */     synchronized (this) {
/* 259 */       if (this.state != State.ACTIVE) {
/* 260 */         throw new SocketException("Close requested");
/*     */       }
/* 262 */       this.socket = new Socket(paramProxy);
/*     */     } 
/* 264 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 265 */       logger.finest(String.format("%s connecting to: [%s:%d]", new Object[] { this, this.host, 
/* 266 */               Integer.valueOf(this.port) }));
/*     */     }
/* 268 */     this.socket.connect(new InetSocketAddress(this.host, this.port));
/* 269 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 270 */       logger.finest(String.format("%s connected to: [%s:%d]", new Object[] { this, this.host, 
/* 271 */               Integer.valueOf(this.port) }));
/*     */     }
/* 273 */     if (this.ssl) {
/* 274 */       synchronized (this) {
/* 275 */         if (this.state != State.ACTIVE) {
/* 276 */           throw new SocketException("Close requested");
/*     */         }
/* 278 */         logger.finest("{0} starting SSL handshake", new Object[] { this });
/* 279 */         this
/* 280 */           .socket = HttpsURLConnection.getDefaultSSLSocketFactory().createSocket(this.socket, this.host, this.port, true);
/*     */       } 
/* 282 */       ((SSLSocket)this.socket).startHandshake();
/*     */     } 
/*     */   }
/*     */   
/*     */   private int fwkSend(byte[] paramArrayOfbyte) {
/* 287 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 288 */       logger.finest(String.format("%s sending len: [%d], data:%s", new Object[] { this, 
/* 289 */               Integer.valueOf(paramArrayOfbyte.length), dump(paramArrayOfbyte, paramArrayOfbyte.length) }));
/*     */     }
/* 291 */     if (this.connected) {
/*     */       try {
/* 293 */         this.socket.getOutputStream().write(paramArrayOfbyte);
/* 294 */         return paramArrayOfbyte.length;
/* 295 */       } catch (IOException iOException) {
/* 296 */         logger.finest(String.format("%s exception", new Object[] { this }), iOException);
/* 297 */         didFail(0, "I/O error");
/* 298 */         return 0;
/*     */       } 
/*     */     }
/* 301 */     logger.finest("{0} not connected", new Object[] { this });
/* 302 */     didFail(0, "Not connected");
/* 303 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private void fwkClose() {
/* 308 */     synchronized (this) {
/* 309 */       logger.finest("{0}", new Object[] { this });
/* 310 */       this.state = State.CLOSE_REQUESTED;
/*     */       try {
/* 312 */         if (this.socket != null) {
/* 313 */           this.socket.close();
/*     */         }
/* 315 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fwkNotifyDisposed() {
/* 320 */     logger.finest("{0}", new Object[] { this });
/* 321 */     this.state = State.DISPOSED;
/*     */   }
/*     */   
/*     */   private void didOpen() {
/* 325 */     Invoker.getInvoker().postOnEventThread(() -> {
/*     */           if (this.state == State.ACTIVE) {
/*     */             notifyDidOpen();
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void didReceiveData(byte[] paramArrayOfbyte, int paramInt) {
/* 333 */     Invoker.getInvoker().postOnEventThread(() -> {
/*     */           if (this.state == State.ACTIVE) {
/*     */             notifyDidReceiveData(paramArrayOfbyte, paramInt);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void didFail(int paramInt, String paramString) {
/* 341 */     Invoker.getInvoker().postOnEventThread(() -> {
/*     */           if (this.state == State.ACTIVE) {
/*     */             notifyDidFail(paramInt, paramString);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void didClose() {
/* 349 */     Invoker.getInvoker().postOnEventThread(() -> {
/*     */           if (this.state != State.DISPOSED) {
/*     */             notifyDidClose();
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void notifyDidOpen() {
/* 357 */     logger.finest("{0}", new Object[] { this });
/* 358 */     twkDidOpen(this.data);
/*     */   }
/*     */   
/*     */   private void notifyDidReceiveData(byte[] paramArrayOfbyte, int paramInt) {
/* 362 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 363 */       logger.finest(String.format("%s, len: [%d], data:%s", new Object[] { this, 
/* 364 */               Integer.valueOf(paramInt), dump(paramArrayOfbyte, paramInt) }));
/*     */     }
/* 366 */     twkDidReceiveData(paramArrayOfbyte, paramInt, this.data);
/*     */   }
/*     */   
/*     */   private void notifyDidFail(int paramInt, String paramString) {
/* 370 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 371 */       logger.finest(String.format("%s, errorCode: %d, errorDescription: %s", new Object[] { this, 
/*     */               
/* 373 */               Integer.valueOf(paramInt), paramString }));
/*     */     }
/* 375 */     twkDidFail(paramInt, paramString, this.data);
/*     */   }
/*     */   
/*     */   private void notifyDidClose() {
/* 379 */     logger.finest("{0}", new Object[] { this });
/* 380 */     twkDidClose(this.data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String dump(byte[] paramArrayOfbyte, int paramInt) {
/* 391 */     StringBuilder stringBuilder = new StringBuilder();
/* 392 */     byte b = 0;
/* 393 */     while (b < paramInt) {
/* 394 */       StringBuilder stringBuilder1 = new StringBuilder();
/* 395 */       StringBuilder stringBuilder2 = new StringBuilder();
/* 396 */       for (byte b1 = 0; b1 < 16; b1++, b++) {
/* 397 */         if (b < paramInt) {
/* 398 */           int i = paramArrayOfbyte[b] & 0xFF;
/* 399 */           stringBuilder1.append(String.format("%02x ", new Object[] { Integer.valueOf(i) }));
/* 400 */           stringBuilder2.append((i >= 32 && i <= 126) ? (char)i : 46);
/*     */         } else {
/* 402 */           stringBuilder1.append("   ");
/*     */         } 
/*     */       } 
/* 405 */       stringBuilder.append(String.format("%n  ", new Object[0])).append(stringBuilder1).append(' ').append(stringBuilder2);
/*     */     } 
/* 407 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 412 */     return String.format("SocketStreamHandle{host=%s, port=%d, ssl=%s, data=0x%016X, state=%s, connected=%s}", new Object[] { this.host, 
/*     */           
/* 414 */           Integer.valueOf(this.port), Boolean.valueOf(this.ssl), Long.valueOf(this.data), this.state, Boolean.valueOf(this.connected) });
/*     */   } private static native void twkDidOpen(long paramLong);
/*     */   private static native void twkDidReceiveData(byte[] paramArrayOfbyte, int paramInt, long paramLong);
/*     */   private static native void twkDidFail(int paramInt, String paramString, long paramLong);
/*     */   private static native void twkDidClose(long paramLong);
/* 419 */   private static final class CustomThreadFactory implements ThreadFactory { private final AtomicInteger index = new AtomicInteger(1); private final ThreadGroup group;
/*     */     
/*     */     private CustomThreadFactory() {
/* 422 */       SecurityManager securityManager = System.getSecurityManager();
/* 423 */       this
/* 424 */         .group = (securityManager != null) ? securityManager.getThreadGroup() : Thread.currentThread().getThreadGroup();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable param1Runnable) {
/* 430 */       Thread thread = new Thread(this.group, param1Runnable, "SocketStreamHandle-" + this.index.getAndIncrement());
/* 431 */       thread.setDaemon(true);
/* 432 */       if (thread.getPriority() != 5) {
/* 433 */         thread.setPriority(5);
/*     */       }
/* 435 */       return thread;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\SocketStreamHandle.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */