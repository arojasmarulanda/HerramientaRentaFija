/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import java.net.CookieHandler;
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CookieManager
/*     */   extends CookieHandler
/*     */ {
/*  46 */   private static final PlatformLogger logger = PlatformLogger.getLogger(CookieManager.class.getName());
/*     */ 
/*     */   
/*  49 */   private final CookieStore store = new CookieStore();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> get(URI paramURI, Map<String, List<String>> paramMap) {
/*     */     Map<?, ?> map;
/*  66 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/*  67 */       logger.finest("uri: [{0}], requestHeaders: {1}", new Object[] { paramURI, 
/*  68 */             toLogString(paramMap) });
/*     */     }
/*     */     
/*  71 */     if (paramURI == null) {
/*  72 */       throw new IllegalArgumentException("uri is null");
/*     */     }
/*  74 */     if (paramMap == null) {
/*  75 */       throw new IllegalArgumentException("requestHeaders is null");
/*     */     }
/*     */     
/*  78 */     String str = get(paramURI);
/*     */ 
/*     */     
/*  81 */     if (str != null) {
/*  82 */       map = new HashMap<>();
/*  83 */       map.put("Cookie", Arrays.asList(new String[] { str }));
/*     */     } else {
/*  85 */       map = Collections.emptyMap();
/*     */     } 
/*  87 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/*  88 */       logger.finest("result: {0}", new Object[] { toLogString((Map)map) });
/*     */     }
/*  90 */     return (Map)map;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String get(URI paramURI) {
/*     */     List<Cookie> list;
/*  97 */     String str1 = paramURI.getHost();
/*  98 */     if (str1 == null || str1.length() == 0) {
/*  99 */       logger.finest("Null or empty URI host, returning null");
/* 100 */       return null;
/*     */     } 
/* 102 */     str1 = canonicalize(str1);
/*     */     
/* 104 */     String str2 = paramURI.getScheme();
/*     */     
/* 106 */     boolean bool1 = ("https".equalsIgnoreCase(str2) || "javascripts".equalsIgnoreCase(str2)) ? true : false;
/*     */     
/* 108 */     boolean bool2 = ("http".equalsIgnoreCase(str2) || "https".equalsIgnoreCase(str2)) ? true : false;
/*     */ 
/*     */     
/* 111 */     synchronized (this.store) {
/* 112 */       list = this.store.get(str1, paramURI.getPath(), bool1, bool2);
/*     */     } 
/*     */ 
/*     */     
/* 116 */     StringBuilder stringBuilder = new StringBuilder();
/* 117 */     for (Cookie cookie : list) {
/* 118 */       if (stringBuilder.length() > 0) {
/* 119 */         stringBuilder.append("; ");
/*     */       }
/* 121 */       stringBuilder.append(cookie.getName());
/* 122 */       stringBuilder.append('=');
/* 123 */       stringBuilder.append(cookie.getValue());
/*     */     } 
/*     */     
/* 126 */     return (stringBuilder.length() > 0) ? stringBuilder.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(URI paramURI, Map<String, List<String>> paramMap) {
/* 134 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 135 */       logger.finest("uri: [{0}], responseHeaders: {1}", new Object[] { paramURI, 
/* 136 */             toLogString(paramMap) });
/*     */     }
/*     */     
/* 139 */     if (paramURI == null) {
/* 140 */       throw new IllegalArgumentException("uri is null");
/*     */     }
/* 142 */     if (paramMap == null) {
/* 143 */       throw new IllegalArgumentException("responseHeaders is null");
/*     */     }
/*     */     
/* 146 */     for (Map.Entry<String, List<String>> entry : paramMap.entrySet()) {
/*     */       
/* 148 */       String str = (String)entry.getKey();
/* 149 */       if (!"Set-Cookie".equalsIgnoreCase(str)) {
/*     */         continue;
/*     */       }
/* 152 */       ExtendedTime extendedTime = ExtendedTime.currentTime();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 158 */       ListIterator<String> listIterator = ((List)entry.getValue()).listIterator(((List)entry.getValue()).size());
/* 159 */       while (listIterator.hasPrevious()) {
/* 160 */         Cookie cookie = Cookie.parse(listIterator.previous(), extendedTime);
/* 161 */         if (cookie != null) {
/* 162 */           put(paramURI, cookie);
/* 163 */           extendedTime = extendedTime.incrementSubtime();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void put(URI paramURI, Cookie paramCookie) {
/* 173 */     logger.finest("cookie: {0}", new Object[] { paramCookie });
/*     */     
/* 175 */     String str = paramURI.getHost();
/* 176 */     if (str == null || str.length() == 0) {
/* 177 */       logger.finest("Null or empty URI host, ignoring cookie");
/*     */       return;
/*     */     } 
/* 180 */     str = canonicalize(str);
/*     */     
/* 182 */     if (PublicSuffixes.isPublicSuffix(paramCookie.getDomain())) {
/* 183 */       if (paramCookie.getDomain().equals(str)) {
/* 184 */         paramCookie.setDomain("");
/*     */       } else {
/* 186 */         logger.finest("Domain is public suffix, ignoring cookie");
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/*     */     
/* 192 */     if (paramCookie.getDomain().length() > 0) {
/* 193 */       if (!Cookie.domainMatches(str, paramCookie.getDomain())) {
/* 194 */         logger.finest("Hostname does not match domain, ignoring cookie");
/*     */         
/*     */         return;
/*     */       } 
/* 198 */       paramCookie.setHostOnly(false);
/*     */     } else {
/*     */       
/* 201 */       paramCookie.setHostOnly(true);
/* 202 */       paramCookie.setDomain(str);
/*     */     } 
/*     */     
/* 205 */     if (paramCookie.getPath() == null) {
/* 206 */       paramCookie.setPath(Cookie.defaultPath(paramURI));
/*     */     }
/*     */ 
/*     */     
/* 210 */     boolean bool = ("http".equalsIgnoreCase(paramURI.getScheme()) || "https".equalsIgnoreCase(paramURI.getScheme())) ? true : false;
/* 211 */     if (paramCookie.getHttpOnly() && !bool) {
/* 212 */       logger.finest("HttpOnly cookie received from non-HTTP API, ignoring cookie");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 217 */     synchronized (this.store) {
/* 218 */       Cookie cookie = this.store.get(paramCookie);
/* 219 */       if (cookie != null) {
/* 220 */         if (cookie.getHttpOnly() && !bool) {
/* 221 */           logger.finest("Non-HTTP API attempts to overwrite HttpOnly cookie, blocked");
/*     */           
/*     */           return;
/*     */         } 
/* 225 */         paramCookie.setCreationTime(cookie.getCreationTime());
/*     */       } 
/*     */       
/* 228 */       this.store.put(paramCookie);
/*     */     } 
/*     */     
/* 231 */     logger.finest("Stored: {0}", new Object[] { paramCookie });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String toLogString(Map<String, List<String>> paramMap) {
/* 239 */     if (paramMap == null) {
/* 240 */       return null;
/*     */     }
/* 242 */     if (paramMap.isEmpty()) {
/* 243 */       return "{}";
/*     */     }
/* 245 */     StringBuilder stringBuilder = new StringBuilder();
/* 246 */     for (Map.Entry<String, List<String>> entry : paramMap.entrySet()) {
/* 247 */       String str = (String)entry.getKey();
/* 248 */       for (String str1 : entry.getValue()) {
/* 249 */         stringBuilder.append(String.format("%n    ", new Object[0]));
/* 250 */         stringBuilder.append(str);
/* 251 */         stringBuilder.append(": ");
/* 252 */         stringBuilder.append(str1);
/*     */       } 
/*     */     } 
/* 255 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String canonicalize(String paramString) {
/* 263 */     return paramString.toLowerCase();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\CookieManager.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */