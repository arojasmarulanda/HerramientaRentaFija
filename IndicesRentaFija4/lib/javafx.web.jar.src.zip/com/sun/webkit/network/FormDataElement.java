/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class FormDataElement
/*     */ {
/*     */   private InputStream inputStream;
/*     */   
/*     */   void open() throws IOException {
/*  52 */     this.inputStream = createInputStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getSize() {
/*  59 */     if (this.inputStream == null) {
/*  60 */       throw new IllegalStateException();
/*     */     }
/*  62 */     return doGetSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getInputStream() {
/*  70 */     if (this.inputStream == null) {
/*  71 */       throw new IllegalStateException();
/*     */     }
/*  73 */     return this.inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void close() throws IOException {
/*  83 */     if (this.inputStream != null) {
/*  84 */       this.inputStream.close();
/*  85 */       this.inputStream = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract InputStream createInputStream() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract long doGetSize();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FormDataElement fwkCreateFromByteArray(byte[] paramArrayOfbyte) {
/* 105 */     return new ByteArrayElement(paramArrayOfbyte);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FormDataElement fwkCreateFromFile(String paramString) {
/* 112 */     return new FileElement(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ByteArrayElement
/*     */     extends FormDataElement
/*     */   {
/*     */     private final byte[] byteArray;
/*     */ 
/*     */     
/*     */     private ByteArrayElement(byte[] param1ArrayOfbyte) {
/* 124 */       this.byteArray = param1ArrayOfbyte;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected InputStream createInputStream() {
/* 130 */       return new ByteArrayInputStream(this.byteArray);
/*     */     }
/*     */ 
/*     */     
/*     */     protected long doGetSize() {
/* 135 */       return this.byteArray.length;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class FileElement
/*     */     extends FormDataElement
/*     */   {
/*     */     private final File file;
/*     */ 
/*     */     
/*     */     private FileElement(String param1String) {
/* 148 */       this.file = new File(param1String);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected InputStream createInputStream() throws IOException {
/* 154 */       return new BufferedInputStream(new FileInputStream(this.file));
/*     */     }
/*     */ 
/*     */     
/*     */     protected long doGetSize() {
/* 159 */       return this.file.length();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\FormDataElement.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */