/*      */ package com.sun.webkit.network;
/*      */ 
/*      */ import com.sun.javafx.logging.PlatformLogger;
/*      */ import com.sun.webkit.Invoker;
/*      */ import com.sun.webkit.WebPage;
/*      */ import java.io.EOFException;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.ConnectException;
/*      */ import java.net.HttpRetryException;
/*      */ import java.net.HttpURLConnection;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.NoRouteToHostException;
/*      */ import java.net.SocketException;
/*      */ import java.net.SocketTimeoutException;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.net.URLDecoder;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.security.AccessControlException;
/*      */ import java.security.AccessController;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.zip.GZIPInputStream;
/*      */ import java.util.zip.InflaterInputStream;
/*      */ import javax.net.ssl.SSLHandshakeException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class URLLoader
/*      */   implements Runnable
/*      */ {
/*      */   public static final int ALLOW_UNASSIGNED = 1;
/*   73 */   private static final PlatformLogger logger = PlatformLogger.getLogger(URLLoader.class.getName());
/*      */   
/*      */   private static final int MAX_REDIRECTS = 10;
/*      */   
/*      */   private static final int MAX_BUF_COUNT = 3;
/*      */   
/*      */   private static final String GET = "GET";
/*      */   
/*      */   private static final String HEAD = "HEAD";
/*      */   
/*      */   private static final String DELETE = "DELETE";
/*      */   
/*      */   private final WebPage webPage;
/*      */   
/*      */   private final ByteBufferPool byteBufferPool;
/*      */   
/*      */   private final boolean asynchronous;
/*      */   
/*      */   private String url;
/*      */   
/*      */   private String method;
/*      */   
/*      */   private final String headers;
/*      */   
/*      */   private FormDataElement[] formDataElements;
/*      */   
/*      */   private final long data;
/*      */   
/*      */   private volatile boolean canceled = false;
/*      */   
/*      */   URLLoader(WebPage paramWebPage, ByteBufferPool paramByteBufferPool, boolean paramBoolean, String paramString1, String paramString2, String paramString3, FormDataElement[] paramArrayOfFormDataElement, long paramLong) {
/*  104 */     this.webPage = paramWebPage;
/*  105 */     this.byteBufferPool = paramByteBufferPool;
/*  106 */     this.asynchronous = paramBoolean;
/*  107 */     this.url = paramString1;
/*  108 */     this.method = paramString2;
/*  109 */     this.headers = paramString3;
/*  110 */     this.formDataElements = paramArrayOfFormDataElement;
/*  111 */     this.data = paramLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fwkCancel() {
/*  119 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/*  120 */       logger.finest(String.format("data: [0x%016X]", new Object[] { Long.valueOf(this.data) }));
/*      */     }
/*  122 */     this.canceled = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void run() {
/*  131 */     AccessController.doPrivileged(() -> { doRun(); return null; }this.webPage
/*      */ 
/*      */         
/*  134 */         .getAccessControlContext());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doRun() {
/*  141 */     Throwable throwable = null;
/*  142 */     byte b = 0;
/*      */     try {
/*  144 */       byte b1 = 0;
/*  145 */       boolean bool1 = true;
/*  146 */       boolean bool2 = true;
/*      */       
/*      */       while (true) {
/*  149 */         String str = this.url;
/*  150 */         if (this.url.startsWith("file:")) {
/*  151 */           int i = this.url.indexOf('?');
/*  152 */           if (i != -1) {
/*  153 */             str = this.url.substring(0, i);
/*      */           }
/*      */         } 
/*      */         
/*  157 */         URL uRL = URLs.newURL(str);
/*      */ 
/*      */         
/*  160 */         workaround7177996(uRL);
/*      */         
/*  162 */         URLConnection uRLConnection = uRL.openConnection();
/*  163 */         prepareConnection(uRLConnection);
/*      */         
/*  165 */         Redirect redirect = null;
/*      */         
/*  167 */         try { sendRequest(uRLConnection, bool1);
/*  168 */           redirect = receiveResponse(uRLConnection); }
/*  169 */         catch (HttpRetryException httpRetryException)
/*      */         
/*  171 */         { if (bool1)
/*  172 */           { bool1 = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  186 */             close(uRLConnection); continue; }  throw httpRetryException; } catch (SocketException socketException) { if ("Connection reset".equals(socketException.getMessage()) && bool2) { bool2 = false; close(uRLConnection); continue; }  throw socketException; } finally { close(uRLConnection); }
/*      */ 
/*      */         
/*  189 */         if (redirect != null) {
/*  190 */           if (b1++ >= 10) {
/*  191 */             throw new TooManyRedirectsException();
/*      */           }
/*      */           
/*  194 */           boolean bool = (!redirect.preserveRequest && !this.method.equals("GET") && !this.method.equals("HEAD")) ? true : false;
/*  195 */           String str1 = bool ? "GET" : this.method;
/*  196 */           willSendRequest(redirect.url, str1, uRLConnection);
/*      */           
/*  198 */           if (this.canceled) {
/*      */             break;
/*      */           }
/*  201 */           this.url = redirect.url;
/*  202 */           this.method = str1;
/*  203 */           this.formDataElements = bool ? null : this.formDataElements;
/*      */           continue;
/*      */         } 
/*      */         break;
/*      */       } 
/*  208 */     } catch (MalformedURLException malformedURLException) {
/*  209 */       throwable = malformedURLException;
/*  210 */       b = 2;
/*  211 */     } catch (AccessControlException accessControlException2) {
/*  212 */       AccessControlException accessControlException1 = accessControlException2;
/*  213 */       b = 8;
/*  214 */     } catch (UnknownHostException unknownHostException2) {
/*  215 */       UnknownHostException unknownHostException1 = unknownHostException2;
/*  216 */       b = 1;
/*  217 */     } catch (NoRouteToHostException noRouteToHostException2) {
/*  218 */       NoRouteToHostException noRouteToHostException1 = noRouteToHostException2;
/*  219 */       b = 6;
/*  220 */     } catch (ConnectException connectException2) {
/*  221 */       ConnectException connectException1 = connectException2;
/*  222 */       b = 4;
/*  223 */     } catch (SocketException socketException2) {
/*  224 */       SocketException socketException1 = socketException2;
/*  225 */       b = 5;
/*  226 */     } catch (SSLHandshakeException sSLHandshakeException2) {
/*  227 */       SSLHandshakeException sSLHandshakeException1 = sSLHandshakeException2;
/*  228 */       b = 3;
/*  229 */     } catch (SocketTimeoutException socketTimeoutException2) {
/*  230 */       SocketTimeoutException socketTimeoutException1 = socketTimeoutException2;
/*  231 */       b = 7;
/*  232 */     } catch (InvalidResponseException invalidResponseException2) {
/*  233 */       InvalidResponseException invalidResponseException1 = invalidResponseException2;
/*  234 */       b = 9;
/*  235 */     } catch (TooManyRedirectsException tooManyRedirectsException2) {
/*  236 */       TooManyRedirectsException tooManyRedirectsException1 = tooManyRedirectsException2;
/*  237 */       b = 10;
/*  238 */     } catch (FileNotFoundException fileNotFoundException2) {
/*  239 */       FileNotFoundException fileNotFoundException1 = fileNotFoundException2;
/*  240 */       b = 11;
/*  241 */     } catch (Throwable throwable1) {
/*  242 */       throwable = throwable1;
/*  243 */       b = 99;
/*      */     } 
/*      */     
/*  246 */     if (throwable != null) {
/*  247 */       if (b == 99) {
/*  248 */         logger.warning("Unexpected error", throwable);
/*      */       } else {
/*  250 */         logger.finest("Load error", throwable);
/*      */       } 
/*  252 */       didFail(b, throwable.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void workaround7177996(URL paramURL) throws FileNotFoundException {
/*  259 */     if (!paramURL.getProtocol().equals("file")) {
/*      */       return;
/*      */     }
/*      */     
/*  263 */     String str = paramURL.getHost();
/*  264 */     if (str == null || str.equals("") || str.equals("~") || str
/*  265 */       .equalsIgnoreCase("localhost")) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  270 */     if (System.getProperty("os.name").startsWith("Windows")) {
/*  271 */       String str1 = null;
/*      */       try {
/*  273 */         str1 = URLDecoder.decode(paramURL.getPath(), "UTF-8");
/*  274 */       } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */ 
/*      */       
/*  277 */       str1 = str1.replace('/', '\\');
/*  278 */       str1 = str1.replace('|', ':');
/*  279 */       File file = new File("\\\\" + str + str1);
/*  280 */       if (!file.exists()) {
/*  281 */         throw new FileNotFoundException("File not found: " + paramURL);
/*      */       }
/*      */     } else {
/*  284 */       throw new FileNotFoundException("File not found: " + paramURL);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareConnection(URLConnection paramURLConnection) throws IOException {
/*  294 */     paramURLConnection.setConnectTimeout(30000);
/*  295 */     paramURLConnection.setReadTimeout(3600000);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  302 */     paramURLConnection.setUseCaches(false);
/*      */     
/*  304 */     Locale locale = Locale.getDefault();
/*  305 */     String str = "";
/*  306 */     if (!locale.equals(Locale.US) && !locale.equals(Locale.ENGLISH))
/*      */     {
/*      */       
/*  309 */       str = locale.getCountry().isEmpty() ? (locale.getLanguage() + ",") : (locale.getLanguage() + "-" + locale.getLanguage() + ",");
/*      */     }
/*  311 */     paramURLConnection.setRequestProperty("Accept-Language", str.toLowerCase() + "en-us;q=0.8,en;q=0.7");
/*  312 */     paramURLConnection.setRequestProperty("Accept-Encoding", "gzip");
/*  313 */     paramURLConnection.setRequestProperty("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
/*      */     
/*  315 */     if (this.headers != null && this.headers.length() > 0) {
/*  316 */       for (String str1 : this.headers.split("\n")) {
/*  317 */         int i = str1.indexOf(':');
/*  318 */         if (i > 0) {
/*  319 */           paramURLConnection.addRequestProperty(str1.substring(0, i), str1.substring(i + 2));
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  324 */     if (paramURLConnection instanceof HttpURLConnection) {
/*  325 */       HttpURLConnection httpURLConnection = (HttpURLConnection)paramURLConnection;
/*  326 */       httpURLConnection.setRequestMethod(this.method);
/*      */ 
/*      */       
/*  329 */       httpURLConnection.setInstanceFollowRedirects(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendRequest(URLConnection paramURLConnection, boolean paramBoolean) throws IOException {
/*  339 */     OutputStream outputStream = null;
/*      */     try {
/*  341 */       long l = 0L;
/*      */ 
/*      */       
/*  344 */       byte b1 = (this.formDataElements != null && paramURLConnection instanceof HttpURLConnection && !this.method.equals("DELETE")) ? 1 : 0;
/*  345 */       boolean bool = (this.method.equals("GET") || this.method.equals("HEAD")) ? true : false;
/*  346 */       if (b1) {
/*  347 */         paramURLConnection.setDoOutput(true);
/*      */         
/*  349 */         for (FormDataElement formDataElement : this.formDataElements) {
/*  350 */           formDataElement.open();
/*  351 */           l += formDataElement.getSize();
/*      */         } 
/*      */         
/*  354 */         if (paramBoolean) {
/*  355 */           HttpURLConnection httpURLConnection = (HttpURLConnection)paramURLConnection;
/*  356 */           if (l <= 2147483647L) {
/*  357 */             httpURLConnection.setFixedLengthStreamingMode((int)l);
/*      */           } else {
/*  359 */             httpURLConnection.setChunkedStreamingMode(0);
/*      */           } 
/*      */         } 
/*  362 */       } else if (!bool && paramURLConnection instanceof HttpURLConnection) {
/*  363 */         paramURLConnection.setRequestProperty("Content-Length", "0");
/*      */       } 
/*      */       
/*  366 */       byte b2 = bool ? 3 : 1;
/*  367 */       paramURLConnection.setConnectTimeout(paramURLConnection.getConnectTimeout() / b2);
/*  368 */       byte b3 = 0;
/*  369 */       while (!this.canceled) {
/*      */         try {
/*  371 */           paramURLConnection.connect();
/*      */           break;
/*  373 */         } catch (SocketTimeoutException socketTimeoutException) {
/*  374 */           if (++b3 >= b2) {
/*  375 */             throw socketTimeoutException;
/*      */           }
/*  377 */         } catch (IllegalArgumentException illegalArgumentException) {
/*      */           
/*  379 */           throw new MalformedURLException(this.url);
/*      */         } 
/*      */       } 
/*      */       
/*  383 */       if (b1) {
/*  384 */         outputStream = paramURLConnection.getOutputStream();
/*  385 */         byte[] arrayOfByte = new byte[4096];
/*  386 */         long l1 = 0L;
/*  387 */         for (FormDataElement formDataElement : this.formDataElements) {
/*  388 */           InputStream inputStream = formDataElement.getInputStream();
/*      */           int i;
/*  390 */           while ((i = inputStream.read(arrayOfByte)) > 0) {
/*  391 */             outputStream.write(arrayOfByte, 0, i);
/*  392 */             l1 += i;
/*  393 */             didSendData(l1, l);
/*      */           } 
/*  395 */           formDataElement.close();
/*      */         } 
/*  397 */         outputStream.flush();
/*  398 */         outputStream.close();
/*  399 */         outputStream = null;
/*      */       } 
/*      */     } finally {
/*  402 */       if (outputStream != null) {
/*      */         try {
/*  404 */           outputStream.close();
/*  405 */         } catch (IOException iOException) {}
/*      */       }
/*  407 */       if (this.formDataElements != null && paramURLConnection instanceof HttpURLConnection) {
/*  408 */         for (FormDataElement formDataElement : this.formDataElements) {
/*      */           try {
/*  410 */             formDataElement.close();
/*  411 */           } catch (IOException iOException) {}
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Redirect receiveResponse(URLConnection paramURLConnection) throws IOException, InterruptedException {
/*  423 */     if (this.canceled) {
/*  424 */       return null;
/*      */     }
/*      */     
/*  427 */     InputStream inputStream1 = null;
/*      */     
/*  429 */     if (paramURLConnection instanceof HttpURLConnection) {
/*  430 */       String str1; HttpURLConnection httpURLConnection = (HttpURLConnection)paramURLConnection;
/*      */       
/*  432 */       int i = httpURLConnection.getResponseCode();
/*  433 */       if (i == -1) {
/*  434 */         throw new InvalidResponseException();
/*      */       }
/*      */       
/*  437 */       if (this.canceled) {
/*  438 */         return null;
/*      */       }
/*      */ 
/*      */       
/*  442 */       switch (i) {
/*      */         case 301:
/*      */         case 302:
/*      */         case 303:
/*      */         case 307:
/*  447 */           str1 = httpURLConnection.getHeaderField("Location");
/*  448 */           if (str1 != null) {
/*      */             URL uRL;
/*      */             try {
/*  451 */               uRL = URLs.newURL(str1);
/*  452 */             } catch (MalformedURLException malformedURLException) {
/*      */ 
/*      */               
/*  455 */               uRL = URLs.newURL(paramURLConnection.getURL(), str1);
/*      */             } 
/*  457 */             return new Redirect(uRL.toExternalForm(), (i == 307));
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 304:
/*  463 */           didReceiveResponse(paramURLConnection);
/*  464 */           didFinishLoading();
/*  465 */           return null;
/*      */       } 
/*      */       
/*  468 */       if (i >= 400 && !this.method.equals("HEAD")) {
/*  469 */         inputStream1 = httpURLConnection.getErrorStream();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  475 */     if (this.url.startsWith("ftp:") || this.url.startsWith("ftps:")) {
/*  476 */       boolean bool1 = false;
/*  477 */       boolean bool2 = false;
/*      */ 
/*      */       
/*  480 */       String str1 = paramURLConnection.getURL().getPath();
/*  481 */       if (str1 == null || str1.isEmpty() || str1.endsWith("/") || str1
/*  482 */         .contains(";type=d")) {
/*      */         
/*  484 */         bool1 = true;
/*      */       } else {
/*  486 */         String str2 = paramURLConnection.getContentType();
/*  487 */         if ("text/plain".equalsIgnoreCase(str2) || "text/html"
/*  488 */           .equalsIgnoreCase(str2)) {
/*      */           
/*  490 */           bool1 = true;
/*  491 */           bool2 = true;
/*      */         } 
/*      */       } 
/*  494 */       if (bool1) {
/*  495 */         paramURLConnection = new DirectoryURLConnection(paramURLConnection, bool2);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  500 */     if (this.url.startsWith("file:") && 
/*  501 */       "text/plain".equals(paramURLConnection.getContentType()) && paramURLConnection
/*  502 */       .getHeaderField("content-length") == null)
/*      */     {
/*      */       
/*  505 */       paramURLConnection = new DirectoryURLConnection(paramURLConnection);
/*      */     }
/*      */ 
/*      */     
/*  509 */     didReceiveResponse(paramURLConnection);
/*      */     
/*  511 */     if (this.method.equals("HEAD")) {
/*  512 */       didFinishLoading();
/*  513 */       return null;
/*      */     } 
/*      */     
/*  516 */     InputStream inputStream2 = null;
/*      */     
/*      */     try {
/*  519 */       inputStream2 = (inputStream1 == null) ? paramURLConnection.getInputStream() : inputStream1;
/*  520 */     } catch (HttpRetryException httpRetryException) {
/*      */ 
/*      */       
/*  523 */       throw httpRetryException;
/*  524 */     } catch (IOException iOException) {
/*  525 */       if (logger.isLoggable(PlatformLogger.Level.FINE)) {
/*  526 */         logger.fine(String.format("Exception caught: [%s], %s", new Object[] { iOException
/*  527 */                 .getClass().getSimpleName(), iOException
/*  528 */                 .getMessage() }));
/*      */       }
/*      */     } 
/*      */     
/*  532 */     String str = paramURLConnection.getContentEncoding();
/*  533 */     if (inputStream2 != null) {
/*      */       try {
/*  535 */         if ("gzip".equalsIgnoreCase(str)) {
/*  536 */           inputStream2 = new GZIPInputStream(inputStream2);
/*  537 */         } else if ("deflate".equalsIgnoreCase(str)) {
/*  538 */           inputStream2 = new InflaterInputStream(inputStream2);
/*      */         } 
/*  540 */       } catch (IOException iOException) {
/*  541 */         if (logger.isLoggable(PlatformLogger.Level.FINE)) {
/*  542 */           logger.fine(String.format("Exception caught: [%s], %s", new Object[] { iOException
/*  543 */                   .getClass().getSimpleName(), iOException
/*  544 */                   .getMessage() }));
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  550 */     ByteBufferAllocator byteBufferAllocator = this.byteBufferPool.newAllocator(3);
/*  551 */     ByteBuffer byteBuffer = null;
/*      */     try {
/*  553 */       if (inputStream2 != null) {
/*      */ 
/*      */ 
/*      */         
/*  557 */         byte[] arrayOfByte = new byte[8192];
/*  558 */         while (!this.canceled) {
/*      */           byte b;
/*      */           try {
/*  561 */             b = inputStream2.read(arrayOfByte);
/*  562 */           } catch (EOFException eOFException) {
/*      */ 
/*      */             
/*  565 */             b = -1;
/*      */           } 
/*      */           
/*  568 */           if (b == -1) {
/*      */             break;
/*      */           }
/*      */           
/*  572 */           if (byteBuffer == null) {
/*  573 */             byteBuffer = byteBufferAllocator.allocate();
/*      */           }
/*      */           
/*  576 */           int i = byteBuffer.remaining();
/*  577 */           if (b < i) {
/*  578 */             byteBuffer.put(arrayOfByte, 0, b); continue;
/*      */           } 
/*  580 */           byteBuffer.put(arrayOfByte, 0, i);
/*      */           
/*  582 */           byteBuffer.flip();
/*  583 */           didReceiveData(byteBuffer, byteBufferAllocator);
/*  584 */           byteBuffer = null;
/*      */           
/*  586 */           int j = b - i;
/*  587 */           if (j > 0) {
/*  588 */             byteBuffer = byteBufferAllocator.allocate();
/*  589 */             byteBuffer.put(arrayOfByte, i, j);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  594 */       if (!this.canceled) {
/*  595 */         if (byteBuffer != null && byteBuffer.position() > 0) {
/*  596 */           byteBuffer.flip();
/*  597 */           didReceiveData(byteBuffer, byteBufferAllocator);
/*  598 */           byteBuffer = null;
/*      */         } 
/*  600 */         didFinishLoading();
/*      */       } 
/*      */     } finally {
/*  603 */       if (byteBuffer != null) {
/*  604 */         byteBuffer.clear();
/*  605 */         byteBufferAllocator.release(byteBuffer);
/*      */       } 
/*      */     } 
/*  608 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void close(URLConnection paramURLConnection) {
/*  615 */     if (paramURLConnection instanceof HttpURLConnection) {
/*  616 */       InputStream inputStream = ((HttpURLConnection)paramURLConnection).getErrorStream();
/*  617 */       if (inputStream != null) {
/*      */         try {
/*  619 */           inputStream.close();
/*  620 */         } catch (IOException iOException) {}
/*      */       }
/*      */     } 
/*      */     try {
/*  624 */       paramURLConnection.getInputStream().close();
/*  625 */     } catch (IOException iOException) {}
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class Redirect
/*      */   {
/*      */     private final String url;
/*      */     
/*      */     private final boolean preserveRequest;
/*      */ 
/*      */     
/*      */     private Redirect(String param1String, boolean param1Boolean) {
/*  637 */       this.url = param1String;
/*  638 */       this.preserveRequest = param1Boolean;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class InvalidResponseException
/*      */     extends IOException
/*      */   {
/*      */     private InvalidResponseException() {
/*  647 */       super("Invalid server response");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class TooManyRedirectsException
/*      */     extends IOException
/*      */   {
/*      */     private TooManyRedirectsException() {
/*  657 */       super("Too many redirects");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void didSendData(long paramLong1, long paramLong2) {
/*  664 */     callBack(() -> {
/*      */           if (!this.canceled) {
/*      */             notifyDidSendData(paramLong1, paramLong2);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyDidSendData(long paramLong1, long paramLong2) {
/*  674 */     if (logger.isLoggable(PlatformLogger.Level.FINEST))
/*  675 */       logger.finest(String.format("totalBytesSent: [%d], totalBytesToBeSent: [%d], data: [0x%016X]", new Object[] {
/*      */ 
/*      */ 
/*      */               
/*  679 */               Long.valueOf(paramLong1), 
/*  680 */               Long.valueOf(paramLong2), 
/*  681 */               Long.valueOf(this.data)
/*      */             })); 
/*  683 */     twkDidSendData(paramLong1, paramLong2, this.data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void willSendRequest(String paramString1, String paramString2, URLConnection paramURLConnection) throws InterruptedException {
/*  690 */     String str1 = adjustUrlForWebKit(paramString1);
/*  691 */     int i = extractStatus(paramURLConnection);
/*  692 */     String str2 = paramURLConnection.getContentType();
/*  693 */     String str3 = extractContentEncoding(paramURLConnection);
/*  694 */     long l = extractContentLength(paramURLConnection);
/*  695 */     String str4 = extractHeaders(paramURLConnection);
/*  696 */     String str5 = adjustUrlForWebKit(this.url);
/*      */     
/*  698 */     CountDownLatch countDownLatch = this.asynchronous ? new CountDownLatch(1) : null;
/*  699 */     callBack(() -> {
/*      */           try {
/*      */             if (!this.canceled) {
/*      */               boolean bool = notifyWillSendRequest(paramString1, paramString2, paramInt, paramString3, paramString4, paramLong, paramString5, paramString6);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               if (!bool) {
/*      */                 fwkCancel();
/*      */               }
/*      */             } 
/*      */           } finally {
/*      */             if (paramCountDownLatch != null) {
/*      */               paramCountDownLatch.countDown();
/*      */             }
/*      */           } 
/*      */         });
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  721 */     if (countDownLatch != null) {
/*  722 */       countDownLatch.await();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean notifyWillSendRequest(String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, long paramLong, String paramString5, String paramString6) {
/*  735 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/*  736 */       logger.finest(String.format("newUrl: [%s], newMethod: [%s], status: [%d], contentType: [%s], contentEncoding: [%s], contentLength: [%d], url: [%s], data: [0x%016X], headers:%n%s", new Object[] { paramString1, paramString2, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  748 */               Integer.valueOf(paramInt), paramString3, paramString4, 
/*      */ 
/*      */               
/*  751 */               Long.valueOf(paramLong), paramString6, 
/*      */               
/*  753 */               Long.valueOf(this.data), 
/*  754 */               Util.formatHeaders(paramString5) }));
/*      */     }
/*  756 */     boolean bool = twkWillSendRequest(paramString1, paramString2, paramInt, paramString3, paramString4, paramLong, paramString5, paramString6, this.data);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  766 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/*  767 */       logger.finest(String.format("result: [%s]", new Object[] { Boolean.valueOf(bool) }));
/*      */     }
/*  769 */     return bool;
/*      */   }
/*      */   
/*      */   private void didReceiveResponse(URLConnection paramURLConnection) {
/*  773 */     int i = extractStatus(paramURLConnection);
/*  774 */     String str1 = paramURLConnection.getContentType();
/*  775 */     String str2 = extractContentEncoding(paramURLConnection);
/*  776 */     long l = extractContentLength(paramURLConnection);
/*  777 */     String str3 = extractHeaders(paramURLConnection);
/*  778 */     String str4 = adjustUrlForWebKit(this.url);
/*  779 */     callBack(() -> {
/*      */           if (!this.canceled) {
/*      */             notifyDidReceiveResponse(paramInt, paramString1, paramString2, paramLong, paramString3, paramString4);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyDidReceiveResponse(int paramInt, String paramString1, String paramString2, long paramLong, String paramString3, String paramString4) {
/*  799 */     if (logger.isLoggable(PlatformLogger.Level.FINEST))
/*  800 */       logger.finest(String.format("status: [%d], contentType: [%s], contentEncoding: [%s], contentLength: [%d], url: [%s], data: [0x%016X], headers:%n%s", new Object[] {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  808 */               Integer.valueOf(paramInt), paramString1, paramString2, 
/*      */ 
/*      */               
/*  811 */               Long.valueOf(paramLong), paramString4, 
/*      */               
/*  813 */               Long.valueOf(this.data), 
/*  814 */               Util.formatHeaders(paramString3)
/*      */             })); 
/*  816 */     twkDidReceiveResponse(paramInt, paramString1, paramString2, paramLong, paramString3, paramString4, this.data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void didReceiveData(ByteBuffer paramByteBuffer, ByteBufferAllocator paramByteBufferAllocator) {
/*  829 */     callBack(() -> {
/*      */           if (!this.canceled) {
/*      */             notifyDidReceiveData(paramByteBuffer, paramByteBuffer.position(), paramByteBuffer.remaining());
/*      */           }
/*      */           paramByteBuffer.clear();
/*      */           paramByteBufferAllocator.release(paramByteBuffer);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyDidReceiveData(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2) {
/*  845 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/*  846 */       logger.finest(String.format("byteBuffer: [%s], position: [%s], remaining: [%s], data: [0x%016X]", new Object[] { paramByteBuffer, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  852 */               Integer.valueOf(paramInt1), 
/*  853 */               Integer.valueOf(paramInt2), 
/*  854 */               Long.valueOf(this.data) }));
/*      */     }
/*  856 */     twkDidReceiveData(paramByteBuffer, paramInt1, paramInt2, this.data);
/*      */   }
/*      */   
/*      */   private void didFinishLoading() {
/*  860 */     callBack(() -> {
/*      */           if (!this.canceled) {
/*      */             notifyDidFinishLoading();
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private void notifyDidFinishLoading() {
/*  868 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/*  869 */       logger.finest(String.format("data: [0x%016X]", new Object[] { Long.valueOf(this.data) }));
/*      */     }
/*  871 */     twkDidFinishLoading(this.data);
/*      */   }
/*      */   
/*      */   private void didFail(int paramInt, String paramString) {
/*  875 */     String str = adjustUrlForWebKit(this.url);
/*  876 */     callBack(() -> {
/*      */           if (!this.canceled) {
/*      */             notifyDidFail(paramInt, paramString1, paramString2);
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private void notifyDidFail(int paramInt, String paramString1, String paramString2) {
/*  884 */     if (logger.isLoggable(PlatformLogger.Level.FINEST))
/*  885 */       logger.finest(String.format("errorCode: [%d], url: [%s], message: [%s], data: [0x%016X]", new Object[] {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  890 */               Integer.valueOf(paramInt), paramString1, paramString2, 
/*      */ 
/*      */               
/*  893 */               Long.valueOf(this.data)
/*      */             })); 
/*  895 */     twkDidFail(paramInt, paramString1, paramString2, this.data);
/*      */   }
/*      */   
/*      */   private void callBack(Runnable paramRunnable) {
/*  899 */     if (this.asynchronous) {
/*  900 */       Invoker.getInvoker().invokeOnEventThread(paramRunnable);
/*      */     } else {
/*  902 */       paramRunnable.run();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int extractStatus(URLConnection paramURLConnection) {
/*  945 */     int i = 0;
/*  946 */     if (paramURLConnection instanceof HttpURLConnection) {
/*      */       try {
/*  948 */         i = ((HttpURLConnection)paramURLConnection).getResponseCode();
/*  949 */       } catch (IOException iOException) {}
/*      */     }
/*  951 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String extractContentEncoding(URLConnection paramURLConnection) {
/*  959 */     String str = paramURLConnection.getContentEncoding();
/*      */     
/*  961 */     if ("gzip".equalsIgnoreCase(str) || "deflate"
/*  962 */       .equalsIgnoreCase(str)) {
/*      */       
/*  964 */       str = null;
/*  965 */       String str1 = paramURLConnection.getContentType();
/*  966 */       if (str1 != null) {
/*  967 */         int i = str1.indexOf("charset=");
/*  968 */         if (i >= 0) {
/*  969 */           str = str1.substring(i + 8);
/*  970 */           i = str.indexOf(";");
/*  971 */           if (i > 0) {
/*  972 */             str = str.substring(0, i);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  977 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static long extractContentLength(URLConnection paramURLConnection) {
/*      */     try {
/*  988 */       return Long.parseLong(paramURLConnection.getHeaderField("content-length"));
/*  989 */     } catch (Exception exception) {
/*  990 */       return -1L;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String extractHeaders(URLConnection paramURLConnection) {
/*  999 */     StringBuilder stringBuilder = new StringBuilder();
/* 1000 */     Map<String, List<String>> map = paramURLConnection.getHeaderFields();
/* 1001 */     for (Map.Entry<String, List<String>> entry : map.entrySet()) {
/* 1002 */       String str = (String)entry.getKey();
/* 1003 */       List list = (List)entry.getValue();
/* 1004 */       for (String str1 : list) {
/* 1005 */         stringBuilder.append((str != null) ? str : "");
/* 1006 */         stringBuilder.append(':').append(str1).append('\n');
/*      */       } 
/*      */     } 
/* 1009 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String adjustUrlForWebKit(String paramString) {
/*      */     try {
/* 1017 */       paramString = Util.adjustUrlForWebKit(paramString);
/* 1018 */     } catch (Exception exception) {}
/*      */     
/* 1020 */     return paramString;
/*      */   }
/*      */   
/*      */   private static native void twkDidSendData(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   private static native boolean twkWillSendRequest(String paramString1, String paramString2, int paramInt, String paramString3, String paramString4, long paramLong1, String paramString5, String paramString6, long paramLong2);
/*      */   
/*      */   private static native void twkDidReceiveResponse(int paramInt, String paramString1, String paramString2, long paramLong1, String paramString3, String paramString4, long paramLong2);
/*      */   
/*      */   private static native void twkDidReceiveData(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, long paramLong);
/*      */   
/*      */   private static native void twkDidFinishLoading(long paramLong);
/*      */   
/*      */   private static native void twkDidFail(int paramInt, String paramString1, String paramString2, long paramLong);
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\URLLoader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */