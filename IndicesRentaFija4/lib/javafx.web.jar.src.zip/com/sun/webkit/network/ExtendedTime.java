/*    */ package com.sun.webkit.network;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ExtendedTime
/*    */   implements Comparable<ExtendedTime>
/*    */ {
/*    */   private final long baseTime;
/*    */   private final int subtime;
/*    */   
/*    */   ExtendedTime(long paramLong, int paramInt) {
/* 42 */     this.baseTime = paramLong;
/* 43 */     this.subtime = paramInt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ExtendedTime currentTime() {
/* 52 */     return new ExtendedTime(System.currentTimeMillis(), 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   long baseTime() {
/* 60 */     return this.baseTime;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   int subtime() {
/* 67 */     return this.subtime;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ExtendedTime incrementSubtime() {
/* 74 */     return new ExtendedTime(this.baseTime, this.subtime + 1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int compareTo(ExtendedTime paramExtendedTime) {
/* 82 */     int i = (int)(this.baseTime - paramExtendedTime.baseTime);
/* 83 */     if (i != 0) {
/* 84 */       return i;
/*    */     }
/* 86 */     return this.subtime - paramExtendedTime.subtime;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 94 */     return "[baseTime=" + this.baseTime + ", subtime=" + this.subtime + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\ExtendedTime.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */