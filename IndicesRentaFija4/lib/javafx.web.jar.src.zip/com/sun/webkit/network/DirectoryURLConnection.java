/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DirectoryURLConnection
/*     */   extends URLConnection
/*     */ {
/*  50 */   private static final String[] patStrings = new String[] { "([\\-ld](?:[r\\-][w\\-][x\\-]){3})\\s*\\d+ (\\w+)\\s*(\\w+)\\s*(\\d+)\\s*([A-Z][a-z][a-z]\\s*\\d+)\\s*((?:\\d\\d:\\d\\d)|(?:\\d{4}))\\s*(\\p{Print}*)", "(\\d{2}/\\d{2}/\\d{4})\\s*(\\d{2}:\\d{2}[ap])\\s*((?:[0-9,]+)|(?:<DIR>))\\s*(\\p{Graph}*)", "(\\d{2}-\\d{2}-\\d{2})\\s*(\\d{2}:\\d{2}[AP]M)\\s*((?:[0-9,]+)|(?:<DIR>))\\s*(\\p{Graph}*)" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private static final int[][] patternGroups = new int[][] { { 7, 4, 5, 6, 1 }, { 4, 3, 1, 2, 0 }, { 4, 3, 1, 2, 0 } };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Pattern[] patterns;
/*     */ 
/*     */   
/*  66 */   private static final Pattern linkp = Pattern.compile("(\\p{Print}+) \\-\\> (\\p{Print}+)$");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String styleSheet = "<style type=\"text/css\" media=\"screen\">TABLE { border: 0;}TR.header { background: #FFFFFF; color: black; font-weight: bold; text-align: center;}TR.odd { background: #E0E0E0;}TR.even { background: #C0C0C0;}TD.file { text-align: left;}TD.fsize { text-align: right; padding-right: 1em;}TD.dir { text-align: center; color: green; padding-right: 1em;}TD.link { text-align: center; color: red; padding-right: 1em;}TD.date { text-align: justify;}</style>";
/*     */ 
/*     */ 
/*     */   
/*     */   private final URLConnection inner;
/*     */ 
/*     */   
/*     */   private final boolean sure;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  82 */     patterns = new Pattern[patStrings.length];
/*  83 */     for (byte b = 0; b < patStrings.length; b++) {
/*  84 */       patterns[b] = Pattern.compile(patStrings[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  89 */   private String dirUrl = null;
/*     */   
/*     */   private boolean toHTML = true;
/*     */   
/*     */   private final boolean ftp;
/*  94 */   private InputStream ins = null;
/*     */ 
/*     */   
/*     */   private final class DirectoryInputStream
/*     */     extends PushbackInputStream
/*     */   {
/*     */     private final byte[] buffer;
/*     */     
/*     */     private boolean endOfStream = false;
/*     */     
/* 104 */     private ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/* 105 */     private PrintStream out = new PrintStream(this.bytesOut);
/* 106 */     private ByteArrayInputStream bytesIn = null;
/* 107 */     private final StringBuffer tmpString = new StringBuffer();
/* 108 */     private int lineCount = 0;
/*     */     
/*     */     private DirectoryInputStream(InputStream param1InputStream, boolean param1Boolean) {
/* 111 */       super(param1InputStream, 512);
/* 112 */       this.buffer = new byte[512];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 117 */       if (param1Boolean) {
/* 118 */         StringBuffer stringBuffer = new StringBuffer();
/* 119 */         int i = 0;
/*     */         
/*     */         try {
/* 122 */           i = super.read(this.buffer, 0, this.buffer.length);
/* 123 */         } catch (IOException iOException) {}
/*     */         
/* 125 */         if (i <= 0) {
/* 126 */           DirectoryURLConnection.this.toHTML = false;
/*     */         } else {
/* 128 */           for (byte b = 0; b < i; b++) {
/* 129 */             stringBuffer.append((char)this.buffer[b]);
/*     */           }
/* 131 */           String str = stringBuffer.toString();
/* 132 */           DirectoryURLConnection.this.toHTML = false;
/* 133 */           for (Pattern pattern : DirectoryURLConnection.patterns) {
/* 134 */             Matcher matcher = pattern.matcher(str);
/* 135 */             if (matcher.find()) {
/*     */ 
/*     */               
/* 138 */               DirectoryURLConnection.this.toHTML = true;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */           try {
/* 143 */             unread(this.buffer, 0, i);
/* 144 */           } catch (IOException iOException) {}
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 149 */       if (DirectoryURLConnection.this.toHTML) {
/*     */ 
/*     */ 
/*     */         
/* 153 */         String str1 = null;
/*     */         
/* 155 */         URL uRL = null;
/* 156 */         if (!DirectoryURLConnection.this.dirUrl.endsWith("/")) {
/* 157 */           DirectoryURLConnection.this.dirUrl = DirectoryURLConnection.this.dirUrl + "/";
/*     */         }
/*     */         try {
/* 160 */           uRL = URLs.newURL(DirectoryURLConnection.this.dirUrl);
/* 161 */         } catch (Exception exception) {}
/*     */ 
/*     */         
/* 164 */         String str2 = uRL.getPath();
/* 165 */         if (str2 != null && !str2.isEmpty()) {
/* 166 */           int i = str2.lastIndexOf("/", str2.length() - 2);
/* 167 */           if (i >= 0) {
/* 168 */             int j = str2.length() - i - 1;
/* 169 */             i = DirectoryURLConnection.this.dirUrl.indexOf(str2);
/* 170 */             str1 = DirectoryURLConnection.this.dirUrl.substring(0, i + str2.length() - j) + DirectoryURLConnection.this.dirUrl.substring(0, i + str2.length() - j);
/*     */           } 
/*     */         } 
/* 173 */         this.out.print("<html><head><title>index of ");
/* 174 */         this.out.print(DirectoryURLConnection.this.dirUrl);
/* 175 */         this.out.print("</title>");
/* 176 */         this.out.print("<style type=\"text/css\" media=\"screen\">TABLE { border: 0;}TR.header { background: #FFFFFF; color: black; font-weight: bold; text-align: center;}TR.odd { background: #E0E0E0;}TR.even { background: #C0C0C0;}TD.file { text-align: left;}TD.fsize { text-align: right; padding-right: 1em;}TD.dir { text-align: center; color: green; padding-right: 1em;}TD.link { text-align: center; color: red; padding-right: 1em;}TD.date { text-align: justify;}</style>");
/* 177 */         this.out.print("</head><body><h1>Index of ");
/* 178 */         this.out.print(DirectoryURLConnection.this.dirUrl);
/* 179 */         this.out.print("</h1><hr></hr>");
/* 180 */         this.out.print("<TABLE width=\"95%\" cellpadding=\"5\" cellspacing=\"5\">");
/* 181 */         this.out.print("<TR class=\"header\"><TD>File</TD><TD>Size</TD><TD>Last Modified</TD></TR>");
/* 182 */         if (str1 != null) {
/* 183 */           this.lineCount++;
/* 184 */           this.out.print("<TR class=\"odd\"><TD colspan=3 class=\"file\"><a href=\"");
/* 185 */           this.out.print(str1);
/* 186 */           this.out.print("\">Up to parent directory</a></TD></TR>");
/*     */         } 
/* 188 */         this.out.close();
/* 189 */         this.bytesIn = new ByteArrayInputStream(this.bytesOut.toByteArray());
/* 190 */         this.out = null;
/* 191 */         this.bytesOut = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void parseFile(String param1String) {
/* 197 */       this.tmpString.append(param1String);
/*     */       int i;
/* 199 */       while ((i = this.tmpString.indexOf("\n")) >= 0) {
/* 200 */         String str1 = this.tmpString.substring(0, i);
/* 201 */         this.tmpString.delete(0, i + 1);
/* 202 */         String str2 = str1;
/* 203 */         String str3 = null;
/* 204 */         String str4 = null;
/* 205 */         boolean bool1 = false;
/* 206 */         boolean bool2 = false;
/* 207 */         URL uRL = null;
/*     */         
/* 209 */         if (str2 != null) {
/* 210 */           this.lineCount++;
/*     */           try {
/* 212 */             uRL = URLs.newURL(DirectoryURLConnection.this.dirUrl + DirectoryURLConnection.this.dirUrl);
/* 213 */             URLConnection uRLConnection = uRL.openConnection();
/* 214 */             uRLConnection.connect();
/* 215 */             str4 = uRLConnection.getHeaderField("last-modified");
/* 216 */             str3 = uRLConnection.getHeaderField("content-length");
/* 217 */             if (str3 == null) {
/* 218 */               bool1 = true;
/*     */             }
/* 220 */             uRLConnection.getInputStream().close();
/* 221 */           } catch (IOException iOException) {
/*     */             
/* 223 */             bool2 = true;
/*     */           } 
/* 225 */           if (this.bytesOut == null) {
/* 226 */             this.bytesOut = new ByteArrayOutputStream();
/* 227 */             this.out = new PrintStream(this.bytesOut);
/*     */           } 
/* 229 */           this.out.print("<TR class=\"" + ((this.lineCount % 2 == 0) ? "even" : "odd") + "\"><TD class=\"file\">");
/* 230 */           if (bool2) {
/* 231 */             this.out.print(str2);
/*     */           } else {
/* 233 */             this.out.print("<a href=\"");
/* 234 */             this.out.print(uRL.toExternalForm());
/* 235 */             this.out.print("\">");
/* 236 */             this.out.print(str2);
/* 237 */             this.out.print("</a>");
/*     */           } 
/* 239 */           if (bool1) {
/* 240 */             this.out.print("</TD><TD class=\"dir\">&lt;Directory&gt;</TD>");
/*     */           } else {
/* 242 */             this.out.print("</TD><TD class=\"fsize\">" + ((str3 == null) ? " " : str3) + "</TD>");
/*     */           } 
/* 244 */           this.out.print("<TD class=\"date\">" + ((str4 == null) ? " " : str4) + "</TD></TR>");
/*     */         } 
/*     */       } 
/* 247 */       if (this.bytesOut != null) {
/* 248 */         this.out.close();
/* 249 */         this.bytesIn = new ByteArrayInputStream(this.bytesOut.toByteArray());
/* 250 */         this.out = null;
/* 251 */         this.bytesOut = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void parseFTP(String param1String) {
/* 257 */       this.tmpString.append(param1String);
/*     */       int i;
/* 259 */       while ((i = this.tmpString.indexOf("\n")) >= 0) {
/* 260 */         String str1 = this.tmpString.substring(0, i);
/* 261 */         this.tmpString.delete(0, i + 1);
/* 262 */         String str2 = null;
/* 263 */         String str3 = null;
/* 264 */         String str4 = null;
/* 265 */         String str5 = null;
/* 266 */         boolean bool = false;
/*     */         
/* 268 */         Matcher matcher = null;
/* 269 */         for (byte b = 0; b < DirectoryURLConnection.patterns.length; b++) {
/* 270 */           matcher = DirectoryURLConnection.patterns[b].matcher(str1);
/* 271 */           if (matcher.find()) {
/* 272 */             str2 = matcher.group(DirectoryURLConnection.patternGroups[b][0]);
/* 273 */             str4 = matcher.group(DirectoryURLConnection.patternGroups[b][1]);
/* 274 */             str5 = matcher.group(DirectoryURLConnection.patternGroups[b][2]);
/* 275 */             if (DirectoryURLConnection.patternGroups[b][3] > 0) {
/* 276 */               str5 = str5 + " " + str5;
/*     */             }
/* 278 */             if (DirectoryURLConnection.patternGroups[b][4] > 0) {
/* 279 */               String str = matcher.group(DirectoryURLConnection.patternGroups[b][4]);
/* 280 */               bool = str.startsWith("d");
/*     */             } 
/* 282 */             if ("<DIR>".equals(str4)) {
/* 283 */               bool = true;
/* 284 */               str4 = null;
/*     */             } 
/*     */           } 
/*     */         } 
/* 288 */         if (str2 != null) {
/* 289 */           matcher = DirectoryURLConnection.linkp.matcher(str2);
/* 290 */           if (matcher.find()) {
/*     */             
/* 292 */             str2 = matcher.group(1);
/* 293 */             str3 = matcher.group(2);
/*     */           } 
/* 295 */           if (this.bytesOut == null) {
/* 296 */             this.bytesOut = new ByteArrayOutputStream();
/* 297 */             this.out = new PrintStream(this.bytesOut);
/*     */           } 
/* 299 */           this.lineCount++;
/* 300 */           this.out.print("<TR class=\"" + ((this.lineCount % 2 == 0) ? "even" : "odd") + "\"><TD class=\"file\"><a href=\"");
/*     */           try {
/* 302 */             this.out.print(DirectoryURLConnection.this.dirUrl + DirectoryURLConnection.this.dirUrl);
/* 303 */           } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */ 
/*     */           
/* 306 */           if (bool) {
/* 307 */             this.out.print("/");
/*     */           }
/* 309 */           this.out.print("\">");
/* 310 */           this.out.print(str2);
/* 311 */           this.out.print("</a>");
/* 312 */           if (str3 != null) {
/* 313 */             this.out.print(" &rarr; " + str3 + "</TD><TD class=\"link\">&lt;Link&gt;</TD>");
/* 314 */           } else if (bool) {
/* 315 */             this.out.print("</TD><TD class=\"dir\">&lt;Directory&gt;</TD>");
/*     */           } else {
/* 317 */             this.out.print("</TD><TD class=\"fsize\">" + str4 + "</TD>");
/*     */           } 
/* 319 */           this.out.print("<TD class=\"date\">" + str5 + "</TD></TR>");
/*     */         } 
/*     */       } 
/* 322 */       if (this.bytesOut != null) {
/* 323 */         this.out.close();
/* 324 */         this.bytesIn = new ByteArrayInputStream(this.bytesOut.toByteArray());
/* 325 */         this.out = null;
/* 326 */         this.bytesOut = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void endOfList() {
/* 334 */       if (DirectoryURLConnection.this.ftp) {
/* 335 */         parseFTP("\n");
/*     */       } else {
/* 337 */         parseFile("\n");
/*     */       } 
/* 339 */       if (this.bytesOut == null) {
/* 340 */         this.bytesOut = new ByteArrayOutputStream();
/* 341 */         this.out = new PrintStream(this.bytesOut);
/*     */       } 
/* 343 */       this.out.print("</TABLE><br><hr></hr></body></html>");
/* 344 */       this.out.close();
/* 345 */       this.bytesIn = new ByteArrayInputStream(this.bytesOut.toByteArray());
/* 346 */       this.out = null;
/* 347 */       this.bytesOut = null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int read(byte[] param1ArrayOfbyte) throws IOException {
/* 353 */       return read(param1ArrayOfbyte, 0, param1ArrayOfbyte.length);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/* 359 */       int i = 0;
/*     */       
/* 361 */       if (!DirectoryURLConnection.this.toHTML) {
/* 362 */         return super.read(param1ArrayOfbyte, param1Int1, param1Int2);
/*     */       }
/* 364 */       if (this.bytesIn != null) {
/* 365 */         i = this.bytesIn.read(param1ArrayOfbyte, param1Int1, param1Int2);
/* 366 */         if (i == -1) {
/* 367 */           this.bytesIn.close();
/* 368 */           this.bytesIn = null;
/* 369 */           if (this.endOfStream) {
/* 370 */             return -1;
/*     */           }
/*     */         } else {
/* 373 */           return i;
/*     */         } 
/*     */       } 
/* 376 */       if (!this.endOfStream) {
/* 377 */         i = super.read(this.buffer, 0, this.buffer.length);
/* 378 */         if (i == -1) {
/* 379 */           this.endOfStream = true;
/* 380 */           endOfList();
/* 381 */           return read(param1ArrayOfbyte, param1Int1, param1Int2);
/*     */         } 
/* 383 */         if (DirectoryURLConnection.this.ftp) {
/* 384 */           parseFTP(new String(this.buffer, 0, i));
/*     */         } else {
/* 386 */           parseFile(new String(this.buffer, 0, i));
/*     */         } 
/* 388 */         if (this.bytesIn != null) {
/* 389 */           return read(param1ArrayOfbyte, param1Int1, param1Int2);
/*     */         }
/*     */       } 
/*     */       
/* 393 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DirectoryURLConnection(URLConnection paramURLConnection, boolean paramBoolean) {
/* 403 */     super(paramURLConnection.getURL());
/* 404 */     this.dirUrl = paramURLConnection.getURL().toExternalForm();
/* 405 */     this.inner = paramURLConnection;
/* 406 */     this.sure = !paramBoolean;
/* 407 */     this.ftp = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DirectoryURLConnection(URLConnection paramURLConnection) {
/* 414 */     super(paramURLConnection.getURL());
/* 415 */     this.dirUrl = paramURLConnection.getURL().toExternalForm();
/* 416 */     this.ftp = false;
/* 417 */     this.sure = true;
/* 418 */     this.inner = paramURLConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {
/* 424 */     this.inner.connect();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 430 */     if (this.ins == null) {
/* 431 */       if (this.ftp) {
/* 432 */         this.ins = new DirectoryInputStream(this.inner.getInputStream(), !this.sure);
/*     */       } else {
/* 434 */         this.ins = new DirectoryInputStream(this.inner.getInputStream(), false);
/*     */       } 
/*     */     }
/* 437 */     return this.ins;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*     */     try {
/* 444 */       if (!this.sure) {
/* 445 */         getInputStream();
/*     */       }
/* 447 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 450 */     if (this.toHTML) {
/* 451 */       return "text/html";
/*     */     }
/*     */     
/* 454 */     return this.inner.getContentType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentEncoding() {
/* 460 */     return this.inner.getContentEncoding();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getContentLength() {
/* 466 */     return this.inner.getContentLength();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> getHeaderFields() {
/* 472 */     return this.inner.getHeaderFields();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHeaderField(String paramString) {
/* 478 */     return this.inner.getHeaderField(paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\DirectoryURLConnection.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */