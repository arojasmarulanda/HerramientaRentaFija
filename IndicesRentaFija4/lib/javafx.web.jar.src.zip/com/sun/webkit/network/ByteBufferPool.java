/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.Semaphore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ByteBufferPool
/*     */ {
/*  42 */   private final Queue<ByteBuffer> byteBuffers = new ConcurrentLinkedQueue<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int bufferSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ByteBufferPool(int paramInt) {
/*  55 */     this.bufferSize = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ByteBufferPool newInstance(int paramInt) {
/*  63 */     return new ByteBufferPool(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ByteBufferAllocator newAllocator(int paramInt) {
/*  74 */     return new ByteBufferAllocatorImpl(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class ByteBufferAllocatorImpl
/*     */     implements ByteBufferAllocator
/*     */   {
/*     */     private final Semaphore semaphore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ByteBufferAllocatorImpl(int param1Int) {
/*  93 */       this.semaphore = new Semaphore(param1Int);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ByteBuffer allocate() throws InterruptedException {
/* 102 */       this.semaphore.acquire();
/* 103 */       ByteBuffer byteBuffer = ByteBufferPool.this.byteBuffers.poll();
/* 104 */       if (byteBuffer == null) {
/* 105 */         byteBuffer = ByteBuffer.allocateDirect(ByteBufferPool.this.bufferSize);
/*     */       }
/* 107 */       return byteBuffer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void release(ByteBuffer param1ByteBuffer) {
/* 115 */       ByteBufferPool.this.byteBuffers.add(param1ByteBuffer);
/* 116 */       this.semaphore.release();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\network\ByteBufferPool.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */