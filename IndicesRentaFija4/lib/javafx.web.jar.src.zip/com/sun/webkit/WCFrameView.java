/*    */ package com.sun.webkit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WCFrameView
/*    */   extends WCWidget
/*    */ {
/*    */   WCFrameView(WebPage paramWebPage) {
/* 31 */     super(paramWebPage);
/*    */   }
/*    */   
/*    */   protected void requestFocus() {
/* 35 */     WebPageClient webPageClient = getPage().getPageClient();
/* 36 */     if (webPageClient != null) {
/* 37 */       webPageClient.setFocus(true);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void setCursor(long paramLong) {
/* 42 */     WebPageClient webPageClient = getPage().getPageClient();
/* 43 */     if (webPageClient != null)
/* 44 */       webPageClient.setCursor(paramLong); 
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\WCFrameView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */