package com.sun.webkit;

import com.sun.webkit.graphics.WCPageBackBuffer;
import com.sun.webkit.graphics.WCPoint;
import com.sun.webkit.graphics.WCRectangle;

public interface WebPageClient<T> {
  void setCursor(long paramLong);
  
  void setFocus(boolean paramBoolean);
  
  void transferFocus(boolean paramBoolean);
  
  void setTooltip(String paramString);
  
  WCRectangle getScreenBounds(boolean paramBoolean);
  
  int getScreenDepth();
  
  T getContainer();
  
  WCPoint screenToWindow(WCPoint paramWCPoint);
  
  WCPoint windowToScreen(WCPoint paramWCPoint);
  
  WCPageBackBuffer createBackBuffer();
  
  boolean isBackBufferSupported();
  
  void addMessageToConsole(String paramString1, int paramInt, String paramString2);
  
  void didClearWindowObject(long paramLong1, long paramLong2);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\WebPageClient.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */