/*     */ package com.sun.webkit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SeparateThreadTimer
/*     */   extends Timer
/*     */   implements Runnable
/*     */ {
/*     */   private final Invoker invoker;
/*     */   private final FireRunner fireRunner;
/*     */   private final Thread thread;
/*     */   
/*     */   SeparateThreadTimer() {
/* 115 */     this.invoker = Invoker.getInvoker();
/* 116 */     this.fireRunner = new FireRunner();
/* 117 */     this.thread = new Thread(this, "WebPane-Timer");
/* 118 */     this.thread.setDaemon(true);
/*     */   }
/*     */   
/*     */   private final class FireRunner implements Runnable {
/*     */     private volatile long time;
/*     */     
/*     */     private Runnable forTime(long param1Long) {
/* 125 */       this.time = param1Long;
/* 126 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 131 */       SeparateThreadTimer.this.fireTimerEvent(this.time);
/*     */     }
/*     */     
/*     */     private FireRunner() {} }
/*     */   
/*     */   synchronized void setFireTime(long paramLong) {
/* 137 */     super.setFireTime(paramLong);
/* 138 */     if (this.thread.getState() == Thread.State.NEW) {
/* 139 */       this.thread.start();
/*     */     }
/* 141 */     notifyAll();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void run() {
/*     */     try {
/*     */       while (true)
/* 148 */       { if (this.fireTime > 0L) {
/* 149 */           long l = System.currentTimeMillis();
/* 150 */           while (this.fireTime > l) {
/* 151 */             wait(this.fireTime - l);
/* 152 */             l = System.currentTimeMillis();
/*     */           } 
/* 154 */           if (this.fireTime > 0L) {
/* 155 */             this.invoker.invokeOnEventThread(this.fireRunner.forTime(this.fireTime));
/*     */           }
/*     */         } 
/* 158 */         wait(); } 
/* 159 */     } catch (InterruptedException interruptedException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void notifyTick() {
/*     */     assert false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\SeparateThreadTimer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */