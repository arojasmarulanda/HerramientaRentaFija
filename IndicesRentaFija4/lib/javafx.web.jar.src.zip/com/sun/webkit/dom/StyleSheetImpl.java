/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.stylesheets.MediaList;
/*     */ import org.w3c.dom.stylesheets.StyleSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StyleSheetImpl
/*     */   implements StyleSheet
/*     */ {
/*     */   private final long peer;
/*     */   private static final int TYPE_CSSStyleSheet = 1;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  38 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  41 */       StyleSheetImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   StyleSheetImpl(long paramLong) {
/*  46 */     this.peer = paramLong;
/*  47 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static StyleSheet create(long paramLong) {
/*  51 */     if (paramLong == 0L) return null; 
/*  52 */     switch (getCPPTypeImpl(paramLong)) { case 1:
/*  53 */         return new CSSStyleSheetImpl(paramLong); }
/*     */     
/*  55 */     return new StyleSheetImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  61 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  65 */     return (paramObject instanceof StyleSheetImpl && this.peer == ((StyleSheetImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  69 */     long l = this.peer;
/*  70 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(StyleSheet paramStyleSheet) {
/*  74 */     return (paramStyleSheet == null) ? 0L : ((StyleSheetImpl)paramStyleSheet).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static StyleSheet getImpl(long paramLong) {
/*  83 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/*  89 */     return getTypeImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDisabled() {
/*  94 */     return getDisabledImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDisabled(boolean paramBoolean) {
/*  99 */     setDisabledImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getOwnerNode() {
/* 104 */     return NodeImpl.getImpl(getOwnerNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public StyleSheet getParentStyleSheet() {
/* 109 */     return getImpl(getParentStyleSheetImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHref() {
/* 114 */     return getHrefImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTitle() {
/* 119 */     return getTitleImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaList getMedia() {
/* 124 */     return MediaListImpl.getImpl(getMediaImpl(getPeer()));
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   private static native int getCPPTypeImpl(long paramLong);
/*     */   
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   static native boolean getDisabledImpl(long paramLong);
/*     */   
/*     */   static native void setDisabledImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   static native long getOwnerNodeImpl(long paramLong);
/*     */   
/*     */   static native long getParentStyleSheetImpl(long paramLong);
/*     */   
/*     */   static native String getHrefImpl(long paramLong);
/*     */   
/*     */   static native String getTitleImpl(long paramLong);
/*     */   
/*     */   static native long getMediaImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\StyleSheetImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */