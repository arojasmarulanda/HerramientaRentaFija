/*     */ package com.sun.webkit.dom;
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.events.Event;
/*     */ import org.w3c.dom.events.EventTarget;
/*     */ 
/*     */ public class EventImpl implements Event {
/*     */   private final long peer;
/*     */   private static final int TYPE_WheelEvent = 1;
/*     */   private static final int TYPE_MouseEvent = 2;
/*     */   private static final int TYPE_KeyboardEvent = 3;
/*     */   private static final int TYPE_UIEvent = 4;
/*     */   private static final int TYPE_MutationEvent = 5;
/*     */   public static final int NONE = 0;
/*     */   public static final int CAPTURING_PHASE = 1;
/*     */   public static final int AT_TARGET = 2;
/*     */   public static final int BUBBLING_PHASE = 3;
/*     */   public static final int MOUSEDOWN = 1;
/*     */   public static final int MOUSEUP = 2;
/*     */   public static final int MOUSEOVER = 4;
/*     */   public static final int MOUSEOUT = 8;
/*     */   public static final int MOUSEMOVE = 16;
/*     */   public static final int MOUSEDRAG = 32;
/*     */   public static final int CLICK = 64;
/*     */   public static final int DBLCLICK = 128;
/*     */   public static final int KEYDOWN = 256;
/*     */   public static final int KEYUP = 512;
/*     */   public static final int KEYPRESS = 1024;
/*     */   public static final int DRAGDROP = 2048;
/*     */   public static final int FOCUS = 4096;
/*     */   public static final int BLUR = 8192;
/*     */   public static final int SELECT = 16384;
/*     */   public static final int CHANGE = 32768;
/*     */   
/*     */   private static class SelfDisposer implements DisposerRecord {
/*     */     SelfDisposer(long param1Long) {
/*  37 */       this.peer = param1Long;
/*     */     } private final long peer;
/*     */     public void dispose() {
/*  40 */       EventImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   EventImpl(long paramLong) {
/*  45 */     this.peer = paramLong;
/*  46 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static Event create(long paramLong) {
/*  50 */     if (paramLong == 0L) return null; 
/*  51 */     switch (getCPPTypeImpl(paramLong)) { case 2:
/*  52 */         return new MouseEventImpl(paramLong);
/*  53 */       case 3: return new KeyboardEventImpl(paramLong);
/*  54 */       case 1: return new WheelEventImpl(paramLong);
/*  55 */       case 4: return new UIEventImpl(paramLong);
/*  56 */       case 5: return new MutationEventImpl(paramLong); }
/*     */     
/*  58 */     return new EventImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  64 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  68 */     return (paramObject instanceof EventImpl && this.peer == ((EventImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  72 */     long l = this.peer;
/*  73 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(Event paramEvent) {
/*  77 */     return (paramEvent == null) ? 0L : ((EventImpl)paramEvent).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Event getImpl(long paramLong) {
/*  90 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 118 */     return getTypeImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public EventTarget getTarget() {
/* 123 */     return (EventTarget)NodeImpl.getImpl(getTargetImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public EventTarget getCurrentTarget() {
/* 128 */     return (EventTarget)NodeImpl.getImpl(getCurrentTargetImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public short getEventPhase() {
/* 133 */     return getEventPhaseImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBubbles() {
/* 138 */     return getBubblesImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getCancelable() {
/* 143 */     return getCancelableImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTimeStamp() {
/* 148 */     return getTimeStampImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDefaultPrevented() {
/* 153 */     return getDefaultPreventedImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getIsTrusted() {
/* 158 */     return getIsTrustedImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public EventTarget getSrcElement() {
/* 163 */     return (EventTarget)NodeImpl.getImpl(getSrcElementImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getReturnValue() {
/* 168 */     return getReturnValueImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReturnValue(boolean paramBoolean) {
/* 173 */     setReturnValueImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getCancelBubble() {
/* 178 */     return getCancelBubbleImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCancelBubble(boolean paramBoolean) {
/* 183 */     setCancelBubbleImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopPropagation() {
/* 191 */     stopPropagationImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void preventDefault() {
/* 198 */     preventDefaultImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initEvent(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 207 */     initEventImpl(getPeer(), paramString, paramBoolean1, paramBoolean2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopImmediatePropagation() {
/* 220 */     stopImmediatePropagationImpl(getPeer());
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   private static native int getCPPTypeImpl(long paramLong);
/*     */   
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   static native long getTargetImpl(long paramLong);
/*     */   
/*     */   static native long getCurrentTargetImpl(long paramLong);
/*     */   
/*     */   static native short getEventPhaseImpl(long paramLong);
/*     */   
/*     */   static native boolean getBubblesImpl(long paramLong);
/*     */   
/*     */   static native boolean getCancelableImpl(long paramLong);
/*     */   
/*     */   static native long getTimeStampImpl(long paramLong);
/*     */   
/*     */   static native boolean getDefaultPreventedImpl(long paramLong);
/*     */   
/*     */   static native boolean getIsTrustedImpl(long paramLong);
/*     */   
/*     */   static native long getSrcElementImpl(long paramLong);
/*     */   
/*     */   static native boolean getReturnValueImpl(long paramLong);
/*     */   
/*     */   static native void setReturnValueImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   static native boolean getCancelBubbleImpl(long paramLong);
/*     */   
/*     */   static native void setCancelBubbleImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   static native void stopPropagationImpl(long paramLong);
/*     */   
/*     */   static native void preventDefaultImpl(long paramLong);
/*     */   
/*     */   static native void initEventImpl(long paramLong, String paramString, boolean paramBoolean1, boolean paramBoolean2);
/*     */   
/*     */   static native void stopImmediatePropagationImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\EventImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */