/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.html.HTMLAreaElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLAreaElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLAreaElement
/*     */ {
/*     */   HTMLAreaElementImpl(long paramLong) {
/*  32 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLAreaElement getImpl(long paramLong) {
/*  36 */     return (HTMLAreaElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getAltImpl(long paramLong);
/*     */   
/*     */   public String getAlt() {
/*  42 */     return getAltImpl(getPeer());
/*     */   }
/*     */   static native void setAltImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setAlt(String paramString) {
/*  47 */     setAltImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCoords() {
/*  52 */     return getCoordsImpl(getPeer());
/*     */   }
/*     */   static native String getCoordsImpl(long paramLong);
/*     */   
/*     */   public void setCoords(String paramString) {
/*  57 */     setCoordsImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCoordsImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getNoHref() {
/*  62 */     return getNoHrefImpl(getPeer());
/*     */   }
/*     */   static native boolean getNoHrefImpl(long paramLong);
/*     */   
/*     */   public void setNoHref(boolean paramBoolean) {
/*  67 */     setNoHrefImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setNoHrefImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getPing() {
/*  72 */     return getPingImpl(getPeer());
/*     */   }
/*     */   static native String getPingImpl(long paramLong);
/*     */   
/*     */   public void setPing(String paramString) {
/*  77 */     setPingImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPingImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getRel() {
/*  82 */     return getRelImpl(getPeer());
/*     */   }
/*     */   static native String getRelImpl(long paramLong);
/*     */   
/*     */   public void setRel(String paramString) {
/*  87 */     setRelImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setRelImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getShape() {
/*  92 */     return getShapeImpl(getPeer());
/*     */   }
/*     */   static native String getShapeImpl(long paramLong);
/*     */   
/*     */   public void setShape(String paramString) {
/*  97 */     setShapeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setShapeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getTarget() {
/* 102 */     return getTargetImpl(getPeer());
/*     */   }
/*     */   static native String getTargetImpl(long paramLong);
/*     */   
/*     */   public void setTarget(String paramString) {
/* 107 */     setTargetImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTargetImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getAccessKey() {
/* 112 */     return getAccessKeyImpl(getPeer());
/*     */   }
/*     */   static native String getAccessKeyImpl(long paramLong);
/*     */   
/*     */   public void setAccessKey(String paramString) {
/* 117 */     setAccessKeyImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAccessKeyImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHref() {
/* 122 */     return getHrefImpl(getPeer());
/*     */   }
/*     */   static native String getHrefImpl(long paramLong);
/*     */   
/*     */   public void setHref(String paramString) {
/* 127 */     setHrefImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHrefImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getOrigin() {
/* 132 */     return getOriginImpl(getPeer());
/*     */   }
/*     */   static native String getOriginImpl(long paramLong);
/*     */   
/*     */   public String getProtocol() {
/* 137 */     return getProtocolImpl(getPeer());
/*     */   }
/*     */   static native String getProtocolImpl(long paramLong);
/*     */   
/*     */   public void setProtocol(String paramString) {
/* 142 */     setProtocolImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setProtocolImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getUsername() {
/* 147 */     return getUsernameImpl(getPeer());
/*     */   }
/*     */   static native String getUsernameImpl(long paramLong);
/*     */   
/*     */   public void setUsername(String paramString) {
/* 152 */     setUsernameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setUsernameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getPassword() {
/* 157 */     return getPasswordImpl(getPeer());
/*     */   }
/*     */   static native String getPasswordImpl(long paramLong);
/*     */   
/*     */   public void setPassword(String paramString) {
/* 162 */     setPasswordImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPasswordImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHost() {
/* 167 */     return getHostImpl(getPeer());
/*     */   }
/*     */   static native String getHostImpl(long paramLong);
/*     */   
/*     */   public void setHost(String paramString) {
/* 172 */     setHostImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHostImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHostname() {
/* 177 */     return getHostnameImpl(getPeer());
/*     */   }
/*     */   static native String getHostnameImpl(long paramLong);
/*     */   
/*     */   public void setHostname(String paramString) {
/* 182 */     setHostnameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHostnameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getPort() {
/* 187 */     return getPortImpl(getPeer());
/*     */   }
/*     */   static native String getPortImpl(long paramLong);
/*     */   
/*     */   public void setPort(String paramString) {
/* 192 */     setPortImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPortImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getPathname() {
/* 197 */     return getPathnameImpl(getPeer());
/*     */   }
/*     */   static native String getPathnameImpl(long paramLong);
/*     */   
/*     */   public void setPathname(String paramString) {
/* 202 */     setPathnameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPathnameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getSearch() {
/* 207 */     return getSearchImpl(getPeer());
/*     */   }
/*     */   static native String getSearchImpl(long paramLong);
/*     */   
/*     */   public void setSearch(String paramString) {
/* 212 */     setSearchImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSearchImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHash() {
/* 217 */     return getHashImpl(getPeer());
/*     */   }
/*     */   static native String getHashImpl(long paramLong);
/*     */   
/*     */   public void setHash(String paramString) {
/* 222 */     setHashImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   static native void setHashImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLAreaElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */