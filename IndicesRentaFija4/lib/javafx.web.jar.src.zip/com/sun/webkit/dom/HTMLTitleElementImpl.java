/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLTitleElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLTitleElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLTitleElement
/*    */ {
/*    */   HTMLTitleElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLTitleElement getImpl(long paramLong) {
/* 36 */     return (HTMLTitleElement)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getText() {
/* 42 */     return getTextImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setText(String paramString) {
/* 47 */     setTextImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native String getTextImpl(long paramLong);
/*    */   
/*    */   static native void setTextImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLTitleElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */