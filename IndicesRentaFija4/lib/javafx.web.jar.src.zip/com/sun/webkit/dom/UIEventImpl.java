/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.events.UIEvent;
/*    */ import org.w3c.dom.views.AbstractView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UIEventImpl
/*    */   extends EventImpl
/*    */   implements UIEvent
/*    */ {
/*    */   UIEventImpl(long paramLong) {
/* 33 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static UIEvent getImpl(long paramLong) {
/* 37 */     return (UIEvent)create(paramLong);
/*    */   }
/*    */   
/*    */   static native long getViewImpl(long paramLong);
/*    */   
/*    */   public AbstractView getView() {
/* 43 */     return DOMWindowImpl.getImpl(getViewImpl(getPeer()));
/*    */   }
/*    */   static native int getDetailImpl(long paramLong);
/*    */   
/*    */   public int getDetail() {
/* 48 */     return getDetailImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public int getKeyCode() {
/* 53 */     return getKeyCodeImpl(getPeer());
/*    */   }
/*    */   static native int getKeyCodeImpl(long paramLong);
/*    */   
/*    */   public int getCharCode() {
/* 58 */     return getCharCodeImpl(getPeer());
/*    */   }
/*    */   static native int getCharCodeImpl(long paramLong);
/*    */   
/*    */   public int getLayerX() {
/* 63 */     return getLayerXImpl(getPeer());
/*    */   }
/*    */   static native int getLayerXImpl(long paramLong);
/*    */   
/*    */   public int getLayerY() {
/* 68 */     return getLayerYImpl(getPeer());
/*    */   }
/*    */   static native int getLayerYImpl(long paramLong);
/*    */   
/*    */   public int getPageX() {
/* 73 */     return getPageXImpl(getPeer());
/*    */   }
/*    */   static native int getPageXImpl(long paramLong);
/*    */   
/*    */   public int getPageY() {
/* 78 */     return getPageYImpl(getPeer());
/*    */   }
/*    */   static native int getPageYImpl(long paramLong);
/*    */   
/*    */   public int getWhich() {
/* 83 */     return getWhichImpl(getPeer());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static native int getWhichImpl(long paramLong);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initUIEvent(String paramString, boolean paramBoolean1, boolean paramBoolean2, AbstractView paramAbstractView, int paramInt) {
/* 95 */     initUIEventImpl(getPeer(), paramString, paramBoolean1, paramBoolean2, 
/*    */ 
/*    */ 
/*    */         
/* 99 */         DOMWindowImpl.getPeer(paramAbstractView), paramInt);
/*    */   }
/*    */   
/*    */   static native void initUIEventImpl(long paramLong1, String paramString, boolean paramBoolean1, boolean paramBoolean2, long paramLong2, int paramInt);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\UIEventImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */