/*      */ package com.sun.webkit.dom;
/*      */ 
/*      */ import org.w3c.dom.Attr;
/*      */ import org.w3c.dom.DOMException;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.w3c.dom.TypeInfo;
/*      */ import org.w3c.dom.css.CSSStyleDeclaration;
/*      */ import org.w3c.dom.events.EventListener;
/*      */ import org.w3c.dom.html.HTMLCollection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ElementImpl
/*      */   extends NodeImpl
/*      */   implements Element
/*      */ {
/*      */   public static final int ALLOW_KEYBOARD_INPUT = 1;
/*      */   
/*      */   ElementImpl(long paramLong) {
/*   40 */     super(paramLong);
/*      */   }
/*      */   
/*      */   static Element getImpl(long paramLong) {
/*   44 */     return (Element)create(paramLong);
/*      */   }
/*      */ 
/*      */   
/*      */   static native boolean isHTMLElementImpl(long paramLong);
/*      */ 
/*      */   
/*      */   static native String getTagNameImpl(long paramLong);
/*      */ 
/*      */   
/*      */   public String getTagName() {
/*   55 */     return getTagNameImpl(getPeer());
/*      */   }
/*      */   static native long getAttributesImpl(long paramLong);
/*      */   
/*      */   public NamedNodeMap getAttributes() {
/*   60 */     return NamedNodeMapImpl.getImpl(getAttributesImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public CSSStyleDeclaration getStyle() {
/*   65 */     return CSSStyleDeclarationImpl.getImpl(getStyleImpl(getPeer()));
/*      */   }
/*      */   static native long getStyleImpl(long paramLong);
/*      */   
/*      */   public String getId() {
/*   70 */     return getIdImpl(getPeer());
/*      */   }
/*      */   static native String getIdImpl(long paramLong);
/*      */   
/*      */   public void setId(String paramString) {
/*   75 */     setIdImpl(getPeer(), paramString);
/*      */   }
/*      */   static native void setIdImpl(long paramLong, String paramString);
/*      */   
/*      */   public double getOffsetLeft() {
/*   80 */     return getOffsetLeftImpl(getPeer());
/*      */   }
/*      */   static native double getOffsetLeftImpl(long paramLong);
/*      */   
/*      */   public double getOffsetTop() {
/*   85 */     return getOffsetTopImpl(getPeer());
/*      */   }
/*      */   static native double getOffsetTopImpl(long paramLong);
/*      */   
/*      */   public double getOffsetWidth() {
/*   90 */     return getOffsetWidthImpl(getPeer());
/*      */   }
/*      */   static native double getOffsetWidthImpl(long paramLong);
/*      */   
/*      */   public double getOffsetHeight() {
/*   95 */     return getOffsetHeightImpl(getPeer());
/*      */   }
/*      */   static native double getOffsetHeightImpl(long paramLong);
/*      */   
/*      */   public double getClientLeft() {
/*  100 */     return getClientLeftImpl(getPeer());
/*      */   }
/*      */   static native double getClientLeftImpl(long paramLong);
/*      */   
/*      */   public double getClientTop() {
/*  105 */     return getClientTopImpl(getPeer());
/*      */   }
/*      */   static native double getClientTopImpl(long paramLong);
/*      */   
/*      */   public double getClientWidth() {
/*  110 */     return getClientWidthImpl(getPeer());
/*      */   }
/*      */   static native double getClientWidthImpl(long paramLong);
/*      */   
/*      */   public double getClientHeight() {
/*  115 */     return getClientHeightImpl(getPeer());
/*      */   }
/*      */   static native double getClientHeightImpl(long paramLong);
/*      */   
/*      */   public int getScrollLeft() {
/*  120 */     return getScrollLeftImpl(getPeer());
/*      */   }
/*      */   static native int getScrollLeftImpl(long paramLong);
/*      */   
/*      */   public void setScrollLeft(int paramInt) {
/*  125 */     setScrollLeftImpl(getPeer(), paramInt);
/*      */   }
/*      */   static native void setScrollLeftImpl(long paramLong, int paramInt);
/*      */   
/*      */   public int getScrollTop() {
/*  130 */     return getScrollTopImpl(getPeer());
/*      */   }
/*      */   static native int getScrollTopImpl(long paramLong);
/*      */   
/*      */   public void setScrollTop(int paramInt) {
/*  135 */     setScrollTopImpl(getPeer(), paramInt);
/*      */   }
/*      */   static native void setScrollTopImpl(long paramLong, int paramInt);
/*      */   
/*      */   public int getScrollWidth() {
/*  140 */     return getScrollWidthImpl(getPeer());
/*      */   }
/*      */   static native int getScrollWidthImpl(long paramLong);
/*      */   
/*      */   public int getScrollHeight() {
/*  145 */     return getScrollHeightImpl(getPeer());
/*      */   }
/*      */   static native int getScrollHeightImpl(long paramLong);
/*      */   
/*      */   public Element getOffsetParent() {
/*  150 */     return getImpl(getOffsetParentImpl(getPeer()));
/*      */   }
/*      */   static native long getOffsetParentImpl(long paramLong);
/*      */   
/*      */   public String getInnerHTML() {
/*  155 */     return getInnerHTMLImpl(getPeer());
/*      */   }
/*      */   static native String getInnerHTMLImpl(long paramLong);
/*      */   
/*      */   public void setInnerHTML(String paramString) throws DOMException {
/*  160 */     setInnerHTMLImpl(getPeer(), paramString);
/*      */   }
/*      */   static native void setInnerHTMLImpl(long paramLong, String paramString);
/*      */   
/*      */   public String getOuterHTML() {
/*  165 */     return getOuterHTMLImpl(getPeer());
/*      */   }
/*      */   static native String getOuterHTMLImpl(long paramLong);
/*      */   
/*      */   public void setOuterHTML(String paramString) throws DOMException {
/*  170 */     setOuterHTMLImpl(getPeer(), paramString);
/*      */   }
/*      */   static native void setOuterHTMLImpl(long paramLong, String paramString);
/*      */   
/*      */   public String getClassName() {
/*  175 */     return getClassNameImpl(getPeer());
/*      */   }
/*      */   static native String getClassNameImpl(long paramLong);
/*      */   
/*      */   public void setClassName(String paramString) {
/*  180 */     setClassNameImpl(getPeer(), paramString);
/*      */   }
/*      */   static native void setClassNameImpl(long paramLong, String paramString);
/*      */   
/*      */   public EventListener getOnbeforecopy() {
/*  185 */     return EventListenerImpl.getImpl(getOnbeforecopyImpl(getPeer()));
/*      */   }
/*      */   static native long getOnbeforecopyImpl(long paramLong);
/*      */   
/*      */   public void setOnbeforecopy(EventListener paramEventListener) {
/*  190 */     setOnbeforecopyImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnbeforecopyImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnbeforecut() {
/*  195 */     return EventListenerImpl.getImpl(getOnbeforecutImpl(getPeer()));
/*      */   }
/*      */   static native long getOnbeforecutImpl(long paramLong);
/*      */   
/*      */   public void setOnbeforecut(EventListener paramEventListener) {
/*  200 */     setOnbeforecutImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnbeforecutImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnbeforepaste() {
/*  205 */     return EventListenerImpl.getImpl(getOnbeforepasteImpl(getPeer()));
/*      */   }
/*      */   static native long getOnbeforepasteImpl(long paramLong);
/*      */   
/*      */   public void setOnbeforepaste(EventListener paramEventListener) {
/*  210 */     setOnbeforepasteImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnbeforepasteImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOncopy() {
/*  215 */     return EventListenerImpl.getImpl(getOncopyImpl(getPeer()));
/*      */   }
/*      */   static native long getOncopyImpl(long paramLong);
/*      */   
/*      */   public void setOncopy(EventListener paramEventListener) {
/*  220 */     setOncopyImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOncopyImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOncut() {
/*  225 */     return EventListenerImpl.getImpl(getOncutImpl(getPeer()));
/*      */   }
/*      */   static native long getOncutImpl(long paramLong);
/*      */   
/*      */   public void setOncut(EventListener paramEventListener) {
/*  230 */     setOncutImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOncutImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnpaste() {
/*  235 */     return EventListenerImpl.getImpl(getOnpasteImpl(getPeer()));
/*      */   }
/*      */   static native long getOnpasteImpl(long paramLong);
/*      */   
/*      */   public void setOnpaste(EventListener paramEventListener) {
/*  240 */     setOnpasteImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnpasteImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnselectstart() {
/*  245 */     return EventListenerImpl.getImpl(getOnselectstartImpl(getPeer()));
/*      */   }
/*      */   static native long getOnselectstartImpl(long paramLong);
/*      */   
/*      */   public void setOnselectstart(EventListener paramEventListener) {
/*  250 */     setOnselectstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnselectstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnanimationend() {
/*  255 */     return EventListenerImpl.getImpl(getOnanimationendImpl(getPeer()));
/*      */   }
/*      */   static native long getOnanimationendImpl(long paramLong);
/*      */   
/*      */   public void setOnanimationend(EventListener paramEventListener) {
/*  260 */     setOnanimationendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnanimationendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnanimationiteration() {
/*  265 */     return EventListenerImpl.getImpl(getOnanimationiterationImpl(getPeer()));
/*      */   }
/*      */   static native long getOnanimationiterationImpl(long paramLong);
/*      */   
/*      */   public void setOnanimationiteration(EventListener paramEventListener) {
/*  270 */     setOnanimationiterationImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnanimationiterationImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnanimationstart() {
/*  275 */     return EventListenerImpl.getImpl(getOnanimationstartImpl(getPeer()));
/*      */   }
/*      */   static native long getOnanimationstartImpl(long paramLong);
/*      */   
/*      */   public void setOnanimationstart(EventListener paramEventListener) {
/*  280 */     setOnanimationstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnanimationstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOntransitionend() {
/*  285 */     return EventListenerImpl.getImpl(getOntransitionendImpl(getPeer()));
/*      */   }
/*      */   static native long getOntransitionendImpl(long paramLong);
/*      */   
/*      */   public void setOntransitionend(EventListener paramEventListener) {
/*  290 */     setOntransitionendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOntransitionendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnwebkitanimationend() {
/*  295 */     return EventListenerImpl.getImpl(getOnwebkitanimationendImpl(getPeer()));
/*      */   }
/*      */   static native long getOnwebkitanimationendImpl(long paramLong);
/*      */   
/*      */   public void setOnwebkitanimationend(EventListener paramEventListener) {
/*  300 */     setOnwebkitanimationendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnwebkitanimationendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnwebkitanimationiteration() {
/*  305 */     return EventListenerImpl.getImpl(getOnwebkitanimationiterationImpl(getPeer()));
/*      */   }
/*      */   static native long getOnwebkitanimationiterationImpl(long paramLong);
/*      */   
/*      */   public void setOnwebkitanimationiteration(EventListener paramEventListener) {
/*  310 */     setOnwebkitanimationiterationImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnwebkitanimationiterationImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnwebkitanimationstart() {
/*  315 */     return EventListenerImpl.getImpl(getOnwebkitanimationstartImpl(getPeer()));
/*      */   }
/*      */   static native long getOnwebkitanimationstartImpl(long paramLong);
/*      */   
/*      */   public void setOnwebkitanimationstart(EventListener paramEventListener) {
/*  320 */     setOnwebkitanimationstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnwebkitanimationstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnwebkittransitionend() {
/*  325 */     return EventListenerImpl.getImpl(getOnwebkittransitionendImpl(getPeer()));
/*      */   }
/*      */   static native long getOnwebkittransitionendImpl(long paramLong);
/*      */   
/*      */   public void setOnwebkittransitionend(EventListener paramEventListener) {
/*  330 */     setOnwebkittransitionendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnwebkittransitionendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnfocusin() {
/*  335 */     return EventListenerImpl.getImpl(getOnfocusinImpl(getPeer()));
/*      */   }
/*      */   static native long getOnfocusinImpl(long paramLong);
/*      */   
/*      */   public void setOnfocusin(EventListener paramEventListener) {
/*  340 */     setOnfocusinImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnfocusinImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnfocusout() {
/*  345 */     return EventListenerImpl.getImpl(getOnfocusoutImpl(getPeer()));
/*      */   }
/*      */   static native long getOnfocusoutImpl(long paramLong);
/*      */   
/*      */   public void setOnfocusout(EventListener paramEventListener) {
/*  350 */     setOnfocusoutImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnfocusoutImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnbeforeload() {
/*  355 */     return EventListenerImpl.getImpl(getOnbeforeloadImpl(getPeer()));
/*      */   }
/*      */   static native long getOnbeforeloadImpl(long paramLong);
/*      */   
/*      */   public void setOnbeforeload(EventListener paramEventListener) {
/*  360 */     setOnbeforeloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnbeforeloadImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnabort() {
/*  365 */     return EventListenerImpl.getImpl(getOnabortImpl(getPeer()));
/*      */   }
/*      */   static native long getOnabortImpl(long paramLong);
/*      */   
/*      */   public void setOnabort(EventListener paramEventListener) {
/*  370 */     setOnabortImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnabortImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnblur() {
/*  375 */     return EventListenerImpl.getImpl(getOnblurImpl(getPeer()));
/*      */   }
/*      */   static native long getOnblurImpl(long paramLong);
/*      */   
/*      */   public void setOnblur(EventListener paramEventListener) {
/*  380 */     setOnblurImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnblurImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOncanplay() {
/*  385 */     return EventListenerImpl.getImpl(getOncanplayImpl(getPeer()));
/*      */   }
/*      */   static native long getOncanplayImpl(long paramLong);
/*      */   
/*      */   public void setOncanplay(EventListener paramEventListener) {
/*  390 */     setOncanplayImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOncanplayImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOncanplaythrough() {
/*  395 */     return EventListenerImpl.getImpl(getOncanplaythroughImpl(getPeer()));
/*      */   }
/*      */   static native long getOncanplaythroughImpl(long paramLong);
/*      */   
/*      */   public void setOncanplaythrough(EventListener paramEventListener) {
/*  400 */     setOncanplaythroughImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOncanplaythroughImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnchange() {
/*  405 */     return EventListenerImpl.getImpl(getOnchangeImpl(getPeer()));
/*      */   }
/*      */   static native long getOnchangeImpl(long paramLong);
/*      */   
/*      */   public void setOnchange(EventListener paramEventListener) {
/*  410 */     setOnchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnchangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnclick() {
/*  415 */     return EventListenerImpl.getImpl(getOnclickImpl(getPeer()));
/*      */   }
/*      */   static native long getOnclickImpl(long paramLong);
/*      */   
/*      */   public void setOnclick(EventListener paramEventListener) {
/*  420 */     setOnclickImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnclickImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOncontextmenu() {
/*  425 */     return EventListenerImpl.getImpl(getOncontextmenuImpl(getPeer()));
/*      */   }
/*      */   static native long getOncontextmenuImpl(long paramLong);
/*      */   
/*      */   public void setOncontextmenu(EventListener paramEventListener) {
/*  430 */     setOncontextmenuImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOncontextmenuImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndblclick() {
/*  435 */     return EventListenerImpl.getImpl(getOndblclickImpl(getPeer()));
/*      */   }
/*      */   static native long getOndblclickImpl(long paramLong);
/*      */   
/*      */   public void setOndblclick(EventListener paramEventListener) {
/*  440 */     setOndblclickImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndblclickImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndrag() {
/*  445 */     return EventListenerImpl.getImpl(getOndragImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragImpl(long paramLong);
/*      */   
/*      */   public void setOndrag(EventListener paramEventListener) {
/*  450 */     setOndragImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndragend() {
/*  455 */     return EventListenerImpl.getImpl(getOndragendImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragendImpl(long paramLong);
/*      */   
/*      */   public void setOndragend(EventListener paramEventListener) {
/*  460 */     setOndragendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndragenter() {
/*  465 */     return EventListenerImpl.getImpl(getOndragenterImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragenterImpl(long paramLong);
/*      */   
/*      */   public void setOndragenter(EventListener paramEventListener) {
/*  470 */     setOndragenterImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragenterImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndragleave() {
/*  475 */     return EventListenerImpl.getImpl(getOndragleaveImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragleaveImpl(long paramLong);
/*      */   
/*      */   public void setOndragleave(EventListener paramEventListener) {
/*  480 */     setOndragleaveImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragleaveImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndragover() {
/*  485 */     return EventListenerImpl.getImpl(getOndragoverImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragoverImpl(long paramLong);
/*      */   
/*      */   public void setOndragover(EventListener paramEventListener) {
/*  490 */     setOndragoverImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragoverImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndragstart() {
/*  495 */     return EventListenerImpl.getImpl(getOndragstartImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragstartImpl(long paramLong);
/*      */   
/*      */   public void setOndragstart(EventListener paramEventListener) {
/*  500 */     setOndragstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndrop() {
/*  505 */     return EventListenerImpl.getImpl(getOndropImpl(getPeer()));
/*      */   }
/*      */   static native long getOndropImpl(long paramLong);
/*      */   
/*      */   public void setOndrop(EventListener paramEventListener) {
/*  510 */     setOndropImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndropImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndurationchange() {
/*  515 */     return EventListenerImpl.getImpl(getOndurationchangeImpl(getPeer()));
/*      */   }
/*      */   static native long getOndurationchangeImpl(long paramLong);
/*      */   
/*      */   public void setOndurationchange(EventListener paramEventListener) {
/*  520 */     setOndurationchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndurationchangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnemptied() {
/*  525 */     return EventListenerImpl.getImpl(getOnemptiedImpl(getPeer()));
/*      */   }
/*      */   static native long getOnemptiedImpl(long paramLong);
/*      */   
/*      */   public void setOnemptied(EventListener paramEventListener) {
/*  530 */     setOnemptiedImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnemptiedImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnended() {
/*  535 */     return EventListenerImpl.getImpl(getOnendedImpl(getPeer()));
/*      */   }
/*      */   static native long getOnendedImpl(long paramLong);
/*      */   
/*      */   public void setOnended(EventListener paramEventListener) {
/*  540 */     setOnendedImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnendedImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnerror() {
/*  545 */     return EventListenerImpl.getImpl(getOnerrorImpl(getPeer()));
/*      */   }
/*      */   static native long getOnerrorImpl(long paramLong);
/*      */   
/*      */   public void setOnerror(EventListener paramEventListener) {
/*  550 */     setOnerrorImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnerrorImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnfocus() {
/*  555 */     return EventListenerImpl.getImpl(getOnfocusImpl(getPeer()));
/*      */   }
/*      */   static native long getOnfocusImpl(long paramLong);
/*      */   
/*      */   public void setOnfocus(EventListener paramEventListener) {
/*  560 */     setOnfocusImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnfocusImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOninput() {
/*  565 */     return EventListenerImpl.getImpl(getOninputImpl(getPeer()));
/*      */   }
/*      */   static native long getOninputImpl(long paramLong);
/*      */   
/*      */   public void setOninput(EventListener paramEventListener) {
/*  570 */     setOninputImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOninputImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOninvalid() {
/*  575 */     return EventListenerImpl.getImpl(getOninvalidImpl(getPeer()));
/*      */   }
/*      */   static native long getOninvalidImpl(long paramLong);
/*      */   
/*      */   public void setOninvalid(EventListener paramEventListener) {
/*  580 */     setOninvalidImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOninvalidImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnkeydown() {
/*  585 */     return EventListenerImpl.getImpl(getOnkeydownImpl(getPeer()));
/*      */   }
/*      */   static native long getOnkeydownImpl(long paramLong);
/*      */   
/*      */   public void setOnkeydown(EventListener paramEventListener) {
/*  590 */     setOnkeydownImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnkeydownImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnkeypress() {
/*  595 */     return EventListenerImpl.getImpl(getOnkeypressImpl(getPeer()));
/*      */   }
/*      */   static native long getOnkeypressImpl(long paramLong);
/*      */   
/*      */   public void setOnkeypress(EventListener paramEventListener) {
/*  600 */     setOnkeypressImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnkeypressImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnkeyup() {
/*  605 */     return EventListenerImpl.getImpl(getOnkeyupImpl(getPeer()));
/*      */   }
/*      */   static native long getOnkeyupImpl(long paramLong);
/*      */   
/*      */   public void setOnkeyup(EventListener paramEventListener) {
/*  610 */     setOnkeyupImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnkeyupImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnload() {
/*  615 */     return EventListenerImpl.getImpl(getOnloadImpl(getPeer()));
/*      */   }
/*      */   static native long getOnloadImpl(long paramLong);
/*      */   
/*      */   public void setOnload(EventListener paramEventListener) {
/*  620 */     setOnloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnloadImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnloadeddata() {
/*  625 */     return EventListenerImpl.getImpl(getOnloadeddataImpl(getPeer()));
/*      */   }
/*      */   static native long getOnloadeddataImpl(long paramLong);
/*      */   
/*      */   public void setOnloadeddata(EventListener paramEventListener) {
/*  630 */     setOnloadeddataImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnloadeddataImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnloadedmetadata() {
/*  635 */     return EventListenerImpl.getImpl(getOnloadedmetadataImpl(getPeer()));
/*      */   }
/*      */   static native long getOnloadedmetadataImpl(long paramLong);
/*      */   
/*      */   public void setOnloadedmetadata(EventListener paramEventListener) {
/*  640 */     setOnloadedmetadataImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnloadedmetadataImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnloadstart() {
/*  645 */     return EventListenerImpl.getImpl(getOnloadstartImpl(getPeer()));
/*      */   }
/*      */   static native long getOnloadstartImpl(long paramLong);
/*      */   
/*      */   public void setOnloadstart(EventListener paramEventListener) {
/*  650 */     setOnloadstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnloadstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmousedown() {
/*  655 */     return EventListenerImpl.getImpl(getOnmousedownImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmousedownImpl(long paramLong);
/*      */   
/*      */   public void setOnmousedown(EventListener paramEventListener) {
/*  660 */     setOnmousedownImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmousedownImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmouseenter() {
/*  665 */     return EventListenerImpl.getImpl(getOnmouseenterImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmouseenterImpl(long paramLong);
/*      */   
/*      */   public void setOnmouseenter(EventListener paramEventListener) {
/*  670 */     setOnmouseenterImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmouseenterImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmouseleave() {
/*  675 */     return EventListenerImpl.getImpl(getOnmouseleaveImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmouseleaveImpl(long paramLong);
/*      */   
/*      */   public void setOnmouseleave(EventListener paramEventListener) {
/*  680 */     setOnmouseleaveImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmouseleaveImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmousemove() {
/*  685 */     return EventListenerImpl.getImpl(getOnmousemoveImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmousemoveImpl(long paramLong);
/*      */   
/*      */   public void setOnmousemove(EventListener paramEventListener) {
/*  690 */     setOnmousemoveImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmousemoveImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmouseout() {
/*  695 */     return EventListenerImpl.getImpl(getOnmouseoutImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmouseoutImpl(long paramLong);
/*      */   
/*      */   public void setOnmouseout(EventListener paramEventListener) {
/*  700 */     setOnmouseoutImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmouseoutImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmouseover() {
/*  705 */     return EventListenerImpl.getImpl(getOnmouseoverImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmouseoverImpl(long paramLong);
/*      */   
/*      */   public void setOnmouseover(EventListener paramEventListener) {
/*  710 */     setOnmouseoverImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmouseoverImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmouseup() {
/*  715 */     return EventListenerImpl.getImpl(getOnmouseupImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmouseupImpl(long paramLong);
/*      */   
/*      */   public void setOnmouseup(EventListener paramEventListener) {
/*  720 */     setOnmouseupImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmouseupImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmousewheel() {
/*  725 */     return EventListenerImpl.getImpl(getOnmousewheelImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmousewheelImpl(long paramLong);
/*      */   
/*      */   public void setOnmousewheel(EventListener paramEventListener) {
/*  730 */     setOnmousewheelImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmousewheelImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnpause() {
/*  735 */     return EventListenerImpl.getImpl(getOnpauseImpl(getPeer()));
/*      */   }
/*      */   static native long getOnpauseImpl(long paramLong);
/*      */   
/*      */   public void setOnpause(EventListener paramEventListener) {
/*  740 */     setOnpauseImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnpauseImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnplay() {
/*  745 */     return EventListenerImpl.getImpl(getOnplayImpl(getPeer()));
/*      */   }
/*      */   static native long getOnplayImpl(long paramLong);
/*      */   
/*      */   public void setOnplay(EventListener paramEventListener) {
/*  750 */     setOnplayImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnplayImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnplaying() {
/*  755 */     return EventListenerImpl.getImpl(getOnplayingImpl(getPeer()));
/*      */   }
/*      */   static native long getOnplayingImpl(long paramLong);
/*      */   
/*      */   public void setOnplaying(EventListener paramEventListener) {
/*  760 */     setOnplayingImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnplayingImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnprogress() {
/*  765 */     return EventListenerImpl.getImpl(getOnprogressImpl(getPeer()));
/*      */   }
/*      */   static native long getOnprogressImpl(long paramLong);
/*      */   
/*      */   public void setOnprogress(EventListener paramEventListener) {
/*  770 */     setOnprogressImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnprogressImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnratechange() {
/*  775 */     return EventListenerImpl.getImpl(getOnratechangeImpl(getPeer()));
/*      */   }
/*      */   static native long getOnratechangeImpl(long paramLong);
/*      */   
/*      */   public void setOnratechange(EventListener paramEventListener) {
/*  780 */     setOnratechangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnratechangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnreset() {
/*  785 */     return EventListenerImpl.getImpl(getOnresetImpl(getPeer()));
/*      */   }
/*      */   static native long getOnresetImpl(long paramLong);
/*      */   
/*      */   public void setOnreset(EventListener paramEventListener) {
/*  790 */     setOnresetImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnresetImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnresize() {
/*  795 */     return EventListenerImpl.getImpl(getOnresizeImpl(getPeer()));
/*      */   }
/*      */   static native long getOnresizeImpl(long paramLong);
/*      */   
/*      */   public void setOnresize(EventListener paramEventListener) {
/*  800 */     setOnresizeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnresizeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnscroll() {
/*  805 */     return EventListenerImpl.getImpl(getOnscrollImpl(getPeer()));
/*      */   }
/*      */   static native long getOnscrollImpl(long paramLong);
/*      */   
/*      */   public void setOnscroll(EventListener paramEventListener) {
/*  810 */     setOnscrollImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnscrollImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnseeked() {
/*  815 */     return EventListenerImpl.getImpl(getOnseekedImpl(getPeer()));
/*      */   }
/*      */   static native long getOnseekedImpl(long paramLong);
/*      */   
/*      */   public void setOnseeked(EventListener paramEventListener) {
/*  820 */     setOnseekedImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnseekedImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnseeking() {
/*  825 */     return EventListenerImpl.getImpl(getOnseekingImpl(getPeer()));
/*      */   }
/*      */   static native long getOnseekingImpl(long paramLong);
/*      */   
/*      */   public void setOnseeking(EventListener paramEventListener) {
/*  830 */     setOnseekingImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnseekingImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnselect() {
/*  835 */     return EventListenerImpl.getImpl(getOnselectImpl(getPeer()));
/*      */   }
/*      */   static native long getOnselectImpl(long paramLong);
/*      */   
/*      */   public void setOnselect(EventListener paramEventListener) {
/*  840 */     setOnselectImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnselectImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnstalled() {
/*  845 */     return EventListenerImpl.getImpl(getOnstalledImpl(getPeer()));
/*      */   }
/*      */   static native long getOnstalledImpl(long paramLong);
/*      */   
/*      */   public void setOnstalled(EventListener paramEventListener) {
/*  850 */     setOnstalledImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnstalledImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnsubmit() {
/*  855 */     return EventListenerImpl.getImpl(getOnsubmitImpl(getPeer()));
/*      */   }
/*      */   static native long getOnsubmitImpl(long paramLong);
/*      */   
/*      */   public void setOnsubmit(EventListener paramEventListener) {
/*  860 */     setOnsubmitImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnsubmitImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnsuspend() {
/*  865 */     return EventListenerImpl.getImpl(getOnsuspendImpl(getPeer()));
/*      */   }
/*      */   static native long getOnsuspendImpl(long paramLong);
/*      */   
/*      */   public void setOnsuspend(EventListener paramEventListener) {
/*  870 */     setOnsuspendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnsuspendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOntimeupdate() {
/*  875 */     return EventListenerImpl.getImpl(getOntimeupdateImpl(getPeer()));
/*      */   }
/*      */   static native long getOntimeupdateImpl(long paramLong);
/*      */   
/*      */   public void setOntimeupdate(EventListener paramEventListener) {
/*  880 */     setOntimeupdateImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOntimeupdateImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnvolumechange() {
/*  885 */     return EventListenerImpl.getImpl(getOnvolumechangeImpl(getPeer()));
/*      */   }
/*      */   static native long getOnvolumechangeImpl(long paramLong);
/*      */   
/*      */   public void setOnvolumechange(EventListener paramEventListener) {
/*  890 */     setOnvolumechangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnvolumechangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnwaiting() {
/*  895 */     return EventListenerImpl.getImpl(getOnwaitingImpl(getPeer()));
/*      */   }
/*      */   static native long getOnwaitingImpl(long paramLong);
/*      */   
/*      */   public void setOnwaiting(EventListener paramEventListener) {
/*  900 */     setOnwaitingImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnwaitingImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnsearch() {
/*  905 */     return EventListenerImpl.getImpl(getOnsearchImpl(getPeer()));
/*      */   }
/*      */   static native long getOnsearchImpl(long paramLong);
/*      */   
/*      */   public void setOnsearch(EventListener paramEventListener) {
/*  910 */     setOnsearchImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnsearchImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnwheel() {
/*  915 */     return EventListenerImpl.getImpl(getOnwheelImpl(getPeer()));
/*      */   }
/*      */   static native long getOnwheelImpl(long paramLong);
/*      */   
/*      */   public void setOnwheel(EventListener paramEventListener) {
/*  920 */     setOnwheelImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnwheelImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public Element getPreviousElementSibling() {
/*  925 */     return getImpl(getPreviousElementSiblingImpl(getPeer()));
/*      */   }
/*      */   static native long getPreviousElementSiblingImpl(long paramLong);
/*      */   
/*      */   public Element getNextElementSibling() {
/*  930 */     return getImpl(getNextElementSiblingImpl(getPeer()));
/*      */   }
/*      */   static native long getNextElementSiblingImpl(long paramLong);
/*      */   
/*      */   public HTMLCollection getChildren() {
/*  935 */     return HTMLCollectionImpl.getImpl(getChildrenImpl(getPeer()));
/*      */   }
/*      */   static native long getChildrenImpl(long paramLong);
/*      */   
/*      */   public Element getFirstElementChild() {
/*  940 */     return getImpl(getFirstElementChildImpl(getPeer()));
/*      */   }
/*      */   static native long getFirstElementChildImpl(long paramLong);
/*      */   
/*      */   public Element getLastElementChild() {
/*  945 */     return getImpl(getLastElementChildImpl(getPeer()));
/*      */   }
/*      */   static native long getLastElementChildImpl(long paramLong);
/*      */   
/*      */   public int getChildElementCount() {
/*  950 */     return getChildElementCountImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   static native int getChildElementCountImpl(long paramLong);
/*      */ 
/*      */   
/*      */   public String getAttribute(String paramString) {
/*  958 */     return getAttributeImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native String getAttributeImpl(long paramLong, String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttribute(String paramString1, String paramString2) throws DOMException {
/*  968 */     setAttributeImpl(getPeer(), paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native void setAttributeImpl(long paramLong, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAttribute(String paramString) {
/*  979 */     removeAttributeImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native void removeAttributeImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public Attr getAttributeNode(String paramString) {
/*  988 */     return AttrImpl.getImpl(getAttributeNodeImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getAttributeNodeImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public Attr setAttributeNode(Attr paramAttr) throws DOMException {
/*  997 */     return AttrImpl.getImpl(setAttributeNodeImpl(getPeer(), 
/*  998 */           AttrImpl.getPeer(paramAttr)));
/*      */   }
/*      */ 
/*      */   
/*      */   static native long setAttributeNodeImpl(long paramLong1, long paramLong2);
/*      */ 
/*      */   
/*      */   public Attr removeAttributeNode(Attr paramAttr) throws DOMException {
/* 1006 */     return AttrImpl.getImpl(removeAttributeNodeImpl(getPeer(), 
/* 1007 */           AttrImpl.getPeer(paramAttr)));
/*      */   }
/*      */ 
/*      */   
/*      */   static native long removeAttributeNodeImpl(long paramLong1, long paramLong2);
/*      */ 
/*      */   
/*      */   public NodeList getElementsByTagName(String paramString) {
/* 1015 */     return NodeListImpl.getImpl(getElementsByTagNameImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getElementsByTagNameImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public boolean hasAttributes() {
/* 1024 */     return hasAttributesImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   static native boolean hasAttributesImpl(long paramLong);
/*      */ 
/*      */   
/*      */   public String getAttributeNS(String paramString1, String paramString2) {
/* 1032 */     return getAttributeNSImpl(getPeer(), paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native String getAttributeNSImpl(long paramLong, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributeNS(String paramString1, String paramString2, String paramString3) throws DOMException {
/* 1045 */     setAttributeNSImpl(getPeer(), paramString1, paramString2, paramString3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native void setAttributeNSImpl(long paramLong, String paramString1, String paramString2, String paramString3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAttributeNS(String paramString1, String paramString2) {
/* 1059 */     removeAttributeNSImpl(getPeer(), paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native void removeAttributeNSImpl(long paramLong, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NodeList getElementsByTagNameNS(String paramString1, String paramString2) {
/* 1071 */     return NodeListImpl.getImpl(getElementsByTagNameNSImpl(getPeer(), paramString1, paramString2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getElementsByTagNameNSImpl(long paramLong, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Attr getAttributeNodeNS(String paramString1, String paramString2) {
/* 1083 */     return AttrImpl.getImpl(getAttributeNodeNSImpl(getPeer(), paramString1, paramString2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getAttributeNodeNSImpl(long paramLong, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */   
/*      */   public Attr setAttributeNodeNS(Attr paramAttr) throws DOMException {
/* 1094 */     return AttrImpl.getImpl(setAttributeNodeNSImpl(getPeer(), 
/* 1095 */           AttrImpl.getPeer(paramAttr)));
/*      */   }
/*      */ 
/*      */   
/*      */   static native long setAttributeNodeNSImpl(long paramLong1, long paramLong2);
/*      */ 
/*      */   
/*      */   public boolean hasAttribute(String paramString) {
/* 1103 */     return hasAttributeImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native boolean hasAttributeImpl(long paramLong, String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasAttributeNS(String paramString1, String paramString2) {
/* 1113 */     return hasAttributeNSImpl(getPeer(), paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native boolean hasAttributeNSImpl(long paramLong, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */   
/*      */   public void focus() {
/* 1124 */     focusImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   static native void focusImpl(long paramLong);
/*      */   
/*      */   public void blur() {
/* 1131 */     blurImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   static native void blurImpl(long paramLong);
/*      */   
/*      */   public void scrollIntoView(boolean paramBoolean) {
/* 1138 */     scrollIntoViewImpl(getPeer(), paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native void scrollIntoViewImpl(long paramLong, boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public void scrollIntoViewIfNeeded(boolean paramBoolean) {
/* 1147 */     scrollIntoViewIfNeededImpl(getPeer(), paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native void scrollIntoViewIfNeededImpl(long paramLong, boolean paramBoolean);
/*      */ 
/*      */   
/*      */   public void scrollByLines(int paramInt) {
/* 1156 */     scrollByLinesImpl(getPeer(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native void scrollByLinesImpl(long paramLong, int paramInt);
/*      */ 
/*      */   
/*      */   public void scrollByPages(int paramInt) {
/* 1165 */     scrollByPagesImpl(getPeer(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native void scrollByPagesImpl(long paramLong, int paramInt);
/*      */ 
/*      */   
/*      */   public HTMLCollection getElementsByClassName(String paramString) {
/* 1174 */     return HTMLCollectionImpl.getImpl(getElementsByClassNameImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getElementsByClassNameImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public boolean matches(String paramString) throws DOMException {
/* 1183 */     return matchesImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native boolean matchesImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public Element closest(String paramString) throws DOMException {
/* 1192 */     return getImpl(closestImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long closestImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public boolean webkitMatchesSelector(String paramString) throws DOMException {
/* 1201 */     return webkitMatchesSelectorImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native boolean webkitMatchesSelectorImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public void webkitRequestFullScreen(short paramShort) {
/* 1210 */     webkitRequestFullScreenImpl(getPeer(), paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native void webkitRequestFullScreenImpl(long paramLong, short paramShort);
/*      */ 
/*      */   
/*      */   public void webkitRequestFullscreen() {
/* 1219 */     webkitRequestFullscreenImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   static native void webkitRequestFullscreenImpl(long paramLong);
/*      */   
/*      */   public void remove() throws DOMException {
/* 1226 */     removeImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   static native void removeImpl(long paramLong);
/*      */   
/*      */   public Element querySelector(String paramString) throws DOMException {
/* 1233 */     return getImpl(querySelectorImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long querySelectorImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public NodeList querySelectorAll(String paramString) throws DOMException {
/* 1242 */     return NodeListImpl.getImpl(querySelectorAllImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long querySelectorAllImpl(long paramLong, String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIdAttribute(String paramString, boolean paramBoolean) throws DOMException {
/* 1252 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */   public void setIdAttributeNode(Attr paramAttr, boolean paramBoolean) throws DOMException {
/* 1255 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */   public TypeInfo getSchemaTypeInfo() {
/* 1258 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */   public void setIdAttributeNS(String paramString1, String paramString2, boolean paramBoolean) throws DOMException {
/* 1261 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\ElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */