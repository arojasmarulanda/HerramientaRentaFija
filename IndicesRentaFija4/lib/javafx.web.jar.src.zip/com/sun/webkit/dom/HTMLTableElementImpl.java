/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.html.HTMLCollection;
/*     */ import org.w3c.dom.html.HTMLElement;
/*     */ import org.w3c.dom.html.HTMLTableCaptionElement;
/*     */ import org.w3c.dom.html.HTMLTableElement;
/*     */ import org.w3c.dom.html.HTMLTableSectionElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLTableElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLTableElement
/*     */ {
/*     */   HTMLTableElementImpl(long paramLong) {
/*  37 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLTableElement getImpl(long paramLong) {
/*  41 */     return (HTMLTableElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native long getCaptionImpl(long paramLong);
/*     */   
/*     */   public HTMLTableCaptionElement getCaption() {
/*  47 */     return HTMLTableCaptionElementImpl.getImpl(getCaptionImpl(getPeer()));
/*     */   }
/*     */   static native void setCaptionImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public void setCaption(HTMLTableCaptionElement paramHTMLTableCaptionElement) throws DOMException {
/*  52 */     setCaptionImpl(getPeer(), HTMLTableCaptionElementImpl.getPeer(paramHTMLTableCaptionElement));
/*     */   }
/*     */ 
/*     */   
/*     */   public HTMLTableSectionElement getTHead() {
/*  57 */     return HTMLTableSectionElementImpl.getImpl(getTHeadImpl(getPeer()));
/*     */   }
/*     */   static native long getTHeadImpl(long paramLong);
/*     */   
/*     */   public void setTHead(HTMLTableSectionElement paramHTMLTableSectionElement) throws DOMException {
/*  62 */     setTHeadImpl(getPeer(), HTMLTableSectionElementImpl.getPeer(paramHTMLTableSectionElement));
/*     */   }
/*     */   static native void setTHeadImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public HTMLTableSectionElement getTFoot() {
/*  67 */     return HTMLTableSectionElementImpl.getImpl(getTFootImpl(getPeer()));
/*     */   }
/*     */   static native long getTFootImpl(long paramLong);
/*     */   
/*     */   public void setTFoot(HTMLTableSectionElement paramHTMLTableSectionElement) throws DOMException {
/*  72 */     setTFootImpl(getPeer(), HTMLTableSectionElementImpl.getPeer(paramHTMLTableSectionElement));
/*     */   }
/*     */   static native void setTFootImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public HTMLCollection getRows() {
/*  77 */     return HTMLCollectionImpl.getImpl(getRowsImpl(getPeer()));
/*     */   }
/*     */   static native long getRowsImpl(long paramLong);
/*     */   
/*     */   public HTMLCollection getTBodies() {
/*  82 */     return HTMLCollectionImpl.getImpl(getTBodiesImpl(getPeer()));
/*     */   }
/*     */   static native long getTBodiesImpl(long paramLong);
/*     */   
/*     */   public String getAlign() {
/*  87 */     return getAlignImpl(getPeer());
/*     */   }
/*     */   static native String getAlignImpl(long paramLong);
/*     */   
/*     */   public void setAlign(String paramString) {
/*  92 */     setAlignImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getBgColor() {
/*  97 */     return getBgColorImpl(getPeer());
/*     */   }
/*     */   static native String getBgColorImpl(long paramLong);
/*     */   
/*     */   public void setBgColor(String paramString) {
/* 102 */     setBgColorImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setBgColorImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getBorder() {
/* 107 */     return getBorderImpl(getPeer());
/*     */   }
/*     */   static native String getBorderImpl(long paramLong);
/*     */   
/*     */   public void setBorder(String paramString) {
/* 112 */     setBorderImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setBorderImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCellPadding() {
/* 117 */     return getCellPaddingImpl(getPeer());
/*     */   }
/*     */   static native String getCellPaddingImpl(long paramLong);
/*     */   
/*     */   public void setCellPadding(String paramString) {
/* 122 */     setCellPaddingImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCellPaddingImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCellSpacing() {
/* 127 */     return getCellSpacingImpl(getPeer());
/*     */   }
/*     */   static native String getCellSpacingImpl(long paramLong);
/*     */   
/*     */   public void setCellSpacing(String paramString) {
/* 132 */     setCellSpacingImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCellSpacingImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getFrame() {
/* 137 */     return getFrameImpl(getPeer());
/*     */   }
/*     */   static native String getFrameImpl(long paramLong);
/*     */   
/*     */   public void setFrame(String paramString) {
/* 142 */     setFrameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFrameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getRules() {
/* 147 */     return getRulesImpl(getPeer());
/*     */   }
/*     */   static native String getRulesImpl(long paramLong);
/*     */   
/*     */   public void setRules(String paramString) {
/* 152 */     setRulesImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setRulesImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getSummary() {
/* 157 */     return getSummaryImpl(getPeer());
/*     */   }
/*     */   static native String getSummaryImpl(long paramLong);
/*     */   
/*     */   public void setSummary(String paramString) {
/* 162 */     setSummaryImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSummaryImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getWidth() {
/* 167 */     return getWidthImpl(getPeer());
/*     */   }
/*     */   static native String getWidthImpl(long paramLong);
/*     */   
/*     */   public void setWidth(String paramString) {
/* 172 */     setWidthImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   static native void setWidthImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public HTMLElement createTHead() {
/* 180 */     return HTMLElementImpl.getImpl(createTHeadImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   static native long createTHeadImpl(long paramLong);
/*     */   
/*     */   public void deleteTHead() {
/* 187 */     deleteTHeadImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void deleteTHeadImpl(long paramLong);
/*     */   
/*     */   public HTMLElement createTFoot() {
/* 194 */     return HTMLElementImpl.getImpl(createTFootImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   static native long createTFootImpl(long paramLong);
/*     */   
/*     */   public void deleteTFoot() {
/* 201 */     deleteTFootImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void deleteTFootImpl(long paramLong);
/*     */   
/*     */   public HTMLElement createTBody() {
/* 208 */     return HTMLElementImpl.getImpl(createTBodyImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   static native long createTBodyImpl(long paramLong);
/*     */   
/*     */   public HTMLElement createCaption() {
/* 215 */     return HTMLElementImpl.getImpl(createCaptionImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   static native long createCaptionImpl(long paramLong);
/*     */   
/*     */   public void deleteCaption() {
/* 222 */     deleteCaptionImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void deleteCaptionImpl(long paramLong);
/*     */   
/*     */   public HTMLElement insertRow(int paramInt) throws DOMException {
/* 229 */     return HTMLElementImpl.getImpl(insertRowImpl(getPeer(), paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native long insertRowImpl(long paramLong, int paramInt);
/*     */ 
/*     */   
/*     */   public void deleteRow(int paramInt) throws DOMException {
/* 238 */     deleteRowImpl(getPeer(), paramInt);
/*     */   }
/*     */   
/*     */   static native void deleteRowImpl(long paramLong, int paramInt);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLTableElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */