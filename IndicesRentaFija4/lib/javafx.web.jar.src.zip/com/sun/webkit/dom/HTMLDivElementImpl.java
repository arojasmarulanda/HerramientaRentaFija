/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLDivElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLDivElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLDivElement
/*    */ {
/*    */   HTMLDivElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLDivElement getImpl(long paramLong) {
/* 36 */     return (HTMLDivElement)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getAlign() {
/* 42 */     return getAlignImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAlign(String paramString) {
/* 47 */     setAlignImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native String getAlignImpl(long paramLong);
/*    */   
/*    */   static native void setAlignImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLDivElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */