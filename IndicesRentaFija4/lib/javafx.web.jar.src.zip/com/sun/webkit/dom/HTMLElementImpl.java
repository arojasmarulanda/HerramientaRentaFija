/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.html.HTMLCollection;
/*     */ import org.w3c.dom.html.HTMLElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLElementImpl
/*     */   extends ElementImpl
/*     */   implements HTMLElement
/*     */ {
/*     */   HTMLElementImpl(long paramLong) {
/*  35 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLElement getImpl(long paramLong) {
/*  39 */     return (HTMLElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getIdImpl(long paramLong);
/*     */   
/*     */   public String getId() {
/*  45 */     return getIdImpl(getPeer());
/*     */   }
/*     */   static native void setIdImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setId(String paramString) {
/*  50 */     setIdImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTitle() {
/*  55 */     return getTitleImpl(getPeer());
/*     */   }
/*     */   static native String getTitleImpl(long paramLong);
/*     */   
/*     */   public void setTitle(String paramString) {
/*  60 */     setTitleImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTitleImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getLang() {
/*  65 */     return getLangImpl(getPeer());
/*     */   }
/*     */   static native String getLangImpl(long paramLong);
/*     */   
/*     */   public void setLang(String paramString) {
/*  70 */     setLangImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setLangImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getTranslate() {
/*  75 */     return getTranslateImpl(getPeer());
/*     */   }
/*     */   static native boolean getTranslateImpl(long paramLong);
/*     */   
/*     */   public void setTranslate(boolean paramBoolean) {
/*  80 */     setTranslateImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setTranslateImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getDir() {
/*  85 */     return getDirImpl(getPeer());
/*     */   }
/*     */   static native String getDirImpl(long paramLong);
/*     */   
/*     */   public void setDir(String paramString) {
/*  90 */     setDirImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setDirImpl(long paramLong, String paramString);
/*     */   
/*     */   public int getTabIndex() {
/*  95 */     return getTabIndexImpl(getPeer());
/*     */   }
/*     */   static native int getTabIndexImpl(long paramLong);
/*     */   
/*     */   public void setTabIndex(int paramInt) {
/* 100 */     setTabIndexImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setTabIndexImpl(long paramLong, int paramInt);
/*     */   
/*     */   public boolean getDraggable() {
/* 105 */     return getDraggableImpl(getPeer());
/*     */   }
/*     */   static native boolean getDraggableImpl(long paramLong);
/*     */   
/*     */   public void setDraggable(boolean paramBoolean) {
/* 110 */     setDraggableImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setDraggableImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getWebkitdropzone() {
/* 115 */     return getWebkitdropzoneImpl(getPeer());
/*     */   }
/*     */   static native String getWebkitdropzoneImpl(long paramLong);
/*     */   
/*     */   public void setWebkitdropzone(String paramString) {
/* 120 */     setWebkitdropzoneImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setWebkitdropzoneImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getHidden() {
/* 125 */     return getHiddenImpl(getPeer());
/*     */   }
/*     */   static native boolean getHiddenImpl(long paramLong);
/*     */   
/*     */   public void setHidden(boolean paramBoolean) {
/* 130 */     setHiddenImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setHiddenImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getAccessKey() {
/* 135 */     return getAccessKeyImpl(getPeer());
/*     */   }
/*     */   static native String getAccessKeyImpl(long paramLong);
/*     */   
/*     */   public void setAccessKey(String paramString) {
/* 140 */     setAccessKeyImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAccessKeyImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getInnerText() {
/* 145 */     return getInnerTextImpl(getPeer());
/*     */   }
/*     */   static native String getInnerTextImpl(long paramLong);
/*     */   
/*     */   public void setInnerText(String paramString) throws DOMException {
/* 150 */     setInnerTextImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setInnerTextImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getOuterText() {
/* 155 */     return getOuterTextImpl(getPeer());
/*     */   }
/*     */   static native String getOuterTextImpl(long paramLong);
/*     */   
/*     */   public void setOuterText(String paramString) throws DOMException {
/* 160 */     setOuterTextImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setOuterTextImpl(long paramLong, String paramString);
/*     */   
/*     */   public HTMLCollection getChildren() {
/* 165 */     return HTMLCollectionImpl.getImpl(getChildrenImpl(getPeer()));
/*     */   }
/*     */   static native long getChildrenImpl(long paramLong);
/*     */   
/*     */   public String getContentEditable() {
/* 170 */     return getContentEditableImpl(getPeer());
/*     */   }
/*     */   static native String getContentEditableImpl(long paramLong);
/*     */   
/*     */   public void setContentEditable(String paramString) throws DOMException {
/* 175 */     setContentEditableImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setContentEditableImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getIsContentEditable() {
/* 180 */     return getIsContentEditableImpl(getPeer());
/*     */   }
/*     */   static native boolean getIsContentEditableImpl(long paramLong);
/*     */   
/*     */   public boolean getSpellcheck() {
/* 185 */     return getSpellcheckImpl(getPeer());
/*     */   }
/*     */   static native boolean getSpellcheckImpl(long paramLong);
/*     */   
/*     */   public void setSpellcheck(boolean paramBoolean) {
/* 190 */     setSpellcheckImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setSpellcheckImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getTitleDisplayString() {
/* 195 */     return getTitleDisplayStringImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native String getTitleDisplayStringImpl(long paramLong);
/*     */ 
/*     */   
/*     */   public Element insertAdjacentElement(String paramString, Element paramElement) throws DOMException {
/* 204 */     return ElementImpl.getImpl(insertAdjacentElementImpl(getPeer(), paramString, 
/*     */           
/* 206 */           ElementImpl.getPeer(paramElement)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native long insertAdjacentElementImpl(long paramLong1, String paramString, long paramLong2);
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertAdjacentHTML(String paramString1, String paramString2) throws DOMException {
/* 216 */     insertAdjacentHTMLImpl(getPeer(), paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void insertAdjacentHTMLImpl(long paramLong, String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertAdjacentText(String paramString1, String paramString2) throws DOMException {
/* 228 */     insertAdjacentTextImpl(getPeer(), paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void insertAdjacentTextImpl(long paramLong, String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */   
/*     */   public void click() {
/* 239 */     clickImpl(getPeer());
/*     */   }
/*     */   
/*     */   static native void clickImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */