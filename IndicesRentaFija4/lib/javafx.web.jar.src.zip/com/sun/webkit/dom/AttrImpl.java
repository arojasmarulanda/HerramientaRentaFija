/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.Attr;
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.TypeInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttrImpl
/*    */   extends NodeImpl
/*    */   implements Attr
/*    */ {
/*    */   AttrImpl(long paramLong) {
/* 35 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static Attr getImpl(long paramLong) {
/* 39 */     return (Attr)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getNameImpl(long paramLong);
/*    */   
/*    */   public String getName() {
/* 45 */     return getNameImpl(getPeer());
/*    */   }
/*    */   static native boolean getSpecifiedImpl(long paramLong);
/*    */   
/*    */   public boolean getSpecified() {
/* 50 */     return getSpecifiedImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 55 */     return getValueImpl(getPeer());
/*    */   }
/*    */   static native String getValueImpl(long paramLong);
/*    */   
/*    */   public void setValue(String paramString) throws DOMException {
/* 60 */     setValueImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setValueImpl(long paramLong, String paramString);
/*    */   
/*    */   public Element getOwnerElement() {
/* 65 */     return ElementImpl.getImpl(getOwnerElementImpl(getPeer()));
/*    */   }
/*    */   static native long getOwnerElementImpl(long paramLong);
/*    */   
/*    */   public boolean isId() {
/* 70 */     return isIdImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   static native boolean isIdImpl(long paramLong);
/*    */   
/*    */   public TypeInfo getSchemaTypeInfo() {
/* 77 */     throw new UnsupportedOperationException("Not supported yet.");
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\AttrImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */