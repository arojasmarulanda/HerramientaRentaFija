/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.css.CSSFontFaceRule;
/*    */ import org.w3c.dom.css.CSSStyleDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSSFontFaceRuleImpl
/*    */   extends CSSRuleImpl
/*    */   implements CSSFontFaceRule
/*    */ {
/*    */   CSSFontFaceRuleImpl(long paramLong) {
/* 33 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static CSSFontFaceRule getImpl(long paramLong) {
/* 37 */     return (CSSFontFaceRule)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CSSStyleDeclaration getStyle() {
/* 43 */     return CSSStyleDeclarationImpl.getImpl(getStyleImpl(getPeer()));
/*    */   }
/*    */   
/*    */   static native long getStyleImpl(long paramLong);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSFontFaceRuleImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */