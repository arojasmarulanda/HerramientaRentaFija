/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLPreElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLPreElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLPreElement
/*    */ {
/*    */   HTMLPreElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLPreElement getImpl(long paramLong) {
/* 36 */     return (HTMLPreElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native int getWidthImpl(long paramLong);
/*    */   
/*    */   public int getWidth() {
/* 42 */     return getWidthImpl(getPeer());
/*    */   }
/*    */   static native void setWidthImpl(long paramLong, int paramInt);
/*    */   
/*    */   public void setWidth(int paramInt) {
/* 47 */     setWidthImpl(getPeer(), paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getWrap() {
/* 52 */     return getWrapImpl(getPeer());
/*    */   }
/*    */   static native boolean getWrapImpl(long paramLong);
/*    */   
/*    */   public void setWrap(boolean paramBoolean) {
/* 57 */     setWrapImpl(getPeer(), paramBoolean);
/*    */   }
/*    */   
/*    */   static native void setWrapImpl(long paramLong, boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLPreElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */