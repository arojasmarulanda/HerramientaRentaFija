/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.Entity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityImpl
/*    */   extends NodeImpl
/*    */   implements Entity
/*    */ {
/*    */   EntityImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static Entity getImpl(long paramLong) {
/* 36 */     return (Entity)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getPublicIdImpl(long paramLong);
/*    */   
/*    */   public String getPublicId() {
/* 42 */     return getPublicIdImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSystemId() {
/* 47 */     return getSystemIdImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getNotationName() {
/* 52 */     return getNotationNameImpl(getPeer());
/*    */   }
/*    */   static native String getSystemIdImpl(long paramLong);
/*    */   
/*    */   static native String getNotationNameImpl(long paramLong);
/*    */   
/*    */   public String getInputEncoding() {
/* 59 */     throw new UnsupportedOperationException("Not supported yet.");
/*    */   }
/*    */   public String getXmlVersion() {
/* 62 */     throw new UnsupportedOperationException("Not supported yet.");
/*    */   }
/*    */   public String getXmlEncoding() {
/* 65 */     throw new UnsupportedOperationException("Not supported yet.");
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\EntityImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */