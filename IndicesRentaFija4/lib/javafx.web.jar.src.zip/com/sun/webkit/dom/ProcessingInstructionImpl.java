/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.ProcessingInstruction;
/*    */ import org.w3c.dom.stylesheets.StyleSheet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProcessingInstructionImpl
/*    */   extends CharacterDataImpl
/*    */   implements ProcessingInstruction
/*    */ {
/*    */   ProcessingInstructionImpl(long paramLong) {
/* 34 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static Node getImpl(long paramLong) {
/* 38 */     return create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getTarget() {
/* 44 */     return getTargetImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public StyleSheet getSheet() {
/* 49 */     return StyleSheetImpl.getImpl(getSheetImpl(getPeer()));
/*    */   }
/*    */   
/*    */   static native String getTargetImpl(long paramLong);
/*    */   
/*    */   static native long getSheetImpl(long paramLong);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\ProcessingInstructionImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */