/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLParagraphElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLParagraphElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLParagraphElement
/*    */ {
/*    */   HTMLParagraphElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLParagraphElement getImpl(long paramLong) {
/* 36 */     return (HTMLParagraphElement)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getAlign() {
/* 42 */     return getAlignImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAlign(String paramString) {
/* 47 */     setAlignImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native String getAlignImpl(long paramLong);
/*    */   
/*    */   static native void setAlignImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLParagraphElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */