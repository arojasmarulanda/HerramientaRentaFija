/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLLIElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLLIElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLLIElement
/*    */ {
/*    */   HTMLLIElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLLIElement getImpl(long paramLong) {
/* 36 */     return (HTMLLIElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getTypeImpl(long paramLong);
/*    */   
/*    */   public String getType() {
/* 42 */     return getTypeImpl(getPeer());
/*    */   }
/*    */   static native void setTypeImpl(long paramLong, String paramString);
/*    */   
/*    */   public void setType(String paramString) {
/* 47 */     setTypeImpl(getPeer(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getValue() {
/* 52 */     return getValueImpl(getPeer());
/*    */   }
/*    */   static native int getValueImpl(long paramLong);
/*    */   
/*    */   public void setValue(int paramInt) {
/* 57 */     setValueImpl(getPeer(), paramInt);
/*    */   }
/*    */   
/*    */   static native void setValueImpl(long paramLong, int paramInt);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLLIElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */