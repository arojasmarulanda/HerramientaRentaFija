/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import netscape.javascript.JSException;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.UserDataHandler;
/*     */ import org.w3c.dom.events.Event;
/*     */ import org.w3c.dom.events.EventListener;
/*     */ import org.w3c.dom.events.EventTarget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeImpl
/*     */   extends JSObject
/*     */   implements Node, EventTarget
/*     */ {
/*  47 */   private static SelfDisposer[] hashTable = new SelfDisposer[64]; private static int hashCount; public static final int ELEMENT_NODE = 1; public static final int ATTRIBUTE_NODE = 2; public static final int TEXT_NODE = 3; public static final int CDATA_SECTION_NODE = 4; public static final int ENTITY_REFERENCE_NODE = 5; public static final int ENTITY_NODE = 6; public static final int PROCESSING_INSTRUCTION_NODE = 7;
/*     */   public static final int COMMENT_NODE = 8;
/*     */   
/*     */   private static int hashPeer(long paramLong) {
/*  51 */     return (int)(paramLong ^ 0xFFFFFFFFFFFFFFFFL ^ paramLong >> 7L) & hashTable.length - 1;
/*     */   }
/*     */   public static final int DOCUMENT_NODE = 9; public static final int DOCUMENT_TYPE_NODE = 10; public static final int DOCUMENT_FRAGMENT_NODE = 11; public static final int NOTATION_NODE = 12; public static final int DOCUMENT_POSITION_DISCONNECTED = 1; public static final int DOCUMENT_POSITION_PRECEDING = 2; public static final int DOCUMENT_POSITION_FOLLOWING = 4; public static final int DOCUMENT_POSITION_CONTAINS = 8; public static final int DOCUMENT_POSITION_CONTAINED_BY = 16; public static final int DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC = 32;
/*     */   private static Node getCachedImpl(long paramLong) {
/*  55 */     if (paramLong == 0L)
/*  56 */       return null; 
/*  57 */     int i = hashPeer(paramLong);
/*  58 */     SelfDisposer selfDisposer1 = hashTable[i];
/*  59 */     SelfDisposer selfDisposer2 = null;
/*  60 */     for (SelfDisposer selfDisposer3 = selfDisposer1; selfDisposer3 != null; ) {
/*  61 */       SelfDisposer selfDisposer = selfDisposer3.next;
/*  62 */       if (selfDisposer3.peer == paramLong) {
/*  63 */         NodeImpl nodeImpl1 = (NodeImpl)selfDisposer3.get();
/*  64 */         if (nodeImpl1 != null) {
/*     */           
/*  66 */           dispose(paramLong);
/*  67 */           return nodeImpl1;
/*     */         } 
/*  69 */         if (selfDisposer2 != null) {
/*  70 */           selfDisposer2.next = selfDisposer; break;
/*     */         } 
/*  72 */         hashTable[i] = selfDisposer;
/*     */         break;
/*     */       } 
/*  75 */       selfDisposer2 = selfDisposer3;
/*  76 */       selfDisposer3 = selfDisposer;
/*     */     } 
/*  78 */     NodeImpl nodeImpl = (NodeImpl)createInterface(paramLong);
/*  79 */     SelfDisposer selfDisposer4 = new SelfDisposer(nodeImpl, paramLong);
/*  80 */     Disposer.addRecord(selfDisposer4);
/*  81 */     selfDisposer4.next = selfDisposer1;
/*  82 */     hashTable[i] = selfDisposer4;
/*  83 */     if (3 * hashCount >= 2 * hashTable.length)
/*  84 */       rehash(); 
/*  85 */     hashCount++;
/*  86 */     return nodeImpl;
/*     */   }
/*     */   
/*     */   static int test_getHashCount() {
/*  90 */     return hashCount;
/*     */   }
/*     */   
/*     */   private static void rehash() {
/*  94 */     SelfDisposer[] arrayOfSelfDisposer1 = hashTable;
/*  95 */     int i = arrayOfSelfDisposer1.length;
/*  96 */     SelfDisposer[] arrayOfSelfDisposer2 = new SelfDisposer[2 * i];
/*  97 */     hashTable = arrayOfSelfDisposer2;
/*  98 */     for (int j = i; --j >= 0; ) {
/*  99 */       SelfDisposer selfDisposer = arrayOfSelfDisposer1[j];
/* 100 */       while (selfDisposer != null) {
/* 101 */         SelfDisposer selfDisposer1 = selfDisposer.next;
/* 102 */         int k = hashPeer(selfDisposer.peer);
/* 103 */         selfDisposer.next = arrayOfSelfDisposer2[k];
/* 104 */         arrayOfSelfDisposer2[k] = selfDisposer;
/* 105 */         selfDisposer = selfDisposer1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static final class SelfDisposer extends Disposer.WeakDisposerRecord { private final long peer;
/*     */     SelfDisposer next;
/*     */     
/*     */     SelfDisposer(Object param1Object, long param1Long) {
/* 114 */       super(param1Object);
/* 115 */       this.peer = param1Long;
/*     */     }
/*     */     
/*     */     public void dispose() {
/* 119 */       int i = NodeImpl.hashPeer(this.peer);
/* 120 */       SelfDisposer selfDisposer1 = NodeImpl.hashTable[i];
/* 121 */       SelfDisposer selfDisposer2 = null;
/* 122 */       for (SelfDisposer selfDisposer3 = selfDisposer1; selfDisposer3 != null; ) {
/* 123 */         SelfDisposer selfDisposer = selfDisposer3.next;
/* 124 */         if (selfDisposer3.peer == this.peer) {
/* 125 */           selfDisposer3.clear();
/* 126 */           if (selfDisposer2 != null) {
/* 127 */             selfDisposer2.next = selfDisposer;
/*     */           } else {
/* 129 */             NodeImpl.hashTable[i] = selfDisposer;
/*     */           }  NodeImpl.hashCount--;
/*     */           break;
/*     */         } 
/* 133 */         selfDisposer2 = selfDisposer3;
/* 134 */         selfDisposer3 = selfDisposer;
/*     */       } 
/* 136 */       NodeImpl.dispose(this.peer);
/*     */     } }
/*     */ 
/*     */   
/*     */   NodeImpl(long paramLong) {
/* 141 */     super(paramLong, 1);
/*     */   }
/*     */   static Node createInterface(long paramLong) {
/*     */     String str;
/* 145 */     if (paramLong == 0L) return null; 
/* 146 */     switch (getNodeTypeImpl(paramLong)) {
/*     */       case 1:
/* 148 */         if (!ElementImpl.isHTMLElementImpl(paramLong)) {
/* 149 */           return new ElementImpl(paramLong);
/*     */         }
/* 151 */         str = ElementImpl.getTagNameImpl(paramLong).toUpperCase();
/* 152 */         if ("A".equals(str)) return new HTMLAnchorElementImpl(paramLong); 
/* 153 */         if ("APPLET".equals(str)) return new HTMLAppletElementImpl(paramLong); 
/* 154 */         if ("AREA".equals(str)) return new HTMLAreaElementImpl(paramLong); 
/* 155 */         if ("BASE".equals(str)) return new HTMLBaseElementImpl(paramLong); 
/* 156 */         if ("BASEFONT".equals(str)) return new HTMLBaseFontElementImpl(paramLong); 
/* 157 */         if ("BODY".equals(str)) return new HTMLBodyElementImpl(paramLong); 
/* 158 */         if ("BR".equals(str)) return new HTMLBRElementImpl(paramLong); 
/* 159 */         if ("BUTTON".equals(str)) return new HTMLButtonElementImpl(paramLong); 
/* 160 */         if ("DIR".equals(str)) return new HTMLDirectoryElementImpl(paramLong); 
/* 161 */         if ("DIV".equals(str)) return new HTMLDivElementImpl(paramLong); 
/* 162 */         if ("DL".equals(str)) return new HTMLDListElementImpl(paramLong); 
/* 163 */         if ("FIELDSET".equals(str)) return new HTMLFieldSetElementImpl(paramLong); 
/* 164 */         if ("FONT".equals(str)) return new HTMLFontElementImpl(paramLong); 
/* 165 */         if ("FORM".equals(str)) return new HTMLFormElementImpl(paramLong); 
/* 166 */         if ("FRAME".equals(str)) return new HTMLFrameElementImpl(paramLong); 
/* 167 */         if ("FRAMESET".equals(str)) return new HTMLFrameSetElementImpl(paramLong); 
/* 168 */         if ("HEAD".equals(str)) return new HTMLHeadElementImpl(paramLong); 
/* 169 */         if (str.length() == 2 && str.charAt(0) == 'H' && str.charAt(1) >= '1' && str.charAt(1) <= '6') return new HTMLHeadingElementImpl(paramLong); 
/* 170 */         if ("HR".equals(str)) return new HTMLHRElementImpl(paramLong); 
/* 171 */         if ("IFRAME".equals(str)) return new HTMLIFrameElementImpl(paramLong); 
/* 172 */         if ("IMG".equals(str)) return new HTMLImageElementImpl(paramLong); 
/* 173 */         if ("INPUT".equals(str)) return new HTMLInputElementImpl(paramLong); 
/* 174 */         if ("LABEL".equals(str)) return new HTMLLabelElementImpl(paramLong); 
/* 175 */         if ("LEGEND".equals(str)) return new HTMLLegendElementImpl(paramLong); 
/* 176 */         if ("LI".equals(str)) return new HTMLLIElementImpl(paramLong); 
/* 177 */         if ("LINK".equals(str)) return new HTMLLinkElementImpl(paramLong); 
/* 178 */         if ("MAP".equals(str)) return new HTMLMapElementImpl(paramLong); 
/* 179 */         if ("MENU".equals(str)) return new HTMLMenuElementImpl(paramLong); 
/* 180 */         if ("META".equals(str)) return new HTMLMetaElementImpl(paramLong); 
/* 181 */         if ("INS".equals(str) || "DEL".equals(str)) return new HTMLModElementImpl(paramLong); 
/* 182 */         if ("OBJECT".equals(str)) return new HTMLObjectElementImpl(paramLong); 
/* 183 */         if ("OL".equals(str)) return new HTMLOListElementImpl(paramLong); 
/* 184 */         if ("OPTGROUP".equals(str)) return new HTMLOptGroupElementImpl(paramLong); 
/* 185 */         if ("OPTION".equals(str)) return new HTMLOptionElementImpl(paramLong); 
/* 186 */         if ("P".equals(str)) return new HTMLParagraphElementImpl(paramLong); 
/* 187 */         if ("PARAM".equals(str)) return new HTMLParamElementImpl(paramLong); 
/* 188 */         if ("PRE".equals(str)) return new HTMLPreElementImpl(paramLong); 
/* 189 */         if ("Q".equals(str)) return new HTMLQuoteElementImpl(paramLong); 
/* 190 */         if ("SCRIPT".equals(str)) return new HTMLScriptElementImpl(paramLong); 
/* 191 */         if ("SELECT".equals(str)) return new HTMLSelectElementImpl(paramLong); 
/* 192 */         if ("STYLE".equals(str)) return new HTMLStyleElementImpl(paramLong); 
/* 193 */         if ("CAPTION".equals(str)) return new HTMLTableCaptionElementImpl(paramLong); 
/* 194 */         if ("TD".equals(str)) return new HTMLTableCellElementImpl(paramLong); 
/* 195 */         if ("COL".equals(str)) return new HTMLTableColElementImpl(paramLong); 
/* 196 */         if ("TABLE".equals(str)) return new HTMLTableElementImpl(paramLong); 
/* 197 */         if ("TR".equals(str)) return new HTMLTableRowElementImpl(paramLong); 
/* 198 */         if ("THEAD".equals(str) || "TFOOT".equals(str) || "TBODY".equals(str)) return new HTMLTableSectionElementImpl(paramLong); 
/* 199 */         if ("TEXTAREA".equals(str)) return new HTMLTextAreaElementImpl(paramLong); 
/* 200 */         if ("TITLE".equals(str)) return new HTMLTitleElementImpl(paramLong); 
/* 201 */         if ("UL".equals(str)) return new HTMLUListElementImpl(paramLong);
/*     */         
/* 203 */         return new HTMLElementImpl(paramLong);
/* 204 */       case 2: return new AttrImpl(paramLong);
/* 205 */       case 3: return new TextImpl(paramLong);
/* 206 */       case 4: return new CDATASectionImpl(paramLong);
/* 207 */       case 5: return new EntityReferenceImpl(paramLong);
/* 208 */       case 6: return new EntityImpl(paramLong);
/* 209 */       case 7: return new ProcessingInstructionImpl(paramLong);
/* 210 */       case 8: return new CommentImpl(paramLong);
/*     */       case 9:
/* 212 */         if (DocumentImpl.isHTMLDocumentImpl(paramLong))
/* 213 */           return new HTMLDocumentImpl(paramLong); 
/* 214 */         return new DocumentImpl(paramLong);
/* 215 */       case 10: return new DocumentTypeImpl(paramLong);
/* 216 */       case 11: return new DocumentFragmentImpl(paramLong);
/*     */     } 
/* 218 */     return new NodeImpl(paramLong);
/*     */   }
/*     */   
/*     */   static Node create(long paramLong) {
/* 222 */     return getCachedImpl(paramLong);
/*     */   }
/*     */   
/*     */   static long getPeer(Node paramNode) {
/* 226 */     return (paramNode == null) ? 0L : ((NodeImpl)paramNode).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Node getImpl(long paramLong) {
/* 232 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNodeName() {
/* 258 */     return getNodeNameImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNodeValue() {
/* 263 */     return getNodeValueImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNodeValue(String paramString) throws DOMException {
/* 268 */     setNodeValueImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getNodeType() {
/* 273 */     return getNodeTypeImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getParentNode() {
/* 278 */     return getImpl(getParentNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeList getChildNodes() {
/* 283 */     return NodeListImpl.getImpl(getChildNodesImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getFirstChild() {
/* 288 */     return getImpl(getFirstChildImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getLastChild() {
/* 293 */     return getImpl(getLastChildImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getPreviousSibling() {
/* 298 */     return getImpl(getPreviousSiblingImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getNextSibling() {
/* 303 */     return getImpl(getNextSiblingImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Document getOwnerDocument() {
/* 308 */     return DocumentImpl.getImpl(getOwnerDocumentImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespaceURI() {
/* 313 */     return getNamespaceURIImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/* 318 */     return getPrefixImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPrefix(String paramString) throws DOMException {
/* 323 */     setPrefixImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocalName() {
/* 328 */     return getLocalNameImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public NamedNodeMap getAttributes() {
/* 333 */     return NamedNodeMapImpl.getImpl(getAttributesImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBaseURI() {
/* 338 */     return getBaseURIImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTextContent() {
/* 343 */     return getTextContentImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTextContent(String paramString) throws DOMException {
/* 348 */     setTextContentImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public Element getParentElement() {
/* 353 */     return ElementImpl.getImpl(getParentElementImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException {
/* 362 */     return getImpl(insertBeforeImpl(getPeer(), 
/* 363 */           getPeer(paramNode1), 
/* 364 */           getPeer(paramNode2)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException {
/* 374 */     return getImpl(replaceChildImpl(getPeer(), 
/* 375 */           getPeer(paramNode1), 
/* 376 */           getPeer(paramNode2)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node removeChild(Node paramNode) throws DOMException {
/* 385 */     return getImpl(removeChildImpl(getPeer(), 
/* 386 */           getPeer(paramNode)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node appendChild(Node paramNode) throws DOMException {
/* 394 */     return getImpl(appendChildImpl(getPeer(), 
/* 395 */           getPeer(paramNode)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasChildNodes() {
/* 403 */     return hasChildNodesImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node cloneNode(boolean paramBoolean) throws DOMException {
/* 410 */     return getImpl(cloneNodeImpl(getPeer(), paramBoolean));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void normalize() {
/* 419 */     normalizeImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSupported(String paramString1, String paramString2) {
/* 427 */     return isSupportedImpl(getPeer(), paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAttributes() {
/* 438 */     return hasAttributesImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSameNode(Node paramNode) {
/* 445 */     return isSameNodeImpl(getPeer(), 
/* 446 */         getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEqualNode(Node paramNode) {
/* 454 */     return isEqualNodeImpl(getPeer(), 
/* 455 */         getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String lookupPrefix(String paramString) {
/* 463 */     return lookupPrefixImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultNamespace(String paramString) {
/* 472 */     return isDefaultNamespaceImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String lookupNamespaceURI(String paramString) {
/* 481 */     return lookupNamespaceURIImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short compareDocumentPosition(Node paramNode) {
/* 490 */     return compareDocumentPositionImpl(getPeer(), 
/* 491 */         getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Node paramNode) {
/* 499 */     return containsImpl(getPeer(), 
/* 500 */         getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEventListener(String paramString, EventListener paramEventListener, boolean paramBoolean) {
/* 510 */     addEventListenerImpl(getPeer(), paramString, 
/*     */         
/* 512 */         EventListenerImpl.getPeer(paramEventListener), paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeEventListener(String paramString, EventListener paramEventListener, boolean paramBoolean) {
/* 525 */     removeEventListenerImpl(getPeer(), paramString, 
/*     */         
/* 527 */         EventListenerImpl.getPeer(paramEventListener), paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dispatchEvent(Event paramEvent) throws DOMException {
/* 538 */     return dispatchEventImpl(getPeer(), 
/* 539 */         EventImpl.getPeer(paramEvent));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getUserData(String paramString) {
/* 548 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   public Object setUserData(String paramString, Object paramObject, UserDataHandler paramUserDataHandler) {
/* 551 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   public Object getFeature(String paramString1, String paramString2) {
/* 554 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native String getNodeNameImpl(long paramLong);
/*     */   
/*     */   static native String getNodeValueImpl(long paramLong);
/*     */   
/*     */   static native void setNodeValueImpl(long paramLong, String paramString);
/*     */   
/*     */   static native short getNodeTypeImpl(long paramLong);
/*     */   
/*     */   static native long getParentNodeImpl(long paramLong);
/*     */   
/*     */   static native long getChildNodesImpl(long paramLong);
/*     */   
/*     */   static native long getFirstChildImpl(long paramLong);
/*     */   
/*     */   static native long getLastChildImpl(long paramLong);
/*     */   
/*     */   static native long getPreviousSiblingImpl(long paramLong);
/*     */   
/*     */   static native long getNextSiblingImpl(long paramLong);
/*     */   
/*     */   static native long getOwnerDocumentImpl(long paramLong);
/*     */   
/*     */   static native String getNamespaceURIImpl(long paramLong);
/*     */   
/*     */   static native String getPrefixImpl(long paramLong);
/*     */   
/*     */   static native void setPrefixImpl(long paramLong, String paramString);
/*     */   
/*     */   static native String getLocalNameImpl(long paramLong);
/*     */   
/*     */   static native long getAttributesImpl(long paramLong);
/*     */   
/*     */   static native String getBaseURIImpl(long paramLong);
/*     */   
/*     */   static native String getTextContentImpl(long paramLong);
/*     */   
/*     */   static native void setTextContentImpl(long paramLong, String paramString);
/*     */   
/*     */   static native long getParentElementImpl(long paramLong);
/*     */   
/*     */   static native long insertBeforeImpl(long paramLong1, long paramLong2, long paramLong3);
/*     */   
/*     */   static native long replaceChildImpl(long paramLong1, long paramLong2, long paramLong3);
/*     */   
/*     */   static native long removeChildImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native long appendChildImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native boolean hasChildNodesImpl(long paramLong);
/*     */   
/*     */   static native long cloneNodeImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   static native void normalizeImpl(long paramLong);
/*     */   
/*     */   static native boolean isSupportedImpl(long paramLong, String paramString1, String paramString2);
/*     */   
/*     */   static native boolean hasAttributesImpl(long paramLong);
/*     */   
/*     */   static native boolean isSameNodeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native boolean isEqualNodeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native String lookupPrefixImpl(long paramLong, String paramString);
/*     */   
/*     */   static native boolean isDefaultNamespaceImpl(long paramLong, String paramString);
/*     */   
/*     */   static native String lookupNamespaceURIImpl(long paramLong, String paramString);
/*     */   
/*     */   static native short compareDocumentPositionImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native boolean containsImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native void addEventListenerImpl(long paramLong1, String paramString, long paramLong2, boolean paramBoolean);
/*     */   
/*     */   static native void removeEventListenerImpl(long paramLong1, String paramString, long paramLong2, boolean paramBoolean);
/*     */   
/*     */   static native boolean dispatchEventImpl(long paramLong1, long paramLong2);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\NodeImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */