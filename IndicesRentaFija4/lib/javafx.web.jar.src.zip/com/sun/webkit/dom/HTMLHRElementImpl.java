/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLHRElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLHRElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLHRElement
/*    */ {
/*    */   HTMLHRElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLHRElement getImpl(long paramLong) {
/* 36 */     return (HTMLHRElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getAlignImpl(long paramLong);
/*    */   
/*    */   public String getAlign() {
/* 42 */     return getAlignImpl(getPeer());
/*    */   }
/*    */   static native void setAlignImpl(long paramLong, String paramString);
/*    */   
/*    */   public void setAlign(String paramString) {
/* 47 */     setAlignImpl(getPeer(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getNoShade() {
/* 52 */     return getNoShadeImpl(getPeer());
/*    */   }
/*    */   static native boolean getNoShadeImpl(long paramLong);
/*    */   
/*    */   public void setNoShade(boolean paramBoolean) {
/* 57 */     setNoShadeImpl(getPeer(), paramBoolean);
/*    */   }
/*    */   static native void setNoShadeImpl(long paramLong, boolean paramBoolean);
/*    */   
/*    */   public String getSize() {
/* 62 */     return getSizeImpl(getPeer());
/*    */   }
/*    */   static native String getSizeImpl(long paramLong);
/*    */   
/*    */   public void setSize(String paramString) {
/* 67 */     setSizeImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setSizeImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getWidth() {
/* 72 */     return getWidthImpl(getPeer());
/*    */   }
/*    */   static native String getWidthImpl(long paramLong);
/*    */   
/*    */   public void setWidth(String paramString) {
/* 77 */     setWidthImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setWidthImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLHRElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */