/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import com.sun.webkit.Disposer;
/*    */ import com.sun.webkit.DisposerRecord;
/*    */ import org.w3c.dom.DOMStringList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DOMStringListImpl
/*    */   implements DOMStringList
/*    */ {
/*    */   private final long peer;
/*    */   
/*    */   private static class SelfDisposer
/*    */     implements DisposerRecord
/*    */   {
/*    */     private final long peer;
/*    */     
/*    */     SelfDisposer(long param1Long) {
/* 36 */       this.peer = param1Long;
/*    */     }
/*    */     public void dispose() {
/* 39 */       DOMStringListImpl.dispose(this.peer);
/*    */     }
/*    */   }
/*    */   
/*    */   DOMStringListImpl(long paramLong) {
/* 44 */     this.peer = paramLong;
/* 45 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*    */   }
/*    */   
/*    */   static DOMStringList create(long paramLong) {
/* 49 */     if (paramLong == 0L) return null; 
/* 50 */     return new DOMStringListImpl(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   long getPeer() {
/* 56 */     return this.peer;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 60 */     return (paramObject instanceof DOMStringListImpl && this.peer == ((DOMStringListImpl)paramObject).peer);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 64 */     long l = this.peer;
/* 65 */     return (int)(l ^ l >> 17L);
/*    */   }
/*    */   
/*    */   static long getPeer(DOMStringList paramDOMStringList) {
/* 69 */     return (paramDOMStringList == null) ? 0L : ((DOMStringListImpl)paramDOMStringList).getPeer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static DOMStringList getImpl(long paramLong) {
/* 75 */     return create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 81 */     return getLengthImpl(getPeer());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String item(int paramInt) {
/* 89 */     return itemImpl(getPeer(), paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean contains(String paramString) {
/* 98 */     return containsImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   private static native void dispose(long paramLong);
/*    */   
/*    */   static native int getLengthImpl(long paramLong);
/*    */   
/*    */   static native String itemImpl(long paramLong, int paramInt);
/*    */   
/*    */   static native boolean containsImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\DOMStringListImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */