/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.css.CSSStyleDeclaration;
/*    */ import org.w3c.dom.css.CSSStyleRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSSStyleRuleImpl
/*    */   extends CSSRuleImpl
/*    */   implements CSSStyleRule
/*    */ {
/*    */   CSSStyleRuleImpl(long paramLong) {
/* 33 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static CSSStyleRule getImpl(long paramLong) {
/* 37 */     return (CSSStyleRule)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getSelectorTextImpl(long paramLong);
/*    */   
/*    */   public String getSelectorText() {
/* 43 */     return getSelectorTextImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setSelectorText(String paramString) {
/* 48 */     setSelectorTextImpl(getPeer(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSStyleDeclaration getStyle() {
/* 53 */     return CSSStyleDeclarationImpl.getImpl(getStyleImpl(getPeer()));
/*    */   }
/*    */   
/*    */   static native void setSelectorTextImpl(long paramLong, String paramString);
/*    */   
/*    */   static native long getStyleImpl(long paramLong);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSStyleRuleImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */