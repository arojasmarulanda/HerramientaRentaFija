/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.css.CSSImportRule;
/*    */ import org.w3c.dom.css.CSSStyleSheet;
/*    */ import org.w3c.dom.stylesheets.MediaList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSSImportRuleImpl
/*    */   extends CSSRuleImpl
/*    */   implements CSSImportRule
/*    */ {
/*    */   CSSImportRuleImpl(long paramLong) {
/* 34 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static CSSImportRule getImpl(long paramLong) {
/* 38 */     return (CSSImportRule)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getHrefImpl(long paramLong);
/*    */   
/*    */   public String getHref() {
/* 44 */     return getHrefImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public MediaList getMedia() {
/* 49 */     return MediaListImpl.getImpl(getMediaImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSStyleSheet getStyleSheet() {
/* 54 */     return CSSStyleSheetImpl.getImpl(getStyleSheetImpl(getPeer()));
/*    */   }
/*    */   
/*    */   static native long getMediaImpl(long paramLong);
/*    */   
/*    */   static native long getStyleSheetImpl(long paramLong);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSImportRuleImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */