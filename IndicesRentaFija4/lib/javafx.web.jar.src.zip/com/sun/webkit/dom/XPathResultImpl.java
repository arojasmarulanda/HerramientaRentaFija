/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.xpath.XPathResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPathResultImpl
/*     */   implements XPathResult
/*     */ {
/*     */   private final long peer;
/*     */   public static final int ANY_TYPE = 0;
/*     */   public static final int NUMBER_TYPE = 1;
/*     */   public static final int STRING_TYPE = 2;
/*     */   public static final int BOOLEAN_TYPE = 3;
/*     */   public static final int UNORDERED_NODE_ITERATOR_TYPE = 4;
/*     */   public static final int ORDERED_NODE_ITERATOR_TYPE = 5;
/*     */   public static final int UNORDERED_NODE_SNAPSHOT_TYPE = 6;
/*     */   public static final int ORDERED_NODE_SNAPSHOT_TYPE = 7;
/*     */   public static final int ANY_UNORDERED_NODE_TYPE = 8;
/*     */   public static final int FIRST_ORDERED_NODE_TYPE = 9;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  38 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  41 */       XPathResultImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   XPathResultImpl(long paramLong) {
/*  46 */     this.peer = paramLong;
/*  47 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static XPathResult create(long paramLong) {
/*  51 */     if (paramLong == 0L) return null; 
/*  52 */     return new XPathResultImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  58 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  62 */     return (paramObject instanceof XPathResultImpl && this.peer == ((XPathResultImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  66 */     long l = this.peer;
/*  67 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(XPathResult paramXPathResult) {
/*  71 */     return (paramXPathResult == null) ? 0L : ((XPathResultImpl)paramXPathResult).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static XPathResult getImpl(long paramLong) {
/*  77 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getResultType() {
/*  95 */     return getResultTypeImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public double getNumberValue() throws DOMException {
/* 100 */     return getNumberValueImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStringValue() throws DOMException {
/* 105 */     return getStringValueImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBooleanValue() throws DOMException {
/* 110 */     return getBooleanValueImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getSingleNodeValue() throws DOMException {
/* 115 */     return NodeImpl.getImpl(getSingleNodeValueImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getInvalidIteratorState() {
/* 120 */     return getInvalidIteratorStateImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSnapshotLength() throws DOMException {
/* 125 */     return getSnapshotLengthImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node iterateNext() throws DOMException {
/* 133 */     return NodeImpl.getImpl(iterateNextImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node snapshotItem(int paramInt) throws DOMException {
/* 140 */     return NodeImpl.getImpl(snapshotItemImpl(getPeer(), paramInt));
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native short getResultTypeImpl(long paramLong);
/*     */   
/*     */   static native double getNumberValueImpl(long paramLong);
/*     */   
/*     */   static native String getStringValueImpl(long paramLong);
/*     */   
/*     */   static native boolean getBooleanValueImpl(long paramLong);
/*     */   
/*     */   static native long getSingleNodeValueImpl(long paramLong);
/*     */   
/*     */   static native boolean getInvalidIteratorStateImpl(long paramLong);
/*     */   
/*     */   static native int getSnapshotLengthImpl(long paramLong);
/*     */   
/*     */   static native long iterateNextImpl(long paramLong);
/*     */   
/*     */   static native long snapshotItemImpl(long paramLong, int paramInt);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\XPathResultImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */