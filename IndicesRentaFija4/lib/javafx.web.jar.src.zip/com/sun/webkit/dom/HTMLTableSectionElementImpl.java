/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.html.HTMLCollection;
/*     */ import org.w3c.dom.html.HTMLElement;
/*     */ import org.w3c.dom.html.HTMLTableSectionElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLTableSectionElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLTableSectionElement
/*     */ {
/*     */   HTMLTableSectionElementImpl(long paramLong) {
/*  35 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLTableSectionElement getImpl(long paramLong) {
/*  39 */     return (HTMLTableSectionElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getAlignImpl(long paramLong);
/*     */   
/*     */   public String getAlign() {
/*  45 */     return getAlignImpl(getPeer());
/*     */   }
/*     */   static native void setAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setAlign(String paramString) {
/*  50 */     setAlignImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCh() {
/*  55 */     return getChImpl(getPeer());
/*     */   }
/*     */   static native String getChImpl(long paramLong);
/*     */   
/*     */   public void setCh(String paramString) {
/*  60 */     setChImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setChImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getChOff() {
/*  65 */     return getChOffImpl(getPeer());
/*     */   }
/*     */   static native String getChOffImpl(long paramLong);
/*     */   
/*     */   public void setChOff(String paramString) {
/*  70 */     setChOffImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setChOffImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getVAlign() {
/*  75 */     return getVAlignImpl(getPeer());
/*     */   }
/*     */   static native String getVAlignImpl(long paramLong);
/*     */   
/*     */   public void setVAlign(String paramString) {
/*  80 */     setVAlignImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setVAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public HTMLCollection getRows() {
/*  85 */     return HTMLCollectionImpl.getImpl(getRowsImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   static native long getRowsImpl(long paramLong);
/*     */ 
/*     */   
/*     */   public HTMLElement insertRow(int paramInt) throws DOMException {
/*  93 */     return HTMLElementImpl.getImpl(insertRowImpl(getPeer(), paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native long insertRowImpl(long paramLong, int paramInt);
/*     */ 
/*     */   
/*     */   public void deleteRow(int paramInt) throws DOMException {
/* 102 */     deleteRowImpl(getPeer(), paramInt);
/*     */   }
/*     */   
/*     */   static native void deleteRowImpl(long paramLong, int paramInt);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLTableSectionElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */