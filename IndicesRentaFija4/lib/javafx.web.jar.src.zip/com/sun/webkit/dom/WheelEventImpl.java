/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.views.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WheelEventImpl
/*     */   extends MouseEventImpl
/*     */ {
/*     */   public static final int DOM_DELTA_PIXEL = 0;
/*     */   public static final int DOM_DELTA_LINE = 1;
/*     */   public static final int DOM_DELTA_PAGE = 2;
/*     */   
/*     */   WheelEventImpl(long paramLong) {
/*  32 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static WheelEventImpl getImpl(long paramLong) {
/*  36 */     return (WheelEventImpl)create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native double getDeltaXImpl(long paramLong);
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDeltaX() {
/*  47 */     return getDeltaXImpl(getPeer());
/*     */   }
/*     */   static native double getDeltaYImpl(long paramLong);
/*     */   
/*     */   public double getDeltaY() {
/*  52 */     return getDeltaYImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDeltaZ() {
/*  57 */     return getDeltaZImpl(getPeer());
/*     */   }
/*     */   static native double getDeltaZImpl(long paramLong);
/*     */   
/*     */   public int getDeltaMode() {
/*  62 */     return getDeltaModeImpl(getPeer());
/*     */   }
/*     */   static native int getDeltaModeImpl(long paramLong);
/*     */   
/*     */   public int getWheelDeltaX() {
/*  67 */     return getWheelDeltaXImpl(getPeer());
/*     */   }
/*     */   static native int getWheelDeltaXImpl(long paramLong);
/*     */   
/*     */   public int getWheelDeltaY() {
/*  72 */     return getWheelDeltaYImpl(getPeer());
/*     */   }
/*     */   static native int getWheelDeltaYImpl(long paramLong);
/*     */   
/*     */   public int getWheelDelta() {
/*  77 */     return getWheelDeltaImpl(getPeer());
/*     */   }
/*     */   static native int getWheelDeltaImpl(long paramLong);
/*     */   
/*     */   public boolean getWebkitDirectionInvertedFromDevice() {
/*  82 */     return getWebkitDirectionInvertedFromDeviceImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native boolean getWebkitDirectionInvertedFromDeviceImpl(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initWheelEvent(int paramInt1, int paramInt2, AbstractView paramAbstractView, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
/* 100 */     initWheelEventImpl(getPeer(), paramInt1, paramInt2, 
/*     */ 
/*     */         
/* 103 */         DOMWindowImpl.getPeer(paramAbstractView), paramInt3, paramInt4, paramInt5, paramInt6, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
/*     */   }
/*     */   
/*     */   static native void initWheelEventImpl(long paramLong1, int paramInt1, int paramInt2, long paramLong2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\WheelEventImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */