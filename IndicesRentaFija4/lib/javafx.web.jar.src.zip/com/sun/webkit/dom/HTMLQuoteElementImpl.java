/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLQuoteElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLQuoteElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLQuoteElement
/*    */ {
/*    */   HTMLQuoteElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLQuoteElement getImpl(long paramLong) {
/* 36 */     return (HTMLQuoteElement)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCite() {
/* 42 */     return getCiteImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCite(String paramString) {
/* 47 */     setCiteImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native String getCiteImpl(long paramLong);
/*    */   
/*    */   static native void setCiteImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLQuoteElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */