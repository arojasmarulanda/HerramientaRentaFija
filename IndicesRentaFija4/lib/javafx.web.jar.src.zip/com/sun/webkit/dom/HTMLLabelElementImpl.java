/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLElement;
/*    */ import org.w3c.dom.html.HTMLFormElement;
/*    */ import org.w3c.dom.html.HTMLLabelElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLLabelElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLLabelElement
/*    */ {
/*    */   HTMLLabelElementImpl(long paramLong) {
/* 34 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLLabelElement getImpl(long paramLong) {
/* 38 */     return (HTMLLabelElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native long getFormImpl(long paramLong);
/*    */   
/*    */   public HTMLFormElement getForm() {
/* 44 */     return HTMLFormElementImpl.getImpl(getFormImpl(getPeer()));
/*    */   }
/*    */   static native String getHtmlForImpl(long paramLong);
/*    */   
/*    */   public String getHtmlFor() {
/* 49 */     return getHtmlForImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setHtmlFor(String paramString) {
/* 54 */     setHtmlForImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setHtmlForImpl(long paramLong, String paramString);
/*    */   
/*    */   public HTMLElement getControl() {
/* 59 */     return HTMLElementImpl.getImpl(getControlImpl(getPeer()));
/*    */   }
/*    */   static native long getControlImpl(long paramLong);
/*    */   
/*    */   public String getAccessKey() {
/* 64 */     return getAccessKeyImpl(getPeer());
/*    */   }
/*    */   static native String getAccessKeyImpl(long paramLong);
/*    */   
/*    */   public void setAccessKey(String paramString) {
/* 69 */     setAccessKeyImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setAccessKeyImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLLabelElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */