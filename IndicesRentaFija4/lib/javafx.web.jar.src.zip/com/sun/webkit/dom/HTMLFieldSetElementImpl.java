/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLFieldSetElement;
/*    */ import org.w3c.dom.html.HTMLFormElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLFieldSetElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLFieldSetElement
/*    */ {
/*    */   HTMLFieldSetElementImpl(long paramLong) {
/* 33 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLFieldSetElement getImpl(long paramLong) {
/* 37 */     return (HTMLFieldSetElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native boolean getDisabledImpl(long paramLong);
/*    */   
/*    */   public boolean getDisabled() {
/* 43 */     return getDisabledImpl(getPeer());
/*    */   }
/*    */   static native void setDisabledImpl(long paramLong, boolean paramBoolean);
/*    */   
/*    */   public void setDisabled(boolean paramBoolean) {
/* 48 */     setDisabledImpl(getPeer(), paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public HTMLFormElement getForm() {
/* 53 */     return HTMLFormElementImpl.getImpl(getFormImpl(getPeer()));
/*    */   }
/*    */   static native long getFormImpl(long paramLong);
/*    */   
/*    */   public String getName() {
/* 58 */     return getNameImpl(getPeer());
/*    */   }
/*    */   static native String getNameImpl(long paramLong);
/*    */   
/*    */   public void setName(String paramString) {
/* 63 */     setNameImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setNameImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getType() {
/* 68 */     return getTypeImpl(getPeer());
/*    */   }
/*    */   static native String getTypeImpl(long paramLong);
/*    */   
/*    */   public boolean getWillValidate() {
/* 73 */     return getWillValidateImpl(getPeer());
/*    */   }
/*    */   static native boolean getWillValidateImpl(long paramLong);
/*    */   
/*    */   public String getValidationMessage() {
/* 78 */     return getValidationMessageImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   static native String getValidationMessageImpl(long paramLong);
/*    */ 
/*    */   
/*    */   public boolean checkValidity() {
/* 86 */     return checkValidityImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   static native boolean checkValidityImpl(long paramLong);
/*    */   
/*    */   public void setCustomValidity(String paramString) {
/* 93 */     setCustomValidityImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setCustomValidityImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLFieldSetElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */