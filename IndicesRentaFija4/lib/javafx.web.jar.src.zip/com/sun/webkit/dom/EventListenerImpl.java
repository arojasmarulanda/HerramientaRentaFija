/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.w3c.dom.events.Event;
/*     */ import org.w3c.dom.events.EventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EventListenerImpl
/*     */   implements EventListener
/*     */ {
/*  40 */   private static final Map<EventListener, Long> EL2peer = new WeakHashMap<>();
/*     */   
/*  42 */   private static final Map<Long, WeakReference<EventListener>> peer2EL = new HashMap<>();
/*     */   private final EventListener eventListener;
/*     */   private final long jsPeer;
/*     */   
/*     */   private static final class SelfDisposer implements DisposerRecord {
/*     */     private SelfDisposer(long param1Long) {
/*  48 */       this.peer = param1Long;
/*     */     }
/*     */     private final long peer;
/*     */     public void dispose() {
/*  52 */       EventListenerImpl.dispose(this.peer);
/*  53 */       EventListenerImpl.twkDisposeJSPeer(this.peer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long getPeer(EventListener paramEventListener) {
/*  61 */     if (paramEventListener == null) {
/*  62 */       return 0L;
/*     */     }
/*     */     
/*  65 */     Long long_ = EL2peer.get(paramEventListener);
/*  66 */     if (long_ != null) {
/*  67 */       return long_.longValue();
/*     */     }
/*     */ 
/*     */     
/*  71 */     EventListenerImpl eventListenerImpl = new EventListenerImpl(paramEventListener, 0L);
/*  72 */     long_ = Long.valueOf(eventListenerImpl.twkCreatePeer());
/*  73 */     EL2peer.put(paramEventListener, long_);
/*  74 */     peer2EL.put(long_, new WeakReference<>(paramEventListener));
/*     */     
/*  76 */     return long_.longValue();
/*     */   }
/*     */ 
/*     */   
/*     */   private static EventListener getELfromPeer(long paramLong) {
/*  81 */     WeakReference<EventListener> weakReference = peer2EL.get(Long.valueOf(paramLong));
/*  82 */     return (weakReference == null) ? null : weakReference.get();
/*     */   }
/*     */   
/*     */   static EventListener getImpl(long paramLong) {
/*  86 */     if (paramLong == 0L) {
/*  87 */       return null;
/*     */     }
/*  89 */     EventListener eventListener = getELfromPeer(paramLong);
/*  90 */     if (eventListener != null) {
/*     */       
/*  92 */       twkDisposeJSPeer(paramLong);
/*  93 */       return eventListener;
/*     */     } 
/*     */ 
/*     */     
/*  97 */     EventListenerImpl eventListenerImpl = new EventListenerImpl(null, paramLong);
/*  98 */     EL2peer.put(eventListenerImpl, Long.valueOf(paramLong));
/*  99 */     peer2EL.put(Long.valueOf(paramLong), new WeakReference<>(eventListenerImpl));
/* 100 */     Disposer.addRecord(eventListenerImpl, new SelfDisposer(paramLong));
/*     */     
/* 102 */     return eventListenerImpl;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleEvent(Event paramEvent) {
/* 107 */     if (this.jsPeer != 0L && paramEvent instanceof EventImpl) {
/* 108 */       twkDispatchEvent(this.jsPeer, ((EventImpl)paramEvent).getPeer());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private EventListenerImpl(EventListener paramEventListener, long paramLong) {
/* 114 */     this.eventListener = paramEventListener;
/* 115 */     this.jsPeer = paramLong;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void dispose(long paramLong) {
/* 120 */     EventListener eventListener = getELfromPeer(paramLong);
/* 121 */     if (eventListener != null)
/* 122 */       EL2peer.remove(eventListener); 
/* 123 */     peer2EL.remove(Long.valueOf(paramLong));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void fwkHandleEvent(long paramLong) {
/* 129 */     this.eventListener.handleEvent(EventImpl.getImpl(paramLong));
/*     */   }
/*     */   
/*     */   private native long twkCreatePeer();
/*     */   
/*     */   private static native void twkDispatchEvent(long paramLong1, long paramLong2);
/*     */   
/*     */   private static native void twkDisposeJSPeer(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\EventListenerImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */