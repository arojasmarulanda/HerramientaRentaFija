/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLDirectoryElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLDirectoryElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLDirectoryElement
/*    */ {
/*    */   HTMLDirectoryElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLDirectoryElement getImpl(long paramLong) {
/* 36 */     return (HTMLDirectoryElement)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getCompact() {
/* 42 */     return getCompactImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCompact(boolean paramBoolean) {
/* 47 */     setCompactImpl(getPeer(), paramBoolean);
/*    */   }
/*    */   
/*    */   static native boolean getCompactImpl(long paramLong);
/*    */   
/*    */   static native void setCompactImpl(long paramLong, boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLDirectoryElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */