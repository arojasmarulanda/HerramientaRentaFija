/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.html.HTMLScriptElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLScriptElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLScriptElement
/*     */ {
/*     */   HTMLScriptElementImpl(long paramLong) {
/*  32 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLScriptElement getImpl(long paramLong) {
/*  36 */     return (HTMLScriptElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getTextImpl(long paramLong);
/*     */   
/*     */   public String getText() {
/*  42 */     return getTextImpl(getPeer());
/*     */   }
/*     */   static native void setTextImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setText(String paramString) {
/*  47 */     setTextImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHtmlFor() {
/*  52 */     return getHtmlForImpl(getPeer());
/*     */   }
/*     */   static native String getHtmlForImpl(long paramLong);
/*     */   
/*     */   public void setHtmlFor(String paramString) {
/*  57 */     setHtmlForImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHtmlForImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getEvent() {
/*  62 */     return getEventImpl(getPeer());
/*     */   }
/*     */   static native String getEventImpl(long paramLong);
/*     */   
/*     */   public void setEvent(String paramString) {
/*  67 */     setEventImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setEventImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCharset() {
/*  72 */     return getCharsetImpl(getPeer());
/*     */   }
/*     */   static native String getCharsetImpl(long paramLong);
/*     */   
/*     */   public void setCharset(String paramString) {
/*  77 */     setCharsetImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCharsetImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getAsync() {
/*  82 */     return getAsyncImpl(getPeer());
/*     */   }
/*     */   static native boolean getAsyncImpl(long paramLong);
/*     */   
/*     */   public void setAsync(boolean paramBoolean) {
/*  87 */     setAsyncImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setAsyncImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public boolean getDefer() {
/*  92 */     return getDeferImpl(getPeer());
/*     */   }
/*     */   static native boolean getDeferImpl(long paramLong);
/*     */   
/*     */   public void setDefer(boolean paramBoolean) {
/*  97 */     setDeferImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setDeferImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getSrc() {
/* 102 */     return getSrcImpl(getPeer());
/*     */   }
/*     */   static native String getSrcImpl(long paramLong);
/*     */   
/*     */   public void setSrc(String paramString) {
/* 107 */     setSrcImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSrcImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getType() {
/* 112 */     return getTypeImpl(getPeer());
/*     */   }
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   public void setType(String paramString) {
/* 117 */     setTypeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTypeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCrossOrigin() {
/* 122 */     return getCrossOriginImpl(getPeer());
/*     */   }
/*     */   static native String getCrossOriginImpl(long paramLong);
/*     */   
/*     */   public void setCrossOrigin(String paramString) {
/* 127 */     setCrossOriginImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   static native void setCrossOriginImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLScriptElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */