/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.css.CSSStyleSheet;
/*     */ import org.w3c.dom.html.HTMLDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMImplementationImpl
/*     */   implements DOMImplementation
/*     */ {
/*     */   private final long peer;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  41 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  44 */       DOMImplementationImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   DOMImplementationImpl(long paramLong) {
/*  49 */     this.peer = paramLong;
/*  50 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static DOMImplementation create(long paramLong) {
/*  54 */     if (paramLong == 0L) return null; 
/*  55 */     return new DOMImplementationImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  61 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  65 */     return (paramObject instanceof DOMImplementationImpl && this.peer == ((DOMImplementationImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  69 */     long l = this.peer;
/*  70 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(DOMImplementation paramDOMImplementation) {
/*  74 */     return (paramDOMImplementation == null) ? 0L : ((DOMImplementationImpl)paramDOMImplementation).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static DOMImplementation getImpl(long paramLong) {
/*  80 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasFeature(String paramString1, String paramString2) {
/*  88 */     return hasFeatureImpl(getPeer(), paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentType createDocumentType(String paramString1, String paramString2, String paramString3) throws DOMException {
/* 101 */     return DocumentTypeImpl.getImpl(createDocumentTypeImpl(getPeer(), paramString1, paramString2, paramString3));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document createDocument(String paramString1, String paramString2, DocumentType paramDocumentType) throws DOMException {
/* 116 */     return DocumentImpl.getImpl(createDocumentImpl(getPeer(), paramString1, paramString2, 
/*     */ 
/*     */           
/* 119 */           DocumentTypeImpl.getPeer(paramDocumentType)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSSStyleSheet createCSSStyleSheet(String paramString1, String paramString2) throws DOMException {
/* 130 */     return CSSStyleSheetImpl.getImpl(createCSSStyleSheetImpl(getPeer(), paramString1, paramString2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HTMLDocument createHTMLDocument(String paramString) {
/* 141 */     return HTMLDocumentImpl.getImpl(createHTMLDocumentImpl(getPeer(), paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getFeature(String paramString1, String paramString2) {
/* 151 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native boolean hasFeatureImpl(long paramLong, String paramString1, String paramString2);
/*     */   
/*     */   static native long createDocumentTypeImpl(long paramLong, String paramString1, String paramString2, String paramString3);
/*     */   
/*     */   static native long createDocumentImpl(long paramLong1, String paramString1, String paramString2, long paramLong2);
/*     */   
/*     */   static native long createCSSStyleSheetImpl(long paramLong, String paramString1, String paramString2);
/*     */   
/*     */   static native long createHTMLDocumentImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\DOMImplementationImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */