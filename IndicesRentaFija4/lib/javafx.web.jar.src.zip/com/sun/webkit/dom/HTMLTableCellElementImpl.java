/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.html.HTMLTableCellElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLTableCellElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLTableCellElement
/*     */ {
/*     */   HTMLTableCellElementImpl(long paramLong) {
/*  32 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLTableCellElement getImpl(long paramLong) {
/*  36 */     return (HTMLTableCellElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native int getCellIndexImpl(long paramLong);
/*     */   
/*     */   public int getCellIndex() {
/*  42 */     return getCellIndexImpl(getPeer());
/*     */   }
/*     */   static native String getAlignImpl(long paramLong);
/*     */   
/*     */   public String getAlign() {
/*  47 */     return getAlignImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlign(String paramString) {
/*  52 */     setAlignImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getAxis() {
/*  57 */     return getAxisImpl(getPeer());
/*     */   }
/*     */   static native String getAxisImpl(long paramLong);
/*     */   
/*     */   public void setAxis(String paramString) {
/*  62 */     setAxisImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAxisImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getBgColor() {
/*  67 */     return getBgColorImpl(getPeer());
/*     */   }
/*     */   static native String getBgColorImpl(long paramLong);
/*     */   
/*     */   public void setBgColor(String paramString) {
/*  72 */     setBgColorImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setBgColorImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCh() {
/*  77 */     return getChImpl(getPeer());
/*     */   }
/*     */   static native String getChImpl(long paramLong);
/*     */   
/*     */   public void setCh(String paramString) {
/*  82 */     setChImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setChImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getChOff() {
/*  87 */     return getChOffImpl(getPeer());
/*     */   }
/*     */   static native String getChOffImpl(long paramLong);
/*     */   
/*     */   public void setChOff(String paramString) {
/*  92 */     setChOffImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setChOffImpl(long paramLong, String paramString);
/*     */   
/*     */   public int getColSpan() {
/*  97 */     return getColSpanImpl(getPeer());
/*     */   }
/*     */   static native int getColSpanImpl(long paramLong);
/*     */   
/*     */   public void setColSpan(int paramInt) {
/* 102 */     setColSpanImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setColSpanImpl(long paramLong, int paramInt);
/*     */   
/*     */   public int getRowSpan() {
/* 107 */     return getRowSpanImpl(getPeer());
/*     */   }
/*     */   static native int getRowSpanImpl(long paramLong);
/*     */   
/*     */   public void setRowSpan(int paramInt) {
/* 112 */     setRowSpanImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setRowSpanImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getHeaders() {
/* 117 */     return getHeadersImpl(getPeer());
/*     */   }
/*     */   static native String getHeadersImpl(long paramLong);
/*     */   
/*     */   public void setHeaders(String paramString) {
/* 122 */     setHeadersImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHeadersImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHeight() {
/* 127 */     return getHeightImpl(getPeer());
/*     */   }
/*     */   static native String getHeightImpl(long paramLong);
/*     */   
/*     */   public void setHeight(String paramString) {
/* 132 */     setHeightImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHeightImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getNoWrap() {
/* 137 */     return getNoWrapImpl(getPeer());
/*     */   }
/*     */   static native boolean getNoWrapImpl(long paramLong);
/*     */   
/*     */   public void setNoWrap(boolean paramBoolean) {
/* 142 */     setNoWrapImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setNoWrapImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getVAlign() {
/* 147 */     return getVAlignImpl(getPeer());
/*     */   }
/*     */   static native String getVAlignImpl(long paramLong);
/*     */   
/*     */   public void setVAlign(String paramString) {
/* 152 */     setVAlignImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setVAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getWidth() {
/* 157 */     return getWidthImpl(getPeer());
/*     */   }
/*     */   static native String getWidthImpl(long paramLong);
/*     */   
/*     */   public void setWidth(String paramString) {
/* 162 */     setWidthImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setWidthImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getAbbr() {
/* 167 */     return getAbbrImpl(getPeer());
/*     */   }
/*     */   static native String getAbbrImpl(long paramLong);
/*     */   
/*     */   public void setAbbr(String paramString) {
/* 172 */     setAbbrImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAbbrImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getScope() {
/* 177 */     return getScopeImpl(getPeer());
/*     */   }
/*     */   static native String getScopeImpl(long paramLong);
/*     */   
/*     */   public void setScope(String paramString) {
/* 182 */     setScopeImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   static native void setScopeImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLTableCellElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */