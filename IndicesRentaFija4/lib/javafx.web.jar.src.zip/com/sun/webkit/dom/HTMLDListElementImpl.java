/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLDListElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLDListElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLDListElement
/*    */ {
/*    */   HTMLDListElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLDListElement getImpl(long paramLong) {
/* 36 */     return (HTMLDListElement)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getCompact() {
/* 42 */     return getCompactImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCompact(boolean paramBoolean) {
/* 47 */     setCompactImpl(getPeer(), paramBoolean);
/*    */   }
/*    */   
/*    */   static native boolean getCompactImpl(long paramLong);
/*    */   
/*    */   static native void setCompactImpl(long paramLong, boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLDListElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */