/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedNodeMapImpl
/*     */   implements NamedNodeMap
/*     */ {
/*     */   private final long peer;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  38 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  41 */       NamedNodeMapImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   NamedNodeMapImpl(long paramLong) {
/*  46 */     this.peer = paramLong;
/*  47 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static NamedNodeMap create(long paramLong) {
/*  51 */     if (paramLong == 0L) return null; 
/*  52 */     return new NamedNodeMapImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  58 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  62 */     return (paramObject instanceof NamedNodeMapImpl && this.peer == ((NamedNodeMapImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  66 */     long l = this.peer;
/*  67 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(NamedNodeMap paramNamedNodeMap) {
/*  71 */     return (paramNamedNodeMap == null) ? 0L : ((NamedNodeMapImpl)paramNamedNodeMap).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static NamedNodeMap getImpl(long paramLong) {
/*  77 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/*  83 */     return getLengthImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getNamedItem(String paramString) {
/*  91 */     return NodeImpl.getImpl(getNamedItemImpl(getPeer(), paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node setNamedItem(Node paramNode) throws DOMException {
/* 100 */     return NodeImpl.getImpl(setNamedItemImpl(getPeer(), 
/* 101 */           NodeImpl.getPeer(paramNode)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node removeNamedItem(String paramString) throws DOMException {
/* 109 */     return NodeImpl.getImpl(removeNamedItemImpl(getPeer(), paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node item(int paramInt) {
/* 118 */     return NodeImpl.getImpl(itemImpl(getPeer(), paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getNamedItemNS(String paramString1, String paramString2) {
/* 128 */     return NodeImpl.getImpl(getNamedItemNSImpl(getPeer(), paramString1, paramString2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node setNamedItemNS(Node paramNode) throws DOMException {
/* 139 */     return NodeImpl.getImpl(setNamedItemNSImpl(getPeer(), 
/* 140 */           NodeImpl.getPeer(paramNode)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node removeNamedItemNS(String paramString1, String paramString2) throws DOMException {
/* 149 */     return NodeImpl.getImpl(removeNamedItemNSImpl(getPeer(), paramString1, paramString2));
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native int getLengthImpl(long paramLong);
/*     */   
/*     */   static native long getNamedItemImpl(long paramLong, String paramString);
/*     */   
/*     */   static native long setNamedItemImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native long removeNamedItemImpl(long paramLong, String paramString);
/*     */   
/*     */   static native long itemImpl(long paramLong, int paramInt);
/*     */   
/*     */   static native long getNamedItemNSImpl(long paramLong, String paramString1, String paramString2);
/*     */   
/*     */   static native long setNamedItemNSImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native long removeNamedItemNSImpl(long paramLong, String paramString1, String paramString2);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\NamedNodeMapImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */