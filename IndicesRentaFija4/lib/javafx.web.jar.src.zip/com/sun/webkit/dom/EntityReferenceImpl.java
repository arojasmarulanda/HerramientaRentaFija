/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.EntityReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityReferenceImpl
/*    */   extends NodeImpl
/*    */   implements EntityReference
/*    */ {
/*    */   EntityReferenceImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static EntityReference getImpl(long paramLong) {
/* 36 */     return (EntityReference)create(paramLong);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\EntityReferenceImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */