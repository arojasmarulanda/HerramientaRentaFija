/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLTableColElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLTableColElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLTableColElement
/*    */ {
/*    */   HTMLTableColElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLTableColElement getImpl(long paramLong) {
/* 36 */     return (HTMLTableColElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getAlignImpl(long paramLong);
/*    */   
/*    */   public String getAlign() {
/* 42 */     return getAlignImpl(getPeer());
/*    */   }
/*    */   static native void setAlignImpl(long paramLong, String paramString);
/*    */   
/*    */   public void setAlign(String paramString) {
/* 47 */     setAlignImpl(getPeer(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCh() {
/* 52 */     return getChImpl(getPeer());
/*    */   }
/*    */   static native String getChImpl(long paramLong);
/*    */   
/*    */   public void setCh(String paramString) {
/* 57 */     setChImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setChImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getChOff() {
/* 62 */     return getChOffImpl(getPeer());
/*    */   }
/*    */   static native String getChOffImpl(long paramLong);
/*    */   
/*    */   public void setChOff(String paramString) {
/* 67 */     setChOffImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setChOffImpl(long paramLong, String paramString);
/*    */   
/*    */   public int getSpan() {
/* 72 */     return getSpanImpl(getPeer());
/*    */   }
/*    */   static native int getSpanImpl(long paramLong);
/*    */   
/*    */   public void setSpan(int paramInt) {
/* 77 */     setSpanImpl(getPeer(), paramInt);
/*    */   }
/*    */   static native void setSpanImpl(long paramLong, int paramInt);
/*    */   
/*    */   public String getVAlign() {
/* 82 */     return getVAlignImpl(getPeer());
/*    */   }
/*    */   static native String getVAlignImpl(long paramLong);
/*    */   
/*    */   public void setVAlign(String paramString) {
/* 87 */     setVAlignImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setVAlignImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getWidth() {
/* 92 */     return getWidthImpl(getPeer());
/*    */   }
/*    */   static native String getWidthImpl(long paramLong);
/*    */   
/*    */   public void setWidth(String paramString) {
/* 97 */     setWidthImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setWidthImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLTableColElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */