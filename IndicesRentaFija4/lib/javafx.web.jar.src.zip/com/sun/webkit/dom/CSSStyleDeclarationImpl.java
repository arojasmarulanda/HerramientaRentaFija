/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.css.CSSRule;
/*     */ import org.w3c.dom.css.CSSStyleDeclaration;
/*     */ import org.w3c.dom.css.CSSValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSSStyleDeclarationImpl
/*     */   implements CSSStyleDeclaration
/*     */ {
/*     */   private final long peer;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  39 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  42 */       CSSStyleDeclarationImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   CSSStyleDeclarationImpl(long paramLong) {
/*  47 */     this.peer = paramLong;
/*  48 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static CSSStyleDeclaration create(long paramLong) {
/*  52 */     if (paramLong == 0L) return null; 
/*  53 */     return new CSSStyleDeclarationImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  59 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  63 */     return (paramObject instanceof CSSStyleDeclarationImpl && this.peer == ((CSSStyleDeclarationImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  67 */     long l = this.peer;
/*  68 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(CSSStyleDeclaration paramCSSStyleDeclaration) {
/*  72 */     return (paramCSSStyleDeclaration == null) ? 0L : ((CSSStyleDeclarationImpl)paramCSSStyleDeclaration).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static CSSStyleDeclaration getImpl(long paramLong) {
/*  78 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCssText() {
/*  84 */     return getCssTextImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCssText(String paramString) throws DOMException {
/*  89 */     setCssTextImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/*  94 */     return getLengthImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public CSSRule getParentRule() {
/*  99 */     return CSSRuleImpl.getImpl(getParentRuleImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPropertyValue(String paramString) {
/* 107 */     return getPropertyValueImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSSValue getPropertyCSSValue(String paramString) {
/* 116 */     return CSSValueImpl.getImpl(getPropertyCSSValueImpl(getPeer(), paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String removeProperty(String paramString) throws DOMException {
/* 125 */     return removePropertyImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPropertyPriority(String paramString) {
/* 134 */     return getPropertyPriorityImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String paramString1, String paramString2, String paramString3) throws DOMException {
/* 145 */     setPropertyImpl(getPeer(), paramString1, paramString2, paramString3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String item(int paramInt) {
/* 158 */     return itemImpl(getPeer(), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPropertyShorthand(String paramString) {
/* 167 */     return getPropertyShorthandImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPropertyImplicit(String paramString) {
/* 176 */     return isPropertyImplicitImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native String getCssTextImpl(long paramLong);
/*     */   
/*     */   static native void setCssTextImpl(long paramLong, String paramString);
/*     */   
/*     */   static native int getLengthImpl(long paramLong);
/*     */   
/*     */   static native long getParentRuleImpl(long paramLong);
/*     */   
/*     */   static native String getPropertyValueImpl(long paramLong, String paramString);
/*     */   
/*     */   static native long getPropertyCSSValueImpl(long paramLong, String paramString);
/*     */   
/*     */   static native String removePropertyImpl(long paramLong, String paramString);
/*     */   
/*     */   static native String getPropertyPriorityImpl(long paramLong, String paramString);
/*     */   
/*     */   static native void setPropertyImpl(long paramLong, String paramString1, String paramString2, String paramString3);
/*     */   
/*     */   static native String itemImpl(long paramLong, int paramInt);
/*     */   
/*     */   static native String getPropertyShorthandImpl(long paramLong, String paramString);
/*     */   
/*     */   static native boolean isPropertyImplicitImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSStyleDeclarationImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */