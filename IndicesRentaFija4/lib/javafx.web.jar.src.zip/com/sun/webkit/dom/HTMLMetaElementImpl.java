/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLMetaElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLMetaElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLMetaElement
/*    */ {
/*    */   HTMLMetaElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLMetaElement getImpl(long paramLong) {
/* 36 */     return (HTMLMetaElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getContentImpl(long paramLong);
/*    */   
/*    */   public String getContent() {
/* 42 */     return getContentImpl(getPeer());
/*    */   }
/*    */   static native void setContentImpl(long paramLong, String paramString);
/*    */   
/*    */   public void setContent(String paramString) {
/* 47 */     setContentImpl(getPeer(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getHttpEquiv() {
/* 52 */     return getHttpEquivImpl(getPeer());
/*    */   }
/*    */   static native String getHttpEquivImpl(long paramLong);
/*    */   
/*    */   public void setHttpEquiv(String paramString) {
/* 57 */     setHttpEquivImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setHttpEquivImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getName() {
/* 62 */     return getNameImpl(getPeer());
/*    */   }
/*    */   static native String getNameImpl(long paramLong);
/*    */   
/*    */   public void setName(String paramString) {
/* 67 */     setNameImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setNameImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getScheme() {
/* 72 */     return getSchemeImpl(getPeer());
/*    */   }
/*    */   static native String getSchemeImpl(long paramLong);
/*    */   
/*    */   public void setScheme(String paramString) {
/* 77 */     setSchemeImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setSchemeImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLMetaElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */