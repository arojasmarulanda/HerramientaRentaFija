/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.css.CSSMediaRule;
/*    */ import org.w3c.dom.css.CSSRuleList;
/*    */ import org.w3c.dom.stylesheets.MediaList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSSMediaRuleImpl
/*    */   extends CSSRuleImpl
/*    */   implements CSSMediaRule
/*    */ {
/*    */   CSSMediaRuleImpl(long paramLong) {
/* 35 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static CSSMediaRule getImpl(long paramLong) {
/* 39 */     return (CSSMediaRule)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MediaList getMedia() {
/* 45 */     return MediaListImpl.getImpl(getMediaImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSRuleList getCssRules() {
/* 50 */     return CSSRuleListImpl.getImpl(getCssRulesImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   static native long getMediaImpl(long paramLong);
/*    */   
/*    */   static native long getCssRulesImpl(long paramLong);
/*    */   
/*    */   public int insertRule(String paramString, int paramInt) throws DOMException {
/* 59 */     return insertRuleImpl(getPeer(), paramString, paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static native int insertRuleImpl(long paramLong, String paramString, int paramInt);
/*    */ 
/*    */ 
/*    */   
/*    */   public void deleteRule(int paramInt) throws DOMException {
/* 70 */     deleteRuleImpl(getPeer(), paramInt);
/*    */   }
/*    */   
/*    */   static native void deleteRuleImpl(long paramLong, int paramInt);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSMediaRuleImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */