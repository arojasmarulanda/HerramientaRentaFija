/*      */ package com.sun.webkit.dom;
/*      */ 
/*      */ import org.w3c.dom.Attr;
/*      */ import org.w3c.dom.CDATASection;
/*      */ import org.w3c.dom.Comment;
/*      */ import org.w3c.dom.DOMConfiguration;
/*      */ import org.w3c.dom.DOMException;
/*      */ import org.w3c.dom.DOMImplementation;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.DocumentFragment;
/*      */ import org.w3c.dom.DocumentType;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.EntityReference;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.w3c.dom.ProcessingInstruction;
/*      */ import org.w3c.dom.Text;
/*      */ import org.w3c.dom.css.CSSStyleDeclaration;
/*      */ import org.w3c.dom.events.DocumentEvent;
/*      */ import org.w3c.dom.events.Event;
/*      */ import org.w3c.dom.events.EventListener;
/*      */ import org.w3c.dom.html.HTMLCollection;
/*      */ import org.w3c.dom.html.HTMLElement;
/*      */ import org.w3c.dom.html.HTMLHeadElement;
/*      */ import org.w3c.dom.html.HTMLScriptElement;
/*      */ import org.w3c.dom.ranges.Range;
/*      */ import org.w3c.dom.stylesheets.StyleSheetList;
/*      */ import org.w3c.dom.traversal.NodeFilter;
/*      */ import org.w3c.dom.traversal.NodeIterator;
/*      */ import org.w3c.dom.traversal.TreeWalker;
/*      */ import org.w3c.dom.views.AbstractView;
/*      */ import org.w3c.dom.views.DocumentView;
/*      */ import org.w3c.dom.xpath.XPathEvaluator;
/*      */ import org.w3c.dom.xpath.XPathExpression;
/*      */ import org.w3c.dom.xpath.XPathNSResolver;
/*      */ import org.w3c.dom.xpath.XPathResult;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DocumentImpl
/*      */   extends NodeImpl
/*      */   implements Document, XPathEvaluator, DocumentView, DocumentEvent
/*      */ {
/*      */   DocumentImpl(long paramLong) {
/*   65 */     super(paramLong);
/*      */   }
/*      */   
/*      */   static Document getImpl(long paramLong) {
/*   69 */     return (Document)create(paramLong);
/*      */   }
/*      */   
/*      */   static native boolean isHTMLDocumentImpl(long paramLong);
/*      */   
/*      */   public Object evaluate(String paramString, Node paramNode, XPathNSResolver paramXPathNSResolver, short paramShort, Object paramObject) throws DOMException {
/*   75 */     return evaluate(paramString, paramNode, paramXPathNSResolver, paramShort, (XPathResult)paramObject);
/*      */   }
/*      */   
/*      */   static native long getDoctypeImpl(long paramLong);
/*      */   
/*      */   public DocumentType getDoctype() {
/*   81 */     return DocumentTypeImpl.getImpl(getDoctypeImpl(getPeer()));
/*      */   }
/*      */   static native long getImplementationImpl(long paramLong);
/*      */   
/*      */   public DOMImplementation getImplementation() {
/*   86 */     return DOMImplementationImpl.getImpl(getImplementationImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Element getDocumentElement() {
/*   91 */     return ElementImpl.getImpl(getDocumentElementImpl(getPeer()));
/*      */   }
/*      */   static native long getDocumentElementImpl(long paramLong);
/*      */   
/*      */   public String getInputEncoding() {
/*   96 */     return getInputEncodingImpl(getPeer());
/*      */   }
/*      */   static native String getInputEncodingImpl(long paramLong);
/*      */   
/*      */   public String getXmlEncoding() {
/*  101 */     return getXmlEncodingImpl(getPeer());
/*      */   }
/*      */   static native String getXmlEncodingImpl(long paramLong);
/*      */   
/*      */   public String getXmlVersion() {
/*  106 */     return getXmlVersionImpl(getPeer());
/*      */   }
/*      */   static native String getXmlVersionImpl(long paramLong);
/*      */   
/*      */   public void setXmlVersion(String paramString) throws DOMException {
/*  111 */     setXmlVersionImpl(getPeer(), paramString);
/*      */   }
/*      */   static native void setXmlVersionImpl(long paramLong, String paramString);
/*      */   
/*      */   public boolean getXmlStandalone() {
/*  116 */     return getXmlStandaloneImpl(getPeer());
/*      */   }
/*      */   static native boolean getXmlStandaloneImpl(long paramLong);
/*      */   
/*      */   public void setXmlStandalone(boolean paramBoolean) throws DOMException {
/*  121 */     setXmlStandaloneImpl(getPeer(), paramBoolean);
/*      */   }
/*      */   static native void setXmlStandaloneImpl(long paramLong, boolean paramBoolean);
/*      */   
/*      */   public String getDocumentURI() {
/*  126 */     return getDocumentURIImpl(getPeer());
/*      */   }
/*      */   static native String getDocumentURIImpl(long paramLong);
/*      */   
/*      */   public void setDocumentURI(String paramString) {
/*  131 */     setDocumentURIImpl(getPeer(), paramString);
/*      */   }
/*      */   static native void setDocumentURIImpl(long paramLong, String paramString);
/*      */   
/*      */   public AbstractView getDefaultView() {
/*  136 */     return DOMWindowImpl.getImpl(getDefaultViewImpl(getPeer()));
/*      */   }
/*      */   static native long getDefaultViewImpl(long paramLong);
/*      */   
/*      */   public StyleSheetList getStyleSheets() {
/*  141 */     return StyleSheetListImpl.getImpl(getStyleSheetsImpl(getPeer()));
/*      */   }
/*      */   static native long getStyleSheetsImpl(long paramLong);
/*      */   
/*      */   public String getContentType() {
/*  146 */     return getContentTypeImpl(getPeer());
/*      */   }
/*      */   static native String getContentTypeImpl(long paramLong);
/*      */   
/*      */   public String getTitle() {
/*  151 */     return getTitleImpl(getPeer());
/*      */   }
/*      */   static native String getTitleImpl(long paramLong);
/*      */   
/*      */   public void setTitle(String paramString) {
/*  156 */     setTitleImpl(getPeer(), paramString);
/*      */   }
/*      */   static native void setTitleImpl(long paramLong, String paramString);
/*      */   
/*      */   public String getReferrer() {
/*  161 */     return getReferrerImpl(getPeer());
/*      */   }
/*      */   static native String getReferrerImpl(long paramLong);
/*      */   
/*      */   public String getDomain() {
/*  166 */     return getDomainImpl(getPeer());
/*      */   }
/*      */   static native String getDomainImpl(long paramLong);
/*      */   
/*      */   public String getURL() {
/*  171 */     return getURLImpl(getPeer());
/*      */   }
/*      */   static native String getURLImpl(long paramLong);
/*      */   
/*      */   public String getCookie() throws DOMException {
/*  176 */     return getCookieImpl(getPeer());
/*      */   }
/*      */   static native String getCookieImpl(long paramLong);
/*      */   
/*      */   public void setCookie(String paramString) throws DOMException {
/*  181 */     setCookieImpl(getPeer(), paramString);
/*      */   }
/*      */   static native void setCookieImpl(long paramLong, String paramString);
/*      */   
/*      */   public HTMLElement getBody() {
/*  186 */     return HTMLElementImpl.getImpl(getBodyImpl(getPeer()));
/*      */   }
/*      */   static native long getBodyImpl(long paramLong);
/*      */   
/*      */   public void setBody(HTMLElement paramHTMLElement) throws DOMException {
/*  191 */     setBodyImpl(getPeer(), HTMLElementImpl.getPeer(paramHTMLElement));
/*      */   }
/*      */   static native void setBodyImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public HTMLHeadElement getHead() {
/*  196 */     return HTMLHeadElementImpl.getImpl(getHeadImpl(getPeer()));
/*      */   }
/*      */   static native long getHeadImpl(long paramLong);
/*      */   
/*      */   public HTMLCollection getImages() {
/*  201 */     return HTMLCollectionImpl.getImpl(getImagesImpl(getPeer()));
/*      */   }
/*      */   static native long getImagesImpl(long paramLong);
/*      */   
/*      */   public HTMLCollection getApplets() {
/*  206 */     return HTMLCollectionImpl.getImpl(getAppletsImpl(getPeer()));
/*      */   }
/*      */   static native long getAppletsImpl(long paramLong);
/*      */   
/*      */   public HTMLCollection getLinks() {
/*  211 */     return HTMLCollectionImpl.getImpl(getLinksImpl(getPeer()));
/*      */   }
/*      */   static native long getLinksImpl(long paramLong);
/*      */   
/*      */   public HTMLCollection getForms() {
/*  216 */     return HTMLCollectionImpl.getImpl(getFormsImpl(getPeer()));
/*      */   }
/*      */   static native long getFormsImpl(long paramLong);
/*      */   
/*      */   public HTMLCollection getAnchors() {
/*  221 */     return HTMLCollectionImpl.getImpl(getAnchorsImpl(getPeer()));
/*      */   }
/*      */   static native long getAnchorsImpl(long paramLong);
/*      */   
/*      */   public String getLastModified() {
/*  226 */     return getLastModifiedImpl(getPeer());
/*      */   }
/*      */   static native String getLastModifiedImpl(long paramLong);
/*      */   
/*      */   public String getCharset() {
/*  231 */     return getCharsetImpl(getPeer());
/*      */   }
/*      */   static native String getCharsetImpl(long paramLong);
/*      */   
/*      */   public String getDefaultCharset() {
/*  236 */     return getDefaultCharsetImpl(getPeer());
/*      */   }
/*      */   static native String getDefaultCharsetImpl(long paramLong);
/*      */   
/*      */   public String getReadyState() {
/*  241 */     return getReadyStateImpl(getPeer());
/*      */   }
/*      */   static native String getReadyStateImpl(long paramLong);
/*      */   
/*      */   public String getCharacterSet() {
/*  246 */     return getCharacterSetImpl(getPeer());
/*      */   }
/*      */   static native String getCharacterSetImpl(long paramLong);
/*      */   
/*      */   public String getPreferredStylesheetSet() {
/*  251 */     return getPreferredStylesheetSetImpl(getPeer());
/*      */   }
/*      */   static native String getPreferredStylesheetSetImpl(long paramLong);
/*      */   
/*      */   public String getSelectedStylesheetSet() {
/*  256 */     return getSelectedStylesheetSetImpl(getPeer());
/*      */   }
/*      */   static native String getSelectedStylesheetSetImpl(long paramLong);
/*      */   
/*      */   public void setSelectedStylesheetSet(String paramString) {
/*  261 */     setSelectedStylesheetSetImpl(getPeer(), paramString);
/*      */   }
/*      */   static native void setSelectedStylesheetSetImpl(long paramLong, String paramString);
/*      */   
/*      */   public Element getActiveElement() {
/*  266 */     return ElementImpl.getImpl(getActiveElementImpl(getPeer()));
/*      */   }
/*      */   static native long getActiveElementImpl(long paramLong);
/*      */   
/*      */   public String getCompatMode() {
/*  271 */     return getCompatModeImpl(getPeer());
/*      */   }
/*      */   static native String getCompatModeImpl(long paramLong);
/*      */   
/*      */   public boolean getWebkitIsFullScreen() {
/*  276 */     return getWebkitIsFullScreenImpl(getPeer());
/*      */   }
/*      */   static native boolean getWebkitIsFullScreenImpl(long paramLong);
/*      */   
/*      */   public boolean getWebkitFullScreenKeyboardInputAllowed() {
/*  281 */     return getWebkitFullScreenKeyboardInputAllowedImpl(getPeer());
/*      */   }
/*      */   static native boolean getWebkitFullScreenKeyboardInputAllowedImpl(long paramLong);
/*      */   
/*      */   public Element getWebkitCurrentFullScreenElement() {
/*  286 */     return ElementImpl.getImpl(getWebkitCurrentFullScreenElementImpl(getPeer()));
/*      */   }
/*      */   static native long getWebkitCurrentFullScreenElementImpl(long paramLong);
/*      */   
/*      */   public boolean getWebkitFullscreenEnabled() {
/*  291 */     return getWebkitFullscreenEnabledImpl(getPeer());
/*      */   }
/*      */   static native boolean getWebkitFullscreenEnabledImpl(long paramLong);
/*      */   
/*      */   public Element getWebkitFullscreenElement() {
/*  296 */     return ElementImpl.getImpl(getWebkitFullscreenElementImpl(getPeer()));
/*      */   }
/*      */   static native long getWebkitFullscreenElementImpl(long paramLong);
/*      */   
/*      */   public String getVisibilityState() {
/*  301 */     return getVisibilityStateImpl(getPeer());
/*      */   }
/*      */   static native String getVisibilityStateImpl(long paramLong);
/*      */   
/*      */   public boolean getHidden() {
/*  306 */     return getHiddenImpl(getPeer());
/*      */   }
/*      */   static native boolean getHiddenImpl(long paramLong);
/*      */   
/*      */   public HTMLScriptElement getCurrentScript() {
/*  311 */     return HTMLScriptElementImpl.getImpl(getCurrentScriptImpl(getPeer()));
/*      */   }
/*      */   static native long getCurrentScriptImpl(long paramLong);
/*      */   
/*      */   public String getOrigin() {
/*  316 */     return getOriginImpl(getPeer());
/*      */   }
/*      */   static native String getOriginImpl(long paramLong);
/*      */   
/*      */   public Element getScrollingElement() {
/*  321 */     return ElementImpl.getImpl(getScrollingElementImpl(getPeer()));
/*      */   }
/*      */   static native long getScrollingElementImpl(long paramLong);
/*      */   
/*      */   public EventListener getOnbeforecopy() {
/*  326 */     return EventListenerImpl.getImpl(getOnbeforecopyImpl(getPeer()));
/*      */   }
/*      */   static native long getOnbeforecopyImpl(long paramLong);
/*      */   
/*      */   public void setOnbeforecopy(EventListener paramEventListener) {
/*  331 */     setOnbeforecopyImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnbeforecopyImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnbeforecut() {
/*  336 */     return EventListenerImpl.getImpl(getOnbeforecutImpl(getPeer()));
/*      */   }
/*      */   static native long getOnbeforecutImpl(long paramLong);
/*      */   
/*      */   public void setOnbeforecut(EventListener paramEventListener) {
/*  341 */     setOnbeforecutImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnbeforecutImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnbeforepaste() {
/*  346 */     return EventListenerImpl.getImpl(getOnbeforepasteImpl(getPeer()));
/*      */   }
/*      */   static native long getOnbeforepasteImpl(long paramLong);
/*      */   
/*      */   public void setOnbeforepaste(EventListener paramEventListener) {
/*  351 */     setOnbeforepasteImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnbeforepasteImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOncopy() {
/*  356 */     return EventListenerImpl.getImpl(getOncopyImpl(getPeer()));
/*      */   }
/*      */   static native long getOncopyImpl(long paramLong);
/*      */   
/*      */   public void setOncopy(EventListener paramEventListener) {
/*  361 */     setOncopyImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOncopyImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOncut() {
/*  366 */     return EventListenerImpl.getImpl(getOncutImpl(getPeer()));
/*      */   }
/*      */   static native long getOncutImpl(long paramLong);
/*      */   
/*      */   public void setOncut(EventListener paramEventListener) {
/*  371 */     setOncutImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOncutImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnpaste() {
/*  376 */     return EventListenerImpl.getImpl(getOnpasteImpl(getPeer()));
/*      */   }
/*      */   static native long getOnpasteImpl(long paramLong);
/*      */   
/*      */   public void setOnpaste(EventListener paramEventListener) {
/*  381 */     setOnpasteImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnpasteImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnselectstart() {
/*  386 */     return EventListenerImpl.getImpl(getOnselectstartImpl(getPeer()));
/*      */   }
/*      */   static native long getOnselectstartImpl(long paramLong);
/*      */   
/*      */   public void setOnselectstart(EventListener paramEventListener) {
/*  391 */     setOnselectstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnselectstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnselectionchange() {
/*  396 */     return EventListenerImpl.getImpl(getOnselectionchangeImpl(getPeer()));
/*      */   }
/*      */   static native long getOnselectionchangeImpl(long paramLong);
/*      */   
/*      */   public void setOnselectionchange(EventListener paramEventListener) {
/*  401 */     setOnselectionchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnselectionchangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnreadystatechange() {
/*  406 */     return EventListenerImpl.getImpl(getOnreadystatechangeImpl(getPeer()));
/*      */   }
/*      */   static native long getOnreadystatechangeImpl(long paramLong);
/*      */   
/*      */   public void setOnreadystatechange(EventListener paramEventListener) {
/*  411 */     setOnreadystatechangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnreadystatechangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnabort() {
/*  416 */     return EventListenerImpl.getImpl(getOnabortImpl(getPeer()));
/*      */   }
/*      */   static native long getOnabortImpl(long paramLong);
/*      */   
/*      */   public void setOnabort(EventListener paramEventListener) {
/*  421 */     setOnabortImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnabortImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnblur() {
/*  426 */     return EventListenerImpl.getImpl(getOnblurImpl(getPeer()));
/*      */   }
/*      */   static native long getOnblurImpl(long paramLong);
/*      */   
/*      */   public void setOnblur(EventListener paramEventListener) {
/*  431 */     setOnblurImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnblurImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOncanplay() {
/*  436 */     return EventListenerImpl.getImpl(getOncanplayImpl(getPeer()));
/*      */   }
/*      */   static native long getOncanplayImpl(long paramLong);
/*      */   
/*      */   public void setOncanplay(EventListener paramEventListener) {
/*  441 */     setOncanplayImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOncanplayImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOncanplaythrough() {
/*  446 */     return EventListenerImpl.getImpl(getOncanplaythroughImpl(getPeer()));
/*      */   }
/*      */   static native long getOncanplaythroughImpl(long paramLong);
/*      */   
/*      */   public void setOncanplaythrough(EventListener paramEventListener) {
/*  451 */     setOncanplaythroughImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOncanplaythroughImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnchange() {
/*  456 */     return EventListenerImpl.getImpl(getOnchangeImpl(getPeer()));
/*      */   }
/*      */   static native long getOnchangeImpl(long paramLong);
/*      */   
/*      */   public void setOnchange(EventListener paramEventListener) {
/*  461 */     setOnchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnchangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnclick() {
/*  466 */     return EventListenerImpl.getImpl(getOnclickImpl(getPeer()));
/*      */   }
/*      */   static native long getOnclickImpl(long paramLong);
/*      */   
/*      */   public void setOnclick(EventListener paramEventListener) {
/*  471 */     setOnclickImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnclickImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOncontextmenu() {
/*  476 */     return EventListenerImpl.getImpl(getOncontextmenuImpl(getPeer()));
/*      */   }
/*      */   static native long getOncontextmenuImpl(long paramLong);
/*      */   
/*      */   public void setOncontextmenu(EventListener paramEventListener) {
/*  481 */     setOncontextmenuImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOncontextmenuImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndblclick() {
/*  486 */     return EventListenerImpl.getImpl(getOndblclickImpl(getPeer()));
/*      */   }
/*      */   static native long getOndblclickImpl(long paramLong);
/*      */   
/*      */   public void setOndblclick(EventListener paramEventListener) {
/*  491 */     setOndblclickImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndblclickImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndrag() {
/*  496 */     return EventListenerImpl.getImpl(getOndragImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragImpl(long paramLong);
/*      */   
/*      */   public void setOndrag(EventListener paramEventListener) {
/*  501 */     setOndragImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndragend() {
/*  506 */     return EventListenerImpl.getImpl(getOndragendImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragendImpl(long paramLong);
/*      */   
/*      */   public void setOndragend(EventListener paramEventListener) {
/*  511 */     setOndragendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndragenter() {
/*  516 */     return EventListenerImpl.getImpl(getOndragenterImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragenterImpl(long paramLong);
/*      */   
/*      */   public void setOndragenter(EventListener paramEventListener) {
/*  521 */     setOndragenterImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragenterImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndragleave() {
/*  526 */     return EventListenerImpl.getImpl(getOndragleaveImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragleaveImpl(long paramLong);
/*      */   
/*      */   public void setOndragleave(EventListener paramEventListener) {
/*  531 */     setOndragleaveImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragleaveImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndragover() {
/*  536 */     return EventListenerImpl.getImpl(getOndragoverImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragoverImpl(long paramLong);
/*      */   
/*      */   public void setOndragover(EventListener paramEventListener) {
/*  541 */     setOndragoverImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragoverImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndragstart() {
/*  546 */     return EventListenerImpl.getImpl(getOndragstartImpl(getPeer()));
/*      */   }
/*      */   static native long getOndragstartImpl(long paramLong);
/*      */   
/*      */   public void setOndragstart(EventListener paramEventListener) {
/*  551 */     setOndragstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndragstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndrop() {
/*  556 */     return EventListenerImpl.getImpl(getOndropImpl(getPeer()));
/*      */   }
/*      */   static native long getOndropImpl(long paramLong);
/*      */   
/*      */   public void setOndrop(EventListener paramEventListener) {
/*  561 */     setOndropImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndropImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOndurationchange() {
/*  566 */     return EventListenerImpl.getImpl(getOndurationchangeImpl(getPeer()));
/*      */   }
/*      */   static native long getOndurationchangeImpl(long paramLong);
/*      */   
/*      */   public void setOndurationchange(EventListener paramEventListener) {
/*  571 */     setOndurationchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOndurationchangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnemptied() {
/*  576 */     return EventListenerImpl.getImpl(getOnemptiedImpl(getPeer()));
/*      */   }
/*      */   static native long getOnemptiedImpl(long paramLong);
/*      */   
/*      */   public void setOnemptied(EventListener paramEventListener) {
/*  581 */     setOnemptiedImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnemptiedImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnended() {
/*  586 */     return EventListenerImpl.getImpl(getOnendedImpl(getPeer()));
/*      */   }
/*      */   static native long getOnendedImpl(long paramLong);
/*      */   
/*      */   public void setOnended(EventListener paramEventListener) {
/*  591 */     setOnendedImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnendedImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnerror() {
/*  596 */     return EventListenerImpl.getImpl(getOnerrorImpl(getPeer()));
/*      */   }
/*      */   static native long getOnerrorImpl(long paramLong);
/*      */   
/*      */   public void setOnerror(EventListener paramEventListener) {
/*  601 */     setOnerrorImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnerrorImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnfocus() {
/*  606 */     return EventListenerImpl.getImpl(getOnfocusImpl(getPeer()));
/*      */   }
/*      */   static native long getOnfocusImpl(long paramLong);
/*      */   
/*      */   public void setOnfocus(EventListener paramEventListener) {
/*  611 */     setOnfocusImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnfocusImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOninput() {
/*  616 */     return EventListenerImpl.getImpl(getOninputImpl(getPeer()));
/*      */   }
/*      */   static native long getOninputImpl(long paramLong);
/*      */   
/*      */   public void setOninput(EventListener paramEventListener) {
/*  621 */     setOninputImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOninputImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOninvalid() {
/*  626 */     return EventListenerImpl.getImpl(getOninvalidImpl(getPeer()));
/*      */   }
/*      */   static native long getOninvalidImpl(long paramLong);
/*      */   
/*      */   public void setOninvalid(EventListener paramEventListener) {
/*  631 */     setOninvalidImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOninvalidImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnkeydown() {
/*  636 */     return EventListenerImpl.getImpl(getOnkeydownImpl(getPeer()));
/*      */   }
/*      */   static native long getOnkeydownImpl(long paramLong);
/*      */   
/*      */   public void setOnkeydown(EventListener paramEventListener) {
/*  641 */     setOnkeydownImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnkeydownImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnkeypress() {
/*  646 */     return EventListenerImpl.getImpl(getOnkeypressImpl(getPeer()));
/*      */   }
/*      */   static native long getOnkeypressImpl(long paramLong);
/*      */   
/*      */   public void setOnkeypress(EventListener paramEventListener) {
/*  651 */     setOnkeypressImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnkeypressImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnkeyup() {
/*  656 */     return EventListenerImpl.getImpl(getOnkeyupImpl(getPeer()));
/*      */   }
/*      */   static native long getOnkeyupImpl(long paramLong);
/*      */   
/*      */   public void setOnkeyup(EventListener paramEventListener) {
/*  661 */     setOnkeyupImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnkeyupImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnload() {
/*  666 */     return EventListenerImpl.getImpl(getOnloadImpl(getPeer()));
/*      */   }
/*      */   static native long getOnloadImpl(long paramLong);
/*      */   
/*      */   public void setOnload(EventListener paramEventListener) {
/*  671 */     setOnloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnloadImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnloadeddata() {
/*  676 */     return EventListenerImpl.getImpl(getOnloadeddataImpl(getPeer()));
/*      */   }
/*      */   static native long getOnloadeddataImpl(long paramLong);
/*      */   
/*      */   public void setOnloadeddata(EventListener paramEventListener) {
/*  681 */     setOnloadeddataImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnloadeddataImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnloadedmetadata() {
/*  686 */     return EventListenerImpl.getImpl(getOnloadedmetadataImpl(getPeer()));
/*      */   }
/*      */   static native long getOnloadedmetadataImpl(long paramLong);
/*      */   
/*      */   public void setOnloadedmetadata(EventListener paramEventListener) {
/*  691 */     setOnloadedmetadataImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnloadedmetadataImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnloadstart() {
/*  696 */     return EventListenerImpl.getImpl(getOnloadstartImpl(getPeer()));
/*      */   }
/*      */   static native long getOnloadstartImpl(long paramLong);
/*      */   
/*      */   public void setOnloadstart(EventListener paramEventListener) {
/*  701 */     setOnloadstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnloadstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmousedown() {
/*  706 */     return EventListenerImpl.getImpl(getOnmousedownImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmousedownImpl(long paramLong);
/*      */   
/*      */   public void setOnmousedown(EventListener paramEventListener) {
/*  711 */     setOnmousedownImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmousedownImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmouseenter() {
/*  716 */     return EventListenerImpl.getImpl(getOnmouseenterImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmouseenterImpl(long paramLong);
/*      */   
/*      */   public void setOnmouseenter(EventListener paramEventListener) {
/*  721 */     setOnmouseenterImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmouseenterImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmouseleave() {
/*  726 */     return EventListenerImpl.getImpl(getOnmouseleaveImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmouseleaveImpl(long paramLong);
/*      */   
/*      */   public void setOnmouseleave(EventListener paramEventListener) {
/*  731 */     setOnmouseleaveImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmouseleaveImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmousemove() {
/*  736 */     return EventListenerImpl.getImpl(getOnmousemoveImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmousemoveImpl(long paramLong);
/*      */   
/*      */   public void setOnmousemove(EventListener paramEventListener) {
/*  741 */     setOnmousemoveImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmousemoveImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmouseout() {
/*  746 */     return EventListenerImpl.getImpl(getOnmouseoutImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmouseoutImpl(long paramLong);
/*      */   
/*      */   public void setOnmouseout(EventListener paramEventListener) {
/*  751 */     setOnmouseoutImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmouseoutImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmouseover() {
/*  756 */     return EventListenerImpl.getImpl(getOnmouseoverImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmouseoverImpl(long paramLong);
/*      */   
/*      */   public void setOnmouseover(EventListener paramEventListener) {
/*  761 */     setOnmouseoverImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmouseoverImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmouseup() {
/*  766 */     return EventListenerImpl.getImpl(getOnmouseupImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmouseupImpl(long paramLong);
/*      */   
/*      */   public void setOnmouseup(EventListener paramEventListener) {
/*  771 */     setOnmouseupImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmouseupImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnmousewheel() {
/*  776 */     return EventListenerImpl.getImpl(getOnmousewheelImpl(getPeer()));
/*      */   }
/*      */   static native long getOnmousewheelImpl(long paramLong);
/*      */   
/*      */   public void setOnmousewheel(EventListener paramEventListener) {
/*  781 */     setOnmousewheelImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnmousewheelImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnpause() {
/*  786 */     return EventListenerImpl.getImpl(getOnpauseImpl(getPeer()));
/*      */   }
/*      */   static native long getOnpauseImpl(long paramLong);
/*      */   
/*      */   public void setOnpause(EventListener paramEventListener) {
/*  791 */     setOnpauseImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnpauseImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnplay() {
/*  796 */     return EventListenerImpl.getImpl(getOnplayImpl(getPeer()));
/*      */   }
/*      */   static native long getOnplayImpl(long paramLong);
/*      */   
/*      */   public void setOnplay(EventListener paramEventListener) {
/*  801 */     setOnplayImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnplayImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnplaying() {
/*  806 */     return EventListenerImpl.getImpl(getOnplayingImpl(getPeer()));
/*      */   }
/*      */   static native long getOnplayingImpl(long paramLong);
/*      */   
/*      */   public void setOnplaying(EventListener paramEventListener) {
/*  811 */     setOnplayingImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnplayingImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnprogress() {
/*  816 */     return EventListenerImpl.getImpl(getOnprogressImpl(getPeer()));
/*      */   }
/*      */   static native long getOnprogressImpl(long paramLong);
/*      */   
/*      */   public void setOnprogress(EventListener paramEventListener) {
/*  821 */     setOnprogressImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnprogressImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnratechange() {
/*  826 */     return EventListenerImpl.getImpl(getOnratechangeImpl(getPeer()));
/*      */   }
/*      */   static native long getOnratechangeImpl(long paramLong);
/*      */   
/*      */   public void setOnratechange(EventListener paramEventListener) {
/*  831 */     setOnratechangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnratechangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnreset() {
/*  836 */     return EventListenerImpl.getImpl(getOnresetImpl(getPeer()));
/*      */   }
/*      */   static native long getOnresetImpl(long paramLong);
/*      */   
/*      */   public void setOnreset(EventListener paramEventListener) {
/*  841 */     setOnresetImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnresetImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnresize() {
/*  846 */     return EventListenerImpl.getImpl(getOnresizeImpl(getPeer()));
/*      */   }
/*      */   static native long getOnresizeImpl(long paramLong);
/*      */   
/*      */   public void setOnresize(EventListener paramEventListener) {
/*  851 */     setOnresizeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnresizeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnscroll() {
/*  856 */     return EventListenerImpl.getImpl(getOnscrollImpl(getPeer()));
/*      */   }
/*      */   static native long getOnscrollImpl(long paramLong);
/*      */   
/*      */   public void setOnscroll(EventListener paramEventListener) {
/*  861 */     setOnscrollImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnscrollImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnseeked() {
/*  866 */     return EventListenerImpl.getImpl(getOnseekedImpl(getPeer()));
/*      */   }
/*      */   static native long getOnseekedImpl(long paramLong);
/*      */   
/*      */   public void setOnseeked(EventListener paramEventListener) {
/*  871 */     setOnseekedImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnseekedImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnseeking() {
/*  876 */     return EventListenerImpl.getImpl(getOnseekingImpl(getPeer()));
/*      */   }
/*      */   static native long getOnseekingImpl(long paramLong);
/*      */   
/*      */   public void setOnseeking(EventListener paramEventListener) {
/*  881 */     setOnseekingImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnseekingImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnselect() {
/*  886 */     return EventListenerImpl.getImpl(getOnselectImpl(getPeer()));
/*      */   }
/*      */   static native long getOnselectImpl(long paramLong);
/*      */   
/*      */   public void setOnselect(EventListener paramEventListener) {
/*  891 */     setOnselectImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnselectImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnstalled() {
/*  896 */     return EventListenerImpl.getImpl(getOnstalledImpl(getPeer()));
/*      */   }
/*      */   static native long getOnstalledImpl(long paramLong);
/*      */   
/*      */   public void setOnstalled(EventListener paramEventListener) {
/*  901 */     setOnstalledImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnstalledImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnsubmit() {
/*  906 */     return EventListenerImpl.getImpl(getOnsubmitImpl(getPeer()));
/*      */   }
/*      */   static native long getOnsubmitImpl(long paramLong);
/*      */   
/*      */   public void setOnsubmit(EventListener paramEventListener) {
/*  911 */     setOnsubmitImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnsubmitImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnsuspend() {
/*  916 */     return EventListenerImpl.getImpl(getOnsuspendImpl(getPeer()));
/*      */   }
/*      */   static native long getOnsuspendImpl(long paramLong);
/*      */   
/*      */   public void setOnsuspend(EventListener paramEventListener) {
/*  921 */     setOnsuspendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnsuspendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOntimeupdate() {
/*  926 */     return EventListenerImpl.getImpl(getOntimeupdateImpl(getPeer()));
/*      */   }
/*      */   static native long getOntimeupdateImpl(long paramLong);
/*      */   
/*      */   public void setOntimeupdate(EventListener paramEventListener) {
/*  931 */     setOntimeupdateImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOntimeupdateImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnvolumechange() {
/*  936 */     return EventListenerImpl.getImpl(getOnvolumechangeImpl(getPeer()));
/*      */   }
/*      */   static native long getOnvolumechangeImpl(long paramLong);
/*      */   
/*      */   public void setOnvolumechange(EventListener paramEventListener) {
/*  941 */     setOnvolumechangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnvolumechangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnwaiting() {
/*  946 */     return EventListenerImpl.getImpl(getOnwaitingImpl(getPeer()));
/*      */   }
/*      */   static native long getOnwaitingImpl(long paramLong);
/*      */   
/*      */   public void setOnwaiting(EventListener paramEventListener) {
/*  951 */     setOnwaitingImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnwaitingImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnsearch() {
/*  956 */     return EventListenerImpl.getImpl(getOnsearchImpl(getPeer()));
/*      */   }
/*      */   static native long getOnsearchImpl(long paramLong);
/*      */   
/*      */   public void setOnsearch(EventListener paramEventListener) {
/*  961 */     setOnsearchImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnsearchImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public EventListener getOnwheel() {
/*  966 */     return EventListenerImpl.getImpl(getOnwheelImpl(getPeer()));
/*      */   }
/*      */   static native long getOnwheelImpl(long paramLong);
/*      */   
/*      */   public void setOnwheel(EventListener paramEventListener) {
/*  971 */     setOnwheelImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */   static native void setOnwheelImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   public HTMLCollection getChildren() {
/*  976 */     return HTMLCollectionImpl.getImpl(getChildrenImpl(getPeer()));
/*      */   }
/*      */   static native long getChildrenImpl(long paramLong);
/*      */   
/*      */   public Element getFirstElementChild() {
/*  981 */     return ElementImpl.getImpl(getFirstElementChildImpl(getPeer()));
/*      */   }
/*      */   static native long getFirstElementChildImpl(long paramLong);
/*      */   
/*      */   public Element getLastElementChild() {
/*  986 */     return ElementImpl.getImpl(getLastElementChildImpl(getPeer()));
/*      */   }
/*      */   static native long getLastElementChildImpl(long paramLong);
/*      */   
/*      */   public int getChildElementCount() {
/*  991 */     return getChildElementCountImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   static native int getChildElementCountImpl(long paramLong);
/*      */ 
/*      */   
/*      */   public Element createElement(String paramString) throws DOMException {
/*  999 */     return ElementImpl.getImpl(createElementImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createElementImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public DocumentFragment createDocumentFragment() {
/* 1008 */     return DocumentFragmentImpl.getImpl(createDocumentFragmentImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   static native long createDocumentFragmentImpl(long paramLong);
/*      */   
/*      */   public Text createTextNode(String paramString) {
/* 1015 */     return TextImpl.getImpl(createTextNodeImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createTextNodeImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public Comment createComment(String paramString) {
/* 1024 */     return CommentImpl.getImpl(createCommentImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createCommentImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public CDATASection createCDATASection(String paramString) throws DOMException {
/* 1033 */     return CDATASectionImpl.getImpl(createCDATASectionImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createCDATASectionImpl(long paramLong, String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public ProcessingInstruction createProcessingInstruction(String paramString1, String paramString2) throws DOMException {
/* 1043 */     return (ProcessingInstruction)ProcessingInstructionImpl.getImpl(createProcessingInstructionImpl(getPeer(), paramString1, paramString2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createProcessingInstructionImpl(long paramLong, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */   
/*      */   public Attr createAttribute(String paramString) throws DOMException {
/* 1054 */     return AttrImpl.getImpl(createAttributeImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createAttributeImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public EntityReference createEntityReference(String paramString) throws DOMException {
/* 1063 */     return EntityReferenceImpl.getImpl(createEntityReferenceImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createEntityReferenceImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public NodeList getElementsByTagName(String paramString) {
/* 1072 */     return NodeListImpl.getImpl(getElementsByTagNameImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getElementsByTagNameImpl(long paramLong, String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public Node importNode(Node paramNode, boolean paramBoolean) throws DOMException {
/* 1082 */     return NodeImpl.getImpl(importNodeImpl(getPeer(), 
/* 1083 */           NodeImpl.getPeer(paramNode), paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long importNodeImpl(long paramLong1, long paramLong2, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public Element createElementNS(String paramString1, String paramString2) throws DOMException {
/* 1094 */     return ElementImpl.getImpl(createElementNSImpl(getPeer(), paramString1, paramString2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createElementNSImpl(long paramLong, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Attr createAttributeNS(String paramString1, String paramString2) throws DOMException {
/* 1106 */     return AttrImpl.getImpl(createAttributeNSImpl(getPeer(), paramString1, paramString2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createAttributeNSImpl(long paramLong, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NodeList getElementsByTagNameNS(String paramString1, String paramString2) {
/* 1118 */     return NodeListImpl.getImpl(getElementsByTagNameNSImpl(getPeer(), paramString1, paramString2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getElementsByTagNameNSImpl(long paramLong, String paramString1, String paramString2);
/*      */ 
/*      */ 
/*      */   
/*      */   public Node adoptNode(Node paramNode) throws DOMException {
/* 1129 */     return NodeImpl.getImpl(adoptNodeImpl(getPeer(), 
/* 1130 */           NodeImpl.getPeer(paramNode)));
/*      */   }
/*      */ 
/*      */   
/*      */   static native long adoptNodeImpl(long paramLong1, long paramLong2);
/*      */ 
/*      */   
/*      */   public Event createEvent(String paramString) throws DOMException {
/* 1138 */     return EventImpl.getImpl(createEventImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createEventImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public Range createRange() {
/* 1147 */     return RangeImpl.getImpl(createRangeImpl(getPeer()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createRangeImpl(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public NodeIterator createNodeIterator(Node paramNode, int paramInt, NodeFilter paramNodeFilter, boolean paramBoolean) throws DOMException {
/* 1157 */     return NodeIteratorImpl.getImpl(createNodeIteratorImpl(getPeer(), 
/* 1158 */           NodeImpl.getPeer(paramNode), paramInt, 
/*      */           
/* 1160 */           NodeFilterImpl.getPeer(paramNodeFilter), paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createNodeIteratorImpl(long paramLong1, long paramLong2, int paramInt, long paramLong3, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TreeWalker createTreeWalker(Node paramNode, int paramInt, NodeFilter paramNodeFilter, boolean paramBoolean) throws DOMException {
/* 1175 */     return TreeWalkerImpl.getImpl(createTreeWalkerImpl(getPeer(), 
/* 1176 */           NodeImpl.getPeer(paramNode), paramInt, 
/*      */           
/* 1178 */           NodeFilterImpl.getPeer(paramNodeFilter), paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createTreeWalkerImpl(long paramLong1, long paramLong2, int paramInt, long paramLong3, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CSSStyleDeclaration getOverrideStyle(Element paramElement, String paramString) {
/* 1191 */     return CSSStyleDeclarationImpl.getImpl(getOverrideStyleImpl(getPeer(), 
/* 1192 */           ElementImpl.getPeer(paramElement), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getOverrideStyleImpl(long paramLong1, long paramLong2, String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public XPathExpression createExpression(String paramString, XPathNSResolver paramXPathNSResolver) throws DOMException {
/* 1203 */     return XPathExpressionImpl.getImpl(createExpressionImpl(getPeer(), paramString, 
/*      */           
/* 1205 */           XPathNSResolverImpl.getPeer(paramXPathNSResolver)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createExpressionImpl(long paramLong1, String paramString, long paramLong2);
/*      */ 
/*      */   
/*      */   public XPathNSResolver createNSResolver(Node paramNode) {
/* 1214 */     return XPathNSResolverImpl.getImpl(createNSResolverImpl(getPeer(), 
/* 1215 */           NodeImpl.getPeer(paramNode)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long createNSResolverImpl(long paramLong1, long paramLong2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XPathResult evaluate(String paramString, Node paramNode, XPathNSResolver paramXPathNSResolver, short paramShort, XPathResult paramXPathResult) throws DOMException {
/* 1227 */     return XPathResultImpl.getImpl(evaluateImpl(getPeer(), paramString, 
/*      */           
/* 1229 */           NodeImpl.getPeer(paramNode), 
/* 1230 */           XPathNSResolverImpl.getPeer(paramXPathNSResolver), paramShort, 
/*      */           
/* 1232 */           XPathResultImpl.getPeer(paramXPathResult)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long evaluateImpl(long paramLong1, String paramString, long paramLong2, long paramLong3, short paramShort, long paramLong4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execCommand(String paramString1, boolean paramBoolean, String paramString2) {
/* 1246 */     return execCommandImpl(getPeer(), paramString1, paramBoolean, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native boolean execCommandImpl(long paramLong, String paramString1, boolean paramBoolean, String paramString2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean queryCommandEnabled(String paramString) {
/* 1259 */     return queryCommandEnabledImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native boolean queryCommandEnabledImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public boolean queryCommandIndeterm(String paramString) {
/* 1268 */     return queryCommandIndetermImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native boolean queryCommandIndetermImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public boolean queryCommandState(String paramString) {
/* 1277 */     return queryCommandStateImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native boolean queryCommandStateImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public boolean queryCommandSupported(String paramString) {
/* 1286 */     return queryCommandSupportedImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native boolean queryCommandSupportedImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public String queryCommandValue(String paramString) {
/* 1295 */     return queryCommandValueImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native String queryCommandValueImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public NodeList getElementsByName(String paramString) {
/* 1304 */     return NodeListImpl.getImpl(getElementsByNameImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getElementsByNameImpl(long paramLong, String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public Element elementFromPoint(int paramInt1, int paramInt2) {
/* 1314 */     return ElementImpl.getImpl(elementFromPointImpl(getPeer(), paramInt1, paramInt2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long elementFromPointImpl(long paramLong, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Range caretRangeFromPoint(int paramInt1, int paramInt2) {
/* 1326 */     return RangeImpl.getImpl(caretRangeFromPointImpl(getPeer(), paramInt1, paramInt2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native long caretRangeFromPointImpl(long paramLong, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */   
/*      */   public CSSStyleDeclaration createCSSStyleDeclaration() {
/* 1337 */     return CSSStyleDeclarationImpl.getImpl(createCSSStyleDeclarationImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   static native long createCSSStyleDeclarationImpl(long paramLong);
/*      */   
/*      */   public HTMLCollection getElementsByClassName(String paramString) {
/* 1344 */     return HTMLCollectionImpl.getImpl(getElementsByClassNameImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getElementsByClassNameImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public boolean hasFocus() {
/* 1353 */     return hasFocusImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   static native boolean hasFocusImpl(long paramLong);
/*      */   
/*      */   public void webkitCancelFullScreen() {
/* 1360 */     webkitCancelFullScreenImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   static native void webkitCancelFullScreenImpl(long paramLong);
/*      */   
/*      */   public void webkitExitFullscreen() {
/* 1367 */     webkitExitFullscreenImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   static native void webkitExitFullscreenImpl(long paramLong);
/*      */   
/*      */   public Element getElementById(String paramString) {
/* 1374 */     return ElementImpl.getImpl(getElementByIdImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long getElementByIdImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public Element querySelector(String paramString) throws DOMException {
/* 1383 */     return ElementImpl.getImpl(querySelectorImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long querySelectorImpl(long paramLong, String paramString);
/*      */ 
/*      */   
/*      */   public NodeList querySelectorAll(String paramString) throws DOMException {
/* 1392 */     return NodeListImpl.getImpl(querySelectorAllImpl(getPeer(), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static native long querySelectorAllImpl(long paramLong, String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getStrictErrorChecking() {
/* 1402 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */   public void setStrictErrorChecking(boolean paramBoolean) {
/* 1405 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */   public Node renameNode(Node paramNode, String paramString1, String paramString2) throws DOMException {
/* 1408 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */   public DOMConfiguration getDomConfig() {
/* 1411 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */   public void normalizeDocument() {
/* 1414 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\DocumentImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */