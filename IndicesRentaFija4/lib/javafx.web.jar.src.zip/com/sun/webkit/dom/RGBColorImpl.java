/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import com.sun.webkit.Disposer;
/*    */ import com.sun.webkit.DisposerRecord;
/*    */ import org.w3c.dom.css.CSSPrimitiveValue;
/*    */ import org.w3c.dom.css.RGBColor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RGBColorImpl
/*    */   implements RGBColor
/*    */ {
/*    */   private final long peer;
/*    */   
/*    */   private static class SelfDisposer
/*    */     implements DisposerRecord
/*    */   {
/*    */     private final long peer;
/*    */     
/*    */     SelfDisposer(long param1Long) {
/* 37 */       this.peer = param1Long;
/*    */     }
/*    */     public void dispose() {
/* 40 */       RGBColorImpl.dispose(this.peer);
/*    */     }
/*    */   }
/*    */   
/*    */   RGBColorImpl(long paramLong) {
/* 45 */     this.peer = paramLong;
/* 46 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*    */   }
/*    */   
/*    */   static RGBColor create(long paramLong) {
/* 50 */     if (paramLong == 0L) return null; 
/* 51 */     return new RGBColorImpl(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   long getPeer() {
/* 57 */     return this.peer;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 61 */     return (paramObject instanceof RGBColorImpl && this.peer == ((RGBColorImpl)paramObject).peer);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 65 */     long l = this.peer;
/* 66 */     return (int)(l ^ l >> 17L);
/*    */   }
/*    */   
/*    */   static long getPeer(RGBColor paramRGBColor) {
/* 70 */     return (paramRGBColor == null) ? 0L : ((RGBColorImpl)paramRGBColor).getPeer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static RGBColor getImpl(long paramLong) {
/* 76 */     return create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CSSPrimitiveValue getRed() {
/* 82 */     return CSSPrimitiveValueImpl.getImpl(getRedImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSPrimitiveValue getGreen() {
/* 87 */     return CSSPrimitiveValueImpl.getImpl(getGreenImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSPrimitiveValue getBlue() {
/* 92 */     return CSSPrimitiveValueImpl.getImpl(getBlueImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSPrimitiveValue getAlpha() {
/* 97 */     return CSSPrimitiveValueImpl.getImpl(getAlphaImpl(getPeer()));
/*    */   }
/*    */   
/*    */   private static native void dispose(long paramLong);
/*    */   
/*    */   static native long getRedImpl(long paramLong);
/*    */   
/*    */   static native long getGreenImpl(long paramLong);
/*    */   
/*    */   static native long getBlueImpl(long paramLong);
/*    */   
/*    */   static native long getAlphaImpl(long paramLong);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\RGBColorImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */