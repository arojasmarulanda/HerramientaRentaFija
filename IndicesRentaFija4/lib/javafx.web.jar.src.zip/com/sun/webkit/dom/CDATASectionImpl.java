/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.CDATASection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CDATASectionImpl
/*    */   extends TextImpl
/*    */   implements CDATASection
/*    */ {
/*    */   CDATASectionImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static CDATASection getImpl(long paramLong) {
/* 36 */     return (CDATASection)create(paramLong);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\CDATASectionImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */