/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLBRElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLBRElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLBRElement
/*    */ {
/*    */   HTMLBRElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLBRElement getImpl(long paramLong) {
/* 36 */     return (HTMLBRElement)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getClear() {
/* 42 */     return getClearImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setClear(String paramString) {
/* 47 */     setClearImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native String getClearImpl(long paramLong);
/*    */   
/*    */   static native void setClearImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLBRElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */