/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.Comment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommentImpl
/*    */   extends CharacterDataImpl
/*    */   implements Comment
/*    */ {
/*    */   CommentImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static Comment getImpl(long paramLong) {
/* 36 */     return (Comment)create(paramLong);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\CommentImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */