/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.events.EventListener;
/*     */ import org.w3c.dom.html.HTMLBodyElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLBodyElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLBodyElement
/*     */ {
/*     */   HTMLBodyElementImpl(long paramLong) {
/*  33 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLBodyElement getImpl(long paramLong) {
/*  37 */     return (HTMLBodyElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getALinkImpl(long paramLong);
/*     */   
/*     */   public String getALink() {
/*  43 */     return getALinkImpl(getPeer());
/*     */   }
/*     */   static native void setALinkImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setALink(String paramString) {
/*  48 */     setALinkImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBackground() {
/*  53 */     return getBackgroundImpl(getPeer());
/*     */   }
/*     */   static native String getBackgroundImpl(long paramLong);
/*     */   
/*     */   public void setBackground(String paramString) {
/*  58 */     setBackgroundImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setBackgroundImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getBgColor() {
/*  63 */     return getBgColorImpl(getPeer());
/*     */   }
/*     */   static native String getBgColorImpl(long paramLong);
/*     */   
/*     */   public void setBgColor(String paramString) {
/*  68 */     setBgColorImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setBgColorImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getLink() {
/*  73 */     return getLinkImpl(getPeer());
/*     */   }
/*     */   static native String getLinkImpl(long paramLong);
/*     */   
/*     */   public void setLink(String paramString) {
/*  78 */     setLinkImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setLinkImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getText() {
/*  83 */     return getTextImpl(getPeer());
/*     */   }
/*     */   static native String getTextImpl(long paramLong);
/*     */   
/*     */   public void setText(String paramString) {
/*  88 */     setTextImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTextImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getVLink() {
/*  93 */     return getVLinkImpl(getPeer());
/*     */   }
/*     */   static native String getVLinkImpl(long paramLong);
/*     */   
/*     */   public void setVLink(String paramString) {
/*  98 */     setVLinkImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setVLinkImpl(long paramLong, String paramString);
/*     */   
/*     */   public EventListener getOnblur() {
/* 103 */     return EventListenerImpl.getImpl(getOnblurImpl(getPeer()));
/*     */   }
/*     */   static native long getOnblurImpl(long paramLong);
/*     */   
/*     */   public void setOnblur(EventListener paramEventListener) {
/* 108 */     setOnblurImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnblurImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnerror() {
/* 113 */     return EventListenerImpl.getImpl(getOnerrorImpl(getPeer()));
/*     */   }
/*     */   static native long getOnerrorImpl(long paramLong);
/*     */   
/*     */   public void setOnerror(EventListener paramEventListener) {
/* 118 */     setOnerrorImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnerrorImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnfocus() {
/* 123 */     return EventListenerImpl.getImpl(getOnfocusImpl(getPeer()));
/*     */   }
/*     */   static native long getOnfocusImpl(long paramLong);
/*     */   
/*     */   public void setOnfocus(EventListener paramEventListener) {
/* 128 */     setOnfocusImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnfocusImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnfocusin() {
/* 133 */     return EventListenerImpl.getImpl(getOnfocusinImpl(getPeer()));
/*     */   }
/*     */   static native long getOnfocusinImpl(long paramLong);
/*     */   
/*     */   public void setOnfocusin(EventListener paramEventListener) {
/* 138 */     setOnfocusinImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnfocusinImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnfocusout() {
/* 143 */     return EventListenerImpl.getImpl(getOnfocusoutImpl(getPeer()));
/*     */   }
/*     */   static native long getOnfocusoutImpl(long paramLong);
/*     */   
/*     */   public void setOnfocusout(EventListener paramEventListener) {
/* 148 */     setOnfocusoutImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnfocusoutImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnload() {
/* 153 */     return EventListenerImpl.getImpl(getOnloadImpl(getPeer()));
/*     */   }
/*     */   static native long getOnloadImpl(long paramLong);
/*     */   
/*     */   public void setOnload(EventListener paramEventListener) {
/* 158 */     setOnloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnloadImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnresize() {
/* 163 */     return EventListenerImpl.getImpl(getOnresizeImpl(getPeer()));
/*     */   }
/*     */   static native long getOnresizeImpl(long paramLong);
/*     */   
/*     */   public void setOnresize(EventListener paramEventListener) {
/* 168 */     setOnresizeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnresizeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnscroll() {
/* 173 */     return EventListenerImpl.getImpl(getOnscrollImpl(getPeer()));
/*     */   }
/*     */   static native long getOnscrollImpl(long paramLong);
/*     */   
/*     */   public void setOnscroll(EventListener paramEventListener) {
/* 178 */     setOnscrollImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnscrollImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnselectionchange() {
/* 183 */     return EventListenerImpl.getImpl(getOnselectionchangeImpl(getPeer()));
/*     */   }
/*     */   static native long getOnselectionchangeImpl(long paramLong);
/*     */   
/*     */   public void setOnselectionchange(EventListener paramEventListener) {
/* 188 */     setOnselectionchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnselectionchangeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnbeforeunload() {
/* 193 */     return EventListenerImpl.getImpl(getOnbeforeunloadImpl(getPeer()));
/*     */   }
/*     */   static native long getOnbeforeunloadImpl(long paramLong);
/*     */   
/*     */   public void setOnbeforeunload(EventListener paramEventListener) {
/* 198 */     setOnbeforeunloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnbeforeunloadImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnhashchange() {
/* 203 */     return EventListenerImpl.getImpl(getOnhashchangeImpl(getPeer()));
/*     */   }
/*     */   static native long getOnhashchangeImpl(long paramLong);
/*     */   
/*     */   public void setOnhashchange(EventListener paramEventListener) {
/* 208 */     setOnhashchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnhashchangeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnmessage() {
/* 213 */     return EventListenerImpl.getImpl(getOnmessageImpl(getPeer()));
/*     */   }
/*     */   static native long getOnmessageImpl(long paramLong);
/*     */   
/*     */   public void setOnmessage(EventListener paramEventListener) {
/* 218 */     setOnmessageImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnmessageImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnoffline() {
/* 223 */     return EventListenerImpl.getImpl(getOnofflineImpl(getPeer()));
/*     */   }
/*     */   static native long getOnofflineImpl(long paramLong);
/*     */   
/*     */   public void setOnoffline(EventListener paramEventListener) {
/* 228 */     setOnofflineImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnofflineImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnonline() {
/* 233 */     return EventListenerImpl.getImpl(getOnonlineImpl(getPeer()));
/*     */   }
/*     */   static native long getOnonlineImpl(long paramLong);
/*     */   
/*     */   public void setOnonline(EventListener paramEventListener) {
/* 238 */     setOnonlineImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnonlineImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnpagehide() {
/* 243 */     return EventListenerImpl.getImpl(getOnpagehideImpl(getPeer()));
/*     */   }
/*     */   static native long getOnpagehideImpl(long paramLong);
/*     */   
/*     */   public void setOnpagehide(EventListener paramEventListener) {
/* 248 */     setOnpagehideImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnpagehideImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnpageshow() {
/* 253 */     return EventListenerImpl.getImpl(getOnpageshowImpl(getPeer()));
/*     */   }
/*     */   static native long getOnpageshowImpl(long paramLong);
/*     */   
/*     */   public void setOnpageshow(EventListener paramEventListener) {
/* 258 */     setOnpageshowImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnpageshowImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnpopstate() {
/* 263 */     return EventListenerImpl.getImpl(getOnpopstateImpl(getPeer()));
/*     */   }
/*     */   static native long getOnpopstateImpl(long paramLong);
/*     */   
/*     */   public void setOnpopstate(EventListener paramEventListener) {
/* 268 */     setOnpopstateImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnpopstateImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnstorage() {
/* 273 */     return EventListenerImpl.getImpl(getOnstorageImpl(getPeer()));
/*     */   }
/*     */   static native long getOnstorageImpl(long paramLong);
/*     */   
/*     */   public void setOnstorage(EventListener paramEventListener) {
/* 278 */     setOnstorageImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnstorageImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnunload() {
/* 283 */     return EventListenerImpl.getImpl(getOnunloadImpl(getPeer()));
/*     */   }
/*     */   static native long getOnunloadImpl(long paramLong);
/*     */   
/*     */   public void setOnunload(EventListener paramEventListener) {
/* 288 */     setOnunloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   
/*     */   static native void setOnunloadImpl(long paramLong1, long paramLong2);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLBodyElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */