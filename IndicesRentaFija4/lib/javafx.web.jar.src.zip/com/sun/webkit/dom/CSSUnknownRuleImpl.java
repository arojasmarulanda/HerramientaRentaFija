/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.css.CSSUnknownRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSSUnknownRuleImpl
/*    */   extends CSSRuleImpl
/*    */   implements CSSUnknownRule
/*    */ {
/*    */   CSSUnknownRuleImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static CSSUnknownRule getImpl(long paramLong) {
/* 36 */     return (CSSUnknownRule)create(paramLong);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSUnknownRuleImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */