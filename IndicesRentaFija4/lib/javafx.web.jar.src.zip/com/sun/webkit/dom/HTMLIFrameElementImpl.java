/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.html.HTMLIFrameElement;
/*     */ import org.w3c.dom.views.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLIFrameElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLIFrameElement
/*     */ {
/*     */   HTMLIFrameElementImpl(long paramLong) {
/*  34 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLIFrameElement getImpl(long paramLong) {
/*  38 */     return (HTMLIFrameElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getAlignImpl(long paramLong);
/*     */   
/*     */   public String getAlign() {
/*  44 */     return getAlignImpl(getPeer());
/*     */   }
/*     */   static native void setAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setAlign(String paramString) {
/*  49 */     setAlignImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFrameBorder() {
/*  54 */     return getFrameBorderImpl(getPeer());
/*     */   }
/*     */   static native String getFrameBorderImpl(long paramLong);
/*     */   
/*     */   public void setFrameBorder(String paramString) {
/*  59 */     setFrameBorderImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFrameBorderImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHeight() {
/*  64 */     return getHeightImpl(getPeer());
/*     */   }
/*     */   static native String getHeightImpl(long paramLong);
/*     */   
/*     */   public void setHeight(String paramString) {
/*  69 */     setHeightImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHeightImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getLongDesc() {
/*  74 */     return getLongDescImpl(getPeer());
/*     */   }
/*     */   static native String getLongDescImpl(long paramLong);
/*     */   
/*     */   public void setLongDesc(String paramString) {
/*  79 */     setLongDescImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setLongDescImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getMarginHeight() {
/*  84 */     return getMarginHeightImpl(getPeer());
/*     */   }
/*     */   static native String getMarginHeightImpl(long paramLong);
/*     */   
/*     */   public void setMarginHeight(String paramString) {
/*  89 */     setMarginHeightImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setMarginHeightImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getMarginWidth() {
/*  94 */     return getMarginWidthImpl(getPeer());
/*     */   }
/*     */   static native String getMarginWidthImpl(long paramLong);
/*     */   
/*     */   public void setMarginWidth(String paramString) {
/*  99 */     setMarginWidthImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setMarginWidthImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getName() {
/* 104 */     return getNameImpl(getPeer());
/*     */   }
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   public void setName(String paramString) {
/* 109 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getScrolling() {
/* 114 */     return getScrollingImpl(getPeer());
/*     */   }
/*     */   static native String getScrollingImpl(long paramLong);
/*     */   
/*     */   public void setScrolling(String paramString) {
/* 119 */     setScrollingImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setScrollingImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getSrc() {
/* 124 */     return getSrcImpl(getPeer());
/*     */   }
/*     */   static native String getSrcImpl(long paramLong);
/*     */   
/*     */   public void setSrc(String paramString) {
/* 129 */     setSrcImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSrcImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getSrcdoc() {
/* 134 */     return getSrcdocImpl(getPeer());
/*     */   }
/*     */   static native String getSrcdocImpl(long paramLong);
/*     */   
/*     */   public void setSrcdoc(String paramString) {
/* 139 */     setSrcdocImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSrcdocImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getWidth() {
/* 144 */     return getWidthImpl(getPeer());
/*     */   }
/*     */   static native String getWidthImpl(long paramLong);
/*     */   
/*     */   public void setWidth(String paramString) {
/* 149 */     setWidthImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setWidthImpl(long paramLong, String paramString);
/*     */   
/*     */   public Document getContentDocument() {
/* 154 */     return DocumentImpl.getImpl(getContentDocumentImpl(getPeer()));
/*     */   }
/*     */   static native long getContentDocumentImpl(long paramLong);
/*     */   
/*     */   public AbstractView getContentWindow() {
/* 159 */     return DOMWindowImpl.getImpl(getContentWindowImpl(getPeer()));
/*     */   }
/*     */   
/*     */   static native long getContentWindowImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLIFrameElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */