/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.html.HTMLFrameElement;
/*     */ import org.w3c.dom.views.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLFrameElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLFrameElement
/*     */ {
/*     */   HTMLFrameElementImpl(long paramLong) {
/*  34 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLFrameElement getImpl(long paramLong) {
/*  38 */     return (HTMLFrameElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getFrameBorderImpl(long paramLong);
/*     */   
/*     */   public String getFrameBorder() {
/*  44 */     return getFrameBorderImpl(getPeer());
/*     */   }
/*     */   static native void setFrameBorderImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setFrameBorder(String paramString) {
/*  49 */     setFrameBorderImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLongDesc() {
/*  54 */     return getLongDescImpl(getPeer());
/*     */   }
/*     */   static native String getLongDescImpl(long paramLong);
/*     */   
/*     */   public void setLongDesc(String paramString) {
/*  59 */     setLongDescImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setLongDescImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getMarginHeight() {
/*  64 */     return getMarginHeightImpl(getPeer());
/*     */   }
/*     */   static native String getMarginHeightImpl(long paramLong);
/*     */   
/*     */   public void setMarginHeight(String paramString) {
/*  69 */     setMarginHeightImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setMarginHeightImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getMarginWidth() {
/*  74 */     return getMarginWidthImpl(getPeer());
/*     */   }
/*     */   static native String getMarginWidthImpl(long paramLong);
/*     */   
/*     */   public void setMarginWidth(String paramString) {
/*  79 */     setMarginWidthImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setMarginWidthImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getName() {
/*  84 */     return getNameImpl(getPeer());
/*     */   }
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   public void setName(String paramString) {
/*  89 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getNoResize() {
/*  94 */     return getNoResizeImpl(getPeer());
/*     */   }
/*     */   static native boolean getNoResizeImpl(long paramLong);
/*     */   
/*     */   public void setNoResize(boolean paramBoolean) {
/*  99 */     setNoResizeImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setNoResizeImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getScrolling() {
/* 104 */     return getScrollingImpl(getPeer());
/*     */   }
/*     */   static native String getScrollingImpl(long paramLong);
/*     */   
/*     */   public void setScrolling(String paramString) {
/* 109 */     setScrollingImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setScrollingImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getSrc() {
/* 114 */     return getSrcImpl(getPeer());
/*     */   }
/*     */   static native String getSrcImpl(long paramLong);
/*     */   
/*     */   public void setSrc(String paramString) {
/* 119 */     setSrcImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSrcImpl(long paramLong, String paramString);
/*     */   
/*     */   public Document getContentDocument() {
/* 124 */     return DocumentImpl.getImpl(getContentDocumentImpl(getPeer()));
/*     */   }
/*     */   static native long getContentDocumentImpl(long paramLong);
/*     */   
/*     */   public AbstractView getContentWindow() {
/* 129 */     return DOMWindowImpl.getImpl(getContentWindowImpl(getPeer()));
/*     */   }
/*     */   static native long getContentWindowImpl(long paramLong);
/*     */   
/*     */   public String getLocation() {
/* 134 */     return getLocationImpl(getPeer());
/*     */   }
/*     */   static native String getLocationImpl(long paramLong);
/*     */   
/*     */   public void setLocation(String paramString) {
/* 139 */     setLocationImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setLocationImpl(long paramLong, String paramString);
/*     */   
/*     */   public int getWidth() {
/* 144 */     return getWidthImpl(getPeer());
/*     */   }
/*     */   static native int getWidthImpl(long paramLong);
/*     */   
/*     */   public int getHeight() {
/* 149 */     return getHeightImpl(getPeer());
/*     */   }
/*     */   
/*     */   static native int getHeightImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLFrameElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */