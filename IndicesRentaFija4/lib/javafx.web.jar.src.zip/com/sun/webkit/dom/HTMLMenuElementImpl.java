/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLMenuElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLMenuElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLMenuElement
/*    */ {
/*    */   HTMLMenuElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLMenuElement getImpl(long paramLong) {
/* 36 */     return (HTMLMenuElement)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getCompact() {
/* 42 */     return getCompactImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCompact(boolean paramBoolean) {
/* 47 */     setCompactImpl(getPeer(), paramBoolean);
/*    */   }
/*    */   
/*    */   static native boolean getCompactImpl(long paramLong);
/*    */   
/*    */   static native void setCompactImpl(long paramLong, boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLMenuElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */