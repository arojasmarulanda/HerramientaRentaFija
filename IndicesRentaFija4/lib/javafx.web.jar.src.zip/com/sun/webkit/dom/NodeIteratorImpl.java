/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.traversal.NodeFilter;
/*     */ import org.w3c.dom.traversal.NodeIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeIteratorImpl
/*     */   implements NodeIterator
/*     */ {
/*     */   private final long peer;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  38 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  41 */       NodeIteratorImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   NodeIteratorImpl(long paramLong) {
/*  46 */     this.peer = paramLong;
/*  47 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static NodeIterator create(long paramLong) {
/*  51 */     if (paramLong == 0L) return null; 
/*  52 */     return new NodeIteratorImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  58 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  62 */     return (paramObject instanceof NodeIteratorImpl && this.peer == ((NodeIteratorImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  66 */     long l = this.peer;
/*  67 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(NodeIterator paramNodeIterator) {
/*  71 */     return (paramNodeIterator == null) ? 0L : ((NodeIteratorImpl)paramNodeIterator).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static NodeIterator getImpl(long paramLong) {
/*  77 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getRoot() {
/*  83 */     return NodeImpl.getImpl(getRootImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWhatToShow() {
/*  88 */     return getWhatToShowImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeFilter getFilter() {
/*  93 */     return NodeFilterImpl.getImpl(getFilterImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getExpandEntityReferences() {
/*  98 */     return getExpandEntityReferencesImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getReferenceNode() {
/* 103 */     return NodeImpl.getImpl(getReferenceNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getPointerBeforeReferenceNode() {
/* 108 */     return getPointerBeforeReferenceNodeImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node nextNode() {
/* 116 */     return NodeImpl.getImpl(nextNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node previousNode() {
/* 123 */     return NodeImpl.getImpl(previousNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void detach() {
/* 130 */     detachImpl(getPeer());
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native long getRootImpl(long paramLong);
/*     */   
/*     */   static native int getWhatToShowImpl(long paramLong);
/*     */   
/*     */   static native long getFilterImpl(long paramLong);
/*     */   
/*     */   static native boolean getExpandEntityReferencesImpl(long paramLong);
/*     */   
/*     */   static native long getReferenceNodeImpl(long paramLong);
/*     */   
/*     */   static native boolean getPointerBeforeReferenceNodeImpl(long paramLong);
/*     */   
/*     */   static native long nextNodeImpl(long paramLong);
/*     */   
/*     */   static native long previousNodeImpl(long paramLong);
/*     */   
/*     */   static native void detachImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\NodeIteratorImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */