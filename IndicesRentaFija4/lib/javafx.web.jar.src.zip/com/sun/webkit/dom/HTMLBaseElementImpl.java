/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLBaseElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLBaseElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLBaseElement
/*    */ {
/*    */   HTMLBaseElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLBaseElement getImpl(long paramLong) {
/* 36 */     return (HTMLBaseElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getHrefImpl(long paramLong);
/*    */   
/*    */   public String getHref() {
/* 42 */     return getHrefImpl(getPeer());
/*    */   }
/*    */   static native void setHrefImpl(long paramLong, String paramString);
/*    */   
/*    */   public void setHref(String paramString) {
/* 47 */     setHrefImpl(getPeer(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTarget() {
/* 52 */     return getTargetImpl(getPeer());
/*    */   }
/*    */   static native String getTargetImpl(long paramLong);
/*    */   
/*    */   public void setTarget(String paramString) {
/* 57 */     setTargetImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setTargetImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLBaseElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */