/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import com.sun.webkit.Invoker;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import netscape.javascript.JSException;
/*     */ import netscape.javascript.JSObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JSObject
/*     */   extends JSObject
/*     */ {
/*  37 */   private static final String UNDEFINED = new String("undefined");
/*     */   
/*     */   static final int JS_CONTEXT_OBJECT = 0;
/*     */   
/*     */   static final int JS_DOM_NODE_OBJECT = 1;
/*     */   
/*     */   static final int JS_DOM_WINDOW_OBJECT = 2;
/*     */   private final long peer;
/*     */   private final int peer_type;
/*  46 */   private static AtomicInteger peerCount = new AtomicInteger();
/*     */   
/*     */   JSObject(long paramLong, int paramInt) {
/*  49 */     this.peer = paramLong;
/*  50 */     this.peer_type = paramInt;
/*     */     
/*  52 */     if (paramInt == 0) {
/*     */ 
/*     */       
/*  55 */       Disposer.addRecord(this, new SelfDisposer(paramLong, paramInt));
/*  56 */       peerCount.incrementAndGet();
/*     */     } 
/*     */   }
/*     */   
/*     */   long getPeer() {
/*  61 */     return this.peer;
/*     */   }
/*     */ 
/*     */   
/*     */   static int test_getPeerCount() {
/*  66 */     return peerCount.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object eval(String paramString) throws JSException {
/*  73 */     Invoker.getInvoker().checkEventThread();
/*  74 */     return evalImpl(this.peer, this.peer_type, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getMember(String paramString) {
/*  81 */     Invoker.getInvoker().checkEventThread();
/*  82 */     return getMemberImpl(this.peer, this.peer_type, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMember(String paramString, Object paramObject) throws JSException {
/*  89 */     Invoker.getInvoker().checkEventThread();
/*  90 */     setMemberImpl(this.peer, this.peer_type, paramString, paramObject, 
/*  91 */         AccessController.getContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeMember(String paramString) throws JSException {
/*  99 */     Invoker.getInvoker().checkEventThread();
/* 100 */     removeMemberImpl(this.peer, this.peer_type, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSlot(int paramInt) throws JSException {
/* 107 */     Invoker.getInvoker().checkEventThread();
/* 108 */     return getSlotImpl(this.peer, this.peer_type, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSlot(int paramInt, Object paramObject) throws JSException {
/* 115 */     Invoker.getInvoker().checkEventThread();
/* 116 */     setSlotImpl(this.peer, this.peer_type, paramInt, paramObject, 
/* 117 */         AccessController.getContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object call(String paramString, Object... paramVarArgs) throws JSException {
/* 125 */     Invoker.getInvoker().checkEventThread();
/* 126 */     return callImpl(this.peer, this.peer_type, paramString, paramVarArgs, 
/* 127 */         AccessController.getContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 135 */     Invoker.getInvoker().checkEventThread();
/* 136 */     return toStringImpl(this.peer, this.peer_type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 142 */     return (paramObject == this || (paramObject != null && paramObject
/* 143 */       .getClass() == JSObject.class && this.peer == ((JSObject)paramObject).peer));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 149 */     return (int)(this.peer ^ this.peer >> 17L);
/*     */   }
/*     */   
/*     */   private static JSException fwkMakeException(Object paramObject) {
/* 153 */     String str = (paramObject == null) ? null : paramObject.toString();
/*     */ 
/*     */ 
/*     */     
/* 157 */     JSException jSException = new JSException((paramObject == null) ? null : paramObject.toString());
/* 158 */     if (paramObject instanceof Throwable)
/* 159 */       jSException.initCause((Throwable)paramObject); 
/* 160 */     return jSException;
/*     */   } private static native void unprotectImpl(long paramLong, int paramInt); private static native Object evalImpl(long paramLong, int paramInt, String paramString); private static native Object getMemberImpl(long paramLong, int paramInt, String paramString); private static native void setMemberImpl(long paramLong, int paramInt, String paramString, Object paramObject, AccessControlContext paramAccessControlContext); private static native void removeMemberImpl(long paramLong, int paramInt, String paramString);
/*     */   private static native Object getSlotImpl(long paramLong, int paramInt1, int paramInt2);
/*     */   private static native void setSlotImpl(long paramLong, int paramInt1, int paramInt2, Object paramObject, AccessControlContext paramAccessControlContext);
/*     */   private static native Object callImpl(long paramLong, int paramInt, String paramString, Object[] paramArrayOfObject, AccessControlContext paramAccessControlContext);
/*     */   private static native String toStringImpl(long paramLong, int paramInt);
/*     */   private static final class SelfDisposer implements DisposerRecord { long peer;
/*     */     private SelfDisposer(long param1Long, int param1Int) {
/* 168 */       this.peer = param1Long;
/* 169 */       this.peer_type = param1Int;
/*     */     }
/*     */     final int peer_type;
/*     */     public void dispose() {
/* 173 */       if (this.peer != 0L) {
/* 174 */         JSObject.unprotectImpl(this.peer, this.peer_type);
/* 175 */         this.peer = 0L;
/* 176 */         JSObject.peerCount.decrementAndGet();
/*     */       } 
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\JSObject.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */