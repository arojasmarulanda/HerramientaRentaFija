/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLUListElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLUListElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLUListElement
/*    */ {
/*    */   HTMLUListElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLUListElement getImpl(long paramLong) {
/* 36 */     return (HTMLUListElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native boolean getCompactImpl(long paramLong);
/*    */   
/*    */   public boolean getCompact() {
/* 42 */     return getCompactImpl(getPeer());
/*    */   }
/*    */   static native void setCompactImpl(long paramLong, boolean paramBoolean);
/*    */   
/*    */   public void setCompact(boolean paramBoolean) {
/* 47 */     setCompactImpl(getPeer(), paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getType() {
/* 52 */     return getTypeImpl(getPeer());
/*    */   }
/*    */   static native String getTypeImpl(long paramLong);
/*    */   
/*    */   public void setType(String paramString) {
/* 57 */     setTypeImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setTypeImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLUListElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */