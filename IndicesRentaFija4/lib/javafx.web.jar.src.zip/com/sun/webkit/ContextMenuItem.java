/*     */ package com.sun.webkit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContextMenuItem
/*     */ {
/*     */   public static final int ACTION_TYPE = 0;
/*     */   public static final int SEPARATOR_TYPE = 1;
/*     */   public static final int SUBMENU_TYPE = 2;
/*     */   private String title;
/*     */   private int action;
/*     */   private boolean isEnabled;
/*     */   private boolean isChecked;
/*     */   private int type;
/*     */   private ContextMenu submenu;
/*     */   
/*     */   public String getTitle() {
/*  42 */     return this.title;
/*     */   } public int getAction() {
/*  44 */     return this.action;
/*     */   } public boolean isEnabled() {
/*  46 */     return this.isEnabled;
/*     */   } public boolean isChecked() {
/*  48 */     return this.isChecked;
/*     */   } public int getType() {
/*  50 */     return this.type;
/*     */   } public ContextMenu getSubmenu() {
/*  52 */     return this.submenu;
/*     */   }
/*     */   public String toString() {
/*  55 */     return String.format("%s[title='%s', action=%d, enabled=%b, checked=%b, type=%d]", new Object[] { super
/*     */           
/*  57 */           .toString(), this.title, Integer.valueOf(this.action), Boolean.valueOf(this.isEnabled), Boolean.valueOf(this.isChecked), Integer.valueOf(this.type) });
/*     */   }
/*     */   
/*     */   private static ContextMenuItem fwkCreateContextMenuItem() {
/*  61 */     return new ContextMenuItem();
/*     */   }
/*     */   
/*     */   private void fwkSetTitle(String paramString) {
/*  65 */     this.title = paramString;
/*     */   }
/*     */   
/*     */   private String fwkGetTitle() {
/*  69 */     return getTitle();
/*     */   }
/*     */   
/*     */   private void fwkSetAction(int paramInt) {
/*  73 */     this.action = paramInt;
/*     */   }
/*     */   
/*     */   private int fwkGetAction() {
/*  77 */     return getAction();
/*     */   }
/*     */   
/*     */   private void fwkSetEnabled(boolean paramBoolean) {
/*  81 */     this.isEnabled = paramBoolean;
/*     */   }
/*     */   
/*     */   private boolean fwkIsEnabled() {
/*  85 */     return isEnabled();
/*     */   }
/*     */   
/*     */   private void fwkSetChecked(boolean paramBoolean) {
/*  89 */     this.isChecked = paramBoolean;
/*     */   }
/*     */   
/*     */   private void fwkSetType(int paramInt) {
/*  93 */     this.type = paramInt;
/*     */   }
/*     */   
/*     */   private int fwkGetType() {
/*  97 */     return getType();
/*     */   }
/*     */   
/*     */   private void fwkSetSubmenu(ContextMenu paramContextMenu) {
/* 101 */     this.submenu = paramContextMenu;
/*     */   }
/*     */   
/*     */   private ContextMenu fwkGetSubmenu() {
/* 105 */     return getSubmenu();
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\ContextMenuItem.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */