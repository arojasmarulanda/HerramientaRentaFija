/*    */ package com.sun.webkit.text;
/*    */ 
/*    */ import java.text.Normalizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TextNormalizer
/*    */ {
/*    */   private static final int FORM_NFC = 0;
/*    */   private static final int FORM_NFD = 1;
/*    */   private static final int FORM_NFKC = 2;
/*    */   private static final int FORM_NFKD = 3;
/*    */   
/*    */   private static String normalize(String paramString, int paramInt) {
/*    */     Normalizer.Form form;
/* 41 */     switch (paramInt) { case 0:
/* 42 */         form = Normalizer.Form.NFC;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 50 */         return Normalizer.normalize(paramString, form);case 1: form = Normalizer.Form.NFD; return Normalizer.normalize(paramString, form);case 2: form = Normalizer.Form.NFKC; return Normalizer.normalize(paramString, form);case 3: form = Normalizer.Form.NFKD; return Normalizer.normalize(paramString, form); }
/*    */     
/*    */     throw new IllegalArgumentException("invalid type: " + paramInt);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\text\TextNormalizer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */