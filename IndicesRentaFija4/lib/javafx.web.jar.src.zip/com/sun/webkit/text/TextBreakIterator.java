/*     */ package com.sun.webkit.text;
/*     */ 
/*     */ import java.text.BreakIterator;
/*     */ import java.text.CharacterIterator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TextBreakIterator
/*     */ {
/*     */   static final int CHARACTER_ITERATOR = 0;
/*     */   static final int WORD_ITERATOR = 1;
/*     */   static final int LINE_ITERATOR = 2;
/*     */   static final int SENTENCE_ITERATOR = 3;
/*     */   static final int TEXT_BREAK_FIRST = 0;
/*     */   static final int TEXT_BREAK_LAST = 1;
/*     */   static final int TEXT_BREAK_NEXT = 2;
/*     */   static final int TEXT_BREAK_PREVIOUS = 3;
/*     */   static final int TEXT_BREAK_CURRENT = 4;
/*     */   static final int TEXT_BREAK_PRECEDING = 5;
/*     */   static final int TEXT_BREAK_FOLLOWING = 6;
/*     */   static final int IS_TEXT_BREAK = 7;
/*     */   static final int IS_WORD_TEXT_BREAK = 8;
/*     */   
/*     */   private static final class CacheKey
/*     */   {
/*     */     private final int type;
/*     */     private final Locale locale;
/*     */     private final int hashCode;
/*     */     
/*     */     CacheKey(int param1Int, Locale param1Locale) {
/*  61 */       this.type = param1Int;
/*  62 */       this.locale = param1Locale;
/*  63 */       this.hashCode = param1Locale.hashCode() + param1Int;
/*     */     }
/*     */     
/*     */     public boolean equals(Object param1Object) {
/*  67 */       if (!(param1Object instanceof CacheKey)) {
/*  68 */         return false;
/*     */       }
/*  70 */       CacheKey cacheKey = (CacheKey)param1Object;
/*  71 */       return (cacheKey.type == this.type && cacheKey.locale.equals(this.locale));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*  75 */       return this.hashCode;
/*     */     }
/*     */   }
/*     */   
/*  79 */   private static final Map<CacheKey, BreakIterator> iteratorCache = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static BreakIterator getIterator(int paramInt, String paramString1, String paramString2, boolean paramBoolean) {
/*     */     String str1;
/*     */     BreakIterator breakIterator;
/*  89 */     String[] arrayOfString = paramString1.split("-");
/*     */     
/*  91 */     switch (arrayOfString.length) { case 1:
/*  92 */         str1 = null; break;
/*  93 */       case 2: str1 = arrayOfString[1]; break;
/*  94 */       default: str1 = arrayOfString[2]; break; }
/*     */     
/*  96 */     String str2 = arrayOfString[0].toLowerCase();
/*     */     
/*  98 */     Locale locale = (str1 == null) ? new Locale(str2) : new Locale(str2, str1.toUpperCase());
/*     */ 
/*     */     
/* 101 */     if (paramBoolean) {
/* 102 */       breakIterator = createIterator(paramInt, locale);
/*     */     } else {
/* 104 */       CacheKey cacheKey = new CacheKey(paramInt, locale);
/* 105 */       breakIterator = iteratorCache.get(cacheKey);
/* 106 */       if (breakIterator == null) {
/* 107 */         breakIterator = createIterator(paramInt, locale);
/* 108 */         iteratorCache.put(cacheKey, breakIterator);
/*     */       } 
/*     */     } 
/* 111 */     breakIterator.setText(paramString2);
/* 112 */     return breakIterator;
/*     */   }
/*     */   
/*     */   private static BreakIterator createIterator(int paramInt, Locale paramLocale) {
/* 116 */     switch (paramInt) {
/*     */       case 0:
/* 118 */         return BreakIterator.getCharacterInstance(paramLocale);
/*     */       case 1:
/* 120 */         return BreakIterator.getWordInstance(paramLocale);
/*     */       case 2:
/* 122 */         return BreakIterator.getLineInstance(paramLocale);
/*     */       case 3:
/* 124 */         return BreakIterator.getSentenceInstance(paramLocale);
/*     */     } 
/* 126 */     throw new IllegalArgumentException("invalid type: " + paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int invokeMethod(BreakIterator paramBreakIterator, int paramInt1, int paramInt2) {
/* 133 */     CharacterIterator characterIterator = paramBreakIterator.getText();
/* 134 */     int i = characterIterator.getEndIndex() - characterIterator.getBeginIndex();
/* 135 */     if (paramInt1 == 5 && paramInt2 > i)
/*     */     {
/* 137 */       return i;
/*     */     }
/* 139 */     if (paramInt2 < 0 || paramInt2 > i) {
/* 140 */       paramInt2 = (paramInt2 < 0) ? 0 : i;
/*     */     }
/*     */     
/* 143 */     switch (paramInt1) { case 0:
/* 144 */         return paramBreakIterator.first();
/* 145 */       case 1: return paramBreakIterator.last();
/* 146 */       case 2: return paramBreakIterator.next();
/* 147 */       case 3: return paramBreakIterator.previous();
/* 148 */       case 4: return paramBreakIterator.current();
/* 149 */       case 5: return paramBreakIterator.preceding(paramInt2);
/* 150 */       case 6: return paramBreakIterator.following(paramInt2);
/* 151 */       case 7: return paramBreakIterator.isBoundary(paramInt2) ? 1 : 0;
/* 152 */       case 8: return 1; }
/*     */     
/* 154 */     throw new IllegalArgumentException("invalid method: " + paramInt1);
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\text\TextBreakIterator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */