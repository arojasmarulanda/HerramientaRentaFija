/*    */ package com.sun.webkit.text;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.CharBuffer;
/*    */ import java.nio.charset.Charset;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.SortedMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TextCodec
/*    */ {
/*    */   private final Charset charset;
/* 40 */   private static final Map<String, String> reMap = new HashMap<>();
/*    */   
/*    */   static {
/* 43 */     reMap.put("ISO-10646-UCS-2", "UTF-16");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private TextCodec(String paramString) {
/* 51 */     this.charset = Charset.forName(paramString);
/*    */   }
/*    */   
/*    */   private byte[] encode(char[] paramArrayOfchar) {
/* 55 */     ByteBuffer byteBuffer = this.charset.encode(CharBuffer.wrap(paramArrayOfchar));
/* 56 */     byte[] arrayOfByte = new byte[byteBuffer.remaining()];
/* 57 */     byteBuffer.get(arrayOfByte);
/* 58 */     return arrayOfByte;
/*    */   }
/*    */   
/*    */   private String decode(byte[] paramArrayOfbyte) {
/* 62 */     CharBuffer charBuffer = this.charset.decode(ByteBuffer.wrap(paramArrayOfbyte));
/* 63 */     char[] arrayOfChar = new char[charBuffer.remaining()];
/* 64 */     charBuffer.get(arrayOfChar);
/* 65 */     return new String(arrayOfChar);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String[] getEncodings() {
/* 77 */     ArrayList<String> arrayList = new ArrayList();
/* 78 */     SortedMap<String, Charset> sortedMap = Charset.availableCharsets();
/* 79 */     for (Map.Entry<String, Charset> entry : sortedMap.entrySet()) {
/* 80 */       String str = (String)entry.getKey();
/* 81 */       arrayList.add(str);
/* 82 */       arrayList.add(str);
/* 83 */       Charset charset = (Charset)entry.getValue();
/* 84 */       for (String str1 : charset.aliases()) {
/*    */ 
/*    */         
/* 87 */         if (str1.equals("8859_1"))
/*    */           continue; 
/* 89 */         arrayList.add(str1);
/* 90 */         String str2 = reMap.get(str1);
/* 91 */         arrayList.add((str2 == null) ? str : str2);
/*    */       } 
/*    */     } 
/* 94 */     return arrayList.<String>toArray(new String[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\text\TextCodec.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */