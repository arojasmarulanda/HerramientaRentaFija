/*    */ package com.sun.webkit.text;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StringCase
/*    */ {
/*    */   private static String toLowerCase(String paramString) {
/* 36 */     return paramString.toLowerCase(Locale.ROOT);
/*    */   }
/*    */   
/*    */   private static String toUpperCase(String paramString) {
/* 40 */     return paramString.toUpperCase(Locale.ROOT);
/*    */   }
/*    */   
/*    */   private static String foldCase(String paramString) {
/* 44 */     return paramString.toUpperCase(Locale.ROOT).toLowerCase(Locale.ROOT);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\text\StringCase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */