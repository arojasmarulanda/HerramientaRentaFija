/*     */ package com.sun.webkit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SharedBuffer
/*     */ {
/*     */   private long nativePointer;
/*     */   
/*     */   SharedBuffer() {
/*  34 */     this.nativePointer = twkCreate();
/*     */   }
/*     */   
/*     */   private SharedBuffer(long paramLong) {
/*  38 */     if (paramLong == 0L) {
/*  39 */       throw new IllegalArgumentException("nativePointer is 0");
/*     */     }
/*  41 */     this.nativePointer = paramLong;
/*     */   }
/*     */ 
/*     */   
/*     */   private static SharedBuffer fwkCreate(long paramLong) {
/*  46 */     return new SharedBuffer(paramLong);
/*     */   }
/*     */   
/*     */   long size() {
/*  50 */     if (this.nativePointer == 0L) {
/*  51 */       throw new IllegalStateException("nativePointer is 0");
/*     */     }
/*  53 */     return twkSize(this.nativePointer);
/*     */   }
/*     */   
/*     */   int getSomeData(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  57 */     if (this.nativePointer == 0L) {
/*  58 */       throw new IllegalStateException("nativePointer is 0");
/*     */     }
/*  60 */     if (paramLong < 0L) {
/*  61 */       throw new IndexOutOfBoundsException("position is negative");
/*     */     }
/*  63 */     if (paramLong > size()) {
/*  64 */       throw new IndexOutOfBoundsException("position is greater than size");
/*     */     }
/*     */     
/*  67 */     if (paramArrayOfbyte == null) {
/*  68 */       throw new NullPointerException("buffer is null");
/*     */     }
/*  70 */     if (paramInt1 < 0) {
/*  71 */       throw new IndexOutOfBoundsException("offset is negative");
/*     */     }
/*  73 */     if (paramInt2 < 0) {
/*  74 */       throw new IndexOutOfBoundsException("length is negative");
/*     */     }
/*  76 */     if (paramInt2 > paramArrayOfbyte.length - paramInt1) {
/*  77 */       throw new IndexOutOfBoundsException("length is greater than buffer.length - offset");
/*     */     }
/*     */     
/*  80 */     return twkGetSomeData(this.nativePointer, paramLong, paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   void append(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  84 */     if (this.nativePointer == 0L) {
/*  85 */       throw new IllegalStateException("nativePointer is 0");
/*     */     }
/*  87 */     if (paramArrayOfbyte == null) {
/*  88 */       throw new NullPointerException("buffer is null");
/*     */     }
/*  90 */     if (paramInt1 < 0) {
/*  91 */       throw new IndexOutOfBoundsException("offset is negative");
/*     */     }
/*  93 */     if (paramInt2 < 0) {
/*  94 */       throw new IndexOutOfBoundsException("length is negative");
/*     */     }
/*  96 */     if (paramInt2 > paramArrayOfbyte.length - paramInt1) {
/*  97 */       throw new IndexOutOfBoundsException("length is greater than buffer.length - offset");
/*     */     }
/*     */     
/* 100 */     twkAppend(this.nativePointer, paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   void dispose() {
/* 104 */     if (this.nativePointer == 0L) {
/* 105 */       throw new IllegalStateException("nativePointer is 0");
/*     */     }
/* 107 */     twkDispose(this.nativePointer);
/* 108 */     this.nativePointer = 0L;
/*     */   }
/*     */   
/*     */   private static native long twkCreate();
/*     */   
/*     */   private static native long twkSize(long paramLong);
/*     */   
/*     */   private static native int twkGetSomeData(long paramLong1, long paramLong2, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*     */   
/*     */   private static native void twkAppend(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*     */   
/*     */   private static native void twkDispose(long paramLong);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\SharedBuffer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */