/*    */ package com.sun.webkit;
/*    */ 
/*    */ import com.sun.javafx.reflect.MethodUtil;
/*    */ import com.sun.javafx.reflect.ReflectUtil;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.security.AccessController;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodHelper
/*    */ {
/* 40 */   private static final boolean logAccessErrors = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("sun.reflect.debugModuleAccessChecks")))).booleanValue();
/*    */ 
/*    */   
/* 43 */   private static final Module trampolineModule = MethodUtil.getTrampolineModule();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object invoke(Method paramMethod, Object paramObject, Object[] paramArrayOfObject) throws InvocationTargetException, IllegalAccessException {
/* 53 */     Class<?> clazz = paramMethod.getDeclaringClass();
/* 54 */     String str = clazz.getPackage().getName();
/* 55 */     Module module1 = clazz.getModule();
/* 56 */     Module module2 = MethodHelper.class.getModule();
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 61 */       if (!module1.isExported(str)) {
/* 62 */         if (!module1.isOpen(str, module2)) {
/* 63 */           throw new IllegalAccessException("module " + module2
/* 64 */               .getName() + " cannot access class " + clazz
/* 65 */               .getName() + " (in module " + module1
/* 66 */               .getName() + ") because module " + module1
/* 67 */               .getName() + " does not open " + str + " to " + module2
/*    */               
/* 69 */               .getName());
/*    */         }
/* 71 */         if (!module1.isOpen(str, trampolineModule)) {
/* 72 */           ReflectUtil.checkPackageAccess(str);
/* 73 */           module1.addOpens(str, trampolineModule);
/*    */         } 
/*    */       } 
/* 76 */     } catch (IllegalAccessException illegalAccessException) {
/* 77 */       if (logAccessErrors) {
/* 78 */         illegalAccessException.printStackTrace(System.err);
/*    */       }
/* 80 */       throw illegalAccessException;
/*    */     } 
/*    */     
/* 83 */     return MethodUtil.invoke(paramMethod, paramObject, paramArrayOfObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\MethodHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */