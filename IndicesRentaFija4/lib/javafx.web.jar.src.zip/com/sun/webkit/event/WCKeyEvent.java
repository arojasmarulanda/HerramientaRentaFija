/*     */ package com.sun.webkit.event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WCKeyEvent
/*     */ {
/*     */   public static final int KEY_TYPED = 0;
/*     */   public static final int KEY_PRESSED = 1;
/*     */   public static final int KEY_RELEASED = 2;
/*     */   public static final int VK_BACK = 8;
/*     */   public static final int VK_TAB = 9;
/*     */   public static final int VK_RETURN = 13;
/*     */   public static final int VK_ESCAPE = 27;
/*     */   public static final int VK_PRIOR = 33;
/*     */   public static final int VK_NEXT = 34;
/*     */   public static final int VK_END = 35;
/*     */   public static final int VK_HOME = 36;
/*     */   public static final int VK_LEFT = 37;
/*     */   public static final int VK_UP = 38;
/*     */   public static final int VK_RIGHT = 39;
/*     */   public static final int VK_DOWN = 40;
/*     */   public static final int VK_INSERT = 45;
/*     */   public static final int VK_DELETE = 46;
/*     */   public static final int VK_OEM_PERIOD = 190;
/*     */   private final int type;
/*     */   private final long when;
/*     */   private final String text;
/*     */   private final String keyIdentifier;
/*     */   private final int windowsVirtualKeyCode;
/*     */   private final boolean shift;
/*     */   private final boolean ctrl;
/*     */   private final boolean alt;
/*     */   private final boolean meta;
/*     */   
/*     */   public WCKeyEvent(int paramInt1, String paramString1, String paramString2, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, long paramLong) {
/*  70 */     this.type = paramInt1;
/*  71 */     this.text = paramString1;
/*  72 */     this.keyIdentifier = paramString2;
/*  73 */     this.windowsVirtualKeyCode = paramInt2;
/*  74 */     this.shift = paramBoolean1;
/*  75 */     this.ctrl = paramBoolean2;
/*  76 */     this.alt = paramBoolean3;
/*  77 */     this.meta = paramBoolean4;
/*  78 */     this.when = paramLong;
/*     */   }
/*     */   
/*     */   public int getType() {
/*  82 */     return this.type;
/*  83 */   } public long getWhen() { return this.when; }
/*  84 */   public String getText() { return this.text; }
/*  85 */   public String getKeyIdentifier() { return this.keyIdentifier; }
/*  86 */   public int getWindowsVirtualKeyCode() { return this.windowsVirtualKeyCode; }
/*  87 */   public boolean isShiftDown() { return this.shift; }
/*  88 */   public boolean isCtrlDown() { return this.ctrl; }
/*  89 */   public boolean isAltDown() { return this.alt; } public boolean isMetaDown() {
/*  90 */     return this.meta;
/*     */   }
/*     */   public static boolean filterEvent(WCKeyEvent paramWCKeyEvent) {
/*  93 */     if (paramWCKeyEvent.getType() == 0) {
/*  94 */       String str = paramWCKeyEvent.getText();
/*  95 */       if (str == null || str.length() != 1) {
/*  96 */         return true;
/*     */       }
/*  98 */       char c = str.charAt(0);
/*     */ 
/*     */       
/* 101 */       if (c == '\b' || c == '\n' || c == '\t' || c == Character.MAX_VALUE || c == '\030' || c == '\033' || c == '')
/*     */       {
/*     */         
/* 104 */         return true;
/*     */       }
/*     */     } 
/* 107 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\event\WCKeyEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */