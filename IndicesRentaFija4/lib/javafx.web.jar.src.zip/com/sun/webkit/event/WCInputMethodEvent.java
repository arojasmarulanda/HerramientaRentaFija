/*    */ package com.sun.webkit.event;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WCInputMethodEvent
/*    */ {
/*    */   public static final int INPUT_METHOD_TEXT_CHANGED = 0;
/*    */   public static final int CARET_POSITION_CHANGED = 1;
/*    */   private final int id;
/*    */   private final String composed;
/*    */   private final String committed;
/*    */   private final int[] attributes;
/*    */   private final int caretPosition;
/*    */   
/*    */   public WCInputMethodEvent(String paramString1, String paramString2, int[] paramArrayOfint, int paramInt) {
/* 43 */     this.id = 0;
/* 44 */     this.composed = paramString1;
/* 45 */     this.committed = paramString2;
/* 46 */     this.attributes = Arrays.copyOf(paramArrayOfint, paramArrayOfint.length);
/* 47 */     this.caretPosition = paramInt;
/*    */   }
/*    */   
/*    */   public WCInputMethodEvent(int paramInt) {
/* 51 */     this.id = 1;
/* 52 */     this.composed = null;
/* 53 */     this.committed = null;
/* 54 */     this.attributes = null;
/* 55 */     this.caretPosition = paramInt;
/*    */   }
/*    */   
/*    */   public int getID() {
/* 59 */     return this.id;
/*    */   }
/*    */   
/*    */   public String getComposed() {
/* 63 */     return this.composed;
/*    */   }
/*    */   
/*    */   public String getCommitted() {
/* 67 */     return this.committed;
/*    */   }
/*    */   
/*    */   public int[] getAttributes() {
/* 71 */     return Arrays.copyOf(this.attributes, this.attributes.length);
/*    */   }
/*    */   
/*    */   public int getCaretPosition() {
/* 75 */     return this.caretPosition;
/*    */   }
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\event\WCInputMethodEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */