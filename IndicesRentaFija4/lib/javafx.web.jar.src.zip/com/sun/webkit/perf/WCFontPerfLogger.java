/*     */ package com.sun.webkit.perf;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.graphics.WCFont;
/*     */ import com.sun.webkit.graphics.WCGlyphBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WCFontPerfLogger
/*     */   extends WCFont
/*     */ {
/*  34 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCFontPerfLogger.class.getName());
/*     */   
/*  36 */   private static final PerfLogger logger = PerfLogger.getLogger(log);
/*     */   
/*     */   private final WCFont fnt;
/*     */   
/*     */   public WCFontPerfLogger(WCFont paramWCFont) {
/*  41 */     this.fnt = paramWCFont;
/*     */   }
/*     */   
/*     */   public static synchronized boolean isEnabled() {
/*  45 */     return logger.isEnabled();
/*     */   }
/*     */   
/*     */   public static void log() {
/*  49 */     logger.log();
/*     */   }
/*     */   
/*     */   public static void reset() {
/*  53 */     logger.reset();
/*     */   }
/*     */   
/*     */   public Object getPlatformFont() {
/*  57 */     return this.fnt.getPlatformFont();
/*     */   }
/*     */   
/*     */   public WCFont deriveFont(float paramFloat) {
/*  61 */     logger.resumeCount("DERIVEFONT");
/*  62 */     WCFont wCFont = this.fnt.deriveFont(paramFloat);
/*  63 */     logger.suspendCount("DERIVEFONT");
/*  64 */     return wCFont;
/*     */   }
/*     */   
/*     */   public int getOffsetForPosition(String paramString, float paramFloat) {
/*  68 */     logger.resumeCount("GETOFFSETFORPOSITION");
/*  69 */     int i = this.fnt.getOffsetForPosition(paramString, paramFloat);
/*  70 */     logger.suspendCount("GETOFFSETFORPOSITION");
/*  71 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public WCGlyphBuffer getGlyphsAndAdvances(String paramString, int paramInt1, int paramInt2, boolean paramBoolean) {
/*  76 */     logger.resumeCount("GETGLYPHSANDADVANCESFORCOMPLEXTEXT");
/*  77 */     WCGlyphBuffer wCGlyphBuffer = this.fnt.getGlyphsAndAdvances(paramString, paramInt1, paramInt2, paramBoolean);
/*  78 */     logger.suspendCount("GETGLYPHSANDADVANCESFORCOMPLEXTEXT");
/*  79 */     return wCGlyphBuffer;
/*     */   }
/*     */   
/*     */   public int[] getGlyphCodes(char[] paramArrayOfchar) {
/*  83 */     logger.resumeCount("GETGLYPHCODES");
/*  84 */     int[] arrayOfInt = this.fnt.getGlyphCodes(paramArrayOfchar);
/*  85 */     logger.suspendCount("GETGLYPHCODES");
/*  86 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   public float getXHeight() {
/*  90 */     logger.resumeCount("GETXHEIGHT");
/*  91 */     float f = this.fnt.getXHeight();
/*  92 */     logger.suspendCount("GETXHEIGHT");
/*  93 */     return f;
/*     */   }
/*     */   
/*     */   public double getGlyphWidth(int paramInt) {
/*  97 */     logger.resumeCount("GETGLYPHWIDTH");
/*  98 */     double d = this.fnt.getGlyphWidth(paramInt);
/*  99 */     logger.suspendCount("GETGLYPHWIDTH");
/* 100 */     return d;
/*     */   }
/*     */   
/*     */   public float[] getGlyphBoundingBox(int paramInt) {
/* 104 */     logger.resumeCount("GETGLYPHBOUNDINGBOX");
/* 105 */     float[] arrayOfFloat = this.fnt.getGlyphBoundingBox(paramInt);
/* 106 */     logger.suspendCount("GETGLYPHBOUNDINGBOX");
/* 107 */     return arrayOfFloat;
/*     */   }
/*     */   
/*     */   public double getStringWidth(String paramString) {
/* 111 */     logger.resumeCount("GETSTRINGLENGTH");
/* 112 */     double d = this.fnt.getStringWidth(paramString);
/* 113 */     logger.suspendCount("GETSTRINGLENGTH");
/* 114 */     return d;
/*     */   }
/*     */   
/*     */   public double[] getStringBounds(String paramString, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 118 */     logger.resumeCount("GETSTRINGBOUNDS");
/* 119 */     double[] arrayOfDouble = this.fnt.getStringBounds(paramString, paramInt1, paramInt2, paramBoolean);
/* 120 */     logger.suspendCount("GETSTRINGBOUNDS");
/* 121 */     return arrayOfDouble;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 125 */     logger.resumeCount("HASH");
/* 126 */     int i = this.fnt.hashCode();
/* 127 */     logger.suspendCount("HASH");
/* 128 */     return i;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 132 */     logger.resumeCount("COMPARE");
/* 133 */     boolean bool = this.fnt.equals(paramObject);
/* 134 */     logger.suspendCount("COMPARE");
/* 135 */     return bool;
/*     */   }
/*     */   
/*     */   public float getAscent() {
/* 139 */     logger.resumeCount("GETASCENT");
/* 140 */     float f = this.fnt.getAscent();
/* 141 */     logger.suspendCount("GETASCENT");
/* 142 */     return f;
/*     */   }
/*     */   
/*     */   public float getDescent() {
/* 146 */     logger.resumeCount("GETDESCENT");
/* 147 */     float f = this.fnt.getDescent();
/* 148 */     logger.suspendCount("GETDESCENT");
/* 149 */     return f;
/*     */   }
/*     */   
/*     */   public float getLineSpacing() {
/* 153 */     logger.resumeCount("GETLINESPACING");
/* 154 */     float f = this.fnt.getLineSpacing();
/* 155 */     logger.suspendCount("GETLINESPACING");
/* 156 */     return f;
/*     */   }
/*     */   
/*     */   public float getLineGap() {
/* 160 */     logger.resumeCount("GETLINEGAP");
/* 161 */     float f = this.fnt.getLineGap();
/* 162 */     logger.suspendCount("GETLINEGAP");
/* 163 */     return f;
/*     */   }
/*     */   
/*     */   public boolean hasUniformLineMetrics() {
/* 167 */     logger.resumeCount("HASUNIFORMLINEMETRICS");
/* 168 */     boolean bool = this.fnt.hasUniformLineMetrics();
/* 169 */     logger.suspendCount("HASUNIFORMLINEMETRICS");
/* 170 */     return bool;
/*     */   }
/*     */   
/*     */   public float getCapHeight() {
/* 174 */     logger.resumeCount("GETCAPHEIGHT");
/* 175 */     float f = this.fnt.getCapHeight();
/* 176 */     logger.suspendCount("GETCAPHEIGHT");
/* 177 */     return f;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\perf\WCFontPerfLogger.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */