/*     */ package com.sun.webkit.perf;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.graphics.Ref;
/*     */ import com.sun.webkit.graphics.RenderTheme;
/*     */ import com.sun.webkit.graphics.ScrollBarTheme;
/*     */ import com.sun.webkit.graphics.WCFont;
/*     */ import com.sun.webkit.graphics.WCGradient;
/*     */ import com.sun.webkit.graphics.WCGraphicsContext;
/*     */ import com.sun.webkit.graphics.WCIcon;
/*     */ import com.sun.webkit.graphics.WCImage;
/*     */ import com.sun.webkit.graphics.WCPath;
/*     */ import com.sun.webkit.graphics.WCPoint;
/*     */ import com.sun.webkit.graphics.WCRectangle;
/*     */ import com.sun.webkit.graphics.WCTransform;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WCGraphicsPerfLogger
/*     */   extends WCGraphicsContext
/*     */ {
/*  45 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCGraphicsPerfLogger.class.getName());
/*     */   
/*  47 */   private static final PerfLogger logger = PerfLogger.getLogger(log);
/*     */   
/*     */   private final WCGraphicsContext gc;
/*     */   
/*     */   public WCGraphicsPerfLogger(WCGraphicsContext paramWCGraphicsContext) {
/*  52 */     this.gc = paramWCGraphicsContext;
/*     */   }
/*     */   
/*     */   public static synchronized boolean isEnabled() {
/*  56 */     return logger.isEnabled();
/*     */   }
/*     */   
/*     */   public static void log() {
/*  60 */     logger.log();
/*     */   }
/*     */   
/*     */   public static void reset() {
/*  64 */     logger.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getPlatformGraphics() {
/*  69 */     return this.gc.getPlatformGraphics();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawString(WCFont paramWCFont, int[] paramArrayOfint, float[] paramArrayOffloat, float paramFloat1, float paramFloat2) {
/*  77 */     logger.resumeCount("DRAWSTRING_GV");
/*  78 */     this.gc.drawString(paramWCFont, paramArrayOfint, paramArrayOffloat, paramFloat1, paramFloat2);
/*  79 */     logger.suspendCount("DRAWSTRING_GV");
/*     */   }
/*     */ 
/*     */   
/*     */   public void strokeRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
/*  84 */     logger.resumeCount("STROKERECT_FFFFF");
/*  85 */     this.gc.strokeRect(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/*  86 */     logger.suspendCount("STROKERECT_FFFFF");
/*     */   }
/*     */ 
/*     */   
/*     */   public void fillRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Integer paramInteger) {
/*  91 */     logger.resumeCount("FILLRECT_FFFFI");
/*  92 */     this.gc.fillRect(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInteger);
/*  93 */     logger.suspendCount("FILLRECT_FFFFI");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fillRoundedRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, int paramInt) {
/* 100 */     logger.resumeCount("FILL_ROUNDED_RECT");
/* 101 */     this.gc.fillRoundedRect(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramInt);
/*     */     
/* 103 */     logger.suspendCount("FILL_ROUNDED_RECT");
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 108 */     logger.resumeCount("CLEARRECT");
/* 109 */     this.gc.clearRect(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 110 */     logger.suspendCount("CLEARRECT");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFillColor(int paramInt) {
/* 115 */     logger.resumeCount("SETFILLCOLOR");
/* 116 */     this.gc.setFillColor(paramInt);
/* 117 */     logger.suspendCount("SETFILLCOLOR");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFillGradient(WCGradient paramWCGradient) {
/* 122 */     logger.resumeCount("SET_FILL_GRADIENT");
/* 123 */     this.gc.setFillGradient(paramWCGradient);
/* 124 */     logger.suspendCount("SET_FILL_GRADIENT");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTextMode(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/* 129 */     logger.resumeCount("SET_TEXT_MODE");
/* 130 */     this.gc.setTextMode(paramBoolean1, paramBoolean2, paramBoolean3);
/* 131 */     logger.suspendCount("SET_TEXT_MODE");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFontSmoothingType(int paramInt) {
/* 136 */     logger.resumeCount("SET_FONT_SMOOTHING_TYPE");
/* 137 */     this.gc.setFontSmoothingType(paramInt);
/* 138 */     logger.suspendCount("SET_FONT_SMOOTHING_TYPE");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFontSmoothingType() {
/* 143 */     logger.resumeCount("GET_FONT_SMOOTHING_TYPE");
/* 144 */     int i = this.gc.getFontSmoothingType();
/* 145 */     logger.suspendCount("GET_FONT_SMOOTHING_TYPE");
/* 146 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStrokeStyle(int paramInt) {
/* 151 */     logger.resumeCount("SETSTROKESTYLE");
/* 152 */     this.gc.setStrokeStyle(paramInt);
/* 153 */     logger.suspendCount("SETSTROKESTYLE");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStrokeColor(int paramInt) {
/* 158 */     logger.resumeCount("SETSTROKECOLOR");
/* 159 */     this.gc.setStrokeColor(paramInt);
/* 160 */     logger.suspendCount("SETSTROKECOLOR");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStrokeWidth(float paramFloat) {
/* 165 */     logger.resumeCount("SETSTROKEWIDTH");
/* 166 */     this.gc.setStrokeWidth(paramFloat);
/* 167 */     logger.suspendCount("SETSTROKEWIDTH");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStrokeGradient(WCGradient paramWCGradient) {
/* 172 */     logger.resumeCount("SET_STROKE_GRADIENT");
/* 173 */     this.gc.setStrokeGradient(paramWCGradient);
/* 174 */     logger.suspendCount("SET_STROKE_GRADIENT");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLineDash(float paramFloat, float... paramVarArgs) {
/* 179 */     logger.resumeCount("SET_LINE_DASH");
/* 180 */     this.gc.setLineDash(paramFloat, paramVarArgs);
/* 181 */     logger.suspendCount("SET_LINE_DASH");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLineCap(int paramInt) {
/* 186 */     logger.resumeCount("SET_LINE_CAP");
/* 187 */     this.gc.setLineCap(paramInt);
/* 188 */     logger.suspendCount("SET_LINE_CAP");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLineJoin(int paramInt) {
/* 193 */     logger.resumeCount("SET_LINE_JOIN");
/* 194 */     this.gc.setLineJoin(paramInt);
/* 195 */     logger.suspendCount("SET_LINE_JOIN");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMiterLimit(float paramFloat) {
/* 200 */     logger.resumeCount("SET_MITER_LIMIT");
/* 201 */     this.gc.setMiterLimit(paramFloat);
/* 202 */     logger.suspendCount("SET_MITER_LIMIT");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShadow(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt) {
/* 207 */     logger.resumeCount("SETSHADOW");
/* 208 */     this.gc.setShadow(paramFloat1, paramFloat2, paramFloat3, paramInt);
/* 209 */     logger.suspendCount("SETSHADOW");
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawPolygon(WCPath paramWCPath, boolean paramBoolean) {
/* 214 */     logger.resumeCount("DRAWPOLYGON");
/* 215 */     this.gc.drawPolygon(paramWCPath, paramBoolean);
/* 216 */     logger.suspendCount("DRAWPOLYGON");
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 221 */     logger.resumeCount("DRAWLINE");
/* 222 */     this.gc.drawLine(paramInt1, paramInt2, paramInt3, paramInt4);
/* 223 */     logger.suspendCount("DRAWLINE");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawImage(WCImage paramWCImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/* 230 */     logger.resumeCount("DRAWIMAGE");
/* 231 */     this.gc.drawImage(paramWCImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/* 232 */     logger.suspendCount("DRAWIMAGE");
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawIcon(WCIcon paramWCIcon, int paramInt1, int paramInt2) {
/* 237 */     logger.resumeCount("DRAWICON");
/* 238 */     this.gc.drawIcon(paramWCIcon, paramInt1, paramInt2);
/* 239 */     logger.suspendCount("DRAWICON");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawPattern(WCImage paramWCImage, WCRectangle paramWCRectangle1, WCTransform paramWCTransform, WCPoint paramWCPoint, WCRectangle paramWCRectangle2) {
/* 246 */     logger.resumeCount("DRAWPATTERN");
/* 247 */     this.gc.drawPattern(paramWCImage, paramWCRectangle1, paramWCTransform, paramWCPoint, paramWCRectangle2);
/* 248 */     logger.suspendCount("DRAWPATTERN");
/*     */   }
/*     */ 
/*     */   
/*     */   public void translate(float paramFloat1, float paramFloat2) {
/* 253 */     logger.resumeCount("TRANSLATE");
/* 254 */     this.gc.translate(paramFloat1, paramFloat2);
/* 255 */     logger.suspendCount("TRANSLATE");
/*     */   }
/*     */ 
/*     */   
/*     */   public void scale(float paramFloat1, float paramFloat2) {
/* 260 */     logger.resumeCount("SCALE");
/* 261 */     this.gc.scale(paramFloat1, paramFloat2);
/* 262 */     logger.suspendCount("SCALE");
/*     */   }
/*     */ 
/*     */   
/*     */   public void rotate(float paramFloat) {
/* 267 */     logger.resumeCount("ROTATE");
/* 268 */     this.gc.rotate(paramFloat);
/* 269 */     logger.suspendCount("ROTATE");
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveState() {
/* 274 */     logger.resumeCount("SAVESTATE");
/* 275 */     this.gc.saveState();
/* 276 */     logger.suspendCount("SAVESTATE");
/*     */   }
/*     */ 
/*     */   
/*     */   public void restoreState() {
/* 281 */     logger.resumeCount("RESTORESTATE");
/* 282 */     this.gc.restoreState();
/* 283 */     logger.suspendCount("RESTORESTATE");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClip(WCPath paramWCPath, boolean paramBoolean) {
/* 288 */     logger.resumeCount("CLIP_PATH");
/* 289 */     this.gc.setClip(paramWCPath, paramBoolean);
/* 290 */     logger.suspendCount("CLIP_PATH");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClip(WCRectangle paramWCRectangle) {
/* 295 */     logger.resumeCount("SETCLIP_R");
/* 296 */     this.gc.setClip(paramWCRectangle);
/* 297 */     logger.suspendCount("SETCLIP_R");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 302 */     logger.resumeCount("SETCLIP_IIII");
/* 303 */     this.gc.setClip(paramInt1, paramInt2, paramInt3, paramInt4);
/* 304 */     logger.suspendCount("SETCLIP_IIII");
/*     */   }
/*     */ 
/*     */   
/*     */   public WCRectangle getClip() {
/* 309 */     logger.resumeCount("SETCLIP_IIII");
/* 310 */     WCRectangle wCRectangle = this.gc.getClip();
/* 311 */     logger.suspendCount("SETCLIP_IIII");
/* 312 */     return wCRectangle;
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 317 */     logger.resumeCount("DRAWRECT");
/* 318 */     this.gc.drawRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 319 */     logger.suspendCount("DRAWRECT");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setComposite(int paramInt) {
/* 324 */     logger.resumeCount("SETCOMPOSITE");
/* 325 */     this.gc.setComposite(paramInt);
/* 326 */     logger.suspendCount("SETCOMPOSITE");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void strokeArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 332 */     logger.resumeCount("STROKEARC");
/* 333 */     this.gc.strokeArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
/* 334 */     logger.suspendCount("STROKEARC");
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawEllipse(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 339 */     logger.resumeCount("DRAWELLIPSE");
/* 340 */     this.gc.drawEllipse(paramInt1, paramInt2, paramInt3, paramInt4);
/* 341 */     logger.suspendCount("DRAWELLIPSE");
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawFocusRing(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 346 */     logger.resumeCount("DRAWFOCUSRING");
/* 347 */     this.gc.drawFocusRing(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 348 */     logger.suspendCount("DRAWFOCUSRING");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAlpha(float paramFloat) {
/* 353 */     logger.resumeCount("SETALPHA");
/* 354 */     this.gc.setAlpha(paramFloat);
/* 355 */     logger.suspendCount("SETALPHA");
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAlpha() {
/* 360 */     logger.resumeCount("GETALPHA");
/* 361 */     float f = this.gc.getAlpha();
/* 362 */     logger.suspendCount("GETALPHA");
/* 363 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public void beginTransparencyLayer(float paramFloat) {
/* 368 */     logger.resumeCount("BEGINTRANSPARENCYLAYER");
/* 369 */     this.gc.beginTransparencyLayer(paramFloat);
/* 370 */     logger.suspendCount("BEGINTRANSPARENCYLAYER");
/*     */   }
/*     */ 
/*     */   
/*     */   public void endTransparencyLayer() {
/* 375 */     logger.resumeCount("ENDTRANSPARENCYLAYER");
/* 376 */     this.gc.endTransparencyLayer();
/* 377 */     logger.suspendCount("ENDTRANSPARENCYLAYER");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawString(WCFont paramWCFont, String paramString, boolean paramBoolean, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
/* 385 */     logger.resumeCount("DRAWSTRING");
/* 386 */     this.gc.drawString(paramWCFont, paramString, paramBoolean, paramInt1, paramInt2, paramFloat1, paramFloat2);
/* 387 */     logger.suspendCount("DRAWSTRING");
/*     */   }
/*     */ 
/*     */   
/*     */   public void strokePath(WCPath paramWCPath) {
/* 392 */     logger.resumeCount("STROKE_PATH");
/* 393 */     this.gc.strokePath(paramWCPath);
/* 394 */     logger.suspendCount("STROKE_PATH");
/*     */   }
/*     */ 
/*     */   
/*     */   public void fillPath(WCPath paramWCPath) {
/* 399 */     logger.resumeCount("FILL_PATH");
/* 400 */     this.gc.fillPath(paramWCPath);
/* 401 */     logger.suspendCount("FILL_PATH");
/*     */   }
/*     */ 
/*     */   
/*     */   public WCImage getImage() {
/* 406 */     logger.resumeCount("GETIMAGE");
/* 407 */     WCImage wCImage = this.gc.getImage();
/* 408 */     logger.suspendCount("GETIMAGE");
/* 409 */     return wCImage;
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawWidget(RenderTheme paramRenderTheme, Ref paramRef, int paramInt1, int paramInt2) {
/* 414 */     logger.resumeCount("DRAWWIDGET");
/* 415 */     this.gc.drawWidget(paramRenderTheme, paramRef, paramInt1, paramInt2);
/* 416 */     logger.suspendCount("DRAWWIDGET");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawScrollbar(ScrollBarTheme paramScrollBarTheme, Ref paramRef, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 423 */     logger.resumeCount("DRAWSCROLLBAR");
/* 424 */     this.gc.drawScrollbar(paramScrollBarTheme, paramRef, paramInt1, paramInt2, paramInt3, paramInt4);
/* 425 */     logger.suspendCount("DRAWSCROLLBAR");
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 430 */     logger.resumeCount("DISPOSE");
/* 431 */     this.gc.dispose();
/* 432 */     logger.suspendCount("DISPOSE");
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() {
/* 437 */     logger.resumeCount("FLUSH");
/* 438 */     this.gc.flush();
/* 439 */     logger.suspendCount("FLUSH");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPerspectiveTransform(WCTransform paramWCTransform) {
/* 444 */     logger.resumeCount("SETPERSPECTIVETRANSFORM");
/* 445 */     this.gc.setPerspectiveTransform(paramWCTransform);
/* 446 */     logger.suspendCount("SETPERSPECTIVETRANSFORM");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransform(WCTransform paramWCTransform) {
/* 451 */     logger.resumeCount("SETTRANSFORM");
/* 452 */     this.gc.setTransform(paramWCTransform);
/* 453 */     logger.suspendCount("SETTRANSFORM");
/*     */   }
/*     */ 
/*     */   
/*     */   public WCTransform getTransform() {
/* 458 */     logger.resumeCount("GETTRANSFORM");
/* 459 */     WCTransform wCTransform = this.gc.getTransform();
/* 460 */     logger.suspendCount("GETTRANSFORM");
/* 461 */     return wCTransform;
/*     */   }
/*     */ 
/*     */   
/*     */   public void concatTransform(WCTransform paramWCTransform) {
/* 466 */     logger.resumeCount("CONCATTRANSFORM");
/* 467 */     this.gc.concatTransform(paramWCTransform);
/* 468 */     logger.suspendCount("CONCATTRANSFORM");
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawBitmapImage(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 473 */     logger.resumeCount("DRAWBITMAPIMAGE");
/* 474 */     this.gc.drawBitmapImage(paramByteBuffer, paramInt1, paramInt2, paramInt3, paramInt4);
/* 475 */     logger.suspendCount("DRAWBITMAPIMAGE");
/*     */   }
/*     */ 
/*     */   
/*     */   public WCGradient createLinearGradient(WCPoint paramWCPoint1, WCPoint paramWCPoint2) {
/* 480 */     logger.resumeCount("CREATE_LINEAR_GRADIENT");
/* 481 */     WCGradient wCGradient = this.gc.createLinearGradient(paramWCPoint1, paramWCPoint2);
/* 482 */     logger.suspendCount("CREATE_LINEAR_GRADIENT");
/* 483 */     return wCGradient;
/*     */   }
/*     */ 
/*     */   
/*     */   public WCGradient createRadialGradient(WCPoint paramWCPoint1, float paramFloat1, WCPoint paramWCPoint2, float paramFloat2) {
/* 488 */     logger.resumeCount("CREATE_RADIAL_GRADIENT");
/* 489 */     WCGradient wCGradient = this.gc.createRadialGradient(paramWCPoint1, paramFloat1, paramWCPoint2, paramFloat2);
/* 490 */     logger.suspendCount("CREATE_RADIAL_GRADIENT");
/* 491 */     return wCGradient;
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\perf\WCGraphicsPerfLogger.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */