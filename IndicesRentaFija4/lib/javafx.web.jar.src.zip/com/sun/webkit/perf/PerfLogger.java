/*     */ package com.sun.webkit.perf;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PerfLogger
/*     */ {
/*     */   private static Thread shutdownHook;
/*     */   private static Map<PlatformLogger, PerfLogger> loggers;
/*  40 */   private final HashMap<String, ProbeStat> probes = new HashMap<>();
/*     */   
/*     */   private final PlatformLogger log;
/*     */   
/*     */   private final boolean isEnabled;
/*     */   
/*     */   private final Comparator timeComparator;
/*     */   
/*     */   private final Comparator countComparator;
/*     */ 
/*     */   
/*     */   public static synchronized PerfLogger getLogger(PlatformLogger paramPlatformLogger) {
/*  52 */     if (loggers == null) {
/*  53 */       loggers = new HashMap<>();
/*     */     }
/*  55 */     PerfLogger perfLogger = loggers.get(paramPlatformLogger);
/*  56 */     if (perfLogger == null) {
/*  57 */       perfLogger = new PerfLogger(paramPlatformLogger);
/*  58 */       loggers.put(paramPlatformLogger, perfLogger);
/*     */     } 
/*     */     
/*  61 */     if (perfLogger.isEnabled() && shutdownHook == null) {
/*  62 */       shutdownHook = new Thread()
/*     */         {
/*     */           public void run() {
/*  65 */             for (PerfLogger perfLogger : PerfLogger.loggers.values()) {
/*  66 */               if (!perfLogger.isEnabled())
/*     */                 continue; 
/*  68 */               perfLogger.log(false);
/*     */             } 
/*     */           }
/*     */         };
/*  72 */       Runtime.getRuntime().addShutdownHook(shutdownHook);
/*     */     } 
/*  74 */     return perfLogger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized PerfLogger getLogger(String paramString) {
/*  84 */     return getLogger(PlatformLogger.getLogger("com.sun.webkit.perf." + paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class ProbeStat
/*     */   {
/*     */     private final String probe;
/*     */ 
/*     */     
/*     */     private int count;
/*     */     
/*     */     private long totalTime;
/*     */     
/*     */     private long startTime;
/*     */     
/*     */     private boolean isRunning = false;
/*     */ 
/*     */     
/*     */     private ProbeStat(String param1String) {
/* 104 */       this.probe = param1String;
/*     */     }
/*     */     
/*     */     public String getProbe() {
/* 108 */       return this.probe;
/*     */     }
/*     */     
/*     */     public int getCount() {
/* 112 */       return this.count;
/*     */     }
/*     */     
/*     */     public long getTotalTime() {
/* 116 */       return this.totalTime;
/*     */     }
/*     */     
/*     */     private void reset() {
/* 120 */       this.count = 0;
/* 121 */       this.totalTime = this.startTime = 0L;
/*     */     }
/*     */     
/*     */     private void suspend() {
/* 125 */       if (this.isRunning) {
/* 126 */         this.totalTime += System.currentTimeMillis() - this.startTime;
/* 127 */         this.isRunning = false;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void resume() {
/* 132 */       this.isRunning = true;
/* 133 */       this.count++;
/* 134 */       this.startTime = System.currentTimeMillis();
/*     */     }
/*     */     
/*     */     private void snapshot() {
/* 138 */       if (this.isRunning) {
/* 139 */         this.totalTime += System.currentTimeMillis() - this.startTime;
/* 140 */         this.startTime = System.currentTimeMillis();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 146 */       return super.toString() + "[count=" + super.toString() + ", time=" + this.count + "]";
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 151 */     return this.isEnabled;
/*     */   }
/*     */   
/*     */   private synchronized String fullName(String paramString) {
/* 155 */     return this.log.getName() + "." + this.log.getName();
/*     */   }
/*     */   private PerfLogger(PlatformLogger paramPlatformLogger) {
/* 158 */     this.timeComparator = ((paramObject1, paramObject2) -> {
/*     */         long l1 = (this.probes.get(paramObject1)).totalTime;
/*     */ 
/*     */         
/*     */         long l2 = (this.probes.get(paramObject2)).totalTime;
/*     */ 
/*     */         
/*     */         return (l1 > l2) ? 1 : ((l1 < l2) ? -1 : 0);
/*     */       });
/*     */ 
/*     */     
/* 169 */     this.countComparator = ((paramObject1, paramObject2) -> {
/*     */         long l1 = (this.probes.get(paramObject1)).count;
/*     */         long l2 = (this.probes.get(paramObject2)).count;
/*     */         return (l1 > l2) ? 1 : ((l1 < l2) ? -1 : 0);
/*     */       });
/*     */     this.log = paramPlatformLogger;
/*     */     this.isEnabled = paramPlatformLogger.isLoggable(PlatformLogger.Level.FINE);
/*     */     startCount("TOTALTIME");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void reset() {
/* 184 */     for (Map.Entry<String, ProbeStat> entry : this.probes.entrySet()) {
/* 185 */       ((ProbeStat)entry.getValue()).reset();
/*     */     }
/* 187 */     startCount("TOTALTIME");
/*     */   }
/*     */   
/*     */   public static synchronized void resetAll() {
/* 191 */     for (PerfLogger perfLogger : loggers.values()) {
/* 192 */       perfLogger.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized ProbeStat registerProbe(String paramString) {
/* 197 */     String str = paramString.intern();
/* 198 */     if (this.probes.containsKey(str)) {
/* 199 */       this.log.fine("Warning: \"" + fullName(str) + "\" probe already exists");
/*     */     } else {
/* 201 */       this.log.fine("Registering \"" + fullName(str) + "\" probe");
/*     */     } 
/* 203 */     ProbeStat probeStat = new ProbeStat(str);
/* 204 */     this.probes.put(str, probeStat);
/* 205 */     return probeStat;
/*     */   }
/*     */   
/*     */   public synchronized ProbeStat getProbeStat(String paramString) {
/* 209 */     String str = paramString.intern();
/* 210 */     ProbeStat probeStat = this.probes.get(str);
/* 211 */     if (probeStat != null) {
/* 212 */       probeStat.snapshot();
/*     */     }
/* 214 */     return probeStat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void startCount(String paramString) {
/* 221 */     if (!isEnabled()) {
/*     */       return;
/*     */     }
/* 224 */     String str = paramString.intern();
/* 225 */     ProbeStat probeStat = this.probes.get(str);
/* 226 */     if (probeStat == null) {
/* 227 */       probeStat = registerProbe(str);
/*     */     }
/* 229 */     probeStat.reset();
/* 230 */     probeStat.resume();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void suspendCount(String paramString) {
/* 237 */     if (!isEnabled()) {
/*     */       return;
/*     */     }
/* 240 */     String str = paramString.intern();
/* 241 */     ProbeStat probeStat = this.probes.get(str);
/* 242 */     if (probeStat != null) {
/* 243 */       probeStat.suspend();
/*     */     } else {
/* 245 */       this.log.fine("Warning: \"" + fullName(str) + "\" probe is not registered");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void resumeCount(String paramString) {
/* 253 */     if (!isEnabled()) {
/*     */       return;
/*     */     }
/* 256 */     String str = paramString.intern();
/* 257 */     ProbeStat probeStat = this.probes.get(str);
/* 258 */     if (probeStat == null) {
/* 259 */       probeStat = registerProbe(str);
/*     */     }
/* 261 */     probeStat.resume();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void log(StringBuffer paramStringBuffer) {
/* 268 */     if (!isEnabled()) {
/*     */       return;
/*     */     }
/* 271 */     paramStringBuffer.append("=========== Performance Statistics =============\n");
/*     */     
/* 273 */     ProbeStat probeStat = getProbeStat("TOTALTIME");
/*     */     
/* 275 */     ArrayList<?> arrayList = new ArrayList();
/* 276 */     arrayList.addAll(this.probes.keySet());
/*     */     
/* 278 */     paramStringBuffer.append("\nTime:\n");
/* 279 */     Collections.sort(arrayList, this.timeComparator);
/* 280 */     for (String str : arrayList) {
/* 281 */       ProbeStat probeStat1 = getProbeStat(str);
/* 282 */       paramStringBuffer.append(String.format("%s: %dms", new Object[] { fullName(str), Long.valueOf(ProbeStat.access$700(probeStat1)) }));
/* 283 */       if (probeStat.totalTime > 0L) {
/* 284 */         paramStringBuffer.append(String.format(", %.2f%%%n", new Object[] { Float.valueOf(100.0F * (float)ProbeStat.access$700(probeStat1) / (float)ProbeStat.access$700(probeStat)) })); continue;
/*     */       } 
/* 286 */       paramStringBuffer.append("\n");
/*     */     } 
/*     */ 
/*     */     
/* 290 */     paramStringBuffer.append("\nInvocations count:\n");
/* 291 */     Collections.sort(arrayList, this.countComparator);
/* 292 */     for (String str : arrayList) {
/* 293 */       paramStringBuffer.append(String.format("%s: %d%n", new Object[] { fullName(str), Integer.valueOf(ProbeStat.access$800(getProbeStat(str))) }));
/*     */     } 
/* 295 */     paramStringBuffer.append("================================================\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void log() {
/* 302 */     log(true);
/*     */   }
/*     */   
/*     */   private synchronized void log(boolean paramBoolean) {
/* 306 */     StringBuffer stringBuffer = new StringBuffer();
/* 307 */     log(stringBuffer);
/* 308 */     if (paramBoolean) {
/* 309 */       this.log.fine(stringBuffer.toString());
/*     */     } else {
/* 311 */       System.out.println(stringBuffer.toString());
/* 312 */       System.out.flush();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void logAll() {
/* 320 */     for (PerfLogger perfLogger : loggers.values())
/* 321 */       perfLogger.log(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\perf\PerfLogger.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */