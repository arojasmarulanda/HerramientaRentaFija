package com.sun.webkit;

import com.sun.webkit.graphics.WCImageFrame;

public interface Pasteboard {
  String getPlainText();
  
  String getHtml();
  
  void writePlainText(String paramString);
  
  void writeSelection(boolean paramBoolean, String paramString1, String paramString2);
  
  void writeImage(WCImageFrame paramWCImageFrame);
  
  void writeUrl(String paramString1, String paramString2);
}


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\Pasteboard.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */