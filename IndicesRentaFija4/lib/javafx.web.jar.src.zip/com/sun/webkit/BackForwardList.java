/*     */ package com.sun.webkit;
/*     */ 
/*     */ import com.sun.webkit.event.WCChangeEvent;
/*     */ import com.sun.webkit.event.WCChangeListener;
/*     */ import com.sun.webkit.graphics.WCImage;
/*     */ import com.sun.webkit.network.URLs;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BackForwardList
/*     */ {
/*     */   private final WebPage page;
/*     */   
/*     */   public static final class Entry
/*     */   {
/*  47 */     private long pitem = 0L;
/*     */ 
/*     */     
/*  50 */     private long ppage = 0L;
/*     */ 
/*     */ 
/*     */     
/*     */     private Entry[] children;
/*     */ 
/*     */     
/*     */     private URL url;
/*     */ 
/*     */     
/*     */     private String title;
/*     */ 
/*     */     
/*     */     private Date lastVisitedDate;
/*     */ 
/*     */     
/*     */     private WCImage icon;
/*     */ 
/*     */     
/*     */     private String target;
/*     */ 
/*     */     
/*     */     private boolean isTargetItem;
/*     */ 
/*     */     
/*     */     private final List<WCChangeListener> listenerList;
/*     */ 
/*     */ 
/*     */     
/*     */     private void notifyItemDestroyed() {
/*  80 */       this.pitem = 0L;
/*     */     }
/*     */ 
/*     */     
/*     */     private void notifyItemChanged() {
/*  85 */       for (WCChangeListener wCChangeListener : this.listenerList) {
/*  86 */         wCChangeListener.stateChanged(new WCChangeEvent(this));
/*     */       }
/*     */     }
/*     */     
/*     */     public URL getURL() {
/*     */       try {
/*  92 */         return (this.pitem == 0L) ? this.url : (this.url = URLs.newURL(BackForwardList.bflItemGetURL(this.pitem)));
/*  93 */       } catch (MalformedURLException malformedURLException) {
/*  94 */         return this.url = null;
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getTitle() {
/*  99 */       return (this.pitem == 0L) ? this.title : (this.title = BackForwardList.bflItemGetTitle(this.pitem));
/*     */     }
/*     */     
/*     */     public WCImage getIcon() {
/* 103 */       return (this.pitem == 0L) ? this.icon : (this.icon = BackForwardList.bflItemGetIcon(this.pitem));
/*     */     }
/*     */     
/*     */     public String getTarget() {
/* 107 */       return (this.pitem == 0L) ? this.target : (this.target = BackForwardList.bflItemGetTarget(this.pitem));
/*     */     }
/*     */     
/*     */     public Date getLastVisitedDate() {
/* 111 */       return (this.lastVisitedDate == null) ? null : (Date)this.lastVisitedDate.clone();
/*     */     }
/*     */     
/*     */     private void updateLastVisitedDate() {
/* 115 */       this.lastVisitedDate = new Date(System.currentTimeMillis());
/* 116 */       notifyItemChanged();
/*     */     }
/*     */     
/*     */     public boolean isTargetItem() {
/* 120 */       return (this.pitem == 0L) ? this.isTargetItem : (this.isTargetItem = BackForwardList.bflItemIsTargetItem(this.pitem));
/*     */     }
/*     */     
/*     */     public Entry[] getChildren() {
/* 124 */       return (this.pitem == 0L) ? this.children : (this.children = BackForwardList.bflItemGetChildren(this.pitem, this.ppage));
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 129 */       return "url=" + getURL() + ",title=" + 
/* 130 */         getTitle() + ",date=" + 
/* 131 */         getLastVisitedDate();
/*     */     }
/*     */     
/*     */     private Entry(long param1Long1, long param1Long2) {
/* 135 */       this.listenerList = new LinkedList<>(); this.pitem = param1Long1; this.ppage = param1Long2; getURL(); getTitle(); getLastVisitedDate();
/*     */       getIcon();
/*     */       getTarget();
/*     */       isTargetItem();
/* 139 */       getChildren(); } public void addChangeListener(WCChangeListener param1WCChangeListener) { if (param1WCChangeListener == null)
/*     */         return; 
/* 141 */       this.listenerList.add(param1WCChangeListener); }
/*     */ 
/*     */     
/*     */     public void removeChangeListener(WCChangeListener param1WCChangeListener) {
/* 145 */       if (param1WCChangeListener == null)
/*     */         return; 
/* 147 */       this.listenerList.remove(param1WCChangeListener);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 152 */   private final List<WCChangeListener> listenerList = new LinkedList<>();
/*     */ 
/*     */   
/*     */   BackForwardList(WebPage paramWebPage) {
/* 156 */     this.page = paramWebPage;
/*     */ 
/*     */ 
/*     */     
/* 160 */     paramWebPage.addLoadListenerClient(new LoadListenerClient()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void dispatchLoadEvent(long param1Long, int param1Int1, String param1String1, String param1String2, double param1Double, int param1Int2)
/*     */           {
/* 168 */             if (param1Int1 == 14) {
/* 169 */               BackForwardList.Entry entry = BackForwardList.this.getCurrentEntry();
/* 170 */               if (entry != null) {
/* 171 */                 entry.updateLastVisitedDate();
/*     */               }
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void dispatchResourceLoadEvent(long param1Long, int param1Int1, String param1String1, String param1String2, double param1Double, int param1Int2) {}
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 187 */     return bflSize(this.page.getPage());
/*     */   }
/*     */   
/*     */   public int getMaximumSize() {
/* 191 */     return bflGetMaximumSize(this.page.getPage());
/*     */   }
/*     */   
/*     */   public void setMaximumSize(int paramInt) {
/* 195 */     bflSetMaximumSize(this.page.getPage(), paramInt);
/*     */   }
/*     */   
/*     */   public int getCurrentIndex() {
/* 199 */     return bflGetCurrentIndex(this.page.getPage());
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 203 */     return (size() == 0);
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean paramBoolean) {
/* 207 */     bflSetEnabled(this.page.getPage(), paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 211 */     return bflIsEnabled(this.page.getPage());
/*     */   }
/*     */   
/*     */   public Entry get(int paramInt) {
/* 215 */     return (Entry)bflGet(this.page.getPage(), paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Entry getCurrentEntry() {
/* 220 */     return get(getCurrentIndex());
/*     */   }
/*     */   
/*     */   public void clearBackForwardListForDRT() {
/* 224 */     bflClearBackForwardListForDRT(this.page.getPage());
/*     */   }
/*     */   
/*     */   public int indexOf(Entry paramEntry) {
/* 228 */     return bflIndexOf(this.page.getPage(), paramEntry.pitem, false);
/*     */   }
/*     */   
/*     */   public boolean contains(Entry paramEntry) {
/* 232 */     return (indexOf(paramEntry) >= 0);
/*     */   }
/*     */   
/*     */   public Entry[] toArray() {
/* 236 */     int i = size();
/* 237 */     Entry[] arrayOfEntry = new Entry[i];
/* 238 */     for (byte b = 0; b < i; b++) {
/* 239 */       arrayOfEntry[b] = get(b);
/*     */     }
/* 241 */     return arrayOfEntry;
/*     */   }
/*     */   
/*     */   public void setCurrentIndex(int paramInt) {
/* 245 */     if (bflSetCurrentIndex(this.page.getPage(), paramInt) < 0) {
/* 246 */       throw new IllegalArgumentException("invalid index: " + paramInt);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean canGoBack(int paramInt) {
/* 251 */     return (paramInt > 0);
/*     */   }
/*     */   
/*     */   public boolean canGoBack() {
/* 255 */     return canGoBack(getCurrentIndex());
/*     */   }
/*     */   
/*     */   public boolean goBack() {
/* 259 */     int i = getCurrentIndex();
/* 260 */     if (canGoBack(i)) {
/* 261 */       setCurrentIndex(i - 1);
/* 262 */       return true;
/*     */     } 
/* 264 */     return false;
/*     */   }
/*     */   
/*     */   private boolean canGoForward(int paramInt) {
/* 268 */     return (paramInt < size() - 1);
/*     */   }
/*     */   
/*     */   public boolean canGoForward() {
/* 272 */     return canGoForward(getCurrentIndex());
/*     */   }
/*     */   
/*     */   public boolean goForward() {
/* 276 */     int i = getCurrentIndex();
/* 277 */     if (canGoForward(i)) {
/* 278 */       setCurrentIndex(i + 1);
/* 279 */       return true;
/*     */     } 
/* 281 */     return false;
/*     */   }
/*     */   
/*     */   public void addChangeListener(WCChangeListener paramWCChangeListener) {
/* 285 */     if (paramWCChangeListener == null) {
/*     */       return;
/*     */     }
/* 288 */     if (this.listenerList.isEmpty()) {
/* 289 */       bflSetHostObject(this.page.getPage(), this);
/*     */     }
/* 291 */     this.listenerList.add(paramWCChangeListener);
/*     */   }
/*     */   
/*     */   public void removeChangeListener(WCChangeListener paramWCChangeListener) {
/* 295 */     if (paramWCChangeListener == null) {
/*     */       return;
/*     */     }
/* 298 */     this.listenerList.remove(paramWCChangeListener);
/* 299 */     if (this.listenerList.isEmpty()) {
/* 300 */       bflSetHostObject(this.page.getPage(), null);
/*     */     }
/*     */   }
/*     */   
/*     */   public WCChangeListener[] getChangeListeners() {
/* 305 */     return this.listenerList.<WCChangeListener>toArray(new WCChangeListener[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private void notifyChanged() {
/* 310 */     for (WCChangeListener wCChangeListener : this.listenerList)
/* 311 */       wCChangeListener.stateChanged(new WCChangeEvent(this)); 
/*     */   }
/*     */   
/*     */   private static native String bflItemGetURL(long paramLong);
/*     */   
/*     */   private static native String bflItemGetTitle(long paramLong);
/*     */   
/*     */   private static native WCImage bflItemGetIcon(long paramLong);
/*     */   
/*     */   private static native long bflItemGetLastVisitedDate(long paramLong);
/*     */   
/*     */   private static native boolean bflItemIsTargetItem(long paramLong);
/*     */   
/*     */   private static native Entry[] bflItemGetChildren(long paramLong1, long paramLong2);
/*     */   
/*     */   private static native String bflItemGetTarget(long paramLong);
/*     */   
/*     */   private static native void bflClearBackForwardListForDRT(long paramLong);
/*     */   
/*     */   private static native int bflSize(long paramLong);
/*     */   
/*     */   private static native int bflGetMaximumSize(long paramLong);
/*     */   
/*     */   private static native void bflSetMaximumSize(long paramLong, int paramInt);
/*     */   
/*     */   private static native int bflGetCurrentIndex(long paramLong);
/*     */   
/*     */   private static native int bflIndexOf(long paramLong1, long paramLong2, boolean paramBoolean);
/*     */   
/*     */   private static native void bflSetEnabled(long paramLong, boolean paramBoolean);
/*     */   
/*     */   private static native boolean bflIsEnabled(long paramLong);
/*     */   
/*     */   private static native Object bflGet(long paramLong, int paramInt);
/*     */   
/*     */   private static native int bflSetCurrentIndex(long paramLong, int paramInt);
/*     */   
/*     */   private static native void bflSetHostObject(long paramLong, Object paramObject);
/*     */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\BackForwardList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */