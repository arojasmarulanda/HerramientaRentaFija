/*    */ package com.sun.webkit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MainThread
/*    */ {
/*    */   private static void fwkScheduleDispatchFunctions() {
/* 34 */     Invoker.getInvoker().postOnEventThread(() -> twkScheduleDispatchFunctions());
/*    */   }
/*    */   
/*    */   private static native void twkScheduleDispatchFunctions();
/*    */ }


/* Location:              C:\Users\arojasm\Downloads\IndicesRentaFija3.jar!\javafx.web.jar!\com\sun\webkit\MainThread.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */